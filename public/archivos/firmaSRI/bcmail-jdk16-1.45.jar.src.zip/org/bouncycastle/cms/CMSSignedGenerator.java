package org.bouncycastle.cms;

import java.io.IOException;
import java.io.OutputStream;
import java.security.AlgorithmParameters;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.CertStore;
import java.security.cert.CertStoreException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.security.interfaces.DSAPrivateKey;
import java.security.interfaces.RSAPrivateKey;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.CMSObjectIdentifiers;
import org.bouncycastle.asn1.cms.IssuerAndSerialNumber;
import org.bouncycastle.asn1.cms.SignerIdentifier;
import org.bouncycastle.asn1.cryptopro.CryptoProObjectIdentifiers;
import org.bouncycastle.asn1.nist.NISTObjectIdentifiers;
import org.bouncycastle.asn1.oiw.OIWObjectIdentifiers;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.teletrust.TeleTrusTObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.AttributeCertificate;
import org.bouncycastle.asn1.x509.TBSCertificateStructure;
import org.bouncycastle.asn1.x9.X9ObjectIdentifiers;
import org.bouncycastle.jce.interfaces.GOST3410PrivateKey;
import org.bouncycastle.x509.X509AttributeCertificate;
import org.bouncycastle.x509.X509Store;

public class CMSSignedGenerator
{
  public static final String DATA = CMSObjectIdentifiers.data.getId();
  public static final String DIGEST_SHA1 = OIWObjectIdentifiers.idSHA1.getId();
  public static final String DIGEST_SHA224 = NISTObjectIdentifiers.id_sha224.getId();
  public static final String DIGEST_SHA256 = NISTObjectIdentifiers.id_sha256.getId();
  public static final String DIGEST_SHA384 = NISTObjectIdentifiers.id_sha384.getId();
  public static final String DIGEST_SHA512 = NISTObjectIdentifiers.id_sha512.getId();
  public static final String DIGEST_MD5 = PKCSObjectIdentifiers.md5.getId();
  public static final String DIGEST_GOST3411 = CryptoProObjectIdentifiers.gostR3411.getId();
  public static final String DIGEST_RIPEMD128 = TeleTrusTObjectIdentifiers.ripemd128.getId();
  public static final String DIGEST_RIPEMD160 = TeleTrusTObjectIdentifiers.ripemd160.getId();
  public static final String DIGEST_RIPEMD256 = TeleTrusTObjectIdentifiers.ripemd256.getId();
  public static final String ENCRYPTION_RSA = PKCSObjectIdentifiers.rsaEncryption.getId();
  public static final String ENCRYPTION_DSA = X9ObjectIdentifiers.id_dsa_with_sha1.getId();
  public static final String ENCRYPTION_ECDSA = X9ObjectIdentifiers.ecdsa_with_SHA1.getId();
  public static final String ENCRYPTION_RSA_PSS = PKCSObjectIdentifiers.id_RSASSA_PSS.getId();
  public static final String ENCRYPTION_GOST3410 = CryptoProObjectIdentifiers.gostR3410_94.getId();
  public static final String ENCRYPTION_ECGOST3410 = CryptoProObjectIdentifiers.gostR3410_2001.getId();
  private static final String ENCRYPTION_ECDSA_WITH_SHA1 = X9ObjectIdentifiers.ecdsa_with_SHA1.getId();
  private static final String ENCRYPTION_ECDSA_WITH_SHA224 = X9ObjectIdentifiers.ecdsa_with_SHA224.getId();
  private static final String ENCRYPTION_ECDSA_WITH_SHA256 = X9ObjectIdentifiers.ecdsa_with_SHA256.getId();
  private static final String ENCRYPTION_ECDSA_WITH_SHA384 = X9ObjectIdentifiers.ecdsa_with_SHA384.getId();
  private static final String ENCRYPTION_ECDSA_WITH_SHA512 = X9ObjectIdentifiers.ecdsa_with_SHA512.getId();
  private static final Set NO_PARAMS = new HashSet();
  private static final Map EC_ALGORITHMS = new HashMap();
  protected List _certs = new ArrayList();
  protected List _crls = new ArrayList();
  protected List _signers = new ArrayList();
  protected Map _digests = new HashMap();
  protected final SecureRandom rand;
  
  protected CMSSignedGenerator()
  {
    this(new SecureRandom());
  }
  
  protected CMSSignedGenerator(SecureRandom paramSecureRandom)
  {
    this.rand = paramSecureRandom;
  }
  
  protected String getEncOID(PrivateKey paramPrivateKey, String paramString)
  {
    String str = null;
    if (((paramPrivateKey instanceof RSAPrivateKey)) || ("RSA".equalsIgnoreCase(paramPrivateKey.getAlgorithm())))
    {
      str = ENCRYPTION_RSA;
    }
    else if (((paramPrivateKey instanceof DSAPrivateKey)) || ("DSA".equalsIgnoreCase(paramPrivateKey.getAlgorithm())))
    {
      str = ENCRYPTION_DSA;
      if (!paramString.equals(DIGEST_SHA1)) {
        throw new IllegalArgumentException("can't mix DSA with anything but SHA1");
      }
    }
    else if (("ECDSA".equalsIgnoreCase(paramPrivateKey.getAlgorithm())) || ("EC".equalsIgnoreCase(paramPrivateKey.getAlgorithm())))
    {
      str = (String)EC_ALGORITHMS.get(paramString);
      if (str == null) {
        throw new IllegalArgumentException("can't mix ECDSA with anything but SHA family digests");
      }
    }
    else if (((paramPrivateKey instanceof GOST3410PrivateKey)) || ("GOST3410".equalsIgnoreCase(paramPrivateKey.getAlgorithm())))
    {
      str = ENCRYPTION_GOST3410;
    }
    else if ("ECGOST3410".equalsIgnoreCase(paramPrivateKey.getAlgorithm()))
    {
      str = ENCRYPTION_ECGOST3410;
    }
    return str;
  }
  
  protected AlgorithmIdentifier getEncAlgorithmIdentifier(String paramString, Signature paramSignature)
    throws IOException
  {
    if (NO_PARAMS.contains(paramString)) {
      return new AlgorithmIdentifier(new DERObjectIdentifier(paramString));
    }
    if (paramString.equals(ENCRYPTION_RSA_PSS))
    {
      AlgorithmParameters localAlgorithmParameters = paramSignature.getParameters();
      return new AlgorithmIdentifier(new DERObjectIdentifier(paramString), ASN1Object.fromByteArray(localAlgorithmParameters.getEncoded()));
    }
    return new AlgorithmIdentifier(new DERObjectIdentifier(paramString), new DERNull());
  }
  
  protected Map getBaseParameters(DERObjectIdentifier paramDERObjectIdentifier, AlgorithmIdentifier paramAlgorithmIdentifier, byte[] paramArrayOfByte)
  {
    HashMap localHashMap = new HashMap();
    localHashMap.put("contentType", paramDERObjectIdentifier);
    localHashMap.put("digestAlgID", paramAlgorithmIdentifier);
    localHashMap.put("digest", paramArrayOfByte.clone());
    return localHashMap;
  }
  
  protected ASN1Set getAttributeSet(AttributeTable paramAttributeTable)
  {
    if (paramAttributeTable != null) {
      return new DERSet(paramAttributeTable.toASN1EncodableVector());
    }
    return null;
  }
  
  public void addCertificatesAndCRLs(CertStore paramCertStore)
    throws CertStoreException, CMSException
  {
    this._certs.addAll(CMSUtils.getCertificatesFromStore(paramCertStore));
    this._crls.addAll(CMSUtils.getCRLsFromStore(paramCertStore));
  }
  
  public void addAttributeCertificates(X509Store paramX509Store)
    throws CMSException
  {
    try
    {
      Iterator localIterator = paramX509Store.getMatches(null).iterator();
      while (localIterator.hasNext())
      {
        X509AttributeCertificate localX509AttributeCertificate = (X509AttributeCertificate)localIterator.next();
        this._certs.add(new DERTaggedObject(false, 2, AttributeCertificate.getInstance(ASN1Object.fromByteArray(localX509AttributeCertificate.getEncoded()))));
      }
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      throw new CMSException("error processing attribute certs", localIllegalArgumentException);
    }
    catch (IOException localIOException)
    {
      throw new CMSException("error processing attribute certs", localIOException);
    }
  }
  
  public void addSigners(SignerInformationStore paramSignerInformationStore)
  {
    Iterator localIterator = paramSignerInformationStore.getSigners().iterator();
    while (localIterator.hasNext()) {
      this._signers.add(localIterator.next());
    }
  }
  
  public Map getGeneratedDigests()
  {
    return new HashMap(this._digests);
  }
  
  static SignerIdentifier getSignerIdentifier(X509Certificate paramX509Certificate)
  {
    TBSCertificateStructure localTBSCertificateStructure;
    try
    {
      localTBSCertificateStructure = CMSUtils.getTBSCertificateStructure(paramX509Certificate);
    }
    catch (CertificateEncodingException localCertificateEncodingException)
    {
      throw new IllegalArgumentException("can't extract TBS structure from this cert");
    }
    IssuerAndSerialNumber localIssuerAndSerialNumber = new IssuerAndSerialNumber(localTBSCertificateStructure.getIssuer(), localTBSCertificateStructure.getSerialNumber().getValue());
    return new SignerIdentifier(localIssuerAndSerialNumber);
  }
  
  static SignerIdentifier getSignerIdentifier(byte[] paramArrayOfByte)
  {
    return new SignerIdentifier(new DEROctetString(paramArrayOfByte));
  }
  
  static
  {
    NO_PARAMS.add(ENCRYPTION_DSA);
    NO_PARAMS.add(ENCRYPTION_ECDSA);
    NO_PARAMS.add(ENCRYPTION_ECDSA_WITH_SHA1);
    NO_PARAMS.add(ENCRYPTION_ECDSA_WITH_SHA224);
    NO_PARAMS.add(ENCRYPTION_ECDSA_WITH_SHA256);
    NO_PARAMS.add(ENCRYPTION_ECDSA_WITH_SHA384);
    NO_PARAMS.add(ENCRYPTION_ECDSA_WITH_SHA512);
    EC_ALGORITHMS.put(DIGEST_SHA1, ENCRYPTION_ECDSA_WITH_SHA1);
    EC_ALGORITHMS.put(DIGEST_SHA224, ENCRYPTION_ECDSA_WITH_SHA224);
    EC_ALGORITHMS.put(DIGEST_SHA256, ENCRYPTION_ECDSA_WITH_SHA256);
    EC_ALGORITHMS.put(DIGEST_SHA384, ENCRYPTION_ECDSA_WITH_SHA384);
    EC_ALGORITHMS.put(DIGEST_SHA512, ENCRYPTION_ECDSA_WITH_SHA512);
  }
  
  static class DigOutputStream
    extends OutputStream
  {
    MessageDigest dig;
    
    public DigOutputStream(MessageDigest paramMessageDigest)
    {
      this.dig = paramMessageDigest;
    }
    
    public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {
      this.dig.update(paramArrayOfByte, paramInt1, paramInt2);
    }
    
    public void write(int paramInt)
      throws IOException
    {
      this.dig.update((byte)paramInt);
    }
  }
  
  static class SigOutputStream
    extends OutputStream
  {
    private final Signature sig;
    
    public SigOutputStream(Signature paramSignature)
    {
      this.sig = paramSignature;
    }
    
    public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {
      try
      {
        this.sig.update(paramArrayOfByte, paramInt1, paramInt2);
      }
      catch (SignatureException localSignatureException)
      {
        throw new CMSStreamException("signature problem: " + localSignatureException, localSignatureException);
      }
    }
    
    public void write(int paramInt)
      throws IOException
    {
      try
      {
        this.sig.update((byte)paramInt);
      }
      catch (SignatureException localSignatureException)
      {
        throw new CMSStreamException("signature problem: " + localSignatureException, localSignatureException);
      }
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSSignedGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */