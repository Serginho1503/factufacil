package org.bouncycastle.cms;

import java.io.IOException;
import java.io.OutputStream;
import java.security.AlgorithmParameters;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.SecureRandom;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.BERSequenceGenerator;
import org.bouncycastle.asn1.BERSet;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.cms.CMSObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class CMSEnvelopedDataStreamGenerator
  extends CMSEnvelopedGenerator
{
  private Object _originatorInfo = null;
  private Object _unprotectedAttributes = null;
  private int _bufferSize;
  private boolean _berEncodeRecipientSet;
  
  public CMSEnvelopedDataStreamGenerator() {}
  
  public CMSEnvelopedDataStreamGenerator(SecureRandom paramSecureRandom)
  {
    super(paramSecureRandom);
  }
  
  public void setBufferSize(int paramInt)
  {
    this._bufferSize = paramInt;
  }
  
  public void setBEREncodeRecipients(boolean paramBoolean)
  {
    this._berEncodeRecipientSet = paramBoolean;
  }
  
  private DERInteger getVersion()
  {
    if ((this._originatorInfo != null) || (this._unprotectedAttributes != null)) {
      return new DERInteger(2);
    }
    return new DERInteger(0);
  }
  
  private OutputStream open(OutputStream paramOutputStream, String paramString, KeyGenerator paramKeyGenerator, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException
  {
    Provider localProvider = paramKeyGenerator.getProvider();
    SecretKey localSecretKey = paramKeyGenerator.generateKey();
    AlgorithmParameters localAlgorithmParameters = generateParameters(paramString, localSecretKey, localProvider);
    Iterator localIterator = this.recipientInfoGenerators.iterator();
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    while (localIterator.hasNext())
    {
      RecipientInfoGenerator localRecipientInfoGenerator = (RecipientInfoGenerator)localIterator.next();
      try
      {
        localASN1EncodableVector.add(localRecipientInfoGenerator.generate(localSecretKey, this.rand, paramProvider));
      }
      catch (InvalidKeyException localInvalidKeyException)
      {
        throw new CMSException("key inappropriate for algorithm.", localInvalidKeyException);
      }
      catch (GeneralSecurityException localGeneralSecurityException)
      {
        throw new CMSException("error making encrypted content.", localGeneralSecurityException);
      }
    }
    return open(paramOutputStream, paramString, localSecretKey, localAlgorithmParameters, localASN1EncodableVector, localProvider);
  }
  
  protected OutputStream open(OutputStream paramOutputStream, String paramString1, SecretKey paramSecretKey, AlgorithmParameters paramAlgorithmParameters, ASN1EncodableVector paramASN1EncodableVector, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    return open(paramOutputStream, paramString1, paramSecretKey, paramAlgorithmParameters, paramASN1EncodableVector, CMSUtils.getProvider(paramString2));
  }
  
  protected OutputStream open(OutputStream paramOutputStream, String paramString, SecretKey paramSecretKey, AlgorithmParameters paramAlgorithmParameters, ASN1EncodableVector paramASN1EncodableVector, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException
  {
    try
    {
      BERSequenceGenerator localBERSequenceGenerator1 = new BERSequenceGenerator(paramOutputStream);
      localBERSequenceGenerator1.addObject(CMSObjectIdentifiers.envelopedData);
      BERSequenceGenerator localBERSequenceGenerator2 = new BERSequenceGenerator(localBERSequenceGenerator1.getRawOutputStream(), 0, true);
      localBERSequenceGenerator2.addObject(getVersion());
      if (this._berEncodeRecipientSet) {
        localBERSequenceGenerator2.getRawOutputStream().write(new BERSet(paramASN1EncodableVector).getEncoded());
      } else {
        localBERSequenceGenerator2.getRawOutputStream().write(new DERSet(paramASN1EncodableVector).getEncoded());
      }
      Cipher localCipher = CMSEnvelopedHelper.INSTANCE.getSymmetricCipher(paramString, paramProvider);
      localCipher.init(1, paramSecretKey, paramAlgorithmParameters, this.rand);
      BERSequenceGenerator localBERSequenceGenerator3 = new BERSequenceGenerator(localBERSequenceGenerator2.getRawOutputStream());
      localBERSequenceGenerator3.addObject(CMSObjectIdentifiers.data);
      if (paramAlgorithmParameters == null) {
        paramAlgorithmParameters = localCipher.getParameters();
      }
      AlgorithmIdentifier localAlgorithmIdentifier = getAlgorithmIdentifier(paramString, paramAlgorithmParameters);
      localBERSequenceGenerator3.getRawOutputStream().write(localAlgorithmIdentifier.getEncoded());
      OutputStream localOutputStream = CMSUtils.createBEROctetOutputStream(localBERSequenceGenerator3.getRawOutputStream(), 0, false, this._bufferSize);
      CipherOutputStream localCipherOutputStream = new CipherOutputStream(localOutputStream, localCipher);
      return new CmsEnvelopedDataOutputStream(localCipherOutputStream, localBERSequenceGenerator1, localBERSequenceGenerator2, localBERSequenceGenerator3);
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new CMSException("key invalid in message.", localInvalidKeyException);
    }
    catch (NoSuchPaddingException localNoSuchPaddingException)
    {
      throw new CMSException("required padding not supported.", localNoSuchPaddingException);
    }
    catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
    {
      throw new CMSException("algorithm parameters invalid.", localInvalidAlgorithmParameterException);
    }
    catch (IOException localIOException)
    {
      throw new CMSException("exception decoding algorithm parameters.", localIOException);
    }
  }
  
  public OutputStream open(OutputStream paramOutputStream, String paramString1, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException, IOException
  {
    return open(paramOutputStream, paramString1, CMSUtils.getProvider(paramString2));
  }
  
  public OutputStream open(OutputStream paramOutputStream, String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException, IOException
  {
    KeyGenerator localKeyGenerator = CMSEnvelopedHelper.INSTANCE.createSymmetricKeyGenerator(paramString, paramProvider);
    localKeyGenerator.init(this.rand);
    return open(paramOutputStream, paramString, localKeyGenerator, paramProvider);
  }
  
  public OutputStream open(OutputStream paramOutputStream, String paramString1, int paramInt, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException, IOException
  {
    return open(paramOutputStream, paramString1, paramInt, CMSUtils.getProvider(paramString2));
  }
  
  public OutputStream open(OutputStream paramOutputStream, String paramString, int paramInt, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException, IOException
  {
    KeyGenerator localKeyGenerator = CMSEnvelopedHelper.INSTANCE.createSymmetricKeyGenerator(paramString, paramProvider);
    localKeyGenerator.init(paramInt, this.rand);
    return open(paramOutputStream, paramString, localKeyGenerator, paramProvider);
  }
  
  private class CmsEnvelopedDataOutputStream
    extends OutputStream
  {
    private CipherOutputStream _out;
    private BERSequenceGenerator _cGen;
    private BERSequenceGenerator _envGen;
    private BERSequenceGenerator _eiGen;
    
    public CmsEnvelopedDataOutputStream(CipherOutputStream paramCipherOutputStream, BERSequenceGenerator paramBERSequenceGenerator1, BERSequenceGenerator paramBERSequenceGenerator2, BERSequenceGenerator paramBERSequenceGenerator3)
    {
      this._out = paramCipherOutputStream;
      this._cGen = paramBERSequenceGenerator1;
      this._envGen = paramBERSequenceGenerator2;
      this._eiGen = paramBERSequenceGenerator3;
    }
    
    public void write(int paramInt)
      throws IOException
    {
      this._out.write(paramInt);
    }
    
    public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {
      this._out.write(paramArrayOfByte, paramInt1, paramInt2);
    }
    
    public void write(byte[] paramArrayOfByte)
      throws IOException
    {
      this._out.write(paramArrayOfByte);
    }
    
    public void close()
      throws IOException
    {
      this._out.close();
      this._eiGen.close();
      this._envGen.close();
      this._cGen.close();
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSEnvelopedDataStreamGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */