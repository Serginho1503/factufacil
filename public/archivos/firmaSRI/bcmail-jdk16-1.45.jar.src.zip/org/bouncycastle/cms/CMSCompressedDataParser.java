package org.bouncycastle.cms;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.InflaterInputStream;
import org.bouncycastle.asn1.ASN1OctetStringParser;
import org.bouncycastle.asn1.ASN1SequenceParser;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cms.CompressedDataParser;
import org.bouncycastle.asn1.cms.ContentInfoParser;

public class CMSCompressedDataParser
  extends CMSContentInfoParser
{
  public CMSCompressedDataParser(byte[] paramArrayOfByte)
    throws CMSException
  {
    this(new ByteArrayInputStream(paramArrayOfByte));
  }
  
  public CMSCompressedDataParser(InputStream paramInputStream)
    throws CMSException
  {
    super(paramInputStream);
  }
  
  public CMSTypedStream getContent()
    throws CMSException
  {
    try
    {
      CompressedDataParser localCompressedDataParser = new CompressedDataParser((ASN1SequenceParser)this._contentInfo.getContent(16));
      ContentInfoParser localContentInfoParser = localCompressedDataParser.getEncapContentInfo();
      ASN1OctetStringParser localASN1OctetStringParser = (ASN1OctetStringParser)localContentInfoParser.getContent(4);
      return new CMSTypedStream(localContentInfoParser.getContentType().toString(), new InflaterInputStream(localASN1OctetStringParser.getOctetStream()));
    }
    catch (IOException localIOException)
    {
      throw new CMSException("IOException reading compressed content.", localIOException);
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSCompressedDataParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */