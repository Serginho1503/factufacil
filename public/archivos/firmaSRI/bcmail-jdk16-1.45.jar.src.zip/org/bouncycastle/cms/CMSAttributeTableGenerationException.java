package org.bouncycastle.cms;

public class CMSAttributeTableGenerationException
  extends CMSRuntimeException
{
  Exception e;
  
  public CMSAttributeTableGenerationException(String paramString)
  {
    super(paramString);
  }
  
  public CMSAttributeTableGenerationException(String paramString, Exception paramException)
  {
    super(paramString);
    this.e = paramException;
  }
  
  public Exception getUnderlyingException()
  {
    return this.e;
  }
  
  public Throwable getCause()
  {
    return this.e;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSAttributeTableGenerationException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */