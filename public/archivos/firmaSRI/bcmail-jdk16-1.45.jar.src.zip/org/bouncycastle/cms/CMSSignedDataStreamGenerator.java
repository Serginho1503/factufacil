package org.bouncycastle.cms;

import java.io.IOException;
import java.io.OutputStream;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.BERSequenceGenerator;
import org.bouncycastle.asn1.BERTaggedObject;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DEREncodableVector;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.CMSObjectIdentifiers;
import org.bouncycastle.asn1.cms.SignerIdentifier;
import org.bouncycastle.asn1.cms.SignerInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.DigestInfo;

public class CMSSignedDataStreamGenerator
  extends CMSSignedGenerator
{
  private List _signerInfs = new ArrayList();
  private List _messageDigests = new ArrayList();
  private int _bufferSize;
  
  public CMSSignedDataStreamGenerator() {}
  
  public CMSSignedDataStreamGenerator(SecureRandom paramSecureRandom)
  {
    super(paramSecureRandom);
  }
  
  public void setBufferSize(int paramInt)
  {
    this._bufferSize = paramInt;
  }
  
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramX509Certificate, paramString1, new DefaultSignedAttributeTableGenerator(), (CMSAttributeTableGenerator)null, paramString2);
  }
  
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2, String paramString3)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramX509Certificate, paramString1, paramString2, new DefaultSignedAttributeTableGenerator(), (CMSAttributeTableGenerator)null, paramString3);
  }
  
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramX509Certificate, paramString, new DefaultSignedAttributeTableGenerator(), (CMSAttributeTableGenerator)null, paramProvider);
  }
  
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramX509Certificate, paramString1, paramString2, new DefaultSignedAttributeTableGenerator(), (CMSAttributeTableGenerator)null, paramProvider);
  }
  
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, AttributeTable paramAttributeTable1, AttributeTable paramAttributeTable2, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramX509Certificate, paramString1, new DefaultSignedAttributeTableGenerator(paramAttributeTable1), new SimpleAttributeTableGenerator(paramAttributeTable2), paramString2);
  }
  
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2, AttributeTable paramAttributeTable1, AttributeTable paramAttributeTable2, String paramString3)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramX509Certificate, paramString1, paramString2, new DefaultSignedAttributeTableGenerator(paramAttributeTable1), new SimpleAttributeTableGenerator(paramAttributeTable2), paramString3);
  }
  
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString, AttributeTable paramAttributeTable1, AttributeTable paramAttributeTable2, Provider paramProvider)
    throws NoSuchAlgorithmException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramX509Certificate, paramString, new DefaultSignedAttributeTableGenerator(paramAttributeTable1), new SimpleAttributeTableGenerator(paramAttributeTable2), paramProvider);
  }
  
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2, AttributeTable paramAttributeTable1, AttributeTable paramAttributeTable2, Provider paramProvider)
    throws NoSuchAlgorithmException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramX509Certificate, paramString1, paramString2, new DefaultSignedAttributeTableGenerator(paramAttributeTable1), new SimpleAttributeTableGenerator(paramAttributeTable2), paramProvider);
  }
  
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2, Provider paramProvider)
    throws NoSuchAlgorithmException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramX509Certificate, getEncOID(paramPrivateKey, paramString), paramString, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2, paramProvider);
  }
  
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2, Provider paramProvider)
    throws NoSuchAlgorithmException, InvalidKeyException
  {
    String str = CMSSignedHelper.INSTANCE.getDigestAlgName(paramString2);
    MessageDigest localMessageDigest = CMSSignedHelper.INSTANCE.getDigestInstance(str, paramProvider);
    this._signerInfs.add(new SignerInf(paramPrivateKey, getSignerIdentifier(paramX509Certificate), paramString2, paramString1, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2, localMessageDigest, paramProvider));
    this._messageDigests.add(localMessageDigest);
  }
  
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramX509Certificate, paramString1, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2, CMSUtils.getProvider(paramString2));
  }
  
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2, String paramString3)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramX509Certificate, paramString1, paramString2, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2, CMSUtils.getProvider(paramString3));
  }
  
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString1, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramArrayOfByte, paramString1, new DefaultSignedAttributeTableGenerator(), (CMSAttributeTableGenerator)null, paramString2);
  }
  
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString1, String paramString2, String paramString3)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramArrayOfByte, paramString1, paramString2, new DefaultSignedAttributeTableGenerator(), (CMSAttributeTableGenerator)null, paramString3);
  }
  
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramArrayOfByte, paramString, new DefaultSignedAttributeTableGenerator(), (CMSAttributeTableGenerator)null, paramProvider);
  }
  
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString1, String paramString2, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramArrayOfByte, paramString1, paramString2, new DefaultSignedAttributeTableGenerator(), (CMSAttributeTableGenerator)null, paramProvider);
  }
  
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString1, AttributeTable paramAttributeTable1, AttributeTable paramAttributeTable2, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramArrayOfByte, paramString1, new DefaultSignedAttributeTableGenerator(paramAttributeTable1), new SimpleAttributeTableGenerator(paramAttributeTable2), paramString2);
  }
  
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString, AttributeTable paramAttributeTable1, AttributeTable paramAttributeTable2, Provider paramProvider)
    throws NoSuchAlgorithmException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramArrayOfByte, paramString, new DefaultSignedAttributeTableGenerator(paramAttributeTable1), new SimpleAttributeTableGenerator(paramAttributeTable2), paramProvider);
  }
  
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2, Provider paramProvider)
    throws NoSuchAlgorithmException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramArrayOfByte, getEncOID(paramPrivateKey, paramString), paramString, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2, paramProvider);
  }
  
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString1, String paramString2, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2, Provider paramProvider)
    throws NoSuchAlgorithmException, InvalidKeyException
  {
    String str = CMSSignedHelper.INSTANCE.getDigestAlgName(paramString2);
    MessageDigest localMessageDigest = CMSSignedHelper.INSTANCE.getDigestInstance(str, paramProvider);
    this._signerInfs.add(new SignerInf(paramPrivateKey, getSignerIdentifier(paramArrayOfByte), paramString2, paramString1, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2, localMessageDigest, paramProvider));
    this._messageDigests.add(localMessageDigest);
  }
  
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramArrayOfByte, paramString1, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2, CMSUtils.getProvider(paramString2));
  }
  
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString1, String paramString2, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2, String paramString3)
    throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException
  {
    addSigner(paramPrivateKey, paramArrayOfByte, paramString1, paramString2, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2, CMSUtils.getProvider(paramString3));
  }
  
  public OutputStream open(OutputStream paramOutputStream)
    throws IOException
  {
    return open(paramOutputStream, false);
  }
  
  public OutputStream open(OutputStream paramOutputStream, boolean paramBoolean)
    throws IOException
  {
    return open(paramOutputStream, DATA, paramBoolean);
  }
  
  public OutputStream open(OutputStream paramOutputStream1, boolean paramBoolean, OutputStream paramOutputStream2)
    throws IOException
  {
    return open(paramOutputStream1, DATA, paramBoolean, paramOutputStream2);
  }
  
  public OutputStream open(OutputStream paramOutputStream, String paramString, boolean paramBoolean)
    throws IOException
  {
    return open(paramOutputStream, paramString, paramBoolean, null);
  }
  
  public OutputStream open(OutputStream paramOutputStream1, String paramString, boolean paramBoolean, OutputStream paramOutputStream2)
    throws IOException
  {
    BERSequenceGenerator localBERSequenceGenerator1 = new BERSequenceGenerator(paramOutputStream1);
    localBERSequenceGenerator1.addObject(CMSObjectIdentifiers.signedData);
    BERSequenceGenerator localBERSequenceGenerator2 = new BERSequenceGenerator(localBERSequenceGenerator1.getRawOutputStream(), 0, true);
    localBERSequenceGenerator2.addObject(calculateVersion(paramString));
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    Object localObject1 = this._signers.iterator();
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (SignerInformation)((Iterator)localObject1).next();
      localASN1EncodableVector.add(CMSSignedHelper.INSTANCE.fixAlgID(((SignerInformation)localObject2).getDigestAlgorithmID()));
    }
    localObject1 = this._signerInfs.iterator();
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (SignerInf)((Iterator)localObject1).next();
      localASN1EncodableVector.add(((SignerInf)localObject2).getDigestAlgorithmID());
    }
    localBERSequenceGenerator2.getRawOutputStream().write(new DERSet(localASN1EncodableVector).getEncoded());
    localObject1 = new BERSequenceGenerator(localBERSequenceGenerator2.getRawOutputStream());
    ((BERSequenceGenerator)localObject1).addObject(new DERObjectIdentifier(paramString));
    Object localObject2 = paramBoolean ? CMSUtils.createBEROctetOutputStream(((BERSequenceGenerator)localObject1).getRawOutputStream(), 0, true, this._bufferSize) : null;
    OutputStream localOutputStream1 = getSafeTeeOutputStream(paramOutputStream2, (OutputStream)localObject2);
    OutputStream localOutputStream2 = attachDigestsToOutputStream(this._messageDigests, localOutputStream1);
    return new CmsSignedDataOutputStream(localOutputStream2, paramString, localBERSequenceGenerator1, localBERSequenceGenerator2, (BERSequenceGenerator)localObject1);
  }
  
  private DERInteger calculateVersion(String paramString)
  {
    int i = 0;
    int j = 0;
    int k = 0;
    int m = 0;
    Iterator localIterator;
    Object localObject;
    if (this._certs != null)
    {
      localIterator = this._certs.iterator();
      while (localIterator.hasNext())
      {
        localObject = localIterator.next();
        if ((localObject instanceof ASN1TaggedObject))
        {
          ASN1TaggedObject localASN1TaggedObject = (ASN1TaggedObject)localObject;
          if (localASN1TaggedObject.getTagNo() == 1) {
            k = 1;
          } else if (localASN1TaggedObject.getTagNo() == 2) {
            m = 1;
          } else if (localASN1TaggedObject.getTagNo() == 3) {
            i = 1;
          }
        }
      }
    }
    if (i != 0) {
      return new DERInteger(5);
    }
    if ((this._crls != null) && (i == 0))
    {
      localIterator = this._crls.iterator();
      while (localIterator.hasNext())
      {
        localObject = localIterator.next();
        if ((localObject instanceof ASN1TaggedObject)) {
          j = 1;
        }
      }
    }
    if (j != 0) {
      return new DERInteger(5);
    }
    if (m != 0) {
      return new DERInteger(4);
    }
    if (k != 0) {
      return new DERInteger(3);
    }
    if (paramString.equals(DATA))
    {
      if (checkForVersion3(this._signers)) {
        return new DERInteger(3);
      }
      return new DERInteger(1);
    }
    return new DERInteger(3);
  }
  
  private boolean checkForVersion3(List paramList)
  {
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      SignerInfo localSignerInfo = SignerInfo.getInstance(((SignerInformation)localIterator.next()).toSignerInfo());
      if (localSignerInfo.getVersion().getValue().intValue() == 3) {
        return true;
      }
    }
    return false;
  }
  
  private static OutputStream attachDigestsToOutputStream(List paramList, OutputStream paramOutputStream)
  {
    OutputStream localOutputStream = paramOutputStream;
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      MessageDigest localMessageDigest = (MessageDigest)localIterator.next();
      localOutputStream = getSafeTeeOutputStream(localOutputStream, new CMSSignedGenerator.DigOutputStream(localMessageDigest));
    }
    return localOutputStream;
  }
  
  private static OutputStream getSafeOutputStream(OutputStream paramOutputStream)
  {
    return paramOutputStream == null ? new NullOutputStream(null) : paramOutputStream;
  }
  
  private static OutputStream getSafeTeeOutputStream(OutputStream paramOutputStream1, OutputStream paramOutputStream2)
  {
    return paramOutputStream2 == null ? getSafeOutputStream(paramOutputStream1) : paramOutputStream1 == null ? getSafeOutputStream(paramOutputStream2) : new TeeOutputStream(paramOutputStream1, paramOutputStream2);
  }
  
  private class CmsSignedDataOutputStream
    extends OutputStream
  {
    private OutputStream _out;
    private DERObjectIdentifier _contentOID;
    private BERSequenceGenerator _sGen;
    private BERSequenceGenerator _sigGen;
    private BERSequenceGenerator _eiGen;
    
    public CmsSignedDataOutputStream(OutputStream paramOutputStream, String paramString, BERSequenceGenerator paramBERSequenceGenerator1, BERSequenceGenerator paramBERSequenceGenerator2, BERSequenceGenerator paramBERSequenceGenerator3)
    {
      this._out = paramOutputStream;
      this._contentOID = new DERObjectIdentifier(paramString);
      this._sGen = paramBERSequenceGenerator1;
      this._sigGen = paramBERSequenceGenerator2;
      this._eiGen = paramBERSequenceGenerator3;
    }
    
    public void write(int paramInt)
      throws IOException
    {
      this._out.write(paramInt);
    }
    
    public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {
      this._out.write(paramArrayOfByte, paramInt1, paramInt2);
    }
    
    public void write(byte[] paramArrayOfByte)
      throws IOException
    {
      this._out.write(paramArrayOfByte);
    }
    
    public void close()
      throws IOException
    {
      this._out.close();
      this._eiGen.close();
      CMSSignedDataStreamGenerator.this._digests.clear();
      if (CMSSignedDataStreamGenerator.this._certs.size() != 0)
      {
        localObject1 = CMSUtils.createBerSetFromList(CMSSignedDataStreamGenerator.this._certs);
        this._sigGen.getRawOutputStream().write(new BERTaggedObject(false, 0, (DEREncodable)localObject1).getEncoded());
      }
      if (CMSSignedDataStreamGenerator.this._crls.size() != 0)
      {
        localObject1 = CMSUtils.createBerSetFromList(CMSSignedDataStreamGenerator.this._crls);
        this._sigGen.getRawOutputStream().write(new BERTaggedObject(false, 1, (DEREncodable)localObject1).getEncoded());
      }
      Object localObject1 = new ASN1EncodableVector();
      Iterator localIterator = CMSSignedDataStreamGenerator.this._signers.iterator();
      Object localObject2;
      while (localIterator.hasNext())
      {
        localObject2 = (SignerInformation)localIterator.next();
        ((ASN1EncodableVector)localObject1).add(((SignerInformation)localObject2).toSignerInfo());
      }
      localIterator = CMSSignedDataStreamGenerator.this._signerInfs.iterator();
      while (localIterator.hasNext())
      {
        localObject2 = (CMSSignedDataStreamGenerator.SignerInf)localIterator.next();
        try
        {
          ((ASN1EncodableVector)localObject1).add(((CMSSignedDataStreamGenerator.SignerInf)localObject2).toSignerInfo(this._contentOID));
        }
        catch (IOException localIOException)
        {
          throw new CMSStreamException("encoding error.", localIOException);
        }
        catch (InvalidKeyException localInvalidKeyException)
        {
          throw new CMSStreamException("key inappropriate for signature.", localInvalidKeyException);
        }
        catch (SignatureException localSignatureException)
        {
          throw new CMSStreamException("error creating signature.", localSignatureException);
        }
        catch (CertificateEncodingException localCertificateEncodingException)
        {
          throw new CMSStreamException("error creating sid.", localCertificateEncodingException);
        }
        catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
        {
          throw new CMSStreamException("unknown signature algorithm.", localNoSuchAlgorithmException);
        }
      }
      this._sigGen.getRawOutputStream().write(new DERSet((DEREncodableVector)localObject1).getEncoded());
      this._sigGen.close();
      this._sGen.close();
    }
  }
  
  private static class NullOutputStream
    extends OutputStream
  {
    public void write(byte[] paramArrayOfByte)
      throws IOException
    {}
    
    public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {}
    
    public void write(int paramInt)
      throws IOException
    {}
  }
  
  private class SignerInf
  {
    private final PrivateKey _key;
    private final SignerIdentifier _signerIdentifier;
    private final String _digestOID;
    private final String _encOID;
    private final CMSAttributeTableGenerator _sAttr;
    private final CMSAttributeTableGenerator _unsAttr;
    private final MessageDigest _digest;
    private final Provider _sigProvider;
    
    SignerInf(PrivateKey paramPrivateKey, SignerIdentifier paramSignerIdentifier, String paramString1, String paramString2, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2, MessageDigest paramMessageDigest, Provider paramProvider)
    {
      this._key = paramPrivateKey;
      this._signerIdentifier = paramSignerIdentifier;
      this._digestOID = paramString1;
      this._encOID = paramString2;
      this._sAttr = paramCMSAttributeTableGenerator1;
      this._unsAttr = paramCMSAttributeTableGenerator2;
      this._digest = paramMessageDigest;
      this._sigProvider = paramProvider;
    }
    
    AlgorithmIdentifier getDigestAlgorithmID()
    {
      return new AlgorithmIdentifier(new DERObjectIdentifier(this._digestOID), DERNull.INSTANCE);
    }
    
    SignerInfo toSignerInfo(DERObjectIdentifier paramDERObjectIdentifier)
      throws IOException, SignatureException, CertificateEncodingException, InvalidKeyException, NoSuchAlgorithmException
    {
      String str1 = CMSSignedHelper.INSTANCE.getDigestAlgName(this._digestOID);
      String str2 = CMSSignedHelper.INSTANCE.getEncryptionAlgName(this._encOID);
      String str3 = str1 + "with" + str2;
      AlgorithmIdentifier localAlgorithmIdentifier = getDigestAlgorithmID();
      byte[] arrayOfByte1 = this._digest.digest();
      CMSSignedDataStreamGenerator.this._digests.put(this._digestOID, arrayOfByte1.clone());
      byte[] arrayOfByte2 = arrayOfByte1;
      ASN1Set localASN1Set = null;
      Signature localSignature;
      if (this._sAttr != null)
      {
        localObject1 = CMSSignedDataStreamGenerator.this.getBaseParameters(paramDERObjectIdentifier, localAlgorithmIdentifier, arrayOfByte1);
        localObject2 = this._sAttr.getAttributes(Collections.unmodifiableMap((Map)localObject1));
        localASN1Set = CMSSignedDataStreamGenerator.this.getAttributeSet((AttributeTable)localObject2);
        arrayOfByte2 = localASN1Set.getEncoded("DER");
        localSignature = CMSSignedHelper.INSTANCE.getSignatureInstance(str3, this._sigProvider);
      }
      else if (str2.equals("RSA"))
      {
        localObject1 = new DigestInfo(localAlgorithmIdentifier, arrayOfByte1);
        arrayOfByte2 = ((DigestInfo)localObject1).getEncoded("DER");
        localSignature = CMSSignedHelper.INSTANCE.getSignatureInstance("RSA", this._sigProvider);
      }
      else if (str2.equals("DSA"))
      {
        localSignature = CMSSignedHelper.INSTANCE.getSignatureInstance("NONEwithDSA", this._sigProvider);
      }
      else
      {
        throw new SignatureException("algorithm: " + str2 + " not supported in base signatures.");
      }
      localSignature.initSign(this._key, CMSSignedDataStreamGenerator.this.rand);
      localSignature.update(arrayOfByte2);
      Object localObject1 = localSignature.sign();
      Object localObject2 = null;
      if (this._unsAttr != null)
      {
        localObject3 = CMSSignedDataStreamGenerator.this.getBaseParameters(paramDERObjectIdentifier, localAlgorithmIdentifier, arrayOfByte1);
        ((Map)localObject3).put("encryptedDigest", ((byte[])localObject1).clone());
        AttributeTable localAttributeTable = this._unsAttr.getAttributes(Collections.unmodifiableMap((Map)localObject3));
        localObject2 = CMSSignedDataStreamGenerator.this.getAttributeSet(localAttributeTable);
      }
      Object localObject3 = CMSSignedDataStreamGenerator.this.getEncAlgorithmIdentifier(this._encOID, localSignature);
      return new SignerInfo(this._signerIdentifier, localAlgorithmIdentifier, localASN1Set, (AlgorithmIdentifier)localObject3, new DEROctetString((byte[])localObject1), (ASN1Set)localObject2);
    }
  }
  
  private static class TeeOutputStream
    extends OutputStream
  {
    private OutputStream s1;
    private OutputStream s2;
    
    public TeeOutputStream(OutputStream paramOutputStream1, OutputStream paramOutputStream2)
    {
      this.s1 = paramOutputStream1;
      this.s2 = paramOutputStream2;
    }
    
    public void write(byte[] paramArrayOfByte)
      throws IOException
    {
      this.s1.write(paramArrayOfByte);
      this.s2.write(paramArrayOfByte);
    }
    
    public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {
      this.s1.write(paramArrayOfByte, paramInt1, paramInt2);
      this.s2.write(paramArrayOfByte, paramInt1, paramInt2);
    }
    
    public void write(int paramInt)
      throws IOException
    {
      this.s1.write(paramInt);
      this.s2.write(paramInt);
    }
    
    public void close()
      throws IOException
    {
      this.s1.close();
      this.s2.close();
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSSignedDataStreamGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */