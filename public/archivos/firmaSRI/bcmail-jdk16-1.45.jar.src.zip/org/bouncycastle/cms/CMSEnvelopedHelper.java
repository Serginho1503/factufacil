package org.bouncycastle.cms;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.AlgorithmParameterGenerator;
import java.security.AlgorithmParameters;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cms.KEKRecipientInfo;
import org.bouncycastle.asn1.cms.KeyAgreeRecipientInfo;
import org.bouncycastle.asn1.cms.KeyTransRecipientInfo;
import org.bouncycastle.asn1.cms.PasswordRecipientInfo;
import org.bouncycastle.asn1.cms.RecipientInfo;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

class CMSEnvelopedHelper
{
  static final CMSEnvelopedHelper INSTANCE = new CMSEnvelopedHelper();
  private static final Map KEYSIZES = new HashMap();
  private static final Map BASE_CIPHER_NAMES = new HashMap();
  private static final Map CIPHER_ALG_NAMES = new HashMap();
  private static final Map MAC_ALG_NAMES = new HashMap();
  
  private String getAsymmetricEncryptionAlgName(String paramString)
  {
    if (PKCSObjectIdentifiers.rsaEncryption.getId().equals(paramString)) {
      return "RSA/ECB/PKCS1Padding";
    }
    return paramString;
  }
  
  Cipher createAsymmetricCipher(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchProviderException, NoSuchPaddingException
  {
    try
    {
      return getCipherInstance(getAsymmetricEncryptionAlgName(paramString), paramProvider);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException) {}
    return getCipherInstance(paramString, paramProvider);
  }
  
  KeyGenerator createSymmetricKeyGenerator(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException
  {
    try
    {
      return createKeyGenerator(paramString, paramProvider);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException1)
    {
      try
      {
        String str = (String)BASE_CIPHER_NAMES.get(paramString);
        if (str != null) {
          return createKeyGenerator(str, paramProvider);
        }
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException2) {}
      if (paramProvider != null) {
        return createSymmetricKeyGenerator(paramString, null);
      }
      throw localNoSuchAlgorithmException1;
    }
  }
  
  AlgorithmParameters createAlgorithmParameters(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException
  {
    try
    {
      return createAlgorithmParams(paramString, paramProvider);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException1)
    {
      try
      {
        String str = (String)BASE_CIPHER_NAMES.get(paramString);
        if (str != null) {
          return createAlgorithmParams(str, paramProvider);
        }
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException2) {}
      throw localNoSuchAlgorithmException1;
    }
  }
  
  AlgorithmParameterGenerator createAlgorithmParameterGenerator(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException
  {
    try
    {
      return createAlgorithmParamsGenerator(paramString, paramProvider);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException1)
    {
      try
      {
        String str = (String)BASE_CIPHER_NAMES.get(paramString);
        if (str != null) {
          return createAlgorithmParamsGenerator(str, paramProvider);
        }
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException2) {}
      throw localNoSuchAlgorithmException1;
    }
  }
  
  String getRFC3211WrapperName(String paramString)
  {
    String str = (String)BASE_CIPHER_NAMES.get(paramString);
    if (str == null) {
      throw new IllegalArgumentException("no name for " + paramString);
    }
    return str + "RFC3211Wrap";
  }
  
  int getKeySize(String paramString)
  {
    Integer localInteger = (Integer)KEYSIZES.get(paramString);
    if (localInteger == null) {
      throw new IllegalArgumentException("no keysize for " + paramString);
    }
    return localInteger.intValue();
  }
  
  Cipher getCipherInstance(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchPaddingException
  {
    if (paramProvider != null) {
      return Cipher.getInstance(paramString, paramProvider);
    }
    return Cipher.getInstance(paramString);
  }
  
  private AlgorithmParameters createAlgorithmParams(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException
  {
    if (paramProvider != null) {
      return AlgorithmParameters.getInstance(paramString, paramProvider);
    }
    return AlgorithmParameters.getInstance(paramString);
  }
  
  private AlgorithmParameterGenerator createAlgorithmParamsGenerator(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException
  {
    if (paramProvider != null) {
      return AlgorithmParameterGenerator.getInstance(paramString, paramProvider);
    }
    return AlgorithmParameterGenerator.getInstance(paramString);
  }
  
  private KeyGenerator createKeyGenerator(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException
  {
    if (paramProvider != null) {
      return KeyGenerator.getInstance(paramString, paramProvider);
    }
    return KeyGenerator.getInstance(paramString);
  }
  
  Cipher getSymmetricCipher(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchPaddingException
  {
    try
    {
      return getCipherInstance(paramString, paramProvider);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException1)
    {
      String str = (String)CIPHER_ALG_NAMES.get(paramString);
      try
      {
        return getCipherInstance(str, paramProvider);
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException2)
      {
        if (paramProvider != null) {
          return getSymmetricCipher(paramString, null);
        }
        throw localNoSuchAlgorithmException1;
      }
    }
  }
  
  private Mac createMac(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchPaddingException
  {
    if (paramProvider != null) {
      return Mac.getInstance(paramString, paramProvider);
    }
    return Mac.getInstance(paramString);
  }
  
  Mac getMac(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchPaddingException
  {
    try
    {
      return createMac(paramString, paramProvider);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException1)
    {
      String str = (String)MAC_ALG_NAMES.get(paramString);
      try
      {
        return createMac(str, paramProvider);
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException2)
      {
        if (paramProvider != null) {
          return getMac(paramString, null);
        }
        throw localNoSuchAlgorithmException1;
      }
    }
  }
  
  AlgorithmParameters getEncryptionAlgorithmParameters(String paramString, byte[] paramArrayOfByte, Provider paramProvider)
    throws CMSException
  {
    if (paramArrayOfByte == null) {
      return null;
    }
    try
    {
      AlgorithmParameters localAlgorithmParameters = createAlgorithmParameters(paramString, paramProvider);
      localAlgorithmParameters.init(paramArrayOfByte, "ASN.1");
      return localAlgorithmParameters;
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new CMSException("can't find parameters for algorithm", localNoSuchAlgorithmException);
    }
    catch (IOException localIOException)
    {
      throw new CMSException("can't find parse parameters", localIOException);
    }
  }
  
  String getSymmetricCipherName(String paramString)
  {
    String str = (String)BASE_CIPHER_NAMES.get(paramString);
    if (str != null) {
      return str;
    }
    return paramString;
  }
  
  static List readRecipientInfos(ASN1Set paramASN1Set, byte[] paramArrayOfByte, AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, AlgorithmIdentifier paramAlgorithmIdentifier3)
  {
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i != paramASN1Set.size(); i++)
    {
      RecipientInfo localRecipientInfo = RecipientInfo.getInstance(paramASN1Set.getObjectAt(i));
      ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
      readRecipientInfo(localArrayList, localRecipientInfo, localByteArrayInputStream, paramAlgorithmIdentifier1, paramAlgorithmIdentifier2, paramAlgorithmIdentifier3);
    }
    return localArrayList;
  }
  
  static List readRecipientInfos(Iterator paramIterator, InputStream paramInputStream, AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, AlgorithmIdentifier paramAlgorithmIdentifier3)
  {
    ArrayList localArrayList = new ArrayList();
    while (paramIterator.hasNext())
    {
      RecipientInfo localRecipientInfo = (RecipientInfo)paramIterator.next();
      readRecipientInfo(localArrayList, localRecipientInfo, paramInputStream, paramAlgorithmIdentifier1, paramAlgorithmIdentifier2, paramAlgorithmIdentifier3);
    }
    return localArrayList;
  }
  
  private static void readRecipientInfo(List paramList, RecipientInfo paramRecipientInfo, InputStream paramInputStream, AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, AlgorithmIdentifier paramAlgorithmIdentifier3)
  {
    DEREncodable localDEREncodable = paramRecipientInfo.getInfo();
    if ((localDEREncodable instanceof KeyTransRecipientInfo)) {
      paramList.add(new KeyTransRecipientInformation((KeyTransRecipientInfo)localDEREncodable, paramAlgorithmIdentifier1, paramAlgorithmIdentifier2, paramAlgorithmIdentifier3, paramInputStream));
    } else if ((localDEREncodable instanceof KEKRecipientInfo)) {
      paramList.add(new KEKRecipientInformation((KEKRecipientInfo)localDEREncodable, paramAlgorithmIdentifier1, paramAlgorithmIdentifier2, paramAlgorithmIdentifier3, paramInputStream));
    } else if ((localDEREncodable instanceof KeyAgreeRecipientInfo)) {
      paramList.add(new KeyAgreeRecipientInformation((KeyAgreeRecipientInfo)localDEREncodable, paramAlgorithmIdentifier1, paramAlgorithmIdentifier2, paramAlgorithmIdentifier3, paramInputStream));
    } else if ((localDEREncodable instanceof PasswordRecipientInfo)) {
      paramList.add(new PasswordRecipientInformation((PasswordRecipientInfo)localDEREncodable, paramAlgorithmIdentifier1, paramAlgorithmIdentifier2, paramAlgorithmIdentifier3, paramInputStream));
    }
  }
  
  static
  {
    KEYSIZES.put(CMSEnvelopedGenerator.DES_EDE3_CBC, new Integer(192));
    KEYSIZES.put(CMSEnvelopedGenerator.AES128_CBC, new Integer(128));
    KEYSIZES.put(CMSEnvelopedGenerator.AES192_CBC, new Integer(192));
    KEYSIZES.put(CMSEnvelopedGenerator.AES256_CBC, new Integer(256));
    BASE_CIPHER_NAMES.put(CMSEnvelopedGenerator.DES_EDE3_CBC, "DESEDE");
    BASE_CIPHER_NAMES.put(CMSEnvelopedGenerator.AES128_CBC, "AES");
    BASE_CIPHER_NAMES.put(CMSEnvelopedGenerator.AES192_CBC, "AES");
    BASE_CIPHER_NAMES.put(CMSEnvelopedGenerator.AES256_CBC, "AES");
    CIPHER_ALG_NAMES.put(CMSEnvelopedGenerator.DES_EDE3_CBC, "DESEDE/CBC/PKCS5Padding");
    CIPHER_ALG_NAMES.put(CMSEnvelopedGenerator.AES128_CBC, "AES/CBC/PKCS5Padding");
    CIPHER_ALG_NAMES.put(CMSEnvelopedGenerator.AES192_CBC, "AES/CBC/PKCS5Padding");
    CIPHER_ALG_NAMES.put(CMSEnvelopedGenerator.AES256_CBC, "AES/CBC/PKCS5Padding");
    MAC_ALG_NAMES.put(CMSEnvelopedGenerator.DES_EDE3_CBC, "DESEDEMac");
    MAC_ALG_NAMES.put(CMSEnvelopedGenerator.AES128_CBC, "AESMac");
    MAC_ALG_NAMES.put(CMSEnvelopedGenerator.AES192_CBC, "AESMac");
    MAC_ALG_NAMES.put(CMSEnvelopedGenerator.AES256_CBC, "AESMac");
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSEnvelopedHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */