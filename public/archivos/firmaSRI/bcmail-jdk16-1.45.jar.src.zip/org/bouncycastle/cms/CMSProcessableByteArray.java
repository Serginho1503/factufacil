package org.bouncycastle.cms;

import java.io.IOException;
import java.io.OutputStream;

public class CMSProcessableByteArray
  implements CMSProcessable
{
  private byte[] bytes;
  
  public CMSProcessableByteArray(byte[] paramArrayOfByte)
  {
    this.bytes = paramArrayOfByte;
  }
  
  public void write(OutputStream paramOutputStream)
    throws IOException, CMSException
  {
    paramOutputStream.write(this.bytes);
  }
  
  public Object getContent()
  {
    return this.bytes.clone();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSProcessableByteArray.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */