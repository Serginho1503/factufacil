package org.bouncycastle.cms;

import java.security.GeneralSecurityException;
import java.security.Provider;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.cms.PasswordRecipientInfo;
import org.bouncycastle.asn1.cms.RecipientInfo;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

class PasswordRecipientInfoGenerator
  implements RecipientInfoGenerator
{
  private AlgorithmIdentifier derivationAlg;
  private SecretKey wrapKey;
  
  void setDerivationAlg(AlgorithmIdentifier paramAlgorithmIdentifier)
  {
    this.derivationAlg = paramAlgorithmIdentifier;
  }
  
  void setWrapKey(SecretKey paramSecretKey)
  {
    this.wrapKey = paramSecretKey;
  }
  
  public RecipientInfo generate(SecretKey paramSecretKey, SecureRandom paramSecureRandom, Provider paramProvider)
    throws GeneralSecurityException
  {
    CMSEnvelopedHelper localCMSEnvelopedHelper = CMSEnvelopedHelper.INSTANCE;
    String str = localCMSEnvelopedHelper.getRFC3211WrapperName(this.wrapKey.getAlgorithm());
    Cipher localCipher = localCMSEnvelopedHelper.createAsymmetricCipher(str, paramProvider);
    localCipher.init(3, this.wrapKey, paramSecureRandom);
    DEROctetString localDEROctetString = new DEROctetString(localCipher.wrap(paramSecretKey));
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(new DERObjectIdentifier(this.wrapKey.getAlgorithm()));
    localASN1EncodableVector.add(new DEROctetString(localCipher.getIV()));
    AlgorithmIdentifier localAlgorithmIdentifier = new AlgorithmIdentifier(PKCSObjectIdentifiers.id_alg_PWRI_KEK, new DERSequence(localASN1EncodableVector));
    return new RecipientInfo(new PasswordRecipientInfo(this.derivationAlg, localAlgorithmIdentifier, localDEROctetString));
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\PasswordRecipientInfoGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */