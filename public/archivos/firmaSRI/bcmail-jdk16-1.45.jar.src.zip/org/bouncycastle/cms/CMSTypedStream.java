package org.bouncycastle.cms;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.util.io.Streams;

public class CMSTypedStream
{
  private static final int BUF_SIZ = 32768;
  private final String _oid;
  private final InputStream _in;
  
  public CMSTypedStream(InputStream paramInputStream)
  {
    this(PKCSObjectIdentifiers.data.getId(), paramInputStream, 32768);
  }
  
  public CMSTypedStream(String paramString, InputStream paramInputStream)
  {
    this(paramString, paramInputStream, 32768);
  }
  
  public CMSTypedStream(String paramString, InputStream paramInputStream, int paramInt)
  {
    this._oid = paramString;
    this._in = new FullReaderStream(paramInputStream, paramInt);
  }
  
  public String getContentType()
  {
    return this._oid;
  }
  
  public InputStream getContentStream()
  {
    return this._in;
  }
  
  public void drain()
    throws IOException
  {
    Streams.drain(this._in);
    this._in.close();
  }
  
  private class FullReaderStream
    extends InputStream
  {
    InputStream _stream;
    
    FullReaderStream(InputStream paramInputStream, int paramInt)
    {
      this._stream = new BufferedInputStream(paramInputStream, paramInt);
    }
    
    public int read()
      throws IOException
    {
      return this._stream.read();
    }
    
    public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {
      int i = 0;
      int j = 0;
      while ((paramInt2 != 0) && ((i = this._stream.read(paramArrayOfByte, paramInt1, paramInt2)) > 0))
      {
        paramInt1 += i;
        paramInt2 -= i;
        j += i;
      }
      if (j > 0) {
        return j;
      }
      return -1;
    }
    
    public void close()
      throws IOException
    {
      this._stream.close();
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSTypedStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */