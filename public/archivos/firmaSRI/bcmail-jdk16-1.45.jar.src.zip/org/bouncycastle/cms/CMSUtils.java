package org.bouncycastle.cms;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.Security;
import java.security.cert.CRLException;
import java.security.cert.CertStore;
import java.security.cert.CertStoreException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.BEROctetStringGenerator;
import org.bouncycastle.asn1.BERSet;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.cms.ContentInfo;
import org.bouncycastle.asn1.x509.CertificateList;
import org.bouncycastle.asn1.x509.TBSCertificateStructure;
import org.bouncycastle.asn1.x509.X509CertificateStructure;
import org.bouncycastle.util.io.Streams;

class CMSUtils
{
  private static final Runtime RUNTIME = ;
  
  static int getMaximumMemory()
  {
    long l = RUNTIME.maxMemory();
    if (l > 2147483647L) {
      return Integer.MAX_VALUE;
    }
    return (int)l;
  }
  
  static ContentInfo readContentInfo(byte[] paramArrayOfByte)
    throws CMSException
  {
    return readContentInfo(new ASN1InputStream(paramArrayOfByte));
  }
  
  static ContentInfo readContentInfo(InputStream paramInputStream)
    throws CMSException
  {
    return readContentInfo(new ASN1InputStream(paramInputStream, getMaximumMemory()));
  }
  
  static List getCertificatesFromStore(CertStore paramCertStore)
    throws CertStoreException, CMSException
  {
    ArrayList localArrayList = new ArrayList();
    try
    {
      Iterator localIterator = paramCertStore.getCertificates(null).iterator();
      while (localIterator.hasNext())
      {
        X509Certificate localX509Certificate = (X509Certificate)localIterator.next();
        localArrayList.add(X509CertificateStructure.getInstance(ASN1Object.fromByteArray(localX509Certificate.getEncoded())));
      }
      return localArrayList;
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      throw new CMSException("error processing certs", localIllegalArgumentException);
    }
    catch (IOException localIOException)
    {
      throw new CMSException("error processing certs", localIOException);
    }
    catch (CertificateEncodingException localCertificateEncodingException)
    {
      throw new CMSException("error encoding certs", localCertificateEncodingException);
    }
  }
  
  static List getCRLsFromStore(CertStore paramCertStore)
    throws CertStoreException, CMSException
  {
    ArrayList localArrayList = new ArrayList();
    try
    {
      Iterator localIterator = paramCertStore.getCRLs(null).iterator();
      while (localIterator.hasNext())
      {
        X509CRL localX509CRL = (X509CRL)localIterator.next();
        localArrayList.add(CertificateList.getInstance(ASN1Object.fromByteArray(localX509CRL.getEncoded())));
      }
      return localArrayList;
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      throw new CMSException("error processing crls", localIllegalArgumentException);
    }
    catch (IOException localIOException)
    {
      throw new CMSException("error processing crls", localIOException);
    }
    catch (CRLException localCRLException)
    {
      throw new CMSException("error encoding crls", localCRLException);
    }
  }
  
  static ASN1Set createBerSetFromList(List paramList)
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext()) {
      localASN1EncodableVector.add((DEREncodable)localIterator.next());
    }
    return new BERSet(localASN1EncodableVector);
  }
  
  static ASN1Set createDerSetFromList(List paramList)
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext()) {
      localASN1EncodableVector.add((DEREncodable)localIterator.next());
    }
    return new DERSet(localASN1EncodableVector);
  }
  
  static OutputStream createBEROctetOutputStream(OutputStream paramOutputStream, int paramInt1, boolean paramBoolean, int paramInt2)
    throws IOException
  {
    BEROctetStringGenerator localBEROctetStringGenerator = new BEROctetStringGenerator(paramOutputStream, paramInt1, paramBoolean);
    if (paramInt2 != 0) {
      return localBEROctetStringGenerator.getOctetOutputStream(new byte[paramInt2]);
    }
    return localBEROctetStringGenerator.getOctetOutputStream();
  }
  
  static TBSCertificateStructure getTBSCertificateStructure(X509Certificate paramX509Certificate)
    throws CertificateEncodingException
  {
    try
    {
      return TBSCertificateStructure.getInstance(ASN1Object.fromByteArray(paramX509Certificate.getTBSCertificate()));
    }
    catch (IOException localIOException)
    {
      throw new CertificateEncodingException(localIOException.toString());
    }
  }
  
  private static ContentInfo readContentInfo(ASN1InputStream paramASN1InputStream)
    throws CMSException
  {
    try
    {
      return ContentInfo.getInstance(paramASN1InputStream.readObject());
    }
    catch (IOException localIOException)
    {
      throw new CMSException("IOException reading content.", localIOException);
    }
    catch (ClassCastException localClassCastException)
    {
      throw new CMSException("Malformed content.", localClassCastException);
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      throw new CMSException("Malformed content.", localIllegalArgumentException);
    }
  }
  
  public static byte[] streamToByteArray(InputStream paramInputStream)
    throws IOException
  {
    return Streams.readAll(paramInputStream);
  }
  
  public static byte[] streamToByteArray(InputStream paramInputStream, int paramInt)
    throws IOException
  {
    return Streams.readAllLimited(paramInputStream, paramInt);
  }
  
  public static Provider getProvider(String paramString)
    throws NoSuchProviderException
  {
    if (paramString != null)
    {
      Provider localProvider = Security.getProvider(paramString);
      if (localProvider != null) {
        return localProvider;
      }
      throw new NoSuchProviderException("provider " + paramString + " not found.");
    }
    return null;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */