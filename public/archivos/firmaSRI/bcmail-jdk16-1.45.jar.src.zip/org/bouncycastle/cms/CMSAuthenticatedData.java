package org.bouncycastle.cms;

import java.io.IOException;
import java.io.InputStream;
import java.security.AlgorithmParameters;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.util.List;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.AuthenticatedData;
import org.bouncycastle.asn1.cms.ContentInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.util.Arrays;

public class CMSAuthenticatedData
{
  RecipientInformationStore recipientInfoStore;
  ContentInfo contentInfo;
  private AlgorithmIdentifier macAlg;
  private ASN1Set authAttrs;
  private ASN1Set unauthAttrs;
  private byte[] mac;
  
  public CMSAuthenticatedData(byte[] paramArrayOfByte)
    throws CMSException
  {
    this(CMSUtils.readContentInfo(paramArrayOfByte));
  }
  
  public CMSAuthenticatedData(InputStream paramInputStream)
    throws CMSException
  {
    this(CMSUtils.readContentInfo(paramInputStream));
  }
  
  public CMSAuthenticatedData(ContentInfo paramContentInfo)
    throws CMSException
  {
    this.contentInfo = paramContentInfo;
    AuthenticatedData localAuthenticatedData = AuthenticatedData.getInstance(paramContentInfo.getContent());
    ContentInfo localContentInfo = localAuthenticatedData.getEncapsulatedContentInfo();
    this.macAlg = localAuthenticatedData.getMacAlgorithm();
    this.mac = localAuthenticatedData.getMac().getOctets();
    byte[] arrayOfByte = ASN1OctetString.getInstance(localContentInfo.getContent()).getOctets();
    List localList = CMSEnvelopedHelper.readRecipientInfos(localAuthenticatedData.getRecipientInfos(), arrayOfByte, null, this.macAlg, null);
    this.authAttrs = localAuthenticatedData.getAuthAttrs();
    this.recipientInfoStore = new RecipientInformationStore(localList);
    this.unauthAttrs = localAuthenticatedData.getUnauthAttrs();
  }
  
  public byte[] getMac()
  {
    return Arrays.clone(this.mac);
  }
  
  private byte[] encodeObj(DEREncodable paramDEREncodable)
    throws IOException
  {
    if (paramDEREncodable != null) {
      return paramDEREncodable.getDERObject().getEncoded();
    }
    return null;
  }
  
  public String getMacAlgOID()
  {
    return this.macAlg.getObjectId().getId();
  }
  
  public byte[] getMacAlgParams()
  {
    try
    {
      return encodeObj(this.macAlg.getParameters());
    }
    catch (Exception localException)
    {
      throw new RuntimeException("exception getting encryption parameters " + localException);
    }
  }
  
  public AlgorithmParameters getMacAlgorithmParameters(String paramString)
    throws CMSException, NoSuchProviderException
  {
    return getMacAlgorithmParameters(CMSUtils.getProvider(paramString));
  }
  
  public AlgorithmParameters getMacAlgorithmParameters(Provider paramProvider)
    throws CMSException
  {
    return CMSEnvelopedHelper.INSTANCE.getEncryptionAlgorithmParameters(getMacAlgOID(), getMacAlgParams(), paramProvider);
  }
  
  public RecipientInformationStore getRecipientInfos()
  {
    return this.recipientInfoStore;
  }
  
  public ContentInfo getContentInfo()
  {
    return this.contentInfo;
  }
  
  public AttributeTable getAuthAttrs()
  {
    if (this.authAttrs == null) {
      return null;
    }
    return new AttributeTable(this.authAttrs);
  }
  
  public AttributeTable getUnauthAttrs()
  {
    if (this.unauthAttrs == null) {
      return null;
    }
    return new AttributeTable(this.unauthAttrs);
  }
  
  public byte[] getEncoded()
    throws IOException
  {
    return this.contentInfo.getEncoded();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSAuthenticatedData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */