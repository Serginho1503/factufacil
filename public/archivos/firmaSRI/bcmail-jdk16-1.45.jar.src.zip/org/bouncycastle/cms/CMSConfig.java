package org.bouncycastle.cms;

import org.bouncycastle.asn1.DERObjectIdentifier;

public class CMSConfig
{
  public static void setSigningEncryptionAlgorithmMapping(String paramString1, String paramString2)
  {
    DERObjectIdentifier localDERObjectIdentifier = new DERObjectIdentifier(paramString1);
    CMSSignedHelper.INSTANCE.setSigningEncryptionAlgorithmMapping(localDERObjectIdentifier, paramString2);
  }
  
  public static void setSigningDigestAlgorithmMapping(String paramString1, String paramString2)
  {
    DERObjectIdentifier localDERObjectIdentifier = new DERObjectIdentifier(paramString1);
    CMSSignedHelper.INSTANCE.setSigningDigestAlgorithmMapping(localDERObjectIdentifier, paramString2);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */