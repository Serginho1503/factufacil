package org.bouncycastle.cms;

import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cms.KEKIdentifier;
import org.bouncycastle.asn1.cms.KEKRecipientInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class KEKRecipientInformation
  extends RecipientInformation
{
  private KEKRecipientInfo info;
  
  /**
   * @deprecated
   */
  public KEKRecipientInformation(KEKRecipientInfo paramKEKRecipientInfo, AlgorithmIdentifier paramAlgorithmIdentifier, InputStream paramInputStream)
  {
    this(paramKEKRecipientInfo, paramAlgorithmIdentifier, null, null, paramInputStream);
  }
  
  /**
   * @deprecated
   */
  public KEKRecipientInformation(KEKRecipientInfo paramKEKRecipientInfo, AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, InputStream paramInputStream)
  {
    this(paramKEKRecipientInfo, paramAlgorithmIdentifier1, paramAlgorithmIdentifier2, null, paramInputStream);
  }
  
  KEKRecipientInformation(KEKRecipientInfo paramKEKRecipientInfo, AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, AlgorithmIdentifier paramAlgorithmIdentifier3, InputStream paramInputStream)
  {
    super(paramAlgorithmIdentifier1, paramAlgorithmIdentifier2, paramAlgorithmIdentifier3, paramKEKRecipientInfo.getKeyEncryptionAlgorithm(), paramInputStream);
    this.info = paramKEKRecipientInfo;
    this.rid = new RecipientId();
    KEKIdentifier localKEKIdentifier = paramKEKRecipientInfo.getKekid();
    this.rid.setKeyIdentifier(localKEKIdentifier.getKeyIdentifier().getOctets());
  }
  
  public CMSTypedStream getContentStream(Key paramKey, String paramString)
    throws CMSException, NoSuchProviderException
  {
    return getContentStream(paramKey, CMSUtils.getProvider(paramString));
  }
  
  public CMSTypedStream getContentStream(Key paramKey, Provider paramProvider)
    throws CMSException
  {
    try
    {
      byte[] arrayOfByte = this.info.getEncryptedKey().getOctets();
      Cipher localCipher = Cipher.getInstance(this.keyEncAlg.getObjectId().getId(), paramProvider);
      localCipher.init(4, paramKey);
      AlgorithmIdentifier localAlgorithmIdentifier = getActiveAlgID();
      String str = localAlgorithmIdentifier.getObjectId().getId();
      Key localKey = localCipher.unwrap(arrayOfByte, str, 3);
      return getContentFromSessionKey(localKey, paramProvider);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new CMSException("can't find algorithm.", localNoSuchAlgorithmException);
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new CMSException("key invalid in message.", localInvalidKeyException);
    }
    catch (NoSuchPaddingException localNoSuchPaddingException)
    {
      throw new CMSException("required padding not supported.", localNoSuchPaddingException);
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\KEKRecipientInformation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */