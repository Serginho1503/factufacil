package org.bouncycastle.cms;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.AlgorithmParameters;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.util.ArrayList;
import java.util.List;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1OctetStringParser;
import org.bouncycastle.asn1.ASN1SequenceParser;
import org.bouncycastle.asn1.ASN1SetParser;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.AuthenticatedDataParser;
import org.bouncycastle.asn1.cms.ContentInfoParser;
import org.bouncycastle.asn1.cms.RecipientInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.util.Arrays;

public class CMSAuthenticatedDataParser
  extends CMSContentInfoParser
{
  RecipientInformationStore _recipientInfoStore;
  AuthenticatedDataParser authData = new AuthenticatedDataParser((ASN1SequenceParser)this._contentInfo.getContent(16));
  private AlgorithmIdentifier macAlg;
  private byte[] mac;
  private AttributeTable authAttrs;
  private AttributeTable unauthAttrs;
  private boolean authAttrNotRead = true;
  private boolean unauthAttrNotRead;
  
  public CMSAuthenticatedDataParser(byte[] paramArrayOfByte)
    throws CMSException, IOException
  {
    this(new ByteArrayInputStream(paramArrayOfByte));
  }
  
  public CMSAuthenticatedDataParser(InputStream paramInputStream)
    throws CMSException, IOException
  {
    super(paramInputStream);
    ASN1SetParser localASN1SetParser = this.authData.getRecipientInfos();
    ArrayList localArrayList = new ArrayList();
    DEREncodable localDEREncodable;
    while ((localDEREncodable = localASN1SetParser.readObject()) != null) {
      localArrayList.add(RecipientInfo.getInstance(localDEREncodable.getDERObject()));
    }
    this.macAlg = this.authData.getMacAlgorithm();
    ContentInfoParser localContentInfoParser = this.authData.getEnapsulatedContentInfo();
    InputStream localInputStream = ((ASN1OctetStringParser)localContentInfoParser.getContent(4)).getOctetStream();
    List localList = CMSEnvelopedHelper.readRecipientInfos(localArrayList.iterator(), localInputStream, null, this.macAlg, null);
    this._recipientInfoStore = new RecipientInformationStore(localList);
  }
  
  public String getMacAlgOID()
  {
    return this.macAlg.getObjectId().toString();
  }
  
  public byte[] getMacAlgParams()
  {
    try
    {
      return encodeObj(this.macAlg.getParameters());
    }
    catch (Exception localException)
    {
      throw new RuntimeException("exception getting encryption parameters " + localException);
    }
  }
  
  public AlgorithmParameters getMacAlgorithmParameters(String paramString)
    throws CMSException, NoSuchProviderException
  {
    return getMacAlgorithmParameters(CMSUtils.getProvider(paramString));
  }
  
  public AlgorithmParameters getMacAlgorithmParameters(Provider paramProvider)
    throws CMSException
  {
    return CMSEnvelopedHelper.INSTANCE.getEncryptionAlgorithmParameters(getMacAlgOID(), getMacAlgParams(), paramProvider);
  }
  
  public RecipientInformationStore getRecipientInfos()
  {
    return this._recipientInfoStore;
  }
  
  public byte[] getMac()
    throws IOException
  {
    if (this.mac == null)
    {
      getAuthAttrs();
      this.mac = this.authData.getMac().getOctets();
    }
    return Arrays.clone(this.mac);
  }
  
  public AttributeTable getAuthAttrs()
    throws IOException
  {
    if ((this.authAttrs == null) && (this.authAttrNotRead))
    {
      ASN1SetParser localASN1SetParser = this.authData.getAuthAttrs();
      this.authAttrNotRead = false;
      if (localASN1SetParser != null)
      {
        ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
        DEREncodable localDEREncodable;
        while ((localDEREncodable = localASN1SetParser.readObject()) != null)
        {
          ASN1SequenceParser localASN1SequenceParser = (ASN1SequenceParser)localDEREncodable;
          localASN1EncodableVector.add(localASN1SequenceParser.getDERObject());
        }
        this.authAttrs = new AttributeTable(new DERSet(localASN1EncodableVector));
      }
    }
    return this.authAttrs;
  }
  
  public AttributeTable getUnauthAttrs()
    throws IOException
  {
    if ((this.unauthAttrs == null) && (this.unauthAttrNotRead))
    {
      ASN1SetParser localASN1SetParser = this.authData.getUnauthAttrs();
      this.unauthAttrNotRead = false;
      if (localASN1SetParser != null)
      {
        ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
        DEREncodable localDEREncodable;
        while ((localDEREncodable = localASN1SetParser.readObject()) != null)
        {
          ASN1SequenceParser localASN1SequenceParser = (ASN1SequenceParser)localDEREncodable;
          localASN1EncodableVector.add(localASN1SequenceParser.getDERObject());
        }
        this.unauthAttrs = new AttributeTable(new DERSet(localASN1EncodableVector));
      }
    }
    return this.unauthAttrs;
  }
  
  private byte[] encodeObj(DEREncodable paramDEREncodable)
    throws IOException
  {
    if (paramDEREncodable != null) {
      return paramDEREncodable.getDERObject().getEncoded();
    }
    return null;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSAuthenticatedDataParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */