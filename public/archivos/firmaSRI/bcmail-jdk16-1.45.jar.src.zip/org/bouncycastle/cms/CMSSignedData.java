package org.bouncycastle.cms;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.cert.CertStore;
import java.security.cert.CertStoreException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.BERSequence;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.cms.ContentInfo;
import org.bouncycastle.asn1.cms.SignedData;
import org.bouncycastle.asn1.cms.SignerInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.x509.NoSuchStoreException;
import org.bouncycastle.x509.X509Store;

public class CMSSignedData
{
  private static final CMSSignedHelper HELPER = CMSSignedHelper.INSTANCE;
  SignedData signedData;
  ContentInfo contentInfo;
  CMSProcessable signedContent;
  CertStore certStore;
  SignerInformationStore signerInfoStore;
  X509Store attributeStore;
  X509Store certificateStore;
  X509Store crlStore;
  private Map hashes;
  
  private CMSSignedData(CMSSignedData paramCMSSignedData)
  {
    this.signedData = paramCMSSignedData.signedData;
    this.contentInfo = paramCMSSignedData.contentInfo;
    this.signedContent = paramCMSSignedData.signedContent;
    this.certStore = paramCMSSignedData.certStore;
    this.signerInfoStore = paramCMSSignedData.signerInfoStore;
  }
  
  public CMSSignedData(byte[] paramArrayOfByte)
    throws CMSException
  {
    this(CMSUtils.readContentInfo(paramArrayOfByte));
  }
  
  public CMSSignedData(CMSProcessable paramCMSProcessable, byte[] paramArrayOfByte)
    throws CMSException
  {
    this(paramCMSProcessable, CMSUtils.readContentInfo(paramArrayOfByte));
  }
  
  public CMSSignedData(Map paramMap, byte[] paramArrayOfByte)
    throws CMSException
  {
    this(paramMap, CMSUtils.readContentInfo(paramArrayOfByte));
  }
  
  public CMSSignedData(CMSProcessable paramCMSProcessable, InputStream paramInputStream)
    throws CMSException
  {
    this(paramCMSProcessable, CMSUtils.readContentInfo(new ASN1InputStream(paramInputStream)));
  }
  
  public CMSSignedData(InputStream paramInputStream)
    throws CMSException
  {
    this(CMSUtils.readContentInfo(paramInputStream));
  }
  
  public CMSSignedData(CMSProcessable paramCMSProcessable, ContentInfo paramContentInfo)
  {
    this.signedContent = paramCMSProcessable;
    this.contentInfo = paramContentInfo;
    this.signedData = SignedData.getInstance(this.contentInfo.getContent());
  }
  
  public CMSSignedData(Map paramMap, ContentInfo paramContentInfo)
  {
    this.hashes = paramMap;
    this.contentInfo = paramContentInfo;
    this.signedData = SignedData.getInstance(this.contentInfo.getContent());
  }
  
  public CMSSignedData(ContentInfo paramContentInfo)
  {
    this.contentInfo = paramContentInfo;
    this.signedData = SignedData.getInstance(this.contentInfo.getContent());
    if (this.signedData.getEncapContentInfo().getContent() != null) {
      this.signedContent = new CMSProcessableByteArray(((ASN1OctetString)this.signedData.getEncapContentInfo().getContent()).getOctets());
    } else {
      this.signedContent = null;
    }
  }
  
  public int getVersion()
  {
    return this.signedData.getVersion().getValue().intValue();
  }
  
  public SignerInformationStore getSignerInfos()
  {
    if (this.signerInfoStore == null)
    {
      ASN1Set localASN1Set = this.signedData.getSignerInfos();
      ArrayList localArrayList = new ArrayList();
      for (int i = 0; i != localASN1Set.size(); i++)
      {
        SignerInfo localSignerInfo = SignerInfo.getInstance(localASN1Set.getObjectAt(i));
        DERObjectIdentifier localDERObjectIdentifier = this.signedData.getEncapContentInfo().getContentType();
        if (this.hashes == null)
        {
          localArrayList.add(new SignerInformation(localSignerInfo, localDERObjectIdentifier, this.signedContent, null));
        }
        else
        {
          byte[] arrayOfByte = (byte[])this.hashes.get(localSignerInfo.getDigestAlgorithm().getObjectId().getId());
          localArrayList.add(new SignerInformation(localSignerInfo, localDERObjectIdentifier, null, new BaseDigestCalculator(arrayOfByte)));
        }
      }
      this.signerInfoStore = new SignerInformationStore(localArrayList);
    }
    return this.signerInfoStore;
  }
  
  public X509Store getAttributeCertificates(String paramString1, String paramString2)
    throws NoSuchStoreException, NoSuchProviderException, CMSException
  {
    return getAttributeCertificates(paramString1, CMSUtils.getProvider(paramString2));
  }
  
  public X509Store getAttributeCertificates(String paramString, Provider paramProvider)
    throws NoSuchStoreException, CMSException
  {
    if (this.attributeStore == null) {
      this.attributeStore = HELPER.createAttributeStore(paramString, paramProvider, this.signedData.getCertificates());
    }
    return this.attributeStore;
  }
  
  public X509Store getCertificates(String paramString1, String paramString2)
    throws NoSuchStoreException, NoSuchProviderException, CMSException
  {
    return getCertificates(paramString1, CMSUtils.getProvider(paramString2));
  }
  
  public X509Store getCertificates(String paramString, Provider paramProvider)
    throws NoSuchStoreException, CMSException
  {
    if (this.certificateStore == null) {
      this.certificateStore = HELPER.createCertificateStore(paramString, paramProvider, this.signedData.getCertificates());
    }
    return this.certificateStore;
  }
  
  public X509Store getCRLs(String paramString1, String paramString2)
    throws NoSuchStoreException, NoSuchProviderException, CMSException
  {
    return getCRLs(paramString1, CMSUtils.getProvider(paramString2));
  }
  
  public X509Store getCRLs(String paramString, Provider paramProvider)
    throws NoSuchStoreException, CMSException
  {
    if (this.crlStore == null) {
      this.crlStore = HELPER.createCRLsStore(paramString, paramProvider, this.signedData.getCRLs());
    }
    return this.crlStore;
  }
  
  public CertStore getCertificatesAndCRLs(String paramString1, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    return getCertificatesAndCRLs(paramString1, CMSUtils.getProvider(paramString2));
  }
  
  public CertStore getCertificatesAndCRLs(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException
  {
    if (this.certStore == null)
    {
      ASN1Set localASN1Set1 = this.signedData.getCertificates();
      ASN1Set localASN1Set2 = this.signedData.getCRLs();
      this.certStore = HELPER.createCertStore(paramString, paramProvider, localASN1Set1, localASN1Set2);
    }
    return this.certStore;
  }
  
  public String getSignedContentTypeOID()
  {
    return this.signedData.getEncapContentInfo().getContentType().getId();
  }
  
  public CMSProcessable getSignedContent()
  {
    return this.signedContent;
  }
  
  public ContentInfo getContentInfo()
  {
    return this.contentInfo;
  }
  
  public byte[] getEncoded()
    throws IOException
  {
    return this.contentInfo.getEncoded();
  }
  
  public static CMSSignedData replaceSigners(CMSSignedData paramCMSSignedData, SignerInformationStore paramSignerInformationStore)
  {
    CMSSignedData localCMSSignedData = new CMSSignedData(paramCMSSignedData);
    localCMSSignedData.signerInfoStore = paramSignerInformationStore;
    ASN1EncodableVector localASN1EncodableVector1 = new ASN1EncodableVector();
    ASN1EncodableVector localASN1EncodableVector2 = new ASN1EncodableVector();
    Iterator localIterator = paramSignerInformationStore.getSigners().iterator();
    while (localIterator.hasNext())
    {
      localObject = (SignerInformation)localIterator.next();
      localASN1EncodableVector1.add(CMSSignedHelper.INSTANCE.fixAlgID(((SignerInformation)localObject).getDigestAlgorithmID()));
      localASN1EncodableVector2.add(((SignerInformation)localObject).toSignerInfo());
    }
    Object localObject = new DERSet(localASN1EncodableVector1);
    DERSet localDERSet = new DERSet(localASN1EncodableVector2);
    ASN1Sequence localASN1Sequence = (ASN1Sequence)paramCMSSignedData.signedData.getDERObject();
    localASN1EncodableVector2 = new ASN1EncodableVector();
    localASN1EncodableVector2.add(localASN1Sequence.getObjectAt(0));
    localASN1EncodableVector2.add((DEREncodable)localObject);
    for (int i = 2; i != localASN1Sequence.size() - 1; i++) {
      localASN1EncodableVector2.add(localASN1Sequence.getObjectAt(i));
    }
    localASN1EncodableVector2.add(localDERSet);
    localCMSSignedData.signedData = SignedData.getInstance(new BERSequence(localASN1EncodableVector2));
    localCMSSignedData.contentInfo = new ContentInfo(localCMSSignedData.contentInfo.getContentType(), localCMSSignedData.signedData);
    return localCMSSignedData;
  }
  
  public static CMSSignedData replaceCertificatesAndCRLs(CMSSignedData paramCMSSignedData, CertStore paramCertStore)
    throws CMSException
  {
    CMSSignedData localCMSSignedData = new CMSSignedData(paramCMSSignedData);
    localCMSSignedData.certStore = paramCertStore;
    Object localObject1 = null;
    Object localObject2 = null;
    try
    {
      ASN1Set localASN1Set1 = CMSUtils.createBerSetFromList(CMSUtils.getCertificatesFromStore(paramCertStore));
      if (localASN1Set1.size() != 0) {
        localObject1 = localASN1Set1;
      }
    }
    catch (CertStoreException localCertStoreException1)
    {
      throw new CMSException("error getting certs from certStore", localCertStoreException1);
    }
    try
    {
      ASN1Set localASN1Set2 = CMSUtils.createBerSetFromList(CMSUtils.getCRLsFromStore(paramCertStore));
      if (localASN1Set2.size() != 0) {
        localObject2 = localASN1Set2;
      }
    }
    catch (CertStoreException localCertStoreException2)
    {
      throw new CMSException("error getting crls from certStore", localCertStoreException2);
    }
    localCMSSignedData.signedData = new SignedData(paramCMSSignedData.signedData.getDigestAlgorithms(), paramCMSSignedData.signedData.getEncapContentInfo(), (ASN1Set)localObject1, (ASN1Set)localObject2, paramCMSSignedData.signedData.getSignerInfos());
    localCMSSignedData.contentInfo = new ContentInfo(localCMSSignedData.contentInfo.getContentType(), localCMSSignedData.signedData);
    return localCMSSignedData;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSSignedData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */