package org.bouncycastle.cms;

import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cms.IssuerAndSerialNumber;
import org.bouncycastle.asn1.cms.KeyAgreeRecipientIdentifier;
import org.bouncycastle.asn1.cms.KeyAgreeRecipientInfo;
import org.bouncycastle.asn1.cms.OriginatorIdentifierOrKey;
import org.bouncycastle.asn1.cms.OriginatorPublicKey;
import org.bouncycastle.asn1.cms.RecipientEncryptedKey;
import org.bouncycastle.asn1.cms.RecipientKeyIdentifier;
import org.bouncycastle.asn1.cms.ecc.MQVuserKeyingMaterial;
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectKeyIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.asn1.x509.X509Name;
import org.bouncycastle.jce.spec.MQVPrivateKeySpec;
import org.bouncycastle.jce.spec.MQVPublicKeySpec;

public class KeyAgreeRecipientInformation
  extends RecipientInformation
{
  private KeyAgreeRecipientInfo info;
  private ASN1OctetString encryptedKey;
  
  /**
   * @deprecated
   */
  public KeyAgreeRecipientInformation(KeyAgreeRecipientInfo paramKeyAgreeRecipientInfo, AlgorithmIdentifier paramAlgorithmIdentifier, InputStream paramInputStream)
  {
    this(paramKeyAgreeRecipientInfo, paramAlgorithmIdentifier, null, null, paramInputStream);
  }
  
  /**
   * @deprecated
   */
  public KeyAgreeRecipientInformation(KeyAgreeRecipientInfo paramKeyAgreeRecipientInfo, AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, InputStream paramInputStream)
  {
    this(paramKeyAgreeRecipientInfo, paramAlgorithmIdentifier1, paramAlgorithmIdentifier2, null, paramInputStream);
  }
  
  KeyAgreeRecipientInformation(KeyAgreeRecipientInfo paramKeyAgreeRecipientInfo, AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, AlgorithmIdentifier paramAlgorithmIdentifier3, InputStream paramInputStream)
  {
    super(paramAlgorithmIdentifier1, paramAlgorithmIdentifier2, paramAlgorithmIdentifier3, paramKeyAgreeRecipientInfo.getKeyEncryptionAlgorithm(), paramInputStream);
    this.info = paramKeyAgreeRecipientInfo;
    this.rid = new RecipientId();
    try
    {
      ASN1Sequence localASN1Sequence = this.info.getRecipientEncryptedKeys();
      RecipientEncryptedKey localRecipientEncryptedKey = RecipientEncryptedKey.getInstance(localASN1Sequence.getObjectAt(0));
      KeyAgreeRecipientIdentifier localKeyAgreeRecipientIdentifier = localRecipientEncryptedKey.getIdentifier();
      IssuerAndSerialNumber localIssuerAndSerialNumber = localKeyAgreeRecipientIdentifier.getIssuerAndSerialNumber();
      if (localIssuerAndSerialNumber != null)
      {
        this.rid.setIssuer(localIssuerAndSerialNumber.getName().getEncoded());
        this.rid.setSerialNumber(localIssuerAndSerialNumber.getSerialNumber().getValue());
      }
      else
      {
        RecipientKeyIdentifier localRecipientKeyIdentifier = localKeyAgreeRecipientIdentifier.getRKeyID();
        this.rid.setSubjectKeyIdentifier(localRecipientKeyIdentifier.getSubjectKeyIdentifier().getOctets());
      }
      this.encryptedKey = localRecipientEncryptedKey.getEncryptedKey();
    }
    catch (IOException localIOException)
    {
      throw new IllegalArgumentException("invalid rid in KeyAgreeRecipientInformation");
    }
  }
  
  private PublicKey getSenderPublicKey(Key paramKey, OriginatorIdentifierOrKey paramOriginatorIdentifierOrKey, Provider paramProvider)
    throws CMSException, GeneralSecurityException, IOException
  {
    OriginatorPublicKey localOriginatorPublicKey = paramOriginatorIdentifierOrKey.getOriginatorKey();
    if (localOriginatorPublicKey != null) {
      return getPublicKeyFromOriginatorPublicKey(paramKey, localOriginatorPublicKey, paramProvider);
    }
    OriginatorId localOriginatorId = new OriginatorId();
    IssuerAndSerialNumber localIssuerAndSerialNumber = paramOriginatorIdentifierOrKey.getIssuerAndSerialNumber();
    if (localIssuerAndSerialNumber != null)
    {
      localOriginatorId.setIssuer(localIssuerAndSerialNumber.getName().getEncoded());
      localOriginatorId.setSerialNumber(localIssuerAndSerialNumber.getSerialNumber().getValue());
    }
    else
    {
      SubjectKeyIdentifier localSubjectKeyIdentifier = paramOriginatorIdentifierOrKey.getSubjectKeyIdentifier();
      localOriginatorId.setSubjectKeyIdentifier(localSubjectKeyIdentifier.getKeyIdentifier());
    }
    return getPublicKeyFromOriginatorId(localOriginatorId, paramProvider);
  }
  
  private PublicKey getPublicKeyFromOriginatorPublicKey(Key paramKey, OriginatorPublicKey paramOriginatorPublicKey, Provider paramProvider)
    throws CMSException, GeneralSecurityException, IOException
  {
    PrivateKeyInfo localPrivateKeyInfo = PrivateKeyInfo.getInstance(ASN1Object.fromByteArray(paramKey.getEncoded()));
    SubjectPublicKeyInfo localSubjectPublicKeyInfo = new SubjectPublicKeyInfo(localPrivateKeyInfo.getAlgorithmId(), paramOriginatorPublicKey.getPublicKey().getBytes());
    X509EncodedKeySpec localX509EncodedKeySpec = new X509EncodedKeySpec(localSubjectPublicKeyInfo.getEncoded());
    KeyFactory localKeyFactory = KeyFactory.getInstance(this.keyEncAlg.getObjectId().getId(), paramProvider);
    return localKeyFactory.generatePublic(localX509EncodedKeySpec);
  }
  
  private PublicKey getPublicKeyFromOriginatorId(OriginatorId paramOriginatorId, Provider paramProvider)
    throws CMSException
  {
    throw new CMSException("No support for 'originator' as IssuerAndSerialNumber or SubjectKeyIdentifier");
  }
  
  private SecretKey calculateAgreedWrapKey(String paramString, PublicKey paramPublicKey, PrivateKey paramPrivateKey, Provider paramProvider)
    throws CMSException, GeneralSecurityException, IOException
  {
    String str = this.keyEncAlg.getObjectId().getId();
    if (str.equals(CMSEnvelopedGenerator.ECMQV_SHA1KDF))
    {
      localObject = this.info.getUserKeyingMaterial().getOctets();
      MQVuserKeyingMaterial localMQVuserKeyingMaterial = MQVuserKeyingMaterial.getInstance(ASN1Object.fromByteArray((byte[])localObject));
      PublicKey localPublicKey = getPublicKeyFromOriginatorPublicKey(paramPrivateKey, localMQVuserKeyingMaterial.getEphemeralPublicKey(), paramProvider);
      paramPublicKey = new MQVPublicKeySpec(paramPublicKey, localPublicKey);
      paramPrivateKey = new MQVPrivateKeySpec(paramPrivateKey, paramPrivateKey);
    }
    Object localObject = KeyAgreement.getInstance(str, paramProvider);
    ((KeyAgreement)localObject).init(paramPrivateKey);
    ((KeyAgreement)localObject).doPhase(paramPublicKey, true);
    return ((KeyAgreement)localObject).generateSecret(paramString);
  }
  
  private Key unwrapSessionKey(String paramString, SecretKey paramSecretKey, Provider paramProvider)
    throws GeneralSecurityException
  {
    AlgorithmIdentifier localAlgorithmIdentifier = getActiveAlgID();
    String str = localAlgorithmIdentifier.getObjectId().getId();
    byte[] arrayOfByte = this.encryptedKey.getOctets();
    Cipher localCipher = Cipher.getInstance(paramString, paramProvider);
    localCipher.init(4, paramSecretKey);
    return localCipher.unwrap(arrayOfByte, str, 3);
  }
  
  protected Key getSessionKey(Key paramKey, Provider paramProvider)
    throws CMSException
  {
    try
    {
      String str = DERObjectIdentifier.getInstance(ASN1Sequence.getInstance(this.keyEncAlg.getParameters()).getObjectAt(0)).getId();
      PublicKey localPublicKey = getSenderPublicKey(paramKey, this.info.getOriginator(), paramProvider);
      SecretKey localSecretKey = calculateAgreedWrapKey(str, localPublicKey, (PrivateKey)paramKey, paramProvider);
      return unwrapSessionKey(str, localSecretKey, paramProvider);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new CMSException("can't find algorithm.", localNoSuchAlgorithmException);
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new CMSException("key invalid in message.", localInvalidKeyException);
    }
    catch (InvalidKeySpecException localInvalidKeySpecException)
    {
      throw new CMSException("originator key spec invalid.", localInvalidKeySpecException);
    }
    catch (NoSuchPaddingException localNoSuchPaddingException)
    {
      throw new CMSException("required padding not supported.", localNoSuchPaddingException);
    }
    catch (Exception localException)
    {
      throw new CMSException("originator key invalid.", localException);
    }
  }
  
  public CMSTypedStream getContentStream(Key paramKey, String paramString)
    throws CMSException, NoSuchProviderException
  {
    return getContentStream(paramKey, CMSUtils.getProvider(paramString));
  }
  
  public CMSTypedStream getContentStream(Key paramKey, Provider paramProvider)
    throws CMSException
  {
    Key localKey = getSessionKey(paramKey, paramProvider);
    return getContentFromSessionKey(localKey, paramProvider);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\KeyAgreeRecipientInformation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */