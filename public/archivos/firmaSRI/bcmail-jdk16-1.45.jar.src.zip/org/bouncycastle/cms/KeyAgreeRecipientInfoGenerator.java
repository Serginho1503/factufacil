package org.bouncycastle.cms;

import java.security.GeneralSecurityException;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.cms.IssuerAndSerialNumber;
import org.bouncycastle.asn1.cms.KeyAgreeRecipientIdentifier;
import org.bouncycastle.asn1.cms.KeyAgreeRecipientInfo;
import org.bouncycastle.asn1.cms.OriginatorIdentifierOrKey;
import org.bouncycastle.asn1.cms.RecipientEncryptedKey;
import org.bouncycastle.asn1.cms.RecipientInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.TBSCertificateStructure;

class KeyAgreeRecipientInfoGenerator
  implements RecipientInfoGenerator
{
  private DERObjectIdentifier algorithmOID;
  private OriginatorIdentifierOrKey originator;
  private TBSCertificateStructure recipientTBSCert;
  private ASN1OctetString ukm;
  private DERObjectIdentifier wrapAlgorithmOID;
  private SecretKey wrapKey;
  
  void setAlgorithmOID(DERObjectIdentifier paramDERObjectIdentifier)
  {
    this.algorithmOID = paramDERObjectIdentifier;
  }
  
  void setOriginator(OriginatorIdentifierOrKey paramOriginatorIdentifierOrKey)
  {
    this.originator = paramOriginatorIdentifierOrKey;
  }
  
  void setRecipientCert(X509Certificate paramX509Certificate)
  {
    try
    {
      this.recipientTBSCert = CMSUtils.getTBSCertificateStructure(paramX509Certificate);
    }
    catch (CertificateEncodingException localCertificateEncodingException)
    {
      throw new IllegalArgumentException("can't extract TBS structure from this cert");
    }
  }
  
  void setUKM(ASN1OctetString paramASN1OctetString)
  {
    this.ukm = paramASN1OctetString;
  }
  
  void setWrapAlgorithmOID(DERObjectIdentifier paramDERObjectIdentifier)
  {
    this.wrapAlgorithmOID = paramDERObjectIdentifier;
  }
  
  void setWrapKey(SecretKey paramSecretKey)
  {
    this.wrapKey = paramSecretKey;
  }
  
  public RecipientInfo generate(SecretKey paramSecretKey, SecureRandom paramSecureRandom, Provider paramProvider)
    throws GeneralSecurityException
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.wrapAlgorithmOID);
    localASN1EncodableVector.add(DERNull.INSTANCE);
    AlgorithmIdentifier localAlgorithmIdentifier = new AlgorithmIdentifier(this.algorithmOID, new DERSequence(localASN1EncodableVector));
    IssuerAndSerialNumber localIssuerAndSerialNumber = new IssuerAndSerialNumber(this.recipientTBSCert.getIssuer(), this.recipientTBSCert.getSerialNumber().getValue());
    Cipher localCipher = CMSEnvelopedHelper.INSTANCE.createAsymmetricCipher(this.wrapAlgorithmOID.getId(), paramProvider);
    localCipher.init(3, this.wrapKey, paramSecureRandom);
    DEROctetString localDEROctetString = new DEROctetString(localCipher.wrap(paramSecretKey));
    RecipientEncryptedKey localRecipientEncryptedKey = new RecipientEncryptedKey(new KeyAgreeRecipientIdentifier(localIssuerAndSerialNumber), localDEROctetString);
    return new RecipientInfo(new KeyAgreeRecipientInfo(this.originator, this.ukm, localAlgorithmIdentifier, new DERSequence(localRecipientEncryptedKey)));
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\KeyAgreeRecipientInfoGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */