package org.bouncycastle.cms;

import java.io.IOException;
import java.io.OutputStream;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.InvalidParameterSpecException;
import java.util.Iterator;
import java.util.List;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.BERSequenceGenerator;
import org.bouncycastle.asn1.BERSet;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.cms.AuthenticatedData;
import org.bouncycastle.asn1.cms.CMSObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class CMSAuthenticatedDataStreamGenerator
  extends CMSAuthenticatedGenerator
{
  private int _bufferSize;
  private boolean _berEncodeRecipientSet;
  
  public CMSAuthenticatedDataStreamGenerator() {}
  
  public CMSAuthenticatedDataStreamGenerator(SecureRandom paramSecureRandom)
  {
    super(paramSecureRandom);
  }
  
  public void setBufferSize(int paramInt)
  {
    this._bufferSize = paramInt;
  }
  
  public void setBEREncodeRecipients(boolean paramBoolean)
  {
    this._berEncodeRecipientSet = paramBoolean;
  }
  
  private OutputStream open(OutputStream paramOutputStream, String paramString, KeyGenerator paramKeyGenerator, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException
  {
    Provider localProvider = paramKeyGenerator.getProvider();
    SecretKey localSecretKey = paramKeyGenerator.generateKey();
    AlgorithmParameterSpec localAlgorithmParameterSpec = generateParameterSpec(paramString, localSecretKey, localProvider);
    Iterator localIterator = this.recipientInfoGenerators.iterator();
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    while (localIterator.hasNext())
    {
      RecipientInfoGenerator localRecipientInfoGenerator = (RecipientInfoGenerator)localIterator.next();
      try
      {
        localASN1EncodableVector.add(localRecipientInfoGenerator.generate(localSecretKey, this.rand, paramProvider));
      }
      catch (InvalidKeyException localInvalidKeyException)
      {
        throw new CMSException("key inappropriate for algorithm.", localInvalidKeyException);
      }
      catch (GeneralSecurityException localGeneralSecurityException)
      {
        throw new CMSException("error making encrypted content.", localGeneralSecurityException);
      }
    }
    return open(paramOutputStream, paramString, localSecretKey, localAlgorithmParameterSpec, localASN1EncodableVector, localProvider);
  }
  
  protected OutputStream open(OutputStream paramOutputStream, String paramString1, SecretKey paramSecretKey, AlgorithmParameterSpec paramAlgorithmParameterSpec, ASN1EncodableVector paramASN1EncodableVector, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    return open(paramOutputStream, paramString1, paramSecretKey, paramAlgorithmParameterSpec, paramASN1EncodableVector, CMSUtils.getProvider(paramString2));
  }
  
  protected OutputStream open(OutputStream paramOutputStream, String paramString, SecretKey paramSecretKey, AlgorithmParameterSpec paramAlgorithmParameterSpec, ASN1EncodableVector paramASN1EncodableVector, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException
  {
    try
    {
      BERSequenceGenerator localBERSequenceGenerator1 = new BERSequenceGenerator(paramOutputStream);
      localBERSequenceGenerator1.addObject(CMSObjectIdentifiers.authenticatedData);
      BERSequenceGenerator localBERSequenceGenerator2 = new BERSequenceGenerator(localBERSequenceGenerator1.getRawOutputStream(), 0, true);
      localBERSequenceGenerator2.addObject(new DERInteger(AuthenticatedData.calculateVersion(null)));
      if (this._berEncodeRecipientSet) {
        localBERSequenceGenerator2.getRawOutputStream().write(new BERSet(paramASN1EncodableVector).getEncoded());
      } else {
        localBERSequenceGenerator2.getRawOutputStream().write(new DERSet(paramASN1EncodableVector).getEncoded());
      }
      Mac localMac = CMSEnvelopedHelper.INSTANCE.getMac(paramString, paramProvider);
      localMac.init(paramSecretKey, paramAlgorithmParameterSpec);
      AlgorithmIdentifier localAlgorithmIdentifier = getAlgorithmIdentifier(paramString, paramAlgorithmParameterSpec, paramProvider);
      localBERSequenceGenerator2.getRawOutputStream().write(localAlgorithmIdentifier.getEncoded());
      BERSequenceGenerator localBERSequenceGenerator3 = new BERSequenceGenerator(localBERSequenceGenerator2.getRawOutputStream());
      localBERSequenceGenerator3.addObject(CMSObjectIdentifiers.data);
      OutputStream localOutputStream = CMSUtils.createBEROctetOutputStream(localBERSequenceGenerator3.getRawOutputStream(), 0, false, this._bufferSize);
      CMSAuthenticatedGenerator.MacOutputStream localMacOutputStream = new CMSAuthenticatedGenerator.MacOutputStream(localOutputStream, localMac);
      return new CmsAuthenticatedDataOutputStream(localMacOutputStream, localBERSequenceGenerator1, localBERSequenceGenerator2, localBERSequenceGenerator3);
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new CMSException("key invalid in message.", localInvalidKeyException);
    }
    catch (NoSuchPaddingException localNoSuchPaddingException)
    {
      throw new CMSException("required padding not supported.", localNoSuchPaddingException);
    }
    catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
    {
      throw new CMSException("algorithm parameter invalid.", localInvalidAlgorithmParameterException);
    }
    catch (InvalidParameterSpecException localInvalidParameterSpecException)
    {
      throw new CMSException("algorithm parameter spec invalid.", localInvalidParameterSpecException);
    }
    catch (IOException localIOException)
    {
      throw new CMSException("exception decoding algorithm parameters.", localIOException);
    }
  }
  
  public OutputStream open(OutputStream paramOutputStream, String paramString1, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException, IOException
  {
    return open(paramOutputStream, paramString1, CMSUtils.getProvider(paramString2));
  }
  
  public OutputStream open(OutputStream paramOutputStream, String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException, IOException
  {
    KeyGenerator localKeyGenerator = CMSEnvelopedHelper.INSTANCE.createSymmetricKeyGenerator(paramString, paramProvider);
    localKeyGenerator.init(this.rand);
    return open(paramOutputStream, paramString, localKeyGenerator, paramProvider);
  }
  
  public OutputStream open(OutputStream paramOutputStream, String paramString1, int paramInt, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException, IOException
  {
    return open(paramOutputStream, paramString1, paramInt, CMSUtils.getProvider(paramString2));
  }
  
  public OutputStream open(OutputStream paramOutputStream, String paramString, int paramInt, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException, IOException
  {
    KeyGenerator localKeyGenerator = CMSEnvelopedHelper.INSTANCE.createSymmetricKeyGenerator(paramString, paramProvider);
    localKeyGenerator.init(paramInt, this.rand);
    return open(paramOutputStream, paramString, localKeyGenerator, paramProvider);
  }
  
  private class CmsAuthenticatedDataOutputStream
    extends OutputStream
  {
    private CMSAuthenticatedGenerator.MacOutputStream macStream;
    private BERSequenceGenerator cGen;
    private BERSequenceGenerator envGen;
    private BERSequenceGenerator eiGen;
    
    public CmsAuthenticatedDataOutputStream(CMSAuthenticatedGenerator.MacOutputStream paramMacOutputStream, BERSequenceGenerator paramBERSequenceGenerator1, BERSequenceGenerator paramBERSequenceGenerator2, BERSequenceGenerator paramBERSequenceGenerator3)
    {
      this.macStream = paramMacOutputStream;
      this.cGen = paramBERSequenceGenerator1;
      this.envGen = paramBERSequenceGenerator2;
      this.eiGen = paramBERSequenceGenerator3;
    }
    
    public void write(int paramInt)
      throws IOException
    {
      this.macStream.write(paramInt);
    }
    
    public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {
      this.macStream.write(paramArrayOfByte, paramInt1, paramInt2);
    }
    
    public void write(byte[] paramArrayOfByte)
      throws IOException
    {
      this.macStream.write(paramArrayOfByte);
    }
    
    public void close()
      throws IOException
    {
      this.macStream.close();
      this.eiGen.close();
      this.envGen.addObject(new DEROctetString(this.macStream.getMac()));
      this.envGen.close();
      this.cGen.close();
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSAuthenticatedDataStreamGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */