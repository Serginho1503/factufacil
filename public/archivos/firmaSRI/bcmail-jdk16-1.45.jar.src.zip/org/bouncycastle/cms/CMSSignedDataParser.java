package org.bouncycastle.cms;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.cert.CertStore;
import java.security.cert.CertStoreException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Generator;
import org.bouncycastle.asn1.ASN1OctetStringParser;
import org.bouncycastle.asn1.ASN1SequenceParser;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.ASN1SetParser;
import org.bouncycastle.asn1.ASN1StreamParser;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.BERSequenceGenerator;
import org.bouncycastle.asn1.BERSetParser;
import org.bouncycastle.asn1.BERTaggedObject;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.cms.CMSObjectIdentifiers;
import org.bouncycastle.asn1.cms.ContentInfoParser;
import org.bouncycastle.asn1.cms.SignedDataParser;
import org.bouncycastle.asn1.cms.SignerInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.util.io.Streams;
import org.bouncycastle.x509.NoSuchStoreException;
import org.bouncycastle.x509.X509Store;

public class CMSSignedDataParser
  extends CMSContentInfoParser
{
  private static final CMSSignedHelper HELPER = CMSSignedHelper.INSTANCE;
  private SignedDataParser _signedData;
  private DERObjectIdentifier _signedContentType;
  private CMSTypedStream _signedContent;
  private Map _digests;
  private CertStore _certStore;
  private SignerInformationStore _signerInfoStore;
  private X509Store _attributeStore;
  private ASN1Set _certSet;
  private ASN1Set _crlSet;
  private boolean _isCertCrlParsed;
  private X509Store _certificateStore;
  private X509Store _crlStore;
  
  public CMSSignedDataParser(byte[] paramArrayOfByte)
    throws CMSException
  {
    this(new ByteArrayInputStream(paramArrayOfByte));
  }
  
  public CMSSignedDataParser(CMSTypedStream paramCMSTypedStream, byte[] paramArrayOfByte)
    throws CMSException
  {
    this(paramCMSTypedStream, new ByteArrayInputStream(paramArrayOfByte));
  }
  
  public CMSSignedDataParser(InputStream paramInputStream)
    throws CMSException
  {
    this(null, paramInputStream);
  }
  
  public CMSSignedDataParser(CMSTypedStream paramCMSTypedStream, InputStream paramInputStream)
    throws CMSException
  {
    super(paramInputStream);
    try
    {
      this._signedContent = paramCMSTypedStream;
      this._signedData = SignedDataParser.getInstance(this._contentInfo.getContent(16));
      this._digests = new HashMap();
      ASN1SetParser localASN1SetParser = this._signedData.getDigestAlgorithms();
      DEREncodable localDEREncodable;
      Object localObject2;
      while ((localDEREncodable = localASN1SetParser.readObject()) != null)
      {
        localObject1 = AlgorithmIdentifier.getInstance(localDEREncodable.getDERObject());
        try
        {
          String str = HELPER.getDigestAlgName(((AlgorithmIdentifier)localObject1).getObjectId().toString());
          localObject2 = HELPER.getDigestInstance(str, null);
          this._digests.put(str, localObject2);
        }
        catch (NoSuchAlgorithmException localNoSuchAlgorithmException) {}
      }
      Object localObject1 = this._signedData.getEncapContentInfo();
      ASN1OctetStringParser localASN1OctetStringParser = (ASN1OctetStringParser)((ContentInfoParser)localObject1).getContent(4);
      if (localASN1OctetStringParser != null)
      {
        localObject2 = new CMSTypedStream(((ContentInfoParser)localObject1).getContentType().getId(), localASN1OctetStringParser.getOctetStream());
        if (this._signedContent == null) {
          this._signedContent = ((CMSTypedStream)localObject2);
        } else {
          ((CMSTypedStream)localObject2).drain();
        }
      }
      if (paramCMSTypedStream == null) {
        this._signedContentType = ((ContentInfoParser)localObject1).getContentType();
      } else {
        this._signedContentType = new DERObjectIdentifier(this._signedContent.getContentType());
      }
    }
    catch (IOException localIOException)
    {
      throw new CMSException("io exception: " + localIOException.getMessage(), localIOException);
    }
    if (this._digests.isEmpty()) {
      throw new CMSException("no digests could be created for message.");
    }
  }
  
  public int getVersion()
  {
    return this._signedData.getVersion().getValue().intValue();
  }
  
  public SignerInformationStore getSignerInfos()
    throws CMSException
  {
    if (this._signerInfoStore == null)
    {
      populateCertCrlSets();
      ArrayList localArrayList = new ArrayList();
      HashMap localHashMap = new HashMap();
      Iterator localIterator = this._digests.keySet().iterator();
      Object localObject;
      while (localIterator.hasNext())
      {
        localObject = localIterator.next();
        localHashMap.put(localObject, ((MessageDigest)this._digests.get(localObject)).digest());
      }
      try
      {
        localObject = this._signedData.getSignerInfos();
        DEREncodable localDEREncodable;
        while ((localDEREncodable = ((ASN1SetParser)localObject).readObject()) != null)
        {
          SignerInfo localSignerInfo = SignerInfo.getInstance(localDEREncodable.getDERObject());
          String str = HELPER.getDigestAlgName(localSignerInfo.getDigestAlgorithm().getObjectId().getId());
          byte[] arrayOfByte = (byte[])localHashMap.get(str);
          localArrayList.add(new SignerInformation(localSignerInfo, this._signedContentType, null, new BaseDigestCalculator(arrayOfByte)));
        }
      }
      catch (IOException localIOException)
      {
        throw new CMSException("io exception: " + localIOException.getMessage(), localIOException);
      }
      this._signerInfoStore = new SignerInformationStore(localArrayList);
    }
    return this._signerInfoStore;
  }
  
  public X509Store getAttributeCertificates(String paramString1, String paramString2)
    throws NoSuchStoreException, NoSuchProviderException, CMSException
  {
    return getAttributeCertificates(paramString1, CMSUtils.getProvider(paramString2));
  }
  
  public X509Store getAttributeCertificates(String paramString, Provider paramProvider)
    throws NoSuchStoreException, CMSException
  {
    if (this._attributeStore == null)
    {
      populateCertCrlSets();
      this._attributeStore = HELPER.createAttributeStore(paramString, paramProvider, this._certSet);
    }
    return this._attributeStore;
  }
  
  public X509Store getCertificates(String paramString1, String paramString2)
    throws NoSuchStoreException, NoSuchProviderException, CMSException
  {
    return getCertificates(paramString1, CMSUtils.getProvider(paramString2));
  }
  
  public X509Store getCertificates(String paramString, Provider paramProvider)
    throws NoSuchStoreException, CMSException
  {
    if (this._certificateStore == null)
    {
      populateCertCrlSets();
      this._certificateStore = HELPER.createCertificateStore(paramString, paramProvider, this._certSet);
    }
    return this._certificateStore;
  }
  
  public X509Store getCRLs(String paramString1, String paramString2)
    throws NoSuchStoreException, NoSuchProviderException, CMSException
  {
    return getCRLs(paramString1, CMSUtils.getProvider(paramString2));
  }
  
  public X509Store getCRLs(String paramString, Provider paramProvider)
    throws NoSuchStoreException, CMSException
  {
    if (this._crlStore == null)
    {
      populateCertCrlSets();
      this._crlStore = HELPER.createCRLsStore(paramString, paramProvider, this._crlSet);
    }
    return this._crlStore;
  }
  
  public CertStore getCertificatesAndCRLs(String paramString1, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    return getCertificatesAndCRLs(paramString1, CMSUtils.getProvider(paramString2));
  }
  
  public CertStore getCertificatesAndCRLs(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    if (this._certStore == null)
    {
      populateCertCrlSets();
      this._certStore = HELPER.createCertStore(paramString, paramProvider, this._certSet, this._crlSet);
    }
    return this._certStore;
  }
  
  private void populateCertCrlSets()
    throws CMSException
  {
    if (this._isCertCrlParsed) {
      return;
    }
    this._isCertCrlParsed = true;
    try
    {
      this._certSet = getASN1Set(this._signedData.getCertificates());
      this._crlSet = getASN1Set(this._signedData.getCrls());
    }
    catch (IOException localIOException)
    {
      throw new CMSException("problem parsing cert/crl sets", localIOException);
    }
  }
  
  public String getSignedContentTypeOID()
  {
    return this._signedContentType.getId();
  }
  
  public CMSTypedStream getSignedContent()
  {
    if (this._signedContent != null)
    {
      Object localObject = this._signedContent.getContentStream();
      Iterator localIterator = this._digests.values().iterator();
      while (localIterator.hasNext()) {
        localObject = new DigestInputStream((InputStream)localObject, (MessageDigest)localIterator.next());
      }
      return new CMSTypedStream(this._signedContent.getContentType(), (InputStream)localObject);
    }
    return null;
  }
  
  public static OutputStream replaceSigners(InputStream paramInputStream, SignerInformationStore paramSignerInformationStore, OutputStream paramOutputStream)
    throws CMSException, IOException
  {
    ASN1StreamParser localASN1StreamParser = new ASN1StreamParser(paramInputStream, CMSUtils.getMaximumMemory());
    ContentInfoParser localContentInfoParser = new ContentInfoParser((ASN1SequenceParser)localASN1StreamParser.readObject());
    SignedDataParser localSignedDataParser = SignedDataParser.getInstance(localContentInfoParser.getContent(16));
    BERSequenceGenerator localBERSequenceGenerator1 = new BERSequenceGenerator(paramOutputStream);
    localBERSequenceGenerator1.addObject(CMSObjectIdentifiers.signedData);
    BERSequenceGenerator localBERSequenceGenerator2 = new BERSequenceGenerator(localBERSequenceGenerator1.getRawOutputStream(), 0, true);
    localBERSequenceGenerator2.addObject(localSignedDataParser.getVersion());
    localSignedDataParser.getDigestAlgorithms().getDERObject();
    ASN1EncodableVector localASN1EncodableVector1 = new ASN1EncodableVector();
    Object localObject1 = paramSignerInformationStore.getSigners().iterator();
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (SignerInformation)((Iterator)localObject1).next();
      localASN1EncodableVector1.add(CMSSignedHelper.INSTANCE.fixAlgID(((SignerInformation)localObject2).getDigestAlgorithmID()));
    }
    localBERSequenceGenerator2.getRawOutputStream().write(new DERSet(localASN1EncodableVector1).getEncoded());
    localObject1 = localSignedDataParser.getEncapContentInfo();
    Object localObject2 = new BERSequenceGenerator(localBERSequenceGenerator2.getRawOutputStream());
    ((BERSequenceGenerator)localObject2).addObject(((ContentInfoParser)localObject1).getContentType());
    ASN1OctetStringParser localASN1OctetStringParser = (ASN1OctetStringParser)((ContentInfoParser)localObject1).getContent(4);
    if (localASN1OctetStringParser != null) {
      pipeOctetString(localASN1OctetStringParser, ((BERSequenceGenerator)localObject2).getRawOutputStream());
    }
    ((BERSequenceGenerator)localObject2).close();
    writeSetToGeneratorTagged(localBERSequenceGenerator2, localSignedDataParser.getCertificates(), 0);
    writeSetToGeneratorTagged(localBERSequenceGenerator2, localSignedDataParser.getCrls(), 1);
    ASN1EncodableVector localASN1EncodableVector2 = new ASN1EncodableVector();
    Iterator localIterator = paramSignerInformationStore.getSigners().iterator();
    while (localIterator.hasNext())
    {
      SignerInformation localSignerInformation = (SignerInformation)localIterator.next();
      localASN1EncodableVector2.add(localSignerInformation.toSignerInfo());
    }
    localBERSequenceGenerator2.getRawOutputStream().write(new DERSet(localASN1EncodableVector2).getEncoded());
    localBERSequenceGenerator2.close();
    localBERSequenceGenerator1.close();
    return paramOutputStream;
  }
  
  public static OutputStream replaceCertificatesAndCRLs(InputStream paramInputStream, CertStore paramCertStore, OutputStream paramOutputStream)
    throws CMSException, IOException
  {
    ASN1StreamParser localASN1StreamParser = new ASN1StreamParser(paramInputStream, CMSUtils.getMaximumMemory());
    ContentInfoParser localContentInfoParser1 = new ContentInfoParser((ASN1SequenceParser)localASN1StreamParser.readObject());
    SignedDataParser localSignedDataParser = SignedDataParser.getInstance(localContentInfoParser1.getContent(16));
    BERSequenceGenerator localBERSequenceGenerator1 = new BERSequenceGenerator(paramOutputStream);
    localBERSequenceGenerator1.addObject(CMSObjectIdentifiers.signedData);
    BERSequenceGenerator localBERSequenceGenerator2 = new BERSequenceGenerator(localBERSequenceGenerator1.getRawOutputStream(), 0, true);
    localBERSequenceGenerator2.addObject(localSignedDataParser.getVersion());
    localBERSequenceGenerator2.getRawOutputStream().write(localSignedDataParser.getDigestAlgorithms().getDERObject().getEncoded());
    ContentInfoParser localContentInfoParser2 = localSignedDataParser.getEncapContentInfo();
    BERSequenceGenerator localBERSequenceGenerator3 = new BERSequenceGenerator(localBERSequenceGenerator2.getRawOutputStream());
    localBERSequenceGenerator3.addObject(localContentInfoParser2.getContentType());
    ASN1OctetStringParser localASN1OctetStringParser = (ASN1OctetStringParser)localContentInfoParser2.getContent(4);
    if (localASN1OctetStringParser != null) {
      pipeOctetString(localASN1OctetStringParser, localBERSequenceGenerator3.getRawOutputStream());
    }
    localBERSequenceGenerator3.close();
    getASN1Set(localSignedDataParser.getCertificates());
    getASN1Set(localSignedDataParser.getCrls());
    ASN1Set localASN1Set1;
    try
    {
      localASN1Set1 = CMSUtils.createBerSetFromList(CMSUtils.getCertificatesFromStore(paramCertStore));
    }
    catch (CertStoreException localCertStoreException1)
    {
      throw new CMSException("error getting certs from certStore", localCertStoreException1);
    }
    if (localASN1Set1.size() > 0) {
      localBERSequenceGenerator2.getRawOutputStream().write(new DERTaggedObject(false, 0, localASN1Set1).getEncoded());
    }
    ASN1Set localASN1Set2;
    try
    {
      localASN1Set2 = CMSUtils.createBerSetFromList(CMSUtils.getCRLsFromStore(paramCertStore));
    }
    catch (CertStoreException localCertStoreException2)
    {
      throw new CMSException("error getting crls from certStore", localCertStoreException2);
    }
    if (localASN1Set2.size() > 0) {
      localBERSequenceGenerator2.getRawOutputStream().write(new DERTaggedObject(false, 1, localASN1Set2).getEncoded());
    }
    localBERSequenceGenerator2.getRawOutputStream().write(localSignedDataParser.getSignerInfos().getDERObject().getEncoded());
    localBERSequenceGenerator2.close();
    localBERSequenceGenerator1.close();
    return paramOutputStream;
  }
  
  private static void writeSetToGeneratorTagged(ASN1Generator paramASN1Generator, ASN1SetParser paramASN1SetParser, int paramInt)
    throws IOException
  {
    ASN1Set localASN1Set = getASN1Set(paramASN1SetParser);
    if (localASN1Set != null)
    {
      DERTaggedObject localDERTaggedObject = (paramASN1SetParser instanceof BERSetParser) ? new BERTaggedObject(false, paramInt, localASN1Set) : new DERTaggedObject(false, paramInt, localASN1Set);
      paramASN1Generator.getRawOutputStream().write(localDERTaggedObject.getEncoded());
    }
  }
  
  private static ASN1Set getASN1Set(ASN1SetParser paramASN1SetParser)
  {
    return paramASN1SetParser == null ? null : ASN1Set.getInstance(paramASN1SetParser.getDERObject());
  }
  
  private static void pipeOctetString(ASN1OctetStringParser paramASN1OctetStringParser, OutputStream paramOutputStream)
    throws IOException
  {
    OutputStream localOutputStream = CMSUtils.createBEROctetOutputStream(paramOutputStream, 0, true, 0);
    Streams.pipeAll(paramASN1OctetStringParser.getOctetStream(), localOutputStream);
    localOutputStream.close();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSSignedDataParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */