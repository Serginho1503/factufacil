package org.bouncycastle.cms;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.Provider;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.cms.IssuerAndSerialNumber;
import org.bouncycastle.asn1.cms.KeyTransRecipientInfo;
import org.bouncycastle.asn1.cms.RecipientIdentifier;
import org.bouncycastle.asn1.cms.RecipientInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.asn1.x509.TBSCertificateStructure;

class KeyTransRecipientInfoGenerator
  implements RecipientInfoGenerator
{
  private TBSCertificateStructure recipientTBSCert;
  private PublicKey recipientPublicKey;
  private ASN1OctetString subjectKeyIdentifier;
  private SubjectPublicKeyInfo info;
  
  void setRecipientCert(X509Certificate paramX509Certificate)
  {
    try
    {
      this.recipientTBSCert = CMSUtils.getTBSCertificateStructure(paramX509Certificate);
    }
    catch (CertificateEncodingException localCertificateEncodingException)
    {
      throw new IllegalArgumentException("can't extract TBS structure from this cert");
    }
    this.recipientPublicKey = paramX509Certificate.getPublicKey();
    this.info = this.recipientTBSCert.getSubjectPublicKeyInfo();
  }
  
  void setRecipientPublicKey(PublicKey paramPublicKey)
  {
    this.recipientPublicKey = paramPublicKey;
    try
    {
      this.info = SubjectPublicKeyInfo.getInstance(ASN1Object.fromByteArray(paramPublicKey.getEncoded()));
    }
    catch (IOException localIOException)
    {
      throw new IllegalArgumentException("can't extract key algorithm from this key");
    }
  }
  
  void setSubjectKeyIdentifier(ASN1OctetString paramASN1OctetString)
  {
    this.subjectKeyIdentifier = paramASN1OctetString;
  }
  
  public RecipientInfo generate(SecretKey paramSecretKey, SecureRandom paramSecureRandom, Provider paramProvider)
    throws GeneralSecurityException
  {
    AlgorithmIdentifier localAlgorithmIdentifier = this.info.getAlgorithmId();
    Cipher localCipher = CMSEnvelopedHelper.INSTANCE.createAsymmetricCipher(localAlgorithmIdentifier.getObjectId().getId(), paramProvider);
    DEROctetString localDEROctetString;
    try
    {
      localCipher.init(3, this.recipientPublicKey, paramSecureRandom);
      localDEROctetString = new DEROctetString(localCipher.wrap(paramSecretKey));
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
      localCipher.init(1, this.recipientPublicKey, paramSecureRandom);
      localDEROctetString = new DEROctetString(localCipher.doFinal(paramSecretKey.getEncoded()));
    }
    catch (IllegalStateException localIllegalStateException)
    {
      localCipher.init(1, this.recipientPublicKey, paramSecureRandom);
      localDEROctetString = new DEROctetString(localCipher.doFinal(paramSecretKey.getEncoded()));
    }
    catch (UnsupportedOperationException localUnsupportedOperationException)
    {
      localCipher.init(1, this.recipientPublicKey, paramSecureRandom);
      localDEROctetString = new DEROctetString(localCipher.doFinal(paramSecretKey.getEncoded()));
    }
    RecipientIdentifier localRecipientIdentifier;
    if (this.recipientTBSCert != null)
    {
      IssuerAndSerialNumber localIssuerAndSerialNumber = new IssuerAndSerialNumber(this.recipientTBSCert.getIssuer(), this.recipientTBSCert.getSerialNumber().getValue());
      localRecipientIdentifier = new RecipientIdentifier(localIssuerAndSerialNumber);
    }
    else
    {
      localRecipientIdentifier = new RecipientIdentifier(this.subjectKeyIdentifier);
    }
    return new RecipientInfo(new KeyTransRecipientInfo(localRecipientIdentifier, localAlgorithmIdentifier, localDEROctetString));
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\KeyTransRecipientInfoGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */