package org.bouncycastle.cms;

import java.security.AlgorithmParameters;
import java.security.InvalidAlgorithmParameterException;
import org.bouncycastle.crypto.PBEParametersGenerator;
import org.bouncycastle.crypto.generators.PKCS5S2ParametersGenerator;
import org.bouncycastle.crypto.params.KeyParameter;

public class PKCS5Scheme2UTF8PBEKey
  extends CMSPBEKey
{
  public PKCS5Scheme2UTF8PBEKey(char[] paramArrayOfChar, byte[] paramArrayOfByte, int paramInt)
  {
    super(paramArrayOfChar, paramArrayOfByte, paramInt);
  }
  
  public PKCS5Scheme2UTF8PBEKey(char[] paramArrayOfChar, AlgorithmParameters paramAlgorithmParameters)
    throws InvalidAlgorithmParameterException
  {
    super(paramArrayOfChar, getParamSpec(paramAlgorithmParameters));
  }
  
  byte[] getEncoded(String paramString)
  {
    PKCS5S2ParametersGenerator localPKCS5S2ParametersGenerator = new PKCS5S2ParametersGenerator();
    localPKCS5S2ParametersGenerator.init(PBEParametersGenerator.PKCS5PasswordToUTF8Bytes(getPassword()), getSalt(), getIterationCount());
    return ((KeyParameter)localPKCS5S2ParametersGenerator.generateDerivedParameters(CMSEnvelopedHelper.INSTANCE.getKeySize(paramString))).getKey();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\PKCS5Scheme2UTF8PBEKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */