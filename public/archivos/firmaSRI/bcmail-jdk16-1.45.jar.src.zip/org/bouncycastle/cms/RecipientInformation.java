package org.bouncycastle.cms;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.AlgorithmParameters;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.spec.InvalidParameterSpecException;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import org.bouncycastle.asn1.ASN1Null;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public abstract class RecipientInformation
{
  protected RecipientId rid = new RecipientId();
  protected AlgorithmIdentifier encAlg;
  protected AlgorithmIdentifier macAlg;
  protected AlgorithmIdentifier authEncAlg;
  protected AlgorithmIdentifier keyEncAlg;
  protected InputStream data;
  private MacInputStream macStream;
  private byte[] resultMac;
  
  /**
   * @deprecated
   */
  protected RecipientInformation(AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, InputStream paramInputStream)
  {
    this(paramAlgorithmIdentifier1, null, paramAlgorithmIdentifier2, paramInputStream);
  }
  
  /**
   * @deprecated
   */
  protected RecipientInformation(AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, AlgorithmIdentifier paramAlgorithmIdentifier3, InputStream paramInputStream)
  {
    this(paramAlgorithmIdentifier1, paramAlgorithmIdentifier2, null, paramAlgorithmIdentifier3, paramInputStream);
  }
  
  RecipientInformation(AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, AlgorithmIdentifier paramAlgorithmIdentifier3, AlgorithmIdentifier paramAlgorithmIdentifier4, InputStream paramInputStream)
  {
    this.encAlg = paramAlgorithmIdentifier1;
    this.macAlg = paramAlgorithmIdentifier2;
    this.authEncAlg = paramAlgorithmIdentifier3;
    this.keyEncAlg = paramAlgorithmIdentifier4;
    this.data = paramInputStream;
  }
  
  AlgorithmIdentifier getActiveAlgID()
  {
    if (this.encAlg != null) {
      return this.encAlg;
    }
    if (this.macAlg != null) {
      return this.macAlg;
    }
    return this.authEncAlg;
  }
  
  public RecipientId getRID()
  {
    return this.rid;
  }
  
  private byte[] encodeObj(DEREncodable paramDEREncodable)
    throws IOException
  {
    if (paramDEREncodable != null) {
      return paramDEREncodable.getDERObject().getEncoded();
    }
    return null;
  }
  
  public String getKeyEncryptionAlgOID()
  {
    return this.keyEncAlg.getObjectId().getId();
  }
  
  public byte[] getKeyEncryptionAlgParams()
  {
    try
    {
      return encodeObj(this.keyEncAlg.getParameters());
    }
    catch (Exception localException)
    {
      throw new RuntimeException("exception getting encryption parameters " + localException);
    }
  }
  
  public AlgorithmParameters getKeyEncryptionAlgorithmParameters(String paramString)
    throws CMSException, NoSuchProviderException
  {
    return getKeyEncryptionAlgorithmParameters(CMSUtils.getProvider(paramString));
  }
  
  public AlgorithmParameters getKeyEncryptionAlgorithmParameters(Provider paramProvider)
    throws CMSException
  {
    try
    {
      byte[] arrayOfByte = encodeObj(this.keyEncAlg.getParameters());
      if (arrayOfByte == null) {
        return null;
      }
      AlgorithmParameters localAlgorithmParameters = CMSEnvelopedHelper.INSTANCE.createAlgorithmParameters(getKeyEncryptionAlgOID(), paramProvider);
      localAlgorithmParameters.init(arrayOfByte, "ASN.1");
      return localAlgorithmParameters;
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new CMSException("can't find parameters for algorithm", localNoSuchAlgorithmException);
    }
    catch (IOException localIOException)
    {
      throw new CMSException("can't find parse parameters", localIOException);
    }
  }
  
  protected CMSTypedStream getContentFromSessionKey(Key paramKey, Provider paramProvider)
    throws CMSException
  {
    try
    {
      Object localObject = this.data;
      if (this.encAlg != null)
      {
        String str = this.encAlg.getObjectId().getId();
        Cipher localCipher = CMSEnvelopedHelper.INSTANCE.getSymmetricCipher(str, paramProvider);
        ASN1Object localASN1Object = (ASN1Object)this.encAlg.getParameters();
        if ((localASN1Object != null) && (!(localASN1Object instanceof ASN1Null))) {
          try
          {
            AlgorithmParameters localAlgorithmParameters = CMSEnvelopedHelper.INSTANCE.createAlgorithmParameters(str, localCipher.getProvider());
            localAlgorithmParameters.init(localASN1Object.getEncoded(), "ASN.1");
            localCipher.init(2, paramKey, localAlgorithmParameters);
          }
          catch (NoSuchAlgorithmException localNoSuchAlgorithmException2)
          {
            if ((str.equals(CMSEnvelopedDataGenerator.DES_EDE3_CBC)) || (str.equals("1.3.6.1.4.1.188.7.1.1.2")) || (str.equals(CMSEnvelopedDataGenerator.AES128_CBC)) || (str.equals(CMSEnvelopedDataGenerator.AES192_CBC)) || (str.equals(CMSEnvelopedDataGenerator.AES256_CBC))) {
              localCipher.init(2, paramKey, new IvParameterSpec(ASN1OctetString.getInstance(localASN1Object).getOctets()));
            } else {
              throw localNoSuchAlgorithmException2;
            }
          }
        } else if ((str.equals(CMSEnvelopedDataGenerator.DES_EDE3_CBC)) || (str.equals("1.3.6.1.4.1.188.7.1.1.2")) || (str.equals("1.2.840.113533.7.66.10"))) {
          localCipher.init(2, paramKey, new IvParameterSpec(new byte[8]));
        } else {
          localCipher.init(2, paramKey);
        }
        localObject = new CipherInputStream((InputStream)localObject, localCipher);
      }
      if (this.macAlg != null) {
        localObject = this.macStream = createMacInputStream(this.macAlg, paramKey, (InputStream)localObject, paramProvider);
      }
      if (this.authEncAlg != null) {
        throw new CMSException("AuthEnveloped data decryption not yet implemented");
      }
      return new CMSTypedStream((InputStream)localObject);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException1)
    {
      throw new CMSException("can't find algorithm.", localNoSuchAlgorithmException1);
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new CMSException("key invalid in message.", localInvalidKeyException);
    }
    catch (NoSuchPaddingException localNoSuchPaddingException)
    {
      throw new CMSException("required padding not supported.", localNoSuchPaddingException);
    }
    catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
    {
      throw new CMSException("algorithm parameters invalid.", localInvalidAlgorithmParameterException);
    }
    catch (InvalidParameterSpecException localInvalidParameterSpecException)
    {
      throw new CMSException("MAC algorithm parameter spec invalid.", localInvalidParameterSpecException);
    }
    catch (IOException localIOException)
    {
      throw new CMSException("error decoding algorithm parameters.", localIOException);
    }
  }
  
  private static MacInputStream createMacInputStream(AlgorithmIdentifier paramAlgorithmIdentifier, Key paramKey, InputStream paramInputStream, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IOException, InvalidParameterSpecException
  {
    Mac localMac = CMSEnvelopedHelper.INSTANCE.getMac(paramAlgorithmIdentifier.getObjectId().getId(), paramProvider);
    ASN1Object localASN1Object = (ASN1Object)paramAlgorithmIdentifier.getParameters();
    if ((localASN1Object != null) && (!(localASN1Object instanceof ASN1Null)))
    {
      AlgorithmParameters localAlgorithmParameters = CMSEnvelopedHelper.INSTANCE.createAlgorithmParameters(paramAlgorithmIdentifier.getObjectId().getId(), paramProvider);
      localAlgorithmParameters.init(localASN1Object.getEncoded(), "ASN.1");
      localMac.init(paramKey, localAlgorithmParameters.getParameterSpec(IvParameterSpec.class));
    }
    else
    {
      localMac.init(paramKey);
    }
    return new MacInputStream(localMac, paramInputStream);
  }
  
  public byte[] getContent(Key paramKey, String paramString)
    throws CMSException, NoSuchProviderException
  {
    return getContent(paramKey, CMSUtils.getProvider(paramString));
  }
  
  public byte[] getContent(Key paramKey, Provider paramProvider)
    throws CMSException
  {
    try
    {
      if ((this.data instanceof ByteArrayInputStream)) {
        this.data.reset();
      }
      return CMSUtils.streamToByteArray(getContentStream(paramKey, paramProvider).getContentStream());
    }
    catch (IOException localIOException)
    {
      throw new RuntimeException("unable to parse internal stream: " + localIOException);
    }
  }
  
  public byte[] getMac()
  {
    if ((this.macStream != null) && (this.resultMac == null)) {
      this.resultMac = this.macStream.getMac();
    }
    return this.resultMac;
  }
  
  public CMSTypedStream getContentStream(Key paramKey, String paramString)
    throws CMSException, NoSuchProviderException
  {
    return getContentStream(paramKey, CMSUtils.getProvider(paramString));
  }
  
  public abstract CMSTypedStream getContentStream(Key paramKey, Provider paramProvider)
    throws CMSException;
  
  private static class MacInputStream
    extends InputStream
  {
    private final InputStream inStream;
    private final Mac mac;
    
    MacInputStream(Mac paramMac, InputStream paramInputStream)
    {
      this.inStream = paramInputStream;
      this.mac = paramMac;
    }
    
    public int read(byte[] paramArrayOfByte)
      throws IOException
    {
      return read(paramArrayOfByte, 0, paramArrayOfByte.length);
    }
    
    public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {
      int i = this.inStream.read(paramArrayOfByte, paramInt1, paramInt2);
      if (i > 0) {
        this.mac.update(paramArrayOfByte, paramInt1, i);
      }
      return i;
    }
    
    public int read()
      throws IOException
    {
      int i = this.inStream.read();
      if (i > 0) {
        this.mac.update((byte)i);
      }
      return i;
    }
    
    public byte[] getMac()
    {
      return this.mac.doFinal();
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\RecipientInformation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */