package org.bouncycastle.cms;

import org.bouncycastle.util.Arrays;

class BaseDigestCalculator
  implements DigestCalculator
{
  private final byte[] digest;
  
  BaseDigestCalculator(byte[] paramArrayOfByte)
  {
    this.digest = paramArrayOfByte;
  }
  
  public byte[] getDigest()
  {
    return Arrays.clone(this.digest);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\BaseDigestCalculator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */