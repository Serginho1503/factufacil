package org.bouncycastle.cms;

import java.io.IOException;
import java.io.InputStream;
import java.security.AlgorithmParameters;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.util.List;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.ContentInfo;
import org.bouncycastle.asn1.cms.EncryptedContentInfo;
import org.bouncycastle.asn1.cms.EnvelopedData;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class CMSEnvelopedData
{
  RecipientInformationStore recipientInfoStore;
  ContentInfo contentInfo;
  private AlgorithmIdentifier encAlg;
  private ASN1Set unprotectedAttributes;
  
  public CMSEnvelopedData(byte[] paramArrayOfByte)
    throws CMSException
  {
    this(CMSUtils.readContentInfo(paramArrayOfByte));
  }
  
  public CMSEnvelopedData(InputStream paramInputStream)
    throws CMSException
  {
    this(CMSUtils.readContentInfo(paramInputStream));
  }
  
  public CMSEnvelopedData(ContentInfo paramContentInfo)
    throws CMSException
  {
    this.contentInfo = paramContentInfo;
    EnvelopedData localEnvelopedData = EnvelopedData.getInstance(paramContentInfo.getContent());
    EncryptedContentInfo localEncryptedContentInfo = localEnvelopedData.getEncryptedContentInfo();
    this.encAlg = localEncryptedContentInfo.getContentEncryptionAlgorithm();
    byte[] arrayOfByte = localEncryptedContentInfo.getEncryptedContent().getOctets();
    List localList = CMSEnvelopedHelper.readRecipientInfos(localEnvelopedData.getRecipientInfos(), arrayOfByte, this.encAlg, null, null);
    this.recipientInfoStore = new RecipientInformationStore(localList);
    this.unprotectedAttributes = localEnvelopedData.getUnprotectedAttrs();
  }
  
  private byte[] encodeObj(DEREncodable paramDEREncodable)
    throws IOException
  {
    if (paramDEREncodable != null) {
      return paramDEREncodable.getDERObject().getEncoded();
    }
    return null;
  }
  
  public String getEncryptionAlgOID()
  {
    return this.encAlg.getObjectId().getId();
  }
  
  public byte[] getEncryptionAlgParams()
  {
    try
    {
      return encodeObj(this.encAlg.getParameters());
    }
    catch (Exception localException)
    {
      throw new RuntimeException("exception getting encryption parameters " + localException);
    }
  }
  
  public AlgorithmParameters getEncryptionAlgorithmParameters(String paramString)
    throws CMSException, NoSuchProviderException
  {
    return getEncryptionAlgorithmParameters(CMSUtils.getProvider(paramString));
  }
  
  public AlgorithmParameters getEncryptionAlgorithmParameters(Provider paramProvider)
    throws CMSException
  {
    return CMSEnvelopedHelper.INSTANCE.getEncryptionAlgorithmParameters(getEncryptionAlgOID(), getEncryptionAlgParams(), paramProvider);
  }
  
  public RecipientInformationStore getRecipientInfos()
  {
    return this.recipientInfoStore;
  }
  
  public ContentInfo getContentInfo()
  {
    return this.contentInfo;
  }
  
  public AttributeTable getUnprotectedAttributes()
  {
    if (this.unprotectedAttributes == null) {
      return null;
    }
    return new AttributeTable(this.unprotectedAttributes);
  }
  
  public byte[] getEncoded()
    throws IOException
  {
    return this.contentInfo.getEncoded();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSEnvelopedData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */