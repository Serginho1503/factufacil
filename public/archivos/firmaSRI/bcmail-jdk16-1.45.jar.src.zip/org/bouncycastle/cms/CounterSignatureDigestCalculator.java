package org.bouncycastle.cms;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;

class CounterSignatureDigestCalculator
  implements DigestCalculator
{
  private final String alg;
  private final Provider provider;
  private final byte[] data;
  
  CounterSignatureDigestCalculator(String paramString, Provider paramProvider, byte[] paramArrayOfByte)
  {
    this.alg = paramString;
    this.provider = paramProvider;
    this.data = paramArrayOfByte;
  }
  
  public byte[] getDigest()
    throws NoSuchAlgorithmException
  {
    MessageDigest localMessageDigest = CMSSignedHelper.INSTANCE.getDigestInstance(this.alg, this.provider);
    return localMessageDigest.digest(this.data);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CounterSignatureDigestCalculator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */