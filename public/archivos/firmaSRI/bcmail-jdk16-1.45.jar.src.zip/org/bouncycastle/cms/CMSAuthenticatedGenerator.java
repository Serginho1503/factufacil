package org.bouncycastle.cms;

import java.io.IOException;
import java.io.OutputStream;
import java.security.AlgorithmParameterGenerator;
import java.security.AlgorithmParameters;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.InvalidParameterSpecException;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.RC2ParameterSpec;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class CMSAuthenticatedGenerator
  extends CMSEnvelopedGenerator
{
  public CMSAuthenticatedGenerator() {}
  
  public CMSAuthenticatedGenerator(SecureRandom paramSecureRandom)
  {
    super(paramSecureRandom);
  }
  
  protected AlgorithmIdentifier getAlgorithmIdentifier(String paramString, AlgorithmParameterSpec paramAlgorithmParameterSpec, Provider paramProvider)
    throws IOException, NoSuchAlgorithmException, InvalidParameterSpecException
  {
    AlgorithmParameters localAlgorithmParameters = CMSEnvelopedHelper.INSTANCE.createAlgorithmParameters(paramString, paramProvider);
    localAlgorithmParameters.init(paramAlgorithmParameterSpec);
    return getAlgorithmIdentifier(paramString, localAlgorithmParameters);
  }
  
  protected AlgorithmParameterSpec generateParameterSpec(String paramString, SecretKey paramSecretKey, Provider paramProvider)
    throws CMSException
  {
    try
    {
      if (paramString.equals(RC2_CBC))
      {
        localObject = new byte[8];
        this.rand.nextBytes((byte[])localObject);
        return new RC2ParameterSpec(paramSecretKey.getEncoded().length * 8, (byte[])localObject);
      }
      Object localObject = CMSEnvelopedHelper.INSTANCE.createAlgorithmParameterGenerator(paramString, paramProvider);
      AlgorithmParameters localAlgorithmParameters = ((AlgorithmParameterGenerator)localObject).generateParameters();
      return localAlgorithmParameters.getParameterSpec(IvParameterSpec.class);
    }
    catch (GeneralSecurityException localGeneralSecurityException) {}
    return null;
  }
  
  protected static class MacOutputStream
    extends OutputStream
  {
    private final OutputStream out;
    private Mac mac;
    
    MacOutputStream(OutputStream paramOutputStream, Mac paramMac)
    {
      this.out = paramOutputStream;
      this.mac = paramMac;
    }
    
    public void write(byte[] paramArrayOfByte)
      throws IOException
    {
      this.mac.update(paramArrayOfByte, 0, paramArrayOfByte.length);
      this.out.write(paramArrayOfByte, 0, paramArrayOfByte.length);
    }
    
    public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {
      this.mac.update(paramArrayOfByte, paramInt1, paramInt2);
      this.out.write(paramArrayOfByte, paramInt1, paramInt2);
    }
    
    public void write(int paramInt)
      throws IOException
    {
      this.mac.update((byte)paramInt);
      this.out.write(paramInt);
    }
    
    public void close()
      throws IOException
    {
      this.out.close();
    }
    
    public byte[] getMac()
    {
      return this.mac.doFinal();
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSAuthenticatedGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */