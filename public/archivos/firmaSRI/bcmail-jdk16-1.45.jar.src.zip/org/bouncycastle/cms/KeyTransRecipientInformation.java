package org.bouncycastle.cms;

import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.ProviderException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cms.IssuerAndSerialNumber;
import org.bouncycastle.asn1.cms.KeyTransRecipientInfo;
import org.bouncycastle.asn1.cms.RecipientIdentifier;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.X509Name;

public class KeyTransRecipientInformation
  extends RecipientInformation
{
  private KeyTransRecipientInfo info;
  
  /**
   * @deprecated
   */
  public KeyTransRecipientInformation(KeyTransRecipientInfo paramKeyTransRecipientInfo, AlgorithmIdentifier paramAlgorithmIdentifier, InputStream paramInputStream)
  {
    this(paramKeyTransRecipientInfo, paramAlgorithmIdentifier, null, null, paramInputStream);
  }
  
  /**
   * @deprecated
   */
  public KeyTransRecipientInformation(KeyTransRecipientInfo paramKeyTransRecipientInfo, AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, InputStream paramInputStream)
  {
    this(paramKeyTransRecipientInfo, paramAlgorithmIdentifier1, paramAlgorithmIdentifier2, null, paramInputStream);
  }
  
  KeyTransRecipientInformation(KeyTransRecipientInfo paramKeyTransRecipientInfo, AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, AlgorithmIdentifier paramAlgorithmIdentifier3, InputStream paramInputStream)
  {
    super(paramAlgorithmIdentifier1, paramAlgorithmIdentifier2, paramAlgorithmIdentifier3, paramKeyTransRecipientInfo.getKeyEncryptionAlgorithm(), paramInputStream);
    this.info = paramKeyTransRecipientInfo;
    this.rid = new RecipientId();
    RecipientIdentifier localRecipientIdentifier = paramKeyTransRecipientInfo.getRecipientIdentifier();
    try
    {
      Object localObject;
      if (localRecipientIdentifier.isTagged())
      {
        localObject = ASN1OctetString.getInstance(localRecipientIdentifier.getId());
        this.rid.setSubjectKeyIdentifier(((ASN1OctetString)localObject).getOctets());
      }
      else
      {
        localObject = IssuerAndSerialNumber.getInstance(localRecipientIdentifier.getId());
        this.rid.setIssuer(((IssuerAndSerialNumber)localObject).getName().getEncoded());
        this.rid.setSerialNumber(((IssuerAndSerialNumber)localObject).getSerialNumber().getValue());
      }
    }
    catch (IOException localIOException)
    {
      throw new IllegalArgumentException("invalid rid in KeyTransRecipientInformation");
    }
  }
  
  private String getExchangeEncryptionAlgorithmName(DERObjectIdentifier paramDERObjectIdentifier)
  {
    if (PKCSObjectIdentifiers.rsaEncryption.equals(paramDERObjectIdentifier)) {
      return "RSA/ECB/PKCS1Padding";
    }
    return paramDERObjectIdentifier.getId();
  }
  
  protected Key getSessionKey(Key paramKey, Provider paramProvider)
    throws CMSException
  {
    byte[] arrayOfByte = this.info.getEncryptedKey().getOctets();
    String str1 = getExchangeEncryptionAlgorithmName(this.keyEncAlg.getObjectId());
    AlgorithmIdentifier localAlgorithmIdentifier = getActiveAlgID();
    String str2 = CMSEnvelopedHelper.INSTANCE.getSymmetricCipherName(localAlgorithmIdentifier.getObjectId().getId());
    try
    {
      Cipher localCipher = CMSEnvelopedHelper.INSTANCE.getSymmetricCipher(str1, paramProvider);
      Object localObject;
      try
      {
        localCipher.init(4, paramKey);
        localObject = localCipher.unwrap(arrayOfByte, str2, 3);
      }
      catch (GeneralSecurityException localGeneralSecurityException)
      {
        localCipher.init(2, paramKey);
        localObject = new SecretKeySpec(localCipher.doFinal(arrayOfByte), str2);
      }
      catch (IllegalStateException localIllegalStateException)
      {
        localCipher.init(2, paramKey);
        localObject = new SecretKeySpec(localCipher.doFinal(arrayOfByte), str2);
      }
      catch (UnsupportedOperationException localUnsupportedOperationException)
      {
        localCipher.init(2, paramKey);
        localObject = new SecretKeySpec(localCipher.doFinal(arrayOfByte), str2);
      }
      catch (ProviderException localProviderException)
      {
        localCipher.init(2, paramKey);
        localObject = new SecretKeySpec(localCipher.doFinal(arrayOfByte), str2);
      }
      return (Key)localObject;
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new CMSException("can't find algorithm.", localNoSuchAlgorithmException);
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new CMSException("key invalid in message.", localInvalidKeyException);
    }
    catch (NoSuchPaddingException localNoSuchPaddingException)
    {
      throw new CMSException("required padding not supported.", localNoSuchPaddingException);
    }
    catch (IllegalBlockSizeException localIllegalBlockSizeException)
    {
      throw new CMSException("illegal blocksize in message.", localIllegalBlockSizeException);
    }
    catch (BadPaddingException localBadPaddingException)
    {
      throw new CMSException("bad padding in message.", localBadPaddingException);
    }
  }
  
  public CMSTypedStream getContentStream(Key paramKey, String paramString)
    throws CMSException, NoSuchProviderException
  {
    return getContentStream(paramKey, CMSUtils.getProvider(paramString));
  }
  
  public CMSTypedStream getContentStream(Key paramKey, Provider paramProvider)
    throws CMSException
  {
    Key localKey = getSessionKey(paramKey, paramProvider);
    return getContentFromSessionKey(localKey, paramProvider);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\KeyTransRecipientInformation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */