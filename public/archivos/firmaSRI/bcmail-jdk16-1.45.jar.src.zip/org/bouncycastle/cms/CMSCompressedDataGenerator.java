package org.bouncycastle.cms;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.DeflaterOutputStream;
import org.bouncycastle.asn1.BERConstructedOctetString;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cms.CMSObjectIdentifiers;
import org.bouncycastle.asn1.cms.CompressedData;
import org.bouncycastle.asn1.cms.ContentInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class CMSCompressedDataGenerator
{
  public static final String ZLIB = "1.2.840.113549.1.9.16.3.8";
  
  public CMSCompressedData generate(CMSProcessable paramCMSProcessable, String paramString)
    throws CMSException
  {
    AlgorithmIdentifier localAlgorithmIdentifier;
    BERConstructedOctetString localBERConstructedOctetString;
    try
    {
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      localObject = new DeflaterOutputStream(localByteArrayOutputStream);
      paramCMSProcessable.write((OutputStream)localObject);
      ((DeflaterOutputStream)localObject).close();
      localAlgorithmIdentifier = new AlgorithmIdentifier(new DERObjectIdentifier(paramString));
      localBERConstructedOctetString = new BERConstructedOctetString(localByteArrayOutputStream.toByteArray());
    }
    catch (IOException localIOException)
    {
      throw new CMSException("exception encoding data.", localIOException);
    }
    ContentInfo localContentInfo = new ContentInfo(CMSObjectIdentifiers.data, localBERConstructedOctetString);
    Object localObject = new ContentInfo(CMSObjectIdentifiers.compressedData, new CompressedData(localAlgorithmIdentifier, localContentInfo));
    return new CMSCompressedData((ContentInfo)localObject);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSCompressedDataGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */