package org.bouncycastle.cms;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class RecipientInformationStore
{
  private final List all;
  private final Map table = new HashMap();
  
  public RecipientInformationStore(Collection paramCollection)
  {
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      RecipientInformation localRecipientInformation = (RecipientInformation)localIterator.next();
      RecipientId localRecipientId = localRecipientInformation.getRID();
      ArrayList localArrayList = (ArrayList)this.table.get(localRecipientId);
      if (localArrayList == null)
      {
        localArrayList = new ArrayList(1);
        this.table.put(localRecipientId, localArrayList);
      }
      localArrayList.add(localRecipientInformation);
    }
    this.all = new ArrayList(paramCollection);
  }
  
  public RecipientInformation get(RecipientId paramRecipientId)
  {
    ArrayList localArrayList = (ArrayList)this.table.get(paramRecipientId);
    return localArrayList == null ? null : (RecipientInformation)localArrayList.get(0);
  }
  
  public int size()
  {
    return this.all.size();
  }
  
  public Collection getRecipients()
  {
    return new ArrayList(this.all);
  }
  
  public Collection getRecipients(RecipientId paramRecipientId)
  {
    ArrayList localArrayList = (ArrayList)this.table.get(paramRecipientId);
    return localArrayList == null ? new ArrayList() : new ArrayList(localArrayList);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\RecipientInformationStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */