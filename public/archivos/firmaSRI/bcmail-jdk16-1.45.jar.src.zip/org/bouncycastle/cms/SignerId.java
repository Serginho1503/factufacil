package org.bouncycastle.cms;

import java.math.BigInteger;
import java.security.cert.X509CertSelector;
import org.bouncycastle.util.Arrays;

public class SignerId
  extends X509CertSelector
{
  public int hashCode()
  {
    int i = Arrays.hashCode(getSubjectKeyIdentifier());
    if (getSerialNumber() != null) {
      i ^= getSerialNumber().hashCode();
    }
    if (getIssuerAsString() != null) {
      i ^= getIssuerAsString().hashCode();
    }
    return i;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof SignerId)) {
      return false;
    }
    SignerId localSignerId = (SignerId)paramObject;
    return (Arrays.areEqual(getSubjectKeyIdentifier(), localSignerId.getSubjectKeyIdentifier())) && (equalsObj(getSerialNumber(), localSignerId.getSerialNumber())) && (equalsObj(getIssuerAsString(), localSignerId.getIssuerAsString()));
  }
  
  private boolean equalsObj(Object paramObject1, Object paramObject2)
  {
    return paramObject2 == null ? true : paramObject1 != null ? paramObject1.equals(paramObject2) : false;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\SignerId.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */