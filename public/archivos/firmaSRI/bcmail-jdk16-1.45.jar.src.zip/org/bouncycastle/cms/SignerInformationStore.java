package org.bouncycastle.cms;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class SignerInformationStore
{
  private Map table = new HashMap();
  
  public SignerInformationStore(Collection paramCollection)
  {
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      SignerInformation localSignerInformation = (SignerInformation)localIterator.next();
      SignerId localSignerId = localSignerInformation.getSID();
      if (this.table.get(localSignerId) == null)
      {
        this.table.put(localSignerId, localSignerInformation);
      }
      else
      {
        Object localObject = this.table.get(localSignerId);
        if ((localObject instanceof List))
        {
          ((List)localObject).add(localSignerInformation);
        }
        else
        {
          ArrayList localArrayList = new ArrayList();
          localArrayList.add(localObject);
          localArrayList.add(localSignerInformation);
          this.table.put(localSignerId, localArrayList);
        }
      }
    }
  }
  
  public SignerInformation get(SignerId paramSignerId)
  {
    Object localObject = this.table.get(paramSignerId);
    if ((localObject instanceof List)) {
      return (SignerInformation)((List)localObject).get(0);
    }
    return (SignerInformation)localObject;
  }
  
  public int size()
  {
    Iterator localIterator = this.table.values().iterator();
    int i = 0;
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      if ((localObject instanceof List)) {
        i += ((List)localObject).size();
      } else {
        i++;
      }
    }
    return i;
  }
  
  public Collection getSigners()
  {
    ArrayList localArrayList = new ArrayList(this.table.size());
    Iterator localIterator = this.table.values().iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      if ((localObject instanceof List)) {
        localArrayList.addAll((List)localObject);
      } else {
        localArrayList.add(localObject);
      }
    }
    return localArrayList;
  }
  
  public Collection getSigners(SignerId paramSignerId)
  {
    Object localObject = this.table.get(paramSignerId);
    if ((localObject instanceof List)) {
      return new ArrayList((List)localObject);
    }
    if (localObject != null) {
      return Collections.singletonList(localObject);
    }
    return new ArrayList();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\SignerInformationStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */