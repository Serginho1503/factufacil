package org.bouncycastle.cms;

import java.io.IOException;
import java.io.OutputStream;

public abstract interface CMSProcessable
{
  public abstract void write(OutputStream paramOutputStream)
    throws IOException, CMSException;
  
  public abstract Object getContent();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSProcessable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */