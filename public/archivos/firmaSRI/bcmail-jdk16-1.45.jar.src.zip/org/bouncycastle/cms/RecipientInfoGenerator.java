package org.bouncycastle.cms;

import java.security.GeneralSecurityException;
import java.security.Provider;
import java.security.SecureRandom;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.cms.RecipientInfo;

abstract interface RecipientInfoGenerator
{
  public abstract RecipientInfo generate(SecretKey paramSecretKey, SecureRandom paramSecureRandom, Provider paramProvider)
    throws GeneralSecurityException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\RecipientInfoGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */