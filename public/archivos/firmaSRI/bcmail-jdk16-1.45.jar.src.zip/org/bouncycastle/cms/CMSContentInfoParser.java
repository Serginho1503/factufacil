package org.bouncycastle.cms;

import java.io.IOException;
import java.io.InputStream;
import org.bouncycastle.asn1.ASN1SequenceParser;
import org.bouncycastle.asn1.ASN1StreamParser;
import org.bouncycastle.asn1.cms.ContentInfoParser;

public class CMSContentInfoParser
{
  protected ContentInfoParser _contentInfo;
  protected InputStream _data;
  
  protected CMSContentInfoParser(InputStream paramInputStream)
    throws CMSException
  {
    this._data = paramInputStream;
    try
    {
      ASN1StreamParser localASN1StreamParser = new ASN1StreamParser(paramInputStream, CMSUtils.getMaximumMemory());
      this._contentInfo = new ContentInfoParser((ASN1SequenceParser)localASN1StreamParser.readObject());
    }
    catch (IOException localIOException)
    {
      throw new CMSException("IOException reading content.", localIOException);
    }
    catch (ClassCastException localClassCastException)
    {
      throw new CMSException("Unexpected object reading content.", localClassCastException);
    }
  }
  
  public void close()
    throws IOException
  {
    this._data.close();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSContentInfoParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */