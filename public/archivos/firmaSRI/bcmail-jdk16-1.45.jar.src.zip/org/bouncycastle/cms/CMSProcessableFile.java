package org.bouncycastle.cms;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

public class CMSProcessableFile
  implements CMSProcessable
{
  private static final int DEFAULT_BUF_SIZE = 32768;
  private final File _file;
  private final byte[] _buf;
  
  public CMSProcessableFile(File paramFile)
  {
    this(paramFile, 32768);
  }
  
  public CMSProcessableFile(File paramFile, int paramInt)
  {
    this._file = paramFile;
    this._buf = new byte[paramInt];
  }
  
  public void write(OutputStream paramOutputStream)
    throws IOException, CMSException
  {
    FileInputStream localFileInputStream = new FileInputStream(this._file);
    int i;
    while ((i = localFileInputStream.read(this._buf, 0, this._buf.length)) > 0) {
      paramOutputStream.write(this._buf, 0, i);
    }
    localFileInputStream.close();
  }
  
  public Object getContent()
  {
    return this._file;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSProcessableFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */