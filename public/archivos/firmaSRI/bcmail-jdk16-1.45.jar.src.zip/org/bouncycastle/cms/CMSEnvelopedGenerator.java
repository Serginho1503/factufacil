package org.bouncycastle.cms;

import java.io.IOException;
import java.security.AlgorithmParameterGenerator;
import java.security.AlgorithmParameters;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.security.interfaces.ECPublicKey;
import java.security.spec.ECParameterSpec;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.KeyAgreement;
import javax.crypto.SecretKey;
import javax.crypto.spec.RC2ParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.cms.KEKIdentifier;
import org.bouncycastle.asn1.cms.OriginatorIdentifierOrKey;
import org.bouncycastle.asn1.cms.OriginatorPublicKey;
import org.bouncycastle.asn1.cms.ecc.MQVuserKeyingMaterial;
import org.bouncycastle.asn1.kisa.KISAObjectIdentifiers;
import org.bouncycastle.asn1.nist.NISTObjectIdentifiers;
import org.bouncycastle.asn1.ntt.NTTObjectIdentifiers;
import org.bouncycastle.asn1.pkcs.PBKDF2Params;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.asn1.x9.X9ObjectIdentifiers;
import org.bouncycastle.jce.spec.MQVPrivateKeySpec;
import org.bouncycastle.jce.spec.MQVPublicKeySpec;

public class CMSEnvelopedGenerator
{
  public static final String DES_EDE3_CBC = PKCSObjectIdentifiers.des_EDE3_CBC.getId();
  public static final String RC2_CBC = PKCSObjectIdentifiers.RC2_CBC.getId();
  public static final String IDEA_CBC = "1.3.6.1.4.1.188.7.1.1.2";
  public static final String CAST5_CBC = "1.2.840.113533.7.66.10";
  public static final String AES128_CBC = NISTObjectIdentifiers.id_aes128_CBC.getId();
  public static final String AES192_CBC = NISTObjectIdentifiers.id_aes192_CBC.getId();
  public static final String AES256_CBC = NISTObjectIdentifiers.id_aes256_CBC.getId();
  public static final String CAMELLIA128_CBC = NTTObjectIdentifiers.id_camellia128_cbc.getId();
  public static final String CAMELLIA192_CBC = NTTObjectIdentifiers.id_camellia192_cbc.getId();
  public static final String CAMELLIA256_CBC = NTTObjectIdentifiers.id_camellia256_cbc.getId();
  public static final String SEED_CBC = KISAObjectIdentifiers.id_seedCBC.getId();
  public static final String DES_EDE3_WRAP = PKCSObjectIdentifiers.id_alg_CMS3DESwrap.getId();
  public static final String AES128_WRAP = NISTObjectIdentifiers.id_aes128_wrap.getId();
  public static final String AES192_WRAP = NISTObjectIdentifiers.id_aes192_wrap.getId();
  public static final String AES256_WRAP = NISTObjectIdentifiers.id_aes256_wrap.getId();
  public static final String CAMELLIA128_WRAP = NTTObjectIdentifiers.id_camellia128_wrap.getId();
  public static final String CAMELLIA192_WRAP = NTTObjectIdentifiers.id_camellia192_wrap.getId();
  public static final String CAMELLIA256_WRAP = NTTObjectIdentifiers.id_camellia256_wrap.getId();
  public static final String SEED_WRAP = KISAObjectIdentifiers.id_npki_app_cmsSeed_wrap.getId();
  public static final String ECDH_SHA1KDF = X9ObjectIdentifiers.dhSinglePass_stdDH_sha1kdf_scheme.getId();
  public static final String ECMQV_SHA1KDF = X9ObjectIdentifiers.mqvSinglePass_sha1kdf_scheme.getId();
  final List recipientInfoGenerators = new ArrayList();
  final SecureRandom rand;
  
  public CMSEnvelopedGenerator()
  {
    this(new SecureRandom());
  }
  
  public CMSEnvelopedGenerator(SecureRandom paramSecureRandom)
  {
    this.rand = paramSecureRandom;
  }
  
  public void addKeyTransRecipient(X509Certificate paramX509Certificate)
    throws IllegalArgumentException
  {
    KeyTransRecipientInfoGenerator localKeyTransRecipientInfoGenerator = new KeyTransRecipientInfoGenerator();
    localKeyTransRecipientInfoGenerator.setRecipientCert(paramX509Certificate);
    this.recipientInfoGenerators.add(localKeyTransRecipientInfoGenerator);
  }
  
  public void addKeyTransRecipient(PublicKey paramPublicKey, byte[] paramArrayOfByte)
    throws IllegalArgumentException
  {
    KeyTransRecipientInfoGenerator localKeyTransRecipientInfoGenerator = new KeyTransRecipientInfoGenerator();
    localKeyTransRecipientInfoGenerator.setRecipientPublicKey(paramPublicKey);
    localKeyTransRecipientInfoGenerator.setSubjectKeyIdentifier(new DEROctetString(paramArrayOfByte));
    this.recipientInfoGenerators.add(localKeyTransRecipientInfoGenerator);
  }
  
  public void addKEKRecipient(SecretKey paramSecretKey, byte[] paramArrayOfByte)
  {
    KEKRecipientInfoGenerator localKEKRecipientInfoGenerator = new KEKRecipientInfoGenerator();
    localKEKRecipientInfoGenerator.setKEKIdentifier(new KEKIdentifier(paramArrayOfByte, null, null));
    localKEKRecipientInfoGenerator.setWrapKey(paramSecretKey);
    this.recipientInfoGenerators.add(localKEKRecipientInfoGenerator);
  }
  
  public void addPasswordRecipient(CMSPBEKey paramCMSPBEKey, String paramString)
  {
    PBKDF2Params localPBKDF2Params = new PBKDF2Params(paramCMSPBEKey.getSalt(), paramCMSPBEKey.getIterationCount());
    PasswordRecipientInfoGenerator localPasswordRecipientInfoGenerator = new PasswordRecipientInfoGenerator();
    localPasswordRecipientInfoGenerator.setDerivationAlg(new AlgorithmIdentifier(PKCSObjectIdentifiers.id_PBKDF2, localPBKDF2Params));
    localPasswordRecipientInfoGenerator.setWrapKey(new SecretKeySpec(paramCMSPBEKey.getEncoded(paramString), paramString));
    this.recipientInfoGenerators.add(localPasswordRecipientInfoGenerator);
  }
  
  public void addKeyAgreementRecipient(String paramString1, PrivateKey paramPrivateKey, PublicKey paramPublicKey, X509Certificate paramX509Certificate, String paramString2, String paramString3)
    throws NoSuchProviderException, NoSuchAlgorithmException, InvalidKeyException
  {
    addKeyAgreementRecipient(paramString1, paramPrivateKey, paramPublicKey, paramX509Certificate, paramString2, CMSUtils.getProvider(paramString3));
  }
  
  public void addKeyAgreementRecipient(String paramString1, PrivateKey paramPrivateKey, PublicKey paramPublicKey, X509Certificate paramX509Certificate, String paramString2, Provider paramProvider)
    throws NoSuchAlgorithmException, InvalidKeyException
  {
    OriginatorIdentifierOrKey localOriginatorIdentifierOrKey;
    try
    {
      localOriginatorIdentifierOrKey = new OriginatorIdentifierOrKey(createOriginatorPublicKey(paramPublicKey));
    }
    catch (IOException localIOException1)
    {
      throw new InvalidKeyException("cannot extract originator public key: " + localIOException1);
    }
    DEROctetString localDEROctetString = null;
    Object localObject1 = paramX509Certificate.getPublicKey();
    if (paramString1.equals(ECMQV_SHA1KDF)) {
      try
      {
        ECParameterSpec localECParameterSpec = ((ECPublicKey)paramPublicKey).getParams();
        localObject2 = KeyPairGenerator.getInstance(paramString1, paramProvider);
        ((KeyPairGenerator)localObject2).initialize(localECParameterSpec, this.rand);
        localObject3 = ((KeyPairGenerator)localObject2).generateKeyPair();
        localDEROctetString = new DEROctetString(new MQVuserKeyingMaterial(createOriginatorPublicKey(((KeyPair)localObject3).getPublic()), null));
        localObject1 = new MQVPublicKeySpec((PublicKey)localObject1, (PublicKey)localObject1);
        paramPrivateKey = new MQVPrivateKeySpec(paramPrivateKey, ((KeyPair)localObject3).getPrivate(), ((KeyPair)localObject3).getPublic());
      }
      catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
      {
        throw new InvalidKeyException("cannot determine MQV ephemeral key pair parameters from public key: " + localInvalidAlgorithmParameterException);
      }
      catch (IOException localIOException2)
      {
        throw new InvalidKeyException("cannot extract MQV ephemeral public key: " + localIOException2);
      }
    }
    KeyAgreement localKeyAgreement = KeyAgreement.getInstance(paramString1, paramProvider);
    localKeyAgreement.init(paramPrivateKey, this.rand);
    localKeyAgreement.doPhase((Key)localObject1, true);
    Object localObject2 = localKeyAgreement.generateSecret(paramString2);
    Object localObject3 = new KeyAgreeRecipientInfoGenerator();
    ((KeyAgreeRecipientInfoGenerator)localObject3).setAlgorithmOID(new DERObjectIdentifier(paramString1));
    ((KeyAgreeRecipientInfoGenerator)localObject3).setOriginator(localOriginatorIdentifierOrKey);
    ((KeyAgreeRecipientInfoGenerator)localObject3).setRecipientCert(paramX509Certificate);
    ((KeyAgreeRecipientInfoGenerator)localObject3).setUKM(localDEROctetString);
    ((KeyAgreeRecipientInfoGenerator)localObject3).setWrapKey((SecretKey)localObject2);
    ((KeyAgreeRecipientInfoGenerator)localObject3).setWrapAlgorithmOID(new DERObjectIdentifier(paramString2));
    this.recipientInfoGenerators.add(localObject3);
  }
  
  protected AlgorithmIdentifier getAlgorithmIdentifier(String paramString, AlgorithmParameters paramAlgorithmParameters)
    throws IOException
  {
    Object localObject;
    if (paramAlgorithmParameters != null) {
      localObject = ASN1Object.fromByteArray(paramAlgorithmParameters.getEncoded("ASN.1"));
    } else {
      localObject = DERNull.INSTANCE;
    }
    return new AlgorithmIdentifier(new DERObjectIdentifier(paramString), (DEREncodable)localObject);
  }
  
  protected AlgorithmParameters generateParameters(String paramString, SecretKey paramSecretKey, Provider paramProvider)
    throws CMSException
  {
    try
    {
      AlgorithmParameterGenerator localAlgorithmParameterGenerator = AlgorithmParameterGenerator.getInstance(paramString, paramProvider);
      if (paramString.equals(RC2_CBC))
      {
        byte[] arrayOfByte = new byte[8];
        this.rand.nextBytes(arrayOfByte);
        try
        {
          localAlgorithmParameterGenerator.init(new RC2ParameterSpec(paramSecretKey.getEncoded().length * 8, arrayOfByte), this.rand);
        }
        catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
        {
          throw new CMSException("parameters generation error: " + localInvalidAlgorithmParameterException, localInvalidAlgorithmParameterException);
        }
      }
      return localAlgorithmParameterGenerator.generateParameters();
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException) {}
    return null;
  }
  
  private static OriginatorPublicKey createOriginatorPublicKey(PublicKey paramPublicKey)
    throws IOException
  {
    SubjectPublicKeyInfo localSubjectPublicKeyInfo = SubjectPublicKeyInfo.getInstance(ASN1Object.fromByteArray(paramPublicKey.getEncoded()));
    return new OriginatorPublicKey(new AlgorithmIdentifier(localSubjectPublicKeyInfo.getAlgorithmId().getObjectId(), DERNull.INSTANCE), localSubjectPublicKeyInfo.getPublicKeyData().getBytes());
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSEnvelopedGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */