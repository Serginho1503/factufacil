package org.bouncycastle.cms;

/**
 * @deprecated
 */
public class CMSSignableByteArray
  extends CMSProcessableByteArray
{
  public CMSSignableByteArray(byte[] paramArrayOfByte)
  {
    super(paramArrayOfByte);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSSignableByteArray.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */