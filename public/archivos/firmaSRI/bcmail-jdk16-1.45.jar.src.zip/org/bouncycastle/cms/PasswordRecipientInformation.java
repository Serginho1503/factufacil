package org.bouncycastle.cms;

import java.io.InputStream;
import java.security.AlgorithmParameters;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cms.PasswordRecipientInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class PasswordRecipientInformation
  extends RecipientInformation
{
  private PasswordRecipientInfo info;
  
  /**
   * @deprecated
   */
  public PasswordRecipientInformation(PasswordRecipientInfo paramPasswordRecipientInfo, AlgorithmIdentifier paramAlgorithmIdentifier, InputStream paramInputStream)
  {
    this(paramPasswordRecipientInfo, paramAlgorithmIdentifier, null, null, paramInputStream);
  }
  
  /**
   * @deprecated
   */
  public PasswordRecipientInformation(PasswordRecipientInfo paramPasswordRecipientInfo, AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, InputStream paramInputStream)
  {
    this(paramPasswordRecipientInfo, paramAlgorithmIdentifier1, paramAlgorithmIdentifier2, null, paramInputStream);
  }
  
  PasswordRecipientInformation(PasswordRecipientInfo paramPasswordRecipientInfo, AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, AlgorithmIdentifier paramAlgorithmIdentifier3, InputStream paramInputStream)
  {
    super(paramAlgorithmIdentifier1, paramAlgorithmIdentifier2, paramAlgorithmIdentifier3, paramPasswordRecipientInfo.getKeyEncryptionAlgorithm(), paramInputStream);
    this.info = paramPasswordRecipientInfo;
    this.rid = new RecipientId();
  }
  
  public String getKeyDerivationAlgOID()
  {
    if (this.info.getKeyDerivationAlgorithm() != null) {
      return this.info.getKeyDerivationAlgorithm().getObjectId().getId();
    }
    return null;
  }
  
  public byte[] getKeyDerivationAlgParams()
  {
    try
    {
      if (this.info.getKeyDerivationAlgorithm() != null)
      {
        DEREncodable localDEREncodable = this.info.getKeyDerivationAlgorithm().getParameters();
        if (localDEREncodable != null) {
          return localDEREncodable.getDERObject().getEncoded();
        }
      }
      return null;
    }
    catch (Exception localException)
    {
      throw new RuntimeException("exception getting encryption parameters " + localException);
    }
  }
  
  public AlgorithmParameters getKeyDerivationAlgParameters(String paramString)
    throws NoSuchProviderException
  {
    return getKeyDerivationAlgParameters(CMSUtils.getProvider(paramString));
  }
  
  public AlgorithmParameters getKeyDerivationAlgParameters(Provider paramProvider)
  {
    try
    {
      if (this.info.getKeyDerivationAlgorithm() != null)
      {
        DEREncodable localDEREncodable = this.info.getKeyDerivationAlgorithm().getParameters();
        if (localDEREncodable != null)
        {
          AlgorithmParameters localAlgorithmParameters = AlgorithmParameters.getInstance(this.info.getKeyDerivationAlgorithm().getObjectId().toString(), paramProvider);
          localAlgorithmParameters.init(localDEREncodable.getDERObject().getEncoded());
          return localAlgorithmParameters;
        }
      }
      return null;
    }
    catch (Exception localException)
    {
      throw new RuntimeException("exception getting encryption parameters " + localException);
    }
  }
  
  public CMSTypedStream getContentStream(Key paramKey, String paramString)
    throws CMSException, NoSuchProviderException
  {
    return getContentStream(paramKey, CMSUtils.getProvider(paramString));
  }
  
  public CMSTypedStream getContentStream(Key paramKey, Provider paramProvider)
    throws CMSException
  {
    try
    {
      AlgorithmIdentifier localAlgorithmIdentifier1 = AlgorithmIdentifier.getInstance(this.info.getKeyEncryptionAlgorithm());
      ASN1Sequence localASN1Sequence = (ASN1Sequence)localAlgorithmIdentifier1.getParameters();
      byte[] arrayOfByte = this.info.getEncryptedKey().getOctets();
      String str1 = DERObjectIdentifier.getInstance(localASN1Sequence.getObjectAt(0)).getId();
      Cipher localCipher = Cipher.getInstance(CMSEnvelopedHelper.INSTANCE.getRFC3211WrapperName(str1), paramProvider);
      IvParameterSpec localIvParameterSpec = new IvParameterSpec(ASN1OctetString.getInstance(localASN1Sequence.getObjectAt(1)).getOctets());
      localCipher.init(4, new SecretKeySpec(((CMSPBEKey)paramKey).getEncoded(str1), str1), localIvParameterSpec);
      AlgorithmIdentifier localAlgorithmIdentifier2 = getActiveAlgID();
      String str2 = localAlgorithmIdentifier2.getObjectId().getId();
      Key localKey = localCipher.unwrap(arrayOfByte, str2, 3);
      return getContentFromSessionKey(localKey, paramProvider);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new CMSException("can't find algorithm.", localNoSuchAlgorithmException);
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new CMSException("key invalid in message.", localInvalidKeyException);
    }
    catch (NoSuchPaddingException localNoSuchPaddingException)
    {
      throw new CMSException("required padding not supported.", localNoSuchPaddingException);
    }
    catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
    {
      throw new CMSException("invalid iv.", localInvalidAlgorithmParameterException);
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\PasswordRecipientInformation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */