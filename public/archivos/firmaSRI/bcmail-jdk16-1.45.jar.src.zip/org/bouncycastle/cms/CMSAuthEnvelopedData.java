package org.bouncycastle.cms;

import java.io.InputStream;
import java.util.List;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.cms.AuthEnvelopedData;
import org.bouncycastle.asn1.cms.ContentInfo;
import org.bouncycastle.asn1.cms.EncryptedContentInfo;
import org.bouncycastle.asn1.cms.OriginatorInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

class CMSAuthEnvelopedData
{
  RecipientInformationStore recipientInfoStore;
  ContentInfo contentInfo;
  private OriginatorInfo originator;
  private AlgorithmIdentifier authEncAlg;
  private ASN1Set authAttrs;
  private byte[] mac;
  private ASN1Set unauthAttrs;
  
  public CMSAuthEnvelopedData(byte[] paramArrayOfByte)
    throws CMSException
  {
    this(CMSUtils.readContentInfo(paramArrayOfByte));
  }
  
  public CMSAuthEnvelopedData(InputStream paramInputStream)
    throws CMSException
  {
    this(CMSUtils.readContentInfo(paramInputStream));
  }
  
  public CMSAuthEnvelopedData(ContentInfo paramContentInfo)
    throws CMSException
  {
    this.contentInfo = paramContentInfo;
    AuthEnvelopedData localAuthEnvelopedData = AuthEnvelopedData.getInstance(paramContentInfo.getContent());
    this.originator = localAuthEnvelopedData.getOriginatorInfo();
    EncryptedContentInfo localEncryptedContentInfo = localAuthEnvelopedData.getAuthEncryptedContentInfo();
    this.authEncAlg = localEncryptedContentInfo.getContentEncryptionAlgorithm();
    byte[] arrayOfByte = localEncryptedContentInfo.getEncryptedContent().getOctets();
    List localList = CMSEnvelopedHelper.readRecipientInfos(localAuthEnvelopedData.getRecipientInfos(), arrayOfByte, null, null, this.authEncAlg);
    this.recipientInfoStore = new RecipientInformationStore(localList);
    this.authAttrs = localAuthEnvelopedData.getAuthAttrs();
    this.mac = localAuthEnvelopedData.getMac().getOctets();
    this.unauthAttrs = localAuthEnvelopedData.getUnauthAttrs();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSAuthEnvelopedData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */