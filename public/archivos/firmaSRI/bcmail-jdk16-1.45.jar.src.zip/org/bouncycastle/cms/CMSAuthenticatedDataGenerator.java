package org.bouncycastle.cms;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.InvalidParameterSpecException;
import java.util.Iterator;
import java.util.List;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.BERConstructedOctetString;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.cms.AuthenticatedData;
import org.bouncycastle.asn1.cms.CMSObjectIdentifiers;
import org.bouncycastle.asn1.cms.ContentInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class CMSAuthenticatedDataGenerator
  extends CMSAuthenticatedGenerator
{
  public CMSAuthenticatedDataGenerator() {}
  
  public CMSAuthenticatedDataGenerator(SecureRandom paramSecureRandom)
  {
    super(paramSecureRandom);
  }
  
  private CMSAuthenticatedData generate(CMSProcessable paramCMSProcessable, String paramString, KeyGenerator paramKeyGenerator, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException
  {
    Provider localProvider = paramKeyGenerator.getProvider();
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    SecretKey localSecretKey;
    AlgorithmIdentifier localAlgorithmIdentifier;
    BERConstructedOctetString localBERConstructedOctetString;
    DEROctetString localDEROctetString;
    try
    {
      Mac localMac = CMSEnvelopedHelper.INSTANCE.getMac(paramString, localProvider);
      localSecretKey = paramKeyGenerator.generateKey();
      localObject = generateParameterSpec(paramString, localSecretKey, localProvider);
      localMac.init(localSecretKey, (AlgorithmParameterSpec)localObject);
      localAlgorithmIdentifier = getAlgorithmIdentifier(paramString, (AlgorithmParameterSpec)localObject, localProvider);
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      CMSAuthenticatedGenerator.MacOutputStream localMacOutputStream = new CMSAuthenticatedGenerator.MacOutputStream(localByteArrayOutputStream, localMac);
      paramCMSProcessable.write(localMacOutputStream);
      localMacOutputStream.close();
      localByteArrayOutputStream.close();
      localBERConstructedOctetString = new BERConstructedOctetString(localByteArrayOutputStream.toByteArray());
      localDEROctetString = new DEROctetString(localMacOutputStream.getMac());
    }
    catch (InvalidKeyException localInvalidKeyException1)
    {
      throw new CMSException("key invalid in message.", localInvalidKeyException1);
    }
    catch (NoSuchPaddingException localNoSuchPaddingException)
    {
      throw new CMSException("required padding not supported.", localNoSuchPaddingException);
    }
    catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
    {
      throw new CMSException("algorithm parameters invalid.", localInvalidAlgorithmParameterException);
    }
    catch (IOException localIOException)
    {
      throw new CMSException("exception decoding algorithm parameters.", localIOException);
    }
    catch (InvalidParameterSpecException localInvalidParameterSpecException)
    {
      throw new CMSException("exception setting up parameters.", localInvalidParameterSpecException);
    }
    Iterator localIterator = this.recipientInfoGenerators.iterator();
    while (localIterator.hasNext())
    {
      localObject = (RecipientInfoGenerator)localIterator.next();
      try
      {
        localASN1EncodableVector.add(((RecipientInfoGenerator)localObject).generate(localSecretKey, this.rand, paramProvider));
      }
      catch (InvalidKeyException localInvalidKeyException2)
      {
        throw new CMSException("key inappropriate for algorithm.", localInvalidKeyException2);
      }
      catch (GeneralSecurityException localGeneralSecurityException)
      {
        throw new CMSException("error making encrypted content.", localGeneralSecurityException);
      }
    }
    Object localObject = new ContentInfo(CMSObjectIdentifiers.data, localBERConstructedOctetString);
    ContentInfo localContentInfo = new ContentInfo(CMSObjectIdentifiers.authenticatedData, new AuthenticatedData(null, new DERSet(localASN1EncodableVector), localAlgorithmIdentifier, null, (ContentInfo)localObject, null, localDEROctetString, null));
    return new CMSAuthenticatedData(localContentInfo);
  }
  
  public CMSAuthenticatedData generate(CMSProcessable paramCMSProcessable, String paramString1, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    return generate(paramCMSProcessable, paramString1, CMSUtils.getProvider(paramString2));
  }
  
  public CMSAuthenticatedData generate(CMSProcessable paramCMSProcessable, String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException
  {
    KeyGenerator localKeyGenerator = CMSEnvelopedHelper.INSTANCE.createSymmetricKeyGenerator(paramString, paramProvider);
    localKeyGenerator.init(this.rand);
    return generate(paramCMSProcessable, paramString, localKeyGenerator, paramProvider);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSAuthenticatedDataGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */