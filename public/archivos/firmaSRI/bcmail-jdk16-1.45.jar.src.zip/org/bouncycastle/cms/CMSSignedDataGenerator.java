package org.bouncycastle.cms;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.BERConstructedOctetString;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.CMSAttributes;
import org.bouncycastle.asn1.cms.CMSObjectIdentifiers;
import org.bouncycastle.asn1.cms.ContentInfo;
import org.bouncycastle.asn1.cms.SignedData;
import org.bouncycastle.asn1.cms.SignerIdentifier;
import org.bouncycastle.asn1.cms.SignerInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class CMSSignedDataGenerator
  extends CMSSignedGenerator
{
  List signerInfs = new ArrayList();
  
  public CMSSignedDataGenerator() {}
  
  public CMSSignedDataGenerator(SecureRandom paramSecureRandom)
  {
    super(paramSecureRandom);
  }
  
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString)
    throws IllegalArgumentException
  {
    addSigner(paramPrivateKey, paramX509Certificate, getEncOID(paramPrivateKey, paramString), paramString);
  }
  
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2)
    throws IllegalArgumentException
  {
    this.signerInfs.add(new SignerInf(paramPrivateKey, getSignerIdentifier(paramX509Certificate), paramString2, paramString1, new DefaultSignedAttributeTableGenerator(), null, null));
  }
  
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString)
    throws IllegalArgumentException
  {
    addSigner(paramPrivateKey, paramArrayOfByte, getEncOID(paramPrivateKey, paramString), paramString);
  }
  
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString1, String paramString2)
    throws IllegalArgumentException
  {
    this.signerInfs.add(new SignerInf(paramPrivateKey, getSignerIdentifier(paramArrayOfByte), paramString2, paramString1, new DefaultSignedAttributeTableGenerator(), null, null));
  }
  
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString, AttributeTable paramAttributeTable1, AttributeTable paramAttributeTable2)
    throws IllegalArgumentException
  {
    addSigner(paramPrivateKey, paramX509Certificate, getEncOID(paramPrivateKey, paramString), paramString, paramAttributeTable1, paramAttributeTable2);
  }
  
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2, AttributeTable paramAttributeTable1, AttributeTable paramAttributeTable2)
    throws IllegalArgumentException
  {
    this.signerInfs.add(new SignerInf(paramPrivateKey, getSignerIdentifier(paramX509Certificate), paramString2, paramString1, new DefaultSignedAttributeTableGenerator(paramAttributeTable1), new SimpleAttributeTableGenerator(paramAttributeTable2), paramAttributeTable1));
  }
  
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString, AttributeTable paramAttributeTable1, AttributeTable paramAttributeTable2)
    throws IllegalArgumentException
  {
    addSigner(paramPrivateKey, paramArrayOfByte, paramString, getEncOID(paramPrivateKey, paramString), new DefaultSignedAttributeTableGenerator(paramAttributeTable1), new SimpleAttributeTableGenerator(paramAttributeTable2));
  }
  
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString1, String paramString2, AttributeTable paramAttributeTable1, AttributeTable paramAttributeTable2)
    throws IllegalArgumentException
  {
    this.signerInfs.add(new SignerInf(paramPrivateKey, getSignerIdentifier(paramArrayOfByte), paramString2, paramString1, new DefaultSignedAttributeTableGenerator(paramAttributeTable1), new SimpleAttributeTableGenerator(paramAttributeTable2), paramAttributeTable1));
  }
  
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2)
    throws IllegalArgumentException
  {
    addSigner(paramPrivateKey, paramX509Certificate, getEncOID(paramPrivateKey, paramString), paramString, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2);
  }
  
  public void addSigner(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2)
    throws IllegalArgumentException
  {
    this.signerInfs.add(new SignerInf(paramPrivateKey, getSignerIdentifier(paramX509Certificate), paramString2, paramString1, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2, null));
  }
  
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2)
    throws IllegalArgumentException
  {
    addSigner(paramPrivateKey, paramArrayOfByte, paramString, getEncOID(paramPrivateKey, paramString), paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2);
  }
  
  public void addSigner(PrivateKey paramPrivateKey, byte[] paramArrayOfByte, String paramString1, String paramString2, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2)
    throws IllegalArgumentException
  {
    this.signerInfs.add(new SignerInf(paramPrivateKey, getSignerIdentifier(paramArrayOfByte), paramString2, paramString1, paramCMSAttributeTableGenerator1, paramCMSAttributeTableGenerator2, null));
  }
  
  public CMSSignedData generate(CMSProcessable paramCMSProcessable, String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    return generate(paramCMSProcessable, CMSUtils.getProvider(paramString));
  }
  
  public CMSSignedData generate(CMSProcessable paramCMSProcessable, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException
  {
    return generate(paramCMSProcessable, false, paramProvider);
  }
  
  public CMSSignedData generate(String paramString1, CMSProcessable paramCMSProcessable, boolean paramBoolean, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    return generate(paramString1, paramCMSProcessable, paramBoolean, CMSUtils.getProvider(paramString2), true);
  }
  
  public CMSSignedData generate(String paramString, CMSProcessable paramCMSProcessable, boolean paramBoolean, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException
  {
    return generate(paramString, paramCMSProcessable, paramBoolean, paramProvider, true);
  }
  
  public CMSSignedData generate(String paramString1, CMSProcessable paramCMSProcessable, boolean paramBoolean1, String paramString2, boolean paramBoolean2)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    return generate(paramString1, paramCMSProcessable, paramBoolean1, CMSUtils.getProvider(paramString2), paramBoolean2);
  }
  
  public CMSSignedData generate(String paramString, CMSProcessable paramCMSProcessable, boolean paramBoolean1, Provider paramProvider, boolean paramBoolean2)
    throws NoSuchAlgorithmException, CMSException
  {
    ASN1EncodableVector localASN1EncodableVector1 = new ASN1EncodableVector();
    ASN1EncodableVector localASN1EncodableVector2 = new ASN1EncodableVector();
    this._digests.clear();
    Iterator localIterator = this._signers.iterator();
    while (localIterator.hasNext())
    {
      SignerInformation localSignerInformation = (SignerInformation)localIterator.next();
      localASN1EncodableVector1.add(CMSSignedHelper.INSTANCE.fixAlgID(localSignerInformation.getDigestAlgorithmID()));
      localASN1EncodableVector2.add(localSignerInformation.toSignerInfo());
    }
    boolean bool = paramString == null;
    DERObjectIdentifier localDERObjectIdentifier = bool ? CMSObjectIdentifiers.data : new DERObjectIdentifier(paramString);
    localIterator = this.signerInfs.iterator();
    while (localIterator.hasNext())
    {
      localObject1 = (SignerInf)localIterator.next();
      try
      {
        localASN1EncodableVector1.add(((SignerInf)localObject1).getDigestAlgorithmID());
        localASN1EncodableVector2.add(((SignerInf)localObject1).toSignerInfo(localDERObjectIdentifier, paramCMSProcessable, this.rand, paramProvider, paramBoolean2, bool));
      }
      catch (IOException localIOException1)
      {
        throw new CMSException("encoding error.", localIOException1);
      }
      catch (InvalidKeyException localInvalidKeyException)
      {
        throw new CMSException("key inappropriate for signature.", localInvalidKeyException);
      }
      catch (SignatureException localSignatureException)
      {
        throw new CMSException("error creating signature.", localSignatureException);
      }
      catch (CertificateEncodingException localCertificateEncodingException)
      {
        throw new CMSException("error creating sid.", localCertificateEncodingException);
      }
    }
    Object localObject1 = null;
    if (this._certs.size() != 0) {
      localObject1 = CMSUtils.createBerSetFromList(this._certs);
    }
    ASN1Set localASN1Set = null;
    if (this._crls.size() != 0) {
      localASN1Set = CMSUtils.createBerSetFromList(this._crls);
    }
    BERConstructedOctetString localBERConstructedOctetString = null;
    if (paramBoolean1)
    {
      localObject2 = new ByteArrayOutputStream();
      if (paramCMSProcessable != null) {
        try
        {
          paramCMSProcessable.write((OutputStream)localObject2);
        }
        catch (IOException localIOException2)
        {
          throw new CMSException("encapsulation error.", localIOException2);
        }
      }
      localBERConstructedOctetString = new BERConstructedOctetString(((ByteArrayOutputStream)localObject2).toByteArray());
    }
    Object localObject2 = new ContentInfo(localDERObjectIdentifier, localBERConstructedOctetString);
    SignedData localSignedData = new SignedData(new DERSet(localASN1EncodableVector1), (ContentInfo)localObject2, (ASN1Set)localObject1, localASN1Set, new DERSet(localASN1EncodableVector2));
    ContentInfo localContentInfo = new ContentInfo(CMSObjectIdentifiers.signedData, localSignedData);
    return new CMSSignedData(paramCMSProcessable, localContentInfo);
  }
  
  public CMSSignedData generate(CMSProcessable paramCMSProcessable, boolean paramBoolean, String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    return generate(DATA, paramCMSProcessable, paramBoolean, paramString);
  }
  
  public CMSSignedData generate(CMSProcessable paramCMSProcessable, boolean paramBoolean, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException
  {
    return generate(DATA, paramCMSProcessable, paramBoolean, paramProvider);
  }
  
  public SignerInformationStore generateCounterSigners(SignerInformation paramSignerInformation, Provider paramProvider)
    throws NoSuchAlgorithmException, CMSException
  {
    return generate(null, new CMSProcessableByteArray(paramSignerInformation.getSignature()), false, paramProvider).getSignerInfos();
  }
  
  public SignerInformationStore generateCounterSigners(SignerInformation paramSignerInformation, String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    return generate(null, new CMSProcessableByteArray(paramSignerInformation.getSignature()), false, CMSUtils.getProvider(paramString)).getSignerInfos();
  }
  
  private class SignerInf
  {
    private final PrivateKey key;
    private final SignerIdentifier signerIdentifier;
    private final String digestOID;
    private final String encOID;
    private final CMSAttributeTableGenerator sAttr;
    private final CMSAttributeTableGenerator unsAttr;
    private final AttributeTable baseSignedTable;
    
    SignerInf(PrivateKey paramPrivateKey, SignerIdentifier paramSignerIdentifier, String paramString1, String paramString2, CMSAttributeTableGenerator paramCMSAttributeTableGenerator1, CMSAttributeTableGenerator paramCMSAttributeTableGenerator2, AttributeTable paramAttributeTable)
    {
      this.key = paramPrivateKey;
      this.signerIdentifier = paramSignerIdentifier;
      this.digestOID = paramString1;
      this.encOID = paramString2;
      this.sAttr = paramCMSAttributeTableGenerator1;
      this.unsAttr = paramCMSAttributeTableGenerator2;
      this.baseSignedTable = paramAttributeTable;
    }
    
    AlgorithmIdentifier getDigestAlgorithmID()
    {
      return new AlgorithmIdentifier(new DERObjectIdentifier(this.digestOID), new DERNull());
    }
    
    SignerInfo toSignerInfo(DERObjectIdentifier paramDERObjectIdentifier, CMSProcessable paramCMSProcessable, SecureRandom paramSecureRandom, Provider paramProvider, boolean paramBoolean1, boolean paramBoolean2)
      throws IOException, SignatureException, InvalidKeyException, NoSuchAlgorithmException, CertificateEncodingException, CMSException
    {
      AlgorithmIdentifier localAlgorithmIdentifier1 = getDigestAlgorithmID();
      String str1 = CMSSignedHelper.INSTANCE.getDigestAlgName(this.digestOID);
      String str2 = str1 + "with" + CMSSignedHelper.INSTANCE.getEncryptionAlgName(this.encOID);
      Signature localSignature = CMSSignedHelper.INSTANCE.getSignatureInstance(str2, paramProvider);
      MessageDigest localMessageDigest = CMSSignedHelper.INSTANCE.getDigestInstance(str1, paramProvider);
      AlgorithmIdentifier localAlgorithmIdentifier2 = CMSSignedDataGenerator.this.getEncAlgorithmIdentifier(this.encOID, localSignature);
      if (paramCMSProcessable != null) {
        paramCMSProcessable.write(new CMSSignedGenerator.DigOutputStream(localMessageDigest));
      }
      byte[] arrayOfByte1 = localMessageDigest.digest();
      CMSSignedDataGenerator.this._digests.put(this.digestOID, arrayOfByte1.clone());
      AttributeTable localAttributeTable1;
      if (paramBoolean1)
      {
        localObject1 = CMSSignedDataGenerator.this.getBaseParameters(paramDERObjectIdentifier, localAlgorithmIdentifier1, arrayOfByte1);
        localAttributeTable1 = this.sAttr != null ? this.sAttr.getAttributes(Collections.unmodifiableMap((Map)localObject1)) : null;
      }
      else
      {
        localAttributeTable1 = this.baseSignedTable;
      }
      Object localObject1 = null;
      byte[] arrayOfByte2;
      if (localAttributeTable1 != null)
      {
        if (paramBoolean2)
        {
          localObject2 = localAttributeTable1.toHashtable();
          ((Hashtable)localObject2).remove(CMSAttributes.contentType);
          localAttributeTable1 = new AttributeTable((Hashtable)localObject2);
        }
        localObject1 = CMSSignedDataGenerator.this.getAttributeSet(localAttributeTable1);
        arrayOfByte2 = ((ASN1Set)localObject1).getEncoded("DER");
      }
      else
      {
        localObject2 = new ByteArrayOutputStream();
        if (paramCMSProcessable != null) {
          paramCMSProcessable.write((OutputStream)localObject2);
        }
        arrayOfByte2 = ((ByteArrayOutputStream)localObject2).toByteArray();
      }
      localSignature.initSign(this.key, paramSecureRandom);
      localSignature.update(arrayOfByte2);
      Object localObject2 = localSignature.sign();
      ASN1Set localASN1Set = null;
      if (this.unsAttr != null)
      {
        Map localMap = CMSSignedDataGenerator.this.getBaseParameters(paramDERObjectIdentifier, localAlgorithmIdentifier1, arrayOfByte1);
        localMap.put("encryptedDigest", ((byte[])localObject2).clone());
        AttributeTable localAttributeTable2 = this.unsAttr.getAttributes(Collections.unmodifiableMap(localMap));
        localASN1Set = CMSSignedDataGenerator.this.getAttributeSet(localAttributeTable2);
      }
      return new SignerInfo(this.signerIdentifier, localAlgorithmIdentifier1, (ASN1Set)localObject1, localAlgorithmIdentifier2, new DEROctetString((byte[])localObject2), localASN1Set);
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSSignedDataGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */