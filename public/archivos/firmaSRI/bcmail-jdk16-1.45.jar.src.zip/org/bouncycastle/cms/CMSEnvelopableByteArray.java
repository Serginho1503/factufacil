package org.bouncycastle.cms;

/**
 * @deprecated
 */
public class CMSEnvelopableByteArray
  extends CMSProcessableByteArray
{
  public CMSEnvelopableByteArray(byte[] paramArrayOfByte)
  {
    super(paramArrayOfByte);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSEnvelopableByteArray.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */