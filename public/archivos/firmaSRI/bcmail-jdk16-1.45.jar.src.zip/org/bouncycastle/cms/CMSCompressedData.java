package org.bouncycastle.cms;

import java.io.IOException;
import java.io.InputStream;
import java.util.zip.InflaterInputStream;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.cms.CompressedData;
import org.bouncycastle.asn1.cms.ContentInfo;

public class CMSCompressedData
{
  ContentInfo contentInfo;
  
  public CMSCompressedData(byte[] paramArrayOfByte)
    throws CMSException
  {
    this(CMSUtils.readContentInfo(paramArrayOfByte));
  }
  
  public CMSCompressedData(InputStream paramInputStream)
    throws CMSException
  {
    this(CMSUtils.readContentInfo(paramInputStream));
  }
  
  public CMSCompressedData(ContentInfo paramContentInfo)
    throws CMSException
  {
    this.contentInfo = paramContentInfo;
  }
  
  public byte[] getContent()
    throws CMSException
  {
    CompressedData localCompressedData = CompressedData.getInstance(this.contentInfo.getContent());
    ContentInfo localContentInfo = localCompressedData.getEncapContentInfo();
    ASN1OctetString localASN1OctetString = (ASN1OctetString)localContentInfo.getContent();
    InflaterInputStream localInflaterInputStream = new InflaterInputStream(localASN1OctetString.getOctetStream());
    try
    {
      return CMSUtils.streamToByteArray(localInflaterInputStream);
    }
    catch (IOException localIOException)
    {
      throw new CMSException("exception reading compressed stream.", localIOException);
    }
  }
  
  public byte[] getContent(int paramInt)
    throws CMSException
  {
    CompressedData localCompressedData = CompressedData.getInstance(this.contentInfo.getContent());
    ContentInfo localContentInfo = localCompressedData.getEncapContentInfo();
    ASN1OctetString localASN1OctetString = (ASN1OctetString)localContentInfo.getContent();
    InflaterInputStream localInflaterInputStream = new InflaterInputStream(localASN1OctetString.getOctetStream());
    try
    {
      return CMSUtils.streamToByteArray(localInflaterInputStream, paramInt);
    }
    catch (IOException localIOException)
    {
      throw new CMSException("exception reading compressed stream.", localIOException);
    }
  }
  
  public ContentInfo getContentInfo()
  {
    return this.contentInfo;
  }
  
  public byte[] getEncoded()
    throws IOException
  {
    return this.contentInfo.getEncoded();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\CMSCompressedData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */