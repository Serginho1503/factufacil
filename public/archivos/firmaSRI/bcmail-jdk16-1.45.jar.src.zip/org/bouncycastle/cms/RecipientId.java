package org.bouncycastle.cms;

import java.math.BigInteger;
import java.security.cert.X509CertSelector;
import org.bouncycastle.util.Arrays;

public class RecipientId
  extends X509CertSelector
{
  byte[] keyIdentifier = null;
  
  public void setKeyIdentifier(byte[] paramArrayOfByte)
  {
    this.keyIdentifier = paramArrayOfByte;
  }
  
  public byte[] getKeyIdentifier()
  {
    return this.keyIdentifier;
  }
  
  public int hashCode()
  {
    int i = Arrays.hashCode(this.keyIdentifier) ^ Arrays.hashCode(getSubjectKeyIdentifier());
    BigInteger localBigInteger = getSerialNumber();
    if (localBigInteger != null) {
      i ^= localBigInteger.hashCode();
    }
    String str = getIssuerAsString();
    if (str != null) {
      i ^= str.hashCode();
    }
    return i;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof RecipientId)) {
      return false;
    }
    RecipientId localRecipientId = (RecipientId)paramObject;
    return (Arrays.areEqual(this.keyIdentifier, localRecipientId.keyIdentifier)) && (Arrays.areEqual(getSubjectKeyIdentifier(), localRecipientId.getSubjectKeyIdentifier())) && (equalsObj(getSerialNumber(), localRecipientId.getSerialNumber())) && (equalsObj(getIssuerAsString(), localRecipientId.getIssuerAsString()));
  }
  
  private boolean equalsObj(Object paramObject1, Object paramObject2)
  {
    return paramObject2 == null ? true : paramObject1 != null ? paramObject1.equals(paramObject2) : false;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\cms\RecipientId.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */