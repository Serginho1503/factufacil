package org.bouncycastle.mail.smime.validator;

import org.bouncycastle.i18n.ErrorBundle;
import org.bouncycastle.i18n.LocalizedException;

public class SignedMailValidatorException
  extends LocalizedException
{
  public SignedMailValidatorException(ErrorBundle paramErrorBundle, Throwable paramThrowable)
  {
    super(paramErrorBundle, paramThrowable);
  }
  
  public SignedMailValidatorException(ErrorBundle paramErrorBundle)
  {
    super(paramErrorBundle);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\validator\SignedMailValidatorException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */