package org.bouncycastle.mail.smime.util;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import javax.mail.internet.SharedInputStream;

public class SharedFileInputStream
  extends FilterInputStream
  implements SharedInputStream
{
  private final SharedFileInputStream _parent;
  private final File _file;
  private final long _start;
  private final long _length;
  private long _position;
  private long _markedPosition;
  private List _subStreams = new LinkedList();
  
  public SharedFileInputStream(String paramString)
    throws IOException
  {
    this(new File(paramString));
  }
  
  public SharedFileInputStream(File paramFile)
    throws IOException
  {
    this(paramFile, 0L, paramFile.length());
  }
  
  private SharedFileInputStream(File paramFile, long paramLong1, long paramLong2)
    throws IOException
  {
    super(new BufferedInputStream(new FileInputStream(paramFile)));
    this._parent = null;
    this._file = paramFile;
    this._start = paramLong1;
    this._length = paramLong2;
    this.in.skip(paramLong1);
  }
  
  private SharedFileInputStream(SharedFileInputStream paramSharedFileInputStream, long paramLong1, long paramLong2)
    throws IOException
  {
    super(new BufferedInputStream(new FileInputStream(paramSharedFileInputStream._file)));
    this._parent = paramSharedFileInputStream;
    this._file = paramSharedFileInputStream._file;
    this._start = paramLong1;
    this._length = paramLong2;
    this.in.skip(paramLong1);
  }
  
  public long getPosition()
  {
    return this._position;
  }
  
  public InputStream newStream(long paramLong1, long paramLong2)
  {
    try
    {
      SharedFileInputStream localSharedFileInputStream;
      if (paramLong2 < 0L)
      {
        if (this._length > 0L) {
          localSharedFileInputStream = new SharedFileInputStream(this, this._start + paramLong1, this._length - paramLong1);
        } else if (this._length == 0L) {
          localSharedFileInputStream = new SharedFileInputStream(this, this._start + paramLong1, 0L);
        } else {
          localSharedFileInputStream = new SharedFileInputStream(this, this._start + paramLong1, -1L);
        }
      }
      else {
        localSharedFileInputStream = new SharedFileInputStream(this, this._start + paramLong1, paramLong2 - paramLong1);
      }
      this._subStreams.add(localSharedFileInputStream);
      return localSharedFileInputStream;
    }
    catch (IOException localIOException)
    {
      throw new IllegalStateException("unable to create shared stream: " + localIOException);
    }
  }
  
  public int read(byte[] paramArrayOfByte)
    throws IOException
  {
    return read(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int i = 0;
    if (paramInt2 == 0) {
      return 0;
    }
    while (i < paramInt2)
    {
      int j = read();
      if (j < 0) {
        break;
      }
      paramArrayOfByte[(paramInt1 + i)] = ((byte)j);
      i++;
    }
    if (i == 0) {
      return -1;
    }
    return i;
  }
  
  public int read()
    throws IOException
  {
    if (this._position == this._length) {
      return -1;
    }
    this._position += 1L;
    return this.in.read();
  }
  
  public boolean markSupported()
  {
    return true;
  }
  
  public long skip(long paramLong)
    throws IOException
  {
    for (long l = 0L; (l != paramLong) && (read() >= 0); l += 1L) {}
    return l;
  }
  
  public void mark(int paramInt)
  {
    this._markedPosition = this._position;
    this.in.mark(paramInt);
  }
  
  public void reset()
    throws IOException
  {
    this._position = this._markedPosition;
    this.in.reset();
  }
  
  public SharedFileInputStream getRoot()
  {
    if (this._parent != null) {
      return this._parent.getRoot();
    }
    return this;
  }
  
  public void dispose()
    throws IOException
  {
    Iterator localIterator = this._subStreams.iterator();
    while (localIterator.hasNext()) {
      try
      {
        ((SharedFileInputStream)localIterator.next()).dispose();
      }
      catch (IOException localIOException) {}
    }
    this.in.close();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\util\SharedFileInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */