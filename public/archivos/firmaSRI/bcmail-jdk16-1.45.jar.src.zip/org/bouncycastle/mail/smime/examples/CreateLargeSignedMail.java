package org.bouncycastle.mail.smime.examples;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.security.GeneralSecurityException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.cert.CertStore;
import java.security.cert.CollectionCertStoreParameters;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Message.RecipientType;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.IssuerAndSerialNumber;
import org.bouncycastle.asn1.smime.SMIMECapabilitiesAttribute;
import org.bouncycastle.asn1.smime.SMIMECapability;
import org.bouncycastle.asn1.smime.SMIMECapabilityVector;
import org.bouncycastle.asn1.smime.SMIMEEncryptionKeyPreferenceAttribute;
import org.bouncycastle.asn1.x509.AuthorityKeyIdentifier;
import org.bouncycastle.asn1.x509.SubjectKeyIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.asn1.x509.X509Name;
import org.bouncycastle.mail.smime.SMIMESignedGenerator;
import org.bouncycastle.x509.X509V3CertificateGenerator;

public class CreateLargeSignedMail
{
  static int serialNo = 1;
  
  static AuthorityKeyIdentifier createAuthorityKeyId(PublicKey paramPublicKey)
    throws IOException
  {
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramPublicKey.getEncoded());
    SubjectPublicKeyInfo localSubjectPublicKeyInfo = new SubjectPublicKeyInfo((ASN1Sequence)new ASN1InputStream(localByteArrayInputStream).readObject());
    return new AuthorityKeyIdentifier(localSubjectPublicKeyInfo);
  }
  
  static SubjectKeyIdentifier createSubjectKeyId(PublicKey paramPublicKey)
    throws IOException
  {
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramPublicKey.getEncoded());
    SubjectPublicKeyInfo localSubjectPublicKeyInfo = new SubjectPublicKeyInfo((ASN1Sequence)new ASN1InputStream(localByteArrayInputStream).readObject());
    return new SubjectKeyIdentifier(localSubjectPublicKeyInfo);
  }
  
  static X509Certificate makeCertificate(KeyPair paramKeyPair1, String paramString1, KeyPair paramKeyPair2, String paramString2)
    throws GeneralSecurityException, IOException
  {
    PublicKey localPublicKey1 = paramKeyPair1.getPublic();
    PrivateKey localPrivateKey = paramKeyPair2.getPrivate();
    PublicKey localPublicKey2 = paramKeyPair2.getPublic();
    X509V3CertificateGenerator localX509V3CertificateGenerator = new X509V3CertificateGenerator();
    localX509V3CertificateGenerator.setSerialNumber(BigInteger.valueOf(serialNo++));
    localX509V3CertificateGenerator.setIssuerDN(new X509Name(paramString2));
    localX509V3CertificateGenerator.setNotBefore(new Date(System.currentTimeMillis()));
    localX509V3CertificateGenerator.setNotAfter(new Date(System.currentTimeMillis() + 8640000000L));
    localX509V3CertificateGenerator.setSubjectDN(new X509Name(paramString1));
    localX509V3CertificateGenerator.setPublicKey(localPublicKey1);
    localX509V3CertificateGenerator.setSignatureAlgorithm("MD5WithRSAEncryption");
    localX509V3CertificateGenerator.addExtension(X509Extensions.SubjectKeyIdentifier, false, createSubjectKeyId(localPublicKey1));
    localX509V3CertificateGenerator.addExtension(X509Extensions.AuthorityKeyIdentifier, false, createAuthorityKeyId(localPublicKey2));
    return localX509V3CertificateGenerator.generateX509Certificate(localPrivateKey);
  }
  
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("RSA", "BC");
    localKeyPairGenerator.initialize(1024, new SecureRandom());
    String str1 = "O=Bouncy Castle, C=AU";
    KeyPair localKeyPair1 = localKeyPairGenerator.generateKeyPair();
    X509Certificate localX509Certificate1 = makeCertificate(localKeyPair1, str1, localKeyPair1, str1);
    String str2 = "CN=Eric H. Echidna, E=eric@bouncycastle.org, O=Bouncy Castle, C=AU";
    KeyPair localKeyPair2 = localKeyPairGenerator.generateKeyPair();
    X509Certificate localX509Certificate2 = makeCertificate(localKeyPair2, str2, localKeyPair1, str1);
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(localX509Certificate2);
    localArrayList.add(localX509Certificate1);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    SMIMECapabilityVector localSMIMECapabilityVector = new SMIMECapabilityVector();
    localSMIMECapabilityVector.addCapability(SMIMECapability.dES_EDE3_CBC);
    localSMIMECapabilityVector.addCapability(SMIMECapability.rC2_CBC, 128);
    localSMIMECapabilityVector.addCapability(SMIMECapability.dES_CBC);
    localASN1EncodableVector.add(new SMIMECapabilitiesAttribute(localSMIMECapabilityVector));
    IssuerAndSerialNumber localIssuerAndSerialNumber = new IssuerAndSerialNumber(new X509Name(str1), localX509Certificate2.getSerialNumber());
    localASN1EncodableVector.add(new SMIMEEncryptionKeyPreferenceAttribute(localIssuerAndSerialNumber));
    SMIMESignedGenerator localSMIMESignedGenerator = new SMIMESignedGenerator();
    localSMIMESignedGenerator.addSigner(localKeyPair2.getPrivate(), localX509Certificate2, SMIMESignedGenerator.DIGEST_SHA1, new AttributeTable(localASN1EncodableVector), null);
    localSMIMESignedGenerator.addCertificatesAndCRLs(localCertStore);
    MimeBodyPart localMimeBodyPart = new MimeBodyPart();
    localMimeBodyPart.setDataHandler(new DataHandler(new FileDataSource(new File(paramArrayOfString[0]))));
    localMimeBodyPart.setHeader("Content-Type", "application/octet-stream");
    localMimeBodyPart.setHeader("Content-Transfer-Encoding", "base64");
    MimeMultipart localMimeMultipart = localSMIMESignedGenerator.generate(localMimeBodyPart, "BC");
    Properties localProperties = System.getProperties();
    Session localSession = Session.getDefaultInstance(localProperties, null);
    InternetAddress localInternetAddress1 = new InternetAddress("\"Eric H. Echidna\"<eric@bouncycastle.org>");
    InternetAddress localInternetAddress2 = new InternetAddress("example@bouncycastle.org");
    MimeMessage localMimeMessage = new MimeMessage(localSession);
    localMimeMessage.setFrom(localInternetAddress1);
    localMimeMessage.setRecipient(Message.RecipientType.TO, localInternetAddress2);
    localMimeMessage.setSubject("example signed message");
    localMimeMessage.setContent(localMimeMultipart, localMimeMultipart.getContentType());
    localMimeMessage.saveChanges();
    localMimeMessage.writeTo(new FileOutputStream("signed.message"));
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\examples\CreateLargeSignedMail.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */