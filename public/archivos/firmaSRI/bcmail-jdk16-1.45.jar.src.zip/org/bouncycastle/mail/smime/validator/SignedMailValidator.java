package org.bouncycastle.mail.smime.validator;

import java.io.IOException;
import java.math.BigInteger;
import java.security.GeneralSecurityException;
import java.security.PublicKey;
import java.security.cert.CertPath;
import java.security.cert.CertStore;
import java.security.cert.CertStoreException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateExpiredException;
import java.security.cert.CertificateFactory;
import java.security.cert.CertificateNotYetValidException;
import java.security.cert.PKIXParameters;
import java.security.cert.TrustAnchor;
import java.security.cert.X509CertSelector;
import java.security.cert.X509Certificate;
import java.security.interfaces.DSAParams;
import java.security.interfaces.DSAPublicKey;
import java.security.interfaces.RSAPublicKey;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.security.auth.x500.X500Principal;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERIA5String;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.cms.Attribute;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.CMSAttributes;
import org.bouncycastle.asn1.cms.Time;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.x509.AuthorityKeyIdentifier;
import org.bouncycastle.asn1.x509.ExtendedKeyUsage;
import org.bouncycastle.asn1.x509.KeyPurposeId;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.cms.SignerInformation;
import org.bouncycastle.cms.SignerInformationStore;
import org.bouncycastle.i18n.ErrorBundle;
import org.bouncycastle.i18n.filter.TrustedInput;
import org.bouncycastle.i18n.filter.UntrustedInput;
import org.bouncycastle.jce.PrincipalUtil;
import org.bouncycastle.jce.X509Principal;
import org.bouncycastle.mail.smime.SMIMESigned;
import org.bouncycastle.x509.CertPathReviewerException;
import org.bouncycastle.x509.PKIXCertPathReviewer;

public class SignedMailValidator
{
  private static final String RESOURCE_NAME = "org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages";
  private static final Class DEFAULT_CERT_PATH_REVIEWER = PKIXCertPathReviewer.class;
  private static final String EXT_KEY_USAGE = X509Extensions.ExtendedKeyUsage.getId();
  private static final String SUBJECT_ALTERNATIVE_NAME = X509Extensions.SubjectAlternativeName.getId();
  private static final int shortKeyLength = 512;
  private static final long THIRTY_YEARS_IN_MILLI_SEC = 946728000000L;
  private CertStore certs;
  private SignerInformationStore signers;
  private Map results;
  private String[] fromAddresses;
  private Class certPathReviewerClass;
  
  public SignedMailValidator(MimeMessage paramMimeMessage, PKIXParameters paramPKIXParameters)
    throws SignedMailValidatorException
  {
    this(paramMimeMessage, paramPKIXParameters, DEFAULT_CERT_PATH_REVIEWER);
  }
  
  public SignedMailValidator(MimeMessage paramMimeMessage, PKIXParameters paramPKIXParameters, Class paramClass)
    throws SignedMailValidatorException
  {
    this.certPathReviewerClass = paramClass;
    boolean bool = DEFAULT_CERT_PATH_REVIEWER.isAssignableFrom(paramClass);
    if (!bool) {
      throw new IllegalArgumentException("certPathReviewerClass is not a subclass of " + DEFAULT_CERT_PATH_REVIEWER.getName());
    }
    try
    {
      SMIMESigned localSMIMESigned;
      if (paramMimeMessage.isMimeType("multipart/signed"))
      {
        localObject1 = (MimeMultipart)paramMimeMessage.getContent();
        localSMIMESigned = new SMIMESigned((MimeMultipart)localObject1);
      }
      else if ((paramMimeMessage.isMimeType("application/pkcs7-mime")) || (paramMimeMessage.isMimeType("application/x-pkcs7-mime")))
      {
        localSMIMESigned = new SMIMESigned(paramMimeMessage);
      }
      else
      {
        localObject1 = new ErrorBundle("org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages", "SignedMailValidator.noSignedMessage");
        throw new SignedMailValidatorException((ErrorBundle)localObject1);
      }
      this.certs = localSMIMESigned.getCertificatesAndCRLs("Collection", "BC");
      this.signers = localSMIMESigned.getSignerInfos();
      Object localObject1 = paramMimeMessage.getFrom();
      localObject2 = null;
      try
      {
        if (paramMimeMessage.getHeader("Sender") != null) {
          localObject2 = new InternetAddress(paramMimeMessage.getHeader("Sender")[0]);
        }
      }
      catch (MessagingException localMessagingException) {}
      this.fromAddresses = new String[localObject1.length + (localObject2 != null ? 1 : 0)];
      for (int i = 0; i < localObject1.length; i++)
      {
        InternetAddress localInternetAddress = (InternetAddress)localObject1[i];
        this.fromAddresses[i] = localInternetAddress.getAddress();
      }
      if (localObject2 != null) {
        this.fromAddresses[localObject1.length] = ((InternetAddress)localObject2).getAddress();
      }
      this.results = new HashMap();
    }
    catch (Exception localException)
    {
      if ((localException instanceof SignedMailValidatorException)) {
        throw ((SignedMailValidatorException)localException);
      }
      Object localObject2 = new ErrorBundle("org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages", "SignedMailValidator.exceptionReadingMessage", new Object[] { localException.getMessage(), localException, localException.getClass().getName() });
      throw new SignedMailValidatorException((ErrorBundle)localObject2, localException);
    }
    validateSignatures(paramPKIXParameters);
  }
  
  protected void validateSignatures(PKIXParameters paramPKIXParameters)
  {
    PKIXParameters localPKIXParameters = (PKIXParameters)paramPKIXParameters.clone();
    localPKIXParameters.addCertStore(this.certs);
    Collection localCollection = this.signers.getSigners();
    Iterator localIterator = localCollection.iterator();
    while (localIterator.hasNext())
    {
      ArrayList localArrayList1 = new ArrayList();
      ArrayList localArrayList2 = new ArrayList();
      SignerInformation localSignerInformation = (SignerInformation)localIterator.next();
      X509Certificate localX509Certificate = null;
      Object localObject1;
      try
      {
        List localList = findCerts(localPKIXParameters.getCertStores(), localSignerInformation.getSID());
        localObject1 = localList.iterator();
        if (((Iterator)localObject1).hasNext()) {
          localX509Certificate = (X509Certificate)((Iterator)localObject1).next();
        }
      }
      catch (CertStoreException localCertStoreException)
      {
        localObject1 = new ErrorBundle("org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages", "SignedMailValidator.exceptionRetrievingSignerCert", new Object[] { localCertStoreException.getMessage(), localCertStoreException, localCertStoreException.getClass().getName() });
        localArrayList1.add(localObject1);
      }
      if (localX509Certificate != null)
      {
        boolean bool = false;
        try
        {
          bool = localSignerInformation.verify(localX509Certificate.getPublicKey(), "BC");
          if (!bool)
          {
            localObject1 = new ErrorBundle("org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages", "SignedMailValidator.signatureNotVerified");
            localArrayList1.add(localObject1);
          }
        }
        catch (Exception localException)
        {
          localObject2 = new ErrorBundle("org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages", "SignedMailValidator.exceptionVerifyingSignature", new Object[] { localException.getMessage(), localException, localException.getClass().getName() });
          localArrayList1.add(localObject2);
        }
        checkSignerCert(localX509Certificate, localArrayList1, localArrayList2);
        AttributeTable localAttributeTable = localSignerInformation.getSignedAttributes();
        ErrorBundle localErrorBundle2;
        if (localAttributeTable != null)
        {
          localObject2 = localAttributeTable.get(PKCSObjectIdentifiers.id_aa_receiptRequest);
          if (localObject2 != null)
          {
            localErrorBundle2 = new ErrorBundle("org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages", "SignedMailValidator.signedReceiptRequest");
            localArrayList2.add(localErrorBundle2);
          }
        }
        Object localObject2 = getSignatureTime(localSignerInformation);
        Object localObject3;
        if (localObject2 == null)
        {
          localErrorBundle2 = new ErrorBundle("org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages", "SignedMailValidator.noSigningTime");
          localArrayList1.add(localErrorBundle2);
          localObject2 = new Date();
        }
        else
        {
          try
          {
            localX509Certificate.checkValidity((Date)localObject2);
          }
          catch (CertificateExpiredException localCertificateExpiredException)
          {
            localObject3 = new ErrorBundle("org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages", "SignedMailValidator.certExpired", new Object[] { new TrustedInput(localObject2), new TrustedInput(localX509Certificate.getNotAfter()) });
            localArrayList1.add(localObject3);
          }
          catch (CertificateNotYetValidException localCertificateNotYetValidException)
          {
            localObject3 = new ErrorBundle("org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages", "SignedMailValidator.certNotYetValid", new Object[] { new TrustedInput(localObject2), new TrustedInput(localX509Certificate.getNotBefore()) });
            localArrayList1.add(localObject3);
          }
        }
        localPKIXParameters.setDate((Date)localObject2);
        try
        {
          ArrayList localArrayList3 = new ArrayList();
          localArrayList3.add(this.certs);
          Object[] arrayOfObject = createCertPath(localX509Certificate, localPKIXParameters.getTrustAnchors(), paramPKIXParameters.getCertStores(), localArrayList3);
          CertPath localCertPath = (CertPath)arrayOfObject[0];
          localObject3 = (List)arrayOfObject[1];
          PKIXCertPathReviewer localPKIXCertPathReviewer;
          try
          {
            localPKIXCertPathReviewer = (PKIXCertPathReviewer)this.certPathReviewerClass.newInstance();
          }
          catch (IllegalAccessException localIllegalAccessException)
          {
            throw new IllegalArgumentException("Cannot instantiate object of type " + this.certPathReviewerClass.getName() + ": " + localIllegalAccessException.getMessage());
          }
          catch (InstantiationException localInstantiationException)
          {
            throw new IllegalArgumentException("Cannot instantiate object of type " + this.certPathReviewerClass.getName() + ": " + localInstantiationException.getMessage());
          }
          localPKIXCertPathReviewer.init(localCertPath, localPKIXParameters);
          if (!localPKIXCertPathReviewer.isValidCertPath())
          {
            ErrorBundle localErrorBundle3 = new ErrorBundle("org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages", "SignedMailValidator.certPathInvalid");
            localArrayList1.add(localErrorBundle3);
          }
          this.results.put(localSignerInformation, new ValidationResult(localPKIXCertPathReviewer, bool, localArrayList1, localArrayList2, (List)localObject3));
        }
        catch (GeneralSecurityException localGeneralSecurityException)
        {
          localObject3 = new ErrorBundle("org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages", "SignedMailValidator.exceptionCreateCertPath", new Object[] { localGeneralSecurityException.getMessage(), localGeneralSecurityException, localGeneralSecurityException.getClass().getName() });
          localArrayList1.add(localObject3);
          this.results.put(localSignerInformation, new ValidationResult(null, bool, localArrayList1, localArrayList2, null));
        }
        catch (CertPathReviewerException localCertPathReviewerException)
        {
          localArrayList1.add(localCertPathReviewerException.getErrorMessage());
          this.results.put(localSignerInformation, new ValidationResult(null, bool, localArrayList1, localArrayList2, null));
        }
      }
      else
      {
        ErrorBundle localErrorBundle1 = new ErrorBundle("org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages", "SignedMailValidator.noSignerCert");
        localArrayList1.add(localErrorBundle1);
        this.results.put(localSignerInformation, new ValidationResult(null, false, localArrayList1, localArrayList2, null));
      }
    }
  }
  
  public static Set getEmailAddresses(X509Certificate paramX509Certificate)
    throws IOException, CertificateEncodingException
  {
    HashSet localHashSet = new HashSet();
    X509Principal localX509Principal = PrincipalUtil.getSubjectX509Principal(paramX509Certificate);
    Vector localVector1 = localX509Principal.getOIDs();
    Vector localVector2 = localX509Principal.getValues();
    Object localObject;
    for (int i = 0; i < localVector1.size(); i++) {
      if (localVector1.get(i).equals(X509Principal.EmailAddress))
      {
        localObject = ((String)localVector2.get(i)).toLowerCase();
        localHashSet.add(localObject);
        break;
      }
    }
    byte[] arrayOfByte = paramX509Certificate.getExtensionValue(SUBJECT_ALTERNATIVE_NAME);
    if (arrayOfByte != null)
    {
      localObject = (DERSequence)getObject(arrayOfByte);
      for (int j = 0; j < ((DERSequence)localObject).size(); j++)
      {
        ASN1TaggedObject localASN1TaggedObject = (ASN1TaggedObject)((DERSequence)localObject).getObjectAt(j);
        if (localASN1TaggedObject.getTagNo() == 1)
        {
          String str = DERIA5String.getInstance(localASN1TaggedObject, true).getString().toLowerCase();
          localHashSet.add(str);
        }
      }
    }
    return localHashSet;
  }
  
  private static DERObject getObject(byte[] paramArrayOfByte)
    throws IOException
  {
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramArrayOfByte);
    ASN1OctetString localASN1OctetString = (ASN1OctetString)localASN1InputStream.readObject();
    localASN1InputStream = new ASN1InputStream(localASN1OctetString.getOctets());
    return localASN1InputStream.readObject();
  }
  
  protected void checkSignerCert(X509Certificate paramX509Certificate, List paramList1, List paramList2)
  {
    PublicKey localPublicKey = paramX509Certificate.getPublicKey();
    int i = -1;
    if ((localPublicKey instanceof RSAPublicKey)) {
      i = ((RSAPublicKey)localPublicKey).getModulus().bitLength();
    } else if ((localPublicKey instanceof DSAPublicKey)) {
      i = ((DSAPublicKey)localPublicKey).getParams().getP().bitLength();
    }
    if ((i != -1) && (i <= 512))
    {
      ErrorBundle localErrorBundle1 = new ErrorBundle("org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages", "SignedMailValidator.shortSigningKey", new Object[] { new Integer(i) });
      paramList2.add(localErrorBundle1);
    }
    long l = paramX509Certificate.getNotAfter().getTime() - paramX509Certificate.getNotBefore().getTime();
    if (l > 946728000000L)
    {
      localObject1 = new ErrorBundle("org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages", "SignedMailValidator.longValidity", new Object[] { new TrustedInput(paramX509Certificate.getNotBefore()), new TrustedInput(paramX509Certificate.getNotAfter()) });
      paramList2.add(localObject1);
    }
    Object localObject1 = paramX509Certificate.getKeyUsage();
    Object localObject2;
    if ((localObject1 != null) && (localObject1[0] == 0) && (localObject1[1] == 0))
    {
      localObject2 = new ErrorBundle("org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages", "SignedMailValidator.signingNotPermitted");
      paramList1.add(localObject2);
    }
    Object localObject3;
    try
    {
      localObject2 = paramX509Certificate.getExtensionValue(EXT_KEY_USAGE);
      if (localObject2 != null)
      {
        localObject3 = ExtendedKeyUsage.getInstance(getObject((byte[])localObject2));
        if ((!((ExtendedKeyUsage)localObject3).hasKeyPurposeId(KeyPurposeId.anyExtendedKeyUsage)) && (!((ExtendedKeyUsage)localObject3).hasKeyPurposeId(KeyPurposeId.id_kp_emailProtection)))
        {
          ErrorBundle localErrorBundle3 = new ErrorBundle("org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages", "SignedMailValidator.extKeyUsageNotPermitted");
          paramList1.add(localErrorBundle3);
        }
      }
    }
    catch (Exception localException1)
    {
      localObject3 = new ErrorBundle("org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages", "SignedMailValidator.extKeyUsageError", new Object[] { localException1.getMessage(), localException1, localException1.getClass().getName() });
      paramList1.add(localObject3);
    }
    try
    {
      Set localSet = getEmailAddresses(paramX509Certificate);
      if (localSet.isEmpty())
      {
        localObject3 = new ErrorBundle("org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages", "SignedMailValidator.noEmailInCert");
        paramList1.add(localObject3);
      }
      else
      {
        int j = 0;
        for (int k = 0; k < this.fromAddresses.length; k++) {
          if (localSet.contains(this.fromAddresses[k].toLowerCase()))
          {
            j = 1;
            break;
          }
        }
        if (j == 0)
        {
          ErrorBundle localErrorBundle4 = new ErrorBundle("org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages", "SignedMailValidator.emailFromCertMismatch", new Object[] { new UntrustedInput(addressesToString(this.fromAddresses)), new UntrustedInput(localSet) });
          paramList1.add(localErrorBundle4);
        }
      }
    }
    catch (Exception localException2)
    {
      ErrorBundle localErrorBundle2 = new ErrorBundle("org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages", "SignedMailValidator.certGetEmailError", new Object[] { localException2.getMessage(), localException2, localException2.getClass().getName() });
      paramList1.add(localErrorBundle2);
    }
  }
  
  static String addressesToString(Object[] paramArrayOfObject)
  {
    if (paramArrayOfObject == null) {
      return "null";
    }
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append('[');
    for (int i = 0; i != paramArrayOfObject.length; i++)
    {
      if (i > 0) {
        localStringBuffer.append(", ");
      }
      localStringBuffer.append(String.valueOf(paramArrayOfObject[i]));
    }
    return ']';
  }
  
  public static Date getSignatureTime(SignerInformation paramSignerInformation)
  {
    AttributeTable localAttributeTable = paramSignerInformation.getSignedAttributes();
    Date localDate = null;
    if (localAttributeTable != null)
    {
      Attribute localAttribute = localAttributeTable.get(CMSAttributes.signingTime);
      if (localAttribute != null)
      {
        Time localTime = Time.getInstance(localAttribute.getAttrValues().getObjectAt(0).getDERObject());
        localDate = localTime.getDate();
      }
    }
    return localDate;
  }
  
  private static List findCerts(List paramList, X509CertSelector paramX509CertSelector)
    throws CertStoreException
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      CertStore localCertStore = (CertStore)localIterator.next();
      Collection localCollection = localCertStore.getCertificates(paramX509CertSelector);
      localArrayList.addAll(localCollection);
    }
    return localArrayList;
  }
  
  private static X509Certificate findNextCert(List paramList, X509CertSelector paramX509CertSelector, Set paramSet)
    throws CertStoreException
  {
    Iterator localIterator = findCerts(paramList, paramX509CertSelector).iterator();
    int i = 0;
    X509Certificate localX509Certificate = null;
    while (localIterator.hasNext())
    {
      localX509Certificate = (X509Certificate)localIterator.next();
      if (!paramSet.contains(localX509Certificate)) {
        i = 1;
      }
    }
    return i != 0 ? localX509Certificate : null;
  }
  
  public static CertPath createCertPath(X509Certificate paramX509Certificate, Set paramSet, List paramList)
    throws GeneralSecurityException
  {
    Object[] arrayOfObject = createCertPath(paramX509Certificate, paramSet, paramList, null);
    return (CertPath)arrayOfObject[0];
  }
  
  public static Object[] createCertPath(X509Certificate paramX509Certificate, Set paramSet, List paramList1, List paramList2)
    throws GeneralSecurityException
  {
    LinkedHashSet localLinkedHashSet = new LinkedHashSet();
    ArrayList localArrayList = new ArrayList();
    X509Certificate localX509Certificate1 = paramX509Certificate;
    localLinkedHashSet.add(localX509Certificate1);
    localArrayList.add(new Boolean(true));
    int i = 0;
    Object localObject1 = null;
    while ((localX509Certificate1 != null) && (i == 0))
    {
      localObject2 = paramSet.iterator();
      Object localObject3;
      label187:
      while (((Iterator)localObject2).hasNext())
      {
        localObject3 = (TrustAnchor)((Iterator)localObject2).next();
        X509Certificate localX509Certificate2 = ((TrustAnchor)localObject3).getTrustedCert();
        if (localX509Certificate2 != null)
        {
          if (localX509Certificate2.getSubjectX500Principal().equals(localX509Certificate1.getIssuerX500Principal())) {
            try
            {
              localX509Certificate1.verify(localX509Certificate2.getPublicKey(), "BC");
              i = 1;
              localObject1 = localX509Certificate2;
            }
            catch (Exception localException1)
            {
              break label187;
            }
          }
        }
        else if (((TrustAnchor)localObject3).getCAName().equals(localX509Certificate1.getIssuerX500Principal().getName())) {
          try
          {
            localX509Certificate1.verify(((TrustAnchor)localObject3).getCAPublicKey(), "BC");
            i = 1;
          }
          catch (Exception localException2) {}
        }
      }
      if (i == 0)
      {
        localObject3 = new X509CertSelector();
        try
        {
          ((X509CertSelector)localObject3).setSubject(localX509Certificate1.getIssuerX500Principal().getEncoded());
        }
        catch (IOException localIOException2)
        {
          throw new IllegalStateException(localIOException2.toString());
        }
        byte[] arrayOfByte = localX509Certificate1.getExtensionValue(X509Extensions.AuthorityKeyIdentifier.getId());
        if (arrayOfByte != null) {
          try
          {
            AuthorityKeyIdentifier localAuthorityKeyIdentifier = AuthorityKeyIdentifier.getInstance(getObject(arrayOfByte));
            if (localAuthorityKeyIdentifier.getKeyIdentifier() != null) {
              ((X509CertSelector)localObject3).setSubjectKeyIdentifier(new DEROctetString(localAuthorityKeyIdentifier.getKeyIdentifier()).getDEREncoded());
            }
          }
          catch (IOException localIOException3) {}
        }
        boolean bool2 = false;
        localX509Certificate1 = findNextCert(paramList1, (X509CertSelector)localObject3, localLinkedHashSet);
        if ((localX509Certificate1 == null) && (paramList2 != null))
        {
          bool2 = true;
          localX509Certificate1 = findNextCert(paramList2, (X509CertSelector)localObject3, localLinkedHashSet);
        }
        if (localX509Certificate1 != null)
        {
          localLinkedHashSet.add(localX509Certificate1);
          localArrayList.add(new Boolean(bool2));
        }
      }
    }
    if (i != 0) {
      if ((localObject1 != null) && (((X509Certificate)localObject1).getSubjectX500Principal().equals(((X509Certificate)localObject1).getIssuerX500Principal())))
      {
        localLinkedHashSet.add(localObject1);
        localArrayList.add(new Boolean(false));
      }
      else
      {
        localObject2 = new X509CertSelector();
        try
        {
          ((X509CertSelector)localObject2).setSubject(localX509Certificate1.getIssuerX500Principal().getEncoded());
          ((X509CertSelector)localObject2).setIssuer(localX509Certificate1.getIssuerX500Principal().getEncoded());
        }
        catch (IOException localIOException1)
        {
          throw new IllegalStateException(localIOException1.toString());
        }
        boolean bool1 = false;
        localObject1 = findNextCert(paramList1, (X509CertSelector)localObject2, localLinkedHashSet);
        if ((localObject1 == null) && (paramList2 != null))
        {
          bool1 = true;
          localObject1 = findNextCert(paramList2, (X509CertSelector)localObject2, localLinkedHashSet);
        }
        if (localObject1 != null) {
          try
          {
            localX509Certificate1.verify(((X509Certificate)localObject1).getPublicKey(), "BC");
            localLinkedHashSet.add(localObject1);
            localArrayList.add(new Boolean(bool1));
          }
          catch (GeneralSecurityException localGeneralSecurityException) {}
        }
      }
    }
    Object localObject2 = CertificateFactory.getInstance("X.509", "BC").generateCertPath(new ArrayList(localLinkedHashSet));
    return new Object[] { localObject2, localArrayList };
  }
  
  public CertStore getCertsAndCRLs()
  {
    return this.certs;
  }
  
  public SignerInformationStore getSignerInformationStore()
  {
    return this.signers;
  }
  
  public ValidationResult getValidationResult(SignerInformation paramSignerInformation)
    throws SignedMailValidatorException
  {
    if (this.signers.getSigners(paramSignerInformation.getSID()).isEmpty())
    {
      ErrorBundle localErrorBundle = new ErrorBundle("org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages", "SignedMailValidator.wrongSigner");
      throw new SignedMailValidatorException(localErrorBundle);
    }
    return (ValidationResult)this.results.get(paramSignerInformation);
  }
  
  public class ValidationResult
  {
    private PKIXCertPathReviewer review;
    private List errors;
    private List notifications;
    private List userProvidedCerts;
    private boolean signVerified;
    
    ValidationResult(PKIXCertPathReviewer paramPKIXCertPathReviewer, boolean paramBoolean, List paramList1, List paramList2, List paramList3)
    {
      this.review = paramPKIXCertPathReviewer;
      this.errors = paramList1;
      this.notifications = paramList2;
      this.signVerified = paramBoolean;
      this.userProvidedCerts = paramList3;
    }
    
    public List getErrors()
    {
      return this.errors;
    }
    
    public List getNotifications()
    {
      return this.notifications;
    }
    
    public PKIXCertPathReviewer getCertPathReview()
    {
      return this.review;
    }
    
    public CertPath getCertPath()
    {
      return this.review != null ? this.review.getCertPath() : null;
    }
    
    public List getUserProvidedCerts()
    {
      return this.userProvidedCerts;
    }
    
    public boolean isVerifiedSignature()
    {
      return this.signVerified;
    }
    
    public boolean isValidSignature()
    {
      if (this.review != null) {
        return (this.signVerified) && (this.review.isValidCertPath()) && (this.errors.isEmpty());
      }
      return false;
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\validator\SignedMailValidator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */