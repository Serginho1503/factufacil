package org.bouncycastle.mail.smime;

import java.io.IOException;
import java.io.OutputStream;
import java.security.AlgorithmParameters;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.PublicKey;
import java.security.cert.X509Certificate;
import javax.activation.CommandMap;
import javax.activation.DataHandler;
import javax.activation.MailcapCommandMap;
import javax.crypto.SecretKey;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.cms.CMSEnvelopedDataGenerator;
import org.bouncycastle.cms.CMSEnvelopedDataStreamGenerator;
import org.bouncycastle.cms.CMSException;

public class SMIMEEnvelopedGenerator
  extends SMIMEGenerator
{
  public static final String DES_EDE3_CBC = CMSEnvelopedDataGenerator.DES_EDE3_CBC;
  public static final String RC2_CBC = CMSEnvelopedDataGenerator.RC2_CBC;
  public static final String IDEA_CBC = "1.3.6.1.4.1.188.7.1.1.2";
  public static final String CAST5_CBC = "1.2.840.113533.7.66.10";
  public static final String AES128_CBC = CMSEnvelopedDataGenerator.AES128_CBC;
  public static final String AES192_CBC = CMSEnvelopedDataGenerator.AES192_CBC;
  public static final String AES256_CBC = CMSEnvelopedDataGenerator.AES256_CBC;
  public static final String CAMELLIA128_CBC = CMSEnvelopedDataGenerator.CAMELLIA128_CBC;
  public static final String CAMELLIA192_CBC = CMSEnvelopedDataGenerator.CAMELLIA192_CBC;
  public static final String CAMELLIA256_CBC = CMSEnvelopedDataGenerator.CAMELLIA256_CBC;
  public static final String SEED_CBC = CMSEnvelopedDataGenerator.SEED_CBC;
  public static final String DES_EDE3_WRAP = CMSEnvelopedDataGenerator.DES_EDE3_WRAP;
  public static final String AES128_WRAP = CMSEnvelopedDataGenerator.AES128_WRAP;
  public static final String AES256_WRAP = CMSEnvelopedDataGenerator.AES256_WRAP;
  public static final String CAMELLIA128_WRAP = CMSEnvelopedDataGenerator.CAMELLIA128_WRAP;
  public static final String CAMELLIA192_WRAP = CMSEnvelopedDataGenerator.CAMELLIA192_WRAP;
  public static final String CAMELLIA256_WRAP = CMSEnvelopedDataGenerator.CAMELLIA256_WRAP;
  public static final String SEED_WRAP = CMSEnvelopedDataGenerator.SEED_WRAP;
  public static final String ECDH_SHA1KDF = CMSEnvelopedDataGenerator.ECDH_SHA1KDF;
  private static final String ENCRYPTED_CONTENT_TYPE = "application/pkcs7-mime; name=\"smime.p7m\"; smime-type=enveloped-data";
  private EnvelopedGenerator fact = new EnvelopedGenerator(null);
  
  private static MailcapCommandMap addCommands(CommandMap paramCommandMap)
  {
    MailcapCommandMap localMailcapCommandMap = (MailcapCommandMap)paramCommandMap;
    localMailcapCommandMap.addMailcap("application/pkcs7-signature;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.pkcs7_signature");
    localMailcapCommandMap.addMailcap("application/pkcs7-mime;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.pkcs7_mime");
    localMailcapCommandMap.addMailcap("application/x-pkcs7-signature;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.x_pkcs7_signature");
    localMailcapCommandMap.addMailcap("application/x-pkcs7-mime;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.x_pkcs7_mime");
    localMailcapCommandMap.addMailcap("multipart/signed;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.multipart_signed");
    return localMailcapCommandMap;
  }
  
  public void addKeyTransRecipient(X509Certificate paramX509Certificate)
    throws IllegalArgumentException
  {
    this.fact.addKeyTransRecipient(paramX509Certificate);
  }
  
  public void addKeyTransRecipient(PublicKey paramPublicKey, byte[] paramArrayOfByte)
    throws IllegalArgumentException
  {
    this.fact.addKeyTransRecipient(paramPublicKey, paramArrayOfByte);
  }
  
  public void addKEKRecipient(SecretKey paramSecretKey, byte[] paramArrayOfByte)
    throws IllegalArgumentException
  {
    this.fact.addKEKRecipient(paramSecretKey, paramArrayOfByte);
  }
  
  public void addKeyAgreementRecipient(String paramString1, PrivateKey paramPrivateKey, PublicKey paramPublicKey, X509Certificate paramX509Certificate, String paramString2, String paramString3)
    throws NoSuchProviderException, NoSuchAlgorithmException, InvalidKeyException
  {
    this.fact.addKeyAgreementRecipient(paramString1, paramPrivateKey, paramPublicKey, paramX509Certificate, paramString2, paramString3);
  }
  
  public void addKeyAgreementRecipient(String paramString1, PrivateKey paramPrivateKey, PublicKey paramPublicKey, X509Certificate paramX509Certificate, String paramString2, Provider paramProvider)
    throws NoSuchProviderException, NoSuchAlgorithmException, InvalidKeyException
  {
    this.fact.addKeyAgreementRecipient(paramString1, paramPrivateKey, paramPublicKey, paramX509Certificate, paramString2, paramProvider);
  }
  
  public void setBerEncodeRecipients(boolean paramBoolean)
  {
    this.fact.setBEREncodeRecipients(paramBoolean);
  }
  
  private MimeBodyPart make(MimeBodyPart paramMimeBodyPart, String paramString, int paramInt, Provider paramProvider)
    throws NoSuchAlgorithmException, SMIMEException
  {
    createSymmetricKeyGenerator(paramString, paramProvider);
    try
    {
      MimeBodyPart localMimeBodyPart = new MimeBodyPart();
      localMimeBodyPart.setContent(new ContentEncryptor(paramMimeBodyPart, paramString, paramInt, paramProvider), "application/pkcs7-mime; name=\"smime.p7m\"; smime-type=enveloped-data");
      localMimeBodyPart.addHeader("Content-Type", "application/pkcs7-mime; name=\"smime.p7m\"; smime-type=enveloped-data");
      localMimeBodyPart.addHeader("Content-Disposition", "attachment; filename=\"smime.p7m\"");
      localMimeBodyPart.addHeader("Content-Description", "S/MIME Encrypted Message");
      localMimeBodyPart.addHeader("Content-Transfer-Encoding", this.encoding);
      return localMimeBodyPart;
    }
    catch (MessagingException localMessagingException)
    {
      throw new SMIMEException("exception putting multi-part together.", localMessagingException);
    }
  }
  
  public MimeBodyPart generate(MimeBodyPart paramMimeBodyPart, String paramString1, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, SMIMEException
  {
    return make(makeContentBodyPart(paramMimeBodyPart), paramString1, 0, SMIMEUtil.getProvider(paramString2));
  }
  
  public MimeBodyPart generate(MimeBodyPart paramMimeBodyPart, String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, SMIMEException
  {
    return make(makeContentBodyPart(paramMimeBodyPart), paramString, 0, paramProvider);
  }
  
  public MimeBodyPart generate(MimeMessage paramMimeMessage, String paramString1, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, SMIMEException
  {
    return generate(paramMimeMessage, paramString1, SMIMEUtil.getProvider(paramString2));
  }
  
  public MimeBodyPart generate(MimeMessage paramMimeMessage, String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchProviderException, SMIMEException
  {
    try
    {
      paramMimeMessage.saveChanges();
    }
    catch (MessagingException localMessagingException)
    {
      throw new SMIMEException("unable to save message", localMessagingException);
    }
    return make(makeContentBodyPart(paramMimeMessage), paramString, 0, paramProvider);
  }
  
  public MimeBodyPart generate(MimeBodyPart paramMimeBodyPart, String paramString1, int paramInt, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, SMIMEException
  {
    return generate(paramMimeBodyPart, paramString1, paramInt, SMIMEUtil.getProvider(paramString2));
  }
  
  public MimeBodyPart generate(MimeBodyPart paramMimeBodyPart, String paramString, int paramInt, Provider paramProvider)
    throws NoSuchAlgorithmException, NoSuchProviderException, SMIMEException
  {
    return make(makeContentBodyPart(paramMimeBodyPart), paramString, paramInt, paramProvider);
  }
  
  public MimeBodyPart generate(MimeMessage paramMimeMessage, String paramString1, int paramInt, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, SMIMEException
  {
    return generate(paramMimeMessage, paramString1, paramInt, SMIMEUtil.getProvider(paramString2));
  }
  
  public MimeBodyPart generate(MimeMessage paramMimeMessage, String paramString, int paramInt, Provider paramProvider)
    throws NoSuchAlgorithmException, SMIMEException
  {
    try
    {
      paramMimeMessage.saveChanges();
    }
    catch (MessagingException localMessagingException)
    {
      throw new SMIMEException("unable to save message", localMessagingException);
    }
    return make(makeContentBodyPart(paramMimeMessage), paramString, paramInt, paramProvider);
  }
  
  static
  {
    CommandMap.setDefaultCommandMap(addCommands(CommandMap.getDefaultCommandMap()));
  }
  
  private class ContentEncryptor
    implements SMIMEStreamingProcessor
  {
    private final MimeBodyPart _content;
    private final String _encryptionOid;
    private final int _keySize;
    private final Provider _provider;
    private boolean _firstTime = true;
    
    ContentEncryptor(MimeBodyPart paramMimeBodyPart, String paramString, int paramInt, Provider paramProvider)
    {
      this._content = paramMimeBodyPart;
      this._encryptionOid = paramString;
      this._keySize = paramInt;
      this._provider = paramProvider;
    }
    
    public void write(OutputStream paramOutputStream)
      throws IOException
    {
      try
      {
        OutputStream localOutputStream;
        if (this._firstTime)
        {
          if (this._keySize == 0) {
            localOutputStream = SMIMEEnvelopedGenerator.this.fact.open(paramOutputStream, this._encryptionOid, this._provider);
          } else {
            localOutputStream = SMIMEEnvelopedGenerator.this.fact.open(paramOutputStream, this._encryptionOid, this._keySize, this._provider);
          }
          this._firstTime = false;
        }
        else
        {
          localOutputStream = SMIMEEnvelopedGenerator.this.fact.regenerate(paramOutputStream, this._provider);
        }
        this._content.getDataHandler().setCommandMap(SMIMEEnvelopedGenerator.addCommands(CommandMap.getDefaultCommandMap()));
        this._content.writeTo(localOutputStream);
        localOutputStream.close();
      }
      catch (MessagingException localMessagingException)
      {
        throw new SMIMEEnvelopedGenerator.WrappingIOException(localMessagingException.toString(), localMessagingException);
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
      {
        throw new SMIMEEnvelopedGenerator.WrappingIOException(localNoSuchAlgorithmException.toString(), localNoSuchAlgorithmException);
      }
      catch (NoSuchProviderException localNoSuchProviderException)
      {
        throw new SMIMEEnvelopedGenerator.WrappingIOException(localNoSuchProviderException.toString(), localNoSuchProviderException);
      }
      catch (CMSException localCMSException)
      {
        throw new SMIMEEnvelopedGenerator.WrappingIOException(localCMSException.toString(), localCMSException);
      }
    }
  }
  
  private class EnvelopedGenerator
    extends CMSEnvelopedDataStreamGenerator
  {
    private String _encryptionOID;
    private SecretKey _encKey;
    private AlgorithmParameters _params;
    private ASN1EncodableVector _recipientInfos;
    
    private EnvelopedGenerator() {}
    
    protected OutputStream open(OutputStream paramOutputStream, String paramString, SecretKey paramSecretKey, AlgorithmParameters paramAlgorithmParameters, ASN1EncodableVector paramASN1EncodableVector, Provider paramProvider)
      throws NoSuchAlgorithmException, CMSException
    {
      this._encryptionOID = paramString;
      this._encKey = paramSecretKey;
      this._params = paramAlgorithmParameters;
      this._recipientInfos = paramASN1EncodableVector;
      return super.open(paramOutputStream, paramString, paramSecretKey, paramAlgorithmParameters, paramASN1EncodableVector, paramProvider);
    }
    
    OutputStream regenerate(OutputStream paramOutputStream, Provider paramProvider)
      throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
    {
      return super.open(paramOutputStream, this._encryptionOID, this._encKey, this._params, this._recipientInfos, paramProvider);
    }
  }
  
  private static class WrappingIOException
    extends IOException
  {
    private Throwable cause;
    
    WrappingIOException(String paramString, Throwable paramThrowable)
    {
      super();
      this.cause = paramThrowable;
    }
    
    public Throwable getCause()
    {
      return this.cause;
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\SMIMEEnvelopedGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */