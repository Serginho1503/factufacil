package org.bouncycastle.mail.smime.examples;

import java.util.Properties;
import javax.mail.Session;
import javax.mail.internet.MimeMessage;
import org.bouncycastle.mail.smime.SMIMECompressedParser;
import org.bouncycastle.mail.smime.SMIMEUtil;
import org.bouncycastle.mail.smime.util.FileBackedMimeBodyPart;
import org.bouncycastle.mail.smime.util.SharedFileInputStream;

public class ReadLargeCompressedMail
{
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    Properties localProperties = System.getProperties();
    Session localSession = Session.getDefaultInstance(localProperties, null);
    MimeMessage localMimeMessage = new MimeMessage(localSession, new SharedFileInputStream("compressed.message"));
    SMIMECompressedParser localSMIMECompressedParser = new SMIMECompressedParser(localMimeMessage);
    FileBackedMimeBodyPart localFileBackedMimeBodyPart = SMIMEUtil.toMimeBodyPart(localSMIMECompressedParser.getContent());
    ExampleUtils.dumpContent(localFileBackedMimeBodyPart, paramArrayOfString[0]);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\examples\ReadLargeCompressedMail.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */