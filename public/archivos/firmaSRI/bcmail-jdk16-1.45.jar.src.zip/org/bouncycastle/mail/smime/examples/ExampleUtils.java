package org.bouncycastle.mail.smime.examples;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.security.KeyStore;
import java.util.Enumeration;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;

public class ExampleUtils
{
  public static void dumpContent(MimeBodyPart paramMimeBodyPart, String paramString)
    throws MessagingException, IOException
  {
    System.out.println("content type: " + paramMimeBodyPart.getContentType());
    FileOutputStream localFileOutputStream = new FileOutputStream(paramString);
    InputStream localInputStream = paramMimeBodyPart.getInputStream();
    byte[] arrayOfByte = new byte['✐'];
    int i;
    while ((i = localInputStream.read(arrayOfByte, 0, arrayOfByte.length)) > 0) {
      localFileOutputStream.write(arrayOfByte, 0, i);
    }
    localFileOutputStream.close();
  }
  
  public static String findKeyAlias(KeyStore paramKeyStore, String paramString, char[] paramArrayOfChar)
    throws Exception
  {
    paramKeyStore.load(new FileInputStream(paramString), paramArrayOfChar);
    Enumeration localEnumeration = paramKeyStore.aliases();
    Object localObject = null;
    while (localEnumeration.hasMoreElements())
    {
      String str = (String)localEnumeration.nextElement();
      if (paramKeyStore.isKeyEntry(str)) {
        localObject = str;
      }
    }
    if (localObject == null) {
      throw new IllegalArgumentException("can't find a private key in keyStore: " + paramString);
    }
    return (String)localObject;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\examples\ExampleUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */