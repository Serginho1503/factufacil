package org.bouncycastle.mail.smime;

import java.io.IOException;
import java.io.InputStream;
import javax.mail.MessagingException;
import javax.mail.Part;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimePart;
import org.bouncycastle.cms.CMSEnvelopedData;
import org.bouncycastle.cms.CMSException;

public class SMIMEEnveloped
  extends CMSEnvelopedData
{
  MimePart message;
  
  private static InputStream getInputStream(Part paramPart)
    throws MessagingException
  {
    try
    {
      return paramPart.getInputStream();
    }
    catch (IOException localIOException)
    {
      throw new MessagingException("can't extract input stream: " + localIOException);
    }
  }
  
  public SMIMEEnveloped(MimeBodyPart paramMimeBodyPart)
    throws MessagingException, CMSException
  {
    super(getInputStream(paramMimeBodyPart));
    this.message = paramMimeBodyPart;
  }
  
  public SMIMEEnveloped(MimeMessage paramMimeMessage)
    throws MessagingException, CMSException
  {
    super(getInputStream(paramMimeMessage));
    this.message = paramMimeMessage;
  }
  
  public MimePart getEncryptedContent()
  {
    return this.message;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\SMIMEEnveloped.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */