package org.bouncycastle.mail.smime;

import java.io.IOException;
import java.io.OutputStream;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.CMSProcessable;
import org.bouncycastle.mail.smime.util.CRLFOutputStream;

public class CMSProcessableBodyPartOutbound
  implements CMSProcessable
{
  private BodyPart bodyPart;
  private String defaultContentTransferEncoding;
  
  public CMSProcessableBodyPartOutbound(BodyPart paramBodyPart)
  {
    this.bodyPart = paramBodyPart;
  }
  
  public CMSProcessableBodyPartOutbound(BodyPart paramBodyPart, String paramString)
  {
    this.bodyPart = paramBodyPart;
    this.defaultContentTransferEncoding = paramString;
  }
  
  public void write(OutputStream paramOutputStream)
    throws IOException, CMSException
  {
    try
    {
      if (SMIMEUtil.isCanonicalisationRequired((MimeBodyPart)this.bodyPart, this.defaultContentTransferEncoding)) {
        paramOutputStream = new CRLFOutputStream(paramOutputStream);
      }
      this.bodyPart.writeTo(paramOutputStream);
    }
    catch (MessagingException localMessagingException)
    {
      throw new CMSException("can't write BodyPart to stream.", localMessagingException);
    }
  }
  
  public Object getContent()
  {
    return this.bodyPart;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\CMSProcessableBodyPartOutbound.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */