package org.bouncycastle.mail.smime.handlers;

import java.awt.datatransfer.DataFlavor;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.activation.ActivationDataFlavor;
import javax.activation.DataContentHandler;
import javax.activation.DataSource;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;

public class x_pkcs7_signature
  implements DataContentHandler
{
  private static final ActivationDataFlavor ADF = new ActivationDataFlavor(MimeBodyPart.class, "application/x-pkcs7-signature", "Signature");
  private static final DataFlavor[] ADFs = { ADF };
  
  public Object getContent(DataSource paramDataSource)
    throws IOException
  {
    return paramDataSource.getInputStream();
  }
  
  public Object getTransferData(DataFlavor paramDataFlavor, DataSource paramDataSource)
    throws IOException
  {
    if (ADF.equals(paramDataFlavor)) {
      return getContent(paramDataSource);
    }
    return null;
  }
  
  public DataFlavor[] getTransferDataFlavors()
  {
    return ADFs;
  }
  
  public void writeTo(Object paramObject, String paramString, OutputStream paramOutputStream)
    throws IOException
  {
    if ((paramObject instanceof MimeBodyPart))
    {
      try
      {
        ((MimeBodyPart)paramObject).writeTo(paramOutputStream);
      }
      catch (MessagingException localMessagingException)
      {
        throw new IOException(localMessagingException.getMessage());
      }
    }
    else if ((paramObject instanceof byte[]))
    {
      paramOutputStream.write((byte[])paramObject);
    }
    else if ((paramObject instanceof InputStream))
    {
      InputStream localInputStream = (InputStream)paramObject;
      int i;
      while ((i = localInputStream.read()) >= 0) {
        paramOutputStream.write(i);
      }
    }
    else
    {
      throw new IOException("unknown object in writeTo " + paramObject);
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\handlers\x_pkcs7_signature.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */