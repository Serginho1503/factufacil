package org.bouncycastle.mail.smime.examples;

import java.io.FileInputStream;
import java.io.PrintStream;
import java.util.Properties;
import javax.mail.Session;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import org.bouncycastle.mail.smime.SMIMECompressed;
import org.bouncycastle.mail.smime.SMIMEUtil;

public class ReadCompressedMail
{
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    Properties localProperties = System.getProperties();
    Session localSession = Session.getDefaultInstance(localProperties, null);
    MimeMessage localMimeMessage = new MimeMessage(localSession, new FileInputStream("compressed.message"));
    SMIMECompressed localSMIMECompressed = new SMIMECompressed(localMimeMessage);
    MimeBodyPart localMimeBodyPart = SMIMEUtil.toMimeBodyPart(localSMIMECompressed.getContent());
    System.out.println("Message Contents");
    System.out.println("----------------");
    System.out.println(localMimeBodyPart.getContent());
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\examples\ReadCompressedMail.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */