package org.bouncycastle.mail.smime;

import java.io.IOException;
import java.io.OutputStream;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.CMSProcessable;

public class CMSProcessableBodyPartInbound
  implements CMSProcessable
{
  private final BodyPart bodyPart;
  private final String defaultContentTransferEncoding;
  
  public CMSProcessableBodyPartInbound(BodyPart paramBodyPart)
  {
    this(paramBodyPart, "7bit");
  }
  
  public CMSProcessableBodyPartInbound(BodyPart paramBodyPart, String paramString)
  {
    this.bodyPart = paramBodyPart;
    this.defaultContentTransferEncoding = paramString;
  }
  
  public void write(OutputStream paramOutputStream)
    throws IOException, CMSException
  {
    try
    {
      SMIMEUtil.outputBodyPart(paramOutputStream, this.bodyPart, this.defaultContentTransferEncoding);
    }
    catch (MessagingException localMessagingException)
    {
      throw new CMSException("can't write BodyPart to stream: " + localMessagingException, localMessagingException);
    }
  }
  
  public Object getContent()
  {
    return this.bodyPart;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\CMSProcessableBodyPartInbound.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */