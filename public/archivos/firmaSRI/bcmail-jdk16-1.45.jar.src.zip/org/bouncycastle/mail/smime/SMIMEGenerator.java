package org.bouncycastle.mail.smime;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.KeyGenerator;
import javax.mail.Header;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import org.bouncycastle.cms.CMSEnvelopedGenerator;
import org.bouncycastle.util.Strings;

public class SMIMEGenerator
{
  private static Map BASE_CIPHER_NAMES = new HashMap();
  protected boolean useBase64 = true;
  protected String encoding = "base64";
  
  public void setContentTransferEncoding(String paramString)
  {
    this.encoding = paramString;
    this.useBase64 = Strings.toLowerCase(paramString).equals("base64");
  }
  
  protected MimeBodyPart makeContentBodyPart(MimeBodyPart paramMimeBodyPart)
    throws SMIMEException
  {
    try
    {
      MimeMessage localMimeMessage = new MimeMessage((Session)null);
      Enumeration localEnumeration = paramMimeBodyPart.getAllHeaders();
      localMimeMessage.setDataHandler(paramMimeBodyPart.getDataHandler());
      Header localHeader;
      while (localEnumeration.hasMoreElements())
      {
        localHeader = (Header)localEnumeration.nextElement();
        localMimeMessage.setHeader(localHeader.getName(), localHeader.getValue());
      }
      localMimeMessage.saveChanges();
      localEnumeration = localMimeMessage.getAllHeaders();
      while (localEnumeration.hasMoreElements())
      {
        localHeader = (Header)localEnumeration.nextElement();
        if (Strings.toLowerCase(localHeader.getName()).startsWith("content-")) {
          paramMimeBodyPart.setHeader(localHeader.getName(), localHeader.getValue());
        }
      }
    }
    catch (MessagingException localMessagingException)
    {
      throw new SMIMEException("exception saving message state.", localMessagingException);
    }
    return paramMimeBodyPart;
  }
  
  protected MimeBodyPart makeContentBodyPart(MimeMessage paramMimeMessage)
    throws SMIMEException
  {
    MimeBodyPart localMimeBodyPart = new MimeBodyPart();
    try
    {
      paramMimeMessage.removeHeader("Message-Id");
      paramMimeMessage.removeHeader("Mime-Version");
      try
      {
        if ((paramMimeMessage.getContent() instanceof Multipart))
        {
          localMimeBodyPart.setContent(paramMimeMessage.getRawInputStream(), paramMimeMessage.getContentType());
          extractHeaders(localMimeBodyPart, paramMimeMessage);
          return localMimeBodyPart;
        }
      }
      catch (MessagingException localMessagingException1) {}
      localMimeBodyPart.setContent(paramMimeMessage.getContent(), paramMimeMessage.getContentType());
      localMimeBodyPart.setDataHandler(paramMimeMessage.getDataHandler());
      extractHeaders(localMimeBodyPart, paramMimeMessage);
    }
    catch (MessagingException localMessagingException2)
    {
      throw new SMIMEException("exception saving message state.", localMessagingException2);
    }
    catch (IOException localIOException)
    {
      throw new SMIMEException("exception getting message content.", localIOException);
    }
    return localMimeBodyPart;
  }
  
  private void extractHeaders(MimeBodyPart paramMimeBodyPart, MimeMessage paramMimeMessage)
    throws MessagingException
  {
    Enumeration localEnumeration = paramMimeMessage.getAllHeaders();
    while (localEnumeration.hasMoreElements())
    {
      Header localHeader = (Header)localEnumeration.nextElement();
      paramMimeBodyPart.setHeader(localHeader.getName(), localHeader.getValue());
    }
  }
  
  protected KeyGenerator createSymmetricKeyGenerator(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException
  {
    try
    {
      return createKeyGenerator(paramString, paramProvider);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException1)
    {
      try
      {
        String str = (String)BASE_CIPHER_NAMES.get(paramString);
        if (str != null) {
          return createKeyGenerator(str, paramProvider);
        }
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException2) {}
      if (paramProvider != null) {
        return createSymmetricKeyGenerator(paramString, null);
      }
      throw localNoSuchAlgorithmException1;
    }
  }
  
  private KeyGenerator createKeyGenerator(String paramString, Provider paramProvider)
    throws NoSuchAlgorithmException
  {
    if (paramProvider != null) {
      return KeyGenerator.getInstance(paramString, paramProvider);
    }
    return KeyGenerator.getInstance(paramString);
  }
  
  static
  {
    BASE_CIPHER_NAMES.put(CMSEnvelopedGenerator.DES_EDE3_CBC, "DESEDE");
    BASE_CIPHER_NAMES.put(CMSEnvelopedGenerator.AES128_CBC, "AES");
    BASE_CIPHER_NAMES.put(CMSEnvelopedGenerator.AES192_CBC, "AES");
    BASE_CIPHER_NAMES.put(CMSEnvelopedGenerator.AES256_CBC, "AES");
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\SMIMEGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */