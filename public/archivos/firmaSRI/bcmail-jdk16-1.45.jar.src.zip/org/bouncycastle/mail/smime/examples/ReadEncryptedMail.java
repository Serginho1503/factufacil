package org.bouncycastle.mail.smime.examples;

import java.io.FileInputStream;
import java.io.PrintStream;
import java.security.KeyStore;
import java.security.cert.X509Certificate;
import java.util.Enumeration;
import java.util.Properties;
import javax.mail.Session;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.security.auth.x500.X500Principal;
import org.bouncycastle.cms.RecipientId;
import org.bouncycastle.cms.RecipientInformation;
import org.bouncycastle.cms.RecipientInformationStore;
import org.bouncycastle.mail.smime.SMIMEEnveloped;
import org.bouncycastle.mail.smime.SMIMEUtil;

public class ReadEncryptedMail
{
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    if (paramArrayOfString.length != 2)
    {
      System.err.println("usage: ReadEncryptedMail pkcs12Keystore password");
      System.exit(0);
    }
    KeyStore localKeyStore = KeyStore.getInstance("PKCS12", "BC");
    localKeyStore.load(new FileInputStream(paramArrayOfString[0]), paramArrayOfString[1].toCharArray());
    Enumeration localEnumeration = localKeyStore.aliases();
    Object localObject1 = null;
    while (localEnumeration.hasMoreElements())
    {
      localObject2 = (String)localEnumeration.nextElement();
      if (localKeyStore.isKeyEntry((String)localObject2)) {
        localObject1 = localObject2;
      }
    }
    if (localObject1 == null)
    {
      System.err.println("can't find a private key!");
      System.exit(0);
    }
    Object localObject2 = (X509Certificate)localKeyStore.getCertificate((String)localObject1);
    RecipientId localRecipientId = new RecipientId();
    localRecipientId.setSerialNumber(((X509Certificate)localObject2).getSerialNumber());
    localRecipientId.setIssuer(((X509Certificate)localObject2).getIssuerX500Principal().getEncoded());
    Properties localProperties = System.getProperties();
    Session localSession = Session.getDefaultInstance(localProperties, null);
    MimeMessage localMimeMessage = new MimeMessage(localSession, new FileInputStream("encrypted.message"));
    SMIMEEnveloped localSMIMEEnveloped = new SMIMEEnveloped(localMimeMessage);
    RecipientInformationStore localRecipientInformationStore = localSMIMEEnveloped.getRecipientInfos();
    RecipientInformation localRecipientInformation = localRecipientInformationStore.get(localRecipientId);
    MimeBodyPart localMimeBodyPart = SMIMEUtil.toMimeBodyPart(localRecipientInformation.getContent(localKeyStore.getKey((String)localObject1, null), "BC"));
    System.out.println("Message Contents");
    System.out.println("----------------");
    System.out.println(localMimeBodyPart.getContent());
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\examples\ReadEncryptedMail.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */