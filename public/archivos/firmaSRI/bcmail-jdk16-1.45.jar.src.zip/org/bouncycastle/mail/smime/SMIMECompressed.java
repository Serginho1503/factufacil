package org.bouncycastle.mail.smime;

import java.io.IOException;
import java.io.InputStream;
import javax.mail.MessagingException;
import javax.mail.Part;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimePart;
import org.bouncycastle.cms.CMSCompressedData;
import org.bouncycastle.cms.CMSException;

public class SMIMECompressed
  extends CMSCompressedData
{
  MimePart message;
  
  private static InputStream getInputStream(Part paramPart)
    throws MessagingException
  {
    try
    {
      return paramPart.getInputStream();
    }
    catch (IOException localIOException)
    {
      throw new MessagingException("can't extract input stream: " + localIOException);
    }
  }
  
  public SMIMECompressed(MimeBodyPart paramMimeBodyPart)
    throws MessagingException, CMSException
  {
    super(getInputStream(paramMimeBodyPart));
    this.message = paramMimeBodyPart;
  }
  
  public SMIMECompressed(MimeMessage paramMimeMessage)
    throws MessagingException, CMSException
  {
    super(getInputStream(paramMimeMessage));
    this.message = paramMimeMessage;
  }
  
  public MimePart getCompressedContent()
  {
    return this.message;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\SMIMECompressed.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */