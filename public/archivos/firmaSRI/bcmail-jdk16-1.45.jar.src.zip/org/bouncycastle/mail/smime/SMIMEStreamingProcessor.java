package org.bouncycastle.mail.smime;

import java.io.IOException;
import java.io.OutputStream;

public abstract interface SMIMEStreamingProcessor
{
  public abstract void write(OutputStream paramOutputStream)
    throws IOException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\SMIMEStreamingProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */