package org.bouncycastle.mail.smime.examples;

import java.io.PrintStream;
import java.security.cert.CertStore;
import java.security.cert.X509Certificate;
import java.util.Collection;
import java.util.Iterator;
import java.util.Properties;
import javax.mail.Session;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import org.bouncycastle.cms.SignerInformation;
import org.bouncycastle.cms.SignerInformationStore;
import org.bouncycastle.mail.smime.SMIMESignedParser;
import org.bouncycastle.mail.smime.util.SharedFileInputStream;

public class ReadLargeSignedMail
{
  private static void verify(SMIMESignedParser paramSMIMESignedParser)
    throws Exception
  {
    CertStore localCertStore = paramSMIMESignedParser.getCertificatesAndCRLs("Collection", "BC");
    SignerInformationStore localSignerInformationStore = paramSMIMESignedParser.getSignerInfos();
    Collection localCollection1 = localSignerInformationStore.getSigners();
    Iterator localIterator1 = localCollection1.iterator();
    while (localIterator1.hasNext())
    {
      SignerInformation localSignerInformation = (SignerInformation)localIterator1.next();
      Collection localCollection2 = localCertStore.getCertificates(localSignerInformation.getSID());
      Iterator localIterator2 = localCollection2.iterator();
      X509Certificate localX509Certificate = (X509Certificate)localIterator2.next();
      if (localSignerInformation.verify(localX509Certificate, "BC")) {
        System.out.println("signature verified");
      } else {
        System.out.println("signature failed!");
      }
    }
  }
  
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    Properties localProperties = System.getProperties();
    Session localSession = Session.getDefaultInstance(localProperties, null);
    MimeMessage localMimeMessage = new MimeMessage(localSession, new SharedFileInputStream("signed.message"));
    SMIMESignedParser localSMIMESignedParser;
    if (localMimeMessage.isMimeType("multipart/signed"))
    {
      localSMIMESignedParser = new SMIMESignedParser((MimeMultipart)localMimeMessage.getContent());
      System.out.println("Status:");
      verify(localSMIMESignedParser);
    }
    else if (localMimeMessage.isMimeType("application/pkcs7-mime"))
    {
      localSMIMESignedParser = new SMIMESignedParser(localMimeMessage);
      System.out.println("Status:");
      verify(localSMIMESignedParser);
    }
    else
    {
      System.err.println("Not a signed message!");
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\examples\ReadLargeSignedMail.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */