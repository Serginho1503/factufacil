package org.bouncycastle.mail.smime;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.Security;
import java.security.cert.CertificateParsingException;
import java.security.cert.X509Certificate;
import java.util.Enumeration;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.internet.ContentType;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import org.bouncycastle.asn1.cms.IssuerAndSerialNumber;
import org.bouncycastle.cms.CMSTypedStream;
import org.bouncycastle.jce.PrincipalUtil;
import org.bouncycastle.mail.smime.util.CRLFOutputStream;
import org.bouncycastle.mail.smime.util.FileBackedMimeBodyPart;

public class SMIMEUtil
{
  private static final int BUF_SIZE = 32760;
  
  static boolean isCanonicalisationRequired(MimeBodyPart paramMimeBodyPart, String paramString)
    throws MessagingException
  {
    String[] arrayOfString = paramMimeBodyPart.getHeader("Content-Transfer-Encoding");
    String str;
    if (arrayOfString == null) {
      str = paramString;
    } else {
      str = arrayOfString[0];
    }
    return !str.equalsIgnoreCase("binary");
  }
  
  public static Provider getProvider(String paramString)
    throws NoSuchProviderException
  {
    if (paramString != null)
    {
      Provider localProvider = Security.getProvider(paramString);
      if (localProvider != null) {
        return localProvider;
      }
      throw new NoSuchProviderException("provider " + paramString + " not found.");
    }
    return null;
  }
  
  static void outputPreamble(LineOutputStream paramLineOutputStream, MimeBodyPart paramMimeBodyPart, String paramString)
    throws MessagingException, IOException
  {
    InputStream localInputStream;
    try
    {
      localInputStream = paramMimeBodyPart.getRawInputStream();
    }
    catch (MessagingException localMessagingException)
    {
      return;
    }
    String str;
    while (((str = readLine(localInputStream)) != null) && (!str.equals(paramString))) {
      paramLineOutputStream.writeln(str);
    }
    localInputStream.close();
    if (str == null) {
      throw new MessagingException("no boundary found");
    }
  }
  
  static void outputPostamble(LineOutputStream paramLineOutputStream, MimeBodyPart paramMimeBodyPart, int paramInt, String paramString)
    throws MessagingException, IOException
  {
    InputStream localInputStream;
    try
    {
      localInputStream = paramMimeBodyPart.getRawInputStream();
    }
    catch (MessagingException localMessagingException)
    {
      return;
    }
    int i = paramInt + 1;
    String str;
    while ((str = readLine(localInputStream)) != null) {
      if (str.startsWith(paramString))
      {
        i--;
        if (i == 0) {
          break;
        }
      }
    }
    while ((str = readLine(localInputStream)) != null) {
      paramLineOutputStream.writeln(str);
    }
    localInputStream.close();
    if (i != 0) {
      throw new MessagingException("all boundaries not found for: " + paramString);
    }
  }
  
  static void outputPostamble(LineOutputStream paramLineOutputStream, BodyPart paramBodyPart1, String paramString, BodyPart paramBodyPart2)
    throws MessagingException, IOException
  {
    InputStream localInputStream;
    try
    {
      localInputStream = ((MimeBodyPart)paramBodyPart1).getRawInputStream();
    }
    catch (MessagingException localMessagingException)
    {
      return;
    }
    MimeMultipart localMimeMultipart = (MimeMultipart)paramBodyPart2.getContent();
    ContentType localContentType = new ContentType(localMimeMultipart.getContentType());
    String str1 = "--" + localContentType.getParameter("boundary");
    int i = localMimeMultipart.getCount() + 1;
    String str2;
    while ((i != 0) && ((str2 = readLine(localInputStream)) != null)) {
      if (str2.startsWith(str1)) {
        i--;
      }
    }
    while (((str2 = readLine(localInputStream)) != null) && (!str2.startsWith(paramString))) {
      paramLineOutputStream.writeln(str2);
    }
    localInputStream.close();
  }
  
  private static String readLine(InputStream paramInputStream)
    throws IOException
  {
    StringBuffer localStringBuffer = new StringBuffer();
    int i;
    while (((i = paramInputStream.read()) >= 0) && (i != 10)) {
      if (i != 13) {
        localStringBuffer.append((char)i);
      }
    }
    if ((i < 0) && (localStringBuffer.length() == 0)) {
      return null;
    }
    return localStringBuffer.toString();
  }
  
  static void outputBodyPart(OutputStream paramOutputStream, BodyPart paramBodyPart, String paramString)
    throws MessagingException, IOException
  {
    if ((paramBodyPart instanceof MimeBodyPart))
    {
      MimeBodyPart localMimeBodyPart = (MimeBodyPart)paramBodyPart;
      String[] arrayOfString = localMimeBodyPart.getHeader("Content-Transfer-Encoding");
      Object localObject1;
      int i;
      if ((localMimeBodyPart.getContent() instanceof MimeMultipart))
      {
        MimeMultipart localMimeMultipart = (MimeMultipart)paramBodyPart.getContent();
        localObject1 = new ContentType(localMimeMultipart.getContentType());
        String str2 = "--" + ((ContentType)localObject1).getParameter("boundary");
        localObject2 = new LineOutputStream(paramOutputStream);
        localObject3 = localMimeBodyPart.getAllHeaderLines();
        while (((Enumeration)localObject3).hasMoreElements())
        {
          String str3 = (String)((Enumeration)localObject3).nextElement();
          ((LineOutputStream)localObject2).writeln(str3);
        }
        ((LineOutputStream)localObject2).writeln();
        outputPreamble((LineOutputStream)localObject2, localMimeBodyPart, str2);
        for (i = 0; i < localMimeMultipart.getCount(); i++)
        {
          ((LineOutputStream)localObject2).writeln(str2);
          BodyPart localBodyPart = localMimeMultipart.getBodyPart(i);
          outputBodyPart(paramOutputStream, localBodyPart, paramString);
          if (!(localBodyPart.getContent() instanceof MimeMultipart)) {
            ((LineOutputStream)localObject2).writeln();
          } else {
            outputPostamble((LineOutputStream)localObject2, localMimeBodyPart, str2, localBodyPart);
          }
        }
        ((LineOutputStream)localObject2).writeln(str2 + "--");
        outputPostamble((LineOutputStream)localObject2, localMimeBodyPart, localMimeMultipart.getCount(), str2);
        return;
      }
      String str1;
      if (arrayOfString == null) {
        str1 = paramString;
      } else {
        str1 = arrayOfString[0];
      }
      if ((!str1.equalsIgnoreCase("base64")) && (!str1.equalsIgnoreCase("quoted-printable")))
      {
        if (!str1.equalsIgnoreCase("binary")) {
          paramOutputStream = new CRLFOutputStream(paramOutputStream);
        }
        paramBodyPart.writeTo(paramOutputStream);
        paramOutputStream.flush();
        return;
      }
      boolean bool = str1.equalsIgnoreCase("base64");
      try
      {
        localObject1 = localMimeBodyPart.getRawInputStream();
      }
      catch (MessagingException localMessagingException)
      {
        paramOutputStream = new CRLFOutputStream(paramOutputStream);
        paramBodyPart.writeTo(paramOutputStream);
        paramOutputStream.flush();
        return;
      }
      LineOutputStream localLineOutputStream = new LineOutputStream(paramOutputStream);
      Object localObject2 = localMimeBodyPart.getAllHeaderLines();
      while (((Enumeration)localObject2).hasMoreElements())
      {
        localObject3 = (String)((Enumeration)localObject2).nextElement();
        localLineOutputStream.writeln((String)localObject3);
      }
      localLineOutputStream.writeln();
      localLineOutputStream.flush();
      if (bool) {
        localObject2 = new Base64CRLFOutputStream(paramOutputStream);
      } else {
        localObject2 = new CRLFOutputStream(paramOutputStream);
      }
      Object localObject3 = new byte['翸'];
      while ((i = ((InputStream)localObject1).read((byte[])localObject3, 0, localObject3.length)) > 0) {
        ((OutputStream)localObject2).write((byte[])localObject3, 0, i);
      }
      ((OutputStream)localObject2).flush();
    }
    else
    {
      if (!paramString.equalsIgnoreCase("binary")) {
        paramOutputStream = new CRLFOutputStream(paramOutputStream);
      }
      paramBodyPart.writeTo(paramOutputStream);
      paramOutputStream.flush();
    }
  }
  
  public static MimeBodyPart toMimeBodyPart(byte[] paramArrayOfByte)
    throws SMIMEException
  {
    return toMimeBodyPart(new ByteArrayInputStream(paramArrayOfByte));
  }
  
  public static MimeBodyPart toMimeBodyPart(InputStream paramInputStream)
    throws SMIMEException
  {
    try
    {
      return new MimeBodyPart(paramInputStream);
    }
    catch (MessagingException localMessagingException)
    {
      throw new SMIMEException("exception creating body part.", localMessagingException);
    }
  }
  
  static FileBackedMimeBodyPart toWriteOnceBodyPart(CMSTypedStream paramCMSTypedStream)
    throws SMIMEException
  {
    try
    {
      return new WriteOnceFileBackedMimeBodyPart(paramCMSTypedStream.getContentStream(), File.createTempFile("bcMail", ".mime"));
    }
    catch (IOException localIOException)
    {
      throw new SMIMEException("IOException creating tmp file:" + localIOException.getMessage(), localIOException);
    }
    catch (MessagingException localMessagingException)
    {
      throw new SMIMEException("can't create part: " + localMessagingException, localMessagingException);
    }
  }
  
  public static FileBackedMimeBodyPart toMimeBodyPart(CMSTypedStream paramCMSTypedStream)
    throws SMIMEException
  {
    try
    {
      return toMimeBodyPart(paramCMSTypedStream, File.createTempFile("bcMail", ".mime"));
    }
    catch (IOException localIOException)
    {
      throw new SMIMEException("IOException creating tmp file:" + localIOException.getMessage(), localIOException);
    }
  }
  
  public static FileBackedMimeBodyPart toMimeBodyPart(CMSTypedStream paramCMSTypedStream, File paramFile)
    throws SMIMEException
  {
    try
    {
      return new FileBackedMimeBodyPart(paramCMSTypedStream.getContentStream(), paramFile);
    }
    catch (IOException localIOException)
    {
      throw new SMIMEException("can't save content to file: " + localIOException, localIOException);
    }
    catch (MessagingException localMessagingException)
    {
      throw new SMIMEException("can't create part: " + localMessagingException, localMessagingException);
    }
  }
  
  public static IssuerAndSerialNumber createIssuerAndSerialNumberFor(X509Certificate paramX509Certificate)
    throws CertificateParsingException
  {
    try
    {
      return new IssuerAndSerialNumber(PrincipalUtil.getIssuerX509Principal(paramX509Certificate), paramX509Certificate.getSerialNumber());
    }
    catch (Exception localException)
    {
      throw new CertificateParsingException("exception extracting issuer and serial number: " + localException);
    }
  }
  
  static class Base64CRLFOutputStream
    extends FilterOutputStream
  {
    protected int lastb = -1;
    protected static byte[] newline = new byte[2];
    private boolean isCrlfStream;
    
    public Base64CRLFOutputStream(OutputStream paramOutputStream)
    {
      super();
    }
    
    public void write(int paramInt)
      throws IOException
    {
      if (paramInt == 13) {
        this.out.write(newline);
      } else if (paramInt == 10)
      {
        if (this.lastb != 13)
        {
          if ((!this.isCrlfStream) || (this.lastb != 10)) {
            this.out.write(newline);
          }
        }
        else {
          this.isCrlfStream = true;
        }
      }
      else {
        this.out.write(paramInt);
      }
      this.lastb = paramInt;
    }
    
    public void write(byte[] paramArrayOfByte)
      throws IOException
    {
      write(paramArrayOfByte, 0, paramArrayOfByte.length);
    }
    
    public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {
      for (int i = paramInt1; i != paramInt1 + paramInt2; i++) {
        write(paramArrayOfByte[i]);
      }
    }
    
    public void writeln()
      throws IOException
    {
      this.out.write(newline);
    }
    
    static
    {
      newline[0] = 13;
      newline[1] = 10;
    }
  }
  
  static class LineOutputStream
    extends FilterOutputStream
  {
    private static byte[] newline = new byte[2];
    
    public LineOutputStream(OutputStream paramOutputStream)
    {
      super();
    }
    
    public void writeln(String paramString)
      throws MessagingException
    {
      try
      {
        byte[] arrayOfByte = getBytes(paramString);
        this.out.write(arrayOfByte);
        this.out.write(newline);
      }
      catch (Exception localException)
      {
        throw new MessagingException("IOException", localException);
      }
    }
    
    public void writeln()
      throws MessagingException
    {
      try
      {
        this.out.write(newline);
      }
      catch (Exception localException)
      {
        throw new MessagingException("IOException", localException);
      }
    }
    
    private static byte[] getBytes(String paramString)
    {
      char[] arrayOfChar = paramString.toCharArray();
      int i = arrayOfChar.length;
      byte[] arrayOfByte = new byte[i];
      int j = 0;
      while (j < i) {
        arrayOfByte[j] = ((byte)arrayOfChar[(j++)]);
      }
      return arrayOfByte;
    }
    
    static
    {
      newline[0] = 13;
      newline[1] = 10;
    }
  }
  
  private static class WriteOnceFileBackedMimeBodyPart
    extends FileBackedMimeBodyPart
  {
    public WriteOnceFileBackedMimeBodyPart(InputStream paramInputStream, File paramFile)
      throws MessagingException, IOException
    {
      super(paramFile);
    }
    
    public void writeTo(OutputStream paramOutputStream)
      throws MessagingException, IOException
    {
      super.writeTo(paramOutputStream);
      dispose();
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\SMIMEUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */