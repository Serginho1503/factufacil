package org.bouncycastle.mail.smime.handlers;

import java.awt.datatransfer.DataFlavor;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.activation.ActivationDataFlavor;
import javax.activation.DataContentHandler;
import javax.activation.DataSource;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;
import org.bouncycastle.mail.smime.SMIMEStreamingProcessor;

public class PKCS7ContentHandler
  implements DataContentHandler
{
  private final ActivationDataFlavor _adf;
  private final DataFlavor[] _dfs;
  
  PKCS7ContentHandler(ActivationDataFlavor paramActivationDataFlavor, DataFlavor[] paramArrayOfDataFlavor)
  {
    this._adf = paramActivationDataFlavor;
    this._dfs = paramArrayOfDataFlavor;
  }
  
  public Object getContent(DataSource paramDataSource)
    throws IOException
  {
    return paramDataSource.getInputStream();
  }
  
  public Object getTransferData(DataFlavor paramDataFlavor, DataSource paramDataSource)
    throws IOException
  {
    if (this._adf.equals(paramDataFlavor)) {
      return getContent(paramDataSource);
    }
    return null;
  }
  
  public DataFlavor[] getTransferDataFlavors()
  {
    return this._dfs;
  }
  
  public void writeTo(Object paramObject, String paramString, OutputStream paramOutputStream)
    throws IOException
  {
    if ((paramObject instanceof MimeBodyPart))
    {
      try
      {
        ((MimeBodyPart)paramObject).writeTo(paramOutputStream);
      }
      catch (MessagingException localMessagingException)
      {
        throw new IOException(localMessagingException.getMessage());
      }
    }
    else if ((paramObject instanceof byte[]))
    {
      paramOutputStream.write((byte[])paramObject);
    }
    else if ((paramObject instanceof InputStream))
    {
      Object localObject = (InputStream)paramObject;
      if (!(localObject instanceof BufferedInputStream)) {
        localObject = new BufferedInputStream((InputStream)localObject);
      }
      int i;
      while ((i = ((InputStream)localObject).read()) >= 0) {
        paramOutputStream.write(i);
      }
    }
    else if ((paramObject instanceof SMIMEStreamingProcessor))
    {
      SMIMEStreamingProcessor localSMIMEStreamingProcessor = (SMIMEStreamingProcessor)paramObject;
      localSMIMEStreamingProcessor.write(paramOutputStream);
    }
    else
    {
      throw new IOException("unknown object in writeTo " + paramObject);
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\handlers\PKCS7ContentHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */