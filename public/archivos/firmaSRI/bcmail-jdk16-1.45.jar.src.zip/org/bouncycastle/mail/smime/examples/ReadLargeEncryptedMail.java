package org.bouncycastle.mail.smime.examples;

import java.io.PrintStream;
import java.security.KeyStore;
import java.security.cert.X509Certificate;
import java.util.Properties;
import javax.mail.Session;
import javax.mail.internet.MimeMessage;
import javax.security.auth.x500.X500Principal;
import org.bouncycastle.cms.RecipientId;
import org.bouncycastle.cms.RecipientInformation;
import org.bouncycastle.cms.RecipientInformationStore;
import org.bouncycastle.mail.smime.SMIMEEnvelopedParser;
import org.bouncycastle.mail.smime.SMIMEUtil;
import org.bouncycastle.mail.smime.util.FileBackedMimeBodyPart;
import org.bouncycastle.mail.smime.util.SharedFileInputStream;

public class ReadLargeEncryptedMail
{
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    if (paramArrayOfString.length != 3)
    {
      System.err.println("usage: ReadLargeEncryptedMail pkcs12Keystore password outputFile");
      System.exit(0);
    }
    KeyStore localKeyStore = KeyStore.getInstance("PKCS12", "BC");
    String str = ExampleUtils.findKeyAlias(localKeyStore, paramArrayOfString[0], paramArrayOfString[1].toCharArray());
    X509Certificate localX509Certificate = (X509Certificate)localKeyStore.getCertificate(str);
    RecipientId localRecipientId = new RecipientId();
    localRecipientId.setSerialNumber(localX509Certificate.getSerialNumber());
    localRecipientId.setIssuer(localX509Certificate.getIssuerX500Principal().getEncoded());
    Properties localProperties = System.getProperties();
    Session localSession = Session.getDefaultInstance(localProperties, null);
    MimeMessage localMimeMessage = new MimeMessage(localSession, new SharedFileInputStream("encrypted.message"));
    SMIMEEnvelopedParser localSMIMEEnvelopedParser = new SMIMEEnvelopedParser(localMimeMessage);
    RecipientInformationStore localRecipientInformationStore = localSMIMEEnvelopedParser.getRecipientInfos();
    RecipientInformation localRecipientInformation = localRecipientInformationStore.get(localRecipientId);
    FileBackedMimeBodyPart localFileBackedMimeBodyPart = SMIMEUtil.toMimeBodyPart(localRecipientInformation.getContentStream(localKeyStore.getKey(str, null), "BC"));
    ExampleUtils.dumpContent(localFileBackedMimeBodyPart, paramArrayOfString[2]);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\examples\ReadLargeEncryptedMail.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */