package org.bouncycastle.mail.smime.examples;

import java.io.FileInputStream;
import java.io.PrintStream;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.Principal;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.cert.CertPath;
import java.security.cert.CertStore;
import java.security.cert.CertificateFactory;
import java.security.cert.CollectionCertStoreParameters;
import java.security.cert.PKIXParameters;
import java.security.cert.TrustAnchor;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;
import javax.mail.Session;
import javax.mail.internet.MimeMessage;
import javax.security.auth.x500.X500Principal;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.cms.SignerInformation;
import org.bouncycastle.cms.SignerInformationStore;
import org.bouncycastle.i18n.ErrorBundle;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.mail.smime.validator.SignedMailValidator;
import org.bouncycastle.mail.smime.validator.SignedMailValidator.ValidationResult;
import org.bouncycastle.x509.PKIXCertPathReviewer;
import org.bouncycastle.x509.extension.X509ExtensionUtil;

public class ValidateSignedMail
{
  public static final boolean useCaCerts = false;
  public static final int TITLE = 0;
  public static final int TEXT = 1;
  public static final int SUMMARY = 2;
  public static final int DETAIL = 3;
  static int dbgLvl = 3;
  private static final String RESOURCE_NAME = "org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages";
  
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    Security.addProvider(new BouncyCastleProvider());
    Properties localProperties = System.getProperties();
    Session localSession = Session.getDefaultInstance(localProperties, null);
    MimeMessage localMimeMessage = new MimeMessage(localSession, new FileInputStream("signed.message"));
    Object localObject1 = new HashSet();
    Object localObject2 = getTrustAnchor("trustanchor");
    if (localObject2 == null)
    {
      System.out.println("no trustanchor file found, using a dummy trustanchor");
      localObject2 = getDummyTrustAnchor();
    }
    ((Set)localObject1).add(localObject2);
    PKIXParameters localPKIXParameters = new PKIXParameters((Set)localObject1);
    localObject1 = new ArrayList();
    localObject2 = loadCRL("crl.file");
    if (localObject2 != null) {
      ((List)localObject1).add(localObject2);
    }
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters((Collection)localObject1), "BC");
    localPKIXParameters.addCertStore(localCertStore);
    localPKIXParameters.setRevocationEnabled(true);
    verifySignedMail(localMimeMessage, localPKIXParameters);
  }
  
  public static void verifySignedMail(MimeMessage paramMimeMessage, PKIXParameters paramPKIXParameters)
    throws Exception
  {
    Locale localLocale = Locale.ENGLISH;
    SignedMailValidator localSignedMailValidator = new SignedMailValidator(paramMimeMessage, paramPKIXParameters);
    Iterator localIterator = localSignedMailValidator.getSignerInformationStore().getSigners().iterator();
    while (localIterator.hasNext())
    {
      SignerInformation localSignerInformation = (SignerInformation)localIterator.next();
      SignedMailValidator.ValidationResult localValidationResult = localSignedMailValidator.getValidationResult(localSignerInformation);
      Object localObject2;
      Object localObject3;
      if (localValidationResult.isValidSignature())
      {
        localObject1 = new ErrorBundle("org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages", "SignedMailValidator.sigValid");
        System.out.println(((ErrorBundle)localObject1).getText(localLocale));
      }
      else
      {
        localObject1 = new ErrorBundle("org.bouncycastle.mail.smime.validator.SignedMailValidatorMessages", "SignedMailValidator.sigInvalid");
        System.out.println(((ErrorBundle)localObject1).getText(localLocale));
        System.out.println("Errors:");
        localObject2 = localValidationResult.getErrors().iterator();
        while (((Iterator)localObject2).hasNext())
        {
          localObject3 = (ErrorBundle)((Iterator)localObject2).next();
          if (dbgLvl == 3) {
            System.out.println("\t\t" + ((ErrorBundle)localObject3).getDetail(localLocale));
          } else {
            System.out.println("\t\t" + ((ErrorBundle)localObject3).getText(localLocale));
          }
        }
      }
      if (!localValidationResult.getNotifications().isEmpty())
      {
        System.out.println("Notifications:");
        localObject1 = localValidationResult.getNotifications().iterator();
        while (((Iterator)localObject1).hasNext())
        {
          localObject2 = (ErrorBundle)((Iterator)localObject1).next();
          if (dbgLvl == 3) {
            System.out.println("\t\t" + ((ErrorBundle)localObject2).getDetail(localLocale));
          } else {
            System.out.println("\t\t" + ((ErrorBundle)localObject2).getText(localLocale));
          }
        }
      }
      Object localObject1 = localValidationResult.getCertPathReview();
      if (localObject1 != null)
      {
        if (((PKIXCertPathReviewer)localObject1).isValidCertPath()) {
          System.out.println("Certificate path valid");
        } else {
          System.out.println("Certificate path invalid");
        }
        System.out.println("\nCertificate path validation results:");
        System.out.println("Errors:");
        localObject2 = ((PKIXCertPathReviewer)localObject1).getErrors(-1).iterator();
        while (((Iterator)localObject2).hasNext())
        {
          localObject3 = (ErrorBundle)((Iterator)localObject2).next();
          if (dbgLvl == 3) {
            System.out.println("\t\t" + ((ErrorBundle)localObject3).getDetail(localLocale));
          } else {
            System.out.println("\t\t" + ((ErrorBundle)localObject3).getText(localLocale));
          }
        }
        System.out.println("Notifications:");
        localObject3 = ((PKIXCertPathReviewer)localObject1).getNotifications(-1).iterator();
        while (((Iterator)localObject3).hasNext())
        {
          localObject4 = (ErrorBundle)((Iterator)localObject3).next();
          System.out.println("\t" + ((ErrorBundle)localObject4).getText(localLocale));
        }
        Object localObject4 = ((PKIXCertPathReviewer)localObject1).getCertPath().getCertificates().iterator();
        for (int i = 0; ((Iterator)localObject4).hasNext(); i++)
        {
          X509Certificate localX509Certificate = (X509Certificate)((Iterator)localObject4).next();
          System.out.println("\nCertificate " + i + "\n========");
          System.out.println("Issuer: " + localX509Certificate.getIssuerDN().getName());
          System.out.println("Subject: " + localX509Certificate.getSubjectDN().getName());
          System.out.println("\tErrors:");
          localObject2 = ((PKIXCertPathReviewer)localObject1).getErrors(i).iterator();
          ErrorBundle localErrorBundle;
          while (((Iterator)localObject2).hasNext())
          {
            localErrorBundle = (ErrorBundle)((Iterator)localObject2).next();
            if (dbgLvl == 3) {
              System.out.println("\t\t" + localErrorBundle.getDetail(localLocale));
            } else {
              System.out.println("\t\t" + localErrorBundle.getText(localLocale));
            }
          }
          System.out.println("\tNotifications:");
          localObject3 = ((PKIXCertPathReviewer)localObject1).getNotifications(i).iterator();
          while (((Iterator)localObject3).hasNext())
          {
            localErrorBundle = (ErrorBundle)((Iterator)localObject3).next();
            if (dbgLvl == 3) {
              System.out.println("\t\t" + localErrorBundle.getDetail(localLocale));
            } else {
              System.out.println("\t\t" + localErrorBundle.getText(localLocale));
            }
          }
        }
      }
    }
  }
  
  protected static TrustAnchor getTrustAnchor(String paramString)
    throws Exception
  {
    X509Certificate localX509Certificate = loadCert(paramString);
    if (localX509Certificate != null)
    {
      byte[] arrayOfByte = localX509Certificate.getExtensionValue(X509Extensions.NameConstraints.getId());
      if (arrayOfByte != null)
      {
        ASN1Object localASN1Object = X509ExtensionUtil.fromExtensionValue(arrayOfByte);
        return new TrustAnchor(localX509Certificate, localASN1Object.getDEREncoded());
      }
      return new TrustAnchor(localX509Certificate, null);
    }
    return null;
  }
  
  protected static X509Certificate loadCert(String paramString)
  {
    X509Certificate localX509Certificate = null;
    try
    {
      FileInputStream localFileInputStream = new FileInputStream(paramString);
      CertificateFactory localCertificateFactory = CertificateFactory.getInstance("X.509", "BC");
      localX509Certificate = (X509Certificate)localCertificateFactory.generateCertificate(localFileInputStream);
    }
    catch (Exception localException)
    {
      System.out.println("certfile \"" + paramString + "\" not found - classpath is " + System.getProperty("java.class.path"));
    }
    return localX509Certificate;
  }
  
  protected static X509CRL loadCRL(String paramString)
  {
    X509CRL localX509CRL = null;
    try
    {
      FileInputStream localFileInputStream = new FileInputStream(paramString);
      CertificateFactory localCertificateFactory = CertificateFactory.getInstance("X.509", "BC");
      localX509CRL = (X509CRL)localCertificateFactory.generateCRL(localFileInputStream);
    }
    catch (Exception localException)
    {
      System.out.println("crlfile \"" + paramString + "\" not found - classpath is " + System.getProperty("java.class.path"));
    }
    return localX509CRL;
  }
  
  private static TrustAnchor getDummyTrustAnchor()
    throws Exception
  {
    X500Principal localX500Principal = new X500Principal("CN=Dummy Trust Anchor");
    KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("RSA", "BC");
    localKeyPairGenerator.initialize(1024, new SecureRandom());
    PublicKey localPublicKey = localKeyPairGenerator.generateKeyPair().getPublic();
    return new TrustAnchor(localX500Principal, localPublicKey, null);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\examples\ValidateSignedMail.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */