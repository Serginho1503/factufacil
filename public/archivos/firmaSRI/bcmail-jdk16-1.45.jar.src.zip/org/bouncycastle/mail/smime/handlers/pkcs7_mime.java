package org.bouncycastle.mail.smime.handlers;

import java.awt.datatransfer.DataFlavor;
import javax.activation.ActivationDataFlavor;
import javax.mail.internet.MimeBodyPart;

public class pkcs7_mime
  extends PKCS7ContentHandler
{
  private static final ActivationDataFlavor ADF = new ActivationDataFlavor(MimeBodyPart.class, "application/pkcs7-mime", "Encrypted Data");
  private static final DataFlavor[] DFS = { ADF };
  
  public pkcs7_mime()
  {
    super(ADF, DFS);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\handlers\pkcs7_mime.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */