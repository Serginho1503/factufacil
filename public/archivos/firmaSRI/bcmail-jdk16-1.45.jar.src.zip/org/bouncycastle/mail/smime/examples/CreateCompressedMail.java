package org.bouncycastle.mail.smime.examples;

import java.io.FileOutputStream;
import java.util.Properties;
import javax.mail.Message.RecipientType;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import org.bouncycastle.mail.smime.SMIMECompressedGenerator;

public class CreateCompressedMail
{
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    SMIMECompressedGenerator localSMIMECompressedGenerator = new SMIMECompressedGenerator();
    MimeBodyPart localMimeBodyPart1 = new MimeBodyPart();
    localMimeBodyPart1.setText("Hello world!");
    MimeBodyPart localMimeBodyPart2 = localSMIMECompressedGenerator.generate(localMimeBodyPart1, "1.2.840.113549.1.9.16.3.8");
    Properties localProperties = System.getProperties();
    Session localSession = Session.getDefaultInstance(localProperties, null);
    InternetAddress localInternetAddress1 = new InternetAddress("\"Eric H. Echidna\"<eric@bouncycastle.org>");
    InternetAddress localInternetAddress2 = new InternetAddress("example@bouncycastle.org");
    MimeMessage localMimeMessage = new MimeMessage(localSession);
    localMimeMessage.setFrom(localInternetAddress1);
    localMimeMessage.setRecipient(Message.RecipientType.TO, localInternetAddress2);
    localMimeMessage.setSubject("example compressed message");
    localMimeMessage.setContent(localMimeBodyPart2.getContent(), localMimeBodyPart2.getContentType());
    localMimeMessage.saveChanges();
    localMimeMessage.writeTo(new FileOutputStream("compressed.message"));
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\examples\CreateCompressedMail.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */