package org.bouncycastle.mail.smime.examples;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Message.RecipientType;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import org.bouncycastle.mail.smime.SMIMEEnvelopedGenerator;

public class CreateLargeEncryptedMail
{
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    if (paramArrayOfString.length != 3)
    {
      System.err.println("usage: CreateLargeEncryptedMail pkcs12Keystore password inputFile");
      System.exit(0);
    }
    KeyStore localKeyStore = KeyStore.getInstance("PKCS12", "BC");
    String str = ExampleUtils.findKeyAlias(localKeyStore, paramArrayOfString[0], paramArrayOfString[1].toCharArray());
    Certificate[] arrayOfCertificate = localKeyStore.getCertificateChain(str);
    SMIMEEnvelopedGenerator localSMIMEEnvelopedGenerator = new SMIMEEnvelopedGenerator();
    localSMIMEEnvelopedGenerator.addKeyTransRecipient((X509Certificate)arrayOfCertificate[0]);
    MimeBodyPart localMimeBodyPart1 = new MimeBodyPart();
    localMimeBodyPart1.setDataHandler(new DataHandler(new FileDataSource(new File(paramArrayOfString[2]))));
    localMimeBodyPart1.setHeader("Content-Type", "application/octet-stream");
    localMimeBodyPart1.setHeader("Content-Transfer-Encoding", "binary");
    MimeBodyPart localMimeBodyPart2 = localSMIMEEnvelopedGenerator.generate(localMimeBodyPart1, SMIMEEnvelopedGenerator.RC2_CBC, "BC");
    Properties localProperties = System.getProperties();
    Session localSession = Session.getDefaultInstance(localProperties, null);
    InternetAddress localInternetAddress1 = new InternetAddress("\"Eric H. Echidna\"<eric@bouncycastle.org>");
    InternetAddress localInternetAddress2 = new InternetAddress("example@bouncycastle.org");
    MimeMessage localMimeMessage = new MimeMessage(localSession);
    localMimeMessage.setFrom(localInternetAddress1);
    localMimeMessage.setRecipient(Message.RecipientType.TO, localInternetAddress2);
    localMimeMessage.setSubject("example encrypted message");
    localMimeMessage.setContent(localMimeBodyPart2.getContent(), localMimeBodyPart2.getContentType());
    localMimeMessage.saveChanges();
    localMimeMessage.writeTo(new FileOutputStream("encrypted.message"));
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\examples\CreateLargeEncryptedMail.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */