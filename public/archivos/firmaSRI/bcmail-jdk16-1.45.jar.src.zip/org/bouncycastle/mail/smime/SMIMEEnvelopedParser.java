package org.bouncycastle.mail.smime;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.mail.MessagingException;
import javax.mail.Part;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimePart;
import org.bouncycastle.cms.CMSEnvelopedDataParser;
import org.bouncycastle.cms.CMSException;

public class SMIMEEnvelopedParser
  extends CMSEnvelopedDataParser
{
  private final MimePart message;
  
  private static InputStream getInputStream(Part paramPart, int paramInt)
    throws MessagingException
  {
    try
    {
      InputStream localInputStream = paramPart.getInputStream();
      if (paramInt == 0) {
        return new BufferedInputStream(localInputStream);
      }
      return new BufferedInputStream(localInputStream, paramInt);
    }
    catch (IOException localIOException)
    {
      throw new MessagingException("can't extract input stream: " + localIOException);
    }
  }
  
  public SMIMEEnvelopedParser(MimeBodyPart paramMimeBodyPart)
    throws IOException, MessagingException, CMSException
  {
    this(paramMimeBodyPart, 0);
  }
  
  public SMIMEEnvelopedParser(MimeMessage paramMimeMessage)
    throws IOException, MessagingException, CMSException
  {
    this(paramMimeMessage, 0);
  }
  
  public SMIMEEnvelopedParser(MimeBodyPart paramMimeBodyPart, int paramInt)
    throws IOException, MessagingException, CMSException
  {
    super(getInputStream(paramMimeBodyPart, paramInt));
    this.message = paramMimeBodyPart;
  }
  
  public SMIMEEnvelopedParser(MimeMessage paramMimeMessage, int paramInt)
    throws IOException, MessagingException, CMSException
  {
    super(getInputStream(paramMimeMessage, paramInt));
    this.message = paramMimeMessage;
  }
  
  public MimePart getEncryptedContent()
  {
    return this.message;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\SMIMEEnvelopedParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */