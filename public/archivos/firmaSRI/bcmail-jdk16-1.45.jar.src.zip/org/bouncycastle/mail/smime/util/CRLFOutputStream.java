package org.bouncycastle.mail.smime.util;

import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class CRLFOutputStream
  extends FilterOutputStream
{
  protected int lastb = -1;
  protected static byte[] newline = new byte[2];
  
  public CRLFOutputStream(OutputStream paramOutputStream)
  {
    super(paramOutputStream);
  }
  
  public void write(int paramInt)
    throws IOException
  {
    if (paramInt == 13) {
      this.out.write(newline);
    } else if (paramInt == 10)
    {
      if (this.lastb != 13) {
        this.out.write(newline);
      }
    }
    else {
      this.out.write(paramInt);
    }
    this.lastb = paramInt;
  }
  
  public void write(byte[] paramArrayOfByte)
    throws IOException
  {
    write(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    for (int i = paramInt1; i != paramInt1 + paramInt2; i++) {
      write(paramArrayOfByte[i]);
    }
  }
  
  public void writeln()
    throws IOException
  {
    this.out.write(newline);
  }
  
  static
  {
    newline[0] = 13;
    newline[1] = 10;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\util\CRLFOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */