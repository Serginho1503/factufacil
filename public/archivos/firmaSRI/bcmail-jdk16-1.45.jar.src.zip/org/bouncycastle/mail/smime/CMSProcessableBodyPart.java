package org.bouncycastle.mail.smime;

import java.io.IOException;
import java.io.OutputStream;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.CMSProcessable;

public class CMSProcessableBodyPart
  implements CMSProcessable
{
  private BodyPart bodyPart;
  
  public CMSProcessableBodyPart(BodyPart paramBodyPart)
  {
    this.bodyPart = paramBodyPart;
  }
  
  public void write(OutputStream paramOutputStream)
    throws IOException, CMSException
  {
    try
    {
      this.bodyPart.writeTo(paramOutputStream);
    }
    catch (MessagingException localMessagingException)
    {
      throw new CMSException("can't write BodyPart to stream.", localMessagingException);
    }
  }
  
  public Object getContent()
  {
    return this.bodyPart;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\mail\smime\CMSProcessableBodyPart.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */