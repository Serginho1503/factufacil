package org.bouncycastle.sasn1;

class BerTagClass
{
  public static final int UNIVERSAL = 0;
  public static final int APPLICATION = 64;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\sasn1\BerTagClass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */