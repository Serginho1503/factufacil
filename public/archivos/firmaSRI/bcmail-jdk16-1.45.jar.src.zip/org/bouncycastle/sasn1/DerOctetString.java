package org.bouncycastle.sasn1;

import java.io.InputStream;

/**
 * @deprecated
 */
public class DerOctetString
  extends DerObject
  implements Asn1OctetString
{
  protected DerOctetString(int paramInt, byte[] paramArrayOfByte)
  {
    super(paramInt, 4, paramArrayOfByte);
  }
  
  public InputStream getOctetStream()
  {
    if (isConstructed()) {
      return new ConstructedOctetStream(getRawContentStream());
    }
    return getRawContentStream();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\sasn1\DerOctetString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */