package org.bouncycastle.sasn1;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * @deprecated
 */
public class DerObject
  extends Asn1Object
{
  private byte[] _content;
  
  DerObject(int paramInt1, int paramInt2, byte[] paramArrayOfByte)
  {
    super(paramInt1, paramInt2, null);
    this._content = paramArrayOfByte;
  }
  
  public int getTagNumber()
  {
    return this._tagNumber;
  }
  
  public InputStream getRawContentStream()
  {
    return new ByteArrayInputStream(this._content);
  }
  
  public byte[] getEncoded()
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    encode(localByteArrayOutputStream);
    return localByteArrayOutputStream.toByteArray();
  }
  
  void encode(OutputStream paramOutputStream)
    throws IOException
  {
    BasicDerGenerator localBasicDerGenerator = new BasicDerGenerator(paramOutputStream);
    localBasicDerGenerator.writeDerEncoded(this._baseTag | this._tagNumber, this._content);
  }
  
  private class BasicDerGenerator
    extends DerGenerator
  {
    protected BasicDerGenerator(OutputStream paramOutputStream)
    {
      super();
    }
    
    public OutputStream getRawOutputStream()
    {
      return this._out;
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\sasn1\DerObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */