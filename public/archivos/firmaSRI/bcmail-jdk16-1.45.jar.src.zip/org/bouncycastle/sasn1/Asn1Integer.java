package org.bouncycastle.sasn1;

import java.io.IOException;
import java.math.BigInteger;

/**
 * @deprecated
 */
public class Asn1Integer
  extends DerObject
{
  private BigInteger _value;
  
  protected Asn1Integer(int paramInt, byte[] paramArrayOfByte)
    throws IOException
  {
    super(paramInt, 2, paramArrayOfByte);
    this._value = new BigInteger(paramArrayOfByte);
  }
  
  public Asn1Integer(long paramLong)
  {
    this(BigInteger.valueOf(paramLong));
  }
  
  public Asn1Integer(BigInteger paramBigInteger)
  {
    super(0, 2, paramBigInteger.toByteArray());
    this._value = paramBigInteger;
  }
  
  public BigInteger getValue()
  {
    return this._value;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\sasn1\Asn1Integer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */