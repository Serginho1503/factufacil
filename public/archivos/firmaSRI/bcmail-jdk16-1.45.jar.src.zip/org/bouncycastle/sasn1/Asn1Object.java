package org.bouncycastle.sasn1;

import java.io.InputStream;

/**
 * @deprecated
 */
public abstract class Asn1Object
{
  protected int _baseTag;
  protected int _tagNumber;
  protected InputStream _contentStream;
  
  protected Asn1Object(int paramInt1, int paramInt2, InputStream paramInputStream)
  {
    this._baseTag = paramInt1;
    this._tagNumber = paramInt2;
    this._contentStream = paramInputStream;
  }
  
  public boolean isConstructed()
  {
    return (this._baseTag & 0x20) != 0;
  }
  
  public int getTagNumber()
  {
    return this._tagNumber;
  }
  
  public InputStream getRawContentStream()
  {
    return this._contentStream;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\sasn1\Asn1Object.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */