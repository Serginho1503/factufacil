package org.bouncycastle.sasn1;

import java.io.IOException;
import java.io.OutputStream;

/**
 * @deprecated
 */
public class BerSequenceGenerator
  extends BerGenerator
{
  public BerSequenceGenerator(OutputStream paramOutputStream)
    throws IOException
  {
    super(paramOutputStream);
    writeBerHeader(48);
  }
  
  public BerSequenceGenerator(OutputStream paramOutputStream, int paramInt, boolean paramBoolean)
    throws IOException
  {
    super(paramOutputStream, paramInt, paramBoolean);
    writeBerHeader(48);
  }
  
  public void addObject(DerObject paramDerObject)
    throws IOException
  {
    this._out.write(paramDerObject.getEncoded());
  }
  
  public void close()
    throws IOException
  {
    writeBerEnd();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\sasn1\BerSequenceGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */