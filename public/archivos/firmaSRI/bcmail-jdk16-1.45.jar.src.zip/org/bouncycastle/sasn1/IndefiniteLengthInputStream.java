package org.bouncycastle.sasn1;

import java.io.IOException;
import java.io.InputStream;

class IndefiniteLengthInputStream
  extends LimitedInputStream
{
  private int _b1;
  private int _b2;
  private boolean _eofReached = false;
  private boolean _eofOn00 = true;
  
  IndefiniteLengthInputStream(InputStream paramInputStream)
    throws IOException
  {
    super(paramInputStream);
    this._b1 = paramInputStream.read();
    this._b2 = paramInputStream.read();
    this._eofReached = (this._b2 < 0);
  }
  
  void setEofOn00(boolean paramBoolean)
  {
    this._eofOn00 = paramBoolean;
  }
  
  void checkForEof()
    throws IOException
  {
    if ((this._eofOn00) && (this._b1 == 0) && (this._b2 == 0))
    {
      this._eofReached = true;
      setParentEofDetect(true);
    }
  }
  
  public int read()
    throws IOException
  {
    checkForEof();
    if (this._eofReached) {
      return -1;
    }
    int i = this._in.read();
    if (i < 0)
    {
      this._eofReached = true;
      return -1;
    }
    int j = this._b1;
    this._b1 = this._b2;
    this._b2 = i;
    return j;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\sasn1\IndefiniteLengthInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */