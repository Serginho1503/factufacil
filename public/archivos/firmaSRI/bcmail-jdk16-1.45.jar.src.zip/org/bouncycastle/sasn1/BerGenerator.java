package org.bouncycastle.sasn1;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * @deprecated
 */
public class BerGenerator
  extends Asn1Generator
{
  private boolean _tagged = false;
  private boolean _isExplicit;
  private int _tagNo;
  
  protected BerGenerator(OutputStream paramOutputStream)
  {
    super(paramOutputStream);
  }
  
  public BerGenerator(OutputStream paramOutputStream, int paramInt, boolean paramBoolean)
  {
    super(paramOutputStream);
    this._tagged = true;
    this._isExplicit = paramBoolean;
    this._tagNo = paramInt;
  }
  
  public OutputStream getRawOutputStream()
  {
    return this._out;
  }
  
  private void writeHdr(int paramInt)
    throws IOException
  {
    this._out.write(paramInt);
    this._out.write(128);
  }
  
  protected void writeBerHeader(int paramInt)
    throws IOException
  {
    int i = this._tagNo | 0x80;
    if (this._tagged)
    {
      if (this._isExplicit)
      {
        writeHdr(i | 0x20);
        writeHdr(paramInt);
      }
      else if ((paramInt & 0x20) != 0)
      {
        writeHdr(i | 0x20);
      }
      else
      {
        writeHdr(i);
      }
    }
    else {
      writeHdr(paramInt);
    }
  }
  
  protected void writeBerBody(InputStream paramInputStream)
    throws IOException
  {
    int i;
    while ((i = paramInputStream.read()) >= 0) {
      this._out.write(i);
    }
  }
  
  protected void writeBerEnd()
    throws IOException
  {
    this._out.write(0);
    this._out.write(0);
    if ((this._tagged) && (this._isExplicit))
    {
      this._out.write(0);
      this._out.write(0);
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\sasn1\BerGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */