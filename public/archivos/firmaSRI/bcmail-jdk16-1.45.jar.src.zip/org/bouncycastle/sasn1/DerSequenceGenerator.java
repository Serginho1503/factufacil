package org.bouncycastle.sasn1;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 * @deprecated
 */
public class DerSequenceGenerator
  extends DerGenerator
{
  private final ByteArrayOutputStream _bOut = new ByteArrayOutputStream();
  
  public DerSequenceGenerator(OutputStream paramOutputStream)
    throws IOException
  {
    super(paramOutputStream);
  }
  
  public DerSequenceGenerator(OutputStream paramOutputStream, int paramInt, boolean paramBoolean)
    throws IOException
  {
    super(paramOutputStream, paramInt, paramBoolean);
  }
  
  public void addObject(DerObject paramDerObject)
    throws IOException
  {
    this._bOut.write(paramDerObject.getEncoded());
  }
  
  public OutputStream getRawOutputStream()
  {
    return this._bOut;
  }
  
  public void close()
    throws IOException
  {
    writeDerEncoded(48, this._bOut.toByteArray());
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\sasn1\DerSequenceGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */