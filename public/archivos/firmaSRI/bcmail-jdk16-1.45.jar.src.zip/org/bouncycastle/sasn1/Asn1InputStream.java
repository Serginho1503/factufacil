package org.bouncycastle.sasn1;

import java.io.ByteArrayInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

/**
 * @deprecated
 */
public class Asn1InputStream
{
  InputStream _in;
  private int _limit;
  private boolean _eofFound;
  
  public Asn1InputStream(InputStream paramInputStream)
  {
    this._in = paramInputStream;
    this._limit = Integer.MAX_VALUE;
  }
  
  public Asn1InputStream(InputStream paramInputStream, int paramInt)
  {
    this._in = paramInputStream;
    this._limit = paramInt;
  }
  
  public Asn1InputStream(byte[] paramArrayOfByte)
  {
    this._in = new ByteArrayInputStream(paramArrayOfByte);
    this._limit = paramArrayOfByte.length;
  }
  
  InputStream getParentStream()
  {
    return this._in;
  }
  
  private int readLength()
    throws IOException
  {
    int i = this._in.read();
    if (i < 0) {
      throw new IOException("EOF found when length expected");
    }
    if (i == 128) {
      return -1;
    }
    if (i > 127)
    {
      int j = i & 0x7F;
      if (j > 4) {
        throw new IOException("DER length more than 4 bytes");
      }
      i = 0;
      for (int k = 0; k < j; k++)
      {
        int m = this._in.read();
        if (m < 0) {
          throw new IOException("EOF found reading length");
        }
        i = (i << 8) + m;
      }
      if (i < 0) {
        throw new IOException("corrupted stream - negative length found");
      }
      if (i >= this._limit) {
        throw new IOException("corrupted stream - out of bounds length found");
      }
    }
    return i;
  }
  
  public Asn1Object readObject()
    throws IOException
  {
    int i = this._in.read();
    if (i == -1)
    {
      if (this._eofFound) {
        throw new EOFException("attempt to read past end of file.");
      }
      this._eofFound = true;
      return null;
    }
    if ((this._in instanceof IndefiniteLengthInputStream)) {
      ((IndefiniteLengthInputStream)this._in).setEofOn00(false);
    }
    int j = i & 0xFFFFFFDF;
    int k = j;
    if ((i & 0x80) != 0)
    {
      k = i & 0x1F;
      if (k == 31)
      {
        k = 0;
        for (m = this._in.read(); (m >= 0) && ((m & 0x80) != 0); m = this._in.read())
        {
          k |= m & 0x7F;
          k <<= 7;
        }
        if (m < 0)
        {
          this._eofFound = true;
          throw new EOFException("EOF encountered inside tag value.");
        }
        k |= m & 0x7F;
      }
    }
    int m = readLength();
    if (m < 0)
    {
      localObject = new IndefiniteLengthInputStream(this._in);
      switch (j)
      {
      case 5: 
        return new Asn1Null(i);
      case 4: 
        return new BerOctetString(i, (InputStream)localObject);
      case 16: 
        return new BerSequence(i, (InputStream)localObject);
      case 17: 
        return new BerSet(i, (InputStream)localObject);
      }
      return new Asn1TaggedObject(i, k, (InputStream)localObject);
    }
    Object localObject = new DefiniteLengthInputStream(this._in, m);
    switch (j)
    {
    case 2: 
      return new Asn1Integer(i, ((DefiniteLengthInputStream)localObject).toByteArray());
    case 5: 
      return new Asn1Null(i);
    case 6: 
      return new Asn1ObjectIdentifier(i, ((DefiniteLengthInputStream)localObject).toByteArray());
    case 4: 
      return new DerOctetString(i, ((DefiniteLengthInputStream)localObject).toByteArray());
    case 16: 
      return new DerSequence(i, ((DefiniteLengthInputStream)localObject).toByteArray());
    case 17: 
      return new DerSet(i, ((DefiniteLengthInputStream)localObject).toByteArray());
    }
    return new Asn1TaggedObject(i, k, (InputStream)localObject);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\sasn1\Asn1InputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */