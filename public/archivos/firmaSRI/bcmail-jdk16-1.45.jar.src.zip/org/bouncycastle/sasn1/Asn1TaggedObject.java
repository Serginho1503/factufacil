package org.bouncycastle.sasn1;

import java.io.IOException;
import java.io.InputStream;

/**
 * @deprecated
 */
public class Asn1TaggedObject
  extends Asn1Object
{
  protected Asn1TaggedObject(int paramInt1, int paramInt2, InputStream paramInputStream)
  {
    super(paramInt1, paramInt2, paramInputStream);
  }
  
  public Asn1Object getObject(int paramInt, boolean paramBoolean)
    throws IOException
  {
    if (paramBoolean) {
      return new Asn1InputStream(getRawContentStream()).readObject();
    }
    switch (paramInt)
    {
    case 17: 
      if ((getRawContentStream() instanceof IndefiniteLengthInputStream)) {
        return new BerSet(32, getRawContentStream());
      }
      return new DerSet(32, ((DefiniteLengthInputStream)getRawContentStream()).toByteArray());
    case 16: 
      if ((getRawContentStream() instanceof IndefiniteLengthInputStream)) {
        return new BerSequence(32, getRawContentStream());
      }
      return new DerSequence(32, ((DefiniteLengthInputStream)getRawContentStream()).toByteArray());
    case 4: 
      if ((getRawContentStream() instanceof IndefiniteLengthInputStream)) {
        return new BerOctetString(32, getRawContentStream());
      }
      if (isConstructed()) {
        return new DerOctetString(32, ((DefiniteLengthInputStream)getRawContentStream()).toByteArray());
      }
      return new DerOctetString(0, ((DefiniteLengthInputStream)getRawContentStream()).toByteArray());
    }
    throw new RuntimeException("implicit tagging not implemented");
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\sasn1\Asn1TaggedObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */