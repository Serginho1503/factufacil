package org.bouncycastle.sasn1;

import java.io.IOException;
import java.io.InputStream;

/**
 * @deprecated
 */
class ConstructedOctetStream
  extends InputStream
{
  private final Asn1InputStream _aIn;
  private boolean _first = true;
  private InputStream _currentStream;
  
  ConstructedOctetStream(InputStream paramInputStream)
  {
    this._aIn = new Asn1InputStream(paramInputStream);
  }
  
  public int read()
    throws IOException
  {
    if (this._first)
    {
      Asn1OctetString localAsn1OctetString1 = (Asn1OctetString)this._aIn.readObject();
      if (localAsn1OctetString1 == null) {
        return -1;
      }
      this._first = false;
      this._currentStream = localAsn1OctetString1.getOctetStream();
    }
    else if (this._currentStream == null)
    {
      return -1;
    }
    int i = this._currentStream.read();
    if (i < 0)
    {
      Asn1OctetString localAsn1OctetString2 = (Asn1OctetString)this._aIn.readObject();
      if (localAsn1OctetString2 == null)
      {
        this._currentStream = null;
        return -1;
      }
      this._currentStream = localAsn1OctetString2.getOctetStream();
      return this._currentStream.read();
    }
    return i;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\sasn1\ConstructedOctetStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */