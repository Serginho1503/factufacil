package org.bouncycastle.sasn1;

import java.io.InputStream;

/**
 * @deprecated
 */
public class BerOctetString
  extends Asn1Object
  implements Asn1OctetString
{
  protected BerOctetString(int paramInt, InputStream paramInputStream)
  {
    super(paramInt, 4, paramInputStream);
  }
  
  public InputStream getOctetStream()
  {
    if (isConstructed()) {
      return new ConstructedOctetStream(getRawContentStream());
    }
    return getRawContentStream();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\sasn1\BerOctetString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */