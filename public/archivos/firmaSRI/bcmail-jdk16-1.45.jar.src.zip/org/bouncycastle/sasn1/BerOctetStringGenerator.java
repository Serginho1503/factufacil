package org.bouncycastle.sasn1;

import java.io.IOException;
import java.io.OutputStream;
import org.bouncycastle.asn1.DEROctetString;

/**
 * @deprecated
 */
public class BerOctetStringGenerator
  extends BerGenerator
{
  public BerOctetStringGenerator(OutputStream paramOutputStream)
    throws IOException
  {
    super(paramOutputStream);
    writeBerHeader(36);
  }
  
  public BerOctetStringGenerator(OutputStream paramOutputStream, int paramInt, boolean paramBoolean)
    throws IOException
  {
    super(paramOutputStream, paramInt, paramBoolean);
    writeBerHeader(36);
  }
  
  public OutputStream getOctetOutputStream()
  {
    return new BerOctetStream(null);
  }
  
  public OutputStream getOctetOutputStream(byte[] paramArrayOfByte)
  {
    return new BufferedBerOctetStream(paramArrayOfByte);
  }
  
  private class BerOctetStream
    extends OutputStream
  {
    private byte[] _buf = new byte[1];
    
    private BerOctetStream() {}
    
    public void write(int paramInt)
      throws IOException
    {
      this._buf[0] = ((byte)paramInt);
      BerOctetStringGenerator.this._out.write(new DEROctetString(this._buf).getEncoded());
    }
    
    public void write(byte[] paramArrayOfByte)
      throws IOException
    {
      BerOctetStringGenerator.this._out.write(new DEROctetString(paramArrayOfByte).getEncoded());
    }
    
    public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {
      byte[] arrayOfByte = new byte[paramInt2];
      System.arraycopy(paramArrayOfByte, paramInt1, arrayOfByte, 0, paramInt2);
      BerOctetStringGenerator.this._out.write(new DEROctetString(arrayOfByte).getEncoded());
    }
    
    public void close()
      throws IOException
    {
      BerOctetStringGenerator.this.writeBerEnd();
    }
  }
  
  private class BufferedBerOctetStream
    extends OutputStream
  {
    private byte[] _buf;
    private int _off;
    
    BufferedBerOctetStream(byte[] paramArrayOfByte)
    {
      this._buf = paramArrayOfByte;
      this._off = 0;
    }
    
    public void write(int paramInt)
      throws IOException
    {
      this._buf[(this._off++)] = ((byte)paramInt);
      if (this._off == this._buf.length)
      {
        BerOctetStringGenerator.this._out.write(new DEROctetString(this._buf).getEncoded());
        this._off = 0;
      }
    }
    
    public void close()
      throws IOException
    {
      if (this._off != 0)
      {
        byte[] arrayOfByte = new byte[this._off];
        System.arraycopy(this._buf, 0, arrayOfByte, 0, this._off);
        BerOctetStringGenerator.this._out.write(new DEROctetString(arrayOfByte).getEncoded());
      }
      BerOctetStringGenerator.this.writeBerEnd();
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\sasn1\BerOctetStringGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */