package org.bouncycastle.sasn1;

import java.io.IOException;
import java.io.InputStream;

/**
 * @deprecated
 */
public class BerSet
  extends Asn1Object
  implements Asn1Set
{
  private Asn1InputStream _aIn;
  
  protected BerSet(int paramInt, InputStream paramInputStream)
  {
    super(paramInt, 17, paramInputStream);
    this._aIn = new Asn1InputStream(paramInputStream);
  }
  
  public Asn1Object readObject()
    throws IOException
  {
    return this._aIn.readObject();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\sasn1\BerSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */