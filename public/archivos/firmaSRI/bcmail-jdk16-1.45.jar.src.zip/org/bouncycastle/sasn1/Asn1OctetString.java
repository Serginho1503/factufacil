package org.bouncycastle.sasn1;

import java.io.InputStream;

/**
 * @deprecated
 */
public abstract interface Asn1OctetString
{
  public abstract InputStream getOctetStream();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\sasn1\Asn1OctetString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */