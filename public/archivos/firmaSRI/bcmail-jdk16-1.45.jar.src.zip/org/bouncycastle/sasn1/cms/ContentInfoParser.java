package org.bouncycastle.sasn1.cms;

import java.io.IOException;
import org.bouncycastle.sasn1.Asn1Object;
import org.bouncycastle.sasn1.Asn1ObjectIdentifier;
import org.bouncycastle.sasn1.Asn1Sequence;
import org.bouncycastle.sasn1.Asn1TaggedObject;

/**
 * @deprecated
 */
public class ContentInfoParser
{
  private Asn1ObjectIdentifier contentType;
  private Asn1TaggedObject content;
  
  public ContentInfoParser(Asn1Sequence paramAsn1Sequence)
    throws IOException
  {
    this.contentType = ((Asn1ObjectIdentifier)paramAsn1Sequence.readObject());
    this.content = ((Asn1TaggedObject)paramAsn1Sequence.readObject());
  }
  
  public Asn1ObjectIdentifier getContentType()
  {
    return this.contentType;
  }
  
  public Asn1Object getContent(int paramInt)
    throws IOException
  {
    if (this.content != null) {
      return this.content.getObject(paramInt, true);
    }
    return null;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\sasn1\cms\ContentInfoParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */