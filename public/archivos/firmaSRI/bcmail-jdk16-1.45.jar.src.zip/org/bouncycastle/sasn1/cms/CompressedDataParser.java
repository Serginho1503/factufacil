package org.bouncycastle.sasn1.cms;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.sasn1.Asn1Integer;
import org.bouncycastle.sasn1.Asn1Sequence;
import org.bouncycastle.sasn1.DerSequence;

/**
 * @deprecated
 */
public class CompressedDataParser
{
  private Asn1Integer _version;
  private AlgorithmIdentifier _compressionAlgorithm;
  private ContentInfoParser _encapContentInfo;
  
  public CompressedDataParser(Asn1Sequence paramAsn1Sequence)
    throws IOException
  {
    this._version = ((Asn1Integer)paramAsn1Sequence.readObject());
    this._compressionAlgorithm = AlgorithmIdentifier.getInstance(new ASN1InputStream(((DerSequence)paramAsn1Sequence.readObject()).getEncoded()).readObject());
    this._encapContentInfo = new ContentInfoParser((Asn1Sequence)paramAsn1Sequence.readObject());
  }
  
  public Asn1Integer getVersion()
  {
    return this._version;
  }
  
  public AlgorithmIdentifier getCompressionAlgorithmIdentifier()
  {
    return this._compressionAlgorithm;
  }
  
  public ContentInfoParser getEncapContentInfo()
  {
    return this._encapContentInfo;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\sasn1\cms\CompressedDataParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */