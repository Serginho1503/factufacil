package org.bouncycastle.sasn1.cms;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.sasn1.Asn1Object;
import org.bouncycastle.sasn1.Asn1ObjectIdentifier;
import org.bouncycastle.sasn1.Asn1Sequence;
import org.bouncycastle.sasn1.Asn1TaggedObject;
import org.bouncycastle.sasn1.DerSequence;

/**
 * @deprecated
 */
public class EncryptedContentInfoParser
{
  private Asn1ObjectIdentifier _contentType;
  private AlgorithmIdentifier _contentEncryptionAlgorithm;
  private Asn1TaggedObject _encryptedContent;
  
  public EncryptedContentInfoParser(Asn1Sequence paramAsn1Sequence)
    throws IOException
  {
    this._contentType = ((Asn1ObjectIdentifier)paramAsn1Sequence.readObject());
    this._contentEncryptionAlgorithm = AlgorithmIdentifier.getInstance(new ASN1InputStream(((DerSequence)paramAsn1Sequence.readObject()).getEncoded()).readObject());
    this._encryptedContent = ((Asn1TaggedObject)paramAsn1Sequence.readObject());
  }
  
  public Asn1ObjectIdentifier getContentType()
  {
    return this._contentType;
  }
  
  public AlgorithmIdentifier getContentEncryptionAlgorithm()
  {
    return this._contentEncryptionAlgorithm;
  }
  
  public Asn1Object getEncryptedContent(int paramInt)
    throws IOException
  {
    return this._encryptedContent.getObject(paramInt, false);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\sasn1\cms\EncryptedContentInfoParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */