package org.bouncycastle.sasn1.cms;

import java.io.IOException;
import org.bouncycastle.sasn1.Asn1Integer;
import org.bouncycastle.sasn1.Asn1Object;
import org.bouncycastle.sasn1.Asn1Sequence;
import org.bouncycastle.sasn1.Asn1Set;
import org.bouncycastle.sasn1.Asn1TaggedObject;

/**
 * @deprecated
 */
public class EnvelopedDataParser
{
  private Asn1Sequence _seq;
  private Asn1Integer _version;
  private Asn1Object _nextObject;
  
  public EnvelopedDataParser(Asn1Sequence paramAsn1Sequence)
    throws IOException
  {
    this._seq = paramAsn1Sequence;
    this._version = ((Asn1Integer)paramAsn1Sequence.readObject());
  }
  
  public Asn1Integer getVersion()
  {
    return this._version;
  }
  
  public Asn1Set getCertificates()
    throws IOException
  {
    this._nextObject = this._seq.readObject();
    if (((this._nextObject instanceof Asn1TaggedObject)) && (((Asn1TaggedObject)this._nextObject).getTagNumber() == 0))
    {
      Asn1Set localAsn1Set = (Asn1Set)((Asn1TaggedObject)this._nextObject).getObject(17, false);
      this._nextObject = null;
      return localAsn1Set;
    }
    return null;
  }
  
  public Asn1Set getCrls()
    throws IOException
  {
    if (this._nextObject == null) {
      this._nextObject = this._seq.readObject();
    }
    if (((this._nextObject instanceof Asn1TaggedObject)) && (((Asn1TaggedObject)this._nextObject).getTagNumber() == 1))
    {
      Asn1Set localAsn1Set = (Asn1Set)((Asn1TaggedObject)this._nextObject).getObject(17, false);
      this._nextObject = null;
      return localAsn1Set;
    }
    return null;
  }
  
  public Asn1Set getRecipientInfos()
    throws IOException
  {
    return (Asn1Set)this._seq.readObject();
  }
  
  public EncryptedContentInfoParser getEncryptedContentInfo()
    throws IOException
  {
    return new EncryptedContentInfoParser((Asn1Sequence)this._seq.readObject());
  }
  
  public Asn1Set getUnprotectedAttrs()
    throws IOException
  {
    Asn1Object localAsn1Object = this._seq.readObject();
    if (localAsn1Object != null) {
      return (Asn1Set)((Asn1TaggedObject)localAsn1Object).getObject(17, false);
    }
    return null;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\sasn1\cms\EnvelopedDataParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */