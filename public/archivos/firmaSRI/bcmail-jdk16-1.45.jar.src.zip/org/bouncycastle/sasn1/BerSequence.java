package org.bouncycastle.sasn1;

import java.io.IOException;
import java.io.InputStream;

/**
 * @deprecated
 */
public class BerSequence
  extends Asn1Object
  implements Asn1Sequence
{
  private Asn1InputStream _aIn;
  
  protected BerSequence(int paramInt, InputStream paramInputStream)
  {
    super(paramInt, 16, paramInputStream);
    this._aIn = new Asn1InputStream(paramInputStream);
  }
  
  public Asn1Object readObject()
    throws IOException
  {
    return this._aIn.readObject();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\sasn1\BerSequence.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */