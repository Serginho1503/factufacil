package org.bouncycastle.sasn1;

import java.io.IOException;
import java.io.InputStream;

class DefiniteLengthInputStream
  extends LimitedInputStream
{
  private int _length;
  
  DefiniteLengthInputStream(InputStream paramInputStream, int paramInt)
  {
    super(paramInputStream);
    this._length = paramInt;
  }
  
  public int read()
    throws IOException
  {
    if (this._length-- > 0) {
      return this._in.read();
    }
    setParentEofDetect(true);
    return -1;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\sasn1\DefiniteLengthInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */