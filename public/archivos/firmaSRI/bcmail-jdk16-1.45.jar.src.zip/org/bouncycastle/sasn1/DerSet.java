package org.bouncycastle.sasn1;

import java.io.IOException;

/**
 * @deprecated
 */
public class DerSet
  extends DerObject
  implements Asn1Set
{
  private Asn1InputStream _aIn;
  
  DerSet(int paramInt, byte[] paramArrayOfByte)
  {
    super(paramInt, 17, paramArrayOfByte);
    this._aIn = new Asn1InputStream(paramArrayOfByte);
  }
  
  public Asn1Object readObject()
    throws IOException
  {
    return this._aIn.readObject();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\sasn1\DerSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */