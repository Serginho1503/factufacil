package org.bouncycastle.sasn1;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * @deprecated
 */
public abstract class DerGenerator
  extends Asn1Generator
{
  private boolean _tagged = false;
  private boolean _isExplicit;
  private int _tagNo;
  
  protected DerGenerator(OutputStream paramOutputStream)
  {
    super(paramOutputStream);
  }
  
  public DerGenerator(OutputStream paramOutputStream, int paramInt, boolean paramBoolean)
  {
    super(paramOutputStream);
    this._tagged = true;
    this._isExplicit = paramBoolean;
    this._tagNo = paramInt;
  }
  
  private void writeLength(OutputStream paramOutputStream, int paramInt)
    throws IOException
  {
    if (paramInt > 127)
    {
      int i = 1;
      int j = paramInt;
      while (j >>>= 8 != 0) {
        i++;
      }
      paramOutputStream.write((byte)(i | 0x80));
      for (int k = (i - 1) * 8; k >= 0; k -= 8) {
        paramOutputStream.write((byte)(paramInt >> k));
      }
    }
    else
    {
      paramOutputStream.write((byte)paramInt);
    }
  }
  
  void writeDerEncoded(OutputStream paramOutputStream, int paramInt, byte[] paramArrayOfByte)
    throws IOException
  {
    paramOutputStream.write(paramInt);
    writeLength(paramOutputStream, paramArrayOfByte.length);
    paramOutputStream.write(paramArrayOfByte);
  }
  
  void writeDerEncoded(int paramInt, byte[] paramArrayOfByte)
    throws IOException
  {
    if (this._tagged)
    {
      int i = this._tagNo | 0x80;
      if (this._isExplicit)
      {
        int j = this._tagNo | 0x20 | 0x80;
        ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
        writeDerEncoded(localByteArrayOutputStream, paramInt, paramArrayOfByte);
        writeDerEncoded(this._out, j, localByteArrayOutputStream.toByteArray());
      }
      else if ((paramInt & 0x20) != 0)
      {
        writeDerEncoded(this._out, i | 0x20, paramArrayOfByte);
      }
      else
      {
        writeDerEncoded(this._out, i, paramArrayOfByte);
      }
    }
    else
    {
      writeDerEncoded(this._out, paramInt, paramArrayOfByte);
    }
  }
  
  void writeDerEncoded(OutputStream paramOutputStream, int paramInt, InputStream paramInputStream)
    throws IOException
  {
    paramOutputStream.write(paramInt);
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    int i = 0;
    while ((i = paramInputStream.read()) >= 0) {
      localByteArrayOutputStream.write(i);
    }
    byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
    writeLength(paramOutputStream, arrayOfByte.length);
    paramOutputStream.write(arrayOfByte);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcmail-jdk16-1.45.jar!\org\bouncycastle\sasn1\DerGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */