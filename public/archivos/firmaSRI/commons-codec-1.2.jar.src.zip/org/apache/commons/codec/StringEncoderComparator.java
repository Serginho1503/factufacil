/*     */ package org.apache.commons.codec;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringEncoderComparator
/*     */   implements Comparator
/*     */ {
/*     */   private StringEncoder stringEncoder;
/*     */   
/*     */   public StringEncoderComparator() {}
/*     */   
/*     */   public StringEncoderComparator(StringEncoder stringEncoder)
/*     */   {
/*  94 */     this.stringEncoder = stringEncoder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int compare(Object o1, Object o2)
/*     */   {
/* 112 */     int compareCode = 0;
/*     */     try
/*     */     {
/* 115 */       Comparable s1 = (Comparable)this.stringEncoder.encode(o1);
/* 116 */       Comparable s2 = (Comparable)this.stringEncoder.encode(o2);
/* 117 */       compareCode = s1.compareTo(s2);
/*     */     }
/*     */     catch (EncoderException ee) {
/* 120 */       compareCode = 0;
/*     */     }
/* 122 */     return compareCode;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-codec-1.2.jar!\org\apache\commons\codec\StringEncoderComparator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */