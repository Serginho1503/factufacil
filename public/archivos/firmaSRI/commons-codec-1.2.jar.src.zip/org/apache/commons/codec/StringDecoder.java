package org.apache.commons.codec;

public abstract interface StringDecoder
  extends Decoder
{
  public abstract String decode(String paramString)
    throws DecoderException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-codec-1.2.jar!\org\apache\commons\codec\StringDecoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */