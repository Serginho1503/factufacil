/*     */ package org.apache.commons.codec.binary;
/*     */ 
/*     */ import org.apache.commons.codec.BinaryDecoder;
/*     */ import org.apache.commons.codec.BinaryEncoder;
/*     */ import org.apache.commons.codec.DecoderException;
/*     */ import org.apache.commons.codec.EncoderException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Hex
/*     */   implements BinaryEncoder, BinaryDecoder
/*     */ {
/*  78 */   private static char[] digits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] decodeHex(char[] data)
/*     */     throws DecoderException
/*     */   {
/*  98 */     int l = data.length;
/*     */     
/* 100 */     if ((l & 0x1) != 0) {
/* 101 */       throw new DecoderException("Odd number of characters.");
/*     */     }
/*     */     
/* 104 */     byte[] out = new byte[l >> 1];
/*     */     
/*     */ 
/* 107 */     int i = 0; for (int j = 0; j < l; i++) {
/* 108 */       int f = Character.digit(data[(j++)], 16) << 4;
/* 109 */       f |= Character.digit(data[(j++)], 16);
/* 110 */       out[i] = ((byte)(f & 0xFF));
/*     */     }
/*     */     
/* 113 */     return out;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static char[] encodeHex(byte[] data)
/*     */   {
/* 127 */     int l = data.length;
/*     */     
/* 129 */     char[] out = new char[l << 1];
/*     */     
/*     */ 
/* 132 */     int i = 0; for (int j = 0; i < l; i++) {
/* 133 */       out[(j++)] = digits[((0xF0 & data[i]) >>> 4)];
/* 134 */       out[(j++)] = digits[(0xF & data[i])];
/*     */     }
/*     */     
/* 137 */     return out;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] decode(byte[] array)
/*     */     throws DecoderException
/*     */   {
/* 155 */     return decodeHex(new String(array).toCharArray());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object decode(Object object)
/*     */     throws DecoderException
/*     */   {
/*     */     try
/*     */     {
/* 174 */       char[] charArray = (object instanceof String) ? ((String)object).toCharArray() : (char[])object;
/* 175 */       return decodeHex(charArray);
/*     */     } catch (ClassCastException e) {
/* 177 */       throw new DecoderException(e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] encode(byte[] array)
/*     */   {
/* 192 */     return new String(encodeHex(array)).getBytes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object encode(Object object)
/*     */     throws EncoderException
/*     */   {
/*     */     try
/*     */     {
/* 208 */       byte[] byteArray = (object instanceof String) ? ((String)object).getBytes() : (byte[])object;
/* 209 */       return encodeHex(byteArray);
/*     */     } catch (ClassCastException e) {
/* 211 */       throw new EncoderException(e.getMessage());
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-codec-1.2.jar!\org\apache\commons\codec\binary\Hex.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */