package org.apache.commons.codec;

public abstract interface Encoder
{
  public abstract Object encode(Object paramObject)
    throws EncoderException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-codec-1.2.jar!\org\apache\commons\codec\Encoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */