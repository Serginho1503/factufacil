/*      */ package org.apache.commons.codec.language;
/*      */ 
/*      */ import org.apache.commons.codec.EncoderException;
/*      */ import org.apache.commons.codec.StringEncoder;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DoubleMetaphone
/*      */   implements StringEncoder
/*      */ {
/*      */   private static final String VOWELS = "AEIOUY";
/*   88 */   private static final String[] SILENT_START = { "GN", "KN", "PN", "WR", "PS" };
/*      */   
/*   90 */   private static final String[] L_R_N_M_B_H_F_V_W_SPACE = { "L", "R", "N", "M", "B", "H", "F", "V", "W", " " };
/*      */   
/*   92 */   private static final String[] ES_EP_EB_EL_EY_IB_IL_IN_IE_EI_ER = { "ES", "EP", "EB", "EL", "EY", "IB", "IL", "IN", "IE", "EI", "ER" };
/*      */   
/*   94 */   private static final String[] L_T_K_S_N_M_B_Z = { "L", "T", "K", "S", "N", "M", "B", "Z" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  100 */   protected int maxCodeLen = 4;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String doubleMetaphone(String value)
/*      */   {
/*  116 */     return doubleMetaphone(value, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String doubleMetaphone(String value, boolean alternate)
/*      */   {
/*  128 */     value = cleanInput(value);
/*  129 */     if (value == null) {
/*  130 */       return null;
/*      */     }
/*      */     
/*  133 */     boolean slavoGermanic = isSlavoGermanic(value);
/*  134 */     int index = isSilentStart(value) ? 1 : 0;
/*      */     
/*  136 */     DoubleMetaphoneResult result = new DoubleMetaphoneResult(getMaxCodeLen());
/*      */     
/*  138 */     while ((!result.isComplete()) && (index <= value.length() - 1)) {
/*  139 */       switch (value.charAt(index)) {
/*      */       case 'A': 
/*      */       case 'E': 
/*      */       case 'I': 
/*      */       case 'O': 
/*      */       case 'U': 
/*      */       case 'Y': 
/*  146 */         index = handleAEIOUY(value, result, index);
/*  147 */         break;
/*      */       case 'B': 
/*  149 */         result.append('P');
/*  150 */         index = charAt(value, index + 1) == 'B' ? index + 2 : index + 1;
/*  151 */         break;
/*      */       
/*      */       case 'Ç': 
/*  154 */         result.append('S');
/*  155 */         index++;
/*  156 */         break;
/*      */       case 'C': 
/*  158 */         index = handleC(value, result, index);
/*  159 */         break;
/*      */       case 'D': 
/*  161 */         index = handleD(value, result, index);
/*  162 */         break;
/*      */       case 'F': 
/*  164 */         result.append('F');
/*  165 */         index = charAt(value, index + 1) == 'F' ? index + 2 : index + 1;
/*  166 */         break;
/*      */       case 'G': 
/*  168 */         index = handleG(value, result, index, slavoGermanic);
/*  169 */         break;
/*      */       case 'H': 
/*  171 */         index = handleH(value, result, index);
/*  172 */         break;
/*      */       case 'J': 
/*  174 */         index = handleJ(value, result, index, slavoGermanic);
/*  175 */         break;
/*      */       case 'K': 
/*  177 */         result.append('K');
/*  178 */         index = charAt(value, index + 1) == 'K' ? index + 2 : index + 1;
/*  179 */         break;
/*      */       case 'L': 
/*  181 */         index = handleL(value, result, index);
/*  182 */         break;
/*      */       case 'M': 
/*  184 */         result.append('M');
/*  185 */         index = conditionM0(value, index) ? index + 2 : index + 1;
/*  186 */         break;
/*      */       case 'N': 
/*  188 */         result.append('N');
/*  189 */         index = charAt(value, index + 1) == 'N' ? index + 2 : index + 1;
/*  190 */         break;
/*      */       
/*      */       case 'Ñ': 
/*  193 */         result.append('N');
/*  194 */         index++;
/*  195 */         break;
/*      */       case 'P': 
/*  197 */         index = handleP(value, result, index);
/*  198 */         break;
/*      */       case 'Q': 
/*  200 */         result.append('K');
/*  201 */         index = charAt(value, index + 1) == 'Q' ? index + 2 : index + 1;
/*  202 */         break;
/*      */       case 'R': 
/*  204 */         index = handleR(value, result, index, slavoGermanic);
/*  205 */         break;
/*      */       case 'S': 
/*  207 */         index = handleS(value, result, index, slavoGermanic);
/*  208 */         break;
/*      */       case 'T': 
/*  210 */         index = handleT(value, result, index);
/*  211 */         break;
/*      */       case 'V': 
/*  213 */         result.append('F');
/*  214 */         index = charAt(value, index + 1) == 'V' ? index + 2 : index + 1;
/*  215 */         break;
/*      */       case 'W': 
/*  217 */         index = handleW(value, result, index);
/*  218 */         break;
/*      */       case 'X': 
/*  220 */         index = handleX(value, result, index);
/*  221 */         break;
/*      */       case 'Z': 
/*  223 */         index = handleZ(value, result, index, slavoGermanic);
/*  224 */         break;
/*      */       default: 
/*  226 */         index++;
/*      */       }
/*      */       
/*      */     }
/*      */     
/*  231 */     return alternate ? result.getAlternate() : result.getPrimary();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object encode(Object obj)
/*      */     throws EncoderException
/*      */   {
/*  244 */     if (!(obj instanceof String)) {
/*  245 */       throw new EncoderException("DoubleMetaphone encode parameter is not of type String");
/*      */     }
/*  247 */     return doubleMetaphone((String)obj);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String encode(String value)
/*      */   {
/*  258 */     return doubleMetaphone(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isDoubleMetaphoneEqual(String value1, String value2)
/*      */   {
/*  272 */     return isDoubleMetaphoneEqual(value1, value2, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isDoubleMetaphoneEqual(String value1, String value2, boolean alternate)
/*      */   {
/*  288 */     return doubleMetaphone(value1, alternate).equals(doubleMetaphone(value2, alternate));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxCodeLen()
/*      */   {
/*  297 */     return this.maxCodeLen;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxCodeLen(int maxCodeLen)
/*      */   {
/*  305 */     this.maxCodeLen = maxCodeLen;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int handleAEIOUY(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  315 */     if (index == 0) {
/*  316 */       result.append('A');
/*      */     }
/*  318 */     return index + 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int handleC(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  327 */     if (conditionC0(value, index)) {
/*  328 */       result.append('K');
/*  329 */       index += 2;
/*  330 */     } else if ((index == 0) && (contains(value, index, 6, "CAESAR"))) {
/*  331 */       result.append('S');
/*  332 */       index += 2;
/*  333 */     } else if (contains(value, index, 2, "CH")) {
/*  334 */       index = handleCH(value, result, index);
/*  335 */     } else if ((contains(value, index, 2, "CZ")) && (!contains(value, index - 2, 4, "WICZ")))
/*      */     {
/*      */ 
/*  338 */       result.append('S', 'X');
/*  339 */       index += 2;
/*  340 */     } else if (contains(value, index + 1, 3, "CIA"))
/*      */     {
/*  342 */       result.append('X');
/*  343 */       index += 3;
/*  344 */     } else { if ((contains(value, index, 2, "CC")) && ((index != 1) || (charAt(value, 0) != 'M')))
/*      */       {
/*      */ 
/*  347 */         return handleCC(value, result, index); }
/*  348 */       if (contains(value, index, 2, "CK", "CG", "CQ")) {
/*  349 */         result.append('K');
/*  350 */         index += 2;
/*  351 */       } else if (contains(value, index, 2, "CI", "CE", "CY"))
/*      */       {
/*  353 */         if (contains(value, index, 3, "CIO", "CIE", "CIA")) {
/*  354 */           result.append('S', 'X');
/*      */         } else {
/*  356 */           result.append('S');
/*      */         }
/*  358 */         index += 2;
/*      */       } else {
/*  360 */         result.append('K');
/*  361 */         if (contains(value, index + 1, 2, " C", " Q", " G"))
/*      */         {
/*  363 */           index += 3;
/*  364 */         } else if ((contains(value, index + 1, 1, "C", "K", "Q")) && (!contains(value, index + 1, 2, "CE", "CI")))
/*      */         {
/*  366 */           index += 2;
/*      */         } else {
/*  368 */           index++;
/*      */         }
/*      */       }
/*      */     }
/*  372 */     return index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int handleCC(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  381 */     if ((contains(value, index + 2, 1, "I", "E", "H")) && (!contains(value, index + 2, 2, "HU")))
/*      */     {
/*      */ 
/*  384 */       if (((index == 1) && (charAt(value, index - 1) == 'A')) || (contains(value, index - 1, 5, "UCCEE", "UCCES")))
/*      */       {
/*      */ 
/*  387 */         result.append("KS");
/*      */       }
/*      */       else {
/*  390 */         result.append('X');
/*      */       }
/*  392 */       index += 3;
/*      */     } else {
/*  394 */       result.append('K');
/*  395 */       index += 2;
/*      */     }
/*      */     
/*  398 */     return index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int handleCH(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  407 */     if ((index > 0) && (contains(value, index, 4, "CHAE"))) {
/*  408 */       result.append('K', 'X');
/*  409 */       return index + 2; }
/*  410 */     if (conditionCH0(value, index))
/*      */     {
/*  412 */       result.append('K');
/*  413 */       return index + 2; }
/*  414 */     if (conditionCH1(value, index))
/*      */     {
/*  416 */       result.append('K');
/*  417 */       return index + 2;
/*      */     }
/*  419 */     if (index > 0) {
/*  420 */       if (contains(value, 0, 2, "MC")) {
/*  421 */         result.append('K');
/*      */       } else {
/*  423 */         result.append('X', 'K');
/*      */       }
/*      */     } else {
/*  426 */       result.append('X');
/*      */     }
/*  428 */     return index + 2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int handleD(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  438 */     if (contains(value, index, 2, "DG"))
/*      */     {
/*  440 */       if (contains(value, index + 2, 1, "I", "E", "Y")) {
/*  441 */         result.append('J');
/*  442 */         index += 3;
/*      */       }
/*      */       else {
/*  445 */         result.append("TK");
/*  446 */         index += 2;
/*      */       }
/*  448 */     } else if (contains(value, index, 2, "DT", "DD")) {
/*  449 */       result.append('T');
/*  450 */       index += 2;
/*      */     } else {
/*  452 */       result.append('T');
/*  453 */       index++;
/*      */     }
/*  455 */     return index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int handleG(String value, DoubleMetaphoneResult result, int index, boolean slavoGermanic)
/*      */   {
/*  465 */     if (charAt(value, index + 1) == 'H') {
/*  466 */       index = handleGH(value, result, index);
/*  467 */     } else if (charAt(value, index + 1) == 'N') {
/*  468 */       if ((index == 1) && (isVowel(charAt(value, 0))) && (!slavoGermanic)) {
/*  469 */         result.append("KN", "N");
/*  470 */       } else if ((!contains(value, index + 2, 2, "EY")) && (charAt(value, index + 1) != 'Y') && (!slavoGermanic))
/*      */       {
/*  472 */         result.append("N", "KN");
/*      */       } else {
/*  474 */         result.append("KN");
/*      */       }
/*  476 */       index += 2;
/*  477 */     } else if ((contains(value, index + 1, 2, "LI")) && (!slavoGermanic)) {
/*  478 */       result.append("KL", "L");
/*  479 */       index += 2;
/*  480 */     } else if ((index == 0) && ((charAt(value, index + 1) == 'Y') || (contains(value, index + 1, 2, ES_EP_EB_EL_EY_IB_IL_IN_IE_EI_ER))))
/*      */     {
/*  482 */       result.append('K', 'J');
/*  483 */       index += 2;
/*  484 */     } else if (((contains(value, index + 1, 2, "ER")) || (charAt(value, index + 1) == 'Y')) && (!contains(value, 0, 6, "DANGER", "RANGER", "MANGER")) && (!contains(value, index - 1, 1, "E", "I")) && (!contains(value, index - 1, 3, "RGY", "OGY")))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  490 */       result.append('K', 'J');
/*  491 */       index += 2;
/*  492 */     } else if ((contains(value, index + 1, 1, "E", "I", "Y")) || (contains(value, index - 1, 4, "AGGI", "OGGI")))
/*      */     {
/*      */ 
/*  495 */       if ((contains(value, 0, 4, "VAN ", "VON ")) || (contains(value, 0, 3, "SCH")) || (contains(value, index + 1, 2, "ET")))
/*      */       {
/*  497 */         result.append('K');
/*  498 */       } else if (contains(value, index + 1, 4, "IER")) {
/*  499 */         result.append('J');
/*      */       } else {
/*  501 */         result.append('J', 'K');
/*      */       }
/*  503 */       index += 2;
/*  504 */     } else if (charAt(value, index + 1) == 'G') {
/*  505 */       index += 2;
/*  506 */       result.append('K');
/*      */     } else {
/*  508 */       index++;
/*  509 */       result.append('K');
/*      */     }
/*  511 */     return index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int handleGH(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  520 */     if ((index > 0) && (!isVowel(charAt(value, index - 1)))) {
/*  521 */       result.append('K');
/*  522 */       index += 2;
/*  523 */     } else if (index == 0) {
/*  524 */       if (charAt(value, index + 2) == 'I') {
/*  525 */         result.append('J');
/*      */       } else {
/*  527 */         result.append('K');
/*      */       }
/*  529 */       index += 2;
/*  530 */     } else if (((index > 1) && (contains(value, index - 2, 1, "B", "H", "D"))) || ((index > 2) && (contains(value, index - 3, 1, "B", "H", "D"))) || ((index > 3) && (contains(value, index - 4, 1, "B", "H"))))
/*      */     {
/*      */ 
/*      */ 
/*  534 */       index += 2;
/*      */     } else {
/*  536 */       if ((index > 2) && (charAt(value, index - 1) == 'U') && (contains(value, index - 3, 1, "C", "G", "L", "R", "T")))
/*      */       {
/*      */ 
/*  539 */         result.append('F');
/*  540 */       } else if ((index > 0) && (charAt(value, index - 1) != 'I')) {
/*  541 */         result.append('K');
/*      */       }
/*  543 */       index += 2;
/*      */     }
/*  545 */     return index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int handleH(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  555 */     if (((index == 0) || (isVowel(charAt(value, index - 1)))) && (isVowel(charAt(value, index + 1))))
/*      */     {
/*  557 */       result.append('H');
/*  558 */       index += 2;
/*      */     }
/*      */     else {
/*  561 */       index++;
/*      */     }
/*  563 */     return index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int handleJ(String value, DoubleMetaphoneResult result, int index, boolean slavoGermanic)
/*      */   {
/*  571 */     if ((contains(value, index, 4, "JOSE")) || (contains(value, 0, 4, "SAN ")))
/*      */     {
/*  573 */       if (((index == 0) && (charAt(value, index + 4) == ' ')) || (value.length() == 4) || (contains(value, 0, 4, "SAN ")))
/*      */       {
/*  575 */         result.append('H');
/*      */       } else {
/*  577 */         result.append('J', 'H');
/*      */       }
/*  579 */       index++;
/*      */     } else {
/*  581 */       if ((index == 0) && (!contains(value, index, 4, "JOSE"))) {
/*  582 */         result.append('J', 'A');
/*  583 */       } else if ((isVowel(charAt(value, index - 1))) && (!slavoGermanic) && ((charAt(value, index + 1) == 'A') || (charAt(value, index + 1) == 'O')))
/*      */       {
/*  585 */         result.append('J', 'H');
/*  586 */       } else if (index == value.length() - 1) {
/*  587 */         result.append('J', ' ');
/*  588 */       } else if ((!contains(value, index + 1, 1, L_T_K_S_N_M_B_Z)) && (!contains(value, index - 1, 1, "S", "K", "L"))) {
/*  589 */         result.append('J');
/*      */       }
/*      */       
/*  592 */       if (charAt(value, index + 1) == 'J') {
/*  593 */         index += 2;
/*      */       } else {
/*  595 */         index++;
/*      */       }
/*      */     }
/*  598 */     return index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int handleL(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  607 */     result.append('L');
/*  608 */     if (charAt(value, index + 1) == 'L') {
/*  609 */       if (conditionL0(value, index)) {
/*  610 */         result.appendAlternate(' ');
/*      */       }
/*  612 */       index += 2;
/*      */     } else {
/*  614 */       index++;
/*      */     }
/*  616 */     return index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int handleP(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  625 */     if (charAt(value, index + 1) == 'H') {
/*  626 */       result.append('F');
/*  627 */       index += 2;
/*      */     } else {
/*  629 */       result.append('P');
/*  630 */       index = contains(value, index + 1, 1, "P", "B") ? index + 2 : index + 1;
/*      */     }
/*  632 */     return index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int handleR(String value, DoubleMetaphoneResult result, int index, boolean slavoGermanic)
/*      */   {
/*  642 */     if ((index == value.length() - 1) && (!slavoGermanic) && (contains(value, index - 2, 2, "IE")) && (!contains(value, index - 4, 2, "ME", "MA")))
/*      */     {
/*      */ 
/*  645 */       result.appendAlternate('R');
/*      */     } else {
/*  647 */       result.append('R');
/*      */     }
/*  649 */     return charAt(value, index + 1) == 'R' ? index + 2 : index + 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int handleS(String value, DoubleMetaphoneResult result, int index, boolean slavoGermanic)
/*      */   {
/*  659 */     if (contains(value, index - 1, 3, "ISL", "YSL"))
/*      */     {
/*  661 */       index++;
/*  662 */     } else if ((index == 0) && (contains(value, index, 5, "SUGAR")))
/*      */     {
/*  664 */       result.append('X', 'S');
/*  665 */       index++;
/*  666 */     } else if (contains(value, index, 2, "SH")) {
/*  667 */       if (contains(value, index + 1, 4, "HEIM", "HOEK", "HOLM", "HOLZ"))
/*      */       {
/*      */ 
/*  670 */         result.append('S');
/*      */       } else {
/*  672 */         result.append('X');
/*      */       }
/*  674 */       index += 2;
/*  675 */     } else if ((contains(value, index, 3, "SIO", "SIA")) || (contains(value, index, 4, "SIAN")))
/*      */     {
/*  677 */       if (slavoGermanic) {
/*  678 */         result.append('S');
/*      */       } else {
/*  680 */         result.append('S', 'X');
/*      */       }
/*  682 */       index += 3;
/*  683 */     } else if (((index == 0) && (contains(value, index + 1, 1, "M", "N", "L", "W"))) || (contains(value, index + 1, 1, "Z")))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  688 */       result.append('S', 'X');
/*  689 */       index = contains(value, index + 1, 1, "Z") ? index + 2 : index + 1;
/*  690 */     } else if (contains(value, index, 2, "SC")) {
/*  691 */       index = handleSC(value, result, index);
/*      */     } else {
/*  693 */       if ((index == value.length() - 1) && (contains(value, index - 2, 2, "AI", "OI")))
/*      */       {
/*      */ 
/*  696 */         result.appendAlternate('S');
/*      */       } else {
/*  698 */         result.append('S');
/*      */       }
/*  700 */       index = contains(value, index + 1, 1, "S", "Z") ? index + 2 : index + 1;
/*      */     }
/*  702 */     return index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int handleSC(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  711 */     if (charAt(value, index + 2) == 'H')
/*      */     {
/*  713 */       if (contains(value, index + 3, 2, "OO", "ER", "EN", "UY", "ED", "EM"))
/*      */       {
/*      */ 
/*  716 */         if (contains(value, index + 3, 2, "ER", "EN"))
/*      */         {
/*  718 */           result.append("X", "SK");
/*      */         } else {
/*  720 */           result.append("SK");
/*      */         }
/*      */       }
/*  723 */       else if ((index == 0) && (!isVowel(charAt(value, 3))) && (charAt(value, 3) != 'W')) {
/*  724 */         result.append('X', 'S');
/*      */       } else {
/*  726 */         result.append('X');
/*      */       }
/*      */     }
/*  729 */     else if (contains(value, index + 2, 1, "I", "E", "Y")) {
/*  730 */       result.append('S');
/*      */     } else {
/*  732 */       result.append("SK");
/*      */     }
/*  734 */     return index + 3;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int handleT(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  743 */     if (contains(value, index, 4, "TION")) {
/*  744 */       result.append('X');
/*  745 */       index += 3;
/*  746 */     } else if (contains(value, index, 3, "TIA", "TCH")) {
/*  747 */       result.append('X');
/*  748 */       index += 3;
/*  749 */     } else if ((contains(value, index, 2, "TH")) || (contains(value, index, 3, "TTH")))
/*      */     {
/*  751 */       if ((contains(value, index + 2, 2, "OM", "AM")) || (contains(value, 0, 4, "VAN ", "VON ")) || (contains(value, 0, 3, "SCH")))
/*      */       {
/*      */ 
/*      */ 
/*  755 */         result.append('T');
/*      */       } else {
/*  757 */         result.append('0', 'T');
/*      */       }
/*  759 */       index += 2;
/*      */     } else {
/*  761 */       result.append('T');
/*  762 */       index = contains(value, index + 1, 1, "T", "D") ? index + 2 : index + 1;
/*      */     }
/*  764 */     return index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int handleW(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  773 */     if (contains(value, index, 2, "WR"))
/*      */     {
/*  775 */       result.append('R');
/*  776 */       index += 2;
/*      */     }
/*  778 */     else if ((index == 0) && ((isVowel(charAt(value, index + 1))) || (contains(value, index, 2, "WH"))))
/*      */     {
/*  780 */       if (isVowel(charAt(value, index + 1)))
/*      */       {
/*  782 */         result.append('A', 'F');
/*      */       }
/*      */       else {
/*  785 */         result.append('A');
/*      */       }
/*  787 */       index++;
/*  788 */     } else if (((index == value.length() - 1) && (isVowel(charAt(value, index - 1)))) || (contains(value, index - 1, 5, "EWSKI", "EWSKY", "OWSKI", "OWSKY")) || (contains(value, 0, 3, "SCH")))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  793 */       result.appendAlternate('F');
/*  794 */       index++;
/*  795 */     } else if (contains(value, index, 4, "WICZ", "WITZ"))
/*      */     {
/*  797 */       result.append("TS", "FX");
/*  798 */       index += 4;
/*      */     } else {
/*  800 */       index++;
/*      */     }
/*      */     
/*  803 */     return index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int handleX(String value, DoubleMetaphoneResult result, int index)
/*      */   {
/*  812 */     if (index == 0) {
/*  813 */       result.append('S');
/*  814 */       index++;
/*      */     } else {
/*  816 */       if ((index != value.length() - 1) || ((!contains(value, index - 3, 3, "IAU", "EAU")) && (!contains(value, index - 2, 2, "AU", "OU"))))
/*      */       {
/*      */ 
/*      */ 
/*  820 */         result.append("KS");
/*      */       }
/*  822 */       index = contains(value, index + 1, 1, "C", "X") ? index + 2 : index + 1;
/*      */     }
/*  824 */     return index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int handleZ(String value, DoubleMetaphoneResult result, int index, boolean slavoGermanic)
/*      */   {
/*  832 */     if (charAt(value, index + 1) == 'H')
/*      */     {
/*  834 */       result.append('J');
/*  835 */       index += 2;
/*      */     } else {
/*  837 */       if ((contains(value, index + 1, 2, "ZO", "ZI", "ZA")) || ((slavoGermanic) && (index > 0) && (charAt(value, index - 1) != 'T'))) {
/*  838 */         result.append("S", "TS");
/*      */       } else {
/*  840 */         result.append('S');
/*      */       }
/*  842 */       index = charAt(value, index + 1) == 'Z' ? index + 2 : index + 1;
/*      */     }
/*  844 */     return index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean conditionC0(String value, int index)
/*      */   {
/*  853 */     if (contains(value, index, 4, "CHIA"))
/*  854 */       return true;
/*  855 */     if (index <= 1)
/*  856 */       return false;
/*  857 */     if (isVowel(charAt(value, index - 2)))
/*  858 */       return false;
/*  859 */     if (!contains(value, index - 1, 3, "ACH")) {
/*  860 */       return false;
/*      */     }
/*  862 */     char c = charAt(value, index + 2);
/*  863 */     if (((c != 'I') && (c != 'E')) || (contains(value, index - 2, 6, "BACHER", "MACHER")))
/*      */     {
/*  865 */       return true;
/*      */     }
/*  867 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean conditionCH0(String value, int index)
/*      */   {
/*  876 */     if (index != 0)
/*  877 */       return false;
/*  878 */     if ((!contains(value, index + 1, 5, "HARAC", "HARIS")) && (!contains(value, index + 1, 3, "HOR", "HYM", "HIA", "HEM")))
/*      */     {
/*  880 */       return false; }
/*  881 */     if (contains(value, 0, 5, "CHORE")) {
/*  882 */       return false;
/*      */     }
/*  884 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean conditionCH1(String value, int index)
/*      */   {
/*  892 */     return (contains(value, 0, 4, "VAN ", "VON ")) || (contains(value, 0, 3, "SCH")) || (contains(value, index - 2, 6, "ORCHES", "ARCHIT", "ORCHID")) || (contains(value, index + 2, 1, "T", "S")) || (((contains(value, index - 1, 1, "A", "O", "U", "E")) || (index == 0)) && ((contains(value, index + 2, 1, L_R_N_M_B_H_F_V_W_SPACE)) || (index + 1 == value.length() - 1)));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean conditionL0(String value, int index)
/*      */   {
/*  904 */     if ((index == value.length() - 3) && (contains(value, index - 1, 4, "ILLO", "ILLA", "ALLE")))
/*      */     {
/*  906 */       return true; }
/*  907 */     if (((contains(value, index - 1, 2, "AS", "OS")) || (contains(value, value.length() - 1, 1, "A", "O"))) && (contains(value, index - 1, 4, "ALLE")))
/*      */     {
/*      */ 
/*  910 */       return true;
/*      */     }
/*  912 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean conditionM0(String value, int index)
/*      */   {
/*  920 */     if (charAt(value, index + 1) == 'M') {
/*  921 */       return true;
/*      */     }
/*  923 */     return (contains(value, index - 1, 3, "UMB")) && ((index + 1 == value.length() - 1) || (contains(value, index + 2, 2, "ER")));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isSlavoGermanic(String value)
/*      */   {
/*  936 */     return (value.indexOf('W') > -1) || (value.indexOf('K') > -1) || (value.indexOf("CZ") > -1) || (value.indexOf("WITZ") > -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isVowel(char ch)
/*      */   {
/*  944 */     return "AEIOUY".indexOf(ch) != -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isSilentStart(String value)
/*      */   {
/*  953 */     boolean result = false;
/*  954 */     for (int i = 0; i < SILENT_START.length; i++) {
/*  955 */       if (value.startsWith(SILENT_START[i])) {
/*  956 */         result = true;
/*  957 */         break;
/*      */       }
/*      */     }
/*  960 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private String cleanInput(String input)
/*      */   {
/*  967 */     if (input == null) {
/*  968 */       return null;
/*      */     }
/*  970 */     input = input.trim();
/*  971 */     if (input.length() == 0) {
/*  972 */       return null;
/*      */     }
/*  974 */     return input.toUpperCase();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected char charAt(String value, int index)
/*      */   {
/*  985 */     if ((index < 0) || (index >= value.length())) {
/*  986 */       return '\000';
/*      */     }
/*  988 */     return value.charAt(index);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static boolean contains(String value, int start, int length, String criteria)
/*      */   {
/*  997 */     return contains(value, start, length, new String[] { criteria });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static boolean contains(String value, int start, int length, String criteria1, String criteria2)
/*      */   {
/* 1006 */     return contains(value, start, length, new String[] { criteria1, criteria2 });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static boolean contains(String value, int start, int length, String criteria1, String criteria2, String criteria3)
/*      */   {
/* 1016 */     return contains(value, start, length, new String[] { criteria1, criteria2, criteria3 });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static boolean contains(String value, int start, int length, String criteria1, String criteria2, String criteria3, String criteria4)
/*      */   {
/* 1026 */     return contains(value, start, length, new String[] { criteria1, criteria2, criteria3, criteria4 });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static boolean contains(String value, int start, int length, String criteria1, String criteria2, String criteria3, String criteria4, String criteria5)
/*      */   {
/* 1038 */     return contains(value, start, length, new String[] { criteria1, criteria2, criteria3, criteria4, criteria5 });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static boolean contains(String value, int start, int length, String criteria1, String criteria2, String criteria3, String criteria4, String criteria5, String criteria6)
/*      */   {
/* 1050 */     return contains(value, start, length, new String[] { criteria1, criteria2, criteria3, criteria4, criteria5, criteria6 });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static boolean contains(String value, int start, int length, String[] criteria)
/*      */   {
/* 1062 */     boolean result = false;
/* 1063 */     if ((start >= 0) && (start + length <= value.length())) {
/* 1064 */       String target = value.substring(start, start + length);
/*      */       
/* 1066 */       for (int i = 0; i < criteria.length; i++) {
/* 1067 */         if (target.equals(criteria[i])) {
/* 1068 */           result = true;
/* 1069 */           break;
/*      */         }
/*      */       }
/*      */     }
/* 1073 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public class DoubleMetaphoneResult
/*      */   {
/* 1084 */     private StringBuffer primary = new StringBuffer(DoubleMetaphone.this.getMaxCodeLen());
/* 1085 */     private StringBuffer alternate = new StringBuffer(DoubleMetaphone.this.getMaxCodeLen());
/*      */     private int maxLength;
/*      */     
/*      */     public DoubleMetaphoneResult(int maxLength) {
/* 1089 */       this.maxLength = maxLength;
/*      */     }
/*      */     
/*      */     public void append(char value) {
/* 1093 */       appendPrimary(value);
/* 1094 */       appendAlternate(value);
/*      */     }
/*      */     
/*      */     public void append(char primary, char alternate) {
/* 1098 */       appendPrimary(primary);
/* 1099 */       appendAlternate(alternate);
/*      */     }
/*      */     
/*      */     public void appendPrimary(char value) {
/* 1103 */       if (this.primary.length() < this.maxLength) {
/* 1104 */         this.primary.append(value);
/*      */       }
/*      */     }
/*      */     
/*      */     public void appendAlternate(char value) {
/* 1109 */       if (this.alternate.length() < this.maxLength) {
/* 1110 */         this.alternate.append(value);
/*      */       }
/*      */     }
/*      */     
/*      */     public void append(String value) {
/* 1115 */       appendPrimary(value);
/* 1116 */       appendAlternate(value);
/*      */     }
/*      */     
/*      */     public void append(String primary, String alternate) {
/* 1120 */       appendPrimary(primary);
/* 1121 */       appendAlternate(alternate);
/*      */     }
/*      */     
/*      */     public void appendPrimary(String value) {
/* 1125 */       int addChars = this.maxLength - this.primary.length();
/* 1126 */       if (value.length() <= addChars) {
/* 1127 */         this.primary.append(value);
/*      */       } else {
/* 1129 */         this.primary.append(value.substring(0, addChars));
/*      */       }
/*      */     }
/*      */     
/*      */     public void appendAlternate(String value) {
/* 1134 */       int addChars = this.maxLength - this.alternate.length();
/* 1135 */       if (value.length() <= addChars) {
/* 1136 */         this.alternate.append(value);
/*      */       } else {
/* 1138 */         this.alternate.append(value.substring(0, addChars));
/*      */       }
/*      */     }
/*      */     
/*      */     public String getPrimary() {
/* 1143 */       return this.primary.toString();
/*      */     }
/*      */     
/*      */     public String getAlternate() {
/* 1147 */       return this.alternate.toString();
/*      */     }
/*      */     
/*      */     public boolean isComplete() {
/* 1151 */       return (this.primary.length() >= this.maxLength) && (this.alternate.length() >= this.maxLength);
/*      */     }
/*      */   }
/*      */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-codec-1.2.jar!\org\apache\commons\codec\language\DoubleMetaphone.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */