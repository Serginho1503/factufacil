/*     */ package org.apache.commons.codec.net;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.BitSet;
/*     */ import org.apache.commons.codec.BinaryDecoder;
/*     */ import org.apache.commons.codec.BinaryEncoder;
/*     */ import org.apache.commons.codec.DecoderException;
/*     */ import org.apache.commons.codec.EncoderException;
/*     */ import org.apache.commons.codec.StringDecoder;
/*     */ import org.apache.commons.codec.StringEncoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class URLCodec
/*     */   implements BinaryEncoder, BinaryDecoder, StringEncoder, StringDecoder
/*     */ {
/*     */   private static final String US_ASCII = "US-ASCII";
/* 102 */   protected String encoding = "UTF-8";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 107 */   protected static final BitSet WWW_FORM_URL = new BitSet(256);
/*     */   
/*     */ 
/*     */   static
/*     */   {
/* 112 */     for (int i = 97; i <= 122; i++) {
/* 113 */       WWW_FORM_URL.set(i);
/*     */     }
/* 115 */     for (int i = 65; i <= 90; i++) {
/* 116 */       WWW_FORM_URL.set(i);
/*     */     }
/*     */     
/* 119 */     for (int i = 48; i <= 57; i++) {
/* 120 */       WWW_FORM_URL.set(i);
/*     */     }
/*     */     
/* 123 */     WWW_FORM_URL.set(45);
/* 124 */     WWW_FORM_URL.set(95);
/* 125 */     WWW_FORM_URL.set(46);
/* 126 */     WWW_FORM_URL.set(42);
/*     */     
/* 128 */     WWW_FORM_URL.set(32);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public URLCodec(String encoding)
/*     */   {
/* 146 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final byte[] encodeUrl(BitSet urlsafe, byte[] pArray)
/*     */   {
/* 159 */     if (pArray == null) {
/* 160 */       return null;
/*     */     }
/* 162 */     if (urlsafe == null) {
/* 163 */       urlsafe = WWW_FORM_URL;
/*     */     }
/*     */     
/* 166 */     ByteArrayOutputStream buffer = new ByteArrayOutputStream();
/* 167 */     for (int i = 0; i < pArray.length; i++) {
/* 168 */       int b = pArray[i];
/* 169 */       if ((b >= 0) && (urlsafe.get(b))) {
/* 170 */         if (b == 32) {
/* 171 */           b = 43;
/*     */         }
/* 173 */         buffer.write(b);
/*     */       } else {
/* 175 */         buffer.write(37);
/* 176 */         char hex1 = Character.toUpperCase(Character.forDigit(b >> 4 & 0xF, 16));
/*     */         
/* 178 */         char hex2 = Character.toUpperCase(Character.forDigit(b & 0xF, 16));
/*     */         
/* 180 */         buffer.write(hex1);
/* 181 */         buffer.write(hex2);
/*     */       }
/*     */     }
/* 184 */     return buffer.toByteArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final byte[] decodeUrl(byte[] pArray)
/*     */     throws DecoderException
/*     */   {
/* 200 */     if (pArray == null) {
/* 201 */       return null;
/*     */     }
/* 203 */     ByteArrayOutputStream buffer = new ByteArrayOutputStream();
/* 204 */     for (int i = 0; i < pArray.length; i++) {
/* 205 */       int b = pArray[i];
/* 206 */       if (b == 43) {
/* 207 */         buffer.write(32);
/* 208 */       } else if (b == 37) {
/*     */         try {
/* 210 */           int u = Character.digit((char)pArray[(++i)], 16);
/* 211 */           int l = Character.digit((char)pArray[(++i)], 16);
/* 212 */           if ((u == -1) || (l == -1)) {
/* 213 */             throw new DecoderException("Invalid URL encoding");
/*     */           }
/* 215 */           buffer.write((char)((u << 4) + l));
/*     */         } catch (ArrayIndexOutOfBoundsException e) {
/* 217 */           throw new DecoderException("Invalid URL encoding");
/*     */         }
/*     */       } else {
/* 220 */         buffer.write(b);
/*     */       }
/*     */     }
/* 223 */     return buffer.toByteArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] encode(byte[] pArray)
/*     */   {
/* 235 */     return encodeUrl(WWW_FORM_URL, pArray);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] decode(byte[] pArray)
/*     */     throws DecoderException
/*     */   {
/* 249 */     return decodeUrl(pArray);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String encode(String pString, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 266 */     if (pString == null) {
/* 267 */       return null;
/*     */     }
/* 269 */     return new String(encode(pString.getBytes(encoding)), "US-ASCII");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String encode(String pString)
/*     */     throws EncoderException
/*     */   {
/* 282 */     if (pString == null) {
/* 283 */       return null;
/*     */     }
/*     */     try {
/* 286 */       return encode(pString, getEncoding());
/*     */     } catch (UnsupportedEncodingException e) {
/* 288 */       throw new EncoderException(e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String decode(String pString, String encoding)
/*     */     throws DecoderException, UnsupportedEncodingException
/*     */   {
/* 308 */     if (pString == null) {
/* 309 */       return null;
/*     */     }
/* 311 */     return new String(decode(pString.getBytes("US-ASCII")), encoding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String decode(String pString)
/*     */     throws DecoderException
/*     */   {
/* 324 */     if (pString == null) {
/* 325 */       return null;
/*     */     }
/*     */     try {
/* 328 */       return decode(pString, getEncoding());
/*     */     } catch (UnsupportedEncodingException e) {
/* 330 */       throw new DecoderException(e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object encode(Object pObject)
/*     */     throws EncoderException
/*     */   {
/* 345 */     if (pObject == null)
/* 346 */       return null;
/* 347 */     if ((pObject instanceof byte[]))
/* 348 */       return encode((byte[])pObject);
/* 349 */     if ((pObject instanceof String)) {
/* 350 */       return encode((String)pObject);
/*     */     }
/* 352 */     throw new EncoderException("Objects of type " + pObject.getClass().getName() + " cannot be URL encoded");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object decode(Object pObject)
/*     */     throws DecoderException
/*     */   {
/* 369 */     if (pObject == null)
/* 370 */       return null;
/* 371 */     if ((pObject instanceof byte[]))
/* 372 */       return decode((byte[])pObject);
/* 373 */     if ((pObject instanceof String)) {
/* 374 */       return decode((String)pObject);
/*     */     }
/* 376 */     throw new DecoderException("Objects of type " + pObject.getClass().getName() + " cannot be URL decoded");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getEncoding()
/*     */   {
/* 388 */     return this.encoding;
/*     */   }
/*     */   
/*     */   public URLCodec() {}
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-codec-1.2.jar!\org\apache\commons\codec\net\URLCodec.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */