/*     */ package org.apache.commons.codec.binary;
/*     */ 
/*     */ import org.apache.commons.codec.BinaryDecoder;
/*     */ import org.apache.commons.codec.BinaryEncoder;
/*     */ import org.apache.commons.codec.DecoderException;
/*     */ import org.apache.commons.codec.EncoderException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Base64
/*     */   implements BinaryEncoder, BinaryDecoder
/*     */ {
/*     */   static final int CHUNK_SIZE = 76;
/*  89 */   static final byte[] CHUNK_SEPARATOR = "\n".getBytes();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int BASELENGTH = 255;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int LOOKUPLENGTH = 64;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int EIGHTBIT = 8;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int SIXTEENBIT = 16;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int TWENTYFOURBITGROUP = 24;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int FOURBYTE = 4;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int SIGN = -128;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final byte PAD = 61;
/*     */   
/*     */ 
/*     */ 
/* 133 */   private static byte[] base64Alphabet = new byte['ÿ'];
/* 134 */   private static byte[] lookUpBase64Alphabet = new byte[64];
/*     */   
/*     */   static
/*     */   {
/* 138 */     for (int i = 0; i < 255; i++) {
/* 139 */       base64Alphabet[i] = -1;
/*     */     }
/* 141 */     for (int i = 90; i >= 65; i--) {
/* 142 */       base64Alphabet[i] = ((byte)(i - 65));
/*     */     }
/* 144 */     for (int i = 122; i >= 97; i--) {
/* 145 */       base64Alphabet[i] = ((byte)(i - 97 + 26));
/*     */     }
/* 147 */     for (int i = 57; i >= 48; i--) {
/* 148 */       base64Alphabet[i] = ((byte)(i - 48 + 52));
/*     */     }
/*     */     
/* 151 */     base64Alphabet[43] = 62;
/* 152 */     base64Alphabet[47] = 63;
/*     */     
/* 154 */     for (int i = 0; i <= 25; i++) {
/* 155 */       lookUpBase64Alphabet[i] = ((byte)(65 + i));
/*     */     }
/*     */     
/* 158 */     int i = 26; for (int j = 0; i <= 51; j++) {
/* 159 */       lookUpBase64Alphabet[i] = ((byte)(97 + j));i++;
/*     */     }
/*     */     
/* 162 */     int i = 52; for (int j = 0; i <= 61; j++) {
/* 163 */       lookUpBase64Alphabet[i] = ((byte)(48 + j));i++;
/*     */     }
/*     */     
/* 166 */     lookUpBase64Alphabet[62] = 43;
/* 167 */     lookUpBase64Alphabet[63] = 47;
/*     */   }
/*     */   
/*     */   private static boolean isBase64(byte octect) {
/* 171 */     if (octect == 61)
/* 172 */       return true;
/* 173 */     if (base64Alphabet[octect] == -1) {
/* 174 */       return false;
/*     */     }
/* 176 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isArrayByteBase64(byte[] arrayOctect)
/*     */   {
/* 190 */     arrayOctect = discardWhitespace(arrayOctect);
/*     */     
/* 192 */     int length = arrayOctect.length;
/* 193 */     if (length == 0)
/*     */     {
/*     */ 
/* 196 */       return true;
/*     */     }
/* 198 */     for (int i = 0; i < length; i++) {
/* 199 */       if (!isBase64(arrayOctect[i])) {
/* 200 */         return false;
/*     */       }
/*     */     }
/* 203 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] encodeBase64(byte[] binaryData)
/*     */   {
/* 214 */     return encodeBase64(binaryData, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] encodeBase64Chunked(byte[] binaryData)
/*     */   {
/* 225 */     return encodeBase64(binaryData, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object decode(Object pObject)
/*     */     throws DecoderException
/*     */   {
/* 245 */     if (!(pObject instanceof byte[])) {
/* 246 */       throw new DecoderException("Parameter supplied to Base64 decode is not a byte[]");
/*     */     }
/* 248 */     Object result = decode((byte[])pObject);
/*     */     
/*     */ 
/* 251 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] decode(byte[] pArray)
/*     */   {
/* 264 */     byte[] result = decodeBase64(pArray);
/* 265 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] encodeBase64(byte[] binaryData, boolean isChunked)
/*     */   {
/* 277 */     int lengthDataBits = binaryData.length * 8;
/* 278 */     int fewerThan24bits = lengthDataBits % 24;
/* 279 */     int numberTriplets = lengthDataBits / 24;
/* 280 */     byte[] encodedData = null;
/* 281 */     int encodedDataLength = 0;
/* 282 */     int nbrChunks = 0;
/*     */     
/* 284 */     if (fewerThan24bits != 0)
/*     */     {
/* 286 */       encodedDataLength = (numberTriplets + 1) * 4;
/*     */     }
/*     */     else {
/* 289 */       encodedDataLength = numberTriplets * 4;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 295 */     if (isChunked)
/*     */     {
/* 297 */       nbrChunks = CHUNK_SEPARATOR.length == 0 ? 0 : (int)Math.ceil(encodedDataLength / 76.0F);
/*     */       
/* 299 */       encodedDataLength += nbrChunks * CHUNK_SEPARATOR.length;
/*     */     }
/*     */     
/* 302 */     encodedData = new byte[encodedDataLength];
/*     */     
/* 304 */     byte k = 0;byte l = 0;byte b1 = 0;byte b2 = 0;byte b3 = 0;
/*     */     
/* 306 */     int encodedIndex = 0;
/* 307 */     int dataIndex = 0;
/* 308 */     int i = 0;
/* 309 */     int nextSeparatorIndex = 76;
/* 310 */     int chunksSoFar = 0;
/*     */     
/*     */ 
/* 313 */     for (i = 0; i < numberTriplets; i++) {
/* 314 */       dataIndex = i * 3;
/* 315 */       b1 = binaryData[dataIndex];
/* 316 */       b2 = binaryData[(dataIndex + 1)];
/* 317 */       b3 = binaryData[(dataIndex + 2)];
/*     */       
/*     */ 
/*     */ 
/* 321 */       l = (byte)(b2 & 0xF);
/* 322 */       k = (byte)(b1 & 0x3);
/*     */       
/* 324 */       byte val1 = (b1 & 0xFFFFFF80) == 0 ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/*     */       
/* 326 */       byte val2 = (b2 & 0xFFFFFF80) == 0 ? (byte)(b2 >> 4) : (byte)(b2 >> 4 ^ 0xF0);
/*     */       
/* 328 */       byte val3 = (b3 & 0xFFFFFF80) == 0 ? (byte)(b3 >> 6) : (byte)(b3 >> 6 ^ 0xFC);
/*     */       
/*     */ 
/* 331 */       encodedData[encodedIndex] = lookUpBase64Alphabet[val1];
/*     */       
/*     */ 
/*     */ 
/* 335 */       encodedData[(encodedIndex + 1)] = lookUpBase64Alphabet[(val2 | k << 4)];
/*     */       
/* 337 */       encodedData[(encodedIndex + 2)] = lookUpBase64Alphabet[(l << 2 | val3)];
/*     */       
/* 339 */       encodedData[(encodedIndex + 3)] = lookUpBase64Alphabet[(b3 & 0x3F)];
/*     */       
/* 341 */       encodedIndex += 4;
/*     */       
/*     */ 
/* 344 */       if (isChunked)
/*     */       {
/* 346 */         if (encodedIndex == nextSeparatorIndex) {
/* 347 */           System.arraycopy(CHUNK_SEPARATOR, 0, encodedData, encodedIndex, CHUNK_SEPARATOR.length);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 353 */           chunksSoFar++;
/* 354 */           nextSeparatorIndex = 76 * (chunksSoFar + 1) + chunksSoFar * CHUNK_SEPARATOR.length;
/*     */           
/*     */ 
/* 357 */           encodedIndex += CHUNK_SEPARATOR.length;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 363 */     dataIndex = i * 3;
/*     */     
/* 365 */     if (fewerThan24bits == 8) {
/* 366 */       b1 = binaryData[dataIndex];
/* 367 */       k = (byte)(b1 & 0x3);
/*     */       
/*     */ 
/* 370 */       byte val1 = (b1 & 0xFFFFFF80) == 0 ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/*     */       
/* 372 */       encodedData[encodedIndex] = lookUpBase64Alphabet[val1];
/* 373 */       encodedData[(encodedIndex + 1)] = lookUpBase64Alphabet[(k << 4)];
/* 374 */       encodedData[(encodedIndex + 2)] = 61;
/* 375 */       encodedData[(encodedIndex + 3)] = 61;
/* 376 */     } else if (fewerThan24bits == 16)
/*     */     {
/* 378 */       b1 = binaryData[dataIndex];
/* 379 */       b2 = binaryData[(dataIndex + 1)];
/* 380 */       l = (byte)(b2 & 0xF);
/* 381 */       k = (byte)(b1 & 0x3);
/*     */       
/* 383 */       byte val1 = (b1 & 0xFFFFFF80) == 0 ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/*     */       
/* 385 */       byte val2 = (b2 & 0xFFFFFF80) == 0 ? (byte)(b2 >> 4) : (byte)(b2 >> 4 ^ 0xF0);
/*     */       
/*     */ 
/* 388 */       encodedData[encodedIndex] = lookUpBase64Alphabet[val1];
/* 389 */       encodedData[(encodedIndex + 1)] = lookUpBase64Alphabet[(val2 | k << 4)];
/*     */       
/* 391 */       encodedData[(encodedIndex + 2)] = lookUpBase64Alphabet[(l << 2)];
/* 392 */       encodedData[(encodedIndex + 3)] = 61;
/*     */     }
/*     */     
/* 395 */     if (isChunked)
/*     */     {
/* 397 */       if (chunksSoFar < nbrChunks) {
/* 398 */         System.arraycopy(CHUNK_SEPARATOR, 0, encodedData, encodedDataLength - CHUNK_SEPARATOR.length, CHUNK_SEPARATOR.length);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 407 */     return encodedData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] decodeBase64(byte[] base64Data)
/*     */   {
/* 418 */     base64Data = discardNonBase64(base64Data);
/*     */     
/*     */ 
/* 421 */     if (base64Data.length == 0) {
/* 422 */       return new byte[0];
/*     */     }
/*     */     
/* 425 */     int numberQuadruple = base64Data.length / 4;
/* 426 */     byte[] decodedData = null;
/* 427 */     byte b1 = 0;byte b2 = 0;byte b3 = 0;byte b4 = 0;byte marker0 = 0;byte marker1 = 0;
/*     */     
/*     */ 
/*     */ 
/* 431 */     int encodedIndex = 0;
/* 432 */     int dataIndex = 0;
/*     */     
/*     */ 
/* 435 */     int lastData = base64Data.length;
/*     */     
/* 437 */     while (base64Data[(lastData - 1)] == 61) {
/* 438 */       lastData--; if (lastData == 0) {
/* 439 */         return new byte[0];
/*     */       }
/*     */     }
/* 442 */     decodedData = new byte[lastData - numberQuadruple];
/*     */     
/*     */ 
/* 445 */     for (int i = 0; i < numberQuadruple; i++) {
/* 446 */       dataIndex = i * 4;
/* 447 */       marker0 = base64Data[(dataIndex + 2)];
/* 448 */       marker1 = base64Data[(dataIndex + 3)];
/*     */       
/* 450 */       b1 = base64Alphabet[base64Data[dataIndex]];
/* 451 */       b2 = base64Alphabet[base64Data[(dataIndex + 1)]];
/*     */       
/* 453 */       if ((marker0 != 61) && (marker1 != 61))
/*     */       {
/* 455 */         b3 = base64Alphabet[marker0];
/* 456 */         b4 = base64Alphabet[marker1];
/*     */         
/* 458 */         decodedData[encodedIndex] = ((byte)(b1 << 2 | b2 >> 4));
/* 459 */         decodedData[(encodedIndex + 1)] = ((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/*     */         
/* 461 */         decodedData[(encodedIndex + 2)] = ((byte)(b3 << 6 | b4));
/* 462 */       } else if (marker0 == 61)
/*     */       {
/* 464 */         decodedData[encodedIndex] = ((byte)(b1 << 2 | b2 >> 4));
/* 465 */       } else if (marker1 == 61)
/*     */       {
/* 467 */         b3 = base64Alphabet[marker0];
/*     */         
/* 469 */         decodedData[encodedIndex] = ((byte)(b1 << 2 | b2 >> 4));
/* 470 */         decodedData[(encodedIndex + 1)] = ((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/*     */       }
/*     */       
/* 473 */       encodedIndex += 3;
/*     */     }
/* 475 */     return decodedData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static byte[] discardWhitespace(byte[] data)
/*     */   {
/* 486 */     byte[] groomedData = new byte[data.length];
/* 487 */     int bytesCopied = 0;
/*     */     
/* 489 */     for (int i = 0; i < data.length; i++) {
/* 490 */       switch (data[i]) {
/*     */       case 9: 
/*     */       case 10: 
/*     */       case 13: 
/*     */       case 32: 
/*     */         break;
/*     */       default: 
/* 497 */         groomedData[(bytesCopied++)] = data[i];
/*     */       }
/*     */       
/*     */     }
/* 501 */     byte[] packedData = new byte[bytesCopied];
/*     */     
/* 503 */     System.arraycopy(groomedData, 0, packedData, 0, bytesCopied);
/*     */     
/* 505 */     return packedData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static byte[] discardNonBase64(byte[] data)
/*     */   {
/* 518 */     byte[] groomedData = new byte[data.length];
/* 519 */     int bytesCopied = 0;
/*     */     
/* 521 */     for (int i = 0; i < data.length; i++) {
/* 522 */       if (isBase64(data[i])) {
/* 523 */         groomedData[(bytesCopied++)] = data[i];
/*     */       }
/*     */     }
/*     */     
/* 527 */     byte[] packedData = new byte[bytesCopied];
/*     */     
/* 529 */     System.arraycopy(groomedData, 0, packedData, 0, bytesCopied);
/*     */     
/* 531 */     return packedData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object encode(Object pObject)
/*     */     throws EncoderException
/*     */   {
/* 553 */     if (!(pObject instanceof byte[])) {
/* 554 */       throw new EncoderException("Parameter supplied to Base64 encode is not a byte[]");
/*     */     }
/*     */     
/* 557 */     Object result = encode((byte[])pObject);
/*     */     
/*     */ 
/* 560 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] encode(byte[] pArray)
/*     */   {
/* 572 */     return encodeBase64(pArray, false);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-codec-1.2.jar!\org\apache\commons\codec\binary\Base64.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */