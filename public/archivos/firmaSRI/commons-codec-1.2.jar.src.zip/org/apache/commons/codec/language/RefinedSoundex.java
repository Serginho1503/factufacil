/*     */ package org.apache.commons.codec.language;
/*     */ 
/*     */ import org.apache.commons.codec.EncoderException;
/*     */ import org.apache.commons.codec.StringEncoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RefinedSoundex
/*     */   implements StringEncoder
/*     */ {
/*  78 */   public static final RefinedSoundex US_ENGLISH = new RefinedSoundex();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */   public static final char[] US_ENGLISH_MAPPING = "01360240043788015936020505".toCharArray();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private char[] soundexMapping;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RefinedSoundex()
/*     */   {
/*  99 */     this(US_ENGLISH_MAPPING);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RefinedSoundex(char[] mapping)
/*     */   {
/* 112 */     this.soundexMapping = mapping;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int difference(String s1, String s2)
/*     */     throws EncoderException
/*     */   {
/* 137 */     return SoundexUtils.difference(this, s1, s2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object encode(Object pObject)
/*     */     throws EncoderException
/*     */   {
/* 155 */     if (!(pObject instanceof String)) {
/* 156 */       throw new EncoderException("Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
/*     */     }
/* 158 */     Object result = soundex((String)pObject);
/*     */     
/* 160 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String encode(String pString)
/*     */   {
/* 171 */     return soundex(pString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private char getMappingCode(char c)
/*     */   {
/* 184 */     if (!Character.isLetter(c)) {
/* 185 */       return '\000';
/*     */     }
/* 187 */     return this.soundexMapping[(Character.toUpperCase(c) - 'A')];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String soundex(String str)
/*     */   {
/* 199 */     if (str == null) {
/* 200 */       return null;
/*     */     }
/* 202 */     str = SoundexUtils.clean(str);
/* 203 */     if (str.length() == 0) {
/* 204 */       return str;
/*     */     }
/*     */     
/* 207 */     StringBuffer sBuf = new StringBuffer();
/* 208 */     sBuf.append(str.charAt(0));
/*     */     
/*     */ 
/* 211 */     char last = '*';
/*     */     
/* 213 */     for (int i = 0; i < str.length(); i++)
/*     */     {
/* 215 */       char current = getMappingCode(str.charAt(i));
/* 216 */       if (current != last)
/*     */       {
/* 218 */         if (current != 0) {
/* 219 */           sBuf.append(current);
/*     */         }
/*     */         
/* 222 */         last = current;
/*     */       }
/*     */     }
/*     */     
/* 226 */     return sBuf.toString();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-codec-1.2.jar!\org\apache\commons\codec\language\RefinedSoundex.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */