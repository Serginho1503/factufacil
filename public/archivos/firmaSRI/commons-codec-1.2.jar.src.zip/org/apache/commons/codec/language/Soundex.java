/*     */ package org.apache.commons.codec.language;
/*     */ 
/*     */ import org.apache.commons.codec.EncoderException;
/*     */ import org.apache.commons.codec.StringEncoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Soundex
/*     */   implements StringEncoder
/*     */ {
/*  80 */   public static final Soundex US_ENGLISH = new Soundex();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  86 */   public static final char[] US_ENGLISH_MAPPING = "01230120022455012623010202".toCharArray();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int difference(String s1, String s2)
/*     */     throws EncoderException
/*     */   {
/* 109 */     return SoundexUtils.difference(this, s1, s2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/* 119 */   private int maxLength = 4;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private char[] soundexMapping;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Soundex()
/*     */   {
/* 133 */     this(US_ENGLISH_MAPPING);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Soundex(char[] mapping)
/*     */   {
/* 146 */     setSoundexMapping(mapping);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object encode(Object pObject)
/*     */     throws EncoderException
/*     */   {
/* 166 */     if (!(pObject instanceof String)) {
/* 167 */       throw new EncoderException("Parameter supplied to Soundex encode is not of type java.lang.String");
/*     */     }
/* 169 */     Object result = soundex((String)pObject);
/*     */     
/*     */ 
/* 172 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String encode(String pString)
/*     */   {
/* 184 */     return soundex(pString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private char getMappingCode(String str, int index)
/*     */   {
/* 200 */     char mappedChar = map(str.charAt(index));
/*     */     
/* 202 */     if ((index > 1) && (mappedChar != '0')) {
/* 203 */       char hwChar = str.charAt(index - 1);
/* 204 */       if (('H' == hwChar) || ('W' == hwChar)) {
/* 205 */         char preHWChar = str.charAt(index - 2);
/* 206 */         char firstCode = map(preHWChar);
/* 207 */         if ((firstCode == mappedChar) || ('H' == preHWChar) || ('W' == preHWChar)) {
/* 208 */           return '\000';
/*     */         }
/*     */       }
/*     */     }
/* 212 */     return mappedChar;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public int getMaxLength()
/*     */   {
/* 223 */     return this.maxLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private char[] getSoundexMapping()
/*     */   {
/* 231 */     return this.soundexMapping;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private char map(char c)
/*     */   {
/* 242 */     return getSoundexMapping()[(c - 'A')];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setMaxLength(int maxLength)
/*     */   {
/* 254 */     this.maxLength = maxLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setSoundexMapping(char[] soundexMapping)
/*     */   {
/* 263 */     this.soundexMapping = soundexMapping;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String soundex(String str)
/*     */   {
/* 274 */     if (str == null) {
/* 275 */       return null;
/*     */     }
/* 277 */     str = SoundexUtils.clean(str);
/* 278 */     if (str.length() == 0) {
/* 279 */       return str;
/*     */     }
/* 281 */     char[] out = { '0', '0', '0', '0' };
/*     */     
/* 283 */     int incount = 1;int count = 1;
/* 284 */     out[0] = str.charAt(0);
/* 285 */     char last = getMappingCode(str, 0);
/* 286 */     while ((incount < str.length()) && (count < out.length)) {
/* 287 */       char mapped = getMappingCode(str, incount++);
/* 288 */       if (mapped != 0) {
/* 289 */         if ((mapped != '0') && (mapped != last)) {
/* 290 */           out[(count++)] = mapped;
/*     */         }
/* 292 */         last = mapped;
/*     */       }
/*     */     }
/* 295 */     return new String(out);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-codec-1.2.jar!\org\apache\commons\codec\language\Soundex.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */