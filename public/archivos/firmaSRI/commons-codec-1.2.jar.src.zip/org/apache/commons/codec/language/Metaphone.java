/*     */ package org.apache.commons.codec.language;
/*     */ 
/*     */ import org.apache.commons.codec.EncoderException;
/*     */ import org.apache.commons.codec.StringEncoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Metaphone
/*     */   implements StringEncoder
/*     */ {
/*  82 */   private String vowels = "AEIOU";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  87 */   private String frontv = "EIY";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  92 */   private String varson = "CSPTG";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  97 */   private int maxCodeLen = 4;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String metaphone(String txt)
/*     */   {
/* 117 */     int mtsz = 0;
/* 118 */     boolean hard = false;
/* 119 */     if ((txt == null) || (txt.length() == 0)) {
/* 120 */       return "";
/*     */     }
/*     */     
/* 123 */     if (txt.length() == 1) {
/* 124 */       return txt.toUpperCase();
/*     */     }
/*     */     
/* 127 */     char[] inwd = txt.toUpperCase().toCharArray();
/*     */     
/*     */ 
/* 130 */     StringBuffer local = new StringBuffer(40);
/* 131 */     StringBuffer code = new StringBuffer(10);
/*     */     
/* 133 */     switch (inwd[0]) {
/*     */     case 'G': 
/*     */     case 'K': 
/*     */     case 'P': 
/* 137 */       if (inwd[1] == 'N') {
/* 138 */         local.append(inwd, 1, inwd.length - 1);
/*     */       } else {
/* 140 */         local.append(inwd);
/*     */       }
/* 142 */       break;
/*     */     case 'A': 
/* 144 */       if (inwd[1] == 'E') {
/* 145 */         local.append(inwd, 1, inwd.length - 1);
/*     */       } else {
/* 147 */         local.append(inwd);
/*     */       }
/* 149 */       break;
/*     */     case 'W': 
/* 151 */       if (inwd[1] == 'R') {
/* 152 */         local.append(inwd, 1, inwd.length - 1);
/*     */ 
/*     */       }
/* 155 */       else if (inwd[1] == 'H') {
/* 156 */         local.append(inwd, 1, inwd.length - 1);
/* 157 */         local.setCharAt(0, 'W');
/*     */       } else {
/* 159 */         local.append(inwd);
/*     */       }
/* 161 */       break;
/*     */     case 'X': 
/* 163 */       inwd[0] = 'S';
/* 164 */       local.append(inwd);
/* 165 */       break;
/*     */     default: 
/* 167 */       local.append(inwd);
/*     */     }
/*     */     
/* 170 */     int wdsz = local.length();
/* 171 */     int n = 0;
/*     */     
/* 173 */     while ((mtsz < getMaxCodeLen()) && (n < wdsz)) {
/* 174 */       char symb = local.charAt(n);
/*     */       
/* 176 */       if ((symb != 'C') && (n > 0) && (local.charAt(n - 1) == symb)) {
/* 177 */         n++;
/*     */       } else {
/* 179 */         switch (symb) {
/*     */         case 'A': case 'E': case 'I': case 'O': case 'U': 
/* 181 */           if (n == 0) {
/* 182 */             code.append(symb);
/* 183 */             mtsz++;
/*     */           }
/*     */           break;
/*     */         case 'B': 
/* 187 */           if ((n > 0) && (n + 1 != wdsz) && (local.charAt(n - 1) == 'M')) {
/* 188 */             code.append(symb);
/*     */           } else {
/* 190 */             code.append(symb);
/*     */           }
/* 192 */           mtsz++;
/* 193 */           break;
/*     */         
/*     */         case 'C': 
/* 196 */           if ((n <= 0) || (local.charAt(n - 1) != 'S') || (n + 1 >= wdsz) || (this.frontv.indexOf(local.charAt(n + 1)) < 0))
/*     */           {
/*     */ 
/* 199 */             String tmpS = local.toString();
/* 200 */             if (tmpS.indexOf("CIA", n) == n) {
/* 201 */               code.append('X');mtsz++;
/*     */             }
/* 203 */             else if ((n + 1 < wdsz) && (this.frontv.indexOf(local.charAt(n + 1)) >= 0)) {
/* 204 */               code.append('S');
/* 205 */               mtsz++;
/*     */ 
/*     */             }
/* 208 */             else if ((n > 0) && (tmpS.indexOf("SCH", n - 1) == n - 1)) {
/* 209 */               code.append('K');
/* 210 */               mtsz++;
/*     */ 
/*     */             }
/* 213 */             else if (tmpS.indexOf("CH", n) == n) {
/* 214 */               if ((n == 0) && (wdsz >= 3) && (this.vowels.indexOf(local.charAt(2)) < 0)) {
/* 215 */                 code.append('K');
/*     */               } else {
/* 217 */                 code.append('X');
/*     */               }
/* 219 */               mtsz++;
/*     */             } else {
/* 221 */               code.append('K');
/* 222 */               mtsz++;
/*     */             } }
/* 224 */           break;
/*     */         case 'D': 
/* 226 */           if ((n + 2 < wdsz) && (local.charAt(n + 1) == 'G') && (this.frontv.indexOf(local.charAt(n + 2)) >= 0)) {
/* 227 */             code.append('J');n += 2;
/*     */           } else {
/* 229 */             code.append('T');
/*     */           }
/* 231 */           mtsz++;
/* 232 */           break;
/*     */         case 'G': 
/* 234 */           if ((n + 2 != wdsz) || (local.charAt(n + 1) != 'H'))
/*     */           {
/*     */ 
/* 237 */             if ((n + 2 >= wdsz) || (local.charAt(n + 1) != 'H') || (this.vowels.indexOf(local.charAt(n + 2)) >= 0))
/*     */             {
/*     */ 
/* 240 */               String tmpS = local.toString();
/* 241 */               if (((n <= 0) || (tmpS.indexOf("GN", n) != n)) && (tmpS.indexOf("GNED", n) != n))
/*     */               {
/*     */ 
/* 244 */                 if ((n > 0) && (local.charAt(n - 1) == 'G')) {
/* 245 */                   hard = true;
/*     */                 } else {
/* 247 */                   hard = false;
/*     */                 }
/* 249 */                 if ((n + 1 < wdsz) && (this.frontv.indexOf(local.charAt(n + 1)) >= 0) && (!hard)) {
/* 250 */                   code.append('J');
/*     */                 } else {
/* 252 */                   code.append('K');
/*     */                 }
/* 254 */                 mtsz++; } } }
/* 255 */           break;
/*     */         case 'H': 
/* 257 */           if (n + 1 != wdsz)
/*     */           {
/*     */ 
/* 260 */             if ((n <= 0) || (this.varson.indexOf(local.charAt(n - 1)) < 0))
/*     */             {
/*     */ 
/* 263 */               if (this.vowels.indexOf(local.charAt(n + 1)) >= 0) {
/* 264 */                 code.append('H');
/* 265 */                 mtsz++;
/*     */               }
/*     */             }
/*     */           }
/*     */           break;
/*     */         case 'F': case 'J': 
/*     */         case 'L': case 'M': 
/*     */         case 'N': 
/*     */         case 'R': 
/* 274 */           code.append(symb);
/* 275 */           mtsz++;
/* 276 */           break;
/*     */         case 'K': 
/* 278 */           if (n > 0) {
/* 279 */             if (local.charAt(n - 1) != 'C') {
/* 280 */               code.append(symb);
/*     */             }
/*     */           } else {
/* 283 */             code.append(symb);
/*     */           }
/* 285 */           mtsz++;
/* 286 */           break;
/*     */         case 'P': 
/* 288 */           if ((n + 1 < wdsz) && (local.charAt(n + 1) == 'H'))
/*     */           {
/* 290 */             code.append('F');
/*     */           } else {
/* 292 */             code.append(symb);
/*     */           }
/* 294 */           mtsz++;
/* 295 */           break;
/*     */         case 'Q': 
/* 297 */           code.append('K');
/* 298 */           mtsz++;
/* 299 */           break;
/*     */         case 'S': 
/* 301 */           String tmpS = local.toString();
/* 302 */           if ((tmpS.indexOf("SH", n) == n) || (tmpS.indexOf("SIO", n) == n) || (tmpS.indexOf("SIA", n) == n)) {
/* 303 */             code.append('X');
/*     */           } else {
/* 305 */             code.append('S');
/*     */           }
/* 307 */           mtsz++;
/* 308 */           break;
/*     */         case 'T': 
/* 310 */           String tmpS = local.toString();
/* 311 */           if ((tmpS.indexOf("TIA", n) == n) || (tmpS.indexOf("TIO", n) == n)) {
/* 312 */             code.append('X');
/* 313 */             mtsz++;
/*     */ 
/*     */           }
/* 316 */           else if (tmpS.indexOf("TCH", n) != n)
/*     */           {
/*     */ 
/*     */ 
/* 320 */             if (tmpS.indexOf("TH", n) == n) {
/* 321 */               code.append('0');
/*     */             } else {
/* 323 */               code.append('T');
/*     */             }
/* 325 */             mtsz++; }
/* 326 */           break;
/*     */         case 'V': 
/* 328 */           code.append('F');mtsz++; break;
/*     */         case 'W': case 'Y': 
/* 330 */           if ((n + 1 < wdsz) && (this.vowels.indexOf(local.charAt(n + 1)) >= 0)) {
/* 331 */             code.append(symb);
/* 332 */             mtsz++;
/*     */           }
/*     */           break;
/*     */         case 'X': 
/* 336 */           code.append('K');code.append('S');mtsz += 2;
/* 337 */           break;
/*     */         case 'Z': 
/* 339 */           code.append('S');mtsz++;
/*     */         }
/* 341 */         n++;
/*     */       }
/* 343 */       if (mtsz > getMaxCodeLen()) code.setLength(getMaxCodeLen());
/*     */     }
/* 345 */     return code.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object encode(Object pObject)
/*     */     throws EncoderException
/*     */   {
/* 363 */     if (!(pObject instanceof String)) {
/* 364 */       throw new EncoderException("Parameter supplied to Metaphone encode is not of type java.lang.String");
/*     */     }
/* 366 */     Object result = metaphone((String)pObject);
/*     */     
/* 368 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String encode(String pString)
/*     */   {
/* 378 */     return metaphone(pString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isMetaphoneEqual(String str1, String str2)
/*     */   {
/* 390 */     return metaphone(str1).equals(metaphone(str2));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getMaxCodeLen()
/*     */   {
/* 397 */     return this.maxCodeLen;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setMaxCodeLen(int maxCodeLen)
/*     */   {
/* 403 */     this.maxCodeLen = maxCodeLen;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-codec-1.2.jar!\org\apache\commons\codec\language\Metaphone.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */