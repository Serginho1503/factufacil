/*     */ package org.apache.commons.codec.language;
/*     */ 
/*     */ import org.apache.commons.codec.EncoderException;
/*     */ import org.apache.commons.codec.StringEncoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SoundexUtils
/*     */ {
/*     */   static String clean(String str)
/*     */   {
/*  80 */     if ((str == null) || (str.length() == 0)) {
/*  81 */       return str;
/*     */     }
/*  83 */     int len = str.length();
/*  84 */     char[] chars = new char[len];
/*  85 */     int count = 0;
/*  86 */     for (int i = 0; i < len; i++) {
/*  87 */       if (Character.isLetter(str.charAt(i))) {
/*  88 */         chars[(count++)] = str.charAt(i);
/*     */       }
/*     */     }
/*  91 */     if (count == len) {
/*  92 */       return str.toUpperCase();
/*     */     }
/*  94 */     return new String(chars, 0, count).toUpperCase();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int difference(StringEncoder encoder, String s1, String s2)
/*     */     throws EncoderException
/*     */   {
/* 124 */     return differenceEncoded(encoder.encode(s1), encoder.encode(s2));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int differenceEncoded(String es1, String es2)
/*     */   {
/* 149 */     if ((es1 == null) || (es2 == null)) {
/* 150 */       return 0;
/*     */     }
/* 152 */     int lengthToMatch = Math.min(es1.length(), es2.length());
/* 153 */     int diff = 0;
/* 154 */     for (int i = 0; i < lengthToMatch; i++) {
/* 155 */       if (es1.charAt(i) == es2.charAt(i)) {
/* 156 */         diff++;
/*     */       }
/*     */     }
/* 159 */     return diff;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-codec-1.2.jar!\org\apache\commons\codec\language\SoundexUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */