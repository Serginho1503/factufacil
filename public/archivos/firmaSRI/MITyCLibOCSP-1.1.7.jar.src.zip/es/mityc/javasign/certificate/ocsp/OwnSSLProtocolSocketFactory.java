/*     */ package es.mityc.javasign.certificate.ocsp;
/*     */ 
/*     */ import es.mityc.javasign.ssl.ISSLErrorManager;
/*     */ import es.mityc.javasign.ssl.ISSLManager;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.security.KeyManagementException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.Principal;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.util.Vector;
/*     */ import javax.net.SocketFactory;
/*     */ import javax.net.ssl.KeyManager;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLPeerUnverifiedException;
/*     */ import javax.net.ssl.SSLSession;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import javax.net.ssl.TrustManager;
/*     */ import javax.security.cert.CertificateEncodingException;
/*     */ import org.apache.commons.httpclient.ConnectTimeoutException;
/*     */ import org.apache.commons.httpclient.params.HttpConnectionParams;
/*     */ import org.apache.commons.httpclient.protocol.SecureProtocolSocketFactory;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.bouncycastle.asn1.x509.X509Name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OwnSSLProtocolSocketFactory
/*     */   implements SecureProtocolSocketFactory
/*     */ {
/*  96 */   private static final Log LOG = LogFactory.getLog(OwnSSLProtocolSocketFactory.class);
/*     */   
/*  98 */   private ISSLManager sslManager = null;
/*  99 */   private SSLContext sslcontext = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OwnSSLProtocolSocketFactory(ISSLManager ssl)
/*     */   {
/* 119 */     this.sslManager = ssl;
/*     */   }
/*     */   
/*     */ 
/*     */   public OwnSSLProtocolSocketFactory() {}
/*     */   
/*     */ 
/*     */   private SSLContext createSSLContext()
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 131 */       KeyManager[] keymanagers = null;
/* 132 */       TrustManager[] trustmanagers = null;
/* 133 */       if (this.sslManager != null) {
/* 134 */         KeyManager km = this.sslManager.getKeyManager();
/* 135 */         if (km != null) {
/* 136 */           keymanagers = new KeyManager[] { km };
/*     */         }
/* 138 */         TrustManager tm = this.sslManager.getTrustManager();
/* 139 */         if (tm != null) {
/* 140 */           trustmanagers = new TrustManager[] { tm };
/*     */         }
/*     */       }
/* 143 */       SSLContext sslcontext = SSLContext.getInstance("SSL");
/* 144 */       sslcontext.init(keymanagers, trustmanagers, null);
/* 145 */       return sslcontext;
/*     */     } catch (NoSuchAlgorithmException ex) {
/* 147 */       LOG.error(ex.getMessage(), ex);
/* 148 */       throw new IOException(ex.getMessage());
/*     */     } catch (KeyManagementException ex) {
/* 150 */       LOG.error(ex.getMessage(), ex);
/* 151 */       throw new IOException(ex.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */   private SSLContext getSSLContext() throws IOException {
/* 156 */     if (this.sslcontext == null) {
/* 157 */       this.sslcontext = createSSLContext();
/*     */     }
/* 159 */     return this.sslcontext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Socket createSocket(String host, int port, InetAddress localAddress, int localPort, HttpConnectionParams params)
/*     */     throws IOException, UnknownHostException, ConnectTimeoutException
/*     */   {
/* 191 */     if (params == null) {
/* 192 */       throw new IllegalArgumentException("Parameters may not be null");
/*     */     }
/* 194 */     int timeout = params.getConnectionTimeout();
/* 195 */     Socket socket = null;
/*     */     
/* 197 */     SocketFactory socketfactory = getSSLContext().getSocketFactory();
/* 198 */     if (timeout == 0) {
/* 199 */       socket = socketfactory.createSocket(host, port, localAddress, localPort);
/*     */     } else {
/* 201 */       socket = socketfactory.createSocket();
/* 202 */       SocketAddress localaddr = new InetSocketAddress(localAddress, localPort);
/* 203 */       SocketAddress remoteaddr = new InetSocketAddress(host, port);
/* 204 */       socket.bind(localaddr);
/* 205 */       socket.connect(remoteaddr, timeout);
/*     */     }
/* 207 */     verifyHostname((SSLSocket)socket);
/* 208 */     return socket;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Socket createSocket(String host, int port, InetAddress clientHost, int clientPort)
/*     */     throws IOException, UnknownHostException
/*     */   {
/* 221 */     SSLSocketFactory sf = getSSLContext().getSocketFactory();
/* 222 */     SSLSocket sslSocket = (SSLSocket)sf.createSocket(host, port, 
/* 223 */       clientHost, 
/* 224 */       clientPort);
/* 225 */     verifyHostname(sslSocket);
/*     */     
/* 227 */     return sslSocket;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Socket createSocket(String host, int port)
/*     */     throws IOException, UnknownHostException
/*     */   {
/* 236 */     SSLSocketFactory sf = getSSLContext().getSocketFactory();
/* 237 */     SSLSocket sslSocket = (SSLSocket)sf.createSocket(host, port);
/* 238 */     verifyHostname(sslSocket);
/*     */     
/* 240 */     return sslSocket;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Socket createSocket(Socket socket, String host, int port, boolean autoClose)
/*     */     throws IOException, UnknownHostException
/*     */   {
/* 253 */     SSLSocketFactory sf = getSSLContext().getSocketFactory();
/* 254 */     SSLSocket sslSocket = (SSLSocket)sf.createSocket(socket, host, 
/* 255 */       port, autoClose);
/* 256 */     verifyHostname(sslSocket);
/*     */     
/* 258 */     return sslSocket;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void verifyHostname(SSLSocket socket)
/*     */     throws SSLPeerUnverifiedException, UnknownHostException
/*     */   {
/* 274 */     if (this.sslManager == null) {
/* 275 */       return;
/*     */     }
/* 277 */     ISSLErrorManager errorMng = this.sslManager.getSSLErrorManager();
/* 278 */     if (errorMng == null) {
/* 279 */       return;
/*     */     }
/*     */     
/* 282 */     SSLSession session = socket.getSession();
/* 283 */     String hostname = session.getPeerHost();
/*     */     try {
/* 285 */       InetAddress.getByName(hostname);
/*     */     } catch (UnknownHostException uhe) {
/* 287 */       throw new UnknownHostException("Could not resolve SSL sessions server hostname: " + 
/* 288 */         hostname);
/*     */     }
/*     */     
/* 291 */     javax.security.cert.X509Certificate[] certs = session.getPeerCertificateChain();
/* 292 */     if ((certs == null) || (certs.length == 0)) {
/* 293 */       throw new SSLPeerUnverifiedException("No server certificates found!");
/*     */     }
/*     */     
/* 296 */     String dn = certs[0].getSubjectDN().getName();
/*     */     
/*     */ 
/*     */ 
/* 300 */     if (LOG.isDebugEnabled()) {
/* 301 */       LOG.debug("Server certificate chain:");
/* 302 */       for (int i = 0; i < certs.length; i++) {
/* 303 */         LOG.debug("X509Certificate[" + i + "]=" + certs[i]);
/*     */       }
/*     */     }
/*     */     
/* 307 */     String cn = getCN(dn);
/* 308 */     if (hostname.equalsIgnoreCase(cn)) {
/* 309 */       if (LOG.isDebugEnabled()) {
/* 310 */         LOG.debug("Target hostname valid: " + cn);
/*     */       }
/*     */     } else {
/*     */       try {
/* 314 */         CertificateFactory cf = CertificateFactory.getInstance("X.509");
/* 315 */         java.security.cert.X509Certificate servCert = (java.security.cert.X509Certificate)cf.generateCertificate(new ByteArrayInputStream(certs[0].getEncoded()));
/* 316 */         if (!errorMng.continueErrorPeer(hostname, servCert)) {
/* 317 */           throw new SSLPeerUnverifiedException(
/* 318 */             "HTTPS hostname invalid: expected '" + hostname + "', received '" + cn + "'");
/*     */         }
/*     */       } catch (CertificateException ex) {
/* 321 */         LOG.error(ex.getMessage(), ex);
/* 322 */         throw new SSLPeerUnverifiedException("Unexpected error checking HTTPS hostname: " + ex.getMessage());
/*     */       } catch (CertificateEncodingException ex) {
/* 324 */         LOG.error(ex.getMessage(), ex);
/* 325 */         throw new SSLPeerUnverifiedException("Unexpected error checking HTTPS hostname: " + ex.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getCN(String dn)
/*     */   {
/* 341 */     X509Name name = new X509Name(dn);
/* 342 */     Vector<?> vector = name.getValues(X509Name.CN);
/* 343 */     if ((vector != null) && (vector.size() > 0)) {
/* 344 */       return (String)vector.get(0);
/*     */     }
/* 346 */     return null;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 351 */     if ((obj != null) && (obj.getClass().equals(OwnSSLProtocolSocketFactory.class))) {
/* 352 */       return true;
/*     */     }
/* 354 */     return false;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 359 */     return OwnSSLProtocolSocketFactory.class.hashCode();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibOCSP-1.1.7.jar!\es\mityc\javasign\certificate\ocsp\OwnSSLProtocolSocketFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */