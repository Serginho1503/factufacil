/*     */ package es.mityc.javasign.certificate.ocsp;
/*     */ 
/*     */ import es.mityc.firmaJava.ocsp.RespuestaOCSP;
/*     */ import es.mityc.javasign.certificate.AbstractCertStatus;
/*     */ import es.mityc.javasign.certificate.ICertStatus.CERT_STATUS;
/*     */ import es.mityc.javasign.certificate.IOCSPCertStatus;
/*     */ import es.mityc.javasign.certificate.IOCSPCertStatus.TYPE_RESPONDER;
/*     */ import es.mityc.javasign.certificate.RevokedInfo;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OCSPStatus
/*     */   extends AbstractCertStatus
/*     */   implements IOCSPCertStatus
/*     */ {
/*  34 */   private byte[] respOCSP = null;
/*     */   
/*  36 */   private Date dateResponse = null;
/*     */   
/*  38 */   private String responderID = null;
/*     */   
/*     */ 
/*     */ 
/*     */   private IOCSPCertStatus.TYPE_RESPONDER responderType;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected OCSPStatus() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public OCSPStatus(RespuestaOCSP resp, X509Certificate cert)
/*     */   {
/*  54 */     setRespOCSP(resp.getRespuestaEncoded());
/*  55 */     setRespondeDate(resp.getTiempoRespuesta());
/*  56 */     setResponder(resp.getValorResponder(), resp.getTipoResponder());
/*  57 */     if (resp.getNroRespuesta() == 0) {
/*  58 */       setCertStatus(ICertStatus.CERT_STATUS.valid);
/*  59 */     } else if (resp.getNroRespuesta() == 1) {
/*  60 */       setCertStatus(ICertStatus.CERT_STATUS.revoked);
/*     */       
/*  62 */       setRevokedInfo(new RevokedInfo(null, resp.getFechaRevocacion()));
/*     */     } else {
/*  64 */       setCertStatus(ICertStatus.CERT_STATUS.unknown);
/*     */     }
/*  66 */     setCertificate(cert);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setRespOCSP(byte[] binary)
/*     */   {
/*  74 */     this.respOCSP = (binary != null ? (byte[])binary.clone() : null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setResponder(String id, IOCSPCertStatus.TYPE_RESPONDER tipoResponder)
/*     */   {
/*  83 */     this.responderID = id;
/*  84 */     this.responderType = tipoResponder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setRespondeDate(Date date)
/*     */   {
/*  92 */     if (date != null) {
/*  93 */       this.dateResponse = ((Date)date.clone());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getResponderID()
/*     */   {
/* 103 */     return this.responderID != null ? this.responderID : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IOCSPCertStatus.TYPE_RESPONDER getResponderType()
/*     */   {
/* 112 */     return this.responderType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getResponseDate()
/*     */   {
/* 121 */     return this.dateResponse != null ? (Date)this.dateResponse.clone() : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getEncoded()
/*     */   {
/* 130 */     return this.respOCSP;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibOCSP-1.1.7.jar!\es\mityc\javasign\certificate\ocsp\OCSPStatus.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */