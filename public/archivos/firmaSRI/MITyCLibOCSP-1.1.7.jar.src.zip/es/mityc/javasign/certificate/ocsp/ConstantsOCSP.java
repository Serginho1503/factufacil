package es.mityc.javasign.certificate.ocsp;

public final class ConstantsOCSP
{
  public static final String LIB_NAME = "MITyCLibOCSP";
  public static final String OCSP_SERVER_URL = "OCSPserverURL";
  public static final String OCSP_LIST_ERROR_1 = "i18n.mityc.ocsp.list.1";
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibOCSP-1.1.7.jar!\es\mityc\javasign\certificate\ocsp\ConstantsOCSP.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */