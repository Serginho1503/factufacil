/*     */ package es.mityc.javasign.certificate.ocsp;
/*     */ 
/*     */ import es.mityc.firmaJava.ocsp.OCSPCliente;
/*     */ import es.mityc.firmaJava.ocsp.RespuestaOCSP;
/*     */ import es.mityc.firmaJava.ocsp.exception.OCSPClienteException;
/*     */ import es.mityc.firmaJava.ocsp.exception.OCSPProxyException;
/*     */ import es.mityc.javasign.certificate.CertStatusException;
/*     */ import es.mityc.javasign.certificate.ICertStatus;
/*     */ import es.mityc.javasign.certificate.ICertStatusRecoverer;
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.trust.TrustAbstract;
/*     */ import es.mityc.javasign.trust.UnknownTrustException;
/*     */ import java.security.cert.CertPath;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OCSPLiveConsultant
/*     */   implements ICertStatusRecoverer
/*     */ {
/*  49 */   static Log logger = LogFactory.getLog(OCSPLiveConsultant.class);
/*     */   
/*     */ 
/*  52 */   private static final II18nManager i18n = I18nFactory.getI18nManager("MITyCLibOCSP");
/*     */   
/*     */ 
/*     */   private String servidorOCSP;
/*     */   
/*     */   private TrustAbstract validadorConfianza;
/*     */   
/*  59 */   private OCSPCliente ocspCliente = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OCSPLiveConsultant(String hostOCSPResponder, TrustAbstract truster)
/*     */   {
/*  68 */     this.servidorOCSP = hostOCSPResponder;
/*  69 */     this.validadorConfianza = truster;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<ICertStatus> getCertStatus(List<X509Certificate> certList)
/*     */     throws CertStatusException
/*     */   {
/*  81 */     throw new UnsupportedOperationException("Not implemented yet");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ICertStatus getCertStatus(X509Certificate cert)
/*     */     throws CertStatusException
/*     */   {
/*  93 */     OCSPStatus bloque = null;
/*  94 */     RespuestaOCSP respuesta = null;
/*     */     try {
/*  96 */       this.ocspCliente = new OCSPCliente(this.servidorOCSP);
/*     */       
/*     */ 
/*  99 */       X509Certificate issuerCertificate = null;
/*     */       try {
/* 101 */         CertPath certPath = this.validadorConfianza.getCertPath(cert);
/* 102 */         List<? extends Certificate> certificates = certPath.getCertificates();
/* 103 */         if (certificates.size() > 1) {
/* 104 */           issuerCertificate = (X509Certificate)certificates.get(1);
/*     */         } else {
/* 106 */           issuerCertificate = (X509Certificate)certificates.get(0);
/*     */         }
/*     */       } catch (UnknownTrustException ex) {
/* 109 */         logger.error(i18n.getLocalMessage("i18n.mityc.ocsp.list.1", new Object[] { cert.getIssuerX500Principal() }), ex);
/*     */         
/* 111 */         issuerCertificate = cert;
/*     */       }
/*     */       
/* 114 */       respuesta = this.ocspCliente.validateCert(cert, issuerCertificate);
/*     */     } catch (OCSPClienteException ex) {
/* 116 */       throw new CertStatusException(ex.getMessage(), ex);
/*     */     } catch (OCSPProxyException ex) {
/* 118 */       throw new CertStatusException(ex.getMessage(), ex);
/*     */     }
/*     */     
/* 121 */     if (respuesta == null) {
/* 122 */       respuesta = new RespuestaOCSP(9, "Consulta OCSP interrumpida");
/* 123 */       respuesta.setTiempoRespuesta(new Date(System.currentTimeMillis()));
/*     */     }
/* 125 */     bloque = new OCSPStatus(respuesta, cert);
/* 126 */     return bloque;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<ICertStatus> getCertChainStatus(X509Certificate cert)
/*     */     throws CertStatusException
/*     */   {
/* 146 */     List<ICertStatus> result = new ArrayList();
/*     */     try {
/* 148 */       this.ocspCliente = new OCSPCliente(this.servidorOCSP);
/*     */       
/*     */ 
/* 151 */       CertPath certPath = this.validadorConfianza.getCertPath(cert);
/* 152 */       List<? extends Certificate> certificates = certPath.getCertificates();
/* 153 */       int certificatesSize = certificates.size();
/* 154 */       for (int i = 0; i < certificatesSize; i++) {
/* 155 */         X509Certificate certificateToValidate = (X509Certificate)certificates.get(i);
/*     */         X509Certificate issuerCertificate;
/*     */         X509Certificate issuerCertificate;
/* 158 */         if (i == certificatesSize - 1) {
/* 159 */           issuerCertificate = (X509Certificate)certificates.get(i);
/*     */         } else {
/* 161 */           issuerCertificate = (X509Certificate)certificates.get(i + 1);
/*     */         }
/* 163 */         RespuestaOCSP respuesta = this.ocspCliente.validateCert(certificateToValidate, issuerCertificate);
/* 164 */         OCSPStatus bloque = new OCSPStatus(respuesta, certificateToValidate);
/* 165 */         result.add(bloque);
/*     */       }
/*     */     }
/*     */     catch (OCSPClienteException ex) {
/* 169 */       throw new CertStatusException(ex.getMessage(), ex);
/*     */     } catch (OCSPProxyException ex) {
/* 171 */       throw new CertStatusException(ex.getMessage(), ex);
/*     */     } catch (UnknownTrustException ex) {
/* 173 */       throw new CertStatusException(ex.getMessage(), ex);
/*     */     }
/*     */     
/* 176 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<List<ICertStatus>> getCertChainStatus(List<X509Certificate> certs)
/*     */     throws CertStatusException
/*     */   {
/* 187 */     throw new UnsupportedOperationException("Not Supported Operation");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized void abort()
/*     */   {
/* 194 */     if (this.ocspCliente != null) {
/* 195 */       this.ocspCliente.abort();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void setTimeOut(int timeOut)
/*     */   {
/* 202 */     if (this.ocspCliente != null) {
/* 203 */       this.ocspCliente.setTimeOut(Integer.valueOf(timeOut));
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibOCSP-1.1.7.jar!\es\mityc\javasign\certificate\ocsp\OCSPLiveConsultant.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */