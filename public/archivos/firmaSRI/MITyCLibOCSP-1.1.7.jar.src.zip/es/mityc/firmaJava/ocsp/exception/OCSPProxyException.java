/*    */ package es.mityc.firmaJava.ocsp.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OCSPProxyException
/*    */   extends OCSPException
/*    */ {
/*    */   public OCSPProxyException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public OCSPProxyException(String mensaje)
/*    */   {
/* 36 */     super(mensaje);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public OCSPProxyException(Throwable causa)
/*    */   {
/* 44 */     super(causa);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public OCSPProxyException(String mensaje, Throwable causa)
/*    */   {
/* 53 */     super(mensaje, causa);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibOCSP-1.1.7.jar!\es\mityc\firmaJava\ocsp\exception\OCSPProxyException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */