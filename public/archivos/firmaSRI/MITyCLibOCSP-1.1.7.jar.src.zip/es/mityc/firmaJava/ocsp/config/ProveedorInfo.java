/*     */ package es.mityc.firmaJava.ocsp.config;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.Vector;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.bouncycastle.asn1.ASN1OctetString;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ProveedorInfo
/*     */   implements Cloneable, ConstantesProveedores
/*     */ {
/*  37 */   private static Log logger = LogFactory.getLog(ProveedorInfo.class);
/*  38 */   private String nombre = null;
/*  39 */   private String descripcion = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  44 */   private Hashtable<String, String> caHash = null;
/*  45 */   private Vector<ServidorOcsp> servidores = null;
/*     */   
/*     */   protected Object clone() throws CloneNotSupportedException
/*     */   {
/*  49 */     ProveedorInfo copy = (ProveedorInfo)super.clone();
/*  50 */     copy.nombre = this.nombre;
/*  51 */     copy.descripcion = this.descripcion;
/*  52 */     copy.caHash = new Hashtable();
/*  53 */     copy.caHash = getCAList();
/*  54 */     copy.servidores = new Vector();
/*  55 */     copy.servidores = getServidores();
/*  56 */     return copy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ProveedorInfo()
/*     */   {
/*  63 */     this.nombre = "";
/*  64 */     this.descripcion = "";
/*  65 */     this.caHash = new Hashtable();
/*  66 */     this.servidores = new Vector();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getNombre()
/*     */   {
/*  73 */     return this.nombre;
/*     */   }
/*     */   
/*     */   protected void setNombre(String nombre) {
/*  77 */     this.nombre = nombre;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getDescripcion()
/*     */   {
/*  84 */     return this.descripcion;
/*     */   }
/*     */   
/*     */   protected void setDescripcion(String descripcion) {
/*  88 */     this.descripcion = descripcion;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector<ServidorOcsp> getServidores()
/*     */   {
/*  96 */     Vector<ServidorOcsp> copy = null;
/*  97 */     int total2 = this.servidores.size();
/*     */     try
/*     */     {
/* 100 */       copy = new Vector();
/* 101 */       for (int i = 0; i < total2; i++)
/* 102 */         copy.add((ServidorOcsp)((ServidorOcsp)this.servidores.get(i)).clone());
/*     */     } catch (CloneNotSupportedException e) {
/* 104 */       logger.error(e.getMessage());
/*     */     }
/* 106 */     return copy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServidorOcsp getServidor()
/*     */   {
/* 114 */     Iterator<ServidorOcsp> lista = getServidores().iterator();
/* 115 */     ServidorOcsp servidorOcsp = null;
/* 116 */     if (lista.hasNext()) {
/* 117 */       servidorOcsp = (ServidorOcsp)lista.next();
/*     */     }
/* 119 */     return servidorOcsp;
/*     */   }
/*     */   
/*     */   protected Hashtable<String, String> getCAList() {
/* 123 */     return (Hashtable)this.caHash.clone();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean puedeValidar(Object certObj)
/*     */   {
/* 132 */     X509Certificate cert = null;
/*     */     
/* 134 */     if (certObj == null) {
/* 135 */       logger.error("Illegal argument type. Can be a String, byte[] or X509Certificate.");
/* 136 */       return false;
/*     */     }
/*     */     try {
/* 139 */       if ((certObj instanceof String)) {
/* 140 */         cert = UtilidadesX509.getCertificate((String)certObj);
/* 141 */       } else if ((certObj instanceof byte[])) {
/* 142 */         cert = UtilidadesX509.getCertificate((byte[])certObj);
/* 143 */       } else if ((certObj instanceof X509Certificate)) {
/* 144 */         cert = (X509Certificate)certObj;
/*     */       } else {
/* 146 */         logger.error("Illegal argument type. Can be a String, byte[] or X509Certificate.");
/* 147 */         return false;
/*     */       }
/*     */     } catch (CertificateException e) {
/* 150 */       logger.error(e.getMessage());
/* 151 */       return false;
/*     */     }
/*     */     
/* 154 */     String nameHash = "";
/* 155 */     String pkHash = "";
/*     */     try
/*     */     {
/* 158 */       ASN1OctetString issuerNameHash = UtilidadesX509.getIssuerNameHash(cert);
/* 159 */       ASN1OctetString issuerKeyHash = UtilidadesX509.getIssuerKeyHash(cert);
/*     */       
/* 161 */       nameHash = issuerNameHash.toString().replace("#", "");
/* 162 */       pkHash = issuerKeyHash.toString().replace("#", "");
/*     */       
/* 164 */       return puedeValidar(nameHash, pkHash);
/*     */     } catch (IOException ex) {
/* 166 */       logger.error(ex.getMessage()); }
/* 167 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean puedeValidar(String nameHash, String pkHash)
/*     */   {
/* 178 */     if (this.caHash.containsKey(nameHash))
/* 179 */       return ((String)this.caHash.get(nameHash)).equals(pkHash);
/* 180 */     return false;
/*     */   }
/*     */   
/*     */   protected void addServidor(ServidorOcsp server) {
/* 184 */     this.servidores.add(server);
/*     */   }
/*     */   
/*     */   protected void addCA(String nameHash, String pkHash) {
/* 188 */     if (UtilidadesX509.isEmpty(nameHash)) { return;
/*     */     }
/* 190 */     if (!this.caHash.containsKey(nameHash)) {
/* 191 */       this.caHash.put(nameHash, pkHash);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibOCSP-1.1.7.jar!\es\mityc\firmaJava\ocsp\config\ProveedorInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */