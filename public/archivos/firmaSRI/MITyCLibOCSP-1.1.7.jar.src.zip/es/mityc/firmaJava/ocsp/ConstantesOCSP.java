package es.mityc.firmaJava.ocsp;

public abstract interface ConstantesOCSP
{
  public static final String ES_MINUSCULA = "es";
  public static final String ES_MAYUSCULA = "ES";
  public static final String NOMBRE_LIBRERIA = "i18n_libreriaOCSP";
  public static final String X509 = "X.509";
  public static final String SUN = "SUN";
  public static final String SUN_RSA_SIGN = "SunRsaSign";
  public static final String LIBRERIA_OCSP_ERROR_1 = "libreriaocsp.error1";
  public static final String LIBRERIA_OCSP_ERROR_2 = "libreriaocsp.error2";
  public static final String LIBRERIA_OCSP_ERROR_3 = "libreriaocsp.error3";
  public static final String LIBRERIA_OCSP_ERROR_4 = "libreriaocsp.error4";
  public static final String LIBRERIA_OCSP_ERROR_5 = "libreriaocsp.error5";
  public static final String LIBRERIA_OCSP_ERROR_6 = "libreriaocsp.error6";
  public static final String LIBRERIA_OCSP_ERROR_7 = "libreriaocsp.error7";
  public static final String LIBRERIA_OCSP_ERROR_9 = "libreriaocsp.error9";
  public static final String LIBRERIA_OCSP_ERROR_10 = "libreriaocsp.error10";
  public static final String LIBRERIA_OCSP_ERROR_11 = "libreriaocsp.error11";
  public static final String LIBRERIA_OCSP_ERROR_12 = "libreriaocsp.error12";
  public static final String LIBRERIA_OCSP_ERROR_13 = "libreriaocsp.error13";
  public static final String LIBRERIA_OCSP_ERROR_14 = "libreriaocsp.error14";
  public static final String LIBRERIA_RAZON_REVOCACION_1 = "libreriaocsp.razonrevocacion1";
  public static final String LIBRERIA_RAZON_REVOCACION_2 = "libreriaocsp.razonrevocacion2";
  public static final String LIBRERIA_RAZON_REVOCACION_3 = "libreriaocsp.razonrevocacion3";
  public static final String LIBRERIA_RAZON_REVOCACION_4 = "libreriaocsp.razonrevocacion4";
  public static final String LIBRERIA_RAZON_REVOCACION_5 = "libreriaocsp.razonrevocacion5";
  public static final String LIBRERIA_RAZON_REVOCACION_6 = "libreriaocsp.razonrevocacion6";
  public static final String RUTA_CERTIFICADOS = "/es/mityc/firmaJava/ocsp/certificadosCA/";
  public static final String LIBRERIA_OCSP_RESPUESTA_1 = "libreriaocsp.respuesta1";
  public static final String LIBRERIA_OCSP_RESPUESTA_2 = "libreriaocsp.respuesta2";
  public static final String LIBRERIA_OCSP_RESPUESTA_3 = "libreriaocsp.respuesta3";
  public static final String LIBRERIA_OCSP_RESPUESTA_4 = "libreriaocsp.respuesta4";
  public static final String LIBRERIA_OCSP_RESPUESTA_5 = "libreriaocsp.respuesta5";
  public static final int GOOD = 0;
  public static final int REVOKED = 1;
  public static final int UNKNOWN = 2;
  public static final int ERROR = 3;
  public static final int MALFORMEDREQUEST = 4;
  public static final int INTERNALERROR = 5;
  public static final int TRYLATER = 6;
  public static final int SIGREQUIRED = 7;
  public static final int UNAUTHORIZED = 8;
  public static final int INTERRUPTED = 9;
  public static final String LOCALE = "locale";
  public static final String MENSAJE_CREADO_INDENTIFICADO = "Creado identificador único de certificado a validar.";
  public static final String MENSAJE_ERROR_GENERAR_IDENTIFICADOR = "Error al generar el identificador unico del certificado de usuario: ";
  public static final String MENSAJE_PETICION_OCSP_GENERADA = "Petición OCSP generada.";
  public static final String ERROR_MENSAJE_GENERAR_PETICION_OCSP = "Error al generar la petición OCSP: ";
  public static final String DEBUG_SERVIDOR_OCSP_ENCONTRADO = "Servidor OCSP encontrado ";
  public static final String CONTENT_TYPE = "Content-Type";
  public static final String APPLICATION_OCSP_REQUEST = "application/ocsp-request";
  public static final String MENSAJE_ERROR_LEER_PETICION = "Error al leer la petición: ";
  public static final String MENSAJE_PETICION_ENVIADA = "Petición enviada.";
  public static final String MENSAJE_FALLO_EJECUCION_METODO = "Fallo la ejecución del método: ";
  public static final String MENSAJE_RESPUESTA_OBTENIDA = "Respuesta obtenida.";
  public static final String MENSAJE_ERROR_SECUENCIA_BYTES_RESPUESTA = "Error en la secuencia de bytes de respuesta: ";
  public static final String MENSAJE_OCSP_NOT_SUCCESSFUL = "OCSPResponseStatus: not successful.";
  public static final String MENSAJE_OCSP_MALFORMED_REQUEST = "OCSPResponseStatus: malformedRequest.";
  public static final String MENSAJE_OCSP_INTERNAL_ERROR = "OCSPResponseStatus: internalError.";
  public static final String MENSAJE_OCSP_TRY_LATER = "OCSPResponseStatus: tryLater.";
  public static final String MENSAJE_OCSP_SIG_REQUIRED = "OCSPResponseStatus: sigRequired.";
  public static final String MENSAJE_OCSP_UNAUTHORIZED = "OCSPResponseStatus: unauthorized.";
  public static final String MENSAJE_OCSP_SUCCESSFUL = "OCSPResponseStatus: successful.";
  public static final String ESTADO_CERTIFICADO_GOOD = "Estado del certificado: Good.";
  public static final String ESTADO_CERTIFICADO_REVOKED = "Estado del certificado: Revoked.";
  public static final String ESTADO_CERTIFICADO_UNKNOWN = "Estado del certificado: Unknown.";
  public static final String MENSAJE_RECIBIDO_ESTADO_NO_DEFINIDO = "Se recibió un estado no definido: ";
  public static final String MENSAJE_ERROR_RESPUESTA_OCPS_BASICA = "Error al instanciar la respuesta OCSP básica: ";
  public static final String MENSAJE_VIOLACION_HTTP = "Violación del protocolo HTTP: ";
  public static final String MENSAJE_ERROR_CONEXION_SERVIDOR_OCSP = "Error en la conexión con el servidor OCSP: ";
  public static final String MENSAJE_UTILIZA_SERVIDOR_PROXY = "Se utiliza un servidor Proxy: ";
  public static final String MENSAJE_RESPUESTA_SERVIDOR_ESTADO_DESCONOCIDO = "El servidor ha respondido que el estado del certificado es desconocido";
  public static final String MENSAJE_PROXY_AUTENTICADO = "Autenticación fallida en el proxy";
  public static final String MENSAJE_PROXY_POR_CONFIGURAR = "Debe configurar su proxy para poder realizar la consulta";
  public static final String MENSAJE_INTERRUMPIDO = "Consulta OCSP interrumpida";
  public static final String BC = "BC";
  public static final String DOS_PUNTOS_ESPACIO = ": ";
  public static final String DOS_PUNTOS = ":";
  public static final String CADENA_VACIA = "";
  public static final String NUEVA_LINEA = "\n";
  public static final String COMA = ",";
  public static final String STR_LENGTH_OF_BASE_64 = "Length of Base64 encoded input string is not a multiple of 4.";
  public static final String STR_ILLEGAL_CHARACTER_IN_BASE_64 = "Illegal character in Base64 encoded data.";
  public static final String STR_INPUT_NOT_PROPERLY_PADDED = "Base64 input not properly padded.";
  public static final String USAR_OCSP_MULTIPLE = "MULTIPLE";
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibOCSP-1.1.7.jar!\es\mityc\firmaJava\ocsp\ConstantesOCSP.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */