/*    */ package es.mityc.firmaJava.ocsp.config;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.xml.sax.EntityResolver;
/*    */ import org.xml.sax.InputSource;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigProveedoresResolver
/*    */   implements EntityResolver, ConstantesProveedores
/*    */ {
/*    */   public InputSource resolveEntity(String arg0, String arg1)
/*    */     throws SAXException, IOException
/*    */   {
/* 37 */     InputSource sourceXsd = null;
/* 38 */     File XsdUpdated = new File(System.getProperty("user.dir") + "/" + "OCSPServersInfo.xsd");
/* 39 */     InputStream sXsd = null;
/*    */     
/* 41 */     if (XsdUpdated.exists()) {
/* 42 */       sXsd = new FileInputStream(XsdUpdated);
/*    */     } else {
/* 44 */       sXsd = getClass().getResourceAsStream("/OCSPServersInfo.xsd");
/*    */     }
/* 46 */     sourceXsd = new InputSource(sXsd);
/*    */     
/* 48 */     return sourceXsd;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibOCSP-1.1.7.jar!\es\mityc\firmaJava\ocsp\config\ConfigProveedoresResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */