/*    */ package es.mityc.firmaJava.ocsp;
/*    */ 
/*    */ import java.net.Authenticator;
/*    */ import java.net.Authenticator.RequestorType;
/*    */ import java.net.PasswordAuthentication;
/*    */ import org.apache.commons.httpclient.NTCredentials;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticatorProxyCredentials
/*    */   extends NTCredentials
/*    */ {
/* 30 */   protected PasswordAuthentication pa = null;
/*    */   
/*    */   public AuthenticatorProxyCredentials(String host, String domain) {
/* 33 */     super("username", "password", host, domain);
/*    */   }
/*    */   
/*    */   private void refreshAuthenticator() {
/* 37 */     String proxyHost = System.getProperty("http.proxyHost");
/* 38 */     int proxyPort = 80;
/*    */     try {
/* 40 */       proxyPort = Integer.parseInt(System.getProperty("http.proxyPort"));
/*    */     }
/*    */     catch (NumberFormatException localNumberFormatException) {}
/*    */     try {
/* 44 */       this.pa = Authenticator.requestPasswordAuthentication(proxyHost, null, proxyPort, "HTTP", "", "http", null, Authenticator.RequestorType.PROXY);
/*    */     } catch (SecurityException ex) {
/* 46 */       this.pa = null;
/*    */     }
/*    */   }
/*    */   
/*    */   public String getUserName() {
/* 51 */     refreshAuthenticator();
/* 52 */     if (this.pa == null)
/* 53 */       return super.getUserName();
/* 54 */     return this.pa.getUserName();
/*    */   }
/*    */   
/*    */   public String getPassword() {
/* 58 */     if (this.pa == null)
/* 59 */       refreshAuthenticator();
/* 60 */     if (this.pa == null)
/* 61 */       return super.getPassword();
/* 62 */     return new String(this.pa.getPassword());
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibOCSP-1.1.7.jar!\es\mityc\firmaJava\ocsp\AuthenticatorProxyCredentials.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */