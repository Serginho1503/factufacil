/*    */ package es.mityc.firmaJava.ocsp.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class OCSPClienteException
/*    */   extends OCSPException
/*    */ {
/*    */   public OCSPClienteException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public OCSPClienteException(String mensaje)
/*    */   {
/* 36 */     super(mensaje);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public OCSPClienteException(Throwable causa)
/*    */   {
/* 44 */     super(causa);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public OCSPClienteException(String mensaje, Throwable causa)
/*    */   {
/* 53 */     super(mensaje, causa);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 57 */     return super.toString();
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibOCSP-1.1.7.jar!\es\mityc\firmaJava\ocsp\exception\OCSPClienteException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */