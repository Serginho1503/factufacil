/*     */ package es.mityc.firmaJava.ocsp.config;
/*     */ 
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.Vector;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConfigProveedoresHandler
/*     */   extends DefaultHandler
/*     */   implements ConstantesProveedores
/*     */ {
/*  37 */   static Log logger = LogFactory.getLog(ConfigProveedoresHandler.class);
/*  38 */   private boolean leyendoProveedor = false;
/*  39 */   private String valorTmp = "";
/*     */   
/*  41 */   private Vector<ProveedorInfo> proveedores = new Vector();
/*  42 */   private String version = "";
/*  43 */   private String fecha = "";
/*     */   
/*     */   public void error(SAXParseException ex) throws SAXException
/*     */   {
/*  47 */     throw ex;
/*     */   }
/*     */   
/*     */   public void fatalError(SAXParseException ex) throws SAXException {
/*  51 */     throw ex;
/*     */   }
/*     */   
/*     */   public void warning(SAXParseException exception) throws SAXException {
/*  55 */     logger.warn(exception.getMessage());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void startElement(String namespace, String localname, String type, Attributes attributes)
/*     */     throws SAXException
/*     */   {
/*  65 */     if (localname.equals(NODO_PROVEEDOR)) {
/*  66 */       this.leyendoProveedor = true;
/*  67 */       String v1 = "";
/*  68 */       String v2 = "";
/*  69 */       int at1 = attributes.getIndex("nombre");
/*  70 */       int at2 = attributes.getIndex("descripcion");
/*  71 */       if (at1 >= 0) v1 = attributes.getValue(at1);
/*  72 */       if (at2 >= 0) { v2 = attributes.getValue(at2);
/*     */       }
/*  74 */       ProveedorInfo po = new ProveedorInfo();
/*     */       
/*  76 */       po.setNombre(v1);
/*  77 */       po.setDescripcion(v2);
/*  78 */       this.proveedores.add(po);
/*     */     }
/*  80 */     else if (!this.leyendoProveedor) { return;
/*     */     }
/*  82 */     if (localname.equals(NODO_CA)) {
/*  83 */       String v1 = "";
/*  84 */       String v2 = "";
/*  85 */       int at1 = attributes.getIndex("nameHash");
/*  86 */       int at2 = attributes.getIndex("pkHash");
/*  87 */       if (at1 >= 0) v1 = attributes.getValue(at1);
/*  88 */       if (at2 >= 0) { v2 = attributes.getValue(at2);
/*     */       }
/*  90 */       ((ProveedorInfo)this.proveedores.lastElement()).addCA(
/*     */       
/*  92 */         v1, v2);
/*     */     }
/*     */     
/*     */ 
/*  96 */     if (localname.equals(NODO_OCSP)) {
/*  97 */       String v1 = "";
/*  98 */       String v2 = "";
/*  99 */       int at1 = attributes.getIndex("URI");
/* 100 */       int at2 = attributes.getIndex("descripcion");
/* 101 */       if (at1 >= 0) v1 = attributes.getValue(at1);
/* 102 */       if (at2 >= 0) { v2 = attributes.getValue(at2);
/*     */       }
/* 104 */       ServidorOcsp server = null;
/*     */       try {
/* 106 */         server = new ServidorOcsp(v1, v2);
/* 107 */         ((ProveedorInfo)this.proveedores.lastElement()).addServidor(server);
/*     */       } catch (URISyntaxException e) {
/* 109 */         throw new SAXException("Invalid Uri. " + e.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void characters(char[] ch, int start, int end) throws SAXException {
/* 115 */     this.valorTmp = new String(ch, start, end);
/* 116 */     this.valorTmp = this.valorTmp.trim();
/*     */   }
/*     */   
/*     */   public void endElement(String namespace, String localname, String type) {
/* 120 */     if (localname.equals(NODO_PROVEEDOR)) this.leyendoProveedor = false;
/* 121 */     if (localname.equals(NODO_VERSION)) {
/* 122 */       this.version = this.valorTmp;
/*     */     }
/* 124 */     if (localname.equals(NODO_FECHA))
/* 125 */       this.fecha = this.valorTmp;
/*     */   }
/*     */   
/*     */   protected Vector<ProveedorInfo> getProveedores() {
/* 129 */     return this.proveedores;
/*     */   }
/*     */   
/* 132 */   protected String getFecha() { return this.fecha; }
/*     */   
/*     */   protected String getVersion() {
/* 135 */     return this.version;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibOCSP-1.1.7.jar!\es\mityc\firmaJava\ocsp\config\ConfigProveedoresHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */