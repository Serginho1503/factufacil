/*     */ package es.mityc.firmaJava.ocsp.config;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Vector;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import javax.xml.validation.SchemaFactory;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.bouncycastle.asn1.ASN1OctetString;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXNotRecognizedException;
/*     */ import org.xml.sax.SAXNotSupportedException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigProveedores
/*     */   implements ConstantesProveedores, Cloneable
/*     */ {
/*  52 */   private static Log logger = LogFactory.getLog(ConfigProveedores.class);
/*  53 */   private Vector<ProveedorInfo> proveedores = null;
/*  54 */   private String version = "";
/*  55 */   private String fecha = "";
/*     */   
/*     */ 
/*     */ 
/*     */   public ConfigProveedores()
/*     */   {
/*  61 */     this.proveedores = new Vector();
/*     */   }
/*     */   
/*     */   protected Object clone() throws CloneNotSupportedException {
/*  65 */     ConfigProveedores copy = (ConfigProveedores)super.clone();
/*  66 */     copy.version = this.version;
/*  67 */     copy.fecha = this.fecha;
/*  68 */     int totalProveedores = this.proveedores.size();
/*  69 */     for (int i = 0; i < totalProveedores; i++) {
/*  70 */       copy.proveedores.add((ProveedorInfo)((ProveedorInfo)this.proveedores.get(i)).clone());
/*     */     }
/*  72 */     return copy;
/*     */   }
/*     */   
/*     */   private InputSource getConfigFile() throws FileNotFoundException {
/*  76 */     InputSource sourceXml = null;
/*  77 */     File XmlUpdated = new File(System.getProperty("user.dir") + "/" + "OCSPServersInfo.xml");
/*  78 */     InputStream sXml = null;
/*     */     
/*  80 */     if (XmlUpdated.exists()) {
/*  81 */       sXml = new FileInputStream(XmlUpdated);
/*     */     } else {
/*  83 */       sXml = getClass().getResourceAsStream("/OCSPServersInfo.xml");
/*     */     }
/*  85 */     sourceXml = new InputSource(sXml);
/*  86 */     return sourceXml;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean read()
/*     */     throws SAXException
/*     */   {
/*  96 */     boolean ok = false;
/*  97 */     ConfigProveedoresHandler reader = new ConfigProveedoresHandler();
/*     */     
/*  99 */     SAXParserFactory spf = SAXParserFactory.newInstance();
/* 100 */     SchemaFactory sf = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
/* 101 */     spf.setSchema(sf.newSchema(new StreamSource(getClass().getResourceAsStream("/OCSPServersInfo.xsd"))));
/* 102 */     spf.setNamespaceAware(true);
/*     */     
/*     */     try
/*     */     {
/* 106 */       SAXParser parser = spf.newSAXParser();
/*     */       
/* 108 */       parser.parse(getConfigFile(), reader);
/*     */       
/* 110 */       this.proveedores = reader.getProveedores();
/* 111 */       this.version = reader.getVersion();
/* 112 */       this.fecha = reader.getFecha();
/* 113 */       ok = true;
/*     */     }
/*     */     catch (FileNotFoundException e)
/*     */     {
/* 117 */       logger.error("IOException " + e.getMessage());
/* 118 */       if (logger.isDebugEnabled()) {
/* 119 */         logger.debug(e);
/*     */       }
/*     */     } catch (SAXNotRecognizedException ex) {
/* 122 */       logger.error(ex.getMessage());
/* 123 */       if (logger.isDebugEnabled()) {
/* 124 */         logger.debug(ex);
/*     */       }
/*     */     } catch (SAXNotSupportedException ex) {
/* 127 */       logger.error(ex.getMessage());
/* 128 */       if (logger.isDebugEnabled()) {
/* 129 */         logger.debug(ex);
/*     */       }
/*     */     } catch (IOException e) {
/* 132 */       logger.error("IOException " + e.getMessage());
/*     */     }
/*     */     catch (ParserConfigurationException ex) {
/* 135 */       logger.error("IOException " + ex.getMessage());
/* 136 */       if (logger.isDebugEnabled())
/* 137 */         logger.debug(ex);
/*     */     }
/* 139 */     return ok;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ProveedorInfo buscarProveedor(Object certObj)
/*     */   {
/* 150 */     X509Certificate cert = null;
/*     */     
/* 152 */     if (certObj == null) {
/* 153 */       logger.error("Illegal argument type. Can be a String, byte[] or X509Certificate.");
/* 154 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 158 */       if ((certObj instanceof byte[])) {
/* 159 */         cert = UtilidadesX509.getCertificate((byte[])certObj);
/* 160 */       } else if ((certObj instanceof String)) {
/* 161 */         cert = UtilidadesX509.getCertificate((String)certObj);
/* 162 */       } else if ((certObj instanceof X509Certificate)) {
/* 163 */         cert = (X509Certificate)certObj;
/*     */       } else {
/* 165 */         logger.error("Illegal argument type. Can be a String, byte[] or X509Certificate.");
/* 166 */         return null;
/*     */       }
/*     */     } catch (CertificateException e) {
/* 169 */       logger.error("IOException ", e);
/*     */       
/* 171 */       ProveedorInfo buscado = null;
/* 172 */       String nameHash = "";
/* 173 */       String pkHash = "";
/*     */       try
/*     */       {
/* 176 */         ASN1OctetString issuerNameHash = UtilidadesX509.getIssuerNameHash(cert);
/* 177 */         ASN1OctetString issuerKeyHash = UtilidadesX509.getIssuerKeyHash(cert);
/*     */         
/* 179 */         nameHash = issuerNameHash.toString().replace("#", "");
/* 180 */         pkHash = issuerKeyHash.toString().replace("#", "");
/*     */         
/* 182 */         buscado = buscarProveedor(nameHash, pkHash);
/*     */       } catch (IOException ex) {
/* 184 */         logger.error(ex.getMessage());
/*     */       }
/* 186 */       return buscado;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ProveedorInfo buscarProveedor(String nameHash, String pkHash)
/*     */   {
/* 196 */     if (this.proveedores == null) return null;
/* 197 */     int totalProveedores = this.proveedores.size();
/* 198 */     ProveedorInfo poBuscado = null;
/* 199 */     for (int i = 0; i < totalProveedores; i++) {
/* 200 */       if (((ProveedorInfo)this.proveedores.get(i)).puedeValidar(nameHash, pkHash))
/* 201 */         poBuscado = (ProveedorInfo)this.proveedores.get(i);
/*     */     }
/* 203 */     return poBuscado;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getFecha()
/*     */   {
/* 210 */     return this.fecha;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getVersion()
/*     */   {
/* 216 */     return this.version;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Vector<ProveedorInfo> getProveedores()
/*     */   {
/* 223 */     return (Vector)this.proveedores.clone();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 228 */   private static ConfigProveedores configCacheado = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ServidorOcsp getServidor(X509Certificate cert)
/*     */   {
/* 236 */     ServidorOcsp servidorOcsp = null;
/*     */     try {
/* 238 */       ConfigProveedores config = null;
/* 239 */       if (configCacheado == null) {
/* 240 */         config = new ConfigProveedores();
/* 241 */         if (!config.read()) { return null;
/*     */         }
/* 243 */         configCacheado = config;
/*     */       } else {
/* 245 */         config = configCacheado;
/*     */       }
/* 247 */       ProveedorInfo proveedor = config.buscarProveedor(cert);
/* 248 */       if (proveedor == null) return null;
/* 249 */       servidorOcsp = proveedor.getServidor();
/*     */     }
/*     */     catch (SAXException e) {
/* 252 */       logger.error(e.getMessage());
/* 253 */       if (logger.isDebugEnabled())
/* 254 */         logger.debug(e);
/*     */     }
/* 256 */     return servidorOcsp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Vector<ServidorOcsp> getServidores(X509Certificate cert)
/*     */   {
/* 264 */     Vector<ServidorOcsp> servidores = null;
/*     */     try {
/* 266 */       ConfigProveedores config = null;
/* 267 */       if (configCacheado == null)
/*     */       {
/* 269 */         config = new ConfigProveedores();
/* 270 */         if (!config.read()) return null;
/* 271 */         configCacheado = config;
/*     */       } else {
/* 273 */         config = configCacheado;
/*     */       }
/* 275 */       ProveedorInfo proveedor = config.buscarProveedor(cert);
/* 276 */       if (proveedor == null) return null;
/* 277 */       servidores = proveedor.getServidores();
/*     */     }
/*     */     catch (SAXException e) {
/* 280 */       logger.error(e.getMessage());
/* 281 */       if (logger.isDebugEnabled())
/* 282 */         logger.debug(e);
/*     */     }
/* 284 */     return servidores;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibOCSP-1.1.7.jar!\es\mityc\firmaJava\ocsp\config\ConfigProveedores.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */