/*    */ package es.mityc.firmaJava.ocsp.config;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface ConstantesProveedores
/*    */ {
/* 24 */   public static final Object NODO_PROVEEDORES = "proveedores";
/* 25 */   public static final Object NODO_VERSION = "version";
/* 26 */   public static final Object NODO_FECHA = "fecha";
/* 27 */   public static final Object NODO_PROVEEDOR = "proveedor";
/* 28 */   public static final Object NODO_CA = "ca";
/* 29 */   public static final Object NODO_OCSP = "servidorOCSP";
/*    */   public static final String ATT_NOMBRE = "nombre";
/*    */   public static final String ATT_NAMEHASH = "nameHash";
/*    */   public static final String ATT_PKHASH = "pkHash";
/*    */   public static final String ATT_DESCRIPCION = "descripcion";
/*    */   public static final String ATT_URI = "URI";
/*    */   public static final String FEATURE_NAMESPACES = "http://xml.org/sax/features/namespaces";
/*    */   public static final String FEATURE_VALIDATION = "http://xml.org/sax/features/validation";
/*    */   public static final String FEATURE_SCHEMA = "http://apache.org/xml/features/validation/schema";
/*    */   public static final String FEATURE_EXTERNALSCHEMA = "http://apache.org/xml/properties/schema/external-schemaLocation";
/*    */   public static final String XML_FILE = "OCSPServersInfo.xml";
/*    */   public static final String XSD_FILE = "OCSPServersInfo.xsd";
/*    */   public static final String SEPARATOR = "/";
/*    */   public static final String EMPTY_STRING = "";
/*    */   public static final String ALMOHADILLA = "#";
/*    */   public static final String XML_DEFAULT_FILE = "/OCSPServersInfo.xml";
/*    */   public static final String XSD_DEFAULT_FILE = "/OCSPServersInfo.xsd";
/*    */   public static final String USERDIR = "user.dir";
/*    */   public static final String IO_EXCEPTION = "IOException ";
/*    */   public static final String CERTIFICATE_EXCEPTION = "IOException ";
/*    */   public static final String INVALID_URI = "Invalid Uri. ";
/*    */   public static final String CERTIFICATE_TYPE_EXCEPTION = "Illegal argument type. Can be a String, byte[] or X509Certificate.";
/*    */   public static final String X_509 = "X.509";
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibOCSP-1.1.7.jar!\es\mityc\firmaJava\ocsp\config\ConstantesProveedores.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */