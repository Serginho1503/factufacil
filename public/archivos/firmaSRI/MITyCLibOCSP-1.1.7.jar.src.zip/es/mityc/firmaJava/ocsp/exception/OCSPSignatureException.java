/*    */ package es.mityc.firmaJava.ocsp.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OCSPSignatureException
/*    */   extends OCSPException
/*    */ {
/*    */   public OCSPSignatureException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public OCSPSignatureException(String message)
/*    */   {
/* 34 */     super(message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public OCSPSignatureException(Throwable cause)
/*    */   {
/* 41 */     super(cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public OCSPSignatureException(String message, Throwable cause)
/*    */   {
/* 49 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibOCSP-1.1.7.jar!\es\mityc\firmaJava\ocsp\exception\OCSPSignatureException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */