/*     */ package es.mityc.firmaJava.ocsp;
/*     */ 
/*     */ import es.mityc.firmaJava.ocsp.exception.OCSPClienteException;
/*     */ import es.mityc.javasign.certificate.ocsp.OwnSSLProtocolSocketFactory;
/*     */ import es.mityc.javasign.ssl.ISSLManager;
/*     */ import es.mityc.javasign.utils.Base64Coder;
/*     */ import java.io.IOException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import org.apache.commons.httpclient.HttpClient;
/*     */ import org.apache.commons.httpclient.methods.PostMethod;
/*     */ import org.apache.commons.httpclient.protocol.Protocol;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.bouncycastle.asn1.ocsp.ResponderID;
/*     */ import org.bouncycastle.ocsp.BasicOCSPResp;
/*     */ import org.bouncycastle.ocsp.CertificateID;
/*     */ import org.bouncycastle.ocsp.OCSPException;
/*     */ import org.bouncycastle.ocsp.OCSPResp;
/*     */ import org.bouncycastle.ocsp.RespID;
/*     */ import org.bouncycastle.ocsp.RevokedStatus;
/*     */ import org.bouncycastle.ocsp.SingleResp;
/*     */ import org.bouncycastle.ocsp.UnknownStatus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ /**
/*     */  * @deprecated
/*     */  */
/*     */ public class OCSPCliente
/*     */ {
/*  72 */   private static final Integer INT_20000 = new Integer(20000);
/*     */   
/*  74 */   private Integer timeOut = INT_20000;
/*     */   
/*     */   private String servidorURL;
/*     */   
/*  78 */   static Log log = LogFactory.getLog(OCSPCliente.class);
/*     */   
/*  80 */   private PostMethod method = null;
/*  81 */   private HttpClient client = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public OCSPCliente(String servidorURL)
/*     */   {
/*  88 */     this.servidorURL = servidorURL;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public RespuestaOCSP validateCert(X509Certificate certificadoUsuario, X509Certificate certificadoEmisor)
/*     */     throws OCSPClienteException, es.mityc.firmaJava.ocsp.exception.OCSPProxyException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 57	es/mityc/firmaJava/ocsp/RespuestaOCSP
/*     */     //   3: dup
/*     */     //   4: invokespecial 59	es/mityc/firmaJava/ocsp/RespuestaOCSP:<init>	()V
/*     */     //   7: astore_3
/*     */     //   8: invokestatic 60	es/mityc/javasign/utils/Utils:addBCProvider	()V
/*     */     //   11: new 65	org/bouncycastle/ocsp/OCSPReqGenerator
/*     */     //   14: dup
/*     */     //   15: invokespecial 67	org/bouncycastle/ocsp/OCSPReqGenerator:<init>	()V
/*     */     //   18: astore 4
/*     */     //   20: aconst_null
/*     */     //   21: astore 5
/*     */     //   23: aconst_null
/*     */     //   24: astore 6
/*     */     //   26: aconst_null
/*     */     //   27: astore 7
/*     */     //   29: new 68	org/bouncycastle/ocsp/CertificateID
/*     */     //   32: dup
/*     */     //   33: ldc 70
/*     */     //   35: aload_2
/*     */     //   36: aload_1
/*     */     //   37: invokevirtual 72	java/security/cert/X509Certificate:getSerialNumber	()Ljava/math/BigInteger;
/*     */     //   40: invokespecial 78	org/bouncycastle/ocsp/CertificateID:<init>	(Ljava/lang/String;Ljava/security/cert/X509Certificate;Ljava/math/BigInteger;)V
/*     */     //   43: astore 7
/*     */     //   45: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   48: ldc 81
/*     */     //   50: invokeinterface 83 2 0
/*     */     //   55: goto +72 -> 127
/*     */     //   58: astore 8
/*     */     //   60: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   63: new 89	java/lang/StringBuilder
/*     */     //   66: dup
/*     */     //   67: ldc 91
/*     */     //   69: invokespecial 93	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   72: aload 8
/*     */     //   74: invokevirtual 95	org/bouncycastle/ocsp/OCSPException:getMessage	()Ljava/lang/String;
/*     */     //   77: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   80: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   83: invokeinterface 83 2 0
/*     */     //   88: new 53	es/mityc/firmaJava/ocsp/exception/OCSPClienteException
/*     */     //   91: dup
/*     */     //   92: new 89	java/lang/StringBuilder
/*     */     //   95: dup
/*     */     //   96: ldc 108
/*     */     //   98: invokestatic 110	es/mityc/firmaJava/ocsp/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   101: invokestatic 116	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   104: invokespecial 93	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   107: ldc 122
/*     */     //   109: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   112: aload 8
/*     */     //   114: invokevirtual 95	org/bouncycastle/ocsp/OCSPException:getMessage	()Ljava/lang/String;
/*     */     //   117: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   120: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   123: invokespecial 124	es/mityc/firmaJava/ocsp/exception/OCSPClienteException:<init>	(Ljava/lang/String;)V
/*     */     //   126: athrow
/*     */     //   127: aload 4
/*     */     //   129: aload 7
/*     */     //   131: invokevirtual 125	org/bouncycastle/ocsp/OCSPReqGenerator:addRequest	(Lorg/bouncycastle/ocsp/CertificateID;)V
/*     */     //   134: aload 4
/*     */     //   136: invokevirtual 129	org/bouncycastle/ocsp/OCSPReqGenerator:generate	()Lorg/bouncycastle/ocsp/OCSPReq;
/*     */     //   139: astore 5
/*     */     //   141: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   144: ldc -123
/*     */     //   146: invokeinterface 83 2 0
/*     */     //   151: goto +72 -> 223
/*     */     //   154: astore 8
/*     */     //   156: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   159: new 89	java/lang/StringBuilder
/*     */     //   162: dup
/*     */     //   163: ldc -121
/*     */     //   165: invokespecial 93	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   168: aload 8
/*     */     //   170: invokevirtual 95	org/bouncycastle/ocsp/OCSPException:getMessage	()Ljava/lang/String;
/*     */     //   173: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   176: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   179: invokeinterface 137 2 0
/*     */     //   184: new 53	es/mityc/firmaJava/ocsp/exception/OCSPClienteException
/*     */     //   187: dup
/*     */     //   188: new 89	java/lang/StringBuilder
/*     */     //   191: dup
/*     */     //   192: ldc -116
/*     */     //   194: invokestatic 110	es/mityc/firmaJava/ocsp/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   197: invokestatic 116	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   200: invokespecial 93	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   203: ldc 122
/*     */     //   205: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   208: aload 8
/*     */     //   210: invokevirtual 95	org/bouncycastle/ocsp/OCSPException:getMessage	()Ljava/lang/String;
/*     */     //   213: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   216: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   219: invokespecial 124	es/mityc/firmaJava/ocsp/exception/OCSPClienteException:<init>	(Ljava/lang/String;)V
/*     */     //   222: athrow
/*     */     //   223: aload_0
/*     */     //   224: new 142	org/apache/commons/httpclient/HttpClient
/*     */     //   227: dup
/*     */     //   228: invokespecial 144	org/apache/commons/httpclient/HttpClient:<init>	()V
/*     */     //   231: putfield 44	es/mityc/firmaJava/ocsp/OCSPCliente:client	Lorg/apache/commons/httpclient/HttpClient;
/*     */     //   234: ldc -111
/*     */     //   236: invokestatic 147	java/lang/System:getProperty	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   239: ifnull +258 -> 497
/*     */     //   242: ldc -111
/*     */     //   244: invokestatic 147	java/lang/System:getProperty	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   247: invokestatic 152	java/lang/Boolean:parseBoolean	(Ljava/lang/String;)Z
/*     */     //   250: ifeq +247 -> 497
/*     */     //   253: aload_0
/*     */     //   254: getfield 46	es/mityc/firmaJava/ocsp/OCSPCliente:servidorURL	Ljava/lang/String;
/*     */     //   257: invokestatic 158	es/mityc/javasign/utils/ProxyUtil:isInNonHosts	(Ljava/lang/String;)Z
/*     */     //   260: ifne +237 -> 497
/*     */     //   263: ldc -93
/*     */     //   265: invokestatic 147	java/lang/System:getProperty	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   268: ifnull +105 -> 373
/*     */     //   271: ldc -91
/*     */     //   273: ldc -93
/*     */     //   275: invokestatic 147	java/lang/System:getProperty	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   278: invokevirtual 167	java/lang/String:equals	(Ljava/lang/Object;)Z
/*     */     //   281: ifne +92 -> 373
/*     */     //   284: new 171	es/mityc/javasign/utils/SimpleAuthenticator
/*     */     //   287: dup
/*     */     //   288: ldc -93
/*     */     //   290: invokestatic 147	java/lang/System:getProperty	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   293: ldc -83
/*     */     //   295: invokestatic 147	java/lang/System:getProperty	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   298: invokespecial 175	es/mityc/javasign/utils/SimpleAuthenticator:<init>	(Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   301: invokestatic 178	java/net/Authenticator:setDefault	(Ljava/net/Authenticator;)V
/*     */     //   304: new 117	java/lang/String
/*     */     //   307: dup
/*     */     //   308: new 89	java/lang/StringBuilder
/*     */     //   311: dup
/*     */     //   312: ldc -93
/*     */     //   314: invokestatic 147	java/lang/System:getProperty	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   317: invokestatic 116	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   320: invokespecial 93	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   323: ldc -72
/*     */     //   325: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   328: ldc -83
/*     */     //   330: invokestatic 147	java/lang/System:getProperty	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   333: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   336: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   339: invokespecial 186	java/lang/String:<init>	(Ljava/lang/String;)V
/*     */     //   342: astore 8
/*     */     //   344: new 187	org/apache/commons/httpclient/UsernamePasswordCredentials
/*     */     //   347: dup
/*     */     //   348: aload 8
/*     */     //   350: invokespecial 189	org/apache/commons/httpclient/UsernamePasswordCredentials:<init>	(Ljava/lang/String;)V
/*     */     //   353: astore 9
/*     */     //   355: aload_0
/*     */     //   356: getfield 44	es/mityc/firmaJava/ocsp/OCSPCliente:client	Lorg/apache/commons/httpclient/HttpClient;
/*     */     //   359: invokevirtual 190	org/apache/commons/httpclient/HttpClient:getState	()Lorg/apache/commons/httpclient/HttpState;
/*     */     //   362: getstatic 194	org/apache/commons/httpclient/auth/AuthScope:ANY	Lorg/apache/commons/httpclient/auth/AuthScope;
/*     */     //   365: aload 9
/*     */     //   367: invokevirtual 200	org/apache/commons/httpclient/HttpState:setProxyCredentials	(Lorg/apache/commons/httpclient/auth/AuthScope;Lorg/apache/commons/httpclient/Credentials;)V
/*     */     //   370: goto +38 -> 408
/*     */     //   373: aconst_null
/*     */     //   374: invokestatic 178	java/net/Authenticator:setDefault	(Ljava/net/Authenticator;)V
/*     */     //   377: new 206	es/mityc/firmaJava/ocsp/AuthenticatorProxyCredentials
/*     */     //   380: dup
/*     */     //   381: ldc -48
/*     */     //   383: invokestatic 147	java/lang/System:getProperty	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   386: ldc -91
/*     */     //   388: invokespecial 210	es/mityc/firmaJava/ocsp/AuthenticatorProxyCredentials:<init>	(Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   391: astore 8
/*     */     //   393: aload_0
/*     */     //   394: getfield 44	es/mityc/firmaJava/ocsp/OCSPCliente:client	Lorg/apache/commons/httpclient/HttpClient;
/*     */     //   397: invokevirtual 190	org/apache/commons/httpclient/HttpClient:getState	()Lorg/apache/commons/httpclient/HttpState;
/*     */     //   400: getstatic 194	org/apache/commons/httpclient/auth/AuthScope:ANY	Lorg/apache/commons/httpclient/auth/AuthScope;
/*     */     //   403: aload 8
/*     */     //   405: invokevirtual 200	org/apache/commons/httpclient/HttpState:setProxyCredentials	(Lorg/apache/commons/httpclient/auth/AuthScope;Lorg/apache/commons/httpclient/Credentials;)V
/*     */     //   408: aload_0
/*     */     //   409: getfield 44	es/mityc/firmaJava/ocsp/OCSPCliente:client	Lorg/apache/commons/httpclient/HttpClient;
/*     */     //   412: invokevirtual 211	org/apache/commons/httpclient/HttpClient:getHostConfiguration	()Lorg/apache/commons/httpclient/HostConfiguration;
/*     */     //   415: ldc -48
/*     */     //   417: invokestatic 147	java/lang/System:getProperty	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   420: ldc -41
/*     */     //   422: invokestatic 147	java/lang/System:getProperty	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   425: invokestatic 217	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*     */     //   428: invokevirtual 221	org/apache/commons/httpclient/HostConfiguration:setProxy	(Ljava/lang/String;I)V
/*     */     //   431: new 117	java/lang/String
/*     */     //   434: dup
/*     */     //   435: new 89	java/lang/StringBuilder
/*     */     //   438: dup
/*     */     //   439: ldc -93
/*     */     //   441: invokestatic 147	java/lang/System:getProperty	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   444: invokestatic 116	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   447: invokespecial 93	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   450: ldc -72
/*     */     //   452: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   455: ldc -83
/*     */     //   457: invokestatic 147	java/lang/System:getProperty	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   460: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   463: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   466: invokespecial 186	java/lang/String:<init>	(Ljava/lang/String;)V
/*     */     //   469: astore 8
/*     */     //   471: new 187	org/apache/commons/httpclient/UsernamePasswordCredentials
/*     */     //   474: dup
/*     */     //   475: aload 8
/*     */     //   477: invokespecial 189	org/apache/commons/httpclient/UsernamePasswordCredentials:<init>	(Ljava/lang/String;)V
/*     */     //   480: astore 9
/*     */     //   482: aload_0
/*     */     //   483: getfield 44	es/mityc/firmaJava/ocsp/OCSPCliente:client	Lorg/apache/commons/httpclient/HttpClient;
/*     */     //   486: invokevirtual 190	org/apache/commons/httpclient/HttpClient:getState	()Lorg/apache/commons/httpclient/HttpState;
/*     */     //   489: getstatic 194	org/apache/commons/httpclient/auth/AuthScope:ANY	Lorg/apache/commons/httpclient/auth/AuthScope;
/*     */     //   492: aload 9
/*     */     //   494: invokevirtual 200	org/apache/commons/httpclient/HttpState:setProxyCredentials	(Lorg/apache/commons/httpclient/auth/AuthScope;Lorg/apache/commons/httpclient/Credentials;)V
/*     */     //   497: aload_0
/*     */     //   498: getfield 44	es/mityc/firmaJava/ocsp/OCSPCliente:client	Lorg/apache/commons/httpclient/HttpClient;
/*     */     //   501: invokevirtual 227	org/apache/commons/httpclient/HttpClient:getParams	()Lorg/apache/commons/httpclient/params/HttpClientParams;
/*     */     //   504: ldc -25
/*     */     //   506: aload_0
/*     */     //   507: getfield 40	es/mityc/firmaJava/ocsp/OCSPCliente:timeOut	Ljava/lang/Integer;
/*     */     //   510: invokevirtual 233	org/apache/commons/httpclient/params/HttpClientParams:setParameter	(Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   513: aload_0
/*     */     //   514: getfield 44	es/mityc/firmaJava/ocsp/OCSPCliente:client	Lorg/apache/commons/httpclient/HttpClient;
/*     */     //   517: invokevirtual 227	org/apache/commons/httpclient/HttpClient:getParams	()Lorg/apache/commons/httpclient/params/HttpClientParams;
/*     */     //   520: ldc -17
/*     */     //   522: new 241	org/apache/commons/httpclient/DefaultHttpMethodRetryHandler
/*     */     //   525: dup
/*     */     //   526: iconst_0
/*     */     //   527: iconst_0
/*     */     //   528: invokespecial 243	org/apache/commons/httpclient/DefaultHttpMethodRetryHandler:<init>	(IZ)V
/*     */     //   531: invokevirtual 233	org/apache/commons/httpclient/params/HttpClientParams:setParameter	(Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   534: aload_0
/*     */     //   535: getfield 46	es/mityc/firmaJava/ocsp/OCSPCliente:servidorURL	Ljava/lang/String;
/*     */     //   538: ifnull +33 -> 571
/*     */     //   541: ldc -91
/*     */     //   543: aload_0
/*     */     //   544: getfield 46	es/mityc/firmaJava/ocsp/OCSPCliente:servidorURL	Ljava/lang/String;
/*     */     //   547: invokevirtual 246	java/lang/String:trim	()Ljava/lang/String;
/*     */     //   550: invokevirtual 167	java/lang/String:equals	(Ljava/lang/Object;)Z
/*     */     //   553: ifne +18 -> 571
/*     */     //   556: aload_0
/*     */     //   557: getfield 46	es/mityc/firmaJava/ocsp/OCSPCliente:servidorURL	Ljava/lang/String;
/*     */     //   560: invokevirtual 246	java/lang/String:trim	()Ljava/lang/String;
/*     */     //   563: ldc -7
/*     */     //   565: invokevirtual 251	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
/*     */     //   568: ifeq +91 -> 659
/*     */     //   571: aload_1
/*     */     //   572: invokestatic 254	es/mityc/firmaJava/ocsp/config/ConfigProveedores:getServidor	(Ljava/security/cert/X509Certificate;)Les/mityc/firmaJava/ocsp/config/ServidorOcsp;
/*     */     //   575: astore 8
/*     */     //   577: aload 8
/*     */     //   579: ifnull +46 -> 625
/*     */     //   582: aload_0
/*     */     //   583: aload 8
/*     */     //   585: invokevirtual 260	es/mityc/firmaJava/ocsp/config/ServidorOcsp:getUrl	()Ljava/net/URI;
/*     */     //   588: invokevirtual 266	java/net/URI:toString	()Ljava/lang/String;
/*     */     //   591: putfield 46	es/mityc/firmaJava/ocsp/OCSPCliente:servidorURL	Ljava/lang/String;
/*     */     //   594: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   597: new 89	java/lang/StringBuilder
/*     */     //   600: dup
/*     */     //   601: ldc_w 269
/*     */     //   604: invokespecial 93	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   607: aload_0
/*     */     //   608: getfield 46	es/mityc/firmaJava/ocsp/OCSPCliente:servidorURL	Ljava/lang/String;
/*     */     //   611: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   614: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   617: invokeinterface 271 2 0
/*     */     //   622: goto +37 -> 659
/*     */     //   625: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   628: ldc_w 274
/*     */     //   631: invokestatic 110	es/mityc/firmaJava/ocsp/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   634: invokeinterface 137 2 0
/*     */     //   639: aload_0
/*     */     //   640: ldc -91
/*     */     //   642: putfield 46	es/mityc/firmaJava/ocsp/OCSPCliente:servidorURL	Ljava/lang/String;
/*     */     //   645: new 53	es/mityc/firmaJava/ocsp/exception/OCSPClienteException
/*     */     //   648: dup
/*     */     //   649: ldc_w 274
/*     */     //   652: invokestatic 110	es/mityc/firmaJava/ocsp/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   655: invokespecial 124	es/mityc/firmaJava/ocsp/exception/OCSPClienteException:<init>	(Ljava/lang/String;)V
/*     */     //   658: athrow
/*     */     //   659: aload_0
/*     */     //   660: new 276	org/apache/commons/httpclient/methods/PostMethod
/*     */     //   663: dup
/*     */     //   664: aload_0
/*     */     //   665: getfield 46	es/mityc/firmaJava/ocsp/OCSPCliente:servidorURL	Ljava/lang/String;
/*     */     //   668: invokespecial 278	org/apache/commons/httpclient/methods/PostMethod:<init>	(Ljava/lang/String;)V
/*     */     //   671: putfield 42	es/mityc/firmaJava/ocsp/OCSPCliente:method	Lorg/apache/commons/httpclient/methods/PostMethod;
/*     */     //   674: aload_0
/*     */     //   675: getfield 42	es/mityc/firmaJava/ocsp/OCSPCliente:method	Lorg/apache/commons/httpclient/methods/PostMethod;
/*     */     //   678: ldc_w 279
/*     */     //   681: ldc_w 281
/*     */     //   684: invokevirtual 283	org/apache/commons/httpclient/methods/PostMethod:addRequestHeader	(Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   687: aconst_null
/*     */     //   688: astore 8
/*     */     //   690: new 286	java/io/ByteArrayInputStream
/*     */     //   693: dup
/*     */     //   694: aload 5
/*     */     //   696: invokevirtual 288	org/bouncycastle/ocsp/OCSPReq:getEncoded	()[B
/*     */     //   699: invokespecial 294	java/io/ByteArrayInputStream:<init>	([B)V
/*     */     //   702: astore 8
/*     */     //   704: goto +74 -> 778
/*     */     //   707: astore 9
/*     */     //   709: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   712: new 89	java/lang/StringBuilder
/*     */     //   715: dup
/*     */     //   716: ldc_w 297
/*     */     //   719: invokespecial 93	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   722: aload 9
/*     */     //   724: invokevirtual 299	java/io/IOException:getMessage	()Ljava/lang/String;
/*     */     //   727: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   730: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   733: invokeinterface 137 2 0
/*     */     //   738: new 53	es/mityc/firmaJava/ocsp/exception/OCSPClienteException
/*     */     //   741: dup
/*     */     //   742: new 89	java/lang/StringBuilder
/*     */     //   745: dup
/*     */     //   746: ldc_w 302
/*     */     //   749: invokestatic 110	es/mityc/firmaJava/ocsp/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   752: invokestatic 116	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   755: invokespecial 93	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   758: ldc 122
/*     */     //   760: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   763: aload 9
/*     */     //   765: invokevirtual 299	java/io/IOException:getMessage	()Ljava/lang/String;
/*     */     //   768: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   771: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   774: invokespecial 124	es/mityc/firmaJava/ocsp/exception/OCSPClienteException:<init>	(Ljava/lang/String;)V
/*     */     //   777: athrow
/*     */     //   778: new 304	org/apache/commons/httpclient/methods/InputStreamRequestEntity
/*     */     //   781: dup
/*     */     //   782: aload 8
/*     */     //   784: invokespecial 306	org/apache/commons/httpclient/methods/InputStreamRequestEntity:<init>	(Ljava/io/InputStream;)V
/*     */     //   787: astore 9
/*     */     //   789: aload_0
/*     */     //   790: getfield 42	es/mityc/firmaJava/ocsp/OCSPCliente:method	Lorg/apache/commons/httpclient/methods/PostMethod;
/*     */     //   793: aload 9
/*     */     //   795: invokevirtual 309	org/apache/commons/httpclient/methods/PostMethod:setRequestEntity	(Lorg/apache/commons/httpclient/methods/RequestEntity;)V
/*     */     //   798: aload_0
/*     */     //   799: getfield 42	es/mityc/firmaJava/ocsp/OCSPCliente:method	Lorg/apache/commons/httpclient/methods/PostMethod;
/*     */     //   802: invokevirtual 313	org/apache/commons/httpclient/methods/PostMethod:getParams	()Lorg/apache/commons/httpclient/params/HttpMethodParams;
/*     */     //   805: ldc -17
/*     */     //   807: new 241	org/apache/commons/httpclient/DefaultHttpMethodRetryHandler
/*     */     //   810: dup
/*     */     //   811: iconst_0
/*     */     //   812: iconst_0
/*     */     //   813: invokespecial 243	org/apache/commons/httpclient/DefaultHttpMethodRetryHandler:<init>	(IZ)V
/*     */     //   816: invokevirtual 316	org/apache/commons/httpclient/params/HttpMethodParams:setParameter	(Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   819: aload_0
/*     */     //   820: getfield 42	es/mityc/firmaJava/ocsp/OCSPCliente:method	Lorg/apache/commons/httpclient/methods/PostMethod;
/*     */     //   823: invokevirtual 313	org/apache/commons/httpclient/methods/PostMethod:getParams	()Lorg/apache/commons/httpclient/params/HttpMethodParams;
/*     */     //   826: ldc -25
/*     */     //   828: aload_0
/*     */     //   829: getfield 40	es/mityc/firmaJava/ocsp/OCSPCliente:timeOut	Ljava/lang/Integer;
/*     */     //   832: invokevirtual 316	org/apache/commons/httpclient/params/HttpMethodParams:setParameter	(Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   835: new 319	es/mityc/firmaJava/ocsp/OCSPCliente$MethodThread
/*     */     //   838: dup
/*     */     //   839: aload_0
/*     */     //   840: invokespecial 321	es/mityc/firmaJava/ocsp/OCSPCliente$MethodThread:<init>	(Les/mityc/firmaJava/ocsp/OCSPCliente;)V
/*     */     //   843: astore 10
/*     */     //   845: aload 10
/*     */     //   847: invokevirtual 324	es/mityc/firmaJava/ocsp/OCSPCliente$MethodThread:start	()V
/*     */     //   850: aload 10
/*     */     //   852: aload_0
/*     */     //   853: getfield 40	es/mityc/firmaJava/ocsp/OCSPCliente:timeOut	Ljava/lang/Integer;
/*     */     //   856: invokevirtual 327	java/lang/Integer:intValue	()I
/*     */     //   859: i2l
/*     */     //   860: invokevirtual 331	es/mityc/firmaJava/ocsp/OCSPCliente$MethodThread:join	(J)V
/*     */     //   863: goto +37 -> 900
/*     */     //   866: astore 11
/*     */     //   868: aload_0
/*     */     //   869: getfield 42	es/mityc/firmaJava/ocsp/OCSPCliente:method	Lorg/apache/commons/httpclient/methods/PostMethod;
/*     */     //   872: invokevirtual 335	org/apache/commons/httpclient/methods/PostMethod:abort	()V
/*     */     //   875: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   878: ldc_w 338
/*     */     //   881: invokeinterface 137 2 0
/*     */     //   886: aload_0
/*     */     //   887: iconst_0
/*     */     //   888: aload 5
/*     */     //   890: aload 10
/*     */     //   892: aload 8
/*     */     //   894: invokevirtual 340	java/io/ByteArrayInputStream:available	()I
/*     */     //   897: invokespecial 343	es/mityc/firmaJava/ocsp/OCSPCliente:retryPost	(ILorg/bouncycastle/ocsp/OCSPReq;Les/mityc/firmaJava/ocsp/OCSPCliente$MethodThread;I)V
/*     */     //   900: aload 10
/*     */     //   902: invokevirtual 347	es/mityc/firmaJava/ocsp/OCSPCliente$MethodThread:getResult	()I
/*     */     //   905: istore 11
/*     */     //   907: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   910: ldc_w 350
/*     */     //   913: invokeinterface 83 2 0
/*     */     //   918: iload 11
/*     */     //   920: sipush 200
/*     */     //   923: if_icmpeq +55 -> 978
/*     */     //   926: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   929: invokeinterface 352 1 0
/*     */     //   934: ifeq +29 -> 963
/*     */     //   937: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   940: new 89	java/lang/StringBuilder
/*     */     //   943: dup
/*     */     //   944: ldc_w 356
/*     */     //   947: invokespecial 93	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   950: iload 11
/*     */     //   952: invokevirtual 358	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*     */     //   955: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   958: invokeinterface 271 2 0
/*     */     //   963: aload_0
/*     */     //   964: iload 11
/*     */     //   966: aload 5
/*     */     //   968: aload 10
/*     */     //   970: aload 8
/*     */     //   972: invokevirtual 340	java/io/ByteArrayInputStream:available	()I
/*     */     //   975: invokespecial 343	es/mityc/firmaJava/ocsp/OCSPCliente:retryPost	(ILorg/bouncycastle/ocsp/OCSPReq;Les/mityc/firmaJava/ocsp/OCSPCliente$MethodThread;I)V
/*     */     //   978: aload 10
/*     */     //   980: invokevirtual 361	es/mityc/firmaJava/ocsp/OCSPCliente$MethodThread:getResponse	()[B
/*     */     //   983: astore 12
/*     */     //   985: aload 12
/*     */     //   987: ifnonnull +57 -> 1044
/*     */     //   990: new 89	java/lang/StringBuilder
/*     */     //   993: dup
/*     */     //   994: ldc_w 364
/*     */     //   997: invokestatic 110	es/mityc/firmaJava/ocsp/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   1000: invokestatic 116	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   1003: invokespecial 93	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   1006: ldc 122
/*     */     //   1008: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   1011: aload_0
/*     */     //   1012: getfield 46	es/mityc/firmaJava/ocsp/OCSPCliente:servidorURL	Ljava/lang/String;
/*     */     //   1015: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   1018: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   1021: astore 13
/*     */     //   1023: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   1026: ldc_w 366
/*     */     //   1029: invokeinterface 137 2 0
/*     */     //   1034: new 53	es/mityc/firmaJava/ocsp/exception/OCSPClienteException
/*     */     //   1037: dup
/*     */     //   1038: aload 13
/*     */     //   1040: invokespecial 124	es/mityc/firmaJava/ocsp/exception/OCSPClienteException:<init>	(Ljava/lang/String;)V
/*     */     //   1043: athrow
/*     */     //   1044: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   1047: ldc_w 368
/*     */     //   1050: invokeinterface 83 2 0
/*     */     //   1055: new 370	org/bouncycastle/ocsp/OCSPResp
/*     */     //   1058: dup
/*     */     //   1059: aload 12
/*     */     //   1061: invokespecial 372	org/bouncycastle/ocsp/OCSPResp:<init>	([B)V
/*     */     //   1064: astore 6
/*     */     //   1066: goto +74 -> 1140
/*     */     //   1069: astore 13
/*     */     //   1071: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   1074: new 89	java/lang/StringBuilder
/*     */     //   1077: dup
/*     */     //   1078: ldc_w 373
/*     */     //   1081: invokespecial 93	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   1084: aload 13
/*     */     //   1086: invokevirtual 299	java/io/IOException:getMessage	()Ljava/lang/String;
/*     */     //   1089: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   1092: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   1095: invokeinterface 137 2 0
/*     */     //   1100: new 53	es/mityc/firmaJava/ocsp/exception/OCSPClienteException
/*     */     //   1103: dup
/*     */     //   1104: new 89	java/lang/StringBuilder
/*     */     //   1107: dup
/*     */     //   1108: ldc_w 375
/*     */     //   1111: invokestatic 110	es/mityc/firmaJava/ocsp/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   1114: invokestatic 116	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   1117: invokespecial 93	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   1120: ldc 122
/*     */     //   1122: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   1125: aload 13
/*     */     //   1127: invokevirtual 299	java/io/IOException:getMessage	()Ljava/lang/String;
/*     */     //   1130: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   1133: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   1136: invokespecial 124	es/mityc/firmaJava/ocsp/exception/OCSPClienteException:<init>	(Ljava/lang/String;)V
/*     */     //   1139: athrow
/*     */     //   1140: aload 6
/*     */     //   1142: aload_3
/*     */     //   1143: aload 7
/*     */     //   1145: invokestatic 377	es/mityc/firmaJava/ocsp/OCSPCliente:processResponse	(Lorg/bouncycastle/ocsp/OCSPResp;Les/mityc/firmaJava/ocsp/RespuestaOCSP;Lorg/bouncycastle/ocsp/CertificateID;)V
/*     */     //   1148: goto +166 -> 1314
/*     */     //   1151: astore 11
/*     */     //   1153: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   1156: new 89	java/lang/StringBuilder
/*     */     //   1159: dup
/*     */     //   1160: ldc_w 381
/*     */     //   1163: invokespecial 93	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   1166: aload 11
/*     */     //   1168: invokevirtual 383	org/apache/commons/httpclient/HttpException:getMessage	()Ljava/lang/String;
/*     */     //   1171: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   1174: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   1177: invokeinterface 137 2 0
/*     */     //   1182: new 53	es/mityc/firmaJava/ocsp/exception/OCSPClienteException
/*     */     //   1185: dup
/*     */     //   1186: new 89	java/lang/StringBuilder
/*     */     //   1189: dup
/*     */     //   1190: ldc_w 386
/*     */     //   1193: invokestatic 110	es/mityc/firmaJava/ocsp/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   1196: invokestatic 116	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   1199: invokespecial 93	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   1202: ldc 122
/*     */     //   1204: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   1207: aload 11
/*     */     //   1209: invokevirtual 383	org/apache/commons/httpclient/HttpException:getMessage	()Ljava/lang/String;
/*     */     //   1212: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   1215: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   1218: invokespecial 124	es/mityc/firmaJava/ocsp/exception/OCSPClienteException:<init>	(Ljava/lang/String;)V
/*     */     //   1221: athrow
/*     */     //   1222: astore 11
/*     */     //   1224: new 89	java/lang/StringBuilder
/*     */     //   1227: dup
/*     */     //   1228: ldc_w 364
/*     */     //   1231: invokestatic 110	es/mityc/firmaJava/ocsp/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   1234: invokestatic 116	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   1237: invokespecial 93	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   1240: ldc 122
/*     */     //   1242: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   1245: aload_0
/*     */     //   1246: getfield 46	es/mityc/firmaJava/ocsp/OCSPCliente:servidorURL	Ljava/lang/String;
/*     */     //   1249: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   1252: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   1255: astore 12
/*     */     //   1257: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   1260: new 89	java/lang/StringBuilder
/*     */     //   1263: dup
/*     */     //   1264: ldc_w 388
/*     */     //   1267: invokespecial 93	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   1270: aload 11
/*     */     //   1272: invokevirtual 299	java/io/IOException:getMessage	()Ljava/lang/String;
/*     */     //   1275: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   1278: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   1281: invokeinterface 137 2 0
/*     */     //   1286: new 53	es/mityc/firmaJava/ocsp/exception/OCSPClienteException
/*     */     //   1289: dup
/*     */     //   1290: aload 12
/*     */     //   1292: invokespecial 124	es/mityc/firmaJava/ocsp/exception/OCSPClienteException:<init>	(Ljava/lang/String;)V
/*     */     //   1295: athrow
/*     */     //   1296: astore 14
/*     */     //   1298: ldc_w 390
/*     */     //   1301: invokestatic 392	java/security/Security:removeProvider	(Ljava/lang/String;)V
/*     */     //   1304: aload_0
/*     */     //   1305: getfield 42	es/mityc/firmaJava/ocsp/OCSPCliente:method	Lorg/apache/commons/httpclient/methods/PostMethod;
/*     */     //   1308: invokevirtual 397	org/apache/commons/httpclient/methods/PostMethod:releaseConnection	()V
/*     */     //   1311: aload 14
/*     */     //   1313: athrow
/*     */     //   1314: ldc_w 390
/*     */     //   1317: invokestatic 392	java/security/Security:removeProvider	(Ljava/lang/String;)V
/*     */     //   1320: aload_0
/*     */     //   1321: getfield 42	es/mityc/firmaJava/ocsp/OCSPCliente:method	Lorg/apache/commons/httpclient/methods/PostMethod;
/*     */     //   1324: invokevirtual 397	org/apache/commons/httpclient/methods/PostMethod:releaseConnection	()V
/*     */     //   1327: aload_3
/*     */     //   1328: areturn
/*     */     // Line number table:
/*     */     //   Java source line #101	-> byte code offset #0
/*     */     //   Java source line #104	-> byte code offset #8
/*     */     //   Java source line #105	-> byte code offset #11
/*     */     //   Java source line #106	-> byte code offset #20
/*     */     //   Java source line #107	-> byte code offset #23
/*     */     //   Java source line #108	-> byte code offset #26
/*     */     //   Java source line #111	-> byte code offset #29
/*     */     //   Java source line #112	-> byte code offset #45
/*     */     //   Java source line #113	-> byte code offset #55
/*     */     //   Java source line #114	-> byte code offset #60
/*     */     //   Java source line #115	-> byte code offset #88
/*     */     //   Java source line #118	-> byte code offset #127
/*     */     //   Java source line #121	-> byte code offset #134
/*     */     //   Java source line #122	-> byte code offset #141
/*     */     //   Java source line #123	-> byte code offset #151
/*     */     //   Java source line #124	-> byte code offset #154
/*     */     //   Java source line #125	-> byte code offset #156
/*     */     //   Java source line #126	-> byte code offset #184
/*     */     //   Java source line #130	-> byte code offset #223
/*     */     //   Java source line #133	-> byte code offset #234
/*     */     //   Java source line #134	-> byte code offset #242
/*     */     //   Java source line #135	-> byte code offset #253
/*     */     //   Java source line #136	-> byte code offset #263
/*     */     //   Java source line #137	-> byte code offset #284
/*     */     //   Java source line #139	-> byte code offset #304
/*     */     //   Java source line #140	-> byte code offset #323
/*     */     //   Java source line #139	-> byte code offset #339
/*     */     //   Java source line #141	-> byte code offset #344
/*     */     //   Java source line #142	-> byte code offset #355
/*     */     //   Java source line #143	-> byte code offset #370
/*     */     //   Java source line #144	-> byte code offset #373
/*     */     //   Java source line #146	-> byte code offset #377
/*     */     //   Java source line #147	-> byte code offset #393
/*     */     //   Java source line #149	-> byte code offset #408
/*     */     //   Java source line #151	-> byte code offset #431
/*     */     //   Java source line #152	-> byte code offset #450
/*     */     //   Java source line #151	-> byte code offset #466
/*     */     //   Java source line #153	-> byte code offset #471
/*     */     //   Java source line #154	-> byte code offset #482
/*     */     //   Java source line #157	-> byte code offset #497
/*     */     //   Java source line #158	-> byte code offset #513
/*     */     //   Java source line #159	-> byte code offset #522
/*     */     //   Java source line #158	-> byte code offset #531
/*     */     //   Java source line #161	-> byte code offset #534
/*     */     //   Java source line #162	-> byte code offset #556
/*     */     //   Java source line #164	-> byte code offset #571
/*     */     //   Java source line #166	-> byte code offset #577
/*     */     //   Java source line #167	-> byte code offset #582
/*     */     //   Java source line #168	-> byte code offset #594
/*     */     //   Java source line #169	-> byte code offset #622
/*     */     //   Java source line #170	-> byte code offset #625
/*     */     //   Java source line #171	-> byte code offset #639
/*     */     //   Java source line #172	-> byte code offset #645
/*     */     //   Java source line #176	-> byte code offset #659
/*     */     //   Java source line #178	-> byte code offset #674
/*     */     //   Java source line #179	-> byte code offset #687
/*     */     //   Java source line #182	-> byte code offset #690
/*     */     //   Java source line #183	-> byte code offset #704
/*     */     //   Java source line #184	-> byte code offset #709
/*     */     //   Java source line #185	-> byte code offset #738
/*     */     //   Java source line #188	-> byte code offset #778
/*     */     //   Java source line #189	-> byte code offset #789
/*     */     //   Java source line #191	-> byte code offset #798
/*     */     //   Java source line #192	-> byte code offset #807
/*     */     //   Java source line #191	-> byte code offset #816
/*     */     //   Java source line #193	-> byte code offset #819
/*     */     //   Java source line #195	-> byte code offset #835
/*     */     //   Java source line #196	-> byte code offset #845
/*     */     //   Java source line #200	-> byte code offset #850
/*     */     //   Java source line #201	-> byte code offset #863
/*     */     //   Java source line #202	-> byte code offset #868
/*     */     //   Java source line #203	-> byte code offset #875
/*     */     //   Java source line #204	-> byte code offset #886
/*     */     //   Java source line #207	-> byte code offset #900
/*     */     //   Java source line #208	-> byte code offset #907
/*     */     //   Java source line #210	-> byte code offset #918
/*     */     //   Java source line #211	-> byte code offset #926
/*     */     //   Java source line #212	-> byte code offset #937
/*     */     //   Java source line #214	-> byte code offset #963
/*     */     //   Java source line #217	-> byte code offset #978
/*     */     //   Java source line #218	-> byte code offset #985
/*     */     //   Java source line #219	-> byte code offset #990
/*     */     //   Java source line #220	-> byte code offset #1023
/*     */     //   Java source line #221	-> byte code offset #1034
/*     */     //   Java source line #223	-> byte code offset #1044
/*     */     //   Java source line #226	-> byte code offset #1055
/*     */     //   Java source line #227	-> byte code offset #1066
/*     */     //   Java source line #228	-> byte code offset #1071
/*     */     //   Java source line #229	-> byte code offset #1100
/*     */     //   Java source line #244	-> byte code offset #1140
/*     */     //   Java source line #245	-> byte code offset #1148
/*     */     //   Java source line #246	-> byte code offset #1153
/*     */     //   Java source line #247	-> byte code offset #1182
/*     */     //   Java source line #248	-> byte code offset #1222
/*     */     //   Java source line #249	-> byte code offset #1224
/*     */     //   Java source line #250	-> byte code offset #1257
/*     */     //   Java source line #251	-> byte code offset #1286
/*     */     //   Java source line #252	-> byte code offset #1296
/*     */     //   Java source line #253	-> byte code offset #1298
/*     */     //   Java source line #254	-> byte code offset #1304
/*     */     //   Java source line #255	-> byte code offset #1311
/*     */     //   Java source line #253	-> byte code offset #1314
/*     */     //   Java source line #254	-> byte code offset #1320
/*     */     //   Java source line #257	-> byte code offset #1327
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	1329	0	this	OCSPCliente
/*     */     //   0	1329	1	certificadoUsuario	X509Certificate
/*     */     //   0	1329	2	certificadoEmisor	X509Certificate
/*     */     //   7	1321	3	respuesta	RespuestaOCSP
/*     */     //   18	117	4	generadorPeticion	org.bouncycastle.ocsp.OCSPReqGenerator
/*     */     //   21	946	5	peticionOCSP	org.bouncycastle.ocsp.OCSPReq
/*     */     //   24	1117	6	respuestaOCSP	OCSPResp
/*     */     //   27	1117	7	certificadoId	CertificateID
/*     */     //   58	55	8	e	OCSPException
/*     */     //   154	55	8	e	OCSPException
/*     */     //   342	7	8	encoded	String
/*     */     //   391	13	8	defaultcreds	org.apache.commons.httpclient.Credentials
/*     */     //   469	7	8	encoded	String
/*     */     //   575	9	8	servidor	es.mityc.firmaJava.ocsp.config.ServidorOcsp
/*     */     //   688	283	8	datos	java.io.ByteArrayInputStream
/*     */     //   353	13	9	defaultcreds	org.apache.commons.httpclient.Credentials
/*     */     //   480	13	9	defaultcreds	org.apache.commons.httpclient.Credentials
/*     */     //   707	57	9	e	IOException
/*     */     //   787	7	9	rq	org.apache.commons.httpclient.methods.InputStreamRequestEntity
/*     */     //   843	136	10	ocspThread	MethodThread
/*     */     //   866	3	11	e	InterruptedException
/*     */     //   905	60	11	estadoCodigo	int
/*     */     //   1151	57	11	e	org.apache.commons.httpclient.HttpException
/*     */     //   1222	49	11	e	IOException
/*     */     //   983	77	12	cuerpoRespuesta	byte[]
/*     */     //   1255	36	12	mensajeError	String
/*     */     //   1021	18	13	mensajeError	String
/*     */     //   1069	57	13	e	IOException
/*     */     //   1296	16	14	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   29	55	58	org/bouncycastle/ocsp/OCSPException
/*     */     //   134	151	154	org/bouncycastle/ocsp/OCSPException
/*     */     //   690	704	707	java/io/IOException
/*     */     //   850	863	866	java/lang/InterruptedException
/*     */     //   1055	1066	1069	java/io/IOException
/*     */     //   850	1148	1151	org/apache/commons/httpclient/HttpException
/*     */     //   850	1148	1222	java/io/IOException
/*     */     //   850	1296	1296	finally
/*     */   }
/*     */   
/*     */   public static void processResponse(OCSPResp inResp, RespuestaOCSP outResp, CertificateID certID)
/*     */     throws OCSPClienteException, IOException
/*     */   {
/* 261 */     outResp.setRespuesta(inResp);
/* 262 */     if (inResp.getStatus() != 0)
/*     */     {
/* 264 */       log.info("OCSPResponseStatus: not successful.");
/* 265 */       switch (inResp.getStatus())
/*     */       {
/*     */       case 1: 
/* 268 */         log.warn("OCSPResponseStatus: malformedRequest.");
/* 269 */         outResp.setNroRespuesta(4);
/* 270 */         outResp.setMensajeRespuesta(I18n.getResource("libreriaocsp.respuesta1"));
/*     */         
/* 272 */         break;
/*     */       case 2: 
/* 274 */         log.warn("OCSPResponseStatus: internalError.");
/* 275 */         outResp.setNroRespuesta(5);
/* 276 */         outResp.setMensajeRespuesta(I18n.getResource("libreriaocsp.respuesta2"));
/* 277 */         break;
/*     */       case 3: 
/* 279 */         log.warn("OCSPResponseStatus: tryLater.");
/* 280 */         outResp.setNroRespuesta(6);
/* 281 */         outResp.setMensajeRespuesta(I18n.getResource("libreriaocsp.respuesta3"));
/* 282 */         break;
/*     */       case 5: 
/* 284 */         log.warn("OCSPResponseStatus: sigRequired.");
/* 285 */         outResp.setNroRespuesta(7);
/* 286 */         outResp.setMensajeRespuesta(I18n.getResource("libreriaocsp.respuesta4"));
/* 287 */         break;
/*     */       case 6: 
/* 289 */         log.warn("OCSPResponseStatus: unauthorized.");
/* 290 */         outResp.setNroRespuesta(8);
/* 291 */         outResp.setMensajeRespuesta(I18n.getResource("libreriaocsp.respuesta5"));
/*     */       }
/*     */       
/*     */     }
/*     */     else
/*     */     {
/*     */       try
/*     */       {
/* 299 */         log.info("OCSPResponseStatus: successful.");
/* 300 */         BasicOCSPResp respuestaBasica = (BasicOCSPResp)inResp.getResponseObject();
/*     */         try
/*     */         {
/* 303 */           X509Certificate[] certs = respuestaBasica.getCerts("SUN");
/* 304 */           if ((certs != null) && (certs.length > 0)) {
/* 305 */             ArrayList<X509Certificate> list = new ArrayList(certs.length);
/* 306 */             for (int i = 0; i < certs.length; i++)
/* 307 */               list.add(certs[i]);
/* 308 */             outResp.setOCSPSigner(list);
/*     */           }
/*     */         } catch (NoSuchProviderException e) {
/* 311 */           log.info(e.getMessage(), e);
/*     */         } catch (OCSPException e) {
/* 313 */           log.info(e.getMessage(), e);
/*     */         }
/*     */         
/* 316 */         SingleResp[] arrayRespuestaBasica = respuestaBasica.getResponses();
/* 317 */         outResp.setTiempoRespuesta(respuestaBasica.getProducedAt());
/* 318 */         ResponderID respID = respuestaBasica.getResponderId().toASN1Object();
/* 319 */         outResp.setResponder(respID);
/* 320 */         StringBuffer mensaje = new StringBuffer("Se recibió un estado no definido: ");
/*     */         
/* 322 */         boolean finded = false;
/* 323 */         for (int i = 0; i < arrayRespuestaBasica.length; i++)
/*     */         {
/*     */ 
/* 326 */           SingleResp sr = arrayRespuestaBasica[i];
/* 327 */           if (certID.equals(sr.getCertID()))
/*     */           {
/*     */ 
/* 330 */             finded = true;
/* 331 */             Object certStatus = arrayRespuestaBasica[i].getCertStatus();
/* 332 */             if (certStatus == null)
/*     */             {
/* 334 */               log.info("Estado del certificado: Good.");
/* 335 */               outResp.setNroRespuesta(0);
/* 336 */               outResp.setMensajeRespuesta(new String(Base64Coder.encode(inResp.getEncoded())));
/*     */             }
/* 338 */             else if ((certStatus instanceof RevokedStatus))
/*     */             {
/* 340 */               log.info("Estado del certificado: Revoked.");
/* 341 */               outResp.setFechaRevocacion(((RevokedStatus)certStatus).getRevocationTime());
/* 342 */               outResp.setNroRespuesta(1);
/*     */               
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 355 */               RevokedStatus revoked = (RevokedStatus)certStatus;
/* 356 */               if (revoked.hasRevocationReason())
/*     */               {
/* 358 */                 switch (revoked.getRevocationReason())
/*     */                 {
/*     */ 
/*     */                 case 1: 
/* 362 */                   outResp.setMensajeRespuesta(I18n.getResource("libreriaocsp.razonrevocacion1"));
/* 363 */                   break;
/*     */                 case 2: 
/* 365 */                   outResp.setMensajeRespuesta(I18n.getResource("libreriaocsp.razonrevocacion2"));
/* 366 */                   break;
/*     */                 case 3: 
/* 368 */                   outResp.setMensajeRespuesta(I18n.getResource("libreriaocsp.razonrevocacion3"));
/* 369 */                   break;
/*     */                 case 4: 
/* 371 */                   outResp.setMensajeRespuesta(I18n.getResource("libreriaocsp.razonrevocacion4"));
/* 372 */                   break;
/*     */                 case 5: 
/* 374 */                   outResp.setMensajeRespuesta(I18n.getResource("libreriaocsp.razonrevocacion5"));
/* 375 */                   break;
/*     */                 case 6: 
/* 377 */                   outResp.setMensajeRespuesta(I18n.getResource("libreriaocsp.razonrevocacion6"));
/* 378 */                   break;
/*     */                 default: 
/* 380 */                   outResp.setMensajeRespuesta("");
/*     */                   
/* 382 */                   break; }
/*     */                  } else {
/* 384 */                 outResp.setMensajeRespuesta("");
/*     */               }
/* 386 */             } else if ((certStatus instanceof UnknownStatus))
/*     */             {
/*     */ 
/* 389 */               log.info("Estado del certificado: Unknown.");
/* 390 */               outResp.setNroRespuesta(2);
/* 391 */               outResp.setMensajeRespuesta("El servidor ha respondido que el estado del certificado es desconocido");
/*     */             }
/*     */             else
/*     */             {
/* 395 */               mensaje.append(arrayRespuestaBasica[i].getCertStatus().getClass().getName());
/* 396 */               log.info(mensaje.toString());
/* 397 */               outResp.setNroRespuesta(3);
/* 398 */               outResp.setMensajeRespuesta(arrayRespuestaBasica[i].getCertStatus().getClass().getName());
/*     */             }
/*     */           }
/*     */         }
/* 402 */         if (!finded) {
/* 403 */           log.info("Estado del certificado: Unknown.");
/* 404 */           outResp.setNroRespuesta(2);
/* 405 */           outResp.setMensajeRespuesta("El servidor ha respondido que el estado del certificado es desconocido");
/*     */         }
/*     */       }
/*     */       catch (OCSPException e)
/*     */       {
/* 410 */         log.error("Error al instanciar la respuesta OCSP básica: " + e.getMessage());
/* 411 */         throw new OCSPClienteException(I18n.getResource("libreriaocsp.error6") + ": " + e.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setSSLManager(ISSLManager sslmanager)
/*     */   {
/* 421 */     Protocol authhttps = new Protocol("https", new OwnSSLProtocolSocketFactory(sslmanager), 443);
/* 422 */     Protocol.registerProtocol("https", authhttps);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeOut(Integer timeMilis)
/*     */   {
/* 430 */     if ((timeMilis != null) && (timeMilis.intValue() > 0)) {
/* 431 */       log.debug("Se establece el tiempo máximo de espera a " + timeMilis);
/* 432 */       this.timeOut = timeMilis;
/*     */     } else {
/* 434 */       log.error("No se pudo establecer el valor de TimeOut a " + timeMilis + ". Se toma el valor por defecto.");
/* 435 */       this.timeOut = INT_20000;
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void abort() {
/* 440 */     if (this.method != null) {
/* 441 */       this.method.abort();
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private void retryPost(int estadoCodigo, org.bouncycastle.ocsp.OCSPReq peticionOCSP, MethodThread ocspThread, int dataLenght)
/*     */     throws OCSPClienteException, es.mityc.firmaJava.ocsp.exception.OCSPProxyException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 42	es/mityc/firmaJava/ocsp/OCSPCliente:method	Lorg/apache/commons/httpclient/methods/PostMethod;
/*     */     //   4: ifnull +13 -> 17
/*     */     //   7: aload_0
/*     */     //   8: getfield 42	es/mityc/firmaJava/ocsp/OCSPCliente:method	Lorg/apache/commons/httpclient/methods/PostMethod;
/*     */     //   11: invokevirtual 676	org/apache/commons/httpclient/methods/PostMethod:isAborted	()Z
/*     */     //   14: ifeq +15 -> 29
/*     */     //   17: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   20: ldc_w 679
/*     */     //   23: invokeinterface 271 2 0
/*     */     //   28: return
/*     */     //   29: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   32: ldc_w 681
/*     */     //   35: invokeinterface 83 2 0
/*     */     //   40: aconst_null
/*     */     //   41: astore 5
/*     */     //   43: aconst_null
/*     */     //   44: astore 6
/*     */     //   46: aload_0
/*     */     //   47: getfield 46	es/mityc/firmaJava/ocsp/OCSPCliente:servidorURL	Ljava/lang/String;
/*     */     //   50: invokestatic 683	es/mityc/javasign/utils/ProxyUtil:getConnection	(Ljava/lang/String;)Ljava/net/HttpURLConnection;
/*     */     //   53: astore 5
/*     */     //   55: aload 5
/*     */     //   57: sipush 7000
/*     */     //   60: invokevirtual 687	java/net/HttpURLConnection:setConnectTimeout	(I)V
/*     */     //   63: aload 5
/*     */     //   65: ldc_w 692
/*     */     //   68: invokevirtual 694	java/net/HttpURLConnection:setRequestMethod	(Ljava/lang/String;)V
/*     */     //   71: aload 5
/*     */     //   73: ldc_w 279
/*     */     //   76: ldc_w 281
/*     */     //   79: invokevirtual 697	java/net/HttpURLConnection:setRequestProperty	(Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   82: aload 5
/*     */     //   84: ldc_w 700
/*     */     //   87: ldc_w 702
/*     */     //   90: invokevirtual 697	java/net/HttpURLConnection:setRequestProperty	(Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   93: aload 5
/*     */     //   95: ldc_w 704
/*     */     //   98: iload 4
/*     */     //   100: invokestatic 706	java/lang/String:valueOf	(I)Ljava/lang/String;
/*     */     //   103: invokevirtual 697	java/net/HttpURLConnection:setRequestProperty	(Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   106: aload 5
/*     */     //   108: iconst_0
/*     */     //   109: invokevirtual 709	java/net/HttpURLConnection:setUseCaches	(Z)V
/*     */     //   112: aload 5
/*     */     //   114: iconst_1
/*     */     //   115: invokevirtual 713	java/net/HttpURLConnection:setDoOutput	(Z)V
/*     */     //   118: new 716	java/io/DataOutputStream
/*     */     //   121: dup
/*     */     //   122: aload 5
/*     */     //   124: invokevirtual 718	java/net/HttpURLConnection:getOutputStream	()Ljava/io/OutputStream;
/*     */     //   127: invokespecial 722	java/io/DataOutputStream:<init>	(Ljava/io/OutputStream;)V
/*     */     //   130: astore 7
/*     */     //   132: aload 7
/*     */     //   134: aload_2
/*     */     //   135: invokevirtual 288	org/bouncycastle/ocsp/OCSPReq:getEncoded	()[B
/*     */     //   138: invokevirtual 725	java/io/DataOutputStream:write	([B)V
/*     */     //   141: aload 7
/*     */     //   143: invokevirtual 728	java/io/DataOutputStream:flush	()V
/*     */     //   146: aload 7
/*     */     //   148: invokevirtual 731	java/io/DataOutputStream:close	()V
/*     */     //   151: aload 5
/*     */     //   153: invokevirtual 734	java/net/HttpURLConnection:getResponseCode	()I
/*     */     //   156: sipush 200
/*     */     //   159: if_icmpne +202 -> 361
/*     */     //   162: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   165: invokeinterface 352 1 0
/*     */     //   170: ifeq +32 -> 202
/*     */     //   173: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   176: new 89	java/lang/StringBuilder
/*     */     //   179: dup
/*     */     //   180: ldc_w 737
/*     */     //   183: invokespecial 93	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   186: aload 5
/*     */     //   188: invokevirtual 739	java/net/HttpURLConnection:usingProxy	()Z
/*     */     //   191: invokevirtual 742	java/lang/StringBuilder:append	(Z)Ljava/lang/StringBuilder;
/*     */     //   194: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   197: invokeinterface 271 2 0
/*     */     //   202: aload 5
/*     */     //   204: invokevirtual 745	java/net/HttpURLConnection:getContent	()Ljava/lang/Object;
/*     */     //   207: checkcast 748	java/io/InputStream
/*     */     //   210: astore 6
/*     */     //   212: new 370	org/bouncycastle/ocsp/OCSPResp
/*     */     //   215: dup
/*     */     //   216: aload 6
/*     */     //   218: invokespecial 750	org/bouncycastle/ocsp/OCSPResp:<init>	(Ljava/io/InputStream;)V
/*     */     //   221: astore 8
/*     */     //   223: aload 8
/*     */     //   225: invokevirtual 444	org/bouncycastle/ocsp/OCSPResp:getStatus	()I
/*     */     //   228: istore 9
/*     */     //   230: aload 8
/*     */     //   232: ifnull +50 -> 282
/*     */     //   235: aload 8
/*     */     //   237: invokevirtual 551	org/bouncycastle/ocsp/OCSPResp:getEncoded	()[B
/*     */     //   240: arraylength
/*     */     //   241: ifle +41 -> 282
/*     */     //   244: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   247: invokeinterface 352 1 0
/*     */     //   252: ifeq +14 -> 266
/*     */     //   255: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   258: ldc_w 751
/*     */     //   261: invokeinterface 271 2 0
/*     */     //   266: sipush 200
/*     */     //   269: istore_1
/*     */     //   270: aload_3
/*     */     //   271: aload 8
/*     */     //   273: invokevirtual 551	org/bouncycastle/ocsp/OCSPResp:getEncoded	()[B
/*     */     //   276: invokevirtual 753	es/mityc/firmaJava/ocsp/OCSPCliente$MethodThread:setResponse	([B)V
/*     */     //   279: goto +229 -> 508
/*     */     //   282: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   285: invokeinterface 352 1 0
/*     */     //   290: ifeq +29 -> 319
/*     */     //   293: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   296: new 89	java/lang/StringBuilder
/*     */     //   299: dup
/*     */     //   300: ldc_w 756
/*     */     //   303: invokespecial 93	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   306: iload 9
/*     */     //   308: invokevirtual 358	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*     */     //   311: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   314: invokeinterface 271 2 0
/*     */     //   319: new 53	es/mityc/firmaJava/ocsp/exception/OCSPClienteException
/*     */     //   322: dup
/*     */     //   323: new 89	java/lang/StringBuilder
/*     */     //   326: dup
/*     */     //   327: ldc_w 758
/*     */     //   330: invokestatic 110	es/mityc/firmaJava/ocsp/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   333: invokestatic 116	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   336: invokespecial 93	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   339: ldc 122
/*     */     //   341: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   344: aload_0
/*     */     //   345: getfield 42	es/mityc/firmaJava/ocsp/OCSPCliente:method	Lorg/apache/commons/httpclient/methods/PostMethod;
/*     */     //   348: invokevirtual 760	org/apache/commons/httpclient/methods/PostMethod:getStatusLine	()Lorg/apache/commons/httpclient/StatusLine;
/*     */     //   351: invokevirtual 668	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   354: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   357: invokespecial 124	es/mityc/firmaJava/ocsp/exception/OCSPClienteException:<init>	(Ljava/lang/String;)V
/*     */     //   360: athrow
/*     */     //   361: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   364: invokeinterface 352 1 0
/*     */     //   369: ifeq +139 -> 508
/*     */     //   372: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   375: new 89	java/lang/StringBuilder
/*     */     //   378: dup
/*     */     //   379: ldc_w 764
/*     */     //   382: invokespecial 93	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   385: aload 5
/*     */     //   387: invokevirtual 734	java/net/HttpURLConnection:getResponseCode	()I
/*     */     //   390: invokevirtual 358	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*     */     //   393: ldc_w 766
/*     */     //   396: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   399: aload 5
/*     */     //   401: invokevirtual 768	java/net/HttpURLConnection:getResponseMessage	()Ljava/lang/String;
/*     */     //   404: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   407: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   410: invokeinterface 271 2 0
/*     */     //   415: goto +93 -> 508
/*     */     //   418: astore 7
/*     */     //   420: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   423: invokeinterface 352 1 0
/*     */     //   428: ifeq +16 -> 444
/*     */     //   431: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   434: ldc_w 771
/*     */     //   437: aload 7
/*     */     //   439: invokeinterface 773 3 0
/*     */     //   444: new 55	es/mityc/firmaJava/ocsp/exception/OCSPProxyException
/*     */     //   447: dup
/*     */     //   448: aload 7
/*     */     //   450: invokespecial 775	es/mityc/firmaJava/ocsp/exception/OCSPProxyException:<init>	(Ljava/lang/Throwable;)V
/*     */     //   453: athrow
/*     */     //   454: astore 10
/*     */     //   456: aload 5
/*     */     //   458: ifnull +8 -> 466
/*     */     //   461: aload 5
/*     */     //   463: invokevirtual 778	java/net/HttpURLConnection:disconnect	()V
/*     */     //   466: aload 6
/*     */     //   468: ifnull +37 -> 505
/*     */     //   471: aload 6
/*     */     //   473: invokevirtual 781	java/io/InputStream:close	()V
/*     */     //   476: goto +29 -> 505
/*     */     //   479: astore 11
/*     */     //   481: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   484: invokeinterface 352 1 0
/*     */     //   489: ifeq +16 -> 505
/*     */     //   492: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   495: ldc_w 782
/*     */     //   498: aload 11
/*     */     //   500: invokeinterface 773 3 0
/*     */     //   505: aload 10
/*     */     //   507: athrow
/*     */     //   508: aload 5
/*     */     //   510: ifnull +8 -> 518
/*     */     //   513: aload 5
/*     */     //   515: invokevirtual 778	java/net/HttpURLConnection:disconnect	()V
/*     */     //   518: aload 6
/*     */     //   520: ifnull +37 -> 557
/*     */     //   523: aload 6
/*     */     //   525: invokevirtual 781	java/io/InputStream:close	()V
/*     */     //   528: goto +29 -> 557
/*     */     //   531: astore 11
/*     */     //   533: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   536: invokeinterface 352 1 0
/*     */     //   541: ifeq +16 -> 557
/*     */     //   544: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   547: ldc_w 782
/*     */     //   550: aload 11
/*     */     //   552: invokeinterface 773 3 0
/*     */     //   557: iload_1
/*     */     //   558: sipush 407
/*     */     //   561: if_icmpne +14 -> 575
/*     */     //   564: new 55	es/mityc/firmaJava/ocsp/exception/OCSPProxyException
/*     */     //   567: dup
/*     */     //   568: ldc_w 784
/*     */     //   571: invokespecial 786	es/mityc/firmaJava/ocsp/exception/OCSPProxyException:<init>	(Ljava/lang/String;)V
/*     */     //   574: athrow
/*     */     //   575: iload_1
/*     */     //   576: sipush 305
/*     */     //   579: if_icmpne +14 -> 593
/*     */     //   582: new 55	es/mityc/firmaJava/ocsp/exception/OCSPProxyException
/*     */     //   585: dup
/*     */     //   586: ldc_w 787
/*     */     //   589: invokespecial 786	es/mityc/firmaJava/ocsp/exception/OCSPProxyException:<init>	(Ljava/lang/String;)V
/*     */     //   592: athrow
/*     */     //   593: iload_1
/*     */     //   594: sipush 200
/*     */     //   597: if_icmpeq +76 -> 673
/*     */     //   600: getstatic 33	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */     //   603: new 89	java/lang/StringBuilder
/*     */     //   606: dup
/*     */     //   607: ldc_w 789
/*     */     //   610: invokespecial 93	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   613: aload_0
/*     */     //   614: getfield 42	es/mityc/firmaJava/ocsp/OCSPCliente:method	Lorg/apache/commons/httpclient/methods/PostMethod;
/*     */     //   617: invokevirtual 760	org/apache/commons/httpclient/methods/PostMethod:getStatusLine	()Lorg/apache/commons/httpclient/StatusLine;
/*     */     //   620: invokevirtual 668	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   623: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   626: invokeinterface 137 2 0
/*     */     //   631: new 53	es/mityc/firmaJava/ocsp/exception/OCSPClienteException
/*     */     //   634: dup
/*     */     //   635: new 89	java/lang/StringBuilder
/*     */     //   638: dup
/*     */     //   639: ldc_w 758
/*     */     //   642: invokestatic 110	es/mityc/firmaJava/ocsp/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   645: invokestatic 116	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   648: invokespecial 93	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   651: ldc 122
/*     */     //   653: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   656: aload_0
/*     */     //   657: getfield 42	es/mityc/firmaJava/ocsp/OCSPCliente:method	Lorg/apache/commons/httpclient/methods/PostMethod;
/*     */     //   660: invokevirtual 760	org/apache/commons/httpclient/methods/PostMethod:getStatusLine	()Lorg/apache/commons/httpclient/StatusLine;
/*     */     //   663: invokevirtual 668	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   666: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   669: invokespecial 124	es/mityc/firmaJava/ocsp/exception/OCSPClienteException:<init>	(Ljava/lang/String;)V
/*     */     //   672: athrow
/*     */     //   673: return
/*     */     // Line number table:
/*     */     //   Java source line #473	-> byte code offset #0
/*     */     //   Java source line #474	-> byte code offset #17
/*     */     //   Java source line #475	-> byte code offset #28
/*     */     //   Java source line #477	-> byte code offset #29
/*     */     //   Java source line #478	-> byte code offset #40
/*     */     //   Java source line #479	-> byte code offset #43
/*     */     //   Java source line #481	-> byte code offset #46
/*     */     //   Java source line #482	-> byte code offset #55
/*     */     //   Java source line #483	-> byte code offset #63
/*     */     //   Java source line #484	-> byte code offset #71
/*     */     //   Java source line #485	-> byte code offset #82
/*     */     //   Java source line #486	-> byte code offset #93
/*     */     //   Java source line #487	-> byte code offset #106
/*     */     //   Java source line #488	-> byte code offset #112
/*     */     //   Java source line #490	-> byte code offset #118
/*     */     //   Java source line #491	-> byte code offset #132
/*     */     //   Java source line #492	-> byte code offset #141
/*     */     //   Java source line #493	-> byte code offset #146
/*     */     //   Java source line #495	-> byte code offset #151
/*     */     //   Java source line #496	-> byte code offset #162
/*     */     //   Java source line #497	-> byte code offset #173
/*     */     //   Java source line #500	-> byte code offset #202
/*     */     //   Java source line #501	-> byte code offset #212
/*     */     //   Java source line #502	-> byte code offset #223
/*     */     //   Java source line #504	-> byte code offset #230
/*     */     //   Java source line #505	-> byte code offset #244
/*     */     //   Java source line #506	-> byte code offset #255
/*     */     //   Java source line #508	-> byte code offset #266
/*     */     //   Java source line #509	-> byte code offset #270
/*     */     //   Java source line #510	-> byte code offset #279
/*     */     //   Java source line #511	-> byte code offset #282
/*     */     //   Java source line #512	-> byte code offset #293
/*     */     //   Java source line #514	-> byte code offset #319
/*     */     //   Java source line #517	-> byte code offset #361
/*     */     //   Java source line #518	-> byte code offset #372
/*     */     //   Java source line #521	-> byte code offset #415
/*     */     //   Java source line #522	-> byte code offset #420
/*     */     //   Java source line #523	-> byte code offset #431
/*     */     //   Java source line #525	-> byte code offset #444
/*     */     //   Java source line #526	-> byte code offset #454
/*     */     //   Java source line #527	-> byte code offset #456
/*     */     //   Java source line #528	-> byte code offset #461
/*     */     //   Java source line #530	-> byte code offset #466
/*     */     //   Java source line #531	-> byte code offset #471
/*     */     //   Java source line #532	-> byte code offset #481
/*     */     //   Java source line #533	-> byte code offset #492
/*     */     //   Java source line #537	-> byte code offset #505
/*     */     //   Java source line #527	-> byte code offset #508
/*     */     //   Java source line #528	-> byte code offset #513
/*     */     //   Java source line #530	-> byte code offset #518
/*     */     //   Java source line #531	-> byte code offset #523
/*     */     //   Java source line #532	-> byte code offset #533
/*     */     //   Java source line #533	-> byte code offset #544
/*     */     //   Java source line #539	-> byte code offset #557
/*     */     //   Java source line #540	-> byte code offset #564
/*     */     //   Java source line #541	-> byte code offset #575
/*     */     //   Java source line #542	-> byte code offset #582
/*     */     //   Java source line #543	-> byte code offset #593
/*     */     //   Java source line #544	-> byte code offset #600
/*     */     //   Java source line #545	-> byte code offset #631
/*     */     //   Java source line #547	-> byte code offset #673
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	674	0	this	OCSPCliente
/*     */     //   0	674	1	estadoCodigo	int
/*     */     //   0	674	2	peticionOCSP	org.bouncycastle.ocsp.OCSPReq
/*     */     //   0	674	3	ocspThread	MethodThread
/*     */     //   0	674	4	dataLenght	int
/*     */     //   41	473	5	conn	java.net.HttpURLConnection
/*     */     //   44	480	6	in	java.io.InputStream
/*     */     //   130	17	7	wr	java.io.DataOutputStream
/*     */     //   418	31	7	e1	Exception
/*     */     //   221	51	8	ocspResponse	OCSPResp
/*     */     //   228	79	9	status	int
/*     */     //   454	52	10	localObject	Object
/*     */     //   479	20	11	e1	IOException
/*     */     //   531	20	11	e1	IOException
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   46	415	418	java/lang/Exception
/*     */     //   46	454	454	finally
/*     */     //   471	476	479	java/io/IOException
/*     */     //   523	528	531	java/io/IOException
/*     */   }
/*     */   
/*     */   class MethodThread
/*     */     extends Thread
/*     */   {
/* 445 */     private int result = 0;
/* 446 */     private byte[] response = null;
/*     */     
/*     */     public MethodThread() {}
/*     */     
/*     */     /* Error */
/*     */     public void run()
/*     */     {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_0
/*     */       //   2: getfield 14	es/mityc/firmaJava/ocsp/OCSPCliente$MethodThread:this$0	Les/mityc/firmaJava/ocsp/OCSPCliente;
/*     */       //   5: invokestatic 28	es/mityc/firmaJava/ocsp/OCSPCliente:access$1	(Les/mityc/firmaJava/ocsp/OCSPCliente;)Lorg/apache/commons/httpclient/HttpClient;
/*     */       //   8: aload_0
/*     */       //   9: getfield 14	es/mityc/firmaJava/ocsp/OCSPCliente$MethodThread:this$0	Les/mityc/firmaJava/ocsp/OCSPCliente;
/*     */       //   12: invokestatic 34	es/mityc/firmaJava/ocsp/OCSPCliente:access$0	(Les/mityc/firmaJava/ocsp/OCSPCliente;)Lorg/apache/commons/httpclient/methods/PostMethod;
/*     */       //   15: invokevirtual 38	org/apache/commons/httpclient/HttpClient:executeMethod	(Lorg/apache/commons/httpclient/HttpMethod;)I
/*     */       //   18: putfield 19	es/mityc/firmaJava/ocsp/OCSPCliente$MethodThread:result	I
/*     */       //   21: aload_0
/*     */       //   22: aload_0
/*     */       //   23: getfield 14	es/mityc/firmaJava/ocsp/OCSPCliente$MethodThread:this$0	Les/mityc/firmaJava/ocsp/OCSPCliente;
/*     */       //   26: invokestatic 34	es/mityc/firmaJava/ocsp/OCSPCliente:access$0	(Les/mityc/firmaJava/ocsp/OCSPCliente;)Lorg/apache/commons/httpclient/methods/PostMethod;
/*     */       //   29: invokevirtual 44	org/apache/commons/httpclient/methods/PostMethod:getResponseBody	()[B
/*     */       //   32: putfield 21	es/mityc/firmaJava/ocsp/OCSPCliente$MethodThread:response	[B
/*     */       //   35: goto +39 -> 74
/*     */       //   38: astore_1
/*     */       //   39: getstatic 50	es/mityc/firmaJava/ocsp/OCSPCliente:log	Lorg/apache/commons/logging/Log;
/*     */       //   42: aload_1
/*     */       //   43: invokeinterface 54 2 0
/*     */       //   48: aload_0
/*     */       //   49: getfield 14	es/mityc/firmaJava/ocsp/OCSPCliente$MethodThread:this$0	Les/mityc/firmaJava/ocsp/OCSPCliente;
/*     */       //   52: invokestatic 34	es/mityc/firmaJava/ocsp/OCSPCliente:access$0	(Les/mityc/firmaJava/ocsp/OCSPCliente;)Lorg/apache/commons/httpclient/methods/PostMethod;
/*     */       //   55: invokevirtual 60	org/apache/commons/httpclient/methods/PostMethod:releaseConnection	()V
/*     */       //   58: goto +26 -> 84
/*     */       //   61: astore_2
/*     */       //   62: aload_0
/*     */       //   63: getfield 14	es/mityc/firmaJava/ocsp/OCSPCliente$MethodThread:this$0	Les/mityc/firmaJava/ocsp/OCSPCliente;
/*     */       //   66: invokestatic 34	es/mityc/firmaJava/ocsp/OCSPCliente:access$0	(Les/mityc/firmaJava/ocsp/OCSPCliente;)Lorg/apache/commons/httpclient/methods/PostMethod;
/*     */       //   69: invokevirtual 60	org/apache/commons/httpclient/methods/PostMethod:releaseConnection	()V
/*     */       //   72: aload_2
/*     */       //   73: athrow
/*     */       //   74: aload_0
/*     */       //   75: getfield 14	es/mityc/firmaJava/ocsp/OCSPCliente$MethodThread:this$0	Les/mityc/firmaJava/ocsp/OCSPCliente;
/*     */       //   78: invokestatic 34	es/mityc/firmaJava/ocsp/OCSPCliente:access$0	(Les/mityc/firmaJava/ocsp/OCSPCliente;)Lorg/apache/commons/httpclient/methods/PostMethod;
/*     */       //   81: invokevirtual 60	org/apache/commons/httpclient/methods/PostMethod:releaseConnection	()V
/*     */       //   84: return
/*     */       // Line number table:
/*     */       //   Java source line #452	-> byte code offset #0
/*     */       //   Java source line #453	-> byte code offset #21
/*     */       //   Java source line #454	-> byte code offset #35
/*     */       //   Java source line #455	-> byte code offset #39
/*     */       //   Java source line #457	-> byte code offset #48
/*     */       //   Java source line #456	-> byte code offset #61
/*     */       //   Java source line #457	-> byte code offset #62
/*     */       //   Java source line #458	-> byte code offset #72
/*     */       //   Java source line #457	-> byte code offset #74
/*     */       //   Java source line #459	-> byte code offset #84
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	signature
/*     */       //   0	85	0	this	MethodThread
/*     */       //   38	5	1	e	Exception
/*     */       //   61	12	2	localObject	Object
/*     */       // Exception table:
/*     */       //   from	to	target	type
/*     */       //   0	35	38	java/lang/Exception
/*     */       //   0	48	61	finally
/*     */     }
/*     */     
/*     */     public int getResult()
/*     */     {
/* 462 */       return this.result;
/*     */     }
/*     */     
/* 465 */     public byte[] getResponse() { return this.response; }
/*     */     
/*     */     public void setResponse(byte[] res) {
/* 468 */       this.response = res;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibOCSP-1.1.7.jar!\es\mityc\firmaJava\ocsp\OCSPCliente.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */