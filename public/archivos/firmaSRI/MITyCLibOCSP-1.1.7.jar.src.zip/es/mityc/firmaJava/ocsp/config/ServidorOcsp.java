/*    */ package es.mityc.firmaJava.ocsp.config;
/*    */ 
/*    */ import java.net.URI;
/*    */ import java.net.URISyntaxException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServidorOcsp
/*    */   implements Cloneable, ConstantesProveedores
/*    */ {
/* 29 */   private URI url = null;
/* 30 */   private String descripcion = "";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ServidorOcsp(String url, String descripcion)
/*    */     throws URISyntaxException
/*    */   {
/* 39 */     this.url = new URI(url);
/* 40 */     this.descripcion = descripcion;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getDescripcion()
/*    */   {
/* 47 */     return this.descripcion;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public URI getUrl()
/*    */   {
/* 54 */     return this.url;
/*    */   }
/*    */   
/* 57 */   protected Object clone() throws CloneNotSupportedException { return (ServidorOcsp)super.clone(); }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibOCSP-1.1.7.jar!\es\mityc\firmaJava\ocsp\config\ServidorOcsp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */