/*    */ package es.mityc.firmaJava.ocsp.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OCSPException
/*    */   extends Exception
/*    */ {
/*    */   public OCSPException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public OCSPException(String message)
/*    */   {
/* 36 */     super(message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public OCSPException(Throwable cause)
/*    */   {
/* 43 */     super(cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public OCSPException(String message, Throwable cause)
/*    */   {
/* 51 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibOCSP-1.1.7.jar!\es\mityc\firmaJava\ocsp\exception\OCSPException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */