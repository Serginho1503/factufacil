/*    */ package es.mityc.firmaJava.ocsp;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class I18n
/*    */   implements ConstantesOCSP
/*    */ {
/* 28 */   private static Locale locale = new Locale("es", "ES");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String getResource(String key)
/*    */   {
/* 37 */     return getResource(key, locale);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String getResource(String key, Locale locale)
/*    */   {
/* 46 */     return ResourceBundle.getBundle("i18n_libreriaOCSP", locale).getString(key);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static Locale getLocale()
/*    */   {
/* 53 */     return locale;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static void setLocale(Locale _locale)
/*    */   {
/* 60 */     locale = _locale;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void setLocaleCountry(String country, String dialect)
/*    */   {
/* 68 */     locale = new Locale(country, dialect);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibOCSP-1.1.7.jar!\es\mityc\firmaJava\ocsp\I18n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */