/*     */ package es.mityc.firmaJava.ocsp.config;
/*     */ 
/*     */ import es.mityc.javasign.utils.Base64Coder;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.bouncycastle.asn1.ASN1InputStream;
/*     */ import org.bouncycastle.asn1.ASN1OctetString;
/*     */ import org.bouncycastle.asn1.ASN1Sequence;
/*     */ import org.bouncycastle.asn1.DERBitString;
/*     */ import org.bouncycastle.asn1.DERObject;
/*     */ import org.bouncycastle.asn1.DERObjectIdentifier;
/*     */ import org.bouncycastle.asn1.DEROctetString;
/*     */ import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
/*     */ import org.bouncycastle.asn1.x509.X509Extensions;
/*     */ import org.bouncycastle.crypto.Digest;
/*     */ import org.bouncycastle.crypto.digests.SHA1Digest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UtilidadesX509
/*     */   implements ConstantesProveedores
/*     */ {
/*  47 */   private static Log logger = LogFactory.getLog(UtilidadesX509.class);
/*     */   private static final String STRING_EMPTY = "";
/*     */   
/*     */   public static boolean isEmpty(String valor) {
/*  51 */     return (valor == null) || (valor.trim().equals(""));
/*     */   }
/*     */   
/*     */   public static X509Certificate getCertificate(Object certObj) throws CertificateException {
/*  55 */     X509Certificate cert = null;
/*  56 */     CertificateFactory cf = CertificateFactory.getInstance("X.509");
/*  57 */     ByteArrayInputStream certStream = null;
/*     */     
/*  59 */     if ((certObj instanceof String)) {
/*  60 */       certStream = new ByteArrayInputStream(Base64Coder.decode((String)certObj));
/*  61 */     } else if ((certObj instanceof byte[])) {
/*  62 */       certStream = new ByteArrayInputStream((byte[])certObj);
/*  63 */     } else if ((certObj instanceof InputStream)) {
/*  64 */       certStream = (ByteArrayInputStream)certObj;
/*     */     } else {
/*  66 */       throw new CertificateException("Illegal argument type. Can be a String, byte[] or X509Certificate.");
/*     */     }
/*     */     try
/*     */     {
/*  70 */       cert = (X509Certificate)cf.generateCertificate(certStream);
/*     */     } catch (CertificateException e) {
/*  72 */       logger.error(e.getMessage());
/*  73 */       throw new CertificateException(e.getMessage());
/*     */     }
/*  75 */     return cert;
/*     */   }
/*     */   
/*     */   public static DERObject convertToDERObject(byte[] data) throws IOException
/*     */   {
/*  80 */     ByteArrayInputStream inStream = new ByteArrayInputStream(data);
/*  81 */     ASN1InputStream derInputStream = new ASN1InputStream(inStream);
/*  82 */     return derInputStream.readObject();
/*     */   }
/*     */   
/*     */   public static ASN1OctetString getIssuerKeyHash(X509Certificate cert) throws IOException {
/*  86 */     ASN1OctetString issuerKeyHash = null;
/*  87 */     Digest digest = new SHA1Digest();
/*  88 */     byte[] resBuf = new byte[digest.getDigestSize()];
/*  89 */     byte[] bytes = cert.getIssuerX500Principal().getEncoded();
/*     */     
/*  91 */     digest.update(bytes, 0, bytes.length);
/*  92 */     digest.doFinal(resBuf, 0);
/*     */     
/*     */ 
/*     */ 
/*  96 */     DERObject derObject = convertToDERObject(cert.getExtensionValue(X509Extensions.AuthorityKeyIdentifier.getId()));
/*  97 */     if ((derObject instanceof DEROctetString))
/*     */     {
/*  99 */       DEROctetString derOctetString = (DEROctetString)derObject;
/* 100 */       derObject = convertToDERObject(derOctetString.getOctets());
/*     */     }
/* 102 */     ASN1Sequence aIs = ASN1Sequence.getInstance(derObject);
/* 103 */     issuerKeyHash = ASN1OctetString.getInstance(aIs.getObjectAt(0));
/*     */     
/* 105 */     return issuerKeyHash;
/*     */   }
/*     */   
/*     */   public static ASN1OctetString getIssuerNameHash(X509Certificate cert) {
/* 109 */     Digest digest = new SHA1Digest();
/* 110 */     byte[] resBuf = new byte[digest.getDigestSize()];
/* 111 */     byte[] bytes = cert.getIssuerX500Principal().getEncoded();
/*     */     
/* 113 */     digest.update(bytes, 0, bytes.length);
/* 114 */     digest.doFinal(resBuf, 0);
/* 115 */     ASN1OctetString issuerNameHash = new DEROctetString(resBuf);
/* 116 */     return issuerNameHash;
/*     */   }
/*     */   
/*     */   public static ASN1OctetString getSubjectNameHash(X509Certificate cert) {
/* 120 */     Digest digest = new SHA1Digest();
/* 121 */     byte[] resBuf = new byte[digest.getDigestSize()];
/* 122 */     byte[] bytes = cert.getSubjectX500Principal().getEncoded();
/*     */     
/* 124 */     digest.update(bytes, 0, bytes.length);
/* 125 */     digest.doFinal(resBuf, 0);
/* 126 */     ASN1OctetString issuerNameHash = new DEROctetString(resBuf);
/* 127 */     return issuerNameHash;
/*     */   }
/*     */   
/*     */   public static ASN1OctetString getSubjectKeyHash(X509Certificate cert) throws IOException {
/* 131 */     PublicKey pk = cert.getPublicKey();
/* 132 */     byte[] pkCertBytes = pk.getEncoded();
/* 133 */     DERObject der = convertToDERObject(pkCertBytes);
/* 134 */     ASN1Sequence seq = ASN1Sequence.getInstance(der);
/* 135 */     SubjectPublicKeyInfo spki = new SubjectPublicKeyInfo(seq);
/*     */     
/* 137 */     Digest digest = new SHA1Digest();
/* 138 */     byte[] resBuf = new byte[digest.getDigestSize()];
/* 139 */     byte[] bytes = spki.getPublicKeyData().getBytes();
/*     */     
/* 141 */     digest.update(bytes, 0, bytes.length);
/* 142 */     digest.doFinal(resBuf, 0);
/* 143 */     ASN1OctetString issuerKeyHash = new DEROctetString(resBuf);
/*     */     
/* 145 */     return issuerKeyHash;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibOCSP-1.1.7.jar!\es\mityc\firmaJava\ocsp\config\UtilidadesX509.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */