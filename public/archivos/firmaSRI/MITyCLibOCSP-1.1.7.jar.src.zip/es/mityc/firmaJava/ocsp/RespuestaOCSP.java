/*     */ package es.mityc.firmaJava.ocsp;
/*     */ 
/*     */ import es.mityc.firmaJava.ocsp.exception.OCSPSignatureException;
/*     */ import es.mityc.javasign.certificate.IOCSPCertStatus.TYPE_RESPONDER;
/*     */ import es.mityc.javasign.utils.Base64Coder;
/*     */ import java.io.IOException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ import org.bouncycastle.asn1.ASN1OctetString;
/*     */ import org.bouncycastle.asn1.ASN1TaggedObject;
/*     */ import org.bouncycastle.asn1.ocsp.ResponderID;
/*     */ import org.bouncycastle.asn1.x509.X509Name;
/*     */ import org.bouncycastle.jce.X509Principal;
/*     */ import org.bouncycastle.ocsp.BasicOCSPResp;
/*     */ import org.bouncycastle.ocsp.OCSPResp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RespuestaOCSP
/*     */ {
/*     */   private static final String PROVEEDOR_SUN = "SUN";
/*     */   
/*     */   public static enum ESTADOS_RESPUESTA
/*     */   {
/*  50 */     SUCCESFULL,  MALFORMED_REQ,  INTERNAL_ERROR,  TRY_LATER,  SIG_REQUIRED,  UNAUTHORIZED; }
/*     */   
/*  52 */   private int nroRespuesta = 9;
/*  53 */   private String mensajeRespuesta = "Consulta OCSP interrumpida";
/*     */   
/*     */   private OCSPResp respuesta;
/*     */   
/*     */   private Date tiempoRespuesta;
/*     */   
/*     */   private IOCSPCertStatus.TYPE_RESPONDER tipoResponder;
/*     */   
/*     */   private String valorResponder;
/*     */   
/*     */   private Date fechaRevocacion;
/*     */   
/*     */   private ArrayList<X509Certificate> ocspSignerCerts;
/*     */   
/*     */   public RespuestaOCSP(int nroRespuesta, String mensajeRespuesta)
/*     */   {
/*  69 */     this.nroRespuesta = nroRespuesta;
/*  70 */     this.mensajeRespuesta = mensajeRespuesta;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RespuestaOCSP() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getRespuestaEncoded()
/*     */   {
/*  88 */     if (this.respuesta != null) {
/*     */       try {
/*  90 */         return this.respuesta.getEncoded();
/*     */       } catch (IOException ex) {
/*  92 */         return null;
/*     */       }
/*     */     }
/*  95 */     return null;
/*     */   }
/*     */   
/*     */   public OCSPResp getRespuesta() {
/*  99 */     return this.respuesta;
/*     */   }
/*     */   
/*     */   public X509Certificate[] getCertificates() throws es.mityc.firmaJava.ocsp.exception.OCSPException {
/* 103 */     X509Certificate[] certs = null;
/* 104 */     byte[] resp = getRespuestaEncoded();
/* 105 */     if (resp != null) {
/*     */       try {
/* 107 */         OCSPResp respuestaOCSP = new OCSPResp(resp);
/* 108 */         BasicOCSPResp basicOcsp = (BasicOCSPResp)respuestaOCSP.getResponseObject();
/* 109 */         if (basicOcsp != null)
/* 110 */           certs = basicOcsp.getCerts("SUN");
/*     */       } catch (IOException ex) {
/* 112 */         throw new es.mityc.firmaJava.ocsp.exception.OCSPException(ex);
/*     */       } catch (NoSuchProviderException ex) {
/* 114 */         throw new es.mityc.firmaJava.ocsp.exception.OCSPException(ex);
/*     */       } catch (org.bouncycastle.ocsp.OCSPException ex) {
/* 116 */         throw new es.mityc.firmaJava.ocsp.exception.OCSPException(ex);
/*     */       }
/*     */     }
/* 119 */     return certs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRespuesta(OCSPResp respuesta)
/*     */   {
/* 129 */     this.respuesta = respuesta;
/*     */   }
/*     */   
/*     */   public void setRespuesta(byte[] data) {
/*     */     try {
/* 134 */       this.respuesta = new OCSPResp(data);
/*     */     } catch (IOException ex) {
/* 136 */       this.respuesta = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMensajeRespuesta()
/*     */   {
/* 146 */     return this.mensajeRespuesta;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMensajeRespuesta(String mensajeRespuesta)
/*     */   {
/* 155 */     this.mensajeRespuesta = mensajeRespuesta;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNroRespuesta()
/*     */   {
/* 164 */     return this.nroRespuesta;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNroRespuesta(int nroRespuesta)
/*     */   {
/* 173 */     this.nroRespuesta = nroRespuesta;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getTiempoRespuesta()
/*     */   {
/* 181 */     Date resp = null;
/* 182 */     if (this.tiempoRespuesta != null)
/* 183 */       resp = new Date(this.tiempoRespuesta.getTime());
/* 184 */     return resp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTiempoRespuesta(Date tiempoRespuesta)
/*     */   {
/* 192 */     this.tiempoRespuesta = new Date(tiempoRespuesta.getTime());
/*     */   }
/*     */   
/*     */ 
/*     */   public IOCSPCertStatus.TYPE_RESPONDER getTipoResponder()
/*     */   {
/* 198 */     return this.tipoResponder;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setResponder(ResponderID responder)
/*     */   {
/* 204 */     ASN1TaggedObject tagged = (ASN1TaggedObject)responder.toASN1Object();
/* 205 */     switch (tagged.getTagNo()) {
/*     */     case 1: 
/* 207 */       this.valorResponder = X509Name.getInstance(tagged.getObject()).toString();
/* 208 */       X509Principal certX509Principal = new X509Principal(this.valorResponder);
/* 209 */       X500Principal cerX500Principal = new X500Principal(certX509Principal.getDEREncoded());
/* 210 */       this.valorResponder = cerX500Principal.getName();
/* 211 */       this.tipoResponder = IOCSPCertStatus.TYPE_RESPONDER.BY_NAME;
/* 212 */       break;
/*     */     case 2: 
/* 214 */       ASN1OctetString octect = (ASN1OctetString)tagged.getObject();
/* 215 */       this.valorResponder = new String(Base64Coder.encode(octect.getOctets()));
/* 216 */       this.tipoResponder = IOCSPCertStatus.TYPE_RESPONDER.BY_KEY;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */   public String getValorResponder()
/*     */   {
/* 224 */     return this.valorResponder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getFechaRevocacion()
/*     */   {
/* 232 */     return this.fechaRevocacion;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFechaRevocacion(Date fecha)
/*     */   {
/* 240 */     if (fecha != null) {
/* 241 */       this.fechaRevocacion = new Date(fecha.getTime());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setOCSPSigner(ArrayList<X509Certificate> certs)
/*     */   {
/* 249 */     this.ocspSignerCerts = certs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ArrayList<X509Certificate> getOCSPSigner()
/*     */   {
/* 257 */     return this.ocspSignerCerts;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void checkSign(PublicKey pk)
/*     */     throws es.mityc.firmaJava.ocsp.exception.OCSPException
/*     */   {
/* 267 */     if (this.respuesta == null)
/* 268 */       throw new es.mityc.firmaJava.ocsp.exception.OCSPException();
/*     */     try {
/* 270 */       BasicOCSPResp respuestaBasica = (BasicOCSPResp)this.respuesta.getResponseObject();
/* 271 */       if (!respuestaBasica.verify(pk, "SunRsaSign"))
/* 272 */         throw new OCSPSignatureException();
/*     */     } catch (org.bouncycastle.ocsp.OCSPException ex) {
/* 274 */       throw new es.mityc.firmaJava.ocsp.exception.OCSPException(ex.getMessage(), ex);
/*     */     } catch (NoSuchProviderException ex) {
/* 276 */       throw new OCSPSignatureException(ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibOCSP-1.1.7.jar!\es\mityc\firmaJava\ocsp\RespuestaOCSP.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */