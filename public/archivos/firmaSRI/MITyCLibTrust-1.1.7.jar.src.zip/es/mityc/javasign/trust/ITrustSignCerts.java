package es.mityc.javasign.trust;

import java.security.cert.CertPath;

public abstract interface ITrustSignCerts
{
  public abstract void isTrusted(CertPath paramCertPath)
    throws TrustException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibTrust-1.1.7.jar!\es\mityc\javasign\trust\ITrustSignCerts.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */