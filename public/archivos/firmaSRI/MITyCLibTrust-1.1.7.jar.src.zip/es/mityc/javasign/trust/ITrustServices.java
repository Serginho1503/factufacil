package es.mityc.javasign.trust;

import java.security.cert.X509Certificate;
import java.util.List;

public abstract interface ITrustServices
{
  public abstract List<MyPropsTruster.TrustCertStruct> getCAs()
    throws TrustException;
  
  public abstract boolean containsCert(String paramString)
    throws TrustException;
  
  public abstract void addCA(X509Certificate paramX509Certificate, PropsTruster.TrusterType paramTrusterType, String paramString)
    throws TrustException;
  
  public abstract void removeCA(X509Certificate paramX509Certificate, PropsTruster.TrusterType paramTrusterType, String paramString)
    throws TrustException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibTrust-1.1.7.jar!\es\mityc\javasign\trust\ITrustServices.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */