/*    */ package es.mityc.javasign.trust;
/*    */ 
/*    */ import java.security.cert.CertPath;
/*    */ import java.security.cert.X509CRL;
/*    */ import java.security.cert.X509Certificate;
/*    */ import org.bouncycastle.ocsp.OCSPResp;
/*    */ import org.bouncycastle.tsp.TimeStampToken;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AllUntrusted
/*    */   extends TrustAdapter
/*    */ {
/* 34 */   private static AllUntrusted instance = new AllUntrusted();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void isTrusted(X509CRL crl)
/*    */     throws TrustException
/*    */   {
/* 43 */     throw new NotTrustedException();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void isTrusted(OCSPResp ocsp)
/*    */     throws TrustException
/*    */   {
/* 53 */     throw new NotTrustedException();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void isTrusted(CertPath certs)
/*    */     throws TrustException
/*    */   {
/* 63 */     throw new NotTrustedException();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void isTrusted(TimeStampToken tst)
/*    */     throws TrustException
/*    */   {
/* 73 */     throw new NotTrustedException();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static TrustAbstract getInstance()
/*    */   {
/* 82 */     return instance;
/*    */   }
/*    */   
/*    */   public CertPath getCertPath(X509Certificate cert) throws UnknownTrustException
/*    */   {
/* 87 */     throw new UnknownTrustException("Not implemented");
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibTrust-1.1.7.jar!\es\mityc\javasign\trust\AllUntrusted.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */