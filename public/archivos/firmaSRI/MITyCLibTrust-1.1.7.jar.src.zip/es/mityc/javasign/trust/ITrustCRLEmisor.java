package es.mityc.javasign.trust;

import java.security.cert.X509CRL;

public abstract interface ITrustCRLEmisor
{
  public abstract void isTrusted(X509CRL paramX509CRL)
    throws TrustException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibTrust-1.1.7.jar!\es\mityc\javasign\trust\ITrustCRLEmisor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */