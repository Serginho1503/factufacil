package es.mityc.javasign.trust;

public final class ConstantsTrust
{
  public static final String LIB_NAME = "MITyCLibTrust";
  public static final String KEY_MITYC = "mityc";
  public static final String I18N_TRUST_1 = "i18n.mityc.trust.1";
  public static final String I18N_TRUST_2 = "i18n.mityc.trust.2";
  public static final String I18N_TRUST_3 = "i18n.mityc.trust.3";
  public static final String I18N_TRUST_4 = "i18n.mityc.trust.4";
  public static final String I18N_TRUST_5 = "i18n.mityc.trust.5";
  public static final String I18N_TRUST_PROPS_1 = "i18n.mityc.trust.props.1";
  public static final String I18N_TRUST_PROPS_2 = "i18n.mityc.trust.props.2";
  public static final String I18N_TRUST_PROPS_3 = "i18n.mityc.trust.props.3";
  public static final String I18N_TRUST_PROPS_4 = "i18n.mityc.trust.props.4";
  public static final String I18N_TRUST_PROPS_5 = "i18n.mityc.trust.props.5";
  public static final String I18N_TRUST_PROPS_6 = "i18n.mityc.trust.props.6";
  public static final String I18N_TRUST_PROPS_7 = "i18n.mityc.trust.props.7";
  public static final String I18N_TRUST_PROPS_8 = "i18n.mityc.trust.props.8";
  public static final String I18N_TRUST_PROPS_9 = "i18n.mityc.trust.props.9";
  public static final String I18N_TRUST_PROPS_10 = "i18n.mityc.trust.props.10";
  public static final String I18N_TRUST_PROPS_11 = "i18n.mityc.trust.props.11";
  public static final String I18N_TRUST_PROPS_12 = "i18n.mityc.trust.props.12";
  public static final String I18N_TRUST_PROPS_13 = "i18n.mityc.trust.props.13";
  public static final String I18N_TRUST_PROPS_14 = "i18n.mityc.trust.props.14";
  public static final String I18N_TRUST_PROPS_15 = "i18n.mityc.trust.props.15";
  public static final String I18N_TRUST_PROPS_16 = "i18n.mityc.trust.props.16";
  public static final String I18N_TRUST_PROPS_17 = "i18n.mityc.trust.props.17";
  public static final String I18N_TRUST_PROPS_18 = "i18n.mityc.trust.props.18";
  public static final String I18N_TRUST_PROPS_19 = "i18n.mityc.trust.props.19";
  public static final String I18N_TRUST_PROPS_20 = "i18n.mityc.trust.props.20";
  public static final String I18N_TRUST_PROPS_21 = "i18n.mityc.trust.props.21";
  public static final String I18N_TRUST_PROPS_22 = "i18n.mityc.trust.props.22";
  public static final String I18N_TRUST_PROPS_23 = "i18n.mityc.trust.props.23";
  public static final String I18N_TRUST_PROPS_24 = "i18n.mityc.trust.props.24";
  public static final String I18N_TRUST_PROPS_25 = "i18n.mityc.trust.props.25";
  public static final String I18N_TRUST_PROPS_26 = "i18n.mityc.trust.props.26";
  public static final String I18N_TRUST_UTILS_1 = "i18n.mityc.trust.utils.1";
  public static final String I18N_TRUST_UTILS_2 = "i18n.mityc.trust.utils.2";
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibTrust-1.1.7.jar!\es\mityc\javasign\trust\ConstantsTrust.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */