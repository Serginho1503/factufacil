/*     */ package es.mityc.javasign.trust;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MyPropsTruster
/*     */   extends PropsTruster
/*     */   implements ITrustServices
/*     */ {
/*  45 */   static Log log = LogFactory.getLog(MyPropsTruster.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String CONF_FILE = "trust/myTruster.properties";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MyPropsTruster(InputStream externalConf)
/*     */   {
/*  57 */     super("trust/myTruster.properties", externalConf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized MyPropsTruster getInstance(InputStream externalConf)
/*     */   {
/*  66 */     if (instance == null) {
/*  67 */       instance = new MyPropsTruster(externalConf);
/*     */     }
/*  69 */     return (MyPropsTruster)instance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private synchronized void reloadConf()
/*     */   {
/*  76 */     loadConf("trust/myTruster.properties", this.externalProps);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void addCA(X509Certificate cert, PropsTruster.TrusterType type, String path)
/*     */     throws TrustException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore 4
/*     */     //   3: aload_0
/*     */     //   4: invokevirtual 59	es/mityc/javasign/trust/MyPropsTruster:getCAs	()Ljava/util/List;
/*     */     //   7: astore 5
/*     */     //   9: iconst_0
/*     */     //   10: istore 6
/*     */     //   12: goto +29 -> 41
/*     */     //   15: aload_1
/*     */     //   16: aload 5
/*     */     //   18: iload 6
/*     */     //   20: invokeinterface 63 2 0
/*     */     //   25: checkcast 69	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct
/*     */     //   28: invokevirtual 71	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct:getCert	()Ljava/security/cert/X509Certificate;
/*     */     //   31: invokevirtual 75	java/security/cert/X509Certificate:equals	(Ljava/lang/Object;)Z
/*     */     //   34: ifeq +4 -> 38
/*     */     //   37: return
/*     */     //   38: iinc 6 1
/*     */     //   41: iload 6
/*     */     //   43: aload 5
/*     */     //   45: invokeinterface 81 1 0
/*     */     //   50: if_icmplt -35 -> 15
/*     */     //   53: aload_1
/*     */     //   54: invokestatic 85	es/mityc/javasign/trust/Utils:getMD5	(Ljava/security/cert/X509Certificate;)Ljava/lang/String;
/*     */     //   57: astore 4
/*     */     //   59: goto +15 -> 74
/*     */     //   62: astore 6
/*     */     //   64: new 57	es/mityc/javasign/trust/TrustException
/*     */     //   67: dup
/*     */     //   68: aload 6
/*     */     //   70: invokespecial 91	es/mityc/javasign/trust/TrustException:<init>	(Ljava/lang/Throwable;)V
/*     */     //   73: athrow
/*     */     //   74: new 94	java/lang/StringBuilder
/*     */     //   77: dup
/*     */     //   78: aload_3
/*     */     //   79: invokestatic 96	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   82: invokespecial 102	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   85: getstatic 105	java/io/File:separator	Ljava/lang/String;
/*     */     //   88: invokevirtual 110	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   91: ldc 114
/*     */     //   93: invokevirtual 110	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   96: invokevirtual 116	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   99: astore 6
/*     */     //   101: new 106	java/io/File
/*     */     //   104: dup
/*     */     //   105: aload 6
/*     */     //   107: invokespecial 120	java/io/File:<init>	(Ljava/lang/String;)V
/*     */     //   110: astore 7
/*     */     //   112: aload 7
/*     */     //   114: invokevirtual 121	java/io/File:exists	()Z
/*     */     //   117: ifne +9 -> 126
/*     */     //   120: aload 7
/*     */     //   122: invokevirtual 125	java/io/File:mkdirs	()Z
/*     */     //   125: pop
/*     */     //   126: new 94	java/lang/StringBuilder
/*     */     //   129: dup
/*     */     //   130: aload_3
/*     */     //   131: invokestatic 96	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   134: invokespecial 102	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   137: getstatic 105	java/io/File:separator	Ljava/lang/String;
/*     */     //   140: invokevirtual 110	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   143: ldc 114
/*     */     //   145: invokevirtual 110	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   148: getstatic 105	java/io/File:separator	Ljava/lang/String;
/*     */     //   151: invokevirtual 110	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   154: aload 4
/*     */     //   156: invokevirtual 110	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   159: ldc -128
/*     */     //   161: invokevirtual 110	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   164: invokevirtual 116	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   167: astore 6
/*     */     //   169: new 106	java/io/File
/*     */     //   172: dup
/*     */     //   173: aload 6
/*     */     //   175: invokespecial 120	java/io/File:<init>	(Ljava/lang/String;)V
/*     */     //   178: invokevirtual 121	java/io/File:exists	()Z
/*     */     //   181: ifne +108 -> 289
/*     */     //   184: aconst_null
/*     */     //   185: astore 8
/*     */     //   187: new 130	java/io/FileOutputStream
/*     */     //   190: dup
/*     */     //   191: aload 6
/*     */     //   193: invokespecial 132	java/io/FileOutputStream:<init>	(Ljava/lang/String;)V
/*     */     //   196: astore 8
/*     */     //   198: aload 8
/*     */     //   200: aload_1
/*     */     //   201: invokevirtual 133	java/security/cert/X509Certificate:getEncoded	()[B
/*     */     //   204: invokevirtual 137	java/io/FileOutputStream:write	([B)V
/*     */     //   207: goto +57 -> 264
/*     */     //   210: astore 9
/*     */     //   212: new 57	es/mityc/javasign/trust/TrustException
/*     */     //   215: dup
/*     */     //   216: aload 9
/*     */     //   218: invokespecial 91	es/mityc/javasign/trust/TrustException:<init>	(Ljava/lang/Throwable;)V
/*     */     //   221: athrow
/*     */     //   222: astore 9
/*     */     //   224: new 57	es/mityc/javasign/trust/TrustException
/*     */     //   227: dup
/*     */     //   228: aload 9
/*     */     //   230: invokespecial 91	es/mityc/javasign/trust/TrustException:<init>	(Ljava/lang/Throwable;)V
/*     */     //   233: athrow
/*     */     //   234: astore 10
/*     */     //   236: aload 8
/*     */     //   238: ifnull +23 -> 261
/*     */     //   241: aload 8
/*     */     //   243: invokevirtual 141	java/io/FileOutputStream:close	()V
/*     */     //   246: goto +15 -> 261
/*     */     //   249: astore 11
/*     */     //   251: new 57	es/mityc/javasign/trust/TrustException
/*     */     //   254: dup
/*     */     //   255: aload 11
/*     */     //   257: invokespecial 91	es/mityc/javasign/trust/TrustException:<init>	(Ljava/lang/Throwable;)V
/*     */     //   260: athrow
/*     */     //   261: aload 10
/*     */     //   263: athrow
/*     */     //   264: aload 8
/*     */     //   266: ifnull +23 -> 289
/*     */     //   269: aload 8
/*     */     //   271: invokevirtual 141	java/io/FileOutputStream:close	()V
/*     */     //   274: goto +15 -> 289
/*     */     //   277: astore 11
/*     */     //   279: new 57	es/mityc/javasign/trust/TrustException
/*     */     //   282: dup
/*     */     //   283: aload 11
/*     */     //   285: invokespecial 91	es/mityc/javasign/trust/TrustException:<init>	(Ljava/lang/Throwable;)V
/*     */     //   288: athrow
/*     */     //   289: new 94	java/lang/StringBuilder
/*     */     //   292: dup
/*     */     //   293: aload_2
/*     */     //   294: invokevirtual 144	es/mityc/javasign/trust/PropsTruster$TrusterType:toString	()Ljava/lang/String;
/*     */     //   297: invokestatic 96	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   300: invokespecial 102	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   303: bipush 46
/*     */     //   305: invokevirtual 147	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
/*     */     //   308: aload 4
/*     */     //   310: invokevirtual 110	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   313: invokevirtual 116	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   316: astore 8
/*     */     //   318: iconst_2
/*     */     //   319: istore 9
/*     */     //   321: goto +40 -> 361
/*     */     //   324: new 94	java/lang/StringBuilder
/*     */     //   327: dup
/*     */     //   328: aload_2
/*     */     //   329: invokevirtual 144	es/mityc/javasign/trust/PropsTruster$TrusterType:toString	()Ljava/lang/String;
/*     */     //   332: invokestatic 96	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   335: invokespecial 102	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   338: bipush 46
/*     */     //   340: invokevirtual 147	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
/*     */     //   343: aload 4
/*     */     //   345: invokevirtual 110	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   348: iload 9
/*     */     //   350: invokevirtual 150	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*     */     //   353: invokevirtual 116	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   356: astore 8
/*     */     //   358: iinc 9 1
/*     */     //   361: aload_0
/*     */     //   362: getfield 46	es/mityc/javasign/trust/MyPropsTruster:externalProps	Ljava/util/Properties;
/*     */     //   365: aload 8
/*     */     //   367: invokevirtual 153	java/util/Properties:containsKey	(Ljava/lang/Object;)Z
/*     */     //   370: ifne -46 -> 324
/*     */     //   373: aload_0
/*     */     //   374: getfield 46	es/mityc/javasign/trust/MyPropsTruster:externalProps	Ljava/util/Properties;
/*     */     //   377: aload 8
/*     */     //   379: aload 6
/*     */     //   381: invokevirtual 158	java/util/Properties:setProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;
/*     */     //   384: pop
/*     */     //   385: aload_0
/*     */     //   386: invokespecial 162	es/mityc/javasign/trust/MyPropsTruster:reloadConf	()V
/*     */     //   389: return
/*     */     // Line number table:
/*     */     //   Java source line #87	-> byte code offset #0
/*     */     //   Java source line #89	-> byte code offset #3
/*     */     //   Java source line #90	-> byte code offset #9
/*     */     //   Java source line #91	-> byte code offset #15
/*     */     //   Java source line #92	-> byte code offset #37
/*     */     //   Java source line #90	-> byte code offset #38
/*     */     //   Java source line #98	-> byte code offset #53
/*     */     //   Java source line #99	-> byte code offset #59
/*     */     //   Java source line #100	-> byte code offset #64
/*     */     //   Java source line #104	-> byte code offset #74
/*     */     //   Java source line #106	-> byte code offset #101
/*     */     //   Java source line #107	-> byte code offset #112
/*     */     //   Java source line #108	-> byte code offset #120
/*     */     //   Java source line #112	-> byte code offset #126
/*     */     //   Java source line #114	-> byte code offset #169
/*     */     //   Java source line #116	-> byte code offset #184
/*     */     //   Java source line #118	-> byte code offset #187
/*     */     //   Java source line #119	-> byte code offset #198
/*     */     //   Java source line #120	-> byte code offset #207
/*     */     //   Java source line #121	-> byte code offset #212
/*     */     //   Java source line #122	-> byte code offset #222
/*     */     //   Java source line #123	-> byte code offset #224
/*     */     //   Java source line #124	-> byte code offset #234
/*     */     //   Java source line #125	-> byte code offset #236
/*     */     //   Java source line #127	-> byte code offset #241
/*     */     //   Java source line #128	-> byte code offset #246
/*     */     //   Java source line #130	-> byte code offset #261
/*     */     //   Java source line #125	-> byte code offset #264
/*     */     //   Java source line #127	-> byte code offset #269
/*     */     //   Java source line #128	-> byte code offset #274
/*     */     //   Java source line #135	-> byte code offset #289
/*     */     //   Java source line #136	-> byte code offset #318
/*     */     //   Java source line #137	-> byte code offset #324
/*     */     //   Java source line #136	-> byte code offset #358
/*     */     //   Java source line #141	-> byte code offset #373
/*     */     //   Java source line #144	-> byte code offset #385
/*     */     //   Java source line #145	-> byte code offset #389
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	390	0	this	MyPropsTruster
/*     */     //   0	390	1	cert	X509Certificate
/*     */     //   0	390	2	type	PropsTruster.TrusterType
/*     */     //   0	390	3	path	String
/*     */     //   1	343	4	fileName	String
/*     */     //   7	37	5	cas	java.util.List<TrustCertStruct>
/*     */     //   10	32	6	i	int
/*     */     //   62	7	6	e	Exception
/*     */     //   99	281	6	pathToCert	String
/*     */     //   110	11	7	desFile	File
/*     */     //   185	85	8	fos	java.io.FileOutputStream
/*     */     //   316	62	8	key	String
/*     */     //   210	7	9	e	java.io.IOException
/*     */     //   222	7	9	e	java.security.cert.CertificateEncodingException
/*     */     //   319	40	9	i	int
/*     */     //   234	28	10	localObject	Object
/*     */     //   249	7	11	e	java.io.IOException
/*     */     //   277	7	11	e	java.io.IOException
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   53	59	62	java/lang/Exception
/*     */     //   187	207	210	java/io/IOException
/*     */     //   187	207	222	java/security/cert/CertificateEncodingException
/*     */     //   187	234	234	finally
/*     */     //   241	246	249	java/io/IOException
/*     */     //   269	274	277	java/io/IOException
/*     */   }
/*     */   
/*     */   public boolean containsCert(String md5Digest)
/*     */     throws TrustException
/*     */   {
/* 154 */     if (this.externalProps == null) {
/* 155 */       throw new TrustException("No hay propiedades externas cargadas");
/*     */     }
/* 157 */     boolean result = false;
/* 158 */     Enumeration<?> keys = this.externalProps.keys();
/* 159 */     String key = null;
/* 160 */     while (keys.hasMoreElements()) {
/* 161 */       key = (String)keys.nextElement();
/* 162 */       if (key.contains(md5Digest)) {
/* 163 */         result = true;
/* 164 */         break;
/*     */       }
/*     */     }
/*     */     
/* 168 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeCA(X509Certificate cert, PropsTruster.TrusterType type, String path)
/*     */     throws TrustException
/*     */   {
/* 181 */     String fileName = null;
/*     */     try {
/* 183 */       fileName = Utils.getMD5(cert);
/*     */     } catch (Exception e) {
/* 185 */       throw new TrustException(e);
/*     */     }
/*     */     
/*     */ 
/* 189 */     String pathToCert = path + "CAs";
/*     */     
/* 191 */     File desFile = new File(pathToCert);
/* 192 */     if (!desFile.exists()) {
/* 193 */       throw new TrustException("No se encuentra el repositorio de certificados local");
/*     */     }
/*     */     
/*     */ 
/* 197 */     pathToCert = pathToCert + File.separator + fileName + ".cer";
/*     */     
/*     */ 
/* 200 */     String keyToDel = type.toString() + '.' + fileName;
/* 201 */     boolean isDeleted = false;
/* 202 */     if (this.externalProps.containsKey(keyToDel)) {
/* 203 */       Enumeration<?> keys = this.externalProps.keys();
/* 204 */       String key = null;
/* 205 */       while (keys.hasMoreElements()) {
/* 206 */         key = (String)keys.nextElement();
/* 207 */         if (key.contains(keyToDel))
/*     */         {
/* 209 */           this.externalProps.remove(key);
/* 210 */           isDeleted = true;
/* 211 */           break;
/*     */         }
/*     */       }
/*     */       
/* 215 */       if (isDeleted)
/*     */       {
/* 217 */         reloadConf();
/*     */       } else {
/* 219 */         throw new TrustException("Error al borrar. No se pudo borrar el certificado " + keyToDel);
/*     */       }
/*     */     } else {
/* 222 */       throw new TrustException("Error al borrar. No se encuentra el certificado " + keyToDel);
/*     */     }
/*     */     
/*     */ 
/* 226 */     desFile = new File(pathToCert);
/*     */     
/* 228 */     if (!desFile.exists()) {
/* 229 */       throw new TrustException("Error al borrar. No se encuentra el certificado indicado");
/*     */     }
/* 231 */     if (!desFile.delete()) {
/* 232 */       log.error("No se pudo borrar el certificado indicado: " + pathToCert);
/* 233 */       desFile.deleteOnExit();
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public java.util.List<TrustCertStruct> getCAs()
/*     */     throws TrustException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 252	java/util/ArrayList
/*     */     //   3: dup
/*     */     //   4: invokespecial 254	java/util/ArrayList:<init>	()V
/*     */     //   7: astore_1
/*     */     //   8: aload_0
/*     */     //   9: getstatic 256	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_SIGNCERTS_CERTS	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   12: invokevirtual 259	es/mityc/javasign/trust/MyPropsTruster:getTrustedCAs	(Les/mityc/javasign/trust/PropsTruster$TrusterType;)Ljava/util/Vector;
/*     */     //   15: invokevirtual 263	java/util/Vector:iterator	()Ljava/util/Iterator;
/*     */     //   18: astore_2
/*     */     //   19: goto +29 -> 48
/*     */     //   22: aload_1
/*     */     //   23: new 69	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct
/*     */     //   26: dup
/*     */     //   27: aload_0
/*     */     //   28: aload_2
/*     */     //   29: invokeinterface 269 1 0
/*     */     //   34: checkcast 76	java/security/cert/X509Certificate
/*     */     //   37: getstatic 256	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_SIGNCERTS_CERTS	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   40: iconst_1
/*     */     //   41: invokespecial 274	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct:<init>	(Les/mityc/javasign/trust/MyPropsTruster;Ljava/security/cert/X509Certificate;Les/mityc/javasign/trust/PropsTruster$TrusterType;Z)V
/*     */     //   44: invokevirtual 277	java/util/ArrayList:add	(Ljava/lang/Object;)Z
/*     */     //   47: pop
/*     */     //   48: aload_2
/*     */     //   49: invokeinterface 280 1 0
/*     */     //   54: ifne -32 -> 22
/*     */     //   57: aload_0
/*     */     //   58: getstatic 283	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_SIGNCERTS_ISSUER	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   61: invokevirtual 259	es/mityc/javasign/trust/MyPropsTruster:getTrustedCAs	(Les/mityc/javasign/trust/PropsTruster$TrusterType;)Ljava/util/Vector;
/*     */     //   64: invokevirtual 263	java/util/Vector:iterator	()Ljava/util/Iterator;
/*     */     //   67: astore_2
/*     */     //   68: goto +29 -> 97
/*     */     //   71: aload_1
/*     */     //   72: new 69	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct
/*     */     //   75: dup
/*     */     //   76: aload_0
/*     */     //   77: aload_2
/*     */     //   78: invokeinterface 269 1 0
/*     */     //   83: checkcast 76	java/security/cert/X509Certificate
/*     */     //   86: getstatic 283	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_SIGNCERTS_ISSUER	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   89: iconst_1
/*     */     //   90: invokespecial 274	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct:<init>	(Les/mityc/javasign/trust/MyPropsTruster;Ljava/security/cert/X509Certificate;Les/mityc/javasign/trust/PropsTruster$TrusterType;Z)V
/*     */     //   93: invokevirtual 277	java/util/ArrayList:add	(Ljava/lang/Object;)Z
/*     */     //   96: pop
/*     */     //   97: aload_2
/*     */     //   98: invokeinterface 280 1 0
/*     */     //   103: ifne -32 -> 71
/*     */     //   106: aload_0
/*     */     //   107: getstatic 286	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_OCSP_CERTS	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   110: invokevirtual 259	es/mityc/javasign/trust/MyPropsTruster:getTrustedCAs	(Les/mityc/javasign/trust/PropsTruster$TrusterType;)Ljava/util/Vector;
/*     */     //   113: invokevirtual 263	java/util/Vector:iterator	()Ljava/util/Iterator;
/*     */     //   116: astore_2
/*     */     //   117: goto +29 -> 146
/*     */     //   120: aload_1
/*     */     //   121: new 69	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct
/*     */     //   124: dup
/*     */     //   125: aload_0
/*     */     //   126: aload_2
/*     */     //   127: invokeinterface 269 1 0
/*     */     //   132: checkcast 76	java/security/cert/X509Certificate
/*     */     //   135: getstatic 286	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_OCSP_CERTS	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   138: iconst_1
/*     */     //   139: invokespecial 274	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct:<init>	(Les/mityc/javasign/trust/MyPropsTruster;Ljava/security/cert/X509Certificate;Les/mityc/javasign/trust/PropsTruster$TrusterType;Z)V
/*     */     //   142: invokevirtual 277	java/util/ArrayList:add	(Ljava/lang/Object;)Z
/*     */     //   145: pop
/*     */     //   146: aload_2
/*     */     //   147: invokeinterface 280 1 0
/*     */     //   152: ifne -32 -> 120
/*     */     //   155: aload_0
/*     */     //   156: getstatic 289	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_OCSP_ISSUER	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   159: invokevirtual 259	es/mityc/javasign/trust/MyPropsTruster:getTrustedCAs	(Les/mityc/javasign/trust/PropsTruster$TrusterType;)Ljava/util/Vector;
/*     */     //   162: invokevirtual 263	java/util/Vector:iterator	()Ljava/util/Iterator;
/*     */     //   165: astore_2
/*     */     //   166: goto +29 -> 195
/*     */     //   169: aload_1
/*     */     //   170: new 69	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct
/*     */     //   173: dup
/*     */     //   174: aload_0
/*     */     //   175: aload_2
/*     */     //   176: invokeinterface 269 1 0
/*     */     //   181: checkcast 76	java/security/cert/X509Certificate
/*     */     //   184: getstatic 289	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_OCSP_ISSUER	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   187: iconst_1
/*     */     //   188: invokespecial 274	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct:<init>	(Les/mityc/javasign/trust/MyPropsTruster;Ljava/security/cert/X509Certificate;Les/mityc/javasign/trust/PropsTruster$TrusterType;Z)V
/*     */     //   191: invokevirtual 277	java/util/ArrayList:add	(Ljava/lang/Object;)Z
/*     */     //   194: pop
/*     */     //   195: aload_2
/*     */     //   196: invokeinterface 280 1 0
/*     */     //   201: ifne -32 -> 169
/*     */     //   204: aload_0
/*     */     //   205: getstatic 292	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_TSA_CERTS	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   208: invokevirtual 259	es/mityc/javasign/trust/MyPropsTruster:getTrustedCAs	(Les/mityc/javasign/trust/PropsTruster$TrusterType;)Ljava/util/Vector;
/*     */     //   211: invokevirtual 263	java/util/Vector:iterator	()Ljava/util/Iterator;
/*     */     //   214: astore_2
/*     */     //   215: goto +29 -> 244
/*     */     //   218: aload_1
/*     */     //   219: new 69	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct
/*     */     //   222: dup
/*     */     //   223: aload_0
/*     */     //   224: aload_2
/*     */     //   225: invokeinterface 269 1 0
/*     */     //   230: checkcast 76	java/security/cert/X509Certificate
/*     */     //   233: getstatic 292	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_TSA_CERTS	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   236: iconst_1
/*     */     //   237: invokespecial 274	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct:<init>	(Les/mityc/javasign/trust/MyPropsTruster;Ljava/security/cert/X509Certificate;Les/mityc/javasign/trust/PropsTruster$TrusterType;Z)V
/*     */     //   240: invokevirtual 277	java/util/ArrayList:add	(Ljava/lang/Object;)Z
/*     */     //   243: pop
/*     */     //   244: aload_2
/*     */     //   245: invokeinterface 280 1 0
/*     */     //   250: ifne -32 -> 218
/*     */     //   253: aload_0
/*     */     //   254: getstatic 295	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_TSA_ISSUER	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   257: invokevirtual 259	es/mityc/javasign/trust/MyPropsTruster:getTrustedCAs	(Les/mityc/javasign/trust/PropsTruster$TrusterType;)Ljava/util/Vector;
/*     */     //   260: invokevirtual 263	java/util/Vector:iterator	()Ljava/util/Iterator;
/*     */     //   263: astore_2
/*     */     //   264: goto +29 -> 293
/*     */     //   267: aload_1
/*     */     //   268: new 69	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct
/*     */     //   271: dup
/*     */     //   272: aload_0
/*     */     //   273: aload_2
/*     */     //   274: invokeinterface 269 1 0
/*     */     //   279: checkcast 76	java/security/cert/X509Certificate
/*     */     //   282: getstatic 295	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_TSA_ISSUER	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   285: iconst_1
/*     */     //   286: invokespecial 274	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct:<init>	(Les/mityc/javasign/trust/MyPropsTruster;Ljava/security/cert/X509Certificate;Les/mityc/javasign/trust/PropsTruster$TrusterType;Z)V
/*     */     //   289: invokevirtual 277	java/util/ArrayList:add	(Ljava/lang/Object;)Z
/*     */     //   292: pop
/*     */     //   293: aload_2
/*     */     //   294: invokeinterface 280 1 0
/*     */     //   299: ifne -32 -> 267
/*     */     //   302: aload_0
/*     */     //   303: getstatic 298	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_CRL_ISSUER	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   306: invokevirtual 259	es/mityc/javasign/trust/MyPropsTruster:getTrustedCAs	(Les/mityc/javasign/trust/PropsTruster$TrusterType;)Ljava/util/Vector;
/*     */     //   309: invokevirtual 263	java/util/Vector:iterator	()Ljava/util/Iterator;
/*     */     //   312: astore_2
/*     */     //   313: goto +29 -> 342
/*     */     //   316: aload_1
/*     */     //   317: new 69	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct
/*     */     //   320: dup
/*     */     //   321: aload_0
/*     */     //   322: aload_2
/*     */     //   323: invokeinterface 269 1 0
/*     */     //   328: checkcast 76	java/security/cert/X509Certificate
/*     */     //   331: getstatic 298	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_CRL_ISSUER	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   334: iconst_1
/*     */     //   335: invokespecial 274	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct:<init>	(Les/mityc/javasign/trust/MyPropsTruster;Ljava/security/cert/X509Certificate;Les/mityc/javasign/trust/PropsTruster$TrusterType;Z)V
/*     */     //   338: invokevirtual 277	java/util/ArrayList:add	(Ljava/lang/Object;)Z
/*     */     //   341: pop
/*     */     //   342: aload_2
/*     */     //   343: invokeinterface 280 1 0
/*     */     //   348: ifne -32 -> 316
/*     */     //   351: aload_0
/*     */     //   352: getfield 46	es/mityc/javasign/trust/MyPropsTruster:externalProps	Ljava/util/Properties;
/*     */     //   355: ifnull +13 -> 368
/*     */     //   358: aload_0
/*     */     //   359: getfield 46	es/mityc/javasign/trust/MyPropsTruster:externalProps	Ljava/util/Properties;
/*     */     //   362: invokevirtual 301	java/util/Properties:size	()I
/*     */     //   365: ifgt +5 -> 370
/*     */     //   368: aload_1
/*     */     //   369: areturn
/*     */     //   370: aload_0
/*     */     //   371: getfield 46	es/mityc/javasign/trust/MyPropsTruster:externalProps	Ljava/util/Properties;
/*     */     //   374: invokevirtual 199	java/util/Properties:keys	()Ljava/util/Enumeration;
/*     */     //   377: astore_3
/*     */     //   378: aconst_null
/*     */     //   379: astore 4
/*     */     //   381: aconst_null
/*     */     //   382: astore 5
/*     */     //   384: ldc_w 302
/*     */     //   387: invokestatic 304	java/security/cert/CertificateFactory:getInstance	(Ljava/lang/String;)Ljava/security/cert/CertificateFactory;
/*     */     //   390: astore 5
/*     */     //   392: goto +18 -> 410
/*     */     //   395: astore 6
/*     */     //   397: new 57	es/mityc/javasign/trust/TrustException
/*     */     //   400: dup
/*     */     //   401: ldc_w 309
/*     */     //   404: aload 6
/*     */     //   406: invokespecial 311	es/mityc/javasign/trust/TrustException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   409: athrow
/*     */     //   410: aconst_null
/*     */     //   411: astore 6
/*     */     //   413: aconst_null
/*     */     //   414: astore 7
/*     */     //   416: goto +525 -> 941
/*     */     //   419: aload_3
/*     */     //   420: invokeinterface 203 1 0
/*     */     //   425: checkcast 97	java/lang/String
/*     */     //   428: astore 4
/*     */     //   430: new 69	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct
/*     */     //   433: dup
/*     */     //   434: aload_0
/*     */     //   435: invokespecial 314	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct:<init>	(Les/mityc/javasign/trust/MyPropsTruster;)V
/*     */     //   438: astore 7
/*     */     //   440: aload 7
/*     */     //   442: iconst_0
/*     */     //   443: invokevirtual 317	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct:setInternal	(Z)V
/*     */     //   446: new 321	java/io/FileInputStream
/*     */     //   449: dup
/*     */     //   450: new 106	java/io/File
/*     */     //   453: dup
/*     */     //   454: aload_0
/*     */     //   455: getfield 46	es/mityc/javasign/trust/MyPropsTruster:externalProps	Ljava/util/Properties;
/*     */     //   458: aload 4
/*     */     //   460: invokevirtual 323	java/util/Properties:getProperty	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   463: invokespecial 120	java/io/File:<init>	(Ljava/lang/String;)V
/*     */     //   466: invokespecial 327	java/io/FileInputStream:<init>	(Ljava/io/File;)V
/*     */     //   469: astore 6
/*     */     //   471: aload 5
/*     */     //   473: aload 6
/*     */     //   475: invokevirtual 330	java/security/cert/CertificateFactory:generateCertificate	(Ljava/io/InputStream;)Ljava/security/cert/Certificate;
/*     */     //   478: checkcast 76	java/security/cert/X509Certificate
/*     */     //   481: astore 8
/*     */     //   483: aload_0
/*     */     //   484: aload 4
/*     */     //   486: aload 8
/*     */     //   488: invokespecial 334	es/mityc/javasign/trust/MyPropsTruster:checkCert	(Ljava/lang/String;Ljava/security/cert/X509Certificate;)Z
/*     */     //   491: ifne +29 -> 520
/*     */     //   494: new 57	es/mityc/javasign/trust/TrustException
/*     */     //   497: dup
/*     */     //   498: new 94	java/lang/StringBuilder
/*     */     //   501: dup
/*     */     //   502: ldc_w 338
/*     */     //   505: invokespecial 102	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   508: aload 4
/*     */     //   510: invokevirtual 110	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   513: invokevirtual 116	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   516: invokespecial 198	es/mityc/javasign/trust/TrustException:<init>	(Ljava/lang/String;)V
/*     */     //   519: athrow
/*     */     //   520: aload 7
/*     */     //   522: aload 8
/*     */     //   524: invokevirtual 340	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct:setCert	(Ljava/security/cert/X509Certificate;)V
/*     */     //   527: aload 4
/*     */     //   529: getstatic 256	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_SIGNCERTS_CERTS	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   532: invokevirtual 144	es/mityc/javasign/trust/PropsTruster$TrusterType:toString	()Ljava/lang/String;
/*     */     //   535: invokevirtual 209	java/lang/String:contains	(Ljava/lang/CharSequence;)Z
/*     */     //   538: ifeq +14 -> 552
/*     */     //   541: aload 7
/*     */     //   543: getstatic 256	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_SIGNCERTS_CERTS	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   546: invokevirtual 344	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct:setType	(Les/mityc/javasign/trust/PropsTruster$TrusterType;)V
/*     */     //   549: goto +161 -> 710
/*     */     //   552: aload 4
/*     */     //   554: getstatic 283	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_SIGNCERTS_ISSUER	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   557: invokevirtual 144	es/mityc/javasign/trust/PropsTruster$TrusterType:toString	()Ljava/lang/String;
/*     */     //   560: invokevirtual 209	java/lang/String:contains	(Ljava/lang/CharSequence;)Z
/*     */     //   563: ifeq +14 -> 577
/*     */     //   566: aload 7
/*     */     //   568: getstatic 283	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_SIGNCERTS_ISSUER	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   571: invokevirtual 344	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct:setType	(Les/mityc/javasign/trust/PropsTruster$TrusterType;)V
/*     */     //   574: goto +136 -> 710
/*     */     //   577: aload 4
/*     */     //   579: getstatic 286	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_OCSP_CERTS	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   582: invokevirtual 144	es/mityc/javasign/trust/PropsTruster$TrusterType:toString	()Ljava/lang/String;
/*     */     //   585: invokevirtual 209	java/lang/String:contains	(Ljava/lang/CharSequence;)Z
/*     */     //   588: ifeq +14 -> 602
/*     */     //   591: aload 7
/*     */     //   593: getstatic 286	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_OCSP_CERTS	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   596: invokevirtual 344	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct:setType	(Les/mityc/javasign/trust/PropsTruster$TrusterType;)V
/*     */     //   599: goto +111 -> 710
/*     */     //   602: aload 4
/*     */     //   604: getstatic 289	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_OCSP_ISSUER	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   607: invokevirtual 144	es/mityc/javasign/trust/PropsTruster$TrusterType:toString	()Ljava/lang/String;
/*     */     //   610: invokevirtual 209	java/lang/String:contains	(Ljava/lang/CharSequence;)Z
/*     */     //   613: ifeq +14 -> 627
/*     */     //   616: aload 7
/*     */     //   618: getstatic 289	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_OCSP_ISSUER	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   621: invokevirtual 344	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct:setType	(Les/mityc/javasign/trust/PropsTruster$TrusterType;)V
/*     */     //   624: goto +86 -> 710
/*     */     //   627: aload 4
/*     */     //   629: getstatic 298	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_CRL_ISSUER	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   632: invokevirtual 144	es/mityc/javasign/trust/PropsTruster$TrusterType:toString	()Ljava/lang/String;
/*     */     //   635: invokevirtual 209	java/lang/String:contains	(Ljava/lang/CharSequence;)Z
/*     */     //   638: ifeq +14 -> 652
/*     */     //   641: aload 7
/*     */     //   643: getstatic 298	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_CRL_ISSUER	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   646: invokevirtual 344	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct:setType	(Les/mityc/javasign/trust/PropsTruster$TrusterType;)V
/*     */     //   649: goto +61 -> 710
/*     */     //   652: aload 4
/*     */     //   654: getstatic 292	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_TSA_CERTS	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   657: invokevirtual 144	es/mityc/javasign/trust/PropsTruster$TrusterType:toString	()Ljava/lang/String;
/*     */     //   660: invokevirtual 209	java/lang/String:contains	(Ljava/lang/CharSequence;)Z
/*     */     //   663: ifeq +14 -> 677
/*     */     //   666: aload 7
/*     */     //   668: getstatic 292	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_TSA_CERTS	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   671: invokevirtual 344	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct:setType	(Les/mityc/javasign/trust/PropsTruster$TrusterType;)V
/*     */     //   674: goto +36 -> 710
/*     */     //   677: aload 4
/*     */     //   679: getstatic 295	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_TSA_ISSUER	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   682: invokevirtual 144	es/mityc/javasign/trust/PropsTruster$TrusterType:toString	()Ljava/lang/String;
/*     */     //   685: invokevirtual 209	java/lang/String:contains	(Ljava/lang/CharSequence;)Z
/*     */     //   688: ifeq +14 -> 702
/*     */     //   691: aload 7
/*     */     //   693: getstatic 295	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_TSA_ISSUER	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   696: invokevirtual 344	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct:setType	(Les/mityc/javasign/trust/PropsTruster$TrusterType;)V
/*     */     //   699: goto +11 -> 710
/*     */     //   702: aload 7
/*     */     //   704: getstatic 256	es/mityc/javasign/trust/PropsTruster$TrusterType:TRUSTER_SIGNCERTS_CERTS	Les/mityc/javasign/trust/PropsTruster$TrusterType;
/*     */     //   707: invokevirtual 344	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct:setType	(Les/mityc/javasign/trust/PropsTruster$TrusterType;)V
/*     */     //   710: iconst_0
/*     */     //   711: istore 9
/*     */     //   713: iconst_0
/*     */     //   714: istore 10
/*     */     //   716: goto +56 -> 772
/*     */     //   719: aload_1
/*     */     //   720: iload 10
/*     */     //   722: invokevirtual 348	java/util/ArrayList:get	(I)Ljava/lang/Object;
/*     */     //   725: checkcast 69	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct
/*     */     //   728: invokevirtual 71	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct:getCert	()Ljava/security/cert/X509Certificate;
/*     */     //   731: aload 7
/*     */     //   733: invokevirtual 71	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct:getCert	()Ljava/security/cert/X509Certificate;
/*     */     //   736: invokevirtual 75	java/security/cert/X509Certificate:equals	(Ljava/lang/Object;)Z
/*     */     //   739: ifeq +30 -> 769
/*     */     //   742: aload 7
/*     */     //   744: iconst_0
/*     */     //   745: invokevirtual 317	es/mityc/javasign/trust/MyPropsTruster$TrustCertStruct:setInternal	(Z)V
/*     */     //   748: aload_1
/*     */     //   749: iload 10
/*     */     //   751: invokevirtual 349	java/util/ArrayList:remove	(I)Ljava/lang/Object;
/*     */     //   754: pop
/*     */     //   755: aload_1
/*     */     //   756: iload 10
/*     */     //   758: aload 7
/*     */     //   760: invokevirtual 351	java/util/ArrayList:add	(ILjava/lang/Object;)V
/*     */     //   763: iconst_1
/*     */     //   764: istore 9
/*     */     //   766: goto +15 -> 781
/*     */     //   769: iinc 10 1
/*     */     //   772: iload 10
/*     */     //   774: aload_1
/*     */     //   775: invokevirtual 354	java/util/ArrayList:size	()I
/*     */     //   778: if_icmplt -59 -> 719
/*     */     //   781: iload 9
/*     */     //   783: ifne +143 -> 926
/*     */     //   786: aload_1
/*     */     //   787: aload 7
/*     */     //   789: invokevirtual 277	java/util/ArrayList:add	(Ljava/lang/Object;)Z
/*     */     //   792: pop
/*     */     //   793: goto +133 -> 926
/*     */     //   796: astore 8
/*     */     //   798: getstatic 23	es/mityc/javasign/trust/MyPropsTruster:log	Lorg/apache/commons/logging/Log;
/*     */     //   801: new 94	java/lang/StringBuilder
/*     */     //   804: dup
/*     */     //   805: ldc_w 355
/*     */     //   808: invokespecial 102	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   811: aload_0
/*     */     //   812: getfield 46	es/mityc/javasign/trust/MyPropsTruster:externalProps	Ljava/util/Properties;
/*     */     //   815: aload 4
/*     */     //   817: invokevirtual 323	java/util/Properties:getProperty	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   820: invokevirtual 110	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   823: invokevirtual 116	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   826: aload 8
/*     */     //   828: invokeinterface 357 3 0
/*     */     //   833: aload 6
/*     */     //   835: ifnull +106 -> 941
/*     */     //   838: aload 6
/*     */     //   840: invokevirtual 360	java/io/FileInputStream:close	()V
/*     */     //   843: goto +98 -> 941
/*     */     //   846: astore 12
/*     */     //   848: goto +93 -> 941
/*     */     //   851: astore 8
/*     */     //   853: getstatic 23	es/mityc/javasign/trust/MyPropsTruster:log	Lorg/apache/commons/logging/Log;
/*     */     //   856: new 94	java/lang/StringBuilder
/*     */     //   859: dup
/*     */     //   860: ldc_w 361
/*     */     //   863: invokespecial 102	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   866: aload_0
/*     */     //   867: getfield 46	es/mityc/javasign/trust/MyPropsTruster:externalProps	Ljava/util/Properties;
/*     */     //   870: aload 4
/*     */     //   872: invokevirtual 323	java/util/Properties:getProperty	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   875: invokevirtual 110	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   878: invokevirtual 116	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   881: aload 8
/*     */     //   883: invokeinterface 357 3 0
/*     */     //   888: aload 6
/*     */     //   890: ifnull +51 -> 941
/*     */     //   893: aload 6
/*     */     //   895: invokevirtual 360	java/io/FileInputStream:close	()V
/*     */     //   898: goto +43 -> 941
/*     */     //   901: astore 12
/*     */     //   903: goto +38 -> 941
/*     */     //   906: astore 11
/*     */     //   908: aload 6
/*     */     //   910: ifnull +13 -> 923
/*     */     //   913: aload 6
/*     */     //   915: invokevirtual 360	java/io/FileInputStream:close	()V
/*     */     //   918: goto +5 -> 923
/*     */     //   921: astore 12
/*     */     //   923: aload 11
/*     */     //   925: athrow
/*     */     //   926: aload 6
/*     */     //   928: ifnull +13 -> 941
/*     */     //   931: aload 6
/*     */     //   933: invokevirtual 360	java/io/FileInputStream:close	()V
/*     */     //   936: goto +5 -> 941
/*     */     //   939: astore 12
/*     */     //   941: aload_3
/*     */     //   942: invokeinterface 213 1 0
/*     */     //   947: ifne -528 -> 419
/*     */     //   950: aload_1
/*     */     //   951: areturn
/*     */     // Line number table:
/*     */     //   Java source line #246	-> byte code offset #0
/*     */     //   Java source line #249	-> byte code offset #8
/*     */     //   Java source line #250	-> byte code offset #19
/*     */     //   Java source line #251	-> byte code offset #22
/*     */     //   Java source line #250	-> byte code offset #48
/*     */     //   Java source line #253	-> byte code offset #57
/*     */     //   Java source line #254	-> byte code offset #68
/*     */     //   Java source line #255	-> byte code offset #71
/*     */     //   Java source line #254	-> byte code offset #97
/*     */     //   Java source line #257	-> byte code offset #106
/*     */     //   Java source line #258	-> byte code offset #117
/*     */     //   Java source line #259	-> byte code offset #120
/*     */     //   Java source line #258	-> byte code offset #146
/*     */     //   Java source line #261	-> byte code offset #155
/*     */     //   Java source line #262	-> byte code offset #166
/*     */     //   Java source line #263	-> byte code offset #169
/*     */     //   Java source line #262	-> byte code offset #195
/*     */     //   Java source line #265	-> byte code offset #204
/*     */     //   Java source line #266	-> byte code offset #215
/*     */     //   Java source line #267	-> byte code offset #218
/*     */     //   Java source line #266	-> byte code offset #244
/*     */     //   Java source line #269	-> byte code offset #253
/*     */     //   Java source line #270	-> byte code offset #264
/*     */     //   Java source line #271	-> byte code offset #267
/*     */     //   Java source line #270	-> byte code offset #293
/*     */     //   Java source line #273	-> byte code offset #302
/*     */     //   Java source line #274	-> byte code offset #313
/*     */     //   Java source line #275	-> byte code offset #316
/*     */     //   Java source line #274	-> byte code offset #342
/*     */     //   Java source line #279	-> byte code offset #351
/*     */     //   Java source line #280	-> byte code offset #368
/*     */     //   Java source line #284	-> byte code offset #370
/*     */     //   Java source line #285	-> byte code offset #378
/*     */     //   Java source line #286	-> byte code offset #381
/*     */     //   Java source line #288	-> byte code offset #384
/*     */     //   Java source line #289	-> byte code offset #392
/*     */     //   Java source line #290	-> byte code offset #397
/*     */     //   Java source line #292	-> byte code offset #410
/*     */     //   Java source line #293	-> byte code offset #413
/*     */     //   Java source line #294	-> byte code offset #416
/*     */     //   Java source line #295	-> byte code offset #419
/*     */     //   Java source line #297	-> byte code offset #430
/*     */     //   Java source line #298	-> byte code offset #440
/*     */     //   Java source line #299	-> byte code offset #446
/*     */     //   Java source line #300	-> byte code offset #471
/*     */     //   Java source line #301	-> byte code offset #483
/*     */     //   Java source line #302	-> byte code offset #494
/*     */     //   Java source line #304	-> byte code offset #520
/*     */     //   Java source line #305	-> byte code offset #527
/*     */     //   Java source line #306	-> byte code offset #541
/*     */     //   Java source line #307	-> byte code offset #549
/*     */     //   Java source line #308	-> byte code offset #566
/*     */     //   Java source line #309	-> byte code offset #574
/*     */     //   Java source line #310	-> byte code offset #591
/*     */     //   Java source line #311	-> byte code offset #599
/*     */     //   Java source line #312	-> byte code offset #616
/*     */     //   Java source line #313	-> byte code offset #624
/*     */     //   Java source line #314	-> byte code offset #641
/*     */     //   Java source line #315	-> byte code offset #649
/*     */     //   Java source line #316	-> byte code offset #666
/*     */     //   Java source line #317	-> byte code offset #674
/*     */     //   Java source line #318	-> byte code offset #691
/*     */     //   Java source line #319	-> byte code offset #699
/*     */     //   Java source line #320	-> byte code offset #702
/*     */     //   Java source line #322	-> byte code offset #710
/*     */     //   Java source line #323	-> byte code offset #713
/*     */     //   Java source line #324	-> byte code offset #719
/*     */     //   Java source line #325	-> byte code offset #742
/*     */     //   Java source line #326	-> byte code offset #748
/*     */     //   Java source line #327	-> byte code offset #755
/*     */     //   Java source line #328	-> byte code offset #763
/*     */     //   Java source line #329	-> byte code offset #766
/*     */     //   Java source line #323	-> byte code offset #769
/*     */     //   Java source line #332	-> byte code offset #781
/*     */     //   Java source line #333	-> byte code offset #786
/*     */     //   Java source line #335	-> byte code offset #793
/*     */     //   Java source line #336	-> byte code offset #798
/*     */     //   Java source line #340	-> byte code offset #833
/*     */     //   Java source line #342	-> byte code offset #838
/*     */     //   Java source line #343	-> byte code offset #843
/*     */     //   Java source line #337	-> byte code offset #851
/*     */     //   Java source line #338	-> byte code offset #853
/*     */     //   Java source line #340	-> byte code offset #888
/*     */     //   Java source line #342	-> byte code offset #893
/*     */     //   Java source line #343	-> byte code offset #898
/*     */     //   Java source line #339	-> byte code offset #906
/*     */     //   Java source line #340	-> byte code offset #908
/*     */     //   Java source line #342	-> byte code offset #913
/*     */     //   Java source line #343	-> byte code offset #918
/*     */     //   Java source line #345	-> byte code offset #923
/*     */     //   Java source line #340	-> byte code offset #926
/*     */     //   Java source line #342	-> byte code offset #931
/*     */     //   Java source line #343	-> byte code offset #936
/*     */     //   Java source line #294	-> byte code offset #941
/*     */     //   Java source line #348	-> byte code offset #950
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	952	0	this	MyPropsTruster
/*     */     //   7	944	1	cas	java.util.ArrayList<TrustCertStruct>
/*     */     //   18	325	2	internalCAs	java.util.Iterator<X509Certificate>
/*     */     //   377	565	3	keys	Enumeration<?>
/*     */     //   379	492	4	key	String
/*     */     //   382	90	5	cf	java.security.cert.CertificateFactory
/*     */     //   395	10	6	e	java.security.cert.CertificateException
/*     */     //   411	521	6	fis	java.io.FileInputStream
/*     */     //   414	374	7	tc	TrustCertStruct
/*     */     //   481	42	8	cert	X509Certificate
/*     */     //   796	31	8	e	java.security.cert.CertificateException
/*     */     //   851	31	8	e	java.io.FileNotFoundException
/*     */     //   711	71	9	alreadyInList	boolean
/*     */     //   714	59	10	i	int
/*     */     //   906	18	11	localObject	Object
/*     */     //   846	1	12	localIOException	java.io.IOException
/*     */     //   901	1	12	localIOException1	java.io.IOException
/*     */     //   921	1	12	localIOException2	java.io.IOException
/*     */     //   939	1	12	localIOException3	java.io.IOException
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   384	392	395	java/security/cert/CertificateException
/*     */     //   430	793	796	java/security/cert/CertificateException
/*     */     //   838	843	846	java/io/IOException
/*     */     //   430	793	851	java/io/FileNotFoundException
/*     */     //   893	898	901	java/io/IOException
/*     */     //   430	833	906	finally
/*     */     //   851	888	906	finally
/*     */     //   913	918	921	java/io/IOException
/*     */     //   931	936	939	java/io/IOException
/*     */   }
/*     */   
/*     */   public Properties getActualProperties()
/*     */   {
/* 356 */     return this.externalProps;
/*     */   }
/*     */   
/*     */   public class TrustCertStruct
/*     */   {
/* 361 */     private X509Certificate cert = null;
/*     */     
/* 363 */     private PropsTruster.TrusterType type = null;
/*     */     
/* 365 */     private boolean isInternal = false;
/*     */     
/*     */     public TrustCertStruct() {
/* 368 */       new TrustCertStruct(MyPropsTruster.this, null, null, false);
/*     */     }
/*     */     
/*     */     public TrustCertStruct(X509Certificate cert, PropsTruster.TrusterType type, boolean isInternal) {
/* 372 */       this.cert = cert;
/* 373 */       this.type = type;
/* 374 */       this.isInternal = isInternal;
/*     */     }
/*     */     
/*     */     public X509Certificate getCert() {
/* 378 */       return this.cert;
/*     */     }
/*     */     
/* 381 */     public synchronized void setCert(X509Certificate cert) { this.cert = cert; }
/*     */     
/*     */     public PropsTruster.TrusterType getType() {
/* 384 */       return this.type;
/*     */     }
/*     */     
/* 387 */     public synchronized void setType(PropsTruster.TrusterType type) { this.type = type; }
/*     */     
/*     */     public boolean isInternal() {
/* 390 */       return this.isInternal;
/*     */     }
/*     */     
/* 393 */     public void setInternal(boolean isInternal) { this.isInternal = isInternal; }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean checkCert(String key, X509Certificate cert)
/*     */     throws TrustException
/*     */   {
/*     */     try
/*     */     {
/* 407 */       String fileName = Utils.getMD5(cert);
/* 408 */       return fileName == null ? false : key.contains(fileName);
/*     */     } catch (Exception e) {
/* 410 */       throw new TrustException(e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibTrust-1.1.7.jar!\es\mityc\javasign\trust\MyPropsTruster.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */