/*      */ package es.mityc.javasign.trust;
/*      */ 
/*      */ import es.mityc.javasign.i18n.I18nFactory;
/*      */ import es.mityc.javasign.i18n.II18nManager;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.security.AccessController;
/*      */ import java.security.InvalidKeyException;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.security.NoSuchProviderException;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.security.SignatureException;
/*      */ import java.security.cert.CRLException;
/*      */ import java.security.cert.CertPath;
/*      */ import java.security.cert.CertStore;
/*      */ import java.security.cert.CertStoreException;
/*      */ import java.security.cert.Certificate;
/*      */ import java.security.cert.CertificateException;
/*      */ import java.security.cert.CertificateExpiredException;
/*      */ import java.security.cert.CertificateFactory;
/*      */ import java.security.cert.CertificateNotYetValidException;
/*      */ import java.security.cert.X509CRL;
/*      */ import java.security.cert.X509CertSelector;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Properties;
/*      */ import java.util.Vector;
/*      */ import javax.security.auth.x500.X500Principal;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.bouncycastle.asn1.ASN1OctetString;
/*      */ import org.bouncycastle.asn1.ASN1TaggedObject;
/*      */ import org.bouncycastle.asn1.ocsp.ResponderID;
/*      */ import org.bouncycastle.asn1.x509.X509Name;
/*      */ import org.bouncycastle.cms.CMSException;
/*      */ import org.bouncycastle.cms.SignerId;
/*      */ import org.bouncycastle.jce.X509Principal;
/*      */ import org.bouncycastle.ocsp.BasicOCSPResp;
/*      */ import org.bouncycastle.ocsp.OCSPException;
/*      */ import org.bouncycastle.ocsp.OCSPResp;
/*      */ import org.bouncycastle.ocsp.RespID;
/*      */ import org.bouncycastle.tsp.TSPException;
/*      */ import org.bouncycastle.tsp.TSPValidationException;
/*      */ import org.bouncycastle.tsp.TimeStampToken;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PropsTruster
/*      */   extends TrustAdapter
/*      */ {
/*  103 */   private static final Log LOG = LogFactory.getLog(PropsTruster.class);
/*      */   
/*  105 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibTrust");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final String CONF_DEFAULT = "trust/myTruster.properties";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static enum TrusterType
/*      */   {
/*  125 */     TRUSTER_SIGNCERTS_ISSUER(
/*  126 */       "signcerts.issuers"), 
/*  127 */     TRUSTER_SIGNCERTS_CERTS(
/*  128 */       "signcerts.certs"), 
/*  129 */     TRUSTER_OCSP_ISSUER(
/*  130 */       "ocsp.issuers"), 
/*  131 */     TRUSTER_OCSP_CERTS(
/*  132 */       "ocsp.certs"), 
/*  133 */     TRUSTER_CRL_ISSUER(
/*  134 */       "crl.issuers"), 
/*  135 */     TRUSTER_TSA_ISSUER(
/*  136 */       "tsa.issuers"), 
/*  137 */     TRUSTER_TSA_CERTS(
/*  138 */       "tsa.certs");
/*      */     
/*      */ 
/*      */ 
/*      */     private String id;
/*      */     
/*      */ 
/*      */ 
/*      */     private TrusterType(String key)
/*      */     {
/*  148 */       this.id = key;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public String toString()
/*      */     {
/*  158 */       return this.id;
/*      */     }
/*      */   }
/*      */   
/*  162 */   protected Properties externalProps = new Properties();
/*      */   
/*      */ 
/*      */   protected static TrustAdapter instance;
/*      */   
/*      */ 
/*      */   private CertStore issuersCerts;
/*      */   
/*      */ 
/*      */   private CertStore certsCerts;
/*      */   
/*      */ 
/*      */   private CertStore issuersOCSP;
/*      */   
/*      */   private CertStore certsOCSP;
/*      */   
/*      */   private CertStore issuersCRL;
/*      */   
/*      */   private CertStore issuersTSA;
/*      */   
/*      */   private CertStore certsTSA;
/*      */   
/*      */ 
/*      */   protected PropsTruster(String fileconf)
/*      */   {
/*  187 */     loadConf(fileconf, new Properties());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PropsTruster(String fileconf, InputStream extFileConf)
/*      */   {
/*  196 */     loadConf(fileconf, extFileConf);
/*      */   }
/*      */   
/*      */   protected synchronized void loadConf(String fileconf, InputStream extConf) {
/*  200 */     Properties extProps = null;
/*      */     
/*  202 */     if (extConf != null) {
/*      */       try {
/*  204 */         extProps = new Properties();
/*  205 */         extProps.load(extConf);
/*      */       }
/*      */       catch (IOException ex) {
/*  208 */         LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.1", new Object[] { extConf }));
/*  209 */         if (!LOG.isDebugEnabled()) break label100; }
/*  210 */       LOG.debug(ex);
/*      */     }
/*      */     else {
/*  213 */       LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.1", new Object[] { extConf })); }
/*      */     label100:
/*  215 */     loadConf(fileconf, extProps);
/*      */   }
/*      */   
/*      */   protected synchronized void loadConf(String fileconf, Properties extProperties)
/*      */   {
/*  220 */     this.externalProps = extProperties;
/*      */     
/*  222 */     Properties internalProps = null;
/*      */     try {
/*  224 */       ClassLoader cl = getClassLoader();
/*  225 */       InputStream is = cl.getResourceAsStream(fileconf);
/*  226 */       if (is != null) {
/*  227 */         internalProps = new Properties();
/*  228 */         internalProps.load(is);
/*      */       } else {
/*  230 */         LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.1", new Object[] { fileconf }));
/*      */       }
/*      */     } catch (IOException ex) {
/*  233 */       LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.1", new Object[] { fileconf }));
/*      */     }
/*      */     
/*  236 */     if (internalProps != null) {
/*      */       try {
/*  238 */         CertificateFactory cf = CertificateFactory.getInstance("X509");
/*  239 */         this.issuersCerts = loadCerts(cf, internalProps, this.externalProps, TrusterType.TRUSTER_SIGNCERTS_ISSUER);
/*  240 */         this.certsCerts = loadCerts(cf, internalProps, this.externalProps, TrusterType.TRUSTER_SIGNCERTS_CERTS);
/*  241 */         this.issuersOCSP = loadCerts(cf, internalProps, this.externalProps, TrusterType.TRUSTER_OCSP_ISSUER);
/*  242 */         this.certsOCSP = loadCerts(cf, internalProps, this.externalProps, TrusterType.TRUSTER_OCSP_CERTS);
/*  243 */         this.issuersCRL = loadCerts(cf, internalProps, this.externalProps, TrusterType.TRUSTER_CRL_ISSUER);
/*  244 */         this.issuersTSA = loadCerts(cf, internalProps, this.externalProps, TrusterType.TRUSTER_TSA_ISSUER);
/*  245 */         this.certsTSA = loadCerts(cf, internalProps, this.externalProps, TrusterType.TRUSTER_TSA_CERTS);
/*      */       } catch (CertificateException ex) {
/*  247 */         LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.9", new Object[] { ex.getMessage() }));
/*  248 */         if (LOG.isDebugEnabled()) {
/*  249 */           LOG.debug("", ex);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void isTrusted(X509CRL crl)
/*      */     throws TrustException
/*      */   {
/*  268 */     if (this.issuersCRL != null) {
/*  269 */       boolean faked = false;
/*  270 */       X509CertSelector certSelector = new X509CertSelector();
/*  271 */       certSelector.setSubject(crl.getIssuerX500Principal());
/*      */       try
/*      */       {
/*  274 */         it = this.issuersCRL.getCertificates(certSelector).iterator();
/*      */       } catch (CertStoreException ex) { Iterator<? extends Certificate> it;
/*  276 */         LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.21", new Object[] { ex.getMessage() }));
/*  277 */         if (LOG.isDebugEnabled()) {
/*  278 */           LOG.debug("", ex);
/*      */         }
/*  280 */         throw new UnknownTrustException(); }
/*      */       Iterator<? extends Certificate> it;
/*  282 */       while (it.hasNext()) {
/*  283 */         X509Certificate issuer = (X509Certificate)it.next();
/*      */         try {
/*  285 */           crl.verify(issuer.getPublicKey());
/*  286 */           return;
/*      */         } catch (InvalidKeyException ex) {
/*  288 */           LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.2", new Object[] { ex.getMessage() }));
/*  289 */           if (LOG.isDebugEnabled()) {
/*  290 */             LOG.debug("", ex);
/*      */           }
/*  292 */           throw new UnknownTrustException();
/*      */         } catch (CRLException ex) {
/*  294 */           LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.3", new Object[] { ex.getMessage() }));
/*  295 */           if (LOG.isDebugEnabled()) {
/*  296 */             LOG.debug("", ex);
/*      */           }
/*  298 */           throw new UnknownTrustException();
/*      */         } catch (NoSuchAlgorithmException ex) {
/*  300 */           LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.4", new Object[] { ex.getMessage() }));
/*  301 */           if (LOG.isDebugEnabled()) {
/*  302 */             LOG.debug("", ex);
/*      */           }
/*  304 */           throw new UnknownTrustException();
/*      */         } catch (NoSuchProviderException ex) {
/*  306 */           LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.5", new Object[] { ex.getMessage() }));
/*  307 */           if (LOG.isDebugEnabled()) {
/*  308 */             LOG.debug("", ex);
/*      */           }
/*  310 */           throw new UnknownTrustException();
/*      */         } catch (SignatureException ex) {
/*  312 */           faked = true;
/*      */         }
/*      */       }
/*  315 */       if (faked) {
/*  316 */         throw new FakedTrustException();
/*      */       }
/*  318 */       throw new NotTrustedException();
/*      */     }
/*      */     
/*      */ 
/*  322 */     throw new UnknownTrustException();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void isTrusted(OCSPResp ocsp)
/*      */     throws TrustException
/*      */   {
/*  340 */     BasicOCSPResp basicResp = null;
/*      */     try {
/*  342 */       basicResp = (BasicOCSPResp)ocsp.getResponseObject();
/*      */     } catch (OCSPException ex) {
/*  344 */       LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.11", new Object[] { ex.getMessage() }));
/*  345 */       if (LOG.isDebugEnabled()) {
/*  346 */         LOG.debug("", ex);
/*      */       }
/*  348 */       throw new UnknownTrustException();
/*      */     }
/*  350 */     if (this.certsOCSP != null) {
/*  351 */       X509CertSelector certSelector = null;
/*      */       
/*      */ 
/*      */       try
/*      */       {
/*  356 */         certs = basicResp.getCerts("SUN");
/*      */       } catch (NoSuchProviderException ex) { X509Certificate[] certs;
/*  358 */         LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.12", new Object[] { ex.getMessage() }));
/*  359 */         if (LOG.isDebugEnabled()) {
/*  360 */           LOG.debug("", ex);
/*      */         }
/*  362 */         throw new UnknownTrustException();
/*      */       } catch (OCSPException ex) {
/*  364 */         LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.12", new Object[] { ex.getMessage() }));
/*  365 */         if (LOG.isDebugEnabled()) {
/*  366 */           LOG.debug("", ex);
/*      */         }
/*  368 */         throw new UnknownTrustException(); }
/*      */       X509Certificate[] certs;
/*  370 */       if ((certs != null) && (certs.length > 0)) {
/*  371 */         certSelector = new X509CertSelector();
/*  372 */         certSelector.setSubjectPublicKey(certs[0].getPublicKey());
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  377 */         ResponderID responderId = basicResp.getResponderId().toASN1Object();
/*  378 */         if (responderId != null) {
/*  379 */           ASN1TaggedObject tagged = (ASN1TaggedObject)responderId.toASN1Object();
/*  380 */           switch (tagged.getTagNo()) {
/*      */           case 1: 
/*  382 */             X509Principal cerX509Principal = new X509Principal(X509Name.getInstance(tagged.getObject()).toString());
/*  383 */             X500Principal cerX500Principal = new X500Principal(cerX509Principal.getDEREncoded());
/*  384 */             certSelector = new X509CertSelector();
/*  385 */             certSelector.setSubject(cerX500Principal);
/*  386 */             break;
/*      */           case 2: 
/*  388 */             ASN1OctetString octect = (ASN1OctetString)tagged.getObject();
/*  389 */             certSelector = new X509CertSelector();
/*      */             try {
/*  391 */               certSelector.setSubjectPublicKey(octect.getOctets());
/*      */             } catch (IOException ex) {
/*  393 */               LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.13", new Object[] { ex.getMessage() }));
/*  394 */               if (LOG.isDebugEnabled()) {
/*  395 */                 LOG.debug("", ex);
/*      */               }
/*  397 */               throw new UnknownTrustException();
/*      */             }
/*      */           
/*      */           default: 
/*  401 */             throw new UnknownTrustException();
/*      */           }
/*      */         }
/*      */       }
/*  405 */       if (certSelector != null)
/*      */       {
/*      */         try {
/*  408 */           it = this.certsOCSP.getCertificates(certSelector).iterator();
/*      */         } catch (CertStoreException ex) { Iterator<? extends Certificate> it;
/*  410 */           LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.22", new Object[] { ex.getMessage() }));
/*  411 */           if (LOG.isDebugEnabled()) {
/*  412 */             LOG.debug("", ex);
/*      */           }
/*  414 */           throw new UnknownTrustException(); }
/*      */         Iterator<? extends Certificate> it;
/*  416 */         if (it.hasNext()) {
/*  417 */           X509Certificate cert = (X509Certificate)it.next();
/*      */           try
/*      */           {
/*  420 */             if (basicResp.verify(cert.getPublicKey(), "SunRsaSign")) {
/*  421 */               return;
/*      */             }
/*  423 */             throw new FakedTrustException();
/*      */           }
/*      */           catch (OCSPException ex) {
/*  426 */             LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.15", new Object[] { ex.getMessage() }));
/*  427 */             if (LOG.isDebugEnabled()) {
/*  428 */               LOG.debug("", ex);
/*      */             }
/*  430 */             throw new UnknownTrustException();
/*      */           } catch (NoSuchProviderException ex) {
/*  432 */             LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.14", new Object[] { ex.getMessage() }));
/*  433 */             if (LOG.isDebugEnabled()) {
/*  434 */               LOG.debug("", ex);
/*      */             }
/*  436 */             throw new UnknownTrustException();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  441 */     if (this.issuersOCSP != null)
/*      */     {
/*      */       try
/*      */       {
/*  445 */         certs = basicResp.getCerts("SUN");
/*      */       } catch (NoSuchProviderException ex) { X509Certificate[] certs;
/*  447 */         LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.12", new Object[] { ex.getMessage() }));
/*  448 */         if (LOG.isDebugEnabled()) {
/*  449 */           LOG.debug("", ex);
/*      */         }
/*  451 */         throw new UnknownTrustException();
/*      */       } catch (OCSPException ex) {
/*  453 */         LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.12", new Object[] { ex.getMessage() }));
/*  454 */         if (LOG.isDebugEnabled()) {
/*  455 */           LOG.debug("", ex);
/*      */         }
/*  457 */         throw new UnknownTrustException(); }
/*      */       X509Certificate[] certs;
/*  459 */       if ((certs == null) || (certs.length == 0)) {
/*  460 */         throw new UnknownTrustException();
/*      */       }
/*      */       
/*  463 */       validateIssuer(certs, this.issuersOCSP);
/*      */       
/*      */ 
/*      */       try
/*      */       {
/*  468 */         if (basicResp.verify(certs[0].getPublicKey(), "SunRsaSign")) {
/*  469 */           return;
/*      */         }
/*  471 */         throw new FakedTrustException();
/*      */       }
/*      */       catch (OCSPException ex) {
/*  474 */         LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.15", new Object[] { ex.getMessage() }));
/*  475 */         if (LOG.isDebugEnabled()) {
/*  476 */           LOG.debug("", ex);
/*      */         }
/*  478 */         throw new UnknownTrustException();
/*      */       } catch (NoSuchProviderException ex) {
/*  480 */         LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.14", new Object[] { ex.getMessage() }));
/*  481 */         if (LOG.isDebugEnabled()) {
/*  482 */           LOG.debug("", ex);
/*      */         }
/*  484 */         throw new UnknownTrustException();
/*      */       }
/*      */     }
/*  487 */     throw new NotTrustedException();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void validateIssuer(X509Certificate[] certs, CertStore store)
/*      */     throws UnknownTrustException, NotTrustedException
/*      */   {
/*  498 */     for (int i = 0; i < certs.length; i++) {
/*  499 */       X509CertSelector certSelector = new X509CertSelector();
/*  500 */       if (certs.length > i + 1) {
/*  501 */         certSelector.setSubjectPublicKey(certs[(i + 1)].getPublicKey());
/*      */       } else {
/*  503 */         certSelector.setSubject(certs[i].getIssuerX500Principal());
/*      */       }
/*      */       try
/*      */       {
/*  507 */         certsCollection = store.getCertificates(certSelector);
/*      */       } catch (CertStoreException ex) { Collection<? extends Certificate> certsCollection;
/*  509 */         LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.22", new Object[] { ex.getMessage() }));
/*  510 */         if (LOG.isDebugEnabled()) {
/*  511 */           LOG.debug("", ex);
/*      */         }
/*  513 */         throw new UnknownTrustException(); }
/*      */       Collection<? extends Certificate> certsCollection;
/*  515 */       if (certsCollection.size() > 0) {
/*  516 */         Iterator<? extends Certificate> it = certsCollection.iterator();
/*  517 */         while (it.hasNext()) {
/*  518 */           X509Certificate certIssuer = (X509Certificate)it.next();
/*      */           try {
/*  520 */             certs[i].verify(certIssuer.getPublicKey());
/*  521 */             return;
/*      */           } catch (InvalidKeyException ex) {
/*  523 */             LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.23", new Object[] { ex.getMessage() }));
/*  524 */             if (LOG.isDebugEnabled()) {
/*  525 */               LOG.debug("", ex);
/*      */             }
/*  527 */             throw new UnknownTrustException();
/*      */           } catch (CertificateException ex) {
/*  529 */             LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.23", new Object[] { ex.getMessage() }));
/*  530 */             if (LOG.isDebugEnabled()) {
/*  531 */               LOG.debug("", ex);
/*      */             }
/*  533 */             throw new UnknownTrustException();
/*      */           } catch (NoSuchAlgorithmException ex) {
/*  535 */             LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.23", new Object[] { ex.getMessage() }));
/*  536 */             if (LOG.isDebugEnabled()) {
/*  537 */               LOG.debug("", ex);
/*      */             }
/*  539 */             throw new UnknownTrustException();
/*      */           } catch (NoSuchProviderException ex) {
/*  541 */             LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.23", new Object[] { ex.getMessage() }));
/*  542 */             if (LOG.isDebugEnabled()) {
/*  543 */               LOG.debug("", ex);
/*      */             }
/*  545 */             throw new UnknownTrustException();
/*      */           }
/*      */           catch (SignatureException localSignatureException1) {}
/*      */         }
/*  549 */         throw new FakedTrustException();
/*      */       }
/*  551 */       if (i + 1 < certs.length) {
/*      */         try
/*      */         {
/*  554 */           certs[i].verify(certs[(i + 1)].getPublicKey());
/*      */         } catch (InvalidKeyException ex) {
/*  556 */           LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.23", new Object[] { ex.getMessage() }));
/*  557 */           if (LOG.isDebugEnabled()) {
/*  558 */             LOG.debug("", ex);
/*      */           }
/*  560 */           throw new UnknownTrustException();
/*      */         } catch (CertificateException ex) {
/*  562 */           LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.23", new Object[] { ex.getMessage() }));
/*  563 */           if (LOG.isDebugEnabled()) {
/*  564 */             LOG.debug("", ex);
/*      */           }
/*  566 */           throw new UnknownTrustException();
/*      */         } catch (NoSuchAlgorithmException ex) {
/*  568 */           LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.23", new Object[] { ex.getMessage() }));
/*  569 */           if (LOG.isDebugEnabled()) {
/*  570 */             LOG.debug("", ex);
/*      */           }
/*  572 */           throw new UnknownTrustException();
/*      */         } catch (NoSuchProviderException ex) {
/*  574 */           LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.23", new Object[] { ex.getMessage() }));
/*  575 */           if (LOG.isDebugEnabled()) {
/*  576 */             LOG.debug("", ex);
/*      */           }
/*  578 */           throw new UnknownTrustException();
/*      */         } catch (SignatureException ex) {
/*  580 */           throw new FakedTrustException();
/*      */         }
/*      */         
/*      */       } else {
/*  584 */         throw new NotTrustedException();
/*      */       }
/*      */     }
/*  587 */     throw new NotTrustedException();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void isTrusted(CertPath certs)
/*      */     throws TrustException
/*      */   {
/*  604 */     if ((certs == null) || (certs.getCertificates().size() == 0)) {
/*  605 */       throw new UnknownTrustException();
/*      */     }
/*      */     
/*  608 */     if (this.certsCerts != null) {
/*  609 */       X509Certificate cert = (X509Certificate)certs.getCertificates().get(0);
/*  610 */       X509CertSelector certSelector = new X509CertSelector();
/*  611 */       certSelector.setCertificate(cert);
/*  612 */       Collection<? extends Certificate> certsCollection = null;
/*      */       try {
/*  614 */         certsCollection = this.certsCerts.getCertificates(certSelector);
/*      */       } catch (CertStoreException ex) {
/*  616 */         LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.24", new Object[] { ex.getMessage() }));
/*  617 */         if (LOG.isDebugEnabled()) {
/*  618 */           LOG.debug("", ex);
/*      */         }
/*  620 */         throw new UnknownTrustException();
/*      */       }
/*  622 */       if (certsCollection.size() > 0) {
/*  623 */         return;
/*      */       }
/*      */     }
/*      */     
/*  627 */     if (this.issuersCerts != null) {
/*  628 */       X509Certificate[] list = (X509Certificate[])certs.getCertificates().toArray(new X509Certificate[0]);
/*  629 */       validateIssuer(list, this.issuersCerts);
/*  630 */       return;
/*      */     }
/*  632 */     throw new NotTrustedException();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void isTrusted(TimeStampToken tst)
/*      */     throws TrustException
/*      */   {
/*  649 */     if (this.certsTSA != null) {
/*  650 */       SignerId sid = tst.getSID();
/*  651 */       if (sid != null)
/*      */       {
/*      */         try {
/*  654 */           certsColl = this.certsTSA.getCertificates(sid);
/*      */         } catch (CertStoreException ex) { Collection<? extends Certificate> certsColl;
/*  656 */           LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.25", new Object[] { ex.getMessage() }));
/*  657 */           if (LOG.isDebugEnabled()) {
/*  658 */             LOG.debug("", ex);
/*      */           }
/*  660 */           throw new UnknownTrustException(); }
/*      */         Collection<? extends Certificate> certsColl;
/*  662 */         if (certsColl.size() <= 0) break label371;
/*  663 */         Iterator<? extends Certificate> it = certsColl.iterator();
/*  664 */         if (!it.hasNext()) break label371;
/*  665 */         X509Certificate cert = (X509Certificate)it.next();
/*      */         try {
/*  667 */           tst.validate(cert, "SunRsaSign");
/*  668 */           return;
/*      */         } catch (CertificateExpiredException ex) {
/*  670 */           LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.26"), ex);
/*  671 */           throw new NotTrustedException(I18N.getLocalMessage("i18n.mityc.trust.props.26"));
/*      */         } catch (CertificateNotYetValidException ex) {
/*  673 */           LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.26"), ex);
/*  674 */           throw new NotTrustedException(I18N.getLocalMessage("i18n.mityc.trust.props.26"));
/*      */         } catch (TSPValidationException ex) {
/*  676 */           throw new FakedTrustException();
/*      */         } catch (NoSuchProviderException ex) {
/*  678 */           LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.6", new Object[] { ex.getMessage() }));
/*  679 */           if (LOG.isDebugEnabled()) {
/*  680 */             LOG.debug("", ex);
/*      */           }
/*  682 */           throw new UnknownTrustException();
/*      */         } catch (TSPException ex) {
/*  684 */           LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.7", new Object[] { ex.getMessage() }));
/*  685 */           if (LOG.isDebugEnabled()) {
/*  686 */             LOG.debug("", ex);
/*      */           }
/*  688 */           throw new UnknownTrustException();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  694 */       throw new UnknownTrustException();
/*      */     }
/*      */     label371:
/*  697 */     if (this.issuersTSA != null)
/*      */     {
/*      */       try
/*      */       {
/*  701 */         certs = (X509Certificate[])tst.getCertificatesAndCRLs("Collection", null).getCertificates(null).toArray(new X509Certificate[0]);
/*      */       } catch (NoSuchAlgorithmException ex) { X509Certificate[] certs;
/*  703 */         LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.19", new Object[] { ex.getMessage() }));
/*  704 */         if (LOG.isDebugEnabled()) {
/*  705 */           LOG.debug("", ex);
/*      */         }
/*  707 */         throw new UnknownTrustException();
/*      */       } catch (NoSuchProviderException ex) {
/*  709 */         LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.19", new Object[] { ex.getMessage() }));
/*  710 */         if (LOG.isDebugEnabled()) {
/*  711 */           LOG.debug("", ex);
/*      */         }
/*  713 */         throw new UnknownTrustException();
/*      */       } catch (CMSException ex) {
/*  715 */         LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.19", new Object[] { ex.getMessage() }));
/*  716 */         if (LOG.isDebugEnabled()) {
/*  717 */           LOG.debug("", ex);
/*      */         }
/*  719 */         throw new UnknownTrustException();
/*      */       } catch (CertStoreException ex) {
/*  721 */         LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.25", new Object[] { ex.getMessage() }));
/*  722 */         if (LOG.isDebugEnabled()) {
/*  723 */           LOG.debug("", ex);
/*      */         }
/*  725 */         throw new UnknownTrustException(); }
/*      */       X509Certificate[] certs;
/*  727 */       if ((certs == null) || (certs.length == 0)) {
/*  728 */         throw new UnknownTrustException();
/*      */       }
/*      */       
/*  731 */       validateIssuer(certs, this.issuersTSA);
/*      */       
/*      */       try
/*      */       {
/*  735 */         tst.validate(certs[0], "SunRsaSign");
/*  736 */         return;
/*      */       }
/*      */       catch (CertificateExpiredException localCertificateExpiredException1) {}catch (CertificateNotYetValidException localCertificateNotYetValidException1) {}catch (TSPValidationException ex)
/*      */       {
/*  740 */         throw new FakedTrustException();
/*      */       } catch (NoSuchProviderException ex) {
/*  742 */         LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.6", new Object[] { ex.getMessage() }));
/*  743 */         if (LOG.isDebugEnabled()) {
/*  744 */           LOG.debug("", ex);
/*      */         }
/*  746 */         throw new UnknownTrustException();
/*      */       } catch (TSPException ex) {
/*  748 */         LOG.error(I18N.getLocalMessage("i18n.mityc.trust.props.7", new Object[] { ex.getMessage() }));
/*  749 */         if (LOG.isDebugEnabled()) {
/*  750 */           LOG.debug("", ex);
/*      */         }
/*  752 */         throw new UnknownTrustException();
/*      */       }
/*      */     }
/*  755 */     throw new NotTrustedException();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static TrustAdapter getInstance()
/*      */   {
/*  764 */     if (instance == null) {
/*  765 */       instance = new PropsTruster("trust/myTruster.properties", null);
/*      */     }
/*  767 */     return instance;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static ClassLoader getClassLoader()
/*      */   {
/*      */     try
/*      */     {
/*  777 */       ClassLoader cl = (ClassLoader)AccessController.doPrivileged(new PrivilegedAction() {
/*      */         public ClassLoader run() {
/*  779 */           ClassLoader classLoader = null;
/*      */           try {
/*  781 */             classLoader = Thread.currentThread().getContextClassLoader();
/*      */           }
/*      */           catch (SecurityException localSecurityException) {}
/*  784 */           return classLoader;
/*      */         }
/*      */       });
/*  787 */       if (cl != null) {
/*  788 */         return cl;
/*      */       }
/*      */     }
/*      */     catch (Exception localException) {}
/*  792 */     return TrustFactory.class.getClassLoader();
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   private CertStore loadCerts(CertificateFactory cf, Properties internalProps, Properties externalProps, TrusterType trusterType)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: new 523	java/util/ArrayList
/*      */     //   3: dup
/*      */     //   4: invokespecial 525	java/util/ArrayList:<init>	()V
/*      */     //   7: astore 5
/*      */     //   9: aload_2
/*      */     //   10: ifnull +216 -> 226
/*      */     //   13: invokestatic 108	es/mityc/javasign/trust/PropsTruster:getClassLoader	()Ljava/lang/ClassLoader;
/*      */     //   16: astore 6
/*      */     //   18: aload_2
/*      */     //   19: invokevirtual 526	java/util/Properties:propertyNames	()Ljava/util/Enumeration;
/*      */     //   22: astore 7
/*      */     //   24: goto +192 -> 216
/*      */     //   27: aload 7
/*      */     //   29: invokeinterface 530 1 0
/*      */     //   34: checkcast 104	java/lang/String
/*      */     //   37: astore 8
/*      */     //   39: aload 8
/*      */     //   41: aload 4
/*      */     //   43: invokevirtual 535	es/mityc/javasign/trust/PropsTruster$TrusterType:toString	()Ljava/lang/String;
/*      */     //   46: invokevirtual 536	java/lang/String:startsWith	(Ljava/lang/String;)Z
/*      */     //   49: ifeq +167 -> 216
/*      */     //   52: aload_2
/*      */     //   53: aload 8
/*      */     //   55: invokevirtual 540	java/util/Properties:getProperty	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   58: astore 9
/*      */     //   60: new 543	java/util/StringTokenizer
/*      */     //   63: dup
/*      */     //   64: aload 9
/*      */     //   66: ldc_w 545
/*      */     //   69: invokespecial 547	java/util/StringTokenizer:<init>	(Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   72: astore 10
/*      */     //   74: goto +129 -> 203
/*      */     //   77: aload 10
/*      */     //   79: invokevirtual 550	java/util/StringTokenizer:nextToken	()Ljava/lang/String;
/*      */     //   82: astore 11
/*      */     //   84: aload 6
/*      */     //   86: aload 11
/*      */     //   88: invokevirtual 112	java/lang/ClassLoader:getResourceAsStream	(Ljava/lang/String;)Ljava/io/InputStream;
/*      */     //   91: astore 12
/*      */     //   93: aload 12
/*      */     //   95: ifnull +80 -> 175
/*      */     //   98: aload 5
/*      */     //   100: aload_1
/*      */     //   101: aload 12
/*      */     //   103: invokevirtual 553	java/security/cert/CertificateFactory:generateCertificate	(Ljava/io/InputStream;)Ljava/security/cert/Certificate;
/*      */     //   106: checkcast 233	java/security/cert/X509Certificate
/*      */     //   109: invokevirtual 557	java/util/ArrayList:add	(Ljava/lang/Object;)Z
/*      */     //   112: pop
/*      */     //   113: goto +90 -> 203
/*      */     //   116: astore 13
/*      */     //   118: getstatic 35	es/mityc/javasign/trust/PropsTruster:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   121: getstatic 45	es/mityc/javasign/trust/PropsTruster:I18N	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   124: ldc_w 561
/*      */     //   127: iconst_1
/*      */     //   128: anewarray 76	java/lang/Object
/*      */     //   131: dup
/*      */     //   132: iconst_0
/*      */     //   133: aload 13
/*      */     //   135: invokevirtual 170	java/security/cert/CertificateException:getMessage	()Ljava/lang/String;
/*      */     //   138: aastore
/*      */     //   139: invokeinterface 78 3 0
/*      */     //   144: invokeinterface 84 2 0
/*      */     //   149: getstatic 35	es/mityc/javasign/trust/PropsTruster:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   152: invokeinterface 90 1 0
/*      */     //   157: ifeq +46 -> 203
/*      */     //   160: getstatic 35	es/mityc/javasign/trust/PropsTruster:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   163: ldc -80
/*      */     //   165: aload 13
/*      */     //   167: invokeinterface 178 3 0
/*      */     //   172: goto +31 -> 203
/*      */     //   175: getstatic 35	es/mityc/javasign/trust/PropsTruster:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   178: getstatic 45	es/mityc/javasign/trust/PropsTruster:I18N	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   181: ldc_w 563
/*      */     //   184: iconst_1
/*      */     //   185: anewarray 76	java/lang/Object
/*      */     //   188: dup
/*      */     //   189: iconst_0
/*      */     //   190: aload 11
/*      */     //   192: aastore
/*      */     //   193: invokeinterface 78 3 0
/*      */     //   198: invokeinterface 565 2 0
/*      */     //   203: aload 10
/*      */     //   205: invokevirtual 568	java/util/StringTokenizer:hasMoreTokens	()Z
/*      */     //   208: ifne -131 -> 77
/*      */     //   211: goto +5 -> 216
/*      */     //   214: astore 9
/*      */     //   216: aload 7
/*      */     //   218: invokeinterface 571 1 0
/*      */     //   223: ifne -196 -> 27
/*      */     //   226: aload_3
/*      */     //   227: ifnull +440 -> 667
/*      */     //   230: aload_3
/*      */     //   231: invokevirtual 526	java/util/Properties:propertyNames	()Ljava/util/Enumeration;
/*      */     //   234: astore 6
/*      */     //   236: goto +421 -> 657
/*      */     //   239: aload 6
/*      */     //   241: invokeinterface 530 1 0
/*      */     //   246: checkcast 104	java/lang/String
/*      */     //   249: astore 7
/*      */     //   251: aload 7
/*      */     //   253: aload 4
/*      */     //   255: invokevirtual 535	es/mityc/javasign/trust/PropsTruster$TrusterType:toString	()Ljava/lang/String;
/*      */     //   258: invokevirtual 536	java/lang/String:startsWith	(Ljava/lang/String;)Z
/*      */     //   261: ifeq +396 -> 657
/*      */     //   264: aload_3
/*      */     //   265: aload 7
/*      */     //   267: invokevirtual 540	java/util/Properties:getProperty	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   270: astore 8
/*      */     //   272: new 543	java/util/StringTokenizer
/*      */     //   275: dup
/*      */     //   276: aload 8
/*      */     //   278: ldc_w 545
/*      */     //   281: invokespecial 547	java/util/StringTokenizer:<init>	(Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   284: astore 9
/*      */     //   286: aconst_null
/*      */     //   287: astore 10
/*      */     //   289: aconst_null
/*      */     //   290: astore 11
/*      */     //   292: goto +285 -> 577
/*      */     //   295: aload 9
/*      */     //   297: invokevirtual 550	java/util/StringTokenizer:nextToken	()Ljava/lang/String;
/*      */     //   300: astore 10
/*      */     //   302: new 574	java/io/FileInputStream
/*      */     //   305: dup
/*      */     //   306: aload 10
/*      */     //   308: invokespecial 576	java/io/FileInputStream:<init>	(Ljava/lang/String;)V
/*      */     //   311: astore 11
/*      */     //   313: aload 5
/*      */     //   315: aload_1
/*      */     //   316: aload 11
/*      */     //   318: invokevirtual 553	java/security/cert/CertificateFactory:generateCertificate	(Ljava/io/InputStream;)Ljava/security/cert/Certificate;
/*      */     //   321: checkcast 233	java/security/cert/X509Certificate
/*      */     //   324: invokevirtual 557	java/util/ArrayList:add	(Ljava/lang/Object;)Z
/*      */     //   327: pop
/*      */     //   328: goto +239 -> 567
/*      */     //   331: astore 12
/*      */     //   333: aconst_null
/*      */     //   334: astore 13
/*      */     //   336: aload 11
/*      */     //   338: invokevirtual 577	java/io/FileInputStream:reset	()V
/*      */     //   341: new 580	java/io/ByteArrayOutputStream
/*      */     //   344: dup
/*      */     //   345: aload 11
/*      */     //   347: invokevirtual 582	java/io/FileInputStream:available	()I
/*      */     //   350: invokespecial 585	java/io/ByteArrayOutputStream:<init>	(I)V
/*      */     //   353: astore 13
/*      */     //   355: sipush 1000
/*      */     //   358: newarray <illegal type>
/*      */     //   360: astore 14
/*      */     //   362: aload 11
/*      */     //   364: aload 14
/*      */     //   366: invokevirtual 588	java/io/FileInputStream:read	([B)I
/*      */     //   369: istore 15
/*      */     //   371: goto +22 -> 393
/*      */     //   374: aload 13
/*      */     //   376: aload 14
/*      */     //   378: iconst_0
/*      */     //   379: iload 15
/*      */     //   381: invokevirtual 592	java/io/ByteArrayOutputStream:write	([BII)V
/*      */     //   384: aload 11
/*      */     //   386: aload 14
/*      */     //   388: invokevirtual 588	java/io/FileInputStream:read	([B)I
/*      */     //   391: istore 15
/*      */     //   393: iload 15
/*      */     //   395: ifgt -21 -> 374
/*      */     //   398: new 596	java/io/ByteArrayInputStream
/*      */     //   401: dup
/*      */     //   402: aload 13
/*      */     //   404: invokevirtual 598	java/io/ByteArrayOutputStream:toByteArray	()[B
/*      */     //   407: invokestatic 601	org/bouncycastle/util/encoders/Base64:encode	([B)[B
/*      */     //   410: invokespecial 607	java/io/ByteArrayInputStream:<init>	([B)V
/*      */     //   413: astore 16
/*      */     //   415: aload 5
/*      */     //   417: aload_1
/*      */     //   418: aload 16
/*      */     //   420: invokevirtual 553	java/security/cert/CertificateFactory:generateCertificate	(Ljava/io/InputStream;)Ljava/security/cert/Certificate;
/*      */     //   423: checkcast 233	java/security/cert/X509Certificate
/*      */     //   426: invokevirtual 557	java/util/ArrayList:add	(Ljava/lang/Object;)Z
/*      */     //   429: pop
/*      */     //   430: goto +99 -> 529
/*      */     //   433: astore 14
/*      */     //   435: getstatic 35	es/mityc/javasign/trust/PropsTruster:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   438: getstatic 45	es/mityc/javasign/trust/PropsTruster:I18N	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   441: ldc_w 561
/*      */     //   444: iconst_1
/*      */     //   445: anewarray 76	java/lang/Object
/*      */     //   448: dup
/*      */     //   449: iconst_0
/*      */     //   450: aload 12
/*      */     //   452: invokevirtual 170	java/security/cert/CertificateException:getMessage	()Ljava/lang/String;
/*      */     //   455: aastore
/*      */     //   456: invokeinterface 78 3 0
/*      */     //   461: invokeinterface 84 2 0
/*      */     //   466: getstatic 35	es/mityc/javasign/trust/PropsTruster:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   469: invokeinterface 90 1 0
/*      */     //   474: ifeq +27 -> 501
/*      */     //   477: getstatic 35	es/mityc/javasign/trust/PropsTruster:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   480: ldc -80
/*      */     //   482: aload 12
/*      */     //   484: invokeinterface 178 3 0
/*      */     //   489: getstatic 35	es/mityc/javasign/trust/PropsTruster:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   492: ldc -80
/*      */     //   494: aload 14
/*      */     //   496: invokeinterface 178 3 0
/*      */     //   501: aload 13
/*      */     //   503: invokevirtual 608	java/io/ByteArrayOutputStream:close	()V
/*      */     //   506: goto +33 -> 539
/*      */     //   509: astore 18
/*      */     //   511: goto +28 -> 539
/*      */     //   514: astore 17
/*      */     //   516: aload 13
/*      */     //   518: invokevirtual 608	java/io/ByteArrayOutputStream:close	()V
/*      */     //   521: goto +5 -> 526
/*      */     //   524: astore 18
/*      */     //   526: aload 17
/*      */     //   528: athrow
/*      */     //   529: aload 13
/*      */     //   531: invokevirtual 608	java/io/ByteArrayOutputStream:close	()V
/*      */     //   534: goto +5 -> 539
/*      */     //   537: astore 18
/*      */     //   539: aload 11
/*      */     //   541: invokevirtual 611	java/io/FileInputStream:close	()V
/*      */     //   544: goto +33 -> 577
/*      */     //   547: astore 20
/*      */     //   549: goto +28 -> 577
/*      */     //   552: astore 19
/*      */     //   554: aload 11
/*      */     //   556: invokevirtual 611	java/io/FileInputStream:close	()V
/*      */     //   559: goto +5 -> 564
/*      */     //   562: astore 20
/*      */     //   564: aload 19
/*      */     //   566: athrow
/*      */     //   567: aload 11
/*      */     //   569: invokevirtual 611	java/io/FileInputStream:close	()V
/*      */     //   572: goto +5 -> 577
/*      */     //   575: astore 20
/*      */     //   577: aload 9
/*      */     //   579: invokevirtual 568	java/util/StringTokenizer:hasMoreTokens	()Z
/*      */     //   582: ifne -287 -> 295
/*      */     //   585: goto +72 -> 657
/*      */     //   588: astore 8
/*      */     //   590: getstatic 35	es/mityc/javasign/trust/PropsTruster:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   593: getstatic 45	es/mityc/javasign/trust/PropsTruster:I18N	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   596: ldc_w 563
/*      */     //   599: iconst_1
/*      */     //   600: anewarray 76	java/lang/Object
/*      */     //   603: dup
/*      */     //   604: iconst_0
/*      */     //   605: aload 8
/*      */     //   607: invokevirtual 612	java/util/MissingResourceException:getMessage	()Ljava/lang/String;
/*      */     //   610: aastore
/*      */     //   611: invokeinterface 78 3 0
/*      */     //   616: invokeinterface 565 2 0
/*      */     //   621: goto +36 -> 657
/*      */     //   624: astore 8
/*      */     //   626: getstatic 35	es/mityc/javasign/trust/PropsTruster:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   629: getstatic 45	es/mityc/javasign/trust/PropsTruster:I18N	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   632: ldc_w 561
/*      */     //   635: iconst_1
/*      */     //   636: anewarray 76	java/lang/Object
/*      */     //   639: dup
/*      */     //   640: iconst_0
/*      */     //   641: aload 8
/*      */     //   643: invokevirtual 615	java/io/FileNotFoundException:getMessage	()Ljava/lang/String;
/*      */     //   646: aastore
/*      */     //   647: invokeinterface 78 3 0
/*      */     //   652: invokeinterface 84 2 0
/*      */     //   657: aload 6
/*      */     //   659: invokeinterface 571 1 0
/*      */     //   664: ifne -425 -> 239
/*      */     //   667: aconst_null
/*      */     //   668: astore 6
/*      */     //   670: aload 5
/*      */     //   672: invokevirtual 618	java/util/ArrayList:size	()I
/*      */     //   675: ifle +138 -> 813
/*      */     //   678: ldc_w 472
/*      */     //   681: new 619	java/security/cert/CollectionCertStoreParameters
/*      */     //   684: dup
/*      */     //   685: aload 5
/*      */     //   687: invokespecial 621	java/security/cert/CollectionCertStoreParameters:<init>	(Ljava/util/Collection;)V
/*      */     //   690: invokestatic 624	java/security/cert/CertStore:getInstance	(Ljava/lang/String;Ljava/security/cert/CertStoreParameters;)Ljava/security/cert/CertStore;
/*      */     //   693: astore 6
/*      */     //   695: goto +118 -> 813
/*      */     //   698: astore 7
/*      */     //   700: getstatic 35	es/mityc/javasign/trust/PropsTruster:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   703: getstatic 45	es/mityc/javasign/trust/PropsTruster:I18N	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   706: ldc_w 627
/*      */     //   709: iconst_1
/*      */     //   710: anewarray 76	java/lang/Object
/*      */     //   713: dup
/*      */     //   714: iconst_0
/*      */     //   715: aload 7
/*      */     //   717: invokevirtual 629	java/security/InvalidAlgorithmParameterException:getMessage	()Ljava/lang/String;
/*      */     //   720: aastore
/*      */     //   721: invokeinterface 78 3 0
/*      */     //   726: invokeinterface 84 2 0
/*      */     //   731: getstatic 35	es/mityc/javasign/trust/PropsTruster:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   734: invokeinterface 90 1 0
/*      */     //   739: ifeq +74 -> 813
/*      */     //   742: getstatic 35	es/mityc/javasign/trust/PropsTruster:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   745: ldc -80
/*      */     //   747: aload 7
/*      */     //   749: invokeinterface 178 3 0
/*      */     //   754: goto +59 -> 813
/*      */     //   757: astore 7
/*      */     //   759: getstatic 35	es/mityc/javasign/trust/PropsTruster:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   762: getstatic 45	es/mityc/javasign/trust/PropsTruster:I18N	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   765: ldc_w 627
/*      */     //   768: iconst_1
/*      */     //   769: anewarray 76	java/lang/Object
/*      */     //   772: dup
/*      */     //   773: iconst_0
/*      */     //   774: aload 7
/*      */     //   776: invokevirtual 255	java/security/NoSuchAlgorithmException:getMessage	()Ljava/lang/String;
/*      */     //   779: aastore
/*      */     //   780: invokeinterface 78 3 0
/*      */     //   785: invokeinterface 84 2 0
/*      */     //   790: getstatic 35	es/mityc/javasign/trust/PropsTruster:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   793: invokeinterface 90 1 0
/*      */     //   798: ifeq +15 -> 813
/*      */     //   801: getstatic 35	es/mityc/javasign/trust/PropsTruster:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   804: ldc -80
/*      */     //   806: aload 7
/*      */     //   808: invokeinterface 178 3 0
/*      */     //   813: aload 6
/*      */     //   815: areturn
/*      */     // Line number table:
/*      */     //   Java source line #804	-> byte code offset #0
/*      */     //   Java source line #805	-> byte code offset #9
/*      */     //   Java source line #806	-> byte code offset #13
/*      */     //   Java source line #807	-> byte code offset #18
/*      */     //   Java source line #808	-> byte code offset #24
/*      */     //   Java source line #809	-> byte code offset #27
/*      */     //   Java source line #810	-> byte code offset #39
/*      */     //   Java source line #812	-> byte code offset #52
/*      */     //   Java source line #813	-> byte code offset #60
/*      */     //   Java source line #814	-> byte code offset #74
/*      */     //   Java source line #815	-> byte code offset #77
/*      */     //   Java source line #816	-> byte code offset #84
/*      */     //   Java source line #817	-> byte code offset #93
/*      */     //   Java source line #819	-> byte code offset #98
/*      */     //   Java source line #820	-> byte code offset #113
/*      */     //   Java source line #821	-> byte code offset #118
/*      */     //   Java source line #822	-> byte code offset #149
/*      */     //   Java source line #823	-> byte code offset #160
/*      */     //   Java source line #826	-> byte code offset #172
/*      */     //   Java source line #828	-> byte code offset #175
/*      */     //   Java source line #814	-> byte code offset #203
/*      */     //   Java source line #831	-> byte code offset #211
/*      */     //   Java source line #808	-> byte code offset #216
/*      */     //   Java source line #836	-> byte code offset #226
/*      */     //   Java source line #837	-> byte code offset #230
/*      */     //   Java source line #838	-> byte code offset #236
/*      */     //   Java source line #839	-> byte code offset #239
/*      */     //   Java source line #840	-> byte code offset #251
/*      */     //   Java source line #842	-> byte code offset #264
/*      */     //   Java source line #843	-> byte code offset #272
/*      */     //   Java source line #844	-> byte code offset #286
/*      */     //   Java source line #845	-> byte code offset #289
/*      */     //   Java source line #846	-> byte code offset #292
/*      */     //   Java source line #847	-> byte code offset #295
/*      */     //   Java source line #848	-> byte code offset #302
/*      */     //   Java source line #850	-> byte code offset #313
/*      */     //   Java source line #851	-> byte code offset #328
/*      */     //   Java source line #852	-> byte code offset #333
/*      */     //   Java source line #854	-> byte code offset #336
/*      */     //   Java source line #855	-> byte code offset #341
/*      */     //   Java source line #858	-> byte code offset #355
/*      */     //   Java source line #859	-> byte code offset #362
/*      */     //   Java source line #860	-> byte code offset #371
/*      */     //   Java source line #861	-> byte code offset #374
/*      */     //   Java source line #862	-> byte code offset #384
/*      */     //   Java source line #860	-> byte code offset #393
/*      */     //   Java source line #864	-> byte code offset #398
/*      */     //   Java source line #866	-> byte code offset #415
/*      */     //   Java source line #867	-> byte code offset #430
/*      */     //   Java source line #868	-> byte code offset #435
/*      */     //   Java source line #869	-> byte code offset #466
/*      */     //   Java source line #870	-> byte code offset #477
/*      */     //   Java source line #871	-> byte code offset #489
/*      */     //   Java source line #874	-> byte code offset #501
/*      */     //   Java source line #873	-> byte code offset #514
/*      */     //   Java source line #874	-> byte code offset #516
/*      */     //   Java source line #875	-> byte code offset #526
/*      */     //   Java source line #874	-> byte code offset #529
/*      */     //   Java source line #877	-> byte code offset #539
/*      */     //   Java source line #876	-> byte code offset #552
/*      */     //   Java source line #877	-> byte code offset #554
/*      */     //   Java source line #878	-> byte code offset #564
/*      */     //   Java source line #877	-> byte code offset #567
/*      */     //   Java source line #846	-> byte code offset #577
/*      */     //   Java source line #880	-> byte code offset #585
/*      */     //   Java source line #881	-> byte code offset #590
/*      */     //   Java source line #882	-> byte code offset #624
/*      */     //   Java source line #883	-> byte code offset #626
/*      */     //   Java source line #838	-> byte code offset #657
/*      */     //   Java source line #888	-> byte code offset #667
/*      */     //   Java source line #889	-> byte code offset #670
/*      */     //   Java source line #891	-> byte code offset #678
/*      */     //   Java source line #892	-> byte code offset #695
/*      */     //   Java source line #893	-> byte code offset #700
/*      */     //   Java source line #894	-> byte code offset #731
/*      */     //   Java source line #895	-> byte code offset #742
/*      */     //   Java source line #897	-> byte code offset #757
/*      */     //   Java source line #898	-> byte code offset #759
/*      */     //   Java source line #899	-> byte code offset #790
/*      */     //   Java source line #900	-> byte code offset #801
/*      */     //   Java source line #904	-> byte code offset #813
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	816	0	this	PropsTruster
/*      */     //   0	816	1	cf	CertificateFactory
/*      */     //   0	816	2	internalProps	Properties
/*      */     //   0	816	3	externalProps	Properties
/*      */     //   0	816	4	trusterType	TrusterType
/*      */     //   7	679	5	list	ArrayList<X509Certificate>
/*      */     //   16	69	6	cl	ClassLoader
/*      */     //   234	424	6	en	java.util.Enumeration<?>
/*      */     //   668	146	6	cs	CertStore
/*      */     //   22	195	7	en	java.util.Enumeration<?>
/*      */     //   249	17	7	propName	String
/*      */     //   698	50	7	ex	java.security.InvalidAlgorithmParameterException
/*      */     //   757	50	7	ex	NoSuchAlgorithmException
/*      */     //   37	17	8	propName	String
/*      */     //   270	7	8	value	String
/*      */     //   588	18	8	ex	java.util.MissingResourceException
/*      */     //   624	18	8	e	java.io.FileNotFoundException
/*      */     //   58	7	9	value	String
/*      */     //   214	1	9	localMissingResourceException1	java.util.MissingResourceException
/*      */     //   284	294	9	st	java.util.StringTokenizer
/*      */     //   72	132	10	st	java.util.StringTokenizer
/*      */     //   287	20	10	res	String
/*      */     //   82	109	11	res	String
/*      */     //   290	278	11	fis	java.io.FileInputStream
/*      */     //   91	11	12	is	InputStream
/*      */     //   331	152	12	ex	CertificateException
/*      */     //   116	50	13	ex	CertificateException
/*      */     //   334	196	13	baos	java.io.ByteArrayOutputStream
/*      */     //   360	27	14	array	byte[]
/*      */     //   433	62	14	ex2	Exception
/*      */     //   369	25	15	leidos	int
/*      */     //   413	6	16	b64	java.io.ByteArrayInputStream
/*      */     //   514	13	17	localObject1	Object
/*      */     //   509	1	18	localException1	Exception
/*      */     //   524	1	18	localException2	Exception
/*      */     //   537	1	18	localException3	Exception
/*      */     //   552	13	19	localObject2	Object
/*      */     //   547	1	20	localException4	Exception
/*      */     //   562	1	20	localException5	Exception
/*      */     //   575	1	20	localException6	Exception
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   98	113	116	java/security/cert/CertificateException
/*      */     //   52	211	214	java/util/MissingResourceException
/*      */     //   313	328	331	java/security/cert/CertificateException
/*      */     //   336	430	433	java/lang/Exception
/*      */     //   501	506	509	java/lang/Exception
/*      */     //   336	501	514	finally
/*      */     //   516	521	524	java/lang/Exception
/*      */     //   529	534	537	java/lang/Exception
/*      */     //   539	544	547	java/lang/Exception
/*      */     //   313	539	552	finally
/*      */     //   554	559	562	java/lang/Exception
/*      */     //   567	572	575	java/lang/Exception
/*      */     //   264	585	588	java/util/MissingResourceException
/*      */     //   264	585	624	java/io/FileNotFoundException
/*      */     //   678	695	698	java/security/InvalidAlgorithmParameterException
/*      */     //   678	695	757	java/security/NoSuchAlgorithmException
/*      */   }
/*      */   
/*      */   public CertPath getCertPath(X509Certificate cert)
/*      */     throws UnknownTrustException
/*      */   {
/*  916 */     Vector<X509Certificate> certsChain = new Vector();
/*  917 */     certsChain.add(cert);
/*      */     
/*      */ 
/*  920 */     ArrayList<CertStore> arrayStores = new ArrayList();
/*  921 */     arrayStores.add(this.issuersCerts);
/*  922 */     arrayStores.add(this.certsCerts);
/*  923 */     arrayStores.add(this.issuersOCSP);
/*  924 */     arrayStores.add(this.certsOCSP);
/*  925 */     arrayStores.add(this.issuersCRL);
/*  926 */     arrayStores.add(this.issuersTSA);
/*  927 */     arrayStores.add(this.certsTSA);
/*      */     
/*      */ 
/*  930 */     X509CertSelector certSelector = new X509CertSelector();
/*  931 */     CertStore cs = null;
/*  932 */     X509Certificate certToValidate = cert;
/*  933 */     X509Certificate issuer = null;
/*  934 */     Iterator<? extends Certificate> it = null;
/*  935 */     boolean chainCompleted = false;
/*      */     
/*      */ 
/*  938 */     for (int i = 0; (i < arrayStores.size()) && (!chainCompleted); i++) {
/*  939 */       cs = (CertStore)arrayStores.get(i);
/*  940 */       int chainLenght = 0;
/*  941 */       label250: for (; (chainLenght != certsChain.size()) && (cs != null); 
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  970 */           it.hasNext())
/*      */       {
/*  943 */         chainLenght = certsChain.size();
/*      */         
/*      */         try
/*      */         {
/*  947 */           certToValidate.verify(certToValidate.getPublicKey());
/*      */           
/*  949 */           chainCompleted = true;
/*      */ 
/*      */         }
/*      */         catch (Exception localException)
/*      */         {
/*  954 */           certSelector.setSubject(certToValidate.getIssuerX500Principal());
/*      */           
/*      */           try
/*      */           {
/*  958 */             Collection<? extends Certificate> preselCerts = cs.getCertificates(certSelector);
/*  959 */             if (preselCerts == null) break label250;
/*  960 */             it = preselCerts.iterator();
/*      */ 
/*      */           }
/*      */           catch (CertStoreException ex)
/*      */           {
/*      */ 
/*  966 */             throw new UnknownTrustException();
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*  971 */         issuer = (X509Certificate)it.next();
/*      */         try {
/*  973 */           certToValidate.verify(issuer.getPublicKey());
/*      */           
/*  975 */           certsChain.add(issuer);
/*  976 */           certToValidate = issuer;
/*      */         }
/*      */         catch (Exception localException1) {}
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  986 */     if (!chainCompleted) {
/*  987 */       throw new UnknownTrustException(I18N.getLocalMessage("i18n.mityc.trust.props.23", new Object[] { cert.getSubjectX500Principal().getName() + " -issuer:  " + cert.getIssuerDN() }));
/*      */     }
/*      */     
/*      */ 
/*  991 */     CertPath cp = null;
/*      */     try {
/*  993 */       CertificateFactory cf = CertificateFactory.getInstance("X.509");
/*  994 */       cp = cf.generateCertPath(certsChain);
/*      */     } catch (CertificateException ex) {
/*  996 */       throw new UnknownTrustException();
/*      */     }
/*      */     
/*  999 */     return cp;
/*      */   }
/*      */   
/*      */   public Vector<X509Certificate> getTrustedCAs(TrusterType type) {
/* 1003 */     Vector<X509Certificate> trustedCerts = new Vector();
/* 1004 */     if (type == null) {
/* 1005 */       trustedCerts.addAll(extractAllCerts(this.certsCerts));
/* 1006 */       trustedCerts.addAll(extractAllCerts(this.issuersCerts));
/* 1007 */       trustedCerts.addAll(extractAllCerts(this.certsOCSP));
/* 1008 */       trustedCerts.addAll(extractAllCerts(this.issuersOCSP));
/* 1009 */       trustedCerts.addAll(extractAllCerts(this.certsTSA));
/* 1010 */       trustedCerts.addAll(extractAllCerts(this.issuersTSA));
/* 1011 */       trustedCerts.addAll(extractAllCerts(this.issuersCRL));
/* 1012 */     } else if (TrusterType.TRUSTER_SIGNCERTS_CERTS.equals(type)) {
/* 1013 */       trustedCerts.addAll(extractAllCerts(this.certsCerts));
/* 1014 */     } else if (TrusterType.TRUSTER_SIGNCERTS_ISSUER.equals(type)) {
/* 1015 */       trustedCerts.addAll(extractAllCerts(this.issuersCerts));
/* 1016 */     } else if (TrusterType.TRUSTER_OCSP_CERTS.equals(type)) {
/* 1017 */       trustedCerts.addAll(extractAllCerts(this.certsOCSP));
/* 1018 */     } else if (TrusterType.TRUSTER_OCSP_ISSUER.equals(type)) {
/* 1019 */       trustedCerts.addAll(extractAllCerts(this.issuersOCSP));
/* 1020 */     } else if (TrusterType.TRUSTER_TSA_CERTS.equals(type)) {
/* 1021 */       trustedCerts.addAll(extractAllCerts(this.certsTSA));
/* 1022 */     } else if (TrusterType.TRUSTER_TSA_ISSUER.equals(type)) {
/* 1023 */       trustedCerts.addAll(extractAllCerts(this.issuersTSA));
/* 1024 */     } else if (TrusterType.TRUSTER_CRL_ISSUER.equals(type)) {
/* 1025 */       trustedCerts.addAll(extractAllCerts(this.issuersCRL));
/*      */     } else {
/* 1027 */       LOG.debug("No se reconoció el tipo indicado: " + type);
/*      */     }
/*      */     
/* 1030 */     return trustedCerts;
/*      */   }
/*      */   
/*      */   private Vector<X509Certificate> extractAllCerts(CertStore cs) {
/* 1034 */     Vector<X509Certificate> trustedCerts = new Vector();
/*      */     
/* 1036 */     if (cs != null) {
/* 1037 */       Collection<? extends Certificate> certs = null;
/*      */       try {
/* 1039 */         certs = cs.getCertificates(null);
/*      */       } catch (CertStoreException e) {
/* 1041 */         if (LOG.isDebugEnabled()) {
/* 1042 */           LOG.debug("", e);
/*      */         }
/* 1044 */         return trustedCerts;
/*      */       }
/* 1046 */       if (certs != null) {
/* 1047 */         Iterator<? extends Certificate> it2 = certs.iterator();
/* 1048 */         while (it2.hasNext()) {
/*      */           try {
/* 1050 */             trustedCerts.add((X509Certificate)it2.next());
/*      */           } catch (Exception e) {
/* 1052 */             if (LOG.isDebugEnabled()) {
/* 1053 */               LOG.debug("", e);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1061 */     return trustedCerts;
/*      */   }
/*      */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibTrust-1.1.7.jar!\es\mityc\javasign\trust\PropsTruster.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */