/*     */ package es.mityc.javasign.trust;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrustExtendFactory
/*     */   extends TrustFactory
/*     */ {
/*  49 */   private static final Log LOG = LogFactory.getLog(TrustExtendFactory.class);
/*     */   
/*  51 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibTrust");
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String TRUSTER_PROPS_SIGNCERTS = ".SignCerts";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String TRUSTER_PROPS_CRLS = ".CRLEmisor";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String TRUSTER_PROPS_OCSP = ".OCSPProducer";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String TRUSTER_PROPS_TSA = ".TSProducer";
/*     */   
/*     */ 
/*     */   private static final String TRUSTER_PROPS_ALL = ".All";
/*     */   
/*     */ 
/*     */ 
/*     */   protected static TrustFactory newInstance()
/*     */   {
/*  76 */     return new TrustExtendFactory();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ITrustSignCerts getSignCertsTruster(String prefix)
/*     */   {
/*  90 */     String clave = prefix != null ? prefix + ".SignCerts" : ".SignCerts";
/*  91 */     TrustAbstract res = getTrusterSuper(clave);
/*  92 */     if (res != null) {
/*  93 */       if ((res instanceof ITrustSignCerts)) {
/*  94 */         return (ITrustSignCerts)res;
/*     */       }
/*  96 */       LOG.error(I18N.getLocalMessage("i18n.mityc.trust.1"));
/*     */     }
/*     */     
/*  99 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ITrustCRLEmisor getCRLTruster(String prefix)
/*     */   {
/* 111 */     String clave = prefix != null ? prefix + ".CRLEmisor" : ".CRLEmisor";
/* 112 */     TrustAbstract res = getTrusterSuper(clave);
/* 113 */     if (res != null) {
/* 114 */       if ((res instanceof ITrustCRLEmisor)) {
/* 115 */         return (ITrustCRLEmisor)res;
/*     */       }
/* 117 */       LOG.error(I18N.getLocalMessage("i18n.mityc.trust.2"));
/*     */     }
/*     */     
/* 120 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ITrustOCSPProducer getOCSPTruster(String prefix)
/*     */   {
/* 132 */     String clave = prefix != null ? prefix + ".OCSPProducer" : ".OCSPProducer";
/* 133 */     TrustAbstract res = getTrusterSuper(clave);
/* 134 */     if (res != null) {
/* 135 */       if ((res instanceof ITrustOCSPProducer)) {
/* 136 */         return (ITrustOCSPProducer)res;
/*     */       }
/* 138 */       LOG.error(I18N.getLocalMessage("i18n.mityc.trust.3"));
/*     */     }
/*     */     
/* 141 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ITrustTSProducer getTSATruster(String prefix)
/*     */   {
/* 153 */     String clave = prefix != null ? prefix + ".TSProducer" : ".TSProducer";
/* 154 */     TrustAbstract res = getTrusterSuper(clave);
/* 155 */     if (res != null) {
/* 156 */       if ((res instanceof ITrustTSProducer)) {
/* 157 */         return (ITrustTSProducer)res;
/*     */       }
/* 159 */       LOG.error(I18N.getLocalMessage("i18n.mityc.trust.4"));
/*     */     }
/*     */     
/* 162 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TrustAbstract getTrusterSuper(String key)
/*     */   {
/* 171 */     return super.getTruster(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TrustAbstract getTruster(String key)
/*     */   {
/* 184 */     String clave = key != null ? key + ".All" : ".All";
/* 185 */     TrustAbstract res = getTrusterSuper(clave);
/* 186 */     if (res != null) {
/* 187 */       if ((res instanceof TrustAdapter)) {
/* 188 */         return (TrustAdapter)res;
/*     */       }
/* 190 */       LOG.error(I18N.getLocalMessage("i18n.mityc.trust.4"));
/*     */     }
/*     */     
/* 193 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibTrust-1.1.7.jar!\es\mityc\javasign\trust\TrustExtendFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */