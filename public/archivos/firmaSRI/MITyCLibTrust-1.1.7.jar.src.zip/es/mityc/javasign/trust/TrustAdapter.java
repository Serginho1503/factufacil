/*    */ package es.mityc.javasign.trust;
/*    */ 
/*    */ import java.security.cert.CertPath;
/*    */ import java.security.cert.X509CRL;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.bouncycastle.ocsp.OCSPResp;
/*    */ import org.bouncycastle.tsp.TimeStampToken;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TrustAdapter
/*    */   extends TrustAbstract
/*    */   implements ITrustCRLEmisor, ITrustOCSPProducer, ITrustSignCerts, ITrustTSProducer
/*    */ {
/* 35 */   private static Log logger = LogFactory.getLog(TrustAdapter.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void isTrusted(Object data)
/*    */     throws TrustException
/*    */   {
/* 46 */     if ((data instanceof CertPath)) {
/* 47 */       isTrusted((CertPath)data);
/* 48 */     } else if ((data instanceof TimeStampToken)) {
/* 49 */       isTrusted((TimeStampToken)data);
/* 50 */     } else if ((data instanceof X509CRL)) {
/* 51 */       isTrusted((X509CRL)data);
/* 52 */     } else if ((data instanceof OCSPResp)) {
/* 53 */       isTrusted((OCSPResp)data);
/*    */     } else {
/* 55 */       if (logger.isDebugEnabled())
/* 56 */         logger.debug("No se pudo validar la confianza porque no se reconoce el tipo indicado: " + (data != null ? data.getClass() : "Tipo nulo"));
/* 57 */       throw new UnknownTrustException();
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibTrust-1.1.7.jar!\es\mityc\javasign\trust\TrustAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */