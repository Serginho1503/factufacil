/*     */ package es.mityc.javasign.trust;
/*     */ 
/*     */ import java.security.cert.CertPath;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509CRL;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import org.bouncycastle.ocsp.OCSPResp;
/*     */ import org.bouncycastle.tsp.TimeStampToken;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AllTrusted
/*     */   extends TrustAdapter
/*     */ {
/*  37 */   private static AllTrusted instance = new AllTrusted();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void isTrusted(X509CRL crl)
/*     */     throws TrustException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void isTrusted(OCSPResp ocsp)
/*     */     throws TrustException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void isTrusted(CertPath certs)
/*     */     throws TrustException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void isTrusted(TimeStampToken tst)
/*     */     throws TrustException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static TrustAbstract getInstance()
/*     */   {
/*  81 */     return instance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CertPath getCertPath(X509Certificate cert)
/*     */     throws UnknownTrustException
/*     */   {
/*  90 */     ArrayList<X509Certificate> list = new ArrayList();
/*  91 */     list.add(cert);
/*     */     
/*  93 */     CertPath certPath = null;
/*     */     try {
/*  95 */       CertificateFactory cf = CertificateFactory.getInstance("X509");
/*  96 */       certPath = cf.generateCertPath(list);
/*     */     } catch (CertificateException e) {
/*  98 */       throw new UnknownTrustException(e.getMessage(), e);
/*     */     }
/*     */     
/* 101 */     return certPath;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibTrust-1.1.7.jar!\es\mityc\javasign\trust\AllTrusted.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */