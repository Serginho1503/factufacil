/*     */ package es.mityc.javasign.trust;
/*     */ 
/*     */ import es.mityc.crypto.symetric.TripleDESManager;
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Writer;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Utils
/*     */ {
/*  41 */   private static II18nManager i18n = I18nFactory.getI18nManager("MITyCLibTrust");
/*     */   
/*  43 */   private static byte[] pass = { 100, 87, 39, 78, 66, 55, 100, 75, 77, 114, 
/*  44 */     97, 85, 35, 119, 53, 64, 109, 98, 88, 37, 
/*  45 */     123, 44, 83, 88, 51, 103, 95, 94, 70, 40, 
/*  46 */     48, 104, 82, 66, 60, 70, 74, 118, 36, 55, 
/*  47 */     105, 98, 37, 73, 71, 34, 80, 75, 67, 63, 
/*  48 */     87, 114, 39 };
/*     */   
/*     */   public static void setPass(byte[] password) {
/*  51 */     pass = password;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getMD5(X509Certificate cert)
/*     */     throws Exception
/*     */   {
/*  62 */     MessageDigest certDigest = MessageDigest.getInstance("MD5");
/*  63 */     byte[] digestByte = certDigest.digest(cert.getEncoded());
/*  64 */     StringBuffer sb = new StringBuffer("");
/*  65 */     for (int i = 0; i < digestByte.length; i++) {
/*  66 */       sb.append(Integer.toString((digestByte[i] & 0xFF) + 256, 16).substring(1));
/*     */     }
/*  68 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void protectConf(Properties conf, String path)
/*     */     throws SecurityException
/*     */   {
/*  78 */     if ((pass == null) || ("".equals(new String(pass).trim())) || (conf == null)) {
/*  79 */       throw new SecurityException(i18n.getLocalMessage("i18n.mityc.trust.utils.1"));
/*     */     }
/*     */     
/*     */ 
/*  83 */     TripleDESManager p = new TripleDESManager();
/*     */     
/*     */ 
/*  86 */     String confText = conf.toString();
/*  87 */     confText = confText.substring(1, confText.lastIndexOf('}')).replace(',', '\n').replace('\\', '/');
/*  88 */     byte[] plainProps = confText.getBytes();
/*     */     
/*     */ 
/*  91 */     char[] bufferChar = p.protectTripleDES(plainProps, new String(pass));
/*  92 */     String protectedConf = new String(bufferChar);
/*     */     try
/*     */     {
/*  95 */       File protectedFile = new File(path);
/*  96 */       Writer w = new FileWriter(protectedFile);
/*  97 */       w.write(protectedConf);
/*  98 */       w.close();
/*     */     } catch (IOException e) {
/* 100 */       throw new SecurityException(i18n.getLocalMessage("i18n.mityc.trust.utils.2"), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] recoverConf(String filePath)
/*     */     throws SecurityException
/*     */   {
/* 110 */     if ((pass == null) || ("".equals(new String(pass).trim())) || (!new File(filePath).exists())) {
/* 111 */       throw new SecurityException(i18n.getLocalMessage("i18n.mityc.trust.utils.1"));
/*     */     }
/* 113 */     InputStream bis = null;
/*     */     
/*     */     try
/*     */     {
/* 117 */       File file = new File(filePath);
/* 118 */       bis = new BufferedInputStream(new FileInputStream(file));
/* 119 */       byte[] buffer = null;
/* 120 */       int length = 0;
/* 121 */       int numBytes = 0;
/*     */       
/*     */ 
/* 124 */       long len = file.length();
/* 125 */       if (len > 2147483647L) {
/* 126 */         throw new SecurityException("Fichero de configuración demasiado largo: " + len);
/*     */       }
/*     */       
/*     */ 
/* 130 */       buffer = new byte[(int)file.length()];
/* 131 */       if (buffer.length < 4096) {
/* 132 */         bis.read(buffer, length, (int)file.length());
/*     */       } else {
/* 134 */         int longitud = bis.read(buffer, length, 4096);
/* 135 */         while ((numBytes = longitud) >= 0) {
/* 136 */           length += numBytes;
/* 137 */           longitud = bis.read(buffer, length, 4096);
/*     */         }
/*     */       }
/*     */       byte[] arrayOfByte1;
/* 141 */       if (len < 4L) {
/* 142 */         return buffer;
/*     */       }
/*     */       
/*     */ 
/* 146 */       TripleDESManager p = new TripleDESManager();
/*     */       
/*     */ 
/* 149 */       return p.recoverTripleDES(new String(buffer).toCharArray(), new String(pass));
/*     */     } catch (IOException ex) {
/* 151 */       throw new SecurityException(ex);
/*     */     } finally {
/*     */       try {
/* 154 */         if (bis != null) {
/* 155 */           bis.close();
/*     */         }
/*     */       }
/*     */       catch (Exception localException2) {}
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibTrust-1.1.7.jar!\es\mityc\javasign\trust\Utils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */