package es.mityc.javasign.trust;

import org.bouncycastle.tsp.TimeStampToken;

public abstract interface ITrustTSProducer
{
  public abstract void isTrusted(TimeStampToken paramTimeStampToken)
    throws TrustException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibTrust-1.1.7.jar!\es\mityc\javasign\trust\ITrustTSProducer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */