/*    */ package es.mityc.firmaJava.libreria.xades;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum EnumFormatoFirma
/*    */ {
/* 27 */   XMLSignature, 
/* 28 */   XAdES_BES, 
/* 29 */   XAdES_T, 
/* 30 */   XAdES_C, 
/* 31 */   XAdES_X, 
/* 32 */   XAdES_XL, 
/* 33 */   PKCS7;
/*    */   
/*    */   public static String getName(EnumFormatoFirma tipo) {
/* 36 */     switch (tipo) {
/*    */     case PKCS7: 
/* 38 */       return "XAdES-BES";
/*    */     case XAdES_BES: 
/* 40 */       return "XAdES-BES";
/*    */     case XAdES_C: 
/* 42 */       return "XAdES-T";
/*    */     case XAdES_T: 
/* 44 */       return "XAdES-C";
/*    */     case XAdES_X: 
/* 46 */       return "XAdES-X";
/*    */     case XAdES_XL: 
/* 48 */       return "XAdES-XL";
/*    */     case XMLSignature: 
/* 50 */       return "PKCS-7";
/*    */     }
/* 52 */     return "XAdES-BES";
/*    */   }
/*    */   
/*    */   public static EnumFormatoFirma parse(String tipo)
/*    */   {
/* 57 */     if ((tipo != null) && (tipo.length() > 0)) {
/* 58 */       if (tipo.equals("XAdES-BES"))
/* 59 */         return XAdES_BES;
/* 60 */       if (tipo.equals("XAdES-BES"))
/* 61 */         return XAdES_BES;
/* 62 */       if (tipo.equals("XAdES-T"))
/* 63 */         return XAdES_T;
/* 64 */       if (tipo.equals("XAdES-C"))
/* 65 */         return XAdES_C;
/* 66 */       if (tipo.equals("XAdES-X"))
/* 67 */         return XAdES_X;
/* 68 */       if (tipo.equals("XAdES-XL"))
/* 69 */         return XAdES_XL;
/* 70 */       if (tipo.equals("PKCS-7")) {
/* 71 */         return PKCS7;
/*    */       }
/* 73 */       return null;
/*    */     }
/*    */     
/* 76 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\EnumFormatoFirma.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */