package es.mityc.javasign.i18n;

import java.util.Locale;

public abstract interface II18nManager
{
  public abstract void init(String paramString, Locale paramLocale)
    throws DictionaryUnknownException;
  
  public abstract String getLocalMessage(String paramString);
  
  public abstract String getLocalMessage(String paramString, Object... paramVarArgs);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\i18n\II18nManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */