package es.mityc.javasign.i18n;

import java.util.Locale;

public abstract interface II18nFactory
{
  public abstract II18nManager getI18nManager(String paramString, Locale paramLocale);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\i18n\II18nFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */