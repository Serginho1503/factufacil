/*     */ package es.mityc.javasign.i18n;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class I18nFactory
/*     */ {
/*  63 */   private static final Log LOG = LogFactory.getLog(I18nFactory.class);
/*     */   
/*     */ 
/*     */   private static final String PATH_RES_I18N_PROPS = "i18n/i18n.properties";
/*     */   
/*     */ 
/*     */   private static final String CLASS_FACTORY = "i18n.factory.class";
/*     */   
/*     */ 
/*     */   private static final String CLASS_MANAGER = "i18n.manager.class";
/*     */   
/*     */ 
/*     */   private static final String LOCALE_DEFAULT = "i18n.locale.default";
/*     */   
/*     */   private static final String METHOD_NEW_INSTANCE = "newInstance";
/*     */   
/*     */   private static final String STRING_SPACE = "_";
/*     */   
/*     */   private static final String STRING_EMPTY = "";
/*     */   
/*     */   private static final String WARN_UNKNOWN_LOCALE = "Locale no reconocido";
/*     */   
/*     */   private static final String NOT_CONFIGURATED_LOCALE = "No se ha configurado un Locale específico";
/*     */   
/*     */   private static final String ERROR_CONFIGURATION_FACTORY = "No se ha configurado ninguna factoría propia para la internacionalización";
/*     */   
/*     */   private static final String ERROR_IMPLEMENTED_CLASS = "Clase indicada no tiene constructor nulo: {0}";
/*     */   
/*     */   private static final String ERROR_CASTING_FACTORY = "Clase indicada no es del tipo II18nFactory: {0}";
/*     */   
/*     */   private static final String ERROR_NOT_AVALAIBLE_CLASS = "Clase indicada no existe: {0}";
/*     */   
/*     */   private static final String ERROR_ACCESING_CLASS = "Clase indicada no es accesible: {0}";
/*     */   
/*     */   private static final String ERROR_INSTANTIATION_FACTORY = "Error creando instancia de factoría de internacionalización: {0}";
/*     */   
/*     */   private static final String NOT_I18N_MANAGER_CONFIGURATED = "No hay manager de internacionalización configurado";
/*     */   
/*     */   private static final String NOTAVALAIBLE_FILE_I18N_PROPS = "No hay fichero de configuración específico";
/*     */   
/*     */   private static final String ERROR_INIT_MANAGER = "Error en la inicialización del manager con el diccionario {0}";
/*     */   
/*     */   private static final String ERROR_CASTING_MANAGER = "Clase indicada no es del tipo II18nManager: {0}";
/*     */   
/*     */   private static final String ERROR_INSTANTIATION_MANAGER = "Error creando instancia de manager de internacionalización: {0}";
/*     */   
/* 109 */   private static Locale locale = null;
/*     */   
/* 111 */   private static II18nFactory factory = null;
/*     */   
/* 113 */   private static Constructor<? extends II18nManager> classManager = null;
/*     */   
/* 115 */   private static HashMap<String, ManagerCached> cache = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/* 122 */     Properties rb = null;
/*     */     try {
/* 124 */       InputStream is = getClassLoader().getResourceAsStream("i18n/i18n.properties");
/* 125 */       if (is != null) {
/* 126 */         rb = new Properties();
/* 127 */         rb.load(is);
/*     */       } else {
/* 129 */         LOG.trace("No hay fichero de configuración específico");
/*     */       }
/*     */     } catch (IOException ex) {
/* 132 */       LOG.trace("No hay fichero de configuración específico");
/*     */     }
/* 134 */     loadFactory(rb);
/*     */     
/* 136 */     if ((factory == null) && (rb != null))
/*     */     {
/* 138 */       String classnameManager = rb.getProperty("i18n.manager.class");
/* 139 */       if (classnameManager != null) {
/* 140 */         if ("".equals(classnameManager.trim())) {
/* 141 */           classnameManager = null;
/*     */         } else {
/* 143 */           loadManager(classnameManager);
/*     */         }
/*     */       }
/* 146 */       if (classManager == null) {
/* 147 */         LOG.trace("No hay manager de internacionalización configurado");
/*     */       }
/*     */       
/* 150 */       loadLocale(rb);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ClassLoader getClassLoader()
/*     */   {
/*     */     try
/*     */     {
/* 167 */       ClassLoader cl = (ClassLoader)AccessController.doPrivileged(new PrivilegedAction() {
/*     */         public ClassLoader run() {
/* 169 */           ClassLoader classLoader = null;
/*     */           try {
/* 171 */             classLoader = Thread.currentThread().getContextClassLoader();
/*     */           }
/*     */           catch (SecurityException localSecurityException) {}
/* 174 */           return classLoader;
/*     */         }
/*     */       });
/* 177 */       if (cl != null) {
/* 178 */         return cl;
/*     */       }
/*     */     }
/*     */     catch (Exception localException) {}
/* 182 */     return I18nFactory.class.getClassLoader();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void loadFactory(Properties rb)
/*     */   {
/* 192 */     if (rb != null) {
/* 193 */       String classname = rb.getProperty("i18n.factory.class");
/* 194 */       if ((classname != null) && (!"".equals(classname.trim()))) {
/*     */         try {
/* 196 */           ClassLoader cl = getClassLoader();
/* 197 */           Class<?> classFactory = null;
/* 198 */           if (cl != null) {
/* 199 */             classFactory = cl.loadClass(classname);
/*     */           } else {
/* 201 */             classFactory = Class.forName(classname);
/*     */           }
/* 203 */           if (classFactory == null) return;
/* 204 */           Method method = classFactory.getDeclaredMethod("newInstance", new Class[0]);
/* 205 */           Class<?> returnType = method.getReturnType();
/* 206 */           if ((returnType == null) || (!returnType.isAssignableFrom(II18nFactory.class))) return;
/* 207 */           factory = (II18nFactory)method.invoke(null, new Object[0]);
/*     */         }
/*     */         catch (IllegalAccessException ex)
/*     */         {
/* 211 */           LOG.error(getFormatedMessage("Clase indicada no es accesible: {0}", new Object[] { classname }), ex);
/*     */         } catch (ClassNotFoundException ex) {
/* 213 */           LOG.error(getFormatedMessage("Clase indicada no existe: {0}", new Object[] { classname }), ex);
/*     */         } catch (ClassCastException ex) {
/* 215 */           LOG.error(getFormatedMessage("Clase indicada no es del tipo II18nFactory: {0}", new Object[] { classname }), ex);
/*     */         } catch (SecurityException ex) {
/* 217 */           LOG.error(getFormatedMessage("Clase indicada no es accesible: {0}", new Object[] { classname }), ex);
/*     */         } catch (NoSuchMethodException ex) {
/* 219 */           LOG.error(getFormatedMessage("Clase indicada no tiene constructor nulo: {0}", new Object[] { classname }), ex);
/*     */         } catch (IllegalArgumentException ex) {
/* 221 */           LOG.error(getFormatedMessage("Clase indicada no tiene constructor nulo: {0}", new Object[] { classname }), ex);
/*     */         } catch (InvocationTargetException ex) {
/* 223 */           LOG.error(getFormatedMessage("Error creando instancia de factoría de internacionalización: {0}", new Object[] { classname }), ex);
/*     */         }
/*     */       } else {
/* 226 */         LOG.trace("No se ha configurado ninguna factoría propia para la internacionalización");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static void loadManager(String classname)
/*     */   {
/*     */     try
/*     */     {
/* 237 */       ClassLoader cl = getClassLoader();
/* 238 */       Class<?> classTemp = null;
/* 239 */       if (cl != null) {
/* 240 */         classTemp = cl.loadClass(classname);
/*     */       } else {
/* 242 */         classTemp = Class.forName(classname);
/*     */       }
/* 244 */       if (classTemp != null) {
/* 245 */         Class<? extends II18nManager> classI18n = classTemp.asSubclass(II18nManager.class);
/* 246 */         classManager = classI18n.getConstructor(null);
/*     */       }
/*     */     } catch (ClassNotFoundException ex) {
/* 249 */       LOG.error(getFormatedMessage("Clase indicada no existe: {0}", new Object[] { classname }), ex);
/*     */     } catch (ClassCastException ex) {
/* 251 */       LOG.error(getFormatedMessage("Clase indicada no es del tipo II18nFactory: {0}", new Object[] { classname }), ex);
/*     */     } catch (SecurityException ex) {
/* 253 */       LOG.error(getFormatedMessage("Clase indicada no es accesible: {0}", new Object[] { classname }), ex);
/*     */     } catch (NoSuchMethodException ex) {
/* 255 */       LOG.error(getFormatedMessage("Clase indicada no tiene constructor nulo: {0}", new Object[] { classname }), ex);
/*     */     } catch (IllegalArgumentException ex) {
/* 257 */       LOG.error(getFormatedMessage("Clase indicada no tiene constructor nulo: {0}", new Object[] { classname }), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void loadLocale(Properties rb)
/*     */   {
/* 267 */     if (rb != null) {
/* 268 */       String localeStr = rb.getProperty("i18n.locale.default");
/* 269 */       StringTokenizer st; if ((localeStr != null) && (!"".equals(localeStr.trim())))
/* 270 */         st = new StringTokenizer(localeStr, "_");
/* 271 */       switch (st.countTokens()) {
/* 272 */       case 1:  setLocale(new Locale(st.nextToken())); break;
/* 273 */       case 2:  setLocale(new Locale(st.nextToken(), st.nextToken())); break;
/* 274 */       case 3:  setLocale(new Locale(st.nextToken(), st.nextToken(), st.nextToken())); break;
/* 275 */       default:  LOG.warn("Locale no reconocido");setLocale(null);
/*     */         
/* 277 */         break;
/* 278 */         setLocale(null);
/* 279 */         LOG.trace("No se ha configurado un Locale específico");
/*     */         
/* 281 */         break; }
/* 282 */     } else { setLocale(null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static II18nManager getI18nManager(String dictionary)
/*     */   {
/* 295 */     return getI18nManager(dictionary, locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static II18nManager getI18nManager(String dictionary, Locale specificLocale)
/*     */   {
/* 307 */     if (factory != null) {
/* 308 */       return factory.getI18nManager(dictionary, specificLocale);
/*     */     }
/*     */     
/* 311 */     synchronized (cache) {
/* 312 */       ManagerCached mc = (ManagerCached)cache.get(dictionary);
/* 313 */       if ((mc == null) || (!mc.isSameLocale(specificLocale))) {
/* 314 */         mc = new ManagerCached(instantiateManager(dictionary, specificLocale), specificLocale);
/* 315 */         cache.put(dictionary, mc);
/*     */       }
/* 317 */       return mc.getI18nCached();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static II18nManager instantiateManager(String dictionary, Locale specificLocale)
/*     */   {
/* 332 */     II18nManager manager = null;
/* 333 */     if (classManager != null) {
/*     */       try {
/* 335 */         manager = (II18nManager)classManager.newInstance(new Object[0]);
/*     */       } catch (InstantiationException ex) {
/* 337 */         LOG.error(getFormatedMessage("Error creando instancia de manager de internacionalización: {0}", new Object[] { classManager }), ex);
/* 338 */         manager = new I18nDumbManager();
/*     */       } catch (IllegalAccessException ex) {
/* 340 */         LOG.error(getFormatedMessage("Clase indicada no es accesible: {0}", new Object[] { classManager }), ex);
/* 341 */         manager = new I18nDumbManager();
/*     */       } catch (ClassCastException ex) {
/* 343 */         LOG.error(getFormatedMessage("Clase indicada no es del tipo II18nManager: {0}", new Object[] { classManager }), ex);
/* 344 */         manager = new I18nDumbManager();
/*     */       } catch (SecurityException ex) {
/* 346 */         LOG.error(getFormatedMessage("Clase indicada no es accesible: {0}", new Object[] { classManager }), ex);
/* 347 */         manager = new I18nDumbManager();
/*     */       } catch (IllegalArgumentException ex) {
/* 349 */         LOG.error(getFormatedMessage("Clase indicada no tiene constructor nulo: {0}", new Object[] { classManager }), ex);
/* 350 */         manager = new I18nDumbManager();
/*     */       } catch (InvocationTargetException ex) {
/* 352 */         LOG.error(getFormatedMessage("Error creando instancia de manager de internacionalización: {0}", new Object[] { classManager }), ex);
/* 353 */         manager = new I18nDumbManager();
/*     */       }
/*     */     } else {
/* 356 */       manager = new I18nDefaultManager();
/*     */     }
/*     */     try
/*     */     {
/* 360 */       manager.init(dictionary, specificLocale);
/*     */     } catch (DictionaryUnknownException ex) {
/* 362 */       LOG.error(getFormatedMessage("Error en la inicialización del manager con el diccionario {0}", new Object[] { dictionary }), ex);
/*     */     }
/* 364 */     return manager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setLocale(Locale newLocale)
/*     */   {
/* 373 */     synchronized (I18nFactory.class) {
/* 374 */       locale = newLocale;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String getFormatedMessage(String message, Object... varargs)
/*     */   {
/* 386 */     MessageFormat mf = new MessageFormat(message);
/* 387 */     return mf.format(varargs, new StringBuffer(), null).toString();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\i18n\I18nFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */