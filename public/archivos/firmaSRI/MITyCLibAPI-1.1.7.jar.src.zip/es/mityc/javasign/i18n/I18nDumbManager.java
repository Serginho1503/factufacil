/*    */ package es.mityc.javasign.i18n;
/*    */ 
/*    */ import java.util.Locale;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class I18nDumbManager
/*    */   implements II18nManager
/*    */ {
/*    */   private static final String SPACE = " ";
/*    */   private static final String DUMB_MESSAGE = "I18nDumbManager: no dictionary avalaible: ";
/*    */   private String response;
/*    */   
/*    */   public void init(String dictionary, Locale locale)
/*    */     throws DictionaryUnknownException
/*    */   {
/* 50 */     this.response = ("I18nDumbManager: no dictionary avalaible: " + dictionary);
/* 51 */     if (locale != null) {
/* 52 */       this.response = (this.response + " " + locale);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getLocalMessage(String message)
/*    */   {
/* 63 */     return this.response + " " + message;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getLocalMessage(String message, Object... varargs)
/*    */   {
/* 74 */     return this.response + " " + message;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\i18n\I18nDumbManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */