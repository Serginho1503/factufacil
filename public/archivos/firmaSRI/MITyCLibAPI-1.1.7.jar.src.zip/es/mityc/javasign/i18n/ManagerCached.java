/*    */ package es.mityc.javasign.i18n;
/*    */ 
/*    */ import java.util.Locale;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ManagerCached
/*    */ {
/*    */   private II18nManager managerCached;
/*    */   private Locale localeCached;
/*    */   
/*    */   public ManagerCached(II18nManager manager, Locale i18nLocale)
/*    */   {
/* 36 */     this.managerCached = manager;
/* 37 */     this.localeCached = i18nLocale;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isSameLocale(Locale otherLocale)
/*    */   {
/* 45 */     if (otherLocale == null) {
/* 46 */       if (this.localeCached == null) {
/* 47 */         return true;
/*    */       }
/* 49 */       return false;
/*    */     }
/* 51 */     return otherLocale.equals(this.localeCached);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public II18nManager getI18nCached()
/*    */   {
/* 58 */     return this.managerCached;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\i18n\ManagerCached.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */