/*     */ package es.mityc.javasign.i18n;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Locale;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class I18nDefaultManager
/*     */   implements II18nManager
/*     */ {
/*     */   static final long serialVersionUID = 1L;
/*  39 */   private static final Log LOG = LogFactory.getLog(I18nDefaultManager.class);
/*     */   
/*     */ 
/*     */   protected static final String BASE_PATH = "i18n/dictionaries/";
/*     */   
/*     */ 
/*     */   private static final String ILLFORMED_KEY = "Clave malformada: {0}";
/*     */   
/*     */   private static final String NOT_AVALAIBLE_KEY = "No existe clave {0}";
/*     */   
/*  49 */   protected ResourceBundle rb = null;
/*     */   
/*  51 */   protected Locale locale = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void init(String dictionary, Locale specificLocale)
/*     */     throws DictionaryUnknownException
/*     */   {
/*     */     try
/*     */     {
/*  72 */       if (specificLocale == null) {
/*  73 */         this.locale = Locale.getDefault();
/*     */       } else {
/*  75 */         this.locale = ((Locale)specificLocale.clone());
/*     */       }
/*  77 */       this.rb = ResourceBundle.getBundle("i18n/dictionaries/" + dictionary, this.locale);
/*     */     } catch (MissingResourceException ex) {
/*  79 */       throw new DictionaryUnknownException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLocalMessage(String message)
/*     */   {
/*     */     try
/*     */     {
/*  91 */       return findMessage(message);
/*     */     } catch (MissingResourceException ex) {
/*  93 */       LOG.warn(getFormatedMessage("No existe clave {0}", new Object[] { message }));
/*     */     }
/*  95 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String findMessage(String key)
/*     */   {
/* 105 */     if (this.rb != null) {
/* 106 */       return this.rb.getString(key);
/*     */     }
/* 108 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String getFormatedMessage(String message, Object... varargs)
/*     */   {
/* 118 */     MessageFormat mf = new MessageFormat(message);
/* 119 */     return mf.format(varargs, new StringBuffer(), null).toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLocalMessage(String message, Object... varargs)
/*     */   {
/*     */     try
/*     */     {
/* 131 */       String res = findMessage(message);
/* 132 */       if (res != null) {
/* 133 */         MessageFormat mf = new MessageFormat(res, this.locale);
/* 134 */         return mf.format(varargs, new StringBuffer(), null).toString();
/*     */       }
/*     */     } catch (MissingResourceException ex) {
/* 137 */       LOG.warn(getFormatedMessage("No existe clave {0}", new Object[] { message }));
/*     */     } catch (IllegalArgumentException ex) {
/* 139 */       LOG.warn(getFormatedMessage("Clave malformada: {0}", new Object[] { message }));
/*     */     }
/* 141 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\i18n\I18nDefaultManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */