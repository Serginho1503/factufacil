/*    */ package es.mityc.javasign.i18n;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.MissingResourceException;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class I18nAddendumManager
/*    */   extends I18nDefaultManager
/*    */ {
/*    */   protected static final String ADDENDUM_SUFIX = "_add";
/* 38 */   private ResourceBundle rbAdd = null;
/*    */   
/*    */   public static I18nAddendumManager newInstance() {
/* 41 */     return new I18nAddendumManager();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void init(String dictionary, Locale specificLocale)
/*    */     throws DictionaryUnknownException
/*    */   {
/* 55 */     super.init(dictionary, specificLocale);
/*    */     try
/*    */     {
/* 58 */       this.rbAdd = ResourceBundle.getBundle("i18n/dictionaries/" + dictionary + "_add", this.locale);
/*    */     }
/*    */     catch (MissingResourceException localMissingResourceException) {}
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected String findMessage(String key)
/*    */   {
/* 71 */     if (this.rbAdd != null) {
/*    */       try {
/* 73 */         return this.rbAdd.getString(key);
/*    */       }
/*    */       catch (MissingResourceException localMissingResourceException) {}
/*    */     }
/* 77 */     return super.findMessage(key);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\i18n\I18nAddendumManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */