/*     */ package es.mityc.javasign.pass;
/*     */ 
/*     */ import es.mityc.javasign.utils.HexUtils;
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.Properties;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.crypto.BadPaddingException;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.IllegalBlockSizeException;
/*     */ import javax.crypto.NoSuchPaddingException;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.SecretKeyFactory;
/*     */ import javax.crypto.spec.PBEKeySpec;
/*     */ import javax.crypto.spec.PBEParameterSpec;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PBESecurity
/*     */   implements IPassSecurity
/*     */ {
/*  54 */   private static final Log LOGGER = LogFactory.getLog(PBESecurity.class);
/*     */   
/*     */ 
/*     */   private static final String CONFIG_SEC_CLIENT = "config/security";
/*     */   
/*     */ 
/*     */   private static final String PROP_SEC_SALT = "simplePBE.salt";
/*     */   
/*     */   private static final String PROP_SEC_ITERATION = "simplePBE.iteration";
/*     */   
/*     */   private static final String PROP_SEC_MASTERKEY = "simplePBE.masterkey";
/*     */   
/*  66 */   private byte[] salt = null;
/*     */   
/*  68 */   private int iter = 0;
/*     */   
/*  70 */   private transient String masterPass = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public PBESecurity()
/*     */     throws PassSecurityException
/*     */   {
/*  77 */     init();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PBESecurity(byte[] saltBase, int iteration, String password)
/*     */     throws PassSecurityException
/*     */   {
/*  88 */     this.salt = saltBase;
/*  89 */     this.iter = iteration;
/*  90 */     this.masterPass = new String(password);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PBESecurity(Properties props)
/*     */     throws PassSecurityException
/*     */   {
/*  99 */     init(props);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void init()
/*     */     throws PassSecurityException
/*     */   {
/*     */     try
/*     */     {
/* 108 */       ResourceBundle rb = ResourceBundle.getBundle("config/security");
/* 109 */       init(rb);
/*     */     } catch (MissingResourceException ex) {
/* 111 */       LOGGER.warn("Fichero de configuración de seguridad tiene datos erróneos");
/* 112 */       LOGGER.trace(ex.getMessage(), ex);
/* 113 */       throw new PassSecurityException("Recurso de configuración no disponible: " + ex.getKey());
/*     */     } catch (NumberFormatException ex) {
/* 115 */       LOGGER.warn("Fichero de configuración de seguridad tiene datos erróneos");
/* 116 */       LOGGER.trace(ex.getMessage(), ex);
/* 117 */       throw new PassSecurityException("Formato numérico inadecuado: " + ex.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void init(ResourceBundle rb)
/*     */     throws PassSecurityException
/*     */   {
/*     */     try
/*     */     {
/* 128 */       init(rb.getString("simplePBE.salt"), rb.getString("simplePBE.iteration"), rb.getString("simplePBE.masterkey"));
/*     */     } catch (MissingResourceException ex) {
/* 130 */       LOGGER.warn("Fichero de configuración de seguridad tiene datos erróneos");
/* 131 */       LOGGER.trace(ex.getMessage(), ex);
/* 132 */       throw new PassSecurityException("Recurso de configuración no disponible: " + ex.getKey());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void init(Properties props)
/*     */     throws PassSecurityException
/*     */   {
/*     */     try
/*     */     {
/* 143 */       init(props.getProperty("simplePBE.salt"), props.getProperty("simplePBE.iteration"), props.getProperty("simplePBE.masterkey"));
/*     */     } catch (NullPointerException ex) {
/* 145 */       LOGGER.warn("Fichero de configuración de seguridad tiene datos erróneos");
/* 146 */       LOGGER.trace(ex.getMessage(), ex);
/* 147 */       throw new PassSecurityException("Recurso de configuración no disponible");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void init(String saltStr, String iterStr, String passStr)
/*     */     throws PassSecurityException
/*     */   {
/* 159 */     LOGGER.trace("Inicializando objeto de seguridad");
/*     */     try {
/* 161 */       this.salt = HexUtils.convert(saltStr);
/* 162 */       this.iter = Integer.parseInt(iterStr);
/* 163 */       this.masterPass = new String(passStr);
/*     */     } catch (NumberFormatException ex) {
/* 165 */       LOGGER.warn("Fichero de configuración de seguridad tiene datos erróneos");
/* 166 */       LOGGER.trace(ex.getMessage(), ex);
/* 167 */       throw new PassSecurityException("Formato numérico inadecuado: " + ex.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String protect(String pass)
/*     */     throws PassSecurityException
/*     */   {
/*     */     try
/*     */     {
/* 180 */       PBEParameterSpec pbeParamSpec = new PBEParameterSpec(this.salt, this.iter);
/*     */       
/* 182 */       PBEKeySpec pbeKeySpec = new PBEKeySpec(this.masterPass.toCharArray());
/* 183 */       SecretKeyFactory keyFac = SecretKeyFactory.getInstance("PBEWithMD5AndDES");
/* 184 */       SecretKey pbeKey = keyFac.generateSecret(pbeKeySpec);
/*     */       
/*     */ 
/* 187 */       Cipher pbeCipher = Cipher.getInstance("PBEWithMD5AndDES");
/*     */       
/*     */ 
/* 190 */       pbeCipher.init(1, pbeKey, pbeParamSpec);
/*     */       
/*     */ 
/* 193 */       byte[] cleartext = pass.getBytes();
/*     */       
/*     */ 
/* 196 */       byte[] ciphertext = pbeCipher.doFinal(cleartext);
/*     */       
/* 198 */       return hexData(ciphertext);
/*     */     } catch (NoSuchAlgorithmException ex) {
/* 200 */       throw new PassSecurityException(ex);
/*     */     } catch (InvalidKeySpecException ex) {
/* 202 */       throw new PassSecurityException(ex);
/*     */     } catch (NoSuchPaddingException ex) {
/* 204 */       throw new PassSecurityException(ex);
/*     */     } catch (InvalidKeyException ex) {
/* 206 */       throw new PassSecurityException(ex);
/*     */     } catch (InvalidAlgorithmParameterException ex) {
/* 208 */       throw new PassSecurityException(ex);
/*     */     } catch (IllegalBlockSizeException ex) {
/* 210 */       throw new PassSecurityException(ex);
/*     */     } catch (BadPaddingException ex) {
/* 212 */       throw new PassSecurityException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String hexData(byte[] data)
/*     */   {
/* 222 */     StringBuffer sb = new StringBuffer("{");
/* 223 */     sb.append(HexUtils.convert(data)).append("}");
/* 224 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String recover(String pass)
/*     */     throws PassSecurityException
/*     */   {
/* 234 */     if (pass.startsWith("{")) {
/* 235 */       String dataStr = pass.substring(1, pass.indexOf("}"));
/* 236 */       byte[] data = HexUtils.convert(dataStr);
/*     */       try
/*     */       {
/* 239 */         PBEParameterSpec pbeParamSpec = new PBEParameterSpec(this.salt, this.iter);
/*     */         
/* 241 */         PBEKeySpec pbeKeySpec = new PBEKeySpec(this.masterPass.toCharArray());
/* 242 */         SecretKeyFactory keyFac = SecretKeyFactory.getInstance("PBEWithMD5AndDES");
/* 243 */         SecretKey pbeKey = keyFac.generateSecret(pbeKeySpec);
/*     */         
/*     */ 
/* 246 */         Cipher pbeCipher = Cipher.getInstance("PBEWithMD5AndDES");
/*     */         
/*     */ 
/* 249 */         pbeCipher.init(2, pbeKey, pbeParamSpec);
/*     */         
/*     */ 
/* 252 */         byte[] ciphertext = pbeCipher.doFinal(data);
/*     */         
/* 254 */         return new String(ciphertext);
/*     */       } catch (NoSuchAlgorithmException ex) {
/* 256 */         throw new PassSecurityException(ex);
/*     */       } catch (InvalidKeySpecException ex) {
/* 258 */         throw new PassSecurityException(ex);
/*     */       } catch (NoSuchPaddingException ex) {
/* 260 */         throw new PassSecurityException(ex);
/*     */       } catch (InvalidKeyException ex) {
/* 262 */         throw new PassSecurityException(ex);
/*     */       } catch (InvalidAlgorithmParameterException ex) {
/* 264 */         throw new PassSecurityException(ex);
/*     */       } catch (IllegalBlockSizeException ex) {
/* 266 */         throw new PassSecurityException(ex);
/*     */       } catch (BadPaddingException ex) {
/* 268 */         throw new PassSecurityException(ex);
/*     */       }
/*     */     }
/* 271 */     return pass;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\pass\PBESecurity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */