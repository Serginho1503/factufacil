/*     */ package es.mityc.javasign.pass;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.utils.HexUtils;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PBEFileSecurity
/*     */   extends PBESecurity
/*     */ {
/*  56 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibAPI");
/*     */   
/*     */ 
/*     */   private static final String PROP_FILE_CONF = "filePBE.URI";
/*     */   
/*     */ 
/*     */   private static final String PROP_DEFAULT_FILE = "./pbesec.properties";
/*     */   
/*     */ 
/*     */   private static final String PROP_FILE_SALT = "simplePBE.salt=";
/*     */   
/*     */ 
/*     */   private static final String PROP_FILE_ITERATION = "simplePBE.iteration=";
/*     */   
/*     */ 
/*     */   private static final String PROP_FILE_MASTERKEY = "simplePBE.masterkey=";
/*     */   
/*     */ 
/*     */   private static final int MAX_VALUE_ITER = 4096;
/*     */   
/*     */ 
/*     */   private static final int MAX_SIZE_MASTER_KEY = 20;
/*     */   
/*     */   private static final int MAX_SIZE_BYTES_SALT = 8;
/*     */   
/*     */ 
/*     */   public PBEFileSecurity()
/*     */     throws PassSecurityException
/*     */   {}
/*     */   
/*     */ 
/*     */   public PBEFileSecurity(Properties props)
/*     */     throws PassSecurityException
/*     */   {
/*  90 */     super(props);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void init()
/*     */     throws PassSecurityException
/*     */   {
/* 100 */     init("./pbesec.properties");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void init(String path)
/*     */     throws PassSecurityException
/*     */   {
/*     */     try
/*     */     {
/* 111 */       URI uri = new URI(path);
/* 112 */       if (!uri.isAbsolute()) {
/* 113 */         uri = new File("./").toURI().resolve(uri);
/*     */       }
/* 115 */       InputStream is = null;
/*     */       try {
/* 117 */         is = uri.toURL().openStream();
/*     */       } catch (IOException ex) {
/* 119 */         if ("file".equals(uri.getScheme())) {
/* 120 */           File file = new File(uri);
/* 121 */           if (!file.exists()) {
/* 122 */             file.getParentFile().mkdirs();
/* 123 */             createSecFile(file);
/* 124 */             is = new FileInputStream(file);
/*     */           }
/*     */         }
/*     */       }
/* 128 */       if (is != null) {
/* 129 */         Properties props = new Properties();
/* 130 */         props.load(is);
/* 131 */         super.init(props);
/*     */       } else {
/* 133 */         throw new PassSecurityException(I18N.getLocalMessage("i18n.mityc.api.pass.4", new Object[] { path }));
/*     */       }
/*     */     } catch (URISyntaxException ex) {
/* 136 */       throw new PassSecurityException(ex.getMessage(), ex);
/*     */     } catch (MalformedURLException ex) {
/* 138 */       throw new PassSecurityException(ex.getMessage(), ex);
/*     */     } catch (IOException ex) {
/* 140 */       throw new PassSecurityException(ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void init(Properties props)
/*     */     throws PassSecurityException
/*     */   {
/* 153 */     String file = props.getProperty("filePBE.URI");
/* 154 */     if ((file != null) && (file.trim().length() > 0)) {
/* 155 */       init(file);
/*     */     } else {
/* 157 */       init();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void createSecFile(File file)
/*     */     throws IOException
/*     */   {
/* 167 */     SecureRandom random = null;
/*     */     try {
/* 169 */       random = SecureRandom.getInstance("SHA1PRNG");
/*     */     } catch (NoSuchAlgorithmException ex) {
/* 171 */       throw new IOException(I18N.getLocalMessage("i18n.mityc.api.pass.9", new Object[] { ex.getMessage() }));
/*     */     }
/* 173 */     if (file.createNewFile()) {
/* 174 */       PrintWriter pw = new PrintWriter(file);
/* 175 */       pw.println(I18N.getLocalMessage("i18n.mityc.api.pass.6"));
/* 176 */       pw.print("simplePBE.salt=");
/* 177 */       byte[] data = new byte[8];
/* 178 */       random.nextBytes(data);
/* 179 */       pw.println(HexUtils.convert(data));
/* 180 */       pw.println(I18N.getLocalMessage("i18n.mityc.api.pass.7"));
/* 181 */       pw.print("simplePBE.iteration=");
/* 182 */       pw.println(random.nextInt(4096));
/* 183 */       pw.println(I18N.getLocalMessage("i18n.mityc.api.pass.8"));
/* 184 */       pw.print("simplePBE.masterkey=");
/* 185 */       for (int i = 0; i < 20; i++) {
/* 186 */         char c = (char)(random.nextInt(94) + 33);
/* 187 */         pw.print(c);
/*     */       }
/* 189 */       pw.println();
/* 190 */       pw.flush();
/* 191 */       pw.close();
/*     */     } else {
/* 193 */       throw new IOException(I18N.getLocalMessage("i18n.mityc.api.pass.5", new Object[] { file.getAbsolutePath() }));
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\pass\PBEFileSecurity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */