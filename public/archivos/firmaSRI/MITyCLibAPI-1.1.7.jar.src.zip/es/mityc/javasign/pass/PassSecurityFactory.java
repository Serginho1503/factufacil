/*     */ package es.mityc.javasign.pass;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PassSecurityFactory
/*     */ {
/*  60 */   private static final Log LOGGER = LogFactory.getLog(PassSecurityFactory.class);
/*     */   
/*  62 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibAPI");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  67 */   private List<Properties> props = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private PassSecurityFactory()
/*     */   {
/*  79 */     loadManagers();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void loadManagers()
/*     */   {
/*  87 */     ClassLoader cl = getClassLoader();
/*     */     try {
/*  89 */       Enumeration<URL> en = cl.getResources("META-INF/pass/security.properties");
/*  90 */       this.props = new ArrayList();
/*  91 */       while (en.hasMoreElements()) {
/*  92 */         URL url = (URL)en.nextElement();
/*     */         try {
/*  94 */           InputStream is = url.openStream();
/*  95 */           Properties properties = new Properties();
/*  96 */           properties.load(is);
/*  97 */           this.props.add(properties);
/*     */         } catch (IOException ex) {
/*  99 */           LOGGER.error(I18N.getLocalMessage("i18n.mityc.api.pass.2", new Object[] { url, ex.getMessage() }));
/*     */         }
/*     */       }
/*     */     } catch (IOException ex) {
/* 103 */       LOGGER.error(I18N.getLocalMessage("i18n.mityc.api.pass.1", new Object[] { ex.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ClassLoader getClassLoader()
/*     */   {
/*     */     try
/*     */     {
/* 115 */       ClassLoader cl = (ClassLoader)AccessController.doPrivileged(new PrivilegedAction() {
/*     */         public ClassLoader run() {
/* 117 */           ClassLoader classLoader = null;
/*     */           try {
/* 119 */             classLoader = Thread.currentThread().getContextClassLoader();
/*     */           }
/*     */           catch (SecurityException localSecurityException) {}
/* 122 */           return classLoader;
/*     */         }
/*     */       });
/* 125 */       if (cl != null) {
/* 126 */         return cl;
/*     */       }
/*     */     }
/*     */     catch (Exception localException) {}
/* 130 */     return PassSecurityFactory.class.getClassLoader();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 137 */   private static PassSecurityFactory instance = getInstance();
/*     */   
/*     */ 
/*     */   private static final String PASS_SECURITY_FILE_CONF = "META-INF/pass/security.properties";
/*     */   
/*     */ 
/*     */ 
/*     */   public static PassSecurityFactory getInstance()
/*     */   {
/* 146 */     if (instance == null) {
/* 147 */       instance = new PassSecurityFactory();
/*     */     }
/* 149 */     return instance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IPassSecurity getPassSecurityManager(String key, boolean defaultManager)
/*     */   {
/* 161 */     IPassSecurity secManager = null;
/* 162 */     if ((this.props != null) && (this.props.size() > 0)) {
/* 163 */       Iterator<Properties> itProp = this.props.iterator();
/* 164 */       while (itProp.hasNext()) {
/* 165 */         Properties prop = (Properties)itProp.next();
/* 166 */         String classname = prop.getProperty(key);
/* 167 */         if (classname != null) {
/*     */           try {
/* 169 */             ClassLoader cl = getClassLoader();
/* 170 */             Class<?> manager = null;
/* 171 */             if (cl != null) {
/* 172 */               manager = cl.loadClass(classname);
/*     */             } else {
/* 174 */               manager = Class.forName(classname);
/*     */             }
/* 176 */             if (manager != null)
/*     */             {
/* 178 */               Constructor<?> constructor = manager.getConstructor(new Class[] { Properties.class });
/* 179 */               if (constructor != null) {
/* 180 */                 secManager = (IPassSecurity)constructor.newInstance(new Object[] { prop });
/*     */               }
/*     */               else {
/* 183 */                 constructor = manager.getConstructor(null);
/* 184 */                 if (constructor != null) {
/* 185 */                   secManager = (IPassSecurity)constructor.newInstance(new Object[0]);
/*     */                 }
/*     */               }
/*     */             }
/*     */           } catch (InstantiationException ex) {
/* 190 */             LOGGER.warn(I18N.getLocalMessage("i18n.mityc.api.pass.3", new Object[] { ex.getMessage() }));
/* 191 */             if (LOGGER.isDebugEnabled()) {
/* 192 */               LOGGER.debug("", ex);
/*     */             }
/*     */           } catch (IllegalAccessException ex) {
/* 195 */             LOGGER.warn(I18N.getLocalMessage("i18n.mityc.api.pass.3", new Object[] { ex.getMessage() }));
/* 196 */             if (LOGGER.isDebugEnabled()) {
/* 197 */               LOGGER.debug("", ex);
/*     */             }
/*     */           } catch (ClassNotFoundException ex) {
/* 200 */             LOGGER.warn(I18N.getLocalMessage("i18n.mityc.api.pass.3", new Object[] { ex.getMessage() }));
/* 201 */             if (LOGGER.isDebugEnabled()) {
/* 202 */               LOGGER.debug("", ex);
/*     */             }
/*     */           } catch (ClassCastException ex) {
/* 205 */             LOGGER.warn(I18N.getLocalMessage("i18n.mityc.api.pass.3", new Object[] { ex.getMessage() }));
/* 206 */             if (LOGGER.isDebugEnabled()) {
/* 207 */               LOGGER.debug("", ex);
/*     */             }
/*     */           } catch (SecurityException ex) {
/* 210 */             LOGGER.warn(I18N.getLocalMessage("i18n.mityc.api.pass.3", new Object[] { ex.getMessage() }));
/* 211 */             if (LOGGER.isDebugEnabled()) {
/* 212 */               LOGGER.debug("", ex);
/*     */             }
/*     */           } catch (NoSuchMethodException ex) {
/* 215 */             LOGGER.warn(I18N.getLocalMessage("i18n.mityc.api.pass.3", new Object[] { ex.getMessage() }));
/* 216 */             if (LOGGER.isDebugEnabled()) {
/* 217 */               LOGGER.debug("", ex);
/*     */             }
/*     */           } catch (IllegalArgumentException ex) {
/* 220 */             LOGGER.warn(I18N.getLocalMessage("i18n.mityc.api.pass.3", new Object[] { ex.getMessage() }));
/* 221 */             if (LOGGER.isDebugEnabled()) {
/* 222 */               LOGGER.debug("", ex);
/*     */             }
/*     */           } catch (InvocationTargetException ex) {
/* 225 */             LOGGER.warn(I18N.getLocalMessage("i18n.mityc.api.pass.3", new Object[] { ex.getMessage() }));
/* 226 */             if (LOGGER.isDebugEnabled()) {
/* 227 */               LOGGER.debug("", ex);
/*     */             }
/*     */           }
/*     */           
/* 231 */           if ((secManager == null) && (defaultManager)) {
/* 232 */             secManager = new NullPassSecurity();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 238 */     if ((secManager == null) && (defaultManager)) {
/* 239 */       secManager = new NullPassSecurity();
/*     */     }
/* 241 */     return secManager;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\pass\PassSecurityFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */