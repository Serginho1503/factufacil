/*    */ package es.mityc.javasign.pass;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ProtectPass
/*    */ {
/* 29 */   private static final Log LOGGER = LogFactory.getLog(ProtectPass.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/* 41 */     if ((args != null) && (args.length == 2)) {
/* 42 */       System.out.println("Recuperando ofuscador " + args[0]);
/*    */       try {
/* 44 */         IPassSecurity sec = PassSecurityFactory.getInstance().getPassSecurityManager(args[0], false);
/* 45 */         if (sec == null) {
/* 46 */           System.out.println("No se encuentra el ofuscador indicado");
/*    */         } else {
/* 48 */           String res = sec.protect(args[0]);
/* 49 */           System.out.println("Contraseña protegida: " + res);
/* 50 */           String orig = sec.recover(res);
/* 51 */           if ((orig == null) || (args[0].compareTo(orig) != 0)) {
/* 52 */             LOGGER.fatal("Error en el proceso de seguridad. Contraseña protegida no es equivalente a contraseña proporcionada.");
/* 53 */             System.out.println("Error en el proceso de seguridad. Contraseña protegida no es equivalente a contraseña proporcionada.");
/*    */           }
/*    */         }
/*    */       } catch (PassSecurityException ex) {
/* 57 */         LOGGER.fatal("Error preparando configuración de seguridad: " + ex.getMessage());
/* 58 */         LOGGER.debug("", ex);
/* 59 */         System.out.println("Error no esperado preparando configuración de seguridad: " + ex.getMessage());
/*    */       }
/*    */     } else {
/* 62 */       System.out.println("Ejemplo de uso:");
/* 63 */       System.out.println("   ProtectPass <id_ofuscador> <contraseña>");
/* 64 */       System.out.println("         id_ofuscador  identificador del ofuscador");
/* 65 */       System.out.println("         contraseña    contraseña que se quiere proteger");
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\pass\ProtectPass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */