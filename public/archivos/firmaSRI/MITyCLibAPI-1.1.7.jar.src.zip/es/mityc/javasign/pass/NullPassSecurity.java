/*    */ package es.mityc.javasign.pass;
/*    */ 
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullPassSecurity
/*    */   implements IPassSecurity
/*    */ {
/*    */   public NullPassSecurity() {}
/*    */   
/*    */   public NullPassSecurity(Properties config) {}
/*    */   
/*    */   public String protect(String pass)
/*    */     throws PassSecurityException
/*    */   {
/* 47 */     return pass != null ? new String(pass) : null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String recover(String pass)
/*    */     throws PassSecurityException
/*    */   {
/* 59 */     return pass != null ? new String(pass) : null;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\pass\NullPassSecurity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */