/*    */ package es.mityc.javasign.pass;
/*    */ 
/*    */ import es.mityc.javasign.exception.SignMITyCException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PassSecurityException
/*    */   extends SignMITyCException
/*    */ {
/*    */   public PassSecurityException() {}
/*    */   
/*    */   public PassSecurityException(String message)
/*    */   {
/* 38 */     super(message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public PassSecurityException(Throwable cause)
/*    */   {
/* 46 */     super(cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PassSecurityException(String message, Throwable cause)
/*    */   {
/* 55 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\pass\PassSecurityException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */