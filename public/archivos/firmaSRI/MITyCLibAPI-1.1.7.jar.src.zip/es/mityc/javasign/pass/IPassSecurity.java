package es.mityc.javasign.pass;

public abstract interface IPassSecurity
{
  public abstract String protect(String paramString)
    throws PassSecurityException;
  
  public abstract String recover(String paramString)
    throws PassSecurityException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\pass\IPassSecurity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */