/*    */ package es.mityc.javasign.certificate;
/*    */ 
/*    */ import es.mityc.javasign.exception.SignMITyCException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CertStatusException
/*    */   extends SignMITyCException
/*    */ {
/*    */   public CertStatusException() {}
/*    */   
/*    */   public CertStatusException(String message)
/*    */   {
/* 39 */     super(message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public CertStatusException(Throwable cause)
/*    */   {
/* 47 */     super(cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CertStatusException(String message, Throwable cause)
/*    */   {
/* 56 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\certificate\CertStatusException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */