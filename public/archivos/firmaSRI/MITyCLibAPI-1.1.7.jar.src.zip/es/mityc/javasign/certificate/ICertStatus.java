/*    */ package es.mityc.javasign.certificate;
/*    */ 
/*    */ import java.security.cert.X509Certificate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface ICertStatus
/*    */ {
/*    */   public abstract CERT_STATUS getStatus();
/*    */   
/*    */   public abstract X509Certificate getCertificate();
/*    */   
/*    */   public abstract byte[] getEncoded();
/*    */   
/*    */   public abstract RevokedInfo getRevokedInfo();
/*    */   
/*    */   public static enum CERT_STATUS
/*    */   {
/* 29 */     unknown, 
/*    */     
/* 31 */     valid, 
/*    */     
/* 33 */     revoked;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\certificate\ICertStatus.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */