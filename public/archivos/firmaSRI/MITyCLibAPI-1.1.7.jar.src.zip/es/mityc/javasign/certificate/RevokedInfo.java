/*    */ package es.mityc.javasign.certificate;
/*    */ 
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RevokedInfo
/*    */ {
/*    */   private Object revokedReason;
/*    */   private Date revokedDate;
/*    */   
/*    */   public RevokedInfo(Object reason, Date date)
/*    */   {
/* 38 */     this.revokedReason = reason;
/* 39 */     this.revokedDate = date;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Object getRevokedReason()
/*    */   {
/* 47 */     return this.revokedReason;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Date getRevokedDate()
/*    */   {
/* 55 */     return this.revokedDate;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Object clone()
/*    */   {
/* 65 */     Date date = this.revokedDate != null ? (Date)this.revokedDate.clone() : null;
/* 66 */     return new RevokedInfo(this.revokedReason, date);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\certificate\RevokedInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */