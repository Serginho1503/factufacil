/*    */ package es.mityc.javasign.certificate;
/*    */ 
/*    */ import es.mityc.javasign.exception.SignMITyCException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ElementNotFoundException
/*    */   extends SignMITyCException
/*    */ {
/*    */   public ElementNotFoundException() {}
/*    */   
/*    */   public ElementNotFoundException(String message)
/*    */   {
/* 39 */     super(message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ElementNotFoundException(Throwable cause)
/*    */   {
/* 47 */     super(cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ElementNotFoundException(String message, Throwable cause)
/*    */   {
/* 56 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\certificate\ElementNotFoundException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */