package es.mityc.javasign.certificate;

import java.security.cert.X509Certificate;
import java.util.List;

public abstract interface ICertStatusRecoverer
{
  public abstract ICertStatus getCertStatus(X509Certificate paramX509Certificate)
    throws CertStatusException;
  
  public abstract List<ICertStatus> getCertStatus(List<X509Certificate> paramList)
    throws CertStatusException;
  
  public abstract List<ICertStatus> getCertChainStatus(X509Certificate paramX509Certificate)
    throws CertStatusException;
  
  public abstract List<List<ICertStatus>> getCertChainStatus(List<X509Certificate> paramList)
    throws CertStatusException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\certificate\ICertStatusRecoverer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */