package es.mityc.javasign.certificate;

import java.security.cert.X509CRL;

public abstract interface IX509CRLCertStatus
  extends ICertStatus
{
  public abstract X509CRL getX509CRL();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\certificate\IX509CRLCertStatus.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */