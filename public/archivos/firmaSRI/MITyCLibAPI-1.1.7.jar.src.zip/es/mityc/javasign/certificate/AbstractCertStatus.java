/*    */ package es.mityc.javasign.certificate;
/*    */ 
/*    */ import java.security.cert.X509Certificate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractCertStatus
/*    */   implements ICertStatus
/*    */ {
/* 27 */   protected ICertStatus.CERT_STATUS certStatus = ICertStatus.CERT_STATUS.unknown;
/*    */   
/* 29 */   protected RevokedInfo revokedInfo = null;
/*    */   
/* 31 */   protected X509Certificate certificate = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public X509Certificate getCertificate()
/*    */   {
/* 39 */     return this.certificate;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract byte[] getEncoded();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public RevokedInfo getRevokedInfo()
/*    */   {
/* 56 */     return this.revokedInfo != null ? (RevokedInfo)this.revokedInfo.clone() : null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ICertStatus.CERT_STATUS getStatus()
/*    */   {
/* 65 */     return this.certStatus;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void setCertStatus(ICertStatus.CERT_STATUS status)
/*    */   {
/* 73 */     this.certStatus = status;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void setRevokedInfo(RevokedInfo ri)
/*    */   {
/* 81 */     this.revokedInfo = ((RevokedInfo)ri.clone());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void setCertificate(X509Certificate cert)
/*    */   {
/* 89 */     this.certificate = cert;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\certificate\AbstractCertStatus.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */