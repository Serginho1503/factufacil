package es.mityc.javasign.certificate;

import java.util.Map;

public abstract interface IRecoverElements
{
  public static final String PROP_URI = "uri";
  public static final String PROP_ISSUER_NAME = "issuer.name";
  public static final String PROP_ISSUER_HASH = "issuer.hash";
  public static final String PROP_SERIAL_NUMBER = "serial.number";
  public static final String PROP_EMISSION_DATE = "emission.date";
  public static final String PROP_DIGEST_ALGORITHM = "digest.algorithm";
  public static final String PROP_DIGEST_VALUE = "digest.value";
  
  public abstract <T> T getElement(Map<String, Object> paramMap, Class<T> paramClass)
    throws ElementNotFoundException, UnknownElementClassException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\certificate\IRecoverElements.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */