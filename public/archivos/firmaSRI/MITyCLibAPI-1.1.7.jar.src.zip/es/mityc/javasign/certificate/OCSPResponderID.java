/*     */ package es.mityc.javasign.certificate;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.utils.Base64Coder;
/*     */ import java.util.Arrays;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class OCSPResponderID
/*     */ {
/*  36 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibAPI");
/*     */   
/*     */ 
/*  39 */   protected IOCSPCertStatus.TYPE_RESPONDER typeResponderID = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public static class OCSPResponderIDName
/*     */     extends OCSPResponderID
/*     */   {
/*  46 */     private X500Principal nameResponder = null;
/*     */     
/*     */ 
/*     */ 
/*     */     protected OCSPResponderIDName(X500Principal name)
/*     */     {
/*  52 */       super();
/*  53 */       this.nameResponder = name;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean equals(Object arg0)
/*     */     {
/*  63 */       if ((arg0 instanceof OCSPResponderIDName)) {
/*  64 */         if (this.nameResponder != null) {
/*  65 */           return this.nameResponder.equals(((OCSPResponderIDName)arg0).nameResponder);
/*     */         }
/*  67 */         return ((OCSPResponderIDName)arg0).nameResponder == null;
/*     */       }
/*  69 */       if ((arg0 instanceof OCSPResponderID.OCSPResponderIDUnknown)) {
/*  70 */         return arg0.equals(this);
/*     */       }
/*  72 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int hashCode()
/*     */     {
/*  81 */       return this.nameResponder != null ? this.nameResponder.hashCode() : super.hashCode();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Object getIdentifierData()
/*     */     {
/*  90 */       return this.nameResponder;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/*  99 */       return super.toString() + OCSPResponderID.I18N.getLocalMessage("i18n.mityc.api.cert.5", new Object[] { this.nameResponder != null ? this.nameResponder.getName() : "null" });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class OCSPResponderIDHash
/*     */     extends OCSPResponderID
/*     */   {
/* 108 */     private byte[] hashPK = null;
/*     */     
/*     */ 
/*     */ 
/*     */     protected OCSPResponderIDHash(byte[] hash)
/*     */     {
/* 114 */       super();
/* 115 */       this.hashPK = hash;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean equals(Object arg0)
/*     */     {
/* 125 */       if ((arg0 instanceof OCSPResponderIDHash))
/* 126 */         return Arrays.equals(this.hashPK, ((OCSPResponderIDHash)arg0).hashPK);
/* 127 */       if ((arg0 instanceof OCSPResponderID.OCSPResponderIDUnknown)) {
/* 128 */         return arg0.equals(this);
/*     */       }
/* 130 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 139 */       if (this.hashPK != null) {
/* 140 */         return this.hashPK.hashCode();
/*     */       }
/* 142 */       return super.hashCode();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Object getIdentifierData()
/*     */     {
/* 152 */       return this.hashPK;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/* 161 */       return super.toString() + OCSPResponderID.I18N.getLocalMessage("i18n.mityc.api.cert.5", new Object[] { Arrays.toString(this.hashPK) });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class OCSPResponderIDUnknown
/*     */     extends OCSPResponderID
/*     */   {
/* 172 */     private String identifier = null;
/*     */     
/*     */ 
/*     */ 
/*     */     public OCSPResponderIDUnknown(String id)
/*     */     {
/* 178 */       super();
/* 179 */       this.identifier = new String(id);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean equals(Object arg0)
/*     */     {
/* 196 */       if ((arg0 instanceof OCSPResponderID.OCSPResponderIDName)) {
/* 197 */         if (this.identifier != null) {
/*     */           try {
/* 199 */             X500Principal prin = new X500Principal(this.identifier);
/* 200 */             return prin.equals(((OCSPResponderID.OCSPResponderIDName)arg0).nameResponder);
/*     */           } catch (IllegalArgumentException ex) {
/* 202 */             return false;
/*     */           }
/*     */         }
/* 205 */         return ((OCSPResponderID.OCSPResponderIDName)arg0).nameResponder == null;
/*     */       }
/* 207 */       if ((arg0 instanceof OCSPResponderID.OCSPResponderIDHash)) {
/* 208 */         if (this.identifier != null) {
/*     */           try {
/* 210 */             byte[] hash = Base64Coder.decode(this.identifier);
/* 211 */             return Arrays.equals(hash, ((OCSPResponderID.OCSPResponderIDHash)arg0).hashPK);
/*     */           } catch (IllegalArgumentException ex) {
/* 213 */             return false;
/*     */           }
/*     */         }
/* 216 */         return ((OCSPResponderID.OCSPResponderIDHash)arg0).hashPK == null;
/*     */       }
/* 218 */       if ((arg0 instanceof OCSPResponderIDUnknown)) {
/* 219 */         if (this.identifier != null) {
/* 220 */           return this.identifier.equals(((OCSPResponderIDUnknown)arg0).identifier);
/*     */         }
/* 222 */         return ((OCSPResponderIDUnknown)arg0).identifier == null;
/*     */       }
/*     */       
/* 225 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 234 */       return this.identifier != null ? this.identifier.hashCode() : super.hashCode();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Object getIdentifierData()
/*     */     {
/* 243 */       return this.identifier;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/* 252 */       return super.toString() + OCSPResponderID.I18N.getLocalMessage("i18n.mityc.api.cert.5", new Object[] { this.identifier });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected OCSPResponderID(IOCSPCertStatus.TYPE_RESPONDER type)
/*     */   {
/* 261 */     this.typeResponderID = type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static OCSPResponderID getOCSPResponderID(X500Principal name)
/*     */   {
/* 270 */     return new OCSPResponderIDName(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static OCSPResponderID getOCSPResponderID(byte[] data)
/*     */   {
/* 279 */     return new OCSPResponderIDHash((byte[])data.clone());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static OCSPResponderID getOCSPresponderID(String id)
/*     */   {
/* 288 */     return new OCSPResponderIDUnknown(id);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IOCSPCertStatus.TYPE_RESPONDER getTypeResponderID()
/*     */   {
/* 297 */     return this.typeResponderID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Object getIdentifierData();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 313 */     String res = null;
/* 314 */     if (this.typeResponderID != null)
/* 315 */       switch (this.typeResponderID) {
/*     */       case BY_KEY: 
/* 317 */         res = I18N.getLocalMessage("i18n.mityc.api.cert.2");
/* 318 */         break;
/*     */       case BY_NAME: 
/*     */       default: 
/* 321 */         res = I18N.getLocalMessage("i18n.mityc.api.cert.3");
/*     */         
/* 323 */         break; } else {
/* 324 */       res = I18N.getLocalMessage("i18n.mityc.api.cert.4");
/*     */     }
/* 326 */     return I18N.getLocalMessage("i18n.mityc.api.cert.1", new Object[] { res });
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\certificate\OCSPResponderID.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */