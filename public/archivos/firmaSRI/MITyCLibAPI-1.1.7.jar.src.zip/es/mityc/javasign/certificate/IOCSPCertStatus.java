/*    */ package es.mityc.javasign.certificate;
/*    */ 
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface IOCSPCertStatus
/*    */   extends ICertStatus
/*    */ {
/*    */   public abstract String getResponderID();
/*    */   
/*    */   public abstract TYPE_RESPONDER getResponderType();
/*    */   
/*    */   public abstract Date getResponseDate();
/*    */   
/*    */   public static enum TYPE_RESPONDER
/*    */   {
/* 29 */     BY_NAME, 
/*    */     
/* 31 */     BY_KEY;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\certificate\IOCSPCertStatus.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */