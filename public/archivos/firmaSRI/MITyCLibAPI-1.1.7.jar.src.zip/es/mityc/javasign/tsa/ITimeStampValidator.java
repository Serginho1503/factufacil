package es.mityc.javasign.tsa;

public abstract interface ITimeStampValidator
{
  public abstract TSValidationResult validateTimeStamp(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws TimeStampException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\tsa\ITimeStampValidator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */