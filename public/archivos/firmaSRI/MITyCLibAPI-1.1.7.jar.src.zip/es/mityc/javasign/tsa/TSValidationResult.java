/*     */ package es.mityc.javasign.tsa;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import java.security.cert.CertPath;
/*     */ import java.util.Date;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TSValidationResult
/*     */ {
/*  31 */   private String formattedDate = null;
/*     */   
/*  33 */   private Date date = null;
/*     */   
/*  35 */   private X500Principal issuer = null;
/*     */   
/*  37 */   private CertPath cadena = null;
/*     */   
/*  39 */   private long timeAccurracy = 0L;
/*     */   
/*  41 */   private BigInteger stamp = null;
/*     */   
/*  43 */   private String stampAlg = null;
/*     */   
/*  45 */   private String signDigest = null;
/*     */   
/*  47 */   private String stampDigest = null;
/*     */   
/*  49 */   private byte[] timeStampRawToken = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFormattedDate()
/*     */   {
/*  56 */     return this.formattedDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFormattedDate(String formattedDate)
/*     */   {
/*  64 */     this.formattedDate = formattedDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getDate()
/*     */   {
/*  72 */     return this.date;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDate(Date date)
/*     */   {
/*  80 */     this.date = date;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public X500Principal getTimeStampIssuer()
/*     */   {
/*  88 */     return this.issuer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeStampIssuer(X500Principal issuer)
/*     */   {
/*  96 */     this.issuer = issuer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSignDigest()
/*     */   {
/* 104 */     return this.signDigest;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSignDigest(String signDigest)
/*     */   {
/* 112 */     this.signDigest = signDigest;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getTimeAccurracy()
/*     */   {
/* 120 */     return this.timeAccurracy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeAccurracy(long timeAccurracy)
/*     */   {
/* 128 */     this.timeAccurracy = timeAccurracy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public BigInteger getStamp()
/*     */   {
/* 136 */     return this.stamp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStamp(BigInteger stamp)
/*     */   {
/* 144 */     this.stamp = stamp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getStampAlg()
/*     */   {
/* 152 */     return this.stampAlg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStampAlg(String selloAlg)
/*     */   {
/* 160 */     this.stampAlg = selloAlg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getStampDigest()
/*     */   {
/* 168 */     return this.stampDigest;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStampDigest(String stampDigest)
/*     */   {
/* 176 */     this.stampDigest = stampDigest;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getTimeStampRawToken()
/*     */   {
/* 184 */     return this.timeStampRawToken;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeStamRawToken(byte[] timeStampRawToken)
/*     */   {
/* 192 */     this.timeStampRawToken = timeStampRawToken;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CertPath getCadena()
/*     */   {
/* 200 */     return this.cadena;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCadena(CertPath cadena)
/*     */   {
/* 208 */     this.cadena = cadena;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\tsa\TSValidationResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */