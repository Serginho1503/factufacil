package es.mityc.javasign.tsa;

public abstract interface ITimeStampGenerator
{
  public abstract byte[] generateTimeStamp(byte[] paramArrayOfByte)
    throws TimeStampException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\tsa\ITimeStampGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */