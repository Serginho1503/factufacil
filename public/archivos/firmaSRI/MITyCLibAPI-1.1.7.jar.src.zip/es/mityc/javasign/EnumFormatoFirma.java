/*    */ package es.mityc.javasign;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum EnumFormatoFirma
/*    */ {
/* 25 */   XMLSignature, 
/* 26 */   XAdES_BES, 
/* 27 */   XAdES_T, 
/* 28 */   XAdES_C, 
/* 29 */   XAdES_X, 
/* 30 */   XAdES_XL, 
/* 31 */   PKCS7, 
/* 32 */   OTHER;
/*    */   
/*    */   public static String getName(EnumFormatoFirma tipo) {
/* 35 */     switch (tipo) {
/*    */     case OTHER: 
/* 37 */       return "XAdES-BES";
/*    */     case PKCS7: 
/* 39 */       return "XAdES-BES";
/*    */     case XAdES_BES: 
/* 41 */       return "XAdES-T";
/*    */     case XAdES_C: 
/* 43 */       return "XAdES-C";
/*    */     case XAdES_T: 
/* 45 */       return "XAdES-X";
/*    */     case XAdES_X: 
/* 47 */       return "XAdES-XL";
/*    */     case XAdES_XL: 
/* 49 */       return "PKCS-7";
/*    */     case XMLSignature: 
/* 51 */       return "OTHER";
/*    */     }
/* 53 */     return "XAdES-BES";
/*    */   }
/*    */   
/*    */   public static EnumFormatoFirma parse(String tipo)
/*    */   {
/* 58 */     if ((tipo != null) && (tipo.length() > 0)) {
/* 59 */       if (tipo.equals("XAdES-BES"))
/* 60 */         return XAdES_BES;
/* 61 */       if (tipo.equals("XAdES-BES"))
/* 62 */         return XAdES_BES;
/* 63 */       if (tipo.equals("XAdES-T"))
/* 64 */         return XAdES_T;
/* 65 */       if (tipo.equals("XAdES-C"))
/* 66 */         return XAdES_C;
/* 67 */       if (tipo.equals("XAdES-X"))
/* 68 */         return XAdES_X;
/* 69 */       if (tipo.equals("XAdES-XL"))
/* 70 */         return XAdES_XL;
/* 71 */       if (tipo.equals("PKCS-7")) {
/* 72 */         return PKCS7;
/*    */       }
/* 74 */       return OTHER;
/*    */     }
/*    */     
/* 77 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\EnumFormatoFirma.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */