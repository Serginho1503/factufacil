package es.mityc.javasign.ssl;

import java.security.cert.X509Certificate;

public abstract interface ISSLErrorManager
{
  public abstract boolean continueErrorPeer(String paramString, X509Certificate paramX509Certificate);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\ssl\ISSLErrorManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */