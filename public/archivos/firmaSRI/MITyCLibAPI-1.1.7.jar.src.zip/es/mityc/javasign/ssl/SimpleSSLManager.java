/*    */ package es.mityc.javasign.ssl;
/*    */ 
/*    */ import javax.net.ssl.KeyManager;
/*    */ import javax.net.ssl.TrustManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleSSLManager
/*    */   implements ISSLManager
/*    */ {
/*    */   private TrustManager truster;
/*    */   private KeyManager keyer;
/*    */   private ISSLErrorManager errorManager;
/*    */   
/*    */   public SimpleSSLManager(TrustManager trustManager, KeyManager keyManager)
/*    */   {
/* 41 */     this.truster = trustManager;
/* 42 */     this.keyer = keyManager;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setSSLErrorManager(ISSLErrorManager errorMng)
/*    */   {
/* 50 */     this.errorManager = errorMng;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ISSLErrorManager getSSLErrorManager()
/*    */   {
/* 59 */     return this.errorManager;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public KeyManager getKeyManager()
/*    */   {
/* 68 */     return this.keyer;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public TrustManager getTrustManager()
/*    */   {
/* 77 */     return this.truster;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\ssl\SimpleSSLManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */