/*    */ package es.mityc.javasign.ssl;
/*    */ 
/*    */ import java.security.cert.CertificateException;
/*    */ import java.security.cert.X509Certificate;
/*    */ import javax.net.ssl.X509TrustManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AllTrustedManager
/*    */   implements X509TrustManager
/*    */ {
/*    */   public void checkClientTrusted(X509Certificate[] arg0, String arg1)
/*    */     throws CertificateException
/*    */   {}
/*    */   
/*    */   public void checkServerTrusted(X509Certificate[] arg0, String arg1)
/*    */     throws CertificateException
/*    */   {}
/*    */   
/*    */   public X509Certificate[] getAcceptedIssuers()
/*    */   {
/* 45 */     return new X509Certificate[0];
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\ssl\AllTrustedManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */