package es.mityc.javasign.ssl;

import javax.net.ssl.KeyManager;
import javax.net.ssl.TrustManager;

public abstract interface ISSLManager
{
  public abstract TrustManager getTrustManager();
  
  public abstract KeyManager getKeyManager();
  
  public abstract ISSLErrorManager getSSLErrorManager();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\ssl\ISSLManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */