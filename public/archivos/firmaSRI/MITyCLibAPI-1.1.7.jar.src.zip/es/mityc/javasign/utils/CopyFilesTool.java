/*     */ package es.mityc.javasign.utils;
/*     */ 
/*     */ import es.mityc.javasign.exception.CopyFileException;
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.trust.TrustFactory;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Field;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ import java.util.zip.Adler32;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CopyFilesTool
/*     */ {
/* 110 */   private static final Log LOG = LogFactory.getLog(CopyFilesTool.class);
/*     */   
/* 112 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibAPI");
/*     */   
/*     */ 
/*     */   private static final int BUFFER_IN_SIZE = 32000;
/*     */   
/*     */ 
/*     */   private static final int BUFFER_OUT_SIZE = 4096;
/*     */   
/*     */ 
/*     */   private static final String DIGEST_SHA_256 = "SHA-256";
/*     */   
/*     */ 
/*     */   private static final String FIELD_SYS_PATHS = "sys_paths";
/*     */   
/*     */   private static final String STR_FILE_DOT = "file.";
/*     */   
/*     */   private static final String STR_DOT_NAME = ".name";
/*     */   
/*     */   private static final String STR_DOT_RES = ".res";
/*     */   
/*     */   private static final String STR_DOT_ADLER32 = ".Adler32";
/*     */   
/*     */   private static final String STR_DOT_SHA2 = ".SHA2";
/*     */   
/*     */   private static final String STR_DOT_SIZE = ".size";
/*     */   
/*     */   private static final String STR_FILE_SEPARATOR = ",";
/*     */   
/*     */   private static final String STR_OS_NAME_WIN = "windows";
/*     */   
/*     */   private static final String STR_OS_NAME_LIN = "linux";
/*     */   
/*     */   private static final String STR_OS_NAME_MACOSX = "macosx";
/*     */   
/*     */   private static final String STR_OS_64BITS = "_64";
/*     */   
/* 148 */   private Properties props = null;
/*     */   
/* 150 */   private ClassLoader internalClassLoader = null;
/*     */   
/* 152 */   private Vector<String> vCopiedLibraries = new Vector();
/*     */   
/*     */   public static enum CrcIntegrityEnum {
/* 155 */     ADLER32,  SHA2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private class Adler32Info
/*     */     extends CopyFilesTool.CRCInfo
/*     */   {
/*     */     private long crc;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private Adler32Info()
/*     */     {
/* 184 */       super(null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void processValue(String value)
/*     */       throws CopyFileException
/*     */     {
/*     */       try
/*     */       {
/* 196 */         this.crc = Long.parseLong(value);
/*     */       } catch (NumberFormatException ex) {
/* 198 */         CopyFilesTool.LOG.error(CopyFilesTool.I18N.getLocalMessage("i18n.mityc.api.tools.cp.5"), ex);
/* 199 */         throw new CopyFileException(CopyFilesTool.I18N.getLocalMessage("i18n.mityc.api.tools.cp.5"));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public CopyFilesTool.CrcIntegrityEnum getCrcType()
/*     */     {
/* 209 */       return CopyFilesTool.CrcIntegrityEnum.ADLER32;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public long getCrcValue()
/*     */     {
/* 216 */       return this.crc;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean checkFile(File file)
/*     */       throws CopyFileException
/*     */     {
/*     */       try
/*     */       {
/* 228 */         Adler32 crcAdler = new Adler32();
/* 229 */         InputStream in = new BufferedInputStream(new FileInputStream(file), 32000);
/* 230 */         byte[] buffer = new byte['က'];
/* 231 */         int readed = in.read(buffer);
/* 232 */         while (readed > 0) {
/* 233 */           crcAdler.update(buffer, 0, readed);
/* 234 */           readed = in.read(buffer);
/*     */         }
/* 236 */         if (CopyFilesTool.LOG.isTraceEnabled()) {
/* 237 */           CopyFilesTool.LOG.trace(CopyFilesTool.I18N.getLocalMessage("i18n.mityc.api.tools.cp.13", new Object[] { Long.valueOf(crcAdler.getValue()), Long.valueOf(getCrcValue()) }));
/*     */         }
/* 239 */         if (crcAdler.getValue() != getCrcValue()) {
/* 240 */           return false;
/*     */         }
/* 242 */         return true;
/*     */       } catch (IOException ex) {
/* 244 */         throw new CopyFileException(ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private class SHA2Info extends CopyFilesTool.CRCInfo { private String crc;
/*     */     
/* 251 */     private SHA2Info() { super(null); }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void processValue(String value)
/*     */       throws CopyFileException
/*     */     {
/* 263 */       this.crc = new String(value);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public CopyFilesTool.CrcIntegrityEnum getCrcType()
/*     */     {
/* 272 */       return CopyFilesTool.CrcIntegrityEnum.SHA2;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public String getCrcValue()
/*     */     {
/* 279 */       return this.crc;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean checkFile(File file)
/*     */       throws CopyFileException
/*     */     {
/*     */       try
/*     */       {
/* 291 */         MessageDigest md = MessageDigest.getInstance("SHA-256");
/* 292 */         InputStream entrada = new BufferedInputStream(new FileInputStream(file), 32000);
/* 293 */         byte[] buffer = new byte['က'];
/* 294 */         int readed = entrada.read(buffer);
/* 295 */         while (readed > 0) {
/* 296 */           md.update(buffer, 0, readed);
/* 297 */           readed = entrada.read(buffer);
/*     */         }
/* 299 */         String crcRes = CopyFilesTool.this.toHexString(md.digest());
/* 300 */         if (CopyFilesTool.LOG.isTraceEnabled()) {
/* 301 */           CopyFilesTool.LOG.trace(CopyFilesTool.I18N.getLocalMessage("i18n.mityc.api.tools.cp.13", new Object[] { crcRes, getCrcValue() }));
/*     */         }
/*     */         
/* 304 */         if (!crcRes.equalsIgnoreCase(getCrcValue())) {
/* 305 */           return false;
/*     */         }
/* 307 */         return true;
/*     */       } catch (IOException ex) {
/* 309 */         throw new CopyFileException(ex);
/*     */       } catch (NoSuchAlgorithmException ex) {
/* 311 */         throw new CopyFileException(ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CopyFilesTool(String fileProperties)
/*     */   {
/* 322 */     this(fileProperties, getClassLoader());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CopyFilesTool(String fileProperties, ClassLoader cl)
/*     */   {
/* 332 */     this.internalClassLoader = cl;
/* 333 */     loadProperties(fileProperties);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void loadProperties(String fileProperties)
/*     */   {
/*     */     try
/*     */     {
/* 343 */       ArrayList<URL> resources = new ArrayList();
/* 344 */       Enumeration<URL> en = this.internalClassLoader.getResources(fileProperties);
/* 345 */       while (en.hasMoreElements()) {
/* 346 */         resources.add(0, (URL)en.nextElement());
/*     */       }
/* 348 */       if (LOG.isTraceEnabled()) {
/* 349 */         LOG.trace(I18N.getLocalMessage("i18n.mityc.api.tools.cp.17", new Object[] { Integer.valueOf(resources.size()), fileProperties }));
/*     */       }
/*     */       
/* 352 */       Properties base = null;
/* 353 */       Iterator<URL> itResources = resources.iterator();
/* 354 */       while (itResources.hasNext()) {
/* 355 */         URL url = (URL)itResources.next();
/*     */         try {
/* 357 */           InputStream is = url.openStream();
/* 358 */           Properties properties = new Properties(base);
/* 359 */           properties.load(is);
/* 360 */           base = properties;
/*     */         } catch (IOException ex) {
/* 362 */           LOG.error(I18N.getLocalMessage("i18n.mityc.api.tools.cp.1", new Object[] { url, ex.getMessage() }));
/*     */         }
/*     */       }
/* 365 */       this.props = base;
/*     */     } catch (IOException ex) {
/* 367 */       LOG.error(I18N.getLocalMessage("i18n.mityc.api.tools.cp.1", new Object[] { fileProperties, ex.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ClassLoader getClassLoader()
/*     */   {
/*     */     try
/*     */     {
/* 378 */       ClassLoader cl = (ClassLoader)AccessController.doPrivileged(new PrivilegedAction() {
/*     */         public ClassLoader run() {
/* 380 */           ClassLoader classLoader = null;
/*     */           try {
/* 382 */             classLoader = Thread.currentThread().getContextClassLoader();
/*     */           }
/*     */           catch (SecurityException localSecurityException) {}
/* 385 */           return classLoader;
/*     */         }
/*     */       });
/* 388 */       if (cl != null) {
/* 389 */         return cl;
/*     */       }
/*     */     }
/*     */     catch (Exception localException) {}
/* 393 */     return TrustFactory.class.getClassLoader();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getKeyOS(String so, String version, String arch, String addendum)
/*     */   {
/* 414 */     String res = addStrings(new String[] { so, version, arch, addendum });
/* 415 */     if (!hasProp(res)) {
/* 416 */       res = addStrings(new String[] { so, arch, addendum });
/* 417 */       if (!hasProp(res)) {
/* 418 */         res = addStrings(new String[] { so, version, addendum });
/* 419 */         if (!hasProp(res)) {
/* 420 */           res = addStrings(new String[] { so + addendum });
/*     */         }
/*     */       }
/*     */     }
/* 424 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String addStrings(String... varargs)
/*     */   {
/* 433 */     StringBuffer sb = new StringBuffer("");
/* 434 */     String[] arrayOfString; int j = (arrayOfString = varargs).length; for (int i = 0; i < j; i++) { String phrase = arrayOfString[i];
/* 435 */       if (phrase != null) {
/* 436 */         sb.append(phrase);
/*     */       }
/*     */     }
/* 439 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String copyFilesOS(String dir, String addendum, boolean updateLibraryPath)
/*     */     throws CopyFileException
/*     */   {
/* 461 */     return copyFilesOS(dir, addendum, updateLibraryPath, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String copyFilesOS(String dir, String addendum, boolean updateLibraryPath, String suffix)
/*     */     throws CopyFileException
/*     */   {
/* 485 */     OSTool.OS so = OSTool.getSO();
/* 486 */     if (LOG.isTraceEnabled()) {
/* 487 */       LOG.trace(I18N.getLocalMessage("i18n.mityc.api.tools.cp.14", new Object[] { so.toString() }));
/* 488 */       LOG.trace("Arquitectura 64b?" + OSTool.isSun64bits()); }
/*     */     String key;
/* 490 */     if (so.isWindows()) {
/* 491 */       key = getKeyOS("windows", so.getVersion(), OSTool.isSun64bits() ? "_64" : null, addendum != null ? "." + addendum : null); } else { String key;
/* 492 */       if (so.isLinux()) {
/* 493 */         key = getKeyOS("linux", so.getVersion(), OSTool.isSun64bits() ? "_64" : null, addendum != null ? "." + addendum : null); } else { String key;
/* 494 */         if (so.isMacOsX()) {
/* 495 */           key = getKeyOS("macosx", so.getVersion(), OSTool.isSun64bits() ? "_64" : null, addendum != null ? "." + addendum : null);
/*     */         } else
/* 497 */           throw new CopyFileException(I18N.getLocalMessage("i18n.mityc.api.tools.cp.2"));
/*     */       }
/*     */     }
/*     */     String key;
/* 501 */     String newDir = null;
/*     */     try {
/* 503 */       newDir = (dir != null) && (!dir.trim().equals("")) ? dir : new File(OSTool.getTempDir()).getCanonicalPath();
/*     */     } catch (IOException e) {
/* 505 */       LOG.error("No se puede canonicalizar la ruta: " + OSTool.getTempDir());
/* 506 */       newDir = (dir != null) && (!dir.trim().equals("")) ? dir : new File(OSTool.getTempDir()).getAbsolutePath();
/*     */     }
/* 508 */     if (updateLibraryPath) {
/* 509 */       if (LOG.isTraceEnabled()) {
/* 510 */         LOG.trace(I18N.getLocalMessage("i18n.mityc.api.tools.cp.16", new Object[] { newDir }));
/*     */       }
/* 512 */       updateLibraryPath(newDir);
/*     */     }
/*     */     
/* 515 */     if (LOG.isTraceEnabled()) {
/* 516 */       LOG.trace(I18N.getLocalMessage("i18n.mityc.api.tools.cp.10", new Object[] { key, newDir }));
/*     */     }
/*     */     
/* 519 */     if (suffix == null) {
/* 520 */       if (LOG.isDebugEnabled()) {
/* 521 */         LOG.debug("Se carga la librería " + key);
/*     */       }
/*     */       try {
/* 524 */         copyFiles(newDir, key);
/*     */       } catch (CopyFileException e) {
/* 526 */         if (dir != null) {
/* 527 */           return copyFilesOS(null, addendum, updateLibraryPath, suffix);
/*     */         }
/* 529 */         throw e;
/*     */       }
/*     */     }
/*     */     else {
/* 533 */       if (LOG.isDebugEnabled()) {
/* 534 */         LOG.debug("Se carga la librería alternativa con el sufijo " + suffix);
/*     */       }
/* 536 */       copyFiles(newDir, key, suffix);
/*     */     }
/*     */     
/* 539 */     return newDir;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean hasProp(String prop)
/*     */   {
/* 548 */     if ((this.props != null) && (prop != null)) {
/* 549 */       return this.props.getProperty(prop) != null;
/*     */     }
/* 551 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void updateLibraryPath(String path)
/*     */   {
/* 560 */     String libPath = System.getProperty("java.library.path");
/* 561 */     File fileDir = new File(path);
/* 562 */     if (!libPath.contains(fileDir.getAbsolutePath())) {
/* 563 */       libPath = fileDir.getAbsolutePath() + File.pathSeparator + libPath;
/* 564 */       System.setProperty("java.library.path", libPath);
/*     */       try {
/* 566 */         Field fieldSysPath = ClassLoader.class.getDeclaredField("sys_paths");
/* 567 */         fieldSysPath.setAccessible(true);
/* 568 */         if (fieldSysPath != null) {
/* 569 */           fieldSysPath.set(System.class.getClassLoader(), null);
/*     */         }
/*     */       } catch (NoSuchFieldException ex) {
/* 572 */         LOG.error(I18N.getLocalMessage("i18n.mityc.api.tools.cp.3"), ex);
/*     */       } catch (IllegalAccessException ex) {
/* 574 */         LOG.error(I18N.getLocalMessage("i18n.mityc.api.tools.cp.3"), ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void copyFiles(String dir, String clave)
/*     */     throws CopyFileException
/*     */   {
/* 588 */     copyFiles(dir, clave, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void copyFiles(String dir, String clave, String sufijo)
/*     */     throws CopyFileException
/*     */   {
/* 601 */     if (this.props != null) {
/*     */       try {
/* 603 */         String conjunto = this.props.getProperty(clave);
/* 604 */         if (LOG.isTraceEnabled()) {
/* 605 */           LOG.trace(I18N.getLocalMessage("i18n.mityc.api.tools.cp.15", new Object[] { conjunto }));
/*     */         }
/* 607 */         if (conjunto == null) {
/* 608 */           LOG.error(I18N.getLocalMessage("i18n.mityc.api.tools.cp.4", new Object[] { clave }));
/* 609 */           throw new CopyFileException(I18N.getLocalMessage("i18n.mityc.api.tools.cp.4", new Object[] { clave }));
/*     */         }
/* 611 */         StringTokenizer st = new StringTokenizer(conjunto, ",");
/* 612 */         boolean hasMore = st.hasMoreTokens();
/* 613 */         String finalFicheroDestino = "";
/* 614 */         while (hasMore)
/*     */         {
/* 616 */           String fichero = st.nextToken();
/* 617 */           hasMore = st.hasMoreTokens();
/* 618 */           if (fichero != null)
/*     */           {
/*     */ 
/* 621 */             String nombreFichero = this.props.getProperty("file." + fichero + ".name");
/* 622 */             String resname = this.props.getProperty("file." + fichero + ".res");
/* 623 */             CRCInfo crcInfo = getCRC(fichero);
/*     */             try {
/* 625 */               long size = Long.parseLong(this.props.getProperty("file." + fichero + ".size"));
/*     */               
/* 627 */               if (sufijo != null) {
/* 628 */                 finalFicheroDestino = nombreFichero.substring(0, nombreFichero.indexOf('.')) + sufijo + nombreFichero.substring(nombreFichero.indexOf('.'));
/*     */               } else {
/* 630 */                 finalFicheroDestino = nombreFichero;
/*     */               }
/* 632 */               LOG.trace("*********DATOS COPIA. nombreFichero=" + nombreFichero + ",sufijo=" + sufijo + ",ficheroDestino=" + finalFicheroDestino + ",dir=" + dir);
/* 633 */               copyRes(dir, nombreFichero, finalFicheroDestino, resname, crcInfo, size);
/* 634 */               this.vCopiedLibraries.add(finalFicheroDestino);
/*     */             } catch (NumberFormatException e) {
/* 636 */               LOG.error(I18N.getLocalMessage("i18n.mityc.api.tools.cp.4", new Object[] { "file." + fichero + ".size" }));
/* 637 */               throw new CopyFileException(I18N.getLocalMessage("i18n.mityc.api.tools.cp.4", new Object[] { "file." + fichero + ".size" }));
/*     */             }
/*     */           }
/*     */         }
/* 641 */       } catch (MissingResourceException ex) { LOG.error(I18N.getLocalMessage("i18n.mityc.api.tools.cp.4", new Object[] { clave }));
/* 642 */         throw new CopyFileException(I18N.getLocalMessage("i18n.mityc.api.tools.cp.4", new Object[] { clave }));
/*     */       }
/*     */     } else {
/* 645 */       LOG.error(I18N.getLocalMessage("i18n.mityc.api.tools.cp.6"));
/* 646 */       throw new CopyFileException(I18N.getLocalMessage("i18n.mityc.api.tools.cp.6"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private CRCInfo getCRC(String fichero)
/*     */     throws CopyFileException
/*     */   {
/*     */     try
/*     */     {
/* 661 */       String value = this.props.getProperty("file." + fichero + ".Adler32");
/* 662 */       if (value == null) {
/* 663 */         throw new CopyFileException(I18N.getLocalMessage("i18n.mityc.api.tools.cp.5"));
/*     */       }
/* 665 */       Adler32Info crc = new Adler32Info(null);
/* 666 */       crc.processValue(value);
/* 667 */       return crc;
/*     */     }
/*     */     catch (MissingResourceException localMissingResourceException) {
/*     */       try {
/* 671 */         String value = this.props.getProperty("file." + fichero + ".SHA2");
/* 672 */         if (value == null) {
/* 673 */           throw new CopyFileException(I18N.getLocalMessage("i18n.mityc.api.tools.cp.5"));
/*     */         }
/* 675 */         SHA2Info crc = new SHA2Info(null);
/* 676 */         crc.processValue(value);
/* 677 */         return crc;
/*     */       } catch (MissingResourceException localMissingResourceException1) {
/* 679 */         throw new CopyFileException(I18N.getLocalMessage("i18n.mityc.api.tools.cp.4"));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private void copyRes(String dir, String fichero, String ficheroDestino, String resname, CRCInfo crcValue, long size)
/*     */     throws CopyFileException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore 8
/*     */     //   3: aconst_null
/*     */     //   4: astore 9
/*     */     //   6: new 341	java/io/File
/*     */     //   9: dup
/*     */     //   10: aload_1
/*     */     //   11: invokespecial 346	java/io/File:<init>	(Ljava/lang/String;)V
/*     */     //   14: astore 10
/*     */     //   16: aload 10
/*     */     //   18: invokevirtual 527	java/io/File:exists	()Z
/*     */     //   21: ifne +36 -> 57
/*     */     //   24: getstatic 72	es/mityc/javasign/utils/CopyFilesTool:LOG	Lorg/apache/commons/logging/Log;
/*     */     //   27: getstatic 82	es/mityc/javasign/utils/CopyFilesTool:I18N	Les/mityc/javasign/i18n/II18nManager;
/*     */     //   30: ldc_w 530
/*     */     //   33: iconst_1
/*     */     //   34: anewarray 3	java/lang/Object
/*     */     //   37: dup
/*     */     //   38: iconst_0
/*     */     //   39: aload_1
/*     */     //   40: aastore
/*     */     //   41: invokeinterface 155 3 0
/*     */     //   46: invokeinterface 532 2 0
/*     */     //   51: aload 10
/*     */     //   53: invokevirtual 535	java/io/File:mkdirs	()Z
/*     */     //   56: pop
/*     */     //   57: new 341	java/io/File
/*     */     //   60: dup
/*     */     //   61: aload_1
/*     */     //   62: aload_2
/*     */     //   63: invokespecial 538	java/io/File:<init>	(Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   66: astore 11
/*     */     //   68: new 341	java/io/File
/*     */     //   71: dup
/*     */     //   72: aload_1
/*     */     //   73: aload_3
/*     */     //   74: invokespecial 538	java/io/File:<init>	(Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   77: astore 12
/*     */     //   79: aload 11
/*     */     //   81: invokevirtual 527	java/io/File:exists	()Z
/*     */     //   84: ifeq +24 -> 108
/*     */     //   87: aload_0
/*     */     //   88: aload 11
/*     */     //   90: aload 5
/*     */     //   92: lload 6
/*     */     //   94: invokespecial 539	es/mityc/javasign/utils/CopyFilesTool:checkIntegrityFile	(Ljava/io/File;Les/mityc/javasign/utils/CopyFilesTool$CRCInfo;J)Z
/*     */     //   97: ifeq +11 -> 108
/*     */     //   100: aload_2
/*     */     //   101: aload_3
/*     */     //   102: invokevirtual 337	java/lang/String:equals	(Ljava/lang/Object;)Z
/*     */     //   105: ifne +330 -> 435
/*     */     //   108: getstatic 72	es/mityc/javasign/utils/CopyFilesTool:LOG	Lorg/apache/commons/logging/Log;
/*     */     //   111: invokeinterface 138 1 0
/*     */     //   116: ifeq +34 -> 150
/*     */     //   119: getstatic 72	es/mityc/javasign/utils/CopyFilesTool:LOG	Lorg/apache/commons/logging/Log;
/*     */     //   122: getstatic 82	es/mityc/javasign/utils/CopyFilesTool:I18N	Les/mityc/javasign/i18n/II18nManager;
/*     */     //   125: ldc_w 543
/*     */     //   128: iconst_1
/*     */     //   129: anewarray 3	java/lang/Object
/*     */     //   132: dup
/*     */     //   133: iconst_0
/*     */     //   134: aload 11
/*     */     //   136: invokevirtual 352	java/io/File:getAbsolutePath	()Ljava/lang/String;
/*     */     //   139: aastore
/*     */     //   140: invokeinterface 155 3 0
/*     */     //   145: invokeinterface 161 2 0
/*     */     //   150: new 545	java/io/BufferedInputStream
/*     */     //   153: dup
/*     */     //   154: aload_0
/*     */     //   155: getfield 102	es/mityc/javasign/utils/CopyFilesTool:internalClassLoader	Ljava/lang/ClassLoader;
/*     */     //   158: aload 4
/*     */     //   160: invokevirtual 547	java/lang/ClassLoader:getResourceAsStream	(Ljava/lang/String;)Ljava/io/InputStream;
/*     */     //   163: sipush 32000
/*     */     //   166: invokespecial 551	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;I)V
/*     */     //   169: astore 8
/*     */     //   171: new 554	java/io/BufferedOutputStream
/*     */     //   174: dup
/*     */     //   175: new 556	java/io/FileOutputStream
/*     */     //   178: dup
/*     */     //   179: aload 12
/*     */     //   181: invokespecial 558	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
/*     */     //   184: invokespecial 561	java/io/BufferedOutputStream:<init>	(Ljava/io/OutputStream;)V
/*     */     //   187: astore 9
/*     */     //   189: getstatic 72	es/mityc/javasign/utils/CopyFilesTool:LOG	Lorg/apache/commons/logging/Log;
/*     */     //   192: getstatic 82	es/mityc/javasign/utils/CopyFilesTool:I18N	Les/mityc/javasign/i18n/II18nManager;
/*     */     //   195: ldc_w 564
/*     */     //   198: iconst_2
/*     */     //   199: anewarray 3	java/lang/Object
/*     */     //   202: dup
/*     */     //   203: iconst_0
/*     */     //   204: aload 4
/*     */     //   206: aastore
/*     */     //   207: dup
/*     */     //   208: iconst_1
/*     */     //   209: aload 12
/*     */     //   211: aastore
/*     */     //   212: invokeinterface 155 3 0
/*     */     //   217: invokeinterface 161 2 0
/*     */     //   222: sipush 4096
/*     */     //   225: newarray <illegal type>
/*     */     //   227: astore 13
/*     */     //   229: aload 8
/*     */     //   231: aload 13
/*     */     //   233: invokevirtual 566	java/io/InputStream:read	([B)I
/*     */     //   236: istore 14
/*     */     //   238: goto +22 -> 260
/*     */     //   241: aload 9
/*     */     //   243: aload 13
/*     */     //   245: iconst_0
/*     */     //   246: iload 14
/*     */     //   248: invokevirtual 572	java/io/OutputStream:write	([BII)V
/*     */     //   251: aload 8
/*     */     //   253: aload 13
/*     */     //   255: invokevirtual 566	java/io/InputStream:read	([B)I
/*     */     //   258: istore 14
/*     */     //   260: iload 14
/*     */     //   262: ifgt -21 -> 241
/*     */     //   265: aload 9
/*     */     //   267: invokevirtual 578	java/io/OutputStream:flush	()V
/*     */     //   270: aload 12
/*     */     //   272: invokevirtual 527	java/io/File:exists	()Z
/*     */     //   275: ifeq +160 -> 435
/*     */     //   278: aload_1
/*     */     //   279: invokestatic 343	es/mityc/javasign/utils/OSTool:getTempDir	()Ljava/lang/String;
/*     */     //   282: invokevirtual 393	java/lang/String:contains	(Ljava/lang/CharSequence;)Z
/*     */     //   285: ifeq +150 -> 435
/*     */     //   288: aload 12
/*     */     //   290: invokevirtual 581	java/io/File:deleteOnExit	()V
/*     */     //   293: goto +142 -> 435
/*     */     //   296: astore 10
/*     */     //   298: getstatic 72	es/mityc/javasign/utils/CopyFilesTool:LOG	Lorg/apache/commons/logging/Log;
/*     */     //   301: getstatic 82	es/mityc/javasign/utils/CopyFilesTool:I18N	Les/mityc/javasign/i18n/II18nManager;
/*     */     //   304: ldc_w 584
/*     */     //   307: invokeinterface 330 2 0
/*     */     //   312: aload 10
/*     */     //   314: invokeinterface 420 3 0
/*     */     //   319: new 285	es/mityc/javasign/exception/CopyFileException
/*     */     //   322: dup
/*     */     //   323: aload 10
/*     */     //   325: invokespecial 586	es/mityc/javasign/exception/CopyFileException:<init>	(Ljava/lang/Throwable;)V
/*     */     //   328: athrow
/*     */     //   329: astore 10
/*     */     //   331: getstatic 72	es/mityc/javasign/utils/CopyFilesTool:LOG	Lorg/apache/commons/logging/Log;
/*     */     //   334: getstatic 82	es/mityc/javasign/utils/CopyFilesTool:I18N	Les/mityc/javasign/i18n/II18nManager;
/*     */     //   337: ldc_w 589
/*     */     //   340: iconst_2
/*     */     //   341: anewarray 3	java/lang/Object
/*     */     //   344: dup
/*     */     //   345: iconst_0
/*     */     //   346: aload_2
/*     */     //   347: aastore
/*     */     //   348: dup
/*     */     //   349: iconst_1
/*     */     //   350: aload_1
/*     */     //   351: aastore
/*     */     //   352: invokeinterface 155 3 0
/*     */     //   357: aload 10
/*     */     //   359: invokeinterface 420 3 0
/*     */     //   364: new 285	es/mityc/javasign/exception/CopyFileException
/*     */     //   367: dup
/*     */     //   368: aload 10
/*     */     //   370: invokespecial 586	es/mityc/javasign/exception/CopyFileException:<init>	(Ljava/lang/Throwable;)V
/*     */     //   373: athrow
/*     */     //   374: astore 15
/*     */     //   376: aload 8
/*     */     //   378: ifnull +26 -> 404
/*     */     //   381: aload 8
/*     */     //   383: invokevirtual 591	java/io/InputStream:close	()V
/*     */     //   386: goto +18 -> 404
/*     */     //   389: astore 16
/*     */     //   391: getstatic 72	es/mityc/javasign/utils/CopyFilesTool:LOG	Lorg/apache/commons/logging/Log;
/*     */     //   394: aload 16
/*     */     //   396: invokevirtual 189	java/io/IOException:getMessage	()Ljava/lang/String;
/*     */     //   399: invokeinterface 195 2 0
/*     */     //   404: aload 9
/*     */     //   406: ifnull +26 -> 432
/*     */     //   409: aload 9
/*     */     //   411: invokevirtual 594	java/io/OutputStream:close	()V
/*     */     //   414: goto +18 -> 432
/*     */     //   417: astore 16
/*     */     //   419: getstatic 72	es/mityc/javasign/utils/CopyFilesTool:LOG	Lorg/apache/commons/logging/Log;
/*     */     //   422: aload 16
/*     */     //   424: invokevirtual 189	java/io/IOException:getMessage	()Ljava/lang/String;
/*     */     //   427: invokeinterface 195 2 0
/*     */     //   432: aload 15
/*     */     //   434: athrow
/*     */     //   435: aload 8
/*     */     //   437: ifnull +26 -> 463
/*     */     //   440: aload 8
/*     */     //   442: invokevirtual 591	java/io/InputStream:close	()V
/*     */     //   445: goto +18 -> 463
/*     */     //   448: astore 16
/*     */     //   450: getstatic 72	es/mityc/javasign/utils/CopyFilesTool:LOG	Lorg/apache/commons/logging/Log;
/*     */     //   453: aload 16
/*     */     //   455: invokevirtual 189	java/io/IOException:getMessage	()Ljava/lang/String;
/*     */     //   458: invokeinterface 195 2 0
/*     */     //   463: aload 9
/*     */     //   465: ifnull +26 -> 491
/*     */     //   468: aload 9
/*     */     //   470: invokevirtual 594	java/io/OutputStream:close	()V
/*     */     //   473: goto +18 -> 491
/*     */     //   476: astore 16
/*     */     //   478: getstatic 72	es/mityc/javasign/utils/CopyFilesTool:LOG	Lorg/apache/commons/logging/Log;
/*     */     //   481: aload 16
/*     */     //   483: invokevirtual 189	java/io/IOException:getMessage	()Ljava/lang/String;
/*     */     //   486: invokeinterface 195 2 0
/*     */     //   491: return
/*     */     // Line number table:
/*     */     //   Java source line #694	-> byte code offset #0
/*     */     //   Java source line #695	-> byte code offset #3
/*     */     //   Java source line #697	-> byte code offset #6
/*     */     //   Java source line #698	-> byte code offset #16
/*     */     //   Java source line #699	-> byte code offset #24
/*     */     //   Java source line #700	-> byte code offset #51
/*     */     //   Java source line #702	-> byte code offset #57
/*     */     //   Java source line #703	-> byte code offset #68
/*     */     //   Java source line #704	-> byte code offset #79
/*     */     //   Java source line #705	-> byte code offset #108
/*     */     //   Java source line #706	-> byte code offset #119
/*     */     //   Java source line #708	-> byte code offset #150
/*     */     //   Java source line #709	-> byte code offset #171
/*     */     //   Java source line #710	-> byte code offset #189
/*     */     //   Java source line #711	-> byte code offset #222
/*     */     //   Java source line #712	-> byte code offset #229
/*     */     //   Java source line #713	-> byte code offset #238
/*     */     //   Java source line #714	-> byte code offset #241
/*     */     //   Java source line #715	-> byte code offset #251
/*     */     //   Java source line #713	-> byte code offset #260
/*     */     //   Java source line #717	-> byte code offset #265
/*     */     //   Java source line #718	-> byte code offset #270
/*     */     //   Java source line #719	-> byte code offset #288
/*     */     //   Java source line #722	-> byte code offset #293
/*     */     //   Java source line #723	-> byte code offset #298
/*     */     //   Java source line #724	-> byte code offset #319
/*     */     //   Java source line #725	-> byte code offset #329
/*     */     //   Java source line #726	-> byte code offset #331
/*     */     //   Java source line #727	-> byte code offset #364
/*     */     //   Java source line #729	-> byte code offset #374
/*     */     //   Java source line #730	-> byte code offset #376
/*     */     //   Java source line #732	-> byte code offset #381
/*     */     //   Java source line #733	-> byte code offset #386
/*     */     //   Java source line #734	-> byte code offset #391
/*     */     //   Java source line #737	-> byte code offset #404
/*     */     //   Java source line #739	-> byte code offset #409
/*     */     //   Java source line #740	-> byte code offset #414
/*     */     //   Java source line #741	-> byte code offset #419
/*     */     //   Java source line #744	-> byte code offset #432
/*     */     //   Java source line #730	-> byte code offset #435
/*     */     //   Java source line #732	-> byte code offset #440
/*     */     //   Java source line #733	-> byte code offset #445
/*     */     //   Java source line #734	-> byte code offset #450
/*     */     //   Java source line #737	-> byte code offset #463
/*     */     //   Java source line #739	-> byte code offset #468
/*     */     //   Java source line #740	-> byte code offset #473
/*     */     //   Java source line #741	-> byte code offset #478
/*     */     //   Java source line #745	-> byte code offset #491
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	492	0	this	CopyFilesTool
/*     */     //   0	492	1	dir	String
/*     */     //   0	492	2	fichero	String
/*     */     //   0	492	3	ficheroDestino	String
/*     */     //   0	492	4	resname	String
/*     */     //   0	492	5	crcValue	CRCInfo
/*     */     //   0	492	6	size	long
/*     */     //   1	440	8	entrada	InputStream
/*     */     //   4	465	9	salida	java.io.OutputStream
/*     */     //   14	38	10	dirFile	File
/*     */     //   296	28	10	ex	java.io.FileNotFoundException
/*     */     //   329	40	10	ex	IOException
/*     */     //   66	69	11	file	File
/*     */     //   77	212	12	fileDestino	File
/*     */     //   227	27	13	buffer	byte[]
/*     */     //   236	25	14	readed	int
/*     */     //   374	59	15	localObject	Object
/*     */     //   389	6	16	e	IOException
/*     */     //   417	6	16	e	IOException
/*     */     //   448	6	16	e	IOException
/*     */     //   476	6	16	e	IOException
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   6	293	296	java/io/FileNotFoundException
/*     */     //   6	293	329	java/io/IOException
/*     */     //   6	374	374	finally
/*     */     //   381	386	389	java/io/IOException
/*     */     //   409	414	417	java/io/IOException
/*     */     //   440	445	448	java/io/IOException
/*     */     //   468	473	476	java/io/IOException
/*     */   }
/*     */   
/*     */   private boolean checkIntegrityFile(File file, CRCInfo crcValue, long size)
/*     */     throws IOException, CopyFileException
/*     */   {
/* 762 */     if (LOG.isTraceEnabled()) {
/* 763 */       LOG.trace(I18N.getLocalMessage("i18n.mityc.api.tools.cp.12", new Object[] { file.getAbsolutePath() }));
/*     */     }
/* 765 */     if (!file.exists()) {
/* 766 */       return false;
/*     */     }
/*     */     
/* 769 */     if (file.length() != size) {
/* 770 */       return false;
/*     */     }
/*     */     
/* 773 */     return crcValue.checkFile(file);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String toHexString(byte[] data)
/*     */   {
/* 783 */     StringBuffer sb = new StringBuffer();
/* 784 */     int pos = data.length;
/* 785 */     while (pos > 0) {
/* 786 */       sb.append(Integer.toHexString(data[(--pos)]));
/*     */     }
/* 788 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector<String> getCopiedLibraries()
/*     */   {
/* 796 */     return this.vCopiedLibraries;
/*     */   }
/*     */   
/*     */   private abstract class CRCInfo
/*     */   {
/*     */     private CRCInfo() {}
/*     */     
/*     */     protected abstract void processValue(String paramString)
/*     */       throws CopyFileException;
/*     */     
/*     */     protected abstract CopyFilesTool.CrcIntegrityEnum getCrcType();
/*     */     
/*     */     public abstract boolean checkFile(File paramFile)
/*     */       throws CopyFileException;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\utils\CopyFilesTool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */