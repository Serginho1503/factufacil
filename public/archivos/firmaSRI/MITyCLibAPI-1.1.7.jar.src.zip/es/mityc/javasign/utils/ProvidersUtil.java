/*    */ package es.mityc.javasign.utils;
/*    */ 
/*    */ import java.security.Security;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProvidersUtil
/*    */ {
/*    */   public static void registerProvider(String name)
/*    */   {
/* 27 */     for (int i = 1; i <= 50; i++) {
/*    */       try {
/* 29 */         if (Security.getProperty("security.provider." + i) == null) {
/* 30 */           Security.setProperty("security.provider." + i, name);
/*    */         }
/*    */       }
/*    */       catch (Exception e) {
/* 34 */         e.printStackTrace();
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\utils\ProvidersUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */