/*     */ package es.mityc.javasign.utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HexUtils
/*     */ {
/*     */   public static String convert(byte[] data)
/*     */   {
/*  35 */     return hexString(data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] convert(String hex)
/*     */   {
/*  44 */     return fromHexString(hex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  50 */   private static final char[] NIBBLE = {
/*  51 */     '0', '1', '2', '3', '4', '5', '6', '7', 
/*  52 */     '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String hexString(byte[] buf, int i, int longitud)
/*     */   {
/*  63 */     StringBuffer sb = new StringBuffer();
/*  64 */     for (int j = i; j < i + longitud; j++) {
/*  65 */       sb.append(NIBBLE[(buf[j] >>> 4 & 0xF)]);
/*  66 */       sb.append(NIBBLE[(buf[j] & 0xF)]);
/*     */     }
/*  68 */     return String.valueOf(sb);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String hexString(byte[] buf)
/*     */   {
/*  77 */     return hexString(buf, 0, buf.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static byte fromHexNibble(char n)
/*     */   {
/*  86 */     if (n <= '9') {
/*  87 */       return (byte)(n - '0');
/*     */     }
/*  89 */     if (n <= 'G') {
/*  90 */       return (byte)(n - '7');
/*     */     }
/*  92 */     return (byte)(n - 'W');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static byte[] fromHexString(String hex)
/*     */   {
/* 101 */     int l = hex.length() + 1 >>> 1;
/* 102 */     byte[] r = new byte[l];
/* 103 */     int i = 0;
/* 104 */     int j = 0;
/* 105 */     if (hex.length() % 2 != 0)
/*     */     {
/* 107 */       r[0] = fromHexNibble(hex.charAt(0));
/* 108 */       i = 1;j = 1;
/*     */     }
/* 110 */     while (i < l) {
/* 111 */       r[(i++)] = ((byte)(fromHexNibble(hex.charAt(j++)) << 4 | fromHexNibble(hex.charAt(j++))));
/*     */     }
/* 113 */     return r;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\utils\HexUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */