/*    */ package es.mityc.javasign.utils;
/*    */ 
/*    */ import java.security.InvalidKeyException;
/*    */ import java.security.NoSuchProviderException;
/*    */ import java.security.SignatureException;
/*    */ import java.security.cert.X509Certificate;
/*    */ 
/*    */ public class CertsUtil
/*    */ {
/*    */   public static boolean isRootCA(X509Certificate cert)
/*    */   {
/* 12 */     boolean ret = false;
/*    */     try {
/* 14 */       cert.verify(cert.getPublicKey());
/* 15 */       ret = true;
/*    */     }
/*    */     catch (InvalidKeyException localInvalidKeyException) {}catch (java.security.cert.CertificateException localCertificateException) {}catch (java.security.NoSuchAlgorithmException localNoSuchAlgorithmException) {}catch (NoSuchProviderException localNoSuchProviderException) {}catch (SignatureException localSignatureException) {}
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 22 */     return ret;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\utils\CertsUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */