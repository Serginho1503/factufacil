/*     */ package es.mityc.javasign.utils;
/*     */ 
/*     */ import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;
/*     */ import java.io.IOException;
/*     */ import java.net.Authenticator;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.Proxy;
/*     */ import java.net.Proxy.Type;
/*     */ import java.net.URL;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProxyUtil
/*     */ {
/*  39 */   static Log log = LogFactory.getLog(ProxyUtil.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HttpURLConnection getConnection(String URL)
/*     */     throws MalformedURLException, IOException
/*     */   {
/*  50 */     HttpURLConnection conn = null;
/*  51 */     if ((System.getProperty("http.proxySet") != null) && 
/*  52 */       (Boolean.parseBoolean(System.getProperty("http.proxySet"))) && 
/*  53 */       (!isInNonHosts(URL))) {
/*  54 */       if (log.isDebugEnabled()) {
/*  55 */         log.debug("Conexión a través de Proxy a " + URL);
/*     */       }
/*  57 */       Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(System.getProperty("http.proxyHost"), Integer.parseInt(System.getProperty("http.proxyPort"))));
/*  58 */       conn = (HttpURLConnection)new URL(URL).openConnection(proxy);
/*     */       
/*  60 */       if ((System.getProperty("http.proxyUser") != null) && (!"".equals(System.getProperty("http.proxyUser")))) {
/*  61 */         if (log.isDebugEnabled()) {
/*  62 */           log.debug("Proxy - Autenticando con " + System.getProperty("http.proxyUser"));
/*     */         }
/*  64 */         Authenticator.setDefault(new SimpleAuthenticator(System.getProperty("http.proxyUser"), System.getProperty("http.proxyPassword")));
/*  65 */         String encoded = new String(Base64.encode(new String(System.getProperty("http.proxyUser") + 
/*  66 */           ":" + System.getProperty("http.proxyPassword")).getBytes()));
/*  67 */         conn.setRequestProperty("Proxy-Authorization", "NTLM " + encoded);
/*     */       }
/*     */     } else {
/*  70 */       if (log.isDebugEnabled()) {
/*  71 */         log.debug("Conexión directa a " + URL);
/*     */       }
/*  73 */       conn = (HttpURLConnection)new URL(URL).openConnection();
/*     */     }
/*  75 */     return conn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isInNonHosts(String URL)
/*     */   {
/*     */     try
/*     */     {
/*  85 */       String nonHostsList = System.getProperty("http.nonProxyHosts");
/*  86 */       if ((nonHostsList != null) && (nonHostsList.trim().length() > 0)) {
/*  87 */         StringTokenizer st = new StringTokenizer(nonHostsList, "|");
/*  88 */         while (st.hasMoreTokens()) {
/*  89 */           String host = st.nextToken();
/*  90 */           URL url = new URL(URL);
/*     */           
/*     */           try
/*     */           {
/*  94 */             InetAddress inet = InetAddress.getByName(host);
/*  95 */             InetAddress inetDestino = InetAddress.getByName(url.getHost());
/*  96 */             String ip = inet.getHostAddress();
/*  97 */             String ipDestino = inetDestino.getHostAddress();
/*  98 */             for (int j = 0; j < ip.length(); j++) {
/*  99 */               if (ipDestino.charAt(j) != ip.charAt(j)) {
/*     */                 break;
/*     */               }
/* 102 */               if ((j > 0) && (host.charAt(j) == '.')) {
/* 103 */                 return true;
/*     */               }
/*     */             }
/*     */           } catch (Exception e) {
/* 107 */             log.debug("Error al comprobar la lista NonHosts por IP", e);
/* 108 */             break;
/*     */           }
/*     */           
/*     */ 
/* 112 */           int i = 0;
/* 113 */           int lenght = host.length();
/* 114 */           while (((host.startsWith("*")) || (host.startsWith("."))) && (i < lenght)) {
/* 115 */             i++;
/* 116 */             host = host.substring(1);
/*     */           }
/* 118 */           if (url.getHost().contains(host)) {
/* 119 */             if (log.isDebugEnabled()) {
/* 120 */               log.debug("URL filtrada para el proxy");
/*     */             }
/* 122 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (IOException e) {
/* 127 */       log.error("Error al comprobar la lista NonHosts", e);
/* 128 */       return false;
/*     */     }
/*     */     
/* 131 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\utils\ProxyUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */