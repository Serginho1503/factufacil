/*     */ package es.mityc.javasign.utils;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OSTool
/*     */ {
/*  31 */   private static final Log LOGGER = LogFactory.getLog(OSTool.class);
/*     */   
/*     */ 
/*     */   private static final String STRING_EMPTY = "";
/*     */   
/*     */ 
/*     */   private static final String STRING_BACKSLASH = "\\";
/*     */   
/*     */   private static final String OS_NAME = "os.name";
/*     */   
/*     */   private static final String OS_VERSION = "os.version";
/*     */   
/*     */   private static final String OS_ARCH = "os.arch";
/*     */   
/*     */   private static final String OS_ARCH_ALTERNATIVE = "sun.arch.data.model";
/*     */   
/*     */   private static final String WIN = "win";
/*     */   
/*     */   private static final String LINUX = "linux";
/*     */   
/*     */   private static final String MAC_OS = "mac os x";
/*     */   
/*     */   private static final String JAVAPLUGIN_VERSION = "javaplugin.version";
/*     */   
/*     */   private static final String USER_NAME = "user.name";
/*     */   
/*     */   private static final String FILE_SEPARATOR = "file.separator";
/*     */   
/*  59 */   public static final String[] WINDOWS4_NAMES = { "windows 95", "windows 98", "windows 2000", "windows 9x" };
/*     */   
/*  61 */   public static final String[] WINDOWS5_NAMES = { "windows 2000", "windows xp", "windows 2003", "windows nt" };
/*     */   
/*  63 */   public static final String[] WINDOWS6_NAMES = { "windows vista", "windows 7", "windows server 2008", "windows server 2008 r2" };
/*     */   
/*  65 */   public static final String[] WINDOWS_VERSIONS = { "4", "5", "6" };
/*     */   
/*  67 */   public static final String[] WINDOWS_ARCHS_64BITS = { "ia64", "amd64" };
/*     */   
/*     */   private static final int WINDOWS_DEFAULT_VERSION = 5;
/*     */   
/*  71 */   public static final String[] LINUX_VERSIONS = { "24", "26" };
/*     */   
/*  73 */   public static final String[] MACOSX_VERSIONS = { "104", "105", "106" };
/*     */   
/*  75 */   public static final String[] MACOSX_ARCHS_64BITS = { "x86_64" };
/*     */   
/*  77 */   public static final String[] SUN_ARCHS = { "32", "64" };
/*     */   
/*  79 */   public static enum OS_NAMES { UNKNOWN,  WINDOWS,  LINUX,  MAC_OS_X; }
/*     */   
/*  81 */   public static enum OS_BITS { UNKNOWN,  OS32BITS,  OS64BITS;
/*     */   }
/*     */   
/*     */   public static enum OS {
/*  85 */     UNKNOWN(
/*  86 */       OSTool.OS_NAMES.UNKNOWN, "", OSTool.OS_BITS.UNKNOWN, "unknown"), 
/*  87 */     WIN_4_32(
/*  88 */       OSTool.OS_NAMES.WINDOWS, OSTool.WINDOWS_VERSIONS[0], OSTool.OS_BITS.OS32BITS, "Windows 4.0 32bits"), 
/*  89 */     WIN_4_64(
/*  90 */       OSTool.OS_NAMES.WINDOWS, OSTool.WINDOWS_VERSIONS[0], OSTool.OS_BITS.OS64BITS, "Windows 4.0 64bits"), 
/*  91 */     WIN_5_32(
/*  92 */       OSTool.OS_NAMES.WINDOWS, OSTool.WINDOWS_VERSIONS[1], OSTool.OS_BITS.OS32BITS, "Windows 5.0 32bits"), 
/*  93 */     WIN_5_64(
/*  94 */       OSTool.OS_NAMES.WINDOWS, OSTool.WINDOWS_VERSIONS[1], OSTool.OS_BITS.OS64BITS, "Windows 5.0 64bits"), 
/*  95 */     WIN_6_32(
/*  96 */       OSTool.OS_NAMES.WINDOWS, OSTool.WINDOWS_VERSIONS[1], OSTool.OS_BITS.OS32BITS, "Windows 6.0 32bits"), 
/*  97 */     WIN_6_64(
/*  98 */       OSTool.OS_NAMES.WINDOWS, OSTool.WINDOWS_VERSIONS[1], OSTool.OS_BITS.OS64BITS, "Windows 6.0 64bits"), 
/*  99 */     LIN_24_32(
/* 100 */       OSTool.OS_NAMES.LINUX, OSTool.LINUX_VERSIONS[0], OSTool.OS_BITS.OS32BITS, "Linux 2.4 32bits"), 
/* 101 */     LIN_24_64(
/* 102 */       OSTool.OS_NAMES.LINUX, OSTool.LINUX_VERSIONS[0], OSTool.OS_BITS.OS64BITS, "Linux 2.4 64bits"), 
/* 103 */     LIN_26_32(
/* 104 */       OSTool.OS_NAMES.LINUX, OSTool.LINUX_VERSIONS[1], OSTool.OS_BITS.OS32BITS, "Linux 2.6 32bits"), 
/* 105 */     LIN_26_64(
/* 106 */       OSTool.OS_NAMES.LINUX, OSTool.LINUX_VERSIONS[1], OSTool.OS_BITS.OS64BITS, "Linux 2.6 64bits"), 
/* 107 */     MACOSX_104_32(
/* 108 */       OSTool.OS_NAMES.MAC_OS_X, OSTool.MACOSX_VERSIONS[0], OSTool.OS_BITS.OS32BITS, "Mac OS X 10.4 32bits"), 
/* 109 */     MACOSX_104_64(
/* 110 */       OSTool.OS_NAMES.MAC_OS_X, OSTool.MACOSX_VERSIONS[0], OSTool.OS_BITS.OS64BITS, "Mac OS X 10.4 64bits"), 
/* 111 */     MACOSX_105_32(
/* 112 */       OSTool.OS_NAMES.MAC_OS_X, OSTool.MACOSX_VERSIONS[1], OSTool.OS_BITS.OS32BITS, "Mac OS X 10.5 32bits"), 
/* 113 */     MACOSX_105_64(
/* 114 */       OSTool.OS_NAMES.MAC_OS_X, OSTool.MACOSX_VERSIONS[1], OSTool.OS_BITS.OS64BITS, "Mac OS X 10.5 64bits"), 
/* 115 */     MACOSX_106_32(
/* 116 */       OSTool.OS_NAMES.MAC_OS_X, OSTool.MACOSX_VERSIONS[1], OSTool.OS_BITS.OS32BITS, "Mac OS X 10.6 32bits"), 
/* 117 */     MACOSX_106_64(
/* 118 */       OSTool.OS_NAMES.MAC_OS_X, OSTool.MACOSX_VERSIONS[1], OSTool.OS_BITS.OS64BITS, "Mac OS X 10.6 64bits");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private OSTool.OS_NAMES osvalue;
/*     */     
/*     */ 
/*     */     private String version;
/*     */     
/*     */ 
/*     */     private OSTool.OS_BITS bits;
/*     */     
/*     */ 
/*     */     private String desc;
/*     */     
/*     */ 
/*     */ 
/*     */     private OS(OSTool.OS_NAMES osname, String osversion, OSTool.OS_BITS osbits, String description)
/*     */     {
/* 138 */       this.osvalue = osname;
/* 139 */       this.version = osversion;
/* 140 */       this.bits = osbits;
/* 141 */       this.desc = new String(description);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean isWindows()
/*     */     {
/* 148 */       if (OSTool.OS_NAMES.WINDOWS.equals(this.osvalue)) {
/* 149 */         return true;
/*     */       }
/* 151 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean isLinux()
/*     */     {
/* 158 */       if (OSTool.OS_NAMES.LINUX.equals(this.osvalue)) {
/* 159 */         return true;
/*     */       }
/* 161 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean isMacOsX()
/*     */     {
/* 168 */       if (OSTool.OS_NAMES.MAC_OS_X.equals(this.osvalue)) {
/* 169 */         return true;
/*     */       }
/* 171 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean is32bits()
/*     */     {
/* 178 */       if (OSTool.OS_BITS.OS32BITS.equals(this.bits)) {
/* 179 */         return true;
/*     */       }
/* 181 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean is64bits()
/*     */     {
/* 188 */       if (OSTool.OS_BITS.OS64BITS.equals(this.bits)) {
/* 189 */         return true;
/*     */       }
/* 191 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public String getVersion()
/*     */     {
/* 198 */       return this.version;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/* 207 */       return this.desc;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 219 */   private static OS actualSO = askSO();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isWindows64bits()
/*     */   {
/* 226 */     boolean res = isSun64bits();
/* 227 */     if (!res) {
/* 228 */       String osArch = System.getProperty("os.arch").toLowerCase();
/* 229 */       for (int i = 0; i < WINDOWS_ARCHS_64BITS.length; i++) {
/* 230 */         if (osArch.startsWith(WINDOWS_ARCHS_64BITS[i])) {
/* 231 */           res = true;
/* 232 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 236 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isMacosx64bits()
/*     */   {
/* 244 */     boolean res = isSun64bits();
/* 245 */     if (!res) {
/* 246 */       String osArch = System.getProperty("os.arch").toLowerCase();
/* 247 */       for (int i = 0; i < MACOSX_ARCHS_64BITS.length; i++) {
/* 248 */         if (osArch.startsWith(MACOSX_ARCHS_64BITS[i])) {
/* 249 */           res = true;
/* 250 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 254 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static boolean isSun64bits()
/*     */   {
/* 262 */     boolean res = false;
/* 263 */     String osArch = System.getProperty("sun.arch.data.model").toLowerCase();
/* 264 */     if ((osArch != null) && (osArch.startsWith(SUN_ARCHS[1]))) {
/* 265 */       res = true;
/*     */     }
/* 267 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int getWindowsMajorVersion()
/*     */   {
/* 275 */     int version = 5;
/* 276 */     String osVersion = System.getProperty("os.version");
/*     */     try {
/* 278 */       version = Integer.parseInt(osVersion.substring(0, osVersion.indexOf(".")));
/*     */     }
/*     */     catch (NumberFormatException localNumberFormatException) {}
/* 281 */     return version;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static OS askSO()
/*     */   {
/* 289 */     OS res = OS.UNKNOWN;
/*     */     
/* 291 */     String osName = System.getProperty("os.name");
/* 292 */     LOGGER.debug("SO: " + osName);
/* 293 */     if (osName.toLowerCase().startsWith("win")) {
/* 294 */       switch (getWindowsMajorVersion()) {
/*     */       case 5: 
/* 296 */         if (isWindows64bits()) {
/* 297 */           res = OS.WIN_5_64;
/*     */         } else {
/* 299 */           res = OS.WIN_5_32;
/*     */         }
/* 301 */         break;
/*     */       case 6: 
/* 303 */         if (isWindows64bits()) {
/* 304 */           res = OS.WIN_6_64;
/*     */         } else {
/* 306 */           res = OS.WIN_6_32;
/*     */         }
/* 308 */         break;
/*     */       case 4: 
/*     */       default: 
/* 311 */         if (isWindows64bits()) {
/* 312 */           res = OS.WIN_4_64;
/*     */         } else {
/* 314 */           res = OS.WIN_4_32;
/*     */         }
/*     */         break;
/*     */       }
/* 318 */       LOGGER.trace("Es un windows: " + res);
/* 319 */     } else if (osName.toLowerCase().startsWith("linux")) {
/* 320 */       LOGGER.trace("Es un linux");
/* 321 */       String osVersion = System.getProperty("os.version");
/* 322 */       if (osVersion.startsWith(LINUX_VERSIONS[0])) {
/* 323 */         if (isSun64bits()) {
/* 324 */           res = OS.LIN_24_64;
/*     */         } else {
/* 326 */           res = OS.LIN_24_32;
/*     */         }
/* 328 */       } else if (osVersion.startsWith(LINUX_VERSIONS[1])) {
/* 329 */         if (isSun64bits()) {
/* 330 */           res = OS.LIN_26_64;
/*     */         } else {
/* 332 */           res = OS.LIN_26_32;
/*     */         }
/*     */         
/*     */       }
/* 336 */       else if (isSun64bits()) {
/* 337 */         res = OS.LIN_26_64;
/*     */       } else {
/* 339 */         res = OS.LIN_26_32;
/*     */       }
/*     */     }
/* 342 */     else if (osName.toLowerCase().startsWith("mac os x")) {
/* 343 */       LOGGER.trace("Es un Mac OS X");
/* 344 */       String osVersion = System.getProperty("os.version");
/* 345 */       if (osVersion.startsWith(MACOSX_VERSIONS[0])) {
/* 346 */         if (isMacosx64bits()) {
/* 347 */           res = OS.MACOSX_104_64;
/*     */         } else {
/* 349 */           res = OS.MACOSX_104_32;
/*     */         }
/* 351 */       } else if (osVersion.startsWith(MACOSX_VERSIONS[1])) {
/* 352 */         if (isMacosx64bits()) {
/* 353 */           res = OS.MACOSX_105_64;
/*     */         } else {
/* 355 */           res = OS.MACOSX_105_32;
/*     */         }
/* 357 */       } else if (osVersion.startsWith(MACOSX_VERSIONS[2])) {
/* 358 */         if (isMacosx64bits()) {
/* 359 */           res = OS.MACOSX_106_64;
/*     */         } else {
/* 361 */           res = OS.MACOSX_106_32;
/*     */         }
/*     */         
/*     */       }
/* 365 */       else if (isMacosx64bits()) {
/* 366 */         res = OS.MACOSX_106_64;
/*     */       } else {
/* 368 */         res = OS.MACOSX_106_32;
/*     */       }
/*     */     }
/*     */     
/* 372 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static OS getSO()
/*     */   {
/* 380 */     return actualSO;
/*     */   }
/*     */   
/*     */ 
/* 384 */   private static boolean javaplugin = false;
/*     */   
/* 386 */   static { String pluginVersion = System.getProperty("javaplugin.version");
/* 387 */     if (pluginVersion != null) {
/* 388 */       javaplugin = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean isPlugin()
/*     */   {
/* 396 */     return javaplugin;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static boolean isOSLinux()
/*     */   {
/* 406 */     if (System.getProperty("os.name").toLowerCase().startsWith("linux")) {
/* 407 */       return true;
/*     */     }
/* 409 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static boolean isOSWindows()
/*     */   {
/* 419 */     if (System.getProperty("os.name").toLowerCase().startsWith("win")) {
/* 420 */       return true;
/*     */     }
/* 422 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getUserHome()
/*     */   {
/* 430 */     String home = System.getProperty("user.home");
/* 431 */     if (isOSWindows())
/*     */     {
/* 433 */       String path = home.substring(0, home.indexOf("\\"));
/* 434 */       return path.replace('\\', '/');
/*     */     }
/* 436 */     return home;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getUserName()
/*     */   {
/* 445 */     return System.getProperty("user.name");
/*     */   }
/*     */   
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static String getFileSeparator()
/*     */   {
/* 454 */     if (isOSWindows()) {
/* 455 */       return System.getProperty("file.separator").replace('\\', '/');
/*     */     }
/* 457 */     return System.getProperty("file.separator");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getTempDir()
/*     */   {
/* 466 */     return System.getProperty("java.io.tmpdir");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getHomeDir()
/*     */   {
/* 474 */     return getUserHome();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\utils\OSTool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */