/*     */ package es.mityc.javasign.utils;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.Provider;
/*     */ import java.security.Security;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.bouncycastle.jce.provider.BouncyCastleProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Utils
/*     */ {
/*  40 */   private static Log logger = LogFactory.getLog(Utils.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] getFileBytes(File file)
/*     */     throws IOException
/*     */   {
/*  49 */     if (!file.exists()) {
/*  50 */       throw new IOException("El fichero indicado: " + file.getAbsolutePath() + " no existe.");
/*     */     }
/*  52 */     return getStreamBytes(new FileInputStream(file));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void writeFile(byte[] fileData, String fileName)
/*     */     throws IOException
/*     */   {
/*  63 */     File file = null;
/*  64 */     if (fileName != null) {
/*  65 */       file = new File(fileName);
/*     */     }
/*  67 */     writeFile(fileData, file);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void writeFile(byte[] fileData, File file)
/*     */     throws IOException
/*     */   {
/*  78 */     OutputStream os = null;
/*  79 */     if ((fileData == null) || (fileData.length <= 0)) {
/*  80 */       throw new IOException("Los datos a escribir son nulos o estan vacíos");
/*     */     }
/*     */     
/*  83 */     if (file == null) {
/*  84 */       os = System.out;
/*     */     } else {
/*  86 */       os = new FileOutputStream(file);
/*     */     }
/*  88 */     if (os == null) {
/*  89 */       throw new IOException("No se pudo recuperar un handler para el fichero: " + file.getAbsolutePath());
/*     */     }
/*  91 */     os.write(fileData);
/*  92 */     os.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] getStreamBytes(InputStream is)
/*     */     throws IOException
/*     */   {
/* 102 */     int BUF_SIZE = 512;
/* 103 */     ByteArrayOutputStream bos = null;
/* 104 */     int bytesRead = 0;
/* 105 */     byte[] data = null;
/*     */     
/* 107 */     data = new byte['Ȁ'];
/* 108 */     bos = new ByteArrayOutputStream();
/*     */     
/* 110 */     while ((bytesRead = is.read(data, 0, 512)) >= 0) {
/* 111 */       bos.write(data, 0, bytesRead);
/*     */     }
/*     */     
/* 114 */     is.close();
/* 115 */     bos.close();
/*     */     
/* 117 */     return bos.toByteArray();
/*     */   }
/*     */   
/*     */   public static void addBCProvider() {
/* 121 */     if (Security.getProvider("BC") == null) {
/* 122 */       AccessController.doPrivileged(new PrivilegedAction() {
/*     */         public Integer run() {
/*     */           try {
/* 125 */             Provider p = new BouncyCastleProvider();
/* 126 */             ProvidersUtil.registerProvider(p.getClass().getName());
/* 127 */             if (Utils.logger.isDebugEnabled()) {
/* 128 */               Utils.logger.debug("Agregando el proveedor BC");
/*     */             }
/* 130 */             return Integer.valueOf(Security.addProvider(p));
/*     */           }
/*     */           catch (Throwable e) {
/* 133 */             if (Utils.logger.isDebugEnabled())
/* 134 */               Utils.logger.debug("Error al agregar el proveedor BC", e);
/*     */           }
/* 136 */           return null;
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\utils\Utils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */