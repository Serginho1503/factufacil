/*     */ package es.mityc.javasign.utils;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.prefs.Preferences;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WinRegistryUtils
/*     */ {
/*     */   public static final int HKEY_CLASSES_ROOT = Integer.MIN_VALUE;
/*     */   public static final int HKEY_CURRENT_USER = -2147483647;
/*     */   public static final int HKEY_LOCAL_MACHINE = -2147483646;
/*     */   public static final int REG_SUCCESS = 0;
/*     */   public static final int REG_NOTFOUND = 2;
/*     */   public static final int REG_ACCESSDENIED = 5;
/*     */   private static final int KEY_ALL_ACCESS = 983103;
/*     */   private static final int KEY_READ = 131097;
/*  47 */   private static Preferences userRoot = ;
/*  48 */   private static Preferences systemRoot = Preferences.systemRoot();
/*  49 */   private static Class<? extends Preferences> userClass = userRoot.getClass();
/*  50 */   private static Method regOpenKey = null;
/*  51 */   private static Method regCloseKey = null;
/*  52 */   private static Method regQueryValueEx = null;
/*  53 */   private static Method regEnumValue = null;
/*  54 */   private static Method regQueryInfoKey = null;
/*  55 */   private static Method regEnumKeyEx = null;
/*  56 */   private static Method regCreateKeyEx = null;
/*  57 */   private static Method regSetValueEx = null;
/*  58 */   private static Method regDeleteKey = null;
/*  59 */   private static Method regDeleteValue = null;
/*     */   
/*     */   static {
/*     */     try {
/*  63 */       regOpenKey = userClass.getDeclaredMethod(
/*  64 */         "WindowsRegOpenKey", new Class[] { Integer.TYPE, byte[].class, Integer.TYPE });
/*  65 */       regOpenKey.setAccessible(true);
/*  66 */       regCloseKey = userClass.getDeclaredMethod(
/*  67 */         "WindowsRegCloseKey", new Class[] { Integer.TYPE });
/*  68 */       regCloseKey.setAccessible(true);
/*  69 */       regQueryValueEx = userClass.getDeclaredMethod(
/*  70 */         "WindowsRegQueryValueEx", new Class[] { Integer.TYPE, byte[].class });
/*  71 */       regQueryValueEx.setAccessible(true);
/*  72 */       regEnumValue = userClass.getDeclaredMethod(
/*  73 */         "WindowsRegEnumValue", new Class[] { Integer.TYPE, Integer.TYPE, Integer.TYPE });
/*  74 */       regEnumValue.setAccessible(true);
/*  75 */       regQueryInfoKey = userClass.getDeclaredMethod(
/*  76 */         "WindowsRegQueryInfoKey1", new Class[] { Integer.TYPE });
/*  77 */       regQueryInfoKey.setAccessible(true);
/*  78 */       regEnumKeyEx = userClass.getDeclaredMethod(
/*  79 */         "WindowsRegEnumKeyEx", new Class[] { Integer.TYPE, Integer.TYPE, Integer.TYPE });
/*  80 */       regEnumKeyEx.setAccessible(true);
/*  81 */       regCreateKeyEx = userClass.getDeclaredMethod(
/*  82 */         "WindowsRegCreateKeyEx", new Class[] { Integer.TYPE, byte[].class });
/*  83 */       regCreateKeyEx.setAccessible(true);
/*  84 */       regSetValueEx = userClass.getDeclaredMethod(
/*  85 */         "WindowsRegSetValueEx", new Class[] { Integer.TYPE, byte[].class, byte[].class });
/*  86 */       regSetValueEx.setAccessible(true);
/*  87 */       regDeleteValue = userClass.getDeclaredMethod(
/*  88 */         "WindowsRegDeleteValue", new Class[] { Integer.TYPE, byte[].class });
/*  89 */       regDeleteValue.setAccessible(true);
/*  90 */       regDeleteKey = userClass.getDeclaredMethod(
/*  91 */         "WindowsRegDeleteKey", new Class[] { Integer.TYPE, byte[].class });
/*  92 */       regDeleteKey.setAccessible(true);
/*     */     } catch (Exception e) {
/*  94 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String readString(int hkey, String key, String valueName)
/*     */     throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 115 */     if (OSTool.getSO().isWindows()) {
/* 116 */       if (hkey == -2147483646)
/* 117 */         return readString(systemRoot, hkey, key, valueName);
/* 118 */       if (hkey == -2147483647) {
/* 119 */         return readString(userRoot, hkey, key, valueName);
/*     */       }
/* 121 */       throw new IllegalArgumentException("hkey=" + hkey);
/*     */     }
/*     */     
/* 124 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map<String, String> readStringValues(int hkey, String key)
/*     */     throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 139 */     if (hkey == -2147483646)
/* 140 */       return readStringValues(systemRoot, hkey, key);
/* 141 */     if (hkey == -2147483647) {
/* 142 */       return readStringValues(userRoot, hkey, key);
/*     */     }
/* 144 */     throw new IllegalArgumentException("hkey=" + hkey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<String> readStringSubKeys(int hkey, String key)
/*     */     throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 159 */     if (hkey == -2147483646)
/* 160 */       return readStringSubKeys(systemRoot, hkey, key);
/* 161 */     if (hkey == -2147483647) {
/* 162 */       return readStringSubKeys(userRoot, hkey, key);
/*     */     }
/* 164 */     throw new IllegalArgumentException("hkey=" + hkey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void createKey(int hkey, String key)
/*     */     throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 178 */     int[] ret = null;
/* 179 */     if (hkey == -2147483646) {
/* 180 */       ret = createKey(systemRoot, hkey, key);
/* 181 */       regCloseKey.invoke(systemRoot, new Object[] { new Integer(ret[0]) });
/* 182 */     } else if (hkey == -2147483647) {
/* 183 */       ret = createKey(userRoot, hkey, key);
/* 184 */       regCloseKey.invoke(userRoot, new Object[] { new Integer(ret[0]) });
/* 185 */     } else if (hkey == Integer.MIN_VALUE) {
/* 186 */       ret = createKey(systemRoot, hkey, key);
/* 187 */       regCloseKey.invoke(systemRoot, new Object[] { new Integer(ret[0]) });
/*     */     } else {
/* 189 */       throw new IllegalArgumentException("hkey=" + hkey);
/*     */     }
/* 191 */     if (ret[1] != 0) {
/* 192 */       throw new IllegalArgumentException("rc=" + ret[1] + "  key=" + key);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void writeStringValue(int hkey, String key, String valueName, String value)
/*     */     throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 208 */     if (hkey == -2147483646) {
/* 209 */       writeStringValue(systemRoot, hkey, key, valueName, value);
/* 210 */     } else if (hkey == -2147483647) {
/* 211 */       writeStringValue(userRoot, hkey, key, valueName, value);
/* 212 */     } else if (hkey == Integer.MIN_VALUE) {
/* 213 */       writeStringValue(systemRoot, hkey, key, valueName, value);
/*     */     } else {
/* 215 */       throw new IllegalArgumentException("hkey=" + hkey);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void deleteKey(int hkey, String key)
/*     */     throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 229 */     int rc = -1;
/* 230 */     if (hkey == -2147483646) {
/* 231 */       rc = deleteKey(systemRoot, hkey, key);
/* 232 */     } else if (hkey == -2147483647) {
/* 233 */       rc = deleteKey(userRoot, hkey, key);
/*     */     }
/* 235 */     if (rc != 0) {
/* 236 */       throw new IllegalArgumentException("rc=" + rc + "  key=" + key);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void deleteValue(int hkey, String key, String value)
/*     */     throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 251 */     int rc = -1;
/* 252 */     if (hkey == -2147483646) {
/* 253 */       rc = deleteValue(systemRoot, hkey, key, value);
/* 254 */     } else if (hkey == -2147483647) {
/* 255 */       rc = deleteValue(userRoot, hkey, key, value);
/*     */     }
/* 257 */     if (rc != 0) {
/* 258 */       throw new IllegalArgumentException("rc=" + rc + "  key=" + key + "  value=" + value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean keyExists(int hkey, String key)
/*     */     throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 272 */     boolean rc = false;
/* 273 */     if (hkey == -2147483646) {
/* 274 */       rc = keyExists(systemRoot, hkey, key);
/* 275 */     } else if (hkey == -2147483647) {
/* 276 */       rc = keyExists(userRoot, hkey, key);
/*     */     }
/* 278 */     return rc;
/*     */   }
/*     */   
/*     */   private static int deleteValue(Preferences root, int hkey, String key, String value) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 283 */     int[] handles = (int[])regOpenKey.invoke(root, new Object[] {
/* 284 */       new Integer(hkey), toCstr(key), new Integer(983103) });
/* 285 */     if (handles[1] != 0) {
/* 286 */       return handles[1];
/*     */     }
/* 288 */     int rc = ((Integer)regDeleteValue.invoke(root, 
/* 289 */       new Object[] {
/* 290 */       new Integer(handles[0]), toCstr(value) }))
/* 291 */       .intValue();
/* 292 */     regCloseKey.invoke(root, new Object[] { new Integer(handles[0]) });
/* 293 */     return rc;
/*     */   }
/*     */   
/*     */   private static int deleteKey(Preferences root, int hkey, String key) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 298 */     int rc = ((Integer)regDeleteKey.invoke(root, 
/* 299 */       new Object[] { new Integer(hkey), toCstr(key) })).intValue();
/* 300 */     return rc;
/*     */   }
/*     */   
/*     */   private static String readString(Preferences root, int hkey, String key, String value) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 305 */     int[] handles = (int[])regOpenKey.invoke(root, new Object[] {
/* 306 */       new Integer(hkey), toCstr(key), new Integer(131097) });
/* 307 */     if (handles[1] != 0) {
/* 308 */       return null;
/*     */     }
/* 310 */     byte[] valb = (byte[])regQueryValueEx.invoke(root, new Object[] {
/* 311 */       new Integer(handles[0]), toCstr(value) });
/* 312 */     regCloseKey.invoke(root, new Object[] { new Integer(handles[0]) });
/* 313 */     return valb != null ? new String(valb).trim() : null;
/*     */   }
/*     */   
/*     */   private static Map<String, String> readStringValues(Preferences root, int hkey, String key) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 318 */     HashMap<String, String> results = new HashMap();
/* 319 */     int[] handles = (int[])regOpenKey.invoke(root, new Object[] {
/* 320 */       new Integer(hkey), toCstr(key), new Integer(131097) });
/* 321 */     if (handles[1] != 0) {
/* 322 */       return null;
/*     */     }
/* 324 */     int[] info = (int[])regQueryInfoKey.invoke(root, new Object[] { new Integer(handles[0]) });
/*     */     
/* 326 */     int count = info[2];
/* 327 */     int maxlen = info[3];
/* 328 */     for (int index = 0; index < count; index++) {
/* 329 */       byte[] name = (byte[])regEnumValue.invoke(root, new Object[] {
/* 330 */         new Integer(
/* 331 */         handles[0]), new Integer(index), new Integer(maxlen + 1) });
/* 332 */       String value = readString(hkey, key, new String(name));
/* 333 */       results.put(new String(name).trim(), value);
/*     */     }
/* 335 */     regCloseKey.invoke(root, new Object[] { new Integer(handles[0]) });
/* 336 */     return results;
/*     */   }
/*     */   
/*     */   private static List<String> readStringSubKeys(Preferences root, int hkey, String key) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 341 */     List<String> results = new ArrayList();
/* 342 */     int[] handles = (int[])regOpenKey.invoke(root, new Object[] {
/* 343 */       new Integer(hkey), toCstr(key), new Integer(131097) });
/*     */     
/* 345 */     if (handles[1] != 0) {
/* 346 */       return null;
/*     */     }
/* 348 */     int[] info = (int[])regQueryInfoKey.invoke(root, new Object[] { new Integer(handles[0]) });
/*     */     
/* 350 */     int count = info[2];
/* 351 */     int maxlen = info[3];
/* 352 */     for (int index = 0; index < count; index++) {
/* 353 */       byte[] name = (byte[])regEnumKeyEx.invoke(root, new Object[] {
/* 354 */         new Integer(
/* 355 */         handles[0]), new Integer(index), new Integer(maxlen + 1) });
/*     */       
/* 357 */       results.add(new String(name).trim());
/*     */     }
/* 359 */     regCloseKey.invoke(root, new Object[] { new Integer(handles[0]) });
/* 360 */     return results;
/*     */   }
/*     */   
/*     */   private static int[] createKey(Preferences root, int hkey, String key) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 365 */     return (int[])regCreateKeyEx.invoke(root, new Object[] { new Integer(hkey), toCstr(key) });
/*     */   }
/*     */   
/*     */   private static void writeStringValue(Preferences root, int hkey, String key, String valueName, String value) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 370 */     int[] handles = (int[])regOpenKey.invoke(root, new Object[] {
/* 371 */       new Integer(hkey), toCstr(key), new Integer(983103) });
/*     */     
/*     */ 
/* 374 */     regSetValueEx.invoke(root, new Object[] {
/* 375 */       new Integer(handles[0]), toCstr(valueName), toCstr(value) });
/*     */     
/* 377 */     regCloseKey.invoke(root, new Object[] { new Integer(handles[0]) });
/*     */   }
/*     */   
/*     */   private static boolean keyExists(Preferences root, int hkey, String key) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 382 */     int[] handles = (int[])regOpenKey.invoke(root, new Object[] {
/* 383 */       new Integer(hkey), toCstr(key), new Integer(983103) });
/* 384 */     return handles[1] != 0;
/*     */   }
/*     */   
/*     */   private static byte[] toCstr(String str) {
/* 388 */     byte[] result = new byte[str.length() + 1];
/*     */     
/* 390 */     for (int i = 0; i < str.length(); i++) {
/* 391 */       result[i] = ((byte)str.charAt(i));
/*     */     }
/* 393 */     result[str.length()] = 0;
/* 394 */     return result;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\utils\WinRegistryUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */