/*    */ package es.mityc.javasign.utils;
/*    */ 
/*    */ import java.net.Authenticator;
/*    */ import java.net.PasswordAuthentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleAuthenticator
/*    */   extends Authenticator
/*    */ {
/*    */   private transient String username;
/*    */   private transient String password;
/*    */   
/*    */   public SimpleAuthenticator(String user, String pass)
/*    */   {
/* 40 */     this.username = (user != null ? new String(user) : null);
/* 41 */     this.password = (pass != null ? new String(pass) : null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected PasswordAuthentication getPasswordAuthentication()
/*    */   {
/* 51 */     return new PasswordAuthentication(this.username, this.password != null ? this.password.toCharArray() : null);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\utils\SimpleAuthenticator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */