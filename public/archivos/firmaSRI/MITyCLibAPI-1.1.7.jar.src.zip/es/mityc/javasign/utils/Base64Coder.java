/*     */ package es.mityc.javasign.utils;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Base64Coder
/*     */ {
/*  36 */   private static II18nManager I18N = I18nFactory.getI18nManager("MITyCLibAPI");
/*     */   
/*     */ 
/*  39 */   private static char[] map1 = new char[64];
/*     */   private static byte[] map2;
/*     */   
/*  42 */   static { int i = 0;
/*  43 */     for (char c = 'A'; c <= 'Z'; c = (char)(c + '\001'))
/*  44 */       map1[(i++)] = c;
/*  45 */     for (char c = 'a'; c <= 'z'; c = (char)(c + '\001'))
/*  46 */       map1[(i++)] = c;
/*  47 */     for (char c = '0'; c <= '9'; c = (char)(c + '\001'))
/*  48 */       map1[(i++)] = c;
/*  49 */     map1[(i++)] = '+';
/*  50 */     map1[(i++)] = '/';
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  55 */     map2 = new byte[''];
/*     */     
/*  57 */     for (int i = 0; i < map2.length; i++)
/*  58 */       map2[i] = -1;
/*  59 */     for (int i = 0; i < 64; i++) {
/*  60 */       map2[map1[i]] = ((byte)i);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encodeString(String s)
/*     */   {
/*  73 */     return new String(encode(s.getBytes()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static char[] encode(byte[] in)
/*     */   {
/*  86 */     return encode(in, in.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static char[] encode(byte[] in, int iLen)
/*     */   {
/* 101 */     int oDataLen = (iLen * 4 + 2) / 3;
/* 102 */     int oLen = (iLen + 2) / 3 * 4;
/* 103 */     char[] out = new char[oLen];
/* 104 */     int ip = 0;
/* 105 */     int op = 0;
/* 106 */     while (ip < iLen) {
/* 107 */       int i0 = in[(ip++)] & 0xFF;
/* 108 */       int i1 = ip < iLen ? in[(ip++)] & 0xFF : 0;
/* 109 */       int i2 = ip < iLen ? in[(ip++)] & 0xFF : 0;
/* 110 */       int o0 = i0 >>> 2;
/* 111 */       int o1 = (i0 & 0x3) << 4 | i1 >>> 4;
/* 112 */       int o2 = (i1 & 0xF) << 2 | i2 >>> 6;
/* 113 */       int o3 = i2 & 0x3F;
/* 114 */       out[(op++)] = map1[o0];
/* 115 */       out[(op++)] = map1[o1];
/* 116 */       out[op] = (op < oDataLen ? map1[o2] : '=');
/* 117 */       op++;
/* 118 */       out[op] = (op < oDataLen ? map1[o3] : '=');
/* 119 */       op++;
/*     */     }
/* 121 */     return out;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String decodeString(String s)
/*     */   {
/* 135 */     return new String(decode(s));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] decode(String input)
/*     */   {
/* 145 */     String cadena = new String(input);
/* 146 */     cadena = cadena.replace(" ", "").replace("\n", "").replace("\r", "");
/* 147 */     return decode(cadena.toCharArray());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] decode(Object input)
/*     */   {
/* 162 */     char[] in = null;
/*     */     
/* 164 */     if ((input instanceof String)) {
/* 165 */       in = ((String)input).toCharArray();
/* 166 */     } else if ((input instanceof char[])) {
/* 167 */       in = (char[])input;
/*     */     } else {
/* 169 */       throw new IllegalArgumentException(I18N.getLocalMessage("i18n.mityc.api.tools.cp.20"));
/*     */     }
/* 171 */     int iLen = in.length;
/* 172 */     if (iLen % 4 != 0) {
/* 173 */       throw new IllegalArgumentException(I18N.getLocalMessage("i18n.mityc.api.tools.cp.18"));
/*     */     }
/* 175 */     while ((iLen > 0) && (in[(iLen - 1)] == '='))
/* 176 */       iLen--;
/* 177 */     int oLen = iLen * 3 / 4;
/* 178 */     byte[] out = new byte[oLen];
/* 179 */     int ip = 0;
/* 180 */     int op = 0;
/* 181 */     while (ip < iLen) {
/* 182 */       int i0 = in[(ip++)];
/* 183 */       int i1 = in[(ip++)];
/* 184 */       int i2 = ip < iLen ? in[(ip++)] : 65;
/* 185 */       int i3 = ip < iLen ? in[(ip++)] : 65;
/* 186 */       if ((i0 > 127) || (i1 > 127) || (i2 > 127) || (i3 > 127)) {
/* 187 */         throw new IllegalArgumentException(I18N.getLocalMessage("i18n.mityc.api.tools.cp.19"));
/*     */       }
/* 189 */       int b0 = map2[i0];
/* 190 */       int b1 = map2[i1];
/* 191 */       int b2 = map2[i2];
/* 192 */       int b3 = map2[i3];
/* 193 */       if ((b0 < 0) || (b1 < 0) || (b2 < 0) || (b3 < 0)) {
/* 194 */         throw new IllegalArgumentException(I18N.getLocalMessage("i18n.mityc.api.tools.cp.19"));
/*     */       }
/* 196 */       int o0 = b0 << 2 | b1 >>> 4;
/* 197 */       int o1 = (b1 & 0xF) << 4 | b2 >>> 2;
/* 198 */       int o2 = (b2 & 0x3) << 6 | b3;
/* 199 */       out[(op++)] = ((byte)o0);
/* 200 */       if (op < oLen) {
/* 201 */         out[(op++)] = ((byte)o1);
/*     */       }
/* 203 */       if (op < oLen) {
/* 204 */         out[(op++)] = ((byte)o2);
/*     */       }
/*     */     }
/* 207 */     return out;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\utils\Base64Coder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */