package es.mityc.javasign;

public final class ConstantsAPI
{
  public static final String PROVIDER_BC_NAME = "BC";
  public static final String PROVIDER_SUN_16_NAME = "SUN version 1.6";
  public static final String PROVIDER_SUN_17_NAME = "SUN version 1.7";
  public static final String LIB_NAME = "MITyCLibAPI";
  public static final String SYSTEM_PROPERTY_USER_DIR = "user.dir";
  public static final String SYSTEM_PROPERTY_USER_HOME = "user.home";
  public static final String SYSTEM_PROPERTY_TMP_DIR = "java.io.tmpdir";
  public static final String SYSTEM_PROPERTY_LIBRARY_PATH = "java.library.path";
  public static final String JAVA_HOME = "java.home";
  public static final String FILE_SEPARATOR = "file.separator";
  public static final String I18N_TOOLS_CP_1 = "i18n.mityc.api.tools.cp.1";
  public static final String I18N_TOOLS_CP_2 = "i18n.mityc.api.tools.cp.2";
  public static final String I18N_TOOLS_CP_3 = "i18n.mityc.api.tools.cp.3";
  public static final String I18N_TOOLS_CP_4 = "i18n.mityc.api.tools.cp.4";
  public static final String I18N_TOOLS_CP_5 = "i18n.mityc.api.tools.cp.5";
  public static final String I18N_TOOLS_CP_6 = "i18n.mityc.api.tools.cp.6";
  public static final String I18N_TOOLS_CP_7 = "i18n.mityc.api.tools.cp.7";
  public static final String I18N_TOOLS_CP_8 = "i18n.mityc.api.tools.cp.8";
  public static final String I18N_TOOLS_CP_9 = "i18n.mityc.api.tools.cp.9";
  public static final String I18N_TOOLS_CP_10 = "i18n.mityc.api.tools.cp.10";
  public static final String I18N_TOOLS_CP_11 = "i18n.mityc.api.tools.cp.11";
  public static final String I18N_TOOLS_CP_12 = "i18n.mityc.api.tools.cp.12";
  public static final String I18N_TOOLS_CP_13 = "i18n.mityc.api.tools.cp.13";
  public static final String I18N_TOOLS_CP_14 = "i18n.mityc.api.tools.cp.14";
  public static final String I18N_TOOLS_CP_15 = "i18n.mityc.api.tools.cp.15";
  public static final String I18N_TOOLS_CP_16 = "i18n.mityc.api.tools.cp.16";
  public static final String I18N_TOOLS_CP_17 = "i18n.mityc.api.tools.cp.17";
  public static final String I18N_TOOLS_CP_18 = "i18n.mityc.api.tools.cp.18";
  public static final String I18N_TOOLS_CP_19 = "i18n.mityc.api.tools.cp.19";
  public static final String I18N_TOOLS_CP_20 = "i18n.mityc.api.tools.cp.20";
  public static final String I18N_TOOLS_CP_21 = "i18n.mityc.api.tools.cp.21";
  public static final String I18N_TOOLS_CP_22 = "i18n.mityc.api.tools.cp.22";
  public static final String I18N_TRUST_1 = "i18n.mityc.api.trust.1";
  public static final String I18N_TRUST_2 = "i18n.mityc.api.trust.2";
  public static final String I18N_TRUST_3 = "i18n.mityc.api.trust.3";
  public static final String I18N_TRUST_4 = "i18n.mityc.api.trust.4";
  public static final String I18N_TRUST_5 = "i18n.mityc.api.trust.5";
  public static final String I18N_TRUST_6 = "i18n.mityc.api.trust.6";
  public static final String I18N_TRUST_7 = "i18n.mityc.api.trust.7";
  public static final String I18N_TRUST_8 = "i18n.mityc.api.trust.8";
  public static final String I18N_TRUST_9 = "i18n.mityc.api.trust.9";
  public static final String TRUSTER_EXTERNAL_CONF_FILE = "truster.properties";
  public static final String I18N_BRIDGE_1 = "i18n.mityc.api.bridge.1";
  public static final String I18N_BRIDGE_2 = "i18n.mityc.api.bridge.2";
  public static final String I18N_BRIDGE_3 = "i18n.mityc.api.bridge.3";
  public static final String I18N_BRIDGE_4 = "i18n.mityc.api.bridge.4";
  public static final String I18N_BRIDGE_5 = "i18n.mityc.api.bridge.5";
  public static final String I18N_BRIDGE_6 = "i18n.mityc.api.bridge.6";
  public static final String I18N_CERT_SMR_CARD_TITLE = "i18n.mityc.api.cert.smartcards.GUI.title";
  public static final String I18N_CERT_SMR_CARD_ACCEPT = "i18n.mityc.api.cert.smartcards.GUI.accept";
  public static final String I18N_CERT_SMR_CARD_CANCEL = "i18n.mityc.api.cert.smartcards.GUI.cancel";
  public static final String I18N_CERT_SMR_CARD_PIN = "i18n.mityc.api.cert.smartcards.GUI.pin";
  public static final String I18N_CERT_1 = "i18n.mityc.api.cert.1";
  public static final String I18N_CERT_2 = "i18n.mityc.api.cert.2";
  public static final String I18N_CERT_3 = "i18n.mityc.api.cert.3";
  public static final String I18N_CERT_4 = "i18n.mityc.api.cert.4";
  public static final String I18N_CERT_5 = "i18n.mityc.api.cert.5";
  public static final String I18N_PASS_SECURITY_1 = "i18n.mityc.api.pass.1";
  public static final String I18N_PASS_SECURITY_2 = "i18n.mityc.api.pass.2";
  public static final String I18N_PASS_SECURITY_3 = "i18n.mityc.api.pass.3";
  public static final String I18N_PASS_SECURITY_4 = "i18n.mityc.api.pass.4";
  public static final String I18N_PASS_SECURITY_5 = "i18n.mityc.api.pass.5";
  public static final String I18N_PASS_SECURITY_6 = "i18n.mityc.api.pass.6";
  public static final String I18N_PASS_SECURITY_7 = "i18n.mityc.api.pass.7";
  public static final String I18N_PASS_SECURITY_8 = "i18n.mityc.api.pass.8";
  public static final String I18N_PASS_SECURITY_9 = "i18n.mityc.api.pass.9";
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\ConstantsAPI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */