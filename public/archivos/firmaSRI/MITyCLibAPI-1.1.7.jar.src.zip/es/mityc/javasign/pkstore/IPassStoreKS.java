package es.mityc.javasign.pkstore;

import java.security.cert.X509Certificate;

public abstract interface IPassStoreKS
{
  public abstract char[] getPassword(X509Certificate paramX509Certificate, String paramString);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\pkstore\IPassStoreKS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */