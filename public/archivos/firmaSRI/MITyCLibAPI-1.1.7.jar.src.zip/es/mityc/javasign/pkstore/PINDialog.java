/*     */ package es.mityc.javasign.pkstore;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Frame;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPasswordField;
/*     */ import javax.swing.JRootPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PINDialog
/*     */ {
/*  49 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibAPI");
/*     */   
/*  51 */   private boolean cancelado = false;
/*     */   
/*  53 */   protected JDialog dialog = null;
/*     */   
/*  55 */   protected JLabel lblMessage = null;
/*     */   
/*  57 */   JButton cancelar = null;
/*     */   
/*     */ 
/*     */   private static final String STR_OK = "OK";
/*     */   
/*     */ 
/*     */   private static final String STR_CLOSE = "CLOSE";
/*     */   
/*     */ 
/*     */   private static final int DEFAULT_WIDTH = 300;
/*     */   
/*     */ 
/*     */   private static final int DEFAULT_HEIGHT = 300;
/*     */   
/*     */   private static final String PIN_ICON = "/es/mityc/javasign/pkstore/Images/Candado.png";
/*     */   
/*  73 */   private JPasswordField pass = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PINDialog(Frame owner)
/*     */   {
/*  80 */     this.dialog = new JDialog(owner, I18N.getLocalMessage("i18n.mityc.api.cert.smartcards.GUI.title"), true);
/*  81 */     dialogInit();
/*     */   }
/*     */   
/*     */ 
/*     */   protected void dialogInit()
/*     */   {
/*     */     try
/*     */     {
/*  89 */       JPanel distr = new JPanel();
/*  90 */       JButton aceptar = new JButton(I18N.getLocalMessage("i18n.mityc.api.cert.smartcards.GUI.accept"));
/*  91 */       this.cancelar = new JButton(I18N.getLocalMessage("i18n.mityc.api.cert.smartcards.GUI.cancel"));
/*     */       
/*  93 */       aceptar.setActionCommand("OK");
/*  94 */       this.cancelar.setActionCommand("CLOSE");
/*     */       
/*  96 */       this.pass = new JPasswordField(15);
/*  97 */       distr.setLayout(new GridBagLayout());
/*     */       
/*  99 */       this.lblMessage = new JLabel(I18N.getLocalMessage("i18n.mityc.api.cert.smartcards.GUI.pin"));
/* 100 */       this.lblMessage.setHorizontalAlignment(0);
/* 101 */       this.lblMessage.setIcon(new ImageIcon(getClass().getResource("/es/mityc/javasign/pkstore/Images/Candado.png")));
/* 102 */       this.lblMessage.setHorizontalTextPosition(4);
/* 103 */       this.lblMessage.setIconTextGap(10);
/*     */       
/*     */ 
/* 106 */       GridBagConstraints g = new GridBagConstraints();
/* 107 */       g.gridx = 0;
/* 108 */       g.gridy = 0;
/* 109 */       g.gridwidth = 4;
/* 110 */       g.insets = new Insets(10, 20, 5, 20);
/* 111 */       distr.add(this.lblMessage, g);
/*     */       
/* 113 */       g.gridx = 0;
/* 114 */       g.gridy = 1;
/* 115 */       g.gridwidth = 4;
/* 116 */       g.fill = 2;
/* 117 */       g.weightx = 1.0D;
/* 118 */       g.insets = new Insets(10, 35, 5, 35);
/* 119 */       distr.add(this.pass, g);
/*     */       
/* 121 */       JPanel btnPanel = new JPanel();
/* 122 */       btnPanel.setLayout(new FlowLayout(0, 50, 5));
/* 123 */       btnPanel.add(aceptar);
/* 124 */       btnPanel.add(this.cancelar);
/*     */       
/* 126 */       g = new GridBagConstraints();
/* 127 */       g.gridx = 0;
/* 128 */       g.gridy = 2;
/* 129 */       g.gridwidth = 4;
/* 130 */       g.anchor = 10;
/* 131 */       g.insets = new Insets(15, 0, 15, 0);
/* 132 */       distr.add(btnPanel, g);
/*     */       
/* 134 */       distr.doLayout();
/* 135 */       this.dialog.add(distr);
/* 136 */       this.dialog.setResizable(false);
/* 137 */       this.dialog.setAlwaysOnTop(true);
/* 138 */       this.dialog.setDefaultCloseOperation(0);
/* 139 */       this.dialog.getRootPane().setDefaultButton(aceptar);
/* 140 */       this.dialog.setSize(new Dimension(300, 300));
/* 141 */       Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
/* 142 */       this.dialog.setLocation(screenSize.width / 2 - this.dialog.getWidth() / 2, screenSize.height / 2 - this.dialog.getHeight() / 2);
/*     */       
/* 144 */       aceptar.addActionListener(
/* 145 */         new ActionListener() {
/*     */           public void actionPerformed(ActionEvent e) {
/* 147 */             if (e.getActionCommand().equals("OK")) {
/* 148 */               PINDialog.this.dialog.setVisible(false);
/*     */             }
/*     */             
/*     */           }
/* 152 */         });
/* 153 */       this.cancelar.addActionListener(
/* 154 */         new ActionListener() {
/*     */           public void actionPerformed(ActionEvent e) {
/* 156 */             if (e.getActionCommand().equals("CLOSE")) {
/* 157 */               PINDialog.this.cancelado = true;
/* 158 */               PINDialog.this.dialog.setVisible(false);
/*     */             }
/*     */           }
/*     */         });
/*     */     }
/*     */     catch (Exception localException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTitle(String newTitle)
/*     */   {
/* 172 */     this.dialog.setTitle(new String(newTitle));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPINMessage(String newMessage)
/*     */   {
/* 180 */     this.lblMessage.setText(new String(newMessage));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIcon(ImageIcon icon)
/*     */   {
/* 188 */     this.lblMessage.setIcon(icon);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCancelBtnVisible(boolean isVisible)
/*     */   {
/* 196 */     this.cancelar.setVisible(isVisible);
/* 197 */     pack();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void pack()
/*     */   {
/* 204 */     this.dialog.pack();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVisible(boolean flag)
/*     */   {
/* 212 */     if (flag) {
/* 213 */       this.cancelado = false;
/* 214 */       this.pass.setText("");
/* 215 */       this.dialog.requestFocus();
/* 216 */       this.pass.requestFocusInWindow();
/*     */     }
/* 218 */     this.dialog.setVisible(flag);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] getPassword()
/*     */   {
/* 226 */     return this.pass.getPassword();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void dispose()
/*     */   {
/* 233 */     this.dialog.dispose();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCancelado()
/*     */   {
/* 241 */     return this.cancelado;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWidth()
/*     */   {
/* 249 */     if (this.dialog != null) {
/* 250 */       return this.dialog.getWidth();
/*     */     }
/* 252 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHeight()
/*     */   {
/* 261 */     if (this.dialog != null) {
/* 262 */       return this.dialog.getHeight();
/*     */     }
/* 264 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocation(int x, int y)
/*     */   {
/* 274 */     if (this.dialog != null) {
/* 275 */       this.dialog.setLocation(x, y);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\pkstore\PINDialog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */