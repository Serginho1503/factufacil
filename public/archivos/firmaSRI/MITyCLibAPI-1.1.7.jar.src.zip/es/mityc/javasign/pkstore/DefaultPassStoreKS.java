/*     */ package es.mityc.javasign.pkstore;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Toolkit;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.swing.ImageIcon;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultPassStoreKS
/*     */   implements IPassStoreKS
/*     */ {
/*  36 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibAPI");
/*     */   
/*     */ 
/*  39 */   private String titleDialog = I18N.getLocalMessage("i18n.mityc.api.cert.smartcards.GUI.title");
/*     */   
/*     */ 
/*  42 */   private String pinMessage = I18N.getLocalMessage("i18n.mityc.api.cert.smartcards.GUI.pin");
/*     */   
/*     */ 
/*  45 */   private PINDialog pinDialog = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] getPassword(X509Certificate certificate, String alias)
/*     */   {
/*  55 */     this.pinDialog = new PINDialog(null);
/*  56 */     processData(certificate, alias);
/*  57 */     this.pinDialog.setTitle(getTitle());
/*  58 */     this.pinDialog.setPINMessage(getPINMessage());
/*  59 */     this.pinDialog.pack();
/*  60 */     Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
/*  61 */     this.pinDialog.setLocation(screenSize.width / 2 - this.pinDialog.getWidth() / 2, screenSize.height / 2 - this.pinDialog.getHeight() / 2);
/*  62 */     this.pinDialog.setVisible(true);
/*     */     
/*  64 */     char[] pass = new char[0];
/*  65 */     if (!this.pinDialog.isCancelado()) {
/*  66 */       pass = this.pinDialog.getPassword();
/*     */     }
/*  68 */     this.pinDialog.dispose();
/*     */     
/*  70 */     return pass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIcon(ImageIcon icon)
/*     */   {
/*  80 */     this.pinDialog.setIcon(icon);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCancelBtnVisible(boolean isVisible)
/*     */   {
/*  88 */     this.pinDialog.setCancelBtnVisible(isVisible);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void processData(X509Certificate certificate, String alias) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTitle(String title)
/*     */   {
/* 107 */     this.titleDialog = new String(title);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTitle()
/*     */   {
/* 115 */     return this.titleDialog;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPINMessage(String message)
/*     */   {
/* 123 */     this.pinMessage = new String(message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPINMessage()
/*     */   {
/* 131 */     return this.pinMessage;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\pkstore\DefaultPassStoreKS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */