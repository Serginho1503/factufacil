/*    */ package es.mityc.javasign.pkstore;
/*    */ 
/*    */ import java.security.cert.X509Certificate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullPassStorePK
/*    */   implements IPassStoreKS
/*    */ {
/*    */   public char[] getPassword(X509Certificate certificate, String alias)
/*    */   {
/* 34 */     return new char[0];
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\pkstore\NullPassStorePK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */