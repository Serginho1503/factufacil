package es.mityc.javasign.pkstore;

import java.security.PrivateKey;
import java.security.Provider;
import java.security.cert.CertPath;
import java.security.cert.X509Certificate;
import java.util.List;

public abstract interface IPKStoreManager
{
  public abstract Provider getProvider(X509Certificate paramX509Certificate);
  
  public abstract List<X509Certificate> getSignCertificates()
    throws CertStoreException;
  
  public abstract List<X509Certificate> getTrustCertificates()
    throws CertStoreException;
  
  public abstract CertPath getCertPath(X509Certificate paramX509Certificate)
    throws CertStoreException;
  
  public abstract PrivateKey getPrivateKey(X509Certificate paramX509Certificate)
    throws CertStoreException;
  
  public abstract List<X509Certificate> getPublicCertificates()
    throws CertStoreException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\pkstore\IPKStoreManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */