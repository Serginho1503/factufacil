/*    */ package es.mityc.javasign.pkstore;
/*    */ 
/*    */ import es.mityc.javasign.exception.SignMITyCException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CertStoreException
/*    */   extends SignMITyCException
/*    */ {
/*    */   static final long serialVersionUID = 1L;
/*    */   
/*    */   public CertStoreException() {}
/*    */   
/*    */   public CertStoreException(String message)
/*    */   {
/* 41 */     super(message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public CertStoreException(Throwable cause)
/*    */   {
/* 49 */     super(cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CertStoreException(String message, Throwable cause)
/*    */   {
/* 58 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\pkstore\CertStoreException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */