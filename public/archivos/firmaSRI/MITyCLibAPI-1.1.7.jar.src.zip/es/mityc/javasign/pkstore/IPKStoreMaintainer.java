package es.mityc.javasign.pkstore;

import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import javax.swing.JPanel;

public abstract interface IPKStoreMaintainer
{
  public abstract void init()
    throws CertStoreException;
  
  public abstract void addTrustCert(X509Certificate paramX509Certificate)
    throws CertStoreException;
  
  public abstract void removeTrustCert(X509Certificate paramX509Certificate)
    throws CertStoreException;
  
  public abstract void importSignCert(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, char[] paramArrayOfChar)
    throws CertStoreException;
  
  public abstract void removeSignCert(X509Certificate paramX509Certificate)
    throws CertStoreException;
  
  public abstract void updateSignCert(X509Certificate paramX509Certificate)
    throws CertStoreException;
  
  public abstract boolean isDeletable(X509Certificate paramX509Certificate);
  
  public abstract JPanel getPreferencesPanel();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\pkstore\IPKStoreMaintainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */