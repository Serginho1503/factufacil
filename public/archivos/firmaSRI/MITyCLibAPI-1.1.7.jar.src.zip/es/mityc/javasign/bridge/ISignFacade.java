package es.mityc.javasign.bridge;

import java.security.cert.X509Certificate;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.w3c.dom.Document;

public abstract interface ISignFacade
{
  public abstract void init(Properties paramProperties)
    throws ConfigurationException;
  
  public abstract void setStoreManager(String paramString1, String paramString2)
    throws ConfigurationException;
  
  public abstract List<X509Certificate> getSignCertificates();
  
  public abstract void validateCert(X509Certificate paramX509Certificate)
    throws InvalidCertificateException;
  
  public abstract void validateCertChain(X509Certificate paramX509Certificate)
    throws InvalidCertificateException;
  
  public abstract Document sign(X509Certificate paramX509Certificate, Document paramDocument)
    throws SigningException;
  
  public abstract List<Map<String, Object>> validate(Document paramDocument)
    throws InvalidSignatureException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\bridge\ISignFacade.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */