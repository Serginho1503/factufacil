/*    */ package es.mityc.javasign.bridge;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RevokedCertificateException
/*    */   extends InvalidCertificateException
/*    */ {
/*    */   public RevokedCertificateException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public RevokedCertificateException(String message)
/*    */   {
/* 38 */     super(message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public RevokedCertificateException(Throwable cause)
/*    */   {
/* 46 */     super(cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public RevokedCertificateException(String message, Throwable cause)
/*    */   {
/* 55 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\bridge\RevokedCertificateException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */