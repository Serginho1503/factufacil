/*     */ package es.mityc.javasign.bridge;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SignFactory
/*     */ {
/*  49 */   private static final Log LOG = LogFactory.getLog(SignFactory.class);
/*     */   
/*  51 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibAPI");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  56 */   private Properties props = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private SignFactory()
/*     */   {
/*  70 */     InputStream is = getClassLoader().getResourceAsStream("bridge/sign.properties");
/*  71 */     if (is != null) {
/*     */       try {
/*  73 */         this.props = new Properties();
/*  74 */         this.props.load(is);
/*     */       } catch (IOException ex) {
/*  76 */         LOG.error(I18N.getLocalMessage("i18n.mityc.api.bridge.1"));
/*     */       }
/*     */     } else {
/*  79 */       LOG.error(I18N.getLocalMessage("i18n.mityc.api.bridge.1"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ClassLoader getClassLoader()
/*     */   {
/*     */     try
/*     */     {
/*  90 */       ClassLoader cl = (ClassLoader)AccessController.doPrivileged(new PrivilegedAction() {
/*     */         public ClassLoader run() {
/*  92 */           ClassLoader classLoader = null;
/*     */           try {
/*  94 */             classLoader = Thread.currentThread().getContextClassLoader();
/*     */           }
/*     */           catch (SecurityException localSecurityException) {}
/*  97 */           return classLoader;
/*     */         }
/*     */       });
/* 100 */       if (cl != null) {
/* 101 */         return cl;
/*     */       }
/*     */     }
/*     */     catch (Exception localException) {}
/* 105 */     return SignFactory.class.getClassLoader();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 113 */   private static SignFactory instance = getInstance();
/*     */   
/*     */   private static final String SIGN_FILE_CONF = "bridge/sign.properties";
/*     */   
/*     */   private static final String PROP_FACADE_CLASS = "facade.sign.class";
/*     */   
/*     */ 
/*     */   public static SignFactory getInstance()
/*     */   {
/* 122 */     if (instance == null) {
/* 123 */       instance = new SignFactory();
/*     */     }
/* 125 */     return instance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ISignFacade getSignFacade()
/*     */   {
/* 134 */     ISignFacade signFacade = null;
/* 135 */     if (this.props != null) {
/* 136 */       String classname = this.props.getProperty("facade.sign.class");
/* 137 */       if ((classname != null) && (!"".equals(classname.trim()))) {
/*     */         try {
/* 139 */           ClassLoader cl = getClassLoader();
/* 140 */           Class<?> classTemp = null;
/* 141 */           if (cl != null) {
/* 142 */             classTemp = cl.loadClass(classname);
/*     */           } else {
/* 144 */             classTemp = Class.forName(classname);
/*     */           }
/* 146 */           if (classTemp == null) return signFacade;
/* 147 */           signFacade = (ISignFacade)classTemp.getConstructor(null).newInstance(new Object[0]);
/*     */         }
/*     */         catch (InstantiationException ex) {
/* 150 */           LOG.error(I18N.getLocalMessage("i18n.mityc.api.bridge.2"));
/* 151 */           if (!LOG.isDebugEnabled()) return signFacade;
/* 152 */           LOG.error("", ex);
/*     */         }
/*     */         catch (InvocationTargetException ex) {
/* 155 */           LOG.error(I18N.getLocalMessage("i18n.mityc.api.bridge.2"));
/* 156 */           if (!LOG.isDebugEnabled()) return signFacade;
/* 157 */           LOG.error("", ex);
/*     */         }
/*     */         catch (IllegalAccessException ex) {
/* 160 */           LOG.error(I18N.getLocalMessage("i18n.mityc.api.bridge.3"));
/* 161 */           if (!LOG.isDebugEnabled()) return signFacade;
/* 162 */           LOG.error("", ex);
/*     */         }
/*     */         catch (ClassNotFoundException ex) {
/* 165 */           LOG.error(I18N.getLocalMessage("i18n.mityc.api.bridge.4", new Object[] { classname }));
/* 166 */           if (!LOG.isDebugEnabled()) return signFacade;
/* 167 */           LOG.error("", ex);
/*     */         }
/*     */         catch (ClassCastException ex) {
/* 170 */           LOG.error(I18N.getLocalMessage("i18n.mityc.api.bridge.5"));
/* 171 */           if (!LOG.isDebugEnabled()) return signFacade;
/* 172 */           LOG.error("", ex);
/*     */         }
/*     */         catch (NoSuchMethodException ex) {
/* 175 */           LOG.error(I18N.getLocalMessage("i18n.mityc.api.bridge.5"));
/* 176 */           if (!LOG.isDebugEnabled()) return signFacade; }
/* 177 */         LOG.error("", ex);
/*     */       }
/*     */       else
/*     */       {
/* 181 */         LOG.error(I18N.getLocalMessage("i18n.mityc.api.bridge.6"));
/*     */       }
/*     */     }
/* 184 */     return signFacade;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\bridge\SignFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */