package es.mityc.javasign.io;

public abstract interface IDecoder
{
  public abstract boolean needsInput();
  
  public abstract boolean isIncomplete();
  
  public abstract void addInput(byte[] paramArrayOfByte, int paramInt1, int paramInt2);
  
  public abstract int decode(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws DecodingException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\io\IDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */