/*     */ package es.mityc.javasign.io;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EmptyDecoder
/*     */   implements IDecoder
/*     */ {
/*     */   private byte[] buffer;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addInput(byte[] data, int pos, int len)
/*     */   {
/*  55 */     int totalLen = len + (this.buffer != null ? this.buffer.length : 0);
/*  56 */     byte[] temp = new byte[totalLen];
/*  57 */     int off = 0;
/*  58 */     if (this.buffer != null) {
/*  59 */       System.arraycopy(this.buffer, 0, temp, off, this.buffer.length);
/*  60 */       off += this.buffer.length;
/*     */     }
/*  62 */     System.arraycopy(data, pos, temp, off, len);
/*  63 */     this.buffer = temp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int decode(byte[] data, int off, int len)
/*     */     throws DecodingException
/*     */   {
/*  77 */     if ((off < 0) || (len < 0) || (off > data.length - len)) {
/*  78 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/*  80 */     int res = 0;
/*  81 */     if (this.buffer != null)
/*     */     {
/*  83 */       int lenBuffer = this.buffer.length;
/*     */       
/*  85 */       int actualLen = Math.min(len, lenBuffer);
/*  86 */       System.arraycopy(this.buffer, 0, data, off, actualLen);
/*  87 */       if (actualLen < lenBuffer) {
/*  88 */         int tempLen = lenBuffer - actualLen;
/*  89 */         byte[] temp = new byte[tempLen];
/*  90 */         System.arraycopy(this.buffer, actualLen, temp, 0, tempLen);
/*  91 */         this.buffer = temp;
/*     */       } else {
/*  93 */         this.buffer = null;
/*     */       }
/*  95 */       res = actualLen;
/*     */     }
/*  97 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean needsInput()
/*     */   {
/* 108 */     return this.buffer == null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isIncomplete()
/*     */   {
/* 117 */     return this.buffer != null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\io\EmptyDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */