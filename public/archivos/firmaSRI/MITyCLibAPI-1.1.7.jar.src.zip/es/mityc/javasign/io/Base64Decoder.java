/*     */ package es.mityc.javasign.io;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Base64Decoder
/*     */   implements IDecoder
/*     */ {
/*     */   private static final int BASE64_CHUNK_LENGTH = 4;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int BASE64_CHUNK_DECODED_LENGTH = 3;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] buffer;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] remaining;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean countMode;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  46 */   private long count = 0L;
/*     */   
/*     */ 
/*     */ 
/*     */   public Base64Decoder()
/*     */   {
/*  52 */     this(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Base64Decoder(boolean onlyCountMode)
/*     */   {
/*  60 */     this.countMode = onlyCountMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/*  67 */     this.count = 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getCount()
/*     */   {
/*  75 */     return this.count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addInput(byte[] data, int pos, int len)
/*     */   {
/*  86 */     int totalLen = len + (this.buffer != null ? this.buffer.length : 0) + (this.remaining != null ? this.remaining.length : 0);
/*  87 */     byte[] temp = new byte[totalLen];
/*  88 */     int off = 0;
/*  89 */     if (this.remaining != null) {
/*  90 */       System.arraycopy(this.remaining, 0, temp, 0, this.remaining.length);
/*  91 */       off += this.remaining.length;
/*     */     }
/*  93 */     if (this.buffer != null) {
/*  94 */       System.arraycopy(this.buffer, 0, temp, off, this.buffer.length);
/*  95 */       off += this.buffer.length;
/*     */     }
/*  97 */     System.arraycopy(data, pos, temp, off, len);
/*  98 */     this.buffer = temp;
/*  99 */     this.remaining = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int decode(byte[] data, int off, int len)
/*     */     throws DecodingException
/*     */   {
/* 113 */     if ((off < 0) || (len < 0) || (off > data.length - len)) {
/* 114 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/* 116 */     if (len < 3) {
/* 117 */       throw new DecodingException("Buffer too small, minimum size = 3");
/*     */     }
/* 119 */     int res = 0;
/* 120 */     if (this.buffer != null)
/*     */     {
/* 122 */       String s = new String(this.buffer).replace("\r\n", "").replace(" ", "").replace("\n", "");
/*     */       
/* 124 */       if (s.length() % 4 != 0) {
/* 125 */         this.remaining = s.substring(s.length() - s.length() % 4).getBytes();
/* 126 */         s = s.substring(0, s.length() - s.length() % 4);
/*     */       } else {
/* 128 */         this.remaining = null;
/*     */       }
/*     */       
/* 131 */       int len64 = s.length() * 3 / 4;
/* 132 */       if (s.endsWith("==")) {
/* 133 */         len64 -= 2;
/* 134 */       } else if (s.endsWith("=")) {
/* 135 */         len64--;
/*     */       }
/* 137 */       int actualLen = len;
/* 138 */       if (actualLen < len64) {
/* 139 */         actualLen -= actualLen % 3;
/* 140 */         this.buffer = s.substring(actualLen * 4 / 3).getBytes();
/* 141 */         s = s.substring(0, actualLen * 4 / 3 - 1);
/*     */       } else {
/* 143 */         this.buffer = null;
/*     */       }
/* 145 */       if (!this.countMode) {
/* 146 */         res = base64ToByteArray(s, data, off);
/* 147 */         this.count += res;
/*     */       } else {
/* 149 */         this.count += s.length() * 3 / 4;
/*     */       }
/*     */     }
/* 152 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int base64ToByteArray(String s, byte[] data, int off)
/*     */   {
/* 167 */     int sLen = s.length();
/* 168 */     int numGroups = sLen / 4;
/* 169 */     if (4 * numGroups != sLen) {
/* 170 */       throw new IllegalArgumentException("String length must be a multiple of four.");
/*     */     }
/* 172 */     int missingBytesInLastGroup = 0;
/* 173 */     int numFullGroups = numGroups;
/* 174 */     if (sLen != 0) {
/* 175 */       if (s.charAt(sLen - 1) == '=') {
/* 176 */         missingBytesInLastGroup++;
/* 177 */         numFullGroups--;
/*     */       }
/* 179 */       if (s.charAt(sLen - 2) == '=') {
/* 180 */         missingBytesInLastGroup++;
/*     */       }
/*     */     }
/*     */     
/* 184 */     int inCursor = 0;int outCursor = off;
/* 185 */     for (int i = 0; i < numFullGroups; i++) {
/* 186 */       int ch0 = base64toInt(s.charAt(inCursor++), BASE64_TO_INT);
/* 187 */       int ch1 = base64toInt(s.charAt(inCursor++), BASE64_TO_INT);
/* 188 */       int ch2 = base64toInt(s.charAt(inCursor++), BASE64_TO_INT);
/* 189 */       int ch3 = base64toInt(s.charAt(inCursor++), BASE64_TO_INT);
/* 190 */       data[(outCursor++)] = ((byte)(ch0 << 2 | ch1 >> 4));
/* 191 */       data[(outCursor++)] = ((byte)(ch1 << 4 | ch2 >> 2));
/* 192 */       data[(outCursor++)] = ((byte)(ch2 << 6 | ch3));
/*     */     }
/*     */     
/*     */ 
/* 196 */     if (missingBytesInLastGroup != 0) {
/* 197 */       int ch0 = base64toInt(s.charAt(inCursor++), BASE64_TO_INT);
/* 198 */       int ch1 = base64toInt(s.charAt(inCursor++), BASE64_TO_INT);
/* 199 */       data[(outCursor++)] = ((byte)(ch0 << 2 | ch1 >> 4));
/*     */       
/* 201 */       if (missingBytesInLastGroup == 1) {
/* 202 */         int ch2 = base64toInt(s.charAt(inCursor++), BASE64_TO_INT);
/* 203 */         data[(outCursor++)] = ((byte)(ch1 << 4 | ch2 >> 2));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 208 */     return outCursor - off;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int base64toInt(char c, byte[] alphaToInt)
/*     */   {
/* 221 */     int result = alphaToInt[c];
/* 222 */     if (result < 0) {
/* 223 */       throw new IllegalArgumentException("Illegal character " + c);
/*     */     }
/* 225 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 236 */   private static final byte[] BASE64_TO_INT = {
/* 237 */     -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
/* 238 */     -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
/* 239 */     -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 
/* 240 */     55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 
/* 241 */     5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 
/* 242 */     24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 
/* 243 */     35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean needsInput()
/*     */   {
/* 253 */     return this.buffer == null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isIncomplete()
/*     */   {
/* 262 */     return (this.remaining != null) || (this.buffer != null);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\io\Base64Decoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */