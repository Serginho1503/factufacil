/*    */ package es.mityc.javasign.io;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteArrayWrittable
/*    */   implements IWriter
/*    */ {
/*    */   private ByteArrayOutputStream baos;
/*    */   
/*    */   public ByteArrayWrittable()
/*    */   {
/* 35 */     this.baos = new ByteArrayOutputStream();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void write(byte[] b, int off, int len)
/*    */   {
/* 46 */     this.baos.write(b, off, len);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void flush()
/*    */     throws IOException
/*    */   {
/* 55 */     this.baos.flush();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void reset()
/*    */   {
/* 64 */     this.baos.reset();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int size()
/*    */   {
/* 73 */     return this.baos.size();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] toByteArray()
/*    */   {
/* 82 */     return this.baos.toByteArray();
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\io\ByteArrayWrittable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */