/*     */ package es.mityc.javasign.io;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DecoderInputStream
/*     */   extends FilterInputStream
/*     */ {
/*     */   private static final int MAX_TRIES = 3;
/*     */   private static final int DEFAULT_BUFFER_SIZE = 512;
/*     */   protected IDecoder decoder;
/*     */   protected byte[] buf;
/*     */   protected int lenBuffer;
/*  45 */   private boolean closed = false;
/*     */   
/*  47 */   private boolean reachEOF = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DecoderInputStream(InputStream in, IDecoder dec)
/*     */   {
/*  56 */     this(in, dec, 512);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DecoderInputStream(InputStream in, IDecoder dec, int size)
/*     */   {
/*  66 */     super(in);
/*  67 */     if ((in == null) || (dec == null))
/*  68 */       throw new NullPointerException();
/*  69 */     if (size <= 0) {
/*  70 */       throw new IllegalArgumentException("buffer size <= 0");
/*     */     }
/*  72 */     this.decoder = dec;
/*  73 */     this.buf = new byte[size];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void ensureOpen()
/*     */     throws IOException
/*     */   {
/*  81 */     if (this.closed) {
/*  82 */       throw new IOException("Stream closed");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*  87 */   private byte[] singleByteBuf = new byte[1];
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int MASK_BYTE = 255;
/*     */   
/*     */ 
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/*  98 */     ensureOpen();
/*  99 */     return read(this.singleByteBuf, 0, 1) == -1 ? -1 : this.singleByteBuf[0] & 0xFF;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 116 */     ensureOpen();
/* 117 */     if ((off | len | off + len | b.length - (off + len)) < 0)
/* 118 */       throw new IndexOutOfBoundsException();
/* 119 */     if (len == 0) {
/* 120 */       return 0;
/*     */     }
/*     */     
/* 123 */     int tries = 0;
/* 124 */     int n; while ((n = this.decoder.decode(b, off, len)) == 0) { int n;
/* 125 */       if ((this.decoder.needsInput()) && 
/* 126 */         (fill() == -1)) {
/* 127 */         if (this.decoder.isIncomplete()) {
/* 128 */           throw new EOFException("Decoder has buffer not depleted");
/*     */         }
/* 130 */         this.reachEOF = true;
/* 131 */         return -1;
/*     */       }
/*     */       
/* 134 */       tries++;
/* 135 */       if (tries > 3) {
/*     */         break;
/*     */       }
/*     */     }
/* 139 */     return n;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int available()
/*     */     throws IOException
/*     */   {
/* 153 */     ensureOpen();
/* 154 */     if (this.reachEOF) {
/* 155 */       return 0;
/*     */     }
/* 157 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 162 */   private byte[] tempBuffer = new byte['Ȁ'];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long skip(long n)
/*     */     throws IOException
/*     */   {
/* 172 */     if (n < 0L) {
/* 173 */       throw new IllegalArgumentException("negative skip length");
/*     */     }
/* 175 */     ensureOpen();
/* 176 */     int max = (int)Math.min(n, 2147483647L);
/* 177 */     int total = 0;
/* 178 */     while (total < max) {
/* 179 */       int len = max - total;
/* 180 */       if (len > this.tempBuffer.length) {
/* 181 */         len = this.tempBuffer.length;
/*     */       }
/* 183 */       len = read(this.tempBuffer, 0, len);
/* 184 */       if (len == -1) {
/* 185 */         this.reachEOF = true;
/* 186 */         break;
/*     */       }
/* 188 */       total += len;
/*     */     }
/* 190 */     return total;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 199 */     if (!this.closed) {
/* 200 */       this.in.close();
/* 201 */       this.closed = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int fill()
/*     */     throws IOException
/*     */   {
/* 211 */     ensureOpen();
/* 212 */     this.lenBuffer = this.in.read(this.buf, 0, this.buf.length);
/* 213 */     if (this.lenBuffer > -1) {
/* 214 */       this.decoder.addInput(this.buf, 0, this.lenBuffer);
/*     */     }
/* 216 */     return this.lenBuffer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean markSupported()
/*     */   {
/* 231 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void mark(int readlimit) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void reset()
/*     */     throws IOException
/*     */   {
/* 260 */     throw new IOException("mark/reset not supported");
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\io\DecoderInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */