package es.mityc.javasign.io;

import java.io.IOException;

public abstract interface IWriter
{
  public abstract void flush()
    throws IOException;
  
  public abstract byte[] toByteArray();
  
  public abstract void reset();
  
  public abstract int size();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\io\IWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */