/*    */ package es.mityc.javasign.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DecodingException
/*    */   extends IOException
/*    */ {
/*    */   public DecodingException() {}
/*    */   
/*    */   public DecodingException(String message)
/*    */   {
/* 39 */     super(message);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\io\DecodingException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */