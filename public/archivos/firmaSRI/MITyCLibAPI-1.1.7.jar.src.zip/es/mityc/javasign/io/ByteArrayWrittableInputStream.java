/*    */ package es.mityc.javasign.io;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteArrayWrittableInputStream
/*    */   extends InputStream
/*    */ {
/* 34 */   private ByteArrayInputStream bais = null;
/*    */   
/* 36 */   private IWriter writer = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ByteArrayWrittableInputStream(IWriter wrt)
/*    */   {
/* 43 */     this.bais = new ByteArrayInputStream(new byte[0]);
/* 44 */     this.writer = wrt;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int read()
/*    */     throws IOException
/*    */   {
/* 56 */     int data = this.bais.read();
/* 57 */     if (data == -1) {
/* 58 */       updateBuffer();
/* 59 */       data = this.bais.read();
/*    */     }
/* 61 */     return data;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   private void updateBuffer()
/*    */     throws IOException
/*    */   {
/* 69 */     flush();
/* 70 */     this.bais = new ByteArrayInputStream(this.writer.toByteArray());
/* 71 */     this.writer.reset();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void flush()
/*    */     throws IOException
/*    */   {
/* 80 */     this.writer.flush();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int available()
/*    */     throws IOException
/*    */   {
/* 94 */     int i = this.bais.available();
/* 95 */     if (i == 0) {
/* 96 */       i = this.writer.size();
/*    */     }
/* 98 */     return i;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\io\ByteArrayWrittableInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */