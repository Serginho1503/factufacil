/*    */ package es.mityc.javasign.io;
/*    */ 
/*    */ import java.io.CharArrayWriter;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CharWrittable
/*    */   implements IWriter
/*    */ {
/*    */   private CharArrayWriter caw;
/*    */   
/*    */   public CharWrittable()
/*    */   {
/* 35 */     this.caw = new CharArrayWriter();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void write(char[] c, int off, int len)
/*    */   {
/* 46 */     this.caw.write(c, off, len);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void flush()
/*    */     throws IOException
/*    */   {
/* 55 */     this.caw.flush();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void reset()
/*    */   {
/* 63 */     this.caw.reset();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int size()
/*    */   {
/* 72 */     return this.caw.size();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] toByteArray()
/*    */   {
/* 81 */     return this.caw.toString().getBytes();
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\io\CharWrittable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */