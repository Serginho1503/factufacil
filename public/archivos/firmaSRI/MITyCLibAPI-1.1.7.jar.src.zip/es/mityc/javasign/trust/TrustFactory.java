/*     */ package es.mityc.javasign.trust;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrustFactory
/*     */ {
/*  63 */   private static final Log LOG = LogFactory.getLog(TrustFactory.class);
/*     */   
/*  65 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibAPI");
/*     */   
/*     */ 
/*     */   private static final String METHOD_GET_INSTANCE = "getInstance";
/*     */   
/*     */ 
/*     */   private static final String METHOD_NEW_INSTANCE = "newInstance";
/*     */   
/*     */ 
/*     */   private static final String STRING_EMPTY = "";
/*     */   
/*     */ 
/*     */   private static final String TRUST_SERVICES_FILE_CONF = "META-INF/trust/trustservices.properties";
/*     */   
/*     */ 
/*     */   private static final String TRUST_SERVICES_FACTORY_CLASS = "services.trust.factory.class";
/*     */   
/*     */   private static final String TRUST_FILE_CONF = "trust/trust.properties";
/*     */   
/*     */   private static final String TRUSTER_PROP_NO_AVALAIBLE = "none";
/*     */   
/*  86 */   private Properties props = null;
/*     */   
/*  88 */   private static TrustFactory instance = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected TrustFactory()
/*     */   {
/*  95 */     loadConfig();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ClassLoader getClassLoader()
/*     */   {
/*     */     try
/*     */     {
/* 105 */       ClassLoader cl = (ClassLoader)AccessController.doPrivileged(new PrivilegedAction() {
/*     */         public ClassLoader run() {
/* 107 */           ClassLoader classLoader = null;
/*     */           try {
/* 109 */             classLoader = Thread.currentThread().getContextClassLoader();
/*     */           }
/*     */           catch (SecurityException localSecurityException) {}
/* 112 */           return classLoader;
/*     */         }
/*     */       });
/* 115 */       if (cl != null) {
/* 116 */         return cl;
/*     */       }
/*     */     }
/*     */     catch (Exception localException) {}
/* 120 */     return TrustFactory.class.getClassLoader();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void loadConfig()
/*     */   {
/* 128 */     ClassLoader cl = getClassLoader();
/*     */     try
/*     */     {
/* 131 */       ArrayList<URL> resources = new ArrayList();
/* 132 */       Enumeration<URL> en = cl.getResources("trust/trust.properties");
/* 133 */       while (en.hasMoreElements()) {
/* 134 */         resources.add(0, (URL)en.nextElement());
/*     */       }
/*     */       
/* 137 */       Properties base = null;
/* 138 */       Iterator<URL> itResources = resources.iterator();
/* 139 */       while (itResources.hasNext()) {
/* 140 */         URL url = (URL)itResources.next();
/*     */         try {
/* 142 */           if (LOG.isDebugEnabled())
/* 143 */             LOG.debug("Cargando el fichero de propiedades de listas de confianza: " + url);
/* 144 */           InputStream is = url.openStream();
/* 145 */           Properties properties = new Properties(base);
/* 146 */           properties.load(is);
/* 147 */           base = properties;
/*     */         } catch (IOException ex) {
/* 149 */           LOG.error(I18N.getLocalMessage("i18n.mityc.api.trust.9", new Object[] { url, ex.getMessage() }));
/*     */         }
/*     */       }
/* 152 */       this.props = base;
/*     */     } catch (IOException ex) {
/* 154 */       LOG.error(I18N.getLocalMessage("i18n.mityc.api.trust.1", new Object[] { ex.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static TrustFactory getInstance()
/*     */   {
/* 163 */     if (instance == null)
/*     */     {
/*     */       try {
/* 166 */         String classname = null;
/*     */         
/* 168 */         ClassLoader cl = getClassLoader();
/* 169 */         InputStream is = cl.getResourceAsStream("META-INF/trust/trustservices.properties");
/* 170 */         if (is != null) {
/* 171 */           Properties rb = new Properties();
/*     */           try {
/* 173 */             rb.load(is);
/* 174 */             classname = rb.getProperty("services.trust.factory.class");
/*     */           } catch (IOException ex) {
/* 176 */             LOG.warn(I18N.getLocalMessage("i18n.mityc.api.trust.9", new Object[] { "services.trust.factory.class", ex.getMessage() }));
/*     */           }
/*     */         }
/*     */         
/* 180 */         if (classname != null) {
/*     */           try {
/* 182 */             Class<?> classFactory = null;
/* 183 */             if (cl != null) {
/* 184 */               classFactory = cl.loadClass(classname);
/*     */             } else {
/* 186 */               classFactory = Class.forName(classname);
/*     */             }
/* 188 */             if (classFactory == null) break label477;
/* 189 */             Method method = classFactory.getDeclaredMethod("newInstance", new Class[0]);
/* 190 */             Class<?> returnType = method.getReturnType();
/* 191 */             if ((returnType == null) || (!returnType.isAssignableFrom(TrustFactory.class))) break label477;
/* 192 */             instance = (TrustFactory)method.invoke(null, new Object[0]);
/*     */           }
/*     */           catch (IllegalAccessException ex)
/*     */           {
/* 196 */             LOG.error(I18N.getLocalMessage("i18n.mityc.api.trust.8", new Object[] { classname }));
/* 197 */             if (!LOG.isDebugEnabled()) break label477;
/* 198 */             LOG.debug("", ex);
/*     */           }
/*     */           catch (ClassNotFoundException ex) {
/* 201 */             LOG.error(I18N.getLocalMessage("i18n.mityc.api.trust.8", new Object[] { classname }));
/* 202 */             if (!LOG.isDebugEnabled()) break label477;
/* 203 */             LOG.debug("", ex);
/*     */           }
/*     */           catch (ClassCastException ex) {
/* 206 */             LOG.error(I18N.getLocalMessage("i18n.mityc.api.trust.8", new Object[] { classname }));
/* 207 */             if (!LOG.isDebugEnabled()) break label477;
/* 208 */             LOG.debug("", ex);
/*     */           }
/*     */           catch (NoSuchMethodException ex) {
/* 211 */             LOG.error(I18N.getLocalMessage("i18n.mityc.api.trust.8", new Object[] { classname }));
/* 212 */             if (!LOG.isDebugEnabled()) break label477;
/* 213 */             LOG.debug("", ex);
/*     */           }
/*     */           catch (IllegalArgumentException ex) {
/* 216 */             LOG.error(I18N.getLocalMessage("i18n.mityc.api.trust.8", new Object[] { classname }));
/* 217 */             if (!LOG.isDebugEnabled()) break label477;
/* 218 */             LOG.debug("", ex);
/*     */           }
/*     */           catch (InvocationTargetException ex) {
/* 221 */             LOG.error(I18N.getLocalMessage("i18n.mityc.api.trust.8", new Object[] { classname }));
/* 222 */             if (!LOG.isDebugEnabled()) break label477; }
/* 223 */           LOG.debug("", ex);
/*     */         }
/*     */       }
/*     */       catch (MissingResourceException localMissingResourceException) {}
/*     */       
/*     */       label477:
/* 229 */       if (instance == null) {
/* 230 */         instance = newInstance();
/*     */       }
/*     */     }
/* 233 */     return instance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static TrustFactory newInstance()
/*     */   {
/* 242 */     return new TrustFactory();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setDefault(TrustFactory factory)
/*     */   {
/* 252 */     instance = factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getClassname(String key)
/*     */   {
/* 265 */     String classname = this.props.getProperty(key);
/* 266 */     if (classname == null) {
/* 267 */       LOG.warn(I18N.getLocalMessage("i18n.mityc.api.trust.6", new Object[] { key }));
/*     */     }
/* 269 */     return classname;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TrustAbstract getTruster(String key)
/*     */   {
/* 282 */     TrustAbstract truster = null;
/* 283 */     if (instance != null) {
/* 284 */       String classname = getClassname(key);
/* 285 */       if ((classname != null) && (!"none".equals(classname.trim().toLowerCase()))) {
/*     */         try {
/* 287 */           ClassLoader cl = getClassLoader();
/* 288 */           Class<?> classTruster = null;
/* 289 */           if (cl != null) {
/* 290 */             classTruster = cl.loadClass(classname);
/*     */           } else {
/* 292 */             classTruster = Class.forName(classname);
/*     */           }
/* 294 */           if (classTruster != null) {
/* 295 */             Method method = classTruster.getMethod("getInstance", new Class[0]);
/* 296 */             Object obj = method.invoke(null, new Object[0]);
/* 297 */             if ((obj instanceof TrustAbstract)) {
/* 298 */               truster = (TrustAbstract)obj;
/*     */             }
/*     */           }
/*     */         } catch (IllegalAccessException ex) {
/* 302 */           LOG.error(I18N.getLocalMessage("i18n.mityc.api.trust.3", new Object[] { key, classname }));
/* 303 */           if (LOG.isDebugEnabled()) {
/* 304 */             LOG.debug("", ex);
/*     */           }
/*     */         } catch (ClassNotFoundException ex) {
/* 307 */           LOG.error(I18N.getLocalMessage("i18n.mityc.api.trust.4", new Object[] { key, classname }));
/* 308 */           if (LOG.isDebugEnabled()) {
/* 309 */             LOG.debug("", ex);
/*     */           }
/*     */         } catch (ClassCastException ex) {
/* 312 */           LOG.error(I18N.getLocalMessage("i18n.mityc.api.trust.5", new Object[] { key, classname }));
/* 313 */           if (LOG.isDebugEnabled()) {
/* 314 */             LOG.debug("", ex);
/*     */           }
/*     */         } catch (NoSuchMethodException ex) {
/* 317 */           LOG.error(I18N.getLocalMessage("i18n.mityc.api.trust.6", new Object[] { key, classname }));
/* 318 */           if (LOG.isDebugEnabled()) {
/* 319 */             LOG.debug("", ex);
/*     */           }
/*     */         } catch (IllegalArgumentException ex) {
/* 322 */           LOG.error(I18N.getLocalMessage("i18n.mityc.api.trust.3", new Object[] { key, classname }));
/* 323 */           if (LOG.isDebugEnabled()) {
/* 324 */             LOG.debug("", ex);
/*     */           }
/*     */         } catch (InvocationTargetException ex) {
/* 327 */           LOG.error(I18N.getLocalMessage("i18n.mityc.api.trust.2", new Object[] { key, classname }));
/* 328 */           if (LOG.isDebugEnabled()) {
/* 329 */             LOG.debug("", ex);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 334 */     return truster;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\trust\TrustFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */