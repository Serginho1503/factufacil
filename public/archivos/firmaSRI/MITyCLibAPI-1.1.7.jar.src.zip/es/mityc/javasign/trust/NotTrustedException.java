/*    */ package es.mityc.javasign.trust;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotTrustedException
/*    */   extends TrustException
/*    */ {
/*    */   static final long serialVersionUID = 1L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public NotTrustedException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public NotTrustedException(String message)
/*    */   {
/* 40 */     super(message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public NotTrustedException(Throwable cause)
/*    */   {
/* 48 */     super(cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public NotTrustedException(String message, Throwable cause)
/*    */   {
/* 57 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\trust\NotTrustedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */