/*    */ package es.mityc.javasign.trust;
/*    */ 
/*    */ import java.security.cert.CertPath;
/*    */ import java.security.cert.X509Certificate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TrustAbstract
/*    */ {
/*    */   public static TrustAbstract getInstance()
/*    */   {
/* 37 */     throw new UnsupportedOperationException();
/*    */   }
/*    */   
/*    */   public abstract void isTrusted(Object paramObject)
/*    */     throws TrustException;
/*    */   
/*    */   public abstract CertPath getCertPath(X509Certificate paramX509Certificate)
/*    */     throws UnknownTrustException;
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\trust\TrustAbstract.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */