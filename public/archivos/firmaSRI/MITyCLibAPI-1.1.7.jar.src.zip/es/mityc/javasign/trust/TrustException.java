/*    */ package es.mityc.javasign.trust;
/*    */ 
/*    */ import es.mityc.javasign.exception.SignMITyCException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TrustException
/*    */   extends SignMITyCException
/*    */ {
/*    */   static final long serialVersionUID = 1L;
/*    */   
/*    */   public TrustException() {}
/*    */   
/*    */   public TrustException(String message)
/*    */   {
/* 42 */     super(message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public TrustException(Throwable cause)
/*    */   {
/* 50 */     super(cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public TrustException(String message, Throwable cause)
/*    */   {
/* 59 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibAPI-1.1.7.jar!\es\mityc\javasign\trust\TrustException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */