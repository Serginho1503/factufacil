/*    */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*    */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*    */ import java.util.ArrayList;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CertificateValues
/*    */   extends CertificateValuesType
/*    */ {
/*    */   public CertificateValues(XAdESSchemas schema)
/*    */   {
/* 37 */     super(schema);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public CertificateValues(XAdESSchemas schema, ArrayList<EncapsulatedX509Certificate> certificates)
/*    */   {
/* 45 */     super(schema, certificates);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void load(Element element)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 53 */     checkElementName(element, this.schema.getSchemaUri(), "CertificateValues");
/* 54 */     super.load(element);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isThisNode(Node node)
/*    */   {
/* 62 */     return isElementName(nodeToElement(node), this.schema.getSchemaUri(), "CertificateValues");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Element createElement(Document doc, String namespaceXAdES)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 70 */     return super.createElement(doc, namespaceXAdES);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected Element createElement(Document doc)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 78 */     Element res = doc.createElementNS(this.schema.getSchemaUri(), this.namespaceXAdES + ":" + "CertificateValues");
/* 79 */     super.addContent(res, this.namespaceXAdES);
/* 80 */     return res;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\CertificateValues.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */