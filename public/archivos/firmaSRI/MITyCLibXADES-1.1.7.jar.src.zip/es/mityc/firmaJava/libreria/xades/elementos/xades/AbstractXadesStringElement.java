/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.XMLDataStringType;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractXadesStringElement
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private XMLDataStringType data;
/*     */   private String nameElement;
/*     */   
/*     */   public AbstractXadesStringElement(XAdESSchemas schema, String nameElement, String data)
/*     */   {
/*  34 */     super(schema);
/*  35 */     this.nameElement = nameElement;
/*  36 */     this.data = new XMLDataStringType(data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractXadesStringElement(XAdESSchemas schema, String nameElement)
/*     */   {
/*  45 */     super(schema);
/*  46 */     this.nameElement = nameElement;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Element createElement(Document doc)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  54 */     if (this.data == null)
/*  55 */       throw new InvalidInfoNodeException("Información insuficiente para escribir elemento " + this.nameElement);
/*  56 */     Element res = doc.createElementNS(this.schema.getSchemaUri(), this.namespaceXAdES + ":" + this.nameElement);
/*  57 */     this.data.addContent(res);
/*  58 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Element createElement(Document doc, String namespaceXAdES)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  66 */     return super.createElement(doc, namespaceXAdES);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  74 */     if ((obj instanceof AbstractXadesStringElement)) {
/*  75 */       AbstractXadesStringElement desc = (AbstractXadesStringElement)obj;
/*  76 */       if ((this.nameElement.equals(desc.nameElement)) && (this.data.equals(desc.data))) {
/*  77 */         return true;
/*     */       }
/*     */     } else {
/*  80 */       return this.data.equals(obj); }
/*  81 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  89 */     checkElementName(element, this.schema.getSchemaUri(), this.nameElement);
/*  90 */     this.data = new XMLDataStringType(null);
/*  91 */     this.data.load(element);
/*     */   }
/*     */   
/*     */   public void setValue(String value) {
/*  95 */     if (this.data == null) {
/*  96 */       this.data = new XMLDataStringType(value);
/*     */     } else
/*  98 */       this.data.setValue(value);
/*     */   }
/*     */   
/*     */   public String getValue() {
/* 102 */     if (this.data != null)
/* 103 */       return this.data.getValue();
/* 104 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isThisNode(Node node)
/*     */   {
/* 112 */     return isElementName(nodeToElement(node), this.schema.getSchemaUri(), this.nameElement);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\AbstractXadesStringElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */