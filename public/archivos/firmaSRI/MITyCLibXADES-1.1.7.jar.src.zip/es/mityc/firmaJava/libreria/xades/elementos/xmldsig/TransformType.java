/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xmldsig;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TransformType
/*     */   extends AbstractXDsigElement
/*     */ {
/*     */   private String algorithm;
/*     */   private NodeList extraNodes;
/*     */   
/*     */   public TransformType(String algorithm)
/*     */   {
/*  38 */     this.algorithm = algorithm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TransformType() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  50 */     if ((obj instanceof TransformType)) {
/*  51 */       TransformType method = (TransformType)obj;
/*  52 */       if (this.algorithm.equals(method.algorithm))
/*  53 */         return true;
/*     */     }
/*  55 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  63 */     if (!element.hasAttribute("Algorithm"))
/*  64 */       throw new InvalidInfoNodeException("Atributo requerido no presenteAlgorithm");
/*  65 */     this.algorithm = element.getAttribute("Algorithm");
/*     */     
/*     */ 
/*  68 */     this.extraNodes = element.getChildNodes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getAlgorithm()
/*     */   {
/*  75 */     return this.algorithm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setAlgorithm(String algorithm)
/*     */   {
/*  82 */     this.algorithm = algorithm;
/*     */   }
/*     */   
/*     */   public NodeList getExtraNodes() {
/*  86 */     return this.extraNodes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void addContent(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  94 */     if (this.algorithm == null)
/*  95 */       throw new InvalidInfoNodeException("Información insuficiente para escribir nodo TransformType");
/*  96 */     element.setAttributeNS(null, "Algorithm", this.algorithm);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addContent(Element element, String namespaceXDsig)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 104 */     super.addContent(element, namespaceXDsig);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xmldsig\TransformType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */