/*    */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*    */ 
/*    */ import java.net.URI;
/*    */ import java.net.URISyntaxException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum EncodingEnum
/*    */ {
/* 29 */   DER_ENCODED("http://uri.etsi.org/01903/v1.2.2#DER"), 
/* 30 */   BER_ENCODED("http://uri.etsi.org/01903/v1.2.2#BER"), 
/* 31 */   CER_ENCODED("http://uri.etsi.org/01903/v1.2.2#CER"), 
/* 32 */   PER_ENCODED("http://uri.etsi.org/01903/v1.2.2#PER"), 
/* 33 */   XER_ENCODED("http://uri.etsi.org/01903/v1.2.2#XER");
/*    */   
/* 35 */   private static final Log logger = LogFactory.getLog(EncodingEnum.class);
/*    */   private URI uri;
/*    */   
/*    */   private EncodingEnum(String uri) {
/*    */     Log logger;
/*    */     try {
/* 41 */       this.uri = new URI(uri);
/*    */     } catch (URISyntaxException ex) {
/* 43 */       logger = LogFactory.getLog(EncodingEnum.class);
/* 44 */       logger.error("Error creando enumerado de encoding", ex);
/*    */     }
/*    */   }
/*    */   
/*    */   public URI getEncodingUri() {
/* 49 */     return this.uri;
/*    */   }
/*    */   
/*    */   public static EncodingEnum getEncoding(String uri) {
/*    */     try {
/* 54 */       if ((uri == null) || ("".equals(uri.trim())))
/* 55 */         return DER_ENCODED;
/* 56 */       URI temp = new URI(uri);
/* 57 */       if (temp.equals(DER_ENCODED.uri))
/* 58 */         return DER_ENCODED;
/* 59 */       if (temp.equals(BER_ENCODED.uri))
/* 60 */         return BER_ENCODED;
/* 61 */       if (temp.equals(CER_ENCODED.uri))
/* 62 */         return CER_ENCODED;
/* 63 */       if (temp.equals(PER_ENCODED.uri))
/* 64 */         return PER_ENCODED;
/* 65 */       if (temp.equals(XER_ENCODED.uri))
/* 66 */         return XER_ENCODED;
/*    */     } catch (URISyntaxException ex) {
/* 68 */       if (logger.isDebugEnabled())
/* 69 */         logger.debug("Encoding indicado no es una URI", ex);
/* 70 */       return null;
/*    */     }
/* 72 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\EncodingEnum.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */