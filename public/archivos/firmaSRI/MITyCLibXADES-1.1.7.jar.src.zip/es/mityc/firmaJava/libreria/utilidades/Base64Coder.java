/*     */ package es.mityc.firmaJava.libreria.utilidades;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Base64Coder
/*     */ {
/*  54 */   private static char[] map1 = new char[64];
/*     */   private static byte[] map2;
/*     */   
/*  57 */   static { int i = 0;
/*  58 */     for (char c = 'A'; c <= 'Z'; c = (char)(c + '\001'))
/*  59 */       map1[(i++)] = c;
/*  60 */     for (char c = 'a'; c <= 'z'; c = (char)(c + '\001'))
/*  61 */       map1[(i++)] = c;
/*  62 */     for (char c = '0'; c <= '9'; c = (char)(c + '\001'))
/*  63 */       map1[(i++)] = c;
/*  64 */     map1[(i++)] = '+';
/*  65 */     map1[(i++)] = '/';
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  70 */     map2 = new byte[''];
/*     */     
/*  72 */     for (int i = 0; i < map2.length; i++)
/*  73 */       map2[i] = -1;
/*  74 */     for (int i = 0; i < 64; i++) {
/*  75 */       map2[map1[i]] = ((byte)i);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encodeString(String s)
/*     */   {
/*  88 */     return new String(encode(s.getBytes()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static char[] encode(byte[] in)
/*     */   {
/* 101 */     return encode(in, in.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static char[] encode(byte[] in, int iLen)
/*     */   {
/* 116 */     int oDataLen = (iLen * 4 + 2) / 3;
/* 117 */     int oLen = (iLen + 2) / 3 * 4;
/* 118 */     char[] out = new char[oLen];
/* 119 */     int ip = 0;
/* 120 */     int op = 0;
/* 121 */     while (ip < iLen) {
/* 122 */       int i0 = in[(ip++)] & 0xFF;
/* 123 */       int i1 = ip < iLen ? in[(ip++)] & 0xFF : 0;
/* 124 */       int i2 = ip < iLen ? in[(ip++)] & 0xFF : 0;
/* 125 */       int o0 = i0 >>> 2;
/* 126 */       int o1 = (i0 & 0x3) << 4 | i1 >>> 4;
/* 127 */       int o2 = (i1 & 0xF) << 2 | i2 >>> 6;
/* 128 */       int o3 = i2 & 0x3F;
/* 129 */       out[(op++)] = map1[o0];
/* 130 */       out[(op++)] = map1[o1];
/* 131 */       out[op] = (op < oDataLen ? map1[o2] : '=');
/* 132 */       op++;
/* 133 */       out[op] = (op < oDataLen ? map1[o3] : '=');
/* 134 */       op++;
/*     */     }
/* 136 */     return out;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String decodeString(String s)
/*     */   {
/* 150 */     return new String(decode(s));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] decode(String input)
/*     */   {
/* 160 */     String cadena = new String(input);
/* 161 */     cadena = cadena.replace(" ", "").replace("\n", "").replace("\r", "");
/* 162 */     return decode(cadena.toCharArray());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] decode(Object input)
/*     */   {
/* 177 */     char[] in = null;
/*     */     
/* 179 */     if ((input instanceof String)) {
/* 180 */       in = ((String)input).toCharArray();
/* 181 */     } else if ((input instanceof char[])) {
/* 182 */       in = (char[])input;
/*     */     } else {
/* 184 */       throw new IllegalArgumentException("Base64 input not properly padded.");
/*     */     }
/* 186 */     int iLen = in.length;
/* 187 */     if (iLen % 4 != 0) {
/* 188 */       throw new IllegalArgumentException(
/* 189 */         "Length of Base64 encoded input string is not a multiple of 4.");
/*     */     }
/* 191 */     while ((iLen > 0) && (in[(iLen - 1)] == '='))
/* 192 */       iLen--;
/* 193 */     int oLen = iLen * 3 / 4;
/* 194 */     byte[] out = new byte[oLen];
/* 195 */     int ip = 0;
/* 196 */     int op = 0;
/* 197 */     while (ip < iLen) {
/* 198 */       int i0 = in[(ip++)];
/* 199 */       int i1 = in[(ip++)];
/* 200 */       int i2 = ip < iLen ? in[(ip++)] : 65;
/* 201 */       int i3 = ip < iLen ? in[(ip++)] : 65;
/* 202 */       if ((i0 > 127) || (i1 > 127) || (i2 > 127) || (i3 > 127))
/* 203 */         throw new IllegalArgumentException("Illegal character in Base64 encoded data.");
/* 204 */       int b0 = map2[i0];
/* 205 */       int b1 = map2[i1];
/* 206 */       int b2 = map2[i2];
/* 207 */       int b3 = map2[i3];
/* 208 */       if ((b0 < 0) || (b1 < 0) || (b2 < 0) || (b3 < 0))
/* 209 */         throw new IllegalArgumentException("Illegal character in Base64 encoded data.");
/* 210 */       int o0 = b0 << 2 | b1 >>> 4;
/* 211 */       int o1 = (b1 & 0xF) << 4 | b2 >>> 2;
/* 212 */       int o2 = (b2 & 0x3) << 6 | b3;
/* 213 */       out[(op++)] = ((byte)o0);
/* 214 */       if (op < oLen)
/* 215 */         out[(op++)] = ((byte)o1);
/* 216 */       if (op < oLen)
/* 217 */         out[(op++)] = ((byte)o2);
/*     */     }
/* 219 */     return out;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\utilidades\Base64Coder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */