/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xmldsig.AbstractXDsigElement;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractXADESElement
/*     */   extends AbstractXDsigElement
/*     */ {
/*     */   protected XAdESSchemas schema;
/*     */   protected String namespaceXAdES;
/*     */   
/*     */   protected AbstractXADESElement(XAdESSchemas schema)
/*     */   {
/*  36 */     this.schema = schema;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public XAdESSchemas getSchema()
/*     */   {
/*  43 */     return this.schema;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSchema(XAdESSchemas schema)
/*     */   {
/*  51 */     this.schema = schema;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Element createElement(Document doc, String namespaceXAdES)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  60 */     setNamespaceXAdES(namespaceXAdES);
/*  61 */     return createElement(doc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Element createElement(Document doc, String namespaceXDsig, String namespaceXAdES)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  74 */     setNamespaceXAdES(namespaceXAdES);
/*  75 */     return super.createElement(doc, namespaceXDsig);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addContent(Element element, String namespaceXAdES)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  84 */     setNamespaceXAdES(namespaceXAdES);
/*  85 */     addContent(element);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addContent(Element element, String namespaceXAdES, String namespaceXDsig)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  97 */     setNamespaceXAdES(namespaceXAdES);
/*  98 */     super.addContent(element, namespaceXDsig);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getNamespaceXAdES()
/*     */   {
/* 105 */     return this.namespaceXAdES;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNamespaceXAdES(String namespaceXAdES)
/*     */   {
/* 113 */     this.namespaceXAdES = namespaceXAdES;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\AbstractXADESElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */