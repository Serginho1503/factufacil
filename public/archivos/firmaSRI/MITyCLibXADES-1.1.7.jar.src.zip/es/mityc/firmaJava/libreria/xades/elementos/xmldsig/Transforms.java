/*    */ package es.mityc.firmaJava.libreria.xades.elementos.xmldsig;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*    */ import java.util.ArrayList;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Transforms
/*    */   extends TransformsType
/*    */ {
/*    */   public Transforms() {}
/*    */   
/*    */   public Transforms(ArrayList<Transform> list)
/*    */   {
/* 43 */     super(list);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void load(Element element)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 51 */     checkElementName(element, "http://www.w3.org/2000/09/xmldsig#", "Transforms");
/* 52 */     super.load(element);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isThisNode(Node node)
/*    */   {
/* 60 */     return isElementName(nodeToElement(node), "http://www.w3.org/2000/09/xmldsig#", "Transforms");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Element createElement(Document doc, String namespaceXDsig)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 68 */     return super.createElement(doc, namespaceXDsig);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected Element createElement(Document doc)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 76 */     Element res = doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", this.namespaceXDsig + ":" + "Transforms");
/* 77 */     super.addContent(res, this.namespaceXDsig);
/* 78 */     return res;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xmldsig\Transforms.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */