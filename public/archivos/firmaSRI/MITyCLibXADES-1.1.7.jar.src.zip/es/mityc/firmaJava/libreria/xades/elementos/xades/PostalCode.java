/*    */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PostalCode
/*    */   extends AbstractXadesStringElement
/*    */ {
/*    */   public PostalCode(XAdESSchemas schema, String data)
/*    */   {
/* 30 */     super(schema, "PostalCode", data);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PostalCode(XAdESSchemas schema)
/*    */   {
/* 39 */     super(schema, "PostalCode");
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\PostalCode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */