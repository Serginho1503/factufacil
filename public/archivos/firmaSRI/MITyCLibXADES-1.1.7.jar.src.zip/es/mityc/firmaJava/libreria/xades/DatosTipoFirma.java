/*    */ package es.mityc.firmaJava.libreria.xades;
/*    */ 
/*    */ import es.mityc.javasign.EnumFormatoFirma;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DatosTipoFirma
/*    */ {
/* 26 */   private EnumFormatoFirma tipoXAdES = null;
/* 27 */   private boolean esXAdES_EPES = false;
/* 28 */   private boolean esXAdES_A = false;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public DatosTipoFirma() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public DatosTipoFirma(EnumFormatoFirma tipoXAdES, boolean esXAdES_EPES, boolean esXAdES_A)
/*    */   {
/* 43 */     this.tipoXAdES = tipoXAdES;
/* 44 */     this.esXAdES_EPES = esXAdES_EPES;
/* 45 */     this.esXAdES_A = esXAdES_A;
/*    */   }
/*    */   
/*    */   public EnumFormatoFirma getTipoXAdES() {
/* 49 */     return this.tipoXAdES;
/*    */   }
/*    */   
/* 52 */   public void setTipoXAdES(EnumFormatoFirma tipoXAdES) { this.tipoXAdES = tipoXAdES; }
/*    */   
/*    */   public boolean esXAdES_EPES() {
/* 55 */     return this.esXAdES_EPES;
/*    */   }
/*    */   
/* 58 */   public void setEsXAdES_EPES(boolean esXAdES_EPES) { this.esXAdES_EPES = esXAdES_EPES; }
/*    */   
/*    */   public boolean esXAdES_A() {
/* 61 */     return this.esXAdES_A;
/*    */   }
/*    */   
/* 64 */   public void setEsXAdES_A(boolean esXAdES_A) { this.esXAdES_A = esXAdES_A; }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\DatosTipoFirma.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */