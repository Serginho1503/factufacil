/*    */ package es.mityc.firmaJava.libreria.xades;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum XAdESSchemas
/*    */   implements Comparable<XAdESSchemas>
/*    */ {
/* 26 */   XAdES_111("1.1.1", "http://uri.etsi.org/01903/v1.1.1#"), 
/* 27 */   XAdES_122("1.2.2", "http://uri.etsi.org/01903/v1.2.2#"), 
/* 28 */   XAdES_132("1.3.2", "http://uri.etsi.org/01903/v1.3.2#"), 
/* 29 */   XAdES_141("1.4.1", "http://uri.etsi.org/01903/v1.4.1#"), 
/* 30 */   XAdES_142("1.4.2", "http://uri.etsi.org/01903/v1.4.2#"), 
/* 31 */   XMLDSIG("xmldsig", "http://www.w3.org/2000/09/xmldsig#"), 
/* 32 */   OTHER("", "");
/*    */   
/*    */   private String name;
/*    */   private String uri;
/*    */   
/*    */   private XAdESSchemas(String name, String uri) {
/* 38 */     this.name = name;
/* 39 */     this.uri = uri;
/*    */   }
/*    */   
/*    */   public String getSchemaVersion() {
/* 43 */     return this.name;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 48 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getSchemaUri() {
/* 52 */     return this.uri;
/*    */   }
/*    */   
/*    */   public static XAdESSchemas getXAdESSchema(String esquemaUri) {
/* 56 */     XAdESSchemas resultado = null;
/* 57 */     if (esquemaUri != null) {
/* 58 */       if (XAdES_111.uri.equals(esquemaUri)) {
/* 59 */         resultado = XAdES_111;
/* 60 */       } else if (XAdES_122.uri.equals(esquemaUri)) {
/* 61 */         resultado = XAdES_122;
/* 62 */       } else if (XAdES_132.uri.equals(esquemaUri)) {
/* 63 */         resultado = XAdES_132;
/* 64 */       } else if (XMLDSIG.uri.equals(esquemaUri)) {
/* 65 */         resultado = XMLDSIG;
/*    */       } else {
/* 67 */         resultado = OTHER;
/*    */       }
/*    */     }
/* 70 */     return resultado;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\XAdESSchemas.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */