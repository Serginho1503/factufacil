/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.math.BigInteger;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CertIDType
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private CertDigest digest;
/*     */   private IssuerSerial issuerSerial;
/*     */   
/*     */   public CertIDType(XAdESSchemas schema)
/*     */   {
/*  35 */     super(schema);
/*     */   }
/*     */   
/*     */   public CertIDType(XAdESSchemas schema, CertDigest digest, IssuerSerial issuerSerial) {
/*  39 */     super(schema);
/*  40 */     this.digest = digest;
/*  41 */     this.issuerSerial = issuerSerial;
/*     */   }
/*     */   
/*     */   public CertIDType(XAdESSchemas schema, String digestMethod, String digestValue, String issuerName, BigInteger serialNumber) {
/*  45 */     super(schema);
/*  46 */     this.digest = new CertDigest(schema, digestMethod, digestValue);
/*  47 */     this.issuerSerial = new IssuerSerial(schema, issuerName, serialNumber);
/*     */   }
/*     */   
/*     */   public CertIDType(XAdESSchemas schema, String digestMethod, byte[] digestValue, String issuerName, BigInteger serialNumber) throws InvalidInfoNodeException {
/*  51 */     super(schema);
/*  52 */     this.digest = new CertDigest(schema, digestMethod, digestValue);
/*  53 */     this.issuerSerial = new IssuerSerial(schema, issuerName, serialNumber);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  61 */     if ((obj instanceof CertIDType)) {
/*  62 */       CertIDType cit = (CertIDType)obj;
/*  63 */       if ((this.digest == null) || (this.issuerSerial == null)) {
/*  64 */         return false;
/*     */       }
/*  66 */       if (!this.digest.equals(cit.digest))
/*  67 */         return false;
/*  68 */       if (this.issuerSerial.equals(cit.issuerSerial))
/*  69 */         return true;
/*     */     }
/*  71 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  79 */     Node node = getFirstNonvoidNode(element);
/*     */     
/*  81 */     CertDigest digest = new CertDigest(getSchema());
/*  82 */     if (!digest.isThisNode(node)) {
/*  83 */       throw new InvalidInfoNodeException("Se esperaba nodo CertDigest en CertIDType");
/*     */     }
/*  85 */     digest.load((Element)node);
/*     */     
/*  87 */     node = getNextNonvoidNode(node);
/*  88 */     IssuerSerial issuerSerial = new IssuerSerial(getSchema());
/*  89 */     if (!issuerSerial.isThisNode(node)) {
/*  90 */       throw new InvalidInfoNodeException("Se esperaba nodo IssuerSerial en CertIDType");
/*     */     }
/*  92 */     issuerSerial.load((Element)node);
/*     */     
/*  94 */     this.digest = digest;
/*  95 */     this.issuerSerial = issuerSerial;
/*     */   }
/*     */   
/*     */   public void setDigest(CertDigest digest) {
/*  99 */     this.digest = digest;
/*     */   }
/*     */   
/*     */   public void setDigest(String digestMethod, String digestValue) {
/* 103 */     this.digest = new CertDigest(this.schema, digestMethod, digestValue);
/*     */   }
/*     */   
/*     */   public void setDigest(String digestMethod, byte[] digestValue) throws InvalidInfoNodeException {
/* 107 */     this.digest = new CertDigest(this.schema, digestMethod, digestValue);
/*     */   }
/*     */   
/*     */   public CertDigest getCertDigest() {
/* 111 */     return this.digest;
/*     */   }
/*     */   
/*     */   public void setIssuerSerial(String issuerName, BigInteger serialNumber) {
/* 115 */     this.issuerSerial = new IssuerSerial(this.schema, issuerName, serialNumber);
/*     */   }
/*     */   
/*     */   public void setIssuerSerial(IssuerSerial issuerSerial) {
/* 119 */     this.issuerSerial = issuerSerial;
/*     */   }
/*     */   
/*     */   public IssuerSerial getIssuerSerial() {
/* 123 */     return this.issuerSerial;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\CertIDType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */