/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.net.URI;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjectIdentifierType
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private Identifier identifier;
/*     */   private Description description;
/*     */   private DocumentationReferences references;
/*     */   
/*     */   public ObjectIdentifierType(XAdESSchemas schema, URI uri, String description)
/*     */   {
/*  36 */     super(schema);
/*  37 */     this.identifier = new Identifier(schema, uri);
/*  38 */     if (description != null) {
/*  39 */       this.description = new Description(schema, description);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectIdentifierType(XAdESSchemas schema)
/*     */   {
/*  48 */     super(schema);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  56 */     if ((obj instanceof ObjectIdentifierType)) {
/*  57 */       ObjectIdentifierType oit = (ObjectIdentifierType)obj;
/*  58 */       if (this.identifier.equals(oit.identifier))
/*  59 */         return true;
/*     */     }
/*  61 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  69 */     Node node = getFirstNonvoidNode(element);
/*  70 */     if ((node == null) || (node.getNodeType() != 1)) {
/*  71 */       throw new InvalidInfoNodeException("Se esperaba elemento como hijo de ObjectIdentifierType");
/*     */     }
/*  73 */     Identifier identifier = new Identifier(this.schema);
/*  74 */     identifier.load((Element)node);
/*     */     
/*     */ 
/*  77 */     node = getNextNonvoidNode(node);
/*  78 */     Description description = null;
/*  79 */     if (node != null) {
/*  80 */       if (node.getNodeType() != 1)
/*  81 */         throw new InvalidInfoNodeException("Se esperaba elemento como hijo de ObjectIdentifierType");
/*  82 */       description = new Description(this.schema);
/*  83 */       if (description.isThisNode(node)) {
/*  84 */         description.load((Element)node);
/*  85 */         node = getNextNonvoidNode(node);
/*     */       }
/*     */     }
/*     */     
/*  89 */     DocumentationReferences references = null;
/*  90 */     if (node != null) {
/*  91 */       if (node.getNodeType() != 1)
/*  92 */         throw new InvalidInfoNodeException("Se esperaba elemento como hijo de ObjectIdentifierType");
/*  93 */       references = new DocumentationReferences(this.schema);
/*  94 */       if (references.isThisNode(node)) {
/*  95 */         references.load((Element)node);
/*     */       }
/*     */     }
/*     */     
/*  99 */     this.identifier = identifier;
/* 100 */     this.description = description;
/* 101 */     this.references = references;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Identifier getIdentifier()
/*     */   {
/* 108 */     return this.identifier;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setIdentifier(Identifier identifier)
/*     */   {
/* 115 */     this.identifier = identifier;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Description getDescription()
/*     */   {
/* 122 */     return this.description;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDescription(Description description)
/*     */   {
/* 129 */     this.description = description;
/*     */   }
/*     */   
/*     */   public DocumentationReferences getReferences() {
/* 133 */     return this.references;
/*     */   }
/*     */   
/*     */   public void setReferences(DocumentationReferences references) {
/* 137 */     this.references = references;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addContent(Element element, String namespaceXAdES)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 145 */     super.addContent(element, namespaceXAdES);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void addContent(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 153 */     if (this.identifier == null)
/* 154 */       throw new InvalidInfoNodeException("Información insuficiente para escribir nodo ObjectIdentifierType");
/* 155 */     element.appendChild(this.identifier.createElement(element.getOwnerDocument(), this.namespaceXAdES));
/* 156 */     if (this.description != null) {
/* 157 */       element.appendChild(this.description.createElement(element.getOwnerDocument(), this.namespaceXAdES));
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\ObjectIdentifierType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */