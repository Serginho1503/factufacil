/*    */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*    */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoticeRef
/*    */   extends NoticeReferenceType
/*    */ {
/*    */   public NoticeRef(XAdESSchemas schema)
/*    */   {
/* 35 */     super(schema);
/*    */   }
/*    */   
/*    */   public NoticeRef(XAdESSchemas schema, String organization, int[] numbers) {
/* 39 */     super(schema, organization, numbers);
/*    */   }
/*    */   
/*    */   public void load(Element element)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 45 */     checkElementName(element, this.schema.getSchemaUri(), "NoticeRef");
/* 46 */     super.load(element);
/*    */   }
/*    */   
/*    */   public boolean isThisNode(Node node)
/*    */   {
/* 51 */     return isElementName(nodeToElement(node), this.schema.getSchemaUri(), "NoticeRef");
/*    */   }
/*    */   
/*    */   public Element createElement(Document doc, String namespaceXAdES) throws InvalidInfoNodeException
/*    */   {
/* 56 */     return super.createElement(doc, namespaceXAdES);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected Element createElement(Document doc)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 64 */     Element res = doc.createElementNS(this.schema.getSchemaUri(), this.namespaceXAdES + ":" + "NoticeRef");
/* 65 */     super.addContent(res, this.namespaceXAdES);
/* 66 */     return res;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\NoticeRef.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */