/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.XMLDataIntegerType;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.math.BigInteger;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractXadesIntegerElement
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private XMLDataIntegerType data;
/*     */   private String nameElement;
/*     */   
/*     */   public AbstractXadesIntegerElement(XAdESSchemas schema, String nameElement, BigInteger data)
/*     */   {
/*  36 */     super(schema);
/*  37 */     this.nameElement = nameElement;
/*  38 */     this.data = new XMLDataIntegerType(data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractXadesIntegerElement(XAdESSchemas schema, String nameElement)
/*     */   {
/*  47 */     super(schema);
/*  48 */     this.nameElement = nameElement;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Element createElement(Document doc)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  56 */     if (this.data == null)
/*  57 */       throw new InvalidInfoNodeException("Información insuficiente para escribir elemento " + this.nameElement);
/*  58 */     Element res = doc.createElementNS(this.schema.getSchemaUri(), this.namespaceXAdES + ":" + this.nameElement);
/*  59 */     this.data.addContent(res);
/*  60 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Element createElement(Document doc, String namespaceXAdES)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  68 */     return super.createElement(doc, namespaceXAdES);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  76 */     if ((obj instanceof AbstractXadesIntegerElement)) {
/*  77 */       AbstractXadesIntegerElement desc = (AbstractXadesIntegerElement)obj;
/*  78 */       if ((this.nameElement.equals(desc.nameElement)) && (this.data.equals(desc.data))) {
/*  79 */         return true;
/*     */       }
/*     */     } else {
/*  82 */       return this.data.equals(obj); }
/*  83 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  91 */     checkElementName(element, this.schema.getSchemaUri(), this.nameElement);
/*  92 */     this.data = new XMLDataIntegerType(null);
/*  93 */     this.data.load(element);
/*     */   }
/*     */   
/*     */   public void setValue(BigInteger value) {
/*  97 */     if (this.data == null) {
/*  98 */       this.data = new XMLDataIntegerType(value);
/*     */     } else
/* 100 */       this.data.setValue(value);
/*     */   }
/*     */   
/*     */   public BigInteger getValue() {
/* 104 */     if (this.data != null)
/* 105 */       return this.data.getValue();
/* 106 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isThisNode(Node node)
/*     */   {
/* 114 */     return isElementName(nodeToElement(node), this.schema.getSchemaUri(), this.nameElement);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\AbstractXadesIntegerElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */