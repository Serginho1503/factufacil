/*     */ package es.mityc.firmaJava.libreria.xades;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.signature.ObjectContainer;
/*     */ import adsi.org.apache.xml.security.signature.Reference;
/*     */ import adsi.org.apache.xml.security.signature.SignedInfo;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignature;
/*     */ import es.mityc.firmaJava.libreria.utilidades.I18n;
/*     */ import es.mityc.firmaJava.libreria.utilidades.NombreNodo;
/*     */ import es.mityc.firmaJava.libreria.utilidades.UtilidadTratarNodo;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.BadFormedSignatureException;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.FirmaXMLError;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UtilidadXadesA
/*     */ {
/*  47 */   private static Log log = LogFactory.getLog(UtilidadXadesA.class);
/*  48 */   private static ArrayList<String> LISTA_ELEMENTOS_UNSIGNED_FOR_DIGEST = new ArrayList();
/*     */   
/*     */   static {
/*  51 */     LISTA_ELEMENTOS_UNSIGNED_FOR_DIGEST.add("SignatureTimeStamp");
/*  52 */     LISTA_ELEMENTOS_UNSIGNED_FOR_DIGEST.add("CounterSignature");
/*  53 */     LISTA_ELEMENTOS_UNSIGNED_FOR_DIGEST.add("CompleteCertificateRefs");
/*  54 */     LISTA_ELEMENTOS_UNSIGNED_FOR_DIGEST.add("CompleteRevocationRefs");
/*  55 */     LISTA_ELEMENTOS_UNSIGNED_FOR_DIGEST.add("AttributeCertificateRefs");
/*  56 */     LISTA_ELEMENTOS_UNSIGNED_FOR_DIGEST.add("AttributeRevocationRefs");
/*  57 */     LISTA_ELEMENTOS_UNSIGNED_FOR_DIGEST.add("SigAndRefsTimeStamp");
/*  58 */     LISTA_ELEMENTOS_UNSIGNED_FOR_DIGEST.add("RefsOnlyTimeStamp");
/*  59 */     LISTA_ELEMENTOS_UNSIGNED_FOR_DIGEST.add("CertificateValues");
/*  60 */     LISTA_ELEMENTOS_UNSIGNED_FOR_DIGEST.add("RevocationValues");
/*  61 */     LISTA_ELEMENTOS_UNSIGNED_FOR_DIGEST.add("AttrAuthoritiesCertValues");
/*  62 */     LISTA_ELEMENTOS_UNSIGNED_FOR_DIGEST.add("AttributeRevocationValues");
/*  63 */     LISTA_ELEMENTOS_UNSIGNED_FOR_DIGEST.add("ArchiveTimeStamp");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] obtenerListadoXadesA(String esquemaURI, XMLSignature xmlSig, Element selloA)
/*     */     throws BadFormedSignatureException, FirmaXMLError, XMLSecurityException, IOException
/*     */   {
/* 106 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*     */     
/* 108 */     SignedInfo si = xmlSig.getSignedInfo();
/* 109 */     Element firma = xmlSig.getElement();
/* 110 */     CanonicalizationEnum cannon = null;
/*     */     
/* 112 */     NodeList nodosCanonicalizationMethod = selloA.getElementsByTagNameNS("http://www.w3.org/2000/09/xmldsig#", 
/* 113 */       "CanonicalizationMethod");
/* 114 */     int numNodosCanonicalization = nodosCanonicalizationMethod.getLength();
/* 115 */     if (numNodosCanonicalization > 0) {
/* 116 */       Element nodoCanonicalizationMethod = (Element)nodosCanonicalizationMethod.item(0);
/* 117 */       String meth = nodoCanonicalizationMethod.getAttribute("Algorithm");
/* 118 */       cannon = CanonicalizationEnum.getCanonicalization(meth);
/* 119 */       if (cannon.equals(CanonicalizationEnum.UNKNOWN)) {
/* 120 */         cannon = CanonicalizationEnum.C14N_OMIT_COMMENTS;
/*     */       }
/*     */     }
/*     */     
/* 124 */     if (cannon == null) {
/* 125 */       cannon = CanonicalizationEnum.getCanonicalization(si.getCanonicalizationMethodURI());
/* 126 */       if ((cannon == null) || (CanonicalizationEnum.UNKNOWN.equals(cannon))) {
/* 127 */         log.warn("No se reconoce el algoritmo de canonicalización " + si.getCanonicalizationMethodURI() + ". Se toma el valor por defecto.");
/* 128 */         cannon = CanonicalizationEnum.C14N_OMIT_COMMENTS;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 133 */     ArrayList<Element> referenceNodes = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 134 */       new NombreNodo("http://www.w3.org/2000/09/xmldsig#", "Reference"));
/* 135 */     if (referenceNodes.size() == 0) {
/* 136 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + " " + 
/* 137 */         "Reference" + " " + I18n.getResource("libreriaxades.firmaxml.error37") + 
/* 138 */         " " + referenceNodes.size());
/*     */     }
/* 140 */     Reference referenceNode = null;
/* 141 */     for (int i = 0; i < si.getLength(); i++) {
/* 142 */       referenceNode = si.item(i);
/* 143 */       if (referenceNode != null) {
/* 144 */         Element reference = (Element)referenceNodes.get(i);
/* 145 */         String referenceUri = reference.getAttribute("URI");
/* 146 */         if ((referenceUri != "") && 
/* 147 */           (!referenceUri.startsWith("#"))) {
/* 148 */           File firmado = new File(referenceUri);
/* 149 */           FileInputStream fis = null;
/*     */           try {
/* 151 */             fis = new FileInputStream(firmado);
/*     */           } catch (FileNotFoundException e1) {
/* 153 */             throw new IOException(I18n.getResource("libreriaxades.validarfirmaxml.error58"));
/*     */           }
/* 155 */           byte[] entrada = null;
/* 156 */           fis.read(entrada);
/* 157 */           baos.write(entrada);
/* 158 */         } else if (referenceUri != "") {
/* 159 */           Element nodo = UtilidadTratarNodo.getElementById(xmlSig.getDocument(), referenceUri.substring(1));
/* 160 */           if (nodo != null) {
/* 161 */             baos.write(UtilidadTratarNodo.obtenerByte(
/* 162 */               nodo, 
/* 163 */               obtenerCanonicalization(nodo, cannon)));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 171 */     ArrayList<Element> signedInfoNodes = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 172 */       new NombreNodo("http://www.w3.org/2000/09/xmldsig#", "SignedInfo"));
/* 173 */     if (signedInfoNodes.size() != 1)
/*     */     {
/* 175 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + " " + 
/* 176 */         "SignedInfo" + " " + I18n.getResource("libreriaxades.firmaxml.error37") + 
/* 177 */         " " + signedInfoNodes.size());
/*     */     }
/* 179 */     baos.write(si.getCanonicalizedOctetStream());
/*     */     
/*     */ 
/* 182 */     Element signatureValueNode = null;
/* 183 */     ArrayList<Element> signatureValueNodes = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 184 */       new NombreNodo("http://www.w3.org/2000/09/xmldsig#", "SignatureValue"));
/* 185 */     if (signatureValueNodes.size() == 1) {
/* 186 */       signatureValueNode = (Element)signatureValueNodes.get(0);
/*     */     }
/*     */     else {
/* 189 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + " " + 
/* 190 */         "SignatureValue" + " " + I18n.getResource("libreriaxades.firmaxml.error37") + 
/* 191 */         " " + signatureValueNodes.size());
/*     */     }
/* 193 */     baos.write(UtilidadTratarNodo.obtenerByte(
/* 194 */       signatureValueNode, 
/* 195 */       obtenerCanonicalization(signatureValueNode, cannon)));
/*     */     
/*     */ 
/*     */ 
/* 199 */     Element keyInfoNode = null;
/* 200 */     ArrayList<Element> keyInfoNodes = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 201 */       new NombreNodo("http://www.w3.org/2000/09/xmldsig#", "KeyInfo"));
/* 202 */     if (keyInfoNodes.size() == 1) {
/* 203 */       keyInfoNode = (Element)keyInfoNodes.get(0);
/*     */     }
/*     */     else {
/* 206 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + " " + 
/* 207 */         "KeyInfo" + " " + I18n.getResource("libreriaxades.firmaxml.error37") + 
/* 208 */         " " + keyInfoNodes.size());
/*     */     }
/* 210 */     baos.write(UtilidadTratarNodo.obtenerByte(
/* 211 */       keyInfoNode, 
/* 212 */       obtenerCanonicalization(keyInfoNode, cannon)));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 219 */     Element unsignedSignaturePropertiesNode = null;
/* 220 */     ArrayList<Element> unsignedSignaturePropertiesNodes = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 221 */       new NombreNodo(esquemaURI, "UnsignedSignatureProperties"));
/* 222 */     if (unsignedSignaturePropertiesNodes.size() == 1) {
/* 223 */       unsignedSignaturePropertiesNode = (Element)unsignedSignaturePropertiesNodes.get(0);
/*     */     }
/*     */     else {
/* 226 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + " " + 
/* 227 */         "UnsignedSignatureProperties" + " " + I18n.getResource("libreriaxades.firmaxml.error37") + 
/* 228 */         " " + unsignedSignaturePropertiesNodes.size());
/*     */     }
/* 230 */     validaUnsignedProperties(unsignedSignaturePropertiesNode, esquemaURI);
/*     */     
/* 232 */     NodeList unsignedPropertiesElements = unsignedSignaturePropertiesNode.getChildNodes();
/* 233 */     int unsignedLength = unsignedPropertiesElements.getLength();
/* 234 */     for (int i = 0; i < unsignedLength; i++) {
/* 235 */       Node currentUnsignedProperty = unsignedPropertiesElements.item(i);
/*     */       
/* 237 */       if ((!UtilidadTratarNodo.obtenerNombreNodo(currentUnsignedProperty).equalsIgnoreCase("ArchiveTimeStamp")) || 
/* 238 */         (selloA == null) || (!selloA.equals(currentUnsignedProperty)))
/*     */       {
/*     */ 
/* 241 */         currentUnsignedProperty = procesarUnsignedProperty(currentUnsignedProperty);
/* 242 */         if (currentUnsignedProperty != null) {
/* 243 */           baos.write(UtilidadTratarNodo.obtenerByte((Element)currentUnsignedProperty, obtenerCanonicalization((Element)currentUnsignedProperty, cannon)));
/*     */         }
/*     */       }
/*     */     }
/* 247 */     ObjectContainer object = null;
/* 248 */     Element reference = null;
/* 249 */     String objectId = null;
/* 250 */     String referenceUri = null;
/* 251 */     for (int i = 0; i < xmlSig.getObjectLength(); i++) {
/* 252 */       object = xmlSig.getObjectItem(i);
/* 253 */       objectId = object.getId();
/* 254 */       boolean incluir = true;
/* 255 */       for (int j = 0; j < referenceNodes.size(); j++) {
/* 256 */         reference = (Element)referenceNodes.get(j);
/* 257 */         referenceUri = reference.getAttribute("URI");
/* 258 */         if ((referenceUri != null) && (referenceUri.length() > 0) && (referenceUri.substring(1).equals(objectId))) {
/* 259 */           incluir = false;
/* 260 */           break;
/*     */         }
/*     */       }
/*     */       
/* 264 */       ArrayList<Element> qualifyingProp = UtilidadTratarNodo.obtenerNodos(firma, 2, new NombreNodo(esquemaURI, "QualifyingProperties"));
/* 265 */       for (int j = 0; (j < qualifyingProp.size()) && (incluir); j++) {
/* 266 */         ArrayList<Element> sp = UtilidadTratarNodo.obtenerNodos(object.getElement(), 
/* 267 */           2, 
/* 268 */           new NombreNodo(esquemaURI, ((Element)qualifyingProp.get(0)).getLocalName()));
/* 269 */         if ((sp != null) && (sp.size() > 0) && (((Element)sp.get(0)).equals(qualifyingProp.get(0)))) {
/* 270 */           incluir = false;
/*     */         }
/*     */       }
/* 273 */       if (incluir) {
/* 274 */         baos.write(UtilidadTratarNodo.obtenerByte(
/* 275 */           object.getElement(), 
/* 276 */           obtenerCanonicalization(object.getElement(), cannon)));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 281 */     return baos.toByteArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Node procesarUnsignedProperty(Node currentUnsignedProperty)
/*     */   {
/* 303 */     String nombreNodo = UtilidadTratarNodo.obtenerNombreNodo(currentUnsignedProperty);
/* 304 */     if (LISTA_ELEMENTOS_UNSIGNED_FOR_DIGEST.contains(nombreNodo)) {
/* 305 */       return currentUnsignedProperty;
/*     */     }
/*     */     
/* 308 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean validaUnsignedProperties(Element unsignedSignaturePropertiesNode, String esquemaURI)
/*     */     throws BadFormedSignatureException, FirmaXMLError
/*     */   {
/* 328 */     ArrayList<Element> completeCertificateRefsNodes = UtilidadTratarNodo.obtenerNodos(unsignedSignaturePropertiesNode, 5, new NombreNodo(esquemaURI, "CompleteCertificateRefs"));
/* 329 */     int numCompleteCertificateRefs = completeCertificateRefsNodes.size();
/* 330 */     if (numCompleteCertificateRefs > 1) {
/* 331 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 332 */         " " + "CompleteCertificateRefs" + " " + 
/* 333 */         I18n.getResource("libreriaxades.firmaxml.error38") + " " + 
/* 334 */         numCompleteCertificateRefs);
/*     */     }
/* 336 */     int numCompleteCertificateRefsChilds = 0;
/*     */     
/* 338 */     if (numCompleteCertificateRefs == 1) {
/* 339 */       numCompleteCertificateRefsChilds = ((Element)completeCertificateRefsNodes.get(0)).getChildNodes().getLength();
/*     */     }
/*     */     
/* 342 */     ArrayList<Element> completeRevocationRefsNodes = UtilidadTratarNodo.obtenerNodos(unsignedSignaturePropertiesNode, 5, new NombreNodo(esquemaURI, "CompleteRevocationRefs"));
/* 343 */     int numCompleteRevocationRefs = completeRevocationRefsNodes.size();
/* 344 */     if (numCompleteRevocationRefs > 1) {
/* 345 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 346 */         " " + "CompleteRevocationRefs" + " " + 
/* 347 */         I18n.getResource("libreriaxades.firmaxml.error38") + " " + 
/* 348 */         numCompleteRevocationRefs);
/*     */     }
/* 350 */     int numCompleteRevocationRefsChilds = 0;
/*     */     
/* 352 */     if (numCompleteRevocationRefs == 1) {
/* 353 */       numCompleteRevocationRefsChilds = ((Element)completeRevocationRefsNodes.get(0)).getChildNodes().getLength();
/*     */     }
/*     */     
/* 356 */     int numAttributeCertificateRefs = UtilidadTratarNodo.obtenerNodos(unsignedSignaturePropertiesNode, 5, new NombreNodo(esquemaURI, "AttributeCertificateRefs")).size();
/* 357 */     if (numAttributeCertificateRefs > 1) {
/* 358 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 359 */         " " + "AttributeCertificateRefs" + " " + 
/* 360 */         I18n.getResource("libreriaxades.firmaxml.error38") + " " + 
/* 361 */         numAttributeCertificateRefs);
/*     */     }
/*     */     
/* 364 */     int numAttributeRevocationRefs = UtilidadTratarNodo.obtenerNodos(unsignedSignaturePropertiesNode, 5, new NombreNodo(esquemaURI, "AttributeRevocationRefs")).size();
/* 365 */     if (numAttributeRevocationRefs > 1) {
/* 366 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 367 */         " " + "AttributeRevocationRefs" + " " + 
/* 368 */         I18n.getResource("libreriaxades.firmaxml.error38") + " " + 
/* 369 */         numAttributeRevocationRefs);
/*     */     }
/*     */     
/* 372 */     int numSigAndRefsTimeStamp = UtilidadTratarNodo.obtenerNodos(unsignedSignaturePropertiesNode, 5, new NombreNodo(esquemaURI, "SigAndRefsTimeStamp")).size();
/* 373 */     if (numSigAndRefsTimeStamp > 1) {
/* 374 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 375 */         " " + "SigAndRefsTimeStamp" + " " + 
/* 376 */         I18n.getResource("libreriaxades.firmaxml.error38") + " " + 
/* 377 */         numSigAndRefsTimeStamp);
/*     */     }
/*     */     
/* 380 */     int numRefsOnlyTimeStamp = UtilidadTratarNodo.obtenerNodos(unsignedSignaturePropertiesNode, 5, new NombreNodo(esquemaURI, "RefsOnlyTimeStamp")).size();
/* 381 */     if (numRefsOnlyTimeStamp > 1) {
/* 382 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 383 */         " " + "RefsOnlyTimeStamp" + " " + 
/* 384 */         I18n.getResource("libreriaxades.firmaxml.error38") + " " + 
/* 385 */         numRefsOnlyTimeStamp);
/*     */     }
/*     */     
/* 388 */     ArrayList<Element> certificateValuesNodes = UtilidadTratarNodo.obtenerNodos(unsignedSignaturePropertiesNode, 5, new NombreNodo(esquemaURI, "CertificateValues"));
/* 389 */     int numCertificateValues = certificateValuesNodes.size();
/* 390 */     if (numCertificateValues != 1) {
/* 391 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 392 */         " " + "CertificateValues" + " " + 
/* 393 */         I18n.getResource("libreriaxades.firmaxml.error38") + " " + 
/* 394 */         numCertificateValues);
/*     */     }
/* 396 */     int numCertificateValuesChilds = ((Element)certificateValuesNodes.get(0)).getChildNodes().getLength();
/*     */     
/* 398 */     ArrayList<Element> revocationValuesNodes = UtilidadTratarNodo.obtenerNodos(unsignedSignaturePropertiesNode, 5, new NombreNodo(esquemaURI, "RevocationValues"));
/* 399 */     int numRevocationValues = revocationValuesNodes.size();
/* 400 */     if (numRevocationValues != 1) {
/* 401 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 402 */         " " + "RevocationValues" + " " + 
/* 403 */         I18n.getResource("libreriaxades.firmaxml.error38") + " " + 
/* 404 */         numRevocationValues);
/*     */     }
/* 406 */     int numRevocationValuesChilds = ((Element)revocationValuesNodes.get(0)).getChildNodes().getLength();
/*     */     
/*     */ 
/* 409 */     if ((numAttributeCertificateRefs > 0) && (numCertificateValuesChilds < numCompleteCertificateRefsChilds)) {
/* 410 */       int numAttrAuthoritiesCertValues = UtilidadTratarNodo.obtenerNodos(unsignedSignaturePropertiesNode, 5, new NombreNodo(esquemaURI, "AttrAuthoritiesCertValues")).size();
/* 411 */       if (numAttrAuthoritiesCertValues != 1) {
/* 412 */         throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 413 */           " " + "AttrAuthoritiesCertValues" + " " + 
/* 414 */           I18n.getResource("libreriaxades.firmaxml.error38") + " " + 
/* 415 */           numAttrAuthoritiesCertValues);
/*     */       }
/*     */     }
/*     */     
/* 419 */     if ((numAttributeCertificateRefs > 0) && (numRevocationValuesChilds < numCompleteRevocationRefsChilds)) {
/* 420 */       int numAttributeRevocationValues = UtilidadTratarNodo.obtenerNodos(unsignedSignaturePropertiesNode, 5, new NombreNodo(esquemaURI, "AttributeRevocationValues")).size();
/*     */       
/* 422 */       if (numAttributeRevocationValues != 1) {
/* 423 */         throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 424 */           " " + "AttributeRevocationValues" + " " + 
/* 425 */           I18n.getResource("libreriaxades.firmaxml.error38") + " " + 
/* 426 */           numAttributeRevocationValues);
/*     */       }
/*     */     }
/*     */     
/* 430 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static CanonicalizationEnum obtenerCanonicalization(Element nodo, CanonicalizationEnum porDefecto)
/*     */     throws FirmaXMLError
/*     */   {
/* 444 */     NodeList nodosCanonicalizationMethod = nodo.getElementsByTagNameNS("http://www.w3.org/2000/09/xmldsig#", 
/* 445 */       "CanonicalizationMethod");
/* 446 */     int numNodosCanonicalization = nodosCanonicalizationMethod.getLength();
/* 447 */     CanonicalizationEnum canonicalization = porDefecto;
/* 448 */     if (numNodosCanonicalization > 0) {
/* 449 */       Element nodoCanonicalizationMethod = (Element)nodosCanonicalizationMethod.item(0);
/* 450 */       String method = nodoCanonicalizationMethod.getAttribute("Algorithm");
/* 451 */       canonicalization = CanonicalizationEnum.getCanonicalization(method);
/* 452 */       if (canonicalization.equals(CanonicalizationEnum.UNKNOWN))
/*     */       {
/* 454 */         throw new FirmaXMLError(I18n.getResource("libreriaxades.validarfirmaxml.error103") + 
/* 455 */           " " + method);
/*     */       }
/*     */     }
/*     */     
/* 459 */     return canonicalization;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ArrayList<String> obtenerListadoIdsElementosXadesA(String esquemaURI, XMLSignature xmlSig, Element selloA)
/*     */     throws BadFormedSignatureException, FirmaXMLError, XMLSecurityException
/*     */   {
/* 477 */     ArrayList<String> input = new ArrayList();
/*     */     
/* 479 */     SignedInfo si = xmlSig.getSignedInfo();
/* 480 */     Element firma = xmlSig.getElement();
/*     */     
/*     */ 
/* 483 */     ArrayList<Element> referenceNodes = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 484 */       new NombreNodo("http://www.w3.org/2000/09/xmldsig#", "Reference"));
/* 485 */     if (referenceNodes.size() == 0) {
/* 486 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + " " + 
/* 487 */         "Reference" + " " + I18n.getResource("libreriaxades.firmaxml.error37") + 
/* 488 */         " " + referenceNodes.size());
/*     */     }
/* 490 */     Reference referenceNode = null;
/* 491 */     for (int i = 0; i < referenceNodes.size(); i++) {
/* 492 */       referenceNode = si.item(i);
/* 493 */       String idRef = referenceNode.getElement().getAttribute("Id");
/* 494 */       if (idRef == null)
/* 495 */         throw new BadFormedSignatureException("No se puede recuperar la Id del nodo Reference");
/* 496 */       input.add("#" + idRef);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 501 */     Element signedInfoNode = null;
/* 502 */     ArrayList<Element> signedInfoNodes = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 503 */       new NombreNodo("http://www.w3.org/2000/09/xmldsig#", "SignedInfo"));
/* 504 */     if (signedInfoNodes.size() == 1) {
/* 505 */       signedInfoNode = (Element)signedInfoNodes.get(0);
/*     */     }
/*     */     else {
/* 508 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + " " + 
/* 509 */         "SignedInfo" + " " + I18n.getResource("libreriaxades.firmaxml.error37") + 
/* 510 */         " " + signedInfoNodes.size());
/*     */     }
/* 512 */     String idSigInfo = signedInfoNode.getAttribute("Id");
/* 513 */     if (idSigInfo == null)
/* 514 */       throw new BadFormedSignatureException("No se puede recuperar la ID del nodo SignedInfo");
/* 515 */     input.add("#" + idSigInfo);
/*     */     
/*     */ 
/* 518 */     Element signatureValueNode = null;
/* 519 */     ArrayList<Element> signatureValueNodes = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 520 */       new NombreNodo("http://www.w3.org/2000/09/xmldsig#", "SignatureValue"));
/* 521 */     if (signatureValueNodes.size() == 1) {
/* 522 */       signatureValueNode = (Element)signatureValueNodes.get(0);
/*     */     }
/*     */     else {
/* 525 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + " " + 
/* 526 */         "SignatureValue" + " " + I18n.getResource("libreriaxades.firmaxml.error37") + 
/* 527 */         " " + signatureValueNodes.size());
/*     */     }
/* 529 */     String idSigValue = signatureValueNode.getAttribute("Id");
/* 530 */     if (idSigValue == null)
/* 531 */       throw new BadFormedSignatureException("No se puede recuperar la ID del nodo SignatureValue");
/* 532 */     input.add("#" + idSigValue);
/*     */     
/*     */ 
/* 535 */     Element keyInfoNode = null;
/* 536 */     ArrayList<Element> keyInfoNodes = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 537 */       new NombreNodo("http://www.w3.org/2000/09/xmldsig#", "KeyInfo"));
/* 538 */     if (keyInfoNodes.size() == 1) {
/* 539 */       keyInfoNode = (Element)keyInfoNodes.get(0);
/*     */     }
/*     */     else {
/* 542 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + " " + 
/* 543 */         "KeyInfo" + " " + I18n.getResource("libreriaxades.firmaxml.error37") + 
/* 544 */         " " + keyInfoNodes.size());
/*     */     }
/* 546 */     String idKeyInfo = keyInfoNode.getAttribute("Id");
/* 547 */     if (idKeyInfo == null)
/* 548 */       throw new BadFormedSignatureException("No se puede recuperar la ID del nodo KeyInfo");
/* 549 */     input.add("#" + idKeyInfo);
/*     */     
/*     */ 
/* 552 */     ArrayList<Element> nodosSigTimeStamp = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 553 */       new NombreNodo(esquemaURI, "SignatureTimeStamp"));
/*     */     
/* 555 */     if (nodosSigTimeStamp.size() < 1)
/*     */     {
/* 557 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error21"));
/*     */     }
/* 559 */     for (int i = 0; i < nodosSigTimeStamp.size(); i++) {
/* 560 */       String idSigTimeStamp = ((Element)nodosSigTimeStamp.get(i)).getAttribute("Id");
/* 561 */       if (idSigTimeStamp == null)
/* 562 */         throw new BadFormedSignatureException("No se puede recuperar la ID de un sello de tiempo XAdES-T");
/* 563 */       input.add("#" + idSigTimeStamp);
/*     */     }
/*     */     
/*     */ 
/* 567 */     ArrayList<Element> counterSignatureNodes = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 568 */       new NombreNodo(esquemaURI, "CounterSignature"));
/*     */     
/* 570 */     for (int i = 0; i < counterSignatureNodes.size(); i++) {
/* 571 */       String idCounterSig = ((Element)counterSignatureNodes.get(i)).getAttribute("Id");
/* 572 */       if (idCounterSig == null)
/* 573 */         throw new BadFormedSignatureException("No se puede recuperar la ID de una contrafirma");
/* 574 */       input.add("#" + idCounterSig);
/*     */     }
/*     */     
/*     */ 
/* 578 */     ArrayList<Element> completeCertificateRefsNodes = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 579 */       new NombreNodo(esquemaURI, "CompleteCertificateRefs"));
/*     */     
/* 581 */     if (completeCertificateRefsNodes.size() > 1)
/*     */     {
/* 583 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 584 */         " " + "CompleteCertificateRefs" + " " + 
/* 585 */         I18n.getResource("libreriaxades.firmaxml.error38") + " " + 
/* 586 */         completeCertificateRefsNodes.size());
/*     */     }
/* 588 */     for (int i = 0; i < completeCertificateRefsNodes.size(); i++) {
/* 589 */       String idCompCertRef = ((Element)completeCertificateRefsNodes.get(i)).getAttribute("Id");
/* 590 */       if (idCompCertRef == null)
/* 591 */         throw new BadFormedSignatureException("No se puede recuperar la ID del nodo CompleteCertificateRefs");
/* 592 */       input.add("#" + idCompCertRef);
/*     */     }
/*     */     
/*     */ 
/* 596 */     ArrayList<Element> completeRevocationRefsNodes = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 597 */       new NombreNodo(esquemaURI, "CompleteRevocationRefs"));
/*     */     
/* 599 */     if (completeRevocationRefsNodes.size() > 1)
/*     */     {
/* 601 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 602 */         " " + "CompleteRevocationRefs" + " " + 
/* 603 */         I18n.getResource("libreriaxades.firmaxml.error38") + " " + 
/* 604 */         completeRevocationRefsNodes.size());
/*     */     }
/* 606 */     for (int i = 0; i < completeRevocationRefsNodes.size(); i++) {
/* 607 */       String idCompRevRef = ((Element)completeRevocationRefsNodes.get(i)).getAttribute("Id");
/* 608 */       if (idCompRevRef == null)
/* 609 */         throw new BadFormedSignatureException("No se puede recuperar la ID del nodo CompleteRevocationRefs");
/* 610 */       input.add("#" + idCompRevRef);
/*     */     }
/*     */     
/*     */ 
/* 614 */     ArrayList<Element> attributeCertificateRefsNodes = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 615 */       new NombreNodo(esquemaURI, "AttributeCertificateRefs"));
/*     */     
/* 617 */     if (attributeCertificateRefsNodes.size() > 1)
/*     */     {
/* 619 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 620 */         " " + "AttributeCertificateRefs" + " " + 
/* 621 */         I18n.getResource("libreriaxades.firmaxml.error38") + " " + 
/* 622 */         attributeCertificateRefsNodes.size());
/*     */     }
/* 624 */     for (int i = 0; i < attributeCertificateRefsNodes.size(); i++) {
/* 625 */       String idAttrCertRef = ((Element)attributeCertificateRefsNodes.get(i)).getAttribute("Id");
/* 626 */       if (idAttrCertRef == null)
/* 627 */         throw new BadFormedSignatureException("No se puede recuperar la ID del nodo AttributeCertificateRefs");
/* 628 */       input.add("#" + idAttrCertRef);
/*     */     }
/*     */     
/*     */ 
/* 632 */     ArrayList<Element> attributeRevocationRefsNodes = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 633 */       new NombreNodo(esquemaURI, "AttributeRevocationRefs"));
/*     */     
/* 635 */     if (attributeRevocationRefsNodes.size() > 1)
/*     */     {
/* 637 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 638 */         " " + "AttributeRevocationRefs" + " " + 
/* 639 */         I18n.getResource("libreriaxades.firmaxml.error38") + " " + 
/* 640 */         attributeRevocationRefsNodes.size());
/*     */     }
/* 642 */     for (int i = 0; i < attributeRevocationRefsNodes.size(); i++) {
/* 643 */       String idAttrRevRef = ((Element)attributeRevocationRefsNodes.get(i)).getAttribute("Id");
/* 644 */       if (idAttrRevRef == null)
/* 645 */         throw new BadFormedSignatureException("No se puede recuperar la ID del nodo AttributeRevocationRefs");
/* 646 */       input.add("#" + idAttrRevRef);
/*     */     }
/*     */     
/*     */ 
/* 650 */     ArrayList<Element> sigAndRefsTimeStampNodes = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 651 */       new NombreNodo(esquemaURI, "SigAndRefsTimeStamp"));
/*     */     
/* 653 */     if (sigAndRefsTimeStampNodes.size() > 1)
/*     */     {
/* 655 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 656 */         " " + "AttributeRevocationRefs" + " " + 
/* 657 */         I18n.getResource("libreriaxades.firmaxml.error38") + " " + 
/* 658 */         sigAndRefsTimeStampNodes.size());
/*     */     }
/* 660 */     for (int i = 0; i < sigAndRefsTimeStampNodes.size(); i++) {
/* 661 */       String idSigAndRefs = ((Element)sigAndRefsTimeStampNodes.get(i)).getAttribute("Id");
/* 662 */       if (idSigAndRefs == null)
/* 663 */         throw new BadFormedSignatureException("No se puede recuperar la ID del nodo SigAndRefsTimeStamp");
/* 664 */       input.add("#" + idSigAndRefs);
/*     */     }
/*     */     
/*     */ 
/* 668 */     ArrayList<Element> refsOnlyTimeStampNodes = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 669 */       new NombreNodo(esquemaURI, "RefsOnlyTimeStamp"));
/*     */     
/* 671 */     if (refsOnlyTimeStampNodes.size() > 1)
/*     */     {
/* 673 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 674 */         " " + "AttributeRevocationRefs" + " " + 
/* 675 */         I18n.getResource("libreriaxades.firmaxml.error38") + " " + 
/* 676 */         refsOnlyTimeStampNodes.size());
/*     */     }
/* 678 */     for (int i = 0; i < refsOnlyTimeStampNodes.size(); i++) {
/* 679 */       String refsOnlyTimeStamp = ((Element)refsOnlyTimeStampNodes.get(i)).getAttribute("Id");
/* 680 */       if (refsOnlyTimeStamp == null)
/* 681 */         throw new BadFormedSignatureException("No se puede recuperar la ID del nodo RefsOnlyTimeStamp");
/* 682 */       input.add("#" + refsOnlyTimeStamp);
/*     */     }
/*     */     
/*     */ 
/* 686 */     ArrayList<Element> certificateValuesNodes = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 687 */       new NombreNodo(esquemaURI, "CertificateValues"));
/*     */     
/* 689 */     if (certificateValuesNodes.size() != 1)
/*     */     {
/* 691 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 692 */         " " + "CertificateValues" + " " + 
/* 693 */         I18n.getResource("libreriaxades.firmaxml.error38") + " " + 
/* 694 */         certificateValuesNodes.size());
/*     */     }
/* 696 */     String certValueId = ((Element)certificateValuesNodes.get(0)).getAttribute("Id");
/* 697 */     if (certValueId == null)
/* 698 */       throw new BadFormedSignatureException("No se puede recuperar la ID del nodo CertificateValues");
/* 699 */     input.add("#" + certValueId);
/*     */     
/*     */ 
/* 702 */     ArrayList<Element> revocationValuesNodes = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 703 */       new NombreNodo(esquemaURI, "RevocationValues"));
/*     */     
/* 705 */     if (revocationValuesNodes.size() != 1)
/*     */     {
/* 707 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 708 */         " " + "RevocationValues" + " " + 
/* 709 */         I18n.getResource("libreriaxades.firmaxml.error38") + " " + 
/* 710 */         revocationValuesNodes.size());
/*     */     }
/* 712 */     String revValuesId = ((Element)revocationValuesNodes.get(0)).getAttribute("Id");
/* 713 */     if (revValuesId == null)
/* 714 */       throw new BadFormedSignatureException("No se puede recuperar la ID del nodo RevocationValues");
/* 715 */     input.add("#" + revValuesId);
/*     */     
/*     */ 
/* 718 */     ArrayList<Element> archiveTimeStampNodes = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 719 */       new NombreNodo(esquemaURI, "ArchiveTimeStamp"));
/*     */     
/* 721 */     for (int i = 0; i < archiveTimeStampNodes.size(); i++) {
/* 722 */       Element selloANode = (Element)archiveTimeStampNodes.get(i);
/* 723 */       if ((selloA != null) && (selloA.equals(selloANode)))
/*     */         break;
/* 725 */       String aTimeStampId = selloANode.getAttribute("Id");
/* 726 */       if (aTimeStampId == null)
/* 727 */         throw new BadFormedSignatureException("No se puede recuperar la ID del nodo ArchiveTimeStamp");
/* 728 */       input.add("#" + aTimeStampId);
/*     */     }
/*     */     
/*     */ 
/* 732 */     ObjectContainer object = null;
/* 733 */     Element reference = null;
/* 734 */     String objectId = null;
/* 735 */     String referenceUri = null;
/* 736 */     for (int i = 0; i < xmlSig.getObjectLength(); i++) {
/* 737 */       object = xmlSig.getObjectItem(i);
/* 738 */       objectId = object.getId();
/* 739 */       boolean incluir = true;
/* 740 */       for (int j = 0; j < referenceNodes.size(); j++) {
/* 741 */         reference = (Element)referenceNodes.get(j);
/* 742 */         referenceUri = reference.getAttribute("URI");
/* 743 */         if ((referenceUri != null) && (referenceUri.length() > 0) && (referenceUri.substring(1).equals(objectId))) {
/* 744 */           incluir = false;
/* 745 */           break;
/*     */         }
/*     */       }
/*     */       
/* 749 */       ArrayList<Element> quialifyingProp = UtilidadTratarNodo.obtenerNodos(firma, 2, new NombreNodo(esquemaURI, "QualifyingProperties"));
/* 750 */       for (int j = 0; (j < quialifyingProp.size()) && (incluir); j++) {
/* 751 */         if (((Element)quialifyingProp.get(j)).equals(object.getElement().getFirstChild())) {
/* 752 */           incluir = false;
/*     */         }
/*     */       }
/* 755 */       if (incluir) {
/* 756 */         String objectNodeId = object.getElement().getAttribute("Id");
/* 757 */         if (objectNodeId == null)
/* 758 */           throw new BadFormedSignatureException("No se puede recuperar la ID del nodo Object");
/* 759 */         input.add("#" + objectNodeId);
/*     */       }
/*     */     }
/*     */     
/* 763 */     return input;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ArrayList<String> casoDistribuido()
/*     */   {
/* 788 */     ArrayList<String> input = new ArrayList();
/*     */     
/* 790 */     return input;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\UtilidadXadesA.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */