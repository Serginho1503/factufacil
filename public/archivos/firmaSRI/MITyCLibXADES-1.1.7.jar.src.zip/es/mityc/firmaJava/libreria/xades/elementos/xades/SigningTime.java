/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.XMLDataDateTimeType;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.util.Date;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SigningTime
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private XMLDataDateTimeType data;
/*     */   
/*     */   public SigningTime(XAdESSchemas schema)
/*     */   {
/*  40 */     super(schema);
/*     */   }
/*     */   
/*     */   public SigningTime(XAdESSchemas schema, Date date) {
/*  44 */     super(schema);
/*  45 */     this.data = new XMLDataDateTimeType(date);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  53 */     if ((obj instanceof SigningTime)) {
/*  54 */       SigningTime time = (SigningTime)obj;
/*  55 */       if (this.data.equals(time.data)) {
/*  56 */         return true;
/*     */       }
/*     */     } else {
/*  59 */       return this.data.equals(obj); }
/*  60 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  68 */     checkElementName(element, this.schema.getSchemaUri(), "SigningTime");
/*  69 */     this.data = new XMLDataDateTimeType(null);
/*  70 */     this.data.load(element);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Element createElement(Document doc)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  78 */     if (this.data == null)
/*  79 */       throw new InvalidInfoNodeException("Información insuficiente para escribir elemento SigningTime");
/*  80 */     Element res = doc.createElementNS(this.schema.getSchemaUri(), this.namespaceXAdES + ":" + "SigningTime");
/*  81 */     this.data.addContent(res);
/*  82 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isThisNode(Node node)
/*     */   {
/*  90 */     return isElementName(nodeToElement(node), this.schema.getSchemaUri(), "SigningTime");
/*     */   }
/*     */   
/*     */   public void setValue(Date value) {
/*  94 */     if (this.data == null) {
/*  95 */       this.data = new XMLDataDateTimeType(value);
/*     */     } else
/*  97 */       this.data.setValue(value);
/*     */   }
/*     */   
/*     */   public Date getValue() {
/* 101 */     if (this.data != null)
/* 102 */       return this.data.getValue();
/* 103 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Element createElement(Document doc, String namespaceXAdES)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 111 */     return super.createElement(doc, namespaceXAdES);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\SigningTime.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */