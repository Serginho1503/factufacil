/*    */ package es.mityc.firmaJava.libreria.xades.errores;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PolicyException
/*    */   extends FirmaXMLError
/*    */ {
/*    */   public PolicyException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PolicyException(String msg)
/*    */   {
/* 30 */     super(msg);
/*    */   }
/*    */   
/*    */   public PolicyException(Exception e) {
/* 34 */     super(e);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public PolicyException(String message, Throwable cause)
/*    */   {
/* 42 */     super(message, cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public PolicyException(Throwable cause)
/*    */   {
/* 49 */     super(cause);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\errores\PolicyException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */