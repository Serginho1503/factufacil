/*    */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum QualifierEnum
/*    */ {
/* 23 */   OIDAsURI("OIDAsURI"), 
/* 24 */   OIDAsURN("OIDAsURN");
/*    */   
/*    */   private String value;
/*    */   
/*    */   private QualifierEnum(String value)
/*    */   {
/* 30 */     this.value = value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 38 */     return new String(this.value);
/*    */   }
/*    */   
/*    */   public static QualifierEnum getQualifierEnum(String value) {
/* 42 */     if (value == null)
/* 43 */       return null;
/* 44 */     if (OIDAsURI.toString().equals(value))
/* 45 */       return OIDAsURI;
/* 46 */     if (OIDAsURN.toString().equals(value))
/* 47 */       return OIDAsURN;
/* 48 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\QualifierEnum.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */