/*    */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*    */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*    */ import java.io.File;
/*    */ import java.security.cert.X509CRL;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CRLRef
/*    */   extends CRLRefType
/*    */ {
/*    */   public CRLRef(XAdESSchemas schema)
/*    */   {
/* 41 */     super(schema);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CRLRef(XAdESSchemas schema, String method, X509CRL crl)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 51 */     super(schema, method, crl);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CRLRef(XAdESSchemas schema, String method, File crlFile)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 61 */     super(schema, method, crlFile);
/*    */   }
/*    */   
/*    */   public void load(Element element) throws InvalidInfoNodeException
/*    */   {
/* 66 */     checkElementName(element, this.schema.getSchemaUri(), "CRLRef");
/* 67 */     super.load(element);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isThisNode(Node node)
/*    */   {
/* 75 */     return isElementName(nodeToElement(node), this.schema.getSchemaUri(), "CRLRef");
/*    */   }
/*    */   
/*    */   public Element createElement(Document doc, String namespaceXDsig, String namespaceXAdES) throws InvalidInfoNodeException
/*    */   {
/* 80 */     return super.createElement(doc, namespaceXDsig, namespaceXAdES);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected Element createElement(Document doc)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 88 */     Element res = doc.createElementNS(this.schema.getSchemaUri(), this.namespaceXAdES + ":" + "CRLRef");
/* 89 */     super.addContent(res, this.namespaceXAdES, this.namespaceXDsig);
/* 90 */     return res;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\CRLRef.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */