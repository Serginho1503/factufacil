/*    */ package es.mityc.firmaJava.libreria.utilidades;
/*    */ 
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NombreNodo
/*    */ {
/*    */   private static final String COMODIN = "*";
/*    */   private String namespace;
/*    */   private String localname;
/*    */   
/*    */   public NombreNodo(String namespace, String localname)
/*    */   {
/* 33 */     this.namespace = namespace;
/* 34 */     this.localname = localname;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 38 */     if (obj != null) {
/* 39 */       if ((obj instanceof NombreNodo)) {
/* 40 */         NombreNodo nodo = (NombreNodo)obj;
/* 41 */         if (this.namespace == null) {
/* 42 */           if (nodo.namespace != null)
/* 43 */             return false;
/* 44 */         } else if ((!"*".equals(this.namespace)) && (!this.namespace.equals(nodo.namespace))) {
/* 45 */           return false;
/*    */         }
/* 47 */         if (this.localname.equals(nodo.localname))
/* 48 */           return true;
/* 49 */       } else if ((obj instanceof Element)) {
/* 50 */         Element el = (Element)obj;
/* 51 */         if ((this.namespace == el.getNamespaceURI()) && 
/* 52 */           (this.localname == el.getLocalName())) {
/* 53 */           return true;
/*    */         }
/*    */       }
/*    */     }
/* 57 */     return false;
/*    */   }
/*    */   
/* 60 */   public String getNamespace() { return this.namespace; }
/*    */   
/*    */   public String getLocalname() {
/* 63 */     return this.localname;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\utilidades\NombreNodo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */