/*    */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*    */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*    */ import es.mityc.javasign.xml.xades.policy.PolicyException;
/*    */ import java.net.URI;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SPURI
/*    */   extends AbstractXadesURIElement
/*    */   implements IPolicyQualifier
/*    */ {
/*    */   public SPURI(XAdESSchemas schema, URI data)
/*    */   {
/* 43 */     super(schema, "SPURI", data);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public SPURI(XAdESSchemas schema)
/*    */   {
/* 51 */     super(schema, "SPURI");
/*    */   }
/*    */   
/*    */   public Node createPolicyQualifierContent(Document doc) throws PolicyException {
/* 55 */     Element el = null;
/*    */     try {
/* 57 */       if (getNamespaceXAdES() != null) {
/* 58 */         el = createElement(doc, this.namespaceXAdES);
/*    */       } else
/* 60 */         throw new PolicyException("No se ha indicado qualifier para nodo SPURI");
/*    */     } catch (InvalidInfoNodeException ex) {
/* 62 */       throw new PolicyException(ex);
/*    */     }
/* 64 */     return el;
/*    */   }
/*    */   
/*    */   public void loadPolicyQualifierContent(Element element) throws PolicyException {
/*    */     try {
/* 69 */       load(element);
/*    */     } catch (InvalidInfoNodeException ex) {
/* 71 */       throw new PolicyException(ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\SPURI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */