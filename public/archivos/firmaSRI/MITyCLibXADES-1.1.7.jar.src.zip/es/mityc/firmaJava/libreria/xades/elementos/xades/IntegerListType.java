/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.math.BigInteger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntegerListType
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private ArrayList<Int> ints;
/*     */   
/*     */   public IntegerListType(XAdESSchemas schema)
/*     */   {
/*  43 */     super(schema);
/*     */   }
/*     */   
/*     */   public IntegerListType(XAdESSchemas schema, ArrayList<Int> ints) {
/*  47 */     super(schema);
/*  48 */     this.ints = ints;
/*     */   }
/*     */   
/*     */   public IntegerListType(XAdESSchemas schema, int[] ints) {
/*  52 */     super(schema);
/*  53 */     if (ints != null) {
/*  54 */       this.ints = new ArrayList(ints.length);
/*  55 */       for (int i = 0; i < ints.length; i++) {
/*  56 */         this.ints.add(new Int(schema, new BigInteger(Integer.toString(ints[i]))));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public ArrayList<Int> getInts()
/*     */   {
/*  63 */     return this.ints;
/*     */   }
/*     */   
/*     */   public void setInts(ArrayList<Int> ints) {
/*  67 */     this.ints = ints;
/*     */   }
/*     */   
/*     */   public void addInt(BigInteger integer) {
/*  71 */     if (this.ints == null)
/*  72 */       this.ints = new ArrayList();
/*  73 */     this.ints.add(new Int(this.schema, integer));
/*     */   }
/*     */   
/*     */   public void addInt(Int integer) {
/*  77 */     if (this.ints == null)
/*  78 */       this.ints = new ArrayList();
/*  79 */     this.ints.add(integer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  87 */     if ((obj instanceof IntegerListType)) {
/*  88 */       IntegerListType cvt = (IntegerListType)obj;
/*  89 */       ArrayList<Int> comp = cvt.ints;
/*  90 */       if (((this.ints == null) || (this.ints.isEmpty())) && (
/*  91 */         (comp == null) || (comp.isEmpty())))
/*  92 */         return true;
/*  93 */       if ((this.ints != null) && (comp != null) && 
/*  94 */         (this.ints.size() == comp.size())) {
/*  95 */         Iterator<Int> itThis = this.ints.iterator();
/*  96 */         Iterator<Int> itComp = comp.iterator();
/*  97 */         while (itThis.hasNext()) {
/*  98 */           if (!((Int)itThis.next()).equals(itComp.next()))
/*  99 */             return false;
/*     */         }
/* 101 */         return true;
/*     */       }
/*     */     }
/* 104 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 112 */     NodeList nodos = element.getChildNodes();
/* 113 */     ArrayList<Int> temp = new ArrayList(nodos.getLength());
/* 114 */     for (int i = 0; i < nodos.getLength(); i++) {
/* 115 */       Node nodo = nodos.item(i);
/* 116 */       if (!isDecorationNode(nodo))
/*     */       {
/*     */ 
/* 119 */         if (nodo.getNodeType() != 1) {
/* 120 */           throw new InvalidInfoNodeException("Hijo de CertificateValuesType no es un elemento");
/*     */         }
/* 122 */         Int integer = new Int(this.schema);
/* 123 */         integer.load((Element)nodo);
/* 124 */         temp.add(integer);
/*     */       } }
/* 126 */     this.ints = temp;
/*     */   }
/*     */   
/*     */   public void addContent(Element element, String namespaceXAdES) throws InvalidInfoNodeException
/*     */   {
/* 131 */     super.addContent(element, namespaceXAdES);
/*     */   }
/*     */   
/*     */   protected void addContent(Element element) throws InvalidInfoNodeException
/*     */   {
/* 136 */     if (this.ints != null) {
/* 137 */       Iterator<Int> it = this.ints.iterator();
/* 138 */       while (it.hasNext()) {
/* 139 */         element.appendChild(((Int)it.next()).createElement(element.getOwnerDocument(), this.namespaceXAdES));
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\IntegerListType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */