/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.math.BigInteger;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Cert
/*     */   extends CertIDType
/*     */ {
/*     */   public Cert(XAdESSchemas schema)
/*     */   {
/*  34 */     super(schema);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cert(XAdESSchemas schema, CertDigest digest, IssuerSerial issuerSerial)
/*     */   {
/*  43 */     super(schema, digest, issuerSerial);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cert(XAdESSchemas schema, String digestMethod, byte[] digestValue, String issuerName, BigInteger serialNumber)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  56 */     super(schema, digestMethod, digestValue, issuerName, serialNumber);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cert(XAdESSchemas schema, String digestMethod, String digestValue, String issuerName, BigInteger serialNumber)
/*     */   {
/*  67 */     super(schema, digestMethod, digestValue, issuerName, serialNumber);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  75 */     checkElementName(element, this.schema.getSchemaUri(), "Cert");
/*  76 */     super.load(element);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isThisNode(Node node)
/*     */   {
/*  84 */     return isElementName(nodeToElement(node), this.schema.getSchemaUri(), "Cert");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Element createElement(Document doc, String namespaceXDsig, String namespaceXAdES)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  92 */     return super.createElement(doc, namespaceXDsig, namespaceXAdES);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Element createElement(Document doc)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 100 */     Element res = doc.createElementNS(this.schema.getSchemaUri(), this.namespaceXAdES + ":" + "Cert");
/* 101 */     super.addContent(res, this.namespaceXAdES, this.namespaceXDsig);
/* 102 */     return res;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\Cert.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */