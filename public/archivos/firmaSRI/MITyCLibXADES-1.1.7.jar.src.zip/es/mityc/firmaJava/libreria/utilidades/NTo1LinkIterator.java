/*    */ package es.mityc.firmaJava.libreria.utilidades;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NTo1LinkIterator<E>
/*    */   implements Iterator<NTo1Link<E>>
/*    */ {
/*    */   private NTo1Link<E> nextNode;
/*    */   
/*    */   NTo1LinkIterator(NTo1Link<E> first)
/*    */   {
/* 30 */     this.nextNode = first;
/*    */   }
/*    */   
/*    */   public boolean hasNext() {
/* 34 */     return this.nextNode != null;
/*    */   }
/*    */   
/*    */   public NTo1Link<E> next() {
/* 38 */     if (this.nextNode == null)
/* 39 */       throw new NoSuchElementException();
/* 40 */     NTo1Link<E> node = this.nextNode;
/* 41 */     this.nextNode = this.nextNode.getNext();
/* 42 */     return node;
/*    */   }
/*    */   
/*    */   public void remove() {
/* 46 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\utilidades\NTo1LinkIterator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */