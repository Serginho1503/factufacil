/*    */ package es.mityc.firmaJava.libreria.errores;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClienteChainNotFoundError
/*    */   extends ClienteError
/*    */ {
/* 22 */   private String tipoCertificado = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ClienteChainNotFoundError() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ClienteChainNotFoundError(String msg)
/*    */   {
/* 36 */     super(msg);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ClienteChainNotFoundError(String msg, String tipoCertificado)
/*    */   {
/* 45 */     super(msg);
/* 46 */     this.tipoCertificado = tipoCertificado;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ClienteChainNotFoundError(Throwable msg)
/*    */   {
/* 55 */     super(msg);
/*    */   }
/*    */   
/*    */   public ClienteChainNotFoundError(String msg, Throwable th) {
/* 59 */     super(msg, th);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ClienteChainNotFoundError(Throwable msg, String tipoCertificado)
/*    */   {
/* 68 */     super(msg);
/* 69 */     this.tipoCertificado = tipoCertificado;
/*    */   }
/*    */   
/*    */   public ClienteChainNotFoundError(String msg, Throwable th, String tipoCertificado) {
/* 73 */     super(msg, th);
/* 74 */     this.tipoCertificado = tipoCertificado;
/*    */   }
/*    */   
/*    */   public String getTipoCertificado() {
/* 78 */     return this.tipoCertificado;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\errores\ClienteChainNotFoundError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */