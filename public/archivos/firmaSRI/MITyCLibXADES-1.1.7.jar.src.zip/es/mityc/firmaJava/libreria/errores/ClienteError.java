/*    */ package es.mityc.firmaJava.libreria.errores;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClienteError
/*    */   extends Exception
/*    */ {
/* 27 */   String mensaje = "";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ClienteError() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ClienteError(String msg)
/*    */   {
/* 41 */     super(msg);
/* 42 */     this.mensaje = msg;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ClienteError(Throwable msg)
/*    */   {
/* 51 */     super(msg);
/* 52 */     this.mensaje = msg.getMessage();
/*    */   }
/*    */   
/*    */   public ClienteError(String msg, Throwable th) {
/* 56 */     super(msg, th);
/* 57 */     this.mensaje = msg;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 66 */     return this.mensaje;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\errores\ClienteError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */