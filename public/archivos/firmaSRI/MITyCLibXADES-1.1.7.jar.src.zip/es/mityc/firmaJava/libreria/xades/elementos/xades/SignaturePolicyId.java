/*    */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*    */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SignaturePolicyId
/*    */   extends SignaturePolicyIdType
/*    */ {
/*    */   public SignaturePolicyId(XAdESSchemas schema)
/*    */   {
/* 35 */     super(schema);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void load(Element element)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 43 */     checkElementName(element, this.schema.getSchemaUri(), "SignaturePolicyId");
/* 44 */     super.load(element);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isThisNode(Node node)
/*    */   {
/* 52 */     return isElementName(nodeToElement(node), this.schema.getSchemaUri(), "SignaturePolicyId");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Element createElement(Document doc, String namespaceXDsig, String namespaceXAdES)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 60 */     return super.createElement(doc, namespaceXDsig, namespaceXAdES);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected Element createElement(Document doc)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 68 */     Element res = doc.createElementNS(this.schema.getSchemaUri(), this.namespaceXAdES + ":" + "SignaturePolicyId");
/* 69 */     super.addContent(res, this.namespaceXAdES, this.namespaceXDsig);
/* 70 */     return res;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\SignaturePolicyId.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */