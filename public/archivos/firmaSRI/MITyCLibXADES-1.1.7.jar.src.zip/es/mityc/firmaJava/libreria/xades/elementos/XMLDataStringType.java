/*    */ package es.mityc.firmaJava.libreria.xades.elementos;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.utilidades.Utilidades;
/*    */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*    */ import org.apache.commons.lang.StringEscapeUtils;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMLDataStringType
/*    */   extends AbstractXMLElement
/*    */ {
/*    */   protected String value;
/*    */   
/*    */   public XMLDataStringType(String value)
/*    */   {
/* 36 */     this.value = value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void addContent(Element element)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 44 */     if (this.value == null)
/* 45 */       throw new InvalidInfoNodeException("Información insuficiente para escribir nodo XMLDataStringType");
/* 46 */     element.setTextContent(Utilidades.escapeXML(this.value));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 54 */     if ((obj instanceof XMLDataStringType)) {
/* 55 */       XMLDataStringType xdst = (XMLDataStringType)obj;
/* 56 */       if (this.value.equals(xdst))
/* 57 */         return true;
/* 58 */     } else if ((obj instanceof String)) {
/* 59 */       String data = (String)obj;
/* 60 */       if (this.value.equals(data))
/* 61 */         return true;
/*    */     }
/* 63 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void load(Element element)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 71 */     Node node = getFirstNonvoidNode(element);
/* 72 */     if ((node != null) && (node.getNodeType() != 3)) {
/* 73 */       throw new InvalidInfoNodeException("Nodo xsd:string no contiene CDATA como primer valor");
/*    */     }
/*    */     
/* 76 */     if (node == null) {
/* 77 */       this.value = new String("");
/*    */     } else {
/* 79 */       this.value = node.getNodeValue();
/* 80 */       if (this.value == null) {
/* 81 */         throw new InvalidInfoNodeException("Contenido de valor de xsd:string vacío");
/*    */       }
/* 83 */       this.value = StringEscapeUtils.unescapeXml(this.value);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getValue()
/*    */   {
/* 91 */     return this.value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setValue(String value)
/*    */   {
/* 98 */     this.value = value;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\XMLDataStringType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */