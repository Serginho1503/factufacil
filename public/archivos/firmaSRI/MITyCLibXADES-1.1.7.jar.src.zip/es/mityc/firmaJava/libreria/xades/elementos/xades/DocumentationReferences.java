/*    */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*    */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*    */ import java.util.ArrayList;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DocumentationReferences
/*    */   extends DocumentationReferencesType
/*    */ {
/*    */   public DocumentationReferences(XAdESSchemas schema)
/*    */   {
/* 40 */     super(schema);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public DocumentationReferences(XAdESSchemas schema, ArrayList<DocumentationReference> list)
/*    */   {
/* 48 */     super(schema, list);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void load(Element element)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 56 */     checkElementName(element, this.schema.getSchemaUri(), "DocumentationReferences");
/* 57 */     super.load(element);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isThisNode(Node node)
/*    */   {
/* 65 */     return isElementName(nodeToElement(node), this.schema.getSchemaUri(), "DocumentationReferences");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Element createElement(Document doc, String namespaceXAdES)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 73 */     return super.createElement(doc, namespaceXAdES);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected Element createElement(Document doc)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 81 */     Element res = doc.createElementNS(this.schema.getSchemaUri(), this.namespaceXAdES + ":" + "DocumentationReferences");
/* 82 */     super.addContent(res, this.namespaceXAdES);
/* 83 */     return res;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\DocumentationReferences.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */