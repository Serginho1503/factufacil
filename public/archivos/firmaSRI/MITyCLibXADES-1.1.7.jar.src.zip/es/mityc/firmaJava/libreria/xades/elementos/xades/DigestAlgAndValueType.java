/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.utilidades.Base64Coder;
/*     */ import es.mityc.firmaJava.libreria.utilidades.UtilidadFirmaElectronica;
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xmldsig.DigestMethod;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xmldsig.DigestValue;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.security.MessageDigest;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DigestAlgAndValueType
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private DigestMethod method;
/*     */   private DigestValue value;
/*     */   
/*     */   public DigestAlgAndValueType(XAdESSchemas schema)
/*     */   {
/*  41 */     super(schema);
/*     */   }
/*     */   
/*     */   public DigestAlgAndValueType(XAdESSchemas schema, String method, byte[] data) throws InvalidInfoNodeException {
/*  45 */     super(schema);
/*  46 */     MessageDigest md = UtilidadFirmaElectronica.getMessageDigest(method);
/*  47 */     if (md == null)
/*  48 */       throw new InvalidInfoNodeException("Método desconocido para calcular el digest: " + method);
/*  49 */     this.method = new DigestMethod(method);
/*  50 */     md.update(data);
/*  51 */     byte[] result = md.digest();
/*  52 */     this.value = new DigestValue(new String(Base64Coder.encode(result)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public DigestAlgAndValueType(XAdESSchemas schema, String method, String value)
/*     */   {
/*  59 */     super(schema);
/*  60 */     this.method = new DigestMethod(method);
/*  61 */     this.value = new DigestValue(value);
/*     */   }
/*     */   
/*     */   public DigestMethod getDigestMethod() {
/*  65 */     return this.method;
/*     */   }
/*     */   
/*     */   public void setMethod(DigestMethod method) {
/*  69 */     this.method = method;
/*     */   }
/*     */   
/*     */   public DigestValue getDigestValue() {
/*  73 */     return this.value;
/*     */   }
/*     */   
/*     */   public void setValue(DigestValue value) {
/*  77 */     this.value = value;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/*  82 */     if ((obj instanceof DigestAlgAndValueType)) {
/*  83 */       DigestAlgAndValueType huella = (DigestAlgAndValueType)obj;
/*  84 */       if (!this.method.equals(huella.getDigestMethod()))
/*  85 */         return false;
/*  86 */       if (this.value.equals(huella.getDigestValue()))
/*  87 */         return true;
/*     */     }
/*  89 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  97 */     Node node = getFirstNonvoidNode(element);
/*     */     
/*  99 */     DigestMethod method = new DigestMethod(null);
/* 100 */     if (!method.isThisNode(node))
/* 101 */       throw new InvalidInfoNodeException("Se esperaba nodo DigestMethod en DigestAlgAndValueType");
/* 102 */     method.load((Element)node);
/*     */     
/* 104 */     node = getNextNonvoidNode(node);
/* 105 */     DigestValue value = new DigestValue(null);
/* 106 */     if (!value.isThisNode(node))
/* 107 */       throw new InvalidInfoNodeException("Se esperaba nodo DigestValue en DigestAlgAndValueType");
/* 108 */     value.load((Element)node);
/*     */     
/* 110 */     this.method = method;
/* 111 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addContent(Element element, String namespaceXAdES, String namespaceXDsig)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 120 */     super.addContent(element, namespaceXAdES, namespaceXDsig);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void addContent(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 128 */     if ((this.method == null) || (this.value == null))
/* 129 */       throw new InvalidInfoNodeException("Información insuficiente para escribir nodo DigestAlgAndValueType");
/* 130 */     element.appendChild(this.method.createElement(element.getOwnerDocument(), this.namespaceXDsig));
/* 131 */     element.appendChild(this.value.createElement(element.getOwnerDocument(), this.namespaceXDsig));
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\DigestAlgAndValueType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */