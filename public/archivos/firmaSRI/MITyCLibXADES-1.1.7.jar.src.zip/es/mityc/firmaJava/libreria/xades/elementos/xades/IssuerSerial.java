/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xmldsig.X509IssuerSerialType;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.math.BigInteger;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IssuerSerial
/*     */   extends X509IssuerSerialType
/*     */ {
/*     */   protected XAdESSchemas schema;
/*     */   protected String namespaceXAdES;
/*     */   
/*     */   public IssuerSerial(XAdESSchemas schema)
/*     */   {
/*  39 */     this.schema = schema;
/*     */   }
/*     */   
/*     */   public IssuerSerial(XAdESSchemas schema, String issuerName, BigInteger serialNumber) {
/*  43 */     super(issuerName, serialNumber);
/*  44 */     this.schema = schema;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public XAdESSchemas getSchema()
/*     */   {
/*  51 */     return this.schema;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSchema(XAdESSchemas schema)
/*     */   {
/*  59 */     this.schema = schema;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Element createElement(Document doc, String namespaceXAdES)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  68 */     setNamespaceXAdES(namespaceXAdES);
/*  69 */     return createElement(doc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element createElement(Document doc, String namespaceXDsig, String namespaceXAdES)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  82 */     setNamespaceXAdES(namespaceXAdES);
/*  83 */     return super.createElement(doc, namespaceXDsig);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getNamespaceXAdES()
/*     */   {
/*  90 */     return this.namespaceXAdES;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNamespaceXAdES(String namespaceXAdES)
/*     */   {
/*  98 */     this.namespaceXAdES = namespaceXAdES;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 106 */     checkElementName(element, this.schema.getSchemaUri(), "IssuerSerial");
/* 107 */     super.load(element);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isThisNode(Node node)
/*     */   {
/* 115 */     return isElementName(nodeToElement(node), this.schema.getSchemaUri(), "IssuerSerial");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Element createElement(Document doc)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 123 */     Element res = doc.createElementNS(this.schema.getSchemaUri(), this.namespaceXAdES + ":" + "IssuerSerial");
/* 124 */     addContent(res, this.namespaceXAdES, this.namespaceXDsig);
/* 125 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addContent(Element element, String namespaceXAdES, String namespaceXDsig)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 136 */     setNamespaceXAdES(namespaceXAdES);
/* 137 */     super.addContent(element, namespaceXDsig);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\IssuerSerial.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */