/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataObjectFormatType
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private URI objectReference;
/*     */   private Description description;
/*     */   private ObjectIdentifier objectIdentifier;
/*     */   private MimeType mimetype;
/*     */   private Encoding encoding;
/*     */   
/*     */   public DataObjectFormatType(XAdESSchemas schema, URI reference, String description, String mimeType)
/*     */   {
/*  44 */     super(schema);
/*  45 */     this.objectReference = reference;
/*  46 */     if (description != null)
/*  47 */       this.description = new Description(schema, description);
/*  48 */     if (mimeType != null) {
/*  49 */       this.mimetype = new MimeType(schema, mimeType);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public DataObjectFormatType(XAdESSchemas schema)
/*     */   {
/*  56 */     super(schema);
/*     */   }
/*     */   
/*     */   public Description getDescription() {
/*  60 */     return this.description;
/*     */   }
/*     */   
/*     */   public void setDescription(String description) {
/*  64 */     this.description = new Description(this.schema, description);
/*     */   }
/*     */   
/*     */   public void setDescription(Description description) {
/*  68 */     this.description = description;
/*     */   }
/*     */   
/*     */   public MimeType getMimeType() {
/*  72 */     return this.mimetype;
/*     */   }
/*     */   
/*     */   public void setMimeType(String mimeType) {
/*  76 */     this.mimetype = new MimeType(this.schema, mimeType);
/*     */   }
/*     */   
/*     */   public void setMimeType(MimeType mimeType) {
/*  80 */     this.mimetype = mimeType;
/*     */   }
/*     */   
/*     */   public Encoding getEnconding() {
/*  84 */     return this.encoding;
/*     */   }
/*     */   
/*     */   public void setEncoding(URI encoding) {
/*  88 */     this.encoding = new Encoding(this.schema, encoding);
/*     */   }
/*     */   
/*     */   public void setEncoding(Encoding encoding) {
/*  92 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */   public ObjectIdentifier getObjectIdentifier() {
/*  96 */     return this.objectIdentifier;
/*     */   }
/*     */   
/*     */   public void setObjectIdentifier(ObjectIdentifier objectIdentifier) {
/* 100 */     this.objectIdentifier = objectIdentifier;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 108 */     if ((obj instanceof DataObjectFormatType)) {
/* 109 */       DataObjectFormatType doft = (DataObjectFormatType)obj;
/* 110 */       if (!compare(this.description, doft.description))
/* 111 */         return false;
/* 112 */       if (!compare(this.objectIdentifier, doft.objectIdentifier))
/* 113 */         return false;
/* 114 */       if (!compare(this.mimetype, doft.mimetype))
/* 115 */         return false;
/* 116 */       if (!compare(this.encoding, doft.encoding))
/* 117 */         return false;
/* 118 */       return true;
/*     */     }
/* 120 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 128 */     String uri = element.getAttribute("ObjectReference");
/* 129 */     if (uri == null)
/* 130 */       throw new InvalidInfoNodeException("No hay ObjectReference en nodo DataObjectFormatType");
/*     */     try {
/* 132 */       this.objectReference = new URI(uri);
/*     */     } catch (URISyntaxException ex) {
/* 134 */       throw new InvalidInfoNodeException("URI en ObjectReference inválida");
/*     */     }
/*     */     
/* 137 */     Description description = null;
/* 138 */     ObjectIdentifier objIdentifier = null;
/* 139 */     MimeType mimeType = null;
/* 140 */     Encoding encoding = null;
/*     */     
/* 142 */     Node node = getFirstNonvoidNode(element);
/* 143 */     if (node != null) {
/* 144 */       if (node.getNodeType() != 1)
/* 145 */         throw new InvalidInfoNodeException("Se esperaba elemento como hijo de DataObjectFormatType");
/* 146 */       description = new Description(this.schema);
/* 147 */       if (description.isThisNode(node)) {
/* 148 */         description.load((Element)node);
/* 149 */         node = getNextNonvoidNode(node);
/*     */       } else {
/* 151 */         description = null;
/*     */       }
/*     */     }
/* 154 */     if (node != null) {
/* 155 */       if (node.getNodeType() != 1)
/* 156 */         throw new InvalidInfoNodeException("Se esperaba elemento como hijo de DataObjectFormatType");
/* 157 */       objIdentifier = new ObjectIdentifier(this.schema);
/* 158 */       if (objIdentifier.isThisNode(node)) {
/* 159 */         objIdentifier.load((Element)node);
/* 160 */         node = getNextNonvoidNode(node);
/*     */       } else {
/* 162 */         objIdentifier = null;
/*     */       }
/*     */     }
/* 165 */     if (node != null) {
/* 166 */       if (node.getNodeType() != 1)
/* 167 */         throw new InvalidInfoNodeException("Se esperaba elemento como hijo de DataObjectFormatType");
/* 168 */       mimeType = new MimeType(this.schema);
/* 169 */       if (mimeType.isThisNode(node)) {
/* 170 */         mimeType.load((Element)node);
/* 171 */         node = getNextNonvoidNode(node);
/*     */       } else {
/* 173 */         mimeType = null;
/*     */       }
/*     */     }
/* 176 */     if (node != null) {
/* 177 */       if (node.getNodeType() != 1)
/* 178 */         throw new InvalidInfoNodeException("Se esperaba elemento como hijo de DataObjectFormatType");
/* 179 */       encoding = new Encoding(this.schema);
/* 180 */       if (encoding.isThisNode(node)) {
/* 181 */         encoding.load((Element)node);
/* 182 */         node = getNextNonvoidNode(node);
/*     */       } else {
/* 184 */         encoding = null;
/*     */       }
/*     */     }
/* 187 */     if ((description == null) && (objIdentifier == null) && (mimeType == null)) {
/* 188 */       throw new InvalidInfoNodeException("No hay información de formato de objeto en nodo DataObjectFormatType");
/*     */     }
/* 190 */     this.description = description;
/* 191 */     this.objectIdentifier = objIdentifier;
/* 192 */     this.mimetype = mimeType;
/* 193 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addContent(Element element, String namespaceXAdES)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 201 */     super.addContent(element, namespaceXAdES);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void addContent(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 209 */     if (this.objectReference == null)
/* 210 */       throw new InvalidInfoNodeException("Información insuficiente para escribir nodo DataObjectFormatType");
/* 211 */     element.setAttributeNS(null, "ObjectReference", this.objectReference.toString());
/*     */     
/* 213 */     if ((this.description == null) && (this.objectIdentifier == null) && (this.mimetype == null)) {
/* 214 */       throw new InvalidInfoNodeException("Información insuficiente para escribir nodo DataObjectFormatType");
/*     */     }
/* 216 */     if (this.description != null)
/* 217 */       element.appendChild(this.description.createElement(element.getOwnerDocument(), this.namespaceXAdES));
/* 218 */     if (this.objectIdentifier != null)
/* 219 */       element.appendChild(this.objectIdentifier.createElement(element.getOwnerDocument(), this.namespaceXAdES));
/* 220 */     if (this.mimetype != null)
/* 221 */       element.appendChild(this.mimetype.createElement(element.getOwnerDocument(), this.namespaceXAdES));
/* 222 */     if (this.encoding != null) {
/* 223 */       element.appendChild(this.encoding.createElement(element.getOwnerDocument(), this.namespaceXAdES));
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\DataObjectFormatType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */