/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class IdentifierType
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private URI uri;
/*  34 */   private QualifierEnum qualifier = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IdentifierType(XAdESSchemas schema)
/*     */   {
/*  42 */     super(schema);
/*     */   }
/*     */   
/*     */   public IdentifierType(XAdESSchemas schema, URI uri, QualifierEnum qualifier) {
/*  46 */     super(schema);
/*  47 */     this.uri = uri;
/*  48 */     this.qualifier = qualifier;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  56 */     if ((obj instanceof IdentifierType)) {
/*  57 */       IdentifierType it = (IdentifierType)obj;
/*  58 */       if (this.uri.equals(it.uri))
/*  59 */         return true;
/*     */     }
/*  61 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  69 */     Node node = getFirstNonvoidNode(element);
/*  70 */     if (node.getNodeType() != 3) {
/*  71 */       throw new InvalidInfoNodeException("Nodo IdentifierType no contiene CDATA como primer valor");
/*     */     }
/*     */     
/*     */ 
/*  75 */     this.qualifier = QualifierEnum.getQualifierEnum(element.getAttribute("Qualifier"));
/*     */     
/*  77 */     String data = node.getNodeValue();
/*  78 */     if (data == null) {
/*  79 */       throw new InvalidInfoNodeException("No hay URI en nodo IdentifierType");
/*     */     }
/*     */     try {
/*  82 */       data = data.replace(" ", "%20");
/*  83 */       this.uri = new URI(data);
/*     */     } catch (URISyntaxException ex) {
/*  85 */       throw new InvalidInfoNodeException("URI malformada en nodo IdentifierType", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addContent(Element element) throws InvalidInfoNodeException {
/*  90 */     if (this.uri == null)
/*  91 */       throw new InvalidInfoNodeException("No hay información de URI para nodo IdentifierType");
/*  92 */     element.setTextContent(this.uri.toString());
/*     */     
/*  94 */     if (this.qualifier != null) {
/*  95 */       element.setAttributeNS(null, "Qualifier", this.qualifier.toString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public URI getUri()
/*     */   {
/* 102 */     return this.uri;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setUri(URI uri)
/*     */   {
/* 109 */     this.uri = uri;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public QualifierEnum getQualifier()
/*     */   {
/* 116 */     return this.qualifier;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setQualifier(QualifierEnum qualifier)
/*     */   {
/* 123 */     this.qualifier = qualifier;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\IdentifierType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */