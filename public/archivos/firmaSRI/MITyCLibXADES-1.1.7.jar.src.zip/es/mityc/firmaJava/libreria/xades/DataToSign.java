/*     */ package es.mityc.firmaJava.libreria.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.role.IClaimedRole;
/*     */ import es.mityc.javasign.EnumFormatoFirma;
/*     */ import es.mityc.javasign.certificate.ICertStatusRecoverer;
/*     */ import es.mityc.javasign.tsa.ITimeStampGenerator;
/*     */ import es.mityc.javasign.xml.refs.ObjectToSign;
/*     */ import es.mityc.javasign.xml.xades.IStoreElements;
/*     */ import es.mityc.javasign.xml.xades.LocalFileStoreElements;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import org.w3c.dom.Document;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataToSign
/*     */ {
/*     */   private Date signDate;
/*     */   private File xmlInFileToSign;
/*     */   private String xmlToSign;
/*     */   private String basePath;
/*     */   private boolean enveloped;
/*     */   private ArrayList<ObjectToSign> objects;
/*     */   private File signingCert;
/*     */   private String[] productionPlace;
/*     */   private ArrayList<IClaimedRole> claimedRoles;
/*     */   private ICertStatusRecoverer certStatusManager;
/*     */   private ITimeStampGenerator timeStampGenerator;
/*     */   
/*     */   public static enum XADES_X_TYPES
/*     */   {
/*  43 */     TYPE_1,  TYPE_2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  56 */   private String algDigestXmlDSig = "http://www.w3.org/2000/09/xmldsig#sha1";
/*  57 */   private XAdESSchemas esquema = XAdESSchemas.XAdES_132;
/*     */   private IStoreElements storer;
/*  59 */   private boolean addPolicy = false;
/*     */   private String policyKey;
/*  61 */   private EnumFormatoFirma xadesFormat = EnumFormatoFirma.XAdES_BES;
/*     */   private Document doc;
/*     */   private String parentSignNode;
/*  64 */   private XADES_X_TYPES xadesXType = XADES_X_TYPES.TYPE_1;
/*  65 */   private String encoding = "UTF-8";
/*     */   private String idNode2Raise;
/*     */   
/*     */   public DataToSign(File xmlToSign)
/*     */   {
/*  70 */     this.xmlInFileToSign = xmlToSign;
/*  71 */     this.basePath = xmlToSign.getParent();
/*  72 */     this.signDate = new Date();
/*     */   }
/*     */   
/*     */   public DataToSign(String xmlToSign) {
/*  76 */     this.xmlToSign = xmlToSign;
/*  77 */     this.signDate = new Date();
/*     */   }
/*     */   
/*     */   public DataToSign() {
/*  81 */     this.signDate = new Date();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXMLEncoding(String _encoding)
/*     */   {
/*  91 */     this.encoding = _encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getXMLEncoding()
/*     */   {
/* 100 */     return this.encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXAdESXType(XADES_X_TYPES _xadesXType)
/*     */   {
/* 108 */     this.xadesXType = _xadesXType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XADES_X_TYPES getXAdESXType()
/*     */   {
/* 117 */     return this.xadesXType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getParentSignNode()
/*     */   {
/* 125 */     return this.parentSignNode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParentSignNode(String parentNode)
/*     */   {
/* 133 */     this.parentSignNode = parentNode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EnumFormatoFirma getXadesFormat()
/*     */   {
/* 143 */     return this.xadesFormat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXadesFormat(EnumFormatoFirma xadesFormat)
/*     */   {
/* 153 */     this.xadesFormat = xadesFormat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasPolicy()
/*     */   {
/* 162 */     return this.addPolicy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPolicyKey()
/*     */   {
/* 171 */     return this.policyKey;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAddPolicy(boolean addPolicy)
/*     */   {
/* 179 */     this.addPolicy = addPolicy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPolicyKey(String policyKey)
/*     */   {
/* 191 */     this.policyKey = policyKey;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setElementsStorer(IStoreElements storer)
/*     */   {
/* 200 */     this.storer = storer;
/*     */   }
/*     */   
/*     */   public IStoreElements getElementsStorer() {
/* 204 */     if (this.storer == null)
/*     */     {
/* 206 */       IStoreElements nullStorer = new LocalFileStoreElements();
/* 207 */       nullStorer.init(getBaseURI());
/* 208 */       this.storer = nullStorer;
/*     */     }
/* 210 */     return this.storer;
/*     */   }
/*     */   
/*     */   public boolean isEnveloped() {
/* 214 */     return this.enveloped;
/*     */   }
/*     */   
/*     */   public void setEnveloped(boolean enveloped) {
/* 218 */     this.enveloped = enveloped;
/*     */   }
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/* 222 */     InputStream is = null;
/* 223 */     if (this.enveloped) {
/* 224 */       if (this.xmlInFileToSign != null) {
/* 225 */         is = new FileInputStream(this.xmlInFileToSign);
/*     */       }
/* 227 */       else if (this.xmlToSign != null) {
/* 228 */         is = new ByteArrayInputStream(this.xmlToSign.getBytes());
/*     */       }
/*     */     }
/* 231 */     return is;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDocument(Document doc)
/*     */   {
/* 239 */     this.doc = doc;
/*     */   }
/*     */   
/*     */   public Document getDocument() {
/* 243 */     return this.doc;
/*     */   }
/*     */   
/*     */   public String getBaseURI() {
/* 247 */     if (this.basePath != null) {
/* 248 */       return this.basePath;
/*     */     }
/* 250 */     return "";
/*     */   }
/*     */   
/*     */   public void setBaseURI(String basePath) {
/* 254 */     this.basePath = basePath;
/*     */   }
/*     */   
/*     */   public void addObject(ObjectToSign object) {
/* 258 */     if (this.objects == null)
/* 259 */       this.objects = new ArrayList();
/* 260 */     this.objects.add(object);
/*     */   }
/*     */   
/*     */   public ArrayList<ObjectToSign> getObjects() {
/* 264 */     return this.objects;
/*     */   }
/*     */   
/*     */   public Date getSignDate() {
/* 268 */     return this.signDate;
/*     */   }
/*     */   
/*     */   public void setSignDate(Date signDate) {
/* 272 */     this.signDate = signDate;
/*     */   }
/*     */   
/*     */   public File getSigningCert() {
/* 276 */     return this.signingCert;
/*     */   }
/*     */   
/*     */   public void setSigningCert(File signingCert) {
/* 280 */     this.signingCert = signingCert;
/*     */   }
/*     */   
/*     */   public void setProductionPlace(String city, String state, String postalCode, String country) {
/* 284 */     if ((city == null) && (state == null) && (postalCode == null) && (country == null)) {
/* 285 */       this.productionPlace = null;
/*     */     } else {
/* 287 */       this.productionPlace = new String[4];
/* 288 */       this.productionPlace[0] = city;
/* 289 */       this.productionPlace[1] = state;
/* 290 */       this.productionPlace[2] = postalCode;
/* 291 */       this.productionPlace[3] = country;
/*     */     }
/*     */   }
/*     */   
/*     */   public String[] getProductionPlace() {
/* 296 */     return this.productionPlace;
/*     */   }
/*     */   
/*     */   public void addClaimedRol(IClaimedRole data) {
/* 300 */     if (this.claimedRoles == null)
/* 301 */       this.claimedRoles = new ArrayList();
/* 302 */     this.claimedRoles.add(data);
/*     */   }
/*     */   
/*     */   public ArrayList<IClaimedRole> getClaimedRoles() {
/* 306 */     return this.claimedRoles;
/*     */   }
/*     */   
/*     */   public ICertStatusRecoverer getCertStatusManager() {
/* 310 */     return this.certStatusManager;
/*     */   }
/*     */   
/*     */   public void setCertStatusManager(ICertStatusRecoverer certStatusManager) {
/* 314 */     this.certStatusManager = certStatusManager;
/*     */   }
/*     */   
/*     */   public ITimeStampGenerator getTimeStampGenerator() {
/* 318 */     return this.timeStampGenerator;
/*     */   }
/*     */   
/*     */   public void setTimeStampGenerator(ITimeStampGenerator timeStampGenerator) {
/* 322 */     this.timeStampGenerator = timeStampGenerator;
/*     */   }
/*     */   
/*     */   public File getXmlInFileToSign() {
/* 326 */     return this.xmlInFileToSign;
/*     */   }
/*     */   
/*     */   public String getAlgDigestXmlDSig() {
/* 330 */     return this.algDigestXmlDSig;
/*     */   }
/*     */   
/*     */   public void setAlgDigestXmlDSig(String algDigestXmlDSig) {
/* 334 */     if (algDigestXmlDSig != null)
/* 335 */       this.algDigestXmlDSig = algDigestXmlDSig;
/*     */   }
/*     */   
/*     */   public XAdESSchemas getEsquema() {
/* 339 */     return this.esquema;
/*     */   }
/*     */   
/*     */   public void setEsquema(XAdESSchemas esquema) {
/* 343 */     this.esquema = esquema;
/*     */   }
/*     */   
/*     */   public String getIdNode2Raise() {
/* 347 */     return this.idNode2Raise;
/*     */   }
/*     */   
/*     */   public void setIdNode2Raise(String idNode2Raise) {
/* 351 */     this.idNode2Raise = idNode2Raise;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\DataToSign.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */