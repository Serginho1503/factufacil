/*    */ package es.mityc.firmaJava.libreria.xades;
/*    */ 
/*    */ import java.io.BufferedOutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class logv
/*    */ {
/* 32 */   private static BufferedOutputStream f = null;
/* 33 */   private static boolean tieneError = false;
/* 34 */   private static StringBuffer logsstart = null;
/* 35 */   private static StringBuffer logsend = null;
/* 36 */   private static StringBuffer logsb = null;
/*    */   
/*    */   static void createFile(String nombreFile) {}
/*    */   
/*    */   static void cierraLog() {}
/*    */   
/*    */   static void error(String error) {}
/*    */   
/*    */   static void info(String info) {}
/*    */   
/*    */   static void error(String error, int tabs) {}
/*    */   
/*    */   static void info(String info, int tabs) {}
/*    */   
/*    */   static void abreTag(boolean resultado) {}
/*    */   
/*    */   static void cierraTag(boolean resultado) {}
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\logv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */