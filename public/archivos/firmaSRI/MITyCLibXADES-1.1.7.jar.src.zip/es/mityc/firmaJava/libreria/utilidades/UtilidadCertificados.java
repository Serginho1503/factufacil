/*     */ package es.mityc.firmaJava.libreria.utilidades;
/*     */ 
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.SignatureException;
/*     */ import java.security.cert.CertPath;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.CertificateParsingException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.bouncycastle.asn1.x509.X509Name;
/*     */ import org.bouncycastle.jce.X509Principal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UtilidadCertificados
/*     */ {
/*  47 */   private static final Log logger = LogFactory.getLog(UtilidadCertificados.class);
/*     */   
/*  49 */   public static enum Filter { SIGN_SIGNER,  CRL_SIGNER,  OCSP_SIGNER,  TS_SIGNER;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String OID_OCSP_SIGNING = "1.3.6.1.5.5.7.3.9";
/*     */   
/*     */ 
/*     */   public static ArrayList<CertPath> getCertPaths(Iterable<X509Certificate> certificates)
/*     */   {
/*  60 */     ArrayList<ArrayList<X509Certificate>> list = getCertPathsArray(certificates);
/*  61 */     ArrayList<CertPath> certPaths = new ArrayList();
/*  62 */     Iterator<ArrayList<X509Certificate>> itArrays = list.iterator();
/*  63 */     while (itArrays.hasNext()) {
/*  64 */       CertPath cp = convertCertPath((ArrayList)itArrays.next());
/*  65 */       if (cp != null)
/*  66 */         certPaths.add(cp);
/*     */     }
/*  68 */     return certPaths;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ArrayList<ArrayList<X509Certificate>> getCertPathsArray(Iterable<X509Certificate> certificates)
/*     */   {
/*  78 */     ArrayList<ArrayList<X509Certificate>> certPaths = new ArrayList();
/*  79 */     if (certificates != null)
/*     */     {
/*  81 */       ArrayList<NTo1Link<X509Certificate>> list = new ArrayList();
/*  82 */       Iterator<X509Certificate> itCerts = certificates.iterator();
/*  83 */       while (itCerts.hasNext()) {
/*  84 */         NTo1Link<X509Certificate> nodo = new NTo1Link((X509Certificate)itCerts.next());
/*  85 */         if (!list.contains(nodo)) {
/*  86 */           list.add(nodo);
/*     */         }
/*     */       }
/*  89 */       for (int i = 0; i < list.size(); i++) {
/*  90 */         for (int j = i + 1; j < list.size(); j++) {
/*  91 */           linkCerts((NTo1Link)list.get(i), (NTo1Link)list.get(j));
/*     */         }
/*     */       }
/*     */       
/*  95 */       Iterator<NTo1Link<X509Certificate>> itNodos = list.iterator();
/*  96 */       while (itNodos.hasNext()) {
/*  97 */         NTo1Link<X509Certificate> nodo = (NTo1Link)itNodos.next();
/*  98 */         if (nodo.getNumPrevs() == 0) {
/*  99 */           ArrayList<X509Certificate> cp = convertCertPathArray(nodo);
/* 100 */           if (cp != null)
/* 101 */             certPaths.add(cp);
/*     */         }
/*     */       }
/*     */     }
/* 105 */     return certPaths;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ArrayList<ArrayList<X509Certificate>> filterCertPathsArrays(ArrayList<ArrayList<X509Certificate>> list, Filter filter)
/*     */   {
/* 116 */     ArrayList<ArrayList<X509Certificate>> result = new ArrayList();
/* 117 */     Iterator<ArrayList<X509Certificate>> it = list.iterator();
/* 118 */     while (it.hasNext()) {
/* 119 */       ArrayList<X509Certificate> certs = (ArrayList)it.next();
/* 120 */       if ((certs != null) && (certs.size() > 0)) {
/* 121 */         if (Filter.OCSP_SIGNER.equals(filter)) {
/* 122 */           if (isOCSPSigning((X509Certificate)certs.get(0))) {
/* 123 */             result.add(certs);
/*     */           }
/* 125 */         } else if (Filter.TS_SIGNER.equals(filter)) {
/* 126 */           if (isTSSigning((X509Certificate)certs.get(0))) {
/* 127 */             result.add(certs);
/*     */           }
/* 129 */         } else if (Filter.CRL_SIGNER.equals(filter)) {
/* 130 */           if (isCRLSigning((X509Certificate)certs.get(0))) {
/* 131 */             result.add(certs);
/*     */           }
/* 133 */         } else if (Filter.SIGN_SIGNER.equals(filter)) {
/* 134 */           result.add(certs);
/*     */         }
/*     */       }
/*     */     }
/* 138 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CertPath orderCertPath(Iterable<X509Certificate> certificates)
/*     */   {
/* 148 */     CertPath cp = null;
/* 149 */     if (certificates != null)
/*     */     {
/* 151 */       ArrayList<NTo1Link<X509Certificate>> list = new ArrayList();
/* 152 */       Iterator<X509Certificate> itCerts = certificates.iterator();
/* 153 */       while (itCerts.hasNext()) {
/* 154 */         NTo1Link<X509Certificate> nodo = new NTo1Link((X509Certificate)itCerts.next());
/* 155 */         if (!list.contains(nodo)) {
/* 156 */           list.add(nodo);
/*     */         }
/*     */       }
/* 159 */       for (int i = 0; i < list.size(); i++) {
/* 160 */         for (int j = i + 1; j < list.size(); j++) {
/* 161 */           linkCerts((NTo1Link)list.get(i), (NTo1Link)list.get(j));
/*     */         }
/*     */       }
/*     */       
/* 165 */       Iterator<NTo1Link<X509Certificate>> itNodos = list.iterator();
/* 166 */       while (itNodos.hasNext()) {
/* 167 */         NTo1Link<X509Certificate> nodo = (NTo1Link)itNodos.next();
/* 168 */         if (nodo.getNumPrevs() == 0) {
/* 169 */           ArrayList<X509Certificate> cpa = convertCertPathArray(nodo);
/* 170 */           if (cpa != null)
/* 171 */             cp = convertCertPath(cpa);
/*     */         }
/*     */       }
/*     */     }
/* 175 */     return cp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isOCSPSigning(X509Certificate cert)
/*     */   {
/*     */     try
/*     */     {
/* 185 */       List<String> list = cert.getExtendedKeyUsage();
/* 186 */       if (list != null) {
/* 187 */         Iterator<String> it = list.iterator();
/* 188 */         while (it.hasNext()) {
/* 189 */           if ("1.3.6.1.5.5.7.3.9".equals(it.next())) {
/* 190 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (CertificateParsingException localCertificateParsingException) {}
/* 195 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isTSSigning(X509Certificate cert)
/*     */   {
/*     */     try
/*     */     {
/* 205 */       List<String> list = cert.getExtendedKeyUsage();
/* 206 */       if (list != null) {
/* 207 */         Iterator<String> it = list.iterator();
/* 208 */         while (it.hasNext()) {
/* 209 */           if ("1.3.6.1.5.5.7.3.8".equals(it.next())) {
/* 210 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (CertificateParsingException localCertificateParsingException) {}
/* 215 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isCRLSigning(X509Certificate cert)
/*     */   {
/* 224 */     boolean[] usage = cert.getKeyUsage();
/* 225 */     if ((cert != null) && (usage[6] != 0))
/* 226 */       return true;
/* 227 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String OID_TS_SIGNING = "1.3.6.1.5.5.7.3.8";
/*     */   
/*     */ 
/*     */ 
/*     */   private static void linkCerts(NTo1Link<X509Certificate> nodo1, NTo1Link<X509Certificate> nodo2)
/*     */   {
/* 240 */     if (((X509Certificate)nodo1.getData()).getIssuerX500Principal().equals(((X509Certificate)nodo2.getData()).getSubjectX500Principal()))
/*     */     {
/*     */       try {
/* 243 */         ((X509Certificate)nodo1.getData()).verify(((X509Certificate)nodo2.getData()).getPublicKey());
/*     */       } catch (InvalidKeyException ex) {
/* 245 */         return;
/*     */       } catch (CertificateException ex) {
/* 247 */         return;
/*     */       } catch (NoSuchAlgorithmException ex) {
/* 249 */         return;
/*     */       } catch (NoSuchProviderException ex) {
/* 251 */         return;
/*     */       } catch (SignatureException ex) {
/* 253 */         return;
/*     */       }
/*     */       
/* 256 */       nodo1.setNext(nodo2);
/* 257 */       nodo2.addPrev(nodo1);
/* 258 */     } else if (((X509Certificate)nodo2.getData()).getIssuerX500Principal().equals(((X509Certificate)nodo1.getData()).getSubjectX500Principal()))
/*     */     {
/*     */       try {
/* 261 */         ((X509Certificate)nodo2.getData()).verify(((X509Certificate)nodo1.getData()).getPublicKey());
/*     */       } catch (InvalidKeyException ex) {
/* 263 */         return;
/*     */       } catch (CertificateException ex) {
/* 265 */         return;
/*     */       } catch (NoSuchAlgorithmException ex) {
/* 267 */         return;
/*     */       } catch (NoSuchProviderException ex) {
/* 269 */         return;
/*     */       } catch (SignatureException ex) {
/* 271 */         return;
/*     */       }
/*     */       
/* 274 */       nodo2.setNext(nodo1);
/* 275 */       nodo1.addPrev(nodo2);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CertPath convertCertPath(Certificate[] certs)
/*     */   {
/* 285 */     if (certs == null)
/* 286 */       return null;
/* 287 */     ArrayList<X509Certificate> input = new ArrayList();
/* 288 */     for (int i = 0; i < certs.length; i++) {
/* 289 */       if ((certs[i] instanceof X509Certificate)) {
/* 290 */         input.add((X509Certificate)certs[i]);
/*     */       } else {
/*     */         try {
/* 293 */           input.add((X509Certificate)certs[i]);
/*     */         } catch (Exception e) {
/* 295 */           logger.debug("El certificado no es de tipo X509", e);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 300 */     return convertCertPath(input);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CertPath convertCertPath(ArrayList<X509Certificate> certs)
/*     */   {
/* 309 */     CertPath cp = null;
/*     */     try {
/* 311 */       CertificateFactory cf = CertificateFactory.getInstance("X.509");
/* 312 */       cp = cf.generateCertPath(certs);
/*     */     } catch (CertificateException ex) {
/* 314 */       logger.error("Error al intentar generar CertPaths", ex);
/*     */     }
/* 316 */     return cp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ArrayList<X509Certificate> convertCertPathArray(NTo1Link<X509Certificate> nodo)
/*     */   {
/* 325 */     ArrayList<X509Certificate> certs = new ArrayList();
/* 326 */     Iterator<NTo1Link<X509Certificate>> itNodo = nodo.iterator();
/* 327 */     while (itNodo.hasNext()) {
/* 328 */       certs.add((X509Certificate)((NTo1Link)itNodo.next()).getData());
/*     */     }
/* 330 */     return certs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getCN(X500Principal dname)
/*     */   {
/* 340 */     String retorno = null;
/* 341 */     X509Principal nombre = new X509Principal(dname.getName());
/*     */     
/*     */ 
/* 344 */     Vector<?> commonNameOIDs = nombre.getOIDs();
/* 345 */     Vector<?> commonName = nombre.getValues();
/* 346 */     int longitudValues = commonName.size();
/*     */     
/* 348 */     if (longitudValues != 0)
/*     */     {
/* 350 */       int indexCN = commonNameOIDs.indexOf(X509Name.CN);
/* 351 */       if (indexCN != -1) {
/* 352 */         Object elemento = commonName.get(indexCN);
/* 353 */         if ((elemento instanceof String)) {
/* 354 */           retorno = (String)elemento;
/*     */         }
/*     */       }
/*     */     }
/* 358 */     return retorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isSameName(X500Principal prin1, X500Principal prin2)
/*     */   {
/* 368 */     X509Name name1 = new X509Name(prin1.getName());
/* 369 */     X509Name name2 = new X509Name(prin2.getName());
/* 370 */     return name1.equals(name2);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\utilidades\UtilidadCertificados.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */