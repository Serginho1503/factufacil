/*    */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*    */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*    */ import es.mityc.javasign.xml.xades.policy.PolicyException;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SPUserNotice
/*    */   extends SPUserNoticeType
/*    */   implements IPolicyQualifier
/*    */ {
/*    */   public SPUserNotice(XAdESSchemas schema)
/*    */   {
/* 39 */     super(schema);
/*    */   }
/*    */   
/*    */   public void load(Element element) throws InvalidInfoNodeException
/*    */   {
/* 44 */     checkElementName(element, this.schema.getSchemaUri(), "SPUserNotice");
/* 45 */     super.load(element);
/*    */   }
/*    */   
/*    */   public boolean isThisNode(Node node)
/*    */   {
/* 50 */     return isElementName(nodeToElement(node), this.schema.getSchemaUri(), "SPUserNotice");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Element createElement(Document doc, String namespaceXAdES)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 58 */     return super.createElement(doc, namespaceXAdES);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected Element createElement(Document doc)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 66 */     Element res = doc.createElementNS(this.schema.getSchemaUri(), this.namespaceXAdES + ":" + "SPUserNotice");
/* 67 */     super.addContent(res, this.namespaceXAdES);
/* 68 */     return res;
/*    */   }
/*    */   
/*    */   public Node createPolicyQualifierContent(Document doc) throws PolicyException {
/* 72 */     Element el = null;
/*    */     try {
/* 74 */       if (getNamespaceXAdES() != null) {
/* 75 */         el = createElement(doc, this.namespaceXAdES);
/*    */       } else
/* 77 */         throw new PolicyException("No se ha indicado qualifier para nodo SPUserNotice");
/*    */     } catch (InvalidInfoNodeException ex) {
/* 79 */       throw new PolicyException(ex);
/*    */     }
/* 81 */     return el;
/*    */   }
/*    */   
/*    */   public void loadPolicyQualifierContent(Element element) throws PolicyException {
/*    */     try {
/* 86 */       load(element);
/*    */     } catch (InvalidInfoNodeException ex) {
/* 88 */       throw new PolicyException(ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\SPUserNotice.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */