/*    */ package es.mityc.firmaJava.libreria.utilidades;
/*    */ 
/*    */ import java.text.ParseException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UtilidadFechas
/*    */ {
/*    */   private static final String FORMATO_FECHA_CON_MILIS = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";
/*    */   private static final String FORMATO_FECHA_SIN_MILIS = "yyyy-MM-dd'T'HH:mm:ssZ";
/*    */   
/*    */   public static Date parseaFechaXML(String fecha)
/*    */   {
/* 42 */     if (fecha == null) {
/* 43 */       return null;
/*    */     }
/* 45 */     String res = new String(fecha);
/*    */     
/*    */ 
/* 48 */     int t = res.indexOf("T");
/* 49 */     if (t == -1) {
/* 50 */       return null;
/*    */     }
/* 52 */     t = res.indexOf(":", t);
/* 53 */     if (t == -1)
/* 54 */       return null;
/* 55 */     t = res.indexOf(":", t + 1);
/* 56 */     if (t == -1)
/* 57 */       return null;
/*    */     String formato;
/*    */     String formato;
/* 60 */     if (res.indexOf(".", t) > -1) {
/* 61 */       formato = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";
/*    */     } else {
/* 63 */       formato = "yyyy-MM-dd'T'HH:mm:ssZ";
/*    */     }
/*    */     
/* 66 */     if ((res.indexOf(":", t + 1) == -1) && (!res.endsWith("Z"))) {
/* 67 */       res = res.concat("Z");
/*    */     }
/*    */     
/* 70 */     if (res.endsWith("Z")) {
/* 71 */       res = res.replace("Z", "+0000");
/*    */     }
/*    */     else {
/* 74 */       res = res.substring(0, res.length() - 3).concat(res.substring(res.length() - 2));
/*    */     }
/* 76 */     SimpleDateFormat sdf = new SimpleDateFormat(formato);
/*    */     try {
/* 78 */       return sdf.parse(res);
/*    */     }
/*    */     catch (ParseException localParseException) {}
/*    */     
/* 82 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String formatFechaXML(Date fecha)
/*    */   {
/* 92 */     SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
/* 93 */     String resultado = sdf.format(fecha);
/*    */     
/* 95 */     resultado = resultado.substring(0, resultado.length() - 2).concat(":").concat(resultado.substring(resultado.length() - 2));
/* 96 */     return resultado;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\utilidades\UtilidadFechas.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */