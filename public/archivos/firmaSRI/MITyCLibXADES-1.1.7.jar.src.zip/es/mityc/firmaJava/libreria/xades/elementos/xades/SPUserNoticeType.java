/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SPUserNoticeType
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private NoticeRef noticeRef;
/*     */   private ExplicitText explicitText;
/*     */   
/*     */   public SPUserNoticeType(XAdESSchemas schema)
/*     */   {
/*  39 */     super(schema);
/*     */   }
/*     */   
/*     */   public NoticeRef getNoticeRef() {
/*  43 */     return this.noticeRef;
/*     */   }
/*     */   
/*     */   public void setNoticeRef(NoticeRef noticeRef) {
/*  47 */     this.noticeRef = noticeRef;
/*     */   }
/*     */   
/*     */   public void setNoticeRef(String organization, int[] numbers) {
/*  51 */     this.noticeRef = new NoticeRef(this.schema, organization, numbers);
/*     */   }
/*     */   
/*     */   public String getExplicitText() {
/*  55 */     if (this.explicitText != null) {
/*  56 */       return this.explicitText.getValue();
/*     */     }
/*  58 */     return null;
/*     */   }
/*     */   
/*     */   public void setExplicitText(String explicitText) {
/*  62 */     this.explicitText = new ExplicitText(this.schema, explicitText);
/*     */   }
/*     */   
/*     */   public void addContent(Element element, String namespaceXAdES) throws InvalidInfoNodeException
/*     */   {
/*  67 */     super.addContent(element, namespaceXAdES);
/*     */   }
/*     */   
/*     */   protected void addContent(Element element) throws InvalidInfoNodeException
/*     */   {
/*  72 */     if (this.noticeRef != null)
/*  73 */       element.appendChild(this.noticeRef.createElement(element.getOwnerDocument(), this.namespaceXAdES));
/*  74 */     if (this.explicitText != null) {
/*  75 */       element.appendChild(this.explicitText.createElement(element.getOwnerDocument(), this.namespaceXAdES));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  83 */     if ((obj instanceof SPUserNoticeType)) {
/*  84 */       SPUserNoticeType sppt = (SPUserNoticeType)obj;
/*  85 */       if (this.noticeRef == null) {
/*  86 */         if (sppt.noticeRef != null) {
/*  87 */           return false;
/*     */         }
/*  89 */       } else if (!this.noticeRef.equals(sppt.noticeRef))
/*  90 */         return false;
/*  91 */       if (this.explicitText == null) {
/*  92 */         if (sppt.explicitText != null) {
/*  93 */           return false;
/*     */         }
/*  95 */       } else if (!this.explicitText.equals(sppt.explicitText)) {
/*  96 */         return false;
/*     */       }
/*  98 */       return true;
/*     */     }
/* 100 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 108 */     Node node = getFirstNonvoidNode(element);
/*     */     
/*     */ 
/* 111 */     if (node == null)
/* 112 */       return;
/* 113 */     if (node.getNodeType() != 1)
/* 114 */       throw new InvalidInfoNodeException("Se esperaba elemento como hijo de SPUserNoticeType");
/* 115 */     Element child = (Element)node;
/* 116 */     NoticeRef noticeTemp = new NoticeRef(this.schema);
/* 117 */     if (noticeTemp.isThisNode(child)) {
/* 118 */       noticeTemp.load(child);
/* 119 */       this.noticeRef = noticeTemp;
/* 120 */       node = getNextNonvoidNode(node);
/*     */     } else {
/* 122 */       this.noticeRef = null;
/*     */     }
/*     */     
/* 125 */     if (node == null)
/* 126 */       return;
/* 127 */     if (node.getNodeType() != 1)
/* 128 */       throw new InvalidInfoNodeException("Se esperaba elemento como hijo de SPUserNoticeType");
/* 129 */     child = (Element)node;
/* 130 */     ExplicitText explicitTemp = new ExplicitText(this.schema);
/* 131 */     if (explicitTemp.isThisNode(child)) {
/* 132 */       explicitTemp.load(child);
/* 133 */       this.explicitText = explicitTemp;
/* 134 */       node = getNextNonvoidNode(node);
/*     */     } else {
/* 136 */       this.explicitText = null;
/*     */     }
/* 138 */     if (node != null) {
/* 139 */       throw new InvalidInfoNodeException("No se esperaba este elemento como hijo de SPUserNoticeType");
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\SPUserNoticeType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */