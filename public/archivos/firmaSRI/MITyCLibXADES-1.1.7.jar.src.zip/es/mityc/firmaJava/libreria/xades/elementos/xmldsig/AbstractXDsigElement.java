/*    */ package es.mityc.firmaJava.libreria.xades.elementos.xmldsig;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.xades.elementos.AbstractXMLElement;
/*    */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractXDsigElement
/*    */   extends AbstractXMLElement
/*    */ {
/*    */   protected String namespaceXDsig;
/*    */   
/*    */   protected Element createElement(Document doc, String namespaceXDsig)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 47 */     setNamespaceXDsig(namespaceXDsig);
/* 48 */     return createElement(doc);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void addContent(Element element, String namespaceXDsig)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 60 */     setNamespaceXDsig(namespaceXDsig);
/* 61 */     addContent(element);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getNamespaceXDsig()
/*    */   {
/* 68 */     return this.namespaceXDsig;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setNamespaceXDsig(String namespaceXDsig)
/*    */   {
/* 75 */     this.namespaceXDsig = namespaceXDsig;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xmldsig\AbstractXDsigElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */