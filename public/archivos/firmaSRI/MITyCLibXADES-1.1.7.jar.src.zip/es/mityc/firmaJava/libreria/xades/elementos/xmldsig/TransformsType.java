/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xmldsig;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransformsType
/*     */   extends AbstractXDsigElement
/*     */ {
/*     */   private ArrayList<Transform> list;
/*     */   
/*     */   public TransformsType() {}
/*     */   
/*     */   public TransformsType(ArrayList<Transform> list)
/*     */   {
/*  40 */     this.list = list;
/*     */   }
/*     */   
/*     */   public void addTransform(Transform transform) {
/*  44 */     if (this.list == null)
/*  45 */       this.list = new ArrayList();
/*  46 */     this.list.add(transform);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addContent(Element element, String namespaceXDsig)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  54 */     super.addContent(element, namespaceXDsig);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void addContent(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  62 */     if ((this.list == null) || (this.list.size() < 1))
/*  63 */       throw new InvalidInfoNodeException("Información insuficiente para escribir nodo TransformsType");
/*  64 */     Iterator<Transform> it = this.list.iterator();
/*  65 */     while (it.hasNext()) {
/*  66 */       element.appendChild(((Transform)it.next()).createElement(element.getOwnerDocument(), this.namespaceXDsig));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  75 */     if ((obj instanceof TransformType)) {
/*  76 */       TransformsType tt = (TransformsType)obj;
/*  77 */       ArrayList<Transform> comp = tt.list;
/*  78 */       if (((this.list == null) || (this.list.isEmpty())) && (
/*  79 */         (comp == null) || (comp.isEmpty())))
/*  80 */         return true;
/*  81 */       if ((this.list != null) && (comp != null) && 
/*  82 */         (this.list.size() == comp.size())) {
/*  83 */         Iterator<Transform> itThis = this.list.iterator();
/*  84 */         Iterator<Transform> itComp = comp.iterator();
/*  85 */         while (itThis.hasNext()) {
/*  86 */           if (!((Transform)itThis.next()).equals(itComp.next()))
/*  87 */             return false;
/*     */         }
/*  89 */         return true;
/*     */       }
/*     */     }
/*  92 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 100 */     NodeList nodos = element.getChildNodes();
/*     */     
/* 102 */     ArrayList<Transform> temp = new ArrayList(nodos.getLength());
/* 103 */     for (int i = 0; i < nodos.getLength(); i++) {
/* 104 */       Node nodo = nodos.item(i);
/* 105 */       if (!isDecorationNode(nodo))
/*     */       {
/*     */ 
/* 108 */         if (nodo.getNodeType() != 1) {
/* 109 */           throw new InvalidInfoNodeException("Hijo de Transforms no es un elemento");
/*     */         }
/* 111 */         Transform transform = new Transform();
/* 112 */         transform.load((Element)nodo);
/* 113 */         temp.add(transform);
/*     */       } }
/* 115 */     if (temp.size() == 0) {
/* 116 */       throw new InvalidInfoNodeException("Un nodo Trasforms debe tener al menos un hijo Transform");
/*     */     }
/* 118 */     this.list = temp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ArrayList<Transform> getList()
/*     */   {
/* 125 */     return this.list;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setList(ArrayList<Transform> list)
/*     */   {
/* 132 */     this.list = list;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xmldsig\TransformsType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */