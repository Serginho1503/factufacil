/*    */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*    */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*    */ import java.net.URI;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Identifier
/*    */   extends IdentifierType
/*    */ {
/*    */   public Identifier(XAdESSchemas schema)
/*    */   {
/* 38 */     super(schema);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Identifier(XAdESSchemas schema, URI uri)
/*    */   {
/* 47 */     super(schema, uri, null);
/*    */   }
/*    */   
/*    */   public Identifier(XAdESSchemas schema, URI uri, QualifierEnum qualifier) {
/* 51 */     super(schema, uri, qualifier);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void load(Element element)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 59 */     checkElementName(element, this.schema.getSchemaUri(), "Identifier");
/* 60 */     super.load(element);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected Element createElement(Document doc)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 68 */     Element res = doc.createElementNS(this.schema.getSchemaUri(), this.namespaceXAdES + ":" + "Identifier");
/* 69 */     super.addContent(res);
/* 70 */     return res;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Element createElement(Document doc, String namespaceXAdES)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 78 */     return super.createElement(doc, namespaceXAdES);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\Identifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */