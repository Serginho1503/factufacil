/*     */ package es.mityc.firmaJava.libreria.utilidades;
/*     */ 
/*     */ import com.sun.org.apache.xerces.internal.dom.DOMOutputImpl;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import org.w3c.dom.DOMConfiguration;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.ls.DOMImplementationLS;
/*     */ import org.w3c.dom.ls.LSSerializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UtilidadFicheros
/*     */ {
/*     */   public static byte[] readFile(File file)
/*     */   {
/*  42 */     FileInputStream fis = null;
/*     */     try {
/*  44 */       fis = new FileInputStream(file);
/*  45 */       int length = (int)file.length();
/*  46 */       ByteArrayOutputStream baos = new ByteArrayOutputStream(length);
/*  47 */       byte[] buffer = new byte['က'];
/*  48 */       int i = 0;
/*  49 */       while (i < length) {
/*  50 */         int j = fis.read(buffer);
/*  51 */         baos.write(buffer, 0, j);
/*  52 */         i += j;
/*     */       }
/*  54 */       return baos.toByteArray();
/*     */     }
/*     */     catch (FileNotFoundException localFileNotFoundException) {}catch (IOException localIOException2) {}finally
/*     */     {
/*  58 */       if (fis != null) {
/*     */         try {
/*  60 */           fis.close();
/*     */         }
/*     */         catch (IOException localIOException4) {}
/*     */       }
/*     */     }
/*  65 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String relativizeRute(String baseUri, File file)
/*     */   {
/*  75 */     String strFile = null;
/*     */     try {
/*  77 */       URI relative = new URI(URIEncoder.encode(baseUri, "UTF-8"));
/*  78 */       URI uri = file.toURI();
/*  79 */       strFile = URIEncoder.relativize(relative.toString(), uri.toString());
/*     */     } catch (UnsupportedEncodingException e) {
/*  81 */       strFile = file.toURI().toString();
/*     */     } catch (URISyntaxException e) {
/*  83 */       strFile = file.toURI().toString();
/*     */     }
/*     */     
/*  86 */     return strFile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void writeXML(Document doc, OutputStream out)
/*     */   {
/*  95 */     OutputStreamWriter osw = new OutputStreamWriter(out);
/*     */     
/*  97 */     DOMOutputImpl domoutputimpl = new DOMOutputImpl();
/*  98 */     domoutputimpl.setEncoding(doc.getXmlEncoding());
/*  99 */     domoutputimpl.setCharacterStream(osw);
/*     */     
/*     */ 
/*     */ 
/* 103 */     DOMImplementationLS dils = (DOMImplementationLS)doc.getImplementation();
/* 104 */     LSSerializer serializer = dils.createLSSerializer();
/* 105 */     serializer.getDomConfig().setParameter("namespaces", Boolean.valueOf(false));
/* 106 */     serializer.getDomConfig().getParameterNames();
/* 107 */     serializer.write(doc, domoutputimpl);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\utilidades\UtilidadFicheros.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */