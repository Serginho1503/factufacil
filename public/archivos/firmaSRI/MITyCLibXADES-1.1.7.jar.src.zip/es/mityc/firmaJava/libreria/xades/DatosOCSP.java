/*     */ package es.mityc.firmaJava.libreria.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.utilidades.Base64Coder;
/*     */ import es.mityc.firmaJava.trust.ConfianzaEnum;
/*     */ import es.mityc.javasign.certificate.ICertStatus;
/*     */ import es.mityc.javasign.certificate.ICertStatus.CERT_STATUS;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Date;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ import org.bouncycastle.asn1.ASN1OctetString;
/*     */ import org.bouncycastle.asn1.ASN1TaggedObject;
/*     */ import org.bouncycastle.asn1.ocsp.ResponderID;
/*     */ import org.bouncycastle.asn1.x509.X509Name;
/*     */ import org.bouncycastle.jce.X509Principal;
/*     */ import org.bouncycastle.ocsp.BasicOCSPResp;
/*     */ import org.bouncycastle.ocsp.OCSPResp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DatosOCSP
/*     */ {
/*  41 */   private ResponderID responderId = null;
/*  42 */   private String responderIdName = null;
/*  43 */   private Date fechaConsulta = null;
/*  44 */   private String certConsultado = null;
/*  45 */   private OCSPResp respuestaOCSP = null;
/*  46 */   private BasicOCSPResp basicOCSPResp = null;
/*  47 */   private ConfianzaEnum esCertConfianza = ConfianzaEnum.NO_REVISADO;
/*  48 */   private ICertStatus.CERT_STATUS revockedStatus = ICertStatus.CERT_STATUS.unknown;
/*  49 */   private ICertStatus status = null;
/*  50 */   private X509Certificate[] certOCSPResponder = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DatosOCSP() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DatosOCSP(ResponderID responderId, Date fechaConsulta, String certConsultado, OCSPResp respuestaOCSP, ConfianzaEnum esCertConfianza, X509Certificate[] certOCSPResponder)
/*     */   {
/*  70 */     this.responderId = responderId;
/*  71 */     updateResponderIDName(responderId);
/*  72 */     this.fechaConsulta = fechaConsulta;
/*  73 */     this.certConsultado = certConsultado;
/*  74 */     this.respuestaOCSP = respuestaOCSP;
/*  75 */     this.esCertConfianza = esCertConfianza;
/*  76 */     this.esCertConfianza = esCertConfianza;
/*  77 */     this.certOCSPResponder = certOCSPResponder;
/*     */   }
/*     */   
/*     */ 
/*  81 */   public ResponderID getResponderId() { return this.responderId; }
/*     */   
/*     */   public void setResponderId(ResponderID responderId) {
/*  84 */     this.responderId = responderId;
/*  85 */     updateResponderIDName(responderId);
/*     */   }
/*     */   
/*  88 */   private void updateResponderIDName(ResponderID responderId) { if (responderId != null) {
/*  89 */       ASN1TaggedObject tagged = (ASN1TaggedObject)responderId.toASN1Object();
/*  90 */       switch (tagged.getTagNo()) {
/*     */       case 1: 
/*  92 */         X509Principal certX509Principal = new X509Principal(X509Name.getInstance(tagged.getObject()).toString());
/*  93 */         X500Principal cerX500Principal = new X500Principal(certX509Principal.getDEREncoded());
/*  94 */         this.responderIdName = cerX500Principal.getName();
/*  95 */         break;
/*     */       case 2: 
/*  97 */         ASN1OctetString octect = (ASN1OctetString)tagged.getObject();
/*  98 */         this.responderIdName = new String(Base64Coder.encode(octect.getOctets()));
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 103 */       this.responderIdName = null;
/*     */     } }
/*     */   
/* 106 */   public String getResponderIdName() { return this.responderIdName; }
/*     */   
/*     */   public String getCertConsultado() {
/* 109 */     return this.certConsultado;
/*     */   }
/*     */   
/* 112 */   public void setCertConsultado(String certConsultado) { this.certConsultado = certConsultado; }
/*     */   
/*     */   public Date getFechaConsulta() {
/* 115 */     return this.fechaConsulta;
/*     */   }
/*     */   
/* 118 */   public void setFechaConsulta(Date fechaConsulta) { this.fechaConsulta = fechaConsulta; }
/*     */   
/*     */   public OCSPResp getRespuestaOCSP() {
/* 121 */     return this.respuestaOCSP;
/*     */   }
/*     */   
/* 124 */   public void setRespuestaOCSP(OCSPResp respuestaOCSP) { this.respuestaOCSP = respuestaOCSP; }
/*     */   
/*     */   public ConfianzaEnum esCertConfianza() {
/* 127 */     return this.esCertConfianza;
/*     */   }
/*     */   
/* 130 */   public void setEsCertConfianza(ConfianzaEnum esCertConfianza) { this.esCertConfianza = esCertConfianza; }
/*     */   
/*     */   public X509Certificate[] getCertOCSPResponder() {
/* 133 */     return this.certOCSPResponder;
/*     */   }
/*     */   
/* 136 */   public void setCertOCSPResponder(X509Certificate[] certOCSPResponder) { this.certOCSPResponder = certOCSPResponder; }
/*     */   
/*     */   public ICertStatus.CERT_STATUS getRevockedStatus() {
/* 139 */     return this.revockedStatus;
/*     */   }
/*     */   
/* 142 */   public void setRevockedStatus(ICertStatus.CERT_STATUS revockedStatus) { this.revockedStatus = revockedStatus; }
/*     */   
/*     */   public BasicOCSPResp getBasicRespuestaOCSP() {
/* 145 */     return this.basicOCSPResp;
/*     */   }
/*     */   
/* 148 */   public void setBasicRespuestaOCSP(BasicOCSPResp basicOCSPResp) { this.basicOCSPResp = basicOCSPResp; }
/*     */   
/*     */   public ICertStatus getStatus() {
/* 151 */     return this.status;
/*     */   }
/*     */   
/* 154 */   public void setStatus(ICertStatus status) { this.status = status; }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\DatosOCSP.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */