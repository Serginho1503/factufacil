/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xmldsig;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.XMLDataIntegerType;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.math.BigInteger;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AbstractXDsigIntegerElement
/*     */   extends AbstractXDsigElement
/*     */ {
/*     */   private XMLDataIntegerType data;
/*     */   private String nameElement;
/*     */   
/*     */   public AbstractXDsigIntegerElement(String nameElement, BigInteger data)
/*     */   {
/*  39 */     this.nameElement = nameElement;
/*  40 */     this.data = new XMLDataIntegerType(data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractXDsigIntegerElement(String nameElement)
/*     */   {
/*  48 */     this.nameElement = nameElement;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Element createElement(Document doc)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  56 */     if (this.data == null) {
/*  57 */       throw new InvalidInfoNodeException("Información insuficiente para escribir elemento " + this.nameElement);
/*     */     }
/*  59 */     Element res = doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", this.namespaceXDsig + ":" + this.nameElement);
/*  60 */     this.data.addContent(res);
/*  61 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Element createElement(Document doc, String namespaceXDsig)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  69 */     return super.createElement(doc, namespaceXDsig);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  77 */     if ((obj instanceof AbstractXDsigIntegerElement)) {
/*  78 */       AbstractXDsigIntegerElement desc = (AbstractXDsigIntegerElement)obj;
/*  79 */       if ((this.nameElement.equals(desc.nameElement)) && (this.data.equals(desc.data))) {
/*  80 */         return true;
/*     */       }
/*     */     } else {
/*  83 */       return this.data.equals(obj);
/*     */     }
/*  85 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  93 */     checkElementName(element, "http://www.w3.org/2000/09/xmldsig#", this.nameElement);
/*  94 */     this.data = new XMLDataIntegerType(null);
/*  95 */     this.data.load(element);
/*     */   }
/*     */   
/*     */   public void setValue(BigInteger value) {
/*  99 */     if (this.data == null) {
/* 100 */       this.data = new XMLDataIntegerType(value);
/*     */     } else {
/* 102 */       this.data.setValue(value);
/*     */     }
/*     */   }
/*     */   
/*     */   public BigInteger getValue() {
/* 107 */     if (this.data != null) {
/* 108 */       return this.data.getValue();
/*     */     }
/* 110 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isThisNode(Node node)
/*     */   {
/* 118 */     return isElementName(nodeToElement(node), "http://www.w3.org/2000/09/xmldsig#", this.nameElement);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xmldsig\AbstractXDsigIntegerElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */