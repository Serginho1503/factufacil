/*    */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*    */ import java.net.URI;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Encoding
/*    */   extends AbstractXadesURIElement
/*    */ {
/*    */   public Encoding(XAdESSchemas schema, URI data)
/*    */   {
/* 34 */     super(schema, "Encoding", data);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Encoding(XAdESSchemas schema)
/*    */   {
/* 42 */     super(schema, "Encoding");
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\Encoding.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */