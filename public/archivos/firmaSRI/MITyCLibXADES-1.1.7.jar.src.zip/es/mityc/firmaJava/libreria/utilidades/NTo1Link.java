/*     */ package es.mityc.firmaJava.libreria.utilidades;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NTo1Link<E>
/*     */   implements Iterable<NTo1Link<E>>
/*     */ {
/*     */   private ArrayList<NTo1Link<E>> prevs;
/*     */   private NTo1Link<E> next;
/*     */   private E data;
/*     */   
/*     */   public NTo1Link(E obj)
/*     */   {
/*  33 */     this.data = obj;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/*  38 */     Object comp = obj;
/*  39 */     if ((obj instanceof NTo1Link)) {
/*  40 */       comp = ((NTo1Link)obj).getData();
/*     */     }
/*  42 */     if ((comp != null) && (comp.equals(this.data))) {
/*  43 */       return true;
/*     */     }
/*  45 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setData(E obj)
/*     */   {
/*  53 */     this.data = obj;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public E getData()
/*     */   {
/*  61 */     return (E)this.data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addPrev(NTo1Link<E> node)
/*     */   {
/*  69 */     if (this.prevs == null)
/*  70 */       this.prevs = new ArrayList();
/*  71 */     this.prevs.add(node);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator<NTo1Link<E>> getPrevs()
/*     */   {
/*  79 */     if (this.prevs != null)
/*  80 */       return this.prevs.iterator();
/*  81 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumPrevs()
/*     */   {
/*  89 */     if (this.prevs != null)
/*  90 */       return this.prevs.size();
/*  91 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNext(NTo1Link<E> node)
/*     */   {
/*  99 */     this.next = node;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NTo1Link<E> getNext()
/*     */   {
/* 107 */     return this.next;
/*     */   }
/*     */   
/*     */   public Iterator<NTo1Link<E>> iterator() {
/* 111 */     return new NTo1LinkIterator(this);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\utilidades\NTo1Link.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */