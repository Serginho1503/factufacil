/*    */ package es.mityc.firmaJava.libreria.xades.elementos.xmldsig;
/*    */ 
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class X509SerialNumber
/*    */   extends AbstractXDsigIntegerElement
/*    */ {
/*    */   public X509SerialNumber(BigInteger data)
/*    */   {
/* 31 */     super("X509SerialNumber", data);
/*    */   }
/*    */   
/*    */   public X509SerialNumber() {
/* 35 */     super("X509SerialNumber");
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xmldsig\X509SerialNumber.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */