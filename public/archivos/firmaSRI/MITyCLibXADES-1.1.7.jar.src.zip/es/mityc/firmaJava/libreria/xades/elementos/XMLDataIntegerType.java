/*    */ package es.mityc.firmaJava.libreria.xades.elementos;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*    */ import java.math.BigInteger;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMLDataIntegerType
/*    */   extends AbstractXMLElement
/*    */ {
/*    */   protected BigInteger value;
/*    */   
/*    */   public XMLDataIntegerType(BigInteger value)
/*    */   {
/* 34 */     this.value = value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void addContent(Element element)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 42 */     if (this.value == null)
/* 43 */       throw new InvalidInfoNodeException("Información insuficiente para escribir nodo XMLDataStringType");
/* 44 */     element.setTextContent(this.value.toString());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 52 */     if ((obj instanceof XMLDataIntegerType)) {
/* 53 */       XMLDataIntegerType xdst = (XMLDataIntegerType)obj;
/* 54 */       if (this.value.equals(xdst))
/* 55 */         return true;
/* 56 */     } else if ((obj instanceof String)) {
/* 57 */       String data = (String)obj;
/* 58 */       if (this.value.equals(data))
/* 59 */         return true;
/*    */     }
/* 61 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void load(Element element)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 69 */     Node node = getFirstNonvoidNode(element);
/* 70 */     if (node.getNodeType() != 3) {
/* 71 */       throw new InvalidInfoNodeException("Nodo xsd:string no contiene CDATA como primer valor");
/*    */     }
/*    */     try {
/* 74 */       String strvalue = node.getNodeValue();
/* 75 */       if (strvalue == null)
/* 76 */         throw new InvalidInfoNodeException("Contenido de valor de xsd.string vacío");
/* 77 */       this.value = new BigInteger(strvalue);
/*    */     } catch (NumberFormatException ex) {
/* 79 */       throw new InvalidInfoNodeException("Contenido de valor de xsd.integer no numérico");
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public BigInteger getValue()
/*    */   {
/* 88 */     return this.value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setValue(BigInteger value)
/*    */   {
/* 95 */     this.value = value;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\XMLDataIntegerType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */