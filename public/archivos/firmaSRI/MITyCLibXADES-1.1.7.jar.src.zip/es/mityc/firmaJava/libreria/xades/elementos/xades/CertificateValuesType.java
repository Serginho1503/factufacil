/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CertificateValuesType
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private ArrayList<EncapsulatedX509Certificate> certificates;
/*     */   private String id;
/*     */   
/*     */   public CertificateValuesType(XAdESSchemas schema)
/*     */   {
/*  41 */     super(schema);
/*     */   }
/*     */   
/*     */   public CertificateValuesType(XAdESSchemas schema, ArrayList<EncapsulatedX509Certificate> certificates) {
/*  45 */     super(schema);
/*  46 */     this.certificates = certificates;
/*     */   }
/*     */   
/*     */   public void addEncapsulatedX509Certificate(EncapsulatedX509Certificate certificate) {
/*  50 */     if (this.certificates == null)
/*  51 */       this.certificates = new ArrayList();
/*  52 */     this.certificates.add(certificate);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ArrayList<EncapsulatedX509Certificate> getCertificates()
/*     */   {
/*  59 */     return this.certificates;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setCertificates(ArrayList<EncapsulatedX509Certificate> certificates)
/*     */   {
/*  66 */     this.certificates = certificates;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getId()
/*     */   {
/*  73 */     return this.id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setId(String id)
/*     */   {
/*  80 */     this.id = id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EncapsulatedX509Certificate getEncapsulatedX509CertificateById(String id)
/*     */   {
/*  90 */     if ((this.certificates != null) && (id != null)) {
/*  91 */       Iterator<EncapsulatedX509Certificate> it = this.certificates.iterator();
/*  92 */       while (it.hasNext()) {
/*  93 */         EncapsulatedX509Certificate cert = (EncapsulatedX509Certificate)it.next();
/*  94 */         String idCert = cert.getId();
/*  95 */         if (id.equals(idCert))
/*  96 */           return cert;
/*     */       }
/*     */     }
/*  99 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 107 */     if ((obj instanceof CertificateValuesType)) {
/* 108 */       CertificateValuesType cvt = (CertificateValuesType)obj;
/* 109 */       ArrayList<EncapsulatedX509Certificate> comp = cvt.certificates;
/* 110 */       if (((this.certificates == null) || (this.certificates.isEmpty())) && (
/* 111 */         (comp == null) || (comp.isEmpty())))
/* 112 */         return true;
/* 113 */       if ((this.certificates != null) && (comp != null) && 
/* 114 */         (this.certificates.size() == comp.size())) {
/* 115 */         Iterator<EncapsulatedX509Certificate> itThis = this.certificates.iterator();
/* 116 */         Iterator<EncapsulatedX509Certificate> itComp = comp.iterator();
/* 117 */         while (itThis.hasNext()) {
/* 118 */           if (!((EncapsulatedX509Certificate)itThis.next()).equals(itComp.next()))
/* 119 */             return false;
/*     */         }
/* 121 */         return true;
/*     */       }
/*     */     }
/* 124 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 133 */     if (element.hasAttribute("Id")) {
/* 134 */       this.id = element.getAttribute("Id");
/*     */     }
/* 136 */     NodeList nodos = element.getChildNodes();
/* 137 */     ArrayList<EncapsulatedX509Certificate> temp = new ArrayList(nodos.getLength());
/* 138 */     for (int i = 0; i < nodos.getLength(); i++) {
/* 139 */       Node nodo = nodos.item(i);
/* 140 */       if (!isDecorationNode(nodo))
/*     */       {
/* 142 */         if (nodo.getNodeType() != 1) {
/* 143 */           throw new InvalidInfoNodeException("Hijo de CertificateValuesType no es un elemento");
/*     */         }
/* 145 */         EncapsulatedX509Certificate certificate = new EncapsulatedX509Certificate(this.schema);
/* 146 */         certificate.load((Element)nodo);
/* 147 */         temp.add(certificate);
/*     */       } }
/* 149 */     this.certificates = temp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void addContent(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 157 */     if (this.certificates != null) {
/* 158 */       Iterator<EncapsulatedX509Certificate> it = this.certificates.iterator();
/* 159 */       while (it.hasNext()) {
/* 160 */         element.appendChild(((EncapsulatedX509Certificate)it.next()).createElement(element.getOwnerDocument(), this.namespaceXAdES));
/*     */       }
/*     */     }
/* 163 */     if (this.id != null) {
/* 164 */       element.setAttributeNS(null, "Id", this.id);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void addContent(Element element, String namespaceXAdES)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 172 */     super.addContent(element, namespaceXAdES);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\CertificateValuesType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */