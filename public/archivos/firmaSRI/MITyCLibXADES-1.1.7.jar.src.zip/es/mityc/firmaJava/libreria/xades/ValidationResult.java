/*    */ package es.mityc.firmaJava.libreria.xades;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidationResult
/*    */ {
/*    */   private boolean validado;
/*    */   private ArrayList log;
/*    */   
/*    */   public ValidationResult()
/*    */   {
/* 36 */     this.validado = false;
/* 37 */     this.log = new ArrayList();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ArrayList getLog()
/*    */   {
/* 45 */     return this.log;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setLog(ArrayList log)
/*    */   {
/* 53 */     this.log = log;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isValidate()
/*    */   {
/* 61 */     return this.validado;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setValidate(boolean validado)
/*    */   {
/* 69 */     this.validado = validado;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void addLog(String log)
/*    */   {
/* 77 */     this.log.add(log);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String writeLog()
/*    */   {
/* 86 */     StringBuffer log = new StringBuffer();
/* 87 */     for (Iterator<String> it = this.log.iterator(); it.hasNext();)
/*    */     {
/* 89 */       String _log = (String)it.next();
/* 90 */       log.append(_log);
/* 91 */       log.append("\n");
/*    */     }
/* 93 */     return log.toString();
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\ValidationResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */