/*      */ package es.mityc.firmaJava.libreria.utilidades;
/*      */ 
/*      */ import java.io.FilterInputStream;
/*      */ import java.io.FilterOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.io.Serializable;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Base64
/*      */ {
/*  115 */   static Log log = LogFactory.getLog(Base64.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int MAX_LINE_LENGTH = 76;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final byte EQUALS_SIGN = 61;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final byte NEW_LINE = 10;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final String PREFERRED_ENCODING = "UTF-8";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final byte WHITE_SPACE_ENC = -5;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final byte EQUALS_SIGN_ENC = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  151 */   private static final byte[] _STANDARD_ALPHABET = {
/*  152 */     65, 66, 67, 68, 69, 70, 71, 72, 
/*  153 */     73, 74, 75, 76, 77, 78, 79, 80, 
/*  154 */     81, 82, 83, 84, 85, 86, 87, 88, 
/*  155 */     89, 90, 97, 98, 99, 100, 101, 102, 
/*  156 */     103, 104, 105, 106, 107, 108, 109, 110, 
/*  157 */     111, 112, 113, 114, 115, 116, 117, 118, 
/*  158 */     119, 120, 121, 122, 48, 49, 50, 51, 
/*  159 */     52, 53, 54, 55, 56, 57, 43, 47 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  168 */   private static final byte[] _STANDARD_DECODABET = {
/*  169 */     -9, -9, -9, -9, -9, -9, -9, -9, -9, 
/*  170 */     -5, -5, 
/*  171 */     -9, -9, 
/*  172 */     -5, 
/*  173 */     -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 
/*  174 */     -9, -9, -9, -9, -9, 
/*  175 */     -5, 
/*  176 */     -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 
/*  177 */     62, 
/*  178 */     -9, -9, -9, 
/*  179 */     63, 
/*  180 */     52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 
/*  181 */     -9, -9, -9, 
/*  182 */     -1, 
/*  183 */     -9, -9, -9, 
/*  184 */     0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 
/*  185 */     14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 
/*  186 */     -9, -9, -9, -9, -9, -9, 
/*  187 */     26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 
/*  188 */     39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 
/*  189 */     -9, -9, -9, -9 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  211 */   private static final byte[] _URL_SAFE_ALPHABET = {
/*  212 */     65, 66, 67, 68, 69, 70, 71, 
/*  213 */     72, 73, 74, 75, 76, 77, 78, 
/*  214 */     79, 80, 81, 82, 83, 84, 85, 
/*  215 */     86, 87, 88, 89, 90, 
/*  216 */     97, 98, 99, 100, 101, 102, 103, 
/*  217 */     104, 105, 106, 107, 108, 109, 110, 
/*  218 */     111, 112, 113, 114, 115, 116, 117, 
/*  219 */     118, 119, 120, 121, 122, 
/*  220 */     48, 49, 50, 51, 52, 53, 
/*  221 */     54, 55, 56, 57, 45, 95 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  228 */   private static final byte[] _URL_SAFE_DECODABET = {
/*  229 */     -9, -9, -9, -9, -9, -9, -9, -9, -9, 
/*  230 */     -5, -5, 
/*  231 */     -9, -9, 
/*  232 */     -5, 
/*  233 */     -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 
/*  234 */     -9, -9, -9, -9, -9, 
/*  235 */     -5, 
/*  236 */     -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 
/*  237 */     -9, 
/*  238 */     -9, 
/*  239 */     62, 
/*  240 */     -9, 
/*  241 */     -9, 
/*  242 */     52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 
/*  243 */     -9, -9, -9, 
/*  244 */     -1, 
/*  245 */     -9, -9, -9, 
/*  246 */     0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 
/*  247 */     14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 
/*  248 */     -9, -9, -9, -9, 
/*  249 */     63, 
/*  250 */     -9, 
/*  251 */     26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 
/*  252 */     39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 
/*  253 */     -9, -9, -9, -9 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  275 */   private static final byte[] _ORDERED_ALPHABET = {
/*  276 */     45, 
/*  277 */     48, 49, 50, 51, 52, 
/*  278 */     53, 54, 55, 56, 57, 
/*  279 */     65, 66, 67, 68, 69, 70, 71, 
/*  280 */     72, 73, 74, 75, 76, 77, 78, 
/*  281 */     79, 80, 81, 82, 83, 84, 85, 
/*  282 */     86, 87, 88, 89, 90, 
/*  283 */     95, 
/*  284 */     97, 98, 99, 100, 101, 102, 103, 
/*  285 */     104, 105, 106, 107, 108, 109, 110, 
/*  286 */     111, 112, 113, 114, 115, 116, 117, 
/*  287 */     118, 119, 120, 121, 122 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  294 */   private static final byte[] _ORDERED_DECODABET = {
/*  295 */     -9, -9, -9, -9, -9, -9, -9, -9, -9, 
/*  296 */     -5, -5, 
/*  297 */     -9, -9, 
/*  298 */     -5, 
/*  299 */     -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 
/*  300 */     -9, -9, -9, -9, -9, 
/*  301 */     -5, 
/*  302 */     -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 
/*  303 */     -9, 
/*  304 */     -9, 
/*      */     
/*  306 */     0, -9, 
/*  307 */     -9, 
/*  308 */     1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 
/*  309 */     -9, -9, -9, 
/*  310 */     -1, 
/*  311 */     -9, -9, -9, 
/*  312 */     11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 
/*  313 */     24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 
/*  314 */     -9, -9, -9, -9, 
/*  315 */     37, 
/*  316 */     -9, 
/*  317 */     38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 
/*  318 */     51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 
/*  319 */     -9, -9, -9, -9 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final byte[] getAlphabet(int options)
/*      */   {
/*  345 */     if ((options & 0x10) == 16) return (byte[])_URL_SAFE_ALPHABET.clone();
/*  346 */     if ((options & 0x20) == 32) return (byte[])_ORDERED_ALPHABET.clone();
/*  347 */     return (byte[])_STANDARD_ALPHABET.clone();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final byte[] getDecodabet(int options)
/*      */   {
/*  361 */     if ((options & 0x10) == 16) return (byte[])_URL_SAFE_DECODABET.clone();
/*  362 */     if ((options & 0x20) == 32) return (byte[])_ORDERED_DECODABET.clone();
/*  363 */     return (byte[])_STANDARD_DECODABET.clone();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static byte[] encode3to4(byte[] b4, byte[] threeBytes, int numSigBytes, int options)
/*      */   {
/*  419 */     encode3to4(threeBytes, 0, numSigBytes, b4, 0, options);
/*  420 */     return b4;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static byte[] encode3to4(byte[] source, int srcOffset, int numSigBytes, byte[] destination, int destOffset, int options)
/*      */   {
/*  451 */     byte[] ALPHABET = getAlphabet(options);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  464 */     int inBuff = (numSigBytes > 0 ? source[srcOffset] << 24 >>> 8 : 0) | 
/*  465 */       (numSigBytes > 1 ? source[(srcOffset + 1)] << 24 >>> 16 : 0) | 
/*  466 */       (numSigBytes > 2 ? source[(srcOffset + 2)] << 24 >>> 24 : 0);
/*      */     
/*  468 */     switch (numSigBytes)
/*      */     {
/*      */     case 3: 
/*  471 */       destination[destOffset] = ALPHABET[(inBuff >>> 18)];
/*  472 */       destination[(destOffset + 1)] = ALPHABET[(inBuff >>> 12 & 0x3F)];
/*  473 */       destination[(destOffset + 2)] = ALPHABET[(inBuff >>> 6 & 0x3F)];
/*  474 */       destination[(destOffset + 3)] = ALPHABET[(inBuff & 0x3F)];
/*  475 */       return destination;
/*      */     
/*      */     case 2: 
/*  478 */       destination[destOffset] = ALPHABET[(inBuff >>> 18)];
/*  479 */       destination[(destOffset + 1)] = ALPHABET[(inBuff >>> 12 & 0x3F)];
/*  480 */       destination[(destOffset + 2)] = ALPHABET[(inBuff >>> 6 & 0x3F)];
/*  481 */       destination[(destOffset + 3)] = 61;
/*  482 */       return destination;
/*      */     
/*      */     case 1: 
/*  485 */       destination[destOffset] = ALPHABET[(inBuff >>> 18)];
/*  486 */       destination[(destOffset + 1)] = ALPHABET[(inBuff >>> 12 & 0x3F)];
/*  487 */       destination[(destOffset + 2)] = 61;
/*  488 */       destination[(destOffset + 3)] = 61;
/*  489 */       return destination;
/*      */     }
/*      */     
/*  492 */     return destination;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String encodeObject(Serializable serializableObject)
/*      */   {
/*  511 */     return encodeObject(serializableObject, 0);
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public static String encodeObject(Serializable serializableObject, int options)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aconst_null
/*      */     //   1: astore_2
/*      */     //   2: aconst_null
/*      */     //   3: astore_3
/*      */     //   4: aconst_null
/*      */     //   5: astore 4
/*      */     //   7: aconst_null
/*      */     //   8: astore 5
/*      */     //   10: iload_1
/*      */     //   11: iconst_2
/*      */     //   12: iand
/*      */     //   13: istore 6
/*      */     //   15: new 94	java/io/ByteArrayOutputStream
/*      */     //   18: dup
/*      */     //   19: invokespecial 96	java/io/ByteArrayOutputStream:<init>	()V
/*      */     //   22: astore_2
/*      */     //   23: new 97	es/mityc/firmaJava/libreria/utilidades/Base64$OutputStream
/*      */     //   26: dup
/*      */     //   27: aload_2
/*      */     //   28: iconst_1
/*      */     //   29: iload_1
/*      */     //   30: ior
/*      */     //   31: invokespecial 99	es/mityc/firmaJava/libreria/utilidades/Base64$OutputStream:<init>	(Ljava/io/OutputStream;I)V
/*      */     //   34: astore_3
/*      */     //   35: iload 6
/*      */     //   37: iconst_2
/*      */     //   38: if_icmpne +27 -> 65
/*      */     //   41: new 102	java/util/zip/GZIPOutputStream
/*      */     //   44: dup
/*      */     //   45: aload_3
/*      */     //   46: invokespecial 104	java/util/zip/GZIPOutputStream:<init>	(Ljava/io/OutputStream;)V
/*      */     //   49: astore 5
/*      */     //   51: new 107	java/io/ObjectOutputStream
/*      */     //   54: dup
/*      */     //   55: aload 5
/*      */     //   57: invokespecial 109	java/io/ObjectOutputStream:<init>	(Ljava/io/OutputStream;)V
/*      */     //   60: astore 4
/*      */     //   62: goto +13 -> 75
/*      */     //   65: new 107	java/io/ObjectOutputStream
/*      */     //   68: dup
/*      */     //   69: aload_3
/*      */     //   70: invokespecial 109	java/io/ObjectOutputStream:<init>	(Ljava/io/OutputStream;)V
/*      */     //   73: astore 4
/*      */     //   75: aload 4
/*      */     //   77: aload_0
/*      */     //   78: invokevirtual 110	java/io/ObjectOutputStream:writeObject	(Ljava/lang/Object;)V
/*      */     //   81: goto +178 -> 259
/*      */     //   84: astore 7
/*      */     //   86: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   89: aload 7
/*      */     //   91: invokeinterface 114 2 0
/*      */     //   96: aload 4
/*      */     //   98: invokevirtual 119	java/io/ObjectOutputStream:close	()V
/*      */     //   101: goto +15 -> 116
/*      */     //   104: astore 9
/*      */     //   106: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   109: aload 9
/*      */     //   111: invokeinterface 114 2 0
/*      */     //   116: aload 5
/*      */     //   118: invokevirtual 122	java/util/zip/GZIPOutputStream:close	()V
/*      */     //   121: goto +15 -> 136
/*      */     //   124: astore 9
/*      */     //   126: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   129: aload 9
/*      */     //   131: invokeinterface 114 2 0
/*      */     //   136: aload_3
/*      */     //   137: invokevirtual 123	es/mityc/firmaJava/libreria/utilidades/Base64$OutputStream:close	()V
/*      */     //   140: goto +15 -> 155
/*      */     //   143: astore 9
/*      */     //   145: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   148: aload 9
/*      */     //   150: invokeinterface 114 2 0
/*      */     //   155: aload_2
/*      */     //   156: invokevirtual 124	java/io/ByteArrayOutputStream:close	()V
/*      */     //   159: goto +15 -> 174
/*      */     //   162: astore 9
/*      */     //   164: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   167: aload 9
/*      */     //   169: invokeinterface 114 2 0
/*      */     //   174: aconst_null
/*      */     //   175: areturn
/*      */     //   176: astore 8
/*      */     //   178: aload 4
/*      */     //   180: invokevirtual 119	java/io/ObjectOutputStream:close	()V
/*      */     //   183: goto +15 -> 198
/*      */     //   186: astore 9
/*      */     //   188: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   191: aload 9
/*      */     //   193: invokeinterface 114 2 0
/*      */     //   198: aload 5
/*      */     //   200: invokevirtual 122	java/util/zip/GZIPOutputStream:close	()V
/*      */     //   203: goto +15 -> 218
/*      */     //   206: astore 9
/*      */     //   208: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   211: aload 9
/*      */     //   213: invokeinterface 114 2 0
/*      */     //   218: aload_3
/*      */     //   219: invokevirtual 123	es/mityc/firmaJava/libreria/utilidades/Base64$OutputStream:close	()V
/*      */     //   222: goto +15 -> 237
/*      */     //   225: astore 9
/*      */     //   227: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   230: aload 9
/*      */     //   232: invokeinterface 114 2 0
/*      */     //   237: aload_2
/*      */     //   238: invokevirtual 124	java/io/ByteArrayOutputStream:close	()V
/*      */     //   241: goto +15 -> 256
/*      */     //   244: astore 9
/*      */     //   246: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   249: aload 9
/*      */     //   251: invokeinterface 114 2 0
/*      */     //   256: aload 8
/*      */     //   258: athrow
/*      */     //   259: aload 4
/*      */     //   261: invokevirtual 119	java/io/ObjectOutputStream:close	()V
/*      */     //   264: goto +15 -> 279
/*      */     //   267: astore 9
/*      */     //   269: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   272: aload 9
/*      */     //   274: invokeinterface 114 2 0
/*      */     //   279: aload 5
/*      */     //   281: invokevirtual 122	java/util/zip/GZIPOutputStream:close	()V
/*      */     //   284: goto +15 -> 299
/*      */     //   287: astore 9
/*      */     //   289: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   292: aload 9
/*      */     //   294: invokeinterface 114 2 0
/*      */     //   299: aload_3
/*      */     //   300: invokevirtual 123	es/mityc/firmaJava/libreria/utilidades/Base64$OutputStream:close	()V
/*      */     //   303: goto +15 -> 318
/*      */     //   306: astore 9
/*      */     //   308: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   311: aload 9
/*      */     //   313: invokeinterface 114 2 0
/*      */     //   318: aload_2
/*      */     //   319: invokevirtual 124	java/io/ByteArrayOutputStream:close	()V
/*      */     //   322: goto +15 -> 337
/*      */     //   325: astore 9
/*      */     //   327: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   330: aload 9
/*      */     //   332: invokeinterface 114 2 0
/*      */     //   337: new 125	java/lang/String
/*      */     //   340: dup
/*      */     //   341: aload_2
/*      */     //   342: invokevirtual 127	java/io/ByteArrayOutputStream:toByteArray	()[B
/*      */     //   345: ldc 18
/*      */     //   347: invokespecial 131	java/lang/String:<init>	([BLjava/lang/String;)V
/*      */     //   350: areturn
/*      */     //   351: astore 7
/*      */     //   353: new 125	java/lang/String
/*      */     //   356: dup
/*      */     //   357: aload_2
/*      */     //   358: invokevirtual 127	java/io/ByteArrayOutputStream:toByteArray	()[B
/*      */     //   361: invokespecial 134	java/lang/String:<init>	([B)V
/*      */     //   364: areturn
/*      */     // Line number table:
/*      */     //   Java source line #542	-> byte code offset #0
/*      */     //   Java source line #543	-> byte code offset #2
/*      */     //   Java source line #544	-> byte code offset #4
/*      */     //   Java source line #545	-> byte code offset #7
/*      */     //   Java source line #548	-> byte code offset #10
/*      */     //   Java source line #554	-> byte code offset #15
/*      */     //   Java source line #555	-> byte code offset #23
/*      */     //   Java source line #558	-> byte code offset #35
/*      */     //   Java source line #560	-> byte code offset #41
/*      */     //   Java source line #561	-> byte code offset #51
/*      */     //   Java source line #562	-> byte code offset #62
/*      */     //   Java source line #564	-> byte code offset #65
/*      */     //   Java source line #566	-> byte code offset #75
/*      */     //   Java source line #567	-> byte code offset #81
/*      */     //   Java source line #568	-> byte code offset #84
/*      */     //   Java source line #570	-> byte code offset #86
/*      */     //   Java source line #575	-> byte code offset #96
/*      */     //   Java source line #576	-> byte code offset #116
/*      */     //   Java source line #577	-> byte code offset #136
/*      */     //   Java source line #578	-> byte code offset #155
/*      */     //   Java source line #571	-> byte code offset #174
/*      */     //   Java source line #574	-> byte code offset #176
/*      */     //   Java source line #575	-> byte code offset #178
/*      */     //   Java source line #576	-> byte code offset #198
/*      */     //   Java source line #577	-> byte code offset #218
/*      */     //   Java source line #578	-> byte code offset #237
/*      */     //   Java source line #579	-> byte code offset #256
/*      */     //   Java source line #575	-> byte code offset #259
/*      */     //   Java source line #576	-> byte code offset #279
/*      */     //   Java source line #577	-> byte code offset #299
/*      */     //   Java source line #578	-> byte code offset #318
/*      */     //   Java source line #584	-> byte code offset #337
/*      */     //   Java source line #586	-> byte code offset #351
/*      */     //   Java source line #588	-> byte code offset #353
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	365	0	serializableObject	Serializable
/*      */     //   0	365	1	options	int
/*      */     //   1	357	2	baos	java.io.ByteArrayOutputStream
/*      */     //   3	297	3	b64os	OutputStream
/*      */     //   5	255	4	oos	java.io.ObjectOutputStream
/*      */     //   8	272	5	gzos	java.util.zip.GZIPOutputStream
/*      */     //   13	23	6	gzip	int
/*      */     //   84	6	7	e	IOException
/*      */     //   351	3	7	uue	java.io.UnsupportedEncodingException
/*      */     //   176	81	8	localObject	Object
/*      */     //   104	6	9	e	Exception
/*      */     //   124	6	9	e	Exception
/*      */     //   143	6	9	e	Exception
/*      */     //   162	6	9	e	Exception
/*      */     //   186	6	9	e	Exception
/*      */     //   206	6	9	e	Exception
/*      */     //   225	6	9	e	Exception
/*      */     //   244	6	9	e	Exception
/*      */     //   267	6	9	e	Exception
/*      */     //   287	6	9	e	Exception
/*      */     //   306	6	9	e	Exception
/*      */     //   325	6	9	e	Exception
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   15	81	84	java/io/IOException
/*      */     //   96	101	104	java/lang/Exception
/*      */     //   116	121	124	java/lang/Exception
/*      */     //   136	140	143	java/lang/Exception
/*      */     //   155	159	162	java/lang/Exception
/*      */     //   15	96	176	finally
/*      */     //   178	183	186	java/lang/Exception
/*      */     //   198	203	206	java/lang/Exception
/*      */     //   218	222	225	java/lang/Exception
/*      */     //   237	241	244	java/lang/Exception
/*      */     //   259	264	267	java/lang/Exception
/*      */     //   279	284	287	java/lang/Exception
/*      */     //   299	303	306	java/lang/Exception
/*      */     //   318	322	325	java/lang/Exception
/*      */     //   337	350	351	java/io/UnsupportedEncodingException
/*      */   }
/*      */   
/*      */   public static String encodeBytes(byte[] source)
/*      */   {
/*  604 */     return encodeBytes(source, 0, source.length, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String encodeBytes(byte[] source, int options)
/*      */   {
/*  631 */     return encodeBytes(source, 0, source.length, options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String encodeBytes(byte[] source, int off, int len)
/*      */   {
/*  646 */     return encodeBytes(source, off, len, 0);
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public static String encodeBytes(byte[] source, int off, int len, int options)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: iload_3
/*      */     //   1: bipush 8
/*      */     //   3: iand
/*      */     //   4: istore 4
/*      */     //   6: iload_3
/*      */     //   7: iconst_2
/*      */     //   8: iand
/*      */     //   9: istore 5
/*      */     //   11: iload 5
/*      */     //   13: iconst_2
/*      */     //   14: if_icmpne +286 -> 300
/*      */     //   17: aconst_null
/*      */     //   18: astore 6
/*      */     //   20: aconst_null
/*      */     //   21: astore 7
/*      */     //   23: aconst_null
/*      */     //   24: astore 8
/*      */     //   26: new 94	java/io/ByteArrayOutputStream
/*      */     //   29: dup
/*      */     //   30: invokespecial 96	java/io/ByteArrayOutputStream:<init>	()V
/*      */     //   33: astore 6
/*      */     //   35: new 97	es/mityc/firmaJava/libreria/utilidades/Base64$OutputStream
/*      */     //   38: dup
/*      */     //   39: aload 6
/*      */     //   41: iconst_1
/*      */     //   42: iload_3
/*      */     //   43: ior
/*      */     //   44: invokespecial 99	es/mityc/firmaJava/libreria/utilidades/Base64$OutputStream:<init>	(Ljava/io/OutputStream;I)V
/*      */     //   47: astore 8
/*      */     //   49: new 102	java/util/zip/GZIPOutputStream
/*      */     //   52: dup
/*      */     //   53: aload 8
/*      */     //   55: invokespecial 104	java/util/zip/GZIPOutputStream:<init>	(Ljava/io/OutputStream;)V
/*      */     //   58: astore 7
/*      */     //   60: aload 7
/*      */     //   62: aload_0
/*      */     //   63: iload_1
/*      */     //   64: iload_2
/*      */     //   65: invokevirtual 170	java/util/zip/GZIPOutputStream:write	([BII)V
/*      */     //   68: goto +142 -> 210
/*      */     //   71: astore 9
/*      */     //   73: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   76: aload 9
/*      */     //   78: invokeinterface 114 2 0
/*      */     //   83: aload 7
/*      */     //   85: invokevirtual 122	java/util/zip/GZIPOutputStream:close	()V
/*      */     //   88: goto +15 -> 103
/*      */     //   91: astore 11
/*      */     //   93: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   96: aload 11
/*      */     //   98: invokeinterface 114 2 0
/*      */     //   103: aload 8
/*      */     //   105: invokevirtual 123	es/mityc/firmaJava/libreria/utilidades/Base64$OutputStream:close	()V
/*      */     //   108: goto +15 -> 123
/*      */     //   111: astore 11
/*      */     //   113: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   116: aload 11
/*      */     //   118: invokeinterface 114 2 0
/*      */     //   123: aload 6
/*      */     //   125: invokevirtual 124	java/io/ByteArrayOutputStream:close	()V
/*      */     //   128: goto +15 -> 143
/*      */     //   131: astore 11
/*      */     //   133: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   136: aload 11
/*      */     //   138: invokeinterface 114 2 0
/*      */     //   143: aconst_null
/*      */     //   144: areturn
/*      */     //   145: astore 10
/*      */     //   147: aload 7
/*      */     //   149: invokevirtual 122	java/util/zip/GZIPOutputStream:close	()V
/*      */     //   152: goto +15 -> 167
/*      */     //   155: astore 11
/*      */     //   157: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   160: aload 11
/*      */     //   162: invokeinterface 114 2 0
/*      */     //   167: aload 8
/*      */     //   169: invokevirtual 123	es/mityc/firmaJava/libreria/utilidades/Base64$OutputStream:close	()V
/*      */     //   172: goto +15 -> 187
/*      */     //   175: astore 11
/*      */     //   177: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   180: aload 11
/*      */     //   182: invokeinterface 114 2 0
/*      */     //   187: aload 6
/*      */     //   189: invokevirtual 124	java/io/ByteArrayOutputStream:close	()V
/*      */     //   192: goto +15 -> 207
/*      */     //   195: astore 11
/*      */     //   197: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   200: aload 11
/*      */     //   202: invokeinterface 114 2 0
/*      */     //   207: aload 10
/*      */     //   209: athrow
/*      */     //   210: aload 7
/*      */     //   212: invokevirtual 122	java/util/zip/GZIPOutputStream:close	()V
/*      */     //   215: goto +15 -> 230
/*      */     //   218: astore 11
/*      */     //   220: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   223: aload 11
/*      */     //   225: invokeinterface 114 2 0
/*      */     //   230: aload 8
/*      */     //   232: invokevirtual 123	es/mityc/firmaJava/libreria/utilidades/Base64$OutputStream:close	()V
/*      */     //   235: goto +15 -> 250
/*      */     //   238: astore 11
/*      */     //   240: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   243: aload 11
/*      */     //   245: invokeinterface 114 2 0
/*      */     //   250: aload 6
/*      */     //   252: invokevirtual 124	java/io/ByteArrayOutputStream:close	()V
/*      */     //   255: goto +15 -> 270
/*      */     //   258: astore 11
/*      */     //   260: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   263: aload 11
/*      */     //   265: invokeinterface 114 2 0
/*      */     //   270: new 125	java/lang/String
/*      */     //   273: dup
/*      */     //   274: aload 6
/*      */     //   276: invokevirtual 127	java/io/ByteArrayOutputStream:toByteArray	()[B
/*      */     //   279: ldc 18
/*      */     //   281: invokespecial 131	java/lang/String:<init>	([BLjava/lang/String;)V
/*      */     //   284: areturn
/*      */     //   285: astore 9
/*      */     //   287: new 125	java/lang/String
/*      */     //   290: dup
/*      */     //   291: aload 6
/*      */     //   293: invokevirtual 127	java/io/ByteArrayOutputStream:toByteArray	()[B
/*      */     //   296: invokespecial 134	java/lang/String:<init>	([B)V
/*      */     //   299: areturn
/*      */     //   300: iload 4
/*      */     //   302: ifne +7 -> 309
/*      */     //   305: iconst_1
/*      */     //   306: goto +4 -> 310
/*      */     //   309: iconst_0
/*      */     //   310: istore 6
/*      */     //   312: iload_2
/*      */     //   313: iconst_4
/*      */     //   314: imul
/*      */     //   315: iconst_3
/*      */     //   316: idiv
/*      */     //   317: istore 7
/*      */     //   319: iload 7
/*      */     //   321: iload_2
/*      */     //   322: iconst_3
/*      */     //   323: irem
/*      */     //   324: ifle +7 -> 331
/*      */     //   327: iconst_4
/*      */     //   328: goto +4 -> 332
/*      */     //   331: iconst_0
/*      */     //   332: iadd
/*      */     //   333: iload 6
/*      */     //   335: ifeq +11 -> 346
/*      */     //   338: iload 7
/*      */     //   340: bipush 76
/*      */     //   342: idiv
/*      */     //   343: goto +4 -> 347
/*      */     //   346: iconst_0
/*      */     //   347: iadd
/*      */     //   348: newarray <illegal type>
/*      */     //   350: astore 8
/*      */     //   352: iconst_0
/*      */     //   353: istore 9
/*      */     //   355: iconst_0
/*      */     //   356: istore 10
/*      */     //   358: iload_2
/*      */     //   359: iconst_2
/*      */     //   360: isub
/*      */     //   361: istore 11
/*      */     //   363: iconst_0
/*      */     //   364: istore 12
/*      */     //   366: bipush 76
/*      */     //   368: istore 13
/*      */     //   370: bipush 10
/*      */     //   372: istore 14
/*      */     //   374: goto +54 -> 428
/*      */     //   377: aload_0
/*      */     //   378: iload 9
/*      */     //   380: iload_1
/*      */     //   381: iadd
/*      */     //   382: iconst_3
/*      */     //   383: aload 8
/*      */     //   385: iload 10
/*      */     //   387: iload_3
/*      */     //   388: invokestatic 73	es/mityc/firmaJava/libreria/utilidades/Base64:encode3to4	([BII[BII)[B
/*      */     //   391: pop
/*      */     //   392: iinc 12 4
/*      */     //   395: iload 6
/*      */     //   397: ifeq +25 -> 422
/*      */     //   400: iload 12
/*      */     //   402: iload 13
/*      */     //   404: if_icmpne +18 -> 422
/*      */     //   407: aload 8
/*      */     //   409: iload 10
/*      */     //   411: iconst_4
/*      */     //   412: iadd
/*      */     //   413: iload 14
/*      */     //   415: bastore
/*      */     //   416: iinc 10 1
/*      */     //   419: iconst_0
/*      */     //   420: istore 12
/*      */     //   422: iinc 9 3
/*      */     //   425: iinc 10 4
/*      */     //   428: iload 9
/*      */     //   430: iload 11
/*      */     //   432: if_icmplt -55 -> 377
/*      */     //   435: iload 9
/*      */     //   437: iload_2
/*      */     //   438: if_icmpge +24 -> 462
/*      */     //   441: aload_0
/*      */     //   442: iload 9
/*      */     //   444: iload_1
/*      */     //   445: iadd
/*      */     //   446: iload_2
/*      */     //   447: iload 9
/*      */     //   449: isub
/*      */     //   450: aload 8
/*      */     //   452: iload 10
/*      */     //   454: iload_3
/*      */     //   455: invokestatic 73	es/mityc/firmaJava/libreria/utilidades/Base64:encode3to4	([BII[BII)[B
/*      */     //   458: pop
/*      */     //   459: iinc 10 4
/*      */     //   462: new 125	java/lang/String
/*      */     //   465: dup
/*      */     //   466: aload 8
/*      */     //   468: iconst_0
/*      */     //   469: iload 10
/*      */     //   471: ldc 18
/*      */     //   473: invokespecial 174	java/lang/String:<init>	([BIILjava/lang/String;)V
/*      */     //   476: areturn
/*      */     //   477: astore 15
/*      */     //   479: new 125	java/lang/String
/*      */     //   482: dup
/*      */     //   483: aload 8
/*      */     //   485: iconst_0
/*      */     //   486: iload 10
/*      */     //   488: invokespecial 177	java/lang/String:<init>	([BII)V
/*      */     //   491: areturn
/*      */     // Line number table:
/*      */     //   Java source line #677	-> byte code offset #0
/*      */     //   Java source line #678	-> byte code offset #6
/*      */     //   Java source line #681	-> byte code offset #11
/*      */     //   Java source line #683	-> byte code offset #17
/*      */     //   Java source line #684	-> byte code offset #20
/*      */     //   Java source line #685	-> byte code offset #23
/*      */     //   Java source line #691	-> byte code offset #26
/*      */     //   Java source line #692	-> byte code offset #35
/*      */     //   Java source line #693	-> byte code offset #49
/*      */     //   Java source line #695	-> byte code offset #60
/*      */     //   Java source line #697	-> byte code offset #68
/*      */     //   Java source line #698	-> byte code offset #71
/*      */     //   Java source line #700	-> byte code offset #73
/*      */     //   Java source line #705	-> byte code offset #83
/*      */     //   Java source line #706	-> byte code offset #103
/*      */     //   Java source line #707	-> byte code offset #123
/*      */     //   Java source line #701	-> byte code offset #143
/*      */     //   Java source line #704	-> byte code offset #145
/*      */     //   Java source line #705	-> byte code offset #147
/*      */     //   Java source line #706	-> byte code offset #167
/*      */     //   Java source line #707	-> byte code offset #187
/*      */     //   Java source line #708	-> byte code offset #207
/*      */     //   Java source line #705	-> byte code offset #210
/*      */     //   Java source line #706	-> byte code offset #230
/*      */     //   Java source line #707	-> byte code offset #250
/*      */     //   Java source line #713	-> byte code offset #270
/*      */     //   Java source line #715	-> byte code offset #285
/*      */     //   Java source line #717	-> byte code offset #287
/*      */     //   Java source line #725	-> byte code offset #300
/*      */     //   Java source line #727	-> byte code offset #312
/*      */     //   Java source line #728	-> byte code offset #319
/*      */     //   Java source line #729	-> byte code offset #321
/*      */     //   Java source line #728	-> byte code offset #332
/*      */     //   Java source line #730	-> byte code offset #333
/*      */     //   Java source line #728	-> byte code offset #347
/*      */     //   Java source line #731	-> byte code offset #352
/*      */     //   Java source line #732	-> byte code offset #355
/*      */     //   Java source line #733	-> byte code offset #358
/*      */     //   Java source line #734	-> byte code offset #363
/*      */     //   Java source line #735	-> byte code offset #366
/*      */     //   Java source line #736	-> byte code offset #370
/*      */     //   Java source line #749	-> byte code offset #374
/*      */     //   Java source line #750	-> byte code offset #377
/*      */     //   Java source line #752	-> byte code offset #392
/*      */     //   Java source line #753	-> byte code offset #395
/*      */     //   Java source line #755	-> byte code offset #407
/*      */     //   Java source line #756	-> byte code offset #416
/*      */     //   Java source line #757	-> byte code offset #419
/*      */     //   Java source line #759	-> byte code offset #422
/*      */     //   Java source line #760	-> byte code offset #425
/*      */     //   Java source line #749	-> byte code offset #428
/*      */     //   Java source line #763	-> byte code offset #435
/*      */     //   Java source line #765	-> byte code offset #441
/*      */     //   Java source line #766	-> byte code offset #459
/*      */     //   Java source line #773	-> byte code offset #462
/*      */     //   Java source line #775	-> byte code offset #477
/*      */     //   Java source line #777	-> byte code offset #479
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	492	0	source	byte[]
/*      */     //   0	492	1	off	int
/*      */     //   0	492	2	len	int
/*      */     //   0	492	3	options	int
/*      */     //   4	297	4	dontBreakLines	int
/*      */     //   9	3	5	gzip	int
/*      */     //   18	274	6	baos	java.io.ByteArrayOutputStream
/*      */     //   310	86	6	breakLines	boolean
/*      */     //   21	190	7	gzos	java.util.zip.GZIPOutputStream
/*      */     //   317	22	7	len43	int
/*      */     //   24	207	8	b64os	OutputStream
/*      */     //   350	134	8	outBuff	byte[]
/*      */     //   71	6	9	e	IOException
/*      */     //   285	3	9	uue	java.io.UnsupportedEncodingException
/*      */     //   353	95	9	d	int
/*      */     //   145	63	10	localObject	Object
/*      */     //   356	131	10	e	int
/*      */     //   91	6	11	e	Exception
/*      */     //   111	6	11	e	Exception
/*      */     //   131	6	11	e	Exception
/*      */     //   155	6	11	e	Exception
/*      */     //   175	6	11	e	Exception
/*      */     //   195	6	11	e	Exception
/*      */     //   218	6	11	e	Exception
/*      */     //   238	6	11	e	Exception
/*      */     //   258	6	11	e	Exception
/*      */     //   361	70	11	len2	int
/*      */     //   364	57	12	lineLength	int
/*      */     //   368	35	13	maxLineLength	int
/*      */     //   372	42	14	newLine	byte
/*      */     //   477	3	15	uue	java.io.UnsupportedEncodingException
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   26	68	71	java/io/IOException
/*      */     //   83	88	91	java/lang/Exception
/*      */     //   103	108	111	java/lang/Exception
/*      */     //   123	128	131	java/lang/Exception
/*      */     //   26	83	145	finally
/*      */     //   147	152	155	java/lang/Exception
/*      */     //   167	172	175	java/lang/Exception
/*      */     //   187	192	195	java/lang/Exception
/*      */     //   210	215	218	java/lang/Exception
/*      */     //   230	235	238	java/lang/Exception
/*      */     //   250	255	258	java/lang/Exception
/*      */     //   270	284	285	java/io/UnsupportedEncodingException
/*      */     //   462	476	477	java/io/UnsupportedEncodingException
/*      */   }
/*      */   
/*      */   private static int decode4to3(byte[] source, int srcOffset, byte[] destination, int destOffset, int options)
/*      */   {
/*  818 */     byte[] DECODABET = getDecodabet(options);
/*      */     
/*      */ 
/*  821 */     if (source[(srcOffset + 2)] == 61)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  826 */       int outBuff = (DECODABET[source[srcOffset]] & 0xFF) << 18 | 
/*  827 */         (DECODABET[source[(srcOffset + 1)]] & 0xFF) << 12;
/*      */       
/*  829 */       destination[destOffset] = ((byte)(outBuff >>> 16));
/*  830 */       return 1;
/*      */     }
/*      */     
/*      */ 
/*  834 */     if (source[(srcOffset + 3)] == 61)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  840 */       int outBuff = (DECODABET[source[srcOffset]] & 0xFF) << 18 | 
/*  841 */         (DECODABET[source[(srcOffset + 1)]] & 0xFF) << 12 | 
/*  842 */         (DECODABET[source[(srcOffset + 2)]] & 0xFF) << 6;
/*      */       
/*  844 */       destination[destOffset] = ((byte)(outBuff >>> 16));
/*  845 */       destination[(destOffset + 1)] = ((byte)(outBuff >>> 8));
/*  846 */       return 2;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  858 */       int outBuff = (DECODABET[source[srcOffset]] & 0xFF) << 18 | 
/*  859 */         (DECODABET[source[(srcOffset + 1)]] & 0xFF) << 12 | 
/*  860 */         (DECODABET[source[(srcOffset + 2)]] & 0xFF) << 6 | 
/*  861 */         DECODABET[source[(srcOffset + 3)]] & 0xFF;
/*      */       
/*      */ 
/*  864 */       destination[destOffset] = ((byte)(outBuff >> 16));
/*  865 */       destination[(destOffset + 1)] = ((byte)(outBuff >> 8));
/*  866 */       destination[(destOffset + 2)] = ((byte)outBuff);
/*      */       
/*  868 */       return 3;
/*      */     } catch (Exception e) {
/*  870 */       System.out.println(source[srcOffset] + ": " + DECODABET[source[srcOffset]]);
/*  871 */       System.out.println(source[(srcOffset + 1)] + ": " + DECODABET[source[(srcOffset + 1)]]);
/*  872 */       System.out.println(source[(srcOffset + 2)] + ": " + DECODABET[source[(srcOffset + 2)]]);
/*  873 */       System.out.println(source[(srcOffset + 3)] + ": " + DECODABET[source[(srcOffset + 3)]]); }
/*  874 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] decode(byte[] source, int off, int len, int options)
/*      */   {
/*  895 */     byte[] DECODABET = getDecodabet(options);
/*      */     
/*  897 */     int len34 = len * 3 / 4;
/*  898 */     byte[] outBuff = new byte[len34];
/*  899 */     int outBuffPosn = 0;
/*      */     
/*  901 */     byte[] b4 = new byte[4];
/*  902 */     int b4Posn = 0;
/*  903 */     int i = 0;
/*  904 */     byte sbiCrop = 0;
/*  905 */     byte sbiDecode = 0;
/*  906 */     byte whiteSpaceEnc = -5;
/*  907 */     byte equalsSignEnc = -1;
/*  908 */     byte equalsSign = 61;
/*  909 */     String strBadBase64 = "Bad Base64 input character at ";
/*  910 */     String strDosPuntos = ": ";
/*  911 */     String strDecimal = "(decimal)";
/*  912 */     for (i = off; i < off + len; i++)
/*      */     {
/*  914 */       sbiCrop = (byte)(source[i] & 0x7F);
/*  915 */       sbiDecode = DECODABET[sbiCrop];
/*      */       
/*  917 */       if (sbiDecode >= whiteSpaceEnc)
/*      */       {
/*  919 */         if (sbiDecode >= equalsSignEnc)
/*      */         {
/*  921 */           b4[(b4Posn++)] = sbiCrop;
/*  922 */           if (b4Posn > 3)
/*      */           {
/*  924 */             outBuffPosn += decode4to3(b4, 0, outBuff, outBuffPosn, options);
/*  925 */             b4Posn = 0;
/*      */             
/*      */ 
/*  928 */             if (sbiCrop == equalsSign) {
/*      */               break;
/*      */             }
/*      */             
/*      */           }
/*      */           
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  938 */         log.error(strBadBase64 + i + strDosPuntos + source[i] + strDecimal);
/*  939 */         return null;
/*      */       }
/*      */     }
/*      */     
/*  943 */     byte[] out = new byte[outBuffPosn];
/*  944 */     System.arraycopy(outBuff, 0, out, 0, outBuffPosn);
/*  945 */     return out;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] decode(String s)
/*      */   {
/*  961 */     return decode(s, 0);
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public static byte[] decode(String s, int options)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: ldc 18
/*      */     //   3: invokevirtual 257	java/lang/String:getBytes	(Ljava/lang/String;)[B
/*      */     //   6: astore_2
/*      */     //   7: goto +9 -> 16
/*      */     //   10: astore_3
/*      */     //   11: aload_0
/*      */     //   12: invokevirtual 260	java/lang/String:getBytes	()[B
/*      */     //   15: astore_2
/*      */     //   16: aload_2
/*      */     //   17: iconst_0
/*      */     //   18: aload_2
/*      */     //   19: arraylength
/*      */     //   20: iload_1
/*      */     //   21: invokestatic 262	es/mityc/firmaJava/libreria/utilidades/Base64:decode	([BIII)[B
/*      */     //   24: astore_2
/*      */     //   25: aload_2
/*      */     //   26: arraylength
/*      */     //   27: istore_3
/*      */     //   28: aload_2
/*      */     //   29: ifnull +323 -> 352
/*      */     //   32: iload_3
/*      */     //   33: iconst_4
/*      */     //   34: if_icmplt +318 -> 352
/*      */     //   37: aload_2
/*      */     //   38: iconst_0
/*      */     //   39: baload
/*      */     //   40: sipush 255
/*      */     //   43: iand
/*      */     //   44: aload_2
/*      */     //   45: iconst_1
/*      */     //   46: baload
/*      */     //   47: bipush 8
/*      */     //   49: ishl
/*      */     //   50: ldc_w 264
/*      */     //   53: iand
/*      */     //   54: ior
/*      */     //   55: istore 4
/*      */     //   57: ldc_w 265
/*      */     //   60: iload 4
/*      */     //   62: if_icmpne +290 -> 352
/*      */     //   65: aconst_null
/*      */     //   66: astore 5
/*      */     //   68: aconst_null
/*      */     //   69: astore 6
/*      */     //   71: aconst_null
/*      */     //   72: astore 7
/*      */     //   74: sipush 2048
/*      */     //   77: newarray <illegal type>
/*      */     //   79: astore 8
/*      */     //   81: iconst_0
/*      */     //   82: istore 9
/*      */     //   84: new 94	java/io/ByteArrayOutputStream
/*      */     //   87: dup
/*      */     //   88: invokespecial 96	java/io/ByteArrayOutputStream:<init>	()V
/*      */     //   91: astore 7
/*      */     //   93: new 266	java/io/ByteArrayInputStream
/*      */     //   96: dup
/*      */     //   97: aload_2
/*      */     //   98: invokespecial 268	java/io/ByteArrayInputStream:<init>	([B)V
/*      */     //   101: astore 5
/*      */     //   103: new 269	java/util/zip/GZIPInputStream
/*      */     //   106: dup
/*      */     //   107: aload 5
/*      */     //   109: invokespecial 271	java/util/zip/GZIPInputStream:<init>	(Ljava/io/InputStream;)V
/*      */     //   112: astore 6
/*      */     //   114: aload 6
/*      */     //   116: aload 8
/*      */     //   118: invokevirtual 274	java/util/zip/GZIPInputStream:read	([B)I
/*      */     //   121: istore 10
/*      */     //   123: goto +22 -> 145
/*      */     //   126: aload 7
/*      */     //   128: aload 8
/*      */     //   130: iconst_0
/*      */     //   131: iload 9
/*      */     //   133: invokevirtual 278	java/io/ByteArrayOutputStream:write	([BII)V
/*      */     //   136: aload 6
/*      */     //   138: aload 8
/*      */     //   140: invokevirtual 274	java/util/zip/GZIPInputStream:read	([B)I
/*      */     //   143: istore 10
/*      */     //   145: iload 10
/*      */     //   147: dup
/*      */     //   148: istore 9
/*      */     //   150: ifge -24 -> 126
/*      */     //   153: aload 7
/*      */     //   155: invokevirtual 127	java/io/ByteArrayOutputStream:toByteArray	()[B
/*      */     //   158: astore_2
/*      */     //   159: goto +133 -> 292
/*      */     //   162: astore 10
/*      */     //   164: aload 7
/*      */     //   166: invokevirtual 124	java/io/ByteArrayOutputStream:close	()V
/*      */     //   169: goto +15 -> 184
/*      */     //   172: astore 12
/*      */     //   174: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   177: aload 12
/*      */     //   179: invokeinterface 114 2 0
/*      */     //   184: aload 6
/*      */     //   186: invokevirtual 279	java/util/zip/GZIPInputStream:close	()V
/*      */     //   189: goto +15 -> 204
/*      */     //   192: astore 12
/*      */     //   194: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   197: aload 12
/*      */     //   199: invokeinterface 114 2 0
/*      */     //   204: aload 5
/*      */     //   206: invokevirtual 280	java/io/ByteArrayInputStream:close	()V
/*      */     //   209: goto +143 -> 352
/*      */     //   212: astore 12
/*      */     //   214: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   217: aload 12
/*      */     //   219: invokeinterface 114 2 0
/*      */     //   224: goto +128 -> 352
/*      */     //   227: astore 11
/*      */     //   229: aload 7
/*      */     //   231: invokevirtual 124	java/io/ByteArrayOutputStream:close	()V
/*      */     //   234: goto +15 -> 249
/*      */     //   237: astore 12
/*      */     //   239: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   242: aload 12
/*      */     //   244: invokeinterface 114 2 0
/*      */     //   249: aload 6
/*      */     //   251: invokevirtual 279	java/util/zip/GZIPInputStream:close	()V
/*      */     //   254: goto +15 -> 269
/*      */     //   257: astore 12
/*      */     //   259: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   262: aload 12
/*      */     //   264: invokeinterface 114 2 0
/*      */     //   269: aload 5
/*      */     //   271: invokevirtual 280	java/io/ByteArrayInputStream:close	()V
/*      */     //   274: goto +15 -> 289
/*      */     //   277: astore 12
/*      */     //   279: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   282: aload 12
/*      */     //   284: invokeinterface 114 2 0
/*      */     //   289: aload 11
/*      */     //   291: athrow
/*      */     //   292: aload 7
/*      */     //   294: invokevirtual 124	java/io/ByteArrayOutputStream:close	()V
/*      */     //   297: goto +15 -> 312
/*      */     //   300: astore 12
/*      */     //   302: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   305: aload 12
/*      */     //   307: invokeinterface 114 2 0
/*      */     //   312: aload 6
/*      */     //   314: invokevirtual 279	java/util/zip/GZIPInputStream:close	()V
/*      */     //   317: goto +15 -> 332
/*      */     //   320: astore 12
/*      */     //   322: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   325: aload 12
/*      */     //   327: invokeinterface 114 2 0
/*      */     //   332: aload 5
/*      */     //   334: invokevirtual 280	java/io/ByteArrayInputStream:close	()V
/*      */     //   337: goto +15 -> 352
/*      */     //   340: astore 12
/*      */     //   342: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   345: aload 12
/*      */     //   347: invokeinterface 114 2 0
/*      */     //   352: aload_2
/*      */     //   353: areturn
/*      */     // Line number table:
/*      */     //   Java source line #979	-> byte code offset #0
/*      */     //   Java source line #980	-> byte code offset #7
/*      */     //   Java source line #981	-> byte code offset #10
/*      */     //   Java source line #983	-> byte code offset #11
/*      */     //   Java source line #988	-> byte code offset #16
/*      */     //   Java source line #993	-> byte code offset #25
/*      */     //   Java source line #994	-> byte code offset #28
/*      */     //   Java source line #997	-> byte code offset #37
/*      */     //   Java source line #998	-> byte code offset #57
/*      */     //   Java source line #1000	-> byte code offset #65
/*      */     //   Java source line #1001	-> byte code offset #68
/*      */     //   Java source line #1002	-> byte code offset #71
/*      */     //   Java source line #1003	-> byte code offset #74
/*      */     //   Java source line #1004	-> byte code offset #81
/*      */     //   Java source line #1008	-> byte code offset #84
/*      */     //   Java source line #1009	-> byte code offset #93
/*      */     //   Java source line #1010	-> byte code offset #103
/*      */     //   Java source line #1012	-> byte code offset #114
/*      */     //   Java source line #1013	-> byte code offset #123
/*      */     //   Java source line #1015	-> byte code offset #126
/*      */     //   Java source line #1016	-> byte code offset #136
/*      */     //   Java source line #1013	-> byte code offset #145
/*      */     //   Java source line #1020	-> byte code offset #153
/*      */     //   Java source line #1022	-> byte code offset #159
/*      */     //   Java source line #1023	-> byte code offset #162
/*      */     //   Java source line #1029	-> byte code offset #164
/*      */     //   Java source line #1030	-> byte code offset #184
/*      */     //   Java source line #1031	-> byte code offset #204
/*      */     //   Java source line #1028	-> byte code offset #227
/*      */     //   Java source line #1029	-> byte code offset #229
/*      */     //   Java source line #1030	-> byte code offset #249
/*      */     //   Java source line #1031	-> byte code offset #269
/*      */     //   Java source line #1032	-> byte code offset #289
/*      */     //   Java source line #1029	-> byte code offset #292
/*      */     //   Java source line #1030	-> byte code offset #312
/*      */     //   Java source line #1031	-> byte code offset #332
/*      */     //   Java source line #1037	-> byte code offset #352
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	354	0	s	String
/*      */     //   0	354	1	options	int
/*      */     //   6	2	2	bytes	byte[]
/*      */     //   15	338	2	bytes	byte[]
/*      */     //   10	2	3	uee	java.io.UnsupportedEncodingException
/*      */     //   27	6	3	l	int
/*      */     //   55	6	4	head	int
/*      */     //   66	267	5	bais	java.io.ByteArrayInputStream
/*      */     //   69	244	6	gzis	java.util.zip.GZIPInputStream
/*      */     //   72	221	7	baos	java.io.ByteArrayOutputStream
/*      */     //   79	60	8	buffer	byte[]
/*      */     //   82	67	9	length	int
/*      */     //   121	25	10	longitud	int
/*      */     //   162	1	10	localIOException	IOException
/*      */     //   227	63	11	localObject	Object
/*      */     //   172	6	12	e	Exception
/*      */     //   192	6	12	e	Exception
/*      */     //   212	6	12	e	Exception
/*      */     //   237	6	12	e	Exception
/*      */     //   257	6	12	e	Exception
/*      */     //   277	6	12	e	Exception
/*      */     //   300	6	12	e	Exception
/*      */     //   320	6	12	e	Exception
/*      */     //   340	6	12	e	Exception
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   0	7	10	java/io/UnsupportedEncodingException
/*      */     //   84	159	162	java/io/IOException
/*      */     //   164	169	172	java/lang/Exception
/*      */     //   184	189	192	java/lang/Exception
/*      */     //   204	209	212	java/lang/Exception
/*      */     //   84	164	227	finally
/*      */     //   229	234	237	java/lang/Exception
/*      */     //   249	254	257	java/lang/Exception
/*      */     //   269	274	277	java/lang/Exception
/*      */     //   292	297	300	java/lang/Exception
/*      */     //   312	317	320	java/lang/Exception
/*      */     //   332	337	340	java/lang/Exception
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public static Object decodeToObject(String encodedObject)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokestatic 294	es/mityc/firmaJava/libreria/utilidades/Base64:decode	(Ljava/lang/String;)[B
/*      */     //   4: astore_1
/*      */     //   5: aconst_null
/*      */     //   6: astore_2
/*      */     //   7: aconst_null
/*      */     //   8: astore_3
/*      */     //   9: aconst_null
/*      */     //   10: astore 4
/*      */     //   12: new 266	java/io/ByteArrayInputStream
/*      */     //   15: dup
/*      */     //   16: aload_1
/*      */     //   17: invokespecial 268	java/io/ByteArrayInputStream:<init>	([B)V
/*      */     //   20: astore_2
/*      */     //   21: new 296	java/io/ObjectInputStream
/*      */     //   24: dup
/*      */     //   25: aload_2
/*      */     //   26: invokespecial 298	java/io/ObjectInputStream:<init>	(Ljava/io/InputStream;)V
/*      */     //   29: astore_3
/*      */     //   30: aload_3
/*      */     //   31: invokevirtual 299	java/io/ObjectInputStream:readObject	()Ljava/lang/Object;
/*      */     //   34: astore 4
/*      */     //   36: goto +158 -> 194
/*      */     //   39: astore 5
/*      */     //   41: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   44: aload 5
/*      */     //   46: invokeinterface 114 2 0
/*      */     //   51: aconst_null
/*      */     //   52: astore 4
/*      */     //   54: aload_2
/*      */     //   55: invokevirtual 280	java/io/ByteArrayInputStream:close	()V
/*      */     //   58: goto +15 -> 73
/*      */     //   61: astore 7
/*      */     //   63: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   66: aload 7
/*      */     //   68: invokeinterface 114 2 0
/*      */     //   73: aload_3
/*      */     //   74: invokevirtual 302	java/io/ObjectInputStream:close	()V
/*      */     //   77: goto +155 -> 232
/*      */     //   80: astore 7
/*      */     //   82: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   85: aload 7
/*      */     //   87: invokeinterface 114 2 0
/*      */     //   92: goto +140 -> 232
/*      */     //   95: astore 5
/*      */     //   97: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   100: aload 5
/*      */     //   102: invokeinterface 114 2 0
/*      */     //   107: aconst_null
/*      */     //   108: astore 4
/*      */     //   110: aload_2
/*      */     //   111: invokevirtual 280	java/io/ByteArrayInputStream:close	()V
/*      */     //   114: goto +15 -> 129
/*      */     //   117: astore 7
/*      */     //   119: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   122: aload 7
/*      */     //   124: invokeinterface 114 2 0
/*      */     //   129: aload_3
/*      */     //   130: invokevirtual 302	java/io/ObjectInputStream:close	()V
/*      */     //   133: goto +99 -> 232
/*      */     //   136: astore 7
/*      */     //   138: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   141: aload 7
/*      */     //   143: invokeinterface 114 2 0
/*      */     //   148: goto +84 -> 232
/*      */     //   151: astore 6
/*      */     //   153: aload_2
/*      */     //   154: invokevirtual 280	java/io/ByteArrayInputStream:close	()V
/*      */     //   157: goto +15 -> 172
/*      */     //   160: astore 7
/*      */     //   162: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   165: aload 7
/*      */     //   167: invokeinterface 114 2 0
/*      */     //   172: aload_3
/*      */     //   173: invokevirtual 302	java/io/ObjectInputStream:close	()V
/*      */     //   176: goto +15 -> 191
/*      */     //   179: astore 7
/*      */     //   181: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   184: aload 7
/*      */     //   186: invokeinterface 114 2 0
/*      */     //   191: aload 6
/*      */     //   193: athrow
/*      */     //   194: aload_2
/*      */     //   195: invokevirtual 280	java/io/ByteArrayInputStream:close	()V
/*      */     //   198: goto +15 -> 213
/*      */     //   201: astore 7
/*      */     //   203: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   206: aload 7
/*      */     //   208: invokeinterface 114 2 0
/*      */     //   213: aload_3
/*      */     //   214: invokevirtual 302	java/io/ObjectInputStream:close	()V
/*      */     //   217: goto +15 -> 232
/*      */     //   220: astore 7
/*      */     //   222: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   225: aload 7
/*      */     //   227: invokeinterface 114 2 0
/*      */     //   232: aload 4
/*      */     //   234: areturn
/*      */     // Line number table:
/*      */     //   Java source line #1054	-> byte code offset #0
/*      */     //   Java source line #1056	-> byte code offset #5
/*      */     //   Java source line #1057	-> byte code offset #7
/*      */     //   Java source line #1058	-> byte code offset #9
/*      */     //   Java source line #1062	-> byte code offset #12
/*      */     //   Java source line #1063	-> byte code offset #21
/*      */     //   Java source line #1065	-> byte code offset #30
/*      */     //   Java source line #1066	-> byte code offset #36
/*      */     //   Java source line #1067	-> byte code offset #39
/*      */     //   Java source line #1069	-> byte code offset #41
/*      */     //   Java source line #1070	-> byte code offset #51
/*      */     //   Java source line #1079	-> byte code offset #54
/*      */     //   Java source line #1080	-> byte code offset #73
/*      */     //   Java source line #1072	-> byte code offset #95
/*      */     //   Java source line #1074	-> byte code offset #97
/*      */     //   Java source line #1075	-> byte code offset #107
/*      */     //   Java source line #1079	-> byte code offset #110
/*      */     //   Java source line #1080	-> byte code offset #129
/*      */     //   Java source line #1078	-> byte code offset #151
/*      */     //   Java source line #1079	-> byte code offset #153
/*      */     //   Java source line #1080	-> byte code offset #172
/*      */     //   Java source line #1081	-> byte code offset #191
/*      */     //   Java source line #1079	-> byte code offset #194
/*      */     //   Java source line #1080	-> byte code offset #213
/*      */     //   Java source line #1083	-> byte code offset #232
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	235	0	encodedObject	String
/*      */     //   4	13	1	objBytes	byte[]
/*      */     //   6	189	2	bais	java.io.ByteArrayInputStream
/*      */     //   8	206	3	ois	java.io.ObjectInputStream
/*      */     //   10	223	4	obj	Object
/*      */     //   39	6	5	e	IOException
/*      */     //   95	6	5	e	ClassNotFoundException
/*      */     //   151	41	6	localObject1	Object
/*      */     //   61	6	7	e	Exception
/*      */     //   80	6	7	e	Exception
/*      */     //   117	6	7	e	Exception
/*      */     //   136	6	7	e	Exception
/*      */     //   160	6	7	e	Exception
/*      */     //   179	6	7	e	Exception
/*      */     //   201	6	7	e	Exception
/*      */     //   220	6	7	e	Exception
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	36	39	java/io/IOException
/*      */     //   54	58	61	java/lang/Exception
/*      */     //   73	77	80	java/lang/Exception
/*      */     //   12	36	95	java/lang/ClassNotFoundException
/*      */     //   110	114	117	java/lang/Exception
/*      */     //   129	133	136	java/lang/Exception
/*      */     //   12	54	151	finally
/*      */     //   95	110	151	finally
/*      */     //   153	157	160	java/lang/Exception
/*      */     //   172	176	179	java/lang/Exception
/*      */     //   194	198	201	java/lang/Exception
/*      */     //   213	217	220	java/lang/Exception
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public static boolean encodeToFile(byte[] dataToEncode, String filename)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: iconst_0
/*      */     //   1: istore_2
/*      */     //   2: aconst_null
/*      */     //   3: astore_3
/*      */     //   4: aconst_null
/*      */     //   5: astore 4
/*      */     //   7: new 97	es/mityc/firmaJava/libreria/utilidades/Base64$OutputStream
/*      */     //   10: dup
/*      */     //   11: new 314	java/io/FileOutputStream
/*      */     //   14: dup
/*      */     //   15: aload_1
/*      */     //   16: invokespecial 316	java/io/FileOutputStream:<init>	(Ljava/lang/String;)V
/*      */     //   19: iconst_1
/*      */     //   20: invokespecial 99	es/mityc/firmaJava/libreria/utilidades/Base64$OutputStream:<init>	(Ljava/io/OutputStream;I)V
/*      */     //   23: astore_3
/*      */     //   24: new 317	java/io/BufferedOutputStream
/*      */     //   27: dup
/*      */     //   28: aload_3
/*      */     //   29: invokespecial 319	java/io/BufferedOutputStream:<init>	(Ljava/io/OutputStream;)V
/*      */     //   32: astore 4
/*      */     //   34: aload 4
/*      */     //   36: aload_0
/*      */     //   37: invokevirtual 320	java/io/BufferedOutputStream:write	([B)V
/*      */     //   40: iconst_1
/*      */     //   41: istore_2
/*      */     //   42: goto +63 -> 105
/*      */     //   45: astore 5
/*      */     //   47: iconst_0
/*      */     //   48: istore_2
/*      */     //   49: aload_3
/*      */     //   50: invokevirtual 123	es/mityc/firmaJava/libreria/utilidades/Base64$OutputStream:close	()V
/*      */     //   53: aload 4
/*      */     //   55: invokevirtual 322	java/io/BufferedOutputStream:close	()V
/*      */     //   58: goto +71 -> 129
/*      */     //   61: astore 7
/*      */     //   63: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   66: aload 7
/*      */     //   68: invokeinterface 114 2 0
/*      */     //   73: goto +56 -> 129
/*      */     //   76: astore 6
/*      */     //   78: aload_3
/*      */     //   79: invokevirtual 123	es/mityc/firmaJava/libreria/utilidades/Base64$OutputStream:close	()V
/*      */     //   82: aload 4
/*      */     //   84: invokevirtual 322	java/io/BufferedOutputStream:close	()V
/*      */     //   87: goto +15 -> 102
/*      */     //   90: astore 7
/*      */     //   92: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   95: aload 7
/*      */     //   97: invokeinterface 114 2 0
/*      */     //   102: aload 6
/*      */     //   104: athrow
/*      */     //   105: aload_3
/*      */     //   106: invokevirtual 123	es/mityc/firmaJava/libreria/utilidades/Base64$OutputStream:close	()V
/*      */     //   109: aload 4
/*      */     //   111: invokevirtual 322	java/io/BufferedOutputStream:close	()V
/*      */     //   114: goto +15 -> 129
/*      */     //   117: astore 7
/*      */     //   119: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   122: aload 7
/*      */     //   124: invokeinterface 114 2 0
/*      */     //   129: iload_2
/*      */     //   130: ireturn
/*      */     // Line number table:
/*      */     //   Java source line #1099	-> byte code offset #0
/*      */     //   Java source line #1100	-> byte code offset #2
/*      */     //   Java source line #1101	-> byte code offset #4
/*      */     //   Java source line #1105	-> byte code offset #7
/*      */     //   Java source line #1106	-> byte code offset #11
/*      */     //   Java source line #1105	-> byte code offset #20
/*      */     //   Java source line #1108	-> byte code offset #24
/*      */     //   Java source line #1109	-> byte code offset #34
/*      */     //   Java source line #1110	-> byte code offset #40
/*      */     //   Java source line #1111	-> byte code offset #42
/*      */     //   Java source line #1112	-> byte code offset #45
/*      */     //   Java source line #1115	-> byte code offset #47
/*      */     //   Java source line #1119	-> byte code offset #49
/*      */     //   Java source line #1120	-> byte code offset #53
/*      */     //   Java source line #1121	-> byte code offset #58
/*      */     //   Java source line #1118	-> byte code offset #76
/*      */     //   Java source line #1119	-> byte code offset #78
/*      */     //   Java source line #1120	-> byte code offset #82
/*      */     //   Java source line #1121	-> byte code offset #87
/*      */     //   Java source line #1122	-> byte code offset #102
/*      */     //   Java source line #1119	-> byte code offset #105
/*      */     //   Java source line #1120	-> byte code offset #109
/*      */     //   Java source line #1121	-> byte code offset #114
/*      */     //   Java source line #1124	-> byte code offset #129
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	131	0	dataToEncode	byte[]
/*      */     //   0	131	1	filename	String
/*      */     //   1	129	2	success	boolean
/*      */     //   3	103	3	bos	OutputStream
/*      */     //   5	105	4	bfos	java.io.BufferedOutputStream
/*      */     //   45	3	5	e	IOException
/*      */     //   76	27	6	localObject	Object
/*      */     //   61	6	7	e	Exception
/*      */     //   90	6	7	e	Exception
/*      */     //   117	6	7	e	Exception
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	42	45	java/io/IOException
/*      */     //   49	58	61	java/lang/Exception
/*      */     //   7	49	76	finally
/*      */     //   78	87	90	java/lang/Exception
/*      */     //   105	114	117	java/lang/Exception
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public static boolean decodeToFile(String dataToDecode, String filename)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: iconst_0
/*      */     //   1: istore_2
/*      */     //   2: aconst_null
/*      */     //   3: astore_3
/*      */     //   4: aconst_null
/*      */     //   5: astore 4
/*      */     //   7: new 97	es/mityc/firmaJava/libreria/utilidades/Base64$OutputStream
/*      */     //   10: dup
/*      */     //   11: new 314	java/io/FileOutputStream
/*      */     //   14: dup
/*      */     //   15: aload_1
/*      */     //   16: invokespecial 316	java/io/FileOutputStream:<init>	(Ljava/lang/String;)V
/*      */     //   19: iconst_0
/*      */     //   20: invokespecial 99	es/mityc/firmaJava/libreria/utilidades/Base64$OutputStream:<init>	(Ljava/io/OutputStream;I)V
/*      */     //   23: astore_3
/*      */     //   24: new 317	java/io/BufferedOutputStream
/*      */     //   27: dup
/*      */     //   28: aload_3
/*      */     //   29: invokespecial 319	java/io/BufferedOutputStream:<init>	(Ljava/io/OutputStream;)V
/*      */     //   32: astore 4
/*      */     //   34: aload 4
/*      */     //   36: aload_0
/*      */     //   37: ldc 18
/*      */     //   39: invokevirtual 257	java/lang/String:getBytes	(Ljava/lang/String;)[B
/*      */     //   42: invokevirtual 320	java/io/BufferedOutputStream:write	([B)V
/*      */     //   45: iconst_1
/*      */     //   46: istore_2
/*      */     //   47: goto +63 -> 110
/*      */     //   50: astore 5
/*      */     //   52: iconst_0
/*      */     //   53: istore_2
/*      */     //   54: aload_3
/*      */     //   55: invokevirtual 123	es/mityc/firmaJava/libreria/utilidades/Base64$OutputStream:close	()V
/*      */     //   58: aload 4
/*      */     //   60: invokevirtual 322	java/io/BufferedOutputStream:close	()V
/*      */     //   63: goto +71 -> 134
/*      */     //   66: astore 7
/*      */     //   68: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   71: aload 7
/*      */     //   73: invokeinterface 114 2 0
/*      */     //   78: goto +56 -> 134
/*      */     //   81: astore 6
/*      */     //   83: aload_3
/*      */     //   84: invokevirtual 123	es/mityc/firmaJava/libreria/utilidades/Base64$OutputStream:close	()V
/*      */     //   87: aload 4
/*      */     //   89: invokevirtual 322	java/io/BufferedOutputStream:close	()V
/*      */     //   92: goto +15 -> 107
/*      */     //   95: astore 7
/*      */     //   97: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   100: aload 7
/*      */     //   102: invokeinterface 114 2 0
/*      */     //   107: aload 6
/*      */     //   109: athrow
/*      */     //   110: aload_3
/*      */     //   111: invokevirtual 123	es/mityc/firmaJava/libreria/utilidades/Base64$OutputStream:close	()V
/*      */     //   114: aload 4
/*      */     //   116: invokevirtual 322	java/io/BufferedOutputStream:close	()V
/*      */     //   119: goto +15 -> 134
/*      */     //   122: astore 7
/*      */     //   124: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   127: aload 7
/*      */     //   129: invokeinterface 114 2 0
/*      */     //   134: iload_2
/*      */     //   135: ireturn
/*      */     // Line number table:
/*      */     //   Java source line #1139	-> byte code offset #0
/*      */     //   Java source line #1140	-> byte code offset #2
/*      */     //   Java source line #1141	-> byte code offset #4
/*      */     //   Java source line #1144	-> byte code offset #7
/*      */     //   Java source line #1145	-> byte code offset #11
/*      */     //   Java source line #1144	-> byte code offset #20
/*      */     //   Java source line #1146	-> byte code offset #24
/*      */     //   Java source line #1147	-> byte code offset #34
/*      */     //   Java source line #1148	-> byte code offset #45
/*      */     //   Java source line #1149	-> byte code offset #47
/*      */     //   Java source line #1150	-> byte code offset #50
/*      */     //   Java source line #1152	-> byte code offset #52
/*      */     //   Java source line #1156	-> byte code offset #54
/*      */     //   Java source line #1157	-> byte code offset #58
/*      */     //   Java source line #1158	-> byte code offset #63
/*      */     //   Java source line #1155	-> byte code offset #81
/*      */     //   Java source line #1156	-> byte code offset #83
/*      */     //   Java source line #1157	-> byte code offset #87
/*      */     //   Java source line #1158	-> byte code offset #92
/*      */     //   Java source line #1159	-> byte code offset #107
/*      */     //   Java source line #1156	-> byte code offset #110
/*      */     //   Java source line #1157	-> byte code offset #114
/*      */     //   Java source line #1158	-> byte code offset #119
/*      */     //   Java source line #1161	-> byte code offset #134
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	136	0	dataToDecode	String
/*      */     //   0	136	1	filename	String
/*      */     //   1	134	2	success	boolean
/*      */     //   3	108	3	bos	OutputStream
/*      */     //   5	110	4	bfos	java.io.BufferedOutputStream
/*      */     //   50	3	5	e	IOException
/*      */     //   81	27	6	localObject	Object
/*      */     //   66	6	7	e	Exception
/*      */     //   95	6	7	e	Exception
/*      */     //   122	6	7	e	Exception
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	47	50	java/io/IOException
/*      */     //   54	63	66	java/lang/Exception
/*      */     //   7	54	81	finally
/*      */     //   83	92	95	java/lang/Exception
/*      */     //   110	119	122	java/lang/Exception
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public static byte[] decodeFromFile(String filename)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aconst_null
/*      */     //   1: astore_1
/*      */     //   2: aconst_null
/*      */     //   3: astore_2
/*      */     //   4: new 333	java/io/File
/*      */     //   7: dup
/*      */     //   8: aload_0
/*      */     //   9: invokespecial 335	java/io/File:<init>	(Ljava/lang/String;)V
/*      */     //   12: astore_3
/*      */     //   13: aconst_null
/*      */     //   14: astore 4
/*      */     //   16: iconst_0
/*      */     //   17: istore 5
/*      */     //   19: iconst_0
/*      */     //   20: istore 6
/*      */     //   22: aload_3
/*      */     //   23: invokevirtual 336	java/io/File:length	()J
/*      */     //   26: lstore 7
/*      */     //   28: lload 7
/*      */     //   30: ldc2_w 339
/*      */     //   33: lcmp
/*      */     //   34: ifle +62 -> 96
/*      */     //   37: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   40: new 199	java/lang/StringBuilder
/*      */     //   43: dup
/*      */     //   44: ldc_w 341
/*      */     //   47: invokespecial 234	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   50: aload_3
/*      */     //   51: invokevirtual 336	java/io/File:length	()J
/*      */     //   54: invokevirtual 343	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
/*      */     //   57: ldc_w 346
/*      */     //   60: invokevirtual 208	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   63: invokevirtual 211	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   66: invokeinterface 114 2 0
/*      */     //   71: aload_2
/*      */     //   72: ifnull +22 -> 94
/*      */     //   75: aload_2
/*      */     //   76: invokevirtual 348	es/mityc/firmaJava/libreria/utilidades/Base64$InputStream:close	()V
/*      */     //   79: goto +15 -> 94
/*      */     //   82: astore 11
/*      */     //   84: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   87: aload 11
/*      */     //   89: invokeinterface 114 2 0
/*      */     //   94: aconst_null
/*      */     //   95: areturn
/*      */     //   96: aload_3
/*      */     //   97: invokevirtual 336	java/io/File:length	()J
/*      */     //   100: l2i
/*      */     //   101: newarray <illegal type>
/*      */     //   103: astore 4
/*      */     //   105: new 349	es/mityc/firmaJava/libreria/utilidades/Base64$InputStream
/*      */     //   108: dup
/*      */     //   109: new 351	java/io/BufferedInputStream
/*      */     //   112: dup
/*      */     //   113: new 353	java/io/FileInputStream
/*      */     //   116: dup
/*      */     //   117: aload_3
/*      */     //   118: invokespecial 355	java/io/FileInputStream:<init>	(Ljava/io/File;)V
/*      */     //   121: invokespecial 358	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
/*      */     //   124: iconst_0
/*      */     //   125: invokespecial 359	es/mityc/firmaJava/libreria/utilidades/Base64$InputStream:<init>	(Ljava/io/InputStream;I)V
/*      */     //   128: astore_2
/*      */     //   129: aload_2
/*      */     //   130: aload 4
/*      */     //   132: iload 5
/*      */     //   134: sipush 4096
/*      */     //   137: invokevirtual 362	es/mityc/firmaJava/libreria/utilidades/Base64$InputStream:read	([BII)I
/*      */     //   140: istore 9
/*      */     //   142: goto +23 -> 165
/*      */     //   145: iload 5
/*      */     //   147: iload 6
/*      */     //   149: iadd
/*      */     //   150: istore 5
/*      */     //   152: aload_2
/*      */     //   153: aload 4
/*      */     //   155: iload 5
/*      */     //   157: sipush 4096
/*      */     //   160: invokevirtual 362	es/mityc/firmaJava/libreria/utilidades/Base64$InputStream:read	([BII)I
/*      */     //   163: istore 9
/*      */     //   165: iload 9
/*      */     //   167: dup
/*      */     //   168: istore 6
/*      */     //   170: ifge -25 -> 145
/*      */     //   173: iload 5
/*      */     //   175: newarray <illegal type>
/*      */     //   177: astore_1
/*      */     //   178: aload 4
/*      */     //   180: iconst_0
/*      */     //   181: aload_1
/*      */     //   182: iconst_0
/*      */     //   183: iload 5
/*      */     //   185: invokestatic 236	java/lang/System:arraycopy	(Ljava/lang/Object;ILjava/lang/Object;II)V
/*      */     //   188: goto +83 -> 271
/*      */     //   191: astore_3
/*      */     //   192: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   195: new 199	java/lang/StringBuilder
/*      */     //   198: dup
/*      */     //   199: ldc_w 365
/*      */     //   202: invokespecial 234	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   205: aload_0
/*      */     //   206: invokevirtual 208	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   209: invokevirtual 211	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   212: invokeinterface 114 2 0
/*      */     //   217: aload_2
/*      */     //   218: ifnull +76 -> 294
/*      */     //   221: aload_2
/*      */     //   222: invokevirtual 348	es/mityc/firmaJava/libreria/utilidades/Base64$InputStream:close	()V
/*      */     //   225: goto +69 -> 294
/*      */     //   228: astore 11
/*      */     //   230: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   233: aload 11
/*      */     //   235: invokeinterface 114 2 0
/*      */     //   240: goto +54 -> 294
/*      */     //   243: astore 10
/*      */     //   245: aload_2
/*      */     //   246: ifnull +22 -> 268
/*      */     //   249: aload_2
/*      */     //   250: invokevirtual 348	es/mityc/firmaJava/libreria/utilidades/Base64$InputStream:close	()V
/*      */     //   253: goto +15 -> 268
/*      */     //   256: astore 11
/*      */     //   258: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   261: aload 11
/*      */     //   263: invokeinterface 114 2 0
/*      */     //   268: aload 10
/*      */     //   270: athrow
/*      */     //   271: aload_2
/*      */     //   272: ifnull +22 -> 294
/*      */     //   275: aload_2
/*      */     //   276: invokevirtual 348	es/mityc/firmaJava/libreria/utilidades/Base64$InputStream:close	()V
/*      */     //   279: goto +15 -> 294
/*      */     //   282: astore 11
/*      */     //   284: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   287: aload 11
/*      */     //   289: invokeinterface 114 2 0
/*      */     //   294: aload_1
/*      */     //   295: areturn
/*      */     // Line number table:
/*      */     //   Java source line #1178	-> byte code offset #0
/*      */     //   Java source line #1179	-> byte code offset #2
/*      */     //   Java source line #1183	-> byte code offset #4
/*      */     //   Java source line #1184	-> byte code offset #13
/*      */     //   Java source line #1185	-> byte code offset #16
/*      */     //   Java source line #1186	-> byte code offset #19
/*      */     //   Java source line #1189	-> byte code offset #22
/*      */     //   Java source line #1190	-> byte code offset #28
/*      */     //   Java source line #1192	-> byte code offset #37
/*      */     //   Java source line #1221	-> byte code offset #71
/*      */     //   Java source line #1222	-> byte code offset #75
/*      */     //   Java source line #1224	-> byte code offset #79
/*      */     //   Java source line #1193	-> byte code offset #94
/*      */     //   Java source line #1195	-> byte code offset #96
/*      */     //   Java source line #1198	-> byte code offset #105
/*      */     //   Java source line #1199	-> byte code offset #109
/*      */     //   Java source line #1200	-> byte code offset #113
/*      */     //   Java source line #1199	-> byte code offset #121
/*      */     //   Java source line #1200	-> byte code offset #124
/*      */     //   Java source line #1198	-> byte code offset #125
/*      */     //   Java source line #1203	-> byte code offset #129
/*      */     //   Java source line #1204	-> byte code offset #142
/*      */     //   Java source line #1205	-> byte code offset #145
/*      */     //   Java source line #1206	-> byte code offset #152
/*      */     //   Java source line #1204	-> byte code offset #165
/*      */     //   Java source line #1210	-> byte code offset #173
/*      */     //   Java source line #1211	-> byte code offset #178
/*      */     //   Java source line #1213	-> byte code offset #188
/*      */     //   Java source line #1214	-> byte code offset #191
/*      */     //   Java source line #1216	-> byte code offset #192
/*      */     //   Java source line #1221	-> byte code offset #217
/*      */     //   Java source line #1222	-> byte code offset #221
/*      */     //   Java source line #1224	-> byte code offset #225
/*      */     //   Java source line #1219	-> byte code offset #243
/*      */     //   Java source line #1221	-> byte code offset #245
/*      */     //   Java source line #1222	-> byte code offset #249
/*      */     //   Java source line #1224	-> byte code offset #253
/*      */     //   Java source line #1225	-> byte code offset #268
/*      */     //   Java source line #1221	-> byte code offset #271
/*      */     //   Java source line #1222	-> byte code offset #275
/*      */     //   Java source line #1224	-> byte code offset #279
/*      */     //   Java source line #1227	-> byte code offset #294
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	296	0	filename	String
/*      */     //   1	294	1	decodedData	byte[]
/*      */     //   3	273	2	bis	InputStream
/*      */     //   12	106	3	file	java.io.File
/*      */     //   191	2	3	e	IOException
/*      */     //   14	165	4	buffer	byte[]
/*      */     //   17	167	5	length	int
/*      */     //   20	149	6	numBytes	int
/*      */     //   26	3	7	len	long
/*      */     //   140	26	9	longitud	int
/*      */     //   243	26	10	localObject	Object
/*      */     //   82	6	11	e	Exception
/*      */     //   228	6	11	e	Exception
/*      */     //   256	6	11	e	Exception
/*      */     //   282	6	11	e	Exception
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   71	79	82	java/lang/Exception
/*      */     //   4	71	191	java/io/IOException
/*      */     //   96	188	191	java/io/IOException
/*      */     //   217	225	228	java/lang/Exception
/*      */     //   4	71	243	finally
/*      */     //   96	217	243	finally
/*      */     //   245	253	256	java/lang/Exception
/*      */     //   271	279	282	java/lang/Exception
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public static String encodeFromFile(String filename)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aconst_null
/*      */     //   1: astore_1
/*      */     //   2: aconst_null
/*      */     //   3: astore_2
/*      */     //   4: new 333	java/io/File
/*      */     //   7: dup
/*      */     //   8: aload_0
/*      */     //   9: invokespecial 335	java/io/File:<init>	(Ljava/lang/String;)V
/*      */     //   12: astore_3
/*      */     //   13: aload_3
/*      */     //   14: invokevirtual 336	java/io/File:length	()J
/*      */     //   17: l2d
/*      */     //   18: ldc2_w 376
/*      */     //   21: dmul
/*      */     //   22: d2i
/*      */     //   23: bipush 40
/*      */     //   25: invokestatic 378	java/lang/Math:max	(II)I
/*      */     //   28: newarray <illegal type>
/*      */     //   30: astore 4
/*      */     //   32: iconst_0
/*      */     //   33: istore 5
/*      */     //   35: iconst_0
/*      */     //   36: istore 6
/*      */     //   38: new 349	es/mityc/firmaJava/libreria/utilidades/Base64$InputStream
/*      */     //   41: dup
/*      */     //   42: new 351	java/io/BufferedInputStream
/*      */     //   45: dup
/*      */     //   46: new 353	java/io/FileInputStream
/*      */     //   49: dup
/*      */     //   50: aload_3
/*      */     //   51: invokespecial 355	java/io/FileInputStream:<init>	(Ljava/io/File;)V
/*      */     //   54: invokespecial 358	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
/*      */     //   57: iconst_1
/*      */     //   58: invokespecial 359	es/mityc/firmaJava/libreria/utilidades/Base64$InputStream:<init>	(Ljava/io/InputStream;I)V
/*      */     //   61: astore_2
/*      */     //   62: aload_2
/*      */     //   63: aload 4
/*      */     //   65: iload 5
/*      */     //   67: sipush 4096
/*      */     //   70: invokevirtual 362	es/mityc/firmaJava/libreria/utilidades/Base64$InputStream:read	([BII)I
/*      */     //   73: istore 7
/*      */     //   75: goto +23 -> 98
/*      */     //   78: iload 5
/*      */     //   80: iload 6
/*      */     //   82: iadd
/*      */     //   83: istore 5
/*      */     //   85: aload_2
/*      */     //   86: aload 4
/*      */     //   88: iload 5
/*      */     //   90: sipush 4096
/*      */     //   93: invokevirtual 362	es/mityc/firmaJava/libreria/utilidades/Base64$InputStream:read	([BII)I
/*      */     //   96: istore 7
/*      */     //   98: iload 7
/*      */     //   100: dup
/*      */     //   101: istore 6
/*      */     //   103: ifge -25 -> 78
/*      */     //   106: new 125	java/lang/String
/*      */     //   109: dup
/*      */     //   110: aload 4
/*      */     //   112: iconst_0
/*      */     //   113: iload 5
/*      */     //   115: ldc 18
/*      */     //   117: invokespecial 174	java/lang/String:<init>	([BIILjava/lang/String;)V
/*      */     //   120: astore_1
/*      */     //   121: goto +75 -> 196
/*      */     //   124: astore_3
/*      */     //   125: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   128: new 199	java/lang/StringBuilder
/*      */     //   131: dup
/*      */     //   132: ldc_w 384
/*      */     //   135: invokespecial 234	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   138: aload_0
/*      */     //   139: invokevirtual 208	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   142: invokevirtual 211	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   145: invokeinterface 114 2 0
/*      */     //   150: aload_2
/*      */     //   151: invokevirtual 348	es/mityc/firmaJava/libreria/utilidades/Base64$InputStream:close	()V
/*      */     //   154: goto +61 -> 215
/*      */     //   157: astore 9
/*      */     //   159: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   162: aload 9
/*      */     //   164: invokeinterface 114 2 0
/*      */     //   169: goto +46 -> 215
/*      */     //   172: astore 8
/*      */     //   174: aload_2
/*      */     //   175: invokevirtual 348	es/mityc/firmaJava/libreria/utilidades/Base64$InputStream:close	()V
/*      */     //   178: goto +15 -> 193
/*      */     //   181: astore 9
/*      */     //   183: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   186: aload 9
/*      */     //   188: invokeinterface 114 2 0
/*      */     //   193: aload 8
/*      */     //   195: athrow
/*      */     //   196: aload_2
/*      */     //   197: invokevirtual 348	es/mityc/firmaJava/libreria/utilidades/Base64$InputStream:close	()V
/*      */     //   200: goto +15 -> 215
/*      */     //   203: astore 9
/*      */     //   205: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   208: aload 9
/*      */     //   210: invokeinterface 114 2 0
/*      */     //   215: aload_1
/*      */     //   216: areturn
/*      */     // Line number table:
/*      */     //   Java source line #1243	-> byte code offset #0
/*      */     //   Java source line #1244	-> byte code offset #2
/*      */     //   Java source line #1248	-> byte code offset #4
/*      */     //   Java source line #1249	-> byte code offset #13
/*      */     //   Java source line #1250	-> byte code offset #32
/*      */     //   Java source line #1251	-> byte code offset #35
/*      */     //   Java source line #1254	-> byte code offset #38
/*      */     //   Java source line #1255	-> byte code offset #42
/*      */     //   Java source line #1256	-> byte code offset #46
/*      */     //   Java source line #1255	-> byte code offset #54
/*      */     //   Java source line #1256	-> byte code offset #57
/*      */     //   Java source line #1254	-> byte code offset #58
/*      */     //   Java source line #1259	-> byte code offset #62
/*      */     //   Java source line #1260	-> byte code offset #75
/*      */     //   Java source line #1261	-> byte code offset #78
/*      */     //   Java source line #1262	-> byte code offset #85
/*      */     //   Java source line #1260	-> byte code offset #98
/*      */     //   Java source line #1267	-> byte code offset #106
/*      */     //   Java source line #1269	-> byte code offset #121
/*      */     //   Java source line #1270	-> byte code offset #124
/*      */     //   Java source line #1272	-> byte code offset #125
/*      */     //   Java source line #1276	-> byte code offset #150
/*      */     //   Java source line #1275	-> byte code offset #172
/*      */     //   Java source line #1276	-> byte code offset #174
/*      */     //   Java source line #1277	-> byte code offset #193
/*      */     //   Java source line #1276	-> byte code offset #196
/*      */     //   Java source line #1279	-> byte code offset #215
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	217	0	filename	String
/*      */     //   1	215	1	encodedData	String
/*      */     //   3	194	2	bis	InputStream
/*      */     //   12	39	3	file	java.io.File
/*      */     //   124	2	3	e	IOException
/*      */     //   30	81	4	buffer	byte[]
/*      */     //   33	81	5	length	int
/*      */     //   36	66	6	numBytes	int
/*      */     //   73	26	7	nBytes	int
/*      */     //   172	22	8	localObject	Object
/*      */     //   157	6	9	e	Exception
/*      */     //   181	6	9	e	Exception
/*      */     //   203	6	9	e	Exception
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   4	121	124	java/io/IOException
/*      */     //   150	154	157	java/lang/Exception
/*      */     //   4	150	172	finally
/*      */     //   174	178	181	java/lang/Exception
/*      */     //   196	200	203	java/lang/Exception
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public static void encodeFileToFile(String infile, String outfile)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokestatic 390	es/mityc/firmaJava/libreria/utilidades/Base64:encodeFromFile	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   4: astore_2
/*      */     //   5: aconst_null
/*      */     //   6: astore_3
/*      */     //   7: new 317	java/io/BufferedOutputStream
/*      */     //   10: dup
/*      */     //   11: new 314	java/io/FileOutputStream
/*      */     //   14: dup
/*      */     //   15: aload_1
/*      */     //   16: invokespecial 316	java/io/FileOutputStream:<init>	(Ljava/lang/String;)V
/*      */     //   19: invokespecial 319	java/io/BufferedOutputStream:<init>	(Ljava/io/OutputStream;)V
/*      */     //   22: astore_3
/*      */     //   23: aload_3
/*      */     //   24: aload_2
/*      */     //   25: ldc_w 392
/*      */     //   28: invokevirtual 257	java/lang/String:getBytes	(Ljava/lang/String;)[B
/*      */     //   31: invokevirtual 394	java/io/OutputStream:write	([B)V
/*      */     //   34: goto +61 -> 95
/*      */     //   37: astore 4
/*      */     //   39: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   42: aload 4
/*      */     //   44: invokeinterface 114 2 0
/*      */     //   49: aload_3
/*      */     //   50: invokevirtual 397	java/io/OutputStream:close	()V
/*      */     //   53: goto +61 -> 114
/*      */     //   56: astore 6
/*      */     //   58: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   61: aload 6
/*      */     //   63: invokeinterface 114 2 0
/*      */     //   68: goto +46 -> 114
/*      */     //   71: astore 5
/*      */     //   73: aload_3
/*      */     //   74: invokevirtual 397	java/io/OutputStream:close	()V
/*      */     //   77: goto +15 -> 92
/*      */     //   80: astore 6
/*      */     //   82: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   85: aload 6
/*      */     //   87: invokeinterface 114 2 0
/*      */     //   92: aload 5
/*      */     //   94: athrow
/*      */     //   95: aload_3
/*      */     //   96: invokevirtual 397	java/io/OutputStream:close	()V
/*      */     //   99: goto +15 -> 114
/*      */     //   102: astore 6
/*      */     //   104: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   107: aload 6
/*      */     //   109: invokeinterface 114 2 0
/*      */     //   114: return
/*      */     // Line number table:
/*      */     //   Java source line #1291	-> byte code offset #0
/*      */     //   Java source line #1292	-> byte code offset #5
/*      */     //   Java source line #1294	-> byte code offset #7
/*      */     //   Java source line #1295	-> byte code offset #11
/*      */     //   Java source line #1294	-> byte code offset #19
/*      */     //   Java source line #1296	-> byte code offset #23
/*      */     //   Java source line #1297	-> byte code offset #34
/*      */     //   Java source line #1298	-> byte code offset #37
/*      */     //   Java source line #1299	-> byte code offset #39
/*      */     //   Java source line #1302	-> byte code offset #49
/*      */     //   Java source line #1303	-> byte code offset #56
/*      */     //   Java source line #1301	-> byte code offset #71
/*      */     //   Java source line #1302	-> byte code offset #73
/*      */     //   Java source line #1303	-> byte code offset #80
/*      */     //   Java source line #1304	-> byte code offset #92
/*      */     //   Java source line #1302	-> byte code offset #95
/*      */     //   Java source line #1303	-> byte code offset #102
/*      */     //   Java source line #1305	-> byte code offset #114
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	115	0	infile	String
/*      */     //   0	115	1	outfile	String
/*      */     //   4	21	2	encoded	String
/*      */     //   6	90	3	out	OutputStream
/*      */     //   37	6	4	ex	IOException
/*      */     //   71	22	5	localObject	Object
/*      */     //   56	6	6	ex	Exception
/*      */     //   80	6	6	ex	Exception
/*      */     //   102	6	6	ex	Exception
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	34	37	java/io/IOException
/*      */     //   49	53	56	java/lang/Exception
/*      */     //   7	49	71	finally
/*      */     //   73	77	80	java/lang/Exception
/*      */     //   95	99	102	java/lang/Exception
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public static void decodeFileToFile(String infile, String outfile)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokestatic 404	es/mityc/firmaJava/libreria/utilidades/Base64:decodeFromFile	(Ljava/lang/String;)[B
/*      */     //   4: astore_2
/*      */     //   5: aconst_null
/*      */     //   6: astore_3
/*      */     //   7: new 317	java/io/BufferedOutputStream
/*      */     //   10: dup
/*      */     //   11: new 314	java/io/FileOutputStream
/*      */     //   14: dup
/*      */     //   15: aload_1
/*      */     //   16: invokespecial 316	java/io/FileOutputStream:<init>	(Ljava/lang/String;)V
/*      */     //   19: invokespecial 319	java/io/BufferedOutputStream:<init>	(Ljava/io/OutputStream;)V
/*      */     //   22: astore_3
/*      */     //   23: aload_3
/*      */     //   24: aload_2
/*      */     //   25: invokevirtual 394	java/io/OutputStream:write	([B)V
/*      */     //   28: goto +61 -> 89
/*      */     //   31: astore 4
/*      */     //   33: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   36: aload 4
/*      */     //   38: invokeinterface 114 2 0
/*      */     //   43: aload_3
/*      */     //   44: invokevirtual 397	java/io/OutputStream:close	()V
/*      */     //   47: goto +61 -> 108
/*      */     //   50: astore 6
/*      */     //   52: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   55: aload 6
/*      */     //   57: invokeinterface 114 2 0
/*      */     //   62: goto +46 -> 108
/*      */     //   65: astore 5
/*      */     //   67: aload_3
/*      */     //   68: invokevirtual 397	java/io/OutputStream:close	()V
/*      */     //   71: goto +15 -> 86
/*      */     //   74: astore 6
/*      */     //   76: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   79: aload 6
/*      */     //   81: invokeinterface 114 2 0
/*      */     //   86: aload 5
/*      */     //   88: athrow
/*      */     //   89: aload_3
/*      */     //   90: invokevirtual 397	java/io/OutputStream:close	()V
/*      */     //   93: goto +15 -> 108
/*      */     //   96: astore 6
/*      */     //   98: getstatic 40	es/mityc/firmaJava/libreria/utilidades/Base64:log	Lorg/apache/commons/logging/Log;
/*      */     //   101: aload 6
/*      */     //   103: invokeinterface 114 2 0
/*      */     //   108: return
/*      */     // Line number table:
/*      */     //   Java source line #1317	-> byte code offset #0
/*      */     //   Java source line #1318	-> byte code offset #5
/*      */     //   Java source line #1320	-> byte code offset #7
/*      */     //   Java source line #1321	-> byte code offset #11
/*      */     //   Java source line #1320	-> byte code offset #19
/*      */     //   Java source line #1322	-> byte code offset #23
/*      */     //   Java source line #1323	-> byte code offset #28
/*      */     //   Java source line #1324	-> byte code offset #31
/*      */     //   Java source line #1325	-> byte code offset #33
/*      */     //   Java source line #1328	-> byte code offset #43
/*      */     //   Java source line #1329	-> byte code offset #50
/*      */     //   Java source line #1327	-> byte code offset #65
/*      */     //   Java source line #1328	-> byte code offset #67
/*      */     //   Java source line #1329	-> byte code offset #74
/*      */     //   Java source line #1330	-> byte code offset #86
/*      */     //   Java source line #1328	-> byte code offset #89
/*      */     //   Java source line #1329	-> byte code offset #96
/*      */     //   Java source line #1331	-> byte code offset #108
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	109	0	infile	String
/*      */     //   0	109	1	outfile	String
/*      */     //   4	21	2	decoded	byte[]
/*      */     //   6	84	3	out	OutputStream
/*      */     //   31	6	4	ex	IOException
/*      */     //   65	22	5	localObject	Object
/*      */     //   50	6	6	ex	Exception
/*      */     //   74	6	6	ex	Exception
/*      */     //   96	6	6	ex	Exception
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	28	31	java/io/IOException
/*      */     //   43	47	50	java/lang/Exception
/*      */     //   7	43	65	finally
/*      */     //   67	71	74	java/lang/Exception
/*      */     //   89	93	96	java/lang/Exception
/*      */   }
/*      */   
/*      */   public static class InputStream
/*      */     extends FilterInputStream
/*      */   {
/*      */     private boolean encode;
/*      */     private int position;
/*      */     private byte[] buffer;
/*      */     private int bufferLength;
/*      */     private int numSigBytes;
/*      */     private int lineLength;
/*      */     private boolean breakLines;
/*      */     private int options;
/*      */     private byte[] decodabet;
/*      */     
/*      */     public InputStream(InputStream in)
/*      */     {
/* 1368 */       this(in, 0);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public InputStream(InputStream in, int options)
/*      */     {
/* 1395 */       super();
/* 1396 */       this.breakLines = ((options & 0x8) != 8);
/* 1397 */       this.encode = ((options & 0x1) == 1);
/* 1398 */       this.bufferLength = (this.encode ? 4 : 3);
/* 1399 */       this.buffer = new byte[this.bufferLength];
/* 1400 */       this.position = -1;
/* 1401 */       this.lineLength = 0;
/* 1402 */       this.options = options;
/*      */       
/* 1404 */       this.decodabet = Base64.getDecodabet(options);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public int read()
/*      */       throws IOException
/*      */     {
/* 1417 */       if (this.position < 0)
/*      */       {
/* 1419 */         if (this.encode)
/*      */         {
/* 1421 */           byte[] b3 = new byte[3];
/* 1422 */           int numBinaryBytes = 0;
/* 1423 */           for (int i = 0; i < 3; i++)
/*      */           {
/*      */             try
/*      */             {
/* 1427 */               int b = this.in.read();
/*      */               
/*      */ 
/* 1430 */               if (b >= 0)
/*      */               {
/* 1432 */                 b3[i] = ((byte)b);
/* 1433 */                 numBinaryBytes++;
/*      */               }
/*      */               
/*      */ 
/*      */             }
/*      */             catch (IOException e)
/*      */             {
/* 1440 */               if (i == 0) {
/* 1441 */                 throw e;
/*      */               }
/*      */             }
/*      */           }
/*      */           
/* 1446 */           if (numBinaryBytes > 0)
/*      */           {
/* 1448 */             Base64.encode3to4(b3, 0, numBinaryBytes, this.buffer, 0, this.options);
/* 1449 */             this.position = 0;
/* 1450 */             this.numSigBytes = 4;
/*      */           }
/*      */           else
/*      */           {
/* 1454 */             return -1;
/*      */           }
/*      */           
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 1461 */           byte[] b4 = new byte[4];
/* 1462 */           int i = 0;
/* 1463 */           byte[] deco = (byte[])this.decodabet.clone();
/* 1464 */           byte whiteSpace = -5;
/* 1465 */           for (i = 0; i < 4; i++)
/*      */           {
/*      */ 
/* 1468 */             int b = 0;
/* 1469 */             do { b = this.in.read();
/* 1470 */             } while ((b >= 0) && (deco[(b & 0x7F)] <= whiteSpace));
/*      */             
/* 1472 */             if (b < 0) {
/*      */               break;
/*      */             }
/* 1475 */             b4[i] = ((byte)b);
/*      */           }
/*      */           
/* 1478 */           if (i == 4)
/*      */           {
/* 1480 */             this.numSigBytes = Base64.decode4to3(b4, 0, this.buffer, 0, this.options);
/* 1481 */             this.position = 0;
/*      */           } else {
/* 1483 */             if (i == 0) {
/* 1484 */               return -1;
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 1490 */             throw new IOException("Improperly padded Base64 input.");
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1497 */       if (this.position >= 0)
/*      */       {
/*      */ 
/* 1500 */         if (this.position >= this.numSigBytes) {
/* 1501 */           return -1;
/*      */         }
/* 1503 */         if ((this.encode) && (this.breakLines) && (this.lineLength >= 76))
/*      */         {
/* 1505 */           this.lineLength = 0;
/* 1506 */           return 10;
/*      */         }
/*      */         
/*      */ 
/* 1510 */         this.lineLength += 1;
/*      */         
/*      */ 
/*      */ 
/* 1514 */         int b = this.buffer[(this.position++)];
/*      */         
/* 1516 */         if (this.position >= this.bufferLength) {
/* 1517 */           this.position = -1;
/*      */         }
/* 1519 */         return b & 0xFF;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1528 */       throw new IOException("Error in Base64 code reading stream.");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public int read(byte[] dest, int off, int len)
/*      */       throws IOException
/*      */     {
/* 1549 */       for (int i = 0; i < len; i++)
/*      */       {
/* 1551 */         int b = read();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1556 */         if (b >= 0) {
/* 1557 */           dest[(off + i)] = ((byte)b);
/* 1558 */         } else { if (i != 0) break;
/* 1559 */           return -1;
/*      */         }
/*      */       }
/*      */       
/* 1563 */       return i;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class OutputStream
/*      */     extends FilterOutputStream
/*      */   {
/*      */     private boolean encode;
/*      */     
/*      */ 
/*      */ 
/*      */     private int position;
/*      */     
/*      */ 
/*      */     private byte[] buffer;
/*      */     
/*      */ 
/*      */     private int bufferLength;
/*      */     
/*      */ 
/*      */     private int lineLength;
/*      */     
/*      */ 
/*      */     private boolean breakLines;
/*      */     
/*      */ 
/*      */     private byte[] b4;
/*      */     
/*      */ 
/*      */     private boolean suspendEncoding;
/*      */     
/*      */ 
/*      */     private int options;
/*      */     
/*      */ 
/*      */     private byte[] decodabet;
/*      */     
/*      */ 
/*      */ 
/*      */     public OutputStream(OutputStream out)
/*      */     {
/* 1607 */       this(out, 1);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public OutputStream(OutputStream out, int options)
/*      */     {
/* 1633 */       super();
/* 1634 */       this.breakLines = ((options & 0x8) != 8);
/* 1635 */       this.encode = ((options & 0x1) == 1);
/* 1636 */       this.bufferLength = (this.encode ? 3 : 4);
/* 1637 */       this.buffer = new byte[this.bufferLength];
/* 1638 */       this.position = 0;
/* 1639 */       this.lineLength = 0;
/* 1640 */       this.suspendEncoding = false;
/* 1641 */       this.b4 = new byte[4];
/* 1642 */       this.options = options;
/*      */       
/* 1644 */       this.decodabet = Base64.getDecodabet(options);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void write(int theByte)
/*      */       throws IOException
/*      */     {
/* 1663 */       if (this.suspendEncoding)
/*      */       {
/* 1665 */         this.out.write(theByte);
/* 1666 */         return;
/*      */       }
/*      */       
/*      */ 
/* 1670 */       if (this.encode)
/*      */       {
/* 1672 */         this.buffer[(this.position++)] = ((byte)theByte);
/* 1673 */         if (this.position >= this.bufferLength)
/*      */         {
/* 1675 */           this.out.write(Base64.encode3to4(this.b4, this.buffer, this.bufferLength, this.options));
/*      */           
/* 1677 */           this.lineLength += 4;
/* 1678 */           if ((this.breakLines) && (this.lineLength >= 76))
/*      */           {
/* 1680 */             this.out.write(10);
/* 1681 */             this.lineLength = 0;
/*      */           }
/*      */           
/* 1684 */           this.position = 0;
/*      */ 
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */       }
/* 1692 */       else if (this.decodabet[(theByte & 0x7F)] > -5)
/*      */       {
/* 1694 */         this.buffer[(this.position++)] = ((byte)theByte);
/* 1695 */         if (this.position >= this.bufferLength)
/*      */         {
/* 1697 */           int len = Base64.decode4to3(this.buffer, 0, this.b4, 0, this.options);
/* 1698 */           this.out.write(this.b4, 0, len);
/*      */           
/* 1700 */           this.position = 0;
/*      */         }
/*      */       }
/* 1703 */       else if (this.decodabet[(theByte & 0x7F)] != -5)
/*      */       {
/* 1705 */         throw new IOException("Invalid character in Base64 data.");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void write(byte[] theBytes, int off, int len)
/*      */       throws IOException
/*      */     {
/* 1724 */       if (this.suspendEncoding)
/*      */       {
/* 1726 */         this.out.write(theBytes, off, len);
/* 1727 */         return;
/*      */       }
/*      */       
/* 1730 */       for (int i = 0; i < len; i++)
/*      */       {
/* 1732 */         write(theBytes[(off + i)]);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void flushBase64()
/*      */       throws IOException
/*      */     {
/* 1745 */       if (this.position > 0)
/*      */       {
/* 1747 */         if (this.encode)
/*      */         {
/* 1749 */           this.out.write(Base64.encode3to4(this.b4, this.buffer, this.position, this.options));
/* 1750 */           this.position = 0;
/*      */         }
/*      */         else
/*      */         {
/* 1754 */           throw new IOException("Base64 input not properly padded.");
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void close()
/*      */       throws IOException
/*      */     {
/* 1769 */       flushBase64();
/*      */       
/*      */ 
/*      */ 
/* 1773 */       super.close();
/*      */       
/* 1775 */       this.buffer = null;
/* 1776 */       this.out = null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void suspendEncoding()
/*      */       throws IOException
/*      */     {
/* 1790 */       flushBase64();
/* 1791 */       this.suspendEncoding = true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void resumeEncoding()
/*      */     {
/* 1804 */       this.suspendEncoding = false;
/*      */     }
/*      */   }
/*      */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\utilidades\Base64.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */