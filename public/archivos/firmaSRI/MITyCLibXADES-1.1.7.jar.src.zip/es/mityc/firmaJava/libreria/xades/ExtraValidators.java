/*     */ package es.mityc.firmaJava.libreria.xades;
/*     */ 
/*     */ import es.mityc.javasign.certificate.ICertStatusRecoverer;
/*     */ import es.mityc.javasign.trust.TrustAbstract;
/*     */ import es.mityc.javasign.xml.xades.policy.IValidacionPolicy;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExtraValidators
/*     */ {
/*     */   private List<IValidacionPolicy> policies;
/*     */   private ICertStatusRecoverer certStatus;
/*     */   private TrustAbstract trusterOCSP;
/*     */   private TrustAbstract trusterCRL;
/*     */   private TrustAbstract trusterCerts;
/*     */   private TrustAbstract trusterTSA;
/*     */   
/*     */   public ExtraValidators(List<IValidacionPolicy> policies, ICertStatusRecoverer certStatus, TrustAbstract trusterCerts)
/*     */   {
/*  54 */     this.policies = policies;
/*  55 */     this.certStatus = certStatus;
/*  56 */     this.trusterCerts = trusterCerts;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<IValidacionPolicy> getPolicies()
/*     */   {
/*  63 */     return this.policies;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setPolicies(List<IValidacionPolicy> policies)
/*     */   {
/*  69 */     this.policies = policies;
/*     */   }
/*     */   
/*     */ 
/*     */   public ICertStatusRecoverer getCertStatus()
/*     */   {
/*  75 */     return this.certStatus;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setCertStatus(ICertStatusRecoverer certStatus)
/*     */   {
/*  81 */     this.certStatus = certStatus;
/*     */   }
/*     */   
/*     */ 
/*     */   public TrustAbstract getTrusterOCSP()
/*     */   {
/*  87 */     return this.trusterOCSP;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setTrusterOCSP(TrustAbstract trusterOCSP)
/*     */   {
/*  93 */     this.trusterOCSP = trusterOCSP;
/*     */   }
/*     */   
/*     */ 
/*     */   public TrustAbstract getTrusterCRL()
/*     */   {
/*  99 */     return this.trusterCRL;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setTrusterCRL(TrustAbstract trusterCRL)
/*     */   {
/* 105 */     this.trusterCRL = trusterCRL;
/*     */   }
/*     */   
/*     */ 
/*     */   public TrustAbstract getTrusterCerts()
/*     */   {
/* 111 */     return this.trusterCerts;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setTrusterCerts(TrustAbstract trusterCerts)
/*     */   {
/* 117 */     this.trusterCerts = trusterCerts;
/*     */   }
/*     */   
/*     */ 
/*     */   public TrustAbstract getTrusterTSA()
/*     */   {
/* 123 */     return this.trusterTSA;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setTrusterTSA(TrustAbstract trusterTSA)
/*     */   {
/* 129 */     this.trusterTSA = trusterTSA;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\ExtraValidators.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */