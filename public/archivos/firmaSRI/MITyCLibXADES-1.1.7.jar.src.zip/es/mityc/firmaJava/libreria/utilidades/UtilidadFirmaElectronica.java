/*     */ package es.mityc.firmaJava.libreria.utilidades;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import java.io.IOException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.Principal;
/*     */ import java.security.cert.CertificateExpiredException;
/*     */ import java.security.cert.CertificateNotYetValidException;
/*     */ import java.security.cert.X509CertSelector;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UtilidadFirmaElectronica
/*     */ {
/*  49 */   private static final Log LOG = LogFactory.getLog(UtilidadFirmaElectronica.class);
/*     */   
/*  51 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibXAdES");
/*     */   
/*     */ 
/*     */   private static final String POLICY_DNIE_AUTHENTICATE = "2.16.724.1.2.2.2.4";
/*     */   
/*     */ 
/*     */   private static final String POLICY_DNIE_SIGN = "2.16.724.1.2.2.2.3";
/*     */   
/*  59 */   private static final X509CertSelector CS_DNIE_AUTHENTICATE = new X509CertSelector();
/*     */   
/*  61 */   private static final X509CertSelector CS_DNIE_SIGN = new X509CertSelector();
/*     */   public static final String DIGEST_ALG_SHA1 = "http://www.w3.org/2000/09/xmldsig#sha1";
/*     */   
/*  64 */   static { try { CS_DNIE_AUTHENTICATE.setPolicy(new HashSet(Arrays.asList(new String[] { "2.16.724.1.2.2.2.4" })));
/*  65 */       CS_DNIE_SIGN.setPolicy(new HashSet(Arrays.asList(new String[] { "2.16.724.1.2.2.2.3" })));
/*     */     } catch (IOException ex) {
/*  67 */       LOG.warn(I18N.getLocalMessage("i18n.mityc.xades.utils.2"));
/*  68 */       if (LOG.isDebugEnabled()) {
/*  69 */         LOG.debug(ex.getMessage(), ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String decodeUTF(byte[] input)
/*     */   {
/*  80 */     int longitud = input.length;
/*  81 */     char[] output = new char[longitud];
/*  82 */     int i = 0;
/*  83 */     int j = 0;
/*  84 */     while (i < longitud) {
/*  85 */       int b = input[(i++)] & 0xFF;
/*     */       
/*  87 */       switch (b >>> 5)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */       default: 
/*  93 */         output[(j++)] = ((char)(b & 0x7F));
/*  94 */         break;
/*     */       
/*     */ 
/*     */ 
/*     */       case 6: 
/*  99 */         int y = b & 0x1F;
/*     */         
/*     */ 
/* 102 */         int x = input[(i++)] & 0x3F;
/*     */         
/* 104 */         output[(j++)] = ((char)(y << 6 | x));
/* 105 */         break;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       case 7: 
/* 111 */         if ((b & 0x10) == 0) {
/* 112 */           throw new RuntimeException("UTF8Decoder does not handle 32-bit characters");
/*     */         }
/*     */         
/*     */ 
/* 116 */         int z = b & 0xF;
/*     */         
/*     */ 
/* 119 */         int y = input[(i++)] & 0x3F;
/*     */         
/*     */ 
/* 122 */         int x = input[(i++)] & 0x3F;
/*     */         
/* 124 */         int asint = z << 12 | y << 6 | x;
/* 125 */         output[(j++)] = ((char)asint);
/*     */       }
/*     */       
/*     */     }
/* 129 */     return new String(output, 0, j);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<X509Certificate> filtraCertificados(List<X509Certificate> listaCertificadosTemp, String emisorDN)
/*     */   {
/* 140 */     String[] allIssuers = emisorDN.split("#");
/* 141 */     List<X509Certificate> devuelveCertificados = new ArrayList();
/* 142 */     Date hoy = new Date();
/* 143 */     int longitudCertificados = listaCertificadosTemp.size();
/* 144 */     for (int a = 0; a < longitudCertificados; a++) {
/* 145 */       X509Certificate certTemp = (X509Certificate)listaCertificadosTemp.get(a);
/* 146 */       int longitudIssuers = allIssuers.length;
/* 147 */       for (int b = 0; b < longitudIssuers; b++) {
/* 148 */         if (certTemp.getIssuerDN().toString().indexOf(allIssuers[b]) >= 0) {
/*     */           try {
/* 150 */             certTemp.checkValidity(hoy);
/*     */           } catch (CertificateExpiredException e) {
/*     */             break;
/*     */           } catch (CertificateNotYetValidException e) {
/*     */             break;
/*     */           }
/* 156 */           devuelveCertificados.add(certTemp);
/* 157 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 161 */     return devuelveCertificados;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<X509Certificate> filtraDNIe(List<X509Certificate> listaCertificadosTemp)
/*     */   {
/* 170 */     if (LOG.isTraceEnabled()) {
/* 171 */       LOG.trace("Filtrando certificados del DNIe...");
/*     */     }
/* 173 */     List<X509Certificate> returnCertificates = new ArrayList();
/* 174 */     Date hoy = new Date();
/* 175 */     Iterator<X509Certificate> it = listaCertificadosTemp.iterator();
/* 176 */     while (it.hasNext()) {
/* 177 */       X509Certificate certTemp = (X509Certificate)it.next();
/*     */       try {
/* 179 */         certTemp.checkValidity(hoy);
/*     */       } catch (CertificateExpiredException e) {
/*     */         continue;
/*     */       } catch (CertificateNotYetValidException e) {
/*     */         continue;
/*     */       }
/* 185 */       if (!CS_DNIE_AUTHENTICATE.match(certTemp)) {
/* 186 */         returnCertificates.add(certTemp);
/*     */       }
/*     */     }
/*     */     
/* 190 */     return returnCertificates;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String obtenerTipoReference(String esquema)
/*     */   {
/* 200 */     String tipoEsquema = null;
/*     */     
/* 202 */     if ("http://uri.etsi.org/01903/v1.3.2#".equals(esquema)) {
/* 203 */       tipoEsquema = "http://uri.etsi.org/01903#SignedProperties";
/* 204 */     } else if ("http://uri.etsi.org/01903/v1.2.2#".equals(esquema)) {
/* 205 */       tipoEsquema = "http://uri.etsi.org/01903/v1.2.2#SignedProperties";
/* 206 */     } else if ("http://uri.etsi.org/01903/v1.1.1#".equals(esquema)) {
/* 207 */       tipoEsquema = "http://uri.etsi.org/01903/v1.1.1#SignedProperties";
/*     */     } else {
/* 209 */       LOG.error(I18n.getResource("libreriaxades.validarfirmaxml.error1"));
/* 210 */       return null;
/*     */     }
/*     */     
/* 213 */     return tipoEsquema;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String DIGEST_ALG_SHA256 = "http://www.w3.org/2001/04/xmldsig-more#sha256";
/*     */   
/*     */ 
/*     */   public static final String DIGEST_ALG_SHA256_enc = "http://www.w3.org/2001/04/xmlenc#sha256";
/*     */   
/*     */ 
/*     */   public static final String DIGEST_ALG_SHA256_hmac = "http://www.w3.org/2001/04/xmldsig-more#hmac-sha256";
/*     */   
/*     */ 
/*     */   public static final String DIGEST_ALG_SHA512 = "http://www.w3.org/2001/04/xmldsig-more#sha512";
/*     */   
/*     */ 
/*     */   public static final String DIGEST_ALG_SHA512_enc = "http://www.w3.org/2001/04/xmlenc#sha512";
/*     */   
/*     */ 
/*     */   public static final String DIGEST_ALG_SHA512_hmac = "http://www.w3.org/2001/04/xmldsig-more#hmac-sha512";
/*     */   
/*     */ 
/*     */   public static final String DIGEST_ALG_SHA224 = "http://www.w3.org/2001/04/xmldsig-more#sha224";
/*     */   
/*     */ 
/*     */   public static final String DIGEST_ALG_SHA384 = "http://www.w3.org/2001/04/xmldsig-more#sha384";
/*     */   
/*     */ 
/*     */   public static final String DIGEST_ALG_MD2 = "http://www.w3.org/2001/04/xmldsig-more#md2";
/*     */   
/*     */ 
/*     */   public static final String DIGEST_ALG_MD4 = "http://www.w3.org/2001/04/xmldsig-more#md4";
/*     */   
/*     */   public static final String DIGEST_ALG_MD5 = "http://www.w3.org/2001/04/xmldsig-more#md5";
/*     */   
/*     */   public static final String DIGEST_ALG_RIPEMD128 = "http://www.w3.org/2001/04/xmldsig-more#ripemd128";
/*     */   
/*     */   public static final String DIGEST_ALG_RIPEMD160 = "http://www.w3.org/2001/04/xmldsig-more#ripemd160";
/*     */   
/*     */   public static final String DIGEST_ALG_RIPEMD256 = "http://www.w3.org/2001/04/xmldsig-more#ripemd256";
/*     */   
/*     */   public static final String DIGEST_ALG_RIPEMD320 = "http://www.w3.org/2001/04/xmldsig-more#ripemd320";
/*     */   
/*     */   public static final String DIGEST_ALG_TIGER = "http://www.w3.org/2001/04/xmldsig-more#tiger";
/*     */   
/*     */   public static final String DIGEST_ALG_WHIRLPOOL = "http://www.w3.org/2001/04/xmldsig-more#whirlpool";
/*     */   
/*     */   public static final String DIGEST_ALG_GOST3411 = "http://www.w3.org/2001/04/xmldsig-more#gost3411";
/*     */   
/*     */   public static MessageDigest getMessageDigest(String uri)
/*     */   {
/* 265 */     MessageDigest md = null;
/* 266 */     if (uri != null) {
/*     */       try {
/* 268 */         if (uri.equals("http://www.w3.org/2000/09/xmldsig#sha1")) {
/* 269 */           md = MessageDigest.getInstance("SHA-1");
/* 270 */         } else if ((uri.equals("http://www.w3.org/2001/04/xmldsig-more#sha256")) || (uri.equals("http://www.w3.org/2001/04/xmlenc#sha256")) || (uri.equals("http://www.w3.org/2001/04/xmldsig-more#hmac-sha256"))) {
/* 271 */           md = MessageDigest.getInstance("SHA-256");
/* 272 */         } else if ((uri.equals("http://www.w3.org/2001/04/xmldsig-more#sha512")) || (uri.equals("http://www.w3.org/2001/04/xmlenc#sha512")) || (uri.equals("http://www.w3.org/2001/04/xmldsig-more#hmac-sha512"))) {
/* 273 */           md = MessageDigest.getInstance("SHA-512");
/* 274 */         } else if (uri.equals("http://www.w3.org/2001/04/xmldsig-more#sha224")) {
/* 275 */           md = MessageDigest.getInstance("SHA-224");
/* 276 */         } else if (uri.equals("http://www.w3.org/2001/04/xmldsig-more#sha384")) {
/* 277 */           md = MessageDigest.getInstance("SHA-384");
/* 278 */         } else if (uri.equals("http://www.w3.org/2001/04/xmldsig-more#md2")) {
/* 279 */           md = MessageDigest.getInstance("MD2");
/* 280 */         } else if (uri.equals("http://www.w3.org/2001/04/xmldsig-more#md4")) {
/* 281 */           md = MessageDigest.getInstance("MD4");
/* 282 */         } else if (uri.equals("http://www.w3.org/2001/04/xmldsig-more#md5")) {
/* 283 */           md = MessageDigest.getInstance("MD5");
/* 284 */         } else if (uri.equals("http://www.w3.org/2001/04/xmldsig-more#ripemd128")) {
/* 285 */           md = MessageDigest.getInstance("RIPEDM128");
/* 286 */         } else if (uri.equals("http://www.w3.org/2001/04/xmldsig-more#ripemd160")) {
/* 287 */           md = MessageDigest.getInstance("RIPEMD160");
/* 288 */         } else if (uri.equals("http://www.w3.org/2001/04/xmldsig-more#ripemd256")) {
/* 289 */           md = MessageDigest.getInstance("RIPEMD256");
/* 290 */         } else if (uri.equals("http://www.w3.org/2001/04/xmldsig-more#ripemd320")) {
/* 291 */           md = MessageDigest.getInstance("RIPEMD320");
/* 292 */         } else if (uri.equals("http://www.w3.org/2001/04/xmldsig-more#tiger")) {
/* 293 */           md = MessageDigest.getInstance("Tiger");
/* 294 */         } else if (uri.equals("http://www.w3.org/2001/04/xmldsig-more#whirlpool")) {
/* 295 */           md = MessageDigest.getInstance("WHIRLPOOL");
/* 296 */         } else if (uri.equals("http://www.w3.org/2001/04/xmldsig-more#gost3411"))
/* 297 */           md = MessageDigest.getInstance("GOST3411");
/*     */       } catch (NoSuchAlgorithmException ex) {
/* 299 */         LOG.info("Algoritmo de digest no disponible para: " + uri, ex);
/*     */       }
/*     */     }
/* 302 */     return md;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\utilidades\UtilidadFirmaElectronica.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */