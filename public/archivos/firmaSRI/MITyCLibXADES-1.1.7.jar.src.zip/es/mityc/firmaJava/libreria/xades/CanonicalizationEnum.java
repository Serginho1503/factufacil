/*    */ package es.mityc.firmaJava.libreria.xades;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CanonicalizationEnum
/*    */ {
/* 23 */   UNKNOWN("unknown"), 
/* 24 */   C14N_OMIT_COMMENTS("http://www.w3.org/TR/2001/REC-xml-c14n-20010315"), 
/* 25 */   C14N_WITH_COMMENTS("http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments"), 
/* 26 */   C14N_EXCL_OMIT_COMMENTS("http://www.w3.org/2001/10/xml-exc-c14n#"), 
/* 27 */   C14N_EXCL_WITH_COMMENTS("http://www.w3.org/2001/10/xml-exc-c14n#WithComments");
/*    */   
/*    */   private String value;
/*    */   
/*    */   private CanonicalizationEnum(String value) {
/* 32 */     this.value = value;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 37 */     return this.value;
/*    */   }
/*    */   
/*    */   public static CanonicalizationEnum getCanonicalization(String value) {
/* 41 */     if (value != null) {
/* 42 */       if ("http://www.w3.org/TR/2001/REC-xml-c14n-20010315".equals(value))
/* 43 */         return C14N_OMIT_COMMENTS;
/* 44 */       if ("http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments".equals(value))
/* 45 */         return C14N_WITH_COMMENTS;
/* 46 */       if ("http://www.w3.org/2001/10/xml-exc-c14n#".equals(value))
/* 47 */         return C14N_EXCL_OMIT_COMMENTS;
/* 48 */       if ("http://www.w3.org/2001/10/xml-exc-c14n#WithComments".equals(value))
/* 49 */         return C14N_EXCL_WITH_COMMENTS;
/*    */     }
/* 51 */     return UNKNOWN;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\CanonicalizationEnum.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */