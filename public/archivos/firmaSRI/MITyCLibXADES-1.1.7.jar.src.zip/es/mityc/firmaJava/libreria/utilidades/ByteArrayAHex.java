/*     */ package es.mityc.firmaJava.libreria.utilidades;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteArrayAHex
/*     */ {
/*  28 */   private static final char[] NIBBLE = {
/*  29 */     '0', '1', '2', '3', '4', '5', '6', '7', 
/*  30 */     '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String hexString(byte[] buf, int i, int longitud)
/*     */   {
/*  42 */     StringBuffer sb = new StringBuffer();
/*  43 */     for (int j = i; j < i + longitud; j++) {
/*  44 */       sb.append(NIBBLE[(buf[j] >>> 4 & 0xF)]);
/*  45 */       sb.append(NIBBLE[(buf[j] & 0xF)]);
/*     */     }
/*  47 */     return String.valueOf(sb);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String hexString(byte[] buf)
/*     */   {
/*  57 */     return hexString(buf, 0, buf.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte fromHexNibble(char n)
/*     */   {
/*  67 */     if (n <= '9')
/*  68 */       return (byte)(n - '0');
/*  69 */     if (n <= 'G')
/*  70 */       return (byte)(n - '7');
/*  71 */     return (byte)(n - 'W');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] fromHexString(String hex)
/*     */   {
/*  80 */     int l = hex.length() + 1 >>> 1;
/*  81 */     byte[] r = new byte[l];
/*  82 */     int i = 0;
/*  83 */     int j = 0;
/*  84 */     if (hex.length() % 2 != 0)
/*     */     {
/*  86 */       r[0] = fromHexNibble(hex.charAt(0));
/*  87 */       i = j = 1;
/*     */     }
/*  89 */     while (i < l)
/*  90 */       r[(i++)] = ((byte)(fromHexNibble(hex.charAt(j++)) << 4 | fromHexNibble(hex.charAt(j++))));
/*  91 */     return r;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] concatByteArrays(byte[] array1, byte[] array2)
/*     */   {
/*  99 */     if (array1.length == 0)
/* 100 */       return array2;
/* 101 */     if (array2.length == 0) {
/* 102 */       return array1;
/*     */     }
/*     */     
/* 105 */     int logitudFinal = array1.length + array2.length;
/* 106 */     byte[] arrayCombinado = new byte[logitudFinal];
/*     */     
/* 108 */     System.arraycopy(array1, 0, arrayCombinado, 0, array1.length);
/* 109 */     System.arraycopy(array2, 0, arrayCombinado, array1.length, array2.length);
/*     */     
/* 111 */     return arrayCombinado;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\utilidades\ByteArrayAHex.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */