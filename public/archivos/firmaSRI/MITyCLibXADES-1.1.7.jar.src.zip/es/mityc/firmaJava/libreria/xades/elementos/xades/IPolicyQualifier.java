package es.mityc.firmaJava.libreria.xades.elementos.xades;

import es.mityc.javasign.xml.xades.policy.PolicyException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public abstract interface IPolicyQualifier
{
  public abstract Node createPolicyQualifierContent(Document paramDocument)
    throws PolicyException;
  
  public abstract void loadPolicyQualifierContent(Element paramElement)
    throws PolicyException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\IPolicyQualifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */