/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.XMLDataDateTimeType;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.util.Date;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AbstractXadesDateElement
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private XMLDataDateTimeType data;
/*     */   private String nameElement;
/*     */   
/*     */   public AbstractXadesDateElement(XAdESSchemas schema, String nameElement, Date data)
/*     */   {
/*  43 */     super(schema);
/*  44 */     this.nameElement = nameElement;
/*  45 */     this.data = new XMLDataDateTimeType(data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractXadesDateElement(XAdESSchemas schema, String nameElement)
/*     */   {
/*  54 */     super(schema);
/*  55 */     this.nameElement = nameElement;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Element createElement(Document doc)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  63 */     if (this.data == null)
/*  64 */       throw new InvalidInfoNodeException("Información insuficiente para escribir elemento " + this.nameElement);
/*  65 */     Element res = doc.createElementNS(this.schema.getSchemaUri(), this.namespaceXAdES + ":" + this.nameElement);
/*  66 */     this.data.addContent(res);
/*  67 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Element createElement(Document doc, String namespaceXAdES)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  75 */     return super.createElement(doc, namespaceXAdES);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  83 */     if ((obj instanceof AbstractXadesDateElement)) {
/*  84 */       AbstractXadesDateElement desc = (AbstractXadesDateElement)obj;
/*  85 */       if ((this.nameElement.equals(desc.nameElement)) && (this.data.equals(desc.data))) {
/*  86 */         return true;
/*     */       }
/*     */     } else {
/*  89 */       return this.data.equals(obj); }
/*  90 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  98 */     checkElementName(element, this.schema.getSchemaUri(), this.nameElement);
/*  99 */     this.data = new XMLDataDateTimeType(null);
/* 100 */     this.data.load(element);
/*     */   }
/*     */   
/*     */   public void setValue(Date value) {
/* 104 */     if (this.data == null) {
/* 105 */       this.data = new XMLDataDateTimeType(value);
/*     */     } else
/* 107 */       this.data.setValue(value);
/*     */   }
/*     */   
/*     */   public Date getValue() {
/* 111 */     if (this.data != null)
/* 112 */       return this.data.getValue();
/* 113 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isThisNode(Node node)
/*     */   {
/* 121 */     return isElementName(nodeToElement(node), this.schema.getSchemaUri(), this.nameElement);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\AbstractXadesDateElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */