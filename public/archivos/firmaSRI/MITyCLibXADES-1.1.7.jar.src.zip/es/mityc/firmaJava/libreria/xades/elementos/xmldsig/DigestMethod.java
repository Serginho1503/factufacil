/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xmldsig;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DigestMethod
/*     */   extends AbstractXDsigElement
/*     */ {
/*     */   private String algorithm;
/*     */   
/*     */   public DigestMethod(String algorithm)
/*     */   {
/*  40 */     this.algorithm = algorithm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Element createElement(Document doc)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  48 */     if (this.algorithm == null)
/*  49 */       throw new InvalidInfoNodeException("Información insuficiente para escribir elemento DigestMethod");
/*  50 */     Element res = doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", this.namespaceXDsig + ":" + "DigestMethod");
/*  51 */     res.setAttributeNS(null, "Algorithm", this.algorithm);
/*  52 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Element createElement(Document doc, String namespaceXDsig)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  60 */     return super.createElement(doc, namespaceXDsig);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  68 */     if ((obj instanceof DigestMethod)) {
/*  69 */       DigestMethod method = (DigestMethod)obj;
/*  70 */       if (this.algorithm.equals(method.algorithm))
/*  71 */         return true;
/*     */     }
/*  73 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  81 */     checkElementName(element, "http://www.w3.org/2000/09/xmldsig#", "DigestMethod");
/*  82 */     if (!element.hasAttribute("Algorithm"))
/*  83 */       throw new InvalidInfoNodeException("Atributo requerido no presenteAlgorithm");
/*  84 */     this.algorithm = element.getAttribute("Algorithm");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getAlgorithm()
/*     */   {
/*  91 */     return this.algorithm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setAlgorithm(String algorithm)
/*     */   {
/*  98 */     this.algorithm = algorithm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isThisNode(Node node)
/*     */   {
/* 106 */     return isElementName(nodeToElement(node), "http://www.w3.org/2000/09/xmldsig#", "DigestMethod");
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xmldsig\DigestMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */