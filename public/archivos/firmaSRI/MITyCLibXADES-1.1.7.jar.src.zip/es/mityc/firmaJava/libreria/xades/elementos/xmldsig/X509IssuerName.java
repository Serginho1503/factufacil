/*    */ package es.mityc.firmaJava.libreria.xades.elementos.xmldsig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class X509IssuerName
/*    */   extends AbstractXDSigStringElement
/*    */ {
/*    */   public X509IssuerName(String data)
/*    */   {
/* 29 */     super("X509IssuerName", data);
/*    */   }
/*    */   
/*    */   public X509IssuerName() {
/* 33 */     super("X509IssuerName");
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xmldsig\X509IssuerName.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */