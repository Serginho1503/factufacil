/*     */ package es.mityc.firmaJava.libreria.xades;
/*     */ 
/*     */ import es.mityc.javasign.EnumFormatoFirma;
/*     */ import es.mityc.javasign.certificate.ICertStatus;
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import org.w3c.dom.Document;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResultadoValidacion
/*     */ {
/*     */   private boolean validado;
/*     */   private ResultadoEnum resultado;
/*  35 */   private String log = "";
/*     */   private String nivelValido;
/*     */   private EnumFormatoFirma EnumNivel;
/*     */   private Document doc;
/*     */   private DatosFirma datosFirma;
/*     */   private URI baseURI;
/*     */   private ArrayList<String> firmados;
/*     */   private ArrayList<ResultadoValidacion> contrafirmadoPor;
/*  43 */   private ICertStatus certStatus = null;
/*  44 */   private boolean integrity = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResultadoValidacion()
/*     */   {
/*  64 */     this.validado = false;
/*  65 */     this.resultado = ResultadoEnum.NOT_VALIDATED;
/*  66 */     this.log = "";
/*  67 */     this.nivelValido = "";
/*  68 */     this.firmados = new ArrayList();
/*  69 */     this.contrafirmadoPor = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLog()
/*     */   {
/*  77 */     return this.log;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLog(String log)
/*     */   {
/*  85 */     this.log = log;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void appendLog(String log)
/*     */   {
/*  93 */     if (log != null) {
/*  94 */       this.log = this.log.concat("\n").concat(log);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isValidate()
/*     */   {
/* 102 */     return this.validado;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValidate(boolean validado)
/*     */   {
/* 110 */     this.validado = validado;
/*     */   }
/*     */   
/*     */   public ResultadoEnum getResultado() {
/* 114 */     return this.resultado;
/*     */   }
/*     */   
/*     */   public void setResultado(ResultadoEnum resultado) {
/* 118 */     this.resultado = resultado;
/*     */   }
/*     */   
/*     */   public Document getDoc() {
/* 122 */     return this.doc;
/*     */   }
/*     */   
/*     */   public void setDoc(Document doc) {
/* 126 */     this.doc = doc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getNivelValido()
/*     */   {
/* 134 */     return this.nivelValido;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNivelValido(String nivelValido)
/*     */   {
/* 142 */     this.nivelValido = nivelValido;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DatosFirma getDatosFirma()
/*     */   {
/* 150 */     return this.datosFirma;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDatosFirma(DatosFirma datosFirma)
/*     */   {
/* 158 */     this.datosFirma = datosFirma;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public EnumFormatoFirma getEnumNivel()
/*     */   {
/* 166 */     return this.EnumNivel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnumNivel(EnumFormatoFirma enumNivel)
/*     */   {
/* 174 */     this.EnumNivel = enumNivel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public URI getBaseURI()
/*     */   {
/* 182 */     return this.baseURI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBaseURI(URI baseURI)
/*     */   {
/* 190 */     this.baseURI = baseURI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ArrayList<String> getFirmados()
/*     */   {
/* 198 */     return this.firmados;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setFirmados(ArrayList<String> firmados)
/*     */   {
/* 205 */     this.firmados = firmados;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ArrayList<ResultadoValidacion> getContrafirmadoPor()
/*     */   {
/* 213 */     return this.contrafirmadoPor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContrafirmadoPor(ArrayList<ResultadoValidacion> contrafirmadoPor)
/*     */   {
/* 221 */     this.contrafirmadoPor = contrafirmadoPor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addContrafirmadoPor(ResultadoValidacion contrafirmadoPor)
/*     */   {
/* 230 */     if (contrafirmadoPor != null) {
/* 231 */       this.contrafirmadoPor.add(contrafirmadoPor);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ICertStatus getCertStatus()
/*     */   {
/* 239 */     return this.certStatus;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCertStatus(ICertStatus certStatus)
/*     */   {
/* 247 */     this.certStatus = certStatus;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getIntegrity()
/*     */   {
/* 255 */     return this.integrity;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIntegrity(boolean integrity)
/*     */   {
/* 263 */     this.integrity = integrity;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\ResultadoValidacion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */