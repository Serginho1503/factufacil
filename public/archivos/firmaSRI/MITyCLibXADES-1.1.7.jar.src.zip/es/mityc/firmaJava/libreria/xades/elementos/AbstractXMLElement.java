/*     */ package es.mityc.firmaJava.libreria.xades.elementos;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.utilidades.NombreNodo;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractXMLElement
/*     */ {
/*     */   protected void addContent(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  43 */     throw new UnsupportedOperationException("invalid operation");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Element createElement(Document doc)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  52 */     throw new UnsupportedOperationException("invalid operation");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void load(Element paramElement)
/*     */     throws InvalidInfoNodeException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean equals(Object paramObject);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkElementName(Element element, String namespaceURI, String name)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  80 */     if (!isElementName(element, namespaceURI, name)) {
/*  81 */       throw new InvalidInfoNodeException("Elemento esperado (".concat(namespaceURI).concat(":").concat(name).concat(" Elemento obtenido ") + element.getNamespaceURI() + ":".concat(element.getLocalName()));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isElementName(Element element, String namespaceURI, String name)
/*     */   {
/*  93 */     if (element != null)
/*     */     {
/*  95 */       if (new NombreNodo(namespaceURI, name).equals(new NombreNodo(element.getNamespaceURI(), element.getLocalName())))
/*  96 */         return true; }
/*  97 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isThisNode(Node node)
/*     */   {
/* 107 */     throw new UnsupportedOperationException("invalid operation");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Element nodeToElement(Node node)
/*     */   {
/* 116 */     Element element = null;
/* 117 */     if ((node != null) && 
/* 118 */       (node.getNodeType() == 1)) {
/* 119 */       element = (Element)node;
/*     */     }
/* 121 */     return element;
/*     */   }
/*     */   
/*     */   protected static boolean isDecorationNode(Node node) {
/* 125 */     if (node != null) {
/* 126 */       switch (node.getNodeType()) {
/*     */       case 3: 
/* 128 */         String text = node.getNodeValue().trim();
/* 129 */         text = text.replaceAll("/n", "");
/* 130 */         text = text.replaceAll("/r", "");
/* 131 */         text = text.replaceAll(" ", "");
/* 132 */         if (text.equals("")) {
/* 133 */           return true;
/*     */         }
/* 135 */         return false;
/*     */       case 8: 
/* 137 */         return true;
/*     */       }
/*     */       
/* 140 */       return false;
/*     */     }
/*     */     
/* 143 */     return true;
/*     */   }
/*     */   
/*     */   protected static Node getFirstNonvoidNode(Node node) {
/* 147 */     Node child = node.getFirstChild();
/*     */     
/* 149 */     while ((child != null) && (isDecorationNode(child))) {
/* 150 */       child = child.getNextSibling();
/*     */     }
/* 152 */     return child;
/*     */   }
/*     */   
/*     */   protected static Node getNextNonvoidNode(Node node) {
/* 156 */     Node child = node.getNextSibling();
/*     */     
/* 158 */     while ((child != null) && (isDecorationNode(child))) {
/* 159 */       child = child.getNextSibling();
/*     */     }
/* 161 */     return child;
/*     */   }
/*     */   
/*     */   protected static boolean compare(Object obj1, Object obj2) {
/* 165 */     if ((obj1 == null) && (obj2 == null))
/* 166 */       return true;
/* 167 */     if (obj1 != null)
/* 168 */       return obj1.equals(obj2);
/* 169 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\AbstractXMLElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */