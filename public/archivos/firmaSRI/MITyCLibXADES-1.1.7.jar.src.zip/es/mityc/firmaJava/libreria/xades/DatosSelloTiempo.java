/*     */ package es.mityc.firmaJava.libreria.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.trust.ConfianzaEnum;
/*     */ import es.mityc.javasign.certificate.ICertStatus.CERT_STATUS;
/*     */ import java.security.cert.CertPath;
/*     */ import java.util.Date;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DatosSelloTiempo
/*     */ {
/*  30 */   private Date fecha = null;
/*  31 */   private X500Principal emisor = null;
/*  32 */   private CertPath cadena = null;
/*  33 */   private String algoritmo = null;
/*  34 */   private Long precision = null;
/*  35 */   private TipoSellosTiempo tipoSello = null;
/*  36 */   private byte[] rawTimestamp = null;
/*  37 */   private ICertStatus.CERT_STATUS revockedStatus = ICertStatus.CERT_STATUS.unknown;
/*  38 */   private ConfianzaEnum esCertConfianza = ConfianzaEnum.NO_REVISADO;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DatosSelloTiempo() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DatosSelloTiempo(Date fecha, X500Principal emisor, CertPath cadena, String algoritmo, Long precision, TipoSellosTiempo tipoSello, byte[] rawTimestamp, ConfianzaEnum esCertconfianza)
/*     */   {
/*  63 */     this.fecha = fecha;
/*  64 */     this.emisor = emisor;
/*  65 */     this.cadena = cadena;
/*  66 */     this.algoritmo = algoritmo;
/*  67 */     this.precision = precision;
/*  68 */     this.tipoSello = tipoSello;
/*  69 */     this.rawTimestamp = rawTimestamp;
/*  70 */     this.esCertConfianza = esCertconfianza;
/*     */   }
/*     */   
/*     */   public String getAlgoritmo() {
/*  74 */     return this.algoritmo;
/*     */   }
/*     */   
/*  77 */   public void setAlgoritmo(String algoritmo) { this.algoritmo = algoritmo; }
/*     */   
/*     */   public X500Principal getEmisor() {
/*  80 */     return this.emisor;
/*     */   }
/*     */   
/*  83 */   public void setEmisor(X500Principal emisor) { this.emisor = emisor; }
/*     */   
/*     */   public Date getFecha() {
/*  86 */     return this.fecha;
/*     */   }
/*     */   
/*  89 */   public void setFecha(Date fecha) { this.fecha = fecha; }
/*     */   
/*     */   public Long getPrecision() {
/*  92 */     return this.precision;
/*     */   }
/*     */   
/*  95 */   public void setPrecision(Long precision) { this.precision = precision; }
/*     */   
/*     */   public TipoSellosTiempo getTipoSello() {
/*  98 */     return this.tipoSello;
/*     */   }
/*     */   
/* 101 */   public void setTipoSello(TipoSellosTiempo tipoSello) { this.tipoSello = tipoSello; }
/*     */   
/*     */   public byte[] getRawTimestamp() {
/* 104 */     return this.rawTimestamp;
/*     */   }
/*     */   
/* 107 */   public void setRawTimestamp(byte[] rawTimestamp) { this.rawTimestamp = rawTimestamp; }
/*     */   
/*     */   public ConfianzaEnum esCertConfianza() {
/* 110 */     return this.esCertConfianza;
/*     */   }
/*     */   
/* 113 */   public void setEsCertConfianza(ConfianzaEnum esCertConfianza) { this.esCertConfianza = esCertConfianza; }
/*     */   
/*     */   public CertPath getCadena() {
/* 116 */     return this.cadena;
/*     */   }
/*     */   
/* 119 */   public void setCadena(CertPath cadena) { this.cadena = cadena; }
/*     */   
/*     */   public ICertStatus.CERT_STATUS getRevockedStatus() {
/* 122 */     return this.revockedStatus;
/*     */   }
/*     */   
/* 125 */   public void setRevockedStatus(ICertStatus.CERT_STATUS revockedStatus) { this.revockedStatus = revockedStatus; }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\DatosSelloTiempo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */