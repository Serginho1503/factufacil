/*     */ package es.mityc.firmaJava.libreria.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.trust.ConfianzaEnum;
/*     */ import es.mityc.javasign.xml.xades.policy.PolicyResult;
/*     */ import java.security.cert.CertPath;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DatosFirma
/*     */ {
/*  32 */   private CertPath cadenaFirma = null;
/*  33 */   private ConfianzaEnum esCadenaConfianza = ConfianzaEnum.NO_REVISADO;
/*  34 */   private DatosTipoFirma tipoFirma = null;
/*  35 */   private ArrayList<DatosSelloTiempo> datosSelloTiempo = null;
/*  36 */   private ArrayList<DatosCRL> datosCRL = null;
/*  37 */   private ArrayList<DatosOCSP> datosOCSP = null;
/*  38 */   private Date fechaFirma = null;
/*  39 */   private ArrayList<String> roles = null;
/*  40 */   private ArrayList<PolicyResult> politicas = null;
/*  41 */   private XAdESSchemas esquema = null;
/*  42 */   private String sigValueId = null;
/*  43 */   private ArrayList<String> contraFirma = null;
/*  44 */   private ArrayList<DatosNodosFirmados> datosNodos = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DatosFirma() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DatosFirma(CertPath cadenaFirma, ConfianzaEnum esCAdenaConfianza, DatosTipoFirma tipoFirma, ArrayList<DatosSelloTiempo> datosSelloTiempo, ArrayList<DatosCRL> datosCRL, ArrayList<DatosOCSP> datosOCSP, Date fechaFirma, ArrayList<String> roles, ArrayList<PolicyResult> politicas, XAdESSchemas esquema, String sigValueId, ArrayList<String> contraFirma, ArrayList<DatosNodosFirmados> datosFicheros)
/*     */   {
/*  79 */     this.cadenaFirma = cadenaFirma;
/*  80 */     this.esCadenaConfianza = esCAdenaConfianza;
/*  81 */     this.datosSelloTiempo = datosSelloTiempo;
/*  82 */     this.datosCRL = datosCRL;
/*  83 */     this.datosOCSP = datosOCSP;
/*  84 */     this.fechaFirma = fechaFirma;
/*  85 */     this.roles = roles;
/*  86 */     this.politicas = politicas;
/*  87 */     this.esquema = esquema;
/*  88 */     this.sigValueId = sigValueId;
/*  89 */     this.contraFirma = contraFirma;
/*  90 */     this.datosNodos = datosFicheros;
/*     */   }
/*     */   
/*     */   public CertPath getCadenaFirma() {
/*  94 */     return this.cadenaFirma;
/*     */   }
/*     */   
/*  97 */   public void setCadenaFirma(CertPath cadenaFirma) { this.cadenaFirma = cadenaFirma; }
/*     */   
/*     */   public ConfianzaEnum esCadenaConfianza() {
/* 100 */     return this.esCadenaConfianza;
/*     */   }
/*     */   
/* 103 */   public void setEsCadenaConfianza(ConfianzaEnum esCadenaConfianza) { this.esCadenaConfianza = esCadenaConfianza; }
/*     */   
/*     */   public ArrayList<DatosOCSP> getDatosOCSP() {
/* 106 */     if (this.datosOCSP != null) {
/* 107 */       return this.datosOCSP;
/*     */     }
/* 109 */     return new ArrayList();
/*     */   }
/*     */   
/* 112 */   public void setDatosOCSP(ArrayList<DatosOCSP> datosOCSP) { this.datosOCSP = datosOCSP; }
/*     */   
/*     */   public ArrayList<DatosCRL> getDatosCRL() {
/* 115 */     return this.datosCRL;
/*     */   }
/*     */   
/* 118 */   public void setDatosCRL(ArrayList<DatosCRL> datosCRL) { this.datosCRL = datosCRL; }
/*     */   
/*     */   public ArrayList<DatosSelloTiempo> getDatosSelloTiempo() {
/* 121 */     if (this.datosSelloTiempo != null) {
/* 122 */       return this.datosSelloTiempo;
/*     */     }
/* 124 */     return new ArrayList();
/*     */   }
/*     */   
/* 127 */   public void setDatosSelloTiempo(ArrayList<DatosSelloTiempo> datosSelloTiempo) { this.datosSelloTiempo = datosSelloTiempo; }
/*     */   
/*     */   public Date getFechaFirma() {
/* 130 */     return this.fechaFirma;
/*     */   }
/*     */   
/* 133 */   public void setFechaFirma(Date fechaFirma) { this.fechaFirma = fechaFirma; }
/*     */   
/*     */   public ArrayList<String> getRoles() {
/* 136 */     if (this.roles != null) {
/* 137 */       return this.roles;
/*     */     }
/* 139 */     return new ArrayList();
/*     */   }
/*     */   
/* 142 */   public void setRoles(ArrayList<String> roles) { this.roles = roles; }
/*     */   
/*     */   public ArrayList<PolicyResult> getPoliticas() {
/* 145 */     if (this.politicas != null) {
/* 146 */       return this.politicas;
/*     */     }
/* 148 */     return new ArrayList();
/*     */   }
/*     */   
/* 151 */   public void setPoliticas(ArrayList<PolicyResult> politicas) { this.politicas = politicas; }
/*     */   
/*     */   public XAdESSchemas getEsquema() {
/* 154 */     return this.esquema;
/*     */   }
/*     */   
/* 157 */   public void setEsquema(XAdESSchemas esquema) { this.esquema = esquema; }
/*     */   
/*     */   public DatosTipoFirma getTipoFirma() {
/* 160 */     return this.tipoFirma;
/*     */   }
/*     */   
/* 163 */   public void setTipoFirma(DatosTipoFirma tipoFirma) { this.tipoFirma = tipoFirma; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSigValueId()
/*     */   {
/* 171 */     return this.sigValueId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setSigValueId(String sigValueId)
/*     */   {
/* 178 */     this.sigValueId = sigValueId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ArrayList<String> getContraFirma()
/*     */   {
/* 185 */     return this.contraFirma;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setContraFirma(ArrayList<String> contraFirma)
/*     */   {
/* 192 */     this.contraFirma = contraFirma;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<DatosNodosFirmados> getDatosNodosFirmados()
/*     */   {
/* 199 */     return this.datosNodos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<DatosNodosFirmados> getDatosNodosNoSignFirmados()
/*     */   {
/* 207 */     ArrayList<DatosNodosFirmados> res = new ArrayList();
/* 208 */     if (this.datosNodos != null) {
/* 209 */       for (DatosNodosFirmados dnf : this.datosNodos) {
/* 210 */         if (!dnf.isSignInternal()) {
/* 211 */           res.add(dnf);
/*     */         }
/*     */       }
/*     */     }
/* 215 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDatosNodosFirmados(ArrayList<DatosNodosFirmados> datosNodos)
/*     */   {
/* 222 */     this.datosNodos = datosNodos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addDatosNodoFirmado(DatosNodosFirmados datosNodo)
/*     */   {
/* 230 */     if (this.datosNodos == null) {
/* 231 */       this.datosNodos = new ArrayList();
/*     */     }
/* 233 */     this.datosNodos.add(datosNodo);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DatosNodosFirmados getDatosNodoFimadoByReferenceId(String id)
/*     */   {
/* 242 */     DatosNodosFirmados dnf = null;
/* 243 */     if ((this.datosNodos != null) && (id != null)) {
/* 244 */       for (DatosNodosFirmados datos : this.datosNodos) {
/* 245 */         if (id.equals(datos.getIdReference())) {
/* 246 */           dnf = datos;
/* 247 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 251 */     return dnf;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DatosNodosFirmados getDatosNodoFimadoById(String id)
/*     */   {
/* 260 */     DatosNodosFirmados dnf = null;
/* 261 */     if ((this.datosNodos != null) && (id != null)) {
/* 262 */       for (DatosNodosFirmados datos : this.datosNodos) {
/* 263 */         if (id.equals(datos.getId())) {
/* 264 */           dnf = datos;
/* 265 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 269 */     return dnf;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\DatosFirma.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */