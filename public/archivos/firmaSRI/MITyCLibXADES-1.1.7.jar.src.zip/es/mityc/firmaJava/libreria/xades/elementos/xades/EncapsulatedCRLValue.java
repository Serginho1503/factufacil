/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.utilidades.Base64Coder;
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.net.URI;
/*     */ import java.security.cert.CRL;
/*     */ import java.security.cert.CRLException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509CRL;
/*     */ import java.security.cert.X509Certificate;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EncapsulatedCRLValue
/*     */   extends EncapsulatedPKIDataType
/*     */ {
/*     */   public EncapsulatedCRLValue(XAdESSchemas schema)
/*     */   {
/*  48 */     super(schema);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public EncapsulatedCRLValue(XAdESSchemas schema, String id)
/*     */   {
/*  56 */     super(schema, id);
/*     */   }
/*     */   
/*     */   public EncapsulatedCRLValue(XAdESSchemas schema, String id, X509CRL crl) throws InvalidInfoNodeException {
/*  60 */     super(schema, id);
/*     */     try {
/*  62 */       setValue(new String(Base64Coder.encode(crl.getEncoded())));
/*     */     } catch (CRLException ex) {
/*  64 */       throw new InvalidInfoNodeException("Error al extraer la información de la crl", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  73 */     checkElementName(element, this.schema.getSchemaUri(), "EncapsulatedCRLValue");
/*  74 */     super.load(element);
/*     */     
/*     */ 
/*  77 */     EncodingEnum encoding = getEncoding();
/*  78 */     if ((encoding != null) && (!encoding.equals(EncodingEnum.DER_ENCODED))) {
/*  79 */       throw new InvalidInfoNodeException("El contenido de EncapsulatedCRLValue debe estar en la codificación " + EncodingEnum.DER_ENCODED.getEncodingUri().toString());
/*     */     }
/*     */     
/*     */     try
/*     */     {
/*  84 */       crl = getX509CRL();
/*     */     } catch (CRLException ex) { X509CRL crl;
/*  86 */       throw new InvalidInfoNodeException("El contenido de EncapsulatedCRLValue no es un certificado X509 válido", ex); }
/*     */     X509CRL crl;
/*  88 */     if (crl == null) {
/*  89 */       throw new InvalidInfoNodeException("El contenido de EncapsulatedCRLValue no es un certificado X509 válido");
/*     */     }
/*     */   }
/*     */   
/*     */   public X509CRL getX509CRL() throws CRLException {
/*  94 */     String value = getValue();
/*  95 */     if (value != null)
/*     */     {
/*     */       try {
/*  98 */         data = Base64Coder.decode(value);
/*     */       } catch (IllegalArgumentException ex) { byte[] data;
/* 100 */         throw new CRLException("Contenido base64 de EncapsulatedCRLValue inválido", ex); }
/*     */       byte[] data;
/* 102 */       ByteArrayInputStream bais = new ByteArrayInputStream(data);
/*     */       
/*     */       try
/*     */       {
/* 106 */         cf = CertificateFactory.getInstance("X.509");
/*     */       } catch (CertificateException ex) { CertificateFactory cf;
/* 108 */         throw new CRLException(ex); }
/*     */       CertificateFactory cf;
/* 110 */       CRL crl = cf.generateCRL(bais);
/* 111 */       if ((crl instanceof X509CRL))
/* 112 */         return (X509CRL)crl;
/* 113 */       throw new CRLException("Contenido base64 de EncapsulatedCRLValue no es una CRL del tipo X.509");
/*     */     }
/*     */     
/* 116 */     return null;
/*     */   }
/*     */   
/*     */   public void setX509Certificate(X509Certificate certificate) throws CertificateException {
/* 120 */     setValue(new String(Base64Coder.encode(certificate.getEncoded())));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isThisNode(Node node)
/*     */   {
/* 128 */     return isElementName(nodeToElement(node), this.schema.getSchemaUri(), "EncapsulatedCRLValue");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Element createElement(Document doc, String namespaceXAdES)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 136 */     return super.createElement(doc, namespaceXAdES);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Element createElement(Document doc)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 144 */     Element res = doc.createElementNS(this.schema.getSchemaUri(), this.namespaceXAdES + ":" + "EncapsulatedCRLValue");
/* 145 */     super.addContent(res, this.namespaceXAdES);
/* 146 */     return res;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\EncapsulatedCRLValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */