/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.utilidades.UtilidadTratarNodo;
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignaturePolicyIdentifierType
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private SignaturePolicyImplied signaturePolicyImplied;
/*     */   private SignaturePolicyId signaturePolicyId;
/*     */   
/*     */   public SignaturePolicyIdentifierType(XAdESSchemas schema)
/*     */   {
/*  37 */     super(schema);
/*     */   }
/*     */   
/*     */   public SignaturePolicyIdentifierType(XAdESSchemas schema, boolean isImplied) {
/*  41 */     super(schema);
/*  42 */     if (isImplied) {
/*  43 */       this.signaturePolicyImplied = new SignaturePolicyImplied(schema);
/*     */     } else {
/*  45 */       this.signaturePolicyId = new SignaturePolicyId(schema);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void addContent(Element element, String namespaceXAdES, String namespaceXDsig)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  53 */     super.addContent(element, namespaceXAdES, namespaceXDsig);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void addContent(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  61 */     if (isImplied()) {
/*  62 */       element.appendChild(this.signaturePolicyImplied.createElement(element.getOwnerDocument(), this.namespaceXAdES));
/*     */     } else {
/*  64 */       if (this.signaturePolicyId == null)
/*  65 */         throw new InvalidInfoNodeException("Información insuficiente para escribir nodo SignaturePolicyId");
/*  66 */       element.appendChild(this.signaturePolicyId.createElement(element.getOwnerDocument(), this.namespaceXDsig, this.namespaceXAdES));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  75 */     if ((obj instanceof SignaturePolicyIdentifierType)) {
/*  76 */       SignaturePolicyIdentifierType spit = (SignaturePolicyIdentifierType)obj;
/*  77 */       if (isImplied()) {
/*  78 */         if (spit.isImplied()) {
/*  79 */           return true;
/*     */         }
/*     */       } else {
/*  82 */         if ((this.signaturePolicyId == null) || (spit.isImplied()))
/*  83 */           return false;
/*  84 */         if (this.signaturePolicyId.equals(spit.signaturePolicyId))
/*  85 */           return true;
/*     */       }
/*     */     }
/*  88 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  97 */     Node node = getFirstNonvoidNode(element);
/*  98 */     SignaturePolicyImplied spi = new SignaturePolicyImplied(this.schema);
/*  99 */     if (spi.isThisNode(node)) {
/* 100 */       spi.load((Element)node);
/* 101 */       this.signaturePolicyImplied = spi;
/*     */     } else {
/* 103 */       SignaturePolicyId spid = new SignaturePolicyId(this.schema);
/* 104 */       spid.load((Element)node);
/* 105 */       this.signaturePolicyId = spid;
/*     */     }
/* 107 */     if (UtilidadTratarNodo.getNextElementSibling(node, true) != null) {
/* 108 */       throw new InvalidInfoNodeException("Nodo SignaturePolicyIdentifierType debe tener un único hijo");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public SignaturePolicyImplied getSignaturePolicyImplied()
/*     */   {
/* 115 */     return this.signaturePolicyImplied;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setSignaturePolicyImplied()
/*     */   {
/* 122 */     this.signaturePolicyImplied = new SignaturePolicyImplied(this.schema);
/* 123 */     this.signaturePolicyId = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public SignaturePolicyId getSignaturePolicyId()
/*     */   {
/* 130 */     return this.signaturePolicyId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setSignaturePolicyId(SignaturePolicyId signaturePolicyId)
/*     */   {
/* 137 */     this.signaturePolicyId = signaturePolicyId;
/* 138 */     this.signaturePolicyId = null;
/*     */   }
/*     */   
/*     */   public boolean isImplied() {
/* 142 */     if (this.signaturePolicyImplied != null)
/* 143 */       return true;
/* 144 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\SignaturePolicyIdentifierType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */