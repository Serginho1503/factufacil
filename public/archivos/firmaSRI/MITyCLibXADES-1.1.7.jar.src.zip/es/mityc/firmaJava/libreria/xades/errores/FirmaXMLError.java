/*    */ package es.mityc.firmaJava.libreria.xades.errores;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FirmaXMLError
/*    */   extends Exception
/*    */ {
/*    */   public FirmaXMLError() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public FirmaXMLError(String msg)
/*    */   {
/* 38 */     super(msg);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public FirmaXMLError(Exception e)
/*    */   {
/* 46 */     super(e);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public FirmaXMLError(String message, Throwable cause)
/*    */   {
/* 54 */     super(message, cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public FirmaXMLError(Throwable cause)
/*    */   {
/* 61 */     super(cause);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\errores\FirmaXMLError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */