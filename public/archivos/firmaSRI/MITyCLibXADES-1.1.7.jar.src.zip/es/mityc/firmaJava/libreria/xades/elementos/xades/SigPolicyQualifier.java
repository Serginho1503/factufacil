/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import es.mityc.javasign.xml.xades.policy.PolicyException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SigPolicyQualifier
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private IPolicyQualifier qualifier;
/*     */   
/*     */   public SigPolicyQualifier(XAdESSchemas schema)
/*     */   {
/*  42 */     super(schema);
/*     */   }
/*     */   
/*     */   public SigPolicyQualifier(XAdESSchemas schema, IPolicyQualifier qualifier) {
/*  46 */     super(schema);
/*  47 */     this.qualifier = qualifier;
/*     */   }
/*     */   
/*     */   public IPolicyQualifier getQualifier() {
/*  51 */     return this.qualifier;
/*     */   }
/*     */   
/*     */   public void setQualifier(IPolicyQualifier qualifier) {
/*  55 */     this.qualifier = qualifier;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/*  60 */     if ((obj instanceof SigPolicyQualifier)) {
/*  61 */       SigPolicyQualifier comp = (SigPolicyQualifier)obj;
/*  62 */       if (this.qualifier == null) {
/*  63 */         if (comp.qualifier != null)
/*  64 */           return false;
/*  65 */         return true;
/*     */       }
/*  67 */       if (this.qualifier.equals(comp.qualifier))
/*  68 */         return true;
/*     */     }
/*  70 */     return false;
/*     */   }
/*     */   
/*     */   public Element createElement(Document doc, String namespaceXAdES) throws InvalidInfoNodeException
/*     */   {
/*  75 */     return super.createElement(doc, namespaceXAdES);
/*     */   }
/*     */   
/*     */   protected Element createElement(Document doc) throws InvalidInfoNodeException
/*     */   {
/*  80 */     Element res = doc.createElementNS(this.schema.getSchemaUri(), this.namespaceXAdES + ":" + "SigPolicyQualifier");
/*  81 */     super.addContent(res, this.namespaceXAdES);
/*  82 */     return res;
/*     */   }
/*     */   
/*     */   protected void addContent(Element element) throws InvalidInfoNodeException
/*     */   {
/*  87 */     if (this.qualifier == null)
/*  88 */       throw new InvalidInfoNodeException("Nodo SigPolicyQualifier sin contenido");
/*     */     try {
/*  90 */       Node node = this.qualifier.createPolicyQualifierContent(element.getOwnerDocument());
/*  91 */       element.appendChild(node);
/*     */     } catch (PolicyException ex) {
/*  93 */       throw new InvalidInfoNodeException("Error creando contenido de nodo SigPolicyQualifier", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addContent(Element element, String namespaceXAdES) throws InvalidInfoNodeException
/*     */   {
/*  99 */     super.addContent(element, namespaceXAdES);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 107 */     checkElementName(element, this.schema.getSchemaUri(), "SigPolicyQualifier");
/*     */     
/*     */ 
/* 110 */     Node node = getFirstNonvoidNode(element);
/* 111 */     if (node.getNodeType() != 1) {
/* 112 */       throw new InvalidInfoNodeException("Contenido de nodo SigPolicyQualifier desconocido");
/*     */     }
/* 114 */     SPURI spuri = new SPURI(this.schema);
/* 115 */     if (spuri.isThisNode(node)) {
/* 116 */       spuri.load((Element)node);
/* 117 */       this.qualifier = spuri;
/*     */     }
/*     */     else {
/* 120 */       SPUserNotice userNotice = new SPUserNotice(this.schema);
/* 121 */       if (userNotice.isThisNode(node)) {
/* 122 */         userNotice.load((Element)node);
/* 123 */         this.qualifier = userNotice;
/*     */       }
/*     */       else {
/* 126 */         throw new InvalidInfoNodeException("Contenido de nodo SigPolicyQualifier desconocido");
/*     */       } }
/* 128 */     if ((node != null) && (getNextNonvoidNode(node) != null)) {
/* 129 */       throw new InvalidInfoNodeException("Contenido de nodo SigPolicyQualifier desconocido");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isThisNode(Node node)
/*     */   {
/* 137 */     return isElementName(nodeToElement(node), this.schema.getSchemaUri(), "SigPolicyQualifier");
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\SigPolicyQualifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */