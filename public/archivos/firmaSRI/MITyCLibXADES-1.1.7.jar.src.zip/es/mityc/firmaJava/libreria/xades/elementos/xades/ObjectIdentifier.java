/*    */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*    */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*    */ import java.net.URI;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectIdentifier
/*    */   extends ObjectIdentifierType
/*    */ {
/*    */   public ObjectIdentifier(XAdESSchemas schema, URI uri, String description)
/*    */   {
/* 39 */     super(schema, uri, description);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public ObjectIdentifier(XAdESSchemas schema)
/*    */   {
/* 46 */     super(schema);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void load(Element element)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 54 */     checkElementName(element, this.schema.getSchemaUri(), "ObjectIdentifier");
/* 55 */     super.load(element);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isThisNode(Node node)
/*    */   {
/* 63 */     return isElementName(nodeToElement(node), this.schema.getSchemaUri(), "ObjectIdentifier");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Element createElement(Document doc, String namespaceXAdES)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 71 */     return super.createElement(doc, namespaceXAdES);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected Element createElement(Document doc)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 79 */     Element res = doc.createElementNS(this.schema.getSchemaUri(), this.namespaceXAdES + ":" + "ObjectIdentifier");
/* 80 */     super.addContent(res, this.namespaceXAdES);
/* 81 */     return res;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\ObjectIdentifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */