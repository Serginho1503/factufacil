/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xmldsig;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.math.BigInteger;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class X509IssuerSerialType
/*     */   extends AbstractXDsigElement
/*     */ {
/*     */   private X509IssuerName issuerName;
/*     */   private X509SerialNumber serialNumber;
/*     */   
/*     */   public X509IssuerSerialType() {}
/*     */   
/*     */   public X509IssuerSerialType(String issuerName, BigInteger serialNumber)
/*     */   {
/*  39 */     this.issuerName = new X509IssuerName(issuerName);
/*  40 */     this.serialNumber = new X509SerialNumber(serialNumber);
/*     */   }
/*     */   
/*     */   public void setIssuerName(String issuerName) {
/*  44 */     this.issuerName = new X509IssuerName(issuerName);
/*     */   }
/*     */   
/*     */   public void setSerialNumber(BigInteger serialNumber) {
/*  48 */     this.serialNumber = new X509SerialNumber(serialNumber);
/*     */   }
/*     */   
/*     */   public String getIssuerName() {
/*  52 */     return this.issuerName != null ? this.issuerName.getValue() : null;
/*     */   }
/*     */   
/*     */   public BigInteger getSerialNumber() {
/*  56 */     return this.serialNumber != null ? this.serialNumber.getValue() : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addContent(Element element, String namespaceXDsig)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  64 */     super.addContent(element, namespaceXDsig);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void addContent(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  72 */     if ((this.issuerName == null) || (this.serialNumber == null)) {
/*  73 */       throw new InvalidInfoNodeException("Información insuficiente para escribir nodo X509IssuerSerialType");
/*     */     }
/*  75 */     element.appendChild(this.issuerName.createElement(element.getOwnerDocument(), this.namespaceXDsig));
/*  76 */     element.appendChild(this.serialNumber.createElement(element.getOwnerDocument(), this.namespaceXDsig));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  84 */     if ((obj instanceof X509IssuerSerialType)) {
/*  85 */       X509IssuerSerialType ist = (X509IssuerSerialType)obj;
/*  86 */       if ((this.serialNumber == null) || (this.issuerName == null))
/*  87 */         return false;
/*  88 */       if (!this.issuerName.equals(ist.issuerName))
/*  89 */         return false;
/*  90 */       if (!this.serialNumber.equals(ist.serialNumber))
/*  91 */         return false;
/*  92 */       return true;
/*     */     }
/*  94 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 102 */     Node node = getFirstNonvoidNode(element);
/*     */     
/* 104 */     X509IssuerName name = new X509IssuerName();
/* 105 */     if (!name.isThisNode(node)) {
/* 106 */       throw new InvalidInfoNodeException("Se esperaba nodo X509IssuerName en X509IssuerSerialType");
/*     */     }
/* 108 */     name.load((Element)node);
/*     */     
/* 110 */     node = getNextNonvoidNode(node);
/* 111 */     X509SerialNumber serial = new X509SerialNumber(null);
/* 112 */     if (!serial.isThisNode(node)) {
/* 113 */       throw new InvalidInfoNodeException("Se esperaba nodo X509SerialNumber en X509IssuerSerialType");
/*     */     }
/* 115 */     serial.load((Element)node);
/*     */     
/* 117 */     this.issuerName = name;
/* 118 */     this.serialNumber = serial;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xmldsig\X509IssuerSerialType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */