/*    */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*    */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*    */ import java.math.BigInteger;
/*    */ import java.util.Date;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CRLIdentifier
/*    */   extends CRLIdentifierType
/*    */ {
/*    */   public CRLIdentifier(XAdESSchemas schema, String issuer, Date issueTime, BigInteger number, String URI)
/*    */   {
/* 45 */     super(schema, issuer, issueTime, number, URI);
/*    */   }
/*    */   
/*    */   public CRLIdentifier(XAdESSchemas schema) {
/* 49 */     super(schema);
/*    */   }
/*    */   
/*    */   public void load(Element element) throws InvalidInfoNodeException
/*    */   {
/* 54 */     checkElementName(element, this.schema.getSchemaUri(), "CRLIdentifier");
/* 55 */     super.load(element);
/*    */   }
/*    */   
/*    */   public boolean isThisNode(Node node)
/*    */   {
/* 60 */     return isElementName(nodeToElement(node), this.schema.getSchemaUri(), "CRLIdentifier");
/*    */   }
/*    */   
/*    */   public Element createElement(Document doc, String namespaceXAdES) throws InvalidInfoNodeException
/*    */   {
/* 65 */     return super.createElement(doc, namespaceXAdES);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected Element createElement(Document doc)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 73 */     Element res = doc.createElementNS(this.schema.getSchemaUri(), this.namespaceXAdES + ":" + "CRLIdentifier");
/* 74 */     super.addContent(res, this.namespaceXAdES);
/* 75 */     return res;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\CRLIdentifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */