/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.XMLDataURIType;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.net.URI;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AbstractXadesURIElement
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private XMLDataURIType data;
/*     */   private String nameElement;
/*     */   
/*     */   public AbstractXadesURIElement(XAdESSchemas schema, String nameElement, URI data)
/*     */   {
/*  41 */     super(schema);
/*  42 */     this.nameElement = nameElement;
/*  43 */     this.data = new XMLDataURIType(data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractXadesURIElement(XAdESSchemas schema, String nameElement)
/*     */   {
/*  52 */     super(schema);
/*  53 */     this.nameElement = nameElement;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Element createElement(Document doc)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  61 */     if (this.data == null)
/*  62 */       throw new InvalidInfoNodeException("Información insuficiente para escribir elemento " + this.nameElement);
/*  63 */     Element res = doc.createElementNS(this.schema.getSchemaUri(), this.namespaceXAdES + ":" + this.nameElement);
/*  64 */     this.data.addContent(res);
/*  65 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Element createElement(Document doc, String namespaceXAdES)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  73 */     return super.createElement(doc, namespaceXAdES);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  81 */     if ((obj instanceof AbstractXadesURIElement)) {
/*  82 */       AbstractXadesURIElement desc = (AbstractXadesURIElement)obj;
/*  83 */       if ((this.nameElement.equals(desc.nameElement)) && (this.data.equals(desc.data))) {
/*  84 */         return true;
/*     */       }
/*     */     } else {
/*  87 */       return this.data.equals(obj); }
/*  88 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  96 */     checkElementName(element, this.schema.getSchemaUri(), this.nameElement);
/*  97 */     this.data = new XMLDataURIType(null);
/*  98 */     this.data.load(element);
/*     */   }
/*     */   
/*     */   public void setValue(URI value) {
/* 102 */     if (this.data == null) {
/* 103 */       this.data = new XMLDataURIType(value);
/*     */     } else
/* 105 */       this.data.setValue(value);
/*     */   }
/*     */   
/*     */   public URI getValue() {
/* 109 */     if (this.data != null)
/* 110 */       return this.data.getValue();
/* 111 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isThisNode(Node node)
/*     */   {
/* 119 */     return isElementName(nodeToElement(node), this.schema.getSchemaUri(), this.nameElement);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\AbstractXadesURIElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */