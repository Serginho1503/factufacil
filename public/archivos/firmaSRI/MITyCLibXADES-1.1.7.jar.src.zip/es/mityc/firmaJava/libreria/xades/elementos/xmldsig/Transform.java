/*    */ package es.mityc.firmaJava.libreria.xades.elementos.xmldsig;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Transform
/*    */   extends TransformType
/*    */ {
/*    */   public Transform(String algorithm)
/*    */   {
/* 35 */     super(algorithm);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Transform() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void load(Element element)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 50 */     checkElementName(element, "http://www.w3.org/2000/09/xmldsig#", "Transform");
/* 51 */     super.load(element);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isThisNode(Node node)
/*    */   {
/* 59 */     return isElementName(nodeToElement(node), "http://www.w3.org/2000/09/xmldsig#", "Transform");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected Element createElement(Document doc)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 67 */     Element res = doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", this.namespaceXDsig + ":" + "Transform");
/* 68 */     super.addContent(res, this.namespaceXDsig);
/* 69 */     return res;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Element createElement(Document doc, String namespaceXDsig)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 77 */     return super.createElement(doc, namespaceXDsig);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xmldsig\Transform.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */