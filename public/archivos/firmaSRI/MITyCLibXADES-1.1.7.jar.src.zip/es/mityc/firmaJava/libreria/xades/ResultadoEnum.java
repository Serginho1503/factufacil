package es.mityc.firmaJava.libreria.xades;

public enum ResultadoEnum
{
  NOT_VALIDATED,  UNKNOWN,  VALID,  INVALID;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\ResultadoEnum.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */