/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.utilidades.UtilidadTratarNodo;
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignatureProductionPlaceType
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private City city;
/*     */   private CountryName country;
/*     */   private PostalCode postal;
/*     */   private StateOrProvince province;
/*     */   
/*     */   public SignatureProductionPlaceType(XAdESSchemas schema)
/*     */   {
/*  42 */     super(schema);
/*     */   }
/*     */   
/*     */   public SignatureProductionPlaceType(XAdESSchemas schema, String city, String state, String postalCode, String country) {
/*  46 */     super(schema);
/*  47 */     if (city != null)
/*  48 */       this.city = new City(schema, city);
/*  49 */     if (state != null)
/*  50 */       this.province = new StateOrProvince(schema, state);
/*  51 */     if (postalCode != null)
/*  52 */       this.postal = new PostalCode(schema, postalCode);
/*  53 */     if (country != null)
/*  54 */       this.country = new CountryName(schema, country);
/*     */   }
/*     */   
/*     */   public String getCity() {
/*  58 */     if (this.city != null)
/*  59 */       return this.city.getValue();
/*  60 */     return null;
/*     */   }
/*     */   
/*     */   public String getCountry() {
/*  64 */     if (this.country != null)
/*  65 */       return this.country.getValue();
/*  66 */     return null;
/*     */   }
/*     */   
/*     */   public String getPostalCode() {
/*  70 */     if (this.postal != null)
/*  71 */       return this.postal.getValue();
/*  72 */     return null;
/*     */   }
/*     */   
/*     */   public String getStateOrProvince() {
/*  76 */     if (this.province != null)
/*  77 */       return this.province.getValue();
/*  78 */     return null;
/*     */   }
/*     */   
/*     */   public void setCity(String city) {
/*  82 */     if (city != null) {
/*  83 */       this.city = new City(this.schema, city);
/*     */     } else
/*  85 */       this.city = null;
/*     */   }
/*     */   
/*     */   public void setCountry(String country) {
/*  89 */     if (country != null) {
/*  90 */       this.country = new CountryName(this.schema, country);
/*     */     } else
/*  92 */       this.country = null;
/*     */   }
/*     */   
/*     */   public void setPostalCode(String postalCode) {
/*  96 */     if (postalCode != null) {
/*  97 */       this.postal = new PostalCode(this.schema, postalCode);
/*     */     } else
/*  99 */       this.postal = null;
/*     */   }
/*     */   
/*     */   public void setStateOrProvince(String stateOrProvince) {
/* 103 */     if (stateOrProvince != null) {
/* 104 */       this.province = new StateOrProvince(this.schema, stateOrProvince);
/*     */     } else {
/* 106 */       this.province = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public void addContent(Element element, String namespaceXAdES) throws InvalidInfoNodeException {
/* 111 */     super.addContent(element, namespaceXAdES);
/*     */   }
/*     */   
/*     */   protected void addContent(Element element) throws InvalidInfoNodeException
/*     */   {
/* 116 */     if (this.city != null)
/* 117 */       element.appendChild(this.city.createElement(element.getOwnerDocument(), this.namespaceXAdES));
/* 118 */     if (this.province != null)
/* 119 */       element.appendChild(this.province.createElement(element.getOwnerDocument(), this.namespaceXAdES));
/* 120 */     if (this.postal != null)
/* 121 */       element.appendChild(this.postal.createElement(element.getOwnerDocument(), this.namespaceXAdES));
/* 122 */     if (this.country != null) {
/* 123 */       element.appendChild(this.country.createElement(element.getOwnerDocument(), this.namespaceXAdES));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 131 */     if ((obj instanceof SignatureProductionPlaceType)) {
/* 132 */       SignatureProductionPlaceType sppt = (SignatureProductionPlaceType)obj;
/* 133 */       if (this.city == null) {
/* 134 */         if (sppt.city != null) {
/* 135 */           return false;
/*     */         }
/* 137 */       } else if (!this.city.equals(sppt.city))
/* 138 */         return false;
/* 139 */       if (this.country == null) {
/* 140 */         if (sppt.country != null) {
/* 141 */           return false;
/*     */         }
/* 143 */       } else if (!this.country.equals(sppt.country))
/* 144 */         return false;
/* 145 */       if (this.postal == null) {
/* 146 */         if (sppt.postal != null) {
/* 147 */           return false;
/*     */         }
/* 149 */       } else if (!this.postal.equals(sppt.postal))
/* 150 */         return false;
/* 151 */       if (this.province == null) {
/* 152 */         if (sppt.province != null) {
/* 153 */           return false;
/*     */         }
/* 155 */       } else if (!this.province.equals(sppt.province)) {
/* 156 */         return false;
/*     */       }
/* 158 */       return true;
/*     */     }
/* 160 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 168 */     Node node = UtilidadTratarNodo.getFirstElementChild(element, true);
/*     */     
/* 170 */     if (node == null)
/* 171 */       return;
/* 172 */     if (node.getNodeType() != 1)
/* 173 */       throw new InvalidInfoNodeException("Se esperaba elemento como hijo de SignatureProductionPlaceType");
/* 174 */     Element child = (Element)node;
/* 175 */     City cityTemp = new City(this.schema);
/* 176 */     if (cityTemp.isThisNode(child)) {
/* 177 */       cityTemp.load(child);
/* 178 */       this.city = cityTemp;
/* 179 */       node = UtilidadTratarNodo.getNextElementSibling(node, true);
/*     */     } else {
/* 181 */       this.city = null;
/*     */     }
/*     */     
/* 184 */     if (node == null)
/* 185 */       return;
/* 186 */     if (node.getNodeType() != 1)
/* 187 */       throw new InvalidInfoNodeException("Se esperaba elemento como hijo de SignatureProductionPlaceType");
/* 188 */     child = (Element)node;
/* 189 */     StateOrProvince stateTemp = new StateOrProvince(this.schema);
/* 190 */     if (stateTemp.isThisNode(child)) {
/* 191 */       stateTemp.load(child);
/* 192 */       this.province = stateTemp;
/* 193 */       node = UtilidadTratarNodo.getNextElementSibling(node, true);
/*     */     } else {
/* 195 */       this.province = null;
/*     */     }
/*     */     
/* 198 */     if (node == null)
/* 199 */       return;
/* 200 */     if (node.getNodeType() != 1)
/* 201 */       throw new InvalidInfoNodeException("Se esperaba elemento como hijo de SignatureProductionPlaceType");
/* 202 */     child = (Element)node;
/* 203 */     PostalCode postalTemp = new PostalCode(this.schema);
/* 204 */     if (postalTemp.isThisNode(child)) {
/* 205 */       postalTemp.load(child);
/* 206 */       this.postal = postalTemp;
/* 207 */       node = UtilidadTratarNodo.getNextElementSibling(node, true);
/*     */     } else {
/* 209 */       this.postal = null;
/*     */     }
/*     */     
/* 212 */     if (node == null)
/* 213 */       return;
/* 214 */     if (node.getNodeType() != 1)
/* 215 */       throw new InvalidInfoNodeException("Se esperaba elemento como hijo de SignatureProductionPlaceType");
/* 216 */     child = (Element)node;
/* 217 */     CountryName countryTemp = new CountryName(this.schema);
/* 218 */     if (countryTemp.isThisNode(child)) {
/* 219 */       countryTemp.load(child);
/* 220 */       this.country = countryTemp;
/* 221 */       node = UtilidadTratarNodo.getNextElementSibling(node, true);
/*     */     } else {
/* 223 */       this.country = null;
/*     */     }
/* 225 */     if (node != null) {
/* 226 */       throw new InvalidInfoNodeException("No se esperaba este elemento como hijo de SignatureProductionPlaceType");
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\SignatureProductionPlaceType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */