/*     */ package es.mityc.firmaJava.libreria.utilidades;
/*     */ 
/*     */ import java.security.cert.CertificateEncodingException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Vector;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.bouncycastle.asn1.x509.X509Name;
/*     */ import org.bouncycastle.jce.PrincipalUtil;
/*     */ import org.bouncycastle.jce.X509Principal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UtilidadDNIe
/*     */ {
/*  39 */   static Log log = LogFactory.getLog(UtilidadDNIe.class);
/*     */   
/*     */   public static enum SUBJECT_OR_ISSUER {
/*  42 */     SUBJECT, 
/*  43 */     ISSUER;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getCN(X509Certificate cert, SUBJECT_OR_ISSUER tipo)
/*     */   {
/*  61 */     String retorno = "";
/*  62 */     X509Principal nombre = null;
/*     */     
/*     */     try
/*     */     {
/*  66 */       if (tipo == SUBJECT_OR_ISSUER.ISSUER) {
/*  67 */         nombre = PrincipalUtil.getIssuerX509Principal(cert);
/*     */       } else {
/*  69 */         nombre = PrincipalUtil.getSubjectX509Principal(cert);
/*     */       }
/*     */     } catch (CertificateEncodingException e) {
/*  72 */       log.error(e.getMessage(), e);
/*  73 */       return retorno;
/*     */     }
/*     */     
/*     */ 
/*  77 */     Vector<?> commonNameOIDs = nombre.getOIDs();
/*  78 */     Vector<?> commonName = nombre.getValues();
/*  79 */     int longitudValues = commonName.size();
/*     */     
/*  81 */     if (longitudValues != 0)
/*     */     {
/*  83 */       int indexCN = commonNameOIDs.indexOf(X509Name.CN);
/*  84 */       if (indexCN != -1) {
/*  85 */         Object elemento = commonName.get(indexCN);
/*  86 */         if ((elemento instanceof String)) {
/*  87 */           retorno = (String)elemento;
/*     */         } else {
/*  89 */           log.error("El CN obtenido no es de tipo String");
/*     */         }
/*     */       }
/*     */       
/*  93 */       if (retorno == "") {
/*  94 */         int indexOU = commonNameOIDs.indexOf(X509Name.OU);
/*  95 */         if (indexOU != -1) {
/*  96 */           Object elemento = commonName.get(indexOU);
/*  97 */           if ((elemento instanceof String)) {
/*  98 */             retorno = (String)elemento;
/*     */           } else {
/* 100 */             log.error("El CN obtenido no es de tipo String");
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 105 */       if ((retorno == "") || (retorno == null)) {
/* 106 */         int indexO = commonNameOIDs.indexOf(X509Name.O);
/* 107 */         if (indexO != -1) {
/* 108 */           Object elemento = commonName.get(indexO);
/* 109 */           if ((elemento instanceof String)) {
/* 110 */             retorno = (String)elemento;
/*     */           } else
/* 112 */             log.error("El CN obtenido no es de tipo String");
/*     */         }
/*     */       }
/*     */     } else {
/* 116 */       log.error("El certificado no contiene valores");
/*     */     }
/* 118 */     return retorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String convertDate(Date date)
/*     */   {
/* 127 */     SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
/* 128 */     String fecha = formatoFecha.format(date);
/*     */     
/* 130 */     return fecha.replace("/", "-");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String giveMeDNINumber(String subjectDN)
/*     */   {
/* 139 */     if (subjectDN == null) {
/* 140 */       return null;
/*     */     }
/* 142 */     String[] tokens = subjectDN.split(",");
/*     */     
/* 144 */     for (int a = 0; a < tokens.length; a++) {
/* 145 */       String[] nDNI = null;
/*     */       
/* 147 */       if (tokens[a].trim().startsWith("Número de serie")) {
/* 148 */         nDNI = tokens[a].trim().split("=");
/* 149 */         return nDNI[1].trim(); }
/* 150 */       if (tokens[a].trim().startsWith("OID.2.5.4.5")) {
/* 151 */         nDNI = tokens[a].trim().split("=");
/* 152 */         return nDNI[1].trim(); }
/* 153 */       if (tokens[a].trim().startsWith("serialNumber")) {
/* 154 */         nDNI = tokens[a].trim().split("=");
/* 155 */         return nDNI[1].trim();
/*     */       }
/*     */     }
/* 158 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final boolean isCertDNIe(String emisorDN)
/*     */   {
/* 167 */     return (emisorDN.indexOf("OU=DNIE") >= 0) && (
/* 168 */       emisorDN.indexOf("O=DIRECCION GENERAL DE LA POLICIA") >= 0);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\utilidades\UtilidadDNIe.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */