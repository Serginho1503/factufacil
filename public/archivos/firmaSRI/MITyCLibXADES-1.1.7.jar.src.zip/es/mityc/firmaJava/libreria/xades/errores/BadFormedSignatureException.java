/*    */ package es.mityc.firmaJava.libreria.xades.errores;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BadFormedSignatureException
/*    */   extends XMLError
/*    */ {
/*    */   public BadFormedSignatureException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public BadFormedSignatureException(String msg)
/*    */   {
/* 36 */     super(msg);
/*    */   }
/*    */   
/*    */   public BadFormedSignatureException(String message, Throwable cause) {
/* 40 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public BadFormedSignatureException(Throwable cause) {
/* 44 */     super(cause);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\errores\BadFormedSignatureException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */