/*     */ package es.mityc.firmaJava.libreria.xades.elementos;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLDataURIType
/*     */   extends AbstractXMLElement
/*     */ {
/*     */   protected URI value;
/*     */   
/*     */   public XMLDataURIType(URI value)
/*     */   {
/*  37 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addContent(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  45 */     if (this.value == null) {
/*  46 */       throw new InvalidInfoNodeException("Información insuficiente para escribir nodo XMLDataURIType");
/*     */     }
/*  48 */     element.setTextContent(this.value.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  56 */     if ((obj instanceof XMLDataURIType)) {
/*  57 */       if (this.value.equals(((XMLDataURIType)obj).value))
/*  58 */         return true;
/*  59 */     } else if (((obj instanceof URI)) && 
/*  60 */       (this.value.equals(obj))) {
/*  61 */       return true;
/*     */     }
/*  63 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  71 */     Node node = getFirstNonvoidNode(element);
/*  72 */     if (node == null) {
/*  73 */       return;
/*     */     }
/*  75 */     if (node.getNodeType() != 3) {
/*  76 */       throw new InvalidInfoNodeException("Nodo xsd:anyURI no contiene CDATA como primer valor");
/*     */     }
/*     */     
/*     */ 
/*  80 */     String data = node.getNodeValue();
/*  81 */     if (data == null) {
/*  82 */       throw new InvalidInfoNodeException("No hay URI en nodo xsd:anyURI");
/*     */     }
/*     */     try
/*     */     {
/*  86 */       data = data.replace(" ", "%20");
/*  87 */       uri = new URI(data);
/*     */     } catch (URISyntaxException ex) { URI uri;
/*  89 */       throw new InvalidInfoNodeException("URI malformada en nodo xsd:anyURI", ex);
/*     */     }
/*     */     URI uri;
/*  92 */     this.value = uri;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public URI getValue()
/*     */   {
/*  99 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setValue(URI value)
/*     */   {
/* 106 */     this.value = value;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\XMLDataURIType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */