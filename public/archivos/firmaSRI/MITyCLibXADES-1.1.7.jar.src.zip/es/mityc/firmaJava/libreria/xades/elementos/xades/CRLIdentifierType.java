/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.utilidades.UtilidadTratarNodo;
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.math.BigInteger;
/*     */ import java.util.Date;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CRLIdentifierType
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private Issuer issuer;
/*     */   private IssueTime issueTime;
/*     */   private Number number;
/*     */   private String uri;
/*     */   
/*     */   public CRLIdentifierType(XAdESSchemas schema, String issuer, Date issueTime, BigInteger number, String URI)
/*     */   {
/*  46 */     super(schema);
/*  47 */     if (issuer != null)
/*  48 */       this.issuer = new Issuer(schema, issuer);
/*  49 */     if (issueTime != null)
/*  50 */       this.issueTime = new IssueTime(schema, issueTime);
/*  51 */     if (number != null)
/*  52 */       this.number = new Number(schema, number);
/*  53 */     if (URI != null)
/*  54 */       this.uri = URI;
/*     */   }
/*     */   
/*     */   public CRLIdentifierType(XAdESSchemas schema) {
/*  58 */     super(schema);
/*     */   }
/*     */   
/*     */   public String getUri() {
/*  62 */     return this.uri;
/*     */   }
/*     */   
/*     */   public void setUri(String uri) {
/*  66 */     this.uri = uri;
/*     */   }
/*     */   
/*     */   public Issuer getIssuer() {
/*  70 */     return this.issuer;
/*     */   }
/*     */   
/*     */   public void setIssuer(Issuer issuer) {
/*  74 */     this.issuer = issuer;
/*     */   }
/*     */   
/*     */   public IssueTime getIssueTime() {
/*  78 */     return this.issueTime;
/*     */   }
/*     */   
/*     */   public void setIssueTime(IssueTime issueTime) {
/*  82 */     this.issueTime = issueTime;
/*     */   }
/*     */   
/*     */   public Number getNumber() {
/*  86 */     return this.number;
/*     */   }
/*     */   
/*     */   public void setNumber(Number number) {
/*  90 */     this.number = number;
/*     */   }
/*     */   
/*     */   public void addContent(Element element, String namespaceXAdES) throws InvalidInfoNodeException
/*     */   {
/*  95 */     super.addContent(element, namespaceXAdES);
/*     */   }
/*     */   
/*     */   protected void addContent(Element element) throws InvalidInfoNodeException
/*     */   {
/* 100 */     if ((this.issuer == null) || (this.issueTime == null)) {
/* 101 */       throw new InvalidInfoNodeException("Información insuficiente para escribir nodo CRLIdentifierType");
/*     */     }
/* 103 */     element.appendChild(this.issuer.createElement(element.getOwnerDocument(), this.namespaceXAdES));
/* 104 */     element.appendChild(this.issueTime.createElement(element.getOwnerDocument(), this.namespaceXAdES));
/*     */     
/* 106 */     if (this.number != null) {
/* 107 */       element.appendChild(this.number.createElement(element.getOwnerDocument(), this.namespaceXAdES));
/*     */     }
/* 109 */     if (this.uri != null) {
/* 110 */       element.setAttributeNS(null, "URI", this.uri);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 116 */     if ((obj instanceof CRLIdentifierType)) {
/* 117 */       CRLIdentifierType crl = (CRLIdentifierType)obj;
/* 118 */       if ((this.issuer == null) || (this.issueTime == null))
/* 119 */         return false;
/* 120 */       if (!this.issuer.equals(crl.getIssuer()))
/* 121 */         return false;
/* 122 */       if (this.issueTime.equals(crl.getIssueTime())) {
/* 123 */         return false;
/*     */       }
/*     */     }
/* 126 */     return false;
/*     */   }
/*     */   
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 132 */     if (element.hasAttribute("URI")) {
/* 133 */       this.uri = element.getAttribute("URI");
/*     */     }
/*     */     
/* 136 */     Node node = UtilidadTratarNodo.getFirstElementChild(element, true);
/* 137 */     if ((node == null) || (node.getNodeType() != 1))
/* 138 */       throw new InvalidInfoNodeException("Se esperaba elemento como hijo de CRLIdentifierType");
/* 139 */     Element child = (Element)node;
/* 140 */     this.issuer = new Issuer(this.schema);
/* 141 */     this.issuer.load(child);
/*     */     
/*     */ 
/* 144 */     node = UtilidadTratarNodo.getNextElementSibling(child, true);
/* 145 */     if ((node == null) || (node.getNodeType() != 1))
/* 146 */       throw new InvalidInfoNodeException("Se esperaba elemento como hijo de CRLIdentifierType");
/* 147 */     child = (Element)node;
/* 148 */     this.issueTime = new IssueTime(this.schema);
/* 149 */     this.issueTime.load(child);
/*     */     
/*     */ 
/* 152 */     node = UtilidadTratarNodo.getNextElementSibling(child, true);
/* 153 */     if (node != null) {
/* 154 */       if (node.getNodeType() != 1)
/* 155 */         throw new InvalidInfoNodeException("Se esperaba elemento como hijo de CRLIdentifierType");
/* 156 */       child = (Element)node;
/* 157 */       this.number = new Number(this.schema);
/* 158 */       this.number.load(child);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\CRLIdentifierType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */