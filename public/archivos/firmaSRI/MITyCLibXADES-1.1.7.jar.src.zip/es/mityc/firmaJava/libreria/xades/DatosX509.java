/*     */ package es.mityc.firmaJava.libreria.xades;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DatosX509
/*     */ {
/*  29 */   private String algMethod = null;
/*  30 */   private String digestValue = null;
/*  31 */   private BigInteger serial = null;
/*  32 */   private X500Principal issuer = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DatosX509() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public DatosX509(String algMethod, String digestValue, BigInteger serial, X500Principal issuer)
/*     */   {
/*  43 */     this.algMethod = algMethod;
/*  44 */     this.digestValue = digestValue;
/*  45 */     this.serial = serial;
/*  46 */     this.issuer = issuer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getAlgMethod()
/*     */   {
/*  53 */     return this.algMethod;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setAlgMethod(String algMethod)
/*     */   {
/*  60 */     this.algMethod = algMethod;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getDigestValue()
/*     */   {
/*  67 */     return this.digestValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDigestValue(String digestValue)
/*     */   {
/*  74 */     this.digestValue = digestValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public X500Principal getIssuer()
/*     */   {
/*  81 */     return this.issuer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setIssuer(X500Principal issuer)
/*     */   {
/*  88 */     this.issuer = issuer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public BigInteger getSerial()
/*     */   {
/*  95 */     return this.serial;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setSerial(BigInteger serial)
/*     */   {
/* 102 */     this.serial = serial;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\DatosX509.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */