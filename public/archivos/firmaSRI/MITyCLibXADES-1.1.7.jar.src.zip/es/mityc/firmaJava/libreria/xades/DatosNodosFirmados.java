/*     */ package es.mityc.firmaJava.libreria.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.utilidades.NombreNodo;
/*     */ import es.mityc.firmaJava.libreria.utilidades.UtilidadTratarNodo;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.ObjectIdentifier;
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.xml.xades.ReferenceProxy;
/*     */ import es.mityc.javasign.xml.xades.TransformProxy;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DatosNodosFirmados
/*     */ {
/*  47 */   private static final Log LOGGER = LogFactory.getLog(DatosNodosFirmados.class);
/*     */   
/*  49 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibXAdES");
/*     */   
/*     */   private static final String XPOINTER_ID = "#xpointer(id('";
/*     */   
/*     */   private static final String XPOINTER_ROOT = "#xpointer(/)";
/*     */   
/*     */   private ObjectIdentifier oi;
/*     */   
/*     */   private String desc;
/*     */   
/*     */   private String mimeType;
/*     */   
/*     */   private URI encoding;
/*     */   private ReferenceProxy reference;
/*     */   
/*     */   public DatosNodosFirmados() {}
/*     */   
/*     */   public DatosNodosFirmados(ObjectIdentifier oi, String desc, String mimeType, URI encoding)
/*     */   {
/*  68 */     this.oi = oi;
/*  69 */     this.desc = desc;
/*  70 */     this.mimeType = mimeType;
/*  71 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */   public void setReference(ReferenceProxy ref) {
/*  75 */     this.reference = ref;
/*     */     
/*  77 */     if ((ref != null) && (!isExternalData())) {
/*  78 */       Element el = UtilidadTratarNodo.getElementById(ref.getElement().getOwnerDocument(), getId());
/*  79 */       NombreNodo nn = new NombreNodo("xmlns", "Object");
/*  80 */       if (nn.equals(el)) {
/*  81 */         setMimeType(el.getAttribute("MimeType"));
/*  82 */         String data = el.getAttribute("Encoding");
/*  83 */         if (data != null) {
/*     */           try
/*     */           {
/*  86 */             data = data.replace(" ", "%20");
/*  87 */             setEncoding(new URI(data));
/*     */           } catch (URISyntaxException ex) {
/*  89 */             LOGGER.warn(I18N.getLocalMessage("i18n.mityc.xades.validate.9", new Object[] { ex.getMessage() }));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getId()
/*     */   {
/* 102 */     String uri = getURI();
/* 103 */     return uri != null ? uri : uri.startsWith("#") ? uri.substring(1) : uri.startsWith("#xpointer(id('") ? uri.substring("#xpointer(id('".length(), uri.length() - 2) : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getIdReference()
/*     */   {
/* 111 */     return this.reference != null ? this.reference.getID() : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element getElementReference()
/*     */   {
/* 119 */     return this.reference != null ? this.reference.getElement() : null;
/*     */   }
/*     */   
/*     */   public ObjectIdentifier getObjectIdentifier() {
/* 123 */     return this.oi;
/*     */   }
/*     */   
/* 126 */   public void setObjectIdentifier(ObjectIdentifier oi) { this.oi = oi; }
/*     */   
/*     */   public String getDescription() {
/* 129 */     return this.desc;
/*     */   }
/*     */   
/* 132 */   public void setDescription(String desc) { this.desc = desc; }
/*     */   
/*     */   public String getMimeType() {
/* 135 */     return this.mimeType;
/*     */   }
/*     */   
/* 138 */   public void setMimeType(String mimeType) { this.mimeType = mimeType; }
/*     */   
/*     */   public URI getEncoding() {
/* 141 */     return this.encoding;
/*     */   }
/*     */   
/* 144 */   public void setEncoding(URI encoding) { this.encoding = encoding; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getURI()
/*     */   {
/* 152 */     return this.reference != null ? this.reference.getURI() : "#xpointer(/)".equals(this.reference) ? "" : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<TransformProxy> getTransforms()
/*     */   {
/* 160 */     return this.reference != null ? this.reference.getTransforms() : new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean canBeModifiedByTransforms()
/*     */   {
/* 170 */     boolean modified = false;
/* 171 */     List<TransformProxy> trans = getTransforms();
/* 172 */     for (TransformProxy transform : trans) {
/* 173 */       String uri = transform.getURI();
/* 174 */       if ((!TransformProxy.isCanonicalization(transform)) && (!uri.equals("http://www.w3.org/2000/09/xmldsig#enveloped-signature"))) {
/* 175 */         modified = true;
/* 176 */         break;
/*     */       }
/*     */     }
/* 179 */     return modified;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getNodoFirmadoBytes()
/*     */   {
/* 187 */     return this.reference.getBytes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeBytesToStream(OutputStream os)
/*     */     throws IOException
/*     */   {
/* 196 */     this.reference.writeToStream(os);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSignInternal()
/*     */   {
/* 205 */     boolean res = false;
/* 206 */     if ((!isExternalData()) && 
/* 207 */       (this.reference != null)) {
/* 208 */       String id = getId();
/* 209 */       if (id != null) {
/* 210 */         Element el = UtilidadTratarNodo.getElementById(this.reference.getElement().getOwnerDocument(), id);
/* 211 */         if (el != null) {
/* 212 */           Element signature = (Element)this.reference.getElement().getParentNode().getParentNode();
/* 213 */           if (UtilidadTratarNodo.isChildNode(el, signature))
/*     */           {
/* 215 */             res = !UtilidadTratarNodo.isChildNode(el, new NombreNodo("xmlns", "Object"), signature);
/*     */           } else {
/* 217 */             res = false;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 223 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isExternalData()
/*     */   {
/* 231 */     boolean res = false;
/* 232 */     if (this.reference != null) {
/* 233 */       String uri = this.reference.getURI();
/* 234 */       if ((uri != null) && (!"".equals(uri)) && (!uri.startsWith("#"))) {
/* 235 */         res = true;
/*     */       }
/*     */     }
/* 238 */     return res;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\DatosNodosFirmados.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */