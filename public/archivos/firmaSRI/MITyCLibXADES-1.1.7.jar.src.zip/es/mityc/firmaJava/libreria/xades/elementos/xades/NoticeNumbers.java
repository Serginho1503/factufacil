/*    */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*    */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*    */ import java.util.ArrayList;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoticeNumbers
/*    */   extends IntegerListType
/*    */ {
/*    */   public NoticeNumbers(XAdESSchemas schema)
/*    */   {
/* 40 */     super(schema);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public NoticeNumbers(XAdESSchemas schema, ArrayList<Int> ints)
/*    */   {
/* 48 */     super(schema, ints);
/*    */   }
/*    */   
/*    */   public NoticeNumbers(XAdESSchemas schema, int[] ints) {
/* 52 */     super(schema, ints);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void load(Element element)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 60 */     checkElementName(element, this.schema.getSchemaUri(), "NoticeNumbers");
/* 61 */     super.load(element);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isThisNode(Node node)
/*    */   {
/* 69 */     return isElementName(nodeToElement(node), this.schema.getSchemaUri(), "NoticeNumbers");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Element createElement(Document doc, String namespaceXAdES)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 77 */     return super.createElement(doc, namespaceXAdES);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected Element createElement(Document doc)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 85 */     Element res = doc.createElementNS(this.schema.getSchemaUri(), this.namespaceXAdES + ":" + "NoticeNumbers");
/* 86 */     super.addContent(res, this.namespaceXAdES);
/* 87 */     return res;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\NoticeNumbers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */