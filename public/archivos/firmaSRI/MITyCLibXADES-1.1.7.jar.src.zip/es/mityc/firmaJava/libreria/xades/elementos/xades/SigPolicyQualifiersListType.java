/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SigPolicyQualifiersListType
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private ArrayList<SigPolicyQualifier> qualifiers;
/*     */   
/*     */   public SigPolicyQualifiersListType(XAdESSchemas schema)
/*     */   {
/*  42 */     super(schema);
/*     */   }
/*     */   
/*     */   public SigPolicyQualifiersListType(XAdESSchemas schema, ArrayList<SigPolicyQualifier> list) {
/*  46 */     super(schema);
/*  47 */     this.qualifiers = list;
/*     */   }
/*     */   
/*     */ 
/*     */   public ArrayList<SigPolicyQualifier> getList()
/*     */   {
/*  53 */     return this.qualifiers;
/*     */   }
/*     */   
/*     */   public void setList(ArrayList<SigPolicyQualifier> list) {
/*  57 */     this.qualifiers = list;
/*     */   }
/*     */   
/*     */   public void addPolicyQualifier(SigPolicyQualifier qualifier) {
/*  61 */     if (this.qualifiers == null)
/*  62 */       this.qualifiers = new ArrayList();
/*  63 */     this.qualifiers.add(qualifier);
/*     */   }
/*     */   
/*     */   public void addPolicyQualifier(IPolicyQualifier policyQualifier) {
/*  67 */     if (this.qualifiers == null)
/*  68 */       this.qualifiers = new ArrayList();
/*  69 */     this.qualifiers.add(new SigPolicyQualifier(this.schema, policyQualifier));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  77 */     if ((obj instanceof SigPolicyQualifiersListType)) {
/*  78 */       SigPolicyQualifiersListType cvt = (SigPolicyQualifiersListType)obj;
/*  79 */       ArrayList<SigPolicyQualifier> comp = cvt.qualifiers;
/*  80 */       if (((this.qualifiers == null) || (this.qualifiers.isEmpty())) && (
/*  81 */         (comp == null) || (comp.isEmpty())))
/*  82 */         return true;
/*  83 */       if ((this.qualifiers != null) && (comp != null) && 
/*  84 */         (this.qualifiers.size() == comp.size())) {
/*  85 */         Iterator<SigPolicyQualifier> itThis = this.qualifiers.iterator();
/*  86 */         Iterator<SigPolicyQualifier> itComp = comp.iterator();
/*  87 */         while (itThis.hasNext()) {
/*  88 */           if (!((SigPolicyQualifier)itThis.next()).equals(itComp.next()))
/*  89 */             return false;
/*     */         }
/*  91 */         return true;
/*     */       }
/*     */     }
/*  94 */     return false;
/*     */   }
/*     */   
/*     */   protected void addContent(Element element) throws InvalidInfoNodeException
/*     */   {
/*  99 */     if ((this.qualifiers != null) && (this.qualifiers.size() > 0)) {
/* 100 */       Iterator<SigPolicyQualifier> it = this.qualifiers.iterator();
/* 101 */       while (it.hasNext()) {
/* 102 */         element.appendChild(((SigPolicyQualifier)it.next()).createElement(element.getOwnerDocument(), this.namespaceXAdES));
/*     */       }
/*     */     }
/*     */     else {
/* 106 */       throw new InvalidInfoNodeException("Nodo SigPolicyQualifiersListType no tiene ningún hijo");
/*     */     }
/*     */   }
/*     */   
/*     */   public void addContent(Element element, String namespaceXAdES) throws InvalidInfoNodeException {
/* 111 */     super.addContent(element, namespaceXAdES);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 120 */     NodeList nodos = element.getChildNodes();
/* 121 */     ArrayList<SigPolicyQualifier> temp = new ArrayList(nodos.getLength());
/* 122 */     for (int i = 0; i < nodos.getLength(); i++) {
/* 123 */       Node nodo = nodos.item(i);
/* 124 */       if (!isDecorationNode(nodo))
/*     */       {
/*     */ 
/* 127 */         if (nodo.getNodeType() != 1) {
/* 128 */           throw new InvalidInfoNodeException("Hijo de SigPolicyQualifiersListType no es un elemento");
/*     */         }
/* 130 */         SigPolicyQualifier qualifier = new SigPolicyQualifier(this.schema);
/* 131 */         qualifier.load((Element)nodo);
/* 132 */         temp.add(qualifier);
/*     */       } }
/* 134 */     if (temp.size() == 0) {
/* 135 */       throw new InvalidInfoNodeException("SigPolicyQualifiersListType no tiene hijos");
/*     */     }
/* 137 */     this.qualifiers = temp;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\SigPolicyQualifiersListType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */