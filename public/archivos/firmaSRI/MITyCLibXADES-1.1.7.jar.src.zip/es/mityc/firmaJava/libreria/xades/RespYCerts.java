/*    */ package es.mityc.firmaJava.libreria.xades;
/*    */ 
/*    */ import es.mityc.javasign.certificate.ICertStatus;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RespYCerts
/*    */ {
/* 26 */   private String x509CertFile = null;
/* 27 */   private ICertStatus certstatus = null;
/* 28 */   private String idCertificado = null;
/* 29 */   private String idRespStatus = null;
/* 30 */   private String fileName = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getIdCertificado()
/*    */   {
/* 38 */     return this.idCertificado;
/*    */   }
/*    */   
/*    */   public void setIdCertificado(String idCertificado) {
/* 42 */     this.idCertificado = idCertificado;
/*    */   }
/*    */   
/*    */   public String getIdRespStatus() {
/* 46 */     return this.idRespStatus;
/*    */   }
/*    */   
/*    */   public void setIdRespStatus(String idRespStatus) {
/* 50 */     this.idRespStatus = idRespStatus;
/*    */   }
/*    */   
/*    */   public String getX509CertFile()
/*    */   {
/* 55 */     return this.x509CertFile;
/*    */   }
/*    */   
/*    */   public void setX509CertFile(String certFile) {
/* 59 */     this.x509CertFile = certFile;
/*    */   }
/*    */   
/*    */   public ICertStatus getCertstatus()
/*    */   {
/* 64 */     return this.certstatus;
/*    */   }
/*    */   
/*    */   public void setCertstatus(ICertStatus certstatus) {
/* 68 */     this.certstatus = certstatus;
/*    */   }
/*    */   
/*    */   public void setFilename(String filename) {
/* 72 */     this.fileName = filename;
/*    */   }
/*    */   
/*    */   public String getFilename() {
/* 76 */     return this.fileName;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\RespYCerts.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */