/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.math.BigInteger;
/*     */ import java.security.cert.CRLException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509CRL;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ import org.bouncycastle.asn1.ASN1InputStream;
/*     */ import org.bouncycastle.asn1.DERInteger;
/*     */ import org.bouncycastle.asn1.DEROctetString;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CRLRefType
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private DigestAlgAndValue digest;
/*     */   private CRLIdentifier crlIdentifier;
/*     */   
/*     */   public CRLRefType(XAdESSchemas schema)
/*     */   {
/*  53 */     super(schema);
/*     */   }
/*     */   
/*     */   public CRLRefType(XAdESSchemas schema, String method, X509CRL crl) throws InvalidInfoNodeException {
/*  57 */     super(schema);
/*  58 */     loadCRL(method, crl);
/*     */   }
/*     */   
/*     */   public CRLRefType(XAdESSchemas schema, String method, File crlFile) throws InvalidInfoNodeException {
/*  62 */     super(schema);
/*     */     try {
/*  64 */       CertificateFactory cf = CertificateFactory.getInstance("X.509");
/*  65 */       X509CRL crl = (X509CRL)cf.generateCRL(new FileInputStream(crlFile));
/*  66 */       loadCRL(method, crl);
/*     */     } catch (CertificateException ex) {
/*  68 */       throw new InvalidInfoNodeException("Error generando digest de CRL", ex);
/*     */     } catch (CRLException ex) {
/*  70 */       throw new InvalidInfoNodeException("Error generando digest de CRL", ex);
/*     */     } catch (FileNotFoundException ex) {
/*  72 */       throw new InvalidInfoNodeException("Error generando digest de CRL", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private void loadCRL(String method, X509CRL crl) throws InvalidInfoNodeException {
/*     */     try {
/*  78 */       this.digest = new DigestAlgAndValue(this.schema, method, crl.getEncoded());
/*     */     } catch (CRLException ex) {
/*  80 */       throw new InvalidInfoNodeException("Error generando digest de CRL", ex);
/*     */     }
/*  82 */     BigInteger numeroRecuperado = null;
/*  83 */     byte[] extension = crl.getExtensionValue("2.5.29.20");
/*  84 */     if (extension != null) {
/*     */       try {
/*  86 */         ASN1InputStream ais = new ASN1InputStream(extension);
/*  87 */         ais = new ASN1InputStream(((DEROctetString)ais.readObject()).getOctets());
/*  88 */         DERInteger derInt = (DERInteger)ais.readObject();
/*  89 */         numeroRecuperado = derInt.getValue();
/*     */       } catch (IOException ex) {
/*  91 */         throw new InvalidInfoNodeException("Error generando digest de CRL", ex);
/*     */       }
/*     */     }
/*  94 */     this.crlIdentifier = new CRLIdentifier(this.schema, crl.getIssuerX500Principal().getName(), crl.getThisUpdate(), numeroRecuperado, null);
/*     */   }
/*     */   
/*     */   public DigestAlgAndValue getDigest() {
/*  98 */     return this.digest;
/*     */   }
/*     */   
/*     */   public void setDigest(DigestAlgAndValue digest) {
/* 102 */     this.digest = digest;
/*     */   }
/*     */   
/*     */   public CRLIdentifier getCrlIdentifier() {
/* 106 */     return this.crlIdentifier;
/*     */   }
/*     */   
/*     */   public void setCrlIdentifier(CRLIdentifier crlIdentifier) {
/* 110 */     this.crlIdentifier = crlIdentifier;
/*     */   }
/*     */   
/*     */   public void addContent(Element element, String namespaceXAdES, String namespaceXDsig) throws InvalidInfoNodeException
/*     */   {
/* 115 */     super.addContent(element, namespaceXAdES, namespaceXDsig);
/*     */   }
/*     */   
/*     */   protected void addContent(Element element) throws InvalidInfoNodeException
/*     */   {
/* 120 */     if (this.digest == null) {
/* 121 */       throw new InvalidInfoNodeException("Información insuficiente para escribir nodo CRLRefType");
/*     */     }
/* 123 */     element.appendChild(this.digest.createElement(element.getOwnerDocument(), this.namespaceXDsig, this.namespaceXAdES));
/*     */     
/* 125 */     if (this.crlIdentifier != null) {
/* 126 */       element.appendChild(this.crlIdentifier.createElement(element.getOwnerDocument(), this.namespaceXAdES));
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 132 */     if ((obj instanceof CRLRefType)) {
/* 133 */       CRLRefType crl = (CRLRefType)obj;
/* 134 */       if ((this.digest == null) || (crl.digest == null))
/* 135 */         return false;
/* 136 */       if (this.digest.equals(crl.digest))
/* 137 */         return true;
/*     */     }
/* 139 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 147 */     Node node = element.getFirstChild();
/* 148 */     DigestAlgAndValue digest = new DigestAlgAndValue(this.schema);
/* 149 */     if (!digest.isThisNode(node))
/* 150 */       throw new InvalidInfoNodeException("Nodo CRLRefType no tiene hijo DigestAlgAndValue");
/* 151 */     digest.load((Element)node);
/*     */     
/* 153 */     node = node.getNextSibling();
/* 154 */     CRLIdentifier crlIdentifier = null;
/* 155 */     if (node != null) {
/* 156 */       crlIdentifier = new CRLIdentifier(this.schema);
/* 157 */       if (!crlIdentifier.isThisNode(node))
/* 158 */         throw new InvalidInfoNodeException("Se esperaba hijo CRLIdentifier en nodo CRLRefType");
/* 159 */       crlIdentifier.load((Element)node);
/*     */     }
/*     */     
/* 162 */     this.digest = digest;
/* 163 */     this.crlIdentifier = crlIdentifier;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\CRLRefType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */