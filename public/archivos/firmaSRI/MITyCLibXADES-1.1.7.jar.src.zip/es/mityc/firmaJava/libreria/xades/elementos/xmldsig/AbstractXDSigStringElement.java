/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xmldsig;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.XMLDataStringType;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AbstractXDSigStringElement
/*     */   extends AbstractXDsigElement
/*     */ {
/*     */   private XMLDataStringType data;
/*     */   private String nameElement;
/*     */   
/*     */   public AbstractXDSigStringElement(String nameElement, String data)
/*     */   {
/*  37 */     this.nameElement = nameElement;
/*  38 */     this.data = new XMLDataStringType(data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractXDSigStringElement(String nameElement)
/*     */   {
/*  47 */     this.nameElement = nameElement;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Element createElement(Document doc)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  55 */     if (this.data == null) {
/*  56 */       throw new InvalidInfoNodeException("Información insuficiente para escribir elemento " + this.nameElement);
/*     */     }
/*  58 */     Element res = doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", this.namespaceXDsig + ":" + this.nameElement);
/*  59 */     this.data.addContent(res);
/*  60 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Element createElement(Document doc, String namespaceXDsig)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  68 */     return super.createElement(doc, namespaceXDsig);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  76 */     if ((obj instanceof AbstractXDSigStringElement)) {
/*  77 */       AbstractXDSigStringElement desc = (AbstractXDSigStringElement)obj;
/*  78 */       if ((this.nameElement.equals(desc.nameElement)) && (this.data.equals(desc.data))) {
/*  79 */         return true;
/*     */       }
/*     */     } else {
/*  82 */       return this.data.equals(obj);
/*     */     }
/*  84 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  92 */     checkElementName(element, "http://www.w3.org/2000/09/xmldsig#", this.nameElement);
/*  93 */     this.data = new XMLDataStringType(null);
/*  94 */     this.data.load(element);
/*     */   }
/*     */   
/*     */   public void setValue(String value) {
/*  98 */     if (this.data == null) {
/*  99 */       this.data = new XMLDataStringType(value);
/*     */     } else {
/* 101 */       this.data.setValue(value);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getValue() {
/* 106 */     if (this.data != null) {
/* 107 */       return this.data.getValue();
/*     */     }
/* 109 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isThisNode(Node node)
/*     */   {
/* 117 */     return isElementName(nodeToElement(node), "http://www.w3.org/2000/09/xmldsig#", this.nameElement);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xmldsig\AbstractXDSigStringElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */