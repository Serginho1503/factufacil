/*    */ package es.mityc.firmaJava.libreria.xades.elementos;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.utilidades.UtilidadFechas;
/*    */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*    */ import java.util.Date;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMLDataDateTimeType
/*    */   extends AbstractXMLElement
/*    */ {
/*    */   protected Date value;
/*    */   
/*    */   public XMLDataDateTimeType(Date value)
/*    */   {
/* 37 */     this.value = value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void addContent(Element element)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 45 */     if (this.value == null) {
/* 46 */       throw new InvalidInfoNodeException("Información insuficiente para escribir nodo DateTimeType");
/*    */     }
/* 48 */     element.setTextContent(UtilidadFechas.formatFechaXML(this.value));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 56 */     if ((obj instanceof XMLDataDateTimeType)) {
/* 57 */       if (this.value.equals(((XMLDataDateTimeType)obj).value))
/* 58 */         return true;
/* 59 */     } else if (((obj instanceof Date)) && 
/* 60 */       (this.value.equals(obj))) {
/* 61 */       return true;
/*    */     }
/* 63 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void load(Element element)
/*    */     throws InvalidInfoNodeException
/*    */   {
/* 71 */     Node node = getFirstNonvoidNode(element);
/* 72 */     if ((node == null) || (node.getNodeType() != 3)) {
/* 73 */       throw new InvalidInfoNodeException("Nodo xsd:string no contiene CDATA como primer valor");
/*    */     }
/* 75 */     String value = node.getNodeValue();
/* 76 */     if (value != null) {
/* 77 */       this.value = UtilidadFechas.parseaFechaXML(value);
/*    */     }
/* 79 */     if (this.value == null) {
/* 80 */       throw new InvalidInfoNodeException("Contenido de valor de xsd.string vacío");
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public Date getValue()
/*    */   {
/* 87 */     return this.value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setValue(Date value)
/*    */   {
/* 94 */     this.value = value;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\XMLDataDateTimeType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */