/*    */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Int
/*    */   extends AbstractXadesIntegerElement
/*    */ {
/*    */   public Int(XAdESSchemas schema, BigInteger data)
/*    */   {
/* 37 */     super(schema, "int", data);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Int(XAdESSchemas schema)
/*    */   {
/* 45 */     super(schema, "int");
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\Int.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */