/*      */ package es.mityc.firmaJava.libreria.utilidades;
/*      */ 
/*      */ import adsi.org.apache.xml.security.c14n.CanonicalizationException;
/*      */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*      */ import adsi.org.apache.xml.security.transforms.TransformationException;
/*      */ import adsi.org.apache.xml.security.transforms.Transforms;
/*      */ import es.mityc.firmaJava.libreria.xades.CanonicalizationEnum;
/*      */ import es.mityc.firmaJava.libreria.xades.errores.FirmaXMLError;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ import java.util.Iterator;
/*      */ import java.util.Random;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.w3c.dom.Attr;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.NamedNodeMap;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class UtilidadTratarNodo
/*      */ {
/*   52 */   private static Log log = LogFactory.getLog(UtilidadTratarNodo.class);
/*      */   
/*   54 */   private static final String[] IDs = { "Id", "id", "ID" };
/*      */   
/*   56 */   private static Random rnd = new Random(new Date().getTime());
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int RND_MAX_SIZE = 1048576;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final String XPOINTER_ID = "#xpointer(id('";
/*      */   
/*      */ 
/*      */ 
/*      */   public static final String XPOINTER_ROOT = "#xpointer(/)";
/*      */   
/*      */ 
/*      */ 
/*      */   public static byte[] obtenerByteNodo(Document doc, String ns, String nombreHijos, CanonicalizationEnum canonicalization)
/*      */     throws FirmaXMLError
/*      */   {
/*   75 */     return obtenerByteNodo(doc.getDocumentElement(), ns, nombreHijos, canonicalization, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] obtenerByteNodo(Element padre, String ns, String nombreHijos, CanonicalizationEnum canonicalization, int tope)
/*      */     throws FirmaXMLError
/*      */   {
/*   93 */     return obtenerByteNodo(padre, ns, nombreHijos, true, canonicalization, tope);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] obtenerByteNodo(Element padre, String ns, String nombreHijos, boolean requerido, CanonicalizationEnum canonicalization, int tope)
/*      */     throws FirmaXMLError
/*      */   {
/*  107 */     if ((canonicalization == null) || (canonicalization.equals(CanonicalizationEnum.UNKNOWN))) {
/*  108 */       throw new FirmaXMLError("Canonicalization Method desconocido");
/*      */     }
/*  110 */     ArrayList<Element> nodesHijos = new ArrayList();
/*      */     
/*  112 */     if (ns == null) {
/*  113 */       ns = padre.getNamespaceURI();
/*      */     }
/*  115 */     if (tope <= 0) {
/*  116 */       NodeList nodosSinTope = padre.getElementsByTagNameNS(ns, nombreHijos);
/*  117 */       for (int i = 0; i < nodosSinTope.getLength(); i++) {
/*  118 */         nodesHijos.add((Element)nodosSinTope.item(i));
/*      */       }
/*      */     } else {
/*  121 */       nodesHijos = obtenerNodos(padre, tope, new NombreNodo(ns, nombreHijos));
/*      */     }
/*  123 */     log.debug("Número de firmas en el documento: " + nodesHijos.size());
/*      */     
/*  125 */     if ((nodesHijos.size() == 0) && (requerido)) {
/*  126 */       log.error(I18n.getResource("libreriaxades.firmaxml.error8") + " " + I18n.getResource("libreriaxades.firmaxml.error33") + " " + nombreHijos);
/*  127 */       throw new FirmaXMLError(I18n.getResource("libreriaxades.firmaxml.error8") + " " + I18n.getResource("libreriaxades.firmaxml.error33") + " " + nombreHijos);
/*      */     }
/*      */     
/*  130 */     if (nodesHijos.size() > 0) {
/*  131 */       Transforms t = new Transforms(padre.getOwnerDocument());
/*      */       try
/*      */       {
/*  134 */         t.addTransform(canonicalization.toString());
/*      */       } catch (TransformationException e) {
/*  136 */         log.error(e);
/*  137 */         throw new FirmaXMLError(I18n.getResource("libreriaxades.firmaxml.error8"));
/*      */       }
/*      */       
/*  140 */       ByteArrayOutputStream bais = new ByteArrayOutputStream();
/*      */       
/*  142 */       for (int i = 0; i < nodesHijos.size(); i++) {
/*  143 */         XMLSignatureInput xmlSignatureInput = new XMLSignatureInput((Node)nodesHijos.get(i));
/*      */         try {
/*  145 */           XMLSignatureInput resultado = null;
/*  146 */           resultado = t.performTransforms(xmlSignatureInput);
/*  147 */           bais.write(resultado.getBytes());
/*      */         } catch (TransformationException ex) {
/*  149 */           log.error(I18n.getResource("libreriaxades.firmaxml.error34"), ex);
/*  150 */           throw new FirmaXMLError(I18n.getResource("libreriaxades.firmaxml.error8"));
/*      */         } catch (CanonicalizationException ex) {
/*  152 */           log.error(I18n.getResource("libreriaxades.firmaxml.error34"), ex);
/*  153 */           throw new FirmaXMLError(I18n.getResource("libreriaxades.firmaxml.error8"));
/*      */         } catch (IOException ex) {
/*  155 */           log.error(I18n.getResource("libreriaxades.firmaxml.error34"), ex);
/*  156 */           throw new FirmaXMLError(I18n.getResource("libreriaxades.firmaxml.error8"));
/*      */         }
/*      */       }
/*      */       
/*  160 */       if (bais.size() > 0)
/*  161 */         return bais.toByteArray();
/*      */     }
/*  163 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] obtenerByteNodo(Element padre, String ns, String nombreHijos, Element tope)
/*      */     throws FirmaXMLError
/*      */   {
/*  177 */     NodeList nodesHijos = null;
/*      */     
/*  179 */     if (ns == null) {
/*  180 */       ns = padre.getNamespaceURI();
/*      */     }
/*  182 */     nodesHijos = padre.getChildNodes();
/*      */     
/*  184 */     if (nodesHijos.getLength() > 0) {
/*  185 */       Transforms t = new Transforms(padre.getOwnerDocument());
/*      */       try
/*      */       {
/*  188 */         t.addTransform("http://www.w3.org/TR/2001/REC-xml-c14n-20010315");
/*      */       } catch (TransformationException e) {
/*  190 */         log.error(e);
/*  191 */         throw new FirmaXMLError(I18n.getResource("libreriaxades.firmaxml.error8"));
/*      */       }
/*      */       
/*  194 */       ByteArrayOutputStream bais = new ByteArrayOutputStream();
/*      */       
/*  196 */       for (int i = 0; i < nodesHijos.getLength(); i++) {
/*  197 */         Node nodo = nodesHijos.item(i);
/*      */         
/*      */ 
/*  200 */         if (nodo.getNodeType() == 1)
/*      */         {
/*      */ 
/*      */ 
/*  204 */           if ((tope != null) && 
/*  205 */             (tope.isEqualNode(nodo))) {
/*      */             break;
/*      */           }
/*      */           
/*      */ 
/*  210 */           if (nodo.getLocalName().equals(nombreHijos))
/*      */           {
/*      */ 
/*  213 */             if (ns == null ? 
/*  214 */               nodo.getNamespaceURI() == null : 
/*      */               
/*  216 */               ns.equals(nodo.getNamespaceURI()))
/*      */             {
/*      */ 
/*  219 */               XMLSignatureInput xmlSignatureInput = new XMLSignatureInput(nodo);
/*      */               try {
/*  221 */                 XMLSignatureInput resultado = null;
/*  222 */                 resultado = t.performTransforms(xmlSignatureInput);
/*  223 */                 bais.write(resultado.getBytes());
/*      */               } catch (TransformationException ex) {
/*  225 */                 log.error(I18n.getResource("libreriaxades.firmaxml.error34"), ex);
/*  226 */                 throw new FirmaXMLError(I18n.getResource("libreriaxades.firmaxml.error8"));
/*      */               } catch (CanonicalizationException ex) {
/*  228 */                 log.error(I18n.getResource("libreriaxades.firmaxml.error34"), ex);
/*  229 */                 throw new FirmaXMLError(I18n.getResource("libreriaxades.firmaxml.error8"));
/*      */               } catch (IOException ex) {
/*  231 */                 log.error(I18n.getResource("libreriaxades.firmaxml.error34"), ex);
/*  232 */                 throw new FirmaXMLError(I18n.getResource("libreriaxades.firmaxml.error8"));
/*      */               }
/*      */             } }
/*      */         } }
/*  236 */       if (bais.size() > 0)
/*  237 */         return bais.toByteArray();
/*      */     }
/*  239 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] obtenerByteNodo(Element padre, ArrayList<NombreNodo> nombreHijos, Element tope)
/*      */     throws FirmaXMLError
/*      */   {
/*  252 */     NodeList nodesHijos = null;
/*      */     
/*  254 */     nodesHijos = padre.getChildNodes();
/*      */     
/*  256 */     if (nodesHijos.getLength() > 0) {
/*  257 */       Transforms t = new Transforms(padre.getOwnerDocument());
/*      */       try
/*      */       {
/*  260 */         t.addTransform("http://www.w3.org/TR/2001/REC-xml-c14n-20010315");
/*      */       } catch (TransformationException e) {
/*  262 */         log.error(e);
/*  263 */         throw new FirmaXMLError(I18n.getResource("libreriaxades.firmaxml.error8"));
/*      */       }
/*      */       
/*  266 */       ByteArrayOutputStream bais = new ByteArrayOutputStream();
/*      */       
/*  268 */       for (int i = 0; i < nodesHijos.getLength(); i++) {
/*  269 */         Node nodo = nodesHijos.item(i);
/*      */         
/*      */ 
/*  272 */         if (nodo.getNodeType() == 1)
/*      */         {
/*      */ 
/*      */ 
/*  276 */           if ((tope != null) && 
/*  277 */             (tope.isEqualNode(nodo))) {
/*      */             break;
/*      */           }
/*      */           
/*      */ 
/*  282 */           NombreNodo nombreNodo = new NombreNodo(nodo.getNamespaceURI(), nodo.getLocalName());
/*  283 */           if (nombreHijos.indexOf(nombreNodo) != -1)
/*      */           {
/*      */ 
/*  286 */             XMLSignatureInput xmlSignatureInput = new XMLSignatureInput(nodo);
/*      */             try {
/*  288 */               XMLSignatureInput resultado = null;
/*  289 */               resultado = t.performTransforms(xmlSignatureInput);
/*  290 */               bais.write(resultado.getBytes());
/*      */             } catch (TransformationException ex) {
/*  292 */               log.error(I18n.getResource("libreriaxades.firmaxml.error34"), ex);
/*  293 */               throw new FirmaXMLError(I18n.getResource("libreriaxades.firmaxml.error8"));
/*      */             } catch (CanonicalizationException ex) {
/*  295 */               log.error(I18n.getResource("libreriaxades.firmaxml.error34"), ex);
/*  296 */               throw new FirmaXMLError(I18n.getResource("libreriaxades.firmaxml.error8"));
/*      */             } catch (IOException ex) {
/*  298 */               log.error(I18n.getResource("libreriaxades.firmaxml.error34"), ex);
/*  299 */               throw new FirmaXMLError(I18n.getResource("libreriaxades.firmaxml.error8"));
/*      */             }
/*      */           }
/*      */         } }
/*  303 */       if (bais.size() > 0)
/*  304 */         return bais.toByteArray();
/*      */     }
/*  306 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ArrayList<Element> obtenerNodos(Element padre, Element tope, NombreNodo nombreHijo)
/*      */   {
/*  318 */     if (padre == null) {
/*  319 */       return null;
/*      */     }
/*  321 */     ArrayList<Element> resultado = new ArrayList();
/*  322 */     NodeList nodesHijos = padre.getChildNodes();
/*      */     
/*  324 */     for (int i = 0; i < nodesHijos.getLength(); i++) {
/*  325 */       Node nodo = nodesHijos.item(i);
/*      */       
/*      */ 
/*  328 */       if (nodo.getNodeType() == 1)
/*      */       {
/*      */ 
/*      */ 
/*  332 */         if ((tope != null) && 
/*  333 */           (tope.isEqualNode(nodo))) {
/*      */           break;
/*      */         }
/*      */         
/*      */ 
/*  338 */         if (new NombreNodo(nodo.getNamespaceURI(), nodo.getLocalName()).equals(nombreHijo))
/*  339 */           resultado.add((Element)nodo);
/*      */       } }
/*  341 */     return resultado;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ArrayList<Element> obtenerNodos(Element padre, Element tope, ArrayList<NombreNodo> nombreHijos)
/*      */     throws FirmaXMLError
/*      */   {
/*  354 */     ArrayList<Element> resultado = new ArrayList();
/*  355 */     NodeList nodesHijos = padre.getChildNodes();
/*      */     
/*  357 */     for (int i = 0; i < nodesHijos.getLength(); i++) {
/*  358 */       Node nodo = nodesHijos.item(i);
/*      */       
/*      */ 
/*  361 */       if (nodo.getNodeType() == 1)
/*      */       {
/*      */ 
/*      */ 
/*  365 */         if ((tope != null) && 
/*  366 */           (tope.isEqualNode(nodo))) {
/*      */           break;
/*      */         }
/*      */         
/*      */ 
/*  371 */         if (nombreHijos.indexOf(new NombreNodo(nodo.getNamespaceURI(), nodo.getLocalName())) != -1)
/*  372 */           resultado.add((Element)nodo);
/*      */       } }
/*  374 */     return resultado;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] obtenerByteNuevo(ArrayList<Element> nodos, CanonicalizationEnum canonicalization)
/*      */     throws FirmaXMLError
/*      */   {
/*  384 */     if ((nodos == null) || (nodos.size() == 0)) {
/*  385 */       return null;
/*      */     }
/*  387 */     if ((canonicalization == null) || (canonicalization.equals(CanonicalizationEnum.UNKNOWN))) {
/*  388 */       return null;
/*      */     }
/*  390 */     ByteArrayOutputStream bais = new ByteArrayOutputStream();
/*      */     
/*  392 */     Iterator<Element> it = nodos.iterator();
/*  393 */     while (it.hasNext()) {
/*  394 */       Element nodo = (Element)it.next();
/*      */       try {
/*  396 */         bais.write(obtenerByte(nodo, canonicalization));
/*      */       } catch (IOException ex) {
/*  398 */         log.error(I18n.getResource("libreriaxades.firmaxml.error34"), ex);
/*  399 */         throw new FirmaXMLError(I18n.getResource("libreriaxades.firmaxml.error8"));
/*      */       }
/*      */     }
/*      */     
/*  403 */     if (bais.size() > 0)
/*  404 */       return bais.toByteArray();
/*  405 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] obtenerByte(Element nodo, CanonicalizationEnum canonicalization)
/*      */     throws FirmaXMLError
/*      */   {
/*  415 */     if (nodo == null) {
/*  416 */       return null;
/*      */     }
/*  418 */     if ((canonicalization == null) || (canonicalization.equals(CanonicalizationEnum.UNKNOWN))) {
/*  419 */       return null;
/*      */     }
/*  421 */     Transforms t = new Transforms(nodo.getOwnerDocument());
/*      */     try
/*      */     {
/*  424 */       t.addTransform(canonicalization.toString());
/*      */     } catch (TransformationException e) {
/*  426 */       log.error(e);
/*  427 */       throw new FirmaXMLError(I18n.getResource("libreriaxades.firmaxml.error8"));
/*      */     }
/*      */     
/*  430 */     XMLSignatureInput xmlSignatureInput = new XMLSignatureInput(nodo);
/*      */     try {
/*  432 */       XMLSignatureInput resultado = null;
/*  433 */       resultado = t.performTransforms(xmlSignatureInput);
/*  434 */       return resultado.getBytes();
/*      */     } catch (TransformationException ex) {
/*  436 */       log.error(I18n.getResource("libreriaxades.firmaxml.error34"), ex);
/*  437 */       throw new FirmaXMLError(I18n.getResource("libreriaxades.firmaxml.error8"));
/*      */     } catch (CanonicalizationException ex) {
/*  439 */       log.error(I18n.getResource("libreriaxades.firmaxml.error34"), ex);
/*  440 */       throw new FirmaXMLError(I18n.getResource("libreriaxades.firmaxml.error8"));
/*      */     } catch (IOException ex) {
/*  442 */       log.error(I18n.getResource("libreriaxades.firmaxml.error34"), ex);
/*  443 */       throw new FirmaXMLError(I18n.getResource("libreriaxades.firmaxml.error8"));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] obtenerByte(ArrayList<Element> nodos, CanonicalizationEnum canonicalization)
/*      */     throws FirmaXMLError
/*      */   {
/*  454 */     if ((nodos == null) || (nodos.size() == 0)) {
/*  455 */       return null;
/*      */     }
/*  457 */     if ((canonicalization == null) || (canonicalization.equals(CanonicalizationEnum.UNKNOWN))) {
/*  458 */       return null;
/*      */     }
/*  460 */     Transforms t = new Transforms(((Element)nodos.get(0)).getOwnerDocument());
/*      */     try
/*      */     {
/*  463 */       t.addTransform(canonicalization.toString());
/*      */     } catch (TransformationException e) {
/*  465 */       log.error(e);
/*  466 */       throw new FirmaXMLError(I18n.getResource("libreriaxades.firmaxml.error8"));
/*      */     }
/*      */     
/*  469 */     ByteArrayOutputStream bais = new ByteArrayOutputStream();
/*      */     
/*  471 */     Iterator<Element> it = nodos.iterator();
/*  472 */     while (it.hasNext()) {
/*  473 */       Element nodo = (Element)it.next();
/*      */       
/*  475 */       XMLSignatureInput xmlSignatureInput = new XMLSignatureInput(nodo);
/*      */       try {
/*  477 */         XMLSignatureInput resultado = null;
/*  478 */         resultado = t.performTransforms(xmlSignatureInput);
/*  479 */         bais.write(resultado.getBytes());
/*      */       } catch (TransformationException ex) {
/*  481 */         log.error(I18n.getResource("libreriaxades.firmaxml.error34"), ex);
/*  482 */         throw new FirmaXMLError(I18n.getResource("libreriaxades.firmaxml.error8"));
/*      */       } catch (CanonicalizationException ex) {
/*  484 */         log.error(I18n.getResource("libreriaxades.firmaxml.error34"), ex);
/*  485 */         throw new FirmaXMLError(I18n.getResource("libreriaxades.firmaxml.error8"));
/*      */       } catch (IOException ex) {
/*  487 */         log.error(I18n.getResource("libreriaxades.firmaxml.error34"), ex);
/*  488 */         throw new FirmaXMLError(I18n.getResource("libreriaxades.firmaxml.error8"));
/*      */       }
/*      */     }
/*      */     
/*  492 */     if (bais.size() > 0)
/*  493 */       return bais.toByteArray();
/*  494 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String obtenerNombreNodo(Node node)
/*      */   {
/*  503 */     String nombreNodoConNS = node.getNodeName();
/*  504 */     int iPosNombreNodo = nombreNodoConNS.lastIndexOf(":") + 1;
/*  505 */     String nombreNodo = nombreNodoConNS.substring(iPosNombreNodo);
/*  506 */     return nombreNodo;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ArrayList<String> obtenerIDs(ArrayList<Element> elementos)
/*      */   {
/*  518 */     if (elementos == null)
/*  519 */       return null;
/*  520 */     ArrayList<String> resultado = new ArrayList();
/*  521 */     Iterator<Element> it = elementos.iterator();
/*  522 */     while (it.hasNext()) {
/*  523 */       Element elemento = (Element)it.next();
/*  524 */       boolean encontrado = false;
/*  525 */       NamedNodeMap map = elemento.getAttributes();
/*  526 */       for (int i = 0; i < map.getLength(); i++) {
/*  527 */         Attr attr = (Attr)map.item(i);
/*  528 */         if (attr.isId()) {
/*  529 */           resultado.add(attr.getValue());
/*  530 */           encontrado = true;
/*  531 */           break;
/*      */         }
/*      */       }
/*  534 */       if (!encontrado) {
/*  535 */         for (int i = 0; i < IDs.length; i++) {
/*  536 */           if (elemento.hasAttribute(IDs[i])) {
/*  537 */             resultado.add(elemento.getAttribute(IDs[i]));
/*  538 */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  543 */     return resultado;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getId(Element element)
/*      */   {
/*  552 */     String id = element.getAttribute("Id");
/*  553 */     if (id == null) {
/*  554 */       NamedNodeMap map = element.getAttributes();
/*  555 */       for (int i = 0; i < map.getLength(); i++) {
/*  556 */         Attr attr = (Attr)map.item(i);
/*  557 */         if (attr.isId()) {
/*  558 */           id = attr.getValue();
/*  559 */           break;
/*      */         }
/*      */       }
/*      */     }
/*  563 */     return id;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Element getElementById(NodeList list, String id)
/*      */   {
/*  573 */     Element resultado = null;
/*  574 */     if (list != null) {
/*  575 */       int length = list.getLength();
/*  576 */       for (int i = 0; i < length; i++) {
/*  577 */         Node node = list.item(i);
/*      */         
/*  579 */         if (node.getNodeType() == 1) {
/*  580 */           Element el = (Element)node;
/*  581 */           if (id.equals(el.getAttribute("Id"))) {
/*  582 */             resultado = el;
/*  583 */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  588 */     return resultado;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static Element exploreElementById(Element el, String id)
/*      */   {
/*  599 */     if (el != null) {
/*  600 */       for (int i = 0; i < IDs.length; i++) {
/*  601 */         if (id.equals(el.getAttribute(IDs[i]))) {
/*  602 */           return el;
/*      */         }
/*      */       }
/*      */       
/*  606 */       NodeList nodes = el.getChildNodes();
/*  607 */       for (int i = 0; i < nodes.getLength(); i++) {
/*  608 */         Node nodo = nodes.item(i);
/*  609 */         if (nodo.getNodeType() == 1) {
/*  610 */           Element temp = exploreElementById((Element)nodo, id);
/*  611 */           if (temp != null)
/*  612 */             return temp;
/*      */         }
/*      */       }
/*      */     }
/*  616 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Element getElementById(Document doc, String id)
/*      */   {
/*  627 */     if ((doc == null) || (id == null)) {
/*  628 */       return null;
/*      */     }
/*      */     
/*  631 */     if (id.length() == 0) {
/*  632 */       return doc.getDocumentElement();
/*      */     }
/*  634 */     id = id != null ? id : id.startsWith("#") ? id.substring(1) : id.startsWith("#xpointer(id('") ? id.substring("#xpointer(id('".length(), id.length() - 2) : null;
/*  635 */     Element el = doc.getElementById(id);
/*  636 */     if (el == null) {
/*  637 */       el = exploreElementById(doc.getDocumentElement(), id);
/*      */     }
/*  639 */     return el;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Element getElementById(Element padre, String id)
/*      */   {
/*  650 */     Element el = getElementById(padre.getOwnerDocument(), id);
/*      */     
/*  652 */     if (el != null) {
/*  653 */       Node temp = el;
/*  654 */       while ((temp != null) && (!temp.isSameNode(padre)))
/*  655 */         temp = temp.getParentNode();
/*  656 */       if (temp != null)
/*  657 */         return el;
/*      */     }
/*  659 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isChildNode(Element child, Element parent)
/*      */   {
/*  669 */     Node temp = child;
/*  670 */     while ((temp != null) && (!temp.isSameNode(parent))) {
/*  671 */       temp = temp.getParentNode();
/*      */     }
/*  673 */     return temp != null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isChildNode(Element child, NombreNodo parent, Element top)
/*      */   {
/*  684 */     Node temp = child;
/*  685 */     while ((temp != null) && (!temp.isSameNode(top))) {
/*  686 */       if (parent.equals(temp)) {
/*      */         break;
/*      */       }
/*  689 */       temp = temp.getParentNode();
/*      */     }
/*  691 */     return parent.equals(temp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String newID(Document doc, String prefix)
/*      */   {
/*  702 */     String newID = prefix + rnd.nextInt(1048576);
/*  703 */     while (getElementById(doc, newID) != null)
/*  704 */       newID = prefix + rnd.nextInt(1048576);
/*  705 */     return newID;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Element getFirstElementChild(Node node, boolean strict)
/*      */   {
/*  716 */     Node nodeTemp = node.getFirstChild();
/*      */     
/*  718 */     while ((nodeTemp != null) && (nodeTemp.getNodeType() != 1)) {
/*  719 */       if ((strict) && 
/*  720 */         (nodeTemp.getNodeType() == 3)) {
/*  721 */         String text = nodeTemp.getNodeValue().trim();
/*  722 */         text = text.replaceAll("/n", "");
/*  723 */         text = text.replaceAll("/r", "");
/*  724 */         text = text.replaceAll(" ", "");
/*  725 */         if (!text.equals("")) {
/*  726 */           return null;
/*      */         }
/*      */       }
/*  729 */       nodeTemp = nodeTemp.getNextSibling();
/*      */     }
/*  731 */     return (Element)nodeTemp;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Element getNextElementSibling(Node node, boolean strict)
/*      */   {
/*  742 */     Node nodeTemp = node.getNextSibling();
/*      */     
/*  744 */     while ((nodeTemp != null) && (nodeTemp.getNodeType() != 1)) {
/*  745 */       if ((strict) && 
/*  746 */         (nodeTemp.getNodeType() == 3)) {
/*  747 */         String text = nodeTemp.getNodeValue().trim();
/*  748 */         text = text.replaceAll("/n", "");
/*  749 */         text = text.replaceAll("/r", "");
/*  750 */         text = text.replaceAll(" ", "");
/*  751 */         if (!text.equals("")) {
/*  752 */           return null;
/*      */         }
/*      */       }
/*  755 */       nodeTemp = nodeTemp.getNextSibling();
/*      */     }
/*  757 */     return (Element)nodeTemp;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ArrayList<Element> getElementChildNodes(Element nodo, boolean strict)
/*      */   {
/*  767 */     ArrayList<Element> retorno = new ArrayList();
/*      */     
/*  769 */     Element hijo = getFirstElementChild(nodo, strict);
/*  770 */     int tope = nodo.getChildNodes().getLength();
/*      */     
/*  772 */     for (int i = 0; i < tope; i++) {
/*  773 */       if (hijo == null)
/*      */         break;
/*  775 */       retorno.add(hijo);
/*  776 */       hijo = getNextElementSibling(hijo, strict);
/*      */     }
/*      */     
/*  779 */     return retorno;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ArrayList<Element> obtenerNodos(Element padre, int tope, NombreNodo nombreHijos)
/*      */     throws FirmaXMLError
/*      */   {
/*  887 */     ArrayList<Element> resultado = new ArrayList();
/*  888 */     NodeList nodesHijos = padre.getChildNodes();
/*      */     
/*  890 */     if (tope < 1) {
/*  891 */       tope = 1;
/*      */     }
/*  893 */     for (int i = 0; i < nodesHijos.getLength(); i++) {
/*  894 */       Node nodo = nodesHijos.item(i);
/*      */       
/*      */ 
/*  897 */       if (nodo.getNodeType() == 1)
/*      */       {
/*      */ 
/*      */ 
/*  901 */         if (nombreHijos.equals(new NombreNodo(nodo.getNamespaceURI(), nodo.getLocalName()))) {
/*  902 */           resultado.add((Element)nodo);
/*      */         }
/*  904 */         if (tope > 1) {
/*  905 */           ArrayList<Element> hijos = obtenerNodos((Element)nodo, tope - 1, nombreHijos);
/*  906 */           if (hijos.size() > 0) {
/*  907 */             resultado.addAll(hijos);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  975 */     return resultado;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ArrayList<Element> obtenerNodos(Element padre, int tope, String nombreHijos)
/*      */     throws FirmaXMLError
/*      */   {
/*  990 */     ArrayList<Element> resultado = new ArrayList();
/*  991 */     NodeList nodesHijos = padre.getChildNodes();
/*      */     
/*  993 */     if (tope < 1) {
/*  994 */       tope = 1;
/*      */     }
/*  996 */     for (int i = 0; i < nodesHijos.getLength(); i++) {
/*  997 */       Node nodo = nodesHijos.item(i);
/*      */       
/*      */ 
/* 1000 */       if (nodo.getNodeType() == 1)
/*      */       {
/*      */ 
/*      */ 
/* 1004 */         if (nombreHijos.equals(nodo.getLocalName())) {
/* 1005 */           resultado.add((Element)nodo);
/*      */         }
/* 1007 */         if (tope > 1) {
/* 1008 */           NodeList nodosHijos2 = nodo.getChildNodes();
/* 1009 */           for (int j = 0; j < nodosHijos2.getLength(); j++) {
/* 1010 */             Node nodo2 = nodosHijos2.item(j);
/*      */             
/*      */ 
/* 1013 */             if (nodo2.getNodeType() == 1)
/*      */             {
/*      */ 
/*      */ 
/* 1017 */               if (nombreHijos.equals(nodo2.getLocalName())) {
/* 1018 */                 resultado.add((Element)nodo2);
/*      */               }
/* 1020 */               if (tope > 2) {
/* 1021 */                 NodeList nodosHijos3 = nodo2.getChildNodes();
/* 1022 */                 for (int k = 0; k < nodosHijos3.getLength(); k++) {
/* 1023 */                   Node nodo3 = nodosHijos3.item(k);
/*      */                   
/*      */ 
/* 1026 */                   if (nodo3.getNodeType() == 1)
/*      */                   {
/*      */ 
/*      */ 
/* 1030 */                     if (nombreHijos.equals(nodo3.getLocalName())) {
/* 1031 */                       resultado.add((Element)nodo3);
/*      */                     }
/* 1033 */                     if (tope > 3) {
/* 1034 */                       NodeList nodosHijos4 = nodo3.getChildNodes();
/* 1035 */                       for (int l = 0; l < nodosHijos4.getLength(); l++) {
/* 1036 */                         Node nodo4 = nodosHijos4.item(l);
/*      */                         
/*      */ 
/* 1039 */                         if (nodo4.getNodeType() == 1)
/*      */                         {
/*      */ 
/*      */ 
/* 1043 */                           if (nombreHijos.equals(nodo4.getLocalName())) {
/* 1044 */                             resultado.add((Element)nodo4);
/*      */                           }
/* 1046 */                           if (tope > 4) {
/* 1047 */                             NodeList nodosHijos5 = nodo4.getChildNodes();
/* 1048 */                             for (int m = 0; m < nodosHijos5.getLength(); m++) {
/* 1049 */                               Node nodo5 = nodosHijos5.item(m);
/*      */                               
/*      */ 
/* 1052 */                               if (nodo5.getNodeType() == 1)
/*      */                               {
/*      */ 
/*      */ 
/* 1056 */                                 if (nombreHijos.equals(nodo5.getLocalName()))
/* 1057 */                                   resultado.add((Element)nodo5); }
/*      */                             }
/*      */                           }
/*      */                         }
/*      */                       }
/*      */                     }
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */           } } } }
/* 1068 */     return resultado;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void saveDocumentToOutputStream(Document document, OutputStream outputStream)
/*      */   {
/* 1085 */     UtilidadFicheros.writeXML(document, outputStream);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void saveDocumentToOutputStream(Document document, OutputStream outputStream, boolean addPreamble)
/*      */   {
/* 1103 */     UtilidadFicheros.writeXML(document, outputStream);
/*      */   }
/*      */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\utilidades\UtilidadTratarNodo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */