/*     */ package es.mityc.firmaJava.libreria.utilidades;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.StringWriter;
/*     */ import java.net.URL;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.bouncycastle.util.encoders.HexEncoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Utilidades
/*     */ {
/*  43 */   static Log logger = LogFactory.getLog(Utilidades.class);
/*     */   
/*     */ 
/*     */   private static final String STR_ABRIENDO_CONEXION = "Abriendo conexion con ";
/*     */   
/*     */ 
/*     */   private static final String STR_TRES_PUNTOS = "...";
/*     */   
/*     */ 
/*     */   public static boolean tieneValor(String valor)
/*     */   {
/*  54 */     if ((valor != null) && (!valor.trim().equals(""))) {
/*  55 */       return true;
/*     */     }
/*  57 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isEmpty(String valor)
/*     */   {
/*  66 */     return (valor == null) || (valor.trim().equals(""));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static InputStream getInputStreamFromURL(String _url)
/*     */     throws Exception
/*     */   {
/*  77 */     URL url = new URL(_url);
/*  78 */     logger.debug("Abriendo conexion con " + _url + "...");
/*  79 */     url.openConnection();
/*     */     
/*     */ 
/*  82 */     InputStream is = url.openStream();
/*     */     
/*  84 */     System.out.flush();
/*     */     
/*  86 */     return is;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public static void writeInputStream(java.io.File sourceFile, java.io.Writer wtargetFile)
/*     */     throws IOException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: sipush 510
/*     */     //   3: newarray <illegal type>
/*     */     //   5: astore_2
/*     */     //   6: iconst_0
/*     */     //   7: istore_3
/*     */     //   8: aconst_null
/*     */     //   9: astore 4
/*     */     //   11: aload_1
/*     */     //   12: checkcast 108	java/io/BufferedWriter
/*     */     //   15: astore 5
/*     */     //   17: new 110	java/io/BufferedInputStream
/*     */     //   20: dup
/*     */     //   21: new 112	java/io/FileInputStream
/*     */     //   24: dup
/*     */     //   25: aload_0
/*     */     //   26: invokespecial 114	java/io/FileInputStream:<init>	(Ljava/io/File;)V
/*     */     //   29: invokespecial 117	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
/*     */     //   32: astore 4
/*     */     //   34: ldc 45
/*     */     //   36: astore 6
/*     */     //   38: aload 4
/*     */     //   40: aload_2
/*     */     //   41: invokevirtual 120	java/io/BufferedInputStream:read	([B)I
/*     */     //   44: istore_3
/*     */     //   45: iload_3
/*     */     //   46: iconst_m1
/*     */     //   47: if_icmpne +6 -> 53
/*     */     //   50: goto +46 -> 96
/*     */     //   53: new 40	java/lang/String
/*     */     //   56: dup
/*     */     //   57: aload_2
/*     */     //   58: iload_3
/*     */     //   59: invokestatic 124	es/mityc/firmaJava/libreria/utilidades/Base64Coder:encode	([BI)[C
/*     */     //   62: invokespecial 130	java/lang/String:<init>	([C)V
/*     */     //   65: astore 6
/*     */     //   67: aload 5
/*     */     //   69: aload 6
/*     */     //   71: invokevirtual 133	java/io/BufferedWriter:write	(Ljava/lang/String;)V
/*     */     //   74: iload_3
/*     */     //   75: ifge -37 -> 38
/*     */     //   78: goto +18 -> 96
/*     */     //   81: astore 7
/*     */     //   83: aload 4
/*     */     //   85: ifnull +8 -> 93
/*     */     //   88: aload 4
/*     */     //   90: invokevirtual 136	java/io/BufferedInputStream:close	()V
/*     */     //   93: aload 7
/*     */     //   95: athrow
/*     */     //   96: aload 4
/*     */     //   98: ifnull +8 -> 106
/*     */     //   101: aload 4
/*     */     //   103: invokevirtual 136	java/io/BufferedInputStream:close	()V
/*     */     //   106: return
/*     */     // Line number table:
/*     */     //   Java source line #96	-> byte code offset #0
/*     */     //   Java source line #97	-> byte code offset #6
/*     */     //   Java source line #98	-> byte code offset #8
/*     */     //   Java source line #99	-> byte code offset #11
/*     */     //   Java source line #101	-> byte code offset #17
/*     */     //   Java source line #102	-> byte code offset #34
/*     */     //   Java source line #104	-> byte code offset #38
/*     */     //   Java source line #105	-> byte code offset #45
/*     */     //   Java source line #106	-> byte code offset #53
/*     */     //   Java source line #107	-> byte code offset #67
/*     */     //   Java source line #108	-> byte code offset #74
/*     */     //   Java source line #103	-> byte code offset #75
/*     */     //   Java source line #109	-> byte code offset #78
/*     */     //   Java source line #110	-> byte code offset #81
/*     */     //   Java source line #111	-> byte code offset #83
/*     */     //   Java source line #112	-> byte code offset #88
/*     */     //   Java source line #113	-> byte code offset #93
/*     */     //   Java source line #111	-> byte code offset #96
/*     */     //   Java source line #112	-> byte code offset #101
/*     */     //   Java source line #115	-> byte code offset #106
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	107	0	sourceFile	java.io.File
/*     */     //   0	107	1	wtargetFile	java.io.Writer
/*     */     //   5	53	2	buffer	byte[]
/*     */     //   7	68	3	numBytes	int
/*     */     //   9	93	4	bSourceFile	java.io.BufferedInputStream
/*     */     //   15	53	5	targetFile	java.io.BufferedWriter
/*     */     //   36	34	6	aux	String
/*     */     //   81	13	7	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   17	81	81	finally
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public static void writeInputStream(java.io.File sourceFile, java.io.File attachedFile, java.io.Writer wtargetFile)
/*     */     throws IOException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: sipush 510
/*     */     //   3: newarray <illegal type>
/*     */     //   5: astore_3
/*     */     //   6: iconst_0
/*     */     //   7: istore 4
/*     */     //   9: aconst_null
/*     */     //   10: astore 5
/*     */     //   12: aload_2
/*     */     //   13: checkcast 108	java/io/BufferedWriter
/*     */     //   16: astore 6
/*     */     //   18: new 108	java/io/BufferedWriter
/*     */     //   21: dup
/*     */     //   22: new 160	java/io/FileWriter
/*     */     //   25: dup
/*     */     //   26: aload_1
/*     */     //   27: invokespecial 162	java/io/FileWriter:<init>	(Ljava/io/File;)V
/*     */     //   30: invokespecial 163	java/io/BufferedWriter:<init>	(Ljava/io/Writer;)V
/*     */     //   33: astore 7
/*     */     //   35: aload_1
/*     */     //   36: invokevirtual 166	java/io/File:deleteOnExit	()V
/*     */     //   39: new 110	java/io/BufferedInputStream
/*     */     //   42: dup
/*     */     //   43: new 112	java/io/FileInputStream
/*     */     //   46: dup
/*     */     //   47: aload_0
/*     */     //   48: invokespecial 114	java/io/FileInputStream:<init>	(Ljava/io/File;)V
/*     */     //   51: invokespecial 117	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
/*     */     //   54: astore 5
/*     */     //   56: ldc 45
/*     */     //   58: astore 8
/*     */     //   60: aload 5
/*     */     //   62: aload_3
/*     */     //   63: invokevirtual 120	java/io/BufferedInputStream:read	([B)I
/*     */     //   66: istore 4
/*     */     //   68: iload 4
/*     */     //   70: iconst_m1
/*     */     //   71: if_icmpne +6 -> 77
/*     */     //   74: goto +75 -> 149
/*     */     //   77: new 40	java/lang/String
/*     */     //   80: dup
/*     */     //   81: aload_3
/*     */     //   82: iload 4
/*     */     //   84: invokestatic 124	es/mityc/firmaJava/libreria/utilidades/Base64Coder:encode	([BI)[C
/*     */     //   87: invokespecial 130	java/lang/String:<init>	([C)V
/*     */     //   90: astore 8
/*     */     //   92: aload 6
/*     */     //   94: aload 8
/*     */     //   96: invokevirtual 133	java/io/BufferedWriter:write	(Ljava/lang/String;)V
/*     */     //   99: aload 7
/*     */     //   101: aload 8
/*     */     //   103: invokevirtual 133	java/io/BufferedWriter:write	(Ljava/lang/String;)V
/*     */     //   106: aload 6
/*     */     //   108: invokevirtual 169	java/io/BufferedWriter:flush	()V
/*     */     //   111: aload 7
/*     */     //   113: invokevirtual 169	java/io/BufferedWriter:flush	()V
/*     */     //   116: iload 4
/*     */     //   118: ifge -58 -> 60
/*     */     //   121: goto +28 -> 149
/*     */     //   124: astore 9
/*     */     //   126: aload 7
/*     */     //   128: ifnull +8 -> 136
/*     */     //   131: aload 7
/*     */     //   133: invokevirtual 170	java/io/BufferedWriter:close	()V
/*     */     //   136: aload 5
/*     */     //   138: ifnull +8 -> 146
/*     */     //   141: aload 5
/*     */     //   143: invokevirtual 136	java/io/BufferedInputStream:close	()V
/*     */     //   146: aload 9
/*     */     //   148: athrow
/*     */     //   149: aload 7
/*     */     //   151: ifnull +8 -> 159
/*     */     //   154: aload 7
/*     */     //   156: invokevirtual 170	java/io/BufferedWriter:close	()V
/*     */     //   159: aload 5
/*     */     //   161: ifnull +8 -> 169
/*     */     //   164: aload 5
/*     */     //   166: invokevirtual 136	java/io/BufferedInputStream:close	()V
/*     */     //   169: return
/*     */     // Line number table:
/*     */     //   Java source line #125	-> byte code offset #0
/*     */     //   Java source line #126	-> byte code offset #6
/*     */     //   Java source line #128	-> byte code offset #9
/*     */     //   Java source line #129	-> byte code offset #12
/*     */     //   Java source line #131	-> byte code offset #18
/*     */     //   Java source line #132	-> byte code offset #35
/*     */     //   Java source line #136	-> byte code offset #39
/*     */     //   Java source line #137	-> byte code offset #56
/*     */     //   Java source line #139	-> byte code offset #60
/*     */     //   Java source line #140	-> byte code offset #68
/*     */     //   Java source line #141	-> byte code offset #77
/*     */     //   Java source line #142	-> byte code offset #92
/*     */     //   Java source line #143	-> byte code offset #99
/*     */     //   Java source line #144	-> byte code offset #106
/*     */     //   Java source line #145	-> byte code offset #111
/*     */     //   Java source line #147	-> byte code offset #116
/*     */     //   Java source line #138	-> byte code offset #118
/*     */     //   Java source line #149	-> byte code offset #121
/*     */     //   Java source line #150	-> byte code offset #124
/*     */     //   Java source line #151	-> byte code offset #126
/*     */     //   Java source line #152	-> byte code offset #131
/*     */     //   Java source line #154	-> byte code offset #136
/*     */     //   Java source line #155	-> byte code offset #141
/*     */     //   Java source line #156	-> byte code offset #146
/*     */     //   Java source line #151	-> byte code offset #149
/*     */     //   Java source line #152	-> byte code offset #154
/*     */     //   Java source line #154	-> byte code offset #159
/*     */     //   Java source line #155	-> byte code offset #164
/*     */     //   Java source line #158	-> byte code offset #169
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	170	0	sourceFile	java.io.File
/*     */     //   0	170	1	attachedFile	java.io.File
/*     */     //   0	170	2	wtargetFile	java.io.Writer
/*     */     //   5	77	3	buffer	byte[]
/*     */     //   7	110	4	numBytes	int
/*     */     //   10	155	5	bSourceFile	java.io.BufferedInputStream
/*     */     //   16	91	6	targetFile	java.io.BufferedWriter
/*     */     //   33	122	7	ficheroAdjuntoDatos	java.io.BufferedWriter
/*     */     //   58	44	8	aux	String
/*     */     //   124	23	9	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   39	124	124	finally
/*     */   }
/*     */   
/*     */   public static String binary2String(byte[] data)
/*     */   {
/*     */     try
/*     */     {
/* 167 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 168 */       HexEncoder enc = new HexEncoder();
/* 169 */       enc.encode(data, 0, data.length, baos);
/* 170 */       return baos.toString();
/*     */     }
/*     */     catch (IOException localIOException) {}
/* 173 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isEqual(byte[] data1, byte[] data2)
/*     */   {
/* 184 */     if ((data1 == null) && (data2 == null))
/* 185 */       return true;
/* 186 */     if ((data1 == null) || (data2 == null))
/* 187 */       return false;
/* 188 */     if (data1.length != data2.length)
/* 189 */       return false;
/* 190 */     for (int i = 0; i < data1.length; i++) {
/* 191 */       if (data1[i] != data2[i])
/* 192 */         return false;
/*     */     }
/* 194 */     return true;
/*     */   }
/*     */   
/* 197 */   private static int[] XML_ENTITIES = { 34, 38, 39, 60, 62 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String escapeXML(String str)
/*     */   {
/* 206 */     StringWriter stringWriter = new StringWriter((int)(str.length() + str.length() * 0.1D));
/* 207 */     int len = str.length();
/* 208 */     for (int i = 0; i < len; i++)
/*     */     {
/* 210 */       char c = str.charAt(i);
/* 211 */       if ((XML_ENTITIES[0] == c) || (XML_ENTITIES[1] == c) || (XML_ENTITIES[2] == c) || (XML_ENTITIES[3] == c) || (XML_ENTITIES[4] == c)) {
/* 212 */         stringWriter.write("&#");
/* 213 */         stringWriter.write(Integer.toString(c, 10));
/* 214 */         stringWriter.write(59);
/*     */       } else {
/* 216 */         stringWriter.write(c);
/*     */       }
/*     */     }
/* 219 */     return stringWriter.toString();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\utilidades\Utilidades.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */