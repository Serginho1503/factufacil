/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.security.cert.X509CRL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CRLValuesType
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private ArrayList<EncapsulatedCRLValue> crls;
/*     */   
/*     */   public CRLValuesType(XAdESSchemas schema)
/*     */   {
/*  43 */     super(schema);
/*     */   }
/*     */   
/*     */   public CRLValuesType(XAdESSchemas schema, ArrayList<EncapsulatedCRLValue> crls) {
/*  47 */     super(schema);
/*  48 */     this.crls = crls;
/*     */   }
/*     */   
/*     */   public void addEncapsulatedCRLValue(EncapsulatedCRLValue crl) {
/*  52 */     if (this.crls == null)
/*  53 */       this.crls = new ArrayList();
/*  54 */     this.crls.add(crl);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ArrayList<EncapsulatedCRLValue> getEncapsulatedCRLValues()
/*     */   {
/*  61 */     return this.crls;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setEncapsulatedCRLValues(ArrayList<EncapsulatedCRLValue> crls)
/*     */   {
/*  68 */     this.crls = crls;
/*     */   }
/*     */   
/*     */   public void addCRL(X509CRL crl, String id) throws InvalidInfoNodeException {
/*  72 */     EncapsulatedCRLValue ecv = new EncapsulatedCRLValue(this.schema, id, crl);
/*  73 */     addEncapsulatedCRLValue(ecv);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  81 */     if ((obj instanceof CertificateValuesType)) {
/*  82 */       CRLValuesType cvt = (CRLValuesType)obj;
/*  83 */       ArrayList<EncapsulatedCRLValue> comp = cvt.crls;
/*  84 */       if (((this.crls == null) || (this.crls.isEmpty())) && (
/*  85 */         (comp == null) || (comp.isEmpty())))
/*  86 */         return true;
/*  87 */       if ((this.crls != null) && (comp != null) && 
/*  88 */         (this.crls.size() == comp.size())) {
/*  89 */         Iterator<EncapsulatedCRLValue> itThis = this.crls.iterator();
/*  90 */         Iterator<EncapsulatedCRLValue> itComp = comp.iterator();
/*  91 */         while (itThis.hasNext()) {
/*  92 */           if (!((EncapsulatedCRLValue)itThis.next()).equals(itComp.next()))
/*  93 */             return false;
/*     */         }
/*  95 */         return true;
/*     */       }
/*     */     }
/*  98 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 106 */     NodeList nodos = element.getChildNodes();
/*     */     
/* 108 */     ArrayList<EncapsulatedCRLValue> temp = new ArrayList(nodos.getLength());
/* 109 */     for (int i = 0; i < nodos.getLength(); i++) {
/* 110 */       Node nodo = nodos.item(i);
/* 111 */       if (!isDecorationNode(nodo))
/*     */       {
/*     */ 
/* 114 */         if (nodo.getNodeType() != 1) {
/* 115 */           throw new InvalidInfoNodeException("Hijo de CRLValuesType no es un elemento");
/*     */         }
/* 117 */         EncapsulatedCRLValue crl = new EncapsulatedCRLValue(this.schema);
/* 118 */         crl.load((Element)nodo);
/* 119 */         temp.add(crl);
/*     */       }
/*     */     }
/* 122 */     if (temp.size() == 0) {
/* 123 */       throw new InvalidInfoNodeException("CRLValuesType debe tener al menos un hijo");
/*     */     }
/* 125 */     this.crls = temp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void addContent(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 133 */     if ((this.crls == null) || (this.crls.size() == 0))
/* 134 */       throw new InvalidInfoNodeException("CRLValuesType debe tener al menos un hijo");
/* 135 */     Iterator<EncapsulatedCRLValue> it = this.crls.iterator();
/* 136 */     while (it.hasNext()) {
/* 137 */       element.appendChild(((EncapsulatedCRLValue)it.next()).createElement(element.getOwnerDocument(), this.namespaceXAdES));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addContent(Element element, String namespaceXAdES)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 146 */     super.addContent(element, namespaceXAdES);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\CRLValuesType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */