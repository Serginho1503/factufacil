/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.net.URI;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EncapsulatedPKIDataType
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private String id;
/*     */   private EncodingEnum encoding;
/*     */   private String value;
/*     */   
/*     */   public EncapsulatedPKIDataType(XAdESSchemas schema)
/*     */   {
/*  36 */     super(schema);
/*     */   }
/*     */   
/*     */   public EncapsulatedPKIDataType(XAdESSchemas schema, String id) {
/*  40 */     super(schema);
/*  41 */     this.id = id;
/*     */   }
/*     */   
/*     */   public EncapsulatedPKIDataType(XAdESSchemas schema, String id, EncodingEnum encoding) {
/*  45 */     this(schema, id);
/*  46 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getId()
/*     */   {
/*  54 */     return this.id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setId(String id)
/*     */   {
/*  61 */     this.id = id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public EncodingEnum getEncoding()
/*     */   {
/*  68 */     if (!this.schema.equals(XAdESSchemas.XAdES_111))
/*  69 */       return this.encoding;
/*  70 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setEncoding(EncodingEnum encoding)
/*     */   {
/*  77 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getValue()
/*     */   {
/*  84 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setValue(String value)
/*     */   {
/*  91 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  99 */     if ((obj instanceof EncapsulatedPKIDataType)) {
/* 100 */       EncapsulatedPKIDataType epdt = (EncapsulatedPKIDataType)obj;
/*     */       
/* 102 */       if (this.value.equals(epdt.value))
/* 103 */         return true;
/*     */     }
/* 105 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addContent(Element element, String namespaceXAdES)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 113 */     super.addContent(element, namespaceXAdES);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 122 */     if (element.hasAttribute("Id"))
/* 123 */       this.id = element.getAttribute("Id");
/* 124 */     if (element.hasAttribute("Encoding")) {
/* 125 */       if (this.schema.equals(XAdESSchemas.XAdES_111))
/* 126 */         throw new InvalidInfoNodeException("Atributo inválido para nodo EncapsulatedPKIDataType en esquema XAdES: " + this.schema.getSchemaUri());
/* 127 */       this.encoding = EncodingEnum.getEncoding(element.getAttribute("Encoding"));
/* 128 */       if (this.encoding == null) {
/* 129 */         throw new InvalidInfoNodeException("Encoding de nodo EncapsulatedPKIDataType desconocido: " + element.getAttribute("Encoding"));
/*     */       }
/*     */     }
/*     */     
/* 133 */     Node node = element.getFirstChild();
/* 134 */     if (node.getNodeType() != 3) {
/* 135 */       throw new InvalidInfoNodeException("Nodo EncapsulatedPKIDataType no contiene CDATA como primer valor");
/*     */     }
/* 137 */     this.value = node.getNodeValue();
/* 138 */     if (this.value == null) {
/* 139 */       throw new InvalidInfoNodeException("Contenido de valor de EncapsulatedPKIDataType vacío");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addContent(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 149 */     if (this.value == null)
/* 150 */       throw new InvalidInfoNodeException("Información insuficiente para escribir nodo EncapsulatedPKIDataType");
/* 151 */     if (this.id != null)
/* 152 */       element.setAttributeNS(null, "Id", this.id);
/* 153 */     EncodingEnum encoding = getEncoding();
/* 154 */     if ((!this.schema.equals(XAdESSchemas.XAdES_111)) && (encoding != null)) {
/* 155 */       element.setAttributeNS(null, "Encoding", encoding.getEncodingUri().toString());
/*     */     }
/* 157 */     element.setTextContent(this.value);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\EncapsulatedPKIDataType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */