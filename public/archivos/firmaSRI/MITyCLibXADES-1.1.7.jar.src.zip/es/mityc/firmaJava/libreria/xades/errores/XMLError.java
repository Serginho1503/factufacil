/*    */ package es.mityc.firmaJava.libreria.xades.errores;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMLError
/*    */   extends Exception
/*    */ {
/*    */   public XMLError() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public XMLError(String msg)
/*    */   {
/* 37 */     super(msg);
/*    */   }
/*    */   
/*    */   public XMLError(String message, Throwable cause) {
/* 41 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public XMLError(Throwable cause) {
/* 45 */     super(cause);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\errores\XMLError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */