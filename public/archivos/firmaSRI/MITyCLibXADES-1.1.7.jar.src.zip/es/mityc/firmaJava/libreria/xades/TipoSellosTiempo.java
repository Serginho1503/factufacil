/*    */ package es.mityc.firmaJava.libreria.xades;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum TipoSellosTiempo
/*    */ {
/* 28 */   CLASE_T("Clase T"), 
/* 29 */   CLASE_X_TIPO_1("Clase X Tipo 1"), 
/* 30 */   CLASE_X_TIPO_2("Clase X Tipo 2"), 
/* 31 */   CLASE_A("Clase A");
/*    */   
/*    */   private String name;
/*    */   
/*    */   private TipoSellosTiempo(String name) {
/* 36 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String getTipoSello() {
/* 40 */     return this.name;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\TipoSellosTiempo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */