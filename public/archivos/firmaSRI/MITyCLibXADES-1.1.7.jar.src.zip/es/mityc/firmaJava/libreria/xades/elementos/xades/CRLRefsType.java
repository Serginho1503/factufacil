/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CRLRefsType
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private ArrayList<CRLRef> crlRefs;
/*     */   
/*     */   public CRLRefsType(XAdESSchemas schema)
/*     */   {
/*  42 */     super(schema);
/*     */   }
/*     */   
/*     */   public CRLRefsType(XAdESSchemas schema, ArrayList<CRLRef> crlRefs) {
/*  46 */     super(schema);
/*  47 */     this.crlRefs = crlRefs;
/*     */   }
/*     */   
/*     */   public void addCRLRef(CRLRef crlRef) {
/*  51 */     if (this.crlRefs == null)
/*  52 */       this.crlRefs = new ArrayList();
/*  53 */     this.crlRefs.add(crlRef);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ArrayList<CRLRef> getCRLRefs()
/*     */   {
/*  60 */     return this.crlRefs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setCertificates(ArrayList<CRLRef> crlRefs)
/*     */   {
/*  67 */     this.crlRefs = crlRefs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  75 */     if ((obj instanceof CRLRefsType)) {
/*  76 */       CRLRefsType cvt = (CRLRefsType)obj;
/*  77 */       ArrayList<CRLRef> comp = cvt.crlRefs;
/*  78 */       if (((this.crlRefs == null) || (this.crlRefs.isEmpty())) && (
/*  79 */         (comp == null) || (comp.isEmpty())))
/*  80 */         return true;
/*  81 */       if ((this.crlRefs != null) && (comp != null) && 
/*  82 */         (this.crlRefs.size() == comp.size())) {
/*  83 */         Iterator<CRLRef> itThis = this.crlRefs.iterator();
/*  84 */         Iterator<CRLRef> itComp = comp.iterator();
/*  85 */         while (itThis.hasNext()) {
/*  86 */           if (!((CRLRef)itThis.next()).equals(itComp.next()))
/*  87 */             return false;
/*     */         }
/*  89 */         return true;
/*     */       }
/*     */     }
/*  92 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 100 */     NodeList nodos = element.getChildNodes();
/*     */     
/* 102 */     ArrayList<CRLRef> temp = new ArrayList(nodos.getLength());
/* 103 */     for (int i = 0; i < nodos.getLength(); i++) {
/* 104 */       Node nodo = nodos.item(i);
/* 105 */       if (nodo.getNodeType() != 1) {
/* 106 */         throw new InvalidInfoNodeException("Hijo de CRLRefsType no es un elemento");
/*     */       }
/* 108 */       CRLRef crlRef = new CRLRef(this.schema);
/* 109 */       crlRef.load((Element)nodo);
/* 110 */       temp.add(crlRef);
/*     */     }
/*     */     
/* 113 */     if (temp.size() == 0) {
/* 114 */       throw new InvalidInfoNodeException("CRLRefsType debe tener al menos un hijo");
/*     */     }
/* 116 */     this.crlRefs = temp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void addContent(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 124 */     if ((this.crlRefs == null) || (this.crlRefs.size() == 0))
/* 125 */       throw new InvalidInfoNodeException("CRLRefsType debe tener al menos un hijo");
/* 126 */     Iterator<CRLRef> it = this.crlRefs.iterator();
/* 127 */     while (it.hasNext()) {
/* 128 */       element.appendChild(((CRLRef)it.next()).createElement(element.getOwnerDocument(), this.namespaceXDsig, this.namespaceXAdES));
/*     */     }
/*     */   }
/*     */   
/*     */   public void addContent(Element element, String namespaceXAdES, String namespaceXDsig) throws InvalidInfoNodeException
/*     */   {
/* 134 */     super.addContent(element, namespaceXAdES, namespaceXDsig);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\CRLRefsType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */