/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xmldsig.Transforms;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignaturePolicyIdType
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private SigPolicyId sigPolicyId;
/*     */   private Transforms transforms;
/*     */   private SigPolicyHash sigPolicyHash;
/*     */   private SigPolicyQualifiers sigPolicyQualifiers;
/*     */   
/*     */   public SignaturePolicyIdType(XAdESSchemas schema)
/*     */   {
/*  39 */     super(schema);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addContent(Element element, String namespaceXAdES, String namespaceXDsig)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  47 */     super.addContent(element, namespaceXAdES, namespaceXDsig);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void addContent(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  55 */     if ((this.sigPolicyId == null) || (this.sigPolicyHash == null)) {
/*  56 */       throw new InvalidInfoNodeException("Información insuficiente para escribir nodo SignaturePolicyIdType");
/*     */     }
/*  58 */     element.appendChild(this.sigPolicyId.createElement(element.getOwnerDocument(), this.namespaceXAdES));
/*     */     
/*  60 */     if (this.transforms != null) {
/*  61 */       element.appendChild(this.transforms.createElement(element.getOwnerDocument(), this.namespaceXDsig));
/*     */     }
/*     */     
/*  64 */     element.appendChild(this.sigPolicyHash.createElement(element.getOwnerDocument(), this.namespaceXDsig, this.namespaceXAdES));
/*     */     
/*  66 */     if (this.sigPolicyQualifiers != null) {
/*  67 */       element.appendChild(this.sigPolicyQualifiers.createElement(element.getOwnerDocument(), this.namespaceXAdES));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  77 */     if ((obj instanceof SignaturePolicyIdType)) {
/*  78 */       SignaturePolicyIdType spit = (SignaturePolicyIdType)obj;
/*  79 */       if ((this.sigPolicyId == null) || (spit.sigPolicyId == null) || 
/*  80 */         (this.sigPolicyHash == null) || (spit.sigPolicyHash == null))
/*  81 */         return false;
/*  82 */       if (((this.transforms == null) && (spit.transforms != null)) || (
/*  83 */         (this.transforms != null) && (spit.transforms == null)))
/*  84 */         return false;
/*  85 */       if (((this.sigPolicyQualifiers == null) && (spit.sigPolicyQualifiers != null)) || (
/*  86 */         (this.sigPolicyQualifiers != null) && (spit.sigPolicyQualifiers == null)))
/*  87 */         return false;
/*  88 */       if ((this.transforms != null) && (spit.transforms != null) && 
/*  89 */         (!this.transforms.equals(spit.transforms)))
/*  90 */         return false;
/*  91 */       if (!this.sigPolicyId.equals(spit.sigPolicyId))
/*  92 */         return false;
/*  93 */       if (!this.sigPolicyHash.equals(spit.sigPolicyHash))
/*  94 */         return false;
/*  95 */       if ((this.sigPolicyQualifiers != null) && (spit.sigPolicyQualifiers != null) && 
/*  96 */         (!this.sigPolicyQualifiers.equals(spit.sigPolicyQualifiers)))
/*  97 */         return false;
/*  98 */       return true;
/*     */     }
/* 100 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 109 */     Node node = getFirstNonvoidNode(element);
/*     */     
/* 111 */     SigPolicyId sigPolicyId = new SigPolicyId(this.schema);
/* 112 */     if (!sigPolicyId.isThisNode(node))
/* 113 */       throw new InvalidInfoNodeException("Nodo SignaturePolicyIdType no tiene hijo SigPolicyId");
/* 114 */     sigPolicyId.load((Element)node);
/*     */     
/*     */ 
/* 117 */     node = getNextNonvoidNode(node);
/* 118 */     Transforms transforms = new Transforms();
/* 119 */     if (transforms.isThisNode(node)) {
/* 120 */       transforms.load((Element)node);
/*     */     } else {
/* 122 */       transforms = null;
/*     */     }
/*     */     
/* 125 */     if (node == null)
/* 126 */       throw new InvalidInfoNodeException("Nodo SignaturePolicyIdType no tiene hijo SigPolicyId");
/* 127 */     if (transforms != null)
/* 128 */       node = getNextNonvoidNode(node);
/* 129 */     SigPolicyHash sigPolicyHash = new SigPolicyHash(this.schema);
/* 130 */     if (!sigPolicyHash.isThisNode(node))
/* 131 */       throw new InvalidInfoNodeException("Nodo SignaturePolicyIdType no tiene hijo SigPolicyHash");
/* 132 */     sigPolicyHash.load((Element)node);
/* 133 */     node = getNextNonvoidNode(node);
/*     */     
/*     */ 
/* 136 */     SigPolicyQualifiers sigPolicyQualifiers = null;
/* 137 */     if (node != null) {
/* 138 */       sigPolicyQualifiers = new SigPolicyQualifiers(this.schema);
/* 139 */       if (!sigPolicyQualifiers.isThisNode(node))
/* 140 */         throw new InvalidInfoNodeException("Nodo SigPolicyQualifiers esperado como hijo de SignaturePolicyIdType");
/* 141 */       sigPolicyQualifiers.load((Element)node);
/*     */     }
/*     */     
/* 144 */     this.sigPolicyId = sigPolicyId;
/* 145 */     this.transforms = transforms;
/* 146 */     this.sigPolicyHash = sigPolicyHash;
/* 147 */     this.sigPolicyQualifiers = sigPolicyQualifiers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public SigPolicyId getSigPolicyId()
/*     */   {
/* 154 */     return this.sigPolicyId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setSigPolicyId(SigPolicyId sigPolicyId)
/*     */   {
/* 161 */     this.sigPolicyId = sigPolicyId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Transforms getTransforms()
/*     */   {
/* 168 */     return this.transforms;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTransforms(Transforms transforms)
/*     */   {
/* 175 */     this.transforms = transforms;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public SigPolicyHash getSigPolicyHash()
/*     */   {
/* 182 */     return this.sigPolicyHash;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setSigPolicyHash(SigPolicyHash sigPolicyHash)
/*     */   {
/* 189 */     this.sigPolicyHash = sigPolicyHash;
/*     */   }
/*     */   
/*     */   public SigPolicyQualifiers getSigPolicyQualifiers() {
/* 193 */     return this.sigPolicyQualifiers;
/*     */   }
/*     */   
/*     */   public void setSigPolicyQualifiers(SigPolicyQualifiers sigPolicyQualifiers) {
/* 197 */     this.sigPolicyQualifiers = sigPolicyQualifiers;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\SignaturePolicyIdType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */