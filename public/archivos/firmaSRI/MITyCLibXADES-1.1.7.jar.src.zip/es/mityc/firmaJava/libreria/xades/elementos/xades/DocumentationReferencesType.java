/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DocumentationReferencesType
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private ArrayList<DocumentationReference> references;
/*     */   
/*     */   public DocumentationReferencesType(XAdESSchemas schema)
/*     */   {
/*  40 */     super(schema);
/*     */   }
/*     */   
/*     */   public DocumentationReferencesType(XAdESSchemas schema, ArrayList<DocumentationReference> list) {
/*  44 */     super(schema);
/*  45 */     this.references = list;
/*     */   }
/*     */   
/*     */ 
/*     */   public ArrayList<DocumentationReference> getList()
/*     */   {
/*  51 */     return this.references;
/*     */   }
/*     */   
/*     */   public void setList(ArrayList<DocumentationReference> list) {
/*  55 */     this.references = list;
/*     */   }
/*     */   
/*     */   public void addReference(DocumentationReference qualifier) {
/*  59 */     if (this.references == null)
/*  60 */       this.references = new ArrayList();
/*  61 */     this.references.add(qualifier);
/*     */   }
/*     */   
/*     */   public void addReference(URI uri) {
/*  65 */     if (this.references == null)
/*  66 */       this.references = new ArrayList();
/*  67 */     this.references.add(new DocumentationReference(this.schema, uri));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  75 */     if ((obj instanceof DocumentationReferencesType)) {
/*  76 */       DocumentationReferencesType cvt = (DocumentationReferencesType)obj;
/*  77 */       ArrayList<DocumentationReference> comp = cvt.references;
/*  78 */       if (((this.references == null) || (this.references.isEmpty())) && (
/*  79 */         (comp == null) || (comp.isEmpty())))
/*  80 */         return true;
/*  81 */       if ((this.references != null) && (comp != null) && 
/*  82 */         (this.references.size() == comp.size())) {
/*  83 */         Iterator<DocumentationReference> itThis = this.references.iterator();
/*  84 */         Iterator<DocumentationReference> itComp = comp.iterator();
/*  85 */         while (itThis.hasNext()) {
/*  86 */           if (!((DocumentationReference)itThis.next()).equals(itComp.next()))
/*  87 */             return false;
/*     */         }
/*  89 */         return true;
/*     */       }
/*     */     }
/*  92 */     return false;
/*     */   }
/*     */   
/*     */   protected void addContent(Element element) throws InvalidInfoNodeException
/*     */   {
/*  97 */     if ((this.references != null) && (this.references.size() > 0)) {
/*  98 */       Iterator<DocumentationReference> it = this.references.iterator();
/*  99 */       while (it.hasNext()) {
/* 100 */         element.appendChild(((DocumentationReference)it.next()).createElement(element.getOwnerDocument(), this.namespaceXAdES));
/*     */       }
/*     */     }
/*     */     else {
/* 104 */       throw new InvalidInfoNodeException("Nodo DocumentationReferencesType no tiene ningún hijo");
/*     */     }
/*     */   }
/*     */   
/*     */   public void addContent(Element element, String namespaceXAdES) throws InvalidInfoNodeException {
/* 109 */     super.addContent(element, namespaceXAdES);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 118 */     NodeList nodos = element.getChildNodes();
/* 119 */     ArrayList<DocumentationReference> temp = new ArrayList(nodos.getLength());
/* 120 */     for (int i = 0; i < nodos.getLength(); i++) {
/* 121 */       Node nodo = nodos.item(i);
/* 122 */       if (!isDecorationNode(nodo))
/*     */       {
/*     */ 
/* 125 */         if (nodo.getNodeType() != 1) {
/* 126 */           throw new InvalidInfoNodeException("Hijo de DocumentationReferencesType no es un elemento");
/*     */         }
/* 128 */         DocumentationReference reference = new DocumentationReference(this.schema);
/* 129 */         reference.load((Element)nodo);
/* 130 */         temp.add(reference);
/*     */       }
/*     */     }
/* 133 */     if (temp.size() == 0) {
/* 134 */       throw new InvalidInfoNodeException("DocumentationReferencesType debe tener al menos un hijo");
/*     */     }
/* 136 */     this.references = temp;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\DocumentationReferencesType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */