/*    */ package es.mityc.firmaJava.libreria.xades.errores;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidInfoNodeException
/*    */   extends XMLError
/*    */ {
/*    */   public InvalidInfoNodeException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InvalidInfoNodeException(String message, Throwable cause)
/*    */   {
/* 37 */     super(message, cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public InvalidInfoNodeException(String msg)
/*    */   {
/* 44 */     super(msg);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public InvalidInfoNodeException(Throwable cause)
/*    */   {
/* 51 */     super(cause);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\errores\InvalidInfoNodeException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */