/*    */ package es.mityc.firmaJava.libreria.xades;
/*    */ 
/*    */ import es.mityc.firmaJava.trust.ConfianzaEnum;
/*    */ import java.security.cert.X509CRL;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DatosCRL
/*    */ {
/* 29 */   private String issuer = null;
/* 30 */   private Date fechaEmision = null;
/* 31 */   private Date fechaCaducidad = null;
/* 32 */   private X509CRL x509CRL = null;
/* 33 */   private ConfianzaEnum esCertConfianza = ConfianzaEnum.NO_REVISADO;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public DatosCRL() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public DatosCRL(String issuer, Date fechaEmision, Date fechaCaducidad, X509CRL x509CRL, ConfianzaEnum esCertConfianza)
/*    */   {
/* 52 */     this.issuer = issuer;
/* 53 */     this.fechaEmision = fechaEmision;
/* 54 */     this.fechaCaducidad = fechaCaducidad;
/* 55 */     this.x509CRL = x509CRL;
/* 56 */     this.esCertConfianza = esCertConfianza;
/*    */   }
/*    */   
/*    */   public String getIssuer() {
/* 60 */     return this.issuer;
/*    */   }
/*    */   
/* 63 */   public void setIssuer(String issuer) { this.issuer = issuer; }
/*    */   
/*    */   public Date getFechaEmision() {
/* 66 */     return this.fechaEmision;
/*    */   }
/*    */   
/* 69 */   public void setFechaEmision(Date fechaEmision) { this.fechaEmision = fechaEmision; }
/*    */   
/*    */   public Date getFechaCaducidad() {
/* 72 */     return this.fechaCaducidad;
/*    */   }
/*    */   
/* 75 */   public void setFechaCaducidad(Date fechaCaducidad) { this.fechaCaducidad = fechaCaducidad; }
/*    */   
/*    */   public X509CRL getX509CRL() {
/* 78 */     return this.x509CRL;
/*    */   }
/*    */   
/* 81 */   public void setX509CRL(X509CRL x509crl) { this.x509CRL = x509crl; }
/*    */   
/*    */   public ConfianzaEnum esCertConfianza() {
/* 84 */     return this.esCertConfianza;
/*    */   }
/*    */   
/* 87 */   public void setEsCertConfianza(ConfianzaEnum esCertConfianza) { this.esCertConfianza = esCertConfianza; }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\DatosCRL.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */