/*    */ package es.mityc.firmaJava.libreria.errores;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PKCS12Error
/*    */   extends Exception
/*    */ {
/* 28 */   static Log log = LogFactory.getLog(PKCS12Error.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public PKCS12Error(String causa)
/*    */   {
/* 35 */     super(causa);
/* 36 */     log.error(causa);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PKCS12Error(Exception e)
/*    */   {
/* 46 */     log.error(e.getMessage());
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 51 */     return super.toString();
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\errores\PKCS12Error.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */