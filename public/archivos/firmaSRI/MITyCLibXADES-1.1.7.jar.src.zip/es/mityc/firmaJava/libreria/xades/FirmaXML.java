/*      */ package es.mityc.firmaJava.libreria.xades;
/*      */ 
/*      */ import adsi.org.apache.xml.security.Init;
/*      */ import adsi.org.apache.xml.security.algorithms.JCEMapper;
/*      */ import adsi.org.apache.xml.security.keys.KeyInfo;
/*      */ import adsi.org.apache.xml.security.signature.ObjectContainer;
/*      */ import adsi.org.apache.xml.security.signature.SignedInfo;
/*      */ import adsi.org.apache.xml.security.signature.XMLSignature;
/*      */ import adsi.org.apache.xml.security.transforms.Transforms;
/*      */ import adsi.org.apache.xml.security.utils.IgnoreAllErrorHandler;
/*      */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolverSpi;
/*      */ import es.mityc.firmaJava.libreria.errores.ClienteChainNotFoundError;
/*      */ import es.mityc.firmaJava.libreria.errores.ClienteError;
/*      */ import es.mityc.firmaJava.libreria.excepciones.AddXadesException;
/*      */ import es.mityc.firmaJava.libreria.utilidades.Base64;
/*      */ import es.mityc.firmaJava.libreria.utilidades.Base64Coder;
/*      */ import es.mityc.firmaJava.libreria.utilidades.I18n;
/*      */ import es.mityc.firmaJava.libreria.utilidades.NombreNodo;
/*      */ import es.mityc.firmaJava.libreria.utilidades.UtilidadCertificados;
/*      */ import es.mityc.firmaJava.libreria.utilidades.UtilidadFechas;
/*      */ import es.mityc.firmaJava.libreria.utilidades.UtilidadFicheros;
/*      */ import es.mityc.firmaJava.libreria.utilidades.UtilidadFirmaElectronica;
/*      */ import es.mityc.firmaJava.libreria.utilidades.UtilidadTratarNodo;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.CRLIdentifier;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.CRLRef;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.CRLRefs;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.CRLValues;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.CertificateValues;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.DataObjectFormat;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.EncapsulatedX509Certificate;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.ObjectIdentifier;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SignatureProductionPlace;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SigningTime;
/*      */ import es.mityc.firmaJava.libreria.xades.errores.BadFormedSignatureException;
/*      */ import es.mityc.firmaJava.libreria.xades.errores.FirmaXMLError;
/*      */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*      */ import es.mityc.firmaJava.libreria.xades.errores.PolicyException;
/*      */ import es.mityc.firmaJava.role.IClaimedRole;
/*      */ import es.mityc.javasign.EnumFormatoFirma;
/*      */ import es.mityc.javasign.asn1.ASN1Utils;
/*      */ import es.mityc.javasign.certificate.CertStatusException;
/*      */ import es.mityc.javasign.certificate.ICertStatus;
/*      */ import es.mityc.javasign.certificate.ICertStatus.CERT_STATUS;
/*      */ import es.mityc.javasign.certificate.ICertStatusRecoverer;
/*      */ import es.mityc.javasign.certificate.IOCSPCertStatus;
/*      */ import es.mityc.javasign.certificate.IOCSPCertStatus.TYPE_RESPONDER;
/*      */ import es.mityc.javasign.certificate.IX509CRLCertStatus;
/*      */ import es.mityc.javasign.certificate.OCSPResponderID;
/*      */ import es.mityc.javasign.exception.SignMITyCException;
/*      */ import es.mityc.javasign.i18n.I18nFactory;
/*      */ import es.mityc.javasign.i18n.II18nManager;
/*      */ import es.mityc.javasign.pkstore.IPKStoreManager;
/*      */ import es.mityc.javasign.tsa.ITimeStampGenerator;
/*      */ import es.mityc.javasign.tsa.TimeStampException;
/*      */ import es.mityc.javasign.utils.Utils;
/*      */ import es.mityc.javasign.xml.refs.AbstractObjectToSign;
/*      */ import es.mityc.javasign.xml.refs.InternObjectToSign;
/*      */ import es.mityc.javasign.xml.refs.ObjectToSign;
/*      */ import es.mityc.javasign.xml.refs.SignObjectToSign;
/*      */ import es.mityc.javasign.xml.resolvers.IPrivateData;
/*      */ import es.mityc.javasign.xml.resolvers.IResourceData;
/*      */ import es.mityc.javasign.xml.resolvers.MITyCResourceResolver;
/*      */ import es.mityc.javasign.xml.resolvers.ResolverPrivateData;
/*      */ import es.mityc.javasign.xml.resolvers.XAdESResourceResolverSpi;
/*      */ import es.mityc.javasign.xml.transform.Transform;
/*      */ import es.mityc.javasign.xml.transform.TransformEnveloped;
/*      */ import es.mityc.javasign.xml.xades.IStoreElements;
/*      */ import es.mityc.javasign.xml.xades.policy.IFirmaPolicy;
/*      */ import es.mityc.javasign.xml.xades.policy.PoliciesManager;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.math.BigInteger;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.net.URLEncoder;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.charset.Charset;
/*      */ import java.security.MessageDigest;
/*      */ import java.security.NoSuchProviderException;
/*      */ import java.security.Principal;
/*      */ import java.security.PrivateKey;
/*      */ import java.security.Provider;
/*      */ import java.security.Security;
/*      */ import java.security.cert.CertPath;
/*      */ import java.security.cert.CertStore;
/*      */ import java.security.cert.Certificate;
/*      */ import java.security.cert.CertificateEncodingException;
/*      */ import java.security.cert.CertificateException;
/*      */ import java.security.cert.CertificateFactory;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.SortedMap;
/*      */ import javax.security.auth.x500.X500Principal;
/*      */ import javax.xml.parsers.DocumentBuilder;
/*      */ import javax.xml.parsers.DocumentBuilderFactory;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.bouncycastle.asn1.ocsp.ResponderID;
/*      */ import org.bouncycastle.cms.CMSException;
/*      */ import org.bouncycastle.cms.CMSSignedData;
/*      */ import org.bouncycastle.ocsp.BasicOCSPResp;
/*      */ import org.bouncycastle.ocsp.OCSPException;
/*      */ import org.bouncycastle.ocsp.OCSPResp;
/*      */ import org.bouncycastle.ocsp.RespID;
/*      */ import org.bouncycastle.tsp.TimeStampResponse;
/*      */ import org.bouncycastle.tsp.TimeStampToken;
/*      */ import org.w3c.dom.Attr;
/*      */ import org.w3c.dom.DOMException;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.NamedNodeMap;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ import org.xml.sax.InputSource;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FirmaXML
/*      */ {
/*  162 */   private static Log log = LogFactory.getLog(FirmaXML.class);
/*  163 */   private static II18nManager i18n = I18nFactory.getI18nManager("MITyCLibXAdES");
/*      */   
/*      */ 
/*      */ 
/*      */   private static final boolean ADD_VALIDATION_OCSP = true;
/*      */   
/*      */ 
/*  170 */   String profileDirectory = "";
/*  171 */   private String xadesNS = "etsi";
/*  172 */   private String xadesSchema = null;
/*  173 */   private String xmldsigNS = "ds";
/*      */   
/*      */ 
/*  176 */   private ArrayList<String> idNodoSelloTiempo = new ArrayList();
/*  177 */   private String idNodoCertificateRefs = null;
/*  178 */   private String idNodoRevocationRefs = null;
/*  179 */   private String idSigProperties = null;
/*  180 */   private String idSignatureValue = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList<ResourceResolverSpi> resolvers;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDefaultNSXmlSig(String namespace)
/*      */   {
/*  195 */     this.xmldsigNS = namespace;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLocale(String locale)
/*      */   {
/*  203 */     I18n.setLocale(locale, locale.toUpperCase());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addResolver(IPrivateData resolver)
/*      */   {
/*  213 */     addResolver(new ResolverPrivateData(resolver));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addResolver(MITyCResourceResolver resolver)
/*      */   {
/*  222 */     if (this.resolvers == null) {
/*  223 */       this.resolvers = new ArrayList();
/*      */     }
/*  225 */     this.resolvers.add(resolver);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addResolver(IResourceData resolver)
/*      */   {
/*  234 */     addResolver(new XAdESResourceResolverSpi(resolver));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String sign2Stream(X509Certificate firmaCertificado, DataToSign xml, IPKStoreManager storeManager, OutputStream salida)
/*      */     throws Exception
/*      */   {
/*  252 */     PrivateKey pk = storeManager.getPrivateKey(firmaCertificado);
/*  253 */     return signFile(firmaCertificado, xml, pk, salida, storeManager.getProvider(firmaCertificado));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean signFile(X509Certificate firmaCertificado, DataToSign xml, IPKStoreManager storeManager, String destino, String nombreArchivo)
/*      */     throws Exception
/*      */   {
/*  271 */     PrivateKey pk = storeManager.getPrivateKey(firmaCertificado);
/*  272 */     return signFile(firmaCertificado, xml, pk, destino, nombreArchivo, storeManager.getProvider(firmaCertificado));
/*      */   }
/*      */   
/*      */   private String signFile(X509Certificate certificadoFirma, DataToSign xml, PrivateKey pk, OutputStream salida, Provider provider)
/*      */     throws Exception
/*      */   {
/*  278 */     Object[] res = signFile(certificadoFirma, xml, pk, provider);
/*      */     
/*  280 */     if (res[1] != null) {
/*  281 */       throw new ClienteError(I18n.getResource("libreriaxades.firmaxml.error43"));
/*      */     }
/*      */     try
/*      */     {
/*  285 */       UtilidadFicheros.writeXML((Document)res[0], salida);
/*  286 */       return (String)res[2];
/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/*  290 */       if ((t.getMessage() != null) && (t.getMessage().startsWith("Java heap space"))) {
/*  291 */         throw new Exception(I18n.getResource("libreriaxades.firmaxml.error3"));
/*      */       }
/*  293 */       throw new Exception(I18n.getResource("libreriaxades.firmaxml.error4"));
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   private boolean signFile(X509Certificate certificadoFirma, DataToSign xml, PrivateKey pk, String destino, String nombreArchivo, Provider provider)
/*      */     throws Exception
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload 4
/*      */     //   2: ifnull +8 -> 10
/*      */     //   5: aload 5
/*      */     //   7: ifnonnull +16 -> 23
/*      */     //   10: new 129	java/lang/Exception
/*      */     //   13: dup
/*      */     //   14: ldc -50
/*      */     //   16: invokestatic 168	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   19: invokespecial 195	java/lang/Exception:<init>	(Ljava/lang/String;)V
/*      */     //   22: athrow
/*      */     //   23: aload_0
/*      */     //   24: aload_1
/*      */     //   25: aload_2
/*      */     //   26: aload_3
/*      */     //   27: aload 6
/*      */     //   29: invokevirtual 161	es/mityc/firmaJava/libreria/xades/FirmaXML:signFile	(Ljava/security/cert/X509Certificate;Les/mityc/firmaJava/libreria/xades/DataToSign;Ljava/security/PrivateKey;Ljava/security/Provider;)[Ljava/lang/Object;
/*      */     //   32: astore 7
/*      */     //   34: aload 7
/*      */     //   36: iconst_0
/*      */     //   37: aaload
/*      */     //   38: checkcast 174	org/w3c/dom/Document
/*      */     //   41: astore 8
/*      */     //   43: new 208	java/io/File
/*      */     //   46: dup
/*      */     //   47: aload 4
/*      */     //   49: aload 5
/*      */     //   51: invokespecial 210	java/io/File:<init>	(Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   54: astore 9
/*      */     //   56: new 212	java/io/FileOutputStream
/*      */     //   59: dup
/*      */     //   60: aload 9
/*      */     //   62: invokespecial 214	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
/*      */     //   65: astore 10
/*      */     //   67: new 217	java/io/OutputStreamWriter
/*      */     //   70: dup
/*      */     //   71: aload 10
/*      */     //   73: ldc -37
/*      */     //   75: invokespecial 221	java/io/OutputStreamWriter:<init>	(Ljava/io/OutputStream;Ljava/lang/String;)V
/*      */     //   78: astore 11
/*      */     //   80: invokestatic 224	javax/xml/transform/TransformerFactory:newInstance	()Ljavax/xml/transform/TransformerFactory;
/*      */     //   83: invokevirtual 230	javax/xml/transform/TransformerFactory:newTransformer	()Ljavax/xml/transform/Transformer;
/*      */     //   86: astore 12
/*      */     //   88: new 234	java/util/Properties
/*      */     //   91: dup
/*      */     //   92: invokespecial 236	java/util/Properties:<init>	()V
/*      */     //   95: astore 13
/*      */     //   97: aload 13
/*      */     //   99: ldc -19
/*      */     //   101: ldc -17
/*      */     //   103: invokevirtual 241	java/util/Properties:setProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;
/*      */     //   106: pop
/*      */     //   107: aload 13
/*      */     //   109: ldc -11
/*      */     //   111: ldc -37
/*      */     //   113: invokevirtual 241	java/util/Properties:setProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;
/*      */     //   116: pop
/*      */     //   117: aload 13
/*      */     //   119: ldc -9
/*      */     //   121: ldc -7
/*      */     //   123: invokevirtual 241	java/util/Properties:setProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;
/*      */     //   126: pop
/*      */     //   127: aload 12
/*      */     //   129: aload 13
/*      */     //   131: invokevirtual 251	javax/xml/transform/Transformer:setOutputProperties	(Ljava/util/Properties;)V
/*      */     //   134: new 257	java/io/StringWriter
/*      */     //   137: dup
/*      */     //   138: invokespecial 259	java/io/StringWriter:<init>	()V
/*      */     //   141: astore 14
/*      */     //   143: aload 12
/*      */     //   145: new 260	javax/xml/transform/dom/DOMSource
/*      */     //   148: dup
/*      */     //   149: aload 8
/*      */     //   151: invokespecial 262	javax/xml/transform/dom/DOMSource:<init>	(Lorg/w3c/dom/Node;)V
/*      */     //   154: new 265	javax/xml/transform/stream/StreamResult
/*      */     //   157: dup
/*      */     //   158: aload 14
/*      */     //   160: invokespecial 267	javax/xml/transform/stream/StreamResult:<init>	(Ljava/io/Writer;)V
/*      */     //   163: invokevirtual 270	javax/xml/transform/Transformer:transform	(Ljavax/xml/transform/Source;Ljavax/xml/transform/Result;)V
/*      */     //   166: aload 11
/*      */     //   168: aload 14
/*      */     //   170: invokevirtual 274	java/io/StringWriter:toString	()Ljava/lang/String;
/*      */     //   173: invokevirtual 277	java/io/Writer:write	(Ljava/lang/String;)V
/*      */     //   176: aload 11
/*      */     //   178: invokevirtual 282	java/io/Writer:flush	()V
/*      */     //   181: aload 11
/*      */     //   183: invokevirtual 285	java/io/Writer:close	()V
/*      */     //   186: goto +67 -> 253
/*      */     //   189: astore 11
/*      */     //   191: aload 11
/*      */     //   193: invokevirtual 182	java/lang/Throwable:getMessage	()Ljava/lang/String;
/*      */     //   196: ifnull +29 -> 225
/*      */     //   199: aload 11
/*      */     //   201: invokevirtual 182	java/lang/Throwable:getMessage	()Ljava/lang/String;
/*      */     //   204: ldc -69
/*      */     //   206: invokevirtual 189	java/lang/String:startsWith	(Ljava/lang/String;)Z
/*      */     //   209: ifeq +16 -> 225
/*      */     //   212: new 129	java/lang/Exception
/*      */     //   215: dup
/*      */     //   216: ldc -63
/*      */     //   218: invokestatic 168	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   221: invokespecial 195	java/lang/Exception:<init>	(Ljava/lang/String;)V
/*      */     //   224: athrow
/*      */     //   225: new 129	java/lang/Exception
/*      */     //   228: dup
/*      */     //   229: ldc -60
/*      */     //   231: invokestatic 168	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   234: invokespecial 195	java/lang/Exception:<init>	(Ljava/lang/String;)V
/*      */     //   237: athrow
/*      */     //   238: astore 15
/*      */     //   240: aload 10
/*      */     //   242: invokevirtual 288	java/io/FileOutputStream:flush	()V
/*      */     //   245: aload 10
/*      */     //   247: invokevirtual 289	java/io/FileOutputStream:close	()V
/*      */     //   250: aload 15
/*      */     //   252: athrow
/*      */     //   253: aload 10
/*      */     //   255: invokevirtual 288	java/io/FileOutputStream:flush	()V
/*      */     //   258: aload 10
/*      */     //   260: invokevirtual 289	java/io/FileOutputStream:close	()V
/*      */     //   263: iconst_1
/*      */     //   264: ireturn
/*      */     // Line number table:
/*      */     //   Java source line #300	-> byte code offset #0
/*      */     //   Java source line #302	-> byte code offset #10
/*      */     //   Java source line #305	-> byte code offset #23
/*      */     //   Java source line #309	-> byte code offset #34
/*      */     //   Java source line #312	-> byte code offset #43
/*      */     //   Java source line #313	-> byte code offset #56
/*      */     //   Java source line #317	-> byte code offset #67
/*      */     //   Java source line #319	-> byte code offset #80
/*      */     //   Java source line #320	-> byte code offset #88
/*      */     //   Java source line #321	-> byte code offset #97
/*      */     //   Java source line #322	-> byte code offset #107
/*      */     //   Java source line #323	-> byte code offset #117
/*      */     //   Java source line #324	-> byte code offset #127
/*      */     //   Java source line #326	-> byte code offset #134
/*      */     //   Java source line #327	-> byte code offset #143
/*      */     //   Java source line #328	-> byte code offset #166
/*      */     //   Java source line #329	-> byte code offset #176
/*      */     //   Java source line #330	-> byte code offset #181
/*      */     //   Java source line #331	-> byte code offset #186
/*      */     //   Java source line #332	-> byte code offset #189
/*      */     //   Java source line #333	-> byte code offset #191
/*      */     //   Java source line #334	-> byte code offset #212
/*      */     //   Java source line #336	-> byte code offset #225
/*      */     //   Java source line #337	-> byte code offset #238
/*      */     //   Java source line #338	-> byte code offset #240
/*      */     //   Java source line #339	-> byte code offset #245
/*      */     //   Java source line #340	-> byte code offset #250
/*      */     //   Java source line #338	-> byte code offset #253
/*      */     //   Java source line #339	-> byte code offset #258
/*      */     //   Java source line #342	-> byte code offset #263
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	265	0	this	FirmaXML
/*      */     //   0	265	1	certificadoFirma	X509Certificate
/*      */     //   0	265	2	xml	DataToSign
/*      */     //   0	265	3	pk	PrivateKey
/*      */     //   0	265	4	destino	String
/*      */     //   0	265	5	nombreArchivo	String
/*      */     //   0	265	6	provider	Provider
/*      */     //   32	3	7	res	Object[]
/*      */     //   41	109	8	doc	Document
/*      */     //   54	7	9	fichero	File
/*      */     //   65	194	10	f	FileOutputStream
/*      */     //   78	104	11	out	java.io.Writer
/*      */     //   189	11	11	t	Throwable
/*      */     //   86	58	12	xformer	javax.xml.transform.Transformer
/*      */     //   95	35	13	props	java.util.Properties
/*      */     //   141	28	14	salida	java.io.StringWriter
/*      */     //   238	13	15	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   67	186	189	java/lang/Throwable
/*      */     //   67	238	238	finally
/*      */   }
/*      */   
/*      */   public Object[] signFile(X509Certificate certificadoFirma, DataToSign dataToSign, PrivateKey pk, Provider provider)
/*      */     throws Exception
/*      */   {
/*  348 */     ArrayList<RespYCerts> respuestas = new ArrayList();
/*  349 */     ArrayList<X509Certificate> certificadosConOCSP = new ArrayList();
/*      */     
/*  351 */     Init.init();
/*      */     
/*  353 */     Document doc = dataToSign.getDocument();
/*  354 */     if (doc == null) {
/*  355 */       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/*      */       
/*  357 */       dbf.setNamespaceAware(true);
/*  358 */       DocumentBuilder db = dbf.newDocumentBuilder();
/*  359 */       db.setErrorHandler(new IgnoreAllErrorHandler());
/*      */       try {
/*  361 */         InputStream is = dataToSign.getInputStream();
/*  362 */         if (is != null) {
/*  363 */           InputSource isour = new InputSource(is);
/*  364 */           String encoding = dataToSign.getXMLEncoding();
/*  365 */           isour.setEncoding(encoding);
/*  366 */           doc = db.parse(isour);
/*      */         } else {
/*  368 */           doc = db.newDocument();
/*      */         }
/*      */       } catch (IOException ex) {
/*  371 */         throw new Exception(I18n.getResource("libreriaxades.firmaxml.error50"), ex);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  376 */     XAdESSchemas esquemaTemp = dataToSign.getEsquema();
/*  377 */     if (esquemaTemp != null) {
/*  378 */       this.xadesSchema = esquemaTemp.getSchemaUri();
/*      */     } else {
/*  380 */       this.xadesSchema = XAdESSchemas.XAdES_132.getSchemaUri();
/*      */     }
/*      */     
/*  383 */     String algDigestXML = dataToSign.getAlgDigestXmlDSig() != null ? dataToSign.getAlgDigestXmlDSig() : "http://www.w3.org/2000/09/xmldsig#sha1";
/*      */     
/*  385 */     if (JCEMapper.translateURItoJCEID(algDigestXML) == null) {
/*  386 */       throw new SignMITyCException(i18n.getLocalMessage("i18n.mityc.xades.sign.1", new Object[] { algDigestXML }));
/*      */     }
/*      */     
/*  389 */     XMLSignature.setDefaultPrefix("http://www.w3.org/2000/09/xmldsig#", this.xmldsigNS);
/*  390 */     XMLSignature firma = new XMLSignature(doc, 
/*  391 */       dataToSign.getBaseURI(), 
/*  392 */       "http://www.w3.org/2000/09/xmldsig#rsa-sha1");
/*  393 */     firma.setId(UtilidadTratarNodo.newID(doc, "Signature"));
/*  394 */     firma.getSignedInfo().setId(UtilidadTratarNodo.newID(doc, "Signature-SignedInfo"));
/*  395 */     if (this.resolvers != null) {
/*  396 */       Iterator<ResourceResolverSpi> it = this.resolvers.iterator();
/*  397 */       while (it.hasNext()) {
/*  398 */         firma.addResourceResolver((ResourceResolverSpi)it.next());
/*      */       }
/*      */     }
/*      */     
/*  402 */     firma.setXPathNamespaceContext(this.xmldsigNS, "http://www.w3.org/2000/09/xmldsig#");
/*  403 */     EnumFormatoFirma tipoFirma = dataToSign.getXadesFormat();
/*  404 */     boolean xadesActivo = tipoFirma.compareTo(EnumFormatoFirma.XAdES_BES) >= 0;
/*      */     
/*  406 */     if (xadesActivo) {
/*  407 */       firma.setXPathNamespaceContext(this.xadesNS, this.xadesSchema);
/*      */     }
/*      */     
/*  410 */     Element elementoPrincipal = null;
/*      */     
/*  412 */     if (!dataToSign.isEnveloped()) {
/*  413 */       doc.appendChild(firma.getElement());
/*      */     } else {
/*  415 */       String nodoRaizXml = dataToSign.getParentSignNode();
/*  416 */       if (nodoRaizXml == null) {
/*  417 */         elementoPrincipal = doc.getDocumentElement();
/*      */       } else {
/*  419 */         NodeList nodos = doc.getElementsByTagName(nodoRaizXml);
/*  420 */         if (nodos.getLength() != 0) {
/*  421 */           elementoPrincipal = (Element)nodos.item(0);
/*      */         } else {
/*  423 */           Node nodo = UtilidadTratarNodo.getElementById(doc, nodoRaizXml);
/*  424 */           if (nodo != null) {
/*  425 */             elementoPrincipal = (Element)nodo;
/*      */           } else
/*  427 */             throw new Exception(I18n.getResource("libreriaxades.firmaxml.error2"));
/*      */         }
/*      */       }
/*  430 */       elementoPrincipal.appendChild(firma.getElement());
/*      */     }
/*      */     
/*  433 */     this.idSigProperties = UtilidadTratarNodo.newID(doc, "-SignedProperties");
/*  434 */     if (xadesActivo)
/*      */     {
/*  436 */       String tipoEsquema = UtilidadFirmaElectronica.obtenerTipoReference(this.xadesSchema);
/*      */       
/*  438 */       firma.addDocument("#" + firma.getId() + 
/*  439 */         this.idSigProperties, null, algDigestXML, 
/*  440 */         UtilidadTratarNodo.newID(doc, "SignedPropertiesID"), tipoEsquema);
/*      */     }
/*      */     
/*  443 */     firma.addKeyInfo(certificadoFirma);
/*  444 */     firma.addKeyInfo(certificadoFirma.getPublicKey());
/*  445 */     String idCert = UtilidadTratarNodo.newID(doc, "Certificate1");
/*  446 */     firma.getKeyInfo().setId(idCert);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  453 */     firma.addDocument("#" + idCert, null, algDigestXML, null, null);
/*      */     
/*      */ 
/*  456 */     ArrayList<ObjectToSign> objects = dataToSign.getObjects();
/*  457 */     if (objects != null) {
/*  458 */       Iterator<ObjectToSign> it = objects.iterator();
/*  459 */       while (it.hasNext()) {
/*  460 */         ObjectToSign obj = (ObjectToSign)it.next();
/*  461 */         objToSign = obj.getObjectToSign();
/*      */         
/*  463 */         String refId = UtilidadTratarNodo.newID(doc, "Reference-ID-");
/*  464 */         List<ObjectContainer> containers = objToSign.getObjects(doc);
/*  465 */         if (containers != null) {
/*  466 */           for (ObjectContainer objectContainer : containers) {
/*  467 */             firma.appendObject(objectContainer);
/*      */           }
/*      */         }
/*      */         
/*  471 */         String objId = objToSign.getReferenceURI();
/*      */         
/*  473 */         Transforms trans = null;
/*  474 */         List<Transform> list = objToSign.getTransforms();
/*      */         
/*  476 */         if ((dataToSign.isEnveloped()) && 
/*  477 */           (objId != null)) {
/*  478 */           Element aFirmar = UtilidadTratarNodo.getElementById(doc, objId);
/*  479 */           if (UtilidadTratarNodo.isChildNode(firma.getElement(), aFirmar)) {
/*  480 */             list.add(new TransformEnveloped());
/*      */           }
/*      */         }
/*      */         
/*  484 */         if (list.size() > 0) {
/*  485 */           trans = new Transforms(doc);
/*  486 */           for (Transform transform : list) {
/*  487 */             trans.addTransform(transform.getAlgorithm(), transform.getExtraData(doc));
/*      */           }
/*      */         }
/*      */         
/*  491 */         MITyCResourceResolver resolver = objToSign.getResolver();
/*  492 */         if (resolver != null) {
/*  493 */           firma.addResourceResolver(resolver);
/*      */         }
/*      */         
/*  496 */         String typeInfo = objToSign.getType();
/*  497 */         firma.addDocument(objId, trans, algDigestXML, refId, typeInfo);
/*      */         
/*  499 */         obj.setId("#" + refId);
/*      */       }
/*      */     }
/*      */     
/*  503 */     XAdESSchemas schema = null;
/*  504 */     if (xadesActivo)
/*      */     {
/*  506 */       schema = XAdESSchemas.getXAdESSchema(this.xadesSchema);
/*  507 */       if (schema == null) {
/*  508 */         log.error(I18n.getResource("libreriaxades.firmaxml.error44") + 
/*  509 */           " " + this.xadesSchema);
/*  510 */         throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error45"));
/*      */       }
/*  512 */       addXades(doc, 
/*  513 */         firma.getId(), 
/*  514 */         certificadoFirma, 
/*  515 */         firma.getElement(), 
/*  516 */         schema, 
/*  517 */         dataToSign, 
/*  518 */         algDigestXML);
/*  519 */       if (dataToSign.hasPolicy()) {
/*  520 */         addXadesEPES(firma.getElement(), dataToSign.getPolicyKey());
/*  521 */       } else if (XAdESSchemas.XAdES_111.equals(schema))
/*      */       {
/*  523 */         addXadesEPES(firma.getElement(), "implied");
/*      */       }
/*      */     }
/*      */     try
/*      */     {
/*  528 */       if ((provider != null) && (Security.getProvider(provider.getName()) == null))
/*      */       {
/*  530 */         JCEMapper.setProviderSignatureThread(provider);
/*      */       }
/*  532 */       firma.sign(pk);
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*  536 */       log.error(I18n.getResource("libreriaxades.firmaxml.error4"), ex);
/*  537 */       throw ex;
/*      */     }
/*      */     finally
/*      */     {
/*  541 */       JCEMapper.removeProviderSignatureThread();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  547 */     Element elementoValorFirma = null;
/*      */     
/*  549 */     NodeList nodoValorFirma = firma.getElement().getElementsByTagNameNS("http://www.w3.org/2000/09/xmldsig#", "SignatureValue");
/*  550 */     if (nodoValorFirma.getLength() != 0) {
/*  551 */       elementoValorFirma = (Element)nodoValorFirma.item(0);
/*      */     } else {
/*  553 */       throw new Exception(I18n.getResource("libreriaxades.firmaxml.error5"));
/*      */     }
/*  555 */     Attr idValorFirma = doc.createAttributeNS(null, "Id");
/*  556 */     this.idSignatureValue = UtilidadTratarNodo.newID(doc, "SignatureValue");
/*  557 */     idValorFirma.setValue(this.idSignatureValue);
/*  558 */     NamedNodeMap elementoIdAtributosValorFirma = 
/*  559 */       elementoValorFirma.getAttributes();
/*  560 */     elementoIdAtributosValorFirma.setNamedItem(idValorFirma);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  565 */     boolean xadesT = tipoFirma.compareTo(EnumFormatoFirma.XAdES_T) >= 0;
/*      */     
/*  567 */     log.debug(I18n.getResource("libreriaxades.firmaxml.debug1") + xadesT);
/*      */     
/*  569 */     byte[] selloTiempo = null;
/*  570 */     if (xadesT)
/*      */     {
/*      */       try
/*      */       {
/*  574 */         ITimeStampGenerator timeStampGenerator = dataToSign.getTimeStampGenerator();
/*  575 */         if (timeStampGenerator == null) {
/*  576 */           throw new ClienteError(I18n.getResource("libreriaxades.firmaxml.error6"));
/*      */         }
/*      */         
/*      */ 
/*  580 */         byte[] byteSignature = UtilidadTratarNodo.obtenerByteNodo(firma.getElement(), "http://www.w3.org/2000/09/xmldsig#", "SignatureValue", CanonicalizationEnum.C14N_OMIT_COMMENTS, 5);
/*  581 */         selloTiempo = timeStampGenerator.generateTimeStamp(byteSignature);
/*  582 */         addXadesT(firma.getElement(), firma.getId(), selloTiempo);
/*      */       }
/*      */       catch (AddXadesException e) {
/*  585 */         throw new ClienteError(I18n.getResource("libreriaxades.firmaxml.error7") + e.getMessage());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  590 */     boolean xadesC = tipoFirma.compareTo(EnumFormatoFirma.XAdES_C) >= 0;
/*  591 */     log.debug(I18n.getResource("libreriaxades.firmaxml.debug2") + xadesC);
/*      */     
/*  593 */     if (xadesC)
/*      */     {
/*      */       try
/*      */       {
/*  597 */         if (xadesT) {
/*  598 */           if (dataToSign.getCertStatusManager() == null) {
/*  599 */             throw new ClienteError(I18n.getResource("libreriaxades.firmaxml.error53"));
/*      */           }
/*      */           
/*  602 */           log.info(i18n.getLocalMessage("i18n.mityc.xades.validate.18"));
/*  603 */           convertICertStatus2RespYCerts(
/*  604 */             dataToSign.getCertStatusManager().getCertChainStatus(certificadoFirma), certificadosConOCSP, respuestas);
/*      */           
/*      */ 
/*  607 */           if (log.isDebugEnabled()) {
/*  608 */             log.debug("Se incluyen las referencias OCSP de la propia VA");
/*      */           }
/*      */           
/*  611 */           X509Certificate ocspCert = null;
/*      */           try
/*      */           {
/*  614 */             IOCSPCertStatus respOcsp = (IOCSPCertStatus)((RespYCerts)respuestas.get(0)).getCertstatus();
/*  615 */             OCSPResp resp = new OCSPResp(respOcsp.getEncoded());
/*  616 */             BasicOCSPResp respuestaBasica = (BasicOCSPResp)resp.getResponseObject();
/*  617 */             if (log.isDebugEnabled()) {
/*  618 */               ResponderID respID = respuestaBasica.getResponderId().toASN1Object();
/*  619 */               log.debug("Extracción del certificado OCSP: " + ASN1Utils.getResponderID(respID).toString());
/*      */             }
/*      */             
/*  622 */             X509Certificate[] ocspCerts = respuestaBasica.getCerts("SUN");
/*  623 */             if ((ocspCerts != null) && (ocspCerts.length > 0)) {
/*  624 */               if (log.isDebugEnabled()) {
/*  625 */                 log.debug("Se regenera la cadena y se lanza la validación");
/*      */               }
/*  627 */               CertPath cpOcsp = UtilidadCertificados.orderCertPath(Arrays.asList(ocspCerts));
/*  628 */               ocspCert = (X509Certificate)cpOcsp.getCertificates().get(0);
/*      */               
/*  630 */               if (!ocspCert.getIssuerX500Principal().equals(certificadoFirma.getIssuerX500Principal())) {
/*  631 */                 List<ICertStatus> re = dataToSign.getCertStatusManager().getCertChainStatus(ocspCert);
/*  632 */                 convertICertStatus2RespYCerts(re, certificadosConOCSP, respuestas);
/*      */               } else {
/*  634 */                 ICertStatus respOCSP = dataToSign.getCertStatusManager().getCertStatus(ocspCert);
/*  635 */                 ArrayList<ICertStatus> re = new ArrayList(1);
/*  636 */                 re.add(respOCSP);
/*  637 */                 convertICertStatus2RespYCerts(re, certificadosConOCSP, respuestas);
/*      */               }
/*      */             }
/*      */             else {
/*  641 */               log.error("No se pudo recuperar el certificado de la VA");
/*      */             }
/*      */           } catch (Exception e1) {
/*  644 */             log.error(e1);
/*      */           }
/*      */           
/*  647 */           if (log.isDebugEnabled()) {
/*  648 */             log.debug("Se incluyen las referencias OCSP del sello de tiempo");
/*      */           }
/*  650 */           TimeStampToken tst = null;
/*      */           try {
/*  652 */             tst = new TimeStampToken(new CMSSignedData(selloTiempo));
/*      */           }
/*      */           catch (CMSException e) {
/*      */             try {
/*  656 */               TimeStampResponse tsr = new TimeStampResponse(selloTiempo);
/*  657 */               tst = tsr.getTimeStampToken();
/*      */             } catch (Exception ex) {
/*  659 */               log.error(ex);
/*      */             }
/*      */           } catch (Exception e) {
/*  662 */             log.error(e);
/*      */           }
/*  664 */           X509Certificate certTSA = null;
/*      */           try {
/*  666 */             CertStore cs = tst.getCertificatesAndCRLs("Collection", null);
/*  667 */             Collection<? extends Certificate> certs = cs.getCertificates(null);
/*  668 */             if ((certs != null) && (certs.size() > 0)) {
/*  669 */               if (log.isDebugEnabled()) {
/*  670 */                 log.debug("Se regenera la cadena de certificados firmante del sello de tiempo y se lanza su validación");
/*      */               }
/*      */               Certificate cert;
/*      */               try {
/*  674 */                 Iterable<X509Certificate> iterableCerts = null;
/*  675 */                 if ((certs instanceof Iterable)) {
/*  676 */                   iterableCerts = certs;
/*      */                 } else {
/*  678 */                   throw new Exception("El certificado no es del tipo esperado: " + certs.getClass());
/*      */                 }
/*  680 */                 CertPath cpTsa = UtilidadCertificados.orderCertPath(iterableCerts);
/*  681 */                 certTSA = (X509Certificate)cpTsa.getCertificates().get(0);
/*      */               }
/*      */               catch (Exception e) {
/*  684 */                 cert = (Certificate)certs.iterator().next();
/*  685 */                 if (!(cert instanceof X509Certificate)) break label2172; }
/*  686 */               certTSA = (X509Certificate)cert;
/*      */             }
/*      */             else
/*      */             {
/*  690 */               log.error("No se pudo recuperar el certificado del sello de tiempo");
/*      */             }
/*      */           } catch (Exception e) {
/*  693 */             log.error(e);
/*      */           }
/*      */           label2172:
/*  696 */           if (certTSA != null) {
/*  697 */             if (log.isDebugEnabled()) {
/*  698 */               log.debug("Certificado de TSA obtenido " + certTSA.getSubjectX500Principal());
/*      */             }
/*  700 */             ArrayList<RespYCerts> respuestasTSA = new ArrayList();
/*      */             
/*  702 */             if ((certTSA.getIssuerX500Principal().equals(certificadoFirma.getIssuerX500Principal())) || (
/*  703 */               (ocspCert != null) && (certTSA.getIssuerX500Principal().equals(ocspCert.getIssuerX500Principal())))) {
/*  704 */               ICertStatus respTSA = dataToSign.getCertStatusManager().getCertStatus(certTSA);
/*  705 */               ArrayList<ICertStatus> re = new ArrayList(1);
/*  706 */               re.add(respTSA);
/*  707 */               convertICertStatus2RespYCerts(re, certificadosConOCSP, respuestasTSA);
/*      */             } else {
/*  709 */               convertICertStatus2RespYCerts(
/*  710 */                 dataToSign.getCertStatusManager().getCertChainStatus(certTSA), certificadosConOCSP, respuestasTSA);
/*      */             }
/*      */             
/*  713 */             respuestas.addAll(respuestasTSA);
/*      */             
/*  715 */             if (log.isDebugEnabled()) {
/*  716 */               log.debug("TSA Validada. Se valida la VA del propio sello");
/*      */             }
/*      */             try {
/*  719 */               IOCSPCertStatus respOcspTsa = (IOCSPCertStatus)((RespYCerts)respuestasTSA.get(0)).getCertstatus();
/*  720 */               OCSPResp resp = new OCSPResp(respOcspTsa.getEncoded());
/*  721 */               BasicOCSPResp respuestaBasica = (BasicOCSPResp)resp.getResponseObject();
/*  722 */               if (log.isDebugEnabled()) {
/*  723 */                 ResponderID respID = respuestaBasica.getResponderId().toASN1Object();
/*  724 */                 log.debug("Extracción del certificado OCSP para el sello de tiempo: " + ASN1Utils.getResponderID(respID).toString());
/*      */               }
/*      */               
/*  727 */               X509Certificate[] ocspTsaCerts = respuestaBasica.getCerts("SUN");
/*  728 */               if ((ocspTsaCerts != null) && (ocspTsaCerts.length > 0))
/*      */               {
/*  730 */                 X509Certificate tsaOCSPCert = null;
/*      */                 
/*  732 */                 CertPath cpTsa = UtilidadCertificados.orderCertPath(Arrays.asList(ocspTsaCerts));
/*      */                 try {
/*  734 */                   tsaOCSPCert = (X509Certificate)cpTsa.getCertificates().get(0);
/*      */                 }
/*      */                 catch (Exception e) {
/*  737 */                   Certificate cert = (Certificate)cpTsa.getCertificates().get(0);
/*  738 */                   if ((cert instanceof X509Certificate)) {
/*  739 */                     tsaOCSPCert = (X509Certificate)cert;
/*      */                   }
/*      */                 }
/*      */                 
/*  743 */                 if (log.isDebugEnabled()) {
/*  744 */                   log.debug("Certificado VA del sello de tiempo obtenido: " + tsaOCSPCert.getSubjectX500Principal());
/*      */                 }
/*      */                 
/*      */ 
/*  748 */                 if ((tsaOCSPCert.getIssuerX500Principal().equals(certificadoFirma.getIssuerX500Principal())) || 
/*  749 */                   ((ocspCert != null) && (tsaOCSPCert.getIssuerX500Principal().equals(ocspCert.getIssuerX500Principal()))) || (
/*  750 */                   (certTSA != null) && (tsaOCSPCert.getIssuerX500Principal().equals(certTSA.getIssuerX500Principal())))) {
/*  751 */                   ICertStatus respOCSP = dataToSign.getCertStatusManager().getCertStatus(tsaOCSPCert);
/*  752 */                   ArrayList<ICertStatus> re = new ArrayList(1);
/*  753 */                   re.add(respOCSP);
/*  754 */                   convertICertStatus2RespYCerts(re, certificadosConOCSP, respuestas);
/*      */                 } else {
/*  756 */                   convertICertStatus2RespYCerts(dataToSign.getCertStatusManager().getCertChainStatus(tsaOCSPCert), certificadosConOCSP, respuestas);
/*      */                 }
/*      */               }
/*      */               else
/*      */               {
/*  761 */                 log.error("No se pudo recuperar el certificado de la VA del sello de tiempo");
/*      */               }
/*      */             } catch (Exception e1) {
/*  764 */               log.error(e1);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*  770 */           addXadesC(firma.getElement(), respuestas, schema, algDigestXML);
/*      */         }
/*      */         else {
/*  773 */           throw new ClienteError(I18n.getResource("libreriaxades.firmaxml.error24"));
/*      */         }
/*      */       } catch (CertStatusException e) {
/*  776 */         throw new ClienteError(I18n.getResource("libreriaxades.firmaxml.error56") + 
/*  777 */           "\n" + e.getMessage());
/*      */       } catch (AddXadesException e) {
/*  779 */         throw new ClienteError(I18n.getResource("libreriaxades.firmaxml.error10") + ":" + 
/*  780 */           "\n" + e.getMessage());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  785 */     boolean xadesX = tipoFirma.compareTo(EnumFormatoFirma.XAdES_X) >= 0;
/*  786 */     log.debug(I18n.getResource("libreriaxades.firmaxml.debug3") + xadesX);
/*      */     
/*  788 */     boolean xadesXL = tipoFirma.compareTo(EnumFormatoFirma.XAdES_XL) == 0;
/*  789 */     log.debug(I18n.getResource("libreriaxades.firmaxml.debug4") + xadesXL);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  795 */     if ((xadesC) && (!xadesXL)) {
/*      */       try {
/*  797 */         doc = addURIXadesC(firma.getElement(), saveOCSPFiles(respuestas, dataToSign.getElementsStorer()), dataToSign.getBaseURI());
/*      */       } catch (FirmaXMLError ex) {
/*  799 */         throw new ClienteError("Error al guardar ficheros de estados de certificados", ex);
/*      */       }
/*      */     }
/*      */     
/*  803 */     if (xadesX)
/*      */     {
/*      */       Element unsignedSignaturePropertiesElement;
/*      */       
/*  807 */       if ((xadesT) && (xadesC))
/*      */       {
/*      */ 
/*  810 */         Element signatureElement = firma.getElement();
/*      */         
/*  812 */         if (!new NombreNodo("http://www.w3.org/2000/09/xmldsig#", "Signature").equals(new NombreNodo(signatureElement.getNamespaceURI(), signatureElement.getLocalName())))
/*      */         {
/*  814 */           throw new ClienteError(I18n.getResource("libreriaxades.firmaxml.error33") + 
/*  815 */             " " + "Signature");
/*      */         }
/*      */         
/*      */ 
/*  819 */         unsignedSignaturePropertiesElement = null;
/*  820 */         NodeList unsignedSignaturePropertiesNodes = 
/*  821 */           signatureElement.getElementsByTagNameNS(this.xadesSchema, "UnsignedSignatureProperties");
/*      */         
/*  823 */         if (unsignedSignaturePropertiesNodes.getLength() != 1)
/*      */         {
/*  825 */           log.error(I18n.getResource("libreriaxades.firmaxml.error36") + " " + 
/*  826 */             "UnsignedSignatureProperties" + " " + 
/*  827 */             I18n.getResource("libreriaxades.firmaxml.error37") + " " + 
/*  828 */             unsignedSignaturePropertiesNodes.getLength());
/*      */           
/*  830 */           throw new ClienteError(I18n.getResource("libreriaxades.firmaxml.error41"));
/*      */         }
/*  832 */         unsignedSignaturePropertiesElement = (Element)unsignedSignaturePropertiesNodes.item(0);
/*      */       }
/*      */       
/*  835 */       switch (dataToSign.getXAdESXType()) {
/*      */       case TYPE_2: 
/*  837 */         addXadesX2(unsignedSignaturePropertiesElement, dataToSign.getTimeStampGenerator());
/*  838 */         break;
/*      */       case TYPE_1: 
/*      */       default: 
/*  841 */         addXadesX(unsignedSignaturePropertiesElement, dataToSign.getTimeStampGenerator());
/*      */         
/*  843 */         break;
/*      */         
/*      */ 
/*  846 */         throw new ClienteError(I18n.getResource("libreriaxades.firmaxml.error25"));
/*      */       }
/*      */       
/*      */     }
/*  850 */     if (xadesXL)
/*      */     {
/*      */ 
/*      */ 
/*  854 */       if ((xadesT) && (xadesC) && (xadesX))
/*      */       {
/*      */         try
/*      */         {
/*  858 */           addXadesXL(firma.getElement(), respuestas, schema);
/*      */         }
/*      */         catch (Exception e) {
/*  861 */           throw new ClienteError(I18n.getResource("libreriaxades.firmaxml.error12") + e.getMessage(), e);
/*      */         }
/*      */         
/*      */       } else {
/*  865 */         throw new ClienteError(I18n.getResource("libreriaxades.firmaxml.error13"));
/*      */       }
/*      */     }
/*      */     
/*  869 */     Object[] res = new Object[3];
/*  870 */     res[0] = doc;
/*  871 */     if ((xadesC) && (!xadesXL)) {
/*  872 */       res[1] = respuestas;
/*      */     } else {
/*  874 */       res[1] = null;
/*      */     }
/*  876 */     res[2] = this.idSignatureValue;
/*      */     
/*  878 */     return res;
/*      */   }
/*      */   
/*      */   private void convertICertStatus2RespYCerts(List<ICertStatus> status, ArrayList<X509Certificate> certificadosConOCSP, ArrayList<RespYCerts> resps)
/*      */   {
/*  883 */     if (status != null) {
/*  884 */       Iterator<ICertStatus> itStatus = status.iterator();
/*  885 */       while (itStatus.hasNext()) {
/*  886 */         RespYCerts resp = new RespYCerts();
/*  887 */         resp.setCertstatus((ICertStatus)itStatus.next());
/*  888 */         if (!certificadosConOCSP.contains(resp.getCertstatus().getCertificate())) {
/*  889 */           certificadosConOCSP.add(resp.getCertstatus().getCertificate());
/*  890 */           resps.add(resp);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Document addXades(Document doc, String firmaID, X509Certificate firmaCertificado, Element elementoPrincipalFirma, XAdESSchemas schemaXades, DataToSign dataToSign, String algDigestXML)
/*      */     throws AddXadesException
/*      */   {
/*  918 */     Element elementoObjeto = doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", this.xmldsigNS + ":" + "Object");
/*  919 */     elementoObjeto.setAttributeNS(null, "Id", UtilidadTratarNodo.newID(doc, firmaID + "-Object"));
/*  920 */     elementoPrincipalFirma.appendChild(elementoObjeto);
/*      */     
/*      */ 
/*  923 */     Element elemntQualifyingProperties = doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "QualifyingProperties");
/*  924 */     elementoObjeto.appendChild(elemntQualifyingProperties);
/*      */     
/*      */ 
/*  927 */     elemntQualifyingProperties.setAttributeNS(null, "Target", "#" + firmaID);
/*      */     
/*      */ 
/*  930 */     Element propiedadesFirmadasElemento = doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "SignedProperties");
/*  931 */     elemntQualifyingProperties.appendChild(propiedadesFirmadasElemento);
/*      */     
/*      */ 
/*  934 */     propiedadesFirmadasElemento.setAttributeNS(null, "Id", firmaID + this.idSigProperties);
/*      */     
/*      */ 
/*  937 */     Element propiedadesFirmadasElementoFirma = doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "SignedSignatureProperties");
/*  938 */     propiedadesFirmadasElemento.appendChild(propiedadesFirmadasElementoFirma);
/*      */     
/*      */ 
/*  941 */     Date signingDate = dataToSign.getSignDate();
/*  942 */     if ((signingDate == null) && (schemaXades.equals(XAdESSchemas.XAdES_111)))
/*  943 */       throw new AddXadesException("SigningTime es requerido");
/*  944 */     if (signingDate != null) {
/*  945 */       SigningTime tiempoFirma = new SigningTime(schemaXades, signingDate);
/*  946 */       Element tiempoFirmaElemento = null;
/*      */       try {
/*  948 */         tiempoFirmaElemento = tiempoFirma.createElement(doc, this.xadesNS);
/*      */       } catch (InvalidInfoNodeException e) {
/*  950 */         throw new AddXadesException(e.getMessage(), e);
/*      */       }
/*  952 */       propiedadesFirmadasElementoFirma.appendChild(tiempoFirmaElemento);
/*      */     }
/*      */     
/*      */ 
/*  956 */     Element certificadoFirmaElemento = doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "SigningCertificate");
/*  957 */     propiedadesFirmadasElementoFirma.appendChild(certificadoFirmaElemento);
/*      */     
/*      */ 
/*  960 */     Element certificadoElemento = doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "Cert");
/*  961 */     File signCertFile = dataToSign.getSigningCert();
/*  962 */     if (signCertFile != null) {
/*  963 */       String uri = UtilidadFicheros.relativizeRute(dataToSign.getBaseURI(), signCertFile);
/*  964 */       certificadoElemento.setAttributeNS(null, "URI", uri);
/*      */     }
/*      */     
/*      */ 
/*  968 */     Element resumenCertificadoElemento = doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "CertDigest");
/*      */     
/*      */ 
/*      */ 
/*  972 */     Element metodoResumenElemento = doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", this.xmldsigNS + ":" + "DigestMethod");
/*  973 */     metodoResumenElemento.setAttributeNS(null, "Algorithm", algDigestXML);
/*      */     
/*      */ 
/*  976 */     String resumenCertificado = "";
/*      */     try
/*      */     {
/*  979 */       MessageDigest resumenCertificadoTemp = UtilidadFirmaElectronica.getMessageDigest(algDigestXML);
/*  980 */       if (resumenCertificadoTemp == null)
/*  981 */         throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error16"));
/*  982 */       byte[] byteMessageDigest = resumenCertificadoTemp.digest(firmaCertificado.getEncoded());
/*  983 */       resumenCertificado = new String(Base64Coder.encode(byteMessageDigest));
/*      */     }
/*      */     catch (CertificateEncodingException cee)
/*      */     {
/*  987 */       throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error17"));
/*      */     }
/*      */     
/*  990 */     Element elementDigestValue = doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", this.xmldsigNS + ":" + "DigestValue");
/*  991 */     elementDigestValue.appendChild(doc.createTextNode(resumenCertificado));
/*      */     
/*      */ 
/*  994 */     Element elementoEmisorSerial = doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "IssuerSerial");
/*      */     
/*      */ 
/*  997 */     Element elementoX509EmisorNombre = doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", this.xmldsigNS + ":" + "X509IssuerName");
/*      */     
/*  999 */     String issuerName = null;
/*      */     try {
/* 1001 */       issuerName = firmaCertificado.getIssuerX500Principal().getName();
/* 1002 */       if (log.isTraceEnabled()) {
/* 1003 */         log.trace("Certificado emisor obtenido del X500: " + issuerName);
/*      */       }
/* 1005 */       Charset charsetUtf = Charset.forName("UTF-8");
/* 1006 */       issuerName = charsetUtf.decode(ByteBuffer.wrap(issuerName.getBytes())).toString();
/* 1007 */       if (log.isTraceEnabled()) {
/* 1008 */         log.trace("Emisor decodificado en UTF8:" + issuerName);
/*      */       }
/*      */     } catch (Exception e1) {
/* 1011 */       if (log.isDebugEnabled()) {
/* 1012 */         log.error("Error al codificar el emisor en UTF-8. Se toma su valor con el charset original.", e1);
/*      */       }
/* 1014 */       issuerName = firmaCertificado.getIssuerDN().getName();
/*      */     }
/* 1016 */     if (log.isTraceEnabled()) {
/* 1017 */       log.debug("Certificado emisor: " + issuerName);
/*      */       
/* 1019 */       Charset charset = null;
/* 1020 */       Iterator<Map.Entry<String, Charset>> charsets = Charset.availableCharsets().entrySet().iterator();
/* 1021 */       log.debug("Charsets disponibles encontrados: " + Charset.availableCharsets().size());
/* 1022 */       while (charsets.hasNext()) {
/* 1023 */         charset = (Charset)((Map.Entry)charsets.next()).getValue();
/*      */         
/*      */ 
/* 1026 */         byte[] data1 = null;
/* 1027 */         byte[] data2 = null;
/*      */         try {
/* 1029 */           data1 = issuerName.getBytes(charset);
/* 1030 */           data2 = firmaCertificado.getIssuerX500Principal().getName().getBytes(charset);
/*      */         } catch (Exception e) {
/* 1032 */           log.error("No se puede codificar la cadena en " + charset.displayName(), e);
/* 1033 */           continue;
/*      */         }
/* 1035 */         if (data1.length == data2.length) {
/* 1036 */           for (int i = 0; i < data1.length; i++) {
/* 1037 */             if (data1[i] != data2[i]) {
/* 1038 */               log.debug("El nombre del Issuer leído y el X500 original no coinciden en formato " + charset.displayName() + ": " + data1[i] + " - " + data2[i]);
/*      */             }
/*      */           }
/*      */         } else {
/* 1042 */           log.debug("No coincide el tamaño en " + charset);
/*      */         }
/*      */       }
/*      */     }
/* 1046 */     elementoX509EmisorNombre.appendChild(doc.createTextNode(issuerName));
/*      */     
/*      */ 
/* 1049 */     Element elementoX509NumeroSerial = doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", this.xmldsigNS + ":" + "X509SerialNumber");
/* 1050 */     elementoX509NumeroSerial.appendChild(doc.createTextNode(firmaCertificado.getSerialNumber().toString()));
/*      */     
/*      */ 
/* 1053 */     String[] produc = dataToSign.getProductionPlace();
/* 1054 */     if (produc != null) {
/* 1055 */       SignatureProductionPlace spp = new SignatureProductionPlace(schemaXades, produc[0], produc[1], produc[2], produc[3]);
/* 1056 */       Element productionPlaceElemento = null;
/*      */       try {
/* 1058 */         productionPlaceElemento = spp.createElement(doc, this.xadesNS);
/*      */       } catch (InvalidInfoNodeException e) {
/* 1060 */         throw new AddXadesException(e.getMessage(), e);
/*      */       }
/* 1062 */       propiedadesFirmadasElementoFirma.appendChild(productionPlaceElemento);
/*      */     }
/*      */     
/* 1065 */     resumenCertificadoElemento.appendChild(metodoResumenElemento);
/* 1066 */     resumenCertificadoElemento.appendChild(elementDigestValue);
/*      */     
/* 1068 */     certificadoElemento.appendChild(resumenCertificadoElemento);
/*      */     
/* 1070 */     elementoEmisorSerial.appendChild(elementoX509EmisorNombre);
/* 1071 */     elementoEmisorSerial.appendChild(elementoX509NumeroSerial);
/*      */     
/* 1073 */     certificadoElemento.appendChild(elementoEmisorSerial);
/*      */     
/*      */ 
/* 1076 */     certificadoFirmaElemento.appendChild(certificadoElemento);
/*      */     
/*      */ 
/* 1079 */     ArrayList<IClaimedRole> rolesFirmante = dataToSign.getClaimedRoles();
/* 1080 */     if (rolesFirmante != null) {
/* 1081 */       Element elementoRoleFirmanteElemento = doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "SignerRole");
/* 1082 */       propiedadesFirmadasElementoFirma.appendChild(elementoRoleFirmanteElemento);
/*      */       
/* 1084 */       Element elementoRolesDemandadosElementos = doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "ClaimedRoles");
/* 1085 */       elementoRoleFirmanteElemento.appendChild(elementoRolesDemandadosElementos);
/* 1086 */       Iterator<IClaimedRole> it = rolesFirmante.iterator();
/* 1087 */       while (it.hasNext()) {
/* 1088 */         Element elementClaimedRoleElement = doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "ClaimedRole");
/* 1089 */         elementClaimedRoleElement.appendChild(((IClaimedRole)it.next()).createClaimedRoleContent(doc));
/* 1090 */         elementoRolesDemandadosElementos.appendChild(elementClaimedRoleElement);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1095 */     ArrayList<ObjectToSign> objects = dataToSign.getObjects();
/* 1096 */     if ((objects != null) && (objects.size() > 0))
/*      */     {
/*      */ 
/* 1099 */       Element signedDataObjectProperties = doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "SignedDataObjectProperties");
/*      */       
/* 1101 */       Iterator<ObjectToSign> it = objects.iterator();
/* 1102 */       DataObjectFormat dof = null;
/* 1103 */       ObjectIdentifier oi = null;
/*      */       
/* 1105 */       ObjectToSign obj = null;
/* 1106 */       String id = null;
/* 1107 */       String desc = null;
/* 1108 */       String tipoMIME = null;
/* 1109 */       URI encoding = null;
/*      */       
/* 1111 */       URI referenceId = null;
/* 1112 */       while (it.hasNext()) {
/* 1113 */         obj = (ObjectToSign)it.next();
/*      */         
/* 1115 */         if (obj != null)
/*      */         {
/* 1117 */           id = obj.getId();
/*      */           
/* 1119 */           desc = obj.getDescription();
/*      */           
/* 1121 */           tipoMIME = obj.getMimeType();
/*      */           
/* 1123 */           encoding = obj.getEncoding();
/*      */           
/* 1125 */           oi = obj.getObjectIdentifier();
/*      */         }
/*      */         
/* 1128 */         if ((desc != null) || (tipoMIME != null) || (oi != null))
/*      */         {
/*      */           try
/*      */           {
/* 1132 */             desc = new String(desc.getBytes(), "UTF-8");
/*      */           } catch (UnsupportedEncodingException e1) {
/* 1134 */             if (log.isDebugEnabled()) {
/* 1135 */               log.debug(e1);
/*      */             }
/*      */             try {
/* 1138 */               desc = URLEncoder.encode(desc, "UTF-8");
/*      */             } catch (UnsupportedEncodingException e) {
/* 1140 */               log.error(e.getMessage(), e);
/* 1141 */               desc = "Unknown";
/*      */             }
/*      */           }
/*      */           
/*      */ 
/* 1146 */           if (id != null) {
/*      */             try {
/* 1148 */               referenceId = new URI(id);
/*      */             } catch (URISyntaxException e) {
/* 1150 */               log.error(e.getMessage(), e);
/*      */             }
/*      */           }
/*      */           
/* 1154 */           if ((referenceId == null) || (schemaXades == null))
/*      */           {
/* 1156 */             log.error("No se puede incluir el objeto DataObjectFormat porque faltan datos");
/* 1157 */             throw new AddXadesException(i18n.getLocalMessage("i18n.mityc.xades.sign.2"));
/*      */           }
/*      */           
/* 1160 */           dof = new DataObjectFormat(schemaXades, 
/* 1161 */             referenceId, 
/* 1162 */             desc, 
/* 1163 */             tipoMIME);
/*      */           
/* 1165 */           if (encoding != null) {
/* 1166 */             dof.setEncoding(encoding);
/*      */           }
/* 1168 */           if (oi != null) {
/* 1169 */             dof.setObjectIdentifier(oi);
/*      */           }
/*      */           try {
/* 1172 */             signedDataObjectProperties.appendChild(dof.createElement(doc, this.xadesNS));
/*      */           } catch (DOMException e) {
/* 1174 */             throw new AddXadesException(e.getMessage(), e);
/*      */           } catch (InvalidInfoNodeException e) {
/* 1176 */             log.error(e.getMessage(), e);
/* 1177 */             throw new AddXadesException(i18n.getLocalMessage("i18n.mityc.xades.sign.2"));
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 1182 */       if (signedDataObjectProperties.getChildNodes().getLength() > 0) {
/* 1183 */         propiedadesFirmadasElemento.appendChild(signedDataObjectProperties);
/*      */       }
/*      */     }
/* 1186 */     return null;
/*      */   }
/*      */   
/*      */   private void addXadesEPES(Element elementoPrincipalFirma, String confPolicyManager) throws AddXadesException {
/* 1190 */     if (confPolicyManager == null) {
/* 1191 */       confPolicyManager = "implied";
/*      */     }
/*      */     
/* 1194 */     IFirmaPolicy policyManager = PoliciesManager.getInstance().getEscritorPolicy(confPolicyManager);
/* 1195 */     if (policyManager == null)
/*      */     {
/* 1197 */       log.error(I18n.getResource("libreriaxades.firmaxml.error46") + 
/* 1198 */         " " + confPolicyManager);
/* 1199 */       throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error47"));
/*      */     }
/*      */     
/* 1202 */     XAdESSchemas schema = XAdESSchemas.getXAdESSchema(this.xadesSchema);
/* 1203 */     if (schema == null) {
/* 1204 */       log.error(I18n.getResource("libreriaxades.firmaxml.error44") + 
/* 1205 */         " " + this.xadesSchema);
/* 1206 */       throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error45"));
/*      */     }
/*      */     try
/*      */     {
/* 1210 */       policyManager.writePolicyNode(elementoPrincipalFirma, this.xmldsigNS, this.xadesNS, schema);
/*      */     }
/*      */     catch (PolicyException ex) {
/* 1213 */       log.error(I18n.getResource("libreriaxades.firmaxml.error48") + 
/* 1214 */         " " + ex.getMessage(), ex);
/* 1215 */       throw new AddXadesException(ex.getMessage(), ex);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Document addXadesT(Element firma, String firmaID, byte[] selloTiempo)
/*      */     throws AddXadesException
/*      */   {
/* 1230 */     Document doc = firma.getOwnerDocument();
/* 1231 */     Element elementoPrincipal = null;
/* 1232 */     NodeList nodos = firma.getElementsByTagNameNS(this.xadesSchema, "QualifyingProperties");
/* 1233 */     if (nodos.getLength() != 0) {
/* 1234 */       elementoPrincipal = (Element)nodos.item(0);
/*      */     } else {
/* 1236 */       throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error18"));
/*      */     }
/*      */     
/* 1239 */     Element propiedadesElementosNoFirmados = null;
/* 1240 */     ArrayList<Element> nodosUnsigendProp = null;
/*      */     try {
/* 1242 */       nodosUnsigendProp = UtilidadTratarNodo.obtenerNodos(elementoPrincipal, 1, 
/* 1243 */         new NombreNodo(this.xadesSchema, "UnsignedProperties"));
/*      */     }
/*      */     catch (FirmaXMLError localFirmaXMLError1) {}
/* 1246 */     if ((nodosUnsigendProp != null) && (nodosUnsigendProp.size() == 1)) {
/* 1247 */       propiedadesElementosNoFirmados = (Element)nodosUnsigendProp.get(0);
/*      */     } else {
/* 1249 */       propiedadesElementosNoFirmados = 
/* 1250 */         doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "UnsignedProperties");
/*      */       
/*      */ 
/* 1253 */       Attr propiedadesNoFirmadasId = doc.createAttributeNS(null, "Id");
/* 1254 */       propiedadesNoFirmadasId.setValue(UtilidadTratarNodo.newID(doc, 
/* 1255 */         firmaID + "-UnsignedProperties"));
/* 1256 */       NamedNodeMap atributosSinFirmarPropiedadesElemento = 
/* 1257 */         propiedadesElementosNoFirmados.getAttributes();
/* 1258 */       atributosSinFirmarPropiedadesElemento.setNamedItem(propiedadesNoFirmadasId);
/*      */     }
/*      */     
/* 1261 */     Element propiedadesSinFirmarFirmaElementos = null;
/* 1262 */     ArrayList<Element> nodosUnsigendSigProp = null;
/*      */     try {
/* 1264 */       nodosUnsigendSigProp = UtilidadTratarNodo.obtenerNodos(elementoPrincipal, 2, 
/* 1265 */         new NombreNodo(this.xadesSchema, "UnsignedSignatureProperties"));
/*      */     }
/*      */     catch (FirmaXMLError localFirmaXMLError2) {}
/* 1268 */     if ((nodosUnsigendSigProp != null) && (nodosUnsigendSigProp.size() == 1)) {
/* 1269 */       propiedadesSinFirmarFirmaElementos = (Element)nodosUnsigendSigProp.get(0);
/*      */     } else {
/* 1271 */       propiedadesSinFirmarFirmaElementos = 
/* 1272 */         doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "UnsignedSignatureProperties");
/*      */     }
/*      */     
/*      */ 
/* 1276 */     NodeList sellosPreexistentes = doc.getElementsByTagNameNS(this.xadesSchema, "SignatureTimeStamp");
/* 1277 */     int numSellos = sellosPreexistentes.getLength();
/* 1278 */     for (int i = 0; i < numSellos; i++) {
/* 1279 */       Element sello = (Element)sellosPreexistentes.item(i);
/* 1280 */       String selloId = sello.getAttribute("Id");
/* 1281 */       if (selloId == null) {
/* 1282 */         Attr informacionElementoSigTimeStamp = doc.createAttributeNS(null, "Id");
/* 1283 */         selloId = UtilidadTratarNodo.newID(doc, "SelloTiempo");
/* 1284 */         informacionElementoSigTimeStamp.setValue(selloId);
/* 1285 */         sello.getAttributes().setNamedItem(informacionElementoSigTimeStamp);
/*      */       }
/*      */       
/* 1288 */       this.idNodoSelloTiempo.add(selloId);
/*      */     }
/*      */     
/*      */ 
/* 1292 */     Element tiempoSelloElementoFirma = 
/* 1293 */       doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "SignatureTimeStamp");
/*      */     
/*      */ 
/* 1296 */     Attr informacionElementoSigTimeStamp = doc.createAttributeNS(null, "Id");
/* 1297 */     String idSelloTiempo = UtilidadTratarNodo.newID(doc, "SelloTiempo");
/* 1298 */     informacionElementoSigTimeStamp.setValue(idSelloTiempo);
/* 1299 */     this.idNodoSelloTiempo.add(idSelloTiempo);
/* 1300 */     tiempoSelloElementoFirma.getAttributes().setNamedItem(informacionElementoSigTimeStamp);
/*      */     
/*      */ 
/* 1303 */     if (("http://uri.etsi.org/01903/v1.1.1#".equals(this.xadesSchema)) || 
/* 1304 */       ("http://uri.etsi.org/01903/v1.2.2#".equals(this.xadesSchema)))
/*      */     {
/* 1306 */       String nombreNodoUri = null;
/* 1307 */       String tipoUri = null;
/* 1308 */       if ("http://uri.etsi.org/01903/v1.1.1#".equals(this.xadesSchema)) {
/* 1309 */         nombreNodoUri = "HashDataInfo";
/* 1310 */         tipoUri = "uri";
/*      */       } else {
/* 1312 */         nombreNodoUri = "Include";
/* 1313 */         tipoUri = "URI";
/*      */       }
/*      */       
/* 1316 */       Element informacionElementoHashDatos = doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + nombreNodoUri);
/*      */       
/* 1318 */       ArrayList<Element> listElements = new ArrayList();
/*      */       try {
/* 1320 */         listElements = UtilidadTratarNodo.obtenerNodos(firma, 2, new NombreNodo("http://www.w3.org/2000/09/xmldsig#", "SignatureValue"));
/*      */       } catch (FirmaXMLError e) {
/* 1322 */         log.error(I18n.getResource("libreriaxades.firmaxml.error5"), e);
/* 1323 */         throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error5"));
/*      */       }
/* 1325 */       if (listElements.size() != 1) {
/* 1326 */         log.error(I18n.getResource("libreriaxades.firmaxml.error5"));
/* 1327 */         throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error5"));
/*      */       }
/* 1329 */       this.idSignatureValue = ((Element)listElements.get(0)).getAttribute("Id");
/* 1330 */       if (this.idSignatureValue == null) {
/* 1331 */         log.error(I18n.getResource("libreriaxades.firmaxml.error5"));
/* 1332 */         throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error5"));
/*      */       }
/*      */       
/* 1335 */       Attr informacionElementoHashDatosUri = doc.createAttributeNS(null, tipoUri);
/* 1336 */       informacionElementoHashDatosUri.setValue("#" + this.idSignatureValue);
/*      */       
/* 1338 */       NamedNodeMap informacionAtributosElementoHashDatos = informacionElementoHashDatos.getAttributes();
/* 1339 */       informacionAtributosElementoHashDatos.setNamedItem(informacionElementoHashDatosUri);
/*      */       
/* 1341 */       tiempoSelloElementoFirma.appendChild(informacionElementoHashDatos);
/*      */     }
/*      */     
/*      */ 
/* 1345 */     if (!"http://uri.etsi.org/01903/v1.1.1#".equals(this.xadesSchema)) {
/* 1346 */       Element canonicalizationElemento = doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", this.xmldsigNS + ":" + "CanonicalizationMethod");
/* 1347 */       Attr canonicalizationAttribute = doc.createAttributeNS(null, "Algorithm");
/* 1348 */       canonicalizationAttribute.setValue("http://www.w3.org/TR/2001/REC-xml-c14n-20010315");
/* 1349 */       canonicalizationElemento.getAttributes().setNamedItem(canonicalizationAttribute);
/*      */       
/* 1351 */       tiempoSelloElementoFirma.appendChild(canonicalizationElemento);
/*      */     }
/*      */     
/*      */ 
/* 1355 */     Element tiempoSelloEncapsulado = 
/* 1356 */       doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "EncapsulatedTimeStamp");
/*      */     
/* 1358 */     tiempoSelloEncapsulado.appendChild(
/* 1359 */       doc.createTextNode(new String(Base64Coder.encode(selloTiempo))));
/* 1360 */     Attr tiempoSelloEncapsuladoId = doc.createAttributeNS(null, "Id");
/* 1361 */     String idEncapsulated = UtilidadTratarNodo.newID(doc, "SelloTiempo-Token");
/* 1362 */     tiempoSelloEncapsuladoId.setValue(idEncapsulated);
/* 1363 */     tiempoSelloEncapsulado.getAttributes().setNamedItem(tiempoSelloEncapsuladoId);
/*      */     
/*      */ 
/* 1366 */     tiempoSelloElementoFirma.appendChild(tiempoSelloEncapsulado);
/*      */     
/* 1368 */     propiedadesSinFirmarFirmaElementos.appendChild(tiempoSelloElementoFirma);
/* 1369 */     propiedadesElementosNoFirmados.appendChild(propiedadesSinFirmarFirmaElementos);
/* 1370 */     elementoPrincipal.appendChild(propiedadesElementosNoFirmados);
/* 1371 */     return doc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Document addXadesC(Element firma, ArrayList<RespYCerts> respuestas, XAdESSchemas schema, String algDigestXML)
/*      */     throws AddXadesException
/*      */   {
/* 1389 */     Document doc = firma.getOwnerDocument();
/*      */     
/*      */ 
/* 1392 */     Element elementoPrincipal = null;
/* 1393 */     ArrayList<X509Certificate> certRefs = null;
/*      */     
/* 1395 */     String tipoUri = null;
/* 1396 */     if ("http://uri.etsi.org/01903/v1.1.1#".equals(this.xadesSchema)) {
/* 1397 */       tipoUri = "uri";
/*      */     } else {
/* 1399 */       tipoUri = "URI";
/*      */     }
/*      */     
/* 1402 */     NodeList nodos = firma.getElementsByTagNameNS(this.xadesSchema, "UnsignedSignatureProperties");
/* 1403 */     if (nodos.getLength() != 0)
/*      */     {
/* 1405 */       elementoPrincipal = (Element)nodos.item(0);
/*      */     }
/*      */     else
/*      */     {
/* 1409 */       throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error19"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1414 */     Element certificadosElementosFirma = 
/* 1415 */       doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "CompleteCertificateRefs");
/* 1416 */     Element revocacionesElementoFirma = 
/* 1417 */       doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "CompleteRevocationRefs");
/*      */     
/*      */ 
/* 1420 */     int size = respuestas.size();
/* 1421 */     if (size > 0) {
/* 1422 */       certRefs = new ArrayList(size);
/* 1423 */       for (int x = 0; x < size; x++) {
/* 1424 */         if (!((RespYCerts)respuestas.get(x)).getCertstatus().getStatus().equals(ICertStatus.CERT_STATUS.valid)) {
/* 1425 */           throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error56") + " " + ((RespYCerts)respuestas.get(x)).getCertstatus().getCertificate().getSubjectDN() + " " + ((RespYCerts)respuestas.get(x)).getCertstatus().getCertificate().getSerialNumber());
/*      */         }
/* 1427 */         certRefs.add(((RespYCerts)respuestas.get(x)).getCertstatus().getCertificate());
/*      */       }
/*      */     } else {
/* 1430 */       throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error56"));
/*      */     }
/*      */     
/* 1433 */     if (certRefs != null)
/*      */     {
/*      */ 
/* 1436 */       Attr informacionElementoCertRef = doc.createAttributeNS(null, "Id");
/* 1437 */       this.idNodoCertificateRefs = UtilidadTratarNodo.newID(doc, "CompleteCertificateRefs");
/* 1438 */       informacionElementoCertRef.setValue(this.idNodoCertificateRefs);
/* 1439 */       certificadosElementosFirma.getAttributes().setNamedItem(informacionElementoCertRef);
/*      */       
/* 1441 */       Element elementoCertRefs = 
/* 1442 */         doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "CertRefs");
/*      */       
/* 1444 */       certificadosElementosFirma.appendChild(elementoCertRefs);
/* 1445 */       int longitud = certRefs.size();
/*      */       
/*      */ 
/* 1448 */       String idNueva = UtilidadTratarNodo.newID(doc, "CertPath");
/* 1449 */       ((RespYCerts)respuestas.get(0)).setIdCertificado(idNueva);
/*      */       
/* 1451 */       for (int i = 1; i < longitud; i++)
/*      */       {
/* 1453 */         X509Certificate firmaCertificado = (X509Certificate)certRefs.get(i);
/* 1454 */         Element elementCertRef = doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "Cert");
/*      */         
/*      */ 
/* 1457 */         Attr uris = doc.createAttributeNS(null, tipoUri);
/*      */         
/* 1459 */         idNueva = UtilidadTratarNodo.newID(doc, "CertPath");
/* 1460 */         uris.setValue("#" + idNueva);
/* 1461 */         ((RespYCerts)respuestas.get(i)).setIdCertificado(idNueva);
/* 1462 */         NamedNodeMap atributosURI = elementCertRef.getAttributes();
/* 1463 */         atributosURI.setNamedItem(uris);
/*      */         
/* 1465 */         Element resumenElementoCert = doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "CertDigest");
/*      */         
/*      */ 
/* 1468 */         Element metodoResumenElemento = doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", this.xmldsigNS + ":" + "DigestMethod");
/*      */         
/*      */ 
/* 1471 */         Attr propiedadesFirmaAlgoritmo = doc.createAttributeNS(null, "Algorithm");
/* 1472 */         propiedadesFirmaAlgoritmo.setValue(algDigestXML);
/* 1473 */         NamedNodeMap cualidadesMetodoResumenElemento = 
/* 1474 */           metodoResumenElemento.getAttributes();
/* 1475 */         cualidadesMetodoResumenElemento.setNamedItem(propiedadesFirmaAlgoritmo);
/*      */         
/*      */ 
/* 1478 */         String resumenCertificado = "";
/*      */         try
/*      */         {
/* 1481 */           MessageDigest resumenCertificadoTemp = UtilidadFirmaElectronica.getMessageDigest(algDigestXML);
/* 1482 */           if (resumenCertificadoTemp == null)
/* 1483 */             throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error16"));
/* 1484 */           byte[] resumenMensajeByte = resumenCertificadoTemp.digest(firmaCertificado.getEncoded());
/* 1485 */           resumenCertificado = new String(Base64Coder.encode(resumenMensajeByte));
/*      */         } catch (CertificateEncodingException e) {
/* 1487 */           log.error(e);
/* 1488 */           throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error23"));
/*      */         }
/*      */         
/* 1491 */         Element elementDigestValue = 
/* 1492 */           doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", this.xmldsigNS + ":" + "DigestValue");
/* 1493 */         elementDigestValue.appendChild(
/* 1494 */           doc.createTextNode(resumenCertificado));
/*      */         
/*      */ 
/* 1497 */         Element elementoEmisorSerial = 
/* 1498 */           doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "IssuerSerial");
/*      */         
/* 1500 */         Element elementoX509EmisorNombre = 
/* 1501 */           doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", this.xmldsigNS + ":" + "X509IssuerName");
/* 1502 */         String issuerName = null;
/*      */         try {
/* 1504 */           issuerName = firmaCertificado.getIssuerX500Principal().getName();
/* 1505 */           if (log.isTraceEnabled()) {
/* 1506 */             log.trace("Certificado emisor obtenido del Issuer X500: " + issuerName);
/*      */           }
/* 1508 */           Charset charsetUtf = Charset.forName("UTF-8");
/* 1509 */           issuerName = charsetUtf.decode(ByteBuffer.wrap(issuerName.getBytes())).toString();
/* 1510 */           if (log.isTraceEnabled()) {
/* 1511 */             log.trace("Emisor decodificado en UTF8:" + issuerName);
/*      */           }
/*      */         } catch (Exception e1) {
/* 1514 */           if (log.isDebugEnabled()) {
/* 1515 */             log.error("Error al codificar el emisor en UTF-8. Se toma su valor con el charset original.", e1);
/*      */           }
/* 1517 */           issuerName = firmaCertificado.getIssuerDN().getName();
/*      */         }
/* 1519 */         if (log.isDebugEnabled()) {
/* 1520 */           log.debug("Certificado emisor: " + issuerName);
/*      */         }
/*      */         
/* 1523 */         elementoX509EmisorNombre.appendChild(doc.createTextNode(issuerName));
/*      */         
/*      */ 
/* 1526 */         Element elementoX509NumeroSerial = 
/* 1527 */           doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", this.xmldsigNS + ":" + "X509SerialNumber");
/* 1528 */         elementoX509NumeroSerial.appendChild(
/* 1529 */           doc.createTextNode(firmaCertificado.getSerialNumber().toString()));
/*      */         
/*      */ 
/* 1532 */         elementoEmisorSerial.appendChild(elementoX509EmisorNombre);
/* 1533 */         elementoEmisorSerial.appendChild(elementoX509NumeroSerial);
/*      */         
/* 1535 */         resumenElementoCert.appendChild(metodoResumenElemento);
/* 1536 */         resumenElementoCert.appendChild(elementDigestValue);
/*      */         
/* 1538 */         elementCertRef.appendChild(resumenElementoCert);
/* 1539 */         elementCertRef.appendChild(elementoEmisorSerial);
/*      */         
/* 1541 */         elementoCertRefs.appendChild(elementCertRef);
/*      */       }
/*      */     }
/*      */     
/* 1545 */     Element elementOCSPRef = null;
/* 1546 */     String tiempoRespuesta = null;
/* 1547 */     byte[] mensajeRespuesta = null;
/*      */     
/* 1549 */     if (size > 0)
/*      */     {
/*      */ 
/* 1552 */       Attr informacionElementoCertRef = doc.createAttributeNS(null, "Id");
/* 1553 */       this.idNodoRevocationRefs = UtilidadTratarNodo.newID(doc, "CompleteRevocationRefs");
/* 1554 */       informacionElementoCertRef.setValue(this.idNodoRevocationRefs);
/* 1555 */       revocacionesElementoFirma.getAttributes().setNamedItem(informacionElementoCertRef);
/*      */       
/* 1557 */       int nOCSPRefs = 0;
/* 1558 */       int nCRLRefs = 0;
/*      */       
/*      */ 
/*      */ 
/* 1562 */       Element elementOCSPRefs = 
/* 1563 */         doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "OCSPRefs");
/* 1564 */       CRLRefs elementCRLRefs = new CRLRefs(schema);
/*      */       
/* 1566 */       for (int x = 0; x < size; x++)
/*      */       {
/* 1568 */         RespYCerts respYCert = (RespYCerts)respuestas.get(x);
/* 1569 */         ICertStatus certStatus = respYCert.getCertstatus();
/* 1570 */         if ((certStatus instanceof IOCSPCertStatus)) {
/* 1571 */           nOCSPRefs++;
/* 1572 */           IOCSPCertStatus respOcsp = (IOCSPCertStatus)certStatus;
/*      */           
/* 1574 */           tiempoRespuesta = UtilidadFechas.formatFechaXML(respOcsp.getResponseDate());
/* 1575 */           IOCSPCertStatus.TYPE_RESPONDER tipoResponder = respOcsp.getResponderType();
/* 1576 */           String valorResponder = respOcsp.getResponderID();
/* 1577 */           mensajeRespuesta = respOcsp.getEncoded();
/*      */           
/* 1579 */           elementOCSPRef = doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "OCSPRef");
/*      */           
/*      */ 
/* 1582 */           String idNueva = UtilidadTratarNodo.newID(doc, "OCSP");
/* 1583 */           respYCert.setIdRespStatus(idNueva);
/*      */           
/* 1585 */           Element identificadorElementoOCSP = doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "OCSPIdentifier");
/* 1586 */           Attr uris = doc.createAttributeNS(null, tipoUri);
/* 1587 */           uris.setValue("#" + idNueva);
/* 1588 */           NamedNodeMap atributosURI = identificadorElementoOCSP.getAttributes();
/* 1589 */           atributosURI.setNamedItem(uris);
/*      */           
/*      */ 
/* 1592 */           Element elementoRespondedorId = doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "ResponderID");
/*      */           
/*      */ 
/* 1595 */           Element responderFinal = elementoRespondedorId;
/* 1596 */           if ((!"http://uri.etsi.org/01903/v1.1.1#".equals(this.xadesSchema)) && (!"http://uri.etsi.org/01903/v1.2.2#".equals(this.xadesSchema))) {
/* 1597 */             Element hijo = null;
/* 1598 */             if (tipoResponder.equals(IOCSPCertStatus.TYPE_RESPONDER.BY_NAME)) {
/* 1599 */               hijo = doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "ByName");
/*      */             }
/*      */             else {
/* 1602 */               hijo = doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "ByKey");
/*      */             }
/*      */             
/* 1605 */             elementoRespondedorId.appendChild(hijo);
/* 1606 */             responderFinal = hijo;
/*      */           }
/*      */           
/*      */           try
/*      */           {
/* 1611 */             valorResponder = new String(valorResponder.getBytes(), "UTF-8");
/*      */           } catch (UnsupportedEncodingException e1) {
/* 1613 */             if (log.isDebugEnabled()) {
/* 1614 */               log.debug(e1);
/*      */             }
/*      */             try {
/* 1617 */               valorResponder = URLEncoder.encode(valorResponder, "UTF-8");
/*      */             } catch (UnsupportedEncodingException e) {
/* 1619 */               throw new AddXadesException("No se pudo construir las referencias OCSP", e);
/*      */             }
/*      */           }
/*      */           
/* 1623 */           responderFinal.appendChild(doc.createTextNode(valorResponder));
/*      */           
/*      */ 
/* 1626 */           Element elementoProdujoEn = doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "ProducedAt");
/*      */           
/*      */ 
/* 1629 */           elementoProdujoEn.appendChild(doc.createTextNode(tiempoRespuesta));
/*      */           
/* 1631 */           identificadorElementoOCSP.appendChild(elementoRespondedorId);
/* 1632 */           identificadorElementoOCSP.appendChild(elementoProdujoEn);
/* 1633 */           Element valorYResumenElemento = doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "DigestAlgAndValue");
/*      */           
/*      */ 
/* 1636 */           Element metodoResumenElemento = doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", this.xmldsigNS + ":" + "DigestMethod");
/*      */           
/*      */ 
/* 1639 */           Attr propiedadesAlgoritmoFirmado = doc.createAttributeNS(null, "Algorithm");
/* 1640 */           propiedadesAlgoritmoFirmado.setValue(algDigestXML);
/* 1641 */           NamedNodeMap atributosMetodoResumenElemento = metodoResumenElemento.getAttributes();
/* 1642 */           atributosMetodoResumenElemento.setNamedItem(propiedadesAlgoritmoFirmado);
/*      */           
/*      */ 
/*      */ 
/* 1646 */           String digestCertificado = "";
/* 1647 */           MessageDigest resumenCertificadoTemp = UtilidadFirmaElectronica.getMessageDigest(algDigestXML);
/* 1648 */           if (resumenCertificadoTemp == null)
/* 1649 */             throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error20"));
/* 1650 */           byte[] resumenMensajeByte = resumenCertificadoTemp.digest(mensajeRespuesta);
/* 1651 */           digestCertificado = new String(Base64Coder.encode(resumenMensajeByte));
/*      */           
/* 1653 */           Element valorResumenElemento = doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", this.xmldsigNS + ":" + "DigestValue");
/*      */           
/* 1655 */           valorResumenElemento.appendChild(doc.createTextNode(digestCertificado));
/*      */           
/* 1657 */           valorYResumenElemento.appendChild(metodoResumenElemento);
/* 1658 */           valorYResumenElemento.appendChild(valorResumenElemento);
/*      */           
/* 1660 */           elementOCSPRef.appendChild(identificadorElementoOCSP);
/* 1661 */           elementOCSPRef.appendChild(valorYResumenElemento);
/*      */           
/* 1663 */           elementOCSPRefs.appendChild(elementOCSPRef);
/*      */         }
/* 1665 */         else if ((certStatus instanceof IX509CRLCertStatus)) {
/* 1666 */           nCRLRefs++;
/* 1667 */           IX509CRLCertStatus respCRL = (IX509CRLCertStatus)certStatus;
/*      */           try {
/* 1669 */             CRLRef crlRef = new CRLRef(schema, algDigestXML, respCRL.getX509CRL());
/*      */             
/* 1671 */             String idNueva = UtilidadTratarNodo.newID(doc, "CRL");
/* 1672 */             crlRef.getCrlIdentifier().setUri("#" + idNueva);
/* 1673 */             respYCert.setIdRespStatus(idNueva);
/*      */             
/* 1675 */             elementCRLRefs.addCRLRef(crlRef);
/*      */           } catch (InvalidInfoNodeException ex) {
/* 1677 */             throw new AddXadesException("No se pudo construir las referencias a CRLs", ex);
/*      */           }
/* 1679 */         } else if (log.isDebugEnabled()) {
/* 1680 */           log.debug("Se salta el elemento número " + x);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1685 */       if (nCRLRefs > 0) {
/*      */         try {
/* 1687 */           Element el = elementCRLRefs.createElement(doc, this.xmldsigNS, this.xadesNS);
/* 1688 */           revocacionesElementoFirma.appendChild(el);
/*      */         } catch (InvalidInfoNodeException ex) {
/* 1690 */           throw new AddXadesException("No se pudo construir las referencias a CRLs", ex);
/*      */         }
/*      */       }
/*      */       
/* 1694 */       if (nOCSPRefs > 0) {
/* 1695 */         revocacionesElementoFirma.appendChild(elementOCSPRefs);
/*      */       }
/*      */     }
/*      */     
/* 1699 */     elementoPrincipal.appendChild(certificadosElementosFirma);
/* 1700 */     elementoPrincipal.appendChild(revocacionesElementoFirma);
/*      */     
/* 1702 */     return doc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Document addXadesX(Element UnsignedSignatureProperties, ITimeStampGenerator timeStampGenerator)
/*      */     throws AddXadesException
/*      */   {
/* 1726 */     String tipoUri = null;
/* 1727 */     String nombreNodoUri = null;
/* 1728 */     if ("http://uri.etsi.org/01903/v1.1.1#".equals(this.xadesSchema)) {
/* 1729 */       nombreNodoUri = "HashDataInfo";
/* 1730 */       tipoUri = "uri";
/*      */     } else {
/* 1732 */       nombreNodoUri = "Include";
/* 1733 */       tipoUri = "URI";
/*      */     }
/*      */     
/*      */ 
/* 1737 */     Document doc = UnsignedSignatureProperties.getOwnerDocument();
/*      */     
/*      */ 
/* 1740 */     Node padre = UnsignedSignatureProperties.getParentNode();
/* 1741 */     for (int i = 0; i < 3; i++) {
/* 1742 */       if (padre != null) {
/* 1743 */         padre = padre.getParentNode();
/*      */       }
/*      */       else {
/* 1746 */         throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error33") + 
/* 1747 */           " " + "Signature");
/*      */       }
/*      */     }
/* 1750 */     Element signatureElement = null;
/* 1751 */     if ((padre != null) && ("Signature".equals(padre.getLocalName()))) {
/* 1752 */       signatureElement = (Element)padre;
/*      */     }
/*      */     else {
/* 1755 */       throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error33") + 
/* 1756 */         " " + "Signature");
/*      */     }
/*      */     
/* 1759 */     Element sigAndRefsTimeStampElement = 
/* 1760 */       doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "SigAndRefsTimeStamp");
/*      */     
/*      */ 
/* 1763 */     Attr informacionElementoSigTimeStamp = doc.createAttributeNS(null, "Id");
/* 1764 */     String idSelloTiempo = UtilidadTratarNodo.newID(doc, "SelloTiempo");
/* 1765 */     informacionElementoSigTimeStamp.setValue(idSelloTiempo);
/* 1766 */     this.idNodoSelloTiempo.add(idSelloTiempo);
/* 1767 */     sigAndRefsTimeStampElement.getAttributes().setNamedItem(informacionElementoSigTimeStamp);
/*      */     
/*      */ 
/* 1770 */     UnsignedSignatureProperties.appendChild(sigAndRefsTimeStampElement);
/*      */     
/*      */ 
/* 1773 */     ArrayList<Element> elementosSelloX = null;
/*      */     try {
/* 1775 */       elementosSelloX = UtilidadXadesX.obtenerListadoXADESX1imp(this.xadesSchema, signatureElement, sigAndRefsTimeStampElement);
/*      */     } catch (BadFormedSignatureException e) {
/* 1777 */       throw new AddXadesException(e.getMessage(), e);
/*      */     } catch (FirmaXMLError e) {
/* 1779 */       throw new AddXadesException(e.getMessage(), e);
/*      */     }
/*      */     
/*      */ 
/* 1783 */     if (("http://uri.etsi.org/01903/v1.1.1#".equals(this.xadesSchema)) || 
/* 1784 */       ("http://uri.etsi.org/01903/v1.2.2#".equals(this.xadesSchema)))
/*      */     {
/* 1786 */       ArrayList<String> elementosIdSelloX = UtilidadTratarNodo.obtenerIDs(elementosSelloX);
/*      */       
/*      */ 
/* 1789 */       ArrayList<Element> nodosUriReferencia = new ArrayList(elementosIdSelloX.size());
/* 1790 */       Iterator<String> itIds = elementosIdSelloX.iterator();
/* 1791 */       while (itIds.hasNext()) {
/* 1792 */         String id = (String)itIds.next();
/* 1793 */         Element uriNode = 
/* 1794 */           doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + nombreNodoUri);
/* 1795 */         Attr includeNodeUri = doc.createAttributeNS(null, tipoUri);
/* 1796 */         includeNodeUri.setValue("#" + id);
/* 1797 */         NamedNodeMap atributosNodo = uriNode.getAttributes();
/* 1798 */         atributosNodo.setNamedItem(includeNodeUri);
/*      */         
/* 1800 */         nodosUriReferencia.add(uriNode);
/*      */       }
/*      */       
/*      */ 
/* 1804 */       Iterator<Element> itUrisReferencia = nodosUriReferencia.iterator();
/* 1805 */       while (itUrisReferencia.hasNext()) {
/* 1806 */         Element includeNode = (Element)itUrisReferencia.next();
/* 1807 */         sigAndRefsTimeStampElement.appendChild(includeNode);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1812 */     byte[] byteData = null;
/*      */     try {
/* 1814 */       byteData = UtilidadTratarNodo.obtenerByte(elementosSelloX, CanonicalizationEnum.C14N_OMIT_COMMENTS);
/*      */     } catch (FirmaXMLError e) {
/* 1816 */       throw new AddXadesException(e.getMessage(), e);
/*      */     }
/*      */     
/* 1819 */     if (timeStampGenerator == null) {
/* 1820 */       throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error14"));
/*      */     }
/*      */     try {
/* 1823 */       byteData = timeStampGenerator.generateTimeStamp(byteData);
/*      */     } catch (TimeStampException e) {
/* 1825 */       throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error11") + e.getMessage());
/*      */     }
/* 1827 */     String hashSelloX = new String(Base64Coder.encode(byteData));
/*      */     
/*      */ 
/* 1830 */     if (!"http://uri.etsi.org/01903/v1.1.1#".equals(this.xadesSchema)) {
/* 1831 */       Element canonicalizationElemento = doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", this.xmldsigNS + ":" + "CanonicalizationMethod");
/* 1832 */       Attr canonicalizationAttribute = doc.createAttributeNS(null, "Algorithm");
/* 1833 */       canonicalizationAttribute.setValue("http://www.w3.org/TR/2001/REC-xml-c14n-20010315");
/* 1834 */       canonicalizationElemento.getAttributes().setNamedItem(canonicalizationAttribute);
/*      */       
/* 1836 */       sigAndRefsTimeStampElement.appendChild(canonicalizationElemento);
/*      */     }
/*      */     
/*      */ 
/* 1840 */     Element encapsulatedTimeStampNode = 
/* 1841 */       doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "EncapsulatedTimeStamp");
/* 1842 */     encapsulatedTimeStampNode.appendChild(doc.createTextNode(hashSelloX));
/* 1843 */     sigAndRefsTimeStampElement.appendChild(encapsulatedTimeStampNode);
/*      */     
/*      */ 
/* 1846 */     return doc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Document addXadesX2(Element UnsignedSignatureProperties, ITimeStampGenerator timeStampGenerator)
/*      */     throws AddXadesException
/*      */   {
/* 1868 */     String tipoUri = null;
/* 1869 */     String nombreNodoUri = null;
/* 1870 */     if ("http://uri.etsi.org/01903/v1.1.1#".equals(this.xadesSchema)) {
/* 1871 */       nombreNodoUri = "HashDataInfo";
/* 1872 */       tipoUri = "uri";
/*      */     } else {
/* 1874 */       nombreNodoUri = "Include";
/* 1875 */       tipoUri = "URI";
/*      */     }
/*      */     
/*      */ 
/* 1879 */     Document doc = UnsignedSignatureProperties.getOwnerDocument();
/*      */     
/*      */ 
/* 1882 */     Node padre = UnsignedSignatureProperties.getParentNode();
/* 1883 */     for (int i = 0; i < 3; i++) {
/* 1884 */       if (padre != null) {
/* 1885 */         padre = padre.getParentNode();
/*      */       }
/*      */       else {
/* 1888 */         throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error33") + 
/* 1889 */           " " + "Signature");
/*      */       }
/*      */     }
/* 1892 */     Element signatureElement = null;
/* 1893 */     if ((padre != null) && ("Signature".equals(padre.getLocalName()))) {
/* 1894 */       signatureElement = (Element)padre;
/*      */     }
/*      */     else {
/* 1897 */       throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error33") + 
/* 1898 */         " " + "Signature");
/*      */     }
/*      */     
/* 1901 */     Element refsOnlyTimeStampElement = 
/* 1902 */       doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "RefsOnlyTimeStamp");
/*      */     
/*      */ 
/* 1905 */     Attr informacionElementoSigTimeStamp = doc.createAttributeNS(null, "Id");
/* 1906 */     String idSelloTiempo = UtilidadTratarNodo.newID(doc, "SelloTiempo");
/* 1907 */     informacionElementoSigTimeStamp.setValue(idSelloTiempo);
/* 1908 */     this.idNodoSelloTiempo.add(idSelloTiempo);
/* 1909 */     refsOnlyTimeStampElement.getAttributes().setNamedItem(informacionElementoSigTimeStamp);
/*      */     
/*      */ 
/* 1912 */     UnsignedSignatureProperties.appendChild(refsOnlyTimeStampElement);
/*      */     
/*      */ 
/* 1915 */     ArrayList<Element> elementosSelloX = null;
/*      */     try {
/* 1917 */       elementosSelloX = UtilidadXadesX.obtenerListadoXADESX2exp(this.xadesSchema, signatureElement, refsOnlyTimeStampElement);
/*      */     } catch (BadFormedSignatureException e) {
/* 1919 */       throw new AddXadesException(e.getMessage(), e);
/*      */     } catch (FirmaXMLError e) {
/* 1921 */       throw new AddXadesException(e.getMessage(), e);
/*      */     }
/*      */     
/*      */ 
/* 1925 */     if (("http://uri.etsi.org/01903/v1.1.1#".equals(this.xadesSchema)) || 
/* 1926 */       ("http://uri.etsi.org/01903/v1.2.2#".equals(this.xadesSchema)))
/*      */     {
/* 1928 */       ArrayList<String> elementosIdSelloX = UtilidadTratarNodo.obtenerIDs(elementosSelloX);
/*      */       
/*      */ 
/* 1931 */       ArrayList<Element> nodosUriReferencia = new ArrayList(elementosIdSelloX.size());
/* 1932 */       Iterator<String> itIds = elementosIdSelloX.iterator();
/* 1933 */       while (itIds.hasNext()) {
/* 1934 */         String id = (String)itIds.next();
/* 1935 */         Element uriNode = 
/* 1936 */           doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + nombreNodoUri);
/* 1937 */         Attr includeNodeUri = doc.createAttributeNS(null, tipoUri);
/* 1938 */         includeNodeUri.setValue("#" + id);
/* 1939 */         NamedNodeMap atributosNodo = uriNode.getAttributes();
/* 1940 */         atributosNodo.setNamedItem(includeNodeUri);
/*      */         
/* 1942 */         nodosUriReferencia.add(uriNode);
/*      */       }
/*      */       
/*      */ 
/* 1946 */       Iterator<Element> itUrisReferencia = nodosUriReferencia.iterator();
/* 1947 */       while (itUrisReferencia.hasNext()) {
/* 1948 */         Element includeNode = (Element)itUrisReferencia.next();
/* 1949 */         refsOnlyTimeStampElement.appendChild(includeNode);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1954 */     byte[] byteData = null;
/*      */     try {
/* 1956 */       byteData = UtilidadTratarNodo.obtenerByte(elementosSelloX, CanonicalizationEnum.C14N_OMIT_COMMENTS);
/*      */     } catch (FirmaXMLError e) {
/* 1958 */       throw new AddXadesException(e.getMessage(), e);
/*      */     }
/*      */     
/*      */ 
/* 1962 */     if (timeStampGenerator == null) {
/* 1963 */       throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error14"));
/*      */     }
/*      */     try {
/* 1966 */       byteData = timeStampGenerator.generateTimeStamp(byteData);
/*      */     } catch (TimeStampException e) {
/* 1968 */       throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error11") + e.getMessage());
/*      */     }
/* 1970 */     String hashSelloX = new String(Base64Coder.encode(byteData));
/*      */     
/*      */ 
/* 1973 */     if (!"http://uri.etsi.org/01903/v1.1.1#".equals(this.xadesSchema)) {
/* 1974 */       Element canonicalizationElemento = doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", this.xmldsigNS + ":" + "CanonicalizationMethod");
/* 1975 */       Attr canonicalizationAttribute = doc.createAttributeNS(null, "Algorithm");
/* 1976 */       canonicalizationAttribute.setValue("http://www.w3.org/TR/2001/REC-xml-c14n-20010315");
/* 1977 */       canonicalizationElemento.getAttributes().setNamedItem(canonicalizationAttribute);
/*      */       
/* 1979 */       refsOnlyTimeStampElement.appendChild(canonicalizationElemento);
/*      */     }
/*      */     
/*      */ 
/* 1983 */     Element encapsulatedTimeStampNode = 
/* 1984 */       doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "EncapsulatedTimeStamp");
/* 1985 */     encapsulatedTimeStampNode.appendChild(doc.createTextNode(hashSelloX));
/* 1986 */     refsOnlyTimeStampElement.appendChild(encapsulatedTimeStampNode);
/*      */     
/*      */ 
/* 1989 */     return doc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Document addXadesXL(Element firma, ArrayList<RespYCerts> respuestas, XAdESSchemas schema)
/*      */     throws AddXadesException
/*      */   {
/* 2005 */     Document doc = firma.getOwnerDocument();
/* 2006 */     Element elementoPrincipal = null;
/*      */     
/* 2008 */     NodeList nodosUnsignedSignatureProperties = firma.getElementsByTagNameNS(schema.getSchemaUri(), "UnsignedSignatureProperties");
/* 2009 */     if (nodosUnsignedSignatureProperties.getLength() != 0) {
/* 2010 */       elementoPrincipal = (Element)nodosUnsignedSignatureProperties.item(0);
/*      */     }
/*      */     else {
/* 2013 */       throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error19"));
/*      */     }
/*      */     
/* 2016 */     if (respuestas != null) {
/* 2017 */       EncapsulatedX509Certificate encapsulatedX509certificate = null;
/* 2018 */       ArrayList<EncapsulatedX509Certificate> certs = new ArrayList();
/* 2019 */       Iterator<RespYCerts> itResp = respuestas.iterator();
/* 2020 */       boolean hasNext = itResp.hasNext();
/*      */       
/*      */ 
/*      */ 
/* 2024 */       if (hasNext) {
/* 2025 */         itResp.next();
/* 2026 */         hasNext = itResp.hasNext();
/*      */       }
/*      */       
/* 2029 */       while (hasNext) {
/* 2030 */         RespYCerts resp = (RespYCerts)itResp.next();
/* 2031 */         hasNext = itResp.hasNext();
/* 2032 */         encapsulatedX509certificate = new EncapsulatedX509Certificate(schema, resp.getIdCertificado());
/*      */         try {
/* 2034 */           encapsulatedX509certificate.setX509Certificate(resp.getCertstatus().getCertificate());
/*      */         } catch (CertificateException e) {
/* 2036 */           log.error(e.getMessage(), e);
/* 2037 */           throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error23"));
/*      */         }
/* 2039 */         certs.add(encapsulatedX509certificate);
/*      */       }
/*      */       
/* 2042 */       CertificateValues certificateValues = new CertificateValues(schema, certs);
/* 2043 */       Element certificateValuesElement = null;
/*      */       try {
/* 2045 */         certificateValuesElement = certificateValues.createElement(doc, this.xadesNS);
/*      */       } catch (InvalidInfoNodeException e) {
/* 2047 */         log.error(e.getMessage(), e);
/* 2048 */         throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error23"));
/*      */       }
/*      */       
/*      */ 
/* 2052 */       Attr atributoCertVal = doc.createAttributeNS(null, "Id");
/* 2053 */       String idCertVal = UtilidadTratarNodo.newID(doc, "CertificateValues");
/* 2054 */       atributoCertVal.setValue(idCertVal);
/* 2055 */       certificateValuesElement.getAttributes().setNamedItem(atributoCertVal);
/*      */       
/* 2057 */       elementoPrincipal.appendChild(certificateValuesElement);
/*      */       
/*      */ 
/* 2060 */       Element valoresElementosRevocados = 
/* 2061 */         doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "RevocationValues");
/*      */       
/* 2063 */       Element valorElementOCSP = 
/* 2064 */         doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "OCSPValues");
/*      */       
/* 2066 */       CRLValues valorElementoCRL = new CRLValues(schema);
/*      */       
/* 2068 */       int nOcspResps = 0;
/* 2069 */       int nCRLSResps = 0;
/* 2070 */       itResp = respuestas.iterator();
/* 2071 */       hasNext = itResp.hasNext();
/* 2072 */       while (hasNext) {
/* 2073 */         RespYCerts resp = (RespYCerts)itResp.next();
/* 2074 */         hasNext = itResp.hasNext();
/* 2075 */         ICertStatus respStatus = resp.getCertstatus();
/* 2076 */         if ((respStatus instanceof IOCSPCertStatus)) {
/* 2077 */           nOcspResps++;
/* 2078 */           IOCSPCertStatus respOCSP = (IOCSPCertStatus)respStatus;
/* 2079 */           Element valorElementoEncapsuladoOCSP = doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "EncapsulatedOCSPValue");
/* 2080 */           valorElementoEncapsuladoOCSP.appendChild(
/* 2081 */             doc.createTextNode(new String(Base64Coder.encode(respOCSP.getEncoded()))));
/* 2082 */           valorElementoEncapsuladoOCSP.setAttributeNS(null, "Id", resp.getIdRespStatus());
/* 2083 */           valorElementOCSP.appendChild(valorElementoEncapsuladoOCSP);
/*      */         }
/* 2085 */         else if ((respStatus instanceof IX509CRLCertStatus)) {
/* 2086 */           nCRLSResps++;
/* 2087 */           IX509CRLCertStatus respCRL = (IX509CRLCertStatus)respStatus;
/*      */           try {
/* 2089 */             valorElementoCRL.addCRL(respCRL.getX509CRL(), resp.getIdRespStatus());
/*      */           } catch (InvalidInfoNodeException ex) {
/* 2091 */             throw new AddXadesException("No se pudo generar nodo EncapsulatedCRLValue", ex);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 2096 */       if (nCRLSResps > 0) {
/*      */         try {
/* 2098 */           Element el = valorElementoCRL.createElement(doc, this.xadesNS);
/* 2099 */           valoresElementosRevocados.appendChild(el);
/*      */         } catch (InvalidInfoNodeException ex) {
/* 2101 */           throw new AddXadesException("No se pudo generar nodo CRLValues", ex);
/*      */         }
/*      */       }
/*      */       
/* 2105 */       if (nOcspResps > 0) {
/* 2106 */         valoresElementosRevocados.appendChild(valorElementOCSP);
/*      */       }
/*      */       
/* 2109 */       Attr atributoRevVal = doc.createAttributeNS(null, "Id");
/* 2110 */       String idRevVal = UtilidadTratarNodo.newID(doc, "RevocationValues");
/* 2111 */       atributoRevVal.setValue(idRevVal);
/* 2112 */       valoresElementosRevocados.getAttributes().setNamedItem(atributoRevVal);
/*      */       
/* 2114 */       elementoPrincipal.appendChild(valoresElementosRevocados);
/*      */     }
/*      */     
/* 2117 */     return doc;
/*      */   }
/*      */   
/*      */   private Document addXadesA(Element firma, byte[] selloTiempo, ArrayList<String> inc) throws Exception
/*      */   {
/* 2122 */     Document doc = firma.getOwnerDocument();
/*      */     
/* 2124 */     ArrayList<Element> unsignedSignaturePropertiesNodes = UtilidadTratarNodo.obtenerNodos(firma, 4, 
/* 2125 */       new NombreNodo(this.xadesSchema, "UnsignedSignatureProperties"));
/* 2126 */     Element unsignedSignaturePropertiesNode = null;
/* 2127 */     if (unsignedSignaturePropertiesNodes.size() == 1) {
/* 2128 */       unsignedSignaturePropertiesNode = (Element)unsignedSignaturePropertiesNodes.get(0);
/*      */     }
/*      */     else {
/* 2131 */       throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error19"));
/*      */     }
/* 2133 */     Element archiveTimeStamp = 
/* 2134 */       doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + "ArchiveTimeStamp");
/*      */     
/*      */ 
/* 2137 */     Attr archiveTimeStampId = doc.createAttributeNS(null, "Id");
/* 2138 */     archiveTimeStampId.setValue(UtilidadTratarNodo.newID(doc, 
/* 2139 */       "ArchiveTimeStamp-"));
/* 2140 */     NamedNodeMap archiveTimeStampAttributesElement = 
/* 2141 */       archiveTimeStamp.getAttributes();
/* 2142 */     archiveTimeStampAttributesElement.setNamedItem(archiveTimeStampId);
/*      */     
/*      */ 
/* 2145 */     Element encapsulatedTimeStamp = 
/* 2146 */       doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + 
/* 2147 */       "EncapsulatedTimeStamp");
/*      */     
/*      */ 
/* 2150 */     Attr informacionElementoSigTimeStamp = doc.createAttributeNS(null, "Id");
/* 2151 */     String idSelloTiempo = UtilidadTratarNodo.newID(doc, "SelloTiempo-Token");
/* 2152 */     informacionElementoSigTimeStamp.setValue(idSelloTiempo);
/* 2153 */     this.idNodoSelloTiempo.add(idSelloTiempo);
/* 2154 */     encapsulatedTimeStamp.getAttributes().setNamedItem(informacionElementoSigTimeStamp);
/*      */     
/*      */ 
/* 2157 */     Element canonicalizationElemento = doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", this.xmldsigNS + ":" + "CanonicalizationMethod");
/* 2158 */     Attr canonicalizationAttribute = doc.createAttributeNS(null, "Algorithm");
/* 2159 */     canonicalizationAttribute.setValue("http://www.w3.org/TR/2001/REC-xml-c14n-20010315");
/* 2160 */     canonicalizationElemento.getAttributes().setNamedItem(canonicalizationAttribute);
/*      */     
/* 2162 */     archiveTimeStamp.appendChild(canonicalizationElemento);
/*      */     
/* 2164 */     encapsulatedTimeStamp.appendChild(doc.createTextNode(new String(Base64Coder.encode(selloTiempo))));
/*      */     
/*      */ 
/* 2167 */     if (inc != null) {
/* 2168 */       Element includeNode = null;
/* 2169 */       for (int i = 0; i < inc.size(); i++) {
/* 2170 */         includeNode = doc.createElementNS(this.xadesSchema, this.xadesNS + ":" + 
/* 2171 */           "Include");
/* 2172 */         includeNode.setAttributeNS(null, "URI", (String)inc.get(i));
/* 2173 */         archiveTimeStamp.appendChild(includeNode);
/*      */       }
/*      */     }
/*      */     
/* 2177 */     archiveTimeStamp.appendChild(encapsulatedTimeStamp);
/*      */     
/*      */ 
/* 2180 */     unsignedSignaturePropertiesNode.appendChild(archiveTimeStamp);
/*      */     
/* 2182 */     return doc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String countersignFile(X509Certificate firmaCertificado, DataToSign xml, IPKStoreManager storeManager, String nodoAFirmarId, String destino, String nombreArchivo)
/*      */     throws Exception
/*      */   {
/* 2200 */     PrivateKey pk = storeManager.getPrivateKey(firmaCertificado);
/* 2201 */     Object[] res = countersign(firmaCertificado, xml, nodoAFirmarId, pk, storeManager.getProvider(firmaCertificado));
/*      */     
/*      */ 
/* 2204 */     File fichero = new File(destino, nombreArchivo);
/* 2205 */     FileOutputStream f2 = new FileOutputStream(fichero);
/*      */     try
/*      */     {
/* 2208 */       UtilidadFicheros.writeXML((Document)res[0], f2);
/* 2209 */       return (String)res[2];
/*      */     } catch (Throwable t) {
/* 2211 */       if ((t.getMessage() != null) && (t.getMessage().startsWith("Java heap space"))) {
/* 2212 */         throw new Exception(I18n.getResource("libreriaxades.firmaxml.error3"));
/*      */       }
/* 2214 */       throw new Exception(I18n.getResource("libreriaxades.firmaxml.error4"));
/*      */     } finally {
/* 2216 */       f2.close();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String countersign2Stream(X509Certificate firmaCertificado, DataToSign xml, IPKStoreManager storeManager, String nodoAFirmarId, OutputStream salida)
/*      */     throws Exception
/*      */   {
/* 2234 */     PrivateKey pk = storeManager.getPrivateKey(firmaCertificado);
/* 2235 */     Object[] res = countersign(firmaCertificado, xml, nodoAFirmarId, pk, storeManager.getProvider(firmaCertificado));
/*      */     
/*      */     try
/*      */     {
/* 2239 */       UtilidadFicheros.writeXML((Document)res[0], salida);
/* 2240 */       return (String)res[2];
/*      */     } catch (Throwable t) {
/* 2242 */       if ((t.getMessage() != null) && (t.getMessage().startsWith("Java heap space"))) {
/* 2243 */         throw new Exception(I18n.getResource("libreriaxades.firmaxml.error3"));
/*      */       }
/* 2245 */       throw new Exception(I18n.getResource("libreriaxades.firmaxml.error4"));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Object[] countersign(X509Certificate certificadoFirma, DataToSign xml, String nodoAFirmarId, PrivateKey pk, Provider provider)
/*      */     throws Exception
/*      */   {
/* 2263 */     Utils.addBCProvider();
/* 2264 */     Document doc = xml.getDocument();
/* 2265 */     if (doc == null) {
/*      */       try {
/* 2267 */         InputStream is = xml.getInputStream();
/* 2268 */         if (is != null) {
/* 2269 */           DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 2270 */           dbf.setNamespaceAware(true);
/* 2271 */           DocumentBuilder db = dbf.newDocumentBuilder();
/* 2272 */           db.setErrorHandler(new IgnoreAllErrorHandler());
/* 2273 */           InputSource isour = new InputSource(is);
/* 2274 */           doc = db.parse(isour);
/*      */         }
/*      */       }
/*      */       catch (IOException ex) {
/* 2278 */         throw new Exception(I18n.getResource("libreriaxades.firmaxml.error50"));
/*      */       }
/*      */     }
/* 2281 */     xml.setXMLEncoding(doc.getXmlEncoding());
/*      */     
/*      */ 
/* 2284 */     Node nodePadreNodoFirmar = null;
/* 2285 */     if (nodoAFirmarId != null) {
/* 2286 */       Element nodoAFirmar = UtilidadTratarNodo.getElementById(doc, nodoAFirmarId);
/* 2287 */       if (nodoAFirmar == null) {
/* 2288 */         log.error(I18n.getResource("libreriaxades.firmaxml.error33") + 
/* 2289 */           " " + nodoAFirmarId);
/* 2290 */         throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error51"));
/*      */       }
/*      */       
/*      */ 
/* 2294 */       if ("SignatureValue".equals(nodoAFirmar.getLocalName())) {
/* 2295 */         this.idSignatureValue = nodoAFirmarId;
/* 2296 */         nodePadreNodoFirmar = nodoAFirmar.getParentNode();
/* 2297 */       } else if ("Signature".equals(nodoAFirmar.getLocalName())) {
/* 2298 */         nodePadreNodoFirmar = nodoAFirmar;
/*      */       } else {
/* 2300 */         log.error(I18n.getResource("libreriaxades.firmaxml.error33") + 
/* 2301 */           " " + nodoAFirmarId);
/* 2302 */         throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error51"));
/*      */       }
/*      */     }
/*      */     else {
/* 2306 */       NodeList list = doc.getElementsByTagNameNS("http://www.w3.org/2000/09/xmldsig#", "Signature");
/* 2307 */       if (list.getLength() < 1) {
/* 2308 */         log.error(I18n.getResource("libreriaxades.firmaxml.error33") + 
/* 2309 */           " " + nodoAFirmarId);
/* 2310 */         throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error51"));
/*      */       }
/* 2312 */       nodePadreNodoFirmar = list.item(list.getLength() - 1);
/*      */     }
/*      */     
/* 2315 */     String idSignatureValue = null;
/* 2316 */     Element padreNodoFirmar = null;
/* 2317 */     if ((nodePadreNodoFirmar != null) && (nodePadreNodoFirmar.getNodeType() == 1)) {
/* 2318 */       padreNodoFirmar = (Element)nodePadreNodoFirmar;
/* 2319 */       ArrayList<Element> listElements = UtilidadTratarNodo.obtenerNodos(padreNodoFirmar, 2, new NombreNodo("http://www.w3.org/2000/09/xmldsig#", "SignatureValue"));
/* 2320 */       if (listElements.size() != 1)
/*      */       {
/* 2322 */         log.error(I18n.getResource("libreriaxades.firmaxml.error33") + 
/* 2323 */           " " + nodoAFirmarId);
/* 2324 */         throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error51"));
/*      */       }
/* 2326 */       idSignatureValue = ((Element)listElements.get(0)).getAttribute("Id");
/*      */       
/* 2328 */       if (idSignatureValue == null)
/*      */       {
/* 2330 */         log.error(I18n.getResource("libreriaxades.firmaxml.error33") + 
/* 2331 */           " " + nodoAFirmarId);
/* 2332 */         throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error51"));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2337 */     ArrayList<Element> listElements = UtilidadTratarNodo.obtenerNodos(padreNodoFirmar, 2, "QualifyingProperties");
/* 2338 */     if (listElements.size() != 1)
/*      */     {
/* 2340 */       log.error(I18n.getResource("libreriaxades.firmaxml.error33") + 
/* 2341 */         " " + nodoAFirmarId);
/* 2342 */       throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error51"));
/*      */     }
/* 2344 */     String esquemaOrigen = ((Element)listElements.get(0)).getNamespaceURI();
/* 2345 */     NodeList nodosUnsigSigProp = padreNodoFirmar.getElementsByTagNameNS(esquemaOrigen, 
/* 2346 */       "UnsignedSignatureProperties");
/*      */     
/* 2348 */     Element nodoRaiz = null;
/* 2349 */     if ((nodosUnsigSigProp != null) && (nodosUnsigSigProp.getLength() != 0)) {
/* 2350 */       nodoRaiz = (Element)nodosUnsigSigProp.item(0);
/*      */     } else {
/* 2352 */       NodeList nodosQualifying = padreNodoFirmar.getElementsByTagNameNS(esquemaOrigen, "QualifyingProperties");
/*      */       
/* 2354 */       if ((nodosQualifying != null) && (nodosQualifying.getLength() != 0)) {
/* 2355 */         Element nodoQualifying = (Element)nodosQualifying.item(0);
/* 2356 */         Element unsignedProperties = null;
/* 2357 */         if (nodoQualifying.getPrefix() != null) {
/* 2358 */           unsignedProperties = 
/* 2359 */             doc.createElementNS(esquemaOrigen, nodoQualifying.getPrefix() + 
/* 2360 */             ":" + "UnsignedProperties");
/* 2361 */           nodoRaiz = doc.createElementNS(esquemaOrigen, nodoQualifying.getPrefix() + 
/* 2362 */             ":" + "UnsignedSignatureProperties");
/*      */         } else {
/* 2364 */           unsignedProperties = 
/* 2365 */             doc.createElementNS(esquemaOrigen, "UnsignedProperties");
/* 2366 */           nodoRaiz = doc.createElementNS(esquemaOrigen, "UnsignedSignatureProperties");
/*      */         }
/*      */         
/* 2369 */         unsignedProperties.appendChild(nodoRaiz);
/* 2370 */         nodosQualifying.item(0).appendChild(unsignedProperties);
/*      */       } else {
/* 2372 */         throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error52"));
/*      */       }
/*      */     }
/*      */     
/* 2376 */     Element counterSignature = null;
/* 2377 */     if (nodoRaiz.getPrefix() != null) {
/* 2378 */       counterSignature = doc.createElementNS(esquemaOrigen, nodoRaiz.getPrefix() + 
/* 2379 */         ":" + "CounterSignature");
/*      */     } else {
/* 2381 */       counterSignature = doc.createElementNS(esquemaOrigen, "CounterSignature");
/*      */     }
/* 2383 */     nodoRaiz.appendChild(counterSignature);
/*      */     
/*      */ 
/* 2386 */     XAdESSchemas esquemaTemp = xml.getEsquema();
/* 2387 */     if (esquemaTemp != null) {
/* 2388 */       this.xadesSchema = esquemaTemp.getSchemaUri();
/*      */     } else {
/* 2390 */       this.xadesSchema = XAdESSchemas.XAdES_132.getSchemaUri();
/*      */     }
/*      */     
/*      */ 
/* 2394 */     Attr counterSignatureAttrib = doc.createAttributeNS(null, "Id");
/* 2395 */     String counterSignatureId = UtilidadTratarNodo.newID(doc, "CounterSignature-");
/* 2396 */     counterSignatureAttrib.setValue(counterSignatureId);
/* 2397 */     counterSignature.getAttributes().setNamedItem(counterSignatureAttrib);
/*      */     
/*      */ 
/* 2400 */     xml.setDocument(doc);
/*      */     
/*      */ 
/* 2403 */     AbstractObjectToSign obj = null;
/* 2404 */     if (XAdESSchemas.XAdES_132.getSchemaUri().equals(this.xadesSchema)) {
/* 2405 */       obj = new SignObjectToSign(idSignatureValue);
/*      */     } else {
/* 2407 */       obj = new InternObjectToSign(idSignatureValue);
/*      */     }
/*      */     
/* 2410 */     xml.addObject(new ObjectToSign(obj, null, null, null, null));
/*      */     
/*      */ 
/*      */ 
/* 2414 */     xml.setParentSignNode(counterSignatureId);
/* 2415 */     Object[] res = signFile(certificadoFirma, xml, pk, provider);
/*      */     
/*      */ 
/* 2418 */     counterSignature = UtilidadTratarNodo.getElementById(doc, counterSignatureId);
/* 2419 */     counterSignature.removeAttribute("Id");
/*      */     
/* 2421 */     return res;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getMilisDiffSigningTime(Element padre, String idNode)
/*      */   {
/*      */     try
/*      */     {
/* 2434 */       return getMilisDiffSigningTime(UtilidadTratarNodo.getElementById(padre, idNode));
/*      */     } catch (Exception e) {
/* 2436 */       log.warn("No se pudo obtener la fecha de la firma: " + e.getMessage(), e); }
/* 2437 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getMilisDiffSigningTime(Element node)
/*      */   {
/* 2449 */     if (node == null) {
/* 2450 */       log.debug("No se recibió ningun parámetro");
/* 2451 */       return 0L;
/*      */     }
/*      */     
/* 2454 */     Date fechaFirma = null;
/*      */     try {
/* 2456 */       ArrayList<Element> nodos = UtilidadTratarNodo.obtenerNodos(node, 5, "SigningTime");
/* 2457 */       if ((nodos != null) && (nodos.size() == 1)) {
/* 2458 */         String fecha = ((Element)nodos.get(0)).getFirstChild().getNodeValue();
/* 2459 */         if (fecha != null) {
/* 2460 */           fechaFirma = UtilidadFechas.parseaFechaXML(fecha);
/*      */         } else {
/* 2462 */           log.warn("No se pudo obtener la fecha del nodo");
/* 2463 */           return 0L;
/*      */         }
/*      */       }
/* 2466 */       long now = System.currentTimeMillis();
/*      */       
/* 2468 */       return now - fechaFirma.getTime();
/*      */     } catch (Exception e) {
/* 2470 */       log.warn("No se pudo obtener la fecha de la firma: " + e.getMessage(), e); }
/* 2471 */     return 0L;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public boolean raiseLevel(InputStream firma, EnumFormatoFirma nivelDeseado, String path, String nombreArchivo, String id, String ocspUrl, String tsaUrl, String trusterId)
/*      */     throws Exception
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_1
/*      */     //   1: ifnull +31 -> 32
/*      */     //   4: aload_2
/*      */     //   5: ifnull +27 -> 32
/*      */     //   8: aload_3
/*      */     //   9: ifnull +23 -> 32
/*      */     //   12: aload 4
/*      */     //   14: ifnull +18 -> 32
/*      */     //   17: aload 5
/*      */     //   19: ifnull +13 -> 32
/*      */     //   22: aload 6
/*      */     //   24: ifnull +8 -> 32
/*      */     //   27: aload 7
/*      */     //   29: ifnonnull +22 -> 51
/*      */     //   32: new 129	java/lang/Exception
/*      */     //   35: dup
/*      */     //   36: getstatic 49	es/mityc/firmaJava/libreria/xades/FirmaXML:i18n	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   39: ldc_w 2051
/*      */     //   42: invokeinterface 778 2 0
/*      */     //   47: invokespecial 195	java/lang/Exception:<init>	(Ljava/lang/String;)V
/*      */     //   50: athrow
/*      */     //   51: new 305	es/mityc/firmaJava/libreria/xades/DataToSign
/*      */     //   54: dup
/*      */     //   55: invokespecial 2053	es/mityc/firmaJava/libreria/xades/DataToSign:<init>	()V
/*      */     //   58: astore 9
/*      */     //   60: aload 9
/*      */     //   62: aload_2
/*      */     //   63: invokevirtual 2054	es/mityc/firmaJava/libreria/xades/DataToSign:setXadesFormat	(Les/mityc/javasign/EnumFormatoFirma;)V
/*      */     //   66: aload 9
/*      */     //   68: getstatic 2058	es/mityc/firmaJava/libreria/xades/DataToSign$XADES_X_TYPES:TYPE_1	Les/mityc/firmaJava/libreria/xades/DataToSign$XADES_X_TYPES;
/*      */     //   71: invokevirtual 2062	es/mityc/firmaJava/libreria/xades/DataToSign:setXAdESXType	(Les/mityc/firmaJava/libreria/xades/DataToSign$XADES_X_TYPES;)V
/*      */     //   74: aload 9
/*      */     //   76: aload_3
/*      */     //   77: invokevirtual 2066	es/mityc/firmaJava/libreria/xades/DataToSign:setBaseURI	(Ljava/lang/String;)V
/*      */     //   80: aload 9
/*      */     //   82: ldc -37
/*      */     //   84: invokevirtual 1947	es/mityc/firmaJava/libreria/xades/DataToSign:setXMLEncoding	(Ljava/lang/String;)V
/*      */     //   87: aload 9
/*      */     //   89: getstatic 378	es/mityc/firmaJava/libreria/xades/XAdESSchemas:XAdES_132	Les/mityc/firmaJava/libreria/xades/XAdESSchemas;
/*      */     //   92: invokevirtual 2069	es/mityc/firmaJava/libreria/xades/DataToSign:setEsquema	(Les/mityc/firmaJava/libreria/xades/XAdESSchemas;)V
/*      */     //   95: aload 9
/*      */     //   97: ldc_w 2072
/*      */     //   100: invokevirtual 2074	es/mityc/firmaJava/libreria/xades/DataToSign:setAlgDigestXmlDSig	(Ljava/lang/String;)V
/*      */     //   103: invokestatic 320	javax/xml/parsers/DocumentBuilderFactory:newInstance	()Ljavax/xml/parsers/DocumentBuilderFactory;
/*      */     //   106: astore 10
/*      */     //   108: aload 10
/*      */     //   110: iconst_1
/*      */     //   111: invokevirtual 325	javax/xml/parsers/DocumentBuilderFactory:setNamespaceAware	(Z)V
/*      */     //   114: aconst_null
/*      */     //   115: astore 11
/*      */     //   117: aload 10
/*      */     //   119: invokevirtual 329	javax/xml/parsers/DocumentBuilderFactory:newDocumentBuilder	()Ljavax/xml/parsers/DocumentBuilder;
/*      */     //   122: astore 12
/*      */     //   124: aload 12
/*      */     //   126: new 333	adsi/org/apache/xml/security/utils/IgnoreAllErrorHandler
/*      */     //   129: dup
/*      */     //   130: invokespecial 335	adsi/org/apache/xml/security/utils/IgnoreAllErrorHandler:<init>	()V
/*      */     //   133: invokevirtual 336	javax/xml/parsers/DocumentBuilder:setErrorHandler	(Lorg/xml/sax/ErrorHandler;)V
/*      */     //   136: aload_1
/*      */     //   137: ifnull +86 -> 223
/*      */     //   140: new 346	org/xml/sax/InputSource
/*      */     //   143: dup
/*      */     //   144: aload_1
/*      */     //   145: invokespecial 348	org/xml/sax/InputSource:<init>	(Ljava/io/InputStream;)V
/*      */     //   148: astore 13
/*      */     //   150: aload 13
/*      */     //   152: ldc -37
/*      */     //   154: invokevirtual 354	org/xml/sax/InputSource:setEncoding	(Ljava/lang/String;)V
/*      */     //   157: aload 12
/*      */     //   159: aload 13
/*      */     //   161: invokevirtual 357	javax/xml/parsers/DocumentBuilder:parse	(Lorg/xml/sax/InputSource;)Lorg/w3c/dom/Document;
/*      */     //   164: astore 11
/*      */     //   166: goto +57 -> 223
/*      */     //   169: astore 12
/*      */     //   171: new 129	java/lang/Exception
/*      */     //   174: dup
/*      */     //   175: ldc_w 364
/*      */     //   178: invokestatic 168	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   181: aload 12
/*      */     //   183: invokespecial 366	java/lang/Exception:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
/*      */     //   186: athrow
/*      */     //   187: astore 12
/*      */     //   189: new 129	java/lang/Exception
/*      */     //   192: dup
/*      */     //   193: ldc_w 364
/*      */     //   196: invokestatic 168	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   199: aload 12
/*      */     //   201: invokespecial 366	java/lang/Exception:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
/*      */     //   204: athrow
/*      */     //   205: astore 12
/*      */     //   207: new 129	java/lang/Exception
/*      */     //   210: dup
/*      */     //   211: ldc_w 364
/*      */     //   214: invokestatic 168	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   217: aload 12
/*      */     //   219: invokespecial 366	java/lang/Exception:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
/*      */     //   222: athrow
/*      */     //   223: aload 9
/*      */     //   225: aload 11
/*      */     //   227: invokevirtual 1969	es/mityc/firmaJava/libreria/xades/DataToSign:setDocument	(Lorg/w3c/dom/Document;)V
/*      */     //   230: aload 9
/*      */     //   232: new 2077	es/mityc/javasign/ts/HTTPTimeStampGenerator
/*      */     //   235: dup
/*      */     //   236: aload 7
/*      */     //   238: ldc_w 2079
/*      */     //   241: invokespecial 2081	es/mityc/javasign/ts/HTTPTimeStampGenerator:<init>	(Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   244: invokevirtual 2082	es/mityc/firmaJava/libreria/xades/DataToSign:setTimeStampGenerator	(Les/mityc/javasign/tsa/ITimeStampGenerator;)V
/*      */     //   247: invokestatic 2086	es/mityc/javasign/trust/TrustFactory:getInstance	()Les/mityc/javasign/trust/TrustFactory;
/*      */     //   250: aload 8
/*      */     //   252: invokevirtual 2091	es/mityc/javasign/trust/TrustFactory:getTruster	(Ljava/lang/String;)Les/mityc/javasign/trust/TrustAbstract;
/*      */     //   255: astore 12
/*      */     //   257: aload 12
/*      */     //   259: ifnonnull +12 -> 271
/*      */     //   262: getstatic 2095	java/lang/System:out	Ljava/io/PrintStream;
/*      */     //   265: ldc_w 2098
/*      */     //   268: invokevirtual 2100	java/io/PrintStream:println	(Ljava/lang/String;)V
/*      */     //   271: aload 9
/*      */     //   273: new 2105	es/mityc/javasign/certificate/ocsp/OCSPLiveConsultant
/*      */     //   276: dup
/*      */     //   277: aload 6
/*      */     //   279: aload 12
/*      */     //   281: invokespecial 2107	es/mityc/javasign/certificate/ocsp/OCSPLiveConsultant:<init>	(Ljava/lang/String;Les/mityc/javasign/trust/TrustAbstract;)V
/*      */     //   284: invokevirtual 2110	es/mityc/firmaJava/libreria/xades/DataToSign:setCertStatusManager	(Les/mityc/javasign/certificate/ICertStatusRecoverer;)V
/*      */     //   287: aload 9
/*      */     //   289: new 2114	es/mityc/javasign/xml/xades/LocalFileStoreElements
/*      */     //   292: dup
/*      */     //   293: invokespecial 2116	es/mityc/javasign/xml/xades/LocalFileStoreElements:<init>	()V
/*      */     //   296: invokevirtual 2117	es/mityc/firmaJava/libreria/xades/DataToSign:setElementsStorer	(Les/mityc/javasign/xml/xades/IStoreElements;)V
/*      */     //   299: aload 9
/*      */     //   301: aload_2
/*      */     //   302: invokevirtual 2054	es/mityc/firmaJava/libreria/xades/DataToSign:setXadesFormat	(Les/mityc/javasign/EnumFormatoFirma;)V
/*      */     //   305: aload_0
/*      */     //   306: aload 9
/*      */     //   308: aload 5
/*      */     //   310: invokevirtual 2121	es/mityc/firmaJava/libreria/xades/FirmaXML:raiseLevel	(Les/mityc/firmaJava/libreria/xades/DataToSign;Ljava/lang/String;)Lorg/w3c/dom/Document;
/*      */     //   313: astore 13
/*      */     //   315: aconst_null
/*      */     //   316: astore 14
/*      */     //   318: aconst_null
/*      */     //   319: astore 15
/*      */     //   321: new 208	java/io/File
/*      */     //   324: dup
/*      */     //   325: new 521	java/lang/StringBuilder
/*      */     //   328: dup
/*      */     //   329: aload_3
/*      */     //   330: invokestatic 636	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   333: invokespecial 525	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   336: aload 4
/*      */     //   338: invokevirtual 529	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   341: invokevirtual 533	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   344: invokespecial 2124	java/io/File:<init>	(Ljava/lang/String;)V
/*      */     //   347: astore 14
/*      */     //   349: new 212	java/io/FileOutputStream
/*      */     //   352: dup
/*      */     //   353: aload 14
/*      */     //   355: invokespecial 214	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
/*      */     //   358: astore 15
/*      */     //   360: aload 13
/*      */     //   362: aload 15
/*      */     //   364: invokestatic 176	es/mityc/firmaJava/libreria/utilidades/UtilidadFicheros:writeXML	(Lorg/w3c/dom/Document;Ljava/io/OutputStream;)V
/*      */     //   367: goto +87 -> 454
/*      */     //   370: astore 16
/*      */     //   372: aload 16
/*      */     //   374: invokevirtual 182	java/lang/Throwable:getMessage	()Ljava/lang/String;
/*      */     //   377: ifnull +29 -> 406
/*      */     //   380: aload 16
/*      */     //   382: invokevirtual 182	java/lang/Throwable:getMessage	()Ljava/lang/String;
/*      */     //   385: ldc -69
/*      */     //   387: invokevirtual 189	java/lang/String:startsWith	(Ljava/lang/String;)Z
/*      */     //   390: ifeq +16 -> 406
/*      */     //   393: new 164	es/mityc/firmaJava/libreria/errores/ClienteError
/*      */     //   396: dup
/*      */     //   397: ldc -63
/*      */     //   399: invokestatic 168	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   402: invokespecial 172	es/mityc/firmaJava/libreria/errores/ClienteError:<init>	(Ljava/lang/String;)V
/*      */     //   405: athrow
/*      */     //   406: new 164	es/mityc/firmaJava/libreria/errores/ClienteError
/*      */     //   409: dup
/*      */     //   410: ldc -60
/*      */     //   412: invokestatic 168	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   415: invokespecial 172	es/mityc/firmaJava/libreria/errores/ClienteError:<init>	(Ljava/lang/String;)V
/*      */     //   418: athrow
/*      */     //   419: astore 17
/*      */     //   421: aload 15
/*      */     //   423: ifnull +28 -> 451
/*      */     //   426: aload 15
/*      */     //   428: invokevirtual 289	java/io/FileOutputStream:close	()V
/*      */     //   431: goto +20 -> 451
/*      */     //   434: astore 18
/*      */     //   436: getstatic 39	es/mityc/firmaJava/libreria/xades/FirmaXML:log	Lorg/apache/commons/logging/Log;
/*      */     //   439: aload 18
/*      */     //   441: invokevirtual 2125	java/io/IOException:getMessage	()Ljava/lang/String;
/*      */     //   444: aload 18
/*      */     //   446: invokeinterface 691 3 0
/*      */     //   451: aload 17
/*      */     //   453: athrow
/*      */     //   454: aload 15
/*      */     //   456: ifnull +28 -> 484
/*      */     //   459: aload 15
/*      */     //   461: invokevirtual 289	java/io/FileOutputStream:close	()V
/*      */     //   464: goto +20 -> 484
/*      */     //   467: astore 18
/*      */     //   469: getstatic 39	es/mityc/firmaJava/libreria/xades/FirmaXML:log	Lorg/apache/commons/logging/Log;
/*      */     //   472: aload 18
/*      */     //   474: invokevirtual 2125	java/io/IOException:getMessage	()Ljava/lang/String;
/*      */     //   477: aload 18
/*      */     //   479: invokeinterface 691 3 0
/*      */     //   484: iconst_1
/*      */     //   485: ireturn
/*      */     // Line number table:
/*      */     //   Java source line #2490	-> byte code offset #0
/*      */     //   Java source line #2491	-> byte code offset #17
/*      */     //   Java source line #2492	-> byte code offset #32
/*      */     //   Java source line #2495	-> byte code offset #51
/*      */     //   Java source line #2498	-> byte code offset #60
/*      */     //   Java source line #2499	-> byte code offset #66
/*      */     //   Java source line #2502	-> byte code offset #74
/*      */     //   Java source line #2503	-> byte code offset #80
/*      */     //   Java source line #2504	-> byte code offset #87
/*      */     //   Java source line #2505	-> byte code offset #95
/*      */     //   Java source line #2508	-> byte code offset #103
/*      */     //   Java source line #2509	-> byte code offset #108
/*      */     //   Java source line #2510	-> byte code offset #114
/*      */     //   Java source line #2512	-> byte code offset #117
/*      */     //   Java source line #2513	-> byte code offset #124
/*      */     //   Java source line #2514	-> byte code offset #136
/*      */     //   Java source line #2515	-> byte code offset #140
/*      */     //   Java source line #2516	-> byte code offset #150
/*      */     //   Java source line #2517	-> byte code offset #157
/*      */     //   Java source line #2519	-> byte code offset #166
/*      */     //   Java source line #2520	-> byte code offset #171
/*      */     //   Java source line #2521	-> byte code offset #187
/*      */     //   Java source line #2522	-> byte code offset #189
/*      */     //   Java source line #2523	-> byte code offset #205
/*      */     //   Java source line #2524	-> byte code offset #207
/*      */     //   Java source line #2527	-> byte code offset #223
/*      */     //   Java source line #2530	-> byte code offset #230
/*      */     //   Java source line #2533	-> byte code offset #247
/*      */     //   Java source line #2534	-> byte code offset #257
/*      */     //   Java source line #2535	-> byte code offset #262
/*      */     //   Java source line #2537	-> byte code offset #271
/*      */     //   Java source line #2540	-> byte code offset #287
/*      */     //   Java source line #2541	-> byte code offset #299
/*      */     //   Java source line #2543	-> byte code offset #305
/*      */     //   Java source line #2546	-> byte code offset #315
/*      */     //   Java source line #2547	-> byte code offset #318
/*      */     //   Java source line #2550	-> byte code offset #321
/*      */     //   Java source line #2551	-> byte code offset #349
/*      */     //   Java source line #2552	-> byte code offset #360
/*      */     //   Java source line #2554	-> byte code offset #367
/*      */     //   Java source line #2555	-> byte code offset #370
/*      */     //   Java source line #2557	-> byte code offset #372
/*      */     //   Java source line #2558	-> byte code offset #393
/*      */     //   Java source line #2560	-> byte code offset #406
/*      */     //   Java source line #2561	-> byte code offset #419
/*      */     //   Java source line #2563	-> byte code offset #421
/*      */     //   Java source line #2564	-> byte code offset #426
/*      */     //   Java source line #2565	-> byte code offset #431
/*      */     //   Java source line #2566	-> byte code offset #436
/*      */     //   Java source line #2568	-> byte code offset #451
/*      */     //   Java source line #2563	-> byte code offset #454
/*      */     //   Java source line #2564	-> byte code offset #459
/*      */     //   Java source line #2565	-> byte code offset #464
/*      */     //   Java source line #2566	-> byte code offset #469
/*      */     //   Java source line #2570	-> byte code offset #484
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	486	0	this	FirmaXML
/*      */     //   0	486	1	firma	InputStream
/*      */     //   0	486	2	nivelDeseado	EnumFormatoFirma
/*      */     //   0	486	3	path	String
/*      */     //   0	486	4	nombreArchivo	String
/*      */     //   0	486	5	id	String
/*      */     //   0	486	6	ocspUrl	String
/*      */     //   0	486	7	tsaUrl	String
/*      */     //   0	486	8	trusterId	String
/*      */     //   58	249	9	data2Sign	DataToSign
/*      */     //   106	12	10	dbf	DocumentBuilderFactory
/*      */     //   115	111	11	docToRaise	Document
/*      */     //   122	36	12	db	DocumentBuilder
/*      */     //   169	13	12	e	IOException
/*      */     //   187	13	12	e	javax.xml.parsers.ParserConfigurationException
/*      */     //   205	13	12	e	org.xml.sax.SAXException
/*      */     //   255	25	12	truster	es.mityc.javasign.trust.TrustAbstract
/*      */     //   148	12	13	isour	InputSource
/*      */     //   313	48	13	doc	Document
/*      */     //   316	38	14	fichero	File
/*      */     //   319	141	15	f	FileOutputStream
/*      */     //   370	11	16	t	Throwable
/*      */     //   419	33	17	localObject	Object
/*      */     //   434	11	18	e	IOException
/*      */     //   467	11	18	e	IOException
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   117	166	169	java/io/IOException
/*      */     //   117	166	187	javax/xml/parsers/ParserConfigurationException
/*      */     //   117	166	205	org/xml/sax/SAXException
/*      */     //   321	367	370	java/lang/Throwable
/*      */     //   321	419	419	finally
/*      */     //   421	431	434	java/io/IOException
/*      */     //   454	464	467	java/io/IOException
/*      */   }
/*      */   
/*      */   public Document raiseLevel(DataToSign signData, String signatureID)
/*      */     throws ClienteError
/*      */   {
/* 2582 */     ArrayList<RespYCerts> respuestas = new ArrayList();
/* 2583 */     ArrayList<X509Certificate> certificadosConOCSP = new ArrayList();
/*      */     
/*      */ 
/* 2586 */     if ((signatureID == null) || (signData == null))
/*      */     {
/* 2588 */       throw new ClienteError(I18n.getResource("libreriaxades.firmaxml.error31"));
/*      */     }
/*      */     
/*      */ 
/* 2592 */     Document doc = signData.getDocument();
/*      */     
/*      */ 
/* 2595 */     EnumFormatoFirma nivelDeseado = signData.getXadesFormat();
/*      */     
/*      */ 
/* 2598 */     NodeList listaFirmas = doc.getElementsByTagNameNS("http://www.w3.org/2000/09/xmldsig#", "Signature");
/* 2599 */     int listaFirmasLength = listaFirmas.getLength();
/* 2600 */     if (listaFirmasLength < 1) {
/* 2601 */       log.error(I18n.getResource("libreriaxades.validarfirmaxml.error2"));
/*      */       
/* 2603 */       throw new ClienteError(I18n.getResource("libreriaxades.validarfirmaxml.error2"));
/*      */     }
/* 2605 */     Element signature = null;
/* 2606 */     if (signatureID.equals(""))
/*      */     {
/* 2608 */       signature = (Element)listaFirmas.item(listaFirmasLength - 1);
/*      */     } else {
/* 2610 */       signature = UtilidadTratarNodo.getElementById(doc, signatureID);
/*      */     }
/*      */     
/* 2613 */     if (signature == null)
/*      */     {
/* 2615 */       log.error(I18n.getResource("libreriaxades.firmaxml.error49") + 
/* 2616 */         " " + listaFirmasLength);
/* 2617 */       throw new ClienteError(I18n.getResource("libreriaxades.validarfirmaxml.error2"));
/*      */     }
/*      */     
/*      */ 
/* 2621 */     if (!new NombreNodo("http://www.w3.org/2000/09/xmldsig#", "Signature").equals(new NombreNodo(signature.getNamespaceURI(), signature.getLocalName())))
/*      */     {
/* 2623 */       throw new ClienteError(I18n.getResource("libreriaxades.firmaxml.error33") + 
/* 2624 */         " " + "Signature");
/*      */     }
/*      */     
/*      */ 
/* 2628 */     Element certificateNode = (Element)signature.getElementsByTagNameNS(
/* 2629 */       "http://www.w3.org/2000/09/xmldsig#", "X509Certificate").item(0);
/* 2630 */     byte[] certificateContent = Base64Coder.decode(certificateNode.getFirstChild().getNodeValue());
/* 2631 */     X509Certificate certificate = null;
/*      */     try {
/* 2633 */       certificate = (X509Certificate)CertificateFactory.getInstance("X.509")
/* 2634 */         .generateCertificate(new ByteArrayInputStream(certificateContent));
/*      */     } catch (CertificateException e) {
/* 2636 */       log.error(e.getMessage(), e);
/* 2637 */       throw new ClienteError(I18n.getResource("libreriaxades.firmaxml.error6"), e);
/*      */     }
/*      */     
/*      */ 
/* 2641 */     ResultadoValidacion resultado = null;
/*      */     try {
/* 2643 */       ValidarFirmaXML validacion = new ValidarFirmaXML();
/* 2644 */       resultado = validacion.validar(signature, 
/* 2645 */         signature.getBaseURI(), 
/* 2646 */         null);
/*      */       
/* 2648 */       this.xadesSchema = resultado.getDatosFirma().getEsquema().getSchemaUri();
/*      */     } catch (Exception e) {
/* 2650 */       throw new ClienteError(e.getMessage(), e);
/*      */     }
/*      */     
/* 2653 */     if ((resultado != null) && (resultado.getDatosFirma() != null) && (
/* 2654 */       (resultado.isValidate()) || (resultado.getDatosFirma().getDatosNodosNoSignFirmados().size() > 0)))
/*      */     {
/*      */ 
/*      */ 
/* 2658 */       ArrayList<EnumFormatoFirma> mejora = new ArrayList();
/* 2659 */       EnumFormatoFirma nivel = resultado.getEnumNivel();
/* 2660 */       if ((nivel == null) && (resultado.getDatosFirma().getDatosNodosNoSignFirmados().size() > 0)) {
/* 2661 */         nivel = EnumFormatoFirma.XAdES_BES;
/*      */       }
/*      */       
/* 2664 */       while (!nivelDeseado.equals(nivel))
/*      */       {
/*      */ 
/* 2667 */         if (EnumFormatoFirma.XAdES_BES.equals(nivel)) {
/* 2668 */           nivel = EnumFormatoFirma.XAdES_T;
/* 2669 */         } else if (EnumFormatoFirma.XAdES_T.equals(nivel)) {
/* 2670 */           nivel = EnumFormatoFirma.XAdES_C;
/* 2671 */         } else if (EnumFormatoFirma.XAdES_C.equals(nivel)) {
/* 2672 */           nivel = EnumFormatoFirma.XAdES_X;
/* 2673 */         } else { if (!EnumFormatoFirma.XAdES_X.equals(nivel)) break;
/* 2674 */           nivel = EnumFormatoFirma.XAdES_XL;
/*      */         }
/*      */         
/*      */ 
/* 2678 */         mejora.add(nivel);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2684 */       boolean isXadesXL = mejora.contains(EnumFormatoFirma.XAdES_XL);
/*      */       
/*      */ 
/* 2687 */       Iterator<EnumFormatoFirma> niveles = mejora.iterator();
/* 2688 */       boolean hasNext = niveles.hasNext();
/* 2689 */       byte[] selloTiempo = null;
/* 2690 */       label1476: while (hasNext) {
/* 2691 */         nivel = (EnumFormatoFirma)niveles.next();
/* 2692 */         hasNext = niveles.hasNext();
/*      */         
/* 2694 */         if (EnumFormatoFirma.XAdES_T.equals(nivel)) {
/*      */           try {
/* 2696 */             ITimeStampGenerator timeStampGenerator = signData.getTimeStampGenerator();
/* 2697 */             if (timeStampGenerator == null) {
/* 2698 */               throw new ClienteError(I18n.getResource("libreriaxades.firmaxml.error6"));
/*      */             }
/*      */             try
/*      */             {
/* 2702 */               byte[] byteSignature = UtilidadTratarNodo.obtenerByteNodo(signature, "http://www.w3.org/2000/09/xmldsig#", "SignatureValue", CanonicalizationEnum.C14N_OMIT_COMMENTS, 5);
/* 2703 */               selloTiempo = timeStampGenerator.generateTimeStamp(byteSignature);
/* 2704 */               addXadesT(signature, signatureID, selloTiempo);
/*      */             } catch (FirmaXMLError e) {
/* 2706 */               log.error(e.getMessage(), e);
/* 2707 */               throw new ClienteError(I18n.getResource("libreriaxades.firmaxml.error6"), e);
/*      */             } catch (TimeStampException e) {
/* 2709 */               log.error(e.getMessage(), e);
/* 2710 */               throw new ClienteError(I18n.getResource("libreriaxades.firmaxml.error6"), e);
/*      */             }
/*      */           }
/*      */           catch (AddXadesException e) {
/* 2714 */             log.error(e.getMessage(), e);
/* 2715 */             throw new ClienteError(I18n.getResource("libreriaxades.firmaxml.error7") + e.getMessage(), e);
/*      */           }
/* 2717 */         } else if (EnumFormatoFirma.XAdES_C.equals(nivel)) {
/*      */           try {
/* 2719 */             log.info(i18n.getLocalMessage("i18n.mityc.xades.validate.18"));
/* 2720 */             convertICertStatus2RespYCerts(signData.getCertStatusManager().getCertChainStatus(certificate), certificadosConOCSP, respuestas);
/*      */             
/*      */ 
/* 2723 */             if (log.isDebugEnabled()) {
/* 2724 */               log.debug("Se incluyen las referencias OCSP de la propia VA");
/*      */             }
/*      */             
/*      */ 
/*      */             try
/*      */             {
/* 2730 */               IOCSPCertStatus respOcsp = (IOCSPCertStatus)((RespYCerts)respuestas.get(0)).getCertstatus();
/* 2731 */               OCSPResp resp = new OCSPResp(respOcsp.getEncoded());
/* 2732 */               BasicOCSPResp respuestaBasica = (BasicOCSPResp)resp.getResponseObject();
/* 2733 */               convertICertStatus2RespYCerts(getOCSPfromOCSP(respuestaBasica, certificadosConOCSP, null, signData), certificadosConOCSP, respuestas);
/*      */             } catch (CertStatusException ec) {
/* 2735 */               log.error(ec);
/* 2736 */               throw new ClienteChainNotFoundError(ec, "OCSP");
/*      */             } catch (Exception e1) {
/* 2738 */               log.error(e1);
/* 2739 */               throw new ClienteError(e1);
/*      */             }
/*      */             
/* 2742 */             if (log.isDebugEnabled()) {
/* 2743 */               log.debug("Se incluyen las referencias OCSP del sello de tiempo");
/*      */             }
/* 2745 */             TimeStampToken tst = null;
/*      */             try
/*      */             {
/* 2748 */               if (selloTiempo == null) {
/* 2749 */                 ArrayList<Element> nodosSignatureTimeStamp = UtilidadTratarNodo.obtenerNodos(signature, 6, 
/* 2750 */                   new NombreNodo(signData.getEsquema().getSchemaUri(), "SignatureTimeStamp"));
/* 2751 */                 Element nodoSigTimeStamp = (Element)nodosSignatureTimeStamp.get(0);
/* 2752 */                 NodeList nodesEncapsulatedTimeStamp = nodoSigTimeStamp.getElementsByTagNameNS(signData.getEsquema().getSchemaUri(), "EncapsulatedTimeStamp");
/* 2753 */                 Element encapsulatedTimeStampElement = (Element)nodesEncapsulatedTimeStamp.item(0);
/*      */                 
/*      */ 
/*      */ 
/* 2757 */                 String encapsulatedTS = encapsulatedTimeStampElement.getFirstChild().getNodeValue();
/* 2758 */                 selloTiempo = Base64.decode(encapsulatedTS);
/*      */               }
/*      */               
/* 2761 */               tst = new TimeStampToken(new CMSSignedData(selloTiempo));
/*      */             }
/*      */             catch (CMSException e) {
/*      */               try {
/* 2765 */                 TimeStampResponse tsr = new TimeStampResponse(selloTiempo);
/* 2766 */                 tst = tsr.getTimeStampToken();
/*      */               } catch (Exception ex) {
/* 2768 */                 log.error(ex);
/* 2769 */                 throw new ClienteError(ex);
/*      */               }
/*      */             } catch (Exception e) {
/* 2772 */               log.error(e);
/* 2773 */               throw new ClienteError(e);
/*      */             }
/* 2775 */             X509Certificate certTSA = null;
/*      */             try {
/* 2777 */               CertStore cs = tst.getCertificatesAndCRLs("Collection", null);
/* 2778 */               Collection<? extends Certificate> certs = cs.getCertificates(null);
/* 2779 */               if ((certs != null) && (certs.size() > 0)) {
/* 2780 */                 if (log.isDebugEnabled()) {
/* 2781 */                   log.debug("Se regenera la cadena de certificados firmante del sello de tiempo y se lanza su validación");
/*      */                 }
/*      */                 Certificate cert;
/*      */                 try {
/* 2785 */                   Iterable<X509Certificate> iterableCerts = null;
/* 2786 */                   if ((certs instanceof Iterable)) {
/* 2787 */                     iterableCerts = certs;
/*      */                   } else {
/* 2789 */                     throw new Exception("El certificado no es del tipo esperado: " + certs.getClass());
/*      */                   }
/* 2791 */                   CertPath cpTsa = UtilidadCertificados.orderCertPath(iterableCerts);
/* 2792 */                   certTSA = (X509Certificate)cpTsa.getCertificates().get(0);
/*      */                 }
/*      */                 catch (Exception e) {
/* 2795 */                   cert = (Certificate)certs.iterator().next();
/* 2796 */                   if (!(cert instanceof X509Certificate)) break label1476; }
/* 2797 */                 certTSA = (X509Certificate)cert;
/*      */               }
/*      */               else
/*      */               {
/* 2801 */                 log.error("No se pudo recuperar el certificado del sello de tiempo");
/* 2802 */                 throw new ClienteError("No se pudo recuperar el certificado del sello de tiempo");
/*      */               }
/*      */             } catch (Exception e) {
/* 2805 */               log.error(e);
/* 2806 */               throw new ClienteError(e);
/*      */             }
/*      */             
/* 2809 */             if (certTSA != null) {
/*      */               try {
/* 2811 */                 if (log.isDebugEnabled()) {
/* 2812 */                   log.debug("Certificado de TSA obtenido " + certTSA.getSubjectX500Principal());
/*      */                 }
/* 2814 */                 ArrayList<RespYCerts> respuestasTSA = new ArrayList();
/*      */                 
/* 2816 */                 if (certificadosConOCSP.contains(certTSA.getIssuerX500Principal())) {
/* 2817 */                   ICertStatus respTSA = signData.getCertStatusManager().getCertStatus(certTSA);
/* 2818 */                   ArrayList<ICertStatus> re = new ArrayList(1);
/* 2819 */                   re.add(respTSA);
/* 2820 */                   convertICertStatus2RespYCerts(re, certificadosConOCSP, respuestasTSA);
/*      */                 } else {
/* 2822 */                   convertICertStatus2RespYCerts(signData.getCertStatusManager().getCertChainStatus(certTSA), certificadosConOCSP, respuestasTSA);
/*      */                 }
/*      */                 
/* 2825 */                 respuestas.addAll(respuestasTSA);
/*      */                 
/* 2827 */                 if (log.isDebugEnabled()) {
/* 2828 */                   log.debug("TSA Validada. Se valida la VA del propio sello");
/*      */                 }
/*      */                 try {
/* 2831 */                   if (respuestasTSA.size() > 0) {
/* 2832 */                     IOCSPCertStatus respOcspTsa = (IOCSPCertStatus)((RespYCerts)respuestasTSA.get(0)).getCertstatus();
/* 2833 */                     OCSPResp resp = new OCSPResp(respOcspTsa.getEncoded());
/* 2834 */                     BasicOCSPResp respuestaBasica = (BasicOCSPResp)resp.getResponseObject();
/*      */                     
/* 2836 */                     convertICertStatus2RespYCerts(getOCSPfromOCSP(respuestaBasica, certificadosConOCSP, null, signData), certificadosConOCSP, respuestas);
/*      */                   } else {
/* 2838 */                     log.error("No se ha podido obtener información de revocación de la cadena del sello de tiempo.");
/* 2839 */                     throw new ClienteError("No se ha podido obtener información de revocación de la cadena del sello de tiempo.");
/*      */                   }
/*      */                 } catch (CertStatusException ec) {
/* 2842 */                   log.error(ec);
/* 2843 */                   throw new ClienteChainNotFoundError(ec, "OCSP");
/*      */                 } catch (Exception e1) {
/* 2845 */                   log.error(e1);
/* 2846 */                   throw new ClienteError(e1);
/*      */                 }
/*      */               } catch (CertStatusException e) {
/* 2849 */                 log.error(e.getMessage(), e);
/* 2850 */                 throw new ClienteChainNotFoundError(I18n.getResource("libreriaxades.firmaxml.error10"), e, "TSA");
/*      */               }
/*      */             }
/*      */           }
/*      */           catch (CertStatusException e) {
/* 2855 */             log.error(e.getMessage(), e);
/* 2856 */             throw new ClienteChainNotFoundError(I18n.getResource("libreriaxades.firmaxml.error10"), e, "FIRMANTE");
/*      */           }
/*      */           
/*      */ 
/* 2860 */           String algDigestXML = signData.getAlgDigestXmlDSig() != null ? signData.getAlgDigestXmlDSig() : "http://www.w3.org/2000/09/xmldsig#sha1";
/*      */           try
/*      */           {
/* 2863 */             addXadesC(signature, respuestas, XAdESSchemas.getXAdESSchema(this.xadesSchema), algDigestXML);
/*      */           } catch (AddXadesException e) {
/* 2865 */             log.error(I18n.getResource("libreriaxades.firmaxml.error10") + e.getMessage(), e);
/* 2866 */             throw new ClienteError(I18n.getResource("libreriaxades.firmaxml.error10") + e.getMessage(), e);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 2871 */           if (!isXadesXL) {
/*      */             try {
/* 2873 */               doc = addURIXadesC(signature, saveOCSPFiles(respuestas, signData.getElementsStorer()), signData.getBaseURI());
/*      */             } catch (FirmaXMLError ex) {
/* 2875 */               log.error("Error al guardar ficheros de estados de certificados", ex);
/* 2876 */               throw new ClienteError("Error al guardar ficheros de estados de certificados", ex);
/*      */             }
/*      */           }
/* 2879 */         } else if (EnumFormatoFirma.XAdES_X.equals(nivel))
/*      */         {
/*      */ 
/* 2882 */           Element unsignedSignaturePropertiesElement = null;
/* 2883 */           NodeList unsignedSignaturePropertiesNodes = 
/* 2884 */             signature.getElementsByTagNameNS(this.xadesSchema, "UnsignedSignatureProperties");
/*      */           
/* 2886 */           if (unsignedSignaturePropertiesNodes.getLength() < 1)
/*      */           {
/* 2888 */             log.error(I18n.getResource("libreriaxades.firmaxml.error36") + " " + 
/* 2889 */               "UnsignedSignatureProperties" + " " + 
/* 2890 */               I18n.getResource("libreriaxades.firmaxml.error37") + " " + 
/* 2891 */               unsignedSignaturePropertiesNodes.getLength());
/*      */             
/* 2893 */             throw new ClienteError(I18n.getResource("libreriaxades.firmaxml.error41"));
/*      */           }
/* 2895 */           unsignedSignaturePropertiesElement = (Element)unsignedSignaturePropertiesNodes.item(0);
/*      */           
/*      */           try
/*      */           {
/* 2899 */             addXadesX(unsignedSignaturePropertiesElement, signData.getTimeStampGenerator());
/*      */           } catch (AddXadesException e) {
/* 2901 */             log.error(e.getMessage(), e);
/* 2902 */             throw new ClienteError(I18n.getResource("libreriaxades.firmaxml.error12") + e.getMessage());
/*      */           }
/*      */         }
/* 2905 */         else if (EnumFormatoFirma.XAdES_XL.equals(nivel)) {
/*      */           try {
/* 2907 */             addXadesXL(signature, respuestas, XAdESSchemas.getXAdESSchema(this.xadesSchema));
/*      */           } catch (Exception e) {
/* 2909 */             log.error(e.getMessage(), e);
/* 2910 */             throw new ClienteError(I18n.getResource("libreriaxades.firmaxml.error12") + e.getMessage());
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2917 */     return doc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private List<ICertStatus> getOCSPfromOCSP(BasicOCSPResp respuestaBasica, List<X509Certificate> certificadosConOCSP, List<X500Principal> certificadosAnteriores, DataToSign signData)
/*      */     throws CertStatusException, NoSuchProviderException, OCSPException
/*      */   {
/* 2932 */     if (log.isDebugEnabled()) {
/* 2933 */       ResponderID respID = respuestaBasica.getResponderId().toASN1Object();
/* 2934 */       log.debug("Extracción del certificado OCSP: " + ASN1Utils.getResponderID(respID).toString());
/*      */     }
/* 2936 */     if (certificadosAnteriores == null) {
/* 2937 */       certificadosAnteriores = new ArrayList();
/* 2938 */       for (X509Certificate currentCert : certificadosConOCSP) {
/* 2939 */         certificadosAnteriores.add(currentCert.getSubjectX500Principal());
/*      */       }
/*      */     }
/* 2942 */     List<ICertStatus> re = new ArrayList();
/*      */     
/* 2944 */     X509Certificate[] ocspCerts = respuestaBasica.getCerts("SUN");
/* 2945 */     if ((ocspCerts != null) && (ocspCerts.length > 0)) {
/* 2946 */       if (log.isDebugEnabled()) {
/* 2947 */         log.debug("Se regenera la cadena y se lanza la validación");
/*      */       }
/* 2949 */       CertPath cpOcsp = UtilidadCertificados.orderCertPath(Arrays.asList(ocspCerts));
/* 2950 */       X509Certificate ocspCert = (X509Certificate)cpOcsp.getCertificates().get(0);
/*      */       
/* 2952 */       if ((!certificadosConOCSP.contains(ocspCert)) && (!certificadosAnteriores.contains(ocspCert.getSubjectX500Principal()))) {
/* 2953 */         if (!certificadosAnteriores.contains(ocspCert.getIssuerX500Principal())) {
/* 2954 */           re = signData.getCertStatusManager().getCertChainStatus(ocspCert);
/*      */         } else {
/* 2956 */           ICertStatus respOCSP = signData.getCertStatusManager().getCertStatus(ocspCert);
/* 2957 */           re = new ArrayList(1);
/* 2958 */           re.add(respOCSP);
/*      */         }
/*      */         
/*      */ 
/* 2962 */         if ((re == null) || (re.size() == 0) || (re.get(0) == null)) {
/* 2963 */           log.error("No se ha podido obtener respuestas de validación para la cadena de certificación de: " + ocspCert.getSubjectX500Principal() + ". La cadena tiene: " + (cpOcsp.getCertificates() != null ? cpOcsp.getCertificates().size() : 0));
/* 2964 */           throw new CertStatusException("No se ha podido obtener respuestas de validación para la cadena de certificación de: " + ocspCert.getSubjectX500Principal() + ". La cadena tiene: " + (cpOcsp.getCertificates() != null ? cpOcsp.getCertificates().size() : 0));
/*      */         }
/*      */         
/* 2967 */         certificadosAnteriores.add(ocspCert.getSubjectX500Principal());
/* 2968 */         X509Certificate newOCSPCert = ((ICertStatus)re.get(0)).getCertificate();
/* 2969 */         if ((!certificadosConOCSP.contains(newOCSPCert)) && (!certificadosAnteriores.contains(newOCSPCert.getSubjectX500Principal()))) {
/* 2970 */           re.addAll(getOCSPfromOCSP(respuestaBasica, certificadosConOCSP, certificadosAnteriores, signData));
/*      */         }
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 2976 */       log.error("No se pudo recuperar el certificado de la VA del OCSP");
/* 2977 */       throw new CertStatusException("No se pudo recuperar el certificado de la VA del OCSP");
/*      */     }
/* 2979 */     return re;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Document addURIXadesC(Element firma, ArrayList<NombreElementos> listaArchivos, String baseUri)
/*      */     throws FirmaXMLError
/*      */   {
/* 2993 */     Document doc = firma.getOwnerDocument();
/*      */     
/* 2995 */     NodeList completeCertificateRefs = null;
/* 2996 */     NodeList completeRevocationRefs = null;
/*      */     
/*      */ 
/* 2999 */     completeCertificateRefs = firma.getElementsByTagNameNS(this.xadesSchema, "CompleteCertificateRefs");
/* 3000 */     completeRevocationRefs = firma.getElementsByTagNameNS(this.xadesSchema, "CompleteRevocationRefs");
/*      */     
/* 3002 */     if ((completeCertificateRefs.getLength() == 0) || (completeRevocationRefs.getLength() == 0)) {
/* 3003 */       log.error(I18n.getResource("libreriaxades.firmaxml.error29"));
/* 3004 */       return doc;
/*      */     }
/*      */     
/* 3007 */     String tipoUri = null;
/* 3008 */     if ("http://uri.etsi.org/01903/v1.1.1#".equals(this.xadesSchema)) {
/* 3009 */       tipoUri = "uri";
/*      */     } else {
/* 3011 */       tipoUri = "URI";
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3016 */     NodeList ocspRefs = null;
/* 3017 */     NodeList crlRefs = null;
/*      */     try {
/* 3019 */       ArrayList<Element> listOcspRefs = UtilidadTratarNodo.obtenerNodos((Element)completeRevocationRefs.item(0), null, new NombreNodo(this.xadesSchema, "OCSPRefs"));
/* 3020 */       ArrayList<Element> listCRLRefs = UtilidadTratarNodo.obtenerNodos((Element)completeRevocationRefs.item(0), null, new NombreNodo(this.xadesSchema, "CRLRefs"));
/* 3021 */       if (listOcspRefs.size() > 1) {
/* 3022 */         throw new FirmaXMLError("hay demasiados elementos ocsprefs");
/*      */       }
/* 3024 */       if (listCRLRefs.size() > 1) {
/* 3025 */         throw new FirmaXMLError("hay demasiados elementos crlrefs");
/*      */       }
/* 3027 */       if (listOcspRefs.size() > 0)
/* 3028 */         ocspRefs = ((Element)listOcspRefs.get(0)).getChildNodes();
/* 3029 */       if (listCRLRefs.size() > 0)
/* 3030 */         crlRefs = ((Element)listCRLRefs.get(0)).getChildNodes();
/*      */     } catch (FirmaXMLError ex) {
/* 3032 */       throw new FirmaXMLError("error obteniendo elementos ocsprefs y crlrefs");
/*      */     }
/*      */     
/*      */ 
/* 3036 */     Iterator<NombreElementos> it = listaArchivos.iterator();
/* 3037 */     int indexOCSP = 0;
/* 3038 */     int indexCRL = 0;
/* 3039 */     while (it.hasNext()) {
/* 3040 */       NombreElementos nf = (NombreElementos)it.next();
/* 3041 */       if (it.hasNext()) {
/* 3042 */         String nameFile = nf.getNameFileCRLResp();
/*      */         Node el;
/* 3044 */         Node el; if (nameFile == null) {
/* 3045 */           nameFile = nf.getNameFileOCSPResp();
/* 3046 */           if (nameFile == null)
/* 3047 */             throw new FirmaXMLError("Fichero de status (OCSP o CRL) sin nombre");
/* 3048 */           if ((ocspRefs == null) || (ocspRefs.getLength() <= indexOCSP))
/* 3049 */             throw new FirmaXMLError("Fichero de status no relacionable con crlref");
/* 3050 */           el = ((Element)ocspRefs.item(indexOCSP++)).getElementsByTagNameNS(this.xadesSchema, "OCSPIdentifier").item(0);
/*      */         }
/*      */         else {
/* 3053 */           if ((crlRefs == null) || (crlRefs.getLength() <= indexCRL))
/* 3054 */             throw new FirmaXMLError("Fichero de status no relacionable con crlref");
/* 3055 */           el = ((Element)crlRefs.item(indexCRL++)).getElementsByTagNameNS(this.xadesSchema, "CRLIdentifier").item(0);
/*      */         }
/* 3057 */         Attr uri = doc.createAttributeNS(null, tipoUri);
/* 3058 */         uri.setValue(nameFile);
/*      */         
/* 3060 */         NamedNodeMap nodo = el.getAttributes();
/* 3061 */         nodo.setNamedItem(uri);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 3066 */     Node certRefs = completeCertificateRefs.item(0).getFirstChild();
/*      */     
/*      */ 
/* 3069 */     if (certRefs != null)
/*      */     {
/*      */ 
/* 3072 */       NodeList certs = certRefs.getChildNodes();
/* 3073 */       int l = certs.getLength();
/*      */       
/* 3075 */       if (l != listaArchivos.size() - 1) {
/* 3076 */         log.error(I18n.getResource("libreriaxades.firmaxml.error30"));
/*      */       }
/*      */       
/* 3079 */       for (int i = 0; i < l; i++)
/*      */       {
/*      */ 
/* 3082 */         Node certificado = certs.item(i);
/* 3083 */         if (certificado != null)
/*      */         {
/*      */ 
/* 3086 */           Attr uri = doc.createAttributeNS(null, tipoUri);
/* 3087 */           uri.setValue(((NombreElementos)listaArchivos.get(i + 1)).getNameFileX509Cert());
/*      */           
/* 3089 */           NamedNodeMap nodoCertificado = certificado.getAttributes();
/* 3090 */           nodoCertificado.setNamedItem(uri);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3095 */     return doc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ArrayList<NombreElementos> saveOCSPFiles(ArrayList<RespYCerts> respuesta, IStoreElements storer)
/*      */   {
/* 3104 */     ArrayList<NombreElementos> listaArchivos = new ArrayList();
/*      */     
/* 3106 */     if ((respuesta != null) && (respuesta.size() > 0)) {
/* 3107 */       int i = 0;
/* 3108 */       Iterator<RespYCerts> it = respuesta.iterator();
/* 3109 */       while (it.hasNext()) {
/* 3110 */         RespYCerts respAndCert = (RespYCerts)it.next();
/*      */         
/*      */ 
/* 3113 */         X509Certificate certificate = null;
/* 3114 */         String certFile = null;
/* 3115 */         if (i > 0) {
/* 3116 */           certFile = respAndCert.getX509CertFile();
/* 3117 */           if ((certFile == null) || (certFile.trim().length() == 0)) {
/* 3118 */             certificate = respAndCert.getCertstatus().getCertificate();
/*      */           }
/*      */         }
/* 3121 */         ICertStatus respCert = null;
/* 3122 */         if (i < respuesta.size() - 1) {
/* 3123 */           respCert = respAndCert.getCertstatus();
/*      */         }
/*      */         
/* 3126 */         String[] names = storer.storeCertAndStatus(certificate, respCert);
/*      */         
/* 3128 */         NombreElementos nombreElemento = new NombreElementos();
/* 3129 */         if ((certFile != null) && (certFile.trim().length() > 0)) {
/* 3130 */           nombreElemento.setNameFileX509Cert(certFile);
/*      */         } else {
/* 3132 */           nombreElemento.setNameFileX509Cert(names[0]);
/*      */         }
/* 3134 */         if ((respCert instanceof IOCSPCertStatus)) {
/* 3135 */           nombreElemento.setNameFileOCSPResp(names[1]);
/* 3136 */         } else if ((respCert instanceof IX509CRLCertStatus)) {
/* 3137 */           nombreElemento.setNameFileCRLResp(names[1]);
/*      */         }
/* 3139 */         listaArchivos.add(nombreElemento);
/*      */         
/* 3141 */         i++;
/*      */       }
/*      */     } else {
/* 3144 */       log.error(I18n.getResource("libreriaxades.firmaxml.error27"));
/* 3145 */       return null;
/*      */     }
/*      */     
/* 3148 */     return listaArchivos;
/*      */   }
/*      */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\FirmaXML.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */