/*    */ package es.mityc.firmaJava.libreria.utilidades;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class I18n
/*    */ {
/* 31 */   private static Locale locale = new Locale("es", "es".toUpperCase());
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String getResource(String clave)
/*    */   {
/* 41 */     return getResource(clave, locale);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String getResource(String clave, Locale locale)
/*    */   {
/* 53 */     return ResourceBundle.getBundle("i18n_libreriaXADES", locale).getString(clave);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Locale getLocale()
/*    */   {
/* 63 */     return locale;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void setLocale(String pais, String dialecto)
/*    */   {
/* 74 */     locale = new Locale(pais, dialecto);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\utilidades\I18n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */