/*    */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MimeType
/*    */   extends AbstractXadesStringElement
/*    */ {
/*    */   public MimeType(XAdESSchemas schema, String data)
/*    */   {
/* 32 */     super(schema, "MimeType", data);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public MimeType(XAdESSchemas schema)
/*    */   {
/* 40 */     super(schema, "MimeType");
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\MimeType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */