/*      */ package es.mityc.firmaJava.libreria.xades;
/*      */ 
/*      */ import adsi.org.apache.xml.security.Init;
/*      */ import adsi.org.apache.xml.security.algorithms.MessageDigestAlgorithm;
/*      */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*      */ import adsi.org.apache.xml.security.signature.Reference;
/*      */ import adsi.org.apache.xml.security.signature.SignedInfo;
/*      */ import adsi.org.apache.xml.security.signature.XMLSignature;
/*      */ import adsi.org.apache.xml.security.signature.XMLSignatureException;
/*      */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*      */ import adsi.org.apache.xml.security.transforms.Transforms;
/*      */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolverSpi;
/*      */ import es.mityc.firmaJava.libreria.utilidades.Base64;
/*      */ import es.mityc.firmaJava.libreria.utilidades.I18n;
/*      */ import es.mityc.firmaJava.libreria.utilidades.NombreNodo;
/*      */ import es.mityc.firmaJava.libreria.utilidades.URIEncoder;
/*      */ import es.mityc.firmaJava.libreria.utilidades.UtilidadCertificados;
/*      */ import es.mityc.firmaJava.libreria.utilidades.UtilidadCertificados.Filter;
/*      */ import es.mityc.firmaJava.libreria.utilidades.UtilidadFechas;
/*      */ import es.mityc.firmaJava.libreria.utilidades.UtilidadFicheros;
/*      */ import es.mityc.firmaJava.libreria.utilidades.UtilidadFirmaElectronica;
/*      */ import es.mityc.firmaJava.libreria.utilidades.UtilidadTratarNodo;
/*      */ import es.mityc.firmaJava.libreria.utilidades.Utilidades;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.Cert;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.CertDigest;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.CertificateValues;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.DataObjectFormat;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.Description;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.EncapsulatedX509Certificate;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.Encoding;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.EncodingEnum;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.Identifier;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.IssuerSerial;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.MimeType;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SigPolicyHash;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SigPolicyId;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SignaturePolicyId;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SignaturePolicyIdentifier;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SigningTime;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xmldsig.DigestMethod;
/*      */ import es.mityc.firmaJava.libreria.xades.elementos.xmldsig.DigestValue;
/*      */ import es.mityc.firmaJava.libreria.xades.errores.BadFormedSignatureException;
/*      */ import es.mityc.firmaJava.libreria.xades.errores.FirmaXMLError;
/*      */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*      */ import es.mityc.firmaJava.ocsp.RespuestaOCSP;
/*      */ import es.mityc.firmaJava.trust.ConfianzaEnum;
/*      */ import es.mityc.javasign.EnumFormatoFirma;
/*      */ import es.mityc.javasign.asn1.ASN1Utils;
/*      */ import es.mityc.javasign.certificate.CertStatusException;
/*      */ import es.mityc.javasign.certificate.ElementNotFoundException;
/*      */ import es.mityc.javasign.certificate.ICertStatus;
/*      */ import es.mityc.javasign.certificate.ICertStatus.CERT_STATUS;
/*      */ import es.mityc.javasign.certificate.ICertStatusRecoverer;
/*      */ import es.mityc.javasign.certificate.IOCSPCertStatus;
/*      */ import es.mityc.javasign.certificate.IOCSPCertStatus.TYPE_RESPONDER;
/*      */ import es.mityc.javasign.certificate.IRecoverElements;
/*      */ import es.mityc.javasign.certificate.OCSPResponderID;
/*      */ import es.mityc.javasign.certificate.RevokedInfo;
/*      */ import es.mityc.javasign.certificate.UnknownElementClassException;
/*      */ import es.mityc.javasign.certificate.ocsp.OCSPStatus;
/*      */ import es.mityc.javasign.i18n.I18nFactory;
/*      */ import es.mityc.javasign.i18n.II18nManager;
/*      */ import es.mityc.javasign.trust.NotTrustedException;
/*      */ import es.mityc.javasign.trust.TrustAbstract;
/*      */ import es.mityc.javasign.trust.TrustException;
/*      */ import es.mityc.javasign.trust.UnknownTrustException;
/*      */ import es.mityc.javasign.ts.TSPAlgoritmos;
/*      */ import es.mityc.javasign.tsa.ITimeStampValidator;
/*      */ import es.mityc.javasign.tsa.TSValidationResult;
/*      */ import es.mityc.javasign.tsa.TimeStampException;
/*      */ import es.mityc.javasign.utils.Utils;
/*      */ import es.mityc.javasign.xml.resolvers.IPrivateData;
/*      */ import es.mityc.javasign.xml.resolvers.IResourceData;
/*      */ import es.mityc.javasign.xml.resolvers.MITyCResourceResolver;
/*      */ import es.mityc.javasign.xml.resolvers.ResolverPrivateData;
/*      */ import es.mityc.javasign.xml.resolvers.XAdESResourceResolverSpi;
/*      */ import es.mityc.javasign.xml.xades.ReferenceProxy;
/*      */ import es.mityc.javasign.xml.xades.policy.IValidacionPolicy;
/*      */ import es.mityc.javasign.xml.xades.policy.PoliciesManager;
/*      */ import es.mityc.javasign.xml.xades.policy.PoliciesManager.PolicyKey;
/*      */ import es.mityc.javasign.xml.xades.policy.PolicyResult;
/*      */ import es.mityc.javasign.xml.xades.policy.PolicyResult.DownloadPolicy;
/*      */ import es.mityc.javasign.xml.xades.policy.PolicyResult.StatusValidation;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.math.BigInteger;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.net.URLDecoder;
/*      */ import java.security.MessageDigest;
/*      */ import java.security.NoSuchProviderException;
/*      */ import java.security.Principal;
/*      */ import java.security.Security;
/*      */ import java.security.cert.CRLException;
/*      */ import java.security.cert.CertPath;
/*      */ import java.security.cert.CertificateEncodingException;
/*      */ import java.security.cert.CertificateException;
/*      */ import java.security.cert.CertificateExpiredException;
/*      */ import java.security.cert.CertificateFactory;
/*      */ import java.security.cert.CertificateNotYetValidException;
/*      */ import java.security.cert.X509CRL;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import javax.security.auth.x500.X500Principal;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.bouncycastle.asn1.ASN1InputStream;
/*      */ import org.bouncycastle.asn1.DERInteger;
/*      */ import org.bouncycastle.asn1.DEROctetString;
/*      */ import org.bouncycastle.asn1.ocsp.ResponderID;
/*      */ import org.bouncycastle.cms.CMSException;
/*      */ import org.bouncycastle.cms.CMSSignedData;
/*      */ import org.bouncycastle.jce.X509Principal;
/*      */ import org.bouncycastle.ocsp.BasicOCSPResp;
/*      */ import org.bouncycastle.ocsp.CertificateID;
/*      */ import org.bouncycastle.ocsp.CertificateStatus;
/*      */ import org.bouncycastle.ocsp.OCSPException;
/*      */ import org.bouncycastle.ocsp.OCSPResp;
/*      */ import org.bouncycastle.ocsp.RespID;
/*      */ import org.bouncycastle.ocsp.RevokedStatus;
/*      */ import org.bouncycastle.ocsp.SingleResp;
/*      */ import org.bouncycastle.ocsp.UnknownStatus;
/*      */ import org.bouncycastle.tsp.TSPException;
/*      */ import org.bouncycastle.tsp.TimeStampToken;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.NamedNodeMap;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ValidarFirmaXML
/*      */ {
/*  167 */   private List<String> esquemasParaValidar = new LinkedList();
/*      */   
/*  169 */   private boolean esValido = false;
/*  170 */   private ResultadoValidacion resultado = new ResultadoValidacion();
/*  171 */   private DatosFirma datosFirma = null;
/*  172 */   private ArrayList<DatosSelloTiempo> arrayDatosSello = null;
/*  173 */   private ArrayList<DatosCRL> arrayDatosCRL = null;
/*  174 */   private ArrayList<DatosOCSP> arrayDatosOCSP = null;
/*  175 */   private ArrayList<PolicyResult> politicas = new ArrayList();
/*  176 */   private ArrayList<X509Certificate> cadenaCertificados = new ArrayList();
/*  177 */   private ArrayList<String> firmados = null;
/*      */   
/*  179 */   private DatosTipoFirma tipoDocFirma = null;
/*      */   
/*  181 */   private String uriXmlNS = null;
/*      */   
/*  183 */   private String nombreNodoUri = "Include";
/*  184 */   private String tipoUri = "URI";
/*      */   
/*  186 */   private static final Log LOGGER = LogFactory.getLog(ValidarFirmaXML.class);
/*  187 */   private static final II18nManager i18n = I18nFactory.getI18nManager("MITyCLibXAdES");
/*      */   
/*  189 */   private IRecoverElements recoverManager = null;
/*  190 */   private ArrayList<ResourceResolverSpi> resolvers = null;
/*  191 */   private ITimeStampValidator tsValidator = null;
/*  192 */   private TrustAbstract truster = null;
/*      */   
/*      */ 
/*      */ 
/*      */   private static final String TSA_REVOCKED = "i18n.mityc.xades.validate.tsa.error.1";
/*      */   
/*      */ 
/*      */ 
/*      */   private static final String TSA_REVOCKED_NO_DATE = "i18n.mityc.xades.validate.tsa.error.2";
/*      */   
/*      */ 
/*      */   private static final String OCSP_REVOCKED = "i18n.mityc.xades.validate.ocsp.error.1";
/*      */   
/*      */ 
/*      */   private static final String OCSP_REVOCKED_NO_DATE = "i18n.mityc.xades.validate.ocsp.error.2";
/*      */   
/*      */ 
/*      */ 
/*      */   public ValidarFirmaXML()
/*      */   {
/*  212 */     setXAdESSchema(XAdESSchemas.XAdES_111, true);
/*  213 */     setXAdESSchema(XAdESSchemas.XAdES_122, true);
/*  214 */     setXAdESSchema(XAdESSchemas.XAdES_132, true);
/*  215 */     setXAdESSchema(XAdESSchemas.XMLDSIG, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRecoverElements(IRecoverElements recoverManager)
/*      */   {
/*  225 */     this.recoverManager = recoverManager;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addResolver(IPrivateData resolver)
/*      */   {
/*  234 */     addResolver(new ResolverPrivateData(resolver));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addResolver(MITyCResourceResolver resolver)
/*      */   {
/*  243 */     if (this.resolvers == null) {
/*  244 */       this.resolvers = new ArrayList();
/*      */     }
/*  246 */     this.resolvers.add(resolver);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addResolver(IResourceData resolver)
/*      */   {
/*  255 */     addResolver(new XAdESResourceResolverSpi(resolver));
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public List<ResultadoValidacion> validar(File firmaParaValidar, ExtraValidators validators, ITimeStampValidator tsValidator)
/*      */     throws FirmaXMLError
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aconst_null
/*      */     //   1: astore 4
/*      */     //   3: new 188	java/io/FileInputStream
/*      */     //   6: dup
/*      */     //   7: aload_1
/*      */     //   8: invokespecial 190	java/io/FileInputStream:<init>	(Ljava/io/File;)V
/*      */     //   11: astore 4
/*      */     //   13: goto +20 -> 33
/*      */     //   16: astore 5
/*      */     //   18: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   21: ldc -63
/*      */     //   23: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   26: invokeinterface 201 2 0
/*      */     //   31: aconst_null
/*      */     //   32: areturn
/*      */     //   33: aconst_null
/*      */     //   34: astore 5
/*      */     //   36: aconst_null
/*      */     //   37: astore 6
/*      */     //   39: aload_0
/*      */     //   40: aload 4
/*      */     //   42: aload_1
/*      */     //   43: invokevirtual 207	java/io/File:getParentFile	()Ljava/io/File;
/*      */     //   46: invokevirtual 213	java/io/File:toURI	()Ljava/net/URI;
/*      */     //   49: invokevirtual 217	java/net/URI:toString	()Ljava/lang/String;
/*      */     //   52: aload_2
/*      */     //   53: aload_3
/*      */     //   54: invokevirtual 223	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:validar	(Ljava/io/InputStream;Ljava/lang/String;Les/mityc/firmaJava/libreria/xades/ExtraValidators;Les/mityc/javasign/tsa/ITimeStampValidator;)Ljava/util/List;
/*      */     //   57: astore 6
/*      */     //   59: goto +37 -> 96
/*      */     //   62: astore 7
/*      */     //   64: aload 7
/*      */     //   66: astore 5
/*      */     //   68: aload 4
/*      */     //   70: invokevirtual 226	java/io/FileInputStream:close	()V
/*      */     //   73: goto +33 -> 106
/*      */     //   76: astore 9
/*      */     //   78: goto +28 -> 106
/*      */     //   81: astore 8
/*      */     //   83: aload 4
/*      */     //   85: invokevirtual 226	java/io/FileInputStream:close	()V
/*      */     //   88: goto +5 -> 93
/*      */     //   91: astore 9
/*      */     //   93: aload 8
/*      */     //   95: athrow
/*      */     //   96: aload 4
/*      */     //   98: invokevirtual 226	java/io/FileInputStream:close	()V
/*      */     //   101: goto +5 -> 106
/*      */     //   104: astore 9
/*      */     //   106: aload 5
/*      */     //   108: ifnull +6 -> 114
/*      */     //   111: aload 5
/*      */     //   113: athrow
/*      */     //   114: aload 6
/*      */     //   116: areturn
/*      */     // Line number table:
/*      */     //   Java source line #268	-> byte code offset #0
/*      */     //   Java source line #270	-> byte code offset #3
/*      */     //   Java source line #271	-> byte code offset #13
/*      */     //   Java source line #272	-> byte code offset #18
/*      */     //   Java source line #273	-> byte code offset #31
/*      */     //   Java source line #276	-> byte code offset #33
/*      */     //   Java source line #277	-> byte code offset #36
/*      */     //   Java source line #279	-> byte code offset #39
/*      */     //   Java source line #280	-> byte code offset #59
/*      */     //   Java source line #281	-> byte code offset #64
/*      */     //   Java source line #284	-> byte code offset #68
/*      */     //   Java source line #285	-> byte code offset #73
/*      */     //   Java source line #282	-> byte code offset #81
/*      */     //   Java source line #284	-> byte code offset #83
/*      */     //   Java source line #285	-> byte code offset #88
/*      */     //   Java source line #286	-> byte code offset #93
/*      */     //   Java source line #284	-> byte code offset #96
/*      */     //   Java source line #285	-> byte code offset #101
/*      */     //   Java source line #288	-> byte code offset #106
/*      */     //   Java source line #289	-> byte code offset #111
/*      */     //   Java source line #291	-> byte code offset #114
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	117	0	this	ValidarFirmaXML
/*      */     //   0	117	1	firmaParaValidar	File
/*      */     //   0	117	2	validators	ExtraValidators
/*      */     //   0	117	3	tsValidator	ITimeStampValidator
/*      */     //   1	96	4	fis	java.io.FileInputStream
/*      */     //   16	3	5	e	java.io.FileNotFoundException
/*      */     //   34	78	5	excepcion	FirmaXMLError
/*      */     //   37	78	6	rs	List<ResultadoValidacion>
/*      */     //   62	3	7	ex	FirmaXMLError
/*      */     //   81	13	8	localObject	Object
/*      */     //   76	1	9	localException	Exception
/*      */     //   91	1	9	localException1	Exception
/*      */     //   104	1	9	localException2	Exception
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   3	13	16	java/io/FileNotFoundException
/*      */     //   39	59	62	es/mityc/firmaJava/libreria/xades/errores/FirmaXMLError
/*      */     //   68	73	76	java/lang/Exception
/*      */     //   39	68	81	finally
/*      */     //   83	88	91	java/lang/Exception
/*      */     //   96	101	104	java/lang/Exception
/*      */   }
/*      */   
/*      */   public List<ResultadoValidacion> validar(byte[] bFirmaParaValidar, ExtraValidators validators, ITimeStampValidator tsValidator)
/*      */     throws FirmaXMLError
/*      */   {
/*  305 */     LOGGER.debug(I18n.getResource("libreriaxades.validarfirmaxml.info2") + " " + 
/*  306 */       System.getProperty("user.dir"));
/*  307 */     File dir = new File(System.getProperty("user.dir"));
/*  308 */     return validar(bFirmaParaValidar, dir.toURI().toString(), validators, tsValidator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<ResultadoValidacion> validar(byte[] bFirmaParaValidar, String baseUri, ExtraValidators validators, ITimeStampValidator tsValidator)
/*      */     throws FirmaXMLError
/*      */   {
/*  322 */     ByteArrayInputStream bis = null;
/*      */     
/*  324 */     bis = new ByteArrayInputStream(bFirmaParaValidar);
/*      */     
/*  326 */     return validar(bis, baseUri, validators, tsValidator);
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public List<ResultadoValidacion> validar(java.io.InputStream inputFirmaParaValidar, String baseUri, ExtraValidators validators, ITimeStampValidator tsValidator)
/*      */     throws FirmaXMLError
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 128	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:recoverManager	Les/mityc/javasign/certificate/IRecoverElements;
/*      */     //   4: ifnonnull +15 -> 19
/*      */     //   7: aload_0
/*      */     //   8: new 304	es/mityc/javasign/xml/xades/LocalFileStoreElements
/*      */     //   11: dup
/*      */     //   12: aload_2
/*      */     //   13: invokespecial 306	es/mityc/javasign/xml/xades/LocalFileStoreElements:<init>	(Ljava/lang/String;)V
/*      */     //   16: putfield 128	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:recoverManager	Les/mityc/javasign/certificate/IRecoverElements;
/*      */     //   19: invokestatic 307	javax/xml/parsers/DocumentBuilderFactory:newInstance	()Ljavax/xml/parsers/DocumentBuilderFactory;
/*      */     //   22: astore 5
/*      */     //   24: aload 5
/*      */     //   26: iconst_1
/*      */     //   27: invokevirtual 313	javax/xml/parsers/DocumentBuilderFactory:setNamespaceAware	(Z)V
/*      */     //   30: aconst_null
/*      */     //   31: astore 6
/*      */     //   33: aload 5
/*      */     //   35: invokevirtual 317	javax/xml/parsers/DocumentBuilderFactory:newDocumentBuilder	()Ljavax/xml/parsers/DocumentBuilder;
/*      */     //   38: astore 6
/*      */     //   40: goto +11 -> 51
/*      */     //   43: astore 7
/*      */     //   45: aload_0
/*      */     //   46: aload 7
/*      */     //   48: invokespecial 321	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:mostrarErrorValidacion	(Ljava/lang/Exception;)V
/*      */     //   51: aconst_null
/*      */     //   52: astore 7
/*      */     //   54: aconst_null
/*      */     //   55: astore 8
/*      */     //   57: aconst_null
/*      */     //   58: astore 9
/*      */     //   60: bipush 10
/*      */     //   62: newarray <illegal type>
/*      */     //   64: astore 10
/*      */     //   66: iconst_0
/*      */     //   67: istore 11
/*      */     //   69: aload_1
/*      */     //   70: invokevirtual 325	java/io/InputStream:available	()I
/*      */     //   73: istore 11
/*      */     //   75: new 331	java/io/ByteArrayOutputStream
/*      */     //   78: dup
/*      */     //   79: iload 11
/*      */     //   81: invokespecial 333	java/io/ByteArrayOutputStream:<init>	(I)V
/*      */     //   84: astore 9
/*      */     //   86: aload_1
/*      */     //   87: aload 10
/*      */     //   89: invokevirtual 336	java/io/InputStream:read	([B)I
/*      */     //   92: istore 12
/*      */     //   94: aload 9
/*      */     //   96: aload 10
/*      */     //   98: iconst_0
/*      */     //   99: iload 12
/*      */     //   101: invokevirtual 340	java/io/ByteArrayOutputStream:write	([BII)V
/*      */     //   104: aload 9
/*      */     //   106: invokevirtual 344	java/io/ByteArrayOutputStream:flush	()V
/*      */     //   109: iload 12
/*      */     //   111: istore 13
/*      */     //   113: sipush 4096
/*      */     //   116: newarray <illegal type>
/*      */     //   118: astore 14
/*      */     //   120: goto +33 -> 153
/*      */     //   123: aload_1
/*      */     //   124: aload 14
/*      */     //   126: invokevirtual 336	java/io/InputStream:read	([B)I
/*      */     //   129: istore 12
/*      */     //   131: aload 9
/*      */     //   133: aload 14
/*      */     //   135: iconst_0
/*      */     //   136: iload 12
/*      */     //   138: invokevirtual 340	java/io/ByteArrayOutputStream:write	([BII)V
/*      */     //   141: aload 9
/*      */     //   143: invokevirtual 344	java/io/ByteArrayOutputStream:flush	()V
/*      */     //   146: iload 13
/*      */     //   148: iload 12
/*      */     //   150: iadd
/*      */     //   151: istore 13
/*      */     //   153: iload 13
/*      */     //   155: iload 11
/*      */     //   157: if_icmplt -34 -> 123
/*      */     //   160: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   163: invokeinterface 347 1 0
/*      */     //   168: ifeq +13 -> 181
/*      */     //   171: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   174: aload 9
/*      */     //   176: invokeinterface 284 2 0
/*      */     //   181: new 351	org/xml/sax/InputSource
/*      */     //   184: dup
/*      */     //   185: new 295	java/io/ByteArrayInputStream
/*      */     //   188: dup
/*      */     //   189: aload 9
/*      */     //   191: invokevirtual 353	java/io/ByteArrayOutputStream:toByteArray	()[B
/*      */     //   194: invokespecial 297	java/io/ByteArrayInputStream:<init>	([B)V
/*      */     //   197: invokespecial 357	org/xml/sax/InputSource:<init>	(Ljava/io/InputStream;)V
/*      */     //   200: astore 7
/*      */     //   202: aload 6
/*      */     //   204: aload 7
/*      */     //   206: invokevirtual 360	javax/xml/parsers/DocumentBuilder:parse	(Lorg/xml/sax/InputSource;)Lorg/w3c/dom/Document;
/*      */     //   209: astore 8
/*      */     //   211: goto +704 -> 915
/*      */     //   214: astore 12
/*      */     //   216: aload_0
/*      */     //   217: aload 12
/*      */     //   219: invokespecial 321	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:mostrarErrorValidacion	(Ljava/lang/Exception;)V
/*      */     //   222: goto +693 -> 915
/*      */     //   225: astore 12
/*      */     //   227: iconst_3
/*      */     //   228: newarray <illegal type>
/*      */     //   230: dup
/*      */     //   231: iconst_0
/*      */     //   232: bipush -17
/*      */     //   234: bastore
/*      */     //   235: dup
/*      */     //   236: iconst_1
/*      */     //   237: bipush -69
/*      */     //   239: bastore
/*      */     //   240: dup
/*      */     //   241: iconst_2
/*      */     //   242: bipush -65
/*      */     //   244: bastore
/*      */     //   245: astore 13
/*      */     //   247: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   250: invokeinterface 366 1 0
/*      */     //   255: ifeq +57 -> 312
/*      */     //   258: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   261: new 257	java/lang/StringBuilder
/*      */     //   264: dup
/*      */     //   265: ldc_w 369
/*      */     //   268: invokespecial 267	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   271: aload 10
/*      */     //   273: iconst_0
/*      */     //   274: baload
/*      */     //   275: invokevirtual 371	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*      */     //   278: ldc_w 270
/*      */     //   281: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   284: aload 10
/*      */     //   286: iconst_1
/*      */     //   287: baload
/*      */     //   288: invokevirtual 371	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*      */     //   291: ldc_w 270
/*      */     //   294: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   297: aload 10
/*      */     //   299: iconst_2
/*      */     //   300: baload
/*      */     //   301: invokevirtual 371	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*      */     //   304: invokevirtual 283	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   307: invokeinterface 284 2 0
/*      */     //   312: aload 10
/*      */     //   314: ifnull +89 -> 403
/*      */     //   317: aload 10
/*      */     //   319: arraylength
/*      */     //   320: ifle +83 -> 403
/*      */     //   323: aload 10
/*      */     //   325: iconst_0
/*      */     //   326: baload
/*      */     //   327: aload 13
/*      */     //   329: iconst_0
/*      */     //   330: baload
/*      */     //   331: if_icmpne +72 -> 403
/*      */     //   334: aload 10
/*      */     //   336: iconst_1
/*      */     //   337: baload
/*      */     //   338: aload 13
/*      */     //   340: iconst_1
/*      */     //   341: baload
/*      */     //   342: if_icmpne +61 -> 403
/*      */     //   345: aload 10
/*      */     //   347: iconst_2
/*      */     //   348: baload
/*      */     //   349: aload 13
/*      */     //   351: iconst_2
/*      */     //   352: baload
/*      */     //   353: if_icmpne +50 -> 403
/*      */     //   356: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   359: invokeinterface 366 1 0
/*      */     //   364: ifeq +14 -> 378
/*      */     //   367: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   370: ldc_w 374
/*      */     //   373: invokeinterface 284 2 0
/*      */     //   378: aload 6
/*      */     //   380: new 295	java/io/ByteArrayInputStream
/*      */     //   383: dup
/*      */     //   384: aload 9
/*      */     //   386: invokevirtual 353	java/io/ByteArrayOutputStream:toByteArray	()[B
/*      */     //   389: iconst_3
/*      */     //   390: iload 11
/*      */     //   392: invokespecial 376	java/io/ByteArrayInputStream:<init>	([BII)V
/*      */     //   395: invokevirtual 378	javax/xml/parsers/DocumentBuilder:parse	(Ljava/io/InputStream;)Lorg/w3c/dom/Document;
/*      */     //   398: astore 8
/*      */     //   400: goto +430 -> 830
/*      */     //   403: bipush 6
/*      */     //   405: newarray <illegal type>
/*      */     //   407: dup
/*      */     //   408: iconst_0
/*      */     //   409: bipush -61
/*      */     //   411: bastore
/*      */     //   412: dup
/*      */     //   413: iconst_1
/*      */     //   414: bipush -81
/*      */     //   416: bastore
/*      */     //   417: dup
/*      */     //   418: iconst_2
/*      */     //   419: bipush -62
/*      */     //   421: bastore
/*      */     //   422: dup
/*      */     //   423: iconst_3
/*      */     //   424: bipush -69
/*      */     //   426: bastore
/*      */     //   427: dup
/*      */     //   428: iconst_4
/*      */     //   429: bipush -62
/*      */     //   431: bastore
/*      */     //   432: dup
/*      */     //   433: iconst_5
/*      */     //   434: bipush -65
/*      */     //   436: bastore
/*      */     //   437: astore 14
/*      */     //   439: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   442: invokeinterface 366 1 0
/*      */     //   447: ifeq +114 -> 561
/*      */     //   450: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   453: new 257	java/lang/StringBuilder
/*      */     //   456: dup
/*      */     //   457: ldc_w 381
/*      */     //   460: invokespecial 267	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   463: new 262	java/lang/String
/*      */     //   466: dup
/*      */     //   467: aload 10
/*      */     //   469: invokespecial 383	java/lang/String:<init>	([B)V
/*      */     //   472: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   475: ldc_w 384
/*      */     //   478: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   481: aload 10
/*      */     //   483: iconst_0
/*      */     //   484: baload
/*      */     //   485: invokevirtual 371	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*      */     //   488: ldc_w 270
/*      */     //   491: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   494: aload 10
/*      */     //   496: iconst_1
/*      */     //   497: baload
/*      */     //   498: invokevirtual 371	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*      */     //   501: ldc_w 270
/*      */     //   504: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   507: aload 10
/*      */     //   509: iconst_2
/*      */     //   510: baload
/*      */     //   511: invokevirtual 371	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*      */     //   514: ldc_w 270
/*      */     //   517: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   520: aload 10
/*      */     //   522: iconst_3
/*      */     //   523: baload
/*      */     //   524: invokevirtual 371	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*      */     //   527: ldc_w 270
/*      */     //   530: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   533: aload 10
/*      */     //   535: iconst_4
/*      */     //   536: baload
/*      */     //   537: invokevirtual 371	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*      */     //   540: ldc_w 270
/*      */     //   543: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   546: aload 10
/*      */     //   548: iconst_5
/*      */     //   549: baload
/*      */     //   550: invokevirtual 371	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*      */     //   553: invokevirtual 283	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   556: invokeinterface 284 2 0
/*      */     //   561: aload 10
/*      */     //   563: ifnull +147 -> 710
/*      */     //   566: aload 10
/*      */     //   568: arraylength
/*      */     //   569: ifle +141 -> 710
/*      */     //   572: aload 10
/*      */     //   574: iconst_0
/*      */     //   575: baload
/*      */     //   576: aload 14
/*      */     //   578: iconst_0
/*      */     //   579: baload
/*      */     //   580: if_icmpne +58 -> 638
/*      */     //   583: aload 10
/*      */     //   585: iconst_1
/*      */     //   586: baload
/*      */     //   587: aload 14
/*      */     //   589: iconst_1
/*      */     //   590: baload
/*      */     //   591: if_icmpne +47 -> 638
/*      */     //   594: aload 10
/*      */     //   596: iconst_2
/*      */     //   597: baload
/*      */     //   598: aload 14
/*      */     //   600: iconst_2
/*      */     //   601: baload
/*      */     //   602: if_icmpne +36 -> 638
/*      */     //   605: aload 10
/*      */     //   607: iconst_3
/*      */     //   608: baload
/*      */     //   609: aload 14
/*      */     //   611: iconst_3
/*      */     //   612: baload
/*      */     //   613: if_icmpne +25 -> 638
/*      */     //   616: aload 10
/*      */     //   618: iconst_4
/*      */     //   619: baload
/*      */     //   620: aload 14
/*      */     //   622: iconst_4
/*      */     //   623: baload
/*      */     //   624: if_icmpne +14 -> 638
/*      */     //   627: aload 10
/*      */     //   629: iconst_5
/*      */     //   630: baload
/*      */     //   631: aload 14
/*      */     //   633: iconst_5
/*      */     //   634: baload
/*      */     //   635: if_icmpeq +27 -> 662
/*      */     //   638: new 262	java/lang/String
/*      */     //   641: dup
/*      */     //   642: aload 10
/*      */     //   644: invokespecial 383	java/lang/String:<init>	([B)V
/*      */     //   647: new 262	java/lang/String
/*      */     //   650: dup
/*      */     //   651: aload 14
/*      */     //   653: invokespecial 383	java/lang/String:<init>	([B)V
/*      */     //   656: invokevirtual 386	java/lang/String:startsWith	(Ljava/lang/String;)Z
/*      */     //   659: ifeq +51 -> 710
/*      */     //   662: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   665: invokeinterface 366 1 0
/*      */     //   670: ifeq +14 -> 684
/*      */     //   673: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   676: ldc_w 390
/*      */     //   679: invokeinterface 284 2 0
/*      */     //   684: aload 6
/*      */     //   686: new 295	java/io/ByteArrayInputStream
/*      */     //   689: dup
/*      */     //   690: aload 9
/*      */     //   692: invokevirtual 353	java/io/ByteArrayOutputStream:toByteArray	()[B
/*      */     //   695: bipush 6
/*      */     //   697: iload 11
/*      */     //   699: invokespecial 376	java/io/ByteArrayInputStream:<init>	([BII)V
/*      */     //   702: invokevirtual 378	javax/xml/parsers/DocumentBuilder:parse	(Ljava/io/InputStream;)Lorg/w3c/dom/Document;
/*      */     //   705: astore 8
/*      */     //   707: goto +123 -> 830
/*      */     //   710: aload_0
/*      */     //   711: aload 12
/*      */     //   713: invokespecial 321	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:mostrarErrorValidacion	(Ljava/lang/Exception;)V
/*      */     //   716: goto +114 -> 830
/*      */     //   719: astore 13
/*      */     //   721: aload_0
/*      */     //   722: aload 12
/*      */     //   724: invokespecial 321	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:mostrarErrorValidacion	(Ljava/lang/Exception;)V
/*      */     //   727: aload_1
/*      */     //   728: ifnull +12 -> 740
/*      */     //   731: aload_1
/*      */     //   732: invokevirtual 392	java/io/InputStream:close	()V
/*      */     //   735: goto +5 -> 740
/*      */     //   738: astore 16
/*      */     //   740: aload 9
/*      */     //   742: ifnull +173 -> 915
/*      */     //   745: aload 9
/*      */     //   747: invokevirtual 393	java/io/ByteArrayOutputStream:close	()V
/*      */     //   750: goto +165 -> 915
/*      */     //   753: astore 16
/*      */     //   755: goto +160 -> 915
/*      */     //   758: astore 13
/*      */     //   760: aload_0
/*      */     //   761: aload 12
/*      */     //   763: invokespecial 321	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:mostrarErrorValidacion	(Ljava/lang/Exception;)V
/*      */     //   766: aload_1
/*      */     //   767: ifnull +12 -> 779
/*      */     //   770: aload_1
/*      */     //   771: invokevirtual 392	java/io/InputStream:close	()V
/*      */     //   774: goto +5 -> 779
/*      */     //   777: astore 16
/*      */     //   779: aload 9
/*      */     //   781: ifnull +134 -> 915
/*      */     //   784: aload 9
/*      */     //   786: invokevirtual 393	java/io/ByteArrayOutputStream:close	()V
/*      */     //   789: goto +126 -> 915
/*      */     //   792: astore 16
/*      */     //   794: goto +121 -> 915
/*      */     //   797: astore 15
/*      */     //   799: aload_1
/*      */     //   800: ifnull +12 -> 812
/*      */     //   803: aload_1
/*      */     //   804: invokevirtual 392	java/io/InputStream:close	()V
/*      */     //   807: goto +5 -> 812
/*      */     //   810: astore 16
/*      */     //   812: aload 9
/*      */     //   814: ifnull +13 -> 827
/*      */     //   817: aload 9
/*      */     //   819: invokevirtual 393	java/io/ByteArrayOutputStream:close	()V
/*      */     //   822: goto +5 -> 827
/*      */     //   825: astore 16
/*      */     //   827: aload 15
/*      */     //   829: athrow
/*      */     //   830: aload_1
/*      */     //   831: ifnull +12 -> 843
/*      */     //   834: aload_1
/*      */     //   835: invokevirtual 392	java/io/InputStream:close	()V
/*      */     //   838: goto +5 -> 843
/*      */     //   841: astore 16
/*      */     //   843: aload 9
/*      */     //   845: ifnull +70 -> 915
/*      */     //   848: aload 9
/*      */     //   850: invokevirtual 393	java/io/ByteArrayOutputStream:close	()V
/*      */     //   853: goto +62 -> 915
/*      */     //   856: astore 16
/*      */     //   858: goto +57 -> 915
/*      */     //   861: astore 12
/*      */     //   863: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   866: new 257	java/lang/StringBuilder
/*      */     //   869: dup
/*      */     //   870: ldc_w 394
/*      */     //   873: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   876: invokestatic 261	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   879: invokespecial 267	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   882: ldc_w 396
/*      */     //   885: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   888: aload 12
/*      */     //   890: invokevirtual 398	com/sun/org/apache/xerces/internal/impl/io/MalformedByteSequenceException:getMessage	()Ljava/lang/String;
/*      */     //   893: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   896: invokevirtual 283	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   899: invokeinterface 284 2 0
/*      */     //   904: goto +11 -> 915
/*      */     //   907: astore 12
/*      */     //   909: aload_0
/*      */     //   910: aload 12
/*      */     //   912: invokespecial 321	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:mostrarErrorValidacion	(Ljava/lang/Exception;)V
/*      */     //   915: aconst_null
/*      */     //   916: astore 5
/*      */     //   918: aconst_null
/*      */     //   919: astore 7
/*      */     //   921: aconst_null
/*      */     //   922: astore 6
/*      */     //   924: aload_0
/*      */     //   925: aload 8
/*      */     //   927: aload_2
/*      */     //   928: aload_3
/*      */     //   929: aload 4
/*      */     //   931: invokevirtual 403	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:validar	(Lorg/w3c/dom/Document;Ljava/lang/String;Les/mityc/firmaJava/libreria/xades/ExtraValidators;Les/mityc/javasign/tsa/ITimeStampValidator;)Ljava/util/ArrayList;
/*      */     //   934: astore 12
/*      */     //   936: aload_3
/*      */     //   937: ifnull +10 -> 947
/*      */     //   940: aload_3
/*      */     //   941: invokevirtual 406	es/mityc/firmaJava/libreria/xades/ExtraValidators:getCertStatus	()Les/mityc/javasign/certificate/ICertStatusRecoverer;
/*      */     //   944: goto +4 -> 948
/*      */     //   947: aconst_null
/*      */     //   948: astore 13
/*      */     //   950: aload 12
/*      */     //   952: ifnull +1061 -> 2013
/*      */     //   955: aload 12
/*      */     //   957: invokevirtual 410	java/util/ArrayList:size	()I
/*      */     //   960: ifle +1053 -> 2013
/*      */     //   963: aload_3
/*      */     //   964: ifnull +1049 -> 2013
/*      */     //   967: aload_3
/*      */     //   968: invokevirtual 413	es/mityc/firmaJava/libreria/xades/ExtraValidators:getTrusterCerts	()Les/mityc/javasign/trust/TrustAbstract;
/*      */     //   971: astore 14
/*      */     //   973: aload_3
/*      */     //   974: invokevirtual 417	es/mityc/firmaJava/libreria/xades/ExtraValidators:getTrusterOCSP	()Les/mityc/javasign/trust/TrustAbstract;
/*      */     //   977: astore 15
/*      */     //   979: aload_3
/*      */     //   980: invokevirtual 420	es/mityc/firmaJava/libreria/xades/ExtraValidators:getTrusterCRL	()Les/mityc/javasign/trust/TrustAbstract;
/*      */     //   983: astore 16
/*      */     //   985: aload_3
/*      */     //   986: invokevirtual 423	es/mityc/firmaJava/libreria/xades/ExtraValidators:getTrusterTSA	()Les/mityc/javasign/trust/TrustAbstract;
/*      */     //   989: astore 17
/*      */     //   991: aconst_null
/*      */     //   992: astore 18
/*      */     //   994: getstatic 426	es/mityc/javasign/certificate/ICertStatus$CERT_STATUS:unknown	Les/mityc/javasign/certificate/ICertStatus$CERT_STATUS;
/*      */     //   997: astore 19
/*      */     //   999: aload 14
/*      */     //   1001: ifnonnull +18 -> 1019
/*      */     //   1004: aload 15
/*      */     //   1006: ifnonnull +13 -> 1019
/*      */     //   1009: aload 16
/*      */     //   1011: ifnonnull +8 -> 1019
/*      */     //   1014: aload 17
/*      */     //   1016: ifnull +997 -> 2013
/*      */     //   1019: aload 12
/*      */     //   1021: invokevirtual 432	java/util/ArrayList:iterator	()Ljava/util/Iterator;
/*      */     //   1024: astore 20
/*      */     //   1026: goto +977 -> 2003
/*      */     //   1029: aload 20
/*      */     //   1031: invokeinterface 436 1 0
/*      */     //   1036: checkcast 94	es/mityc/firmaJava/libreria/xades/ResultadoValidacion
/*      */     //   1039: astore 21
/*      */     //   1041: aload 21
/*      */     //   1043: ifnull +960 -> 2003
/*      */     //   1046: aload 21
/*      */     //   1048: invokevirtual 442	es/mityc/firmaJava/libreria/xades/ResultadoValidacion:getDatosFirma	()Les/mityc/firmaJava/libreria/xades/DatosFirma;
/*      */     //   1051: astore 22
/*      */     //   1053: aload 22
/*      */     //   1055: ifnull +948 -> 2003
/*      */     //   1058: aload 14
/*      */     //   1060: ifnull +54 -> 1114
/*      */     //   1063: aload 21
/*      */     //   1065: invokevirtual 446	es/mityc/firmaJava/libreria/xades/ResultadoValidacion:getCertStatus	()Les/mityc/javasign/certificate/ICertStatus;
/*      */     //   1068: astore 18
/*      */     //   1070: aload 18
/*      */     //   1072: ifnull +12 -> 1084
/*      */     //   1075: aload 18
/*      */     //   1077: invokeinterface 449 1 0
/*      */     //   1082: astore 19
/*      */     //   1084: getstatic 426	es/mityc/javasign/certificate/ICertStatus$CERT_STATUS:unknown	Les/mityc/javasign/certificate/ICertStatus$CERT_STATUS;
/*      */     //   1087: aload 19
/*      */     //   1089: invokevirtual 455	es/mityc/javasign/certificate/ICertStatus$CERT_STATUS:equals	(Ljava/lang/Object;)Z
/*      */     //   1092: ifne +14 -> 1106
/*      */     //   1095: aload 22
/*      */     //   1097: getstatic 458	es/mityc/firmaJava/trust/ConfianzaEnum:CON_CONFIANZA	Les/mityc/firmaJava/trust/ConfianzaEnum;
/*      */     //   1100: invokevirtual 464	es/mityc/firmaJava/libreria/xades/DatosFirma:setEsCadenaConfianza	(Les/mityc/firmaJava/trust/ConfianzaEnum;)V
/*      */     //   1103: goto +11 -> 1114
/*      */     //   1106: aload_0
/*      */     //   1107: aload 14
/*      */     //   1109: aload 22
/*      */     //   1111: invokespecial 470	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:validateTrustCerts	(Les/mityc/javasign/trust/TrustAbstract;Les/mityc/firmaJava/libreria/xades/DatosFirma;)V
/*      */     //   1114: aload 15
/*      */     //   1116: ifnull +393 -> 1509
/*      */     //   1119: aload 22
/*      */     //   1121: invokevirtual 474	es/mityc/firmaJava/libreria/xades/DatosFirma:getDatosOCSP	()Ljava/util/ArrayList;
/*      */     //   1124: astore 23
/*      */     //   1126: aload 23
/*      */     //   1128: ifnull +381 -> 1509
/*      */     //   1131: aload 23
/*      */     //   1133: invokevirtual 410	java/util/ArrayList:size	()I
/*      */     //   1136: ifle +373 -> 1509
/*      */     //   1139: aload 22
/*      */     //   1141: invokevirtual 478	es/mityc/firmaJava/libreria/xades/DatosFirma:getTipoFirma	()Les/mityc/firmaJava/libreria/xades/DatosTipoFirma;
/*      */     //   1144: invokevirtual 482	es/mityc/firmaJava/libreria/xades/DatosTipoFirma:getTipoXAdES	()Les/mityc/javasign/EnumFormatoFirma;
/*      */     //   1147: getstatic 488	es/mityc/javasign/EnumFormatoFirma:XAdES_X	Les/mityc/javasign/EnumFormatoFirma;
/*      */     //   1150: invokevirtual 494	es/mityc/javasign/EnumFormatoFirma:compareTo	(Ljava/lang/Enum;)I
/*      */     //   1153: iflt +14 -> 1167
/*      */     //   1156: aload_0
/*      */     //   1157: aload 15
/*      */     //   1159: aload 22
/*      */     //   1161: invokespecial 498	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:validateTrustOCSP	(Les/mityc/javasign/trust/TrustAbstract;Les/mityc/firmaJava/libreria/xades/DatosFirma;)V
/*      */     //   1164: goto +345 -> 1509
/*      */     //   1167: aload 23
/*      */     //   1169: invokevirtual 432	java/util/ArrayList:iterator	()Ljava/util/Iterator;
/*      */     //   1172: astore 24
/*      */     //   1174: goto +325 -> 1499
/*      */     //   1177: aload 24
/*      */     //   1179: invokeinterface 436 1 0
/*      */     //   1184: checkcast 501	es/mityc/firmaJava/libreria/xades/DatosOCSP
/*      */     //   1187: astore 25
/*      */     //   1189: aload 25
/*      */     //   1191: invokevirtual 503	es/mityc/firmaJava/libreria/xades/DatosOCSP:getRespuestaOCSP	()Lorg/bouncycastle/ocsp/OCSPResp;
/*      */     //   1194: astore 26
/*      */     //   1196: aload 26
/*      */     //   1198: ifnull +301 -> 1499
/*      */     //   1201: aload 13
/*      */     //   1203: aload 25
/*      */     //   1205: invokevirtual 507	es/mityc/firmaJava/libreria/xades/DatosOCSP:getCertOCSPResponder	()[Ljava/security/cert/X509Certificate;
/*      */     //   1208: iconst_0
/*      */     //   1209: aaload
/*      */     //   1210: invokeinterface 511 2 0
/*      */     //   1215: astore 18
/*      */     //   1217: aload 18
/*      */     //   1219: ifnull +22 -> 1241
/*      */     //   1222: aload 18
/*      */     //   1224: invokeinterface 449 1 0
/*      */     //   1229: astore 19
/*      */     //   1231: goto +10 -> 1241
/*      */     //   1234: astore 27
/*      */     //   1236: getstatic 426	es/mityc/javasign/certificate/ICertStatus$CERT_STATUS:unknown	Les/mityc/javasign/certificate/ICertStatus$CERT_STATUS;
/*      */     //   1239: astore 19
/*      */     //   1241: aload 25
/*      */     //   1243: aload 19
/*      */     //   1245: invokevirtual 516	es/mityc/firmaJava/libreria/xades/DatosOCSP:setRevockedStatus	(Les/mityc/javasign/certificate/ICertStatus$CERT_STATUS;)V
/*      */     //   1248: aload 25
/*      */     //   1250: aload 18
/*      */     //   1252: invokevirtual 520	es/mityc/firmaJava/libreria/xades/DatosOCSP:setStatus	(Les/mityc/javasign/certificate/ICertStatus;)V
/*      */     //   1255: getstatic 426	es/mityc/javasign/certificate/ICertStatus$CERT_STATUS:unknown	Les/mityc/javasign/certificate/ICertStatus$CERT_STATUS;
/*      */     //   1258: aload 19
/*      */     //   1260: invokevirtual 455	es/mityc/javasign/certificate/ICertStatus$CERT_STATUS:equals	(Ljava/lang/Object;)Z
/*      */     //   1263: ifeq +14 -> 1277
/*      */     //   1266: aload_0
/*      */     //   1267: aload 15
/*      */     //   1269: aload 22
/*      */     //   1271: invokespecial 498	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:validateTrustOCSP	(Les/mityc/javasign/trust/TrustAbstract;Les/mityc/firmaJava/libreria/xades/DatosFirma;)V
/*      */     //   1274: goto +225 -> 1499
/*      */     //   1277: getstatic 524	es/mityc/javasign/certificate/ICertStatus$CERT_STATUS:revoked	Les/mityc/javasign/certificate/ICertStatus$CERT_STATUS;
/*      */     //   1280: aload 19
/*      */     //   1282: invokevirtual 455	es/mityc/javasign/certificate/ICertStatus$CERT_STATUS:equals	(Ljava/lang/Object;)Z
/*      */     //   1285: ifeq +206 -> 1491
/*      */     //   1288: aload 25
/*      */     //   1290: getstatic 458	es/mityc/firmaJava/trust/ConfianzaEnum:CON_CONFIANZA	Les/mityc/firmaJava/trust/ConfianzaEnum;
/*      */     //   1293: invokevirtual 527	es/mityc/firmaJava/libreria/xades/DatosOCSP:setEsCertConfianza	(Les/mityc/firmaJava/trust/ConfianzaEnum;)V
/*      */     //   1296: aload 21
/*      */     //   1298: iconst_0
/*      */     //   1299: invokevirtual 530	es/mityc/firmaJava/libreria/xades/ResultadoValidacion:setValidate	(Z)V
/*      */     //   1302: aload 21
/*      */     //   1304: getstatic 533	es/mityc/firmaJava/libreria/xades/ResultadoEnum:INVALID	Les/mityc/firmaJava/libreria/xades/ResultadoEnum;
/*      */     //   1307: invokevirtual 539	es/mityc/firmaJava/libreria/xades/ResultadoValidacion:setResultado	(Les/mityc/firmaJava/libreria/xades/ResultadoEnum;)V
/*      */     //   1310: aload 18
/*      */     //   1312: invokeinterface 543 1 0
/*      */     //   1317: astore 27
/*      */     //   1319: aconst_null
/*      */     //   1320: astore 28
/*      */     //   1322: aload 27
/*      */     //   1324: ifnull +10 -> 1334
/*      */     //   1327: aload 27
/*      */     //   1329: invokevirtual 547	es/mityc/javasign/certificate/RevokedInfo:getRevokedDate	()Ljava/util/Date;
/*      */     //   1332: astore 28
/*      */     //   1334: aload 28
/*      */     //   1336: ifnull +106 -> 1442
/*      */     //   1339: new 553	java/text/SimpleDateFormat
/*      */     //   1342: dup
/*      */     //   1343: ldc_w 555
/*      */     //   1346: invokespecial 557	java/text/SimpleDateFormat:<init>	(Ljava/lang/String;)V
/*      */     //   1349: astore 29
/*      */     //   1351: aload 21
/*      */     //   1353: getstatic 80	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:i18n	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   1356: ldc 54
/*      */     //   1358: iconst_1
/*      */     //   1359: anewarray 3	java/lang/Object
/*      */     //   1362: dup
/*      */     //   1363: iconst_0
/*      */     //   1364: aload 29
/*      */     //   1366: aload 28
/*      */     //   1368: invokevirtual 558	java/text/SimpleDateFormat:format	(Ljava/util/Date;)Ljava/lang/String;
/*      */     //   1371: aastore
/*      */     //   1372: invokeinterface 562 3 0
/*      */     //   1377: invokevirtual 568	es/mityc/firmaJava/libreria/xades/ResultadoValidacion:setLog	(Ljava/lang/String;)V
/*      */     //   1380: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   1383: getstatic 80	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:i18n	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   1386: ldc 54
/*      */     //   1388: iconst_1
/*      */     //   1389: anewarray 3	java/lang/Object
/*      */     //   1392: dup
/*      */     //   1393: iconst_0
/*      */     //   1394: aload 29
/*      */     //   1396: aload 28
/*      */     //   1398: invokevirtual 558	java/text/SimpleDateFormat:format	(Ljava/util/Date;)Ljava/lang/String;
/*      */     //   1401: aastore
/*      */     //   1402: invokeinterface 562 3 0
/*      */     //   1407: invokeinterface 571 2 0
/*      */     //   1412: getstatic 80	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:i18n	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   1415: ldc 54
/*      */     //   1417: iconst_1
/*      */     //   1418: anewarray 3	java/lang/Object
/*      */     //   1421: dup
/*      */     //   1422: iconst_0
/*      */     //   1423: aload 29
/*      */     //   1425: aload 28
/*      */     //   1427: invokevirtual 558	java/text/SimpleDateFormat:format	(Ljava/util/Date;)Ljava/lang/String;
/*      */     //   1430: aastore
/*      */     //   1431: invokeinterface 562 3 0
/*      */     //   1436: invokestatic 574	es/mityc/firmaJava/libreria/xades/logv:error	(Ljava/lang/String;)V
/*      */     //   1439: goto +60 -> 1499
/*      */     //   1442: aload 21
/*      */     //   1444: getstatic 80	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:i18n	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   1447: ldc 57
/*      */     //   1449: invokeinterface 578 2 0
/*      */     //   1454: invokevirtual 568	es/mityc/firmaJava/libreria/xades/ResultadoValidacion:setLog	(Ljava/lang/String;)V
/*      */     //   1457: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   1460: getstatic 80	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:i18n	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   1463: ldc 57
/*      */     //   1465: invokeinterface 578 2 0
/*      */     //   1470: invokeinterface 571 2 0
/*      */     //   1475: getstatic 80	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:i18n	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   1478: ldc 57
/*      */     //   1480: invokeinterface 578 2 0
/*      */     //   1485: invokestatic 574	es/mityc/firmaJava/libreria/xades/logv:error	(Ljava/lang/String;)V
/*      */     //   1488: goto +11 -> 1499
/*      */     //   1491: aload 25
/*      */     //   1493: getstatic 458	es/mityc/firmaJava/trust/ConfianzaEnum:CON_CONFIANZA	Les/mityc/firmaJava/trust/ConfianzaEnum;
/*      */     //   1496: invokevirtual 527	es/mityc/firmaJava/libreria/xades/DatosOCSP:setEsCertConfianza	(Les/mityc/firmaJava/trust/ConfianzaEnum;)V
/*      */     //   1499: aload 24
/*      */     //   1501: invokeinterface 580 1 0
/*      */     //   1506: ifne -329 -> 1177
/*      */     //   1509: aload 16
/*      */     //   1511: ifnull +11 -> 1522
/*      */     //   1514: aload_0
/*      */     //   1515: aload 16
/*      */     //   1517: aload 22
/*      */     //   1519: invokespecial 583	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:validateTrustCRL	(Les/mityc/javasign/trust/TrustAbstract;Les/mityc/firmaJava/libreria/xades/DatosFirma;)V
/*      */     //   1522: aload 17
/*      */     //   1524: ifnull +479 -> 2003
/*      */     //   1527: aload 22
/*      */     //   1529: invokevirtual 586	es/mityc/firmaJava/libreria/xades/DatosFirma:getDatosSelloTiempo	()Ljava/util/ArrayList;
/*      */     //   1532: astore 23
/*      */     //   1534: aload 23
/*      */     //   1536: ifnull +467 -> 2003
/*      */     //   1539: aload 23
/*      */     //   1541: invokevirtual 410	java/util/ArrayList:size	()I
/*      */     //   1544: ifle +459 -> 2003
/*      */     //   1547: aload 23
/*      */     //   1549: invokevirtual 432	java/util/ArrayList:iterator	()Ljava/util/Iterator;
/*      */     //   1552: astore 24
/*      */     //   1554: aload_0
/*      */     //   1555: aload 17
/*      */     //   1557: aload 22
/*      */     //   1559: invokespecial 589	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:validateTrustTSA	(Les/mityc/javasign/trust/TrustAbstract;Les/mityc/firmaJava/libreria/xades/DatosFirma;)V
/*      */     //   1562: goto +431 -> 1993
/*      */     //   1565: aload 24
/*      */     //   1567: invokeinterface 436 1 0
/*      */     //   1572: checkcast 592	es/mityc/firmaJava/libreria/xades/DatosSelloTiempo
/*      */     //   1575: astore 25
/*      */     //   1577: aload 22
/*      */     //   1579: invokevirtual 478	es/mityc/firmaJava/libreria/xades/DatosFirma:getTipoFirma	()Les/mityc/firmaJava/libreria/xades/DatosTipoFirma;
/*      */     //   1582: invokevirtual 482	es/mityc/firmaJava/libreria/xades/DatosTipoFirma:getTipoXAdES	()Les/mityc/javasign/EnumFormatoFirma;
/*      */     //   1585: getstatic 488	es/mityc/javasign/EnumFormatoFirma:XAdES_X	Les/mityc/javasign/EnumFormatoFirma;
/*      */     //   1588: invokevirtual 494	es/mityc/javasign/EnumFormatoFirma:compareTo	(Ljava/lang/Enum;)I
/*      */     //   1591: iflt +16 -> 1607
/*      */     //   1594: aload 24
/*      */     //   1596: invokeinterface 580 1 0
/*      */     //   1601: ifeq +6 -> 1607
/*      */     //   1604: goto +389 -> 1993
/*      */     //   1607: aload 25
/*      */     //   1609: invokevirtual 594	es/mityc/firmaJava/libreria/xades/DatosSelloTiempo:esCertConfianza	()Les/mityc/firmaJava/trust/ConfianzaEnum;
/*      */     //   1612: getstatic 598	es/mityc/firmaJava/trust/ConfianzaEnum:SIN_CONFIANZA	Les/mityc/firmaJava/trust/ConfianzaEnum;
/*      */     //   1615: invokevirtual 601	es/mityc/firmaJava/trust/ConfianzaEnum:equals	(Ljava/lang/Object;)Z
/*      */     //   1618: ifeq +6 -> 1624
/*      */     //   1621: goto +372 -> 1993
/*      */     //   1624: aload 25
/*      */     //   1626: invokevirtual 602	es/mityc/firmaJava/libreria/xades/DatosSelloTiempo:getRawTimestamp	()[B
/*      */     //   1629: astore 26
/*      */     //   1631: aconst_null
/*      */     //   1632: astore 27
/*      */     //   1634: new 605	org/bouncycastle/tsp/TimeStampToken
/*      */     //   1637: dup
/*      */     //   1638: new 607	org/bouncycastle/cms/CMSSignedData
/*      */     //   1641: dup
/*      */     //   1642: aload 26
/*      */     //   1644: invokespecial 609	org/bouncycastle/cms/CMSSignedData:<init>	([B)V
/*      */     //   1647: invokespecial 610	org/bouncycastle/tsp/TimeStampToken:<init>	(Lorg/bouncycastle/cms/CMSSignedData;)V
/*      */     //   1650: astore 28
/*      */     //   1652: aload 28
/*      */     //   1654: ldc_w 613
/*      */     //   1657: aconst_null
/*      */     //   1658: invokevirtual 615	org/bouncycastle/tsp/TimeStampToken:getCertificatesAndCRLs	(Ljava/lang/String;Ljava/lang/String;)Ljava/security/cert/CertStore;
/*      */     //   1661: astore 29
/*      */     //   1663: aload 29
/*      */     //   1665: aconst_null
/*      */     //   1666: invokevirtual 619	java/security/cert/CertStore:getCertificates	(Ljava/security/cert/CertSelector;)Ljava/util/Collection;
/*      */     //   1669: astore 30
/*      */     //   1671: aload 30
/*      */     //   1673: invokeinterface 625 1 0
/*      */     //   1678: ifle +40 -> 1718
/*      */     //   1681: aload 30
/*      */     //   1683: invokeinterface 628 1 0
/*      */     //   1688: invokeinterface 436 1 0
/*      */     //   1693: checkcast 629	java/security/cert/Certificate
/*      */     //   1696: astore 31
/*      */     //   1698: aload 31
/*      */     //   1700: instanceof 631
/*      */     //   1703: ifeq +15 -> 1718
/*      */     //   1706: aload 31
/*      */     //   1708: checkcast 631	java/security/cert/X509Certificate
/*      */     //   1711: astore 27
/*      */     //   1713: goto +5 -> 1718
/*      */     //   1716: astore 28
/*      */     //   1718: aload 13
/*      */     //   1720: aload 27
/*      */     //   1722: invokeinterface 511 2 0
/*      */     //   1727: astore 18
/*      */     //   1729: aload 18
/*      */     //   1731: ifnull +22 -> 1753
/*      */     //   1734: aload 18
/*      */     //   1736: invokeinterface 449 1 0
/*      */     //   1741: astore 19
/*      */     //   1743: goto +10 -> 1753
/*      */     //   1746: astore 28
/*      */     //   1748: getstatic 426	es/mityc/javasign/certificate/ICertStatus$CERT_STATUS:unknown	Les/mityc/javasign/certificate/ICertStatus$CERT_STATUS;
/*      */     //   1751: astore 19
/*      */     //   1753: aload 25
/*      */     //   1755: aload 19
/*      */     //   1757: invokevirtual 633	es/mityc/firmaJava/libreria/xades/DatosSelloTiempo:setRevockedStatus	(Les/mityc/javasign/certificate/ICertStatus$CERT_STATUS;)V
/*      */     //   1760: getstatic 426	es/mityc/javasign/certificate/ICertStatus$CERT_STATUS:unknown	Les/mityc/javasign/certificate/ICertStatus$CERT_STATUS;
/*      */     //   1763: aload 19
/*      */     //   1765: invokevirtual 455	es/mityc/javasign/certificate/ICertStatus$CERT_STATUS:equals	(Ljava/lang/Object;)Z
/*      */     //   1768: ifne +225 -> 1993
/*      */     //   1771: getstatic 524	es/mityc/javasign/certificate/ICertStatus$CERT_STATUS:revoked	Les/mityc/javasign/certificate/ICertStatus$CERT_STATUS;
/*      */     //   1774: aload 19
/*      */     //   1776: invokevirtual 455	es/mityc/javasign/certificate/ICertStatus$CERT_STATUS:equals	(Ljava/lang/Object;)Z
/*      */     //   1779: ifeq +206 -> 1985
/*      */     //   1782: aload 25
/*      */     //   1784: getstatic 458	es/mityc/firmaJava/trust/ConfianzaEnum:CON_CONFIANZA	Les/mityc/firmaJava/trust/ConfianzaEnum;
/*      */     //   1787: invokevirtual 634	es/mityc/firmaJava/libreria/xades/DatosSelloTiempo:setEsCertConfianza	(Les/mityc/firmaJava/trust/ConfianzaEnum;)V
/*      */     //   1790: aload 21
/*      */     //   1792: iconst_0
/*      */     //   1793: invokevirtual 530	es/mityc/firmaJava/libreria/xades/ResultadoValidacion:setValidate	(Z)V
/*      */     //   1796: aload 21
/*      */     //   1798: getstatic 635	es/mityc/firmaJava/libreria/xades/ResultadoEnum:UNKNOWN	Les/mityc/firmaJava/libreria/xades/ResultadoEnum;
/*      */     //   1801: invokevirtual 539	es/mityc/firmaJava/libreria/xades/ResultadoValidacion:setResultado	(Les/mityc/firmaJava/libreria/xades/ResultadoEnum;)V
/*      */     //   1804: aload 18
/*      */     //   1806: invokeinterface 543 1 0
/*      */     //   1811: astore 28
/*      */     //   1813: aconst_null
/*      */     //   1814: astore 29
/*      */     //   1816: aload 28
/*      */     //   1818: ifnull +10 -> 1828
/*      */     //   1821: aload 28
/*      */     //   1823: invokevirtual 547	es/mityc/javasign/certificate/RevokedInfo:getRevokedDate	()Ljava/util/Date;
/*      */     //   1826: astore 29
/*      */     //   1828: aload 29
/*      */     //   1830: ifnull +106 -> 1936
/*      */     //   1833: new 553	java/text/SimpleDateFormat
/*      */     //   1836: dup
/*      */     //   1837: ldc_w 555
/*      */     //   1840: invokespecial 557	java/text/SimpleDateFormat:<init>	(Ljava/lang/String;)V
/*      */     //   1843: astore 30
/*      */     //   1845: aload 21
/*      */     //   1847: getstatic 80	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:i18n	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   1850: ldc 48
/*      */     //   1852: iconst_1
/*      */     //   1853: anewarray 3	java/lang/Object
/*      */     //   1856: dup
/*      */     //   1857: iconst_0
/*      */     //   1858: aload 30
/*      */     //   1860: aload 29
/*      */     //   1862: invokevirtual 558	java/text/SimpleDateFormat:format	(Ljava/util/Date;)Ljava/lang/String;
/*      */     //   1865: aastore
/*      */     //   1866: invokeinterface 562 3 0
/*      */     //   1871: invokevirtual 568	es/mityc/firmaJava/libreria/xades/ResultadoValidacion:setLog	(Ljava/lang/String;)V
/*      */     //   1874: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   1877: getstatic 80	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:i18n	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   1880: ldc 48
/*      */     //   1882: iconst_1
/*      */     //   1883: anewarray 3	java/lang/Object
/*      */     //   1886: dup
/*      */     //   1887: iconst_0
/*      */     //   1888: aload 30
/*      */     //   1890: aload 29
/*      */     //   1892: invokevirtual 558	java/text/SimpleDateFormat:format	(Ljava/util/Date;)Ljava/lang/String;
/*      */     //   1895: aastore
/*      */     //   1896: invokeinterface 562 3 0
/*      */     //   1901: invokeinterface 571 2 0
/*      */     //   1906: getstatic 80	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:i18n	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   1909: ldc 48
/*      */     //   1911: iconst_1
/*      */     //   1912: anewarray 3	java/lang/Object
/*      */     //   1915: dup
/*      */     //   1916: iconst_0
/*      */     //   1917: aload 30
/*      */     //   1919: aload 29
/*      */     //   1921: invokevirtual 558	java/text/SimpleDateFormat:format	(Ljava/util/Date;)Ljava/lang/String;
/*      */     //   1924: aastore
/*      */     //   1925: invokeinterface 562 3 0
/*      */     //   1930: invokestatic 574	es/mityc/firmaJava/libreria/xades/logv:error	(Ljava/lang/String;)V
/*      */     //   1933: goto +60 -> 1993
/*      */     //   1936: aload 21
/*      */     //   1938: getstatic 80	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:i18n	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   1941: ldc 51
/*      */     //   1943: invokeinterface 578 2 0
/*      */     //   1948: invokevirtual 568	es/mityc/firmaJava/libreria/xades/ResultadoValidacion:setLog	(Ljava/lang/String;)V
/*      */     //   1951: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   1954: getstatic 80	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:i18n	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   1957: ldc 51
/*      */     //   1959: invokeinterface 578 2 0
/*      */     //   1964: invokeinterface 571 2 0
/*      */     //   1969: getstatic 80	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:i18n	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   1972: ldc 51
/*      */     //   1974: invokeinterface 578 2 0
/*      */     //   1979: invokestatic 574	es/mityc/firmaJava/libreria/xades/logv:error	(Ljava/lang/String;)V
/*      */     //   1982: goto +11 -> 1993
/*      */     //   1985: aload 25
/*      */     //   1987: getstatic 458	es/mityc/firmaJava/trust/ConfianzaEnum:CON_CONFIANZA	Les/mityc/firmaJava/trust/ConfianzaEnum;
/*      */     //   1990: invokevirtual 634	es/mityc/firmaJava/libreria/xades/DatosSelloTiempo:setEsCertConfianza	(Les/mityc/firmaJava/trust/ConfianzaEnum;)V
/*      */     //   1993: aload 24
/*      */     //   1995: invokeinterface 580 1 0
/*      */     //   2000: ifne -435 -> 1565
/*      */     //   2003: aload 20
/*      */     //   2005: invokeinterface 580 1 0
/*      */     //   2010: ifne -981 -> 1029
/*      */     //   2013: aload 12
/*      */     //   2015: areturn
/*      */     // Line number table:
/*      */     //   Java source line #340	-> byte code offset #0
/*      */     //   Java source line #341	-> byte code offset #7
/*      */     //   Java source line #344	-> byte code offset #19
/*      */     //   Java source line #345	-> byte code offset #24
/*      */     //   Java source line #347	-> byte code offset #30
/*      */     //   Java source line #349	-> byte code offset #33
/*      */     //   Java source line #350	-> byte code offset #40
/*      */     //   Java source line #351	-> byte code offset #45
/*      */     //   Java source line #354	-> byte code offset #51
/*      */     //   Java source line #355	-> byte code offset #54
/*      */     //   Java source line #356	-> byte code offset #57
/*      */     //   Java source line #357	-> byte code offset #60
/*      */     //   Java source line #358	-> byte code offset #66
/*      */     //   Java source line #360	-> byte code offset #69
/*      */     //   Java source line #361	-> byte code offset #75
/*      */     //   Java source line #363	-> byte code offset #86
/*      */     //   Java source line #364	-> byte code offset #94
/*      */     //   Java source line #365	-> byte code offset #104
/*      */     //   Java source line #366	-> byte code offset #109
/*      */     //   Java source line #367	-> byte code offset #113
/*      */     //   Java source line #368	-> byte code offset #120
/*      */     //   Java source line #369	-> byte code offset #123
/*      */     //   Java source line #370	-> byte code offset #131
/*      */     //   Java source line #371	-> byte code offset #141
/*      */     //   Java source line #372	-> byte code offset #146
/*      */     //   Java source line #368	-> byte code offset #153
/*      */     //   Java source line #375	-> byte code offset #160
/*      */     //   Java source line #376	-> byte code offset #171
/*      */     //   Java source line #383	-> byte code offset #181
/*      */     //   Java source line #384	-> byte code offset #202
/*      */     //   Java source line #385	-> byte code offset #211
/*      */     //   Java source line #386	-> byte code offset #216
/*      */     //   Java source line #387	-> byte code offset #225
/*      */     //   Java source line #389	-> byte code offset #227
/*      */     //   Java source line #390	-> byte code offset #247
/*      */     //   Java source line #391	-> byte code offset #258
/*      */     //   Java source line #392	-> byte code offset #312
/*      */     //   Java source line #393	-> byte code offset #334
/*      */     //   Java source line #394	-> byte code offset #345
/*      */     //   Java source line #396	-> byte code offset #356
/*      */     //   Java source line #397	-> byte code offset #367
/*      */     //   Java source line #398	-> byte code offset #378
/*      */     //   Java source line #399	-> byte code offset #400
/*      */     //   Java source line #400	-> byte code offset #403
/*      */     //   Java source line #401	-> byte code offset #439
/*      */     //   Java source line #402	-> byte code offset #450
/*      */     //   Java source line #403	-> byte code offset #475
/*      */     //   Java source line #402	-> byte code offset #556
/*      */     //   Java source line #404	-> byte code offset #561
/*      */     //   Java source line #405	-> byte code offset #583
/*      */     //   Java source line #406	-> byte code offset #594
/*      */     //   Java source line #407	-> byte code offset #605
/*      */     //   Java source line #408	-> byte code offset #616
/*      */     //   Java source line #409	-> byte code offset #627
/*      */     //   Java source line #410	-> byte code offset #638
/*      */     //   Java source line #412	-> byte code offset #662
/*      */     //   Java source line #413	-> byte code offset #673
/*      */     //   Java source line #414	-> byte code offset #684
/*      */     //   Java source line #415	-> byte code offset #707
/*      */     //   Java source line #416	-> byte code offset #710
/*      */     //   Java source line #419	-> byte code offset #716
/*      */     //   Java source line #420	-> byte code offset #721
/*      */     //   Java source line #424	-> byte code offset #727
/*      */     //   Java source line #425	-> byte code offset #731
/*      */     //   Java source line #427	-> byte code offset #740
/*      */     //   Java source line #428	-> byte code offset #745
/*      */     //   Java source line #421	-> byte code offset #758
/*      */     //   Java source line #422	-> byte code offset #760
/*      */     //   Java source line #424	-> byte code offset #766
/*      */     //   Java source line #425	-> byte code offset #770
/*      */     //   Java source line #427	-> byte code offset #779
/*      */     //   Java source line #428	-> byte code offset #784
/*      */     //   Java source line #423	-> byte code offset #797
/*      */     //   Java source line #424	-> byte code offset #799
/*      */     //   Java source line #425	-> byte code offset #803
/*      */     //   Java source line #427	-> byte code offset #812
/*      */     //   Java source line #428	-> byte code offset #817
/*      */     //   Java source line #430	-> byte code offset #827
/*      */     //   Java source line #424	-> byte code offset #830
/*      */     //   Java source line #425	-> byte code offset #834
/*      */     //   Java source line #427	-> byte code offset #843
/*      */     //   Java source line #428	-> byte code offset #848
/*      */     //   Java source line #430	-> byte code offset #858
/*      */     //   Java source line #431	-> byte code offset #861
/*      */     //   Java source line #432	-> byte code offset #863
/*      */     //   Java source line #433	-> byte code offset #907
/*      */     //   Java source line #434	-> byte code offset #909
/*      */     //   Java source line #436	-> byte code offset #915
/*      */     //   Java source line #437	-> byte code offset #918
/*      */     //   Java source line #438	-> byte code offset #921
/*      */     //   Java source line #440	-> byte code offset #924
/*      */     //   Java source line #443	-> byte code offset #936
/*      */     //   Java source line #446	-> byte code offset #950
/*      */     //   Java source line #447	-> byte code offset #967
/*      */     //   Java source line #448	-> byte code offset #973
/*      */     //   Java source line #449	-> byte code offset #979
/*      */     //   Java source line #450	-> byte code offset #985
/*      */     //   Java source line #451	-> byte code offset #991
/*      */     //   Java source line #452	-> byte code offset #994
/*      */     //   Java source line #453	-> byte code offset #999
/*      */     //   Java source line #454	-> byte code offset #1019
/*      */     //   Java source line #455	-> byte code offset #1026
/*      */     //   Java source line #456	-> byte code offset #1029
/*      */     //   Java source line #457	-> byte code offset #1041
/*      */     //   Java source line #458	-> byte code offset #1046
/*      */     //   Java source line #459	-> byte code offset #1053
/*      */     //   Java source line #460	-> byte code offset #1058
/*      */     //   Java source line #461	-> byte code offset #1063
/*      */     //   Java source line #462	-> byte code offset #1070
/*      */     //   Java source line #463	-> byte code offset #1075
/*      */     //   Java source line #464	-> byte code offset #1084
/*      */     //   Java source line #465	-> byte code offset #1095
/*      */     //   Java source line #466	-> byte code offset #1103
/*      */     //   Java source line #467	-> byte code offset #1106
/*      */     //   Java source line #471	-> byte code offset #1114
/*      */     //   Java source line #472	-> byte code offset #1119
/*      */     //   Java source line #473	-> byte code offset #1126
/*      */     //   Java source line #474	-> byte code offset #1139
/*      */     //   Java source line #476	-> byte code offset #1156
/*      */     //   Java source line #477	-> byte code offset #1164
/*      */     //   Java source line #478	-> byte code offset #1167
/*      */     //   Java source line #479	-> byte code offset #1174
/*      */     //   Java source line #480	-> byte code offset #1177
/*      */     //   Java source line #481	-> byte code offset #1189
/*      */     //   Java source line #482	-> byte code offset #1196
/*      */     //   Java source line #484	-> byte code offset #1201
/*      */     //   Java source line #485	-> byte code offset #1217
/*      */     //   Java source line #486	-> byte code offset #1222
/*      */     //   Java source line #487	-> byte code offset #1231
/*      */     //   Java source line #488	-> byte code offset #1236
/*      */     //   Java source line #490	-> byte code offset #1241
/*      */     //   Java source line #491	-> byte code offset #1248
/*      */     //   Java source line #492	-> byte code offset #1255
/*      */     //   Java source line #493	-> byte code offset #1266
/*      */     //   Java source line #494	-> byte code offset #1274
/*      */     //   Java source line #495	-> byte code offset #1288
/*      */     //   Java source line #496	-> byte code offset #1296
/*      */     //   Java source line #497	-> byte code offset #1302
/*      */     //   Java source line #498	-> byte code offset #1310
/*      */     //   Java source line #499	-> byte code offset #1319
/*      */     //   Java source line #500	-> byte code offset #1322
/*      */     //   Java source line #501	-> byte code offset #1327
/*      */     //   Java source line #503	-> byte code offset #1334
/*      */     //   Java source line #504	-> byte code offset #1339
/*      */     //   Java source line #505	-> byte code offset #1351
/*      */     //   Java source line #506	-> byte code offset #1380
/*      */     //   Java source line #507	-> byte code offset #1412
/*      */     //   Java source line #508	-> byte code offset #1439
/*      */     //   Java source line #509	-> byte code offset #1442
/*      */     //   Java source line #510	-> byte code offset #1457
/*      */     //   Java source line #511	-> byte code offset #1475
/*      */     //   Java source line #513	-> byte code offset #1488
/*      */     //   Java source line #514	-> byte code offset #1491
/*      */     //   Java source line #479	-> byte code offset #1499
/*      */     //   Java source line #522	-> byte code offset #1509
/*      */     //   Java source line #523	-> byte code offset #1514
/*      */     //   Java source line #525	-> byte code offset #1522
/*      */     //   Java source line #526	-> byte code offset #1527
/*      */     //   Java source line #527	-> byte code offset #1534
/*      */     //   Java source line #528	-> byte code offset #1547
/*      */     //   Java source line #529	-> byte code offset #1554
/*      */     //   Java source line #530	-> byte code offset #1562
/*      */     //   Java source line #531	-> byte code offset #1565
/*      */     //   Java source line #532	-> byte code offset #1577
/*      */     //   Java source line #533	-> byte code offset #1594
/*      */     //   Java source line #534	-> byte code offset #1604
/*      */     //   Java source line #537	-> byte code offset #1607
/*      */     //   Java source line #538	-> byte code offset #1621
/*      */     //   Java source line #540	-> byte code offset #1624
/*      */     //   Java source line #542	-> byte code offset #1631
/*      */     //   Java source line #544	-> byte code offset #1634
/*      */     //   Java source line #545	-> byte code offset #1652
/*      */     //   Java source line #546	-> byte code offset #1663
/*      */     //   Java source line #547	-> byte code offset #1671
/*      */     //   Java source line #548	-> byte code offset #1681
/*      */     //   Java source line #549	-> byte code offset #1698
/*      */     //   Java source line #550	-> byte code offset #1706
/*      */     //   Java source line #552	-> byte code offset #1713
/*      */     //   Java source line #553	-> byte code offset #1716
/*      */     //   Java source line #556	-> byte code offset #1718
/*      */     //   Java source line #557	-> byte code offset #1729
/*      */     //   Java source line #558	-> byte code offset #1734
/*      */     //   Java source line #559	-> byte code offset #1743
/*      */     //   Java source line #560	-> byte code offset #1748
/*      */     //   Java source line #562	-> byte code offset #1753
/*      */     //   Java source line #563	-> byte code offset #1760
/*      */     //   Java source line #565	-> byte code offset #1771
/*      */     //   Java source line #566	-> byte code offset #1782
/*      */     //   Java source line #567	-> byte code offset #1790
/*      */     //   Java source line #568	-> byte code offset #1796
/*      */     //   Java source line #569	-> byte code offset #1804
/*      */     //   Java source line #570	-> byte code offset #1813
/*      */     //   Java source line #571	-> byte code offset #1816
/*      */     //   Java source line #572	-> byte code offset #1821
/*      */     //   Java source line #574	-> byte code offset #1828
/*      */     //   Java source line #575	-> byte code offset #1833
/*      */     //   Java source line #576	-> byte code offset #1845
/*      */     //   Java source line #577	-> byte code offset #1874
/*      */     //   Java source line #578	-> byte code offset #1906
/*      */     //   Java source line #579	-> byte code offset #1933
/*      */     //   Java source line #580	-> byte code offset #1936
/*      */     //   Java source line #581	-> byte code offset #1951
/*      */     //   Java source line #582	-> byte code offset #1969
/*      */     //   Java source line #584	-> byte code offset #1982
/*      */     //   Java source line #585	-> byte code offset #1985
/*      */     //   Java source line #530	-> byte code offset #1993
/*      */     //   Java source line #455	-> byte code offset #2003
/*      */     //   Java source line #595	-> byte code offset #2013
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	2016	0	this	ValidarFirmaXML
/*      */     //   0	2016	1	inputFirmaParaValidar	java.io.InputStream
/*      */     //   0	2016	2	baseUri	String
/*      */     //   0	2016	3	validators	ExtraValidators
/*      */     //   0	2016	4	tsValidator	ITimeStampValidator
/*      */     //   22	895	5	dbf	javax.xml.parsers.DocumentBuilderFactory
/*      */     //   31	892	6	db	javax.xml.parsers.DocumentBuilder
/*      */     //   43	4	7	e1	javax.xml.parsers.ParserConfigurationException
/*      */     //   52	868	7	isour	org.xml.sax.InputSource
/*      */     //   55	871	8	doc	Document
/*      */     //   58	791	9	baosLeido	java.io.ByteArrayOutputStream
/*      */     //   64	579	10	cabecera	byte[]
/*      */     //   67	631	11	length	int
/*      */     //   92	57	12	j	int
/*      */     //   214	4	12	e1	java.io.FileNotFoundException
/*      */     //   225	537	12	e1	org.xml.sax.SAXException
/*      */     //   861	28	12	me	com.sun.org.apache.xerces.internal.impl.io.MalformedByteSequenceException
/*      */     //   907	4	12	e1	IOException
/*      */     //   934	1080	12	res	ArrayList<ResultadoValidacion>
/*      */     //   111	43	13	i	int
/*      */     //   245	105	13	utf8BOM	byte[]
/*      */     //   719	3	13	e	IOException
/*      */     //   758	3	13	e	org.xml.sax.SAXException
/*      */     //   948	771	13	certStatus	ICertStatusRecoverer
/*      */     //   118	16	14	buffer	byte[]
/*      */     //   437	215	14	utf8BOMNotUTF8	byte[]
/*      */     //   971	137	14	trusterCerts	TrustAbstract
/*      */     //   797	31	15	localObject	Object
/*      */     //   977	291	15	trusterOCSP	TrustAbstract
/*      */     //   738	1	16	localIOException1	IOException
/*      */     //   753	1	16	localIOException2	IOException
/*      */     //   777	1	16	localIOException3	IOException
/*      */     //   792	1	16	localIOException4	IOException
/*      */     //   810	1	16	localIOException5	IOException
/*      */     //   825	1	16	localIOException6	IOException
/*      */     //   841	1	16	localIOException7	IOException
/*      */     //   856	1	16	localIOException8	IOException
/*      */     //   983	533	16	trusterCRL	TrustAbstract
/*      */     //   989	567	17	trusterTSA	TrustAbstract
/*      */     //   992	813	18	status	ICertStatus
/*      */     //   997	778	19	statusRes	ICertStatus.CERT_STATUS
/*      */     //   1024	980	20	it	Iterator<ResultadoValidacion>
/*      */     //   1039	898	21	rv	ResultadoValidacion
/*      */     //   1051	527	22	df	DatosFirma
/*      */     //   1124	44	23	ocsps	ArrayList<DatosOCSP>
/*      */     //   1532	16	23	tsas	ArrayList<DatosSelloTiempo>
/*      */     //   1172	328	24	itOcsp	Iterator<DatosOCSP>
/*      */     //   1552	442	24	itTsas	Iterator<DatosSelloTiempo>
/*      */     //   1187	305	25	docsp	DatosOCSP
/*      */     //   1575	411	25	dst	DatosSelloTiempo
/*      */     //   1194	3	26	ocspr	OCSPResp
/*      */     //   1629	14	26	rawTimestamp	byte[]
/*      */     //   1234	3	27	e	Exception
/*      */     //   1317	11	27	ri	RevokedInfo
/*      */     //   1632	89	27	tsaCert	X509Certificate
/*      */     //   1320	106	28	revoked	Date
/*      */     //   1650	3	28	tst	TimeStampToken
/*      */     //   1716	1	28	localException1	Exception
/*      */     //   1746	3	28	e	Exception
/*      */     //   1811	11	28	ri	RevokedInfo
/*      */     //   1349	75	29	formatter	SimpleDateFormat
/*      */     //   1661	3	29	cs	java.security.cert.CertStore
/*      */     //   1814	106	29	revoked	Date
/*      */     //   1669	13	30	certs	java.util.Collection<? extends java.security.cert.Certificate>
/*      */     //   1843	75	30	formatter	SimpleDateFormat
/*      */     //   1696	11	31	cert	java.security.cert.Certificate
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   33	40	43	javax/xml/parsers/ParserConfigurationException
/*      */     //   69	211	214	java/io/FileNotFoundException
/*      */     //   69	211	225	org/xml/sax/SAXException
/*      */     //   227	716	719	java/io/IOException
/*      */     //   731	735	738	java/io/IOException
/*      */     //   745	750	753	java/io/IOException
/*      */     //   227	716	758	org/xml/sax/SAXException
/*      */     //   770	774	777	java/io/IOException
/*      */     //   784	789	792	java/io/IOException
/*      */     //   227	727	797	finally
/*      */     //   758	766	797	finally
/*      */     //   803	807	810	java/io/IOException
/*      */     //   817	822	825	java/io/IOException
/*      */     //   834	838	841	java/io/IOException
/*      */     //   848	853	856	java/io/IOException
/*      */     //   69	211	861	com/sun/org/apache/xerces/internal/impl/io/MalformedByteSequenceException
/*      */     //   69	211	907	java/io/IOException
/*      */     //   1201	1231	1234	java/lang/Exception
/*      */     //   1634	1713	1716	java/lang/Exception
/*      */     //   1718	1743	1746	java/lang/Exception
/*      */   }
/*      */   
/*      */   private void validateTrustCerts(TrustAbstract truster, DatosFirma df)
/*      */   {
/*      */     try
/*      */     {
/*  605 */       truster.isTrusted(df.getCadenaFirma());
/*  606 */       df.setEsCadenaConfianza(ConfianzaEnum.CON_CONFIANZA);
/*      */     } catch (NotTrustedException ex) {
/*  608 */       df.setEsCadenaConfianza(ConfianzaEnum.SIN_CONFIANZA);
/*      */     } catch (UnknownTrustException ex) {
/*  610 */       df.setEsCadenaConfianza(ConfianzaEnum.NO_REVISADO);
/*      */     } catch (TrustException ex) {
/*  612 */       df.setEsCadenaConfianza(ConfianzaEnum.NO_REVISADO);
/*  613 */       LOGGER.error(i18n.getLocalMessage("i18n.mityc.xades.validate.trust.1", new Object[] { ex.getMessage() }));
/*  614 */       if (LOGGER.isDebugEnabled()) {
/*  615 */         LOGGER.debug("", ex);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void validateTrustOCSP(TrustAbstract truster, DatosFirma df)
/*      */   {
/*  625 */     ArrayList<DatosOCSP> ocsps = df.getDatosOCSP();
/*  626 */     if ((ocsps != null) && (ocsps.size() > 0)) {
/*  627 */       Iterator<DatosOCSP> it = ocsps.iterator();
/*  628 */       while (it.hasNext()) {
/*  629 */         DatosOCSP docsp = (DatosOCSP)it.next();
/*  630 */         OCSPResp ocspr = docsp.getRespuestaOCSP();
/*  631 */         if (ocspr != null) {
/*      */           try {
/*  633 */             truster.isTrusted(ocspr);
/*  634 */             docsp.setEsCertConfianza(ConfianzaEnum.CON_CONFIANZA);
/*      */           } catch (NotTrustedException ex) {
/*  636 */             docsp.setEsCertConfianza(ConfianzaEnum.SIN_CONFIANZA);
/*      */           } catch (UnknownTrustException ex) {
/*  638 */             docsp.setEsCertConfianza(ConfianzaEnum.NO_REVISADO);
/*      */           } catch (TrustException ex) {
/*  640 */             docsp.setEsCertConfianza(ConfianzaEnum.NO_REVISADO);
/*  641 */             LOGGER.error(i18n.getLocalMessage("i18n.mityc.xades.validate.trust.2", new Object[] { ex.getMessage() }));
/*  642 */             if (LOGGER.isDebugEnabled()) {
/*  643 */               LOGGER.debug("", ex);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void validateTrustCRL(TrustAbstract truster, DatosFirma df)
/*      */   {
/*  656 */     ArrayList<DatosCRL> crls = df.getDatosCRL();
/*  657 */     if ((crls != null) && (crls.size() > 0)) {
/*  658 */       Iterator<DatosCRL> it = crls.iterator();
/*  659 */       while (it.hasNext()) {
/*  660 */         DatosCRL dcrl = (DatosCRL)it.next();
/*  661 */         X509CRL crl = dcrl.getX509CRL();
/*  662 */         if (crl != null) {
/*      */           try {
/*  664 */             truster.isTrusted(crl);
/*  665 */             dcrl.setEsCertConfianza(ConfianzaEnum.CON_CONFIANZA);
/*      */           } catch (NotTrustedException ex) {
/*  667 */             dcrl.setEsCertConfianza(ConfianzaEnum.SIN_CONFIANZA);
/*      */           } catch (UnknownTrustException ex) {
/*  669 */             dcrl.setEsCertConfianza(ConfianzaEnum.NO_REVISADO);
/*      */           } catch (TrustException ex) {
/*  671 */             dcrl.setEsCertConfianza(ConfianzaEnum.NO_REVISADO);
/*  672 */             LOGGER.error(i18n.getLocalMessage("i18n.mityc.xades.validate.trust.3", new Object[] { ex.getMessage() }));
/*  673 */             if (LOGGER.isDebugEnabled()) {
/*  674 */               LOGGER.debug("", ex);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void validateTrustTSA(TrustAbstract truster, DatosFirma df)
/*      */   {
/*  687 */     ArrayList<DatosSelloTiempo> tsts = df.getDatosSelloTiempo();
/*  688 */     if ((tsts != null) && (tsts.size() > 0)) {
/*  689 */       Iterator<DatosSelloTiempo> it = tsts.iterator();
/*  690 */       while (it.hasNext()) {
/*  691 */         DatosSelloTiempo dst = (DatosSelloTiempo)it.next();
/*  692 */         byte[] rawTimestamp = dst.getRawTimestamp();
/*      */         try
/*      */         {
/*  695 */           TimeStampToken tst = new TimeStampToken(new CMSSignedData(rawTimestamp));
/*      */           try {
/*  697 */             truster.isTrusted(tst);
/*  698 */             dst.setEsCertConfianza(ConfianzaEnum.CON_CONFIANZA);
/*      */           } catch (NotTrustedException ex) {
/*  700 */             dst.setEsCertConfianza(ConfianzaEnum.SIN_CONFIANZA);
/*      */           } catch (UnknownTrustException ex) {
/*  702 */             dst.setEsCertConfianza(ConfianzaEnum.NO_REVISADO);
/*      */           } catch (TrustException ex) {
/*  704 */             dst.setEsCertConfianza(ConfianzaEnum.NO_REVISADO);
/*  705 */             LOGGER.error(i18n.getLocalMessage("i18n.mityc.xades.validate.trust.4", new Object[] { ex.getMessage() }));
/*  706 */             if (!LOGGER.isDebugEnabled()) continue; }
/*  707 */           LOGGER.debug("", ex);
/*      */         }
/*      */         catch (TSPException e) {
/*  710 */           dst.setEsCertConfianza(ConfianzaEnum.NO_REVISADO);
/*  711 */           LOGGER.error(i18n.getLocalMessage("i18n.mityc.xades.validate.trust.4", new Object[] { e.getMessage() }));
/*  712 */           if (LOGGER.isDebugEnabled()) {
/*  713 */             LOGGER.debug("", e);
/*      */           }
/*      */         } catch (IOException e) {
/*  716 */           dst.setEsCertConfianza(ConfianzaEnum.NO_REVISADO);
/*  717 */           LOGGER.error(i18n.getLocalMessage("i18n.mityc.xades.validate.trust.4", new Object[] { e.getMessage() }));
/*  718 */           if (LOGGER.isDebugEnabled()) {
/*  719 */             LOGGER.debug("", e);
/*      */           }
/*      */         } catch (CMSException e) {
/*  722 */           dst.setEsCertConfianza(ConfianzaEnum.NO_REVISADO);
/*  723 */           LOGGER.error(i18n.getLocalMessage("i18n.mityc.xades.validate.trust.4", new Object[] { e.getMessage() }));
/*  724 */           if (LOGGER.isDebugEnabled()) {
/*  725 */             LOGGER.debug("", e);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLocale(String locale)
/*      */   {
/*  738 */     I18n.setLocale(locale, locale.toUpperCase());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setXAdESSchema(XAdESSchemas schema, boolean activate)
/*      */   {
/*  749 */     if (schema != null) {
/*  750 */       if (activate) {
/*  751 */         this.esquemasParaValidar.add(schema.getSchemaUri());
/*      */       } else {
/*  753 */         this.esquemasParaValidar.remove(schema.getSchemaUri());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ArrayList<ResultadoValidacion> validar(Document doc, String baseUri, ExtraValidators validators, ITimeStampValidator timeStampValidator)
/*      */     throws FirmaXMLError
/*      */   {
/*  770 */     ArrayList<ResultadoValidacion> resultados = new ArrayList();
/*      */     
/*  772 */     Utils.addBCProvider();
/*      */     
/*      */     try
/*      */     {
/*  776 */       if (this.tsValidator == null) {
/*  777 */         this.tsValidator = timeStampValidator;
/*      */       }
/*      */       
/*      */ 
/*  781 */       this.uriXmlNS = "http://www.w3.org/2000/09/xmldsig#";
/*      */       
/*  783 */       if (this.esquemasParaValidar.isEmpty())
/*      */       {
/*      */ 
/*  786 */         LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error1"));
/*  787 */         throw new FirmaXMLError(I18n.getResource("libreriaxades.validarfirmaxml.error1"));
/*      */       }
/*      */       
/*      */ 
/*  791 */       Init.init();
/*      */       
/*      */ 
/*  794 */       NodeList listaFirmas = doc.getElementsByTagNameNS(this.uriXmlNS, "Signature");
/*  795 */       if (listaFirmas.getLength() == 0)
/*      */       {
/*      */ 
/*  798 */         LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error2"));
/*  799 */         throw new FirmaXMLError(I18n.getResource("libreriaxades.validarfirmaxml.error2"));
/*      */       }
/*      */       
/*      */ 
/*  803 */       int longitud = listaFirmas.getLength();
/*  804 */       LOGGER.debug(I18n.getResource("libreriaxades.validarfirmaxml.info1") + " " + longitud);
/*      */       
/*      */ 
/*  807 */       this.truster = (validators != null ? validators.getTrusterCerts() : null);
/*      */       
/*      */ 
/*  810 */       List<IValidacionPolicy> policies = validators != null ? validators.getPolicies() : null;
/*      */       
/*      */ 
/*  813 */       for (int i = 0; i < longitud; i++) {
/*  814 */         resultados.add(validaFirma(listaFirmas.item(i), baseUri, policies));
/*      */       }
/*      */       
/*      */ 
/*  818 */       Iterator<ResultadoValidacion> itResVal = resultados.iterator();
/*  819 */       while (itResVal.hasNext()) {
/*  820 */         ResultadoValidacion rv = (ResultadoValidacion)itResVal.next();
/*      */         
/*  822 */         DatosFirma datos = rv.getDatosFirma();
/*      */         
/*  824 */         rv.setContrafirmadoPor(new ArrayList());
/*  825 */         if (datos != null)
/*      */         {
/*  827 */           String id = datos.getSigValueId();
/*  828 */           if (id != null)
/*      */           {
/*  830 */             Iterator<ResultadoValidacion> itResVal2 = resultados.iterator();
/*  831 */             while (itResVal2.hasNext()) {
/*  832 */               ResultadoValidacion rv2 = (ResultadoValidacion)itResVal2.next();
/*  833 */               DatosFirma datos2 = rv2.getDatosFirma();
/*      */               
/*  835 */               if ((datos2 != null) && (!id.equals(datos2.getSigValueId())))
/*      */               {
/*  837 */                 ArrayList<String> contrafirmaA = datos2.getContraFirma();
/*      */                 
/*      */ 
/*  840 */                 if ((contrafirmaA != null) && (contrafirmaA.contains(id))) {
/*  841 */                   rv.addContrafirmadoPor(rv2);
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*  849 */       ICertStatusRecoverer certStatus = validators != null ? validators.getCertStatus() : null;
/*  850 */       if (certStatus != null) {
/*  851 */         Iterator<ResultadoValidacion> it = resultados.iterator();
/*  852 */         while (it.hasNext()) {
/*  853 */           ResultadoValidacion rv = (ResultadoValidacion)it.next();
/*      */           
/*  855 */           if (rv.isValidate()) {
/*  856 */             Date firstTimestamp = null;
/*  857 */             if (EnumFormatoFirma.XAdES_T.compareTo(rv.getEnumNivel()) <= 0) {
/*  858 */               ArrayList<DatosSelloTiempo> listTS = rv.getDatosFirma().getDatosSelloTiempo();
/*  859 */               if (listTS != null) {
/*  860 */                 Iterator<DatosSelloTiempo> itTS = listTS.iterator();
/*  861 */                 while (itTS.hasNext()) {
/*  862 */                   DatosSelloTiempo dst = (DatosSelloTiempo)itTS.next();
/*  863 */                   if (firstTimestamp == null) {
/*  864 */                     firstTimestamp = dst.getFecha();
/*  865 */                   } else if (firstTimestamp.after(dst.getFecha()))
/*  866 */                     firstTimestamp = dst.getFecha();
/*      */                 }
/*      */               }
/*      */             }
/*  870 */             CertPath cp = rv.getDatosFirma().getCadenaFirma();
/*  871 */             X509Certificate certificate = (X509Certificate)cp.getCertificates().get(0);
/*  872 */             BasicOCSPResp basicResponse; if (EnumFormatoFirma.XAdES_X.compareTo(rv.getEnumNivel()) > 0) {
/*      */               try {
/*  874 */                 ICertStatus respYCerts = certStatus.getCertStatus(certificate);
/*  875 */                 if (respYCerts != null) {
/*  876 */                   rv.setCertStatus(respYCerts);
/*  877 */                   if (ICertStatus.CERT_STATUS.revoked.equals(respYCerts.getStatus())) {
/*  878 */                     if (firstTimestamp != null) {
/*  879 */                       RevokedInfo ri = respYCerts.getRevokedInfo();
/*  880 */                       Date revoked = ri != null ? ri.getRevokedDate() : null;
/*      */                       
/*  882 */                       if ((revoked != null) && (firstTimestamp.before(revoked))) {
/*  883 */                         rv.setValidate(false);
/*  884 */                         rv.setResultado(ResultadoEnum.UNKNOWN);
/*  885 */                         rv.setLog(null);
/*  886 */                         continue;
/*      */                       }
/*      */                     } else {
/*  889 */                       RevokedInfo ri = respYCerts.getRevokedInfo();
/*  890 */                       Date revoked = ri != null ? ri.getRevokedDate() : null;
/*      */                       
/*  892 */                       Date signingTime = rv.getDatosFirma().getFechaFirma();
/*  893 */                       if ((revoked != null) && (signingTime.before(revoked))) {
/*  894 */                         rv.setValidate(false);
/*  895 */                         rv.setResultado(ResultadoEnum.UNKNOWN);
/*  896 */                         rv.setLog(i18n.getLocalMessage("i18n.mityc.xades.validate.15", new Object[] { revoked }) + "\n" + 
/*  897 */                           i18n.getLocalMessage("i18n.mityc.xades.validate.17", new Object[] { signingTime }));
/*  898 */                         continue;
/*      */                       }
/*      */                     }
/*      */                     
/*  902 */                     RevokedInfo ri = respYCerts.getRevokedInfo();
/*  903 */                     if (ri != null) {
/*  904 */                       Date revoked = ri.getRevokedDate();
/*  905 */                       if (revoked != null) {
/*  906 */                         SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
/*  907 */                         rv.setLog(i18n.getLocalMessage("i18n.mityc.xades.validate.15", new Object[] { formatter.format(revoked) }));
/*  908 */                         LOGGER.info(i18n.getLocalMessage("i18n.mityc.xades.validate.15", new Object[] { formatter.format(revoked) }));
/*      */                       } else {
/*  910 */                         LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.error165"));
/*      */                       }
/*      */                     } else {
/*  913 */                       LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.error165"));
/*      */                     }
/*      */                     
/*  916 */                     if (EnumFormatoFirma.XAdES_C.compareTo(rv.getEnumNivel()) <= 0) {
/*  917 */                       BasicOCSPResp basicResponse = getOCSPResponseFromSignature(rv, certificate);
/*  918 */                       if (basicResponse != null) {
/*  919 */                         SingleResp[] responses = basicResponse.getResponses();
/*  920 */                         if (responses.length == 1) {
/*  921 */                           SingleResp resp = responses[0];
/*  922 */                           Object status = resp.getCertStatus();
/*  923 */                           if (status == CertificateStatus.GOOD) {
/*  924 */                             SimpleDateFormat f = new SimpleDateFormat("dd/MM/yyyy H:mm:ss");
/*  925 */                             String log = rv.getLog();
/*  926 */                             if ((log != null) && (log.length() > 0)) {
/*  927 */                               log = log + "\nSe adjuntan respuestas OCSP con fecha: " + f.format(basicResponse.getProducedAt());
/*      */                             } else {
/*  929 */                               log = "El certificado firmante esta revocado.\nSe adjuntan respuestas OCSP con fecha: " + f.format(basicResponse.getProducedAt());
/*      */                             }
/*  931 */                             rv.setLog(log);
/*  932 */                             rv.setValidate(true);
/*  933 */                             rv.setResultado(ResultadoEnum.VALID);
/*      */                           } else {
/*  935 */                             rv.setValidate(false);
/*  936 */                             rv.setResultado(ResultadoEnum.INVALID);
/*  937 */                             rv.setLog(null);
/*      */                           }
/*      */                         }
/*      */                       } else {
/*  941 */                         rv.setValidate(false);
/*  942 */                         rv.setResultado(ResultadoEnum.INVALID);
/*  943 */                         rv.setLog(null);
/*      */                       }
/*      */                     } else {
/*  946 */                       rv.setValidate(false);
/*  947 */                       rv.setResultado(ResultadoEnum.INVALID);
/*  948 */                       rv.setLog(null);
/*      */                     }
/*      */                     
/*  951 */                     logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error165"));
/*      */                   }
/*  953 */                   else if (ICertStatus.CERT_STATUS.unknown.equals(respYCerts.getStatus())) {
/*  954 */                     if (EnumFormatoFirma.XAdES_C.compareTo(rv.getEnumNivel()) <= 0) {
/*  955 */                       BasicOCSPResp basicResponse = getOCSPResponseFromSignature(rv, certificate);
/*  956 */                       if (basicResponse != null) {
/*  957 */                         SingleResp[] responses = basicResponse.getResponses();
/*  958 */                         if (responses.length == 1) {
/*  959 */                           SingleResp resp = responses[0];
/*  960 */                           Object status = resp.getCertStatus();
/*  961 */                           if (status == CertificateStatus.GOOD) {
/*  962 */                             SimpleDateFormat f = new SimpleDateFormat("dd/MM/yyyy H:mm:ss");
/*  963 */                             rv.setLog("El certificado firmante tiene un estado de revocación desconocido.\nSe adjuntan respuestas OCSP con fecha: " + f.format(basicResponse.getProducedAt()));
/*  964 */                             rv.setValidate(true);
/*  965 */                             rv.setResultado(ResultadoEnum.VALID);
/*      */                           } else {
/*  967 */                             rv.setValidate(false);
/*  968 */                             rv.setResultado(ResultadoEnum.UNKNOWN);
/*  969 */                             rv.setLog(null);
/*      */                           }
/*      */                         }
/*      */                       } else {
/*  973 */                         rv.setValidate(false);
/*  974 */                         rv.setResultado(ResultadoEnum.UNKNOWN);
/*  975 */                         rv.setLog(null);
/*      */                       }
/*      */                     } else {
/*  978 */                       rv.setValidate(false);
/*  979 */                       rv.setResultado(ResultadoEnum.UNKNOWN);
/*  980 */                       rv.setLog(null);
/*      */                     }
/*  982 */                     LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.error166"));
/*  983 */                     logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error166"));
/*      */                   }
/*      */                   else
/*      */                   {
/*  987 */                     if (LOGGER.isTraceEnabled())
/*  988 */                       LOGGER.trace(I18n.getResource("libreriaxades.validarfirmaxml.error167"));
/*  989 */                     logv.info(I18n.getResource("libreriaxades.validarfirmaxml.error167"));
/*      */                   }
/*      */                 }
/*  992 */                 else if (EnumFormatoFirma.XAdES_C.compareTo(rv.getEnumNivel()) <= 0) {
/*  993 */                   basicResponse = getOCSPResponseFromSignature(rv, certificate);
/*  994 */                   if (basicResponse != null) {
/*  995 */                     SingleResp[] responses = basicResponse.getResponses();
/*  996 */                     if (responses.length == 1) {
/*  997 */                       SingleResp resp = responses[0];
/*  998 */                       Object status = resp.getCertStatus();
/*  999 */                       if (status == CertificateStatus.GOOD) {
/* 1000 */                         SimpleDateFormat f = new SimpleDateFormat("dd/MM/yyyy H:mm:ss");
/* 1001 */                         rv.setLog("El certificado firmante tiene un estado de revocación desconocido.\nSe adjuntan respuestas OCSP con fecha: " + f.format(basicResponse.getProducedAt()));
/* 1002 */                         rv.setValidate(true);
/* 1003 */                         rv.setResultado(ResultadoEnum.VALID);
/*      */                       } else {
/* 1005 */                         rv.setValidate(false);
/* 1006 */                         rv.setResultado(ResultadoEnum.UNKNOWN);
/* 1007 */                         rv.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error166"));
/*      */                       }
/*      */                     }
/*      */                   } else {
/* 1011 */                     rv.setValidate(false);
/* 1012 */                     rv.setResultado(ResultadoEnum.UNKNOWN);
/* 1013 */                     rv.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error166"));
/*      */                   }
/*      */                 } else {
/* 1016 */                   rv.setValidate(false);
/* 1017 */                   rv.setResultado(ResultadoEnum.UNKNOWN);
/* 1018 */                   rv.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error166"));
/* 1019 */                   LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.error166"));
/* 1020 */                   logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error166"));
/*      */                 }
/*      */               }
/*      */               catch (CertStatusException ex) {
/* 1024 */                 rv.setResultado(ResultadoEnum.UNKNOWN);
/* 1025 */                 rv.setLog(i18n.getLocalMessage("i18n.mityc.xades.validate.14"));
/* 1026 */                 LOGGER.info(ex.getMessage(), ex);
/* 1027 */                 logv.error(ex.getMessage());
/*      */               }
/*      */             }
/*      */             
/*      */ 
/*      */ 
/* 1033 */             if (this.arrayDatosOCSP != null) {
/* 1034 */               for (DatosOCSP currentOCSP : this.arrayDatosOCSP) {
/* 1035 */                 if (currentOCSP.getRevockedStatus().equals(ICertStatus.CERT_STATUS.revoked)) {
/* 1036 */                   rv.setValidate(false);
/* 1037 */                   rv.setResultado(ResultadoEnum.INVALID);
/* 1038 */                   rv.setLog(i18n.getLocalMessage("i18n.mityc.xades.validate.19", new Object[] { currentOCSP.getCertConsultado() }));
/* 1039 */                 } else if (currentOCSP.getRevockedStatus().equals(ICertStatus.CERT_STATUS.unknown)) {
/* 1040 */                   rv.setValidate(false);
/* 1041 */                   rv.setResultado(ResultadoEnum.UNKNOWN);
/* 1042 */                   rv.setLog(i18n.getLocalMessage("i18n.mityc.xades.validate.20", new Object[] { currentOCSP.getCertConsultado() }));
/*      */                 }
/*      */                 
/*      */               }
/*      */               
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/* 1051 */               rv.setValidate(false);
/* 1052 */               rv.setResultado(ResultadoEnum.INVALID);
/* 1053 */               rv.setLog(i18n.getLocalMessage("i18n.mityc.xades.validate.21"));
/*      */             }
/*      */             
/* 1056 */             BasicOCSPResp basicResponse = getOCSPResponseFromSignature(rv, certificate);
/* 1057 */             if (basicResponse != null) {
/* 1058 */               SingleResp[] responses = basicResponse.getResponses();
/* 1059 */               if (responses.length == 1) {
/* 1060 */                 SingleResp resp = responses[0];
/* 1061 */                 Object status = resp.getCertStatus();
/* 1062 */                 if (status == CertificateStatus.GOOD) {
/* 1063 */                   rv.setValidate(true);
/* 1064 */                   rv.setResultado(ResultadoEnum.VALID);
/*      */                 } else {
/* 1066 */                   rv.setValidate(false);
/* 1067 */                   rv.setResultado(ResultadoEnum.INVALID);
/* 1068 */                   rv.setLog(null);
/*      */                 }
/*      */               }
/*      */             } else {
/* 1072 */               rv.setValidate(false);
/* 1073 */               rv.setResultado(ResultadoEnum.INVALID);
/* 1074 */               rv.setLog(null);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1081 */       doc = null;
/*      */       
/* 1083 */       return resultados;
/*      */     } finally {
/*      */       try {
/* 1086 */         Security.removeProvider("BC");
/*      */       } catch (Exception e) {
/* 1088 */         if (LOGGER.isDebugEnabled()) {
/* 1089 */           LOGGER.debug(e);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private BasicOCSPResp getOCSPResponseFromSignature(ResultadoValidacion rv, X509Certificate certificate)
/*      */   {
/* 1097 */     BasicOCSPResp basicResponse = null;
/*      */     try {
/* 1099 */       ArrayList<DatosOCSP> datos = rv.getDatosFirma().getDatosOCSP();
/* 1100 */       for (int i = 0; i < datos.size(); i++) {
/* 1101 */         if (((DatosOCSP)datos.get(i)).getCertConsultado().equals(certificate.getSubjectX500Principal().toString())) {
/* 1102 */           basicResponse = (BasicOCSPResp)((DatosOCSP)datos.get(i)).getRespuestaOCSP().getResponseObject();
/* 1103 */           break;
/*      */         }
/*      */       }
/*      */     } catch (Throwable e) {
/* 1107 */       LOGGER.debug("Error al acceder a las datos OCSP", e); }
/* 1108 */     return basicResponse;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ArrayList<ResultadoValidacion> validar(Document doc, String baseUri, ExtraValidators validators)
/*      */     throws FirmaXMLError
/*      */   {
/* 1122 */     return validar(doc, baseUri, validators, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultadoValidacion validar(Node firma, String baseUri, List<IValidacionPolicy> policies)
/*      */   {
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 1137 */       if (this.uriXmlNS == null) {
/* 1138 */         this.uriXmlNS = "http://www.w3.org/2000/09/xmldsig#";
/*      */       }
/*      */       
/* 1141 */       Init.init();
/*      */       
/* 1143 */       return validaFirma(firma, baseUri, policies);
/*      */     } finally {
/*      */       try {
/* 1146 */         Security.removeProvider("BC");
/*      */       } catch (Exception e) {
/* 1148 */         if (LOGGER.isDebugEnabled()) {
/* 1149 */           LOGGER.debug(e);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ResultadoValidacion validaFirma(Node firma, String baseUri, List<IValidacionPolicy> policies)
/*      */   {
/* 1164 */     if (baseUri == null) {
/* 1165 */       baseUri = new File("./").getAbsolutePath();
/*      */     }
/*      */     
/*      */ 
/* 1169 */     this.politicas = new ArrayList();
/* 1170 */     if ((policies != null) && (policies.size() > 0)) {
/* 1171 */       Iterator<IValidacionPolicy> it = policies.iterator();
/* 1172 */       while (it.hasNext()) {
/* 1173 */         IValidacionPolicy valPol = (IValidacionPolicy)it.next();
/* 1174 */         if (valPol != null) {
/* 1175 */           PolicyResult pr = new PolicyResult();
/* 1176 */           pr.setPolicyVal(valPol);
/* 1177 */           this.politicas.add(pr);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1182 */     this.resultado = new ResultadoValidacion();
/* 1183 */     X509Certificate cert = null;
/* 1184 */     XMLSignature firmaDocumento = null;
/* 1185 */     String uriDS = null;
/*      */     try
/*      */     {
/* 1188 */       firmaDocumento = new XMLSignature((Element)firma, baseUri);
/* 1189 */       if (this.resolvers != null) {
/* 1190 */         Iterator<ResourceResolverSpi> it = this.resolvers.iterator();
/* 1191 */         while (it.hasNext()) {
/* 1192 */           firmaDocumento.addResourceResolver((ResourceResolverSpi)it.next());
/*      */         }
/*      */       }
/* 1195 */       uriDS = firmaDocumento.getBaseNamespace();
/*      */     } catch (XMLSignatureException e) {
/* 1197 */       LOGGER.error(e.getMessage(), e);
/* 1198 */       this.resultado.setDatosFirma(new DatosFirma());
/* 1199 */       this.resultado.setDoc(firma.getOwnerDocument());
/* 1200 */       this.resultado.setFirmados(new ArrayList());
/*      */       
/* 1202 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error7") + 
/* 1203 */         ": " + e.getMessage());
/* 1204 */       this.resultado.setValidate(false);
/* 1205 */       this.resultado.setResultado(ResultadoEnum.INVALID);
/* 1206 */       return this.resultado;
/*      */     } catch (XMLSecurityException e) {
/* 1208 */       LOGGER.error(e.getMessage(), e);
/* 1209 */       this.resultado.setDatosFirma(new DatosFirma());
/* 1210 */       this.resultado.setDoc(firma.getOwnerDocument());
/* 1211 */       this.resultado.setFirmados(new ArrayList());
/* 1212 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error7") + 
/* 1213 */         ": " + e.getMessage());
/* 1214 */       this.resultado.setValidate(false);
/* 1215 */       return this.resultado;
/*      */     }
/*      */     try
/*      */     {
/* 1219 */       this.resultado.setBaseURI(new URI(URIEncoder.encode(baseUri, "UTF-8")));
/*      */     } catch (URISyntaxException ex) {
/* 1221 */       LOGGER.error(ex.getMessage(), ex);
/*      */     } catch (UnsupportedEncodingException ex) {
/* 1223 */       LOGGER.error(ex.getMessage(), ex);
/*      */     }
/*      */     
/*      */ 
/* 1227 */     this.datosFirma = new DatosFirma();
/* 1228 */     this.firmados = new ArrayList();
/* 1229 */     this.arrayDatosSello = new ArrayList();
/* 1230 */     this.arrayDatosCRL = new ArrayList();
/* 1231 */     this.arrayDatosOCSP = new ArrayList();
/* 1232 */     ArrayList<String> cfA = new ArrayList();
/* 1233 */     this.resultado.setDatosFirma(this.datosFirma);
/* 1234 */     this.resultado.setDoc(firma.getOwnerDocument());
/* 1235 */     this.resultado.setFirmados(this.firmados);
/*      */     
/*      */ 
/* 1238 */     EstructuraFirma estructuraFirma = obtenerEsquema((Element)firma);
/* 1239 */     if ((estructuraFirma == null) || (estructuraFirma.esquema == null))
/*      */     {
/* 1241 */       LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error1"));
/* 1242 */       logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error1"));
/*      */       
/* 1244 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error1"));
/* 1245 */       this.resultado.setValidate(false);
/* 1246 */       this.resultado.setResultado(ResultadoEnum.UNKNOWN);
/*      */     } else {
/* 1248 */       estructuraFirma.xmlSig = firmaDocumento;
/* 1249 */       this.datosFirma.setEsquema(estructuraFirma.esquema);
/* 1250 */       logv.info("Xml Schema: " + estructuraFirma.esquema);
/*      */     }
/*      */     
/*      */ 
/* 1254 */     ArrayList<Element> signatureValues = null;
/*      */     try {
/* 1256 */       signatureValues = UtilidadTratarNodo.obtenerNodos((Element)firma, 
/* 1257 */         2, new NombreNodo(this.uriXmlNS, "SignatureValue"));
/*      */     } catch (FirmaXMLError e) {
/* 1259 */       LOGGER.error(e.getMessage(), e);
/* 1260 */       logv.error(e.getMessage());
/*      */       
/* 1262 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error5"));
/* 1263 */       this.resultado.setValidate(false);
/* 1264 */       this.resultado.setResultado(ResultadoEnum.INVALID);
/* 1265 */       return this.resultado;
/*      */     }
/*      */     
/* 1268 */     if ((signatureValues != null) && (signatureValues.size() > 0)) {
/* 1269 */       String id = ((Element)signatureValues.get(0)).getAttribute("Id");
/* 1270 */       if ((id != null) && (!"".equals(id))) {
/* 1271 */         this.datosFirma.setSigValueId(id);
/*      */       }
/*      */     }
/*      */     
/* 1275 */     getConstantesEsquema(estructuraFirma.esquema);
/*      */     
/*      */ 
/*      */ 
/* 1279 */     if ((estructuraFirma != null) && (estructuraFirma.esquema != null)) {
/* 1280 */       obtenerCadenaCertificados(estructuraFirma);
/*      */     }
/*      */     
/*      */ 
/* 1284 */     ArrayList<Element> nodosReference = new ArrayList();
/* 1285 */     SignedInfo si = firmaDocumento.getSignedInfo();
/* 1286 */     for (int i = 0; i < si.getLength(); i++) {
/*      */       try {
/* 1288 */         Reference ref = si.item(i);
/* 1289 */         nodosReference.add(si.item(i).getElement());
/* 1290 */         DatosNodosFirmados dnf = new DatosNodosFirmados();
/* 1291 */         dnf.setReference(new ReferenceProxy(ref));
/* 1292 */         this.datosFirma.addDatosNodoFirmado(dnf);
/*      */       } catch (XMLSecurityException ex) {
/* 1294 */         LOGGER.warn(i18n.getLocalMessage("i18n.mityc.xades.validate.7", new Object[] { ex.getMessage() }));
/*      */       }
/*      */     }
/*      */     
/* 1298 */     int nodeFileReferenceLength = nodosReference.size();
/* 1299 */     for (int f = 0; f < nodeFileReferenceLength; f++)
/*      */     {
/* 1301 */       Element elementReference = (Element)nodosReference.get(f);
/* 1302 */       String referenceUri = elementReference.getAttribute("URI");
/*      */       
/* 1304 */       if (referenceUri != null) {
/* 1305 */         this.firmados.add(referenceUri);
/*      */       }
/*      */       
/* 1308 */       if ((referenceUri != "") && 
/* 1309 */         (referenceUri.startsWith("#")))
/*      */       {
/* 1311 */         Element nodo = UtilidadTratarNodo.getElementById(firma.getOwnerDocument(), referenceUri.substring(1));
/*      */         
/* 1313 */         if (nodo != null)
/*      */         {
/* 1315 */           if ((nodo.getLocalName().equals("SignatureValue")) && 
/* 1316 */             (!referenceUri.substring(1).equals(this.datosFirma.getSigValueId())))
/*      */           {
/* 1318 */             Node cs = firma.getParentNode();
/* 1319 */             if ((cs.getNodeType() == 1) && 
/* 1320 */               (((Element)cs).getLocalName().equals("CounterSignature")) && (
/* 1321 */               (cs.getChildNodes() == null) || (cs.getChildNodes().getLength() != 1))) {
/* 1322 */               LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error172"));
/* 1323 */               logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error173"));
/*      */               
/* 1325 */               this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error173"));
/* 1326 */               this.resultado.setValidate(false);
/* 1327 */               this.resultado.setResultado(ResultadoEnum.INVALID);
/*      */               
/* 1329 */               return this.resultado;
/*      */             }
/*      */             
/*      */ 
/* 1333 */             cfA.add(referenceUri.substring(1));
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1339 */     if ((cfA != null) && (cfA.size() > 0)) {
/* 1340 */       this.datosFirma.setContraFirma(cfA);
/*      */     }
/*      */     
/* 1343 */     Node padre = firma.getParentNode();
/* 1344 */     if ((padre != null) && 
/* 1345 */       ("CounterSignature".equals(padre.getLocalName())))
/*      */     {
/* 1347 */       boolean hayReferencia = false;
/*      */       
/*      */ 
/* 1350 */       Node sigNode = padre.getParentNode().getParentNode().getParentNode().getParentNode().getParentNode();
/* 1351 */       NodeList hijosSigNode = sigNode.getChildNodes();
/* 1352 */       Element sigValueNode = null;
/* 1353 */       for (int i = 0; i < hijosSigNode.getLength(); i++) {
/* 1354 */         if ("SignatureValue".equals(hijosSigNode.item(i).getLocalName())) {
/* 1355 */           sigValueNode = (Element)hijosSigNode.item(i);
/*      */         }
/*      */       }
/* 1358 */       if (sigValueNode == null)
/*      */       {
/* 1360 */         LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/* 1361 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/*      */         
/* 1363 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/* 1364 */         this.resultado.setValidate(false);
/* 1365 */         this.resultado.setResultado(ResultadoEnum.INVALID);
/* 1366 */         return this.resultado;
/*      */       }
/*      */       
/*      */ 
/* 1370 */       for (int f = 0; f < nodeFileReferenceLength; f++) {
/* 1371 */         Element elementReference = (Element)nodosReference.get(f);
/* 1372 */         String uri = elementReference.getAttribute("URI");
/*      */         
/* 1374 */         if ((uri != null) && (uri != "") && 
/* 1375 */           (uri.startsWith("#")))
/*      */         {
/* 1377 */           Element nodoSigValue = UtilidadTratarNodo.getElementById(firma.getOwnerDocument(), uri.substring(1));
/* 1378 */           if ((nodoSigValue != null) && (nodoSigValue.equals(sigValueNode))) {
/* 1379 */             hayReferencia = true;
/* 1380 */             if (XAdESSchemas.XAdES_132.equals(estructuraFirma.esquema)) {
/* 1381 */               String tipo = elementReference.getAttribute("Type");
/* 1382 */               if (!"http://uri.etsi.org/01903#CountersignedSignature".equals(tipo)) {
/* 1383 */                 LOGGER.warn("Atención. Nodo Reference no está incluyendo tipo Contrafirma (ETSI TS 101 903 v1.3.2 7.2.4.1");
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 1390 */       if (!hayReferencia)
/*      */       {
/* 1392 */         LOGGER.error("Contrafirma mal formada: No se encuentra una referencia bien formada al nodo \"" + 
/* 1393 */           sigValueNode.getAttribute("Id") + "\"");
/* 1394 */         logv.error("La contrafirma no esta firmando el nodo SignatureValue de la firma que lo contiene");
/*      */         
/* 1396 */         this.resultado.setLog("Contrafirma inválida. La firma validada no contrafirma a la firma que lo contiene");
/* 1397 */         this.resultado.setValidate(false);
/* 1398 */         this.resultado.setResultado(ResultadoEnum.INVALID);
/* 1399 */         return this.resultado;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1404 */     if ((this.cadenaCertificados != null) && (this.cadenaCertificados.size() != 0)) {
/* 1405 */       cert = (X509Certificate)this.cadenaCertificados.get(0);
/* 1406 */       logv.info("Signing Certificate: " + cert.getSubjectDN().toString());
/*      */     }
/*      */     else {
/* 1409 */       if (estructuraFirma.esquema != null) {
/* 1410 */         LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/* 1411 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/* 1412 */         this.resultado.setValidate(false);
/* 1413 */         this.resultado.setResultado(ResultadoEnum.INVALID);
/* 1414 */         return this.resultado;
/*      */       }
/*      */       
/* 1417 */       return this.resultado;
/*      */     }
/*      */     
/*      */ 
/* 1421 */     if (cert != null) {
/*      */       try {
/* 1423 */         this.esValido = firmaDocumento.checkSignatureValue(cert);
/*      */       } catch (XMLSignatureException ex) {
/* 1425 */         LOGGER.error(ex, ex);
/*      */         
/* 1427 */         LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.error105"));
/* 1428 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error105"));
/*      */         
/* 1430 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error105"));
/* 1431 */         this.resultado.setValidate(false);
/* 1432 */         this.resultado.setResultado(ResultadoEnum.INVALID);
/* 1433 */         return this.resultado;
/*      */       }
/* 1435 */       if (this.esValido) {
/* 1436 */         logv.info("XMLDSig Core Validation: Passed");
/* 1437 */         this.resultado.setIntegrity(true);
/*      */       }
/*      */       else {
/* 1440 */         for (int i = 0; i < nodosReference.size(); i++) {
/* 1441 */           Element elementReference = (Element)nodosReference.get(i);
/*      */           
/* 1443 */           NodeList childs = elementReference.getElementsByTagName("*");
/* 1444 */           String method = null;
/* 1445 */           String digest = null;
/* 1446 */           for (int j = 0; j < childs.getLength(); j++) {
/* 1447 */             if (childs.item(j).getLocalName().contains("DigestValue")) {
/* 1448 */               digest = childs.item(j).getFirstChild().getNodeValue();
/* 1449 */             } else if (childs.item(j).getLocalName().contains("DigestMethod")) {
/* 1450 */               NamedNodeMap attribs = childs.item(j).getAttributes();
/* 1451 */               for (int k = 0; k < attribs.getLength(); k++) {
/* 1452 */                 if (attribs.item(k).getLocalName().contains("Algorithm")) {
/* 1453 */                   method = attribs.item(k).getNodeValue();
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/* 1458 */           byte[] abyte0 = Base64.decode(digest);
/*      */           
/*      */ 
/* 1461 */           String uri = elementReference.getAttribute("URI");
/* 1462 */           byte[] abyte1 = null;
/* 1463 */           if ((uri != null) && (uri != "")) {
/* 1464 */             if (uri.startsWith("#")) {
/* 1465 */               uri = uri.substring(1);
/*      */             }
/* 1467 */             Element nodoReferenciado = UtilidadTratarNodo.getElementById(firma.getOwnerDocument(), uri);
/*      */             try
/*      */             {
/* 1470 */               if (nodoReferenciado != null) {
/* 1471 */                 MessageDigestAlgorithm alg = MessageDigestAlgorithm.getInstance(nodoReferenciado.getOwnerDocument(), method);
/* 1472 */                 alg.reset();
/*      */                 
/* 1474 */                 NodeList nodosCanonicalizationMethod = ((Element)elementReference.getParentNode()).getElementsByTagNameNS("http://www.w3.org/2000/09/xmldsig#", 
/* 1475 */                   "CanonicalizationMethod");
/* 1476 */                 int numNodosCanonicalization = nodosCanonicalizationMethod.getLength();
/* 1477 */                 CanonicalizationEnum canonicalization = null;
/* 1478 */                 if (numNodosCanonicalization > 0) {
/* 1479 */                   Element nodoCanonicalizationMethod = (Element)nodosCanonicalizationMethod.item(0);
/* 1480 */                   String meth = nodoCanonicalizationMethod.getAttribute("Algorithm");
/* 1481 */                   canonicalization = CanonicalizationEnum.getCanonicalization(meth);
/* 1482 */                   if (canonicalization.equals(CanonicalizationEnum.UNKNOWN)) {
/* 1483 */                     canonicalization = CanonicalizationEnum.C14N_OMIT_COMMENTS;
/*      */                   }
/*      */                 }
/* 1486 */                 if (uri.equals("")) {
/* 1487 */                   Transforms tr = new Transforms(firma.getOwnerDocument());
/* 1488 */                   tr.addTransform(canonicalization.toString());
/* 1489 */                   XMLSignatureInput xmlSignatureInput = new XMLSignatureInput(nodoReferenciado);
/* 1490 */                   xmlSignatureInput.setExcludeNode(firma);
/* 1491 */                   XMLSignatureInput resultado = tr.performTransforms(xmlSignatureInput);
/*      */                   
/* 1493 */                   alg.update(resultado.getBytes());
/*      */                 } else {
/* 1495 */                   alg.update(UtilidadTratarNodo.obtenerByte(nodoReferenciado, canonicalization));
/*      */                 }
/* 1497 */                 abyte1 = alg.digest();
/*      */               } else {
/* 1499 */                 byte[] file = UtilidadFicheros.readFile(new File(new File(new URI(baseUri)).getAbsolutePath() + File.separator + uri));
/* 1500 */                 MessageDigest md = UtilidadFirmaElectronica.getMessageDigest(method);
/* 1501 */                 md.reset();
/* 1502 */                 md.update(file);
/* 1503 */                 abyte1 = md.digest();
/*      */               }
/*      */             } catch (Exception e) {
/* 1506 */               LOGGER.debug("Error al comprobar la integridad", e);
/*      */             }
/*      */             
/*      */ 
/* 1510 */             boolean flag = MessageDigestAlgorithm.isEqual(abyte0, abyte1);
/* 1511 */             this.resultado.setIntegrity(flag);
/* 1512 */             if (flag) {
/* 1513 */               if (LOGGER.isDebugEnabled())
/* 1514 */                 LOGGER.debug("La referencia que apunta a \"" + uri + "\" pasa el chequeo de integridad");
/*      */             } else {
/* 1516 */               if (!LOGGER.isDebugEnabled()) break;
/* 1517 */               LOGGER.debug("La referencia que apunta a \"" + uri + "\" NO pasa el chequeo de integridad");
/* 1518 */               LOGGER.debug("Leído: " + Base64.encodeBytes(abyte0));
/* 1519 */               LOGGER.debug("Calculado: " + Base64.encodeBytes(abyte1));
/*      */               
/* 1521 */               break;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 1527 */         LOGGER.debug("XMLDSig Core Validation: Not passed");
/* 1528 */         logv.error("XMLDSig Core Validation: Not passed");
/*      */         
/* 1530 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error105"));
/* 1531 */         this.resultado.setValidate(false);
/* 1532 */         this.resultado.setResultado(ResultadoEnum.INVALID);
/*      */       }
/*      */     }
/*      */     else {
/* 1536 */       LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error5"));
/* 1537 */       logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error5"));
/*      */       
/* 1539 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error5"));
/* 1540 */       this.resultado.setValidate(false);
/* 1541 */       this.resultado.setResultado(ResultadoEnum.INVALID);
/* 1542 */       return this.resultado;
/*      */     }
/*      */     
/*      */ 
/* 1546 */     getDataObjectFormat(firma.getOwnerDocument(), estructuraFirma);
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 1551 */       this.tipoDocFirma = tipoFirma(estructuraFirma);
/* 1552 */       logv.info("XAdES type: " + this.tipoDocFirma.getTipoXAdES().name());
/* 1553 */       this.datosFirma.setTipoFirma(this.tipoDocFirma);
/*      */     } catch (BadFormedSignatureException e) {
/* 1555 */       LOGGER.error(e.getMessage());
/*      */       
/* 1557 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error4"));
/* 1558 */       this.resultado.setValidate(false);
/* 1559 */       this.resultado.setResultado(ResultadoEnum.INVALID);
/* 1560 */       logv.error("Bad XAdES format. Invalid Signature: " + e.getMessage());
/*      */       
/* 1562 */       this.esValido = false;
/* 1563 */       this.tipoDocFirma = new DatosTipoFirma(EnumFormatoFirma.XMLSignature, false, false);
/*      */     }
/*      */     
/*      */ 
/* 1567 */     if (this.esValido)
/*      */     {
/* 1569 */       if (this.tipoDocFirma.getTipoXAdES().equals(EnumFormatoFirma.XMLSignature)) {
/* 1570 */         this.resultado.setValidate(true);
/* 1571 */         this.resultado.setResultado(ResultadoEnum.VALID);
/* 1572 */         this.resultado.setEnumNivel(EnumFormatoFirma.XMLSignature);
/* 1573 */         return this.resultado;
/*      */       }
/*      */       
/* 1576 */       if (validarXadesBes(estructuraFirma))
/*      */       {
/* 1578 */         if (this.tipoDocFirma.esXAdES_EPES()) {
/* 1579 */           LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.texto5"));
/*      */           
/* 1581 */           logv.info("XAdES-EPES validation: Valid");
/*      */           
/* 1583 */           this.resultado.setNivelValido(I18n.getResource("libreriaxades.validarfirmaxml.texto5"));
/*      */         } else {
/* 1585 */           LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.texto1"));
/*      */           
/* 1587 */           logv.info("XAdES-BES validation: Valid");
/*      */           
/* 1589 */           this.resultado.setNivelValido(I18n.getResource("libreriaxades.validarfirmaxml.texto1"));
/*      */         }
/*      */         
/* 1592 */         this.resultado.setEnumNivel(EnumFormatoFirma.XAdES_BES);
/* 1593 */         this.resultado.setLog(i18n.getLocalMessage("i18n.mityc.xades.validate.14"));
/*      */         
/*      */ 
/* 1596 */         this.datosFirma.setRoles(obtenerRoles(estructuraFirma));
/*      */         
/*      */ 
/* 1599 */         if (this.tipoDocFirma.getTipoXAdES().compareTo(EnumFormatoFirma.XAdES_BES) > 0)
/*      */         {
/*      */ 
/* 1602 */           if (validarSelloTiempoXadesT(estructuraFirma))
/*      */           {
/*      */ 
/* 1605 */             LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.texto2"));
/* 1606 */             this.resultado.setEnumNivel(EnumFormatoFirma.XAdES_T);
/* 1607 */             this.resultado.setNivelValido(I18n.getResource("libreriaxades.validarfirmaxml.texto2"));
/* 1608 */             this.datosFirma.setDatosSelloTiempo(this.arrayDatosSello);
/*      */             
/*      */ 
/*      */ 
/* 1612 */             if (this.tipoDocFirma.getTipoXAdES().compareTo(EnumFormatoFirma.XAdES_T) > 0)
/*      */             {
/*      */ 
/*      */ 
/* 1616 */               if (validarXadesC(uriDS, cert, estructuraFirma)) {
/* 1617 */                 LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.texto4"));
/*      */                 
/* 1619 */                 logv.info("XAdES-C validation: Valid");
/*      */                 
/* 1621 */                 this.resultado.setEnumNivel(EnumFormatoFirma.XAdES_C);
/* 1622 */                 this.resultado.setNivelValido(I18n.getResource("libreriaxades.validarfirmaxml.texto4"));
/* 1623 */                 this.resultado.setLog("");
/* 1624 */                 this.datosFirma.setDatosOCSP(this.arrayDatosOCSP);
/* 1625 */                 this.datosFirma.setDatosCRL(this.arrayDatosCRL);
/*      */                 
/*      */ 
/* 1628 */                 if (this.tipoDocFirma.getTipoXAdES().compareTo(EnumFormatoFirma.XAdES_X) >= 0)
/*      */                 {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1635 */                   if ((validarSelloTiempoXadesX(estructuraFirma, "SigAndRefsTimeStamp")) || (validarSelloTiempoXadesX(estructuraFirma, "RefsOnlyTimeStamp")))
/*      */                   {
/*      */ 
/* 1638 */                     this.resultado.setEnumNivel(this.tipoDocFirma.getTipoXAdES());
/* 1639 */                     if (EnumFormatoFirma.XAdES_X.compareTo(this.tipoDocFirma.getTipoXAdES()) == 0) {
/* 1640 */                       this.resultado.setNivelValido(I18n.getResource("libreriaxades.validarfirmaxml.texto7"));
/* 1641 */                       LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.texto7"));
/*      */                       
/* 1643 */                       logv.info("XAdES-X validation: Valid");
/*      */                     }
/*      */                     else {
/* 1646 */                       this.resultado.setNivelValido(I18n.getResource("libreriaxades.validarfirmaxml.texto3"));
/* 1647 */                       LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.texto3"));
/*      */                       
/* 1649 */                       logv.info("XAdES-XL validation: Valid");
/*      */                     }
/*      */                     
/* 1652 */                     this.datosFirma.setDatosSelloTiempo(this.arrayDatosSello);
/* 1653 */                     this.datosFirma.setDatosOCSP(this.arrayDatosOCSP);
/*      */                   }
/*      */                 }
/*      */               } else {
/* 1657 */                 this.datosFirma.setDatosOCSP(this.arrayDatosOCSP);
/*      */               }
/*      */               
/*      */             }
/*      */             
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/* 1667 */             String sello = "";
/* 1668 */             if (this.tipoDocFirma.getTipoXAdES().compareTo(EnumFormatoFirma.XAdES_XL) == 0) {
/* 1669 */               sello = "XAdES T ";
/*      */             }
/*      */             
/* 1672 */             LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.error8") + " " + 
/* 1673 */               sello + " " + 
/* 1674 */               I18n.getResource("libreriaxades.validarfirmaxml.error9") + " " + 
/* 1675 */               this.tipoDocFirma.getTipoXAdES() + " " + 
/* 1676 */               I18n.getResource("libreriaxades.validarfirmaxml.error10"));
/*      */             
/*      */ 
/* 1679 */             if (i18n.getLocalMessage("i18n.mityc.xades.validate.14").equals(this.resultado.getLog())) {
/* 1680 */               this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error8") + " " + 
/* 1681 */                 sello + " " + 
/* 1682 */                 I18n.getResource("libreriaxades.validarfirmaxml.error9") + " " + 
/* 1683 */                 this.tipoDocFirma.getTipoXAdES().name() + " " + 
/* 1684 */                 I18n.getResource("libreriaxades.validarfirmaxml.error10"));
/*      */             }
/* 1686 */             this.esValido = false;
/*      */           }
/*      */         } else {
/*      */           try {
/* 1690 */             cert.checkValidity(new Date(System.currentTimeMillis()));
/*      */           }
/*      */           catch (CertificateExpiredException e) {
/* 1693 */             LOGGER.info("El certificado firmante ha caducado");
/* 1694 */             logv.info("El certificado firmante ha caducado");
/* 1695 */             this.resultado.appendLog("El certificado firmante ha caducado");
/* 1696 */             this.resultado.setValidate(false);
/* 1697 */             this.resultado.setResultado(ResultadoEnum.INVALID);
/* 1698 */             this.esValido = false;
/*      */           }
/*      */           catch (CertificateNotYetValidException e) {
/* 1701 */             LOGGER.info("El certificado firmante aún no es válido");
/* 1702 */             logv.info("El certificado firmante aún no es válido");
/* 1703 */             this.resultado.appendLog("El certificado firmante aún no es válido");
/* 1704 */             this.resultado.setValidate(false);
/* 1705 */             this.resultado.setResultado(ResultadoEnum.INVALID);
/* 1706 */             this.esValido = false;
/*      */           }
/*      */         }
/*      */       }
/* 1710 */       this.resultado.setValidate(this.esValido);
/* 1711 */       if (!ResultadoEnum.UNKNOWN.equals(this.resultado.getResultado())) {
/* 1712 */         this.resultado.setResultado(this.esValido ? ResultadoEnum.VALID : ResultadoEnum.INVALID);
/*      */       }
/*      */       
/* 1715 */       if (this.tipoDocFirma.esXAdES_A()) {
/*      */         try
/*      */         {
/* 1718 */           if (validaXadesA(estructuraFirma)) {
/* 1719 */             LOGGER.info("La firma contiene un sello de tiempo XAdES-A válido");
/*      */           } else {
/* 1721 */             LOGGER.info("La firma contiene un sello de tiempo XAdES-A NO válido");
/* 1722 */             logv.info("La firma contiene un sello de tiempo del tipo XAdES-A NO válido");
/*      */             
/* 1724 */             if (this.resultado.getLog() != null) {
/* 1725 */               this.resultado.setLog("Un sello de tiempo de tipo A es inválido - " + this.resultado.getLog());
/*      */             } else {
/* 1727 */               this.resultado.setLog("Un sello de tiempo de tipo A es inválido");
/*      */             }
/* 1729 */             this.resultado.setValidate(false);
/* 1730 */             this.resultado.setResultado(ResultadoEnum.INVALID);
/* 1731 */             return this.resultado;
/*      */           }
/*      */         } catch (Exception e) {
/* 1734 */           LOGGER.error(e.getMessage(), e);
/*      */         }
/*      */       }
/*      */       
/* 1738 */       if (this.esValido) {
/* 1739 */         Date fechaFirma = this.datosFirma.getFechaFirma();
/* 1740 */         if (EnumFormatoFirma.XAdES_BES.compareTo(this.datosFirma.getTipoFirma().getTipoXAdES()) > 0) {
/* 1741 */           fechaFirma = ((DatosSelloTiempo)this.datosFirma.getDatosSelloTiempo().get(0)).getFecha();
/*      */         }
/*      */         
/* 1744 */         if (fechaFirma != null) {
/* 1745 */           if (fechaFirma.after(new Date())) {
/* 1746 */             this.esValido = false;
/* 1747 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error170"));
/* 1748 */             LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error170"));
/*      */             
/* 1750 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error170"));
/*      */           }
/*      */           
/*      */ 
/* 1754 */           Date notAfter = cert.getNotAfter();
/* 1755 */           Date notBefore = cert.getNotBefore();
/* 1756 */           if ((fechaFirma.after(notAfter)) || (fechaFirma.before(notBefore))) {
/* 1757 */             this.esValido = false;
/*      */             
/* 1759 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error159"));
/* 1760 */             LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error159"));
/*      */             
/* 1762 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error159"));
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1768 */       buscaXadesEpes(estructuraFirma);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1773 */     if (this.politicas.size() > 0) {
/* 1774 */       if (LOGGER.isDebugEnabled()) {
/* 1775 */         LOGGER.debug("Se validan " + this.politicas.size() + " políticas");
/*      */       }
/* 1777 */       Iterator<PolicyResult> it = this.politicas.iterator();
/* 1778 */       while (it.hasNext()) {
/* 1779 */         PolicyResult pr = (PolicyResult)it.next();
/* 1780 */         if (pr.getPolicyVal() != null) {
/*      */           try {
/* 1782 */             IValidacionPolicy valPol = pr.getPolicyVal();
/* 1783 */             if (LOGGER.isDebugEnabled()) {
/* 1784 */               LOGGER.debug("Manager de política empleado: " + valPol.getIdentidadPolicy());
/*      */             }
/* 1786 */             if (this.truster != null) {
/* 1787 */               valPol.setTruster(this.truster);
/*      */             }
/* 1789 */             PolicyResult prTemp = valPol.validaPolicy((Element)firma, this.resultado);
/* 1790 */             pr.copy(prTemp);
/* 1791 */             if (LOGGER.isDebugEnabled()) {
/* 1792 */               LOGGER.debug("Política validada con éxito: " + pr.getResult());
/*      */             }
/*      */           }
/*      */           catch (Throwable th) {
/* 1796 */             LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error109"), th);
/* 1797 */             if (LOGGER.isDebugEnabled()) {
/* 1798 */               LOGGER.debug("Error al validar la política: " + th.getMessage());
/*      */             }
/*      */             
/* 1801 */             this.resultado.setValidate(false);
/* 1802 */             this.resultado.setResultado(ResultadoEnum.INVALID);
/*      */             
/* 1804 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error71"));
/* 1805 */             pr.setResult(PolicyResult.StatusValidation.unknown);
/* 1806 */             pr.setDescriptionResult(th.getMessage());
/* 1807 */             break;
/*      */           }
/*      */           
/* 1810 */           if (PolicyResult.StatusValidation.invalid.equals(pr.getResult())) {
/* 1811 */             this.resultado.setValidate(false);
/* 1812 */             this.resultado.setResultado(ResultadoEnum.INVALID);
/* 1813 */             this.resultado.setLog(pr.getDescriptionResult());
/* 1814 */           } else if (PolicyResult.StatusValidation.unknown.equals(pr.getResult())) {
/* 1815 */             this.resultado.setValidate(false);
/* 1816 */             this.resultado.setResultado(ResultadoEnum.UNKNOWN);
/* 1817 */             this.resultado.setLog(pr.getDescriptionResult());
/*      */ 
/*      */           }
/*      */           
/*      */ 
/*      */         }
/* 1823 */         else if (LOGGER.isDebugEnabled()) {
/* 1824 */           LOGGER.debug("No se encontró validador para " + pr.getPolicyID());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1829 */         PolicyResult.StatusValidation sv = pr.getResult();
/* 1830 */         String policyDescResult = pr.getDescriptionResult();
/* 1831 */         PolicyResult.DownloadPolicy[] policyDownload = pr.getDownloable();
/* 1832 */         String[] policyNotices = pr.getNotices();
/*      */         
/* 1834 */         boolean valido = false;
/* 1835 */         String policyID = null;
/* 1836 */         if (PolicyResult.StatusValidation.valid.equals(sv)) {
/* 1837 */           policyID = "Accomplished policy: " + pr.getPolicyID();
/* 1838 */           valido = true;
/* 1839 */         } else if (PolicyResult.StatusValidation.invalid.equals(sv)) {
/* 1840 */           policyID = "Unaccomplished policy: " + pr.getPolicyID();
/* 1841 */         } else if (PolicyResult.StatusValidation.unknown.equals(sv)) {
/* 1842 */           if (pr.getPolicyID() == null) {
/* 1843 */             policyID = "Implied policy";
/*      */           } else
/* 1845 */             policyID = "Unkown policy";
/* 1846 */           valido = true;
/*      */         }
/*      */         
/* 1849 */         logv.abreTag(valido);
/* 1850 */         logv.info(policyID, 2);
/* 1851 */         if ((!valido) && (policyDescResult != null))
/* 1852 */           logv.info(policyDescResult, 2);
/* 1853 */         for (int i = 0; (policyDownload != null) && (i < policyDownload.length); i++) {
/* 1854 */           String value = policyDownload[i].uri.toString();
/* 1855 */           if (PolicyResult.StatusValidation.unknown.equals(policyDownload[i].status)) {
/* 1856 */             value = "(Unknown integrity): ".concat(value);
/* 1857 */           } else { if (!PolicyResult.StatusValidation.valid.equals(policyDownload[i].status)) continue;
/* 1858 */             value = "(Checked integrity): ".concat(value);
/*      */           }
/*      */           
/* 1861 */           logv.info("Download URI " + value, 2);
/*      */         }
/* 1863 */         for (int i = 0; (policyNotices != null) && (i < policyNotices.length); i++) {
/* 1864 */           logv.info("Notice: " + policyNotices[i].toString(), 2);
/*      */         }
/* 1866 */         logv.cierraTag(valido);
/*      */       }
/*      */     }
/*      */     
/* 1870 */     if (this.politicas.size() > 0) {
/* 1871 */       this.datosFirma.setPoliticas(this.politicas);
/*      */     }
/*      */     
/* 1874 */     return this.resultado;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void buscaXadesEpes(EstructuraFirma estructuraFirma)
/*      */   {
/* 1885 */     if (LOGGER.isDebugEnabled()) {
/* 1886 */       LOGGER.debug("Buscando nodos de políticas");
/*      */     }
/* 1888 */     Element firma = estructuraFirma.firma;
/* 1889 */     String esquemaURI = estructuraFirma.esquema.getSchemaUri();
/*      */     
/*      */ 
/* 1892 */     ArrayList<Element> signaturePolicyList = null;
/*      */     try {
/* 1894 */       signaturePolicyList = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 1895 */         new NombreNodo(esquemaURI, "SignaturePolicyIdentifier"));
/*      */     } catch (FirmaXMLError e) {
/* 1897 */       LOGGER.error(e.getMessage(), e);
/* 1898 */       logv.error(e.getMessage());
/*      */       
/* 1900 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error5"));
/* 1901 */       this.resultado.setValidate(false);
/* 1902 */       this.resultado.setResultado(ResultadoEnum.INVALID);
/* 1903 */       return;
/*      */     }
/*      */     
/* 1906 */     int numNodosSigPolicy = 0;
/* 1907 */     if (signaturePolicyList != null) {
/* 1908 */       numNodosSigPolicy = signaturePolicyList.size();
/*      */     }
/* 1910 */     if ((numNodosSigPolicy == 0) && ("http://uri.etsi.org/01903/v1.1.1#".equals(esquemaURI)))
/*      */     {
/* 1912 */       LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error110"));
/* 1913 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error111"));
/* 1914 */       this.esValido = false;
/* 1915 */       this.resultado.setValidate(false);
/* 1916 */       this.resultado.setResultado(ResultadoEnum.INVALID);
/* 1917 */       return;
/*      */     }
/*      */     
/* 1920 */     if (numNodosSigPolicy == 1)
/*      */     {
/* 1922 */       Element signaturePolicyIdentifierNode = (Element)signaturePolicyList.get(0);
/*      */       try
/*      */       {
/* 1925 */         SignaturePolicyIdentifier spi = new SignaturePolicyIdentifier(estructuraFirma.esquema);
/* 1926 */         if (!spi.isThisNode(signaturePolicyIdentifierNode))
/*      */         {
/* 1928 */           throw new InvalidInfoNodeException(I18n.getResource("libreriaxades.validarfirmaxml.error112")); }
/* 1929 */         spi.load(signaturePolicyIdentifierNode);
/*      */       }
/*      */       catch (InvalidInfoNodeException ex) {
/* 1932 */         LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error164") + 
/* 1933 */           " " + ex.getMessage(), ex);
/*      */         
/* 1935 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error164") + 
/* 1936 */           " " + ex.getMessage());
/*      */         
/* 1938 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error114"));
/* 1939 */         this.esValido = false;
/* 1940 */         this.resultado.setValidate(false);
/* 1941 */         this.resultado.setResultado(ResultadoEnum.INVALID); return;
/*      */       }
/*      */       
/*      */       SignaturePolicyIdentifier spi;
/*      */       
/* 1946 */       PoliciesManager policiesManager = PoliciesManager.getInstance();
/* 1947 */       PoliciesManager.PolicyKey clave = policiesManager.newPolicyKey(null, "implied");
/* 1948 */       if (!spi.isImplied()) {
/* 1949 */         clave.hash = Utilidades.binary2String(es.mityc.firmaJava.libreria.utilidades.Base64Coder.decode(spi.getSignaturePolicyId().getSigPolicyHash().getDigestValue().getValue()));
/* 1950 */         clave.uri = spi.getSignaturePolicyId().getSigPolicyId().getIdentifier().getUri();
/*      */       }
/* 1952 */       IValidacionPolicy valPol = policiesManager.getValidadorPolicy(clave);
/* 1953 */       if (valPol == null) {
/* 1954 */         if (LOGGER.isDebugEnabled()) {
/* 1955 */           LOGGER.debug("No se pudo encontrar validador para la política " + clave.uri);
/* 1956 */           LOGGER.debug("Hash obtenido " + clave.hash);
/* 1957 */           LOGGER.debug("Políticas disponibles: " + this.politicas.size());
/*      */         }
/* 1959 */         PolicyResult pr = new PolicyResult();
/* 1960 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error104"));
/* 1961 */         pr.setResult(PolicyResult.StatusValidation.unknown);
/* 1962 */         pr.setPolicyID(clave.uri);
/* 1963 */         this.politicas.add(pr);
/* 1964 */       } else if (!this.politicas.contains(valPol)) {
/* 1965 */         if (LOGGER.isDebugEnabled()) {
/* 1966 */           LOGGER.debug("Validador de política nuevo: " + valPol.getIdentidadPolicy());
/* 1967 */           LOGGER.debug("Para la política " + clave.uri);
/* 1968 */           LOGGER.debug("Hash obtenido " + clave.hash);
/* 1969 */           LOGGER.debug("Políticas disponibles: " + this.politicas.size());
/*      */         }
/* 1971 */         PolicyResult pr = new PolicyResult();
/* 1972 */         pr.setPolicyVal(valPol);
/* 1973 */         this.politicas.add(pr);
/*      */       }
/*      */     }
/* 1976 */     else if (numNodosSigPolicy > 1)
/*      */     {
/* 1978 */       LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error115"));
/*      */       
/* 1980 */       logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error115"));
/*      */       
/* 1982 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error116"));
/* 1983 */       this.esValido = false;
/* 1984 */       this.resultado.setValidate(false);
/* 1985 */       this.resultado.setResultado(ResultadoEnum.INVALID);
/* 1986 */       return;
/*      */     }
/*      */   }
/*      */   
/*      */   private void mostrarErrorValidacion(Exception ex)
/*      */     throws FirmaXMLError
/*      */   {
/* 1993 */     LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error28"), ex);
/* 1994 */     throw new FirmaXMLError(I18n.getResource("libreriaxades.validarfirmaxml.error28"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void getDataObjectFormat(Document doc, EstructuraFirma estructuraFirma)
/*      */   {
/* 2004 */     DatosNodosFirmados datos = null;
/* 2005 */     ArrayList<Element> signedDataObjectProperties = null;
/* 2006 */     DataObjectFormat dof = null;
/* 2007 */     Element dataOF = null;
/* 2008 */     Node attId = null;
/*      */     
/*      */     try
/*      */     {
/* 2012 */       signedDataObjectProperties = UtilidadTratarNodo.obtenerNodos(estructuraFirma.firma, 4, 
/* 2013 */         new NombreNodo(estructuraFirma.esquema.getSchemaUri(), "SignedDataObjectProperties"));
/*      */     } catch (FirmaXMLError e) {
/* 2015 */       LOGGER.debug("No se pudo recoger el nodo SignedDataObjectProperties", e);
/*      */     }
/*      */     
/* 2018 */     if ((signedDataObjectProperties != null) && (signedDataObjectProperties.size() == 1)) {
/* 2019 */       Element signedDOP = (Element)signedDataObjectProperties.get(0);
/*      */       
/* 2021 */       NodeList dataOFs = signedDOP.getChildNodes();
/* 2022 */       int dofLength = dataOFs.getLength();
/* 2023 */       Node item = null;
/* 2024 */       for (int i = 0; i < dofLength; i++) {
/* 2025 */         item = dataOFs.item(i);
/* 2026 */         if ((item instanceof Element))
/*      */         {
/* 2028 */           dataOF = (Element)item;
/*      */           
/* 2030 */           dof = new DataObjectFormat(estructuraFirma.esquema);
/*      */           try {
/* 2032 */             dof.load(dataOF);
/*      */           } catch (InvalidInfoNodeException e) {
/* 2034 */             LOGGER.error(e.getMessage(), e);
/* 2035 */             continue;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 2041 */           if ((dataOF.getAttributes() != null) && (dataOF.getAttributes().getLength() > 0)) {
/* 2042 */             if (dataOF.getAttributes() != null) {
/* 2043 */               attId = dataOF.getAttributes().getNamedItem("ObjectReference");
/*      */             }
/* 2045 */             if (attId != null)
/*      */             {
/* 2047 */               String uri = attId.getTextContent();
/* 2048 */               if ((uri != null) && (uri.startsWith("#"))) {
/* 2049 */                 datos = this.datosFirma.getDatosNodoFimadoByReferenceId(uri.substring(1));
/* 2050 */                 if (datos != null) {
/* 2051 */                   if (dof.getObjectIdentifier() != null) {
/* 2052 */                     datos.setObjectIdentifier(dof.getObjectIdentifier());
/*      */                   }
/* 2054 */                   if (dof.getDescription() != null) {
/* 2055 */                     datos.setDescription(dof.getDescription().getValue());
/*      */                   }
/* 2057 */                   if (dof.getMimeType() != null) {
/* 2058 */                     datos.setMimeType(dof.getMimeType().getValue());
/*      */                   }
/* 2060 */                   if (dof.getEnconding() != null) {
/* 2061 */                     datos.setEncoding(dof.getEnconding().getValue());
/*      */                   }
/*      */                 } else {
/* 2064 */                   LOGGER.warn(i18n.getLocalMessage("i18n.mityc.xades.validate.8", new Object[] { uri }));
/*      */                 }
/*      */                 
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 2075 */       LOGGER.debug("El nodo SignedDataObjectProperties no existe o no es único");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean validarXadesBes(EstructuraFirma estructuraFirma)
/*      */   {
/* 2087 */     if (estructuraFirma.firma == null) {
/* 2088 */       this.esValido = false;
/*      */       
/* 2090 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error76"));
/* 2091 */       LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error76"));
/* 2092 */       return false;
/*      */     }
/*      */     
/* 2095 */     Element firma = estructuraFirma.firma;
/* 2096 */     String esquemaURI = estructuraFirma.esquema.getSchemaUri();
/*      */     
/*      */ 
/* 2099 */     Date fechaFirma = obtenerFechaFirma(estructuraFirma);
/*      */     
/* 2101 */     this.datosFirma.setFechaFirma(fechaFirma);
/*      */     
/*      */ 
/* 2104 */     ArrayList<DatosX509> certificadosSigning = new ArrayList();
/* 2105 */     DatosX509 datos = new DatosX509();
/* 2106 */     ArrayList<Element> nodosSigningCertificate = UtilidadTratarNodo.obtenerNodos(estructuraFirma.signedSignatureProperties, null, 
/* 2107 */       new NombreNodo(esquemaURI, "SigningCertificate"));
/* 2108 */     if ((nodosSigningCertificate != null) && (nodosSigningCertificate.size() > 0)) {
/* 2109 */       Node nodoSigningCertificate = (Node)nodosSigningCertificate.get(0);
/* 2110 */       ArrayList<Element> nodosCert = UtilidadTratarNodo.getElementChildNodes((Element)nodoSigningCertificate, false);
/* 2111 */       if (nodosCert == null) {
/* 2112 */         this.esValido = false;
/* 2113 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/* 2114 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/* 2115 */         return false;
/*      */       }
/* 2117 */       int nodosCertSize = nodosCert.size();
/* 2118 */       Element nodoCert = null;
/* 2119 */       for (int i = 0; i < nodosCertSize; i++) {
/* 2120 */         nodoCert = (Element)nodosCert.get(i);
/*      */         
/* 2122 */         Cert cert = new Cert(estructuraFirma.esquema);
/*      */         try {
/* 2124 */           cert.load(nodoCert);
/*      */         } catch (InvalidInfoNodeException ex) {
/* 2126 */           this.esValido = false;
/*      */           
/* 2128 */           this.resultado.setLog(i18n.getLocalMessage("i18n.mityc.xades.validate.13"));
/*      */           
/* 2130 */           LOGGER.error(i18n.getLocalMessage("i18n.mityc.xades.validate.11", new Object[] { ex.getMessage() }));
/*      */           
/* 2132 */           logv.error(i18n.getLocalMessage("i18n.mityc.xades.validate.13") + ex.getMessage());
/*      */           
/* 2134 */           return false;
/*      */         }
/* 2136 */         datos.setAlgMethod(cert.getCertDigest().getDigestMethod().getAlgorithm());
/* 2137 */         datos.setDigestValue(cert.getCertDigest().getDigestValue().getValue());
/*      */         try {
/* 2139 */           datos.setIssuer(new X500Principal(cert.getIssuerSerial().getIssuerName()));
/*      */         } catch (IllegalArgumentException ex) {
/* 2141 */           this.esValido = false;
/*      */           
/* 2143 */           this.resultado.setLog(i18n.getLocalMessage("i18n.mityc.xades.validate.13"));
/*      */           
/* 2145 */           LOGGER.error(i18n.getLocalMessage("i18n.mityc.xades.validate.12", new Object[] { ex.getMessage() }));
/*      */           
/* 2147 */           logv.error(i18n.getLocalMessage("i18n.mityc.xades.validate.13") + ex.getMessage());
/*      */           
/* 2149 */           return false;
/*      */         }
/* 2151 */         datos.setSerial(cert.getIssuerSerial().getSerialNumber());
/*      */         
/* 2153 */         certificadosSigning.add(datos);
/*      */       }
/*      */     }
/*      */     int x;
/* 2157 */     if (certificadosSigning.size() > 0)
/*      */     {
/*      */ 
/* 2160 */       X509Certificate certFirmante = (X509Certificate)this.cadenaCertificados.get(0);
/* 2161 */       X500Principal certFirmIssuer = certFirmante.getIssuerX500Principal();
/* 2162 */       BigInteger certFirmSerial = certFirmante.getSerialNumber();
/*      */       
/* 2164 */       boolean coincidencia = false;
/* 2165 */       for (int i = 0; i < certificadosSigning.size(); i++) {
/* 2166 */         DatosX509 certAComparar = (DatosX509)certificadosSigning.get(i);
/* 2167 */         if ((UtilidadCertificados.isSameName(certFirmIssuer, certAComparar.getIssuer())) && 
/* 2168 */           (certFirmSerial.equals(certAComparar.getSerial())))
/*      */         {
/* 2170 */           ArrayList<Element> nodosKeyInfo = new ArrayList();
/*      */           try {
/* 2172 */             nodosKeyInfo = UtilidadTratarNodo.obtenerNodos(firma, 2, 
/* 2173 */               new NombreNodo(this.uriXmlNS, "KeyInfo"));
/*      */           } catch (FirmaXMLError e) {
/* 2175 */             this.esValido = false;
/*      */             
/* 2177 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/*      */             
/* 2179 */             LOGGER.error(e.getMessage(), e);
/*      */             
/* 2181 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error3") + e.getMessage());
/*      */             
/* 2183 */             return false;
/*      */           }
/* 2185 */           if (nodosKeyInfo.size() > 0) {
/* 2186 */             Element nodoKeyInfo = (Element)nodosKeyInfo.get(0);
/* 2187 */             Element primerNodoX509Data = (Element)nodoKeyInfo.getElementsByTagNameNS(this.uriXmlNS, "X509Data").item(0);
/* 2188 */             NodeList nodosIssuerSerial = primerNodoX509Data.getElementsByTagNameNS(this.uriXmlNS, "X509IssuerSerial");
/* 2189 */             if (nodosIssuerSerial.getLength() > 0)
/*      */             {
/*      */ 
/* 2192 */               X500Principal issuer = null;
/* 2193 */               BigInteger serial = null;
/* 2194 */               Element nodoIssuerSerial = (Element)nodosIssuerSerial.item(0);
/* 2195 */               NodeList issuerVals = nodoIssuerSerial.getElementsByTagNameNS(this.uriXmlNS, "X509IssuerName");
/* 2196 */               if (issuerVals != null) {
/* 2197 */                 Element issuerValElement = (Element)issuerVals.item(0);
/* 2198 */                 String issuerName = issuerValElement.getFirstChild().getNodeValue();
/*      */                 try {
/* 2200 */                   issuer = new X500Principal(issuerName);
/*      */                 } catch (IllegalArgumentException ex) {
/* 2202 */                   this.esValido = false;
/*      */                   
/* 2204 */                   this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/*      */                   
/* 2206 */                   LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error23"), ex);
/*      */                   
/* 2208 */                   logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error3") + ex.getMessage());
/*      */                   
/* 2210 */                   return false;
/*      */                 } catch (NullPointerException ex) {
/* 2212 */                   this.esValido = false;
/*      */                   
/* 2214 */                   this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/*      */                   
/* 2216 */                   LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error23"), ex);
/*      */                   
/* 2218 */                   logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error3") + ex.getMessage());
/*      */                   
/* 2220 */                   return false;
/*      */                 }
/*      */               }
/* 2223 */               NodeList serialVals = nodoIssuerSerial.getElementsByTagNameNS(this.uriXmlNS, "X509SerialNumber");
/* 2224 */               if (serialVals != null) {
/* 2225 */                 Element serialValElement = (Element)serialVals.item(0);
/* 2226 */                 serial = new BigInteger(serialValElement.getFirstChild().getNodeValue());
/*      */               }
/*      */               
/* 2229 */               if ((!UtilidadCertificados.isSameName(certAComparar.getIssuer(), issuer)) || 
/* 2230 */                 (!certAComparar.getSerial().equals(serial)))
/*      */               {
/*      */ 
/* 2233 */                 this.esValido = false;
/*      */                 
/* 2235 */                 this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/*      */                 
/* 2237 */                 LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error85"));
/*      */                 
/* 2239 */                 logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error85"));
/*      */                 
/* 2241 */                 return false;
/*      */               }
/*      */             }
/*      */           }
/*      */           
/*      */ 
/* 2247 */           MessageDigest haseador = UtilidadFirmaElectronica.getMessageDigest(certAComparar.getAlgMethod());
/* 2248 */           byte[] digestCertFirmante = null;
/*      */           try {
/* 2250 */             digestCertFirmante = haseador.digest(certFirmante.getEncoded());
/*      */           } catch (CertificateEncodingException e) {
/* 2252 */             this.esValido = false;
/*      */             
/* 2254 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/*      */             
/* 2256 */             LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error52"));
/*      */             
/* 2258 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error52"));
/*      */             
/* 2260 */             return false;
/*      */           }
/* 2262 */           if (Utilidades.isEqual(digestCertFirmante, es.mityc.firmaJava.libreria.utilidades.Base64Coder.decode(certAComparar.getDigestValue())))
/*      */           {
/* 2264 */             coincidencia = true;
/*      */             
/* 2266 */             certificadosSigning.remove(i);
/*      */             
/* 2268 */             logv.info("Signing certificate is valid");
/*      */             
/* 2270 */             break;
/*      */           }
/* 2272 */           this.esValido = false;
/*      */           
/* 2274 */           this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error136"));
/*      */           
/* 2276 */           LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error86"));
/*      */           
/* 2278 */           logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error86"));
/*      */           
/* 2280 */           return false;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2286 */       if (!coincidencia) {
/* 2287 */         this.esValido = false;
/*      */         
/* 2289 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error136"));
/*      */         
/* 2291 */         LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error87"));
/*      */         
/* 2293 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error87") + " because it not match the information contained in the SigningCertificate node.");
/*      */         
/* 2295 */         return false;
/*      */       }
/*      */       
/*      */ 
/* 2299 */       int validos = 0;
/* 2300 */       for (int i = 0; i < certificadosSigning.size(); i++) {
/* 2301 */         DatosX509 certAComparar = (DatosX509)certificadosSigning.get(i);
/* 2302 */         for (x = 0; x < this.cadenaCertificados.size(); x++) {
/* 2303 */           X509Certificate certContenidos = (X509Certificate)this.cadenaCertificados.get(x);
/* 2304 */           X500Principal certContIssuer = certContenidos.getIssuerX500Principal();
/* 2305 */           BigInteger certContSerial = certContenidos.getSerialNumber();
/*      */           
/* 2307 */           if ((UtilidadCertificados.isSameName(certContIssuer, certAComparar.getIssuer())) && 
/* 2308 */             (certContSerial.equals(certAComparar.getSerial())))
/*      */           {
/* 2310 */             MessageDigest haseador = UtilidadFirmaElectronica.getMessageDigest(certAComparar.getAlgMethod());
/* 2311 */             byte[] digestCertContenidos = null;
/*      */             try {
/* 2313 */               digestCertContenidos = haseador.digest(certContenidos.getEncoded());
/*      */             } catch (CertificateEncodingException e) {
/* 2315 */               this.esValido = false;
/*      */               
/* 2317 */               this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error52"));
/*      */               
/* 2319 */               LOGGER.error(I18n.getResource("libreriaxades.firmaxml.error8"), e);
/*      */               
/* 2321 */               logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error52") + e.getMessage());
/*      */               
/* 2323 */               return false;
/*      */             }
/* 2325 */             if (Utilidades.isEqual(digestCertContenidos, es.mityc.firmaJava.libreria.utilidades.Base64Coder.decode(certAComparar.getDigestValue())))
/*      */             {
/* 2327 */               validos++;
/*      */             }
/*      */             else {
/* 2330 */               this.esValido = false;
/*      */               
/* 2332 */               this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error136"));
/*      */               
/* 2334 */               LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error88"));
/*      */               
/* 2336 */               logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error88"));
/*      */               
/* 2338 */               return false;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 2344 */       if (validos < certificadosSigning.size()) {
/* 2345 */         this.esValido = false;
/*      */         
/* 2347 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error89"));
/* 2348 */         LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error89"));
/*      */         
/* 2350 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error89"));
/*      */         
/* 2352 */         return false;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2357 */     ArrayList<Element> nodosSignedProperties = new ArrayList();
/*      */     try {
/* 2359 */       nodosSignedProperties = UtilidadTratarNodo.obtenerNodos(firma, 3, 
/* 2360 */         new NombreNodo(esquemaURI, "SignedProperties"));
/*      */     } catch (FirmaXMLError e) {
/* 2362 */       this.esValido = false;
/*      */       
/* 2364 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error139"));
/*      */       
/* 2366 */       LOGGER.error(e.getMessage(), e);
/* 2367 */       logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error77"));
/* 2368 */       return false;
/*      */     }
/*      */     
/* 2371 */     if (nodosSignedProperties.size() == 0) {
/* 2372 */       this.esValido = false;
/*      */       
/* 2374 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error139"));
/*      */       
/* 2376 */       LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error77"));
/*      */       
/* 2378 */       logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error77"));
/*      */       
/* 2380 */       return false;
/*      */     }
/*      */     
/* 2383 */     Element nodoSignedProperties = (Element)nodosSignedProperties.get(0);
/* 2384 */     Node signedPropertiesId = nodoSignedProperties.getAttributes().getNamedItem("Id");
/* 2385 */     if (signedPropertiesId == null) {
/* 2386 */       this.esValido = false;
/*      */       
/* 2388 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error140"));
/*      */       
/* 2390 */       LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error78"));
/*      */       
/* 2392 */       logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error78"));
/*      */       
/* 2394 */       return false;
/*      */     }
/*      */     
/* 2397 */     String nodoId = signedPropertiesId.getNodeValue();
/*      */     
/* 2399 */     List<DatosNodosFirmados> references = this.datosFirma.getDatosNodosFirmados();
/*      */     
/* 2401 */     if (references.size() == 0) {
/* 2402 */       this.esValido = false;
/*      */       
/* 2404 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error141"));
/*      */       
/* 2406 */       LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error79"));
/*      */       
/* 2408 */       LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error79"));
/*      */       
/* 2410 */       return false;
/*      */     }
/*      */     
/* 2413 */     String tipoEsperado = UtilidadFirmaElectronica.obtenerTipoReference(esquemaURI);
/*      */     
/* 2415 */     for (DatosNodosFirmados dnf : references)
/*      */     {
/*      */ 
/* 2418 */       String id = dnf.getId();
/* 2419 */       if (id != null)
/*      */       {
/*      */ 
/* 2422 */         if (id.equals(nodoId)) {
/* 2423 */           Element reference = dnf.getElementReference();
/* 2424 */           if (reference != null) {
/* 2425 */             Node referenceType = reference.getAttributes().getNamedItem("Type");
/* 2426 */             if (referenceType != null)
/*      */             {
/*      */ 
/* 2429 */               if (tipoEsperado.equals(referenceType.getNodeValue()))
/*      */               {
/* 2431 */                 if (!dnf.canBeModifiedByTransforms()) {
/* 2432 */                   return true;
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 2440 */     this.esValido = false;
/*      */     
/* 2442 */     this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error142"));
/*      */     
/* 2444 */     LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error80"));
/*      */     
/* 2446 */     logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error80"));
/*      */     
/* 2448 */     return false;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   private boolean validarSelloTiempoXadesT(EstructuraFirma estructuraFirma)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 132	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:tsValidator	Les/mityc/javasign/tsa/ITimeStampValidator;
/*      */     //   4: ifnonnull +14 -> 18
/*      */     //   7: aload_0
/*      */     //   8: new 2222	es/mityc/javasign/ts/TimeStampValidator
/*      */     //   11: dup
/*      */     //   12: invokespecial 2224	es/mityc/javasign/ts/TimeStampValidator:<init>	()V
/*      */     //   15: putfield 132	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:tsValidator	Les/mityc/javasign/tsa/ITimeStampValidator;
/*      */     //   18: aload_1
/*      */     //   19: getfield 1783	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML$EstructuraFirma:firma	Lorg/w3c/dom/Element;
/*      */     //   22: astore_2
/*      */     //   23: aload_1
/*      */     //   24: getfield 1121	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML$EstructuraFirma:esquema	Les/mityc/firmaJava/libreria/xades/XAdESSchemas;
/*      */     //   27: invokevirtual 794	es/mityc/firmaJava/libreria/xades/XAdESSchemas:getSchemaUri	()Ljava/lang/String;
/*      */     //   30: astore_3
/*      */     //   31: new 107	java/util/ArrayList
/*      */     //   34: dup
/*      */     //   35: invokespecial 109	java/util/ArrayList:<init>	()V
/*      */     //   38: astore 4
/*      */     //   40: aconst_null
/*      */     //   41: astore 5
/*      */     //   43: aconst_null
/*      */     //   44: astore 6
/*      */     //   46: aload_2
/*      */     //   47: iconst_5
/*      */     //   48: new 1139	es/mityc/firmaJava/libreria/utilidades/NombreNodo
/*      */     //   51: dup
/*      */     //   52: aload_3
/*      */     //   53: ldc_w 2225
/*      */     //   56: invokespecial 1143	es/mityc/firmaJava/libreria/utilidades/NombreNodo:<init>	(Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   59: invokestatic 1145	es/mityc/firmaJava/libreria/utilidades/UtilidadTratarNodo:obtenerNodos	(Lorg/w3c/dom/Element;ILes/mityc/firmaJava/libreria/utilidades/NombreNodo;)Ljava/util/ArrayList;
/*      */     //   62: astore 4
/*      */     //   64: goto +62 -> 126
/*      */     //   67: astore 7
/*      */     //   69: aload_0
/*      */     //   70: iconst_0
/*      */     //   71: putfield 92	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:esValido	Z
/*      */     //   74: aload_0
/*      */     //   75: getfield 97	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:resultado	Les/mityc/firmaJava/libreria/xades/ResultadoValidacion;
/*      */     //   78: ldc_w 2227
/*      */     //   81: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   84: invokevirtual 568	es/mityc/firmaJava/libreria/xades/ResultadoValidacion:setLog	(Ljava/lang/String;)V
/*      */     //   87: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   90: aload 7
/*      */     //   92: invokevirtual 1151	es/mityc/firmaJava/libreria/xades/errores/FirmaXMLError:getMessage	()Ljava/lang/String;
/*      */     //   95: aload 7
/*      */     //   97: invokeinterface 1073 3 0
/*      */     //   102: ldc_w 2229
/*      */     //   105: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   108: invokestatic 574	es/mityc/firmaJava/libreria/xades/logv:error	(Ljava/lang/String;)V
/*      */     //   111: aload_0
/*      */     //   112: getfield 92	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:esValido	Z
/*      */     //   115: istore 14
/*      */     //   117: aconst_null
/*      */     //   118: astore 5
/*      */     //   120: aconst_null
/*      */     //   121: astore 6
/*      */     //   123: iload 14
/*      */     //   125: ireturn
/*      */     //   126: aload 4
/*      */     //   128: invokevirtual 410	java/util/ArrayList:size	()I
/*      */     //   131: ifgt +59 -> 190
/*      */     //   134: aload_0
/*      */     //   135: iconst_0
/*      */     //   136: putfield 92	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:esValido	Z
/*      */     //   139: aload_0
/*      */     //   140: getfield 97	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:resultado	Les/mityc/firmaJava/libreria/xades/ResultadoValidacion;
/*      */     //   143: ldc_w 2227
/*      */     //   146: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   149: invokevirtual 568	es/mityc/firmaJava/libreria/xades/ResultadoValidacion:setLog	(Ljava/lang/String;)V
/*      */     //   152: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   155: ldc_w 2229
/*      */     //   158: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   161: invokeinterface 201 2 0
/*      */     //   166: ldc_w 2229
/*      */     //   169: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   172: invokestatic 574	es/mityc/firmaJava/libreria/xades/logv:error	(Ljava/lang/String;)V
/*      */     //   175: aload_0
/*      */     //   176: getfield 92	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:esValido	Z
/*      */     //   179: istore 14
/*      */     //   181: aconst_null
/*      */     //   182: astore 5
/*      */     //   184: aconst_null
/*      */     //   185: astore 6
/*      */     //   187: iload 14
/*      */     //   189: ireturn
/*      */     //   190: aload 4
/*      */     //   192: iconst_0
/*      */     //   193: invokevirtual 1017	java/util/ArrayList:get	(I)Ljava/lang/Object;
/*      */     //   196: checkcast 1056	org/w3c/dom/Element
/*      */     //   199: astore 7
/*      */     //   201: aload 7
/*      */     //   203: aload_3
/*      */     //   204: aload_0
/*      */     //   205: getfield 122	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:nombreNodoUri	Ljava/lang/String;
/*      */     //   208: invokeinterface 1327 3 0
/*      */     //   213: astore 8
/*      */     //   215: aload 8
/*      */     //   217: invokeinterface 827 1 0
/*      */     //   222: istore 9
/*      */     //   224: iload 9
/*      */     //   226: ifne +13 -> 239
/*      */     //   229: aload_3
/*      */     //   230: ldc_w 2231
/*      */     //   233: invokevirtual 855	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   236: ifeq +9 -> 245
/*      */     //   239: iload 9
/*      */     //   241: iconst_1
/*      */     //   242: if_icmple +107 -> 349
/*      */     //   245: aload_0
/*      */     //   246: iconst_0
/*      */     //   247: putfield 92	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:esValido	Z
/*      */     //   250: aload_0
/*      */     //   251: getfield 97	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:resultado	Les/mityc/firmaJava/libreria/xades/ResultadoValidacion;
/*      */     //   254: ldc_w 2233
/*      */     //   257: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   260: invokevirtual 568	es/mityc/firmaJava/libreria/xades/ResultadoValidacion:setLog	(Ljava/lang/String;)V
/*      */     //   263: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   266: new 257	java/lang/StringBuilder
/*      */     //   269: dup
/*      */     //   270: ldc_w 2235
/*      */     //   273: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   276: invokestatic 261	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   279: invokespecial 267	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   282: ldc_w 270
/*      */     //   285: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   288: iload 9
/*      */     //   290: invokevirtual 371	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*      */     //   293: invokevirtual 283	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   296: invokeinterface 201 2 0
/*      */     //   301: new 257	java/lang/StringBuilder
/*      */     //   304: dup
/*      */     //   305: ldc_w 2235
/*      */     //   308: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   311: invokestatic 261	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   314: invokespecial 267	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   317: ldc_w 270
/*      */     //   320: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   323: iload 9
/*      */     //   325: invokevirtual 371	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*      */     //   328: invokevirtual 283	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   331: invokestatic 574	es/mityc/firmaJava/libreria/xades/logv:error	(Ljava/lang/String;)V
/*      */     //   334: aload_0
/*      */     //   335: getfield 92	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:esValido	Z
/*      */     //   338: istore 14
/*      */     //   340: aconst_null
/*      */     //   341: astore 5
/*      */     //   343: aconst_null
/*      */     //   344: astore 6
/*      */     //   346: iload 14
/*      */     //   348: ireturn
/*      */     //   349: aload_3
/*      */     //   350: ldc_w 1787
/*      */     //   353: invokevirtual 855	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   356: ifeq +89 -> 445
/*      */     //   359: aload 8
/*      */     //   361: iconst_0
/*      */     //   362: invokeinterface 840 2 0
/*      */     //   367: checkcast 1056	org/w3c/dom/Element
/*      */     //   370: aload_0
/*      */     //   371: getfield 118	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:uriXmlNS	Ljava/lang/String;
/*      */     //   374: ldc_w 2237
/*      */     //   377: invokeinterface 1327 3 0
/*      */     //   382: astore 10
/*      */     //   384: aload 10
/*      */     //   386: invokeinterface 827 1 0
/*      */     //   391: istore 11
/*      */     //   393: iload 11
/*      */     //   395: ifle +50 -> 445
/*      */     //   398: aload_0
/*      */     //   399: iconst_0
/*      */     //   400: putfield 92	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:esValido	Z
/*      */     //   403: aload_0
/*      */     //   404: getfield 97	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:resultado	Les/mityc/firmaJava/libreria/xades/ResultadoValidacion;
/*      */     //   407: ldc_w 2239
/*      */     //   410: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   413: invokevirtual 568	es/mityc/firmaJava/libreria/xades/ResultadoValidacion:setLog	(Ljava/lang/String;)V
/*      */     //   416: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   419: ldc_w 2241
/*      */     //   422: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   425: invokeinterface 201 2 0
/*      */     //   430: aload_0
/*      */     //   431: getfield 92	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:esValido	Z
/*      */     //   434: istore 14
/*      */     //   436: aconst_null
/*      */     //   437: astore 5
/*      */     //   439: aconst_null
/*      */     //   440: astore 6
/*      */     //   442: iload 14
/*      */     //   444: ireturn
/*      */     //   445: iload 9
/*      */     //   447: ifne +13 -> 460
/*      */     //   450: aload_3
/*      */     //   451: ldc_w 2231
/*      */     //   454: invokevirtual 855	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   457: ifne +299 -> 756
/*      */     //   460: aload 8
/*      */     //   462: iconst_0
/*      */     //   463: invokeinterface 840 2 0
/*      */     //   468: invokeinterface 1298 1 0
/*      */     //   473: astore 10
/*      */     //   475: aload 10
/*      */     //   477: ifnull +17 -> 494
/*      */     //   480: aload 10
/*      */     //   482: aload_0
/*      */     //   483: getfield 126	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:tipoUri	Ljava/lang/String;
/*      */     //   486: invokeinterface 1925 2 0
/*      */     //   491: ifnonnull +50 -> 541
/*      */     //   494: aload_0
/*      */     //   495: iconst_0
/*      */     //   496: putfield 92	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:esValido	Z
/*      */     //   499: aload_0
/*      */     //   500: getfield 97	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:resultado	Les/mityc/firmaJava/libreria/xades/ResultadoValidacion;
/*      */     //   503: ldc_w 2243
/*      */     //   506: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   509: invokevirtual 568	es/mityc/firmaJava/libreria/xades/ResultadoValidacion:setLog	(Ljava/lang/String;)V
/*      */     //   512: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   515: ldc_w 2245
/*      */     //   518: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   521: invokeinterface 201 2 0
/*      */     //   526: aload_0
/*      */     //   527: getfield 92	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:esValido	Z
/*      */     //   530: istore 14
/*      */     //   532: aconst_null
/*      */     //   533: astore 5
/*      */     //   535: aconst_null
/*      */     //   536: astore 6
/*      */     //   538: iload 14
/*      */     //   540: ireturn
/*      */     //   541: aconst_null
/*      */     //   542: astore 11
/*      */     //   544: aload 10
/*      */     //   546: aload_0
/*      */     //   547: getfield 126	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:tipoUri	Ljava/lang/String;
/*      */     //   550: invokeinterface 1925 2 0
/*      */     //   555: invokeinterface 1293 1 0
/*      */     //   560: ldc_w 1098
/*      */     //   563: invokestatic 2247	java/net/URLDecoder:decode	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*      */     //   566: astore 11
/*      */     //   568: goto +54 -> 622
/*      */     //   571: astore 12
/*      */     //   573: aload_0
/*      */     //   574: iconst_0
/*      */     //   575: putfield 92	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:esValido	Z
/*      */     //   578: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   581: ldc_w 2251
/*      */     //   584: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   587: aload 12
/*      */     //   589: invokeinterface 1073 3 0
/*      */     //   594: aload_0
/*      */     //   595: getfield 97	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:resultado	Les/mityc/firmaJava/libreria/xades/ResultadoValidacion;
/*      */     //   598: ldc_w 2243
/*      */     //   601: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   604: invokevirtual 568	es/mityc/firmaJava/libreria/xades/ResultadoValidacion:setLog	(Ljava/lang/String;)V
/*      */     //   607: aload_0
/*      */     //   608: getfield 92	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:esValido	Z
/*      */     //   611: istore 14
/*      */     //   613: aconst_null
/*      */     //   614: astore 5
/*      */     //   616: aconst_null
/*      */     //   617: astore 6
/*      */     //   619: iload 14
/*      */     //   621: ireturn
/*      */     //   622: aload_2
/*      */     //   623: aload 11
/*      */     //   625: iconst_1
/*      */     //   626: invokevirtual 1208	java/lang/String:substring	(I)Ljava/lang/String;
/*      */     //   629: invokestatic 2253	es/mityc/firmaJava/libreria/utilidades/UtilidadTratarNodo:getElementById	(Lorg/w3c/dom/Element;Ljava/lang/String;)Lorg/w3c/dom/Element;
/*      */     //   632: astore 12
/*      */     //   634: aload 12
/*      */     //   636: ifnull +33 -> 669
/*      */     //   639: ldc_w 1141
/*      */     //   642: aload 12
/*      */     //   644: invokeinterface 1216 1 0
/*      */     //   649: invokevirtual 855	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   652: ifeq +17 -> 669
/*      */     //   655: aload 12
/*      */     //   657: invokeinterface 1324 1 0
/*      */     //   662: aload_2
/*      */     //   663: invokevirtual 1243	java/lang/Object:equals	(Ljava/lang/Object;)Z
/*      */     //   666: ifne +90 -> 756
/*      */     //   669: aload_0
/*      */     //   670: iconst_0
/*      */     //   671: putfield 92	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:esValido	Z
/*      */     //   674: aload_0
/*      */     //   675: getfield 97	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:resultado	Les/mityc/firmaJava/libreria/xades/ResultadoValidacion;
/*      */     //   678: ldc_w 2256
/*      */     //   681: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   684: invokevirtual 568	es/mityc/firmaJava/libreria/xades/ResultadoValidacion:setLog	(Ljava/lang/String;)V
/*      */     //   687: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   690: new 257	java/lang/StringBuilder
/*      */     //   693: dup
/*      */     //   694: ldc_w 2258
/*      */     //   697: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   700: invokestatic 261	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   703: invokespecial 267	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   706: ldc_w 270
/*      */     //   709: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   712: ldc_w 1141
/*      */     //   715: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   718: ldc_w 270
/*      */     //   721: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   724: ldc_w 2260
/*      */     //   727: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   730: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   733: invokevirtual 283	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   736: invokeinterface 201 2 0
/*      */     //   741: aload_0
/*      */     //   742: getfield 92	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:esValido	Z
/*      */     //   745: istore 14
/*      */     //   747: aconst_null
/*      */     //   748: astore 5
/*      */     //   750: aconst_null
/*      */     //   751: astore 6
/*      */     //   753: iload 14
/*      */     //   755: ireturn
/*      */     //   756: aload_0
/*      */     //   757: aload_3
/*      */     //   758: aload 7
/*      */     //   760: invokespecial 2262	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:getCanonicalizationMethodTS	(Ljava/lang/String;Lorg/w3c/dom/Element;)Les/mityc/firmaJava/libreria/xades/CanonicalizationEnum;
/*      */     //   763: astore 10
/*      */     //   765: aload_0
/*      */     //   766: getfield 92	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:esValido	Z
/*      */     //   769: ifne +18 -> 787
/*      */     //   772: aload_0
/*      */     //   773: getfield 92	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:esValido	Z
/*      */     //   776: istore 14
/*      */     //   778: aconst_null
/*      */     //   779: astore 5
/*      */     //   781: aconst_null
/*      */     //   782: astore 6
/*      */     //   784: iload 14
/*      */     //   786: ireturn
/*      */     //   787: aload 7
/*      */     //   789: aload_3
/*      */     //   790: ldc_w 2266
/*      */     //   793: invokeinterface 1327 3 0
/*      */     //   798: astore 5
/*      */     //   800: aload 5
/*      */     //   802: iconst_0
/*      */     //   803: invokeinterface 840 2 0
/*      */     //   808: checkcast 1056	org/w3c/dom/Element
/*      */     //   811: astore 6
/*      */     //   813: aload_0
/*      */     //   814: aload_0
/*      */     //   815: aload_3
/*      */     //   816: aload 6
/*      */     //   818: invokespecial 2268	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:validateEncodingTS	(Ljava/lang/String;Lorg/w3c/dom/Element;)Z
/*      */     //   821: putfield 92	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:esValido	Z
/*      */     //   824: aload_0
/*      */     //   825: getfield 92	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:esValido	Z
/*      */     //   828: ifne +18 -> 846
/*      */     //   831: aload_0
/*      */     //   832: getfield 92	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:esValido	Z
/*      */     //   835: istore 14
/*      */     //   837: aconst_null
/*      */     //   838: astore 5
/*      */     //   840: aconst_null
/*      */     //   841: astore 6
/*      */     //   843: iload 14
/*      */     //   845: ireturn
/*      */     //   846: aload_2
/*      */     //   847: aload_0
/*      */     //   848: getfield 118	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:uriXmlNS	Ljava/lang/String;
/*      */     //   851: ldc_w 1141
/*      */     //   854: aload 10
/*      */     //   856: iconst_5
/*      */     //   857: invokestatic 2272	es/mityc/firmaJava/libreria/utilidades/UtilidadTratarNodo:obtenerByteNodo	(Lorg/w3c/dom/Element;Ljava/lang/String;Ljava/lang/String;Les/mityc/firmaJava/libreria/xades/CanonicalizationEnum;I)[B
/*      */     //   860: astore 11
/*      */     //   862: aload_0
/*      */     //   863: aload 6
/*      */     //   865: aload 11
/*      */     //   867: getstatic 2276	es/mityc/firmaJava/libreria/xades/TipoSellosTiempo:CLASE_T	Les/mityc/firmaJava/libreria/xades/TipoSellosTiempo;
/*      */     //   870: invokespecial 2282	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:addDatosSelloFromBytes	(Lorg/w3c/dom/Element;[BLes/mityc/firmaJava/libreria/xades/TipoSellosTiempo;)V
/*      */     //   873: goto +346 -> 1219
/*      */     //   876: astore 7
/*      */     //   878: aload_0
/*      */     //   879: iconst_0
/*      */     //   880: putfield 92	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:esValido	Z
/*      */     //   883: aload_0
/*      */     //   884: getfield 97	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:resultado	Les/mityc/firmaJava/libreria/xades/ResultadoValidacion;
/*      */     //   887: ldc_w 2286
/*      */     //   890: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   893: invokevirtual 568	es/mityc/firmaJava/libreria/xades/ResultadoValidacion:setLog	(Ljava/lang/String;)V
/*      */     //   896: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   899: aload 7
/*      */     //   901: invokevirtual 1151	es/mityc/firmaJava/libreria/xades/errores/FirmaXMLError:getMessage	()Ljava/lang/String;
/*      */     //   904: aload 7
/*      */     //   906: invokeinterface 1073 3 0
/*      */     //   911: aload 7
/*      */     //   913: invokevirtual 1151	es/mityc/firmaJava/libreria/xades/errores/FirmaXMLError:getMessage	()Ljava/lang/String;
/*      */     //   916: invokestatic 574	es/mityc/firmaJava/libreria/xades/logv:error	(Ljava/lang/String;)V
/*      */     //   919: aconst_null
/*      */     //   920: astore 5
/*      */     //   922: aconst_null
/*      */     //   923: astore 6
/*      */     //   925: goto +300 -> 1225
/*      */     //   928: astore 7
/*      */     //   930: ldc_w 740
/*      */     //   933: astore 8
/*      */     //   935: aload_0
/*      */     //   936: getfield 116	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:tipoDocFirma	Les/mityc/firmaJava/libreria/xades/DatosTipoFirma;
/*      */     //   939: invokevirtual 482	es/mityc/firmaJava/libreria/xades/DatosTipoFirma:getTipoXAdES	()Les/mityc/javasign/EnumFormatoFirma;
/*      */     //   942: getstatic 1518	es/mityc/javasign/EnumFormatoFirma:XAdES_XL	Les/mityc/javasign/EnumFormatoFirma;
/*      */     //   945: invokevirtual 494	es/mityc/javasign/EnumFormatoFirma:compareTo	(Ljava/lang/Enum;)I
/*      */     //   948: ifne +8 -> 956
/*      */     //   951: ldc_w 1521
/*      */     //   954: astore 8
/*      */     //   956: aload_0
/*      */     //   957: iconst_0
/*      */     //   958: putfield 92	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:esValido	Z
/*      */     //   961: aload_0
/*      */     //   962: getfield 97	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:resultado	Les/mityc/firmaJava/libreria/xades/ResultadoValidacion;
/*      */     //   965: new 257	java/lang/StringBuilder
/*      */     //   968: dup
/*      */     //   969: ldc_w 1523
/*      */     //   972: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   975: invokestatic 261	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   978: invokespecial 267	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   981: ldc_w 270
/*      */     //   984: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   987: aload 8
/*      */     //   989: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   992: ldc_w 1525
/*      */     //   995: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   998: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1001: ldc_w 270
/*      */     //   1004: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1007: aload_0
/*      */     //   1008: getfield 116	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:tipoDocFirma	Les/mityc/firmaJava/libreria/xades/DatosTipoFirma;
/*      */     //   1011: invokevirtual 482	es/mityc/firmaJava/libreria/xades/DatosTipoFirma:getTipoXAdES	()Les/mityc/javasign/EnumFormatoFirma;
/*      */     //   1014: invokevirtual 1136	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*      */     //   1017: ldc_w 270
/*      */     //   1020: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1023: ldc_w 2288
/*      */     //   1026: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   1029: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1032: invokevirtual 283	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   1035: invokevirtual 568	es/mityc/firmaJava/libreria/xades/ResultadoValidacion:setLog	(Ljava/lang/String;)V
/*      */     //   1038: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   1041: aload 7
/*      */     //   1043: invokevirtual 2290	es/mityc/javasign/tsa/TimeStampException:getMessage	()Ljava/lang/String;
/*      */     //   1046: invokeinterface 201 2 0
/*      */     //   1051: aload 7
/*      */     //   1053: invokevirtual 2290	es/mityc/javasign/tsa/TimeStampException:getMessage	()Ljava/lang/String;
/*      */     //   1056: invokestatic 574	es/mityc/firmaJava/libreria/xades/logv:error	(Ljava/lang/String;)V
/*      */     //   1059: aconst_null
/*      */     //   1060: astore 5
/*      */     //   1062: aconst_null
/*      */     //   1063: astore 6
/*      */     //   1065: goto +160 -> 1225
/*      */     //   1068: astore 7
/*      */     //   1070: ldc_w 740
/*      */     //   1073: astore 8
/*      */     //   1075: aload_0
/*      */     //   1076: getfield 116	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:tipoDocFirma	Les/mityc/firmaJava/libreria/xades/DatosTipoFirma;
/*      */     //   1079: invokevirtual 482	es/mityc/firmaJava/libreria/xades/DatosTipoFirma:getTipoXAdES	()Les/mityc/javasign/EnumFormatoFirma;
/*      */     //   1082: getstatic 1518	es/mityc/javasign/EnumFormatoFirma:XAdES_XL	Les/mityc/javasign/EnumFormatoFirma;
/*      */     //   1085: invokevirtual 494	es/mityc/javasign/EnumFormatoFirma:compareTo	(Ljava/lang/Enum;)I
/*      */     //   1088: ifne +8 -> 1096
/*      */     //   1091: ldc_w 1521
/*      */     //   1094: astore 8
/*      */     //   1096: aload_0
/*      */     //   1097: iconst_0
/*      */     //   1098: putfield 92	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:esValido	Z
/*      */     //   1101: aload_0
/*      */     //   1102: getfield 97	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:resultado	Les/mityc/firmaJava/libreria/xades/ResultadoValidacion;
/*      */     //   1105: new 257	java/lang/StringBuilder
/*      */     //   1108: dup
/*      */     //   1109: ldc_w 1523
/*      */     //   1112: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   1115: invokestatic 261	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1118: invokespecial 267	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   1121: ldc_w 270
/*      */     //   1124: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1127: aload 8
/*      */     //   1129: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1132: ldc_w 1525
/*      */     //   1135: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   1138: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1141: ldc_w 270
/*      */     //   1144: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1147: aload_0
/*      */     //   1148: getfield 116	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:tipoDocFirma	Les/mityc/firmaJava/libreria/xades/DatosTipoFirma;
/*      */     //   1151: invokevirtual 482	es/mityc/firmaJava/libreria/xades/DatosTipoFirma:getTipoXAdES	()Les/mityc/javasign/EnumFormatoFirma;
/*      */     //   1154: invokevirtual 1136	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*      */     //   1157: ldc_w 270
/*      */     //   1160: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1163: ldc_w 2288
/*      */     //   1166: invokestatic 195	es/mityc/firmaJava/libreria/utilidades/I18n:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   1169: invokevirtual 272	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1172: invokevirtual 283	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   1175: invokevirtual 568	es/mityc/firmaJava/libreria/xades/ResultadoValidacion:setLog	(Ljava/lang/String;)V
/*      */     //   1178: getstatic 70	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:LOGGER	Lorg/apache/commons/logging/Log;
/*      */     //   1181: aload 7
/*      */     //   1183: invokevirtual 1568	java/lang/Exception:getMessage	()Ljava/lang/String;
/*      */     //   1186: invokeinterface 201 2 0
/*      */     //   1191: aload 7
/*      */     //   1193: invokevirtual 1568	java/lang/Exception:getMessage	()Ljava/lang/String;
/*      */     //   1196: invokestatic 574	es/mityc/firmaJava/libreria/xades/logv:error	(Ljava/lang/String;)V
/*      */     //   1199: aconst_null
/*      */     //   1200: astore 5
/*      */     //   1202: aconst_null
/*      */     //   1203: astore 6
/*      */     //   1205: goto +20 -> 1225
/*      */     //   1208: astore 13
/*      */     //   1210: aconst_null
/*      */     //   1211: astore 5
/*      */     //   1213: aconst_null
/*      */     //   1214: astore 6
/*      */     //   1216: aload 13
/*      */     //   1218: athrow
/*      */     //   1219: aconst_null
/*      */     //   1220: astore 5
/*      */     //   1222: aconst_null
/*      */     //   1223: astore 6
/*      */     //   1225: aload_0
/*      */     //   1226: getfield 92	es/mityc/firmaJava/libreria/xades/ValidarFirmaXML:esValido	Z
/*      */     //   1229: ireturn
/*      */     // Line number table:
/*      */     //   Java source line #2458	-> byte code offset #0
/*      */     //   Java source line #2459	-> byte code offset #7
/*      */     //   Java source line #2462	-> byte code offset #18
/*      */     //   Java source line #2463	-> byte code offset #23
/*      */     //   Java source line #2465	-> byte code offset #31
/*      */     //   Java source line #2466	-> byte code offset #40
/*      */     //   Java source line #2467	-> byte code offset #43
/*      */     //   Java source line #2472	-> byte code offset #46
/*      */     //   Java source line #2473	-> byte code offset #48
/*      */     //   Java source line #2472	-> byte code offset #59
/*      */     //   Java source line #2474	-> byte code offset #64
/*      */     //   Java source line #2475	-> byte code offset #69
/*      */     //   Java source line #2477	-> byte code offset #74
/*      */     //   Java source line #2479	-> byte code offset #87
/*      */     //   Java source line #2480	-> byte code offset #102
/*      */     //   Java source line #2481	-> byte code offset #111
/*      */     //   Java source line #2623	-> byte code offset #117
/*      */     //   Java source line #2624	-> byte code offset #120
/*      */     //   Java source line #2481	-> byte code offset #123
/*      */     //   Java source line #2484	-> byte code offset #126
/*      */     //   Java source line #2485	-> byte code offset #134
/*      */     //   Java source line #2487	-> byte code offset #139
/*      */     //   Java source line #2489	-> byte code offset #152
/*      */     //   Java source line #2491	-> byte code offset #166
/*      */     //   Java source line #2493	-> byte code offset #175
/*      */     //   Java source line #2623	-> byte code offset #181
/*      */     //   Java source line #2624	-> byte code offset #184
/*      */     //   Java source line #2493	-> byte code offset #187
/*      */     //   Java source line #2497	-> byte code offset #190
/*      */     //   Java source line #2498	-> byte code offset #201
/*      */     //   Java source line #2499	-> byte code offset #215
/*      */     //   Java source line #2500	-> byte code offset #224
/*      */     //   Java source line #2502	-> byte code offset #245
/*      */     //   Java source line #2504	-> byte code offset #250
/*      */     //   Java source line #2506	-> byte code offset #263
/*      */     //   Java source line #2507	-> byte code offset #282
/*      */     //   Java source line #2506	-> byte code offset #296
/*      */     //   Java source line #2509	-> byte code offset #301
/*      */     //   Java source line #2510	-> byte code offset #317
/*      */     //   Java source line #2509	-> byte code offset #328
/*      */     //   Java source line #2512	-> byte code offset #334
/*      */     //   Java source line #2623	-> byte code offset #340
/*      */     //   Java source line #2624	-> byte code offset #343
/*      */     //   Java source line #2512	-> byte code offset #346
/*      */     //   Java source line #2515	-> byte code offset #349
/*      */     //   Java source line #2516	-> byte code offset #359
/*      */     //   Java source line #2517	-> byte code offset #384
/*      */     //   Java source line #2518	-> byte code offset #393
/*      */     //   Java source line #2520	-> byte code offset #398
/*      */     //   Java source line #2522	-> byte code offset #403
/*      */     //   Java source line #2524	-> byte code offset #416
/*      */     //   Java source line #2525	-> byte code offset #430
/*      */     //   Java source line #2623	-> byte code offset #436
/*      */     //   Java source line #2624	-> byte code offset #439
/*      */     //   Java source line #2525	-> byte code offset #442
/*      */     //   Java source line #2529	-> byte code offset #445
/*      */     //   Java source line #2530	-> byte code offset #460
/*      */     //   Java source line #2531	-> byte code offset #475
/*      */     //   Java source line #2532	-> byte code offset #480
/*      */     //   Java source line #2533	-> byte code offset #494
/*      */     //   Java source line #2535	-> byte code offset #499
/*      */     //   Java source line #2537	-> byte code offset #512
/*      */     //   Java source line #2538	-> byte code offset #526
/*      */     //   Java source line #2623	-> byte code offset #532
/*      */     //   Java source line #2624	-> byte code offset #535
/*      */     //   Java source line #2538	-> byte code offset #538
/*      */     //   Java source line #2540	-> byte code offset #541
/*      */     //   Java source line #2542	-> byte code offset #544
/*      */     //   Java source line #2543	-> byte code offset #568
/*      */     //   Java source line #2544	-> byte code offset #573
/*      */     //   Java source line #2546	-> byte code offset #578
/*      */     //   Java source line #2548	-> byte code offset #594
/*      */     //   Java source line #2549	-> byte code offset #607
/*      */     //   Java source line #2623	-> byte code offset #613
/*      */     //   Java source line #2624	-> byte code offset #616
/*      */     //   Java source line #2549	-> byte code offset #619
/*      */     //   Java source line #2551	-> byte code offset #622
/*      */     //   Java source line #2552	-> byte code offset #634
/*      */     //   Java source line #2554	-> byte code offset #655
/*      */     //   Java source line #2555	-> byte code offset #669
/*      */     //   Java source line #2557	-> byte code offset #674
/*      */     //   Java source line #2559	-> byte code offset #687
/*      */     //   Java source line #2560	-> byte code offset #706
/*      */     //   Java source line #2561	-> byte code offset #724
/*      */     //   Java source line #2559	-> byte code offset #736
/*      */     //   Java source line #2562	-> byte code offset #741
/*      */     //   Java source line #2623	-> byte code offset #747
/*      */     //   Java source line #2624	-> byte code offset #750
/*      */     //   Java source line #2562	-> byte code offset #753
/*      */     //   Java source line #2566	-> byte code offset #756
/*      */     //   Java source line #2567	-> byte code offset #765
/*      */     //   Java source line #2568	-> byte code offset #772
/*      */     //   Java source line #2623	-> byte code offset #778
/*      */     //   Java source line #2624	-> byte code offset #781
/*      */     //   Java source line #2568	-> byte code offset #784
/*      */     //   Java source line #2572	-> byte code offset #787
/*      */     //   Java source line #2573	-> byte code offset #800
/*      */     //   Java source line #2576	-> byte code offset #813
/*      */     //   Java source line #2577	-> byte code offset #824
/*      */     //   Java source line #2578	-> byte code offset #831
/*      */     //   Java source line #2623	-> byte code offset #837
/*      */     //   Java source line #2624	-> byte code offset #840
/*      */     //   Java source line #2578	-> byte code offset #843
/*      */     //   Java source line #2581	-> byte code offset #846
/*      */     //   Java source line #2582	-> byte code offset #854
/*      */     //   Java source line #2581	-> byte code offset #857
/*      */     //   Java source line #2584	-> byte code offset #862
/*      */     //   Java source line #2585	-> byte code offset #873
/*      */     //   Java source line #2586	-> byte code offset #878
/*      */     //   Java source line #2587	-> byte code offset #883
/*      */     //   Java source line #2588	-> byte code offset #896
/*      */     //   Java source line #2590	-> byte code offset #911
/*      */     //   Java source line #2623	-> byte code offset #919
/*      */     //   Java source line #2624	-> byte code offset #922
/*      */     //   Java source line #2592	-> byte code offset #928
/*      */     //   Java source line #2593	-> byte code offset #930
/*      */     //   Java source line #2594	-> byte code offset #935
/*      */     //   Java source line #2595	-> byte code offset #951
/*      */     //   Java source line #2597	-> byte code offset #956
/*      */     //   Java source line #2599	-> byte code offset #961
/*      */     //   Java source line #2600	-> byte code offset #987
/*      */     //   Java source line #2601	-> byte code offset #1007
/*      */     //   Java source line #2602	-> byte code offset #1023
/*      */     //   Java source line #2599	-> byte code offset #1035
/*      */     //   Java source line #2603	-> byte code offset #1038
/*      */     //   Java source line #2605	-> byte code offset #1051
/*      */     //   Java source line #2623	-> byte code offset #1059
/*      */     //   Java source line #2624	-> byte code offset #1062
/*      */     //   Java source line #2607	-> byte code offset #1068
/*      */     //   Java source line #2608	-> byte code offset #1070
/*      */     //   Java source line #2609	-> byte code offset #1075
/*      */     //   Java source line #2610	-> byte code offset #1091
/*      */     //   Java source line #2612	-> byte code offset #1096
/*      */     //   Java source line #2614	-> byte code offset #1101
/*      */     //   Java source line #2615	-> byte code offset #1127
/*      */     //   Java source line #2616	-> byte code offset #1147
/*      */     //   Java source line #2617	-> byte code offset #1163
/*      */     //   Java source line #2614	-> byte code offset #1175
/*      */     //   Java source line #2618	-> byte code offset #1178
/*      */     //   Java source line #2620	-> byte code offset #1191
/*      */     //   Java source line #2623	-> byte code offset #1199
/*      */     //   Java source line #2624	-> byte code offset #1202
/*      */     //   Java source line #2622	-> byte code offset #1208
/*      */     //   Java source line #2623	-> byte code offset #1210
/*      */     //   Java source line #2624	-> byte code offset #1213
/*      */     //   Java source line #2625	-> byte code offset #1216
/*      */     //   Java source line #2623	-> byte code offset #1219
/*      */     //   Java source line #2624	-> byte code offset #1222
/*      */     //   Java source line #2627	-> byte code offset #1225
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	1230	0	this	ValidarFirmaXML
/*      */     //   0	1230	1	estructuraFirma	EstructuraFirma
/*      */     //   22	825	2	firma	Element
/*      */     //   30	786	3	esquemaURI	String
/*      */     //   38	153	4	nodosSignatureTimeStamp	ArrayList<Element>
/*      */     //   41	1180	5	nodesEncapsulatedTimeStamp	NodeList
/*      */     //   44	1180	6	encapsulatedTimeStampElement	Element
/*      */     //   67	29	7	e	FirmaXMLError
/*      */     //   199	589	7	nodoSigTimeStamp	Element
/*      */     //   876	36	7	e	FirmaXMLError
/*      */     //   928	124	7	e	TimeStampException
/*      */     //   1068	124	7	e	Exception
/*      */     //   213	248	8	nodosUri	NodeList
/*      */     //   933	55	8	sello	String
/*      */     //   1073	55	8	sello	String
/*      */     //   222	224	9	nodosLenght	int
/*      */     //   382	3	10	nodosTransforms	NodeList
/*      */     //   473	72	10	nodosUriAttrb	NamedNodeMap
/*      */     //   763	92	10	canonicalization	CanonicalizationEnum
/*      */     //   391	3	11	transformsLenght	int
/*      */     //   542	82	11	timeStampUri	String
/*      */     //   860	6	11	nodeSignatureValue	byte[]
/*      */     //   571	17	12	ex	UnsupportedEncodingException
/*      */     //   632	24	12	nodoReferenciado	Element
/*      */     //   1208	9	13	localObject	Object
/*      */     //   115	729	14	bool	boolean
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   46	64	67	es/mityc/firmaJava/libreria/xades/errores/FirmaXMLError
/*      */     //   544	568	571	java/io/UnsupportedEncodingException
/*      */     //   46	117	876	es/mityc/firmaJava/libreria/xades/errores/FirmaXMLError
/*      */     //   126	181	876	es/mityc/firmaJava/libreria/xades/errores/FirmaXMLError
/*      */     //   190	340	876	es/mityc/firmaJava/libreria/xades/errores/FirmaXMLError
/*      */     //   349	436	876	es/mityc/firmaJava/libreria/xades/errores/FirmaXMLError
/*      */     //   445	532	876	es/mityc/firmaJava/libreria/xades/errores/FirmaXMLError
/*      */     //   541	613	876	es/mityc/firmaJava/libreria/xades/errores/FirmaXMLError
/*      */     //   622	747	876	es/mityc/firmaJava/libreria/xades/errores/FirmaXMLError
/*      */     //   756	778	876	es/mityc/firmaJava/libreria/xades/errores/FirmaXMLError
/*      */     //   787	837	876	es/mityc/firmaJava/libreria/xades/errores/FirmaXMLError
/*      */     //   846	873	876	es/mityc/firmaJava/libreria/xades/errores/FirmaXMLError
/*      */     //   46	117	928	es/mityc/javasign/tsa/TimeStampException
/*      */     //   126	181	928	es/mityc/javasign/tsa/TimeStampException
/*      */     //   190	340	928	es/mityc/javasign/tsa/TimeStampException
/*      */     //   349	436	928	es/mityc/javasign/tsa/TimeStampException
/*      */     //   445	532	928	es/mityc/javasign/tsa/TimeStampException
/*      */     //   541	613	928	es/mityc/javasign/tsa/TimeStampException
/*      */     //   622	747	928	es/mityc/javasign/tsa/TimeStampException
/*      */     //   756	778	928	es/mityc/javasign/tsa/TimeStampException
/*      */     //   787	837	928	es/mityc/javasign/tsa/TimeStampException
/*      */     //   846	873	928	es/mityc/javasign/tsa/TimeStampException
/*      */     //   46	117	1068	java/lang/Exception
/*      */     //   126	181	1068	java/lang/Exception
/*      */     //   190	340	1068	java/lang/Exception
/*      */     //   349	436	1068	java/lang/Exception
/*      */     //   445	532	1068	java/lang/Exception
/*      */     //   541	613	1068	java/lang/Exception
/*      */     //   622	747	1068	java/lang/Exception
/*      */     //   756	778	1068	java/lang/Exception
/*      */     //   787	837	1068	java/lang/Exception
/*      */     //   846	873	1068	java/lang/Exception
/*      */     //   46	117	1208	finally
/*      */     //   126	181	1208	finally
/*      */     //   190	340	1208	finally
/*      */     //   349	436	1208	finally
/*      */     //   445	532	1208	finally
/*      */     //   541	613	1208	finally
/*      */     //   622	747	1208	finally
/*      */     //   756	778	1208	finally
/*      */     //   787	837	1208	finally
/*      */     //   846	919	1208	finally
/*      */     //   928	1059	1208	finally
/*      */     //   1068	1199	1208	finally
/*      */   }
/*      */   
/*      */   private void addDatosSelloFromBytes(Element encapsulatedTimeStampElement, byte[] nodeSignatureValue, TipoSellosTiempo tipoSello)
/*      */     throws TimeStampException
/*      */   {
/* 2642 */     String encapsulatedTS = encapsulatedTimeStampElement.getFirstChild().getNodeValue();
/* 2643 */     byte[] timeStampBytes = Base64.decode(encapsulatedTS);
/* 2644 */     DatosSelloTiempo datosSelloTiempo = new DatosSelloTiempo();
/*      */     
/* 2646 */     TSValidationResult tsv = this.tsValidator.validateTimeStamp(nodeSignatureValue, timeStampBytes);
/*      */     
/* 2648 */     Date fechaSello = tsv.getDate();
/* 2649 */     if (fechaSello != null) {
/* 2650 */       long now = System.currentTimeMillis();
/* 2651 */       if (tsv.getTimeAccurracy() > 0L)
/* 2652 */         now += tsv.getTimeAccurracy();
/* 2653 */       if (fechaSello.after(new Date(now)))
/*      */       {
/* 2655 */         this.resultado.setResultado(ResultadoEnum.UNKNOWN);
/* 2656 */         LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error81"));
/* 2657 */         this.resultado.setLog(i18n.getLocalMessage("i18n.mityc.xades.validate.16", new Object[] { fechaSello, Long.valueOf(tsv.getTimeAccurracy()), new Date(System.currentTimeMillis()) }));
/* 2658 */         LOGGER.error(i18n.getLocalMessage("i18n.mityc.xades.validate.16", new Object[] { fechaSello, Long.valueOf(tsv.getTimeAccurracy()), new Date(System.currentTimeMillis()) }));
/*      */         
/* 2660 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error81"));
/*      */       }
/*      */     }
/*      */     
/* 2664 */     if (this.esValido) {
/*      */       try {
/* 2666 */         datosSelloTiempo.setFecha(fechaSello);
/* 2667 */         datosSelloTiempo.setEmisor(tsv.getTimeStampIssuer());
/* 2668 */         datosSelloTiempo.setAlgoritmo(TSPAlgoritmos.getAlgName(tsv.getStampAlg()));
/* 2669 */         datosSelloTiempo.setPrecision(Long.valueOf(tsv.getTimeAccurracy()));
/* 2670 */         datosSelloTiempo.setTipoSello(tipoSello);
/* 2671 */         datosSelloTiempo.setRawTimestamp(tsv.getTimeStampRawToken());
/* 2672 */         CertPath tsaCerts = tsv.getCadena();
/* 2673 */         if (tsaCerts != null) {
/* 2674 */           if ((this.truster != null) && (tsaCerts.getCertificates().size() == 1))
/*      */           {
/*      */             try {
/* 2677 */               tsaCerts = this.truster.getCertPath((X509Certificate)tsaCerts.getCertificates().get(0));
/*      */               
/* 2679 */               datosSelloTiempo.setCadena(
/* 2680 */                 UtilidadCertificados.orderCertPath(
/* 2681 */                 tsaCerts.getCertificates()));
/* 2682 */               datosSelloTiempo.setEsCertConfianza(ConfianzaEnum.CON_CONFIANZA);
/*      */             } catch (Exception e) {
/* 2684 */               LOGGER.debug("No se pudo ordenar la cadena de certificados del sello de tiempo");
/* 2685 */               datosSelloTiempo.setCadena(tsaCerts);
/*      */             }
/*      */           } else {
/* 2688 */             LOGGER.debug("No se pudo recuperar la cadena de certificación");
/* 2689 */             datosSelloTiempo.setCadena(tsaCerts);
/*      */           }
/*      */         }
/*      */         
/* 2693 */         logv.abreTag(true);
/* 2694 */         logv.info("XAdES-T TimeStamp validation: VALID", 2);
/* 2695 */         logv.info("Date: " + fechaSello, 2);
/* 2696 */         logv.info("Issuer: " + tsv.getTimeStampIssuer(), 2);
/* 2697 */         logv.cierraTag(true);
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/* 2701 */         this.esValido = false;
/* 2702 */         LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error64"), e);
/*      */         
/* 2704 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error64"));
/*      */         
/* 2706 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error64"));
/*      */       }
/*      */       
/* 2709 */       this.arrayDatosSello.add(datosSelloTiempo);
/*      */     } else {
/* 2711 */       logv.abreTag(false);
/* 2712 */       logv.info("XAdES-T TimeStamp validation: INVALID", 2);
/* 2713 */       logv.info("Date: " + fechaSello, 2);
/* 2714 */       logv.info("Issuer: " + tsv.getTimeStampIssuer(), 2);
/* 2715 */       logv.cierraTag(false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private CanonicalizationEnum getCanonicalizationMethodTS(String esquemaURI, Element nodoSigTimeStamp)
/*      */   {
/* 2728 */     NodeList nodosCanonicalizationMethod = nodoSigTimeStamp.getElementsByTagNameNS(this.uriXmlNS, "CanonicalizationMethod");
/* 2729 */     int numNodosCanonicalization = nodosCanonicalizationMethod.getLength();
/* 2730 */     CanonicalizationEnum canonicalization = CanonicalizationEnum.C14N_OMIT_COMMENTS;
/* 2731 */     if (numNodosCanonicalization > 0) {
/* 2732 */       if ("http://uri.etsi.org/01903/v1.1.1#".equals(esquemaURI)) {
/* 2733 */         this.esValido = false;
/* 2734 */         LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error102"));
/* 2735 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error102"));
/* 2736 */         return null;
/*      */       }
/* 2738 */       Element nodoCanonicalizationMethod = (Element)nodosCanonicalizationMethod.item(0);
/* 2739 */       String method = nodoCanonicalizationMethod.getAttribute("Algorithm");
/* 2740 */       canonicalization = CanonicalizationEnum.getCanonicalization(method);
/* 2741 */       if (canonicalization.equals(CanonicalizationEnum.UNKNOWN)) {
/* 2742 */         this.esValido = false;
/*      */         
/* 2744 */         LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error103") + 
/* 2745 */           " " + method);
/*      */         
/* 2747 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error103") + 
/* 2748 */           " " + method);
/*      */         
/* 2750 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error103") + 
/* 2751 */           " " + method);
/* 2752 */         return null;
/*      */       }
/*      */     }
/*      */     
/* 2756 */     return canonicalization;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean validarSelloTiempoXadesX(EstructuraFirma estructuraFirma, String nombreNodo)
/*      */   {
/* 2775 */     ArrayList<Element> nodesTimeStamp = new ArrayList();
/*      */     try {
/* 2777 */       nodesTimeStamp = UtilidadTratarNodo.obtenerNodos(estructuraFirma.firma, 5, 
/* 2778 */         new NombreNodo(estructuraFirma.esquema.getSchemaUri(), nombreNodo));
/*      */     } catch (FirmaXMLError e) {
/* 2780 */       LOGGER.error(e.getMessage(), e);
/* 2781 */       return false;
/*      */     }
/* 2783 */     int numNodos = nodesTimeStamp.size();
/*      */     
/* 2785 */     if (numNodos == 0) {
/* 2786 */       return false;
/*      */     }
/* 2788 */     for (int i = 0; i < numNodos; i++) {
/* 2789 */       this.esValido = validarSegundoSelloTiempo((Element)nodesTimeStamp.get(i), estructuraFirma);
/* 2790 */       if (!this.esValido) {
/*      */         break;
/*      */       }
/*      */     }
/* 2794 */     return this.esValido;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean validarSegundoSelloTiempo(Element selloTiempo, EstructuraFirma estructuraFirma)
/*      */   {
/* 2804 */     if (this.tsValidator == null) {
/* 2805 */       LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error64"));
/* 2806 */       return false;
/*      */     }
/*      */     
/* 2809 */     Element firma = estructuraFirma.firma;
/* 2810 */     String esquemaURI = estructuraFirma.esquema.getSchemaUri();
/*      */     
/* 2812 */     TipoSellosTiempo tipoSello = TipoSellosTiempo.CLASE_X_TIPO_1;
/*      */     
/*      */ 
/* 2815 */     if (new NombreNodo(esquemaURI, "SigAndRefsTimeStamp").equals(new NombreNodo(selloTiempo.getNamespaceURI(), selloTiempo.getLocalName()))) {
/* 2816 */       tipoSello = TipoSellosTiempo.CLASE_X_TIPO_1;
/*      */     }
/* 2818 */     else if (new NombreNodo(esquemaURI, "RefsOnlyTimeStamp").equals(new NombreNodo(selloTiempo.getNamespaceURI(), selloTiempo.getLocalName()))) {
/* 2819 */       tipoSello = TipoSellosTiempo.CLASE_X_TIPO_2;
/*      */     } else {
/* 2821 */       this.esValido = false;
/*      */       
/* 2823 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error15"));
/*      */       
/* 2825 */       LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error8") + " " + 
/* 2826 */         I18n.getResource("libreriaxades.validarfirmaxml.error9") + " " + 
/* 2827 */         selloTiempo.getLocalName() + " " + 
/* 2828 */         I18n.getResource("libreriaxades.validarfirmaxml.error10"));
/*      */       
/* 2830 */       logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error8") + " " + 
/* 2831 */         I18n.getResource("libreriaxades.validarfirmaxml.error9") + " " + 
/* 2832 */         selloTiempo.getLocalName() + " " + 
/* 2833 */         I18n.getResource("libreriaxades.validarfirmaxml.error10"));
/*      */       
/* 2835 */       return this.esValido;
/*      */     }
/*      */     
/*      */ 
/* 2839 */     ArrayList<Element> elementosSelloX = null;
/*      */     try {
/* 2841 */       if (TipoSellosTiempo.CLASE_X_TIPO_1.equals(tipoSello)) {
/* 2842 */         elementosSelloX = UtilidadXadesX.obtenerListadoXADESX1imp(esquemaURI, firma, selloTiempo);
/*      */       } else
/* 2844 */         elementosSelloX = UtilidadXadesX.obtenerListadoXADESX2exp(esquemaURI, firma, selloTiempo);
/*      */     } catch (BadFormedSignatureException e) {
/* 2846 */       this.esValido = false;
/*      */       
/* 2848 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error148"));
/* 2849 */       LOGGER.error(e.getMessage(), e);
/*      */       
/* 2851 */       logv.error(e.getMessage());
/*      */       
/* 2853 */       return this.esValido;
/*      */     } catch (FirmaXMLError e) {
/* 2855 */       this.esValido = false;
/*      */       
/* 2857 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error148"));
/* 2858 */       LOGGER.error(e.getMessage(), e);
/*      */       
/* 2860 */       logv.error(e.getMessage());
/*      */       
/* 2862 */       return this.esValido;
/*      */     }
/*      */     
/*      */ 
/* 2866 */     if (elementosSelloX.size() <= 0) {
/* 2867 */       this.esValido = false;
/*      */       
/* 2869 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error143"));
/*      */       
/* 2871 */       LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error91"));
/*      */       
/* 2873 */       logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error91"));
/*      */       
/* 2875 */       return this.esValido;
/*      */     }
/*      */     
/*      */ 
/* 2879 */     if (("http://uri.etsi.org/01903/v1.1.1#".equals(esquemaURI)) || 
/* 2880 */       ("http://uri.etsi.org/01903/v1.2.2#".equals(esquemaURI)))
/*      */     {
/* 2882 */       ArrayList<String> elementosIdSelloX = UtilidadTratarNodo.obtenerIDs(elementosSelloX);
/*      */       
/*      */ 
/* 2885 */       NodeList nodosUriRef = selloTiempo.getElementsByTagNameNS(esquemaURI, this.nombreNodoUri);
/* 2886 */       int numNodosUriRef = nodosUriRef.getLength();
/*      */       
/* 2888 */       if (numNodosUriRef == 0)
/*      */       {
/* 2890 */         this.esValido = false;
/*      */         
/* 2892 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error144"));
/*      */         
/* 2894 */         LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error94") + 
/* 2895 */           " " + numNodosUriRef);
/*      */         
/* 2897 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error94") + 
/* 2898 */           " " + numNodosUriRef);
/*      */         
/* 2900 */         return this.esValido;
/*      */       }
/*      */       
/*      */ 
/* 2904 */       ArrayList<String> urisRef = new ArrayList(numNodosUriRef);
/* 2905 */       Element nodoUriRef = null;
/*      */       
/*      */ 
/* 2908 */       for (int j = 0; j < numNodosUriRef; j++) {
/* 2909 */         if (j == 0) {
/* 2910 */           nodoUriRef = (Element)selloTiempo.getFirstChild();
/*      */         } else {
/* 2912 */           nodoUriRef = (Element)nodoUriRef.getNextSibling();
/*      */         }
/* 2914 */         if ((nodoUriRef == null) || (!this.nombreNodoUri.equals(nodoUriRef.getLocalName()))) {
/* 2915 */           this.esValido = false;
/*      */           
/* 2917 */           this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error146"));
/*      */           
/* 2919 */           LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error95") + 
/* 2920 */             " " + this.nombreNodoUri);
/* 2921 */           return this.esValido;
/*      */         }
/*      */         
/*      */ 
/* 2925 */         if ("http://uri.etsi.org/01903/v1.1.1#".equals(esquemaURI)) {
/* 2926 */           NodeList nodosTransforms = nodoUriRef.getElementsByTagNameNS(this.uriXmlNS, "Transforms");
/* 2927 */           int transformsLenght = nodosTransforms.getLength();
/* 2928 */           if (transformsLenght > 0) {
/* 2929 */             this.esValido = false;
/*      */             
/* 2931 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error145"));
/*      */             
/* 2933 */             LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error93"));
/* 2934 */             return this.esValido;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 2939 */         NamedNodeMap atributosNodo = nodoUriRef.getAttributes();
/* 2940 */         if ((atributosNodo == null) || (atributosNodo.getNamedItem(this.tipoUri) == null)) {
/* 2941 */           this.esValido = false;
/*      */           
/* 2943 */           this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error143"));
/*      */           
/* 2945 */           LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error92"));
/* 2946 */           return this.esValido;
/*      */         }
/* 2948 */         String uriReferencia = atributosNodo.getNamedItem(this.tipoUri).getNodeValue();
/*      */         
/* 2950 */         urisRef.add(uriReferencia);
/*      */       }
/*      */       
/*      */ 
/* 2954 */       for (int j = 0; j < numNodosUriRef; j++) {
/* 2955 */         String idUri = ((String)urisRef.get(j)).substring(1);
/* 2956 */         if (!idUri.equals(elementosIdSelloX.get(j)))
/*      */         {
/* 2958 */           this.esValido = false;
/* 2959 */           this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error97") + 
/* 2960 */             " " + idUri + " " + 
/* 2961 */             I18n.getResource("libreriaxades.validarfirmaxml.error98"));
/* 2962 */           LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error97") + 
/* 2963 */             " " + idUri + " " + 
/* 2964 */             I18n.getResource("libreriaxades.validarfirmaxml.error98"));
/* 2965 */           return this.esValido;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2971 */     CanonicalizationEnum canonicalization = getCanonicalizationMethodTS(esquemaURI, selloTiempo);
/* 2972 */     if (!this.esValido) {
/* 2973 */       return this.esValido;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2978 */     byte[] byteData = null;
/*      */     try {
/* 2980 */       byteData = UtilidadTratarNodo.obtenerByte(elementosSelloX, canonicalization);
/*      */     } catch (FirmaXMLError e) {
/* 2982 */       this.esValido = false;
/*      */       
/* 2984 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error14"));
/*      */       
/* 2986 */       logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error14"));
/*      */       
/* 2988 */       LOGGER.error(e.getMessage(), e);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2993 */     NodeList nodesEncapsulatedTimeStamp = selloTiempo.getElementsByTagNameNS(esquemaURI, "EncapsulatedTimeStamp");
/*      */     
/* 2995 */     if (nodesEncapsulatedTimeStamp.getLength() != 1) {
/* 2996 */       this.esValido = false;
/*      */       
/* 2998 */       LOGGER.error(I18n.getResource("libreriaxades.firmaxml.error36") + " " + 
/* 2999 */         "EncapsulatedTimeStamp" + I18n.getResource("libreriaxades.firmaxml.error37") + 
/* 3000 */         " " + nodesEncapsulatedTimeStamp.getLength());
/*      */       
/* 3002 */       logv.error(I18n.getResource("libreriaxades.firmaxml.error36") + " " + 
/* 3003 */         "EncapsulatedTimeStamp" + I18n.getResource("libreriaxades.firmaxml.error37") + 
/* 3004 */         " " + nodesEncapsulatedTimeStamp.getLength());
/*      */       
/*      */ 
/* 3007 */       this.resultado.setLog(I18n.getResource("libreriaxades.firmaxml.error15"));
/* 3008 */       return this.esValido;
/*      */     }
/*      */     
/* 3011 */     Element encapsulatedTimeStampElement = (Element)nodesEncapsulatedTimeStamp.item(0);
/*      */     
/* 3013 */     this.esValido = validateEncodingTS(esquemaURI, encapsulatedTimeStampElement);
/* 3014 */     if (!this.esValido) {
/* 3015 */       return this.esValido;
/*      */     }
/*      */     try
/*      */     {
/* 3019 */       addDatosSelloFromBytes(encapsulatedTimeStampElement, byteData, tipoSello);
/*      */     } catch (TimeStampException e) {
/* 3021 */       String sello = "";
/* 3022 */       if (this.tipoDocFirma.getTipoXAdES().compareTo(EnumFormatoFirma.XAdES_XL) == 0) {
/* 3023 */         sello = "XAdES T ";
/*      */       }
/* 3025 */       this.esValido = false;
/*      */       
/* 3027 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error8") + " " + 
/* 3028 */         sello + I18n.getResource("libreriaxades.validarfirmaxml.error9") + " " + 
/* 3029 */         this.tipoDocFirma.getTipoXAdES() + " " + 
/* 3030 */         I18n.getResource("libreriaxades.validarfirmaxml.error13"));
/* 3031 */       LOGGER.error(e.getMessage());
/*      */       
/* 3033 */       logv.error(e.getMessage());
/*      */     }
/*      */     
/*      */ 
/* 3037 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean validateEncodingTS(String esquemaURI, Element encapsulatedTimeStampElement)
/*      */   {
/* 3049 */     if (("http://uri.etsi.org/01903/v1.2.2#".equals(esquemaURI)) || 
/* 3050 */       ("http://uri.etsi.org/01903/v1.3.2#".equals(esquemaURI))) {
/* 3051 */       String enc = encapsulatedTimeStampElement.getAttribute("Encoding");
/* 3052 */       EncodingEnum encoding = EncodingEnum.getEncoding(enc);
/* 3053 */       if (encoding == null) {
/* 3054 */         this.esValido = false;
/* 3055 */         LOGGER.error("Encoding del sello de tiempo X desconocido: " + enc);
/* 3056 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error148"));
/*      */       }
/*      */     }
/* 3059 */     return this.esValido;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean validarXadesC(String uriDS, X509Certificate certFirma, EstructuraFirma estructuraFirma)
/*      */   {
/* 3077 */     Element firma = estructuraFirma.firma;
/* 3078 */     String esquemaURI = estructuraFirma.esquema.getSchemaUri();
/*      */     
/* 3080 */     ArrayList<Element> completeCertificateRefs = new ArrayList();
/* 3081 */     ArrayList<Element> completeRevocationRefs = new ArrayList();
/*      */     
/*      */ 
/* 3084 */     ArrayList<String> certURI = null;
/* 3085 */     ArrayList<String> digestAlg = null;
/* 3086 */     ArrayList<String> digestValue = null;
/* 3087 */     ArrayList<X500Principal> issuerName = null;
/* 3088 */     ArrayList<String> issuerSerial = null;
/*      */     
/*      */ 
/* 3091 */     ArrayList<String> ocspURI = null;
/* 3092 */     ArrayList<OCSPResponderID> identifierOCSP = null;
/* 3093 */     ArrayList<Date> identifierTime = null;
/* 3094 */     ArrayList<String> ocspDigestAlg = null;
/* 3095 */     ArrayList<String> ocspDigestValue = null;
/* 3096 */     ArrayList<OCSPResp> respuestasOCSP = null;
/*      */     
/*      */ 
/* 3099 */     ArrayList<String> crlURI = null;
/* 3100 */     ArrayList<String> crlDigestAlg = null;
/* 3101 */     ArrayList<String> crlDigestValue = null;
/* 3102 */     ArrayList<String> crlIssuer = null;
/* 3103 */     ArrayList<Date> crlIssuerTime = null;
/* 3104 */     ArrayList<BigInteger> crlNumber = null;
/* 3105 */     ArrayList<X509CRL> crlList = null;
/*      */     
/*      */     try
/*      */     {
/* 3109 */       completeCertificateRefs = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 3110 */         new NombreNodo(esquemaURI, "CompleteCertificateRefs"));
/* 3111 */       completeRevocationRefs = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 3112 */         new NombreNodo(esquemaURI, "CompleteRevocationRefs"));
/*      */     }
/*      */     catch (FirmaXMLError e) {
/* 3115 */       LOGGER.error(e.getMessage(), e);
/* 3116 */       logv.error(I18n.getResource("libreriaxades.firmaxml.error29"));
/*      */       
/* 3118 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error135"));
/* 3119 */       this.esValido = false;
/*      */     }
/*      */     
/* 3122 */     if ((completeCertificateRefs.size() == 0) || (completeRevocationRefs.size() == 0))
/*      */     {
/* 3124 */       LOGGER.error(I18n.getResource("libreriaxades.firmaxml.error29"));
/*      */       
/* 3126 */       logv.error(I18n.getResource("libreriaxades.firmaxml.error29"));
/*      */       
/*      */ 
/* 3129 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error135"));
/* 3130 */       this.esValido = false;
/* 3131 */       return this.esValido;
/*      */     }
/*      */     
/*      */ 
/* 3135 */     Node certRefs = ((Element)completeCertificateRefs.get(0))
/* 3136 */       .getElementsByTagNameNS(esquemaURI, "CertRefs").item(0);
/*      */     
/*      */ 
/* 3139 */     if (certRefs != null)
/*      */     {
/*      */ 
/* 3142 */       ArrayList<Element> certs = UtilidadTratarNodo.getElementChildNodes((Element)certRefs, false);
/* 3143 */       if (certs == null) {
/* 3144 */         this.esValido = false;
/* 3145 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/* 3146 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/* 3147 */         return false;
/*      */       }
/* 3149 */       int l = certs.size();
/*      */       
/* 3151 */       certURI = new ArrayList(l);
/* 3152 */       digestAlg = new ArrayList(l);
/* 3153 */       digestValue = new ArrayList(l);
/* 3154 */       issuerName = new ArrayList(l);
/* 3155 */       issuerSerial = new ArrayList(l);
/*      */       
/* 3157 */       int i = 0;
/*      */       do
/*      */       {
/* 3160 */         Element certificate = (Element)certs.get(i);
/*      */         
/* 3162 */         if (certificate != null)
/*      */         {
/* 3164 */           String uri = null;
/*      */           try {
/* 3166 */             uri = URLDecoder.decode(certificate.getAttributes().getNamedItem(this.tipoUri).getNodeValue(), "UTF-8");
/*      */           }
/*      */           catch (UnsupportedEncodingException e) {
/* 3169 */             LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error30"));
/* 3170 */             this.esValido = false;
/*      */             
/* 3172 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error31"));
/*      */             
/* 3174 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error31"));
/*      */           }
/*      */           catch (Exception e)
/*      */           {
/* 3178 */             LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error65"));
/* 3179 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error65"));
/*      */           }
/* 3181 */           if (uri != null) {
/* 3182 */             certURI.add(uri);
/*      */           }
/*      */           
/*      */ 
/* 3186 */           Element certDigest = (Element)certificate.getElementsByTagNameNS(esquemaURI, "CertDigest").item(0);
/*      */           
/* 3188 */           Node algorithm = certDigest.getElementsByTagNameNS(uriDS, "DigestMethod").item(0);
/* 3189 */           Node value = certDigest.getElementsByTagNameNS(uriDS, "DigestValue").item(0);
/*      */           
/* 3191 */           digestAlg.add(algorithm.getAttributes().getNamedItem("Algorithm").getNodeValue());
/* 3192 */           digestValue.add(value.getFirstChild().getNodeValue());
/*      */           
/* 3194 */           Element issuer = (Element)certificate.getElementsByTagNameNS(esquemaURI, "IssuerSerial").item(0);
/* 3195 */           Node name = issuer.getElementsByTagNameNS(uriDS, "X509IssuerName").item(0);
/* 3196 */           Node serial = issuer.getElementsByTagNameNS(uriDS, "X509SerialNumber").item(0);
/*      */           
/* 3198 */           String issuerRef = name.getFirstChild().getNodeValue();
/* 3199 */           if (issuerRef == null)
/*      */           {
/* 3201 */             LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error169"));
/* 3202 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error169"));
/* 3203 */             this.esValido = false;
/*      */             
/* 3205 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error36"));
/*      */           } else {
/*      */             try {
/* 3208 */               issuerName.add(new X500Principal(issuerRef));
/*      */             }
/*      */             catch (IllegalArgumentException e) {
/* 3211 */               LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error169"));
/* 3212 */               logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error169"));
/* 3213 */               this.esValido = false;
/*      */               
/* 3215 */               this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error29"));
/*      */             }
/*      */           }
/* 3218 */           issuerSerial.add(serial.getFirstChild().getNodeValue());
/*      */         }
/* 3157 */         i++; if (i >= l) break; } while (this.esValido);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3222 */       this.esValido = false;
/* 3223 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error95") + 
/* 3224 */         " " + "CertRefs");
/* 3225 */       logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error95") + 
/* 3226 */         " " + "CertRefs");
/* 3227 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 3231 */     Node ocspRefs = ((Element)completeRevocationRefs.get(0))
/* 3232 */       .getElementsByTagNameNS(esquemaURI, "OCSPRefs").item(0);
/*      */     
/*      */ 
/* 3235 */     if ((ocspRefs != null) && (this.esValido))
/*      */     {
/*      */ 
/* 3238 */       ArrayList<Element> refs = UtilidadTratarNodo.getElementChildNodes((Element)ocspRefs, false);
/* 3239 */       if (refs == null) {
/* 3240 */         this.esValido = false;
/* 3241 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error95 OCSPRefs"));
/*      */         
/* 3243 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error95 OCSPRefs"));
/*      */         
/* 3245 */         return false;
/*      */       }
/* 3247 */       int l = refs.size();
/*      */       
/* 3249 */       ocspURI = new ArrayList(l);
/* 3250 */       identifierOCSP = new ArrayList(l);
/* 3251 */       OCSPResponderID responderData = null;
/* 3252 */       identifierTime = new ArrayList(l);
/* 3253 */       ocspDigestAlg = new ArrayList(l);
/* 3254 */       ocspDigestValue = new ArrayList(l);
/* 3255 */       String noURIOCSPidentifier = I18n.getResource("libreriaxades.validarfirmaxml.error32") + 
/* 3256 */         " " + I18n.getResource("libreriaxades.validarfirmaxml.error62");
/*      */       
/* 3258 */       for (int i = 0; (i < l) && (this.esValido); i++)
/*      */       {
/*      */ 
/* 3261 */         Element ocspRef = (Element)refs.get(i);
/*      */         
/* 3263 */         if (ocspRef != null)
/*      */         {
/* 3265 */           NodeList list = ocspRef.getElementsByTagNameNS(esquemaURI, "OCSPIdentifier");
/*      */           
/* 3267 */           if (list.getLength() != 0)
/*      */           {
/*      */             try {
/* 3270 */               ocspURI.add(URLDecoder.decode(((Element)list.item(0)).getAttributes().getNamedItem(this.tipoUri).getNodeValue(), "UTF-8"));
/*      */             }
/*      */             catch (UnsupportedEncodingException e) {
/* 3273 */               LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error30"));
/* 3274 */               this.esValido = false;
/*      */               
/* 3276 */               this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error32"));
/*      */               
/* 3278 */               LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error32"));
/*      */             }
/*      */             catch (NullPointerException e)
/*      */             {
/* 3282 */               LOGGER.warn(I18n.getResource("libreriaxades.validarfirmaxml.error160"));
/*      */             }
/*      */             catch (Exception e) {
/* 3285 */               LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error30"));
/* 3286 */               this.esValido = false;
/* 3287 */               this.resultado.setLog(noURIOCSPidentifier);
/*      */               
/* 3289 */               logv.error(noURIOCSPidentifier);
/*      */             }
/*      */             
/*      */ 
/*      */             try
/*      */             {
/* 3295 */               Element certDigest = (Element)ocspRef.getElementsByTagNameNS(esquemaURI, "OCSPIdentifier").item(0);
/* 3296 */               Node responder = certDigest.getElementsByTagNameNS(esquemaURI, "ResponderID").item(0);
/* 3297 */               Node time = certDigest.getElementsByTagNameNS(esquemaURI, "ProducedAt").item(0);
/*      */               
/* 3299 */               responderData = null;
/* 3300 */               if (("http://uri.etsi.org/01903/v1.1.1#".equals(esquemaURI)) || ("http://uri.etsi.org/01903/v1.2.2#".equals(esquemaURI))) {
/* 3301 */                 X500Principal prin = new X500Principal(responder.getFirstChild().getNodeValue());
/* 3302 */                 responderData = OCSPResponderID.getOCSPResponderID(prin);
/*      */               }
/*      */               else {
/* 3305 */                 Node responderBy = responder.getFirstChild();
/* 3306 */                 if ("ByName".equals(responderBy.getLocalName())) {
/*      */                   try {
/* 3308 */                     X500Principal prin = new X500Principal(responderBy.getFirstChild().getNodeValue());
/* 3309 */                     responderData = OCSPResponderID.getOCSPResponderID(prin);
/*      */                   } catch (IllegalArgumentException ex) {
/* 3311 */                     this.esValido = false;
/*      */                     
/* 3313 */                     LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error23"), ex);
/*      */                     
/* 3315 */                     this.resultado.setLog(I18n.getResource("libreriaxades.firmaxml.error27"));
/*      */                     
/* 3317 */                     logv.error(I18n.getResource("libreriaxades.firmaxml.error27"));
/*      */                     
/* 3319 */                     return false;
/*      */                   } catch (NullPointerException ex) {
/* 3321 */                     this.esValido = false;
/*      */                     
/* 3323 */                     this.resultado.setLog(I18n.getResource("libreriaxades.firmaxml.error27"));
/*      */                     
/* 3325 */                     logv.error(I18n.getResource("libreriaxades.firmaxml.error27"));
/*      */                     
/*      */ 
/* 3328 */                     LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error23"), ex);
/* 3329 */                     return false;
/*      */                   }
/* 3331 */                 } else if ("ByKey".equals(responderBy.getLocalName())) {
/* 3332 */                   String hash = responderBy.getFirstChild().getNodeValue();
/*      */                   try {
/* 3334 */                     responderData = OCSPResponderID.getOCSPResponderID(es.mityc.javasign.utils.Base64Coder.decode(hash));
/*      */                   } catch (IllegalArgumentException ex) {
/* 3336 */                     LOGGER.error(i18n.getLocalMessage("i18n.mityc.xades.validate.5", new Object[] { hash }));
/*      */                   }
/*      */                 }
/*      */                 
/* 3340 */                 if (responderData == null) {
/* 3341 */                   this.esValido = false;
/*      */                   
/* 3343 */                   this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error101"));
/* 3344 */                   LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error101"));
/*      */                   
/* 3346 */                   logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error101"));
/*      */                   
/* 3348 */                   return false;
/*      */                 }
/*      */               }
/*      */               
/* 3352 */               identifierOCSP.add(responderData);
/*      */               
/* 3354 */               Date fecha = UtilidadFechas.parseaFechaXML(time.getFirstChild().getNodeValue());
/* 3355 */               if (fecha != null) {
/* 3356 */                 identifierTime.add(fecha);
/*      */               } else {
/* 3358 */                 this.esValido = false;
/*      */                 
/* 3360 */                 LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.error63"));
/*      */                 
/* 3362 */                 logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error63"));
/* 3363 */                 logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error40"));
/*      */                 
/*      */ 
/* 3366 */                 this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error40"));
/*      */               }
/*      */               
/*      */ 
/* 3370 */               Element ocspDigest = (Element)ocspRef.getElementsByTagNameNS(esquemaURI, "DigestAlgAndValue").item(0);
/* 3371 */               Node algorithm = ocspDigest.getElementsByTagNameNS(uriDS, "DigestMethod").item(0);
/* 3372 */               Node value = ocspDigest.getElementsByTagNameNS(uriDS, "DigestValue").item(0);
/*      */               
/* 3374 */               ocspDigestAlg.add(algorithm.getAttributes().getNamedItem("Algorithm").getNodeValue());
/* 3375 */               ocspDigestValue.add(value.getFirstChild().getNodeValue());
/*      */             }
/*      */             catch (Exception ex) {
/* 3378 */               LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error66"));
/*      */               
/* 3380 */               logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error66"));
/*      */               
/* 3382 */               this.esValido = false;
/* 3383 */               this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error66"));
/*      */             }
/*      */           }
/*      */           
/*      */ 
/* 3388 */           LOGGER.debug(I18n.getResource("libreriaxades.validarfirmaxml.error72"));
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3395 */     Node crlRefs = null;
/* 3396 */     NodeList crlRefsList = ((Element)completeRevocationRefs.get(0))
/* 3397 */       .getElementsByTagNameNS(esquemaURI, "CRLRefs");
/* 3398 */     if (crlRefsList != null) {
/* 3399 */       crlRefs = crlRefsList.item(0);
/*      */     }
/*      */     
/*      */ 
/* 3403 */     if ((crlRefs != null) && (this.esValido))
/*      */     {
/*      */ 
/* 3406 */       ArrayList<Element> crls = UtilidadTratarNodo.getElementChildNodes((Element)crlRefs, false);
/* 3407 */       if (crls == null) {
/* 3408 */         this.esValido = false;
/* 3409 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error95 CRLRefs"));
/*      */         
/* 3411 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error95 CRLRefs"));
/*      */         
/* 3413 */         return false;
/*      */       }
/* 3415 */       int l = crls.size();
/*      */       
/* 3417 */       crlURI = new ArrayList(l);
/* 3418 */       crlDigestAlg = new ArrayList(l);
/* 3419 */       crlDigestValue = new ArrayList(l);
/* 3420 */       crlIssuer = new ArrayList(l);
/* 3421 */       crlIssuerTime = new ArrayList(l);
/* 3422 */       crlNumber = new ArrayList(l);
/*      */       
/* 3424 */       for (int i = 0; i < l; i++)
/*      */       {
/*      */ 
/* 3427 */         Element crl = (Element)crls.get(i);
/*      */         
/*      */ 
/* 3430 */         if (crl != null) {
/* 3431 */           Element crlDigest = (Element)crl.getElementsByTagNameNS(esquemaURI, "DigestAlgAndValue").item(0);
/*      */           
/* 3433 */           Node algorithm = crlDigest.getElementsByTagNameNS(uriDS, "DigestMethod").item(0);
/* 3434 */           Node value = crlDigest.getElementsByTagNameNS(uriDS, "DigestValue").item(0);
/*      */           
/* 3436 */           crlDigestAlg.add(algorithm.getAttributes().getNamedItem("Algorithm").getNodeValue());
/* 3437 */           crlDigestValue.add(value.getFirstChild().getNodeValue());
/*      */           
/* 3439 */           Element identifier = (Element)crl.getElementsByTagNameNS(esquemaURI, "CRLIdentifier").item(0);
/*      */           try {
/* 3441 */             crlURI.add(URLDecoder.decode(identifier.getAttributes().getNamedItem(this.tipoUri).getNodeValue(), "UTF-8"));
/*      */           }
/*      */           catch (UnsupportedEncodingException e) {
/* 3444 */             LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error30"), e);
/* 3445 */             this.esValido = false;
/*      */             
/* 3447 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error33"));
/*      */             
/* 3449 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error33"));
/*      */           }
/*      */           catch (NullPointerException e)
/*      */           {
/* 3453 */             LOGGER.warn(I18n.getResource("libreriaxades.validarfirmaxml.error161"));
/*      */           }
/*      */           catch (Exception e) {
/* 3456 */             LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error30"), e);
/* 3457 */             this.esValido = false;
/*      */             
/* 3459 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error33"));
/*      */             
/* 3461 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error33"));
/*      */           }
/*      */           
/*      */           try
/*      */           {
/* 3466 */             Node issuer = identifier.getElementsByTagNameNS(esquemaURI, "Issuer").item(0);
/* 3467 */             Node issuerTime = identifier.getElementsByTagNameNS(esquemaURI, "IssueTime").item(0);
/* 3468 */             Node number = identifier.getElementsByTagNameNS(esquemaURI, "Number").item(0);
/*      */             
/* 3470 */             String crlIssuerName = issuer.getFirstChild().getNodeValue();
/*      */             try {
/* 3472 */               X500Principal prin = new X500Principal(crlIssuerName);
/* 3473 */               crlIssuer.add(prin.getName());
/*      */             } catch (IllegalArgumentException ex) {
/* 3475 */               this.esValido = false;
/*      */               
/* 3477 */               this.resultado.setLog(I18n.getResource("libreriaxades.firmaxml.error44"));
/*      */               
/* 3479 */               LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error23"), ex);
/*      */               
/* 3481 */               logv.error(I18n.getResource("libreriaxades.firmaxml.error44"));
/*      */               
/* 3483 */               return false;
/*      */             } catch (NullPointerException ex) {
/* 3485 */               this.esValido = false;
/*      */               
/* 3487 */               this.resultado.setLog(I18n.getResource("libreriaxades.firmaxml.error44"));
/*      */               
/* 3489 */               LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error23"), ex);
/*      */               
/* 3491 */               logv.error(I18n.getResource("libreriaxades.firmaxml.error44"));
/*      */               
/* 3493 */               return false;
/*      */             }
/* 3495 */             Date fecha = UtilidadFechas.parseaFechaXML(issuerTime.getFirstChild().getNodeValue());
/* 3496 */             if (fecha != null) {
/* 3497 */               crlIssuerTime.add(fecha);
/*      */             }
/*      */             else {
/* 3500 */               LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error63"));
/* 3501 */               this.esValido = false;
/*      */               
/* 3503 */               this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error40"));
/*      */               
/* 3505 */               logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error63"));
/* 3506 */               logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error40"));
/*      */             }
/*      */             
/*      */ 
/* 3510 */             if (number != null) {
/* 3511 */               crlNumber.add(new BigInteger(number.getFirstChild().getNodeValue()));
/*      */             } else {
/* 3513 */               crlNumber.add(null);
/*      */             }
/*      */           }
/*      */           catch (Exception ex) {
/* 3517 */             LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error66"), ex);
/* 3518 */             this.esValido = false;
/* 3519 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error66"));
/*      */             
/* 3521 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error66"));
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 3528 */     ArrayList<Element> certificateValues = new ArrayList();
/* 3529 */     ArrayList<Element> revocationValues = new ArrayList();
/*      */     try
/*      */     {
/* 3532 */       certificateValues = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 3533 */         new NombreNodo(esquemaURI, "CertificateValues"));
/* 3534 */       revocationValues = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 3535 */         new NombreNodo(esquemaURI, "RevocationValues"));
/*      */     } catch (FirmaXMLError e) {
/* 3537 */       LOGGER.debug(e.getMessage(), e);
/*      */     }
/*      */     
/*      */ 
/* 3541 */     boolean certsYOcspInterno = false;
/* 3542 */     if ((certificateValues.size() != 0) && (revocationValues.size() != 0)) {
/* 3543 */       certsYOcspInterno = true;
/*      */     }
/*      */     
/*      */ 
/* 3547 */     if ((ocspDigestValue != null) && (ocspDigestValue.size() != 0) && (this.esValido)) {
/* 3548 */       int ocspNum = ocspDigestValue.size();
/* 3549 */       OCSPResponderID responderData = null;
/* 3550 */       byte[] respuesta = null;
/* 3551 */       respuestasOCSP = new ArrayList(ocspNum);
/* 3552 */       for (int x = 0; (x < ocspNum) && (this.esValido); x++) {
/* 3553 */         if (certsYOcspInterno) {
/* 3554 */           Element ocsp = null;
/* 3555 */           if ((ocspURI != null) && (ocspURI.size() == ocspNum)) {
/* 3556 */             String uri = (String)ocspURI.get(x);
/* 3557 */             if (uri.startsWith("#"))
/* 3558 */               ocsp = UtilidadTratarNodo.getElementById(firma.getElementsByTagNameNS(esquemaURI, "EncapsulatedOCSPValue"), uri.substring(1));
/*      */           }
/* 3560 */           if (ocsp == null) {
/* 3561 */             ocsp = buscarRevocationValueOCSP((String)ocspDigestValue.get(x), (String)ocspDigestAlg.get(x), estructuraFirma);
/* 3562 */             if (ocsp == null)
/*      */             {
/* 3564 */               LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.error95") + 
/* 3565 */                 " " + "RevocationValues");
/* 3566 */               this.esValido = false;
/*      */               
/* 3568 */               this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error34"));
/*      */               
/* 3570 */               logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error95") + 
/* 3571 */                 " " + "RevocationValues");
/*      */               
/* 3573 */               return this.esValido;
/*      */             }
/* 3575 */             respuesta = Base64.decode(ocsp.getFirstChild().getNodeValue());
/*      */           } else {
/* 3577 */             respuesta = Base64.decode(ocsp.getFirstChild().getNodeValue());
/*      */           }
/*      */           
/*      */         }
/* 3581 */         else if (this.recoverManager != null) {
/* 3582 */           Map<String, Object> props = new HashMap();
/* 3583 */           if ((ocspURI != null) && (ocspURI.size() == ocspNum) && (ocspURI.get(x) != null)) {
/* 3584 */             props.put("uri", ocspURI.get(x));
/*      */           } else {
/* 3586 */             props.put("emission.date", identifierTime.get(x));
/* 3587 */             props.put("digest.algorithm", ocspDigestAlg.get(x));
/* 3588 */             props.put("digest.value", Base64.decode((String)ocspDigestValue.get(x)));
/* 3589 */             OCSPResponderID ocspData = (OCSPResponderID)identifierOCSP.get(x);
/* 3590 */             IOCSPCertStatus.TYPE_RESPONDER typeResponder = ocspData.getTypeResponderID();
/* 3591 */             if (typeResponder != null) {
/* 3592 */               switch (typeResponder) {
/*      */               case BY_KEY: 
/* 3594 */                 props.put("issuer.name", (X500Principal)ocspData.getIdentifierData());
/* 3595 */                 break;
/*      */               case BY_NAME: 
/* 3597 */                 props.put("issuer.hash", (byte[])ocspData.getIdentifierData());
/*      */               }
/*      */               
/*      */             } else {
/*      */               try
/*      */               {
/* 3603 */                 props.put("issuer.name", new X500Principal((String)ocspData.getIdentifierData()));
/*      */               } catch (IllegalArgumentException ex) {
/*      */                 try {
/* 3606 */                   props.put("issuer.hash", Base64.decode((String)ocspData.getIdentifierData()));
/*      */                 } catch (IllegalArgumentException ex1) {
/* 3608 */                   LOGGER.warn(i18n.getLocalMessage("i18n.mityc.xades.validate.6"));
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */           
/* 3614 */           IOCSPCertStatus ocsp = null;
/*      */           try {
/* 3616 */             ocsp = (IOCSPCertStatus)this.recoverManager.getElement(props, IOCSPCertStatus.class);
/*      */           } catch (ElementNotFoundException ex) {
/* 3618 */             LOGGER.warn(i18n.getLocalMessage("i18n.mityc.xades.validate.2"), ex);
/* 3619 */             if (LOGGER.isTraceEnabled()) {
/* 3620 */               LOGGER.trace(props);
/*      */             }
/*      */           } catch (UnknownElementClassException ex) {
/* 3623 */             LOGGER.error(i18n.getLocalMessage("i18n.mityc.xades.validate.3", new Object[] { "IOCSP" }), ex);
/*      */           }
/* 3625 */           if (ocsp == null)
/*      */           {
/* 3627 */             LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error34"));
/*      */             
/* 3629 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error34"));
/*      */             
/* 3631 */             this.esValido = false;
/*      */             
/* 3633 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error36"));
/*      */           } else {
/* 3635 */             respuesta = ocsp.getEncoded();
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 3642 */         String digestOCSPResponse = null;
/* 3643 */         if (this.esValido) {
/* 3644 */           MessageDigest resumenCertificadoTemp = UtilidadFirmaElectronica.getMessageDigest((String)ocspDigestAlg.get(x));
/* 3645 */           byte[] resumenMensajeByte = resumenCertificadoTemp.digest(respuesta);
/* 3646 */           digestOCSPResponse = new String(es.mityc.firmaJava.libreria.utilidades.Base64Coder.encode(resumenMensajeByte));
/*      */           
/* 3648 */           if (!((String)ocspDigestValue.get(x)).equals(digestOCSPResponse)) {
/* 3649 */             this.esValido = false;
/*      */             
/* 3651 */             LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.error38"));
/*      */             
/* 3653 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error38"));
/*      */             
/* 3655 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error38"));
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 3660 */         OCSPResp resp = null;
/* 3661 */         if (this.esValido) {
/*      */           try {
/* 3663 */             resp = new OCSPResp(respuesta);
/*      */           }
/*      */           catch (IOException e) {
/* 3666 */             LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error150"), e);
/* 3667 */             this.esValido = false;
/*      */             
/* 3669 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error18"));
/*      */             
/* 3671 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error18"));
/*      */           }
/*      */           
/* 3674 */           BasicOCSPResp respuestaBasica = null;
/* 3675 */           OCSPResponderID respuestaOCSP = null;
/* 3676 */           Date tiempoRespuesta = null;
/*      */           try {
/*      */             try {
/* 3679 */               respuestaBasica = (BasicOCSPResp)resp.getResponseObject();
/*      */             } catch (ClassCastException e) {
/*      */               continue;
/*      */             }
/* 3683 */             tiempoRespuesta = respuestaBasica.getProducedAt();
/*      */             
/* 3685 */             ResponderID respID = respuestaBasica.getResponderId().toASN1Object();
/* 3686 */             respuestaOCSP = ASN1Utils.getResponderID(respID);
/*      */           }
/*      */           catch (OCSPException e) {
/* 3689 */             LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error150"), e);
/* 3690 */             this.esValido = false;
/*      */             
/* 3692 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error18"));
/*      */             
/* 3694 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error18"));
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 3699 */           responderData = (OCSPResponderID)identifierOCSP.get(x);
/*      */           try {
/* 3701 */             X500Principal prin1 = null;
/* 3702 */             byte[] bprin1 = null;
/* 3703 */             if ((responderData.getIdentifierData() instanceof String)) {
/* 3704 */               prin1 = new X500Principal((String)responderData.getIdentifierData());
/* 3705 */             } else if ((responderData.getIdentifierData() instanceof X500Principal)) {
/* 3706 */               prin1 = (X500Principal)responderData.getIdentifierData();
/*      */             } else {
/* 3708 */               bprin1 = (byte[])responderData.getIdentifierData();
/*      */             }
/*      */             
/* 3711 */             if (prin1 != null) {
/* 3712 */               X500Principal prin2 = (X500Principal)respuestaOCSP.getIdentifierData();
/* 3713 */               if (!prin2.equals(prin1)) {
/* 3714 */                 this.esValido = false;
/*      */                 
/* 3716 */                 this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error39"));
/* 3717 */                 LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.error39"));
/*      */                 
/* 3719 */                 logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error39"));
/*      */               }
/*      */             } else {
/* 3722 */               byte[] bprin2 = (byte[])respuestaOCSP.getIdentifierData();
/* 3723 */               if (!Arrays.equals(bprin2, bprin1)) {
/* 3724 */                 this.esValido = false;
/*      */                 
/* 3726 */                 this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error39"));
/* 3727 */                 LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.error39"));
/*      */                 
/* 3729 */                 logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error39"));
/*      */               }
/*      */             }
/*      */           } catch (IllegalArgumentException e) {
/* 3733 */             LOGGER.error("OCSP-ResponderID problem: " + e.getMessage());
/* 3734 */             if (!responderData.equals(respuestaOCSP)) {
/* 3735 */               this.esValido = false;
/*      */               
/* 3737 */               this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error39"));
/* 3738 */               LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.error39"));
/*      */               
/* 3740 */               logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error39"));
/*      */             }
/*      */           }
/*      */           
/*      */ 
/* 3745 */           if (!((Date)identifierTime.get(x)).equals(tiempoRespuesta)) {
/* 3746 */             this.esValido = false;
/*      */             
/* 3748 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error40"));
/* 3749 */             LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.error40"));
/*      */             
/* 3751 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error40"));
/*      */           }
/*      */           
/*      */ 
/* 3755 */           if (this.esValido) {
/* 3756 */             respuestasOCSP.add(resp);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3762 */     if ((crlDigestValue != null) && (crlDigestValue.size() != 0) && (this.esValido)) {
/* 3763 */       int crlNum = crlDigestValue.size();
/* 3764 */       X509CRL x509CRL = null;
/* 3765 */       crlList = new ArrayList(crlNum);
/* 3766 */       for (int x = 0; (x < crlNum) && (this.esValido); x++) {
/* 3767 */         if (certsYOcspInterno) {
/* 3768 */           byte[] crl = null;
/* 3769 */           Element crlValue = null;
/* 3770 */           if ((crlURI != null) && (crlURI.size() == crlNum)) {
/* 3771 */             String uri = (String)crlURI.get(x);
/* 3772 */             if (uri.startsWith("#"))
/* 3773 */               crlValue = UtilidadTratarNodo.getElementById(firma.getElementsByTagNameNS(esquemaURI, "EncapsulatedCRLValue"), uri.substring(1));
/*      */           }
/* 3775 */           if (crlValue == null) {
/* 3776 */             crlValue = buscarRevocationValueCRL((String)crlDigestValue.get(x), (String)crlDigestAlg.get(x), estructuraFirma);
/* 3777 */             if (crlValue == null)
/*      */             {
/* 3779 */               LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error151"));
/* 3780 */               this.esValido = false;
/*      */               
/* 3782 */               this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error41"));
/*      */               
/* 3784 */               logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error41"));
/*      */               
/* 3786 */               return this.esValido;
/*      */             }
/* 3788 */             crl = Base64.decode(crlValue.getFirstChild().getNodeValue());
/*      */           }
/*      */           else {
/* 3791 */             crl = Base64.decode(crlValue.getFirstChild().getNodeValue());
/*      */           }
/*      */           
/* 3794 */           if (crl != null)
/*      */           {
/*      */             try {
/* 3797 */               ByteArrayInputStream bais = new ByteArrayInputStream(crl);
/* 3798 */               CertificateFactory certificatefactory = CertificateFactory.getInstance("X.509");
/* 3799 */               x509CRL = (X509CRL)certificatefactory.generateCRL(bais);
/*      */             }
/*      */             catch (CertificateException e) {
/* 3802 */               LOGGER.error(I18n.getResource("libreriaxades.firmaxml.error23"), e);
/* 3803 */               this.esValido = false;
/*      */               
/* 3805 */               this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error154"));
/*      */               
/* 3807 */               logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error154"));
/*      */             }
/*      */             catch (CRLException e)
/*      */             {
/* 3811 */               LOGGER.error(I18n.getResource("libreriaxades.firmaxml.error44"), e);
/* 3812 */               this.esValido = false;
/*      */               
/* 3814 */               this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error154"));
/*      */               
/* 3816 */               logv.error(I18n.getResource("libreriaxades.firmaxml.error44"));
/*      */             }
/*      */           }
/*      */           else
/*      */           {
/* 3821 */             LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error151"));
/* 3822 */             this.esValido = false;
/*      */             
/* 3824 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error41"));
/*      */             
/* 3826 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error41"));
/*      */           }
/*      */           
/*      */ 
/*      */         }
/* 3831 */         else if (this.recoverManager != null) {
/* 3832 */           Map<String, Object> props = new HashMap();
/* 3833 */           if ((crlURI != null) && (crlURI.size() == crlNum) && (crlURI.get(x) != null)) {
/* 3834 */             props.put("uri", crlURI.get(x));
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 3839 */           X509CRL x509crl = null;
/*      */           try {
/* 3841 */             x509crl = (X509CRL)this.recoverManager.getElement(props, X509CRL.class);
/*      */           } catch (ElementNotFoundException ex) {
/* 3843 */             LOGGER.warn(i18n.getLocalMessage("i18n.mityc.xades.validate.2"));
/* 3844 */             if (LOGGER.isTraceEnabled()) {
/* 3845 */               LOGGER.trace(props);
/*      */             }
/*      */           } catch (UnknownElementClassException ex) {
/* 3848 */             LOGGER.error(i18n.getLocalMessage("i18n.mityc.xades.validate.3", new Object[] { "X509CRL" }), ex);
/*      */           }
/* 3850 */           if (x509crl == null)
/*      */           {
/* 3852 */             LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error152"));
/* 3853 */             this.esValido = false;
/*      */             
/* 3855 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error42"));
/*      */             
/* 3857 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error152"));
/*      */           } else {
/* 3859 */             x509CRL = x509crl;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 3866 */         String digestCRLResponse = null;
/* 3867 */         if (this.esValido) {
/* 3868 */           MessageDigest resumenCRLTemp = UtilidadFirmaElectronica.getMessageDigest((String)crlDigestAlg.get(x));
/*      */           try {
/* 3870 */             byte[] resumenMensajeByte = resumenCRLTemp.digest(x509CRL.getEncoded());
/* 3871 */             digestCRLResponse = new String(es.mityc.firmaJava.libreria.utilidades.Base64Coder.encode(resumenMensajeByte));
/* 3872 */             if (!((String)crlDigestValue.get(x)).equals(digestCRLResponse)) {
/* 3873 */               this.esValido = false;
/*      */               
/* 3875 */               LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.error43"));
/* 3876 */               this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error43"));
/*      */               
/* 3878 */               logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error43"));
/*      */             }
/*      */           }
/*      */           catch (CRLException ex) {
/* 3882 */             this.esValido = false;
/*      */             
/* 3884 */             LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.error43"));
/* 3885 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error43"));
/*      */             
/* 3887 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error43"));
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 3892 */         if ((this.esValido) && 
/* 3893 */           (x509CRL != null))
/*      */         {
/* 3895 */           X509Principal prin1 = new X509Principal((String)crlIssuer.get(x));
/* 3896 */           X509Principal prin2 = new X509Principal(x509CRL.getIssuerX500Principal().getName());
/* 3897 */           if (!prin1.equals(prin2)) {
/* 3898 */             this.esValido = false;
/*      */             
/* 3900 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error45"));
/* 3901 */             LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.error45"));
/*      */             
/* 3903 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error45"));
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 3908 */           Date time = x509CRL.getThisUpdate();
/*      */           
/* 3910 */           if (!((Date)crlIssuerTime.get(x)).equals(time)) {
/* 3911 */             this.esValido = false;
/*      */             
/* 3913 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error46"));
/* 3914 */             LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.error46"));
/*      */             
/* 3916 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error46"));
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 3921 */           BigInteger numeroNodo = (BigInteger)crlNumber.get(x);
/*      */           
/*      */ 
/* 3924 */           if (numeroNodo != null) {
/* 3925 */             BigInteger numeroRecuperado = null;
/* 3926 */             DERInteger derInt = null;
/*      */             
/* 3928 */             ASN1InputStream ais = new ASN1InputStream(x509CRL.getExtensionValue("2.5.29.20"));
/*      */             try {
/* 3930 */               ais = new ASN1InputStream(((DEROctetString)ais.readObject()).getOctets());
/* 3931 */               derInt = (DERInteger)ais.readObject();
/*      */             } catch (IOException e) {
/* 3933 */               this.esValido = false;
/*      */               
/* 3935 */               LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error47"), e);
/* 3936 */               this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error47"));
/*      */               
/* 3938 */               logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error47"));
/*      */             }
/*      */             
/* 3941 */             numeroRecuperado = derInt.getValue();
/*      */             
/* 3943 */             if (!numeroNodo.equals(numeroRecuperado)) {
/* 3944 */               this.esValido = false;
/*      */               
/* 3946 */               this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error48"));
/* 3947 */               LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.error48"));
/*      */               
/* 3949 */               logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error48"));
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 3956 */         if (this.esValido) {
/* 3957 */           crlList.add(x509CRL);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3962 */     int numCert = digestValue.size();
/* 3963 */     ArrayList<X509Certificate> certsDeURI = new ArrayList();
/* 3964 */     X509Certificate certificado = null;
/* 3965 */     for (int x = 0; (x < numCert) && (this.esValido); x++) {
/* 3966 */       if (certsYOcspInterno)
/*      */       {
/* 3968 */         Element certValue = null;
/* 3969 */         if ((certURI != null) && (certURI.size() == numCert)) {
/* 3970 */           String uri = (String)certURI.get(x);
/* 3971 */           if (uri.startsWith("#"))
/* 3972 */             certValue = UtilidadTratarNodo.getElementById(firma.getElementsByTagNameNS(esquemaURI, "EncapsulatedX509Certificate"), ((String)certURI.get(x)).substring(1));
/*      */         }
/* 3974 */         if (certValue == null) {
/* 3975 */           certificado = buscarCertificateValue((X500Principal)issuerName.get(x), new BigInteger((String)issuerSerial.get(x)), estructuraFirma);
/* 3976 */           if (certificado == null)
/*      */           {
/* 3978 */             LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error155"));
/* 3979 */             this.esValido = false;
/*      */             
/* 3981 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error49"));
/*      */             
/* 3983 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error155"));
/*      */             
/* 3985 */             return this.esValido;
/*      */           }
/*      */         }
/*      */         else {
/*      */           try {
/* 3990 */             ByteArrayInputStream bais = new ByteArrayInputStream(Base64.decode(certValue.getFirstChild().getNodeValue()));
/* 3991 */             CertificateFactory cf = CertificateFactory.getInstance("X.509");
/* 3992 */             certificado = (X509Certificate)cf.generateCertificate(bais);
/*      */           }
/*      */           catch (CertificateException e1) {
/* 3995 */             LOGGER.error(I18n.getResource("libreriaxades.firmaxml.error23"), e1);
/* 3996 */             this.esValido = false;
/*      */             
/* 3998 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error156"));
/*      */             
/* 4000 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error156"));
/*      */           }
/*      */           
/*      */         }
/*      */         
/*      */ 
/*      */       }
/* 4007 */       else if (this.recoverManager != null) {
/* 4008 */         Map<String, Object> props = new HashMap();
/* 4009 */         if ((certURI != null) && (certURI.size() == numCert) && (certURI.get(x) != null)) {
/* 4010 */           props.put("uri", certURI.get(x));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 4015 */         X509Certificate x509cert = null;
/*      */         try {
/* 4017 */           x509cert = (X509Certificate)this.recoverManager.getElement(props, X509Certificate.class);
/*      */         } catch (ElementNotFoundException ex) {
/* 4019 */           LOGGER.warn(i18n.getLocalMessage("i18n.mityc.xades.validate.2"));
/* 4020 */           if (LOGGER.isTraceEnabled()) {
/* 4021 */             LOGGER.trace(props);
/*      */           }
/*      */         } catch (UnknownElementClassException ex) {
/* 4024 */           LOGGER.error(i18n.getLocalMessage("i18n.mityc.xades.validate.3", new Object[] { "X509Certificate" }), ex);
/*      */         }
/* 4026 */         if (x509cert == null)
/*      */         {
/* 4028 */           LOGGER.error(i18n.getLocalMessage("i18n.mityc.xades.validate.4", new Object[] { certURI, Integer.valueOf(x) }));
/* 4029 */           this.esValido = false;
/*      */           
/* 4031 */           this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error50"));
/*      */           
/* 4033 */           logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error50"));
/*      */         } else {
/* 4035 */           certificado = x509cert;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 4041 */       String resumenCertificado = "";
/*      */       try
/*      */       {
/* 4044 */         MessageDigest resumenCertificadoTemp = UtilidadFirmaElectronica.getMessageDigest((String)digestAlg.get(x));
/* 4045 */         if (resumenCertificadoTemp == null) {
/* 4046 */           this.esValido = false;
/*      */           
/* 4048 */           this.resultado.setLog(I18n.getResource("libreriaxades.firmaxml.error16") + 
/* 4049 */             ": " + (String)digestAlg.get(x));
/*      */           
/* 4051 */           LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error52"));
/*      */           
/* 4053 */           logv.error(I18n.getResource("libreriaxades.firmaxml.error16") + 
/* 4054 */             ": " + (String)digestAlg.get(x));
/*      */           
/* 4056 */           return false;
/*      */         }
/* 4058 */         byte[] resumenMensajeByte = resumenCertificadoTemp.digest(certificado.getEncoded());
/* 4059 */         resumenCertificado = new String(es.mityc.firmaJava.libreria.utilidades.Base64Coder.encode(resumenMensajeByte));
/*      */       }
/*      */       catch (CertificateEncodingException e) {
/* 4062 */         LOGGER.error(I18n.getResource("libreriaxades.firmaxml.error23") + 
/* 4063 */           ": " + e.getMessage(), e);
/* 4064 */         this.esValido = false;
/*      */         
/* 4066 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error52"));
/*      */         
/* 4068 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error52"));
/*      */       }
/*      */       
/*      */ 
/* 4072 */       if (!((String)digestValue.get(x)).equals(resumenCertificado)) {
/* 4073 */         this.esValido = false;
/*      */         
/* 4075 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error53"));
/* 4076 */         LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.error53"));
/*      */         
/* 4078 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error53"));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 4083 */       if (!((String)issuerSerial.get(x)).equals(certificado.getSerialNumber().toString())) {
/* 4084 */         this.esValido = false;
/*      */         
/* 4086 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error54"));
/* 4087 */         LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.error54"));
/*      */         
/* 4089 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error54"));
/*      */       }
/*      */       
/*      */ 
/* 4093 */       if (this.esValido) {
/* 4094 */         certsDeURI.add(certificado);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4100 */     X509Certificate signingCert = (X509Certificate)this.cadenaCertificados.get(0);
/* 4101 */     this.cadenaCertificados.addAll(certsDeURI);
/* 4102 */     ArrayList<ArrayList<X509Certificate>> certChains = UtilidadCertificados.filterCertPathsArrays(UtilidadCertificados.getCertPathsArray(this.cadenaCertificados), UtilidadCertificados.Filter.SIGN_SIGNER);
/* 4103 */     if (certChains.size() > 1)
/*      */     {
/* 4105 */       LOGGER.info(I18n.getResource("libreriaxades.validarfirmaxml.error84") + 
/* 4106 */         ": " + certChains.size());
/*      */       
/* 4108 */       logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error84") + 
/* 4109 */         ": " + certChains.size());
/*      */     }
/*      */     
/* 4112 */     ArrayList<X509Certificate> certificadoYaValidadoOCSP = new ArrayList();
/* 4113 */     for (int z = 0; z < certChains.size(); z++) {
/* 4114 */       this.cadenaCertificados = ((ArrayList)certChains.get(z));
/*      */       
/* 4116 */       Iterator<X509Certificate> certGenIter = this.cadenaCertificados.iterator();
/* 4117 */       ArrayList<X509Certificate> cadenaClon = new ArrayList(this.cadenaCertificados);
/*      */       
/* 4119 */       cadenaClon.remove(0);
/* 4120 */       certGenIter.next();
/*      */       
/* 4122 */       int certRefLenght = digestValue.size();
/*      */       
/* 4124 */       while (certGenIter.hasNext())
/*      */       {
/* 4126 */         X509Certificate certAValidar = (X509Certificate)certGenIter.next();
/*      */         
/* 4128 */         for (int i = 0; (i < certRefLenght) && (this.esValido); i++)
/*      */         {
/* 4130 */           X500Principal issuer = (X500Principal)issuerName.get(i);
/* 4131 */           BigInteger serial = new BigInteger((String)issuerSerial.get(i));
/* 4132 */           String alg = (String)digestAlg.get(i);
/* 4133 */           byte[] value = es.mityc.firmaJava.libreria.utilidades.Base64Coder.decode((String)digestValue.get(i));
/*      */           
/* 4135 */           if ((issuer.equals(certAValidar.getIssuerX500Principal())) && 
/* 4136 */             (serial.equals(certAValidar.getSerialNumber())))
/*      */           {
/* 4138 */             MessageDigest haseador = UtilidadFirmaElectronica.getMessageDigest(alg);
/* 4139 */             byte[] digestCert = null;
/*      */             try {
/* 4141 */               digestCert = haseador.digest(certAValidar.getEncoded());
/*      */             } catch (CertificateEncodingException e) {
/* 4143 */               this.esValido = false;
/*      */               
/* 4145 */               this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error52"));
/*      */               
/* 4147 */               LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error23") + 
/* 4148 */                 ": " + e.getMessage(), e);
/*      */               
/* 4150 */               logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error52"));
/*      */               
/* 4152 */               return false;
/*      */             }
/* 4154 */             if (Utilidades.isEqual(digestCert, value))
/*      */             {
/* 4156 */               cadenaClon.remove(certAValidar);
/* 4157 */               break;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 4163 */       if (cadenaClon.size() > 0) {
/* 4164 */         this.esValido = false;
/*      */         
/* 4166 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error67"));
/* 4167 */         LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error67"));
/*      */         
/* 4169 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error67"));
/*      */         
/* 4171 */         return false;
/*      */       }
/*      */       
/*      */ 
/* 4175 */       for (int b = 0; b < this.cadenaCertificados.size(); b++) {
/* 4176 */         if (((X509Certificate)this.cadenaCertificados.get(b)).equals(signingCert)) {
/* 4177 */           this.datosFirma.setCadenaFirma(UtilidadCertificados.convertCertPath(this.cadenaCertificados));
/* 4178 */           break;
/*      */         }
/*      */       }
/* 4181 */       if (this.esValido)
/*      */       {
/*      */ 
/* 4184 */         boolean tieneError = false;
/*      */         
/* 4186 */         int numCadenaCerts = this.cadenaCertificados.size();
/* 4187 */         for (int i = 0; i < numCadenaCerts; i++) {
/* 4188 */           X509Certificate certAValidar = (X509Certificate)this.cadenaCertificados.get(i);
/*      */           
/* 4190 */           if (!certificadoYaValidadoOCSP.contains(certAValidar)) {
/* 4191 */             X509Certificate certIssuer = null;
/* 4192 */             if (i < numCadenaCerts - 1) {
/* 4193 */               certIssuer = (X509Certificate)this.cadenaCertificados.get(i + 1);
/*      */             } else {
/* 4195 */               certIssuer = certAValidar;
/*      */             }
/* 4197 */             CertificateID certificadoId = null;
/*      */             try {
/* 4199 */               certificadoId = new CertificateID("1.3.14.3.2.26", certIssuer, certAValidar.getSerialNumber());
/*      */             }
/*      */             catch (OCSPException ex) {
/* 4202 */               LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error158") + 
/* 4203 */                 ": " + ex.getMessage(), ex);
/* 4204 */               this.esValido = false;
/*      */               
/* 4206 */               this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error56"));
/*      */               
/* 4208 */               if (i == 0) {
/* 4209 */                 logv.abreTag(false);
/* 4210 */                 logv.info("Certificate chain status:", 2);
/* 4211 */                 tieneError = true;
/*      */               }
/* 4213 */               logv.error(
/* 4214 */                 I18n.getResource("libreriaxades.validarfirmaxml.error158") + ": " + ex.getMessage(), 2);
/*      */               
/* 4216 */               break;
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 4222 */             int good = 0;
/* 4223 */             int revoked = 0;
/* 4224 */             DatosOCSP datosOCSP = null;
/* 4225 */             DatosCRL datosCRL = null;
/* 4226 */             BasicOCSPResp basicOcsp = null;
/*      */             
/* 4228 */             if (respuestasOCSP != null) {
/* 4229 */               Iterator<OCSPResp> itRespOCSP = respuestasOCSP.iterator();
/* 4230 */               boolean hasNext = itRespOCSP.hasNext();
/* 4231 */               while ((hasNext) && (this.esValido)) {
/* 4232 */                 OCSPResp respuestaOCSP = (OCSPResp)itRespOCSP.next();
/*      */                 try {
/* 4234 */                   basicOcsp = (BasicOCSPResp)respuestaOCSP.getResponseObject();
/*      */                 }
/*      */                 catch (OCSPException e) {
/* 4237 */                   LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error118"), e);
/*      */                   
/* 4239 */                   if (i == 0) {
/* 4240 */                     logv.abreTag(false);
/* 4241 */                     logv.info("Certificate chain status:", 2);
/* 4242 */                     tieneError = true;
/*      */                   }
/* 4244 */                   logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error118"), 2);
/*      */                   
/* 4246 */                   break;
/*      */                 }
/*      */                 
/* 4249 */                 hasNext = itRespOCSP.hasNext();
/* 4250 */                 SingleResp[] singleResps = basicOcsp.getResponses();
/* 4251 */                 int numSingleResps = singleResps.length;
/* 4252 */                 for (int j = 0; j < numSingleResps; j++) {
/* 4253 */                   if (certificadoId.equals(singleResps[j].getCertID())) {
/* 4254 */                     datosOCSP = new DatosOCSP();
/* 4255 */                     datosOCSP.setResponderId(basicOcsp.getResponderId().toASN1Object());
/* 4256 */                     datosOCSP.setCertConsultado(certAValidar.getSubjectX500Principal().toString());
/* 4257 */                     datosOCSP.setFechaConsulta(basicOcsp.getProducedAt());
/* 4258 */                     datosOCSP.setRespuestaOCSP(respuestaOCSP);
/*      */                     
/* 4260 */                     RespuestaOCSP res = null;
/*      */                     
/* 4262 */                     boolean isUnknown = false;
/*      */                     
/* 4264 */                     Object obj = singleResps[j].getCertStatus();
/* 4265 */                     if (obj == null) {
/* 4266 */                       good++;
/*      */                       
/* 4268 */                       if (i == 0) {
/* 4269 */                         logv.abreTag(true);
/* 4270 */                         logv.info("Certificate chain status:", 2);
/*      */                       }
/*      */                       
/* 4273 */                       if (i < identifierOCSP.size()) {
/* 4274 */                         logv.info("Certificate: " + certAValidar.getSubjectDN() + " is VALID (OCSP response: " + ((OCSPResponderID)identifierOCSP.get(i)).toString() + ")", 2);
/*      */                       }
/* 4276 */                     } else if ((obj instanceof RevokedStatus)) {
/* 4277 */                       revoked++;
/*      */                       
/* 4279 */                       if (i == 0) {
/* 4280 */                         logv.abreTag(false);
/* 4281 */                         logv.info("Certificate chain status:", 2);
/* 4282 */                         tieneError = true;
/*      */                       }
/* 4284 */                       logv.error("Certificate: " + certificadoId + " is REVOKED (OCSP response: " + basicOcsp.getResponderId() + ")", 2);
/* 4285 */                     } else if ((obj instanceof UnknownStatus)) {
/* 4286 */                       isUnknown = true;
/* 4287 */                       datosOCSP.setRevockedStatus(ICertStatus.CERT_STATUS.unknown);
/* 4288 */                       res = new RespuestaOCSP(2, "");
/*      */                     }
/*      */                     
/* 4291 */                     if (!isUnknown) {
/* 4292 */                       switch (respuestaOCSP.getStatus()) {
/*      */                       case 0: 
/* 4294 */                         datosOCSP.setRevockedStatus(ICertStatus.CERT_STATUS.valid);
/* 4295 */                         res = new RespuestaOCSP(0, "");
/* 4296 */                         break;
/*      */                       case 1: 
/* 4298 */                         datosOCSP.setRevockedStatus(ICertStatus.CERT_STATUS.revoked);
/* 4299 */                         res = new RespuestaOCSP(1, "");
/* 4300 */                         break;
/*      */                       default: 
/* 4302 */                         datosOCSP.setRevockedStatus(ICertStatus.CERT_STATUS.unknown);
/* 4303 */                         res = new RespuestaOCSP(2, "");
/*      */                       }
/*      */                     }
/* 4306 */                     datosOCSP.setStatus(new OCSPStatus(res, certAValidar));
/*      */                     try {
/* 4308 */                       CertPath ocspCertChain = UtilidadCertificados.orderCertPath(Arrays.asList(basicOcsp.getCerts("SUN")));
/* 4309 */                       datosOCSP.setCertOCSPResponder((X509Certificate[])ocspCertChain.getCertificates().toArray(new X509Certificate[0]));
/*      */                     } catch (NoSuchProviderException e) {
/* 4311 */                       LOGGER.error(e.getMessage(), e);
/*      */                     } catch (OCSPException e) {
/* 4313 */                       LOGGER.error(e.getMessage(), e);
/*      */                     }
/* 4315 */                     this.arrayDatosOCSP.add(datosOCSP);
/* 4316 */                     break;
/*      */                   }
/*      */                 }
/* 4319 */                 if ((revoked > 0) || (good > 0))
/*      */                   break;
/*      */               }
/*      */             }
/* 4323 */             if (crlList != null) {
/* 4324 */               Iterator<X509CRL> itCRLList = crlList.iterator();
/* 4325 */               boolean hasNext = itCRLList.hasNext();
/* 4326 */               while ((hasNext) && (this.esValido)) {
/* 4327 */                 X509CRL x509CRL = (X509CRL)itCRLList.next();
/* 4328 */                 hasNext = itCRLList.hasNext();
/*      */                 
/* 4330 */                 if ((x509CRL.getIssuerX500Principal().getName().equals(certIssuer.getSubjectX500Principal().getName())) && 
/* 4331 */                   (!certAValidar.getSubjectDN().equals(certAValidar.getIssuerDN())))
/*      */                 {
/* 4333 */                   if (x509CRL.isRevoked(certAValidar)) {
/* 4334 */                     revoked++;
/*      */                     
/* 4336 */                     if (i == 0) {
/* 4337 */                       logv.abreTag(false);
/* 4338 */                       logv.info("Certificate chain status:", 2);
/* 4339 */                       tieneError = true;
/*      */                     }
/* 4341 */                     logv.error("Certificate: " + certAValidar.getSubjectDN() + " is REVOKED (CRL response: " + x509CRL.getIssuerX500Principal().getName() + ")", 2);
/*      */                     
/* 4343 */                     break;
/*      */                   }
/* 4345 */                   good++;
/*      */                   
/* 4347 */                   if (i == 0) {
/* 4348 */                     logv.abreTag(true);
/* 4349 */                     logv.info("Certificate chain status:", 2);
/*      */                   }
/*      */                   
/* 4352 */                   logv.info("Certificate: " + certAValidar.getSubjectDN() + " is VALID (CRL response: " + x509CRL.getIssuerX500Principal().getName() + ")", 2);
/*      */                   
/* 4354 */                   datosCRL = new DatosCRL();
/* 4355 */                   datosCRL.setIssuer(x509CRL.getIssuerX500Principal().getName());
/* 4356 */                   datosCRL.setFechaEmision(x509CRL.getThisUpdate());
/* 4357 */                   datosCRL.setFechaCaducidad(x509CRL.getNextUpdate());
/* 4358 */                   datosCRL.setX509CRL(x509CRL);
/* 4359 */                   this.arrayDatosCRL.add(datosCRL);
/*      */                 }
/*      */               }
/*      */               
/* 4363 */               if (revoked > 0) {
/*      */                 break;
/*      */               }
/*      */             }
/* 4367 */             if ((revoked == 0) && (good == 0)) {
/* 4368 */               if (!certAValidar.getSubjectDN().equals(certAValidar.getIssuerDN()))
/*      */               {
/* 4370 */                 LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error67"));
/*      */                 
/* 4372 */                 if (i == 0) {
/* 4373 */                   logv.abreTag(false);
/* 4374 */                   logv.info("Certificate chain status:", 2);
/* 4375 */                   tieneError = true;
/*      */                 }
/* 4377 */                 logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error67"), 2);
/*      */                 
/* 4379 */                 this.esValido = false;
/* 4380 */                 this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error67"));
/* 4381 */                 break;
/*      */               }
/*      */             }
/* 4384 */             else if ((revoked > 0) || (good == 0))
/*      */             {
/* 4386 */               LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error57"));
/*      */               
/* 4388 */               if (i == 0) {
/* 4389 */                 logv.abreTag(false);
/* 4390 */                 logv.info("Certificate chain status:", 2);
/* 4391 */                 tieneError = true;
/*      */               }
/* 4393 */               logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error57"), 2);
/*      */               
/* 4395 */               this.esValido = false;
/* 4396 */               this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error57"));
/* 4397 */               break;
/*      */             }
/*      */             
/* 4400 */             certificadoYaValidadoOCSP.add(certAValidar);
/*      */           }
/*      */         }
/* 4403 */         logv.cierraTag(!tieneError);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4409 */     return this.esValido;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean validaXadesA(EstructuraFirma estructuraFirma)
/*      */     throws Exception
/*      */   {
/* 4421 */     Element firma = estructuraFirma.firma;
/* 4422 */     String esquemaURI = estructuraFirma.esquema.getSchemaUri();
/*      */     
/*      */ 
/* 4425 */     Element archiveTimeStampNode = null;
/* 4426 */     ArrayList<Element> nodesArchiveTimeStamp = new ArrayList();
/*      */     try {
/* 4428 */       nodesArchiveTimeStamp = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 4429 */         new NombreNodo(esquemaURI, "ArchiveTimeStamp"));
/*      */     } catch (FirmaXMLError e) {
/* 4431 */       LOGGER.error(e.getMessage(), e);
/* 4432 */       return false;
/*      */     }
/*      */     
/* 4435 */     int numNodes = nodesArchiveTimeStamp.size();
/*      */     
/* 4437 */     if (numNodes == 0) {
/* 4438 */       this.esValido = false;
/*      */       
/* 4440 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error15"));
/*      */       
/* 4442 */       LOGGER.error("El sello de tiempo del nivel XAdES-A, no es válido");
/*      */       
/* 4444 */       logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error8") + " " + 
/* 4445 */         I18n.getResource("libreriaxades.validarfirmaxml.error9") + " " + 
/* 4446 */         I18n.getResource("libreriaxades.validarfirmaxml.error10"));
/*      */       
/* 4448 */       return this.esValido;
/*      */     }
/*      */     
/* 4451 */     TSValidationResult tsv2 = null;
/* 4452 */     DatosSelloTiempo datosSelloTiempo = null;
/* 4453 */     byte[] byteData = null;
/*      */     
/*      */ 
/* 4456 */     for (int i = 0; i < numNodes; i++)
/*      */     {
/* 4458 */       archiveTimeStampNode = (Element)nodesArchiveTimeStamp.get(i);
/*      */       
/* 4460 */       datosSelloTiempo = new DatosSelloTiempo();
/*      */       
/*      */ 
/* 4463 */       if (("http://uri.etsi.org/01903/v1.1.1#".equals(esquemaURI)) || 
/* 4464 */         ("http://uri.etsi.org/01903/v1.2.2#".equals(esquemaURI)))
/*      */       {
/* 4466 */         ArrayList<String> inc = UtilidadXadesA.obtenerListadoIdsElementosXadesA(esquemaURI, estructuraFirma.xmlSig, archiveTimeStampNode);
/*      */         
/*      */ 
/* 4469 */         ArrayList<Element> incNodes = UtilidadTratarNodo.obtenerNodos(archiveTimeStampNode, 1, 
/* 4470 */           new NombreNodo(esquemaURI, "Include"));
/*      */         
/*      */ 
/* 4473 */         String uriIncludeObtenida = null;
/* 4474 */         Element incNode = null;
/* 4475 */         String uriIncludeLeida = null;
/* 4476 */         for (int j = 0; j < inc.size(); j++) {
/* 4477 */           uriIncludeObtenida = (String)inc.get(j);
/* 4478 */           incNode = (Element)incNodes.get(j);
/* 4479 */           uriIncludeLeida = incNode.getAttribute("URI");
/*      */           
/* 4481 */           if (!uriIncludeObtenida.equals(uriIncludeLeida)) {
/* 4482 */             this.esValido = false;
/*      */             
/* 4484 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error15"));
/* 4485 */             LOGGER.error("El sello de tiempo del nivel XAdES-A, no es válido. Los nodos Include no coinciden con los esperados");
/* 4486 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error15"));
/*      */             
/* 4488 */             return this.esValido;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */       try
/*      */       {
/* 4495 */         byteData = UtilidadXadesA.obtenerListadoXadesA(esquemaURI, estructuraFirma.xmlSig, archiveTimeStampNode);
/*      */       } catch (BadFormedSignatureException e) {
/* 4497 */         this.esValido = false;
/* 4498 */         LOGGER.error("Firma mal formada: " + e.getMessage());
/* 4499 */         this.resultado.setLog(e.getMessage());
/* 4500 */         logv.error(e.getMessage());
/* 4501 */         return this.esValido;
/*      */       }
/*      */       
/*      */ 
/* 4505 */       NodeList nodesEncapsulatedTimeStamp = archiveTimeStampNode.getElementsByTagNameNS(esquemaURI, "EncapsulatedTimeStamp");
/*      */       
/* 4507 */       if (nodesEncapsulatedTimeStamp.getLength() != 1) {
/* 4508 */         this.esValido = false;
/*      */         
/* 4510 */         LOGGER.error(I18n.getResource("libreriaxades.firmaxml.error36") + " " + 
/* 4511 */           "EncapsulatedTimeStamp" + " " + I18n.getResource("libreriaxades.firmaxml.error37") + 
/* 4512 */           " " + nodesEncapsulatedTimeStamp.getLength());
/*      */         
/* 4514 */         logv.error(I18n.getResource("libreriaxades.firmaxml.error36") + " " + 
/* 4515 */           "EncapsulatedTimeStamp" + I18n.getResource("libreriaxades.firmaxml.error37") + 
/* 4516 */           " " + nodesEncapsulatedTimeStamp.getLength());
/*      */         
/*      */ 
/* 4519 */         this.resultado.setLog("El sello de tiempo XAdES-A no es válido");
/* 4520 */         return this.esValido;
/*      */       }
/*      */       
/* 4523 */       Element encapsulatedTimeStampElement = (Element)nodesEncapsulatedTimeStamp.item(0);
/*      */       
/*      */ 
/* 4526 */       String enc = encapsulatedTimeStampElement.getAttribute("Encoding");
/* 4527 */       EncodingEnum encoding = EncodingEnum.getEncoding(enc);
/* 4528 */       if (encoding == null) {
/* 4529 */         this.esValido = false;
/* 4530 */         LOGGER.error("Encoding del sello de tiempo A desconocido: " + enc);
/* 4531 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error171"));
/* 4532 */         return this.esValido;
/*      */       }
/*      */       
/* 4535 */       String encapsulatedTS = encapsulatedTimeStampElement.getFirstChild().getNodeValue();
/* 4536 */       byte[] timeStampBytes = Base64.decode(encapsulatedTS);
/*      */       
/*      */       try
/*      */       {
/* 4540 */         tsv2 = this.tsValidator.validateTimeStamp(byteData, timeStampBytes);
/*      */       } catch (TimeStampException e) {
/* 4542 */         this.esValido = false;
/*      */         
/* 4544 */         LOGGER.info("El sello de tiempo XAdES-A no es válido");
/*      */         
/* 4546 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error15"));
/*      */         
/* 4548 */         this.resultado.setLog("El sello de tiempo XAdES-A no es válido");
/* 4549 */         return this.esValido;
/*      */       }
/*      */       
/*      */ 
/* 4553 */       Date fechaSello = tsv2.getDate();
/* 4554 */       if (fechaSello != null) {
/* 4555 */         long now = System.currentTimeMillis();
/* 4556 */         if (tsv2.getTimeAccurracy() > 0L)
/* 4557 */           now += tsv2.getTimeAccurracy();
/* 4558 */         if (fechaSello.after(new Date(now)))
/*      */         {
/* 4560 */           this.resultado.setLog(i18n.getLocalMessage("i18n.mityc.xades.validate.16", new Object[] { fechaSello, Long.valueOf(tsv2.getTimeAccurracy()), new Date(System.currentTimeMillis()) }));
/* 4561 */           LOGGER.error(i18n.getLocalMessage("i18n.mityc.xades.validate.16", new Object[] { fechaSello, Long.valueOf(tsv2.getTimeAccurracy()), new Date(System.currentTimeMillis()) }));
/* 4562 */           this.resultado.setResultado(ResultadoEnum.UNKNOWN);
/* 4563 */           logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error82"));
/*      */         }
/*      */       }
/*      */       try
/*      */       {
/* 4568 */         datosSelloTiempo.setFecha(fechaSello);
/* 4569 */         datosSelloTiempo.setEmisor(tsv2.getTimeStampIssuer());
/* 4570 */         datosSelloTiempo.setAlgoritmo(TSPAlgoritmos.getAlgName(tsv2.getStampAlg()));
/* 4571 */         datosSelloTiempo.setPrecision(Long.valueOf(tsv2.getTimeAccurracy()));
/* 4572 */         datosSelloTiempo.setTipoSello(TipoSellosTiempo.CLASE_A);
/* 4573 */         datosSelloTiempo.setRawTimestamp(tsv2.getTimeStampRawToken());
/* 4574 */         CertPath tsaCerts = tsv2.getCadena();
/* 4575 */         if (tsaCerts != null) {
/* 4576 */           if ((this.truster != null) && (tsaCerts.getCertificates().size() == 1))
/*      */           {
/*      */             try {
/* 4579 */               tsaCerts = this.truster.getCertPath((X509Certificate)tsaCerts.getCertificates().get(0));
/*      */               
/* 4581 */               datosSelloTiempo.setCadena(
/* 4582 */                 UtilidadCertificados.orderCertPath(
/* 4583 */                 tsaCerts.getCertificates()));
/*      */             } catch (Exception e) {
/* 4585 */               LOGGER.debug("No se pudo ordenar la cadena de certificados del sello de tiempo");
/* 4586 */               datosSelloTiempo.setCadena(tsaCerts);
/*      */             }
/*      */           } else {
/* 4589 */             LOGGER.debug("No se pudo recuperar la cadena de certificación");
/* 4590 */             datosSelloTiempo.setCadena(tsaCerts);
/*      */           }
/*      */         }
/*      */         
/* 4594 */         if (this.esValido) {
/* 4595 */           logv.abreTag(true);
/* 4596 */           logv.info("XAdES-A TimeStamp validation: VALID", 2);
/* 4597 */           logv.info("Date: " + fechaSello, 2);
/* 4598 */           logv.info("Issuer: " + tsv2.getTimeStampIssuer(), 2);
/* 4599 */           logv.cierraTag(true);
/* 4600 */           this.resultado.setNivelValido(I18n.getResource("libreriaxades.validarfirmaxml.texto8"));
/*      */         } else {
/* 4602 */           logv.abreTag(false);
/* 4603 */           logv.info("XAdES-A TimeStamp validation: INVALID", 2);
/* 4604 */           logv.info("Date: " + fechaSello, 2);
/* 4605 */           logv.info("Issuer: " + tsv2.getTimeStampIssuer(), 2);
/* 4606 */           logv.cierraTag(false);
/*      */         }
/*      */         
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/* 4612 */         this.esValido = false;
/* 4613 */         LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error64"), e);
/*      */         
/* 4615 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error64"));
/*      */         
/* 4617 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error64"));
/* 4618 */         return this.esValido;
/*      */       }
/*      */       
/* 4621 */       this.arrayDatosSello.add(datosSelloTiempo);
/*      */     }
/*      */     
/* 4624 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private X509Certificate buscarCertificateValue(X500Principal certIssuer, BigInteger serialNumber, EstructuraFirma estructuraFirma)
/*      */   {
/* 4636 */     Element firma = estructuraFirma.firma;
/* 4637 */     String esquemaURI = estructuraFirma.esquema.getSchemaUri();
/* 4638 */     X509Certificate certificado = null;
/* 4639 */     CertificateValues certificateValues = new CertificateValues(estructuraFirma.esquema);
/*      */     
/*      */ 
/* 4642 */     ArrayList<Element> certificateValuesNodeList = new ArrayList();
/*      */     try {
/* 4644 */       certificateValuesNodeList = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 4645 */         new NombreNodo(esquemaURI, "CertificateValues"));
/*      */     } catch (FirmaXMLError e) {
/* 4647 */       LOGGER.debug(e.getMessage(), e);
/* 4648 */       return null;
/*      */     }
/* 4650 */     int certLength = certificateValuesNodeList.size();
/*      */     
/* 4652 */     for (int i = 0; i < certLength; i++) {
/*      */       try {
/* 4654 */         certificateValues.load((Element)certificateValuesNodeList.get(i));
/*      */       } catch (InvalidInfoNodeException e) {
/* 4656 */         LOGGER.debug(e.getMessage(), e);
/* 4657 */         return null;
/*      */       }
/* 4659 */       ArrayList<EncapsulatedX509Certificate> certificados = certificateValues.getCertificates();
/* 4660 */       int certificadosLength = certificados.size();
/*      */       
/* 4662 */       for (int j = 0; j < certificadosLength; j++) {
/* 4663 */         EncapsulatedX509Certificate certEncapsulated = (EncapsulatedX509Certificate)certificados.get(j);
/*      */         try {
/* 4665 */           certificado = certEncapsulated.getX509Certificate();
/*      */         } catch (CertificateException e) {
/* 4667 */           LOGGER.debug(e.getMessage(), e);
/* 4668 */           return null;
/*      */         }
/*      */         
/*      */ 
/* 4672 */         if ((certIssuer.equals(certificado.getIssuerX500Principal())) && 
/* 4673 */           (serialNumber.equals(certificado.getSerialNumber()))) {
/* 4674 */           return certificado;
/*      */         }
/*      */       }
/*      */     }
/* 4678 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Element buscarRevocationValueOCSP(String digest, String method, EstructuraFirma estructuraFirma)
/*      */   {
/* 4690 */     Element firma = estructuraFirma.firma;
/* 4691 */     String esquemaURI = estructuraFirma.esquema.getSchemaUri();
/*      */     
/*      */ 
/* 4694 */     ArrayList<Element> revocationValuesNodeList = new ArrayList();
/*      */     try {
/* 4696 */       revocationValuesNodeList = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 4697 */         new NombreNodo(esquemaURI, "RevocationValues"));
/*      */     } catch (FirmaXMLError e) {
/* 4699 */       LOGGER.debug(e.getMessage(), e);
/* 4700 */       return null;
/*      */     }
/* 4702 */     int revocationLength = revocationValuesNodeList.size();
/*      */     
/* 4704 */     for (int i = 0; i < revocationLength; i++)
/*      */     {
/* 4706 */       Element revocationValuesElement = (Element)revocationValuesNodeList.get(i);
/* 4707 */       NodeList ocspValues = revocationValuesElement.getElementsByTagNameNS(esquemaURI, "OCSPValues");
/* 4708 */       if (ocspValues.getLength() != 1)
/*      */       {
/* 4710 */         LOGGER.error(I18n.getResource("libreriaxades.firmaxml.error36") + " " + 
/* 4711 */           "OCSPValues" + " " + 
/* 4712 */           I18n.getResource("libreriaxades.firmaxml.error37") + " " + 
/* 4713 */           ocspValues.getLength());
/*      */         
/* 4715 */         logv.error(I18n.getResource("libreriaxades.firmaxml.error36") + " " + 
/* 4716 */           "OCSPValues" + " " + 
/* 4717 */           I18n.getResource("libreriaxades.firmaxml.error37") + " " + 
/* 4718 */           ocspValues.getLength());
/*      */         
/* 4720 */         return null;
/*      */       }
/* 4722 */       ArrayList<Element> respuestasOCSP = UtilidadTratarNodo.getElementChildNodes((Element)ocspValues.item(0), false);
/* 4723 */       if (respuestasOCSP == null) {
/* 4724 */         this.esValido = false;
/* 4725 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error95 OCSPValues"));
/*      */         
/* 4727 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error95 OCSPValues"));
/*      */         
/* 4729 */         return null;
/*      */       }
/* 4731 */       int respuestasOCSPLength = respuestasOCSP.size();
/*      */       
/* 4733 */       for (int j = 0; j < respuestasOCSPLength; j++)
/*      */       {
/* 4735 */         Element respuestaOCSPElement = (Element)respuestasOCSP.get(j);
/*      */         
/* 4737 */         if (!new NombreNodo(esquemaURI, "EncapsulatedOCSPValue").equals(new NombreNodo(respuestaOCSPElement.getNamespaceURI(), respuestaOCSPElement.getLocalName())))
/*      */         {
/* 4739 */           LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error119"));
/*      */           
/* 4741 */           logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error119"));
/*      */           
/* 4743 */           return null;
/*      */         }
/*      */         
/* 4746 */         byte[] data = null;
/* 4747 */         String encapsulatedValue = respuestaOCSPElement.getFirstChild().getNodeValue();
/* 4748 */         if (encapsulatedValue != null) {
/*      */           try {
/* 4750 */             data = es.mityc.firmaJava.libreria.utilidades.Base64Coder.decode(encapsulatedValue);
/*      */           }
/*      */           catch (IllegalArgumentException ex) {
/* 4753 */             LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error120"), ex);
/*      */             
/* 4755 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error120"));
/*      */             
/* 4757 */             break;
/*      */           }
/*      */         }
/*      */         else {
/* 4761 */           LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error121"));
/*      */           
/* 4763 */           logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error121"));
/*      */           
/* 4765 */           return null;
/*      */         }
/*      */         
/* 4768 */         MessageDigest resumenTemp = UtilidadFirmaElectronica.getMessageDigest(method);
/* 4769 */         byte[] resumenMensajeByte = resumenTemp.digest(data);
/* 4770 */         String digestLeido = new String(es.mityc.firmaJava.libreria.utilidades.Base64Coder.encode(resumenMensajeByte));
/*      */         
/*      */ 
/* 4773 */         if (digest.equals(digestLeido)) {
/* 4774 */           return respuestaOCSPElement;
/*      */         }
/*      */       }
/*      */     }
/* 4778 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Element buscarRevocationValueCRL(String digest, String method, EstructuraFirma estructuraFirma)
/*      */   {
/* 4790 */     Element firma = estructuraFirma.firma;
/* 4791 */     String esquemaURI = estructuraFirma.esquema.getSchemaUri();
/*      */     
/*      */ 
/* 4794 */     ArrayList<Element> revocationValuesNodeList = new ArrayList();
/*      */     try {
/* 4796 */       revocationValuesNodeList = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 4797 */         new NombreNodo(esquemaURI, "RevocationValues"));
/*      */     } catch (FirmaXMLError e) {
/* 4799 */       LOGGER.debug(e.getMessage(), e);
/* 4800 */       return null;
/*      */     }
/* 4802 */     int revocationLength = revocationValuesNodeList.size();
/*      */     
/* 4804 */     for (int i = 0; i < revocationLength; i++)
/*      */     {
/* 4806 */       Element revocationValuesElement = (Element)revocationValuesNodeList.get(i);
/* 4807 */       NodeList crlValues = revocationValuesElement.getElementsByTagNameNS(esquemaURI, "CRLValues");
/* 4808 */       if (crlValues.getLength() != 1)
/*      */       {
/* 4810 */         LOGGER.error(I18n.getResource("libreriaxades.firmaxml.error36") + " " + 
/* 4811 */           "CRLValues" + " " + 
/* 4812 */           I18n.getResource("libreriaxades.firmaxml.error37") + " " + 
/* 4813 */           crlValues.getLength());
/*      */         
/* 4815 */         logv.error(I18n.getResource("libreriaxades.firmaxml.error36") + " " + 
/* 4816 */           "CRLValues" + " " + 
/* 4817 */           I18n.getResource("libreriaxades.firmaxml.error37") + " " + 
/* 4818 */           crlValues.getLength());
/*      */         
/* 4820 */         return null;
/*      */       }
/* 4822 */       ArrayList<Element> crls = UtilidadTratarNodo.getElementChildNodes((Element)crlValues.item(0), false);
/* 4823 */       if (crls == null) {
/* 4824 */         this.esValido = false;
/* 4825 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error95 CRLValues"));
/*      */         
/* 4827 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error95 CRLValues"));
/*      */         
/* 4829 */         return null;
/*      */       }
/* 4831 */       int crlsLength = crls.size();
/*      */       
/* 4833 */       for (int j = 0; j < crlsLength; j++)
/*      */       {
/* 4835 */         Element crlElement = (Element)crls.get(j);
/*      */         
/* 4837 */         if (!new NombreNodo(esquemaURI, "EncapsulatedCRLValue").equals(new NombreNodo(crlElement.getNamespaceURI(), crlElement.getLocalName())))
/*      */         {
/* 4839 */           LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error122"));
/*      */           
/* 4841 */           logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error122"));
/*      */           
/* 4843 */           return null;
/*      */         }
/*      */         
/*      */ 
/* 4847 */         byte[] data = null;
/* 4848 */         String encapsulatedValue = crlElement.getFirstChild().getNodeValue();
/* 4849 */         if (encapsulatedValue != null) {
/*      */           try {
/* 4851 */             data = es.mityc.firmaJava.libreria.utilidades.Base64Coder.decode(encapsulatedValue);
/*      */           }
/*      */           catch (IllegalArgumentException ex) {
/* 4854 */             LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error123"), ex);
/*      */             
/* 4856 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error123"));
/*      */             
/* 4858 */             break;
/*      */           }
/*      */         }
/*      */         else {
/* 4862 */           LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error124"));
/*      */           
/* 4864 */           logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error124"));
/*      */           
/* 4866 */           return null;
/*      */         }
/*      */         
/* 4869 */         MessageDigest resumenTemp = UtilidadFirmaElectronica.getMessageDigest(method);
/* 4870 */         byte[] resumenMensajeByte = resumenTemp.digest(data);
/* 4871 */         String digestLeido = new String(es.mityc.firmaJava.libreria.utilidades.Base64Coder.encode(resumenMensajeByte));
/*      */         
/*      */ 
/* 4874 */         if (digest.equals(digestLeido)) {
/* 4875 */           return crlElement;
/*      */         }
/*      */       }
/*      */     }
/* 4879 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private DatosTipoFirma tipoFirma(EstructuraFirma estructuraFirma)
/*      */     throws BadFormedSignatureException
/*      */   {
/* 4889 */     Element firma = estructuraFirma.firma;
/* 4890 */     String esquema = estructuraFirma.esquema.getSchemaUri();
/*      */     
/* 4892 */     DatosTipoFirma datosTipoFirma = new DatosTipoFirma();
/* 4893 */     boolean esXAdES_C = false;
/* 4894 */     boolean esXAdES_X = false;
/*      */     
/*      */ 
/* 4897 */     datosTipoFirma.setTipoXAdES(EnumFormatoFirma.XAdES_BES);
/*      */     
/*      */ 
/*      */ 
/* 4901 */     ArrayList<Element> nodosObject = UtilidadTratarNodo.obtenerNodos(firma, null, 
/* 4902 */       new NombreNodo("http://www.w3.org/2000/09/xmldsig#", "Object"));
/* 4903 */     Iterator<Element> itObject = nodosObject.iterator();
/* 4904 */     int numQualifyingProperties = 0;
/* 4905 */     while (itObject.hasNext()) {
/* 4906 */       ArrayList<Element> nodosQualifyingProperties = UtilidadTratarNodo.obtenerNodos((Element)itObject.next(), null, 
/* 4907 */         new NombreNodo(esquema, "QualifyingProperties"));
/* 4908 */       numQualifyingProperties += nodosQualifyingProperties.size();
/*      */     }
/*      */     
/* 4911 */     if (numQualifyingProperties != 1)
/*      */     {
/* 4913 */       LOGGER.error(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 4914 */         " " + "QualifyingProperties" + 
/* 4915 */         " " + I18n.getResource("libreriaxades.firmaxml.error37") + 
/* 4916 */         " " + numQualifyingProperties);
/* 4917 */       logv.error(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 4918 */         " " + "QualifyingProperties" + 
/* 4919 */         " " + I18n.getResource("libreriaxades.firmaxml.error37") + 
/* 4920 */         " " + numQualifyingProperties);
/*      */       
/* 4922 */       ArrayList<Element> nodosSigValue = UtilidadTratarNodo.obtenerNodos(
/* 4923 */         firma, null, new NombreNodo("http://www.w3.org/2000/09/xmldsig#", "SignatureValue"));
/* 4924 */       Iterator<Element> itSigVal = nodosSigValue.iterator();
/* 4925 */       if (itSigVal.hasNext()) {
/* 4926 */         datosTipoFirma.setTipoXAdES(EnumFormatoFirma.XMLSignature);
/* 4927 */         return datosTipoFirma;
/*      */       }
/*      */       
/* 4930 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.validarfirmaxml.error125"));
/*      */     }
/*      */     
/*      */ 
/* 4934 */     ArrayList<Element> nodosSignaturePolicyIdentifier = new ArrayList();
/*      */     try {
/* 4936 */       nodosSignaturePolicyIdentifier = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 4937 */         new NombreNodo(esquema, "SignaturePolicyIdentifier"));
/*      */     } catch (FirmaXMLError e) {
/* 4939 */       LOGGER.error(e.getMessage(), e);
/*      */       
/* 4941 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.validarfirmaxml.error126"));
/*      */     }
/* 4943 */     int numSignaturePolicyIdentifier = nodosSignaturePolicyIdentifier.size();
/*      */     
/* 4945 */     if (numSignaturePolicyIdentifier > 1)
/*      */     {
/* 4947 */       LOGGER.error(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 4948 */         " " + "SignaturePolicyIdentifier" + 
/* 4949 */         " " + I18n.getResource("libreriaxades.firmaxml.error38") + 
/* 4950 */         " " + numSignaturePolicyIdentifier);
/*      */       
/* 4952 */       logv.error(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 4953 */         " " + "SignaturePolicyIdentifier" + 
/* 4954 */         " " + I18n.getResource("libreriaxades.firmaxml.error38") + 
/* 4955 */         " " + numSignaturePolicyIdentifier);
/*      */       
/*      */ 
/* 4958 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.validarfirmaxml.error126")); }
/* 4959 */     if (("http://uri.etsi.org/01903/v1.1.1#".equals(esquema)) && (numSignaturePolicyIdentifier < 1))
/*      */     {
/* 4961 */       LOGGER.error(I18n.getResource("libreriaxades.firmaxml.error33") + 
/* 4962 */         " " + "SignaturePolicyIdentifier");
/*      */       
/* 4964 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.validarfirmaxml.error126")); }
/* 4965 */     if (numSignaturePolicyIdentifier == 1) {
/* 4966 */       datosTipoFirma.setEsXAdES_EPES(true);
/*      */     }
/*      */     
/*      */ 
/* 4970 */     ArrayList<Element> nodosSignatureTimeStamp = new ArrayList();
/*      */     try {
/* 4972 */       nodosSignatureTimeStamp = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 4973 */         new NombreNodo(esquema, "SignatureTimeStamp"));
/*      */     } catch (FirmaXMLError e) {
/* 4975 */       LOGGER.debug(e.getMessage(), e);
/*      */     }
/*      */     
/* 4978 */     int numSignatureTimeStamp = nodosSignatureTimeStamp.size();
/*      */     
/* 4980 */     if (numSignatureTimeStamp > 0) {
/* 4981 */       datosTipoFirma.setTipoXAdES(EnumFormatoFirma.XAdES_T);
/*      */     }
/*      */     
/* 4984 */     ArrayList<Element> nodosCompleteCertificateRefs = new ArrayList();
/* 4985 */     ArrayList<Element> nodosCompleteRevocationRefs = new ArrayList();
/*      */     try {
/* 4987 */       nodosCompleteCertificateRefs = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 4988 */         new NombreNodo(esquema, "CompleteCertificateRefs"));
/* 4989 */       nodosCompleteRevocationRefs = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 4990 */         new NombreNodo(esquema, "CompleteRevocationRefs"));
/*      */     } catch (FirmaXMLError e) {
/* 4992 */       LOGGER.error(e.getMessage(), e);
/* 4993 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.validarfirmaxml.error127"));
/*      */     }
/*      */     
/* 4996 */     int numCompleteCertificateRefs = nodosCompleteCertificateRefs.size();
/* 4997 */     int numCompleteRevocationRefs = nodosCompleteRevocationRefs.size();
/*      */     
/* 4999 */     if ((numCompleteCertificateRefs > 1) || (numCompleteCertificateRefs != numCompleteRevocationRefs)) {
/* 5000 */       if (numCompleteCertificateRefs > 1)
/*      */       {
/* 5002 */         LOGGER.error(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 5003 */           " " + "CompleteCertificateRefs" + 
/* 5004 */           " " + I18n.getResource("libreriaxades.firmaxml.error38") + 
/* 5005 */           " " + numCompleteCertificateRefs);
/* 5006 */         logv.error(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 5007 */           " " + "CompleteCertificateRefs" + 
/* 5008 */           " " + I18n.getResource("libreriaxades.firmaxml.error38") + 
/* 5009 */           " " + numCompleteCertificateRefs);
/*      */       }
/*      */       else
/*      */       {
/* 5013 */         LOGGER.error(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 5014 */           " " + "CompleteRevocationRefs" + 
/* 5015 */           " " + I18n.getResource("libreriaxades.firmaxml.error38") + 
/* 5016 */           " " + numCompleteRevocationRefs);
/* 5017 */         logv.error(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 5018 */           " " + "CompleteRevocationRefs" + 
/* 5019 */           " " + I18n.getResource("libreriaxades.firmaxml.error38") + 
/* 5020 */           " " + numCompleteRevocationRefs);
/*      */       }
/*      */       
/* 5023 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.validarfirmaxml.error127")); }
/* 5024 */     if ((numCompleteCertificateRefs == 1) && (numCompleteCertificateRefs == numCompleteRevocationRefs)) {
/* 5025 */       if (("http://uri.etsi.org/01903/v1.1.1#".equals(esquema)) && (!EnumFormatoFirma.XAdES_T.equals(datosTipoFirma.getTipoXAdES())))
/*      */       {
/* 5027 */         LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error131"));
/*      */         
/* 5029 */         throw new BadFormedSignatureException(I18n.getResource("libreriaxades.validarfirmaxml.error127"));
/*      */       }
/* 5031 */       esXAdES_C = true;
/* 5032 */       datosTipoFirma.setTipoXAdES(EnumFormatoFirma.XAdES_C);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 5037 */     ArrayList<Element> nodosArchiveTimeStamp = new ArrayList();
/* 5038 */     ArrayList<Element> nodosCertificateValues = new ArrayList();
/* 5039 */     ArrayList<Element> nodosRevocationValues = new ArrayList();
/*      */     try {
/* 5041 */       nodosArchiveTimeStamp = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 5042 */         new NombreNodo(esquema, "ArchiveTimeStamp"));
/* 5043 */       nodosCertificateValues = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 5044 */         new NombreNodo(esquema, "CertificateValues"));
/* 5045 */       nodosRevocationValues = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 5046 */         new NombreNodo(esquema, "RevocationValues"));
/*      */     } catch (FirmaXMLError e) {
/* 5048 */       LOGGER.error(e.getMessage(), e);
/*      */     }
/* 5050 */     int numArchiveTimeStamp = nodosArchiveTimeStamp.size();
/* 5051 */     int numCertificateValues = nodosCertificateValues.size();
/* 5052 */     int numRevocationValues = nodosRevocationValues.size();
/*      */     
/* 5054 */     if (numArchiveTimeStamp > 0) {
/* 5055 */       if ((numCertificateValues < 1) || (numRevocationValues < 1))
/*      */       {
/* 5057 */         LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error132"));
/* 5058 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error132"));
/* 5059 */         throw new BadFormedSignatureException(I18n.getResource("libreriaxades.validarfirmaxml.error128")); }
/* 5060 */       if ((numCertificateValues > 1) || (numRevocationValues > 1))
/*      */       {
/* 5062 */         LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error133"));
/* 5063 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error133"));
/* 5064 */         throw new BadFormedSignatureException(I18n.getResource("libreriaxades.validarfirmaxml.error128")); }
/* 5065 */       if (("http://uri.etsi.org/01903/v1.1.1#".equals(esquema)) && (!esXAdES_C))
/*      */       {
/* 5067 */         LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error134"));
/* 5068 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error134"));
/* 5069 */         throw new BadFormedSignatureException(I18n.getResource("libreriaxades.validarfirmaxml.error128"));
/*      */       }
/* 5071 */       datosTipoFirma.setEsXAdES_A(true);
/*      */     }
/*      */     
/*      */ 
/* 5075 */     ArrayList<Element> nodosSigAndRefTimeStamp = new ArrayList();
/* 5076 */     ArrayList<Element> nodosRefsOnlyTimeStamp = new ArrayList();
/*      */     try {
/* 5078 */       nodosSigAndRefTimeStamp = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 5079 */         new NombreNodo(esquema, "SigAndRefsTimeStamp"));
/* 5080 */       nodosRefsOnlyTimeStamp = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 5081 */         new NombreNodo(esquema, "RefsOnlyTimeStamp"));
/*      */     } catch (FirmaXMLError e) {
/* 5083 */       LOGGER.error(e.getMessage(), e);
/*      */     }
/* 5085 */     int numSigAndRefsTimeStamp = nodosSigAndRefTimeStamp.size();
/* 5086 */     int numRefsOnlyTimeStamp = nodosRefsOnlyTimeStamp.size();
/*      */     
/* 5088 */     if ((numSigAndRefsTimeStamp > 0) || (numRefsOnlyTimeStamp > 0)) {
/* 5089 */       if (!esXAdES_C)
/*      */       {
/* 5091 */         LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error135"));
/* 5092 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error135"));
/* 5093 */         throw new BadFormedSignatureException(I18n.getResource("libreriaxades.validarfirmaxml.error129"));
/*      */       }
/* 5095 */       esXAdES_X = true;
/* 5096 */       datosTipoFirma.setTipoXAdES(EnumFormatoFirma.XAdES_X);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5102 */     if ((numCertificateValues > 1) || (numRevocationValues > 1))
/*      */     {
/* 5104 */       LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error133"));
/* 5105 */       logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error133"));
/* 5106 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.validarfirmaxml.error128")); }
/* 5107 */     if ((numCertificateValues == 1) && (numRevocationValues == 1))
/*      */     {
/*      */ 
/*      */ 
/* 5111 */       if (esXAdES_X) {
/* 5112 */         datosTipoFirma.setTipoXAdES(EnumFormatoFirma.XAdES_XL);
/* 5113 */       } else if (!datosTipoFirma.esXAdES_A())
/*      */       {
/* 5115 */         LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error137"));
/* 5116 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error137"));
/* 5117 */         throw new BadFormedSignatureException(I18n.getResource("libreriaxades.validarfirmaxml.error130"));
/*      */       }
/*      */     }
/*      */     
/* 5121 */     LOGGER.debug(datosTipoFirma.getTipoXAdES());
/* 5122 */     return datosTipoFirma;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Date obtenerFechaFirma(EstructuraFirma estructuraFirma)
/*      */   {
/* 5134 */     ArrayList<Element> nodesSignTimeValue = new ArrayList();
/* 5135 */     Date fechaFirma = null;
/*      */     
/* 5137 */     SigningTime momentoFirma = new SigningTime(estructuraFirma.esquema);
/*      */     try
/*      */     {
/* 5140 */       nodesSignTimeValue = UtilidadTratarNodo.obtenerNodos(estructuraFirma.firma, 5, 
/* 5141 */         new NombreNodo(estructuraFirma.esquema.getSchemaUri(), "SigningTime"));
/*      */     } catch (FirmaXMLError e) {
/* 5143 */       LOGGER.error(e.getMessage(), e);
/*      */     }
/*      */     
/* 5146 */     if (nodesSignTimeValue.size() != 0) {
/*      */       try {
/* 5148 */         momentoFirma.load((Element)nodesSignTimeValue.get(0));
/*      */       } catch (InvalidInfoNodeException e) {
/* 5150 */         LOGGER.warn(I18n.getResource("libreriaxades.validarfirmaxml.error63"));
/*      */         
/* 5152 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error63"));
/*      */         
/* 5154 */         return null;
/*      */       }
/* 5156 */       fechaFirma = momentoFirma.getValue();
/*      */     }
/*      */     
/* 5159 */     if (fechaFirma == null) {
/* 5160 */       if (nodesSignTimeValue.size() != 0)
/*      */       {
/* 5162 */         LOGGER.warn(I18n.getResource("libreriaxades.validarfirmaxml.error63"));
/* 5163 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error63"));
/*      */       }
/*      */       else {
/* 5166 */         LOGGER.warn(I18n.getResource("libreriaxades.validarfirmaxml.error163"));
/* 5167 */         logv.info(I18n.getResource("libreriaxades.validarfirmaxml.error163"));
/*      */       }
/*      */     }
/*      */     
/* 5171 */     return fechaFirma;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList<String> obtenerRoles(EstructuraFirma estructuraFirma)
/*      */   {
/* 5180 */     String esquemaURI = estructuraFirma.esquema.getSchemaUri();
/*      */     
/* 5182 */     ArrayList<String> roles = new ArrayList();
/*      */     
/* 5184 */     ArrayList<Element> lst = UtilidadTratarNodo.obtenerNodos(estructuraFirma.signedSignatureProperties, 
/* 5185 */       null, new NombreNodo(esquemaURI, "SignerRole"));
/* 5186 */     Iterator<Element> it = lst.iterator();
/* 5187 */     int nodesClaimedRolesLength; int i; for (; it.hasNext(); 
/*      */         
/*      */ 
/*      */ 
/* 5191 */         i < nodesClaimedRolesLength)
/*      */     {
/* 5188 */       NodeList nodesClaimedRoles = ((Element)it.next()).getElementsByTagNameNS(esquemaURI, "ClaimedRole");
/*      */       
/* 5190 */       nodesClaimedRolesLength = nodesClaimedRoles.getLength();
/* 5191 */       i = 0; continue;
/*      */       
/* 5193 */       Element stElement = (Element)nodesClaimedRoles.item(i);
/* 5194 */       roles.add(stElement.getTextContent());i++;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5198 */     return roles.size() > 0 ? roles : null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private EstructuraFirma obtenerEsquema(Element firma)
/*      */   {
/* 5208 */     String esquema = null;
/* 5209 */     for (Iterator<String> it = this.esquemasParaValidar.iterator(); it.hasNext();)
/*      */     {
/* 5211 */       esquema = ((String)it.next()).trim();
/*      */       
/* 5213 */       Element qualifyingElement = null;
/* 5214 */       ArrayList<Element> nodosObject = UtilidadTratarNodo.obtenerNodos(firma, null, new NombreNodo("http://www.w3.org/2000/09/xmldsig#", "Object"));
/* 5215 */       Iterator<Element> itObject = nodosObject.iterator();
/* 5216 */       while (itObject.hasNext()) {
/* 5217 */         ArrayList<Element> nodosQualifyingProperties = UtilidadTratarNodo.obtenerNodos((Element)itObject.next(), null, new NombreNodo(esquema, "QualifyingProperties"));
/* 5218 */         if (nodosQualifyingProperties.size() > 0) {
/* 5219 */           qualifyingElement = (Element)nodosQualifyingProperties.get(0);
/* 5220 */           break;
/*      */         }
/*      */       }
/*      */       
/* 5224 */       if (qualifyingElement != null) {
/* 5225 */         EstructuraFirma ef = new EstructuraFirma();
/* 5226 */         ef.firma = firma;
/* 5227 */         ArrayList<Element> signedProperties = UtilidadTratarNodo.obtenerNodos(qualifyingElement, null, new NombreNodo(esquema, "SignedProperties"));
/* 5228 */         if (signedProperties.size() != 1)
/* 5229 */           return null;
/* 5230 */         ArrayList<Element> signedSignatureProperties = UtilidadTratarNodo.obtenerNodos((Element)signedProperties.get(0), null, new NombreNodo(esquema, "SignedSignatureProperties"));
/* 5231 */         if (signedSignatureProperties.size() != 1)
/* 5232 */           return null;
/* 5233 */         ef.signedSignatureProperties = ((Element)signedSignatureProperties.get(0));
/* 5234 */         ArrayList<Element> unsignedProperties = UtilidadTratarNodo.obtenerNodos(qualifyingElement, null, new NombreNodo(esquema, "UnsignedProperties"));
/* 5235 */         if (unsignedProperties.size() != 1) {
/* 5236 */           ef.unsignedSignatureProperties = null;
/*      */         } else {
/* 5238 */           ArrayList<Element> unsignedSignatureProperties = UtilidadTratarNodo.obtenerNodos((Element)unsignedProperties.get(0), null, new NombreNodo(esquema, "UnsignedSignatureProperties"));
/* 5239 */           if (unsignedSignatureProperties.size() != 1) {
/* 5240 */             ef.unsignedSignatureProperties = null;
/*      */           } else
/* 5242 */             ef.unsignedSignatureProperties = ((Element)unsignedSignatureProperties.get(0));
/*      */         }
/* 5244 */         ef.esquema = XAdESSchemas.getXAdESSchema(esquema);
/* 5245 */         return ef; }
/* 5246 */       if (esquema.equals("http://www.w3.org/2000/09/xmldsig#"))
/*      */       {
/* 5248 */         Element sigValElement = null;
/* 5249 */         ArrayList<Element> nodosSigValue = UtilidadTratarNodo.obtenerNodos(
/* 5250 */           firma, null, new NombreNodo("http://www.w3.org/2000/09/xmldsig#", "SignatureValue"));
/* 5251 */         Iterator<Element> itSigVal = nodosSigValue.iterator();
/* 5252 */         if (itSigVal.hasNext()) {
/* 5253 */           sigValElement = (Element)itSigVal.next();
/* 5254 */           if (esquema.equals(sigValElement.getNamespaceURI())) {
/* 5255 */             EstructuraFirma ef = new EstructuraFirma();
/* 5256 */             ef.firma = firma;
/* 5257 */             ef.esquema = XAdESSchemas.getXAdESSchema(esquema);
/* 5258 */             return ef;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5267 */     EstructuraFirma ef = new EstructuraFirma();
/* 5268 */     ef.firma = firma;
/*      */     
/* 5270 */     return ef;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean obtenerCadenaCertificados(EstructuraFirma estructuraFirma)
/*      */   {
/* 5281 */     Element firma = estructuraFirma.firma;
/* 5282 */     String esquemaURI = estructuraFirma.esquema.getSchemaUri();
/*      */     
/* 5284 */     if (firma == null) {
/* 5285 */       this.esValido = false;
/*      */       
/* 5287 */       this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error76"));
/* 5288 */       LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error76"));
/*      */       
/* 5290 */       logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error76"));
/*      */       
/* 5292 */       return false;
/*      */     }
/*      */     
/* 5295 */     DatosX509 certificadoFirma = null;
/*      */     
/* 5297 */     ArrayList<X509Certificate> certificadosKeyInfo = new ArrayList();
/* 5298 */     ArrayList<Element> nodosKeyInfo = new ArrayList();
/*      */     try {
/* 5300 */       nodosKeyInfo = UtilidadTratarNodo.obtenerNodos(firma, 2, 
/* 5301 */         new NombreNodo(this.uriXmlNS, "KeyInfo"));
/*      */     } catch (FirmaXMLError e) {
/* 5303 */       LOGGER.error(e.getMessage(), e);
/*      */     }
/* 5305 */     if (nodosKeyInfo.size() > 0) {
/* 5306 */       Element nodoKeyInfo = (Element)nodosKeyInfo.get(0);
/*      */       
/* 5308 */       NodeList nodosX509Data = nodoKeyInfo.getElementsByTagNameNS(this.uriXmlNS, "X509Data");
/* 5309 */       int nodosX509DataLenght = nodosX509Data.getLength();
/* 5310 */       for (int i = 0; i < nodosX509DataLenght; i++) {
/* 5311 */         Element nodoX509Data = (Element)nodosX509Data.item(i);
/*      */         
/* 5313 */         NodeList x509Cert = nodoX509Data.getElementsByTagNameNS(this.uriXmlNS, "X509Certificate");
/* 5314 */         int x509CertLenght = x509Cert.getLength();
/* 5315 */         for (int x = 0; x < x509CertLenght; x++) {
/* 5316 */           Node nodoX509Certificate = x509Cert.item(x);
/*      */           try
/*      */           {
/* 5319 */             ByteArrayInputStream bais = new ByteArrayInputStream(Base64.decode(nodoX509Certificate.getFirstChild().getNodeValue()));
/* 5320 */             CertificateFactory cf = CertificateFactory.getInstance("X.509");
/* 5321 */             certificadosKeyInfo.add((X509Certificate)cf.generateCertificate(bais));
/*      */           } catch (CertificateException e1) {
/* 5323 */             this.esValido = false;
/*      */             
/* 5325 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/*      */             
/* 5327 */             LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error23"), e1);
/*      */             
/* 5329 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/*      */             
/* 5331 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/* 5337 */       certificadoFirma = new DatosX509();
/* 5338 */       ArrayList<Element> nodosSigningCertificate = new ArrayList();
/*      */       try {
/* 5340 */         nodosSigningCertificate = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 5341 */           new NombreNodo(esquemaURI, "SigningCertificate"));
/*      */       } catch (FirmaXMLError e) {
/* 5343 */         LOGGER.error(e.getMessage(), e);
/*      */       }
/* 5345 */       if (nodosSigningCertificate.size() == 1) {
/* 5346 */         Node nodoSigningCertificate = (Node)nodosSigningCertificate.get(0);
/* 5347 */         ArrayList<Element> nodosCert = UtilidadTratarNodo.getElementChildNodes((Element)nodoSigningCertificate, false);
/* 5348 */         if (nodosCert == null) {
/* 5349 */           this.esValido = false;
/* 5350 */           this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error95 Cert"));
/*      */           
/* 5352 */           logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error95 Cert"));
/*      */           
/* 5354 */           return false;
/*      */         }
/* 5356 */         String algoritmo = null;
/* 5357 */         String digest = null;
/* 5358 */         Element nodoCert = (Element)nodosCert.get(0);
/* 5359 */         Element certDigest = (Element)nodoCert.getElementsByTagNameNS(esquemaURI, "CertDigest").item(0);
/* 5360 */         if (certDigest != null) {
/* 5361 */           NodeList digAlgs = certDigest.getElementsByTagNameNS(this.uriXmlNS, "DigestMethod");
/* 5362 */           if (digAlgs != null) {
/* 5363 */             Element certDigestAlgElement = (Element)digAlgs.item(0);
/* 5364 */             algoritmo = certDigestAlgElement.getAttributes().getNamedItem("Algorithm").getNodeValue(); }
/* 5365 */           NodeList digValues = certDigest.getElementsByTagNameNS(this.uriXmlNS, "DigestValue");
/* 5366 */           if (digValues != null) {
/* 5367 */             Element certDigestValElement = (Element)digValues.item(0);
/* 5368 */             digest = certDigestValElement.getFirstChild().getNodeValue();
/*      */           }
/* 5370 */           certificadoFirma.setAlgMethod(algoritmo);
/* 5371 */           certificadoFirma.setDigestValue(digest);
/*      */         }
/*      */       }
/*      */       else {
/* 5375 */         LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error138"));
/*      */         
/* 5377 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error138"));
/*      */         
/* 5379 */         this.esValido = false;
/*      */         
/* 5381 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/* 5382 */         return false;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 5387 */     ArrayList<X509Certificate> certificadosRef = new ArrayList();
/* 5388 */     ArrayList<Element> nodosCertValue = new ArrayList();
/*      */     try {
/* 5390 */       nodosCertValue = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 5391 */         new NombreNodo(esquemaURI, "CertificateValues"));
/*      */     } catch (FirmaXMLError e) {
/* 5393 */       LOGGER.error(e.getMessage(), e);
/*      */     }
/* 5395 */     if (nodosCertValue.size() > 0) {
/* 5396 */       Element nodoCertValue = (Element)nodosCertValue.get(0);
/*      */       
/* 5398 */       NodeList nodosX509Cert = nodoCertValue.getElementsByTagNameNS(esquemaURI, "EncapsulatedX509Certificate");
/* 5399 */       int nodosX509DataLenght = nodosX509Cert.getLength();
/* 5400 */       for (int i = 0; i < nodosX509DataLenght; i++) {
/* 5401 */         Element nodoX509Cert = (Element)nodosX509Cert.item(i);
/*      */         try
/*      */         {
/* 5404 */           ByteArrayInputStream bais = new ByteArrayInputStream(Base64.decode(nodoX509Cert.getFirstChild().getNodeValue()));
/* 5405 */           CertificateFactory cf = CertificateFactory.getInstance("X.509");
/* 5406 */           certificadosRef.add((X509Certificate)cf.generateCertificate(bais));
/*      */         } catch (CertificateException e1) {
/* 5408 */           this.esValido = false;
/*      */           
/* 5410 */           this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/*      */           
/* 5412 */           LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error23"), e1);
/*      */           
/* 5414 */           logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/*      */           
/* 5416 */           return false;
/*      */         }
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 5422 */       ArrayList<Element> nodosCompCertRef = new ArrayList();
/*      */       try {
/* 5424 */         nodosCompCertRef = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/* 5425 */           new NombreNodo(esquemaURI, "CompleteCertificateRefs"));
/*      */       } catch (FirmaXMLError e) {
/* 5427 */         LOGGER.error(e.getMessage(), e);
/*      */       }
/* 5429 */       if (nodosCompCertRef.size() > 0)
/*      */       {
/* 5431 */         Node nodoCertRefs = UtilidadTratarNodo.getFirstElementChild((Element)nodosCompCertRef.get(0), false);
/* 5432 */         if (nodoCertRefs == null) {
/* 5433 */           this.esValido = false;
/* 5434 */           this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error95 CertRefs"));
/*      */           
/* 5436 */           logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error95 CertRefs"));
/*      */           
/* 5438 */           return false;
/*      */         }
/* 5440 */         ArrayList<Element> nodosCert = UtilidadTratarNodo.getElementChildNodes((Element)nodoCertRefs, false);
/* 5441 */         if (nodosCert == null) {
/* 5442 */           this.esValido = false;
/* 5443 */           this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error95 Cert"));
/*      */           
/* 5445 */           logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error95 Cert"));
/*      */           
/* 5447 */           return false;
/*      */         }
/* 5449 */         int nodosCertSize = nodosCert.size();
/* 5450 */         for (int i = 0; i < nodosCertSize; i++) {
/* 5451 */           Node nodoCert = (Node)nodosCert.get(i);
/* 5452 */           String uri = null;
/*      */           try {
/* 5454 */             uri = URLDecoder.decode(nodoCert.getAttributes().getNamedItem(this.tipoUri).getNodeValue(), "UTF-8");
/*      */           }
/*      */           catch (UnsupportedEncodingException e) {
/* 5457 */             LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error30"), e);
/* 5458 */             this.esValido = false;
/*      */             
/* 5460 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/*      */             
/* 5462 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/*      */           }
/*      */           catch (Exception e)
/*      */           {
/* 5466 */             LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error65"), e);
/*      */             
/* 5468 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error65"));
/*      */             
/* 5470 */             this.esValido = false;
/*      */             
/* 5472 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/*      */           }
/*      */           
/*      */ 
/* 5476 */           if ((uri != null) && (!uri.startsWith("#"))) {
/* 5477 */             X509Certificate certFile = null;
/* 5478 */             if (this.recoverManager != null) {
/* 5479 */               Map<String, Object> props = new HashMap();
/* 5480 */               props.put("uri", uri);
/*      */               try
/*      */               {
/* 5483 */                 certFile = (X509Certificate)this.recoverManager.getElement(props, X509Certificate.class);
/*      */               } catch (ElementNotFoundException ex) {
/* 5485 */                 LOGGER.warn(i18n.getLocalMessage("i18n.mityc.xades.validate.2"));
/* 5486 */                 if (LOGGER.isTraceEnabled()) {
/* 5487 */                   LOGGER.trace(props);
/*      */                 }
/*      */               } catch (UnknownElementClassException ex) {
/* 5490 */                 LOGGER.error(i18n.getLocalMessage("i18n.mityc.xades.validate.3", new Object[] { "X509Certificate" }), ex);
/*      */               }
/*      */             }
/* 5493 */             if (certFile == null) {
/* 5494 */               LOGGER.error(i18n.getLocalMessage("i18n.mityc.xades.validate.1", new Object[] { uri }));
/* 5495 */               this.esValido = false;
/*      */               
/*      */ 
/* 5498 */               this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/*      */               
/* 5500 */               logv.error(i18n.getLocalMessage("i18n.mityc.xades.validate.1", new Object[] { uri }));
/*      */               
/* 5502 */               return false;
/*      */             }
/*      */             
/*      */ 
/*      */ 
/* 5507 */             Element certElement = (Element)nodoCert;
/* 5508 */             Element certDigest = (Element)certElement.getElementsByTagNameNS(esquemaURI, "CertDigest").item(0);
/*      */             
/* 5510 */             String alg = null;
/* 5511 */             String digest = null;
/* 5512 */             String resumenCertificado = "";
/* 5513 */             if (certDigest != null) {
/* 5514 */               Node algorithm = certDigest.getElementsByTagNameNS(this.uriXmlNS, "DigestMethod").item(0);
/* 5515 */               Node value = certDigest.getElementsByTagNameNS(this.uriXmlNS, "DigestValue").item(0);
/*      */               
/* 5517 */               alg = algorithm.getAttributes().getNamedItem("Algorithm").getNodeValue();
/* 5518 */               digest = value.getFirstChild().getNodeValue();
/*      */               
/*      */ 
/*      */               try
/*      */               {
/* 5523 */                 MessageDigest haseador = UtilidadFirmaElectronica.getMessageDigest(alg);
/* 5524 */                 if (haseador == null) {
/* 5525 */                   this.esValido = false;
/*      */                   
/* 5527 */                   this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error52"));
/*      */                   
/* 5529 */                   LOGGER.error(I18n.getResource("libreriaxades.firmaxml.error16"));
/*      */                   
/* 5531 */                   logv.error(I18n.getResource("libreriaxades.firmaxml.error16"));
/*      */                   
/* 5533 */                   return false;
/*      */                 }
/* 5535 */                 byte[] resumenMensajeByte = haseador.digest(certFile.getEncoded());
/* 5536 */                 resumenCertificado = new String(es.mityc.firmaJava.libreria.utilidades.Base64Coder.encode(resumenMensajeByte));
/*      */               }
/*      */               catch (CertificateEncodingException e) {
/* 5539 */                 LOGGER.error(I18n.getResource("libreriaxades.firmaxml.error23") + 
/* 5540 */                   " " + e.getMessage(), e);
/* 5541 */                 this.esValido = false;
/*      */                 
/* 5543 */                 this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error52"));
/*      */                 
/* 5545 */                 logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error52") + "\n" + 
/* 5546 */                   I18n.getResource("libreriaxades.firmaxml.error23") + 
/* 5547 */                   " " + e.getMessage());
/*      */                 
/* 5549 */                 return false;
/*      */               }
/*      */               
/* 5552 */               if (digest.equals(resumenCertificado)) {
/* 5553 */                 certificadosRef.add(certFile);
/*      */               } else {
/* 5555 */                 this.esValido = false;
/*      */                 
/* 5557 */                 this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error53"));
/* 5558 */                 LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error53"));
/*      */                 
/* 5560 */                 logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error53"));
/*      */                 
/* 5562 */                 return false;
/*      */               }
/*      */             }
/*      */             else
/*      */             {
/* 5567 */               LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error66"));
/*      */               
/* 5569 */               logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error66"));
/*      */               
/*      */ 
/* 5572 */               this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/* 5573 */               this.esValido = false;
/* 5574 */               return false;
/*      */             }
/*      */           }
/*      */           else
/*      */           {
/* 5579 */             LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error83"));
/*      */             
/* 5581 */             logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error83"));
/*      */             
/* 5583 */             this.esValido = false;
/*      */             
/* 5585 */             this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error3"));
/* 5586 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 5593 */     certificadosRef.addAll(certificadosKeyInfo);
/* 5594 */     ArrayList<ArrayList<X509Certificate>> certChains = UtilidadCertificados.filterCertPathsArrays(UtilidadCertificados.getCertPathsArray(certificadosRef), UtilidadCertificados.Filter.SIGN_SIGNER);
/* 5595 */     int certChainsSize = certChains.size();
/* 5596 */     if (certChainsSize > 1) {
/* 5597 */       boolean encontrado = false;
/*      */       
/*      */ 
/* 5600 */       if (certificadosKeyInfo.size() != 0) {
/* 5601 */         for (int i = 0; i < certChainsSize; i++) {
/* 5602 */           ArrayList<X509Certificate> cadena = (ArrayList)certChains.get(i);
/* 5603 */           X509Certificate cert = (X509Certificate)cadena.get(0);
/* 5604 */           if (cert.equals(certificadosKeyInfo.get(0))) {
/* 5605 */             this.cadenaCertificados = cadena;
/* 5606 */             this.datosFirma.setCadenaFirma(UtilidadCertificados.convertCertPath(this.cadenaCertificados));
/* 5607 */             encontrado = true;
/*      */           }
/*      */         }
/* 5610 */       } else if (certificadoFirma != null) {
/* 5611 */         MessageDigest haseador = null;
/* 5612 */         haseador = UtilidadFirmaElectronica.getMessageDigest(certificadoFirma.getAlgMethod());
/* 5613 */         for (int i = 0; (i < certChainsSize) && (haseador != null); i++) {
/* 5614 */           ArrayList<X509Certificate> cadena = (ArrayList)certChains.get(i);
/* 5615 */           X509Certificate cert = (X509Certificate)cadena.get(0);
/*      */           
/* 5617 */           String digest = null;
/*      */           try {
/* 5619 */             byte[] resumenMensajeByte = haseador.digest(cert.getEncoded());
/* 5620 */             digest = new String(es.mityc.firmaJava.libreria.utilidades.Base64Coder.encode(resumenMensajeByte));
/*      */           } catch (CertificateEncodingException e) {
/* 5622 */             LOGGER.error(I18n.getResource("libreriaxades.firmaxml.error23"), e);
/*      */             
/* 5624 */             logv.error(I18n.getResource("libreriaxades.firmaxml.error23") + " " + e.getMessage());
/*      */           }
/*      */           
/* 5627 */           if (certificadoFirma.getDigestValue().equals(digest)) {
/* 5628 */             this.cadenaCertificados = cadena;
/* 5629 */             this.datosFirma.setCadenaFirma(UtilidadCertificados.convertCertPath(this.cadenaCertificados));
/* 5630 */             encontrado = true;
/*      */           }
/*      */         }
/*      */       }
/* 5634 */       if (!encontrado)
/*      */       {
/* 5636 */         this.esValido = false;
/* 5637 */         this.resultado.setLog(I18n.getResource("libreriaxades.validarfirmaxml.error84"));
/* 5638 */         LOGGER.error(I18n.getResource("libreriaxades.validarfirmaxml.error84"));
/*      */         
/* 5640 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error84"));
/*      */         
/* 5642 */         return false;
/*      */       }
/* 5644 */     } else { if (certChainsSize == 0)
/*      */       {
/* 5646 */         this.esValido = false;
/* 5647 */         this.resultado.setLog(i18n.getLocalMessage("i18n.mityc.xades.validate.10"));
/* 5648 */         LOGGER.error(i18n.getLocalMessage("i18n.mityc.xades.validate.10"));
/*      */         
/* 5650 */         logv.error(I18n.getResource("libreriaxades.validarfirmaxml.error84"));
/*      */         
/* 5652 */         return false;
/*      */       }
/* 5654 */       this.cadenaCertificados = ((ArrayList)certChains.get(0));
/*      */       
/* 5656 */       this.datosFirma.setCadenaFirma(UtilidadCertificados.convertCertPath(this.cadenaCertificados));
/*      */     }
/*      */     
/* 5659 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void getConstantesEsquema(XAdESSchemas esquema)
/*      */   {
/* 5666 */     if ((esquema != null) && ("http://uri.etsi.org/01903/v1.1.1#".equals(esquema.getSchemaUri()))) {
/* 5667 */       this.nombreNodoUri = "HashDataInfo";
/* 5668 */       this.tipoUri = "uri";
/*      */     } else {
/* 5670 */       this.nombreNodoUri = "Include";
/* 5671 */       this.tipoUri = "URI";
/*      */     }
/*      */   }
/*      */   
/*      */   protected class EstructuraFirma
/*      */   {
/*      */     XAdESSchemas esquema;
/*      */     Element firma;
/*      */     Element signedSignatureProperties;
/*      */     Element unsignedSignatureProperties;
/*      */     XMLSignature xmlSig;
/*      */     
/*      */     protected EstructuraFirma() {}
/*      */   }
/*      */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\ValidarFirmaXML.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */