/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.utilidades.Base64Coder;
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.net.URI;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509Certificate;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EncapsulatedX509Certificate
/*     */   extends EncapsulatedPKIDataType
/*     */ {
/*     */   public EncapsulatedX509Certificate(XAdESSchemas schema)
/*     */   {
/*  42 */     super(schema);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public EncapsulatedX509Certificate(XAdESSchemas schema, String id)
/*     */   {
/*  50 */     super(schema, id);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  58 */     checkElementName(element, this.schema.getSchemaUri(), "EncapsulatedX509Certificate");
/*  59 */     super.load(element);
/*     */     
/*     */ 
/*  62 */     EncodingEnum encoding = getEncoding();
/*  63 */     if ((encoding != null) && (!encoding.equals(EncodingEnum.DER_ENCODED))) {
/*  64 */       throw new InvalidInfoNodeException("El contenido de EncapsulatedX509Certificate debe estar en la codificación " + EncodingEnum.DER_ENCODED.getEncodingUri().toString());
/*     */     }
/*     */     
/*     */     try
/*     */     {
/*  69 */       cert = getX509Certificate();
/*     */     } catch (CertificateException ex) { X509Certificate cert;
/*  71 */       throw new InvalidInfoNodeException("El contenido de EncapsulatedX509Certificate no es un certificado X509 válido", ex); }
/*     */     X509Certificate cert;
/*  73 */     if (cert == null) {
/*  74 */       throw new InvalidInfoNodeException("El contenido de EncapsulatedX509Certificate no es un certificado X509 válido");
/*     */     }
/*     */   }
/*     */   
/*     */   public X509Certificate getX509Certificate() throws CertificateException {
/*  79 */     String value = getValue();
/*  80 */     if (value != null)
/*     */     {
/*     */       try {
/*  83 */         data = Base64Coder.decode(value);
/*     */       } catch (IllegalArgumentException ex) { byte[] data;
/*  85 */         throw new CertificateException("Contenido base64 de EncapsulatedX509Certificate inválido", ex); }
/*     */       byte[] data;
/*  87 */       ByteArrayInputStream bais = new ByteArrayInputStream(data);
/*  88 */       CertificateFactory cf = CertificateFactory.getInstance("X.509");
/*  89 */       Certificate cert = cf.generateCertificate(bais);
/*  90 */       if ((cert instanceof X509Certificate))
/*  91 */         return (X509Certificate)cert;
/*  92 */       throw new CertificateException("Contenido base64 de EncapsulatedX509Certificate no es un certificado tipo X.509");
/*     */     }
/*     */     
/*  95 */     return null;
/*     */   }
/*     */   
/*     */   public void setX509Certificate(X509Certificate certificate) throws CertificateException {
/*  99 */     setValue(new String(Base64Coder.encode(certificate.getEncoded())));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isThisNode(Node node)
/*     */   {
/* 107 */     return isElementName(nodeToElement(node), this.schema.getSchemaUri(), "EncapsulatedX509Certificate");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Element createElement(Document doc, String namespaceXAdES)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 115 */     return super.createElement(doc, namespaceXAdES);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Element createElement(Document doc)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 123 */     Element res = doc.createElementNS(this.schema.getSchemaUri(), this.namespaceXAdES + ":" + "EncapsulatedX509Certificate");
/* 124 */     super.addContent(res, this.namespaceXAdES);
/* 125 */     return res;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\EncapsulatedX509Certificate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */