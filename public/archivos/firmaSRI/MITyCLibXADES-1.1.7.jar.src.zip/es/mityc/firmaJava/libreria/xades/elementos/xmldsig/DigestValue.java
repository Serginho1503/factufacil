/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xmldsig;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DigestValue
/*     */   extends AbstractXDsigElement
/*     */ {
/*     */   private String value;
/*     */   
/*     */   public DigestValue() {}
/*     */   
/*     */   public DigestValue(String value)
/*     */   {
/*  43 */     setValue(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getValue()
/*     */   {
/*  52 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setValue(String value)
/*     */   {
/*  59 */     this.value = value;
/*  60 */     if (this.value != null) {
/*  61 */       this.value = this.value.replace(" ", "").replace("\n", "").replace("\r", "");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected Element createElement(Document doc)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  69 */     if (this.value == null)
/*  70 */       throw new InvalidInfoNodeException("Información insuficiente para escribir elemento DigestValue");
/*  71 */     Element res = doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", this.namespaceXDsig + ":" + "DigestValue");
/*  72 */     res.setTextContent(this.value);
/*  73 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Element createElement(Document doc, String namespaceXDsig)
/*     */     throws InvalidInfoNodeException
/*     */   {
/*  81 */     return super.createElement(doc, namespaceXDsig);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  89 */     if ((obj instanceof DigestValue)) {
/*  90 */       DigestValue huella = (DigestValue)obj;
/*  91 */       if (this.value.equals(huella.value))
/*  92 */         return true;
/*     */     }
/*  94 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load(Element element)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 102 */     checkElementName(element, "http://www.w3.org/2000/09/xmldsig#", "DigestValue");
/*     */     
/* 104 */     Node node = getFirstNonvoidNode(element);
/* 105 */     if ((node == null) || (node.getNodeType() != 3)) {
/* 106 */       throw new InvalidInfoNodeException("Nodo DigestValue no contiene CDATA como primer valor");
/*     */     }
/* 108 */     this.value = node.getNodeValue();
/* 109 */     if (this.value == null)
/* 110 */       throw new InvalidInfoNodeException("Contenido de valor de digest vacío");
/* 111 */     this.value = this.value.replace(" ", "").replace("\n", "").replace("\r", "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isThisNode(Node node)
/*     */   {
/* 119 */     return isElementName(nodeToElement(node), "http://www.w3.org/2000/09/xmldsig#", "DigestValue");
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xmldsig\DigestValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */