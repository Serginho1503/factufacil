/*    */ package es.mityc.firmaJava.libreria.xades;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NombreElementos
/*    */ {
/* 23 */   private String nameFileOCSPResp = null;
/* 24 */   private String nameFileCRLResp = null;
/* 25 */   private String nameFileX509Cert = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getNameFileOCSPResp()
/*    */   {
/* 32 */     return this.nameFileOCSPResp;
/*    */   }
/*    */   
/*    */   public String getNameFileX509Cert() {
/* 36 */     return this.nameFileX509Cert;
/*    */   }
/*    */   
/*    */   public void setNameFileOCSPResp(String name) {
/* 40 */     this.nameFileOCSPResp = name;
/*    */   }
/*    */   
/*    */   public void setNameFileX509Cert(String name) {
/* 44 */     this.nameFileX509Cert = name;
/*    */   }
/*    */   
/*    */   public String getNameFileCRLResp() {
/* 48 */     return this.nameFileCRLResp;
/*    */   }
/*    */   
/*    */   public void setNameFileCRLResp(String nameFileCRLResp) {
/* 52 */     this.nameFileCRLResp = nameFileCRLResp;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\NombreElementos.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */