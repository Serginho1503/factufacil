/*     */ package es.mityc.firmaJava.libreria.xades;
/*     */ 
/*     */ import adsi.org.apache.xml.security.Init;
/*     */ import es.mityc.firmaJava.libreria.excepciones.AddXadesException;
/*     */ import es.mityc.firmaJava.libreria.utilidades.Base64Coder;
/*     */ import es.mityc.firmaJava.libreria.utilidades.I18n;
/*     */ import es.mityc.firmaJava.libreria.utilidades.NombreNodo;
/*     */ import es.mityc.firmaJava.libreria.utilidades.UtilidadTratarNodo;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.FirmaXMLError;
/*     */ import java.util.ArrayList;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignXAdEST
/*     */ {
/*     */   public static byte[] getDataToStamp(Element sign)
/*     */     throws AddXadesException
/*     */   {
/*     */     
/*     */     try
/*     */     {
/*  51 */       return UtilidadTratarNodo.obtenerByteNodo(sign, "http://www.w3.org/2000/09/xmldsig#", "SignatureValue", CanonicalizationEnum.C14N_OMIT_COMMENTS, 5);
/*     */     } catch (FirmaXMLError ex) {
/*  53 */       throw new AddXadesException("Error procesando información a sellar: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void addXAdEST(Element sign, byte[] ts)
/*     */     throws AddXadesException
/*     */   {
/*     */     
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  68 */       Document doc = sign.getOwnerDocument();
/*  69 */       Element qualifying = null;
/*  70 */       ArrayList<Element> qualifyings = UtilidadTratarNodo.obtenerNodos(sign, 2, new NombreNodo("*", "QualifyingProperties"));
/*  71 */       if ((qualifyings == null) || (qualifyings.size() != 1)) {
/*  72 */         throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error18"));
/*     */       }
/*  74 */       qualifying = (Element)qualifyings.get(0);
/*  75 */       String xadesSchema = qualifying.getNamespaceURI();
/*  76 */       String xadesNS = qualifying.getPrefix();
/*  77 */       String xmldsigNS = sign.getPrefix();
/*  78 */       String firmaID = UtilidadTratarNodo.getId(sign);
/*  79 */       ArrayList<Element> signaturesValue = UtilidadTratarNodo.obtenerNodos(sign, 1, new NombreNodo("http://www.w3.org/2000/09/xmldsig#", "SignatureValue"));
/*  80 */       if ((signaturesValue == null) || (signaturesValue.size() != 1)) {
/*  81 */         throw new AddXadesException(I18n.getResource("libreriaxades.firmaxml.error18"));
/*     */       }
/*  83 */       String idSignatureValue = UtilidadTratarNodo.getId((Element)signaturesValue.get(0));
/*     */       
/*     */ 
/*  86 */       Element propiedadesElementosNoFirmados = null;
/*  87 */       ArrayList<Element> unsignedsProps = UtilidadTratarNodo.obtenerNodos(qualifying, 1, new NombreNodo(xadesSchema, "UnsignedProperties"));
/*  88 */       if ((unsignedsProps == null) || (unsignedsProps.size() == 0)) {
/*  89 */         propiedadesElementosNoFirmados = doc.createElementNS(xadesSchema, xadesNS + ":" + "UnsignedProperties");
/*  90 */         Attr propiedadesNoFirmadasId = doc.createAttributeNS(null, "Id");
/*  91 */         propiedadesNoFirmadasId.setValue(UtilidadTratarNodo.newID(doc, 
/*  92 */           firmaID + "-UnsignedProperties"));
/*  93 */         NamedNodeMap atributosSinFirmarPropiedadesElemento = 
/*  94 */           propiedadesElementosNoFirmados.getAttributes();
/*  95 */         atributosSinFirmarPropiedadesElemento.setNamedItem(propiedadesNoFirmadasId);
/*  96 */         qualifying.appendChild(propiedadesElementosNoFirmados);
/*     */       } else {
/*  98 */         propiedadesElementosNoFirmados = (Element)unsignedsProps.get(0);
/*     */       }
/*     */       
/* 101 */       Element propiedadesSinFirmarFirmaElementos = null;
/* 102 */       ArrayList<Element> unsignedsSigsProps = UtilidadTratarNodo.obtenerNodos(propiedadesElementosNoFirmados, 1, new NombreNodo(xadesSchema, "UnsignedSignatureProperties"));
/* 103 */       if ((unsignedsSigsProps == null) || (unsignedsSigsProps.size() == 0)) {
/* 104 */         propiedadesSinFirmarFirmaElementos = doc.createElementNS(xadesSchema, xadesNS + ":" + "UnsignedSignatureProperties");
/* 105 */         propiedadesElementosNoFirmados.appendChild(propiedadesSinFirmarFirmaElementos);
/*     */       } else {
/* 107 */         propiedadesSinFirmarFirmaElementos = (Element)unsignedsSigsProps.get(0);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 112 */       Element tiempoSelloElementoFirma = 
/* 113 */         doc.createElementNS(xadesSchema, xadesNS + ":" + "SignatureTimeStamp");
/*     */       
/*     */ 
/* 116 */       Attr informacionElementoSigTimeStamp = doc.createAttributeNS(null, "Id");
/* 117 */       String idSelloTiempo = UtilidadTratarNodo.newID(doc, "SelloTiempo");
/* 118 */       informacionElementoSigTimeStamp.setValue(idSelloTiempo);
/* 119 */       tiempoSelloElementoFirma.getAttributes().setNamedItem(informacionElementoSigTimeStamp);
/*     */       
/*     */ 
/* 122 */       if (("http://uri.etsi.org/01903/v1.1.1#".equals(xadesSchema)) || 
/* 123 */         ("http://uri.etsi.org/01903/v1.2.2#".equals(xadesSchema)))
/*     */       {
/* 125 */         String nombreNodoUri = null;
/* 126 */         String tipoUri = null;
/* 127 */         if ("http://uri.etsi.org/01903/v1.1.1#".equals(xadesSchema)) {
/* 128 */           nombreNodoUri = "HashDataInfo";
/* 129 */           tipoUri = "uri";
/*     */         } else {
/* 131 */           nombreNodoUri = "Include";
/* 132 */           tipoUri = "URI";
/*     */         }
/*     */         
/* 135 */         Element informacionElementoHashDatos = doc.createElementNS(xadesSchema, xadesNS + ":" + nombreNodoUri);
/*     */         
/* 137 */         Attr informacionElementoHashDatosUri = doc.createAttributeNS(null, tipoUri);
/* 138 */         informacionElementoHashDatosUri.setValue("#" + idSignatureValue);
/*     */         
/* 140 */         NamedNodeMap informacionAtributosElementoHashDatos = informacionElementoHashDatos.getAttributes();
/* 141 */         informacionAtributosElementoHashDatos.setNamedItem(informacionElementoHashDatosUri);
/*     */         
/* 143 */         tiempoSelloElementoFirma.appendChild(informacionElementoHashDatos);
/*     */       }
/*     */       
/*     */ 
/* 147 */       if (!"http://uri.etsi.org/01903/v1.1.1#".equals(xadesSchema)) {
/* 148 */         Element canonicalizationElemento = doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", xmldsigNS + ":" + "CanonicalizationMethod");
/* 149 */         Attr canonicalizationAttribute = doc.createAttributeNS(null, "Algorithm");
/* 150 */         canonicalizationAttribute.setValue("http://www.w3.org/TR/2001/REC-xml-c14n-20010315");
/* 151 */         canonicalizationElemento.getAttributes().setNamedItem(canonicalizationAttribute);
/*     */         
/* 153 */         tiempoSelloElementoFirma.appendChild(canonicalizationElemento);
/*     */       }
/*     */       
/*     */ 
/* 157 */       Element tiempoSelloEncapsulado = 
/* 158 */         doc.createElementNS(xadesSchema, xadesNS + ":" + "EncapsulatedTimeStamp");
/*     */       
/* 160 */       tiempoSelloEncapsulado.appendChild(
/* 161 */         doc.createTextNode(new String(Base64Coder.encode(ts))));
/* 162 */       Attr tiempoSelloEncapsuladoId = doc.createAttributeNS(null, "Id");
/* 163 */       String idEncapsulated = UtilidadTratarNodo.newID(doc, "SelloTiempo-Token");
/* 164 */       tiempoSelloEncapsuladoId.setValue(idEncapsulated);
/* 165 */       tiempoSelloEncapsulado.getAttributes().setNamedItem(tiempoSelloEncapsuladoId);
/*     */       
/*     */ 
/* 168 */       tiempoSelloElementoFirma.appendChild(tiempoSelloEncapsulado);
/*     */       
/* 170 */       propiedadesSinFirmarFirmaElementos.appendChild(tiempoSelloElementoFirma);
/*     */     } catch (FirmaXMLError ex) {
/* 172 */       throw new AddXadesException("Error incrustando sello de tiempo en firma XAdES: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\SignXAdEST.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */