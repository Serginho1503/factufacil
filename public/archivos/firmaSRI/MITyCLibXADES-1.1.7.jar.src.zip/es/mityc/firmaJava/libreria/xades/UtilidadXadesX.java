/*     */ package es.mityc.firmaJava.libreria.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.utilidades.I18n;
/*     */ import es.mityc.firmaJava.libreria.utilidades.NombreNodo;
/*     */ import es.mityc.firmaJava.libreria.utilidades.UtilidadTratarNodo;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.BadFormedSignatureException;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.FirmaXMLError;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UtilidadXadesX
/*     */ {
/*  36 */   private static ArrayList<String> NODOS_DE_X = null;
/*     */   
/*  38 */   static { NODOS_DE_X = new ArrayList(6);
/*  39 */     NODOS_DE_X.add("SignatureValue");
/*  40 */     NODOS_DE_X.add("SignatureTimeStamp");
/*  41 */     NODOS_DE_X.add("CompleteCertificateRefs");
/*  42 */     NODOS_DE_X.add("CompleteRevocationRefs");
/*  43 */     NODOS_DE_X.add("AttributeCertificateRefs");
/*  44 */     NODOS_DE_X.add("AttributeRevocationRefs");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ArrayList<Element> obtenerListadoXADESX1imp(String esquemaXADES, Element firma, Element nodoSigAndRefs)
/*     */     throws BadFormedSignatureException, FirmaXMLError
/*     */   {
/*  70 */     ArrayList<Element> resultado = new ArrayList();
/*     */     
/*     */ 
/*  73 */     Element signatureValueNode = null;
/*  74 */     ArrayList<Element> signatureValueNodes = UtilidadTratarNodo.obtenerNodos(firma, 5, 
/*  75 */       new NombreNodo("http://www.w3.org/2000/09/xmldsig#", "SignatureValue"));
/*  76 */     if (signatureValueNodes.size() == 1) {
/*  77 */       signatureValueNode = (Element)signatureValueNodes.get(0);
/*     */     }
/*     */     else {
/*  80 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + " " + 
/*  81 */         "SignatureValue" + " " + I18n.getResource("libreriaxades.firmaxml.error37") + 
/*  82 */         " " + signatureValueNodes.size());
/*     */     }
/*  84 */     resultado.add(signatureValueNode);
/*     */     
/*     */ 
/*  87 */     Element UnsignedSignaturePropertiesElement = (Element)nodoSigAndRefs.getParentNode();
/*     */     
/*     */ 
/*  90 */     if (!new NombreNodo(esquemaXADES, "UnsignedSignatureProperties").equals(new NombreNodo(UnsignedSignaturePropertiesElement.getNamespaceURI(), UnsignedSignaturePropertiesElement.getLocalName())))
/*     */     {
/*  92 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error40") + 
/*  93 */         " " + "SigAndRefsTimeStamp" + " " + 
/*  94 */         I18n.getResource("libreriaxades.firmaxml.error42"));
/*     */     }
/*     */     
/*     */ 
/*  98 */     if (("http://uri.etsi.org/01903/v1.2.2#".equals(esquemaXADES)) || 
/*  99 */       ("http://uri.etsi.org/01903/v1.1.1#".equals(esquemaXADES)))
/*     */     {
/*     */ 
/* 102 */       NombreNodo tagName = new NombreNodo(esquemaXADES, "SignatureTimeStamp");
/* 103 */       ArrayList<Element> nodosSigTimeStamp = UtilidadTratarNodo.obtenerNodos(UnsignedSignaturePropertiesElement, 
/* 104 */         nodoSigAndRefs, tagName);
/*     */       
/* 106 */       if (nodosSigTimeStamp.size() < 1)
/*     */       {
/* 108 */         throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error21"));
/*     */       }
/* 110 */       resultado.addAll(nodosSigTimeStamp);
/*     */       
/*     */ 
/* 113 */       tagName = new NombreNodo(esquemaXADES, "CompleteCertificateRefs");
/* 114 */       ArrayList<Element> nodosCompleteCertificateRefs = UtilidadTratarNodo.obtenerNodos(UnsignedSignaturePropertiesElement, 
/* 115 */         nodoSigAndRefs, tagName);
/*     */       
/* 117 */       if (nodosCompleteCertificateRefs.size() != 1)
/*     */       {
/* 119 */         throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 120 */           " " + "CompleteCertificateRefs" + " " + 
/* 121 */           I18n.getResource("libreriaxades.firmaxml.error37") + " " + 
/* 122 */           nodosCompleteCertificateRefs.size());
/*     */       }
/* 124 */       resultado.addAll(nodosCompleteCertificateRefs);
/*     */       
/*     */ 
/* 127 */       tagName = new NombreNodo(esquemaXADES, "CompleteRevocationRefs");
/* 128 */       ArrayList<Element> nodosCompleteRevocationRefs = UtilidadTratarNodo.obtenerNodos(UnsignedSignaturePropertiesElement, 
/* 129 */         nodoSigAndRefs, tagName);
/*     */       
/* 131 */       if (nodosCompleteRevocationRefs.size() != 1)
/*     */       {
/* 133 */         throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 134 */           " " + "CompleteRevocationRefs" + " " + 
/* 135 */           I18n.getResource("libreriaxades.firmaxml.error37") + " " + 
/* 136 */           nodosCompleteRevocationRefs.size());
/*     */       }
/* 138 */       resultado.addAll(nodosCompleteRevocationRefs);
/*     */       
/* 140 */       if ("http://uri.etsi.org/01903/v1.2.2#".equals(esquemaXADES))
/*     */       {
/*     */ 
/* 143 */         tagName = new NombreNodo(esquemaXADES, "AttributeCertificateRefs");
/* 144 */         ArrayList<Element> nodosAttributeCertificateRefs = UtilidadTratarNodo.obtenerNodos(UnsignedSignaturePropertiesElement, 
/* 145 */           nodoSigAndRefs, tagName);
/*     */         
/* 147 */         if (nodosAttributeCertificateRefs.size() > 1)
/*     */         {
/* 149 */           throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 150 */             " " + "AttributeCertificateRefs" + " " + 
/* 151 */             I18n.getResource("libreriaxades.firmaxml.error38") + " " + 
/* 152 */             nodosAttributeCertificateRefs.size());
/*     */         }
/*     */         
/* 155 */         if (nodosAttributeCertificateRefs.size() == 1) {
/* 156 */           resultado.addAll(nodosAttributeCertificateRefs);
/*     */         }
/*     */         
/* 159 */         tagName = new NombreNodo(esquemaXADES, "AttributeRevocationRefs");
/* 160 */         ArrayList<Element> nodosAttributeRevocationRefs = UtilidadTratarNodo.obtenerNodos(UnsignedSignaturePropertiesElement, 
/* 161 */           nodoSigAndRefs, tagName);
/*     */         
/* 163 */         if (nodosAttributeRevocationRefs.size() > 1)
/*     */         {
/* 165 */           throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 166 */             " " + "AttributeRevocationRefs" + " " + 
/* 167 */             I18n.getResource("libreriaxades.firmaxml.error38") + " " + 
/* 168 */             nodosAttributeRevocationRefs.size());
/*     */         }
/*     */         
/* 171 */         if (nodosAttributeRevocationRefs.size() == 1) {
/* 172 */           resultado.addAll(nodosAttributeRevocationRefs);
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 177 */       ArrayList<NombreNodo> nodosABuscar = new ArrayList();
/*     */       
/*     */ 
/* 180 */       nodosABuscar.add(new NombreNodo(esquemaXADES, "SignatureTimeStamp"));
/*     */       
/* 182 */       nodosABuscar.add(new NombreNodo(esquemaXADES, "CompleteCertificateRefs"));
/*     */       
/* 184 */       nodosABuscar.add(new NombreNodo(esquemaXADES, "CompleteRevocationRefs"));
/*     */       
/* 186 */       nodosABuscar.add(new NombreNodo(esquemaXADES, "AttributeCertificateRefs"));
/* 187 */       nodosABuscar.add(new NombreNodo(esquemaXADES, "AttributeRevocationRefs"));
/*     */       
/*     */ 
/* 190 */       ArrayList<Element> nodos = UtilidadTratarNodo.obtenerNodos(UnsignedSignaturePropertiesElement, 
/* 191 */         nodoSigAndRefs, nodosABuscar);
/*     */       
/* 193 */       resultado.addAll(nodos);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 198 */     int[] listaAparicion = new int[6];
/* 199 */     Iterator<Element> it = resultado.iterator();
/* 200 */     int indexAnterior = 0;
/* 201 */     while (it.hasNext()) {
/* 202 */       Element el = (Element)it.next();
/* 203 */       int index = NODOS_DE_X.indexOf(el.getLocalName());
/*     */       
/*     */ 
/*     */ 
/* 207 */       if (("http://uri.etsi.org/01903/v1.1.1#".equals(esquemaXADES)) || 
/* 208 */         ("http://uri.etsi.org/01903/v1.2.2#".equals(esquemaXADES)))
/*     */       {
/* 210 */         if (index < indexAnterior)
/*     */         {
/* 212 */           throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error39"));
/*     */         }
/* 214 */         indexAnterior = index;
/*     */       }
/*     */       
/* 217 */       listaAparicion[index] += 1;
/*     */     }
/* 219 */     if ((listaAparicion[0] != 1) || (listaAparicion[1] < 1) || (listaAparicion[2] != 1) || 
/* 220 */       (listaAparicion[3] != 1) || (listaAparicion[4] > 1) || (listaAparicion[5] > 1))
/*     */     {
/* 222 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error39"));
/*     */     }
/*     */     
/* 225 */     return resultado;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ArrayList<Element> obtenerListadoXADESX2exp(String esquemaXADES, Element firma, Element nodoRefsOnly)
/*     */     throws BadFormedSignatureException, FirmaXMLError
/*     */   {
/* 249 */     ArrayList<Element> resultado = new ArrayList();
/*     */     
/*     */ 
/* 252 */     Element UnsignedSignaturePropertiesElement = (Element)nodoRefsOnly.getParentNode();
/*     */     
/*     */ 
/* 255 */     if (!new NombreNodo(esquemaXADES, "UnsignedSignatureProperties").equals(new NombreNodo(UnsignedSignaturePropertiesElement.getNamespaceURI(), UnsignedSignaturePropertiesElement.getLocalName())))
/*     */     {
/* 257 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error40") + 
/* 258 */         " " + "RefsOnlyTimeStamp" + " " + 
/* 259 */         I18n.getResource("libreriaxades.firmaxml.error42"));
/*     */     }
/*     */     
/*     */ 
/* 263 */     if (("http://uri.etsi.org/01903/v1.3.2#".equals(esquemaXADES)) || 
/* 264 */       ("http://uri.etsi.org/01903/v1.1.1#".equals(esquemaXADES)))
/*     */     {
/*     */ 
/* 267 */       NombreNodo tagName = new NombreNodo(esquemaXADES, "CompleteCertificateRefs");
/* 268 */       ArrayList<Element> nodosCompleteCertificateRefs = UtilidadTratarNodo.obtenerNodos(UnsignedSignaturePropertiesElement, 
/* 269 */         nodoRefsOnly, tagName);
/*     */       
/* 271 */       if (nodosCompleteCertificateRefs.size() != 1)
/*     */       {
/* 273 */         throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 274 */           " " + "CompleteCertificateRefs" + " " + 
/* 275 */           I18n.getResource("libreriaxades.firmaxml.error37") + " " + 
/* 276 */           nodosCompleteCertificateRefs.size());
/*     */       }
/* 278 */       resultado.addAll(nodosCompleteCertificateRefs);
/*     */       
/*     */ 
/* 281 */       tagName = new NombreNodo(esquemaXADES, "CompleteRevocationRefs");
/* 282 */       ArrayList<Element> nodosCompleteRevocationRefs = UtilidadTratarNodo.obtenerNodos(UnsignedSignaturePropertiesElement, 
/* 283 */         nodoRefsOnly, tagName);
/*     */       
/* 285 */       if (nodosCompleteRevocationRefs.size() != 1)
/*     */       {
/* 287 */         throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 288 */           " " + "CompleteRevocationRefs" + " " + 
/* 289 */           I18n.getResource("libreriaxades.firmaxml.error37") + " " + 
/* 290 */           nodosCompleteRevocationRefs.size());
/*     */       }
/* 292 */       resultado.addAll(nodosCompleteRevocationRefs);
/*     */       
/* 294 */       if ("http://uri.etsi.org/01903/v1.2.2#".equals(esquemaXADES))
/*     */       {
/*     */ 
/* 297 */         tagName = new NombreNodo(esquemaXADES, "AttributeCertificateRefs");
/* 298 */         ArrayList<Element> nodosAttributeCertificateRefs = UtilidadTratarNodo.obtenerNodos(UnsignedSignaturePropertiesElement, 
/* 299 */           nodoRefsOnly, tagName);
/*     */         
/* 301 */         if (nodosAttributeCertificateRefs.size() > 1)
/*     */         {
/* 303 */           throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 304 */             " " + "AttributeCertificateRefs" + " " + 
/* 305 */             I18n.getResource("libreriaxades.firmaxml.error38") + " " + 
/* 306 */             nodosAttributeCertificateRefs.size());
/*     */         }
/*     */         
/* 309 */         if (nodosAttributeCertificateRefs.size() == 1) {
/* 310 */           resultado.addAll(nodosAttributeCertificateRefs);
/*     */         }
/*     */         
/* 313 */         tagName = new NombreNodo(esquemaXADES, "AttributeRevocationRefs");
/* 314 */         ArrayList<Element> nodosAttributeRevocationRefs = UtilidadTratarNodo.obtenerNodos(UnsignedSignaturePropertiesElement, 
/* 315 */           nodoRefsOnly, tagName);
/*     */         
/* 317 */         if (nodosAttributeRevocationRefs.size() > 1)
/*     */         {
/* 319 */           throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error36") + 
/* 320 */             " " + "AttributeRevocationRefs" + " " + 
/* 321 */             I18n.getResource("libreriaxades.firmaxml.error38") + " " + 
/* 322 */             nodosAttributeRevocationRefs.size());
/*     */         }
/*     */         
/* 325 */         if (nodosAttributeRevocationRefs.size() == 1) {
/* 326 */           resultado.addAll(nodosAttributeRevocationRefs);
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 331 */       ArrayList<NombreNodo> nodosABuscar = new ArrayList();
/*     */       
/*     */ 
/* 334 */       nodosABuscar.add(new NombreNodo(esquemaXADES, "CompleteCertificateRefs"));
/*     */       
/* 336 */       nodosABuscar.add(new NombreNodo(esquemaXADES, "CompleteRevocationRefs"));
/*     */       
/* 338 */       nodosABuscar.add(new NombreNodo(esquemaXADES, "AttributeCertificateRefs"));
/* 339 */       nodosABuscar.add(new NombreNodo(esquemaXADES, "AttributeRevocationRefs"));
/*     */       
/*     */ 
/* 342 */       ArrayList<Element> nodos = UtilidadTratarNodo.obtenerNodos(UnsignedSignaturePropertiesElement, 
/* 343 */         nodoRefsOnly, nodosABuscar);
/*     */       
/* 345 */       resultado.addAll(nodos);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 350 */     int[] listaAparicion = new int[6];
/* 351 */     Iterator<Element> it = resultado.iterator();
/* 352 */     int indexAnterior = 0;
/* 353 */     while (it.hasNext()) {
/* 354 */       Element el = (Element)it.next();
/* 355 */       int index = NODOS_DE_X.indexOf(el.getLocalName());
/*     */       
/*     */ 
/*     */ 
/* 359 */       if (("http://uri.etsi.org/01903/v1.1.1#".equals(esquemaXADES)) || 
/* 360 */         ("http://uri.etsi.org/01903/v1.2.2#".equals(esquemaXADES)))
/*     */       {
/* 362 */         if (index < indexAnterior)
/*     */         {
/* 364 */           throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error39"));
/*     */         }
/* 366 */         indexAnterior = index;
/*     */       }
/*     */       
/* 369 */       listaAparicion[index] += 1;
/*     */     }
/*     */     
/* 372 */     if ((listaAparicion[0] != 0) || (listaAparicion[1] != 0) || (listaAparicion[2] != 1) || 
/* 373 */       (listaAparicion[3] != 1) || (listaAparicion[4] > 1) || (listaAparicion[5] > 1))
/*     */     {
/* 375 */       throw new BadFormedSignatureException(I18n.getResource("libreriaxades.firmaxml.error39"));
/*     */     }
/*     */     
/* 378 */     return resultado;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\UtilidadXadesX.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */