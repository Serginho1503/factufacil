/*    */ package es.mityc.firmaJava.libreria.excepciones;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AddXadesException
/*    */   extends Exception
/*    */ {
/*    */   public AddXadesException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public AddXadesException(String message)
/*    */   {
/* 35 */     super(message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public AddXadesException(Throwable cause)
/*    */   {
/* 42 */     super(cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public AddXadesException(String message, Throwable cause)
/*    */   {
/* 50 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\excepciones\AddXadesException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */