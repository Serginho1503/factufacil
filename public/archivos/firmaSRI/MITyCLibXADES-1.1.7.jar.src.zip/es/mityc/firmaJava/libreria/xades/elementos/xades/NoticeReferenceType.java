/*     */ package es.mityc.firmaJava.libreria.xades.elementos.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NoticeReferenceType
/*     */   extends AbstractXADESElement
/*     */ {
/*     */   private Organization organization;
/*     */   private NoticeNumbers noticeNumbers;
/*     */   
/*     */   public NoticeReferenceType(XAdESSchemas schema)
/*     */   {
/*  39 */     super(schema);
/*     */   }
/*     */   
/*     */   public NoticeReferenceType(XAdESSchemas schema, String organization, int[] numbers) {
/*  43 */     super(schema);
/*  44 */     this.organization = new Organization(schema, organization);
/*  45 */     this.noticeNumbers = new NoticeNumbers(schema, numbers);
/*     */   }
/*     */   
/*     */   public Organization getOrganization() {
/*  49 */     return this.organization;
/*     */   }
/*     */   
/*     */   public void setOrganization(Organization organization) {
/*  53 */     this.organization = organization;
/*     */   }
/*     */   
/*     */   public void setOrganization(String organization) {
/*  57 */     this.organization = new Organization(this.schema, organization);
/*     */   }
/*     */   
/*     */   public NoticeNumbers getNoticeNumbers() {
/*  61 */     return this.noticeNumbers;
/*     */   }
/*     */   
/*     */   public void setNoticeNumbers(NoticeNumbers noticeNumbers) {
/*  65 */     this.noticeNumbers = noticeNumbers;
/*     */   }
/*     */   
/*     */   public void setNoticeNumbers(int[] noticeNumbers) {
/*  69 */     this.noticeNumbers = new NoticeNumbers(this.schema, noticeNumbers);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  77 */     if ((obj instanceof NoticeReferenceType)) {
/*  78 */       NoticeReferenceType cvt = (NoticeReferenceType)obj;
/*  79 */       if ((this.organization == null) || (this.noticeNumbers == null))
/*  80 */         return false;
/*  81 */       if (!this.organization.equals(cvt.organization))
/*  82 */         return false;
/*  83 */       if (!this.noticeNumbers.equals(cvt.noticeNumbers))
/*  84 */         return false;
/*  85 */       return true;
/*     */     }
/*  87 */     return false;
/*     */   }
/*     */   
/*     */   public void addContent(Element element, String namespaceXAdES) throws InvalidInfoNodeException
/*     */   {
/*  92 */     super.addContent(element, namespaceXAdES);
/*     */   }
/*     */   
/*     */   protected void addContent(Element element) throws InvalidInfoNodeException
/*     */   {
/*  97 */     if ((this.organization == null) || (this.noticeNumbers == null)) {
/*  98 */       throw new InvalidInfoNodeException("Nodo NoticeReferenceType no tiene suficiente información");
/*     */     }
/* 100 */     element.appendChild(this.organization.createElement(element.getOwnerDocument(), this.namespaceXAdES));
/* 101 */     element.appendChild(this.noticeNumbers.createElement(element.getOwnerDocument(), this.namespaceXAdES));
/*     */   }
/*     */   
/*     */   public void load(Element element) throws InvalidInfoNodeException
/*     */   {
/* 106 */     Node node = getFirstNonvoidNode(element);
/* 107 */     if ((node == null) || (node.getNodeType() != 1))
/* 108 */       throw new InvalidInfoNodeException("Se esperaba elemento como hijo de NoticeReferenceType");
/* 109 */     Element child = (Element)node;
/*     */     
/* 111 */     Organization org = new Organization(this.schema);
/* 112 */     org.load(child);
/*     */     
/* 114 */     node = getNextNonvoidNode(child);
/* 115 */     if ((node == null) || (node.getNodeType() != 1))
/* 116 */       throw new InvalidInfoNodeException("Se esperaba elemento como hijo de NoticeReferenceType");
/* 117 */     child = (Element)node;
/* 118 */     NoticeNumbers nn = new NoticeNumbers(this.schema);
/* 119 */     nn.load(child);
/*     */     
/* 121 */     this.organization = org;
/* 122 */     this.noticeNumbers = nn;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\xades\elementos\xades\NoticeReferenceType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */