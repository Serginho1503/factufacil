/*     */ package es.mityc.firmaJava.libreria.utilidades;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.security.AccessController;
/*     */ import java.util.BitSet;
/*     */ import sun.security.action.GetPropertyAction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class URIEncoder
/*     */ {
/*     */   static BitSet dontNeedEncoding;
/*     */   static final int caseDiff = 32;
/*     */   
/*     */   static
/*     */   {
/*  84 */     dontNeedEncoding = new BitSet(256);
/*     */     
/*  86 */     for (int i = 97; i <= 122; i++) {
/*  87 */       dontNeedEncoding.set(i);
/*     */     }
/*  89 */     for (i = 65; i <= 90; i++) {
/*  90 */       dontNeedEncoding.set(i);
/*     */     }
/*  92 */     for (i = 48; i <= 57; i++) {
/*  93 */       dontNeedEncoding.set(i);
/*     */     }
/*     */     
/*     */ 
/*  97 */     dontNeedEncoding.set(95);
/*  98 */     dontNeedEncoding.set(45);
/*  99 */     dontNeedEncoding.set(33);
/* 100 */     dontNeedEncoding.set(46);
/* 101 */     dontNeedEncoding.set(126);
/* 102 */     dontNeedEncoding.set(39);
/* 103 */     dontNeedEncoding.set(40);
/* 104 */     dontNeedEncoding.set(41);
/* 105 */     dontNeedEncoding.set(42);
/* 106 */     dontNeedEncoding.set(44);
/* 107 */     dontNeedEncoding.set(59);
/* 108 */     dontNeedEncoding.set(58);
/* 109 */     dontNeedEncoding.set(36);
/* 110 */     dontNeedEncoding.set(38);
/* 111 */     dontNeedEncoding.set(43);
/* 112 */     dontNeedEncoding.set(61);
/* 113 */     dontNeedEncoding.set(63);
/* 114 */     dontNeedEncoding.set(47);
/* 115 */     dontNeedEncoding.set(91);
/* 116 */     dontNeedEncoding.set(93);
/* 117 */     dontNeedEncoding.set(64);
/*     */   }
/*     */   
/* 120 */   static String dfltEncName = (String)AccessController.doPrivileged(new GetPropertyAction("file.encoding"));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static String encode(String s)
/*     */   {
/* 142 */     String str = null;
/*     */     try
/*     */     {
/* 145 */       str = encode(s, dfltEncName);
/*     */     }
/*     */     catch (UnsupportedEncodingException localUnsupportedEncodingException) {}
/*     */     
/*     */ 
/* 150 */     return str;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encode(String s, String enc)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 178 */     boolean needToChange = false;
/* 179 */     boolean wroteUnencodedChar = false;
/* 180 */     int maxBytesPerChar = 10;
/* 181 */     StringBuffer out = new StringBuffer(s.length());
/* 182 */     ByteArrayOutputStream buf = new ByteArrayOutputStream(maxBytesPerChar);
/*     */     
/* 184 */     OutputStreamWriter writer = new OutputStreamWriter(buf, enc);
/*     */     
/* 186 */     for (int i = 0; i < s.length(); i++) {
/* 187 */       int c = s.charAt(i);
/*     */       
/* 189 */       if (dontNeedEncoding.get(c))
/*     */       {
/*     */ 
/* 192 */         out.append((char)c);
/* 193 */         wroteUnencodedChar = true;
/*     */       }
/*     */       else {
/*     */         try {
/* 197 */           if (wroteUnencodedChar) {
/* 198 */             writer = new OutputStreamWriter(buf, enc);
/* 199 */             wroteUnencodedChar = false;
/*     */           }
/* 201 */           writer.write(c);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 210 */           if ((c >= 55296) && (c <= 56319))
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/* 215 */             if (i + 1 < s.length()) {
/* 216 */               int d = s.charAt(i + 1);
/*     */               
/*     */ 
/*     */ 
/*     */ 
/* 221 */               if ((d >= 56320) && (d <= 57343))
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 227 */                 writer.write(d);
/* 228 */                 i++;
/*     */               }
/*     */             }
/*     */           }
/* 232 */           writer.flush();
/*     */         } catch (IOException e) {
/* 234 */           buf.reset();
/* 235 */           continue;
/*     */         }
/* 237 */         byte[] ba = buf.toByteArray();
/* 238 */         for (int j = 0; j < ba.length; j++) {
/* 239 */           out.append('%');
/* 240 */           char ch = Character.forDigit(ba[j] >> 4 & 0xF, 16);
/*     */           
/*     */ 
/* 243 */           if (Character.isLetter(ch)) {
/* 244 */             ch = (char)(ch - ' ');
/*     */           }
/* 246 */           out.append(ch);
/* 247 */           ch = Character.forDigit(ba[j] & 0xF, 16);
/* 248 */           if (Character.isLetter(ch)) {
/* 249 */             ch = (char)(ch - ' ');
/*     */           }
/* 251 */           out.append(ch);
/*     */         }
/* 253 */         buf.reset();
/* 254 */         needToChange = true;
/*     */       }
/*     */     }
/*     */     
/* 258 */     return needToChange ? out.toString() : s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String relativize(String base, String object)
/*     */   {
/* 269 */     String res = "";
/*     */     
/* 271 */     int i = base.indexOf("/");
/* 272 */     int j = object.indexOf("/");
/* 273 */     int l = 0;
/* 274 */     while ((i == j) && (i >= 0) && (object.startsWith(base.substring(0, i)))) {
/* 275 */       i = base.indexOf("/", i + 1);
/* 276 */       l = j + 1;
/* 277 */       j = object.indexOf("/", j + 1);
/*     */     }
/*     */     
/* 280 */     if ((i == -1) && (j >= 0)) {
/* 281 */       res = res.concat("./");
/*     */     }
/* 283 */     while (i >= 0) {
/* 284 */       i = base.indexOf("/", i + 1);
/* 285 */       res = res.concat("../");
/*     */     }
/*     */     
/* 288 */     res = res + object.substring(l);
/*     */     
/*     */ 
/* 291 */     res = res.replace("./", "");
/*     */     
/* 293 */     return res;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\libreria\utilidades\URIEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */