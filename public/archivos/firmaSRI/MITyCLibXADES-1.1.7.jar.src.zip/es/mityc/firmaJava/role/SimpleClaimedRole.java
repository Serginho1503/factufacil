/*    */ package es.mityc.firmaJava.role;
/*    */ 
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleClaimedRole
/*    */   implements IClaimedRole
/*    */ {
/*    */   private String text;
/*    */   
/*    */   public SimpleClaimedRole(String text)
/*    */   {
/* 32 */     this.text = text;
/*    */   }
/*    */   
/*    */   public Node createClaimedRoleContent(Document doc) {
/* 36 */     return doc.createTextNode(this.text);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\role\SimpleClaimedRole.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */