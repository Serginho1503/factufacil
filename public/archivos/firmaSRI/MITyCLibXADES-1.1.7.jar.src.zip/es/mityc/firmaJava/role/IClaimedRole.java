package es.mityc.firmaJava.role;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

public abstract interface IClaimedRole
{
  public abstract Node createClaimedRoleContent(Document paramDocument);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\role\IClaimedRole.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */