/*    */ package es.mityc.firmaJava.role;
/*    */ 
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XadesLabsClaimedRole
/*    */   implements IClaimedRole
/*    */ {
/*    */   private String type;
/*    */   private boolean executiveDirector;
/*    */   private boolean shareHolder;
/*    */   private boolean vendor;
/*    */   private boolean purchaser;
/*    */   private boolean engineer;
/*    */   
/*    */   public XadesLabsClaimedRole(String type)
/*    */   {
/* 38 */     this.type = type;
/*    */   }
/*    */   
/*    */   public void setExecutiveDirector(boolean executiveDirector)
/*    */   {
/* 43 */     this.executiveDirector = executiveDirector;
/*    */   }
/*    */   
/*    */   public void setShareHolder(boolean shareHolder) {
/* 47 */     this.shareHolder = shareHolder;
/*    */   }
/*    */   
/*    */   public void setVendor(boolean vendor) {
/* 51 */     this.vendor = vendor;
/*    */   }
/*    */   
/*    */   public void setPurchaser(boolean purchaser) {
/* 55 */     this.purchaser = purchaser;
/*    */   }
/*    */   
/*    */   public void setEngineer(boolean engineer) {
/* 59 */     this.engineer = engineer;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Node createClaimedRoleContent(Document doc)
/*    */   {
/* 66 */     Element root = doc.createElementNS("http://xadeslabs.com/xades", "xl:XadesLabs");
/* 67 */     root.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns:xl", "http://xadeslabs.com/xades");
/* 68 */     Element roles = doc.createElementNS("http://xadeslabs.com/xades", "xl:Roles");
/* 69 */     roles.setAttributeNS(null, "type", this.type);
/* 70 */     root.appendChild(roles);
/* 71 */     Element child = doc.createElementNS("http://xadeslabs.com/xades", "xl:ExecutiveDirector");
/* 72 */     child.appendChild(doc.createTextNode(Boolean.toString(this.executiveDirector)));
/* 73 */     roles.appendChild(child);
/* 74 */     child = doc.createElementNS("http://xadeslabs.com/xades", "xl:ShareHolder");
/* 75 */     child.appendChild(doc.createTextNode(Boolean.toString(this.shareHolder)));
/* 76 */     roles.appendChild(child);
/* 77 */     child = doc.createElementNS("http://xadeslabs.com/xades", "xl:Vendor");
/* 78 */     child.appendChild(doc.createTextNode(Boolean.toString(this.vendor)));
/* 79 */     roles.appendChild(child);
/* 80 */     child = doc.createElementNS("http://xadeslabs.com/xades", "xl:Purchaser");
/* 81 */     child.appendChild(doc.createTextNode(Boolean.toString(this.purchaser)));
/* 82 */     roles.appendChild(child);
/* 83 */     child = doc.createElementNS("http://xadeslabs.com/xades", "xl:Engineer");
/* 84 */     child.appendChild(doc.createTextNode(Boolean.toString(this.engineer)));
/* 85 */     roles.appendChild(child);
/* 86 */     return root;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\role\XadesLabsClaimedRole.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */