package es.mityc.firmaJava.trust;

public enum ConfianzaEnum
{
  NO_REVISADO,  SIN_CONFIANZA,  CA_CONFIANZA,  CON_CONFIANZA;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\firmaJava\trust\ConfianzaEnum.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */