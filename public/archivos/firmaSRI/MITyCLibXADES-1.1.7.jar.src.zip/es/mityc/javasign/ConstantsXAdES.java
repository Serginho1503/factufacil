package es.mityc.javasign;

public class ConstantsXAdES
{
  public static final String LIB_NAME = "MITyCLibXAdES";
  public static final String DEFAULT_NS_XMLSIG = "ds";
  public static final String DEFAULT_NS_XADES = "etsi";
  public static final String DEFAULT_XML_ENCODING = "UTF-8";
  public static final String I18N_SIGN_1 = "i18n.mityc.xades.sign.1";
  public static final String I18N_SIGN_2 = "i18n.mityc.xades.sign.2";
  public static final String I18N_SIGN_3 = "i18n.mityc.xades.sign.3";
  public static final String I18N_SIGN_4 = "i18n.mityc.xades.sign.4";
  public static final String I18N_SIGN_5 = "i18n.mityc.xades.sign.5";
  public static final String I18N_SIGN_6 = "i18n.mityc.xades.sign.6";
  public static final String I18N_SIGN_7 = "i18n.mityc.xades.sign.7";
  public static final String I18N_SIGN_8 = "i18n.mityc.xades.sign.8";
  public static final String I18N_SIGN_9 = "i18n.mityc.xades.sign.9";
  public static final String I18N_SIGN_10 = "i18n.mityc.xades.sign.10";
  public static final String I18N_SIGN_11 = "i18n.mityc.xades.sign.11";
  public static final String I18N_VALIDATE_TRUST_1 = "i18n.mityc.xades.validate.trust.1";
  public static final String I18N_VALIDATE_TRUST_2 = "i18n.mityc.xades.validate.trust.2";
  public static final String I18N_VALIDATE_TRUST_3 = "i18n.mityc.xades.validate.trust.3";
  public static final String I18N_VALIDATE_TRUST_4 = "i18n.mityc.xades.validate.trust.4";
  public static final String I18N_VALIDATE_1 = "i18n.mityc.xades.validate.1";
  public static final String I18N_VALIDATE_2 = "i18n.mityc.xades.validate.2";
  public static final String I18N_VALIDATE_3 = "i18n.mityc.xades.validate.3";
  public static final String I18N_VALIDATE_4 = "i18n.mityc.xades.validate.4";
  public static final String I18N_VALIDATE_5 = "i18n.mityc.xades.validate.5";
  public static final String I18N_VALIDATE_6 = "i18n.mityc.xades.validate.6";
  public static final String I18N_VALIDATE_7 = "i18n.mityc.xades.validate.7";
  public static final String I18N_VALIDATE_8 = "i18n.mityc.xades.validate.8";
  public static final String I18N_VALIDATE_9 = "i18n.mityc.xades.validate.9";
  public static final String I18N_VALIDATE_10 = "i18n.mityc.xades.validate.10";
  public static final String I18N_VALIDATE_11 = "i18n.mityc.xades.validate.11";
  public static final String I18N_VALIDATE_12 = "i18n.mityc.xades.validate.12";
  public static final String I18N_VALIDATE_13 = "i18n.mityc.xades.validate.13";
  public static final String I18N_VALIDATE_14 = "i18n.mityc.xades.validate.14";
  public static final String I18N_VALIDATE_15 = "i18n.mityc.xades.validate.15";
  public static final String I18N_VALIDATE_16 = "i18n.mityc.xades.validate.16";
  public static final String I18N_VALIDATE_17 = "i18n.mityc.xades.validate.17";
  public static final String I18N_VALIDATE_18 = "i18n.mityc.xades.validate.18";
  public static final String I18N_VALIDATE_19 = "i18n.mityc.xades.validate.19";
  public static final String I18N_VALIDATE_20 = "i18n.mityc.xades.validate.20";
  public static final String I18N_VALIDATE_21 = "i18n.mityc.xades.validate.21";
  public static final String I18N_POLICY_1 = "i18n.mityc.xades.policy.1";
  public static final String I18N_POLICY_2 = "i18n.mityc.xades.policy.2";
  public static final String I18N_UTILS_1 = "i18n.mityc.xades.utils.1";
  public static final String I18N_UTILS_2 = "i18n.mityc.xades.utils.2";
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\ConstantsXAdES.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */