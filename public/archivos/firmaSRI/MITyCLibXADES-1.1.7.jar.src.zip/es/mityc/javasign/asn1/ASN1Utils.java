/*    */ package es.mityc.javasign.asn1;
/*    */ 
/*    */ import es.mityc.javasign.certificate.OCSPResponderID;
/*    */ import es.mityc.javasign.i18n.I18nFactory;
/*    */ import es.mityc.javasign.i18n.II18nManager;
/*    */ import java.io.IOException;
/*    */ import javax.security.auth.x500.X500Principal;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.bouncycastle.asn1.ASN1OctetString;
/*    */ import org.bouncycastle.asn1.ASN1TaggedObject;
/*    */ import org.bouncycastle.asn1.ocsp.ResponderID;
/*    */ import org.bouncycastle.asn1.x509.X509Name;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ASN1Utils
/*    */ {
/* 41 */   private static Log LOG = LogFactory.getLog(ASN1Utils.class);
/*    */   
/* 43 */   private static II18nManager I18N = I18nFactory.getI18nManager("MITyCLibXAdES");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static OCSPResponderID getResponderID(ResponderID responder)
/*    */   {
/* 57 */     OCSPResponderID result = null;
/* 58 */     ASN1TaggedObject tagged = (ASN1TaggedObject)responder.toASN1Object();
/* 59 */     switch (tagged.getTagNo()) {
/*    */     case 1: 
/*    */       try {
/* 62 */         X509Name name = X509Name.getInstance(tagged.getObject());
/* 63 */         result = OCSPResponderID.getOCSPResponderID(new X500Principal(name.getEncoded()));
/*    */       } catch (IllegalArgumentException ex) {
/* 65 */         LOG.error(I18N.getLocalMessage("i18n.mityc.xades.utils.1", new Object[] { ex.getMessage() }));
/* 66 */         if (!LOG.isDebugEnabled()) break;
/* 67 */         LOG.debug("", ex);
/*    */       }
/*    */       catch (IOException ex) {
/* 70 */         LOG.error(I18N.getLocalMessage("i18n.mityc.xades.utils.1", new Object[] { ex.getMessage() }));
/* 71 */         if (!LOG.isDebugEnabled()) break; }
/* 72 */       LOG.debug("", ex);
/*    */       
/*    */ 
/* 75 */       break;
/*    */     case 2: 
/* 77 */       ASN1OctetString octect = (ASN1OctetString)tagged.getObject();
/* 78 */       result = OCSPResponderID.getOCSPResponderID(octect.getOctets());
/*    */     }
/*    */     
/* 81 */     return result;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\asn1\ASN1Utils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */