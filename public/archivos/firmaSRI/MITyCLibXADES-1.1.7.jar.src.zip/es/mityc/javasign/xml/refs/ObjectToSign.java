/*    */ package es.mityc.javasign.xml.refs;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.xades.elementos.xades.ObjectIdentifier;
/*    */ import java.net.URI;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectToSign
/*    */ {
/*    */   private AbstractObjectToSign objectToSign;
/*    */   private String id;
/* 32 */   private String description = null;
/* 33 */   private ObjectIdentifier objectIdentifier = null;
/* 34 */   private ExtraObjectData extraData = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ObjectToSign(AbstractObjectToSign objectToSign, String desc, ObjectIdentifier id, String mimeType, URI encoding)
/*    */   {
/* 47 */     this.objectToSign = objectToSign;
/* 48 */     this.description = desc;
/* 49 */     this.objectIdentifier = id;
/* 50 */     this.extraData = new ExtraObjectData(mimeType, encoding);
/*    */   }
/*    */   
/*    */   public void setObjectToSign(AbstractObjectToSign objectToSign) {
/* 54 */     this.objectToSign = objectToSign;
/*    */   }
/*    */   
/*    */   public AbstractObjectToSign getObjectToSign() {
/* 58 */     return this.objectToSign;
/*    */   }
/*    */   
/*    */   public String getDescription() {
/* 62 */     return this.description;
/*    */   }
/*    */   
/*    */   public void setDescription(String descripcion) {
/* 66 */     this.description = descripcion;
/*    */   }
/*    */   
/*    */   public ObjectIdentifier getObjectIdentifier() {
/* 70 */     return this.objectIdentifier;
/*    */   }
/*    */   
/*    */   public void setObjectIdentifier(ObjectIdentifier identificador) {
/* 74 */     this.objectIdentifier = identificador;
/*    */   }
/*    */   
/*    */   public String getMimeType() {
/* 78 */     return this.extraData.getMimeType();
/*    */   }
/*    */   
/*    */   public URI getEncoding() {
/* 82 */     return this.extraData.getEncoding();
/*    */   }
/*    */   
/*    */   public String getId() {
/* 86 */     return this.id;
/*    */   }
/*    */   
/*    */   public void setId(String id) {
/* 90 */     this.id = id;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\refs\ObjectToSign.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */