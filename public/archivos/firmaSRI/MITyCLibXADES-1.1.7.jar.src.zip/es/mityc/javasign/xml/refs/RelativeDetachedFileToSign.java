/*    */ package es.mityc.javasign.xml.refs;
/*    */ 
/*    */ import es.mityc.javasign.certificate.ElementNotFoundException;
/*    */ import es.mityc.javasign.certificate.IRecoverElements;
/*    */ import es.mityc.javasign.certificate.UnknownElementClassException;
/*    */ import java.io.File;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RelativeDetachedFileToSign
/*    */   extends AbstractObjectToSign
/*    */   implements IRecoverElements
/*    */ {
/*    */   private File file;
/*    */   
/*    */   public RelativeDetachedFileToSign(File file)
/*    */   {
/* 34 */     this.file = file;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public File getFile()
/*    */   {
/* 41 */     return this.file;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setFile(File file)
/*    */   {
/* 48 */     this.file = file;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getReferenceURI()
/*    */   {
/* 56 */     return "." + File.separator + this.file.getName();
/*    */   }
/*    */   
/*    */   public <T> T getElement(Map<String, Object> props, Class<T> elementClass)
/*    */     throws ElementNotFoundException, UnknownElementClassException
/*    */   {
/* 62 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\refs\RelativeDetachedFileToSign.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */