/*    */ package es.mityc.javasign.xml.refs;
/*    */ 
/*    */ import es.mityc.javasign.i18n.I18nFactory;
/*    */ import es.mityc.javasign.i18n.II18nManager;
/*    */ import es.mityc.javasign.xml.resolvers.IPrivateData;
/*    */ import es.mityc.javasign.xml.resolvers.MITyCResourceResolver;
/*    */ import es.mityc.javasign.xml.resolvers.ResolverPrivateData;
/*    */ import es.mityc.javasign.xml.transform.Transform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnknownExternObjectToSign
/*    */   extends AbstractObjectToSign
/*    */ {
/* 38 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibXAdES");
/*    */   
/*    */ 
/*    */   private String name;
/*    */   
/*    */   private IPrivateData digester;
/*    */   
/*    */ 
/*    */   public UnknownExternObjectToSign(String name, IPrivateData privateDataDigester)
/*    */   {
/* 48 */     this.name = name;
/* 49 */     this.digester = privateDataDigester;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getName()
/*    */   {
/* 57 */     return this.name;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public IPrivateData getDigester()
/*    */   {
/* 65 */     return this.digester;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void addTransform(Transform t)
/*    */   {
/* 73 */     throw new IllegalArgumentException(I18N.getLocalMessage("i18n.mityc.xades.sign.10"));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getReferenceURI()
/*    */   {
/* 81 */     return this.name;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public MITyCResourceResolver getResolver()
/*    */   {
/* 89 */     return new ResolverPrivateData(getDigester());
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\refs\UnknownExternObjectToSign.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */