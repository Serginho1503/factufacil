/*    */ package es.mityc.javasign.xml.resolvers;
/*    */ 
/*    */ import es.mityc.javasign.xml.XmlException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourceDataException
/*    */   extends XmlException
/*    */ {
/*    */   public ResourceDataException() {}
/*    */   
/*    */   public ResourceDataException(String message)
/*    */   {
/* 38 */     super(message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public ResourceDataException(Throwable cause)
/*    */   {
/* 45 */     super(cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ResourceDataException(String message, Throwable cause)
/*    */   {
/* 53 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\resolvers\ResourceDataException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */