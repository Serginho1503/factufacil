/*    */ package es.mityc.javasign.xml.transform;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.NodeList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XPathTransformData
/*    */   implements ITransformData
/*    */ {
/* 34 */   private List<String> paths = new ArrayList();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void addPath(String path)
/*    */   {
/* 41 */     this.paths.add(path);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public NodeList getExtraData(Document doc)
/*    */   {
/* 48 */     SimpleNodeList nl = null;
/* 49 */     if (this.paths.size() > 0) {
/* 50 */       nl = new SimpleNodeList();
/* 51 */       for (String path : this.paths) {
/* 52 */         Element pathElement = doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", "ds:XPath");
/* 53 */         pathElement.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns:ds", "http://www.w3.org/2000/09/xmldsig#");
/* 54 */         pathElement.setTextContent(path);
/* 55 */         nl.addNode(pathElement);
/*    */       }
/*    */     }
/* 58 */     return nl;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\transform\XPathTransformData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */