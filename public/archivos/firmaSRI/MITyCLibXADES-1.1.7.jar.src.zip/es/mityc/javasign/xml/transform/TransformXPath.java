/*    */ package es.mityc.javasign.xml.transform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransformXPath
/*    */   extends Transform
/*    */ {
/* 27 */   private XPathTransformData data = new XPathTransformData();
/*    */   
/*    */   public TransformXPath()
/*    */   {
/* 31 */     super("http://www.w3.org/TR/1999/REC-xpath-19991116", null);
/* 32 */     setTransformData(this.data);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void addPath(String path)
/*    */   {
/* 40 */     this.data.addPath(path);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\transform\TransformXPath.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */