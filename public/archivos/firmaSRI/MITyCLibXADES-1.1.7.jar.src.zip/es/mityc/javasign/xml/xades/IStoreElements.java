package es.mityc.javasign.xml.xades;

import es.mityc.javasign.certificate.ICertStatus;
import java.security.cert.X509Certificate;

public abstract interface IStoreElements
{
  public abstract void init(String paramString);
  
  public abstract String[] storeCertAndStatus(X509Certificate paramX509Certificate, ICertStatus paramICertStatus);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\xades\IStoreElements.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */