/*    */ package es.mityc.javasign.xml.xades.policy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PolicyException
/*    */   extends Exception
/*    */ {
/*    */   public PolicyException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PolicyException(String message)
/*    */   {
/* 33 */     super(message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public PolicyException(Throwable cause)
/*    */   {
/* 40 */     super(cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public PolicyException(String message, Throwable cause)
/*    */   {
/* 48 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\xades\policy\PolicyException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */