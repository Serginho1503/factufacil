/*    */ package es.mityc.javasign.xml;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XmlException
/*    */   extends Exception
/*    */ {
/*    */   public XmlException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public XmlException(String message)
/*    */   {
/* 34 */     super(message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public XmlException(Throwable cause)
/*    */   {
/* 41 */     super(cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public XmlException(String message, Throwable cause)
/*    */   {
/* 49 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\XmlException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */