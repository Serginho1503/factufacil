/*    */ package es.mityc.javasign.xml.transform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransformC14N11
/*    */   extends Transform
/*    */ {
/*    */   public TransformC14N11()
/*    */   {
/* 27 */     super("http://www.w3.org/2006/12/xml-c14n11", null);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\transform\TransformC14N11.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */