/*    */ package es.mityc.javasign.xml.resolvers;
/*    */ 
/*    */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*    */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolverException;
/*    */ import org.w3c.dom.Attr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResolverPrivateData
/*    */   extends MITyCResourceResolver
/*    */ {
/* 30 */   private static final String[] keys = { "digest.algorithm" };
/*    */   
/*    */ 
/*    */   private IPrivateData internalResolver;
/*    */   
/*    */ 
/*    */ 
/*    */   public ResolverPrivateData(IPrivateData internalResolver)
/*    */   {
/* 39 */     this.internalResolver = internalResolver;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean engineCanResolve(Attr uri, String BaseURI)
/*    */   {
/* 47 */     if (this.internalResolver == null) {
/* 48 */       return false;
/*    */     }
/* 50 */     return this.internalResolver.canDigest(uri.getValue(), BaseURI);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public XMLSignatureInput engineResolve(Attr uri, String BaseURI)
/*    */     throws ResourceResolverException
/*    */   {
/* 58 */     if (this.internalResolver == null) {
/* 59 */       throw new ResourceResolverException("", uri, BaseURI);
/*    */     }
/* 61 */     String algName = engineGetProperty("digest.algorithm");
/* 62 */     if (algName == null) {
/* 63 */       throw new ResourceResolverException("", uri, BaseURI);
/*    */     }
/*    */     try {
/* 66 */       byte[] data = this.internalResolver.getDigest(uri.getValue(), BaseURI, algName);
/* 67 */       return new XMLSignatureInput(data);
/*    */     }
/*    */     catch (ResourceDataException ex) {
/* 70 */       throw new ResourceResolverException("", uri, BaseURI);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean engineIsPrivateData()
/*    */   {
/* 79 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String[] engineGetPropertyKeys()
/*    */   {
/* 87 */     return keys;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\resolvers\ResolverPrivateData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */