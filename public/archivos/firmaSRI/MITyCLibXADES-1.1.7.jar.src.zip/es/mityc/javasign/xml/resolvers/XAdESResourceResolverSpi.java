/*    */ package es.mityc.javasign.xml.resolvers;
/*    */ 
/*    */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*    */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolverException;
/*    */ import java.io.InputStream;
/*    */ import org.w3c.dom.Attr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XAdESResourceResolverSpi
/*    */   extends MITyCResourceResolver
/*    */ {
/*    */   private IResourceData internalResolver;
/*    */   
/*    */   public XAdESResourceResolverSpi(IResourceData internalResolver)
/*    */   {
/* 39 */     this.internalResolver = internalResolver;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean engineCanResolve(Attr uri, String BaseURI)
/*    */   {
/* 47 */     if (this.internalResolver == null) {
/* 48 */       return false;
/*    */     }
/* 50 */     return this.internalResolver.canAccess(uri.getValue(), BaseURI);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public XMLSignatureInput engineResolve(Attr uri, String BaseURI)
/*    */     throws ResourceResolverException
/*    */   {
/* 58 */     if (this.internalResolver == null) {
/* 59 */       throw new ResourceResolverException("", uri, BaseURI);
/*    */     }
/*    */     try {
/* 62 */       Object dataAccess = this.internalResolver.getAccess(uri.getValue(), BaseURI);
/* 63 */       XMLSignatureInput xsi = null;
/* 64 */       if ((dataAccess instanceof InputStream)) {
/* 65 */         xsi = new XMLSignatureInput((InputStream)dataAccess);
/* 66 */       } else if ((dataAccess instanceof byte[])) {
/* 67 */         xsi = new XMLSignatureInput((byte[])dataAccess);
/*    */       } else {
/* 69 */         throw new ResourceResolverException("", uri, BaseURI);
/*    */       }
/* 71 */       return xsi;
/*    */     } catch (ResourceDataException ex) {
/* 73 */       throw new ResourceResolverException("", uri, BaseURI);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\resolvers\XAdESResourceResolverSpi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */