/*     */ package es.mityc.javasign.xml.refs;
/*     */ 
/*     */ import adsi.org.apache.xml.security.signature.ObjectContainer;
/*     */ import es.mityc.javasign.xml.resolvers.MITyCResourceResolver;
/*     */ import es.mityc.javasign.xml.transform.Transform;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.w3c.dom.Document;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractObjectToSign
/*     */ {
/*  37 */   private ArrayList<Transform> transforms = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addTransform(Transform t)
/*     */   {
/*  46 */     if (t != null) {
/*  47 */       boolean mustadd = true;
/*  48 */       String alg = t.getAlgorithm();
/*  49 */       if ((alg != null) && 
/*  50 */         ("http://www.w3.org/2000/09/xmldsig#enveloped-signature".equals(alg))) {
/*  51 */         for (Transform trans : this.transforms) {
/*  52 */           if (alg.equals(trans.getAlgorithm())) {
/*  53 */             mustadd = false;
/*  54 */             break;
/*     */           }
/*     */         }
/*     */       }
/*  58 */       if (mustadd) {
/*  59 */         this.transforms.add(t);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Transform> getTransforms()
/*     */   {
/*  70 */     return (List)this.transforms.clone();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String getReferenceURI();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getType()
/*     */   {
/*  85 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<ObjectContainer> getObjects(Document doc)
/*     */   {
/*  95 */     return new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MITyCResourceResolver getResolver()
/*     */   {
/* 104 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\refs\AbstractObjectToSign.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */