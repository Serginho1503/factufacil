/*     */ package es.mityc.javasign.xml.xades;
/*     */ 
/*     */ import adsi.org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.signature.Reference;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureException;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import adsi.org.apache.xml.security.transforms.InvalidTransformException;
/*     */ import adsi.org.apache.xml.security.transforms.TransformationException;
/*     */ import adsi.org.apache.xml.security.transforms.Transforms;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReferenceProxy
/*     */ {
/*     */   private Reference reference;
/*     */   
/*     */   public ReferenceProxy(Reference ref)
/*     */   {
/*  48 */     this.reference = ref;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getID()
/*     */   {
/*  56 */     return this.reference.getId();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getURI()
/*     */   {
/*  64 */     return this.reference.getURI();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<TransformProxy> getTransforms()
/*     */   {
/*  72 */     ArrayList<TransformProxy> proxys = new ArrayList();
/*  73 */     Transforms trans = null;
/*     */     try {
/*  75 */       trans = this.reference.getTransforms();
/*     */     }
/*     */     catch (XMLSignatureException localXMLSignatureException) {}catch (InvalidTransformException localInvalidTransformException) {}catch (TransformationException localTransformationException) {}catch (XMLSecurityException localXMLSecurityException) {}
/*     */     
/*     */ 
/*     */ 
/*  81 */     if (trans != null) {
/*  82 */       for (int i = 0; i < trans.getLength(); i++) {
/*     */         try {
/*  84 */           proxys.add(new TransformProxy(trans.item(i)));
/*     */         }
/*     */         catch (TransformationException localTransformationException1) {}
/*     */       }
/*     */     }
/*  89 */     return proxys;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getBytes()
/*     */   {
/*  97 */     byte[] data = null;
/*     */     try {
/*  99 */       XMLSignatureInput si = this.reference.getContentsAfterTransformation();
/* 100 */       data = si.getBytes();
/*     */     }
/*     */     catch (XMLSignatureException localXMLSignatureException) {}catch (CanonicalizationException localCanonicalizationException) {}catch (IOException localIOException) {}
/*     */     
/*     */ 
/* 105 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeToStream(OutputStream os)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 114 */       XMLSignatureInput si = this.reference.getContentsAfterTransformation();
/* 115 */       si.updateOutputStream(os);
/*     */     }
/*     */     catch (XMLSignatureException localXMLSignatureException) {}catch (CanonicalizationException localCanonicalizationException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element getElement()
/*     */   {
/* 126 */     return this.reference.getElement();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\xades\ReferenceProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */