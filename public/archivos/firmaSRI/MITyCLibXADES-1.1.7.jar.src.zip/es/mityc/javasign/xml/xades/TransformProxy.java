/*    */ package es.mityc.javasign.xml.xades;
/*    */ 
/*    */ import adsi.org.apache.xml.security.transforms.Transform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransformProxy
/*    */ {
/*    */   public static final String TRANSFORM_C14N_OMIT_COMMENTS = "http://www.w3.org/TR/2001/REC-xml-c14n-20010315";
/*    */   public static final String TRANSFORM_C14N_WITH_COMMENTS = "http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments";
/*    */   public static final String TRANSFORM_C14N11_OMIT_COMMENTS = "http://www.w3.org/2006/12/xml-c14n11";
/*    */   public static final String TRANSFORM_C14N11_WITH_COMMENTS = "http://www.w3.org/2006/12/xml-c14n11#WithComments";
/*    */   public static final String TRANSFORM_C14N_EXCL_OMIT_COMMENTS = "http://www.w3.org/2001/10/xml-exc-c14n#";
/*    */   public static final String TRANSFORM_C14N_EXCL_WITH_COMMENTS = "http://www.w3.org/2001/10/xml-exc-c14n#WithComments";
/*    */   public static final String TRANSFORM_XSLT = "http://www.w3.org/TR/1999/REC-xslt-19991116";
/*    */   public static final String TRANSFORM_BASE64_DECODE = "http://www.w3.org/2000/09/xmldsig#base64";
/*    */   public static final String TRANSFORM_XPATH = "http://www.w3.org/TR/1999/REC-xpath-19991116";
/*    */   public static final String TRANSFORM_ENVELOPED_SIGNATURE = "http://www.w3.org/2000/09/xmldsig#enveloped-signature";
/*    */   public static final String TRANSFORM_XPOINTER = "http://www.w3.org/TR/2001/WD-xptr-20010108";
/*    */   public static final String TRANSFORM_XPATH2FILTER04 = "http://www.w3.org/2002/04/xmldsig-filter2";
/*    */   public static final String TRANSFORM_XPATH2FILTER = "http://www.w3.org/2002/06/xmldsig-filter2";
/*    */   public static final String TRANSFORM_XPATHFILTERCHGP = "http://www.nue.et-inf.uni-siegen.de/~geuer-pollmann/#xpathFilter";
/*    */   private Transform transform;
/*    */   
/*    */   public TransformProxy(Transform ref)
/*    */   {
/* 51 */     this.transform = ref;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getURI()
/*    */   {
/* 59 */     return this.transform.getURI();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static boolean isCanonicalization(TransformProxy trans)
/*    */   {
/* 68 */     String uri = trans.getURI();
/* 69 */     if ((uri.equals("http://www.w3.org/TR/2001/REC-xml-c14n-20010315")) || 
/* 70 */       (uri.equals("http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments")) || 
/* 71 */       (uri.equals("http://www.w3.org/2006/12/xml-c14n11")) || 
/* 72 */       (uri.equals("http://www.w3.org/2006/12/xml-c14n11#WithComments")) || 
/* 73 */       (uri.equals("http://www.w3.org/2001/10/xml-exc-c14n#")) || 
/* 74 */       (uri.equals("http://www.w3.org/2001/10/xml-exc-c14n#WithComments"))) {
/* 75 */       return true;
/*    */     }
/* 77 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\xades\TransformProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */