package es.mityc.javasign.xml.resolvers;

import adsi.org.apache.xml.security.utils.resolver.ResourceResolverSpi;

public abstract class MITyCResourceResolver
  extends ResourceResolverSpi
{}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\resolvers\MITyCResourceResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */