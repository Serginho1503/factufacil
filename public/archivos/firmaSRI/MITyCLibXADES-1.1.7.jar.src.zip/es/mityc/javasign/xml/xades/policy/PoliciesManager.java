/*     */ package es.mityc.javasign.xml.xades.policy;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PoliciesManager
/*     */ {
/*     */   public class PolicyKey
/*     */   {
/*     */     public URI uri;
/*     */     public String hash;
/*     */     
/*     */     public PolicyKey(URI uri, String hash)
/*     */     {
/*  77 */       this.uri = uri;
/*  78 */       this.hash = hash;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PolicyKey newPolicyKey(URI uri, String hash)
/*     */   {
/*  89 */     return new PolicyKey(uri, hash);
/*     */   }
/*     */   
/*     */ 
/*  93 */   private static final Log logger = LogFactory.getLog(PoliciesManager.class);
/*     */   
/*  95 */   private static final II18nManager i18n = I18nFactory.getI18nManager("MITyCLibXAdES");
/*     */   
/*     */ 
/*     */ 
/*  99 */   private Properties props = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private PoliciesManager()
/*     */   {
/* 111 */     loadManagers();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void loadManagers()
/*     */   {
/* 119 */     ClassLoader cl = getClassLoader();
/*     */     try
/*     */     {
/* 122 */       ArrayList<URL> resources = new ArrayList();
/* 123 */       Enumeration<URL> en = cl.getResources("META-INF/xades/policy.properties");
/*     */       
/* 125 */       if ((en == null) || (!en.hasMoreElements())) {
/* 126 */         logger.error("No se pudo encontrar el fichero de configuración META-INF/xades/policy.properties");
/*     */       }
/*     */       
/* 129 */       URL element = null;
/* 130 */       while (en.hasMoreElements()) {
/* 131 */         element = (URL)en.nextElement();
/* 132 */         if (logger.isDebugEnabled()) {
/* 133 */           logger.debug("Configuración de política encontrado: " + element);
/*     */         }
/* 135 */         resources.add(0, element);
/*     */       }
/*     */       
/* 138 */       Properties base = null;
/* 139 */       Iterator<URL> itResources = resources.iterator();
/* 140 */       while (itResources.hasNext())
/*     */       {
/* 142 */         URL url = (URL)itResources.next();
/*     */         try {
/* 144 */           InputStream is = url.openStream();
/* 145 */           Properties properties = new Properties(base);
/* 146 */           properties.load(is);
/* 147 */           base = properties;
/*     */         } catch (IOException ex) {
/* 149 */           logger.error(i18n.getLocalMessage("i18n.mityc.xades.policy.2", new Object[] { url, ex.getMessage() }));
/*     */         }
/*     */       }
/* 152 */       this.props = base;
/*     */     } catch (IOException ex) {
/* 154 */       logger.error(i18n.getLocalMessage("i18n.mityc.xades.policy.1", new Object[] { ex.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */   private static ClassLoader getClassLoader()
/*     */   {
/*     */     try {
/* 161 */       ClassLoader cl = (ClassLoader)AccessController.doPrivileged(new PrivilegedAction() {
/*     */         public ClassLoader run() {
/* 163 */           ClassLoader classLoader = null;
/*     */           try {
/* 165 */             classLoader = Thread.currentThread().getContextClassLoader();
/*     */           }
/*     */           catch (SecurityException localSecurityException) {}
/* 168 */           return classLoader;
/*     */         } });
/* 170 */       if (cl != null) {
/* 171 */         return cl;
/*     */       }
/*     */     }
/*     */     catch (Exception localException) {}
/* 175 */     return PoliciesManager.class.getClassLoader();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 182 */   private static PoliciesManager instance = getInstance();
/*     */   
/*     */ 
/*     */   private static final String POLICY_FILE_CONF = "META-INF/xades/policy.properties";
/*     */   
/*     */ 
/*     */ 
/*     */   public static PoliciesManager getInstance()
/*     */   {
/* 191 */     if (instance == null) {
/* 192 */       instance = new PoliciesManager();
/*     */     }
/* 194 */     return instance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IValidacionPolicy getValidadorPolicy(PolicyKey clave)
/*     */   {
/* 207 */     return getValidadorPolicy(clave, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IValidacionPolicy getValidadorPolicy(PolicyKey clave, boolean defaultManager)
/*     */   {
/* 221 */     IValidacionPolicy policyManager = null;
/* 222 */     if (this.props != null) {
/*     */       try {
/* 224 */         String classname = this.props.getProperty(clave.hash);
/* 225 */         if (classname != null) {
/*     */           try {
/* 227 */             ClassLoader cl = getClassLoader();
/* 228 */             Class<?> manager = null;
/* 229 */             if (cl != null) {
/* 230 */               manager = cl.loadClass(classname);
/*     */             } else {
/* 232 */               manager = Class.forName(classname);
/*     */             }
/* 234 */             if (manager != null) {
/* 235 */               policyManager = (IValidacionPolicy)manager.newInstance();
/*     */             }
/*     */           } catch (InstantiationException e) {
/* 238 */             logger.warn("La clase asociada no se puede instanciar (" + clave.hash + ", " + classname + ")");
/* 239 */             if (logger.isDebugEnabled())
/* 240 */               logger.debug("", e);
/*     */           } catch (IllegalAccessException e) {
/* 242 */             logger.warn("No hay permisos para instanciar el validador (" + clave.hash + ", " + classname + ")");
/* 243 */             if (logger.isDebugEnabled())
/* 244 */               logger.debug("", e);
/*     */           } catch (ClassNotFoundException e) {
/* 246 */             logger.warn("La clase asociada al valor no se encuentra disponible (" + clave.hash + ", " + classname + ")");
/* 247 */             if (logger.isDebugEnabled())
/* 248 */               logger.debug("", e);
/*     */           } catch (ClassCastException e) {
/* 250 */             logger.warn("La clase asociada no es del tipo validador (" + clave.hash + " " + classname + ")");
/* 251 */             if (logger.isDebugEnabled()) {
/* 252 */               logger.debug("", e);
/*     */             }
/*     */           }
/* 255 */           if (policyManager == null)
/* 256 */             policyManager = new GeneralPolicyManager();
/*     */         }
/*     */       } catch (MissingResourceException ex) {
/* 259 */         logger.error("No hay validador de policy asociado a esa clave: " + clave);
/*     */       }
/*     */       
/* 262 */       if (policyManager == null)
/* 263 */         policyManager = new GeneralPolicyManager();
/*     */     }
/* 265 */     return policyManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IFirmaPolicy getEscritorPolicy(String clave)
/*     */   {
/* 278 */     IFirmaPolicy policyManager = null;
/* 279 */     if (this.props != null) {
/*     */       try {
/* 281 */         String classname = this.props.getProperty(clave.toLowerCase());
/* 282 */         if (classname != null) {
/*     */           try {
/* 284 */             ClassLoader cl = getClassLoader();
/* 285 */             Class<?> manager = null;
/* 286 */             if (cl != null) {
/* 287 */               manager = cl.loadClass(classname);
/*     */             } else {
/* 289 */               manager = Class.forName(classname);
/*     */             }
/* 291 */             if (manager == null) return policyManager;
/* 292 */             policyManager = (IFirmaPolicy)manager.newInstance();
/*     */           }
/*     */           catch (InstantiationException e) {
/* 295 */             logger.warn("La clase asociada no se puede instanciar (" + clave + ", " + classname + ")");
/* 296 */             if (!logger.isDebugEnabled()) return policyManager;
/* 297 */             logger.debug("", e);
/*     */           } catch (IllegalAccessException e) {
/* 299 */             logger.warn("No hay permisos para instanciar el validador (" + clave + ", " + classname + ")");
/* 300 */             if (!logger.isDebugEnabled()) return policyManager;
/* 301 */             logger.debug("", e);
/*     */           } catch (ClassNotFoundException e) {
/* 303 */             logger.warn("La clase asociada al valor no se encuentra disponible (" + clave + ", " + classname + ")");
/* 304 */             if (!logger.isDebugEnabled()) return policyManager;
/* 305 */             logger.debug("", e);
/*     */           } catch (ClassCastException e) {
/* 307 */             logger.warn("La clase asociada no es del tipo validador (" + clave + " " + classname + ")");
/* 308 */             if (!logger.isDebugEnabled()) return policyManager; }
/* 309 */           logger.debug("", e);
/*     */         }
/*     */       }
/*     */       catch (MissingResourceException ex) {
/* 313 */         logger.error("No hay validador de policy asociado a esa clave: " + clave);
/*     */       }
/*     */     }
/* 316 */     return policyManager;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\xades\policy\PoliciesManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */