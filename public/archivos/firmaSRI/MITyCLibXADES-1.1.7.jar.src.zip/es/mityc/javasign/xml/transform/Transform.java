/*    */ package es.mityc.javasign.xml.transform;
/*    */ 
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.NodeList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Transform
/*    */ {
/*    */   private String algorithm;
/*    */   private ITransformData data;
/*    */   
/*    */   public Transform(String alg, ITransformData extraData)
/*    */   {
/* 39 */     this.algorithm = alg;
/* 40 */     this.data = extraData;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void setTransformData(ITransformData extraData)
/*    */   {
/* 48 */     this.data = extraData;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getAlgorithm()
/*    */   {
/* 56 */     return this.algorithm;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public NodeList getExtraData(Document doc)
/*    */   {
/* 65 */     NodeList nl = null;
/* 66 */     if (this.data != null) {
/* 67 */       nl = this.data.getExtraData(doc);
/*    */     }
/* 69 */     return nl;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\transform\Transform.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */