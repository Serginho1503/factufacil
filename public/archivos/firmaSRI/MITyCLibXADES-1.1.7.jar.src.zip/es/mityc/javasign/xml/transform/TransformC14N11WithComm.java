/*    */ package es.mityc.javasign.xml.transform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransformC14N11WithComm
/*    */   extends Transform
/*    */ {
/*    */   public TransformC14N11WithComm()
/*    */   {
/* 27 */     super("http://www.w3.org/2006/12/xml-c14n11#WithComments", null);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\transform\TransformC14N11WithComm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */