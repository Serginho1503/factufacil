package es.mityc.javasign.xml.resolvers;

public abstract interface IResourceData
{
  public abstract Object getAccess(String paramString1, String paramString2)
    throws ResourceDataException;
  
  public abstract boolean canAccess(String paramString1, String paramString2);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\resolvers\IResourceData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */