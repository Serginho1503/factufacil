/*    */ package es.mityc.javasign.xml.refs;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.utilidades.UtilidadFicheros;
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExternFileToSign
/*    */   extends AbstractObjectToSign
/*    */ {
/*    */   private File file;
/*    */   private String base;
/*    */   
/*    */   public ExternFileToSign(File file, String baseUri)
/*    */   {
/* 34 */     this.file = file;
/* 35 */     this.base = baseUri;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public File getFile()
/*    */   {
/* 42 */     return this.file;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setFile(File file)
/*    */   {
/* 49 */     this.file = file;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getReferenceURI()
/*    */   {
/* 57 */     return UtilidadFicheros.relativizeRute(this.base, this.file);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\refs\ExternFileToSign.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */