/*     */ package es.mityc.javasign.xml.xades;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.utilidades.UtilidadFicheros;
/*     */ import es.mityc.javasign.certificate.AbstractCertStatus;
/*     */ import es.mityc.javasign.certificate.ElementNotFoundException;
/*     */ import es.mityc.javasign.certificate.ICertStatus;
/*     */ import es.mityc.javasign.certificate.IOCSPCertStatus;
/*     */ import es.mityc.javasign.certificate.IOCSPCertStatus.TYPE_RESPONDER;
/*     */ import es.mityc.javasign.certificate.IRecoverElements;
/*     */ import es.mityc.javasign.certificate.IX509CRLCertStatus;
/*     */ import es.mityc.javasign.certificate.OCSPResponderID;
/*     */ import es.mityc.javasign.certificate.UnknownElementClassException;
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import java.io.File;
/*     */ import java.math.BigInteger;
/*     */ import java.net.URI;
/*     */ import java.security.cert.CertificateEncodingException;
/*     */ import java.security.cert.X509CRL;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ import java.util.zip.Adler32;
/*     */ import java.util.zip.Checksum;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalFileStoreElements
/*     */   implements IStoreElements, IRecoverElements
/*     */ {
/*  70 */   private static Log log = LogFactory.getLog(LocalFileStoreElements.class);
/*  71 */   private static II18nManager i18n = I18nFactory.getI18nManager("MITyCLibXAdES");
/*     */   private static final String PREFIX_CERT = "cert-";
/*     */   private static final String EXT_CERT = ".cer";
/*     */   private static final String PREFIX_OCSP = "ocsp-";
/*     */   private static final String EXT_OCSP = ".ors";
/*     */   private static final String PREFIX_CRL = "crl-";
/*     */   private static final String EXT_CRL = ".crl";
/*     */   
/*     */   private class OCSPResp extends AbstractCertStatus implements IOCSPCertStatus {
/*     */     private byte[] data;
/*     */     
/*     */     private OCSPResp(byte[] data) {
/*  83 */       this.data = data;
/*     */     }
/*     */     
/*     */     public byte[] getEncoded() {
/*  87 */       return this.data;
/*     */     }
/*     */     
/*     */ 
/*     */     public String getResponderID()
/*     */     {
/*  93 */       throw new UnsupportedOperationException("Not implemented yet");
/*     */     }
/*     */     
/*     */ 
/*     */     public IOCSPCertStatus.TYPE_RESPONDER getResponderType()
/*     */     {
/*  99 */       throw new UnsupportedOperationException("Not implemented yet");
/*     */     }
/*     */     
/*     */ 
/*     */     public Date getResponseDate()
/*     */     {
/* 105 */       throw new UnsupportedOperationException("Not implemented yet");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/* 110 */   private URI base = null;
/*     */   
/* 112 */   private static ThreadLocal<Adler32> digester = new ThreadLocal()
/*     */   {
/*     */     protected Adler32 initialValue() {
/* 115 */       return new Adler32();
/*     */     }
/*     */   };
/*     */   
/*     */   public LocalFileStoreElements()
/*     */   {
/* 121 */     init(null);
/*     */   }
/*     */   
/*     */   public LocalFileStoreElements(String base) {
/* 125 */     init(base);
/*     */   }
/*     */   
/*     */   private URI getWorkdir()
/*     */   {
/* 130 */     return new File(".").toURI();
/*     */   }
/*     */   
/*     */   public void init(String base) {
/* 134 */     if ((base == null) || (base.trim().length() == 0)) {
/* 135 */       this.base = getWorkdir();
/*     */     } else {
/*     */       try {
/* 138 */         this.base = URI.create(base);
/*     */       } catch (IllegalArgumentException ex) {
/* 140 */         log.error(i18n.getLocalMessage("i18n.mityc.xades.sign.5", new Object[] { ex.getMessage() }));
/* 141 */         this.base = getWorkdir();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private void saveData(File file, byte[] data)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_3
/*     */     //   2: new 131	java/io/FileOutputStream
/*     */     //   5: dup
/*     */     //   6: aload_1
/*     */     //   7: invokespecial 133	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
/*     */     //   10: astore_3
/*     */     //   11: aload_3
/*     */     //   12: aload_2
/*     */     //   13: invokevirtual 136	java/io/FileOutputStream:write	([B)V
/*     */     //   16: goto +143 -> 159
/*     */     //   19: astore 4
/*     */     //   21: getstatic 48	es/mityc/javasign/xml/xades/LocalFileStoreElements:log	Lorg/apache/commons/logging/Log;
/*     */     //   24: getstatic 58	es/mityc/javasign/xml/xades/LocalFileStoreElements:i18n	Les/mityc/javasign/i18n/II18nManager;
/*     */     //   27: ldc -116
/*     */     //   29: iconst_2
/*     */     //   30: anewarray 3	java/lang/Object
/*     */     //   33: dup
/*     */     //   34: iconst_0
/*     */     //   35: aload 4
/*     */     //   37: invokevirtual 142	java/io/FileNotFoundException:getMessage	()Ljava/lang/String;
/*     */     //   40: aastore
/*     */     //   41: dup
/*     */     //   42: iconst_1
/*     */     //   43: aload_1
/*     */     //   44: invokevirtual 145	java/io/File:getAbsolutePath	()Ljava/lang/String;
/*     */     //   47: aastore
/*     */     //   48: invokeinterface 114 3 0
/*     */     //   53: invokeinterface 120 2 0
/*     */     //   58: aload_3
/*     */     //   59: ifnull +117 -> 176
/*     */     //   62: aload_3
/*     */     //   63: invokevirtual 148	java/io/FileOutputStream:flush	()V
/*     */     //   66: aload_3
/*     */     //   67: invokevirtual 151	java/io/FileOutputStream:close	()V
/*     */     //   70: goto +106 -> 176
/*     */     //   73: astore 6
/*     */     //   75: goto +101 -> 176
/*     */     //   78: astore 4
/*     */     //   80: getstatic 48	es/mityc/javasign/xml/xades/LocalFileStoreElements:log	Lorg/apache/commons/logging/Log;
/*     */     //   83: getstatic 58	es/mityc/javasign/xml/xades/LocalFileStoreElements:i18n	Les/mityc/javasign/i18n/II18nManager;
/*     */     //   86: ldc -116
/*     */     //   88: iconst_2
/*     */     //   89: anewarray 3	java/lang/Object
/*     */     //   92: dup
/*     */     //   93: iconst_0
/*     */     //   94: aload 4
/*     */     //   96: invokevirtual 154	java/io/IOException:getMessage	()Ljava/lang/String;
/*     */     //   99: aastore
/*     */     //   100: dup
/*     */     //   101: iconst_1
/*     */     //   102: aload_1
/*     */     //   103: invokevirtual 145	java/io/File:getAbsolutePath	()Ljava/lang/String;
/*     */     //   106: aastore
/*     */     //   107: invokeinterface 114 3 0
/*     */     //   112: invokeinterface 120 2 0
/*     */     //   117: aload_3
/*     */     //   118: ifnull +58 -> 176
/*     */     //   121: aload_3
/*     */     //   122: invokevirtual 148	java/io/FileOutputStream:flush	()V
/*     */     //   125: aload_3
/*     */     //   126: invokevirtual 151	java/io/FileOutputStream:close	()V
/*     */     //   129: goto +47 -> 176
/*     */     //   132: astore 6
/*     */     //   134: goto +42 -> 176
/*     */     //   137: astore 5
/*     */     //   139: aload_3
/*     */     //   140: ifnull +16 -> 156
/*     */     //   143: aload_3
/*     */     //   144: invokevirtual 148	java/io/FileOutputStream:flush	()V
/*     */     //   147: aload_3
/*     */     //   148: invokevirtual 151	java/io/FileOutputStream:close	()V
/*     */     //   151: goto +5 -> 156
/*     */     //   154: astore 6
/*     */     //   156: aload 5
/*     */     //   158: athrow
/*     */     //   159: aload_3
/*     */     //   160: ifnull +16 -> 176
/*     */     //   163: aload_3
/*     */     //   164: invokevirtual 148	java/io/FileOutputStream:flush	()V
/*     */     //   167: aload_3
/*     */     //   168: invokevirtual 151	java/io/FileOutputStream:close	()V
/*     */     //   171: goto +5 -> 176
/*     */     //   174: astore 6
/*     */     //   176: return
/*     */     // Line number table:
/*     */     //   Java source line #147	-> byte code offset #0
/*     */     //   Java source line #149	-> byte code offset #2
/*     */     //   Java source line #150	-> byte code offset #11
/*     */     //   Java source line #151	-> byte code offset #16
/*     */     //   Java source line #152	-> byte code offset #21
/*     */     //   Java source line #156	-> byte code offset #58
/*     */     //   Java source line #158	-> byte code offset #62
/*     */     //   Java source line #159	-> byte code offset #66
/*     */     //   Java source line #160	-> byte code offset #70
/*     */     //   Java source line #153	-> byte code offset #78
/*     */     //   Java source line #154	-> byte code offset #80
/*     */     //   Java source line #156	-> byte code offset #117
/*     */     //   Java source line #158	-> byte code offset #121
/*     */     //   Java source line #159	-> byte code offset #125
/*     */     //   Java source line #160	-> byte code offset #129
/*     */     //   Java source line #155	-> byte code offset #137
/*     */     //   Java source line #156	-> byte code offset #139
/*     */     //   Java source line #158	-> byte code offset #143
/*     */     //   Java source line #159	-> byte code offset #147
/*     */     //   Java source line #160	-> byte code offset #151
/*     */     //   Java source line #163	-> byte code offset #156
/*     */     //   Java source line #156	-> byte code offset #159
/*     */     //   Java source line #158	-> byte code offset #163
/*     */     //   Java source line #159	-> byte code offset #167
/*     */     //   Java source line #160	-> byte code offset #171
/*     */     //   Java source line #164	-> byte code offset #176
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	177	0	this	LocalFileStoreElements
/*     */     //   0	177	1	file	File
/*     */     //   0	177	2	data	byte[]
/*     */     //   1	167	3	fos	java.io.FileOutputStream
/*     */     //   19	17	4	ex	java.io.FileNotFoundException
/*     */     //   78	17	4	ex	java.io.IOException
/*     */     //   137	20	5	localObject	Object
/*     */     //   73	1	6	localIOException1	java.io.IOException
/*     */     //   132	1	6	localIOException2	java.io.IOException
/*     */     //   154	1	6	localIOException3	java.io.IOException
/*     */     //   174	1	6	localIOException4	java.io.IOException
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   2	16	19	java/io/FileNotFoundException
/*     */     //   62	70	73	java/io/IOException
/*     */     //   2	16	78	java/io/IOException
/*     */     //   121	129	132	java/io/IOException
/*     */     //   2	58	137	finally
/*     */     //   78	117	137	finally
/*     */     //   143	151	154	java/io/IOException
/*     */     //   163	171	174	java/io/IOException
/*     */   }
/*     */   
/*     */   private long digest(byte[] data)
/*     */   {
/* 167 */     Checksum digest = (Checksum)digester.get();
/* 168 */     digest.reset();
/* 169 */     digest.update(data, 0, data.length);
/* 170 */     return digest.getValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] storeCertAndStatus(X509Certificate certificate, ICertStatus certStatus)
/*     */   {
/* 188 */     String[] names = new String[2];
/* 189 */     File dir = new File(this.base);
/* 190 */     if ((!dir.exists()) && 
/* 191 */       (!dir.mkdirs())) {
/* 192 */       return names;
/*     */     }
/*     */     
/*     */ 
/* 196 */     if (certificate != null) {
/*     */       try
/*     */       {
/* 199 */         byte[] data = certificate.getEncoded();
/* 200 */         String nameCert = "cert-" + Long.toHexString(digest(data)) + ".cer";
/*     */         
/* 202 */         File certFile = new File(dir, nameCert);
/* 203 */         saveData(certFile, data);
/* 204 */         names[0] = certFile.getName();
/*     */       } catch (CertificateEncodingException ex) {
/* 206 */         log.error(i18n.getLocalMessage("i18n.mityc.xades.sign.6", new Object[] { ex.getMessage() }));
/*     */       }
/*     */     }
/*     */     
/* 210 */     if (certStatus != null) {
/* 211 */       if ((certStatus instanceof IOCSPCertStatus)) {
/* 212 */         IOCSPCertStatus respOcsp = (IOCSPCertStatus)certStatus;
/*     */         
/* 214 */         byte[] data = respOcsp.getEncoded();
/* 215 */         String ocspName = "ocsp-" + Long.toHexString(digest(data)) + ".ors";
/*     */         
/* 217 */         File ocspFile = new File(dir, ocspName);
/* 218 */         saveData(ocspFile, data);
/* 219 */         names[1] = ocspFile.getName();
/* 220 */       } else if ((certStatus instanceof IX509CRLCertStatus)) {
/* 221 */         IX509CRLCertStatus respCRL = (IX509CRLCertStatus)certStatus;
/*     */         
/* 223 */         byte[] data = respCRL.getEncoded();
/* 224 */         String crlName = "crl-" + Long.toHexString(digest(data)) + ".crl";
/*     */         
/* 226 */         File crlFile = new File(dir, crlName);
/* 227 */         saveData(crlFile, data);
/* 228 */         names[1] = crlFile.getName();
/*     */       }
/*     */     }
/* 231 */     return names;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> T getElement(Map<String, Object> props, Class<T> elementClass)
/*     */     throws ElementNotFoundException, UnknownElementClassException
/*     */   {
/* 254 */     if (X509Certificate.class.isAssignableFrom(elementClass)) {
/* 255 */       X509Certificate cert = getCertificate(props);
/* 256 */       if (cert != null) {
/* 257 */         return cert;
/*     */       }
/* 259 */       throw new ElementNotFoundException();
/*     */     }
/* 261 */     if (IOCSPCertStatus.class.isAssignableFrom(elementClass)) {
/* 262 */       IOCSPCertStatus ocsp = getOCSPResponse(props);
/* 263 */       if (ocsp != null) {
/* 264 */         return ocsp;
/*     */       }
/* 266 */       throw new ElementNotFoundException();
/*     */     }
/* 268 */     if (X509CRL.class.isAssignableFrom(elementClass)) {
/* 269 */       X509CRL crl = getCRL(props);
/* 270 */       if (crl != null) {
/* 271 */         return crl;
/*     */       }
/* 273 */       throw new ElementNotFoundException();
/*     */     }
/*     */     
/* 276 */     throw new UnknownElementClassException();
/*     */   }
/*     */   
/*     */   private X509CRL getCRL(Map<String, Object> props)
/*     */   {
/* 281 */     if (props != null) {
/* 282 */       Object uriObj = props.get("uri");
/* 283 */       if ((uriObj != null) && ((uriObj instanceof String))) {
/* 284 */         return getCRL((String)uriObj);
/*     */       }
/*     */     }
/* 287 */     return null;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private X509CRL getCRL(String uri)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_2
/*     */     //   2: new 80	java/io/File
/*     */     //   5: dup
/*     */     //   6: aload_0
/*     */     //   7: getfield 70	es/mityc/javasign/xml/xades/LocalFileStoreElements:base	Ljava/net/URI;
/*     */     //   10: invokespecial 192	java/io/File:<init>	(Ljava/net/URI;)V
/*     */     //   13: astore_3
/*     */     //   14: new 316	java/io/FileInputStream
/*     */     //   17: dup
/*     */     //   18: new 80	java/io/File
/*     */     //   21: dup
/*     */     //   22: aload_3
/*     */     //   23: aload_1
/*     */     //   24: invokespecial 226	java/io/File:<init>	(Ljava/io/File;Ljava/lang/String;)V
/*     */     //   27: invokespecial 318	java/io/FileInputStream:<init>	(Ljava/io/File;)V
/*     */     //   30: astore 4
/*     */     //   32: ldc_w 319
/*     */     //   35: invokestatic 321	java/security/cert/CertificateFactory:getInstance	(Ljava/lang/String;)Ljava/security/cert/CertificateFactory;
/*     */     //   38: astore 5
/*     */     //   40: aload 5
/*     */     //   42: aload 4
/*     */     //   44: invokevirtual 327	java/security/cert/CertificateFactory:generateCRL	(Ljava/io/InputStream;)Ljava/security/cert/CRL;
/*     */     //   47: checkcast 285	java/security/cert/X509CRL
/*     */     //   50: astore_2
/*     */     //   51: goto +63 -> 114
/*     */     //   54: astore 5
/*     */     //   56: aload 4
/*     */     //   58: ifnull +76 -> 134
/*     */     //   61: aload 4
/*     */     //   63: invokevirtual 331	java/io/FileInputStream:close	()V
/*     */     //   66: goto +68 -> 134
/*     */     //   69: astore 7
/*     */     //   71: goto +63 -> 134
/*     */     //   74: astore 5
/*     */     //   76: aload 4
/*     */     //   78: ifnull +56 -> 134
/*     */     //   81: aload 4
/*     */     //   83: invokevirtual 331	java/io/FileInputStream:close	()V
/*     */     //   86: goto +48 -> 134
/*     */     //   89: astore 7
/*     */     //   91: goto +43 -> 134
/*     */     //   94: astore 6
/*     */     //   96: aload 4
/*     */     //   98: ifnull +13 -> 111
/*     */     //   101: aload 4
/*     */     //   103: invokevirtual 331	java/io/FileInputStream:close	()V
/*     */     //   106: goto +5 -> 111
/*     */     //   109: astore 7
/*     */     //   111: aload 6
/*     */     //   113: athrow
/*     */     //   114: aload 4
/*     */     //   116: ifnull +18 -> 134
/*     */     //   119: aload 4
/*     */     //   121: invokevirtual 331	java/io/FileInputStream:close	()V
/*     */     //   124: goto +10 -> 134
/*     */     //   127: astore 7
/*     */     //   129: goto +5 -> 134
/*     */     //   132: astore 4
/*     */     //   134: aload_2
/*     */     //   135: areturn
/*     */     // Line number table:
/*     */     //   Java source line #291	-> byte code offset #0
/*     */     //   Java source line #292	-> byte code offset #2
/*     */     //   Java source line #294	-> byte code offset #14
/*     */     //   Java source line #298	-> byte code offset #32
/*     */     //   Java source line #299	-> byte code offset #40
/*     */     //   Java source line #300	-> byte code offset #51
/*     */     //   Java source line #303	-> byte code offset #56
/*     */     //   Java source line #305	-> byte code offset #61
/*     */     //   Java source line #306	-> byte code offset #66
/*     */     //   Java source line #301	-> byte code offset #74
/*     */     //   Java source line #303	-> byte code offset #76
/*     */     //   Java source line #305	-> byte code offset #81
/*     */     //   Java source line #306	-> byte code offset #86
/*     */     //   Java source line #302	-> byte code offset #94
/*     */     //   Java source line #303	-> byte code offset #96
/*     */     //   Java source line #305	-> byte code offset #101
/*     */     //   Java source line #306	-> byte code offset #106
/*     */     //   Java source line #308	-> byte code offset #111
/*     */     //   Java source line #303	-> byte code offset #114
/*     */     //   Java source line #305	-> byte code offset #119
/*     */     //   Java source line #306	-> byte code offset #124
/*     */     //   Java source line #309	-> byte code offset #129
/*     */     //   Java source line #311	-> byte code offset #134
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	136	0	this	LocalFileStoreElements
/*     */     //   0	136	1	uri	String
/*     */     //   1	134	2	crl	X509CRL
/*     */     //   13	10	3	dir	File
/*     */     //   30	90	4	fis	java.io.FileInputStream
/*     */     //   132	1	4	localFileNotFoundException	java.io.FileNotFoundException
/*     */     //   38	3	5	cf	java.security.cert.CertificateFactory
/*     */     //   54	1	5	localCertificateException	java.security.cert.CertificateException
/*     */     //   74	1	5	localCRLException	java.security.cert.CRLException
/*     */     //   94	18	6	localObject	Object
/*     */     //   69	1	7	localIOException	java.io.IOException
/*     */     //   89	1	7	localIOException1	java.io.IOException
/*     */     //   109	1	7	localIOException2	java.io.IOException
/*     */     //   127	1	7	localIOException3	java.io.IOException
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   32	51	54	java/security/cert/CertificateException
/*     */     //   61	66	69	java/io/IOException
/*     */     //   32	51	74	java/security/cert/CRLException
/*     */     //   81	86	89	java/io/IOException
/*     */     //   32	56	94	finally
/*     */     //   74	76	94	finally
/*     */     //   101	106	109	java/io/IOException
/*     */     //   119	124	127	java/io/IOException
/*     */     //   14	129	132	java/io/FileNotFoundException
/*     */   }
/*     */   
/*     */   private IOCSPCertStatus getOCSPResponse(Map<String, Object> props)
/*     */   {
/* 316 */     if (props != null) {
/* 317 */       Object uriObj = props.get("uri");
/* 318 */       if ((uriObj != null) && ((uriObj instanceof String))) {
/* 319 */         return getOCSPResponse((String)uriObj);
/*     */       }
/* 321 */       Object emissiondateObj = props.get("emission.date");
/* 322 */       Object digestalgObj = props.get("digest.algorithm");
/* 323 */       Object digestvalueObj = props.get("digest.value");
/* 324 */       Object issuernameObj = props.get("issuer.name");
/* 325 */       Object issuerhashObj = props.get("issuer.hash");
/* 326 */       if ((digestalgObj != null) && ((digestalgObj instanceof String)) && 
/* 327 */         (digestvalueObj != null) && ((digestvalueObj instanceof byte[])) && 
/* 328 */         (emissiondateObj != null) && ((emissiondateObj instanceof Date)) && (
/* 329 */         ((issuernameObj != null) && ((issuernameObj instanceof X500Principal))) || (
/* 330 */         (issuerhashObj != null) && ((issuerhashObj instanceof byte[]))))) {
/* 331 */         OCSPResponderID issuer = null;
/* 332 */         if (issuernameObj != null) {
/* 333 */           issuer = OCSPResponderID.getOCSPResponderID((X500Principal)issuernameObj);
/* 334 */         } else if (issuerhashObj != null) {
/* 335 */           issuer = OCSPResponderID.getOCSPResponderID((byte[])issuerhashObj);
/*     */         }
/* 337 */         return getOCSPResponse((String)digestalgObj, (byte[])digestvalueObj, issuer, (Date)emissiondateObj);
/*     */       }
/*     */     }
/* 340 */     return null;
/*     */   }
/*     */   
/*     */   private IOCSPCertStatus getOCSPResponse(String uri) {
/* 344 */     OCSPResp ocsp = null;
/* 345 */     File file = new File(new File(this.base), uri);
/* 346 */     if (file.exists()) {
/* 347 */       byte[] data = UtilidadFicheros.readFile(file);
/* 348 */       if (data != null) {
/* 349 */         ocsp = new OCSPResp(data, null);
/*     */       }
/*     */     }
/* 352 */     return ocsp;
/*     */   }
/*     */   
/*     */   private IOCSPCertStatus getOCSPResponse(String digestAlg, byte[] digestValue, OCSPResponderID issuer, Date emission) {
/* 356 */     OCSPResp ocsp = null;
/*     */     
/*     */ 
/* 359 */     return ocsp;
/*     */   }
/*     */   
/*     */   private X509Certificate getCertificate(Map<String, Object> props) {
/* 363 */     if (props != null) {
/* 364 */       Object uriObj = props.get("uri");
/* 365 */       if ((uriObj != null) && ((uriObj instanceof String))) {
/* 366 */         return getCertificate((String)uriObj);
/*     */       }
/* 368 */       Object issuernameObj = props.get("issuer.name");
/* 369 */       Object serialnumberObj = props.get("serial.number");
/* 370 */       if ((issuernameObj != null) && ((issuernameObj instanceof X500Principal)) && 
/* 371 */         (serialnumberObj != null) && ((serialnumberObj instanceof BigInteger))) {
/* 372 */         return getCertificate((X500Principal)issuernameObj, (BigInteger)serialnumberObj);
/*     */       }
/*     */     }
/* 375 */     return null;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private X509Certificate getCertificate(String uri)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_2
/*     */     //   2: new 80	java/io/File
/*     */     //   5: dup
/*     */     //   6: aload_0
/*     */     //   7: getfield 70	es/mityc/javasign/xml/xades/LocalFileStoreElements:base	Ljava/net/URI;
/*     */     //   10: invokespecial 192	java/io/File:<init>	(Ljava/net/URI;)V
/*     */     //   13: astore_3
/*     */     //   14: new 316	java/io/FileInputStream
/*     */     //   17: dup
/*     */     //   18: new 80	java/io/File
/*     */     //   21: dup
/*     */     //   22: aload_3
/*     */     //   23: aload_1
/*     */     //   24: invokespecial 226	java/io/File:<init>	(Ljava/io/File;Ljava/lang/String;)V
/*     */     //   27: invokespecial 318	java/io/FileInputStream:<init>	(Ljava/io/File;)V
/*     */     //   30: astore 4
/*     */     //   32: ldc_w 319
/*     */     //   35: invokestatic 321	java/security/cert/CertificateFactory:getInstance	(Ljava/lang/String;)Ljava/security/cert/CertificateFactory;
/*     */     //   38: astore 5
/*     */     //   40: aload 5
/*     */     //   42: aload 4
/*     */     //   44: invokevirtual 405	java/security/cert/CertificateFactory:generateCertificate	(Ljava/io/InputStream;)Ljava/security/cert/Certificate;
/*     */     //   47: checkcast 203	java/security/cert/X509Certificate
/*     */     //   50: astore_2
/*     */     //   51: goto +43 -> 94
/*     */     //   54: astore 5
/*     */     //   56: aload 4
/*     */     //   58: ifnull +56 -> 114
/*     */     //   61: aload 4
/*     */     //   63: invokevirtual 331	java/io/FileInputStream:close	()V
/*     */     //   66: goto +48 -> 114
/*     */     //   69: astore 7
/*     */     //   71: goto +43 -> 114
/*     */     //   74: astore 6
/*     */     //   76: aload 4
/*     */     //   78: ifnull +13 -> 91
/*     */     //   81: aload 4
/*     */     //   83: invokevirtual 331	java/io/FileInputStream:close	()V
/*     */     //   86: goto +5 -> 91
/*     */     //   89: astore 7
/*     */     //   91: aload 6
/*     */     //   93: athrow
/*     */     //   94: aload 4
/*     */     //   96: ifnull +18 -> 114
/*     */     //   99: aload 4
/*     */     //   101: invokevirtual 331	java/io/FileInputStream:close	()V
/*     */     //   104: goto +10 -> 114
/*     */     //   107: astore 7
/*     */     //   109: goto +5 -> 114
/*     */     //   112: astore 4
/*     */     //   114: aload_2
/*     */     //   115: areturn
/*     */     // Line number table:
/*     */     //   Java source line #379	-> byte code offset #0
/*     */     //   Java source line #380	-> byte code offset #2
/*     */     //   Java source line #382	-> byte code offset #14
/*     */     //   Java source line #386	-> byte code offset #32
/*     */     //   Java source line #387	-> byte code offset #40
/*     */     //   Java source line #388	-> byte code offset #51
/*     */     //   Java source line #390	-> byte code offset #56
/*     */     //   Java source line #392	-> byte code offset #61
/*     */     //   Java source line #393	-> byte code offset #66
/*     */     //   Java source line #389	-> byte code offset #74
/*     */     //   Java source line #390	-> byte code offset #76
/*     */     //   Java source line #392	-> byte code offset #81
/*     */     //   Java source line #393	-> byte code offset #86
/*     */     //   Java source line #395	-> byte code offset #91
/*     */     //   Java source line #390	-> byte code offset #94
/*     */     //   Java source line #392	-> byte code offset #99
/*     */     //   Java source line #393	-> byte code offset #104
/*     */     //   Java source line #396	-> byte code offset #109
/*     */     //   Java source line #398	-> byte code offset #114
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	116	0	this	LocalFileStoreElements
/*     */     //   0	116	1	uri	String
/*     */     //   1	114	2	certificate	X509Certificate
/*     */     //   13	10	3	dir	File
/*     */     //   30	70	4	fis	java.io.FileInputStream
/*     */     //   112	1	4	localFileNotFoundException	java.io.FileNotFoundException
/*     */     //   38	3	5	cf	java.security.cert.CertificateFactory
/*     */     //   54	1	5	localCertificateException	java.security.cert.CertificateException
/*     */     //   74	18	6	localObject	Object
/*     */     //   69	1	7	localIOException	java.io.IOException
/*     */     //   89	1	7	localIOException1	java.io.IOException
/*     */     //   107	1	7	localIOException2	java.io.IOException
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   32	51	54	java/security/cert/CertificateException
/*     */     //   61	66	69	java/io/IOException
/*     */     //   32	56	74	finally
/*     */     //   81	86	89	java/io/IOException
/*     */     //   99	104	107	java/io/IOException
/*     */     //   14	109	112	java/io/FileNotFoundException
/*     */   }
/*     */   
/*     */   private X509Certificate getCertificate(X500Principal issuername, BigInteger serialnumber)
/*     */   {
/* 402 */     X509Certificate certificate = null;
/*     */     
/* 404 */     return certificate;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\xades\LocalFileStoreElements.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */