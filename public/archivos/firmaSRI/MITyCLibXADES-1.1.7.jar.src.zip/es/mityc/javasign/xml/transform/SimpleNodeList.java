/*    */ package es.mityc.javasign.xml.transform;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.w3c.dom.Node;
/*    */ import org.w3c.dom.NodeList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleNodeList
/*    */   implements NodeList
/*    */ {
/* 32 */   private List<Node> list = new ArrayList();
/*    */   
/*    */   public void addNode(Node node) {
/* 35 */     this.list.add(node);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int getLength()
/*    */   {
/* 42 */     return this.list.size();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Node item(int index)
/*    */   {
/* 49 */     return (Node)this.list.get(index);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\transform\SimpleNodeList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */