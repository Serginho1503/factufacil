/*    */ package es.mityc.javasign.xml.transform;
/*    */ 
/*    */ import es.mityc.javasign.i18n.I18nFactory;
/*    */ import es.mityc.javasign.i18n.II18nManager;
/*    */ import org.w3c.dom.DOMException;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ import org.w3c.dom.NodeList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransformXSLT
/*    */   extends Transform
/*    */   implements ITransformData
/*    */ {
/* 37 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibXAdES");
/*    */   
/*    */ 
/*    */ 
/*    */   private Element stylesheet;
/*    */   
/*    */ 
/*    */ 
/*    */   public TransformXSLT()
/*    */   {
/* 47 */     super("http://www.w3.org/TR/1999/REC-xslt-19991116", null);
/* 48 */     setTransformData(this);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public NodeList getExtraData(Document doc)
/*    */   {
/* 56 */     SimpleNodeList nl = null;
/* 57 */     if (this.stylesheet != null) {
/*    */       try {
/* 59 */         Node node = doc.importNode(this.stylesheet, true);
/* 60 */         nl = new SimpleNodeList();
/* 61 */         nl.addNode(node);
/*    */       }
/*    */       catch (DOMException localDOMException) {}
/*    */     }
/* 65 */     return nl;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setStyleSheet(Element stylesheet)
/*    */     throws IllegalArgumentException
/*    */   {
/* 74 */     if (!"http://www.w3.org/1999/XSL/Transform".equals(stylesheet.getNamespaceURI())) {
/* 75 */       throw new IllegalArgumentException(I18N.getLocalMessage("i18n.mityc.xades.sign.8", new Object[] { stylesheet.getNamespaceURI() }));
/*    */     }
/* 77 */     if (!"stylesheet".equals(stylesheet.getLocalName())) {
/* 78 */       throw new IllegalArgumentException(I18N.getLocalMessage("i18n.mityc.xades.sign.9", new Object[] { stylesheet.getLocalName() }));
/*    */     }
/* 80 */     this.stylesheet = stylesheet;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\transform\TransformXSLT.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */