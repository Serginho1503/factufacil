package es.mityc.javasign.xml.xades.policy;

import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
import es.mityc.firmaJava.libreria.xades.errores.PolicyException;
import org.w3c.dom.Element;

public abstract interface IFirmaPolicy
{
  public abstract void writePolicyNode(Element paramElement, String paramString1, String paramString2, XAdESSchemas paramXAdESSchemas)
    throws PolicyException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\xades\policy\IFirmaPolicy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */