/*     */ package es.mityc.javasign.xml.refs;
/*     */ 
/*     */ import adsi.org.apache.xml.security.signature.ObjectContainer;
/*     */ import es.mityc.firmaJava.libreria.utilidades.UtilidadTratarNodo;
/*     */ import java.util.List;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InternObjectSignToSign
/*     */   extends AbstractObjectToSign
/*     */ {
/*     */   private String encoding;
/*     */   private String mimeType;
/*     */   private Element data;
/*  38 */   private String id = null;
/*     */   
/*     */   public InternObjectSignToSign() {}
/*     */   
/*     */   public InternObjectSignToSign(String encoding, String mimeType)
/*     */   {
/*  44 */     this.encoding = encoding;
/*  45 */     this.mimeType = mimeType;
/*     */   }
/*     */   
/*     */   public void setData(Element data) {
/*  49 */     this.data = data;
/*     */   }
/*     */   
/*     */   public Element getData() {
/*  53 */     return this.data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getEncoding()
/*     */   {
/*  60 */     return this.encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getMimeType()
/*     */   {
/*  67 */     return this.mimeType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getReferenceURI()
/*     */   {
/*  75 */     return this.id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<ObjectContainer> getObjects(Document doc)
/*     */   {
/*  83 */     List<ObjectContainer> list = super.getObjects(doc);
/*     */     
/*  85 */     ObjectContainer container = new ObjectContainer(doc);
/*     */     
/*  87 */     container.appendChild(doc.adoptNode(getData().cloneNode(true)));
/*     */     
/*  89 */     this.id = UtilidadTratarNodo.newID(doc, "Object-ID-");
/*  90 */     container.setId(this.id);
/*  91 */     if (getEncoding() != null) {
/*  92 */       container.setEncoding(getEncoding());
/*     */     }
/*  94 */     if (getMimeType() != null) {
/*  95 */       container.setMimeType(getMimeType());
/*     */     }
/*  97 */     this.id = ("#" + this.id);
/*     */     
/*  99 */     list.add(container);
/* 100 */     return list;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\refs\InternObjectSignToSign.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */