/*    */ package es.mityc.javasign.xml.refs;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SignObjectToSign
/*    */   extends InternObjectToSign
/*    */ {
/*    */   public SignObjectToSign(String id)
/*    */   {
/* 34 */     super(id);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getType()
/*    */   {
/* 42 */     return "http://uri.etsi.org/01903#CountersignedSignature";
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\refs\SignObjectToSign.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */