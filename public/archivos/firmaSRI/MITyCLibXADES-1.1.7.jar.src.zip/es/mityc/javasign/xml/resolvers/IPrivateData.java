package es.mityc.javasign.xml.resolvers;

public abstract interface IPrivateData
{
  public abstract byte[] getDigest(String paramString1, String paramString2, String paramString3)
    throws ResourceDataException;
  
  public abstract boolean canDigest(String paramString1, String paramString2);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\resolvers\IPrivateData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */