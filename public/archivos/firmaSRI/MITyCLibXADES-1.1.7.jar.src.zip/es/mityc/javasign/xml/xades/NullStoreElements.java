/*    */ package es.mityc.javasign.xml.xades;
/*    */ 
/*    */ import es.mityc.javasign.certificate.ElementNotFoundException;
/*    */ import es.mityc.javasign.certificate.ICertStatus;
/*    */ import es.mityc.javasign.certificate.IRecoverElements;
/*    */ import es.mityc.javasign.certificate.UnknownElementClassException;
/*    */ import java.security.cert.X509Certificate;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullStoreElements
/*    */   implements IStoreElements, IRecoverElements
/*    */ {
/* 34 */   public static final NullStoreElements instance = new NullStoreElements();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void init(String baseURI) {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String[] storeCertAndStatus(X509Certificate certificate, ICertStatus certStatus)
/*    */   {
/* 52 */     return new String[0];
/*    */   }
/*    */   
/*    */ 
/*    */   public <T> T getElement(Map<String, Object> props, Class<T> elementClass)
/*    */     throws ElementNotFoundException, UnknownElementClassException
/*    */   {
/* 59 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\xades\NullStoreElements.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */