/*    */ package es.mityc.javasign.xml.refs;
/*    */ 
/*    */ import java.net.URI;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExtraObjectData
/*    */ {
/* 27 */   private String mimeType = null;
/*    */   
/* 29 */   private URI encoding = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ExtraObjectData(String mimeType, URI encoding)
/*    */   {
/* 38 */     this.mimeType = mimeType;
/* 39 */     this.encoding = encoding;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getMimeType()
/*    */   {
/* 46 */     return this.mimeType;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public URI getEncoding()
/*    */   {
/* 53 */     return this.encoding;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\refs\ExtraObjectData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */