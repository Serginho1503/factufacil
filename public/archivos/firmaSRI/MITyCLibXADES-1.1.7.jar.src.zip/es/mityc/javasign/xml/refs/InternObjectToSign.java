/*    */ package es.mityc.javasign.xml.refs;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InternObjectToSign
/*    */   extends AbstractObjectToSign
/*    */ {
/*    */   private String id;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InternObjectToSign(String id)
/*    */   {
/* 34 */     this.id = id;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getId()
/*    */   {
/* 41 */     return this.id;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setId(String id)
/*    */   {
/* 48 */     this.id = id;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getReferenceURI()
/*    */   {
/* 56 */     return "#" + getId();
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\refs\InternObjectToSign.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */