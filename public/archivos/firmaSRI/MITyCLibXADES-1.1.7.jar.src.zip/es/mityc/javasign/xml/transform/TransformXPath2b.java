/*    */ package es.mityc.javasign.xml.transform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransformXPath2b
/*    */   extends Transform
/*    */ {
/* 26 */   private XPathTransformData data = new XPathTransformData();
/*    */   
/*    */   public TransformXPath2b()
/*    */   {
/* 30 */     super("http://www.w3.org/2002/06/xmldsig-filter2", null);
/* 31 */     setTransformData(this.data);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void addPath(String path)
/*    */   {
/* 39 */     this.data.addPath(path);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\transform\TransformXPath2b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */