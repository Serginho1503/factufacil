/*    */ package es.mityc.javasign.xml.xades.policy;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.utilidades.NombreNodo;
/*    */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*    */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SignaturePolicyIdentifier;
/*    */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*    */ import es.mityc.firmaJava.libreria.xades.errores.PolicyException;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ import org.w3c.dom.NodeList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PoliciesTool
/*    */ {
/*    */   public static void insertPolicyNode(Element signNode, String namespaceDS, String namespaceXAdES, XAdESSchemas schema, SignaturePolicyIdentifier spi)
/*    */     throws PolicyException
/*    */   {
/* 51 */     NodeList list = signNode.getElementsByTagNameNS(schema.getSchemaUri(), "SignedSignatureProperties");
/* 52 */     if ((list.getLength() != 1) || (list.item(0).getNodeType() != 1)) {
/* 53 */       throw new PolicyException("No hay nodo SignedSignatureProperties claro al que aplicar la política");
/*    */     }
/*    */     
/*    */     try
/*    */     {
/* 58 */       policy = spi.createElement(signNode.getOwnerDocument(), namespaceDS, namespaceXAdES);
/*    */     } catch (InvalidInfoNodeException ex) { Element policy;
/* 60 */       throw new PolicyException("Error en la creación de la política:" + ex.getMessage(), ex);
/*    */     }
/*    */     Element policy;
/* 63 */     NombreNodo SIGNING_TIME = new NombreNodo(schema.getSchemaUri(), "SigningTime");
/* 64 */     NombreNodo SIGNING_CERTIFICATE = new NombreNodo(schema.getSchemaUri(), "SigningCertificate");
/* 65 */     NombreNodo SIGNATURE_POLICY_IDENTIFIER = new NombreNodo(schema.getSchemaUri(), "SignaturePolicyIdentifier");
/*    */     
/* 67 */     Element signedSignatureProperties = (Element)list.item(0);
/* 68 */     Node node = signedSignatureProperties.getFirstChild();
/* 69 */     while (node != null) {
/* 70 */       if (node.getNodeType() != 1)
/* 71 */         throw new PolicyException("Error en el formato de SignedSignatureProperties");
/* 72 */       NombreNodo nombre = new NombreNodo(node.getNamespaceURI(), node.getLocalName());
/* 73 */       if ((!nombre.equals(SIGNING_TIME)) && (!nombre.equals(SIGNING_CERTIFICATE)))
/*    */         break;
/* 75 */       node = node.getNextSibling();
/*    */     }
/*    */     
/* 78 */     if ((node != null) && (SIGNATURE_POLICY_IDENTIFIER.equals(new NombreNodo(node.getNamespaceURI(), node.getLocalName())))) {
/* 79 */       signedSignatureProperties.replaceChild(policy, node);
/*    */     } else {
/* 81 */       signedSignatureProperties.insertBefore(policy, node);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\xades\policy\PoliciesTool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */