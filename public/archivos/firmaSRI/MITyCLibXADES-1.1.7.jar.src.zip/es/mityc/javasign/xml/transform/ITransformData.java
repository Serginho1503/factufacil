package es.mityc.javasign.xml.transform;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

public abstract interface ITransformData
{
  public abstract NodeList getExtraData(Document paramDocument);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\transform\ITransformData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */