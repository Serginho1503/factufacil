/*     */ package es.mityc.javasign.xml.xades.policy;
/*     */ 
/*     */ import java.net.URI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PolicyResult
/*     */ {
/*     */   private StatusValidation result;
/*     */   private String descriptionResult;
/*     */   private String description;
/*     */   private URI policyID;
/*     */   private URI[] documentation;
/*     */   private DownloadPolicy[] downloable;
/*     */   private String[] notices;
/*     */   private IValidacionPolicy policyVal;
/*     */   
/*     */   public static enum StatusValidation
/*     */   {
/*  28 */     unknown,  valid,  invalid;
/*     */   }
/*     */   
/*     */   public class DownloadPolicy { public URI uri;
/*     */     public PolicyResult.StatusValidation status;
/*     */     
/*  34 */     public DownloadPolicy(URI uri, PolicyResult.StatusValidation status) { this.uri = uri;
/*  35 */       this.status = status;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PolicyResult()
/*     */   {
/*  49 */     this.result = StatusValidation.unknown;
/*     */   }
/*     */   
/*     */   public DownloadPolicy newDownloadPolicy(URI uri, StatusValidation status) {
/*  53 */     return new DownloadPolicy(uri, status);
/*     */   }
/*     */   
/*     */   public StatusValidation getResult() {
/*  57 */     return this.result;
/*     */   }
/*     */   
/*     */   public void setResult(StatusValidation result) {
/*  61 */     this.result = result;
/*     */   }
/*     */   
/*     */   public String getDescriptionResult() {
/*  65 */     return this.descriptionResult;
/*     */   }
/*     */   
/*     */   public void setDescriptionResult(String descriptionResult) {
/*  69 */     this.descriptionResult = descriptionResult;
/*     */   }
/*     */   
/*     */   public URI getPolicyID() {
/*  73 */     return this.policyID;
/*     */   }
/*     */   
/*     */   public void setPolicyID(URI policyID) {
/*  77 */     this.policyID = policyID;
/*     */   }
/*     */   
/*     */   public URI[] getDocumentation() {
/*  81 */     return this.documentation;
/*     */   }
/*     */   
/*     */   public void setDocumentation(URI[] documentation) {
/*  85 */     this.documentation = documentation;
/*     */   }
/*     */   
/*     */   public DownloadPolicy[] getDownloable() {
/*  89 */     return this.downloable;
/*     */   }
/*     */   
/*     */   public void setDownloable(DownloadPolicy[] downloable) {
/*  93 */     this.downloable = downloable;
/*     */   }
/*     */   
/*     */   public String[] getNotices() {
/*  97 */     return this.notices;
/*     */   }
/*     */   
/*     */   public void setNotices(String[] notices) {
/* 101 */     this.notices = notices;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public IValidacionPolicy getPolicyVal()
/*     */   {
/* 109 */     return this.policyVal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPolicyVal(IValidacionPolicy policyVal)
/*     */   {
/* 117 */     this.policyVal = policyVal;
/*     */   }
/*     */   
/*     */   public String getDescription() {
/* 121 */     return this.description;
/*     */   }
/*     */   
/*     */   public void setDescription(String description) {
/* 125 */     this.description = description;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 133 */     if (((obj instanceof IValidacionPolicy)) && (this.policyVal != null)) {
/* 134 */       IValidacionPolicy val = (IValidacionPolicy)obj;
/* 135 */       if (this.policyVal.getIdentidadPolicy().equals(val.getIdentidadPolicy()))
/* 136 */         return true;
/* 137 */       return false;
/*     */     }
/*     */     
/* 140 */     return super.equals(obj);
/*     */   }
/*     */   
/*     */   public void copy(PolicyResult pr) {
/* 144 */     setResult(pr.getResult());
/* 145 */     setPolicyID(pr.getPolicyID());
/* 146 */     setDescriptionResult(pr.getDescriptionResult());
/* 147 */     setDocumentation(pr.getDocumentation());
/* 148 */     setDownloable(pr.getDownloable());
/* 149 */     setNotices(pr.getNotices());
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\xades\policy\PolicyResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */