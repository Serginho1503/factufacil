/*     */ package es.mityc.javasign.xml.xades.policy;
/*     */ 
/*     */ import adsi.org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import adsi.org.apache.xml.security.transforms.TransformationException;
/*     */ import es.mityc.firmaJava.libreria.utilidades.Base64Coder;
/*     */ import es.mityc.firmaJava.libreria.utilidades.NombreNodo;
/*     */ import es.mityc.firmaJava.libreria.utilidades.UtilidadFicheros;
/*     */ import es.mityc.firmaJava.libreria.utilidades.UtilidadFirmaElectronica;
/*     */ import es.mityc.firmaJava.libreria.utilidades.UtilidadTratarNodo;
/*     */ import es.mityc.firmaJava.libreria.xades.DatosFirma;
/*     */ import es.mityc.firmaJava.libreria.xades.ResultadoValidacion;
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.Description;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.DocumentationReference;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.DocumentationReferences;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.Identifier;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.Int;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.NoticeNumbers;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.NoticeRef;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.Organization;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SPURI;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SPUserNotice;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SigPolicyHash;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SigPolicyId;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SigPolicyQualifier;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SigPolicyQualifiers;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SignaturePolicyId;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SignaturePolicyIdentifier;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xmldsig.DigestMethod;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xmldsig.DigestValue;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xmldsig.Transform;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.FirmaXMLError;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import es.mityc.javasign.trust.TrustAbstract;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.math.BigInteger;
/*     */ import java.net.URI;
/*     */ import java.security.MessageDigest;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeneralPolicyManager
/*     */   implements IValidacionPolicy
/*     */ {
/*  71 */   private static final Log logger = LogFactory.getLog(GeneralPolicyManager.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String GENERAL_ID = "self:policy/general";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getIdentidadPolicy()
/*     */   {
/*  85 */     return "self:policy/general";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PolicyResult validaPolicy(Element nodoFirma, ResultadoValidacion resultadoValidacion)
/*     */   {
/*  92 */     PolicyResult pr = new PolicyResult();
/*  93 */     pr.setResult(PolicyResult.StatusValidation.unknown);
/*     */     try
/*     */     {
/*  96 */       SignaturePolicyIdentifier signaturePolicyIdentifier = extractInfo(nodoFirma, resultadoValidacion);
/*     */       
/*     */ 
/*  99 */       if (!signaturePolicyIdentifier.isImplied()) {
/* 100 */         SignaturePolicyId spi = signaturePolicyIdentifier.getSignaturePolicyId();
/*     */         
/*     */ 
/* 103 */         pr.setPolicyID(spi.getSigPolicyId().getIdentifier().getUri());
/* 104 */         if (spi.getSigPolicyId().getDescription() != null)
/* 105 */           pr.setDescription(spi.getSigPolicyId().getDescription().getValue());
/* 106 */         if (spi.getSigPolicyId().getReferences() != null) {
/* 107 */           ArrayList<DocumentationReference> references = spi.getSigPolicyId().getReferences().getList();
/* 108 */           if ((references != null) && (references.size() > 0)) {
/* 109 */             ArrayList<URI> uris = new ArrayList(references.size());
/* 110 */             Iterator<DocumentationReference> it = references.iterator();
/* 111 */             while (it.hasNext()) {
/* 112 */               uris.add(((DocumentationReference)it.next()).getValue());
/*     */             }
/* 114 */             pr.setDocumentation((URI[])uris.toArray(new URI[0]));
/*     */           }
/*     */         }
/* 117 */         if (spi.getSigPolicyQualifiers() != null) {
/* 118 */           ArrayList<SigPolicyQualifier> list = spi.getSigPolicyQualifiers().getList();
/* 119 */           if ((list != null) && (list.size() > 0)) {
/* 120 */             MessageDigest md = UtilidadFirmaElectronica.getMessageDigest(spi.getSigPolicyHash().getDigestMethod().getAlgorithm());
/* 121 */             String digestValue = spi.getSigPolicyHash().getDigestValue().getValue();
/*     */             
/* 123 */             ArrayList<PolicyResult.DownloadPolicy> downloadbles = new ArrayList();
/* 124 */             ArrayList<String> notices = new ArrayList();
/* 125 */             Iterator<SigPolicyQualifier> it = list.iterator();
/* 126 */             while (it.hasNext()) {
/* 127 */               SigPolicyQualifier spq = (SigPolicyQualifier)it.next();
/* 128 */               Object obj = spq.getQualifier();
/* 129 */               if ((obj instanceof SPURI)) {
/* 130 */                 downloadbles.add(checkIntegrity(pr, ((SPURI)obj).getValue(), spi, resultadoValidacion.getBaseURI(), md, digestValue, nodoFirma.getOwnerDocument()));
/*     */               }
/* 132 */               else if ((obj instanceof SPUserNotice)) {
/* 133 */                 StringBuffer notice = new StringBuffer("");
/* 134 */                 String expl = ((SPUserNotice)obj).getExplicitText();
/* 135 */                 if (expl != null)
/* 136 */                   notice.append(expl).append(" ");
/* 137 */                 NoticeRef nr = ((SPUserNotice)obj).getNoticeRef();
/* 138 */                 if (nr != null) {
/* 139 */                   notice.append("(").append(nr.getOrganization().getValue());
/* 140 */                   Iterator<Int> itInt = nr.getNoticeNumbers().getInts().iterator();
/* 141 */                   if (itInt.hasNext())
/* 142 */                     notice.append(" ");
/* 143 */                   while (itInt.hasNext()) {
/* 144 */                     notice.append(((Int)itInt.next()).getValue().toString());
/* 145 */                     if (itInt.hasNext())
/* 146 */                       notice.append(".");
/*     */                   }
/* 148 */                   notice.append(")");
/*     */                 }
/* 150 */                 notices.add(notice.toString());
/*     */               }
/*     */             }
/*     */             
/* 154 */             if (downloadbles.size() > 0) {
/* 155 */               pr.setDownloable((PolicyResult.DownloadPolicy[])downloadbles.toArray(new PolicyResult.DownloadPolicy[0]));
/*     */             }
/* 157 */             if (notices.size() > 0) {
/* 158 */               pr.setNotices((String[])notices.toArray(new String[0]));
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (PolicyException ex) {
/* 165 */       pr.setResult(PolicyResult.StatusValidation.invalid);
/* 166 */       pr.setDescriptionResult(ex.getMessage());
/*     */     }
/*     */     
/* 169 */     return pr;
/*     */   }
/*     */   
/*     */   private PolicyResult.DownloadPolicy checkIntegrity(PolicyResult pr, URI uri, SignaturePolicyId spi, URI baseUri, MessageDigest md, String digestValue, Document doc) {
/* 173 */     PolicyResult.StatusValidation status = PolicyResult.StatusValidation.unknown;
/*     */     
/* 175 */     if (md != null)
/*     */     {
/* 177 */       URI descarga = uri;
/* 178 */       if ((!uri.isAbsolute()) && (baseUri != null)) {
/* 179 */         descarga = baseUri.resolve(uri);
/*     */       }
/* 181 */       if ("file".equals(descarga.getScheme()))
/*     */       {
/* 183 */         byte[] data = UtilidadFicheros.readFile(new File(descarga.getSchemeSpecificPart()));
/* 184 */         if (data == null) {
/* 185 */           logger.warn("No se puede obtener el contenido referenciado");
/*     */         }
/*     */         else {
/* 188 */           if (spi.getTransforms() != null) {
/* 189 */             data = transform(data, spi.getTransforms(), doc);
/*     */           }
/*     */           
/*     */ 
/* 193 */           md.update(data);
/* 194 */           byte[] resData = md.digest();
/* 195 */           String res = new String(Base64Coder.encode(resData));
/* 196 */           if (res.equals(digestValue)) {
/* 197 */             status = PolicyResult.StatusValidation.valid;
/*     */           } else {
/* 199 */             status = PolicyResult.StatusValidation.invalid;
/*     */           }
/*     */         }
/*     */       } else {
/* 203 */         logger.warn("No se puede obtener el contenido referenciado en: " + descarga);
/*     */       }
/*     */     } else {
/* 206 */       logger.warn("Algoritmo desconocido"); }
/* 207 */     return pr.newDownloadPolicy(uri, status);
/*     */   }
/*     */   
/*     */   private byte[] transform(byte[] in, es.mityc.firmaJava.libreria.xades.elementos.xmldsig.Transforms transforms, Document doc) {
/* 211 */     adsi.org.apache.xml.security.transforms.Transforms t = new adsi.org.apache.xml.security.transforms.Transforms(doc);
/*     */     
/* 213 */     ArrayList<Transform> list = transforms.getList();
/* 214 */     if (list != null) {
/* 215 */       Iterator<Transform> it = list.iterator();
/* 216 */       while (it.hasNext()) {
/* 217 */         Transform tr = (Transform)it.next();
/*     */         try {
/* 219 */           if ("http://www.w3.org/2001/10/xml-exc-c14n#".equals(tr.getAlgorithm())) {
/* 220 */             t.addTransform("http://www.w3.org/2001/10/xml-exc-c14n#");
/*     */           }
/* 222 */           else if ("http://www.w3.org/2001/10/xml-exc-c14n#WithComments".equals(tr.getAlgorithm())) {
/* 223 */             t.addTransform("http://www.w3.org/2001/10/xml-exc-c14n#WithComments");
/*     */           }
/* 225 */           else if ("http://www.w3.org/TR/2001/REC-xml-c14n-20010315".equals(tr.getAlgorithm())) {
/* 226 */             t.addTransform("http://www.w3.org/TR/2001/REC-xml-c14n-20010315");
/*     */           }
/* 228 */           else if ("http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments".equals(tr.getAlgorithm())) {
/* 229 */             t.addTransform("http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments");
/*     */           }
/* 231 */           else if ("http://www.w3.org/TR/1999/REC-xpath-19991116".equals(tr.getAlgorithm())) {
/* 232 */             t.addTransform("http://www.w3.org/TR/1999/REC-xpath-19991116", tr.getExtraNodes());
/*     */           }
/*     */         } catch (TransformationException ex) {
/* 235 */           logger.error("Error incluyendo transformada", ex);
/* 236 */           return in;
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 241 */       return in;
/*     */     }
/* 243 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 244 */     XMLSignatureInput xmlSignatureInput = new XMLSignatureInput(in);
/*     */     try {
/* 246 */       XMLSignatureInput resultado = null;
/* 247 */       resultado = t.performTransforms(xmlSignatureInput);
/* 248 */       baos.write(resultado.getBytes());
/*     */     } catch (TransformationException ex) {
/* 250 */       logger.error("Error calculando transformada de política", ex);
/* 251 */       return in;
/*     */     } catch (CanonicalizationException ex) {
/* 253 */       logger.error("Error calculando transformada de política", ex);
/* 254 */       return in;
/*     */     } catch (IOException ex) {
/* 256 */       logger.error("Error calculando transformada de política", ex);
/* 257 */       return in;
/*     */     }
/*     */     
/* 260 */     return baos.toByteArray();
/*     */   }
/*     */   
/*     */   private SignaturePolicyIdentifier extractInfo(Element nodoFirma, ResultadoValidacion resultadoValidacion) throws PolicyException {
/* 264 */     XAdESSchemas schema = resultadoValidacion.getDatosFirma().getEsquema();
/* 265 */     if (schema == null) {
/* 266 */       throw new PolicyException("Error obteniendo esquema de firma");
/*     */     }
/*     */     
/* 269 */     String esquema = schema.getSchemaUri();
/*     */     
/*     */ 
/* 272 */     ArrayList<Element> signaturePolicyList = null;
/*     */     try {
/* 274 */       signaturePolicyList = UtilidadTratarNodo.obtenerNodos(nodoFirma, 5, 
/* 275 */         new NombreNodo(esquema, "SignaturePolicyIdentifier"));
/*     */     } catch (FirmaXMLError e) {
/* 277 */       logger.error(e.getMessage(), e);
/* 278 */       throw new PolicyException("Error obteniendo el nodo de política: " + e.getMessage());
/*     */     }
/*     */     
/* 281 */     if (signaturePolicyList.size() != 1)
/* 282 */       throw new PolicyException("Error obteniendo nodo de política (no hay nodo, o hay más de uno)");
/* 283 */     if (((Element)signaturePolicyList.get(0)).getNodeType() != 1) {
/* 284 */       throw new PolicyException("Error obteniendo nodo de política (no es del tipo elemento)");
/*     */     }
/*     */     try {
/* 287 */       SignaturePolicyIdentifier signaturePolicyIdentifier = new SignaturePolicyIdentifier(schema);
/* 288 */       if (!signaturePolicyIdentifier.isThisNode((Node)signaturePolicyList.get(0)))
/* 289 */         throw new InvalidInfoNodeException("No se ha encontrado política");
/* 290 */       signaturePolicyIdentifier.load((Element)signaturePolicyList.get(0));
/*     */       
/* 292 */       return signaturePolicyIdentifier;
/*     */     } catch (InvalidInfoNodeException ex) {
/* 294 */       throw new PolicyException(ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setTruster(TrustAbstract truster) {}
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\xades\policy\GeneralPolicyManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */