/*    */ package es.mityc.javasign.xml.xades.policy;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.xades.ResultadoValidacion;
/*    */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*    */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SignaturePolicyIdentifier;
/*    */ import es.mityc.firmaJava.libreria.xades.errores.PolicyException;
/*    */ import es.mityc.javasign.trust.TrustAbstract;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PolicyImplied
/*    */   implements IFirmaPolicy, IValidacionPolicy
/*    */ {
/*    */   public void writePolicyNode(Element nodoFirma, String namespaceDS, String namespaceXAdES, XAdESSchemas schema)
/*    */     throws PolicyException
/*    */   {
/* 41 */     SignaturePolicyIdentifier spi = new SignaturePolicyIdentifier(schema, true);
/* 42 */     PoliciesTool.insertPolicyNode(nodoFirma, namespaceDS, namespaceXAdES, schema, spi);
/*    */   }
/*    */   
/*    */   public String getIdentidadPolicy() {
/* 46 */     return "IMPLIED";
/*    */   }
/*    */   
/*    */   public PolicyResult validaPolicy(Element nodoFirma, ResultadoValidacion resultadoValidacion) {
/* 50 */     PolicyResult policyResult = new PolicyResult();
/* 51 */     policyResult.setResult(PolicyResult.StatusValidation.valid);
/*    */     
/* 53 */     return policyResult;
/*    */   }
/*    */   
/*    */   public void setTruster(TrustAbstract truster) {}
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\xades\policy\PolicyImplied.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */