package es.mityc.javasign.xml.xades.policy;

import es.mityc.firmaJava.libreria.xades.ResultadoValidacion;
import es.mityc.javasign.trust.TrustAbstract;
import org.w3c.dom.Element;

public abstract interface IValidacionPolicy
{
  public abstract PolicyResult validaPolicy(Element paramElement, ResultadoValidacion paramResultadoValidacion);
  
  public abstract String getIdentidadPolicy();
  
  public abstract void setTruster(TrustAbstract paramTrustAbstract);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\xades\policy\IValidacionPolicy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */