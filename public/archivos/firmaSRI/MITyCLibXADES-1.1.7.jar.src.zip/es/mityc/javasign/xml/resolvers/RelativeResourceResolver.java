/*     */ package es.mityc.javasign.xml.resolvers;
/*     */ 
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolverException;
/*     */ import es.mityc.firmaJava.libreria.utilidades.UtilidadFicheros;
/*     */ import es.mityc.firmaJava.libreria.utilidades.UtilidadTratarNodo;
/*     */ import es.mityc.firmaJava.libreria.xades.CanonicalizationEnum;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.FirmaXMLError;
/*     */ import es.mityc.javasign.xml.refs.AbstractObjectToSign;
/*     */ import es.mityc.javasign.xml.refs.RelativeDetachedFileToSign;
/*     */ import java.io.File;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RelativeResourceResolver
/*     */   extends MITyCResourceResolver
/*     */ {
/*     */   private RelativeDetachedFileToSign internalResolver;
/*     */   
/*     */   public RelativeResourceResolver(File file)
/*     */   {
/*  49 */     this.internalResolver = new RelativeDetachedFileToSign(file);
/*     */   }
/*     */   
/*     */   public AbstractObjectToSign getResolver() {
/*  53 */     return this.internalResolver;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean engineCanResolve(Attr uri, String BaseURI)
/*     */   {
/*  61 */     if (this.internalResolver == null) {
/*  62 */       return false;
/*     */     }
/*     */     try {
/*  65 */       return this.internalResolver.getFile().exists();
/*     */     } catch (Exception e) {}
/*  67 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput engineResolve(Attr uri, String BaseURI)
/*     */     throws ResourceResolverException
/*     */   {
/*  76 */     if (this.internalResolver == null) {
/*  77 */       throw new ResourceResolverException("", uri, BaseURI);
/*     */     }
/*     */     
/*     */ 
/*  81 */     CanonicalizationEnum canonicalization = null;
/*     */     try {
/*  83 */       NodeList nodosCanonicalizationMethod = ((Element)uri.getOwnerElement().getParentNode()).getElementsByTagNameNS("http://www.w3.org/2000/09/xmldsig#", 
/*  84 */         "CanonicalizationMethod");
/*  85 */       int numNodosCanonicalization = nodosCanonicalizationMethod.getLength();
/*     */       
/*  87 */       if (numNodosCanonicalization > 0) {
/*  88 */         Element nodoCanonicalizationMethod = (Element)nodosCanonicalizationMethod.item(0);
/*  89 */         String meth = nodoCanonicalizationMethod.getAttribute("Algorithm");
/*  90 */         canonicalization = CanonicalizationEnum.getCanonicalization(meth);
/*  91 */         if (canonicalization.equals(CanonicalizationEnum.UNKNOWN)) {
/*  92 */           canonicalization = CanonicalizationEnum.C14N_OMIT_COMMENTS;
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/*  96 */       canonicalization = CanonicalizationEnum.C14N_OMIT_COMMENTS;
/*     */     }
/*     */     
/*  99 */     if (uri.getValue().startsWith("#")) {
/*     */       try {
/* 101 */         Element el = UtilidadTratarNodo.getElementById(uri.getOwnerDocument(), uri.getValue().substring(1));
/* 102 */         byte[] source = UtilidadTratarNodo.obtenerByte(el, canonicalization);
/* 103 */         if ((source == null) || (source.length <= 0))
/* 104 */           throw new ResourceDataException("No se puede obtener el contenido referenciado");
/* 105 */         return new XMLSignatureInput(source);
/*     */       }
/*     */       catch (ResourceDataException ex) {
/* 108 */         throw new ResourceResolverException("", uri, BaseURI);
/*     */       } catch (FirmaXMLError e) {
/* 110 */         throw new ResourceResolverException(e.getMessage(), uri, BaseURI);
/*     */       }
/*     */     }
/* 113 */     byte[] data = UtilidadFicheros.readFile(this.internalResolver.getFile());
/* 114 */     XMLSignatureInput xsi = new XMLSignatureInput(data);
/* 115 */     return xsi;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibXADES-1.1.7.jar!\es\mityc\javasign\xml\resolvers\RelativeResourceResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */