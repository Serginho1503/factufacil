/*    */ package org.jcp.xml.dsig.internal.dom;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import javax.xml.crypto.NodeSetData;
/*    */ import org.apache.xml.security.signature.NodeFilter;
/*    */ import org.apache.xml.security.signature.XMLSignatureInput;
/*    */ import org.apache.xml.security.utils.XMLUtils;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApacheNodeSetData
/*    */   implements ApacheData, NodeSetData
/*    */ {
/*    */   private XMLSignatureInput xi;
/*    */   
/*    */   public ApacheNodeSetData(XMLSignatureInput xi)
/*    */   {
/* 42 */     this.xi = xi;
/*    */   }
/*    */   
/*    */   public Iterator iterator()
/*    */   {
/* 47 */     if (this.xi.getNodeFilters() != null) {
/* 48 */       return Collections.unmodifiableSet(getNodeSet(this.xi.getNodeFilters())).iterator();
/*    */     }
/*    */     try
/*    */     {
/* 52 */       return Collections.unmodifiableSet(this.xi.getNodeSet()).iterator();
/*    */     }
/*    */     catch (Exception e) {
/* 55 */       throw new RuntimeException("unrecoverable error retrieving nodeset", e);
/*    */     }
/*    */   }
/*    */   
/*    */   public XMLSignatureInput getXMLSignatureInput()
/*    */   {
/* 61 */     return this.xi;
/*    */   }
/*    */   
/*    */   private Set getNodeSet(List nodeFilters) {
/* 65 */     if (this.xi.isNeedsToBeExpanded()) {
/* 66 */       XMLUtils.circumventBug2650(XMLUtils.getOwnerDocument(this.xi.getSubNode()));
/*    */     }
/*    */     
/*    */ 
/* 70 */     Set inputSet = new LinkedHashSet();
/* 71 */     XMLUtils.getSet(this.xi.getSubNode(), inputSet, null, !this.xi.isExcludeComments());
/*    */     
/* 73 */     Set nodeSet = new LinkedHashSet();
/* 74 */     Iterator i = inputSet.iterator();
/* 75 */     while (i.hasNext()) {
/* 76 */       Node currentNode = (Node)i.next();
/* 77 */       Iterator it = nodeFilters.iterator();
/* 78 */       boolean skipNode = false;
/* 79 */       while ((it.hasNext()) && (!skipNode)) {
/* 80 */         NodeFilter nf = (NodeFilter)it.next();
/* 81 */         if (nf.isNodeInclude(currentNode) != 1) {
/* 82 */           skipNode = true;
/*    */         }
/*    */       }
/* 85 */       if (!skipNode) {
/* 86 */         nodeSet.add(currentNode);
/*    */       }
/*    */     }
/* 89 */     return nodeSet;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\jcp\xml\dsig\internal\dom\ApacheNodeSetData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */