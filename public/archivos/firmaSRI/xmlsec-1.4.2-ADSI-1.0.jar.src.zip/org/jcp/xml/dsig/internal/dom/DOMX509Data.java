/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.security.cert.CRLException;
/*     */ import java.security.cert.CertificateEncodingException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509CRL;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.XMLStructure;
/*     */ import javax.xml.crypto.dom.DOMCryptoContext;
/*     */ import javax.xml.crypto.dsig.keyinfo.X509Data;
/*     */ import javax.xml.crypto.dsig.keyinfo.X509IssuerSerial;
/*     */ import org.apache.xml.security.exceptions.Base64DecodingException;
/*     */ import org.apache.xml.security.utils.Base64;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DOMX509Data
/*     */   extends DOMStructure
/*     */   implements X509Data
/*     */ {
/*     */   private final List content;
/*     */   private CertificateFactory cf;
/*     */   
/*     */   public DOMX509Data(List content)
/*     */   {
/*  69 */     if (content == null) {
/*  70 */       throw new NullPointerException("content cannot be null");
/*     */     }
/*  72 */     List contentCopy = new ArrayList(content);
/*  73 */     if (contentCopy.isEmpty()) {
/*  74 */       throw new IllegalArgumentException("content cannot be empty");
/*     */     }
/*  76 */     int i = 0; for (int size = contentCopy.size(); i < size; i++) {
/*  77 */       Object x509Type = contentCopy.get(i);
/*  78 */       if ((x509Type instanceof String)) {
/*  79 */         new X500Principal((String)x509Type);
/*  80 */       } else if ((!(x509Type instanceof byte[])) && (!(x509Type instanceof X509Certificate)) && (!(x509Type instanceof X509CRL)) && (!(x509Type instanceof XMLStructure)))
/*     */       {
/*     */ 
/*     */ 
/*  84 */         throw new ClassCastException("content[" + i + "] is not a valid X509Data type");
/*     */       }
/*     */     }
/*     */     
/*  88 */     this.content = Collections.unmodifiableList(contentCopy);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMX509Data(Element xdElem)
/*     */     throws MarshalException
/*     */   {
/*  99 */     NodeList nl = xdElem.getChildNodes();
/* 100 */     int length = nl.getLength();
/* 101 */     List content = new ArrayList(length);
/* 102 */     for (int i = 0; i < length; i++) {
/* 103 */       Node child = nl.item(i);
/*     */       
/* 105 */       if (child.getNodeType() == 1)
/*     */       {
/*     */ 
/*     */ 
/* 109 */         Element childElem = (Element)child;
/* 110 */         String localName = childElem.getLocalName();
/* 111 */         if (localName.equals("X509Certificate")) {
/* 112 */           content.add(unmarshalX509Certificate(childElem));
/* 113 */         } else if (localName.equals("X509IssuerSerial")) {
/* 114 */           content.add(new DOMX509IssuerSerial(childElem));
/* 115 */         } else if (localName.equals("X509SubjectName")) {
/* 116 */           content.add(childElem.getFirstChild().getNodeValue());
/* 117 */         } else if (localName.equals("X509SKI")) {
/*     */           try {
/* 119 */             content.add(Base64.decode(childElem));
/*     */           } catch (Base64DecodingException bde) {
/* 121 */             throw new MarshalException("cannot decode X509SKI", bde);
/*     */           }
/* 123 */         } else if (localName.equals("X509CRL")) {
/* 124 */           content.add(unmarshalX509CRL(childElem));
/*     */         } else
/* 126 */           content.add(new javax.xml.crypto.dom.DOMStructure(childElem));
/*     */       }
/*     */     }
/* 129 */     this.content = Collections.unmodifiableList(content);
/*     */   }
/*     */   
/*     */   public List getContent() {
/* 133 */     return this.content;
/*     */   }
/*     */   
/*     */   public void marshal(Node parent, String dsPrefix, DOMCryptoContext context) throws MarshalException
/*     */   {
/* 138 */     Document ownerDoc = DOMUtils.getOwnerDocument(parent);
/*     */     
/* 140 */     Element xdElem = DOMUtils.createElement(ownerDoc, "X509Data", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */     
/*     */ 
/*     */ 
/* 144 */     int i = 0; for (int size = this.content.size(); i < size; i++) {
/* 145 */       Object object = this.content.get(i);
/* 146 */       if ((object instanceof X509Certificate)) {
/* 147 */         marshalCert((X509Certificate)object, xdElem, ownerDoc, dsPrefix);
/* 148 */       } else if ((object instanceof XMLStructure)) {
/* 149 */         if ((object instanceof X509IssuerSerial)) {
/* 150 */           ((DOMX509IssuerSerial)object).marshal(xdElem, dsPrefix, context);
/*     */         }
/*     */         else {
/* 153 */           javax.xml.crypto.dom.DOMStructure domContent = (javax.xml.crypto.dom.DOMStructure)object;
/*     */           
/* 155 */           DOMUtils.appendChild(xdElem, domContent.getNode());
/*     */         }
/* 157 */       } else if ((object instanceof byte[])) {
/* 158 */         marshalSKI((byte[])object, xdElem, ownerDoc, dsPrefix);
/* 159 */       } else if ((object instanceof String)) {
/* 160 */         marshalSubjectName((String)object, xdElem, ownerDoc, dsPrefix);
/* 161 */       } else if ((object instanceof X509CRL)) {
/* 162 */         marshalCRL((X509CRL)object, xdElem, ownerDoc, dsPrefix);
/*     */       }
/*     */     }
/*     */     
/* 166 */     parent.appendChild(xdElem);
/*     */   }
/*     */   
/*     */ 
/*     */   private void marshalSKI(byte[] skid, Node parent, Document doc, String dsPrefix)
/*     */   {
/* 172 */     Element skidElem = DOMUtils.createElement(doc, "X509SKI", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */     
/* 174 */     skidElem.appendChild(doc.createTextNode(Base64.encode(skid)));
/* 175 */     parent.appendChild(skidElem);
/*     */   }
/*     */   
/*     */ 
/*     */   private void marshalSubjectName(String name, Node parent, Document doc, String dsPrefix)
/*     */   {
/* 181 */     Element snElem = DOMUtils.createElement(doc, "X509SubjectName", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */     
/* 183 */     snElem.appendChild(doc.createTextNode(name));
/* 184 */     parent.appendChild(snElem);
/*     */   }
/*     */   
/*     */   private void marshalCert(X509Certificate cert, Node parent, Document doc, String dsPrefix)
/*     */     throws MarshalException
/*     */   {
/* 190 */     Element certElem = DOMUtils.createElement(doc, "X509Certificate", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */     try
/*     */     {
/* 193 */       certElem.appendChild(doc.createTextNode(Base64.encode(cert.getEncoded())));
/*     */     }
/*     */     catch (CertificateEncodingException e) {
/* 196 */       throw new MarshalException("Error encoding X509Certificate", e);
/*     */     }
/* 198 */     parent.appendChild(certElem);
/*     */   }
/*     */   
/*     */   private void marshalCRL(X509CRL crl, Node parent, Document doc, String dsPrefix)
/*     */     throws MarshalException
/*     */   {
/* 204 */     Element crlElem = DOMUtils.createElement(doc, "X509CRL", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */     try
/*     */     {
/* 207 */       crlElem.appendChild(doc.createTextNode(Base64.encode(crl.getEncoded())));
/*     */     }
/*     */     catch (CRLException e) {
/* 210 */       throw new MarshalException("Error encoding X509CRL", e);
/*     */     }
/* 212 */     parent.appendChild(crlElem);
/*     */   }
/*     */   
/*     */   private X509Certificate unmarshalX509Certificate(Element elem) throws MarshalException
/*     */   {
/*     */     try {
/* 218 */       ByteArrayInputStream bs = unmarshalBase64Binary(elem);
/* 219 */       return (X509Certificate)this.cf.generateCertificate(bs);
/*     */     } catch (CertificateException e) {
/* 221 */       throw new MarshalException("Cannot create X509Certificate", e);
/*     */     }
/*     */   }
/*     */   
/*     */   private X509CRL unmarshalX509CRL(Element elem) throws MarshalException {
/*     */     try {
/* 227 */       ByteArrayInputStream bs = unmarshalBase64Binary(elem);
/* 228 */       return (X509CRL)this.cf.generateCRL(bs);
/*     */     } catch (CRLException e) {
/* 230 */       throw new MarshalException("Cannot create X509CRL", e);
/*     */     }
/*     */   }
/*     */   
/*     */   private ByteArrayInputStream unmarshalBase64Binary(Element elem) throws MarshalException
/*     */   {
/*     */     try {
/* 237 */       if (this.cf == null) {
/* 238 */         this.cf = CertificateFactory.getInstance("X.509");
/*     */       }
/* 240 */       return new ByteArrayInputStream(Base64.decode(elem));
/*     */     } catch (CertificateException e) {
/* 242 */       throw new MarshalException("Cannot create CertificateFactory", e);
/*     */     } catch (Base64DecodingException bde) {
/* 244 */       throw new MarshalException("Cannot decode Base64-encoded val", bde);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 249 */     if (this == o) {
/* 250 */       return true;
/*     */     }
/*     */     
/* 253 */     if (!(o instanceof X509Data)) {
/* 254 */       return false;
/*     */     }
/* 256 */     X509Data oxd = (X509Data)o;
/*     */     
/* 258 */     List ocontent = oxd.getContent();
/* 259 */     int size = this.content.size();
/* 260 */     if (size != ocontent.size()) {
/* 261 */       return false;
/*     */     }
/*     */     
/* 264 */     for (int i = 0; i < size; i++) {
/* 265 */       Object x = this.content.get(i);
/* 266 */       Object ox = ocontent.get(i);
/* 267 */       if ((x instanceof byte[])) {
/* 268 */         if ((!(ox instanceof byte[])) || (!Arrays.equals((byte[])x, (byte[])ox)))
/*     */         {
/* 270 */           return false;
/*     */         }
/*     */       }
/* 273 */       else if (!x.equals(ox)) {
/* 274 */         return false;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 279 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 283 */     if (!$assertionsDisabled) throw new AssertionError("hashCode not designed");
/* 284 */     return 56;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\jcp\xml\dsig\internal\dom\DOMX509Data.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */