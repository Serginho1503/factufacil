/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.Key;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.Provider;
/*     */ import java.security.PublicKey;
/*     */ import java.security.Signature;
/*     */ import java.security.SignatureException;
/*     */ import java.security.spec.AlgorithmParameterSpec;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.dom.DOMCryptoContext;
/*     */ import javax.xml.crypto.dsig.SignatureMethod;
/*     */ import javax.xml.crypto.dsig.XMLSignContext;
/*     */ import javax.xml.crypto.dsig.XMLSignatureException;
/*     */ import javax.xml.crypto.dsig.XMLValidateContext;
/*     */ import javax.xml.crypto.dsig.spec.SignatureMethodParameterSpec;
/*     */ import org.jcp.xml.dsig.internal.SignerOutputStream;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DOMSignatureMethod
/*     */   extends DOMStructure
/*     */   implements SignatureMethod
/*     */ {
/*  49 */   private static Logger log = Logger.getLogger("org.jcp.xml.dsig.internal.dom");
/*     */   
/*     */ 
/*     */   static final String RSA_SHA256 = "http://www.w3.org/2001/04/xmldsig-more#rsa-sha256";
/*     */   
/*     */ 
/*     */   static final String RSA_SHA384 = "http://www.w3.org/2001/04/xmldsig-more#rsa-sha384";
/*     */   
/*     */ 
/*     */   static final String RSA_SHA512 = "http://www.w3.org/2001/04/xmldsig-more#rsa-sha512";
/*     */   
/*     */ 
/*     */   static final String HMAC_SHA256 = "http://www.w3.org/2001/04/xmldsig-more#hmac-sha256";
/*     */   
/*     */ 
/*     */   static final String HMAC_SHA384 = "http://www.w3.org/2001/04/xmldsig-more#hmac-sha384";
/*     */   
/*     */ 
/*     */   static final String HMAC_SHA512 = "http://www.w3.org/2001/04/xmldsig-more#hmac-sha512";
/*     */   
/*     */ 
/*     */   private SignatureMethodParameterSpec params;
/*     */   
/*     */   private Signature signature;
/*     */   
/*     */ 
/*     */   DOMSignatureMethod(AlgorithmParameterSpec params)
/*     */     throws InvalidAlgorithmParameterException
/*     */   {
/*  78 */     if ((params != null) && (!(params instanceof SignatureMethodParameterSpec)))
/*     */     {
/*  80 */       throw new InvalidAlgorithmParameterException("params must be of type SignatureMethodParameterSpec");
/*     */     }
/*     */     
/*  83 */     checkParams((SignatureMethodParameterSpec)params);
/*  84 */     this.params = ((SignatureMethodParameterSpec)params);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   DOMSignatureMethod(Element smElem)
/*     */     throws MarshalException
/*     */   {
/*  95 */     Element paramsElem = DOMUtils.getFirstChildElement(smElem);
/*  96 */     if (paramsElem != null) {
/*  97 */       this.params = unmarshalParams(paramsElem);
/*     */     }
/*     */     try {
/* 100 */       checkParams(this.params);
/*     */     } catch (InvalidAlgorithmParameterException iape) {
/* 102 */       throw new MarshalException(iape);
/*     */     }
/*     */   }
/*     */   
/*     */   static SignatureMethod unmarshal(Element smElem) throws MarshalException {
/* 107 */     String alg = DOMUtils.getAttributeValue(smElem, "Algorithm");
/* 108 */     if (alg.equals("http://www.w3.org/2000/09/xmldsig#rsa-sha1"))
/* 109 */       return new SHA1withRSA(smElem);
/* 110 */     if (alg.equals("http://www.w3.org/2001/04/xmldsig-more#rsa-sha256"))
/* 111 */       return new SHA256withRSA(smElem);
/* 112 */     if (alg.equals("http://www.w3.org/2001/04/xmldsig-more#rsa-sha384"))
/* 113 */       return new SHA384withRSA(smElem);
/* 114 */     if (alg.equals("http://www.w3.org/2001/04/xmldsig-more#rsa-sha512"))
/* 115 */       return new SHA512withRSA(smElem);
/* 116 */     if (alg.equals("http://www.w3.org/2000/09/xmldsig#dsa-sha1"))
/* 117 */       return new SHA1withDSA(smElem);
/* 118 */     if (alg.equals("http://www.w3.org/2000/09/xmldsig#hmac-sha1"))
/* 119 */       return new DOMHMACSignatureMethod.SHA1(smElem);
/* 120 */     if (alg.equals("http://www.w3.org/2001/04/xmldsig-more#hmac-sha256"))
/* 121 */       return new DOMHMACSignatureMethod.SHA256(smElem);
/* 122 */     if (alg.equals("http://www.w3.org/2001/04/xmldsig-more#hmac-sha384"))
/* 123 */       return new DOMHMACSignatureMethod.SHA384(smElem);
/* 124 */     if (alg.equals("http://www.w3.org/2001/04/xmldsig-more#hmac-sha512")) {
/* 125 */       return new DOMHMACSignatureMethod.SHA512(smElem);
/*     */     }
/* 127 */     throw new MarshalException("unsupported SignatureMethod algorithm: " + alg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void checkParams(SignatureMethodParameterSpec params)
/*     */     throws InvalidAlgorithmParameterException
/*     */   {
/* 144 */     if (params != null) {
/* 145 */       throw new InvalidAlgorithmParameterException("no parameters should be specified for the " + getSignatureAlgorithm() + " SignatureMethod algorithm");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public final AlgorithmParameterSpec getParameterSpec()
/*     */   {
/* 152 */     return this.params;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   SignatureMethodParameterSpec unmarshalParams(Element paramsElem)
/*     */     throws MarshalException
/*     */   {
/* 167 */     throw new MarshalException("no parameters should be specified for the " + getSignatureAlgorithm() + " SignatureMethod algorithm");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void marshal(Node parent, String dsPrefix, DOMCryptoContext context)
/*     */     throws MarshalException
/*     */   {
/* 178 */     Document ownerDoc = DOMUtils.getOwnerDocument(parent);
/*     */     
/* 180 */     Element smElem = DOMUtils.createElement(ownerDoc, "SignatureMethod", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */     
/* 182 */     DOMUtils.setAttribute(smElem, "Algorithm", getAlgorithm());
/*     */     
/* 184 */     if (this.params != null) {
/* 185 */       marshalParams(smElem, dsPrefix);
/*     */     }
/*     */     
/* 188 */     parent.appendChild(smElem);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean verify(Key key, DOMSignedInfo si, byte[] sig, XMLValidateContext context)
/*     */     throws InvalidKeyException, SignatureException, XMLSignatureException
/*     */   {
/* 212 */     if ((key == null) || (si == null) || (sig == null)) {
/* 213 */       throw new NullPointerException();
/*     */     }
/*     */     
/* 216 */     if (!(key instanceof PublicKey)) {
/* 217 */       throw new InvalidKeyException("key must be PublicKey");
/*     */     }
/* 219 */     if (this.signature == null) {
/*     */       try {
/* 221 */         Provider p = (Provider)context.getProperty("org.jcp.xml.dsig.internal.dom.SignatureProvider");
/*     */         
/* 223 */         this.signature = (p == null ? Signature.getInstance(getSignatureAlgorithm()) : Signature.getInstance(getSignatureAlgorithm(), p));
/*     */       }
/*     */       catch (NoSuchAlgorithmException nsae)
/*     */       {
/* 227 */         throw new XMLSignatureException(nsae);
/*     */       }
/*     */     }
/* 230 */     this.signature.initVerify((PublicKey)key);
/* 231 */     if (log.isLoggable(Level.FINE)) {
/* 232 */       log.log(Level.FINE, "Signature provider:" + this.signature.getProvider());
/* 233 */       log.log(Level.FINE, "verifying with key: " + key);
/*     */     }
/* 235 */     si.canonicalize(context, new SignerOutputStream(this.signature));
/*     */     
/* 237 */     if (getAlgorithm().equals("http://www.w3.org/2000/09/xmldsig#dsa-sha1")) {
/*     */       try {
/* 239 */         return this.signature.verify(convertXMLDSIGtoASN1(sig));
/*     */       } catch (IOException ioe) {
/* 241 */         throw new XMLSignatureException(ioe);
/*     */       }
/*     */     }
/* 244 */     return this.signature.verify(sig);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] sign(Key key, DOMSignedInfo si, XMLSignContext context)
/*     */     throws InvalidKeyException, XMLSignatureException
/*     */   {
/* 264 */     if ((key == null) || (si == null)) {
/* 265 */       throw new NullPointerException();
/*     */     }
/*     */     
/* 268 */     if (!(key instanceof PrivateKey)) {
/* 269 */       throw new InvalidKeyException("key must be PrivateKey");
/*     */     }
/* 271 */     if (this.signature == null) {
/*     */       try {
/* 273 */         Provider p = (Provider)context.getProperty("org.jcp.xml.dsig.internal.dom.SignatureProvider");
/*     */         
/* 275 */         this.signature = (p == null ? Signature.getInstance(getSignatureAlgorithm()) : Signature.getInstance(getSignatureAlgorithm(), p));
/*     */       }
/*     */       catch (NoSuchAlgorithmException nsae)
/*     */       {
/* 279 */         throw new XMLSignatureException(nsae);
/*     */       }
/*     */     }
/* 282 */     this.signature.initSign((PrivateKey)key);
/* 283 */     if (log.isLoggable(Level.FINE)) {
/* 284 */       log.log(Level.FINE, "Signature provider:" + this.signature.getProvider());
/* 285 */       log.log(Level.FINE, "Signing with key: " + key);
/*     */     }
/*     */     
/* 288 */     si.canonicalize(context, new SignerOutputStream(this.signature));
/*     */     try
/*     */     {
/* 291 */       if (getAlgorithm().equals("http://www.w3.org/2000/09/xmldsig#dsa-sha1")) {
/* 292 */         return convertASN1toXMLDSIG(this.signature.sign());
/*     */       }
/* 294 */       return this.signature.sign();
/*     */     }
/*     */     catch (SignatureException se) {
/* 297 */       throw new XMLSignatureException(se);
/*     */     } catch (IOException ioe) {
/* 299 */       throw new XMLSignatureException(ioe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void marshalParams(Element parent, String paramsPrefix)
/*     */     throws MarshalException
/*     */   {
/* 315 */     throw new MarshalException("no parameters should be specified for the " + getSignatureAlgorithm() + " SignatureMethod algorithm");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   abstract String getSignatureAlgorithm();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean paramsEqual(AlgorithmParameterSpec spec)
/*     */   {
/* 332 */     return getParameterSpec() == spec;
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 336 */     if (this == o) {
/* 337 */       return true;
/*     */     }
/*     */     
/* 340 */     if (!(o instanceof SignatureMethod)) {
/* 341 */       return false;
/*     */     }
/* 343 */     SignatureMethod osm = (SignatureMethod)o;
/*     */     
/* 345 */     return (getAlgorithm().equals(osm.getAlgorithm())) && (paramsEqual(osm.getParameterSpec()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static byte[] convertASN1toXMLDSIG(byte[] asn1Bytes)
/*     */     throws IOException
/*     */   {
/* 363 */     byte rLength = asn1Bytes[3];
/*     */     
/*     */ 
/* 366 */     for (int i = rLength; (i > 0) && (asn1Bytes[(4 + rLength - i)] == 0); i--) {}
/*     */     
/* 368 */     byte sLength = asn1Bytes[(5 + rLength)];
/*     */     
/*     */ 
/* 371 */     int j = sLength;
/* 372 */     while ((j > 0) && (asn1Bytes[(6 + rLength + sLength - j)] == 0)) { j--;
/*     */     }
/* 374 */     if ((asn1Bytes[0] != 48) || (asn1Bytes[1] != asn1Bytes.length - 2) || (asn1Bytes[2] != 2) || (i > 20) || (asn1Bytes[(4 + rLength)] != 2) || (j > 20))
/*     */     {
/*     */ 
/* 377 */       throw new IOException("Invalid ASN.1 format of DSA signature");
/*     */     }
/* 379 */     byte[] xmldsigBytes = new byte[40];
/*     */     
/* 381 */     System.arraycopy(asn1Bytes, 4 + rLength - i, xmldsigBytes, 20 - i, i);
/* 382 */     System.arraycopy(asn1Bytes, 6 + rLength + sLength - j, xmldsigBytes, 40 - j, j);
/*     */     
/*     */ 
/* 385 */     return xmldsigBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static byte[] convertXMLDSIGtoASN1(byte[] xmldsigBytes)
/*     */     throws IOException
/*     */   {
/* 403 */     if (xmldsigBytes.length != 40) {
/* 404 */       throw new IOException("Invalid XMLDSIG format of DSA signature");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 409 */     for (int i = 20; (i > 0) && (xmldsigBytes[(20 - i)] == 0); i--) {}
/*     */     
/* 411 */     int j = i;
/*     */     
/* 413 */     if (xmldsigBytes[(20 - i)] < 0) {
/* 414 */       j++;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 419 */     for (int k = 20; (k > 0) && (xmldsigBytes[(40 - k)] == 0); k--) {}
/*     */     
/* 421 */     int l = k;
/*     */     
/* 423 */     if (xmldsigBytes[(40 - k)] < 0) {
/* 424 */       l++;
/*     */     }
/*     */     
/* 427 */     byte[] asn1Bytes = new byte[6 + j + l];
/*     */     
/* 429 */     asn1Bytes[0] = 48;
/* 430 */     asn1Bytes[1] = ((byte)(4 + j + l));
/* 431 */     asn1Bytes[2] = 2;
/* 432 */     asn1Bytes[3] = ((byte)j);
/*     */     
/* 434 */     System.arraycopy(xmldsigBytes, 20 - i, asn1Bytes, 4 + j - i, i);
/*     */     
/* 436 */     asn1Bytes[(4 + j)] = 2;
/* 437 */     asn1Bytes[(5 + j)] = ((byte)l);
/*     */     
/* 439 */     System.arraycopy(xmldsigBytes, 40 - k, asn1Bytes, 6 + j + l - k, k);
/*     */     
/* 441 */     return asn1Bytes;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 445 */     if (!$assertionsDisabled) throw new AssertionError("hashCode not designed");
/* 446 */     return 57;
/*     */   }
/*     */   
/*     */   static final class SHA1withRSA extends DOMSignatureMethod
/*     */   {
/*     */     SHA1withRSA(AlgorithmParameterSpec params) throws InvalidAlgorithmParameterException {
/* 452 */       super();
/*     */     }
/*     */     
/* 455 */     SHA1withRSA(Element dmElem) throws MarshalException { super(); }
/*     */     
/*     */     public String getAlgorithm() {
/* 458 */       return "http://www.w3.org/2000/09/xmldsig#rsa-sha1";
/*     */     }
/*     */     
/* 461 */     String getSignatureAlgorithm() { return "SHA1withRSA"; }
/*     */   }
/*     */   
/*     */   static final class SHA256withRSA extends DOMSignatureMethod
/*     */   {
/*     */     SHA256withRSA(AlgorithmParameterSpec params) throws InvalidAlgorithmParameterException
/*     */     {
/* 468 */       super();
/*     */     }
/*     */     
/* 471 */     SHA256withRSA(Element dmElem) throws MarshalException { super(); }
/*     */     
/*     */     public String getAlgorithm() {
/* 474 */       return "http://www.w3.org/2001/04/xmldsig-more#rsa-sha256";
/*     */     }
/*     */     
/* 477 */     String getSignatureAlgorithm() { return "SHA256withRSA"; }
/*     */   }
/*     */   
/*     */   static final class SHA384withRSA extends DOMSignatureMethod
/*     */   {
/*     */     SHA384withRSA(AlgorithmParameterSpec params) throws InvalidAlgorithmParameterException
/*     */     {
/* 484 */       super();
/*     */     }
/*     */     
/* 487 */     SHA384withRSA(Element dmElem) throws MarshalException { super(); }
/*     */     
/*     */     public String getAlgorithm() {
/* 490 */       return "http://www.w3.org/2001/04/xmldsig-more#rsa-sha384";
/*     */     }
/*     */     
/* 493 */     String getSignatureAlgorithm() { return "SHA384withRSA"; }
/*     */   }
/*     */   
/*     */   static final class SHA512withRSA extends DOMSignatureMethod
/*     */   {
/*     */     SHA512withRSA(AlgorithmParameterSpec params) throws InvalidAlgorithmParameterException
/*     */     {
/* 500 */       super();
/*     */     }
/*     */     
/* 503 */     SHA512withRSA(Element dmElem) throws MarshalException { super(); }
/*     */     
/*     */     public String getAlgorithm() {
/* 506 */       return "http://www.w3.org/2001/04/xmldsig-more#rsa-sha512";
/*     */     }
/*     */     
/* 509 */     String getSignatureAlgorithm() { return "SHA512withRSA"; }
/*     */   }
/*     */   
/*     */   static final class SHA1withDSA extends DOMSignatureMethod
/*     */   {
/*     */     SHA1withDSA(AlgorithmParameterSpec params) throws InvalidAlgorithmParameterException
/*     */     {
/* 516 */       super();
/*     */     }
/*     */     
/* 519 */     SHA1withDSA(Element dmElem) throws MarshalException { super(); }
/*     */     
/*     */     public String getAlgorithm() {
/* 522 */       return "http://www.w3.org/2000/09/xmldsig#dsa-sha1";
/*     */     }
/*     */     
/* 525 */     String getSignatureAlgorithm() { return "SHA1withDSA"; }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\jcp\xml\dsig\internal\dom\DOMSignatureMethod.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */