/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import java.security.KeyException;
/*     */ import java.security.PublicKey;
/*     */ import java.util.List;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.URIDereferencer;
/*     */ import javax.xml.crypto.XMLStructure;
/*     */ import javax.xml.crypto.dom.DOMStructure;
/*     */ import javax.xml.crypto.dsig.keyinfo.KeyInfo;
/*     */ import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
/*     */ import javax.xml.crypto.dsig.keyinfo.KeyName;
/*     */ import javax.xml.crypto.dsig.keyinfo.KeyValue;
/*     */ import javax.xml.crypto.dsig.keyinfo.PGPData;
/*     */ import javax.xml.crypto.dsig.keyinfo.RetrievalMethod;
/*     */ import javax.xml.crypto.dsig.keyinfo.X509Data;
/*     */ import javax.xml.crypto.dsig.keyinfo.X509IssuerSerial;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DOMKeyInfoFactory
/*     */   extends KeyInfoFactory
/*     */ {
/*     */   public KeyInfo newKeyInfo(List content)
/*     */   {
/*  47 */     return newKeyInfo(content, null);
/*     */   }
/*     */   
/*     */   public KeyInfo newKeyInfo(List content, String id) {
/*  51 */     return new DOMKeyInfo(content, id);
/*     */   }
/*     */   
/*     */   public KeyName newKeyName(String name) {
/*  55 */     return new DOMKeyName(name);
/*     */   }
/*     */   
/*     */   public KeyValue newKeyValue(PublicKey key) throws KeyException {
/*  59 */     return new DOMKeyValue(key);
/*     */   }
/*     */   
/*     */   public PGPData newPGPData(byte[] keyId) {
/*  63 */     return newPGPData(keyId, null, null);
/*     */   }
/*     */   
/*     */   public PGPData newPGPData(byte[] keyId, byte[] keyPacket, List other) {
/*  67 */     return new DOMPGPData(keyId, keyPacket, other);
/*     */   }
/*     */   
/*     */   public PGPData newPGPData(byte[] keyPacket, List other) {
/*  71 */     return new DOMPGPData(keyPacket, other);
/*     */   }
/*     */   
/*     */   public RetrievalMethod newRetrievalMethod(String uri) {
/*  75 */     return newRetrievalMethod(uri, null, null);
/*     */   }
/*     */   
/*     */   public RetrievalMethod newRetrievalMethod(String uri, String type, List transforms)
/*     */   {
/*  80 */     if (uri == null) {
/*  81 */       throw new NullPointerException("uri must not be null");
/*     */     }
/*  83 */     return new DOMRetrievalMethod(uri, type, transforms);
/*     */   }
/*     */   
/*     */   public X509Data newX509Data(List content) {
/*  87 */     return new DOMX509Data(content);
/*     */   }
/*     */   
/*     */   public X509IssuerSerial newX509IssuerSerial(String issuerName, BigInteger serialNumber)
/*     */   {
/*  92 */     return new DOMX509IssuerSerial(issuerName, serialNumber);
/*     */   }
/*     */   
/*     */   public boolean isFeatureSupported(String feature) {
/*  96 */     if (feature == null) {
/*  97 */       throw new NullPointerException();
/*     */     }
/*  99 */     return false;
/*     */   }
/*     */   
/*     */   public URIDereferencer getURIDereferencer()
/*     */   {
/* 104 */     return DOMURIDereferencer.INSTANCE;
/*     */   }
/*     */   
/*     */   public KeyInfo unmarshalKeyInfo(XMLStructure xmlStructure) throws MarshalException
/*     */   {
/* 109 */     if (xmlStructure == null) {
/* 110 */       throw new NullPointerException("xmlStructure cannot be null");
/*     */     }
/* 112 */     Node node = ((DOMStructure)xmlStructure).getNode();
/*     */     
/* 114 */     node.normalize();
/*     */     
/* 116 */     Element element = null;
/* 117 */     if (node.getNodeType() == 9) {
/* 118 */       element = ((Document)node).getDocumentElement();
/* 119 */     } else if (node.getNodeType() == 1) {
/* 120 */       element = (Element)node;
/*     */     } else {
/* 122 */       throw new MarshalException("xmlStructure does not contain a proper Node");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 127 */     String tag = element.getLocalName();
/* 128 */     if (tag == null) {
/* 129 */       throw new MarshalException("Document implementation must support DOM Level 2 and be namespace aware");
/*     */     }
/*     */     
/* 132 */     if (tag.equals("KeyInfo")) {
/* 133 */       return new DOMKeyInfo(element, null, getProvider());
/*     */     }
/* 135 */     throw new MarshalException("invalid KeyInfo tag: " + tag);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\jcp\xml\dsig\internal\dom\DOMKeyInfoFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */