/*    */ package org.jcp.xml.dsig.internal;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import javax.crypto.Mac;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MacOutputStream
/*    */   extends ByteArrayOutputStream
/*    */ {
/*    */   private final Mac mac;
/*    */   
/*    */   public MacOutputStream(Mac mac)
/*    */   {
/* 34 */     this.mac = mac;
/*    */   }
/*    */   
/*    */   public void write(byte[] arg0)
/*    */   {
/* 39 */     super.write(arg0, 0, arg0.length);
/* 40 */     this.mac.update(arg0);
/*    */   }
/*    */   
/*    */   public void write(int arg0)
/*    */   {
/* 45 */     super.write(arg0);
/* 46 */     this.mac.update((byte)arg0);
/*    */   }
/*    */   
/*    */   public void write(byte[] arg0, int arg1, int arg2)
/*    */   {
/* 51 */     super.write(arg0, arg1, arg2);
/* 52 */     this.mac.update(arg0, arg1, arg2);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\jcp\xml\dsig\internal\MacOutputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */