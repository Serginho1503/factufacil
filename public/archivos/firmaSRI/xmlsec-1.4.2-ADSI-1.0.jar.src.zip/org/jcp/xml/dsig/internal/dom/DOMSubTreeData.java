/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import javax.xml.crypto.NodeSetData;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMSubTreeData
/*     */   implements NodeSetData
/*     */ {
/*     */   private boolean excludeComments;
/*     */   private Iterator ni;
/*     */   private Node root;
/*     */   
/*     */   public DOMSubTreeData(Node root, boolean excludeComments)
/*     */   {
/*  48 */     this.root = root;
/*  49 */     this.ni = new DelayedNodeIterator(root, excludeComments);
/*  50 */     this.excludeComments = excludeComments;
/*     */   }
/*     */   
/*     */   public Iterator iterator() {
/*  54 */     return this.ni;
/*     */   }
/*     */   
/*     */   public Node getRoot() {
/*  58 */     return this.root;
/*     */   }
/*     */   
/*     */   public boolean excludeComments() {
/*  62 */     return this.excludeComments;
/*     */   }
/*     */   
/*     */ 
/*     */   static class DelayedNodeIterator
/*     */     implements Iterator
/*     */   {
/*     */     private Node root;
/*     */     private List nodeSet;
/*     */     private ListIterator li;
/*     */     private boolean withComments;
/*     */     
/*     */     DelayedNodeIterator(Node root, boolean excludeComments)
/*     */     {
/*  76 */       this.root = root;
/*  77 */       this.withComments = (!excludeComments);
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/*  81 */       if (this.nodeSet == null) {
/*  82 */         this.nodeSet = dereferenceSameDocumentURI(this.root);
/*  83 */         this.li = this.nodeSet.listIterator();
/*     */       }
/*  85 */       return this.li.hasNext();
/*     */     }
/*     */     
/*     */     public Object next() {
/*  89 */       if (this.nodeSet == null) {
/*  90 */         this.nodeSet = dereferenceSameDocumentURI(this.root);
/*  91 */         this.li = this.nodeSet.listIterator();
/*     */       }
/*  93 */       if (this.li.hasNext()) {
/*  94 */         return (Node)this.li.next();
/*     */       }
/*  96 */       throw new NoSuchElementException();
/*     */     }
/*     */     
/*     */     public void remove()
/*     */     {
/* 101 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private List dereferenceSameDocumentURI(Node node)
/*     */     {
/* 112 */       List nodeSet = new ArrayList();
/* 113 */       if (node != null) {
/* 114 */         nodeSetMinusCommentNodes(node, nodeSet, null);
/*     */       }
/* 116 */       return nodeSet;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void nodeSetMinusCommentNodes(Node node, List nodeSet, Node prevSibling)
/*     */     {
/* 130 */       switch (node.getNodeType()) {
/*     */       case 1: 
/* 132 */         NamedNodeMap attrs = node.getAttributes();
/* 133 */         if (attrs != null) {
/* 134 */           int i = 0; for (int len = attrs.getLength(); i < len; i++) {
/* 135 */             nodeSet.add(attrs.item(i));
/*     */           }
/*     */         }
/* 138 */         nodeSet.add(node);
/*     */       case 9: 
/* 140 */         Node pSibling = null;
/* 141 */         for (Node child = node.getFirstChild(); child != null; 
/* 142 */             child = child.getNextSibling()) {
/* 143 */           nodeSetMinusCommentNodes(child, nodeSet, pSibling);
/* 144 */           pSibling = child;
/*     */         }
/* 146 */         break;
/*     */       
/*     */ 
/*     */       case 3: 
/*     */       case 4: 
/* 151 */         if ((prevSibling != null) && ((prevSibling.getNodeType() == 3) || (prevSibling.getNodeType() == 4)))
/*     */         {
/* 153 */           return;
/*     */         }
/*     */       case 7: 
/* 156 */         nodeSet.add(node);
/* 157 */         break;
/*     */       case 8: 
/* 159 */         if (this.withComments) {
/* 160 */           nodeSet.add(node);
/*     */         }
/*     */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\jcp\xml\dsig\internal\dom\DOMSubTreeData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */