package org.jcp.xml.dsig.internal.dom;

import javax.xml.crypto.Data;
import org.apache.xml.security.signature.XMLSignatureInput;

public abstract interface ApacheData
  extends Data
{
  public abstract XMLSignatureInput getXMLSignatureInput();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\jcp\xml\dsig\internal\dom\ApacheData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */