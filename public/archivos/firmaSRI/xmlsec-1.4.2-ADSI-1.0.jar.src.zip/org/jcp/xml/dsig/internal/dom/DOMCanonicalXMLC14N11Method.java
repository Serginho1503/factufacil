/*    */ package org.jcp.xml.dsig.internal.dom;
/*    */ 
/*    */ import java.security.InvalidAlgorithmParameterException;
/*    */ import javax.xml.crypto.Data;
/*    */ import javax.xml.crypto.XMLCryptoContext;
/*    */ import javax.xml.crypto.dsig.TransformException;
/*    */ import javax.xml.crypto.dsig.spec.TransformParameterSpec;
/*    */ import org.apache.xml.security.c14n.Canonicalizer;
/*    */ import org.apache.xml.security.c14n.InvalidCanonicalizerException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DOMCanonicalXMLC14N11Method
/*    */   extends ApacheCanonicalizer
/*    */ {
/*    */   public static final String C14N_11 = "http://www.w3.org/2006/12/xml-c14n11";
/*    */   public static final String C14N_11_WITH_COMMENTS = "http://www.w3.org/2006/12/xml-c14n11#WithComments";
/*    */   
/*    */   public void init(TransformParameterSpec params)
/*    */     throws InvalidAlgorithmParameterException
/*    */   {
/* 48 */     if (params != null) {
/* 49 */       throw new InvalidAlgorithmParameterException("no parameters should be specified for Canonical XML 1.1 algorithm");
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Data transform(Data data, XMLCryptoContext xc)
/*    */     throws TransformException
/*    */   {
/* 60 */     if ((data instanceof DOMSubTreeData)) {
/* 61 */       DOMSubTreeData subTree = (DOMSubTreeData)data;
/* 62 */       if (subTree.excludeComments()) {
/*    */         try {
/* 64 */           this.apacheCanonicalizer = Canonicalizer.getInstance("http://www.w3.org/2006/12/xml-c14n11");
/*    */         } catch (InvalidCanonicalizerException ice) {
/* 66 */           throw new TransformException("Couldn't find Canonicalizer for: http://www.w3.org/2006/12/xml-c14n11: " + ice.getMessage(), ice);
/*    */         }
/*    */       }
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 73 */     return canonicalize(data, xc);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\jcp\xml\dsig\internal\dom\DOMCanonicalXMLC14N11Method.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */