/*    */ package org.jcp.xml.dsig.internal.dom;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.xml.crypto.OctetStreamData;
/*    */ import org.apache.xml.security.c14n.CanonicalizationException;
/*    */ import org.apache.xml.security.signature.XMLSignatureInput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApacheOctetStreamData
/*    */   extends OctetStreamData
/*    */   implements ApacheData
/*    */ {
/*    */   private XMLSignatureInput xi;
/*    */   
/*    */   public ApacheOctetStreamData(XMLSignatureInput xi)
/*    */     throws CanonicalizationException, IOException
/*    */   {
/* 37 */     super(xi.getOctetStream(), xi.getSourceURI(), xi.getMIMEType());
/* 38 */     this.xi = xi;
/*    */   }
/*    */   
/*    */   public XMLSignatureInput getXMLSignatureInput() {
/* 42 */     return this.xi;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\jcp\xml\dsig\internal\dom\ApacheOctetStreamData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */