/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.XMLStructure;
/*     */ import javax.xml.crypto.dom.DOMCryptoContext;
/*     */ import javax.xml.crypto.dsig.SignatureProperty;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DOMSignatureProperty
/*     */   extends DOMStructure
/*     */   implements SignatureProperty
/*     */ {
/*     */   private final String id;
/*     */   private final String target;
/*     */   private final List content;
/*     */   
/*     */   public DOMSignatureProperty(List content, String target, String id)
/*     */   {
/*  62 */     if (target == null)
/*  63 */       throw new NullPointerException("target cannot be null");
/*  64 */     if (content == null)
/*  65 */       throw new NullPointerException("content cannot be null");
/*  66 */     if (content.isEmpty()) {
/*  67 */       throw new IllegalArgumentException("content cannot be empty");
/*     */     }
/*  69 */     List contentCopy = new ArrayList(content);
/*  70 */     int i = 0; for (int size = contentCopy.size(); i < size; i++) {
/*  71 */       if (!(contentCopy.get(i) instanceof XMLStructure)) {
/*  72 */         throw new ClassCastException("content[" + i + "] is not a valid type");
/*     */       }
/*     */     }
/*     */     
/*  76 */     this.content = Collections.unmodifiableList(contentCopy);
/*     */     
/*  78 */     this.target = target;
/*  79 */     this.id = id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMSignatureProperty(Element propElem)
/*     */     throws MarshalException
/*     */   {
/*  89 */     this.target = DOMUtils.getAttributeValue(propElem, "Target");
/*  90 */     if (this.target == null) {
/*  91 */       throw new MarshalException("target cannot be null");
/*     */     }
/*  93 */     this.id = DOMUtils.getAttributeValue(propElem, "Id");
/*     */     
/*  95 */     NodeList nodes = propElem.getChildNodes();
/*  96 */     int length = nodes.getLength();
/*  97 */     List content = new ArrayList(length);
/*  98 */     for (int i = 0; i < length; i++) {
/*  99 */       content.add(new javax.xml.crypto.dom.DOMStructure(nodes.item(i)));
/*     */     }
/* 101 */     if (content.isEmpty()) {
/* 102 */       throw new MarshalException("content cannot be empty");
/*     */     }
/* 104 */     this.content = Collections.unmodifiableList(content);
/*     */   }
/*     */   
/*     */   public List getContent()
/*     */   {
/* 109 */     return this.content;
/*     */   }
/*     */   
/*     */   public String getId() {
/* 113 */     return this.id;
/*     */   }
/*     */   
/*     */   public String getTarget() {
/* 117 */     return this.target;
/*     */   }
/*     */   
/*     */   public void marshal(Node parent, String dsPrefix, DOMCryptoContext context) throws MarshalException
/*     */   {
/* 122 */     Document ownerDoc = DOMUtils.getOwnerDocument(parent);
/*     */     
/* 124 */     Element propElem = DOMUtils.createElement(ownerDoc, "SignatureProperty", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */     
/*     */ 
/*     */ 
/* 128 */     DOMUtils.setAttributeID(propElem, "Id", this.id);
/* 129 */     DOMUtils.setAttribute(propElem, "Target", this.target);
/*     */     
/*     */ 
/* 132 */     int i = 0; for (int size = this.content.size(); i < size; i++) {
/* 133 */       javax.xml.crypto.dom.DOMStructure property = (javax.xml.crypto.dom.DOMStructure)this.content.get(i);
/*     */       
/* 135 */       DOMUtils.appendChild(propElem, property.getNode());
/*     */     }
/*     */     
/* 138 */     parent.appendChild(propElem);
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 142 */     if (this == o) {
/* 143 */       return true;
/*     */     }
/*     */     
/* 146 */     if (!(o instanceof SignatureProperty)) {
/* 147 */       return false;
/*     */     }
/* 149 */     SignatureProperty osp = (SignatureProperty)o;
/*     */     
/* 151 */     boolean idsEqual = this.id == null ? false : osp.getId() == null ? true : this.id.equals(osp.getId());
/*     */     
/*     */ 
/* 154 */     return (equalsContent(osp.getContent())) && (this.target.equals(osp.getTarget())) && (idsEqual);
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 159 */     if (!$assertionsDisabled) throw new AssertionError("hashCode not designed");
/* 160 */     return 50;
/*     */   }
/*     */   
/*     */   private boolean equalsContent(List otherContent) {
/* 164 */     int osize = otherContent.size();
/* 165 */     if (this.content.size() != osize) {
/* 166 */       return false;
/*     */     }
/* 168 */     for (int i = 0; i < osize; i++) {
/* 169 */       XMLStructure oxs = (XMLStructure)otherContent.get(i);
/* 170 */       XMLStructure xs = (XMLStructure)this.content.get(i);
/* 171 */       if ((oxs instanceof javax.xml.crypto.dom.DOMStructure)) {
/* 172 */         if (!(xs instanceof javax.xml.crypto.dom.DOMStructure)) {
/* 173 */           return false;
/*     */         }
/* 175 */         Node onode = ((javax.xml.crypto.dom.DOMStructure)oxs).getNode();
/*     */         
/* 177 */         Node node = ((javax.xml.crypto.dom.DOMStructure)xs).getNode();
/*     */         
/* 179 */         if (!DOMUtils.nodesEqual(node, onode)) {
/* 180 */           return false;
/*     */         }
/*     */       }
/* 183 */       else if (!xs.equals(oxs)) {
/* 184 */         return false;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 189 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\jcp\xml\dsig\internal\dom\DOMSignatureProperty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */