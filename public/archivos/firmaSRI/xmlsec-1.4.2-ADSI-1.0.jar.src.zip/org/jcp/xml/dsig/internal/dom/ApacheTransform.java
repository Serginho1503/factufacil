/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.io.OutputStream;
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.spec.AlgorithmParameterSpec;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.xml.crypto.Data;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.NodeSetData;
/*     */ import javax.xml.crypto.OctetStreamData;
/*     */ import javax.xml.crypto.XMLCryptoContext;
/*     */ import javax.xml.crypto.XMLStructure;
/*     */ import javax.xml.crypto.dom.DOMCryptoContext;
/*     */ import javax.xml.crypto.dom.DOMStructure;
/*     */ import javax.xml.crypto.dsig.TransformException;
/*     */ import javax.xml.crypto.dsig.TransformService;
/*     */ import javax.xml.crypto.dsig.spec.TransformParameterSpec;
/*     */ import org.apache.xml.security.Init;
/*     */ import org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import org.apache.xml.security.transforms.Transform;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ApacheTransform
/*     */   extends TransformService
/*     */ {
/*  56 */   private static Logger log = Logger.getLogger("org.jcp.xml.dsig.internal.dom");
/*     */   private Transform apacheTransform;
/*     */   protected Document ownerDoc;
/*     */   protected Element transformElem;
/*     */   protected TransformParameterSpec params;
/*     */   
/*     */   public final AlgorithmParameterSpec getParameterSpec() {
/*  63 */     return this.params;
/*     */   }
/*     */   
/*     */   public void init(XMLStructure parent, XMLCryptoContext context) throws InvalidAlgorithmParameterException
/*     */   {
/*  68 */     if ((context != null) && (!(context instanceof DOMCryptoContext))) {
/*  69 */       throw new ClassCastException("context must be of type DOMCryptoContext");
/*     */     }
/*     */     
/*  72 */     this.transformElem = ((Element)((DOMStructure)parent).getNode());
/*     */     
/*  74 */     this.ownerDoc = DOMUtils.getOwnerDocument(this.transformElem);
/*     */   }
/*     */   
/*     */   public void marshalParams(XMLStructure parent, XMLCryptoContext context) throws MarshalException
/*     */   {
/*  79 */     if ((context != null) && (!(context instanceof DOMCryptoContext))) {
/*  80 */       throw new ClassCastException("context must be of type DOMCryptoContext");
/*     */     }
/*     */     
/*  83 */     this.transformElem = ((Element)((DOMStructure)parent).getNode());
/*     */     
/*  85 */     this.ownerDoc = DOMUtils.getOwnerDocument(this.transformElem);
/*     */   }
/*     */   
/*     */   public Data transform(Data data, XMLCryptoContext xc) throws TransformException
/*     */   {
/*  90 */     if (data == null) {
/*  91 */       throw new NullPointerException("data must not be null");
/*     */     }
/*  93 */     return transformIt(data, xc, (OutputStream)null);
/*     */   }
/*     */   
/*     */   public Data transform(Data data, XMLCryptoContext xc, OutputStream os) throws TransformException
/*     */   {
/*  98 */     if (data == null) {
/*  99 */       throw new NullPointerException("data must not be null");
/*     */     }
/* 101 */     if (os == null) {
/* 102 */       throw new NullPointerException("output stream must not be null");
/*     */     }
/* 104 */     return transformIt(data, xc, os);
/*     */   }
/*     */   
/*     */   private Data transformIt(Data data, XMLCryptoContext xc, OutputStream os)
/*     */     throws TransformException
/*     */   {
/* 110 */     if (this.ownerDoc == null) {
/* 111 */       throw new TransformException("transform must be marshalled");
/*     */     }
/*     */     
/* 114 */     if (this.apacheTransform == null) {
/*     */       try {
/* 116 */         this.apacheTransform = Transform.getInstance(this.ownerDoc, getAlgorithm(), this.transformElem.getChildNodes());
/*     */         
/* 118 */         this.apacheTransform.setElement(this.transformElem, xc.getBaseURI());
/* 119 */         if (log.isLoggable(Level.FINE)) {
/* 120 */           log.log(Level.FINE, "Created transform for algorithm: " + getAlgorithm());
/*     */         }
/*     */       }
/*     */       catch (Exception ex) {
/* 124 */         throw new TransformException("Couldn't find Transform for: " + getAlgorithm(), ex);
/*     */       }
/*     */     }
/*     */     
/*     */     XMLSignatureInput in;
/*     */     XMLSignatureInput in;
/* 130 */     if ((data instanceof ApacheData)) {
/* 131 */       if (log.isLoggable(Level.FINE)) {
/* 132 */         log.log(Level.FINE, "ApacheData = true");
/*     */       }
/* 134 */       in = ((ApacheData)data).getXMLSignatureInput(); } else { XMLSignatureInput in;
/* 135 */       if ((data instanceof NodeSetData)) {
/* 136 */         if (log.isLoggable(Level.FINE)) {
/* 137 */           log.log(Level.FINE, "isNodeSet() = true");
/*     */         }
/* 139 */         if ((data instanceof DOMSubTreeData)) {
/* 140 */           if (log.isLoggable(Level.FINE)) {
/* 141 */             log.log(Level.FINE, "DOMSubTreeData = true");
/*     */           }
/* 143 */           DOMSubTreeData subTree = (DOMSubTreeData)data;
/* 144 */           XMLSignatureInput in = new XMLSignatureInput(subTree.getRoot());
/* 145 */           in.setExcludeComments(subTree.excludeComments());
/*     */         } else {
/* 147 */           Set nodeSet = Utils.toNodeSet(((NodeSetData)data).iterator());
/*     */           
/* 149 */           in = new XMLSignatureInput(nodeSet);
/*     */         }
/*     */       } else {
/* 152 */         if (log.isLoggable(Level.FINE)) {
/* 153 */           log.log(Level.FINE, "isNodeSet() = false");
/*     */         }
/*     */         try {
/* 156 */           in = new XMLSignatureInput(((OctetStreamData)data).getOctetStream());
/*     */         }
/*     */         catch (Exception ex) {
/* 159 */           throw new TransformException(ex);
/*     */         }
/*     */       }
/*     */     }
/*     */     try {
/* 164 */       if (os != null) {
/* 165 */         in = this.apacheTransform.performTransform(in, os);
/* 166 */         if ((!in.isNodeSet()) && (!in.isElement())) {
/* 167 */           return null;
/*     */         }
/*     */       } else {
/* 170 */         in = this.apacheTransform.performTransform(in);
/*     */       }
/* 172 */       if (in.isOctetStream()) {
/* 173 */         return new ApacheOctetStreamData(in);
/*     */       }
/* 175 */       return new ApacheNodeSetData(in);
/*     */     }
/*     */     catch (Exception ex) {
/* 178 */       throw new TransformException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public final boolean isFeatureSupported(String feature) {
/* 183 */     if (feature == null) {
/* 184 */       throw new NullPointerException();
/*     */     }
/* 186 */     return false;
/*     */   }
/*     */   
/*     */   static {}
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\jcp\xml\dsig\internal\dom\ApacheTransform.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */