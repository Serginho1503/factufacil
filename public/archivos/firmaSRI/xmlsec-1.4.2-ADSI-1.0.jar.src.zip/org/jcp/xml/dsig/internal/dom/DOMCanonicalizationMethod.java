/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.io.OutputStream;
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.Provider;
/*     */ import javax.xml.crypto.Data;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.XMLCryptoContext;
/*     */ import javax.xml.crypto.dsig.CanonicalizationMethod;
/*     */ import javax.xml.crypto.dsig.TransformException;
/*     */ import javax.xml.crypto.dsig.TransformService;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMCanonicalizationMethod
/*     */   extends DOMTransform
/*     */   implements CanonicalizationMethod
/*     */ {
/*     */   public DOMCanonicalizationMethod(TransformService spi)
/*     */     throws InvalidAlgorithmParameterException
/*     */   {
/*  49 */     super(spi);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMCanonicalizationMethod(Element cmElem, XMLCryptoContext context, Provider provider)
/*     */     throws MarshalException
/*     */   {
/*  61 */     super(cmElem, context, provider);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Data canonicalize(Data data, XMLCryptoContext xc)
/*     */     throws TransformException
/*     */   {
/*  79 */     return transform(data, xc);
/*     */   }
/*     */   
/*     */   public Data canonicalize(Data data, XMLCryptoContext xc, OutputStream os) throws TransformException
/*     */   {
/*  84 */     return transform(data, xc, os);
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/*  88 */     if (this == o) {
/*  89 */       return true;
/*     */     }
/*     */     
/*  92 */     if (!(o instanceof CanonicalizationMethod)) {
/*  93 */       return false;
/*     */     }
/*  95 */     CanonicalizationMethod ocm = (CanonicalizationMethod)o;
/*     */     
/*  97 */     return (getAlgorithm().equals(ocm.getAlgorithm())) && (DOMUtils.paramsEqual(getParameterSpec(), ocm.getParameterSpec()));
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 102 */     if (!$assertionsDisabled) throw new AssertionError("hashCode not designed");
/* 103 */     return 42;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\jcp\xml\dsig\internal\dom\DOMCanonicalizationMethod.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */