/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.XMLCryptoContext;
/*     */ import javax.xml.crypto.XMLStructure;
/*     */ import javax.xml.crypto.dsig.spec.TransformParameterSpec;
/*     */ import javax.xml.crypto.dsig.spec.XPathFilter2ParameterSpec;
/*     */ import javax.xml.crypto.dsig.spec.XPathType;
/*     */ import javax.xml.crypto.dsig.spec.XPathType.Filter;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DOMXPathFilter2Transform
/*     */   extends ApacheTransform
/*     */ {
/*     */   public void init(TransformParameterSpec params)
/*     */     throws InvalidAlgorithmParameterException
/*     */   {
/*  57 */     if (params == null)
/*  58 */       throw new InvalidAlgorithmParameterException("params are required");
/*  59 */     if (!(params instanceof XPathFilter2ParameterSpec)) {
/*  60 */       throw new InvalidAlgorithmParameterException("params must be of type XPathFilter2ParameterSpec");
/*     */     }
/*     */     
/*  63 */     this.params = params;
/*     */   }
/*     */   
/*     */   public void init(XMLStructure parent, XMLCryptoContext context)
/*     */     throws InvalidAlgorithmParameterException
/*     */   {
/*  69 */     super.init(parent, context);
/*     */     try {
/*  71 */       unmarshalParams(DOMUtils.getFirstChildElement(this.transformElem));
/*     */     } catch (MarshalException me) {
/*  73 */       throw ((InvalidAlgorithmParameterException)new InvalidAlgorithmParameterException().initCause(me));
/*     */     }
/*     */   }
/*     */   
/*     */   private void unmarshalParams(Element curXPathElem) throws MarshalException
/*     */   {
/*  79 */     List list = new ArrayList();
/*  80 */     while (curXPathElem != null) {
/*  81 */       String xPath = curXPathElem.getFirstChild().getNodeValue();
/*  82 */       String filterVal = DOMUtils.getAttributeValue(curXPathElem, "Filter");
/*     */       
/*  84 */       if (filterVal == null) {
/*  85 */         throw new MarshalException("filter cannot be null");
/*     */       }
/*  87 */       XPathType.Filter filter = null;
/*  88 */       if (filterVal.equals("intersect")) {
/*  89 */         filter = XPathType.Filter.INTERSECT;
/*  90 */       } else if (filterVal.equals("subtract")) {
/*  91 */         filter = XPathType.Filter.SUBTRACT;
/*  92 */       } else if (filterVal.equals("union")) {
/*  93 */         filter = XPathType.Filter.UNION;
/*     */       } else {
/*  95 */         throw new MarshalException("Unknown XPathType filter type" + filterVal);
/*     */       }
/*     */       
/*  98 */       NamedNodeMap attributes = curXPathElem.getAttributes();
/*  99 */       if (attributes != null) {
/* 100 */         int length = attributes.getLength();
/* 101 */         Map namespaceMap = new HashMap(length);
/* 102 */         for (int i = 0; i < length; i++) {
/* 103 */           Attr attr = (Attr)attributes.item(i);
/* 104 */           String prefix = attr.getPrefix();
/* 105 */           if ((prefix != null) && (prefix.equals("xmlns"))) {
/* 106 */             namespaceMap.put(attr.getLocalName(), attr.getValue());
/*     */           }
/*     */         }
/* 109 */         list.add(new XPathType(xPath, filter, namespaceMap));
/*     */       } else {
/* 111 */         list.add(new XPathType(xPath, filter));
/*     */       }
/*     */       
/* 114 */       curXPathElem = DOMUtils.getNextSiblingElement(curXPathElem);
/*     */     }
/* 116 */     this.params = new XPathFilter2ParameterSpec(list);
/*     */   }
/*     */   
/*     */   public void marshalParams(XMLStructure parent, XMLCryptoContext context)
/*     */     throws MarshalException
/*     */   {
/* 122 */     super.marshalParams(parent, context);
/* 123 */     XPathFilter2ParameterSpec xp = (XPathFilter2ParameterSpec)getParameterSpec();
/*     */     
/* 125 */     String prefix = DOMUtils.getNSPrefix(context, "http://www.w3.org/2002/06/xmldsig-filter2");
/* 126 */     String qname = "xmlns:" + prefix;
/*     */     
/* 128 */     List list = xp.getXPathList();
/* 129 */     int i = 0; for (int size = list.size(); i < size; i++) {
/* 130 */       XPathType xpathType = (XPathType)list.get(i);
/* 131 */       Element elem = DOMUtils.createElement(this.ownerDoc, "XPath", "http://www.w3.org/2002/06/xmldsig-filter2", prefix);
/*     */       
/* 133 */       elem.appendChild(this.ownerDoc.createTextNode(xpathType.getExpression()));
/*     */       
/* 135 */       DOMUtils.setAttribute(elem, "Filter", xpathType.getFilter().toString());
/*     */       
/* 137 */       elem.setAttributeNS("http://www.w3.org/2000/xmlns/", qname, "http://www.w3.org/2002/06/xmldsig-filter2");
/*     */       
/*     */ 
/*     */ 
/* 141 */       Iterator it = xpathType.getNamespaceMap().entrySet().iterator();
/* 142 */       while (it.hasNext()) {
/* 143 */         Map.Entry entry = (Map.Entry)it.next();
/* 144 */         elem.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns:" + (String)entry.getKey(), (String)entry.getValue());
/*     */       }
/*     */       
/*     */ 
/* 148 */       this.transformElem.appendChild(elem);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\jcp\xml\dsig\internal\dom\DOMXPathFilter2Transform.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */