/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.XMLStructure;
/*     */ import javax.xml.crypto.dom.DOMCryptoContext;
/*     */ import javax.xml.crypto.dsig.keyinfo.PGPData;
/*     */ import org.apache.xml.security.exceptions.Base64DecodingException;
/*     */ import org.apache.xml.security.utils.Base64;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DOMPGPData
/*     */   extends DOMStructure
/*     */   implements PGPData
/*     */ {
/*     */   private final byte[] keyId;
/*     */   private final byte[] keyPacket;
/*     */   private final List externalElements;
/*     */   
/*     */   public DOMPGPData(byte[] keyPacket, List other)
/*     */   {
/*  67 */     if (keyPacket == null) {
/*  68 */       throw new NullPointerException("keyPacket cannot be null");
/*     */     }
/*  70 */     if ((other == null) || (other.isEmpty())) {
/*  71 */       this.externalElements = Collections.EMPTY_LIST;
/*     */     } else {
/*  73 */       List otherCopy = new ArrayList(other);
/*  74 */       int i = 0; for (int size = otherCopy.size(); i < size; i++) {
/*  75 */         if (!(otherCopy.get(i) instanceof XMLStructure)) {
/*  76 */           throw new ClassCastException("other[" + i + "] is not a valid PGPData type");
/*     */         }
/*     */       }
/*     */       
/*  80 */       this.externalElements = Collections.unmodifiableList(otherCopy);
/*     */     }
/*  82 */     this.keyPacket = ((byte[])keyPacket.clone());
/*  83 */     checkKeyPacket(keyPacket);
/*  84 */     this.keyId = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMPGPData(byte[] keyId, byte[] keyPacket, List other)
/*     */   {
/* 108 */     if (keyId == null) {
/* 109 */       throw new NullPointerException("keyId cannot be null");
/*     */     }
/*     */     
/* 112 */     if (keyId.length != 8) {
/* 113 */       throw new IllegalArgumentException("keyId must be 8 bytes long");
/*     */     }
/* 115 */     if ((other == null) || (other.isEmpty())) {
/* 116 */       this.externalElements = Collections.EMPTY_LIST;
/*     */     } else {
/* 118 */       List otherCopy = new ArrayList(other);
/* 119 */       int i = 0; for (int size = otherCopy.size(); i < size; i++) {
/* 120 */         if (!(otherCopy.get(i) instanceof XMLStructure)) {
/* 121 */           throw new ClassCastException("other[" + i + "] is not a valid PGPData type");
/*     */         }
/*     */       }
/*     */       
/* 125 */       this.externalElements = Collections.unmodifiableList(otherCopy);
/*     */     }
/* 127 */     this.keyId = ((byte[])keyId.clone());
/* 128 */     this.keyPacket = (keyPacket == null ? null : (byte[])keyPacket.clone());
/* 129 */     if (keyPacket != null) {
/* 130 */       checkKeyPacket(keyPacket);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMPGPData(Element pdElem)
/*     */     throws MarshalException
/*     */   {
/* 141 */     byte[] keyId = null;
/* 142 */     byte[] keyPacket = null;
/* 143 */     NodeList nl = pdElem.getChildNodes();
/* 144 */     int length = nl.getLength();
/* 145 */     List other = new ArrayList(length);
/* 146 */     for (int x = 0; x < length; x++) {
/* 147 */       Node n = nl.item(x);
/* 148 */       if (n.getNodeType() == 1) {
/* 149 */         Element childElem = (Element)n;
/* 150 */         String localName = childElem.getLocalName();
/*     */         try {
/* 152 */           if (localName.equals("PGPKeyID")) {
/* 153 */             keyId = Base64.decode(childElem);
/* 154 */           } else if (localName.equals("PGPKeyPacket")) {
/* 155 */             keyPacket = Base64.decode(childElem);
/*     */           } else {
/* 157 */             other.add(new javax.xml.crypto.dom.DOMStructure(childElem));
/*     */           }
/*     */         }
/*     */         catch (Base64DecodingException bde) {
/* 161 */           throw new MarshalException(bde);
/*     */         }
/*     */       }
/*     */     }
/* 165 */     this.keyId = keyId;
/* 166 */     this.keyPacket = keyPacket;
/* 167 */     this.externalElements = Collections.unmodifiableList(other);
/*     */   }
/*     */   
/*     */   public byte[] getKeyId() {
/* 171 */     return this.keyId == null ? null : (byte[])this.keyId.clone();
/*     */   }
/*     */   
/*     */   public byte[] getKeyPacket() {
/* 175 */     return this.keyPacket == null ? null : (byte[])this.keyPacket.clone();
/*     */   }
/*     */   
/*     */   public List getExternalElements() {
/* 179 */     return this.externalElements;
/*     */   }
/*     */   
/*     */   public void marshal(Node parent, String dsPrefix, DOMCryptoContext context) throws MarshalException
/*     */   {
/* 184 */     Document ownerDoc = DOMUtils.getOwnerDocument(parent);
/*     */     
/* 186 */     Element pdElem = DOMUtils.createElement(ownerDoc, "PGPData", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */     
/*     */ 
/*     */ 
/* 190 */     if (this.keyId != null) {
/* 191 */       Element keyIdElem = DOMUtils.createElement(ownerDoc, "PGPKeyID", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */       
/* 193 */       keyIdElem.appendChild(ownerDoc.createTextNode(Base64.encode(this.keyId)));
/*     */       
/* 195 */       pdElem.appendChild(keyIdElem);
/*     */     }
/*     */     
/*     */ 
/* 199 */     if (this.keyPacket != null) {
/* 200 */       Element keyPktElem = DOMUtils.createElement(ownerDoc, "PGPKeyPacket", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */       
/* 202 */       keyPktElem.appendChild(ownerDoc.createTextNode(Base64.encode(this.keyPacket)));
/*     */       
/* 204 */       pdElem.appendChild(keyPktElem);
/*     */     }
/*     */     
/*     */ 
/* 208 */     int i = 0; for (int size = this.externalElements.size(); i < size; i++) {
/* 209 */       DOMUtils.appendChild(pdElem, ((javax.xml.crypto.dom.DOMStructure)this.externalElements.get(i)).getNode());
/*     */     }
/*     */     
/*     */ 
/* 213 */     parent.appendChild(pdElem);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkKeyPacket(byte[] keyPacket)
/*     */   {
/* 226 */     if (keyPacket.length < 3) {
/* 227 */       throw new IllegalArgumentException("keypacket must be at least 3 bytes long");
/*     */     }
/*     */     
/*     */ 
/* 231 */     int tag = keyPacket[0];
/*     */     
/* 233 */     if ((tag & 0x80) != 128) {
/* 234 */       throw new IllegalArgumentException("keypacket tag is invalid: bit 7 is not set");
/*     */     }
/*     */     
/*     */ 
/* 238 */     if ((tag & 0x40) != 64) {
/* 239 */       throw new IllegalArgumentException("old keypacket tag format is unsupported");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 244 */     if (((tag & 0x6) != 6) && ((tag & 0xE) != 14) && ((tag & 0x5) != 5) && ((tag & 0x7) != 7))
/*     */     {
/* 246 */       throw new IllegalArgumentException("keypacket tag is invalid: must be 6, 14, 5, or 7");
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\jcp\xml\dsig\internal\dom\DOMPGPData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */