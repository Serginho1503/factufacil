/*    */ package org.jcp.xml.dsig.internal;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.security.Signature;
/*    */ import java.security.SignatureException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SignerOutputStream
/*    */   extends ByteArrayOutputStream
/*    */ {
/*    */   private final Signature sig;
/*    */   
/*    */   public SignerOutputStream(Signature sig)
/*    */   {
/* 41 */     this.sig = sig;
/*    */   }
/*    */   
/*    */   public void write(byte[] arg0)
/*    */   {
/* 46 */     super.write(arg0, 0, arg0.length);
/*    */     try {
/* 48 */       this.sig.update(arg0);
/*    */     } catch (SignatureException e) {
/* 50 */       throw new RuntimeException("" + e);
/*    */     }
/*    */   }
/*    */   
/*    */   public void write(int arg0)
/*    */   {
/* 56 */     super.write(arg0);
/*    */     try {
/* 58 */       this.sig.update((byte)arg0);
/*    */     } catch (SignatureException e) {
/* 60 */       throw new RuntimeException("" + e);
/*    */     }
/*    */   }
/*    */   
/*    */   public void write(byte[] arg0, int arg1, int arg2)
/*    */   {
/* 66 */     super.write(arg0, arg1, arg2);
/*    */     try {
/* 68 */       this.sig.update(arg0, arg1, arg2);
/*    */     } catch (SignatureException e) {
/* 70 */       throw new RuntimeException("" + e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\jcp\xml\dsig\internal\SignerOutputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */