/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.security.Provider;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.xml.crypto.Data;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.XMLCryptoContext;
/*     */ import javax.xml.crypto.dom.DOMCryptoContext;
/*     */ import javax.xml.crypto.dsig.CanonicalizationMethod;
/*     */ import javax.xml.crypto.dsig.Reference;
/*     */ import javax.xml.crypto.dsig.SignatureMethod;
/*     */ import javax.xml.crypto.dsig.SignedInfo;
/*     */ import javax.xml.crypto.dsig.TransformException;
/*     */ import javax.xml.crypto.dsig.XMLSignatureException;
/*     */ import org.apache.xml.security.utils.Base64;
/*     */ import org.apache.xml.security.utils.UnsyncBufferedOutputStream;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DOMSignedInfo
/*     */   extends DOMStructure
/*     */   implements SignedInfo
/*     */ {
/*  54 */   private static Logger log = Logger.getLogger("org.jcp.xml.dsig.internal.dom");
/*     */   
/*     */ 
/*     */   private List references;
/*     */   
/*     */ 
/*     */   private CanonicalizationMethod canonicalizationMethod;
/*     */   
/*     */ 
/*     */   private SignatureMethod signatureMethod;
/*     */   
/*     */ 
/*     */   private String id;
/*     */   
/*     */ 
/*     */   private Document ownerDoc;
/*     */   
/*     */ 
/*     */   private Element localSiElem;
/*     */   
/*     */   private InputStream canonData;
/*     */   
/*     */ 
/*     */   public DOMSignedInfo(CanonicalizationMethod cm, SignatureMethod sm, List references)
/*     */   {
/*  79 */     if ((cm == null) || (sm == null) || (references == null)) {
/*  80 */       throw new NullPointerException();
/*     */     }
/*  82 */     this.canonicalizationMethod = cm;
/*  83 */     this.signatureMethod = sm;
/*  84 */     this.references = Collections.unmodifiableList(new ArrayList(references));
/*     */     
/*  86 */     if (this.references.isEmpty()) {
/*  87 */       throw new IllegalArgumentException("list of references must contain at least one entry");
/*     */     }
/*     */     
/*  90 */     int i = 0; for (int size = this.references.size(); i < size; i++) {
/*  91 */       Object obj = this.references.get(i);
/*  92 */       if (!(obj instanceof Reference)) {
/*  93 */         throw new ClassCastException("list of references contains an illegal type");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMSignedInfo(CanonicalizationMethod cm, SignatureMethod sm, List references, String id)
/*     */   {
/* 116 */     this(cm, sm, references);
/* 117 */     this.id = id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMSignedInfo(Element siElem, XMLCryptoContext context, Provider provider)
/*     */     throws MarshalException
/*     */   {
/* 127 */     this.localSiElem = siElem;
/* 128 */     this.ownerDoc = siElem.getOwnerDocument();
/*     */     
/*     */ 
/* 131 */     this.id = DOMUtils.getAttributeValue(siElem, "Id");
/*     */     
/*     */ 
/* 134 */     Element cmElem = DOMUtils.getFirstChildElement(siElem);
/* 135 */     this.canonicalizationMethod = new DOMCanonicalizationMethod(cmElem, context, provider);
/*     */     
/*     */ 
/*     */ 
/* 139 */     Element smElem = DOMUtils.getNextSiblingElement(cmElem);
/* 140 */     this.signatureMethod = DOMSignatureMethod.unmarshal(smElem);
/*     */     
/*     */ 
/* 143 */     ArrayList refList = new ArrayList(5);
/* 144 */     Element refElem = DOMUtils.getNextSiblingElement(smElem);
/* 145 */     while (refElem != null) {
/* 146 */       refList.add(new DOMReference(refElem, context, provider));
/* 147 */       refElem = DOMUtils.getNextSiblingElement(refElem);
/*     */     }
/* 149 */     this.references = Collections.unmodifiableList(refList);
/*     */   }
/*     */   
/*     */   public CanonicalizationMethod getCanonicalizationMethod() {
/* 153 */     return this.canonicalizationMethod;
/*     */   }
/*     */   
/*     */   public SignatureMethod getSignatureMethod() {
/* 157 */     return this.signatureMethod;
/*     */   }
/*     */   
/*     */   public String getId() {
/* 161 */     return this.id;
/*     */   }
/*     */   
/*     */   public List getReferences() {
/* 165 */     return this.references;
/*     */   }
/*     */   
/*     */   public InputStream getCanonicalizedData() {
/* 169 */     return this.canonData;
/*     */   }
/*     */   
/*     */   public void canonicalize(XMLCryptoContext context, ByteArrayOutputStream bos)
/*     */     throws XMLSignatureException
/*     */   {
/* 175 */     if (context == null) {
/* 176 */       throw new NullPointerException("context cannot be null");
/*     */     }
/*     */     
/* 179 */     OutputStream os = new UnsyncBufferedOutputStream(bos);
/*     */     try {
/* 181 */       os.close();
/*     */     }
/*     */     catch (IOException e) {}
/*     */     
/*     */ 
/* 186 */     DOMSubTreeData subTree = new DOMSubTreeData(this.localSiElem, true);
/*     */     try
/*     */     {
/* 189 */       data = ((DOMCanonicalizationMethod)this.canonicalizationMethod).canonicalize(subTree, context, os);
/*     */     } catch (TransformException te) {
/*     */       Data data;
/* 192 */       throw new XMLSignatureException(te);
/*     */     }
/*     */     
/* 195 */     byte[] signedInfoBytes = bos.toByteArray();
/*     */     
/*     */ 
/* 198 */     if (log.isLoggable(Level.FINE)) {
/* 199 */       InputStreamReader isr = new InputStreamReader(new ByteArrayInputStream(signedInfoBytes));
/*     */       
/* 201 */       char[] siBytes = new char[signedInfoBytes.length];
/*     */       try {
/* 203 */         isr.read(siBytes);
/* 204 */         log.log(Level.FINE, "Canonicalized SignedInfo:\n" + new String(siBytes));
/*     */       }
/*     */       catch (IOException ioex) {
/* 207 */         log.log(Level.FINE, "IOException reading SignedInfo bytes");
/*     */       }
/* 209 */       log.log(Level.FINE, "Data to be signed/verified:" + Base64.encode(signedInfoBytes));
/*     */     }
/*     */     
/*     */ 
/* 213 */     this.canonData = new ByteArrayInputStream(signedInfoBytes);
/*     */   }
/*     */   
/*     */   public void marshal(Node parent, String dsPrefix, DOMCryptoContext context) throws MarshalException
/*     */   {
/* 218 */     this.ownerDoc = DOMUtils.getOwnerDocument(parent);
/*     */     
/* 220 */     Element siElem = DOMUtils.createElement(this.ownerDoc, "SignedInfo", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */     
/*     */ 
/*     */ 
/* 224 */     DOMCanonicalizationMethod dcm = (DOMCanonicalizationMethod)this.canonicalizationMethod;
/*     */     
/* 226 */     dcm.marshal(siElem, dsPrefix, context);
/*     */     
/*     */ 
/* 229 */     ((DOMSignatureMethod)this.signatureMethod).marshal(siElem, dsPrefix, context);
/*     */     
/*     */ 
/*     */ 
/* 233 */     int i = 0; for (int size = this.references.size(); i < size; i++) {
/* 234 */       DOMReference reference = (DOMReference)this.references.get(i);
/* 235 */       reference.marshal(siElem, dsPrefix, context);
/*     */     }
/*     */     
/*     */ 
/* 239 */     DOMUtils.setAttributeID(siElem, "Id", this.id);
/*     */     
/* 241 */     parent.appendChild(siElem);
/* 242 */     this.localSiElem = siElem;
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 246 */     if (this == o) {
/* 247 */       return true;
/*     */     }
/*     */     
/* 250 */     if (!(o instanceof SignedInfo)) {
/* 251 */       return false;
/*     */     }
/* 253 */     SignedInfo osi = (SignedInfo)o;
/*     */     
/* 255 */     boolean idEqual = this.id == null ? false : osi.getId() == null ? true : this.id.equals(osi.getId());
/*     */     
/*     */ 
/* 258 */     return (this.canonicalizationMethod.equals(osi.getCanonicalizationMethod())) && (this.signatureMethod.equals(osi.getSignatureMethod())) && (this.references.equals(osi.getReferences())) && (idEqual);
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 264 */     if (!$assertionsDisabled) throw new AssertionError("hashCode not designed");
/* 265 */     return 59;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\jcp\xml\dsig\internal\dom\DOMSignedInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */