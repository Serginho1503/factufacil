/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.security.Provider;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.xml.crypto.Data;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.URIDereferencer;
/*     */ import javax.xml.crypto.URIReferenceException;
/*     */ import javax.xml.crypto.XMLCryptoContext;
/*     */ import javax.xml.crypto.XMLStructure;
/*     */ import javax.xml.crypto.dom.DOMCryptoContext;
/*     */ import javax.xml.crypto.dom.DOMURIReference;
/*     */ import javax.xml.crypto.dsig.Transform;
/*     */ import javax.xml.crypto.dsig.keyinfo.RetrievalMethod;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DOMRetrievalMethod
/*     */   extends DOMStructure
/*     */   implements RetrievalMethod, DOMURIReference
/*     */ {
/*     */   private final List transforms;
/*     */   private String uri;
/*     */   private String type;
/*     */   private Attr here;
/*     */   
/*     */   public DOMRetrievalMethod(String uri, String type, List transforms)
/*     */   {
/*  82 */     if (uri == null) {
/*  83 */       throw new NullPointerException("uri cannot be null");
/*     */     }
/*  85 */     if ((transforms == null) || (transforms.isEmpty())) {
/*  86 */       this.transforms = Collections.EMPTY_LIST;
/*     */     } else {
/*  88 */       List transformsCopy = new ArrayList(transforms);
/*  89 */       int i = 0; for (int size = transformsCopy.size(); i < size; i++) {
/*  90 */         if (!(transformsCopy.get(i) instanceof Transform)) {
/*  91 */           throw new ClassCastException("transforms[" + i + "] is not a valid type");
/*     */         }
/*     */       }
/*     */       
/*  95 */       this.transforms = Collections.unmodifiableList(transformsCopy);
/*     */     }
/*  97 */     this.uri = uri;
/*  98 */     if ((uri != null) && (!uri.equals(""))) {
/*     */       try {
/* 100 */         new URI(uri);
/*     */       } catch (URISyntaxException e) {
/* 102 */         throw new IllegalArgumentException(e.getMessage());
/*     */       }
/*     */     }
/*     */     
/* 106 */     this.type = type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMRetrievalMethod(Element rmElem, XMLCryptoContext context, Provider provider)
/*     */     throws MarshalException
/*     */   {
/* 117 */     this.uri = DOMUtils.getAttributeValue(rmElem, "URI");
/* 118 */     this.type = DOMUtils.getAttributeValue(rmElem, "Type");
/*     */     
/*     */ 
/* 121 */     this.here = rmElem.getAttributeNodeNS(null, "URI");
/*     */     
/*     */ 
/* 124 */     List transforms = new ArrayList();
/* 125 */     Element transformsElem = DOMUtils.getFirstChildElement(rmElem);
/* 126 */     if (transformsElem != null) {
/* 127 */       Element transformElem = DOMUtils.getFirstChildElement(transformsElem);
/*     */       
/* 129 */       while (transformElem != null) {
/* 130 */         transforms.add(new DOMTransform(transformElem, context, provider));
/*     */         
/* 132 */         transformElem = DOMUtils.getNextSiblingElement(transformElem);
/*     */       }
/*     */     }
/* 135 */     if (transforms.isEmpty()) {
/* 136 */       this.transforms = Collections.EMPTY_LIST;
/*     */     } else {
/* 138 */       this.transforms = Collections.unmodifiableList(transforms);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getURI() {
/* 143 */     return this.uri;
/*     */   }
/*     */   
/*     */   public String getType() {
/* 147 */     return this.type;
/*     */   }
/*     */   
/*     */   public List getTransforms() {
/* 151 */     return this.transforms;
/*     */   }
/*     */   
/*     */   public void marshal(Node parent, String dsPrefix, DOMCryptoContext context) throws MarshalException
/*     */   {
/* 156 */     Document ownerDoc = DOMUtils.getOwnerDocument(parent);
/*     */     
/* 158 */     Element rmElem = DOMUtils.createElement(ownerDoc, "RetrievalMethod", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */     
/*     */ 
/*     */ 
/* 162 */     DOMUtils.setAttribute(rmElem, "URI", this.uri);
/* 163 */     DOMUtils.setAttribute(rmElem, "Type", this.type);
/*     */     
/*     */ 
/* 166 */     if (!this.transforms.isEmpty()) {
/* 167 */       Element transformsElem = DOMUtils.createElement(ownerDoc, "Transforms", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */       
/* 169 */       rmElem.appendChild(transformsElem);
/* 170 */       int i = 0; for (int size = this.transforms.size(); i < size; i++) {
/* 171 */         ((DOMTransform)this.transforms.get(i)).marshal(transformsElem, dsPrefix, context);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 176 */     parent.appendChild(rmElem);
/*     */     
/*     */ 
/* 179 */     this.here = rmElem.getAttributeNodeNS(null, "URI");
/*     */   }
/*     */   
/*     */   public Node getHere() {
/* 183 */     return this.here;
/*     */   }
/*     */   
/*     */   public Data dereference(XMLCryptoContext context)
/*     */     throws URIReferenceException
/*     */   {
/* 189 */     if (context == null) {
/* 190 */       throw new NullPointerException("context cannot be null");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 197 */     URIDereferencer deref = context.getURIDereferencer();
/* 198 */     if (deref == null) {
/* 199 */       deref = DOMURIDereferencer.INSTANCE;
/*     */     }
/*     */     
/* 202 */     Data data = deref.dereference(this, context);
/*     */     
/*     */     try
/*     */     {
/* 206 */       int i = 0; for (int size = this.transforms.size(); i < size; i++) {
/* 207 */         Transform transform = (Transform)this.transforms.get(i);
/* 208 */         data = ((DOMTransform)transform).transform(data, context);
/*     */       }
/*     */     } catch (Exception e) {
/* 211 */       throw new URIReferenceException(e);
/*     */     }
/* 213 */     return data;
/*     */   }
/*     */   
/*     */   public XMLStructure dereferenceAsXMLStructure(XMLCryptoContext context) throws URIReferenceException
/*     */   {
/*     */     try
/*     */     {
/* 220 */       ApacheData data = (ApacheData)dereference(context);
/* 221 */       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 222 */       dbf.setNamespaceAware(true);
/* 223 */       DocumentBuilder db = dbf.newDocumentBuilder();
/* 224 */       Document doc = db.parse(new ByteArrayInputStream(data.getXMLSignatureInput().getBytes()));
/*     */       
/* 226 */       Element kiElem = doc.getDocumentElement();
/* 227 */       if (kiElem.getLocalName().equals("X509Data")) {
/* 228 */         return new DOMX509Data(kiElem);
/*     */       }
/* 230 */       return null;
/*     */     }
/*     */     catch (Exception e) {
/* 233 */       throw new URIReferenceException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/* 238 */     if (this == obj) {
/* 239 */       return true;
/*     */     }
/* 241 */     if (!(obj instanceof RetrievalMethod)) {
/* 242 */       return false;
/*     */     }
/* 244 */     RetrievalMethod orm = (RetrievalMethod)obj;
/*     */     
/* 246 */     boolean typesEqual = this.type == null ? false : orm.getType() == null ? true : this.type.equals(orm.getType());
/*     */     
/*     */ 
/* 249 */     return (this.uri.equals(orm.getURI())) && (this.transforms.equals(orm.getTransforms())) && (typesEqual);
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 254 */     if (!$assertionsDisabled) throw new AssertionError("hashCode not designed");
/* 255 */     return 48;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\jcp\xml\dsig\internal\dom\DOMRetrievalMethod.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */