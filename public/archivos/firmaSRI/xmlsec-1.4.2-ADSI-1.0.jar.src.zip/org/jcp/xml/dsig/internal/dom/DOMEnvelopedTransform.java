/*    */ package org.jcp.xml.dsig.internal.dom;
/*    */ 
/*    */ import java.security.InvalidAlgorithmParameterException;
/*    */ import javax.xml.crypto.dsig.spec.TransformParameterSpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DOMEnvelopedTransform
/*    */   extends ApacheTransform
/*    */ {
/*    */   public void init(TransformParameterSpec params)
/*    */     throws InvalidAlgorithmParameterException
/*    */   {
/* 38 */     if (params != null) {
/* 39 */       throw new InvalidAlgorithmParameterException("params must be null");
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\jcp\xml\dsig\internal\dom\DOMEnvelopedTransform.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */