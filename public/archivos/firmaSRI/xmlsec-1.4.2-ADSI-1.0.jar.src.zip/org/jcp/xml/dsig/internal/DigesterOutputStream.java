/*     */ package org.jcp.xml.dsig.internal;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.security.MessageDigest;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import org.apache.xml.security.utils.UnsyncByteArrayOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DigesterOutputStream
/*     */   extends OutputStream
/*     */ {
/*  44 */   private boolean buffer = false;
/*     */   private UnsyncByteArrayOutputStream bos;
/*     */   private final MessageDigest md;
/*  47 */   private static Logger log = Logger.getLogger("org.jcp.xml.dsig.internal");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DigesterOutputStream(MessageDigest md)
/*     */   {
/*  55 */     this(md, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DigesterOutputStream(MessageDigest md, boolean buffer)
/*     */   {
/*  65 */     this.md = md;
/*  66 */     this.buffer = buffer;
/*  67 */     if (buffer) {
/*  68 */       this.bos = new UnsyncByteArrayOutputStream();
/*     */     }
/*     */   }
/*     */   
/*     */   public void write(byte[] input)
/*     */   {
/*  74 */     write(input, 0, input.length);
/*     */   }
/*     */   
/*     */   public void write(int input)
/*     */   {
/*  79 */     if (this.buffer) {
/*  80 */       this.bos.write(input);
/*     */     }
/*  82 */     this.md.update((byte)input);
/*     */   }
/*     */   
/*     */   public void write(byte[] input, int offset, int len)
/*     */   {
/*  87 */     if (this.buffer) {
/*  88 */       this.bos.write(input, offset, len);
/*     */     }
/*  90 */     if (log.isLoggable(Level.FINER)) {
/*  91 */       log.log(Level.FINER, "Pre-digested input:");
/*  92 */       StringBuffer sb = new StringBuffer(len);
/*  93 */       for (int i = offset; i < offset + len; i++) {
/*  94 */         sb.append((char)input[i]);
/*     */       }
/*  96 */       log.log(Level.FINER, sb.toString());
/*     */     }
/*  98 */     this.md.update(input, offset, len);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public byte[] getDigestValue()
/*     */   {
/* 105 */     return this.md.digest();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputStream getInputStream()
/*     */   {
/* 113 */     if (this.buffer) {
/* 114 */       return new ByteArrayInputStream(this.bos.toByteArray());
/*     */     }
/* 116 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\jcp\xml\dsig\internal\DigesterOutputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */