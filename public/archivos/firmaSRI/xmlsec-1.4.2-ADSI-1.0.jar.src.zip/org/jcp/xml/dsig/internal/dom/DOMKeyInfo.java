/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.security.Provider;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.XMLCryptoContext;
/*     */ import javax.xml.crypto.XMLStructure;
/*     */ import javax.xml.crypto.dom.DOMCryptoContext;
/*     */ import javax.xml.crypto.dsig.keyinfo.KeyInfo;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DOMKeyInfo
/*     */   extends DOMStructure
/*     */   implements KeyInfo
/*     */ {
/*     */   private final String id;
/*     */   private final List keyInfoTypes;
/*     */   
/*     */   public DOMKeyInfo(List content, String id)
/*     */   {
/*  61 */     if (content == null) {
/*  62 */       throw new NullPointerException("content cannot be null");
/*     */     }
/*  64 */     List typesCopy = new ArrayList(content);
/*  65 */     if (typesCopy.isEmpty()) {
/*  66 */       throw new IllegalArgumentException("content cannot be empty");
/*     */     }
/*  68 */     int i = 0; for (int size = typesCopy.size(); i < size; i++) {
/*  69 */       if (!(typesCopy.get(i) instanceof XMLStructure)) {
/*  70 */         throw new ClassCastException("content[" + i + "] is not a valid KeyInfo type");
/*     */       }
/*     */     }
/*     */     
/*  74 */     this.keyInfoTypes = Collections.unmodifiableList(typesCopy);
/*  75 */     this.id = id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMKeyInfo(Element kiElem, XMLCryptoContext context, Provider provider)
/*     */     throws MarshalException
/*     */   {
/*  86 */     this.id = DOMUtils.getAttributeValue(kiElem, "Id");
/*     */     
/*     */ 
/*  89 */     NodeList nl = kiElem.getChildNodes();
/*  90 */     int length = nl.getLength();
/*  91 */     if (length < 1) {
/*  92 */       throw new MarshalException("KeyInfo must contain at least one type");
/*     */     }
/*     */     
/*  95 */     List content = new ArrayList(length);
/*  96 */     for (int i = 0; i < length; i++) {
/*  97 */       Node child = nl.item(i);
/*     */       
/*  99 */       if (child.getNodeType() == 1)
/*     */       {
/*     */ 
/* 102 */         Element childElem = (Element)child;
/* 103 */         String localName = childElem.getLocalName();
/* 104 */         if (localName.equals("X509Data")) {
/* 105 */           content.add(new DOMX509Data(childElem));
/* 106 */         } else if (localName.equals("KeyName")) {
/* 107 */           content.add(new DOMKeyName(childElem));
/* 108 */         } else if (localName.equals("KeyValue")) {
/* 109 */           content.add(new DOMKeyValue(childElem));
/* 110 */         } else if (localName.equals("RetrievalMethod")) {
/* 111 */           content.add(new DOMRetrievalMethod(childElem, context, provider));
/*     */         }
/* 113 */         else if (localName.equals("PGPData")) {
/* 114 */           content.add(new DOMPGPData(childElem));
/*     */         } else
/* 116 */           content.add(new javax.xml.crypto.dom.DOMStructure(childElem));
/*     */       }
/*     */     }
/* 119 */     this.keyInfoTypes = Collections.unmodifiableList(content);
/*     */   }
/*     */   
/*     */   public String getId() {
/* 123 */     return this.id;
/*     */   }
/*     */   
/*     */   public List getContent() {
/* 127 */     return this.keyInfoTypes;
/*     */   }
/*     */   
/*     */   public void marshal(XMLStructure parent, XMLCryptoContext context) throws MarshalException
/*     */   {
/* 132 */     if (parent == null) {
/* 133 */       throw new NullPointerException("parent is null");
/*     */     }
/*     */     
/* 136 */     Node pNode = ((javax.xml.crypto.dom.DOMStructure)parent).getNode();
/* 137 */     String dsPrefix = DOMUtils.getSignaturePrefix(context);
/* 138 */     Element kiElem = DOMUtils.createElement(DOMUtils.getOwnerDocument(pNode), "KeyInfo", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */     
/*     */ 
/* 141 */     if ((dsPrefix == null) || (dsPrefix.length() == 0)) {
/* 142 */       kiElem.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns", "http://www.w3.org/2000/09/xmldsig#");
/*     */     }
/*     */     else {
/* 145 */       kiElem.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns:" + dsPrefix, "http://www.w3.org/2000/09/xmldsig#");
/*     */     }
/*     */     
/*     */ 
/* 149 */     marshal(pNode, kiElem, null, dsPrefix, (DOMCryptoContext)context);
/*     */   }
/*     */   
/*     */   public void marshal(Node parent, String dsPrefix, DOMCryptoContext context) throws MarshalException
/*     */   {
/* 154 */     marshal(parent, null, dsPrefix, context);
/*     */   }
/*     */   
/*     */   public void marshal(Node parent, Node nextSibling, String dsPrefix, DOMCryptoContext context) throws MarshalException
/*     */   {
/* 159 */     Document ownerDoc = DOMUtils.getOwnerDocument(parent);
/*     */     
/* 161 */     Element kiElem = DOMUtils.createElement(ownerDoc, "KeyInfo", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */     
/* 163 */     marshal(parent, kiElem, nextSibling, dsPrefix, context);
/*     */   }
/*     */   
/*     */   private void marshal(Node parent, Element kiElem, Node nextSibling, String dsPrefix, DOMCryptoContext context)
/*     */     throws MarshalException
/*     */   {
/* 169 */     int i = 0; for (int size = this.keyInfoTypes.size(); i < size; i++) {
/* 170 */       XMLStructure kiType = (XMLStructure)this.keyInfoTypes.get(i);
/* 171 */       if ((kiType instanceof DOMStructure)) {
/* 172 */         ((DOMStructure)kiType).marshal(kiElem, dsPrefix, context);
/*     */       } else {
/* 174 */         DOMUtils.appendChild(kiElem, ((javax.xml.crypto.dom.DOMStructure)kiType).getNode());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 180 */     DOMUtils.setAttributeID(kiElem, "Id", this.id);
/*     */     
/* 182 */     parent.insertBefore(kiElem, nextSibling);
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 186 */     if (this == o) {
/* 187 */       return true;
/*     */     }
/*     */     
/* 190 */     if (!(o instanceof KeyInfo)) {
/* 191 */       return false;
/*     */     }
/* 193 */     KeyInfo oki = (KeyInfo)o;
/*     */     
/* 195 */     boolean idsEqual = this.id == null ? false : oki.getId() == null ? true : this.id.equals(oki.getId());
/*     */     
/*     */ 
/* 198 */     return (this.keyInfoTypes.equals(oki.getContent())) && (idsEqual);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 202 */     if (!$assertionsDisabled) throw new AssertionError("hashCode not designed");
/* 203 */     return 43;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\jcp\xml\dsig\internal\dom\DOMKeyInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */