/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.spec.AlgorithmParameterSpec;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.dom.DOMCryptoContext;
/*     */ import javax.xml.crypto.dsig.DigestMethod;
/*     */ import javax.xml.crypto.dsig.spec.DigestMethodParameterSpec;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DOMDigestMethod
/*     */   extends DOMStructure
/*     */   implements DigestMethod
/*     */ {
/*     */   static final String SHA384 = "http://www.w3.org/2001/04/xmldsig-more#sha384";
/*     */   private DigestMethodParameterSpec params;
/*     */   
/*     */   DOMDigestMethod(AlgorithmParameterSpec params)
/*     */     throws InvalidAlgorithmParameterException
/*     */   {
/*  57 */     if ((params != null) && (!(params instanceof DigestMethodParameterSpec))) {
/*  58 */       throw new InvalidAlgorithmParameterException("params must be of type DigestMethodParameterSpec");
/*     */     }
/*     */     
/*  61 */     checkParams((DigestMethodParameterSpec)params);
/*  62 */     this.params = ((DigestMethodParameterSpec)params);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   DOMDigestMethod(Element dmElem)
/*     */     throws MarshalException
/*     */   {
/*  73 */     Element paramsElem = DOMUtils.getFirstChildElement(dmElem);
/*  74 */     if (paramsElem != null) {
/*  75 */       this.params = unmarshalParams(paramsElem);
/*     */     }
/*     */     try {
/*  78 */       checkParams(this.params);
/*     */     } catch (InvalidAlgorithmParameterException iape) {
/*  80 */       throw new MarshalException(iape);
/*     */     }
/*     */   }
/*     */   
/*     */   static DigestMethod unmarshal(Element dmElem) throws MarshalException {
/*  85 */     String alg = DOMUtils.getAttributeValue(dmElem, "Algorithm");
/*  86 */     if (alg.equals("http://www.w3.org/2000/09/xmldsig#sha1"))
/*  87 */       return new SHA1(dmElem);
/*  88 */     if (alg.equals("http://www.w3.org/2001/04/xmlenc#sha256"))
/*  89 */       return new SHA256(dmElem);
/*  90 */     if (alg.equals("http://www.w3.org/2001/04/xmldsig-more#sha384"))
/*  91 */       return new SHA384(dmElem);
/*  92 */     if (alg.equals("http://www.w3.org/2001/04/xmlenc#sha512")) {
/*  93 */       return new SHA512(dmElem);
/*     */     }
/*  95 */     throw new MarshalException("unsupported DigestMethod algorithm: " + alg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void checkParams(DigestMethodParameterSpec params)
/*     */     throws InvalidAlgorithmParameterException
/*     */   {
/* 112 */     if (params != null) {
/* 113 */       throw new InvalidAlgorithmParameterException("no parameters should be specified for the " + getMessageDigestAlgorithm() + " DigestMethod algorithm");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public final AlgorithmParameterSpec getParameterSpec()
/*     */   {
/* 120 */     return this.params;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   DigestMethodParameterSpec unmarshalParams(Element paramsElem)
/*     */     throws MarshalException
/*     */   {
/* 135 */     throw new MarshalException("no parameters should be specified for the " + getMessageDigestAlgorithm() + " DigestMethod algorithm");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void marshal(Node parent, String prefix, DOMCryptoContext context)
/*     */     throws MarshalException
/*     */   {
/* 146 */     Document ownerDoc = DOMUtils.getOwnerDocument(parent);
/*     */     
/* 148 */     Element dmElem = DOMUtils.createElement(ownerDoc, "DigestMethod", "http://www.w3.org/2000/09/xmldsig#", prefix);
/*     */     
/* 150 */     DOMUtils.setAttribute(dmElem, "Algorithm", getAlgorithm());
/*     */     
/* 152 */     if (this.params != null) {
/* 153 */       marshalParams(dmElem, prefix);
/*     */     }
/*     */     
/* 156 */     parent.appendChild(dmElem);
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 160 */     if (this == o) {
/* 161 */       return true;
/*     */     }
/*     */     
/* 164 */     if (!(o instanceof DigestMethod)) {
/* 165 */       return false;
/*     */     }
/* 167 */     DigestMethod odm = (DigestMethod)o;
/*     */     
/* 169 */     boolean paramsEqual = this.params == null ? false : odm.getParameterSpec() == null ? true : this.params.equals(odm.getParameterSpec());
/*     */     
/*     */ 
/* 172 */     return (getAlgorithm().equals(odm.getAlgorithm())) && (paramsEqual);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 176 */     if (!$assertionsDisabled) throw new AssertionError("hashCode not designed");
/* 177 */     return 51;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void marshalParams(Element parent, String prefix)
/*     */     throws MarshalException
/*     */   {
/* 192 */     throw new MarshalException("no parameters should be specified for the " + getMessageDigestAlgorithm() + " DigestMethod algorithm");
/*     */   }
/*     */   
/*     */ 
/*     */   abstract String getMessageDigestAlgorithm();
/*     */   
/*     */ 
/*     */   static final class SHA1
/*     */     extends DOMDigestMethod
/*     */   {
/*     */     SHA1(AlgorithmParameterSpec params)
/*     */       throws InvalidAlgorithmParameterException
/*     */     {
/* 205 */       super();
/*     */     }
/*     */     
/* 208 */     SHA1(Element dmElem) throws MarshalException { super(); }
/*     */     
/*     */     public String getAlgorithm() {
/* 211 */       return "http://www.w3.org/2000/09/xmldsig#sha1";
/*     */     }
/*     */     
/* 214 */     String getMessageDigestAlgorithm() { return "SHA-1"; }
/*     */   }
/*     */   
/*     */   static final class SHA256 extends DOMDigestMethod
/*     */   {
/*     */     SHA256(AlgorithmParameterSpec params) throws InvalidAlgorithmParameterException
/*     */     {
/* 221 */       super();
/*     */     }
/*     */     
/* 224 */     SHA256(Element dmElem) throws MarshalException { super(); }
/*     */     
/*     */     public String getAlgorithm() {
/* 227 */       return "http://www.w3.org/2001/04/xmlenc#sha256";
/*     */     }
/*     */     
/* 230 */     String getMessageDigestAlgorithm() { return "SHA-256"; }
/*     */   }
/*     */   
/*     */   static final class SHA384 extends DOMDigestMethod
/*     */   {
/*     */     SHA384(AlgorithmParameterSpec params) throws InvalidAlgorithmParameterException
/*     */     {
/* 237 */       super();
/*     */     }
/*     */     
/* 240 */     SHA384(Element dmElem) throws MarshalException { super(); }
/*     */     
/*     */     public String getAlgorithm() {
/* 243 */       return "http://www.w3.org/2001/04/xmldsig-more#sha384";
/*     */     }
/*     */     
/* 246 */     String getMessageDigestAlgorithm() { return "SHA-384"; }
/*     */   }
/*     */   
/*     */   static final class SHA512 extends DOMDigestMethod
/*     */   {
/*     */     SHA512(AlgorithmParameterSpec params) throws InvalidAlgorithmParameterException
/*     */     {
/* 253 */       super();
/*     */     }
/*     */     
/* 256 */     SHA512(Element dmElem) throws MarshalException { super(); }
/*     */     
/*     */     public String getAlgorithm() {
/* 259 */       return "http://www.w3.org/2001/04/xmlenc#sha512";
/*     */     }
/*     */     
/* 262 */     String getMessageDigestAlgorithm() { return "SHA-512"; }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\jcp\xml\dsig\internal\dom\DOMDigestMethod.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */