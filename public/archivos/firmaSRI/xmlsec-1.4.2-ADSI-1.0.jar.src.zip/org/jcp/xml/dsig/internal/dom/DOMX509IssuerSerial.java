/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.dom.DOMCryptoContext;
/*     */ import javax.xml.crypto.dsig.keyinfo.X509IssuerSerial;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DOMX509IssuerSerial
/*     */   extends DOMStructure
/*     */   implements X509IssuerSerial
/*     */ {
/*     */   private final String issuerName;
/*     */   private final BigInteger serialNumber;
/*     */   
/*     */   public DOMX509IssuerSerial(String issuerName, BigInteger serialNumber)
/*     */   {
/*  60 */     if (issuerName == null) {
/*  61 */       throw new NullPointerException("issuerName cannot be null");
/*     */     }
/*  63 */     if (serialNumber == null) {
/*  64 */       throw new NullPointerException("serialNumber cannot be null");
/*     */     }
/*     */     
/*  67 */     new X500Principal(issuerName);
/*  68 */     this.issuerName = issuerName;
/*  69 */     this.serialNumber = serialNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMX509IssuerSerial(Element isElem)
/*     */   {
/*  78 */     Element iNElem = DOMUtils.getFirstChildElement(isElem);
/*  79 */     Element sNElem = DOMUtils.getNextSiblingElement(iNElem);
/*  80 */     this.issuerName = iNElem.getFirstChild().getNodeValue();
/*  81 */     this.serialNumber = new BigInteger(sNElem.getFirstChild().getNodeValue());
/*     */   }
/*     */   
/*     */   public String getIssuerName() {
/*  85 */     return this.issuerName;
/*     */   }
/*     */   
/*     */   public BigInteger getSerialNumber() {
/*  89 */     return this.serialNumber;
/*     */   }
/*     */   
/*     */   public void marshal(Node parent, String dsPrefix, DOMCryptoContext context) throws MarshalException
/*     */   {
/*  94 */     Document ownerDoc = DOMUtils.getOwnerDocument(parent);
/*     */     
/*  96 */     Element isElem = DOMUtils.createElement(ownerDoc, "X509IssuerSerial", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */     
/*  98 */     Element inElem = DOMUtils.createElement(ownerDoc, "X509IssuerName", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */     
/* 100 */     Element snElem = DOMUtils.createElement(ownerDoc, "X509SerialNumber", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */     
/* 102 */     inElem.appendChild(ownerDoc.createTextNode(this.issuerName));
/* 103 */     snElem.appendChild(ownerDoc.createTextNode(this.serialNumber.toString()));
/* 104 */     isElem.appendChild(inElem);
/* 105 */     isElem.appendChild(snElem);
/* 106 */     parent.appendChild(isElem);
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/* 110 */     if (this == obj) {
/* 111 */       return true;
/*     */     }
/* 113 */     if (!(obj instanceof X509IssuerSerial)) {
/* 114 */       return false;
/*     */     }
/* 116 */     X509IssuerSerial ois = (X509IssuerSerial)obj;
/* 117 */     return (this.issuerName.equals(ois.getIssuerName())) && (this.serialNumber.equals(ois.getSerialNumber()));
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 122 */     if (!$assertionsDisabled) throw new AssertionError("hashCode not designed");
/* 123 */     return 52;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\jcp\xml\dsig\internal\dom\DOMX509IssuerSerial.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */