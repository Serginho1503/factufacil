/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.spec.AlgorithmParameterSpec;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.xml.crypto.Data;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.NodeSetData;
/*     */ import javax.xml.crypto.OctetStreamData;
/*     */ import javax.xml.crypto.XMLCryptoContext;
/*     */ import javax.xml.crypto.XMLStructure;
/*     */ import javax.xml.crypto.dom.DOMCryptoContext;
/*     */ import javax.xml.crypto.dom.DOMStructure;
/*     */ import javax.xml.crypto.dsig.TransformException;
/*     */ import javax.xml.crypto.dsig.TransformService;
/*     */ import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
/*     */ import org.apache.xml.security.Init;
/*     */ import org.apache.xml.security.c14n.Canonicalizer;
/*     */ import org.apache.xml.security.c14n.InvalidCanonicalizerException;
/*     */ import org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import org.apache.xml.security.transforms.Transform;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ApacheCanonicalizer
/*     */   extends TransformService
/*     */ {
/*  55 */   private static Logger log = Logger.getLogger("org.jcp.xml.dsig.internal.dom");
/*     */   protected Canonicalizer apacheCanonicalizer;
/*     */   private Transform apacheTransform;
/*     */   protected String inclusiveNamespaces;
/*     */   protected C14NMethodParameterSpec params;
/*     */   protected Document ownerDoc;
/*     */   protected Element transformElem;
/*     */   
/*     */   public final AlgorithmParameterSpec getParameterSpec() {
/*  64 */     return this.params;
/*     */   }
/*     */   
/*     */   public void init(XMLStructure parent, XMLCryptoContext context) throws InvalidAlgorithmParameterException
/*     */   {
/*  69 */     if ((context != null) && (!(context instanceof DOMCryptoContext))) {
/*  70 */       throw new ClassCastException("context must be of type DOMCryptoContext");
/*     */     }
/*     */     
/*  73 */     this.transformElem = ((Element)((DOMStructure)parent).getNode());
/*     */     
/*  75 */     this.ownerDoc = DOMUtils.getOwnerDocument(this.transformElem);
/*     */   }
/*     */   
/*     */   public void marshalParams(XMLStructure parent, XMLCryptoContext context) throws MarshalException
/*     */   {
/*  80 */     if ((context != null) && (!(context instanceof DOMCryptoContext))) {
/*  81 */       throw new ClassCastException("context must be of type DOMCryptoContext");
/*     */     }
/*     */     
/*  84 */     this.transformElem = ((Element)((DOMStructure)parent).getNode());
/*     */     
/*  86 */     this.ownerDoc = DOMUtils.getOwnerDocument(this.transformElem);
/*     */   }
/*     */   
/*     */   public Data canonicalize(Data data, XMLCryptoContext xc) throws TransformException
/*     */   {
/*  91 */     return canonicalize(data, xc, null);
/*     */   }
/*     */   
/*     */   public Data canonicalize(Data data, XMLCryptoContext xc, OutputStream os)
/*     */     throws TransformException
/*     */   {
/*  97 */     if (this.apacheCanonicalizer == null) {
/*     */       try {
/*  99 */         this.apacheCanonicalizer = Canonicalizer.getInstance(getAlgorithm());
/* 100 */         if (log.isLoggable(Level.FINE)) {
/* 101 */           log.log(Level.FINE, "Created canonicalizer for algorithm: " + getAlgorithm());
/*     */         }
/*     */       }
/*     */       catch (InvalidCanonicalizerException ice) {
/* 105 */         throw new TransformException("Couldn't find Canonicalizer for: " + getAlgorithm() + ": " + ice.getMessage(), ice);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 111 */     if (os != null) {
/* 112 */       this.apacheCanonicalizer.setWriter(os);
/*     */     } else {
/* 114 */       this.apacheCanonicalizer.setWriter(new ByteArrayOutputStream());
/*     */     }
/*     */     try
/*     */     {
/* 118 */       Set nodeSet = null;
/* 119 */       if ((data instanceof ApacheData)) {
/* 120 */         XMLSignatureInput in = ((ApacheData)data).getXMLSignatureInput();
/*     */         
/* 122 */         if (in.isElement()) {
/* 123 */           if (this.inclusiveNamespaces != null) {
/* 124 */             return new OctetStreamData(new ByteArrayInputStream(this.apacheCanonicalizer.canonicalizeSubtree(in.getSubNode(), this.inclusiveNamespaces)));
/*     */           }
/*     */           
/*     */ 
/* 128 */           return new OctetStreamData(new ByteArrayInputStream(this.apacheCanonicalizer.canonicalizeSubtree(in.getSubNode())));
/*     */         }
/*     */         
/*     */ 
/* 132 */         if (in.isNodeSet()) {
/* 133 */           nodeSet = in.getNodeSet();
/*     */         } else {
/* 135 */           return new OctetStreamData(new ByteArrayInputStream(this.apacheCanonicalizer.canonicalize(Utils.readBytesFromStream(in.getOctetStream()))));
/*     */         }
/*     */       }
/*     */       else {
/* 139 */         if ((data instanceof DOMSubTreeData)) {
/* 140 */           DOMSubTreeData subTree = (DOMSubTreeData)data;
/* 141 */           if (this.inclusiveNamespaces != null) {
/* 142 */             return new OctetStreamData(new ByteArrayInputStream(this.apacheCanonicalizer.canonicalizeSubtree(subTree.getRoot(), this.inclusiveNamespaces)));
/*     */           }
/*     */           
/*     */ 
/* 146 */           return new OctetStreamData(new ByteArrayInputStream(this.apacheCanonicalizer.canonicalizeSubtree(subTree.getRoot())));
/*     */         }
/*     */         
/*     */ 
/* 150 */         if ((data instanceof NodeSetData)) {
/* 151 */           NodeSetData nsd = (NodeSetData)data;
/*     */           
/* 153 */           nodeSet = Utils.toNodeSet(nsd.iterator());
/* 154 */           if (log.isLoggable(Level.FINE)) {
/* 155 */             log.log(Level.FINE, "Canonicalizing " + nodeSet.size() + " nodes");
/*     */           }
/*     */         }
/*     */         else {
/* 159 */           return new OctetStreamData(new ByteArrayInputStream(this.apacheCanonicalizer.canonicalize(Utils.readBytesFromStream(((OctetStreamData)data).getOctetStream()))));
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 164 */       if (this.inclusiveNamespaces != null) {
/* 165 */         return new OctetStreamData(new ByteArrayInputStream(this.apacheCanonicalizer.canonicalizeXPathNodeSet(nodeSet, this.inclusiveNamespaces)));
/*     */       }
/*     */       
/*     */ 
/* 169 */       return new OctetStreamData(new ByteArrayInputStream(this.apacheCanonicalizer.canonicalizeXPathNodeSet(nodeSet)));
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 173 */       throw new TransformException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public Data transform(Data data, XMLCryptoContext xc, OutputStream os) throws TransformException
/*     */   {
/* 179 */     if (data == null) {
/* 180 */       throw new NullPointerException("data must not be null");
/*     */     }
/* 182 */     if (os == null) {
/* 183 */       throw new NullPointerException("output stream must not be null");
/*     */     }
/*     */     
/* 186 */     if (this.ownerDoc == null) {
/* 187 */       throw new TransformException("transform must be marshalled");
/*     */     }
/*     */     
/* 190 */     if (this.apacheTransform == null) {
/*     */       try {
/* 192 */         this.apacheTransform = Transform.getInstance(this.ownerDoc, getAlgorithm(), this.transformElem.getChildNodes());
/*     */         
/* 194 */         this.apacheTransform.setElement(this.transformElem, xc.getBaseURI());
/* 195 */         if (log.isLoggable(Level.FINE)) {
/* 196 */           log.log(Level.FINE, "Created transform for algorithm: " + getAlgorithm());
/*     */         }
/*     */       }
/*     */       catch (Exception ex) {
/* 200 */         throw new TransformException("Couldn't find Transform for: " + getAlgorithm(), ex);
/*     */       }
/*     */     }
/*     */     
/*     */     XMLSignatureInput in;
/*     */     XMLSignatureInput in;
/* 206 */     if ((data instanceof ApacheData)) {
/* 207 */       if (log.isLoggable(Level.FINE)) {
/* 208 */         log.log(Level.FINE, "ApacheData = true");
/*     */       }
/* 210 */       in = ((ApacheData)data).getXMLSignatureInput(); } else { XMLSignatureInput in;
/* 211 */       if ((data instanceof NodeSetData)) {
/* 212 */         if (log.isLoggable(Level.FINE)) {
/* 213 */           log.log(Level.FINE, "isNodeSet() = true");
/*     */         }
/* 215 */         if ((data instanceof DOMSubTreeData)) {
/* 216 */           DOMSubTreeData subTree = (DOMSubTreeData)data;
/* 217 */           XMLSignatureInput in = new XMLSignatureInput(subTree.getRoot());
/* 218 */           in.setExcludeComments(subTree.excludeComments());
/*     */         } else {
/* 220 */           Set nodeSet = Utils.toNodeSet(((NodeSetData)data).iterator());
/*     */           
/* 222 */           in = new XMLSignatureInput(nodeSet);
/*     */         }
/*     */       } else {
/* 225 */         if (log.isLoggable(Level.FINE)) {
/* 226 */           log.log(Level.FINE, "isNodeSet() = false");
/*     */         }
/*     */         try {
/* 229 */           in = new XMLSignatureInput(((OctetStreamData)data).getOctetStream());
/*     */         }
/*     */         catch (Exception ex) {
/* 232 */           throw new TransformException(ex);
/*     */         }
/*     */       }
/*     */     }
/*     */     try {
/* 237 */       in = this.apacheTransform.performTransform(in, os);
/* 238 */       if ((!in.isNodeSet()) && (!in.isElement())) {
/* 239 */         return null;
/*     */       }
/* 241 */       if (in.isOctetStream()) {
/* 242 */         return new ApacheOctetStreamData(in);
/*     */       }
/* 244 */       return new ApacheNodeSetData(in);
/*     */     }
/*     */     catch (Exception ex) {
/* 247 */       throw new TransformException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public final boolean isFeatureSupported(String feature) {
/* 252 */     if (feature == null) {
/* 253 */       throw new NullPointerException();
/*     */     }
/* 255 */     return false;
/*     */   }
/*     */   
/*     */   static {}
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\jcp\xml\dsig\internal\dom\ApacheCanonicalizer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */