/*    */ package org.apache.xml.security.transforms.implementations;
/*    */ 
/*    */ import java.io.OutputStream;
/*    */ import org.apache.xml.security.c14n.CanonicalizationException;
/*    */ import org.apache.xml.security.c14n.implementations.Canonicalizer20010315WithComments;
/*    */ import org.apache.xml.security.signature.XMLSignatureInput;
/*    */ import org.apache.xml.security.transforms.Transform;
/*    */ import org.apache.xml.security.transforms.TransformSpi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransformC14NWithComments
/*    */   extends TransformSpi
/*    */ {
/*    */   public static final String implementedTransformURI = "http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments";
/*    */   
/*    */   protected String engineGetURI()
/*    */   {
/* 42 */     return "http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments";
/*    */   }
/*    */   
/*    */ 
/*    */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, Transform _transformObject)
/*    */     throws CanonicalizationException
/*    */   {
/* 49 */     return enginePerformTransform(input, null, _transformObject);
/*    */   }
/*    */   
/*    */ 
/*    */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, OutputStream os, Transform _transformObject)
/*    */     throws CanonicalizationException
/*    */   {
/* 56 */     Canonicalizer20010315WithComments c14n = new Canonicalizer20010315WithComments();
/* 57 */     if (os != null) {
/* 58 */       c14n.setWriter(os);
/*    */     }
/*    */     
/* 61 */     byte[] result = null;
/* 62 */     result = c14n.engineCanonicalize(input);
/* 63 */     XMLSignatureInput output = new XMLSignatureInput(result);
/* 64 */     if (os != null) {
/* 65 */       output.setOutputStream(os);
/*    */     }
/* 67 */     return output;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\transforms\implementations\TransformC14NWithComments.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */