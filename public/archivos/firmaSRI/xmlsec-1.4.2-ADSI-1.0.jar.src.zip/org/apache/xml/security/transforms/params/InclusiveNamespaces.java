/*     */ package org.apache.xml.security.transforms.params;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.SortedSet;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.TreeSet;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.transforms.TransformParam;
/*     */ import org.apache.xml.security.utils.ElementProxy;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InclusiveNamespaces
/*     */   extends ElementProxy
/*     */   implements TransformParam
/*     */ {
/*     */   public static final String _TAG_EC_INCLUSIVENAMESPACES = "InclusiveNamespaces";
/*     */   public static final String _ATT_EC_PREFIXLIST = "PrefixList";
/*     */   public static final String ExclusiveCanonicalizationNamespace = "http://www.w3.org/2001/10/xml-exc-c14n#";
/*     */   
/*     */   public InclusiveNamespaces(Document doc, String prefixList)
/*     */   {
/*  64 */     this(doc, prefixStr2Set(prefixList));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InclusiveNamespaces(Document doc, Set prefixes)
/*     */   {
/*  75 */     super(doc);
/*     */     
/*  77 */     StringBuffer sb = new StringBuffer();
/*  78 */     SortedSet prefixList = new TreeSet(prefixes);
/*     */     
/*     */ 
/*  81 */     Iterator it = prefixList.iterator();
/*     */     
/*  83 */     while (it.hasNext()) {
/*  84 */       String prefix = (String)it.next();
/*     */       
/*  86 */       if (prefix.equals("xmlns")) {
/*  87 */         sb.append("#default ");
/*     */       } else {
/*  89 */         sb.append(prefix + " ");
/*     */       }
/*     */     }
/*     */     
/*  93 */     this._constructionElement.setAttributeNS(null, "PrefixList", sb.toString().trim());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getInclusiveNamespaces()
/*     */   {
/* 104 */     return this._constructionElement.getAttributeNS(null, "PrefixList");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InclusiveNamespaces(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 117 */     super(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SortedSet prefixStr2Set(String inclusiveNamespaces)
/*     */   {
/* 139 */     SortedSet prefixes = new TreeSet();
/*     */     
/* 141 */     if ((inclusiveNamespaces == null) || (inclusiveNamespaces.length() == 0))
/*     */     {
/* 143 */       return prefixes;
/*     */     }
/*     */     
/* 146 */     StringTokenizer st = new StringTokenizer(inclusiveNamespaces, " \t\r\n");
/*     */     
/* 148 */     while (st.hasMoreTokens()) {
/* 149 */       String prefix = st.nextToken();
/*     */       
/* 151 */       if (prefix.equals("#default")) {
/* 152 */         prefixes.add("xmlns");
/*     */       } else {
/* 154 */         prefixes.add(prefix);
/*     */       }
/*     */     }
/*     */     
/* 158 */     return prefixes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBaseNamespace()
/*     */   {
/* 167 */     return "http://www.w3.org/2001/10/xml-exc-c14n#";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBaseLocalName()
/*     */   {
/* 176 */     return "InclusiveNamespaces";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\transforms\params\InclusiveNamespaces.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */