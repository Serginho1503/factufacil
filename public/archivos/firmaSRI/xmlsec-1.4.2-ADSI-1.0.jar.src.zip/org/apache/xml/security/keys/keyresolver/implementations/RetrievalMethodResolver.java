/*     */ package org.apache.xml.security.keys.keyresolver.implementations;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Set;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.keys.content.RetrievalMethod;
/*     */ import org.apache.xml.security.keys.keyresolver.KeyResolver;
/*     */ import org.apache.xml.security.keys.keyresolver.KeyResolverException;
/*     */ import org.apache.xml.security.keys.keyresolver.KeyResolverSpi;
/*     */ import org.apache.xml.security.keys.storage.StorageResolver;
/*     */ import org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import org.apache.xml.security.transforms.Transforms;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.apache.xml.security.utils.resolver.ResourceResolver;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RetrievalMethodResolver
/*     */   extends KeyResolverSpi
/*     */ {
/*  68 */   static Log log = LogFactory.getLog(RetrievalMethodResolver.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PublicKey engineLookupAndResolvePublicKey(Element element, String BaseURI, StorageResolver storage)
/*     */   {
/*  83 */     if (!XMLUtils.elementIsInSignatureSpace(element, "RetrievalMethod"))
/*     */     {
/*  85 */       return null;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/*  90 */       RetrievalMethod rm = new RetrievalMethod(element, BaseURI);
/*  91 */       String type = rm.getType();
/*  92 */       XMLSignatureInput resource = resolveInput(rm, BaseURI);
/*  93 */       if ("http://www.w3.org/2000/09/xmldsig#rawX509Certificate".equals(type))
/*     */       {
/*  95 */         X509Certificate cert = getRawCertificate(resource);
/*  96 */         if (cert != null) {
/*  97 */           return cert.getPublicKey();
/*     */         }
/*  99 */         return null;
/*     */       }
/* 101 */       Element e = obtainRefrenceElement(resource);
/* 102 */       return resolveKey(e, BaseURI, storage);
/*     */     } catch (XMLSecurityException ex) {
/* 104 */       log.debug("XMLSecurityException", ex);
/*     */     } catch (CertificateException ex) {
/* 106 */       log.debug("CertificateException", ex);
/*     */     } catch (IOException ex) {
/* 108 */       log.debug("IOException", ex);
/*     */     } catch (ParserConfigurationException e) {
/* 110 */       log.debug("ParserConfigurationException", e);
/*     */     } catch (SAXException e) {
/* 112 */       log.debug("SAXException", e);
/*     */     }
/* 114 */     return null;
/*     */   }
/*     */   
/*     */   private static Element obtainRefrenceElement(XMLSignatureInput resource) throws CanonicalizationException, ParserConfigurationException, IOException, SAXException, KeyResolverException { Element e;
/*     */     Element e;
/* 119 */     if (resource.isElement()) {
/* 120 */       e = (Element)resource.getSubNode(); } else { Element e;
/* 121 */       if (resource.isNodeSet())
/*     */       {
/* 123 */         e = getDocumentElement(resource.getNodeSet());
/*     */       }
/*     */       else {
/* 126 */         byte[] inputBytes = resource.getBytes();
/* 127 */         e = getDocFromBytes(inputBytes);
/*     */         
/* 129 */         if (log.isDebugEnabled())
/* 130 */           log.debug("we have to parse " + inputBytes.length + " bytes");
/*     */       } }
/* 132 */     return e;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Certificate engineLookupResolveX509Certificate(Element element, String BaseURI, StorageResolver storage)
/*     */   {
/* 146 */     if (!XMLUtils.elementIsInSignatureSpace(element, "RetrievalMethod"))
/*     */     {
/* 148 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 152 */       RetrievalMethod rm = new RetrievalMethod(element, BaseURI);
/* 153 */       String type = rm.getType();
/* 154 */       XMLSignatureInput resource = resolveInput(rm, BaseURI);
/* 155 */       if ("http://www.w3.org/2000/09/xmldsig#rawX509Certificate".equals(type)) {
/* 156 */         return getRawCertificate(resource);
/*     */       }
/*     */       
/* 159 */       Element e = obtainRefrenceElement(resource);
/* 160 */       return resolveCertificate(e, BaseURI, storage);
/*     */     } catch (XMLSecurityException ex) {
/* 162 */       log.debug("XMLSecurityException", ex);
/*     */     } catch (CertificateException ex) {
/* 164 */       log.debug("CertificateException", ex);
/*     */     } catch (IOException ex) {
/* 166 */       log.debug("IOException", ex);
/*     */     } catch (ParserConfigurationException e) {
/* 168 */       log.debug("ParserConfigurationException", e);
/*     */     } catch (SAXException e) {
/* 170 */       log.debug("SAXException", e);
/*     */     }
/* 172 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static X509Certificate resolveCertificate(Element e, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/* 184 */     if (log.isDebugEnabled()) {
/* 185 */       log.debug("Now we have a {" + e.getNamespaceURI() + "}" + e.getLocalName() + " Element");
/*     */     }
/* 187 */     if (e != null) {
/* 188 */       return KeyResolver.getX509Certificate(e, BaseURI, storage);
/*     */     }
/* 190 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static PublicKey resolveKey(Element e, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/* 202 */     if (log.isDebugEnabled()) {
/* 203 */       log.debug("Now we have a {" + e.getNamespaceURI() + "}" + e.getLocalName() + " Element");
/*     */     }
/* 205 */     if (e != null) {
/* 206 */       return KeyResolver.getPublicKey(e, BaseURI, storage);
/*     */     }
/* 208 */     return null;
/*     */   }
/*     */   
/*     */   private static X509Certificate getRawCertificate(XMLSignatureInput resource) throws CanonicalizationException, IOException, CertificateException {
/* 212 */     byte[] inputBytes = resource.getBytes();
/*     */     
/* 214 */     CertificateFactory certFact = CertificateFactory.getInstance("X.509");
/* 215 */     X509Certificate cert = (X509Certificate)certFact.generateCertificate(new ByteArrayInputStream(inputBytes));
/* 216 */     return cert;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static XMLSignatureInput resolveInput(RetrievalMethod rm, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 224 */     Attr uri = rm.getURIAttr();
/*     */     
/* 226 */     Transforms transforms = rm.getTransforms();
/* 227 */     ResourceResolver resRes = ResourceResolver.getInstance(uri, BaseURI);
/* 228 */     if (resRes != null) {
/* 229 */       XMLSignatureInput resource = resRes.resolve(uri, BaseURI);
/* 230 */       if (transforms != null) {
/* 231 */         log.debug("We have Transforms");
/* 232 */         resource = transforms.performTransforms(resource);
/*     */       }
/* 234 */       return resource;
/*     */     }
/* 236 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Element getDocFromBytes(byte[] bytes)
/*     */     throws KeyResolverException
/*     */   {
/*     */     try
/*     */     {
/* 248 */       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 249 */       dbf.setNamespaceAware(true);
/* 250 */       DocumentBuilder db = dbf.newDocumentBuilder();
/* 251 */       Document doc = db.parse(new ByteArrayInputStream(bytes));
/*     */       
/* 253 */       return doc.getDocumentElement();
/*     */     } catch (SAXException ex) {
/* 255 */       throw new KeyResolverException("empty", ex);
/*     */     } catch (IOException ex) {
/* 257 */       throw new KeyResolverException("empty", ex);
/*     */     } catch (ParserConfigurationException ex) {
/* 259 */       throw new KeyResolverException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SecretKey engineLookupAndResolveSecretKey(Element element, String BaseURI, StorageResolver storage)
/*     */   {
/* 274 */     return null;
/*     */   }
/*     */   
/*     */   static Element getDocumentElement(Set set) {
/* 278 */     Iterator it = set.iterator();
/* 279 */     Element e = null;
/* 280 */     while (it.hasNext()) {
/* 281 */       Node currentNode = (Node)it.next();
/* 282 */       if ((currentNode instanceof Element)) {
/* 283 */         e = (Element)currentNode;
/* 284 */         break;
/*     */       }
/*     */     }
/*     */     
/* 288 */     List parents = new ArrayList(10);
/*     */     
/*     */     do
/*     */     {
/* 292 */       parents.add(e);
/* 293 */       Node n = e.getParentNode();
/* 294 */       if (!(n instanceof Element)) {
/*     */         break;
/*     */       }
/* 297 */       e = (Element)n;
/* 298 */     } while (e != null);
/*     */     
/* 300 */     ListIterator it2 = parents.listIterator(parents.size() - 1);
/* 301 */     Element ele = null;
/* 302 */     while (it2.hasPrevious()) {
/* 303 */       ele = (Element)it2.previous();
/* 304 */       if (set.contains(ele)) {
/* 305 */         return ele;
/*     */       }
/*     */     }
/* 308 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\keyresolver\implementations\RetrievalMethodResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */