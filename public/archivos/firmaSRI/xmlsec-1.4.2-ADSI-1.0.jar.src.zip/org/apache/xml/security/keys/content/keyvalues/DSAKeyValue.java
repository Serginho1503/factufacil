/*     */ package org.apache.xml.security.keys.content.keyvalues;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import java.security.Key;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PublicKey;
/*     */ import java.security.interfaces.DSAParams;
/*     */ import java.security.interfaces.DSAPublicKey;
/*     */ import java.security.spec.DSAPublicKeySpec;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.utils.I18n;
/*     */ import org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DSAKeyValue
/*     */   extends SignatureElementProxy
/*     */   implements KeyValueContent
/*     */ {
/*     */   public DSAKeyValue(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  52 */     super(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DSAKeyValue(Document doc, BigInteger P, BigInteger Q, BigInteger G, BigInteger Y)
/*     */   {
/*  67 */     super(doc);
/*     */     
/*  69 */     XMLUtils.addReturnToElement(this._constructionElement);
/*  70 */     addBigIntegerElement(P, "P");
/*  71 */     addBigIntegerElement(Q, "Q");
/*  72 */     addBigIntegerElement(G, "G");
/*  73 */     addBigIntegerElement(Y, "Y");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DSAKeyValue(Document doc, Key key)
/*     */     throws IllegalArgumentException
/*     */   {
/*  85 */     super(doc);
/*     */     
/*  87 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */     
/*  89 */     if ((key instanceof DSAPublicKey)) {
/*  90 */       addBigIntegerElement(((DSAPublicKey)key).getParams().getP(), "P");
/*     */       
/*  92 */       addBigIntegerElement(((DSAPublicKey)key).getParams().getQ(), "Q");
/*     */       
/*  94 */       addBigIntegerElement(((DSAPublicKey)key).getParams().getG(), "G");
/*     */       
/*  96 */       addBigIntegerElement(((DSAPublicKey)key).getY(), "Y");
/*     */     }
/*     */     else {
/*  99 */       Object[] exArgs = { "DSAKeyValue", key.getClass().getName() };
/*     */       
/*     */ 
/* 102 */       throw new IllegalArgumentException(I18n.translate("KeyValue.IllegalArgument", exArgs));
/*     */     }
/*     */   }
/*     */   
/*     */   public PublicKey getPublicKey()
/*     */     throws XMLSecurityException
/*     */   {
/*     */     try
/*     */     {
/* 111 */       DSAPublicKeySpec pkspec = new DSAPublicKeySpec(getBigIntegerFromChildElement("Y", "http://www.w3.org/2000/09/xmldsig#"), getBigIntegerFromChildElement("P", "http://www.w3.org/2000/09/xmldsig#"), getBigIntegerFromChildElement("Q", "http://www.w3.org/2000/09/xmldsig#"), getBigIntegerFromChildElement("G", "http://www.w3.org/2000/09/xmldsig#"));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 121 */       KeyFactory dsaFactory = KeyFactory.getInstance("DSA");
/* 122 */       return dsaFactory.generatePublic(pkspec);
/*     */     }
/*     */     catch (NoSuchAlgorithmException ex)
/*     */     {
/* 126 */       throw new XMLSecurityException("empty", ex);
/*     */     } catch (InvalidKeySpecException ex) {
/* 128 */       throw new XMLSecurityException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 134 */     return "DSAKeyValue";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\content\keyvalues\DSAKeyValue.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */