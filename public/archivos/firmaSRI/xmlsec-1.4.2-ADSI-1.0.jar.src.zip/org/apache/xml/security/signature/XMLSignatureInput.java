/*     */ package org.apache.xml.security.signature;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import org.apache.xml.security.c14n.implementations.Canonicalizer11_OmitComments;
/*     */ import org.apache.xml.security.c14n.implementations.Canonicalizer20010315OmitComments;
/*     */ import org.apache.xml.security.c14n.implementations.CanonicalizerBase;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityRuntimeException;
/*     */ import org.apache.xml.security.utils.IgnoreAllErrorHandler;
/*     */ import org.apache.xml.security.utils.JavaUtils;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLSignatureInput
/*     */   implements Cloneable
/*     */ {
/*  56 */   static Log log = LogFactory.getLog(XMLSignatureInput.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  73 */   InputStream _inputOctetStreamProxy = null;
/*     */   
/*     */ 
/*     */ 
/*  77 */   Set _inputNodeSet = null;
/*     */   
/*     */ 
/*     */ 
/*  81 */   Node _subNode = null;
/*     */   
/*     */ 
/*     */ 
/*  85 */   Node excludeNode = null;
/*     */   
/*     */ 
/*     */ 
/*  89 */   boolean excludeComments = false;
/*     */   
/*  91 */   boolean isNodeSet = false;
/*     */   
/*     */ 
/*     */ 
/*  95 */   byte[] bytes = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 100 */   private String _MIMEType = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 105 */   private String _SourceURI = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 110 */   List nodeFilters = new ArrayList();
/*     */   
/* 112 */   boolean needsToBeExpanded = false;
/* 113 */   OutputStream outputStream = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isNeedsToBeExpanded()
/*     */   {
/* 120 */     return this.needsToBeExpanded;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNeedsToBeExpanded(boolean needsToBeExpanded)
/*     */   {
/* 128 */     this.needsToBeExpanded = needsToBeExpanded;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput(byte[] inputOctets)
/*     */   {
/* 144 */     this.bytes = inputOctets;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput(InputStream inputOctetStream)
/*     */   {
/* 154 */     this._inputOctetStreamProxy = inputOctetStream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public XMLSignatureInput(String inputStr)
/*     */   {
/* 168 */     this(inputStr.getBytes());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public XMLSignatureInput(String inputStr, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 184 */     this(inputStr.getBytes(encoding));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput(Node rootNode)
/*     */   {
/* 195 */     this._subNode = rootNode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput(Set inputNodeSet)
/*     */   {
/* 205 */     this._inputNodeSet = inputNodeSet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set getNodeSet()
/*     */     throws CanonicalizationException, ParserConfigurationException, IOException, SAXException
/*     */   {
/* 220 */     return getNodeSet(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set getNodeSet(boolean circumvent)
/*     */     throws ParserConfigurationException, IOException, SAXException, CanonicalizationException
/*     */   {
/* 237 */     if (this._inputNodeSet != null) {
/* 238 */       return this._inputNodeSet;
/*     */     }
/* 240 */     if ((this._inputOctetStreamProxy == null) && (this._subNode != null))
/*     */     {
/* 242 */       if (circumvent) {
/* 243 */         XMLUtils.circumventBug2650(XMLUtils.getOwnerDocument(this._subNode));
/*     */       }
/* 245 */       this._inputNodeSet = new HashSet();
/* 246 */       XMLUtils.getSet(this._subNode, this._inputNodeSet, this.excludeNode, this.excludeComments);
/*     */       
/* 248 */       return this._inputNodeSet; }
/* 249 */     if (isOctetStream()) {
/* 250 */       convertToNodes();
/* 251 */       HashSet result = new HashSet();
/* 252 */       XMLUtils.getSet(this._subNode, result, null, false);
/*     */       
/* 254 */       return result;
/*     */     }
/*     */     
/* 257 */     throw new RuntimeException("getNodeSet() called but no input data present");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputStream getOctetStream()
/*     */     throws IOException
/*     */   {
/* 271 */     return getResetableInputStream();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public InputStream getOctetStreamReal()
/*     */   {
/* 278 */     return this._inputOctetStreamProxy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getBytes()
/*     */     throws IOException, CanonicalizationException
/*     */   {
/* 292 */     if (this.bytes != null) {
/* 293 */       return this.bytes;
/*     */     }
/* 295 */     InputStream is = getResetableInputStream();
/* 296 */     if (is != null)
/*     */     {
/* 298 */       if (this.bytes == null) {
/* 299 */         is.reset();
/* 300 */         this.bytes = JavaUtils.getBytesFromStream(is);
/*     */       }
/* 302 */       return this.bytes;
/*     */     }
/* 304 */     Canonicalizer20010315OmitComments c14nizer = new Canonicalizer20010315OmitComments();
/*     */     
/* 306 */     this.bytes = c14nizer.engineCanonicalize(this);
/* 307 */     return this.bytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isNodeSet()
/*     */   {
/* 316 */     return ((this._inputOctetStreamProxy == null) && (this._inputNodeSet != null)) || (this.isNodeSet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isElement()
/*     */   {
/* 326 */     return (this._inputOctetStreamProxy == null) && (this._subNode != null) && (this._inputNodeSet == null) && (!this.isNodeSet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isOctetStream()
/*     */   {
/* 336 */     return ((this._inputOctetStreamProxy != null) || (this.bytes != null)) && (this._inputNodeSet == null) && (this._subNode == null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isOutputStreamSet()
/*     */   {
/* 348 */     return this.outputStream != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isByteArray()
/*     */   {
/* 357 */     return (this.bytes != null) && (this._inputNodeSet == null) && (this._subNode == null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isInitialized()
/*     */   {
/* 367 */     return (isOctetStream()) || (isNodeSet());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMIMEType()
/*     */   {
/* 376 */     return this._MIMEType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMIMEType(String MIMEType)
/*     */   {
/* 385 */     this._MIMEType = MIMEType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSourceURI()
/*     */   {
/* 394 */     return this._SourceURI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSourceURI(String SourceURI)
/*     */   {
/* 403 */     this._SourceURI = SourceURI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 411 */     if (isNodeSet()) {
/* 412 */       return "XMLSignatureInput/NodeSet/" + this._inputNodeSet.size() + " nodes/" + getSourceURI();
/*     */     }
/*     */     
/* 415 */     if (isElement()) {
/* 416 */       return "XMLSignatureInput/Element/" + this._subNode + " exclude " + this.excludeNode + " comments:" + this.excludeComments + "/" + getSourceURI();
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 421 */       return "XMLSignatureInput/OctetStream/" + getBytes().length + " octets/" + getSourceURI();
/*     */     }
/*     */     catch (IOException iex) {
/* 424 */       return "XMLSignatureInput/OctetStream//" + getSourceURI();
/*     */     } catch (CanonicalizationException cex) {}
/* 426 */     return "XMLSignatureInput/OctetStream//" + getSourceURI();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHTMLRepresentation()
/*     */     throws XMLSignatureException
/*     */   {
/* 438 */     XMLSignatureInputDebugger db = new XMLSignatureInputDebugger(this);
/*     */     
/* 440 */     return db.getHTMLRepresentation();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHTMLRepresentation(Set inclusiveNamespaces)
/*     */     throws XMLSignatureException
/*     */   {
/* 453 */     XMLSignatureInputDebugger db = new XMLSignatureInputDebugger(this, inclusiveNamespaces);
/*     */     
/*     */ 
/* 456 */     return db.getHTMLRepresentation();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node getExcludeNode()
/*     */   {
/* 464 */     return this.excludeNode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExcludeNode(Node excludeNode)
/*     */   {
/* 472 */     this.excludeNode = excludeNode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node getSubNode()
/*     */   {
/* 480 */     return this._subNode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isExcludeComments()
/*     */   {
/* 487 */     return this.excludeComments;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setExcludeComments(boolean excludeComments)
/*     */   {
/* 494 */     this.excludeComments = excludeComments;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void updateOutputStream(OutputStream diOs)
/*     */     throws CanonicalizationException, IOException
/*     */   {
/* 504 */     updateOutputStream(diOs, false);
/*     */   }
/*     */   
/*     */   public void updateOutputStream(OutputStream diOs, boolean c14n11) throws CanonicalizationException, IOException
/*     */   {
/* 509 */     if (diOs == this.outputStream) {
/* 510 */       return;
/*     */     }
/* 512 */     if (this.bytes != null) {
/* 513 */       diOs.write(this.bytes);
/* 514 */       return; }
/* 515 */     if (this._inputOctetStreamProxy == null) {
/* 516 */       CanonicalizerBase c14nizer = null;
/* 517 */       if (c14n11) {
/* 518 */         c14nizer = new Canonicalizer11_OmitComments();
/*     */       } else {
/* 520 */         c14nizer = new Canonicalizer20010315OmitComments();
/*     */       }
/* 522 */       c14nizer.setWriter(diOs);
/* 523 */       c14nizer.engineCanonicalize(this);
/* 524 */       return;
/*     */     }
/* 526 */     InputStream is = getResetableInputStream();
/* 527 */     if (this.bytes != null)
/*     */     {
/* 529 */       diOs.write(this.bytes, 0, this.bytes.length);
/* 530 */       return;
/*     */     }
/* 532 */     is.reset();
/*     */     
/* 534 */     byte[] bytesT = new byte['က'];
/* 535 */     int num; while ((num = is.read(bytesT)) >= 0) {
/* 536 */       diOs.write(bytesT, 0, num);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOutputStream(OutputStream os)
/*     */   {
/* 545 */     this.outputStream = os;
/*     */   }
/*     */   
/*     */   protected InputStream getResetableInputStream() throws IOException {
/* 549 */     if ((this._inputOctetStreamProxy instanceof ByteArrayInputStream)) {
/* 550 */       if (!this._inputOctetStreamProxy.markSupported()) {
/* 551 */         throw new RuntimeException("Accepted as Markable but not truly been" + this._inputOctetStreamProxy);
/*     */       }
/* 553 */       return this._inputOctetStreamProxy;
/*     */     }
/*     */     
/* 556 */     if ((this._inputOctetStreamProxy != null) && (this._inputOctetStreamProxy.markSupported())) {
/* 557 */       return this._inputOctetStreamProxy;
/*     */     }
/* 559 */     if (this.bytes != null) {
/* 560 */       this._inputOctetStreamProxy = new ByteArrayInputStream(this.bytes);
/* 561 */       return this._inputOctetStreamProxy;
/*     */     }
/* 563 */     if (this._inputOctetStreamProxy == null)
/* 564 */       return null;
/* 565 */     if (this._inputOctetStreamProxy.markSupported()) {
/* 566 */       log.info("Mark Suported but not used as reset");
/*     */     }
/* 568 */     this.bytes = JavaUtils.getBytesFromStream(this._inputOctetStreamProxy);
/* 569 */     this._inputOctetStreamProxy.close();
/* 570 */     this._inputOctetStreamProxy = new ByteArrayInputStream(this.bytes);
/* 571 */     return this._inputOctetStreamProxy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addNodeFilter(NodeFilter filter)
/*     */   {
/* 578 */     if (isOctetStream()) {
/*     */       try {
/* 580 */         convertToNodes();
/*     */       } catch (Exception e) {
/* 582 */         throw new XMLSecurityRuntimeException("signature.XMLSignatureInput.nodesetReference", e);
/*     */       }
/*     */     }
/* 585 */     this.nodeFilters.add(filter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getNodeFilters()
/*     */   {
/* 593 */     return this.nodeFilters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setNodeSet(boolean b)
/*     */   {
/* 600 */     this.isNodeSet = b;
/*     */   }
/*     */   
/*     */   void convertToNodes() throws CanonicalizationException, ParserConfigurationException, IOException, SAXException
/*     */   {
/* 605 */     DocumentBuilderFactory dfactory = DocumentBuilderFactory.newInstance();
/* 606 */     dfactory.setValidating(false);
/* 607 */     dfactory.setNamespaceAware(true);
/* 608 */     DocumentBuilder db = dfactory.newDocumentBuilder();
/*     */     try
/*     */     {
/* 611 */       db.setErrorHandler(new IgnoreAllErrorHandler());
/*     */       
/*     */ 
/* 614 */       Document doc = db.parse(getOctetStream());
/*     */       
/* 616 */       this._subNode = doc.getDocumentElement();
/*     */     }
/*     */     catch (SAXException ex)
/*     */     {
/* 620 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*     */       
/* 622 */       baos.write("<container>".getBytes());
/* 623 */       baos.write(getBytes());
/* 624 */       baos.write("</container>".getBytes());
/*     */       
/* 626 */       byte[] result = baos.toByteArray();
/* 627 */       Document document = db.parse(new ByteArrayInputStream(result));
/* 628 */       this._subNode = document.getDocumentElement().getFirstChild().getFirstChild();
/*     */     }
/* 630 */     this._inputOctetStreamProxy = null;
/* 631 */     this.bytes = null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\signature\XMLSignatureInput.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */