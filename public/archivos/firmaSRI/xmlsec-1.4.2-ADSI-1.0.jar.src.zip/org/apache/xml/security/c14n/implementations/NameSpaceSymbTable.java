/*     */ package org.apache.xml.security.c14n.implementations;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NameSpaceSymbTable
/*     */ {
/*     */   SymbMap symb;
/*  41 */   int nameSpaces = 0;
/*     */   
/*     */   List level;
/*  44 */   boolean cloned = true;
/*     */   static final String XMLNS = "xmlns";
/*  46 */   static final SymbMap initialMap = new SymbMap();
/*     */   
/*  48 */   static { NameSpaceSymbEntry ne = new NameSpaceSymbEntry("", null, true, "xmlns");
/*  49 */     ne.lastrendered = "";
/*  50 */     initialMap.put("xmlns", ne);
/*     */   }
/*     */   
/*     */ 
/*     */   public NameSpaceSymbTable()
/*     */   {
/*  56 */     this.level = new ArrayList(10);
/*     */     
/*  58 */     this.symb = ((SymbMap)initialMap.clone());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getUnrenderedNodes(Collection result)
/*     */   {
/*  68 */     Iterator it = this.symb.entrySet().iterator();
/*  69 */     while (it.hasNext()) {
/*  70 */       NameSpaceSymbEntry n = (NameSpaceSymbEntry)it.next();
/*     */       
/*  72 */       if ((!n.rendered) && (n.n != null)) {
/*  73 */         n = (NameSpaceSymbEntry)n.clone();
/*  74 */         needsClone();
/*  75 */         this.symb.put(n.prefix, n);
/*  76 */         n.lastrendered = n.uri;
/*  77 */         n.rendered = true;
/*     */         
/*  79 */         result.add(n.n);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void outputNodePush()
/*     */   {
/*  90 */     this.nameSpaces += 1;
/*  91 */     push();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void outputNodePop()
/*     */   {
/*  98 */     this.nameSpaces -= 1;
/*  99 */     pop();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void push()
/*     */   {
/* 108 */     this.level.add(null);
/* 109 */     this.cloned = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void pop()
/*     */   {
/* 117 */     int size = this.level.size() - 1;
/* 118 */     Object ob = this.level.remove(size);
/* 119 */     if (ob != null) {
/* 120 */       this.symb = ((SymbMap)ob);
/* 121 */       if (size == 0) {
/* 122 */         this.cloned = false;
/*     */       } else
/* 124 */         this.cloned = (this.level.get(size - 1) != this.symb);
/*     */     } else {
/* 126 */       this.cloned = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   final void needsClone()
/*     */   {
/* 133 */     if (!this.cloned) {
/* 134 */       this.level.set(this.level.size() - 1, this.symb);
/* 135 */       this.symb = ((SymbMap)this.symb.clone());
/* 136 */       this.cloned = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Attr getMapping(String prefix)
/*     */   {
/* 148 */     NameSpaceSymbEntry entry = this.symb.get(prefix);
/* 149 */     if (entry == null)
/*     */     {
/* 151 */       return null;
/*     */     }
/* 153 */     if (entry.rendered)
/*     */     {
/* 155 */       return null;
/*     */     }
/*     */     
/* 158 */     entry = (NameSpaceSymbEntry)entry.clone();
/* 159 */     needsClone();
/* 160 */     this.symb.put(prefix, entry);
/* 161 */     entry.rendered = true;
/* 162 */     entry.level = this.nameSpaces;
/* 163 */     entry.lastrendered = entry.uri;
/*     */     
/* 165 */     return entry.n;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Attr getMappingWithoutRendered(String prefix)
/*     */   {
/* 175 */     NameSpaceSymbEntry entry = this.symb.get(prefix);
/* 176 */     if (entry == null) {
/* 177 */       return null;
/*     */     }
/* 179 */     if (entry.rendered) {
/* 180 */       return null;
/*     */     }
/* 182 */     return entry.n;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean addMapping(String prefix, String uri, Attr n)
/*     */   {
/* 193 */     NameSpaceSymbEntry ob = this.symb.get(prefix);
/* 194 */     if ((ob != null) && (uri.equals(ob.uri)))
/*     */     {
/* 196 */       return false;
/*     */     }
/*     */     
/* 199 */     NameSpaceSymbEntry ne = new NameSpaceSymbEntry(uri, n, false, prefix);
/* 200 */     needsClone();
/* 201 */     this.symb.put(prefix, ne);
/* 202 */     if (ob != null)
/*     */     {
/*     */ 
/* 205 */       ne.lastrendered = ob.lastrendered;
/* 206 */       if ((ob.lastrendered != null) && (ob.lastrendered.equals(uri)))
/*     */       {
/* 208 */         ne.rendered = true;
/*     */       }
/*     */     }
/* 211 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node addMappingAndRender(String prefix, String uri, Attr n)
/*     */   {
/* 223 */     NameSpaceSymbEntry ob = this.symb.get(prefix);
/*     */     
/* 225 */     if ((ob != null) && (uri.equals(ob.uri))) {
/* 226 */       if (!ob.rendered) {
/* 227 */         ob = (NameSpaceSymbEntry)ob.clone();
/* 228 */         needsClone();
/* 229 */         this.symb.put(prefix, ob);
/* 230 */         ob.lastrendered = uri;
/* 231 */         ob.rendered = true;
/* 232 */         return ob.n;
/*     */       }
/* 234 */       return null;
/*     */     }
/*     */     
/* 237 */     NameSpaceSymbEntry ne = new NameSpaceSymbEntry(uri, n, true, prefix);
/* 238 */     ne.lastrendered = uri;
/* 239 */     needsClone();
/* 240 */     this.symb.put(prefix, ne);
/* 241 */     if (ob != null)
/*     */     {
/* 243 */       if ((ob.lastrendered != null) && (ob.lastrendered.equals(uri))) {
/* 244 */         ne.rendered = true;
/* 245 */         return null;
/*     */       }
/*     */     }
/* 248 */     return ne.n;
/*     */   }
/*     */   
/*     */   public int getLevel()
/*     */   {
/* 253 */     return this.level.size();
/*     */   }
/*     */   
/*     */   public void removeMapping(String prefix) {
/* 257 */     NameSpaceSymbEntry ob = this.symb.get(prefix);
/*     */     
/* 259 */     if (ob != null) {
/* 260 */       needsClone();
/* 261 */       this.symb.put(prefix, null);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeMappingIfNotRender(String prefix) {
/* 266 */     NameSpaceSymbEntry ob = this.symb.get(prefix);
/*     */     
/* 268 */     if ((ob != null) && (!ob.rendered)) {
/* 269 */       needsClone();
/* 270 */       this.symb.put(prefix, null);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean removeMappingIfRender(String prefix) {
/* 275 */     NameSpaceSymbEntry ob = this.symb.get(prefix);
/*     */     
/* 277 */     if ((ob != null) && (ob.rendered)) {
/* 278 */       needsClone();
/* 279 */       this.symb.put(prefix, null);
/*     */     }
/* 281 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\c14n\implementations\NameSpaceSymbTable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */