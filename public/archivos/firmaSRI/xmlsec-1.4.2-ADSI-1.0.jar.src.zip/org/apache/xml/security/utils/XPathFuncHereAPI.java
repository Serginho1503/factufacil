/*     */ package org.apache.xml.security.utils;
/*     */ 
/*     */ import javax.xml.transform.TransformerException;
/*     */ import org.apache.xml.security.transforms.implementations.FuncHereContext;
/*     */ import org.apache.xml.utils.PrefixResolver;
/*     */ import org.apache.xml.utils.PrefixResolverDefault;
/*     */ import org.apache.xpath.XPath;
/*     */ import org.apache.xpath.objects.XObject;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.ProcessingInstruction;
/*     */ import org.w3c.dom.Text;
/*     */ import org.w3c.dom.traversal.NodeIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XPathFuncHereAPI
/*     */ {
/*     */   public static Node selectSingleNode(Node contextNode, Node xpathnode)
/*     */     throws TransformerException
/*     */   {
/*  70 */     return selectSingleNode(contextNode, xpathnode, contextNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Node selectSingleNode(Node contextNode, Node xpathnode, Node namespaceNode)
/*     */     throws TransformerException
/*     */   {
/*  89 */     NodeIterator nl = selectNodeIterator(contextNode, xpathnode, namespaceNode);
/*     */     
/*     */ 
/*     */ 
/*  93 */     return nl.nextNode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static NodeIterator selectNodeIterator(Node contextNode, Node xpathnode)
/*     */     throws TransformerException
/*     */   {
/* 108 */     return selectNodeIterator(contextNode, xpathnode, contextNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static NodeIterator selectNodeIterator(Node contextNode, Node xpathnode, Node namespaceNode)
/*     */     throws TransformerException
/*     */   {
/* 127 */     XObject list = eval(contextNode, xpathnode, namespaceNode);
/*     */     
/*     */ 
/* 130 */     return list.nodeset();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static NodeList selectNodeList(Node contextNode, Node xpathnode)
/*     */     throws TransformerException
/*     */   {
/* 145 */     return selectNodeList(contextNode, xpathnode, contextNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static NodeList selectNodeList(Node contextNode, Node xpathnode, Node namespaceNode)
/*     */     throws TransformerException
/*     */   {
/* 164 */     XObject list = eval(contextNode, xpathnode, namespaceNode);
/*     */     
/*     */ 
/* 167 */     return list.nodelist();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XObject eval(Node contextNode, Node xpathnode)
/*     */     throws TransformerException
/*     */   {
/* 187 */     return eval(contextNode, xpathnode, contextNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XObject eval(Node contextNode, Node xpathnode, Node namespaceNode)
/*     */     throws TransformerException
/*     */   {
/* 219 */     FuncHereContext xpathSupport = new FuncHereContext(xpathnode);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 225 */     PrefixResolverDefault prefixResolver = new PrefixResolverDefault(namespaceNode.getNodeType() == 9 ? ((Document)namespaceNode).getDocumentElement() : namespaceNode);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 231 */     String str = getStrFromNode(xpathnode);
/*     */     
/*     */ 
/* 234 */     XPath xpath = new XPath(str, null, prefixResolver, 0, null);
/*     */     
/*     */ 
/*     */ 
/* 238 */     int ctxtNode = xpathSupport.getDTMHandleFromNode(contextNode);
/*     */     
/* 240 */     return xpath.execute(xpathSupport, ctxtNode, prefixResolver);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XObject eval(Node contextNode, Node xpathnode, PrefixResolver prefixResolver)
/*     */     throws TransformerException
/*     */   {
/* 268 */     String str = getStrFromNode(xpathnode);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 276 */     XPath xpath = new XPath(str, null, prefixResolver, 0, null);
/*     */     
/*     */ 
/* 279 */     FuncHereContext xpathSupport = new FuncHereContext(xpathnode);
/* 280 */     int ctxtNode = xpathSupport.getDTMHandleFromNode(contextNode);
/*     */     
/* 282 */     return xpath.execute(xpathSupport, ctxtNode, prefixResolver);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String getStrFromNode(Node xpathnode)
/*     */   {
/* 293 */     if (xpathnode.getNodeType() == 3)
/* 294 */       return ((Text)xpathnode).getData();
/* 295 */     if (xpathnode.getNodeType() == 2)
/* 296 */       return ((Attr)xpathnode).getNodeValue();
/* 297 */     if (xpathnode.getNodeType() == 7) {
/* 298 */       return ((ProcessingInstruction)xpathnode).getNodeValue();
/*     */     }
/*     */     
/* 301 */     return "";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\utils\XPathFuncHereAPI.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */