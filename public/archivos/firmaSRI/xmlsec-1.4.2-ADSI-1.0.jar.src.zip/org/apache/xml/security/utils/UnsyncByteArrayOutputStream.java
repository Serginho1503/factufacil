/*    */ package org.apache.xml.security.utils;
/*    */ 
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnsyncByteArrayOutputStream
/*    */   extends OutputStream
/*    */ {
/* 27 */   private static ThreadLocal bufCahce = new ThreadLocal() {
/*    */     protected synchronized Object initialValue() {
/* 29 */       return new byte[' '];
/*    */     }
/*    */   };
/*    */   byte[] buf;
/* 33 */   int size = 8192;
/* 34 */   int pos = 0;
/*    */   
/*    */ 
/* 37 */   public UnsyncByteArrayOutputStream() { this.buf = ((byte[])bufCahce.get()); }
/*    */   
/*    */   public void write(byte[] arg0) {
/* 40 */     int newPos = this.pos + arg0.length;
/* 41 */     if (newPos > this.size) {
/* 42 */       expandSize();
/*    */     }
/* 44 */     System.arraycopy(arg0, 0, this.buf, this.pos, arg0.length);
/* 45 */     this.pos = newPos;
/*    */   }
/*    */   
/*    */   public void write(byte[] arg0, int arg1, int arg2) {
/* 49 */     int newPos = this.pos + arg2;
/* 50 */     if (newPos > this.size) {
/* 51 */       expandSize();
/*    */     }
/* 53 */     System.arraycopy(arg0, arg1, this.buf, this.pos, arg2);
/* 54 */     this.pos = newPos;
/*    */   }
/*    */   
/*    */   public void write(int arg0) {
/* 58 */     if (this.pos >= this.size) {
/* 59 */       expandSize();
/*    */     }
/* 61 */     this.buf[(this.pos++)] = ((byte)arg0);
/*    */   }
/*    */   
/*    */   public byte[] toByteArray() {
/* 65 */     byte[] result = new byte[this.pos];
/* 66 */     System.arraycopy(this.buf, 0, result, 0, this.pos);
/* 67 */     return result;
/*    */   }
/*    */   
/*    */   public void reset()
/*    */   {
/* 72 */     this.pos = 0;
/*    */   }
/*    */   
/*    */   void expandSize()
/*    */   {
/* 77 */     int newSize = this.size << 2;
/* 78 */     byte[] newBuf = new byte[newSize];
/* 79 */     System.arraycopy(this.buf, 0, newBuf, 0, this.pos);
/* 80 */     this.buf = newBuf;
/* 81 */     this.size = newSize;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\utils\UnsyncByteArrayOutputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */