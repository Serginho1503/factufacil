/*     */ package org.apache.xml.security.c14n.implementations;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import org.apache.xml.security.c14n.helper.C14nHelper;
/*     */ import org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Canonicalizer20010315
/*     */   extends CanonicalizerBase
/*     */ {
/*  56 */   boolean firstCall = true;
/*  57 */   final SortedSet result = new TreeSet(COMPARE);
/*     */   static final String XMLNS_URI = "http://www.w3.org/2000/xmlns/";
/*     */   static final String XML_LANG_URI = "http://www.w3.org/XML/1998/namespace";
/*     */   
/*  61 */   static class XmlAttrStack { int currentLevel = 0;
/*  62 */     int lastlevel = 0;
/*     */     XmlsStackElement cur;
/*     */     
/*     */     static class XmlsStackElement { int level;
/*  66 */       boolean rendered = false;
/*  67 */       List nodes = new ArrayList(); }
/*     */     
/*  69 */     List levels = new ArrayList();
/*     */     
/*  71 */     void push(int level) { this.currentLevel = level;
/*  72 */       if (this.currentLevel == -1)
/*  73 */         return;
/*  74 */       this.cur = null;
/*  75 */       while (this.lastlevel >= this.currentLevel) {
/*  76 */         this.levels.remove(this.levels.size() - 1);
/*  77 */         if (this.levels.size() == 0) {
/*  78 */           this.lastlevel = 0;
/*  79 */           return;
/*     */         }
/*  81 */         this.lastlevel = ((XmlsStackElement)this.levels.get(this.levels.size() - 1)).level;
/*     */       }
/*     */     }
/*     */     
/*  85 */     void addXmlnsAttr(Attr n) { if (this.cur == null) {
/*  86 */         this.cur = new XmlsStackElement();
/*  87 */         this.cur.level = this.currentLevel;
/*  88 */         this.levels.add(this.cur);
/*  89 */         this.lastlevel = this.currentLevel;
/*     */       }
/*  91 */       this.cur.nodes.add(n);
/*     */     }
/*     */     
/*  94 */     void getXmlnsAttr(Collection col) { int size = this.levels.size() - 1;
/*  95 */       if (this.cur == null) {
/*  96 */         this.cur = new XmlsStackElement();
/*  97 */         this.cur.level = this.currentLevel;
/*  98 */         this.lastlevel = this.currentLevel;
/*  99 */         this.levels.add(this.cur);
/*     */       }
/* 101 */       boolean parentRendered = false;
/* 102 */       XmlsStackElement e = null;
/* 103 */       if (size == -1) {
/* 104 */         parentRendered = true;
/*     */       } else {
/* 106 */         e = (XmlsStackElement)this.levels.get(size);
/* 107 */         if ((e.rendered) && (e.level + 1 == this.currentLevel)) {
/* 108 */           parentRendered = true;
/*     */         }
/*     */       }
/* 111 */       if (parentRendered) {
/* 112 */         col.addAll(this.cur.nodes);
/* 113 */         this.cur.rendered = true;
/* 114 */         return;
/*     */       }
/*     */       
/* 117 */       Map loa = new HashMap();
/* 118 */       for (; size >= 0; size--) {
/* 119 */         e = (XmlsStackElement)this.levels.get(size);
/* 120 */         Iterator it = e.nodes.iterator();
/* 121 */         while (it.hasNext()) {
/* 122 */           Attr n = (Attr)it.next();
/* 123 */           if (!loa.containsKey(n.getName())) {
/* 124 */             loa.put(n.getName(), n);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 132 */       this.cur.rendered = true;
/* 133 */       col.addAll(loa.values());
/*     */     }
/*     */   }
/*     */   
/* 137 */   XmlAttrStack xmlattrStack = new XmlAttrStack();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Canonicalizer20010315(boolean includeComments)
/*     */   {
/* 144 */     super(includeComments);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Iterator handleAttributesSubtree(Element E, NameSpaceSymbTable ns)
/*     */     throws CanonicalizationException
/*     */   {
/* 163 */     if ((!E.hasAttributes()) && (!this.firstCall)) {
/* 164 */       return null;
/*     */     }
/*     */     
/* 167 */     SortedSet result = this.result;
/* 168 */     result.clear();
/* 169 */     NamedNodeMap attrs = E.getAttributes();
/* 170 */     int attrsLength = attrs.getLength();
/*     */     
/* 172 */     for (int i = 0; i < attrsLength; i++) {
/* 173 */       Attr N = (Attr)attrs.item(i);
/* 174 */       String NUri = N.getNamespaceURI();
/*     */       
/* 176 */       if ("http://www.w3.org/2000/xmlns/" != NUri)
/*     */       {
/* 178 */         result.add(N);
/*     */       }
/*     */       else
/*     */       {
/* 182 */         String NName = N.getLocalName();
/* 183 */         String NValue = N.getValue();
/* 184 */         if ((!"xml".equals(NName)) || (!"http://www.w3.org/XML/1998/namespace".equals(NValue)))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 190 */           Node n = ns.addMappingAndRender(NName, NValue, N);
/*     */           
/* 192 */           if (n != null)
/*     */           {
/* 194 */             result.add(n);
/* 195 */             if (C14nHelper.namespaceIsRelative(N)) {
/* 196 */               Object[] exArgs = { E.getTagName(), NName, N.getNodeValue() };
/* 197 */               throw new CanonicalizationException("c14n.Canonicalizer.RelativeNamespace", exArgs);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 203 */     if (this.firstCall)
/*     */     {
/*     */ 
/* 206 */       ns.getUnrenderedNodes(result);
/*     */       
/* 208 */       this.xmlattrStack.getXmlnsAttr(result);
/* 209 */       this.firstCall = false;
/*     */     }
/*     */     
/* 212 */     return result.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Iterator handleAttributes(Element E, NameSpaceSymbTable ns)
/*     */     throws CanonicalizationException
/*     */   {
/* 229 */     this.xmlattrStack.push(ns.getLevel());
/* 230 */     boolean isRealVisible = isVisibleDO(E, ns.getLevel()) == 1;
/* 231 */     NamedNodeMap attrs = null;
/* 232 */     int attrsLength = 0;
/* 233 */     if (E.hasAttributes()) {
/* 234 */       attrs = E.getAttributes();
/* 235 */       attrsLength = attrs.getLength();
/*     */     }
/*     */     
/*     */ 
/* 239 */     SortedSet result = this.result;
/* 240 */     result.clear();
/*     */     
/* 242 */     for (int i = 0; i < attrsLength; i++) {
/* 243 */       Attr N = (Attr)attrs.item(i);
/* 244 */       String NUri = N.getNamespaceURI();
/*     */       
/* 246 */       if ("http://www.w3.org/2000/xmlns/" != NUri)
/*     */       {
/* 248 */         if ("http://www.w3.org/XML/1998/namespace" == NUri) {
/* 249 */           this.xmlattrStack.addXmlnsAttr(N);
/* 250 */         } else if (isRealVisible)
/*     */         {
/* 252 */           result.add(N);
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 258 */         String NName = N.getLocalName();
/* 259 */         String NValue = N.getValue();
/* 260 */         if ((!"xml".equals(NName)) || (!"http://www.w3.org/XML/1998/namespace".equals(NValue)))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 269 */           if (isVisible(N)) {
/* 270 */             if ((isRealVisible) || (!ns.removeMappingIfRender(NName)))
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/* 275 */               Node n = ns.addMappingAndRender(NName, NValue, N);
/* 276 */               if (n != null) {
/* 277 */                 result.add(n);
/* 278 */                 if (C14nHelper.namespaceIsRelative(N)) {
/* 279 */                   Object[] exArgs = { E.getTagName(), NName, N.getNodeValue() };
/* 280 */                   throw new CanonicalizationException("c14n.Canonicalizer.RelativeNamespace", exArgs);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/* 285 */           else if ((isRealVisible) && (NName != "xmlns")) {
/* 286 */             ns.removeMapping(NName);
/*     */           } else
/* 288 */             ns.addMapping(NName, NValue, N);
/*     */         }
/*     */       }
/*     */     }
/* 292 */     if (isRealVisible)
/*     */     {
/* 294 */       Attr xmlns = E.getAttributeNodeNS("http://www.w3.org/2000/xmlns/", "xmlns");
/* 295 */       Node n = null;
/* 296 */       if (xmlns == null)
/*     */       {
/* 298 */         n = ns.getMapping("xmlns");
/* 299 */       } else if (!isVisible(xmlns))
/*     */       {
/*     */ 
/* 302 */         n = ns.addMappingAndRender("xmlns", "", nullNode);
/*     */       }
/*     */       
/* 305 */       if (n != null) {
/* 306 */         result.add(n);
/*     */       }
/*     */       
/*     */ 
/* 310 */       this.xmlattrStack.getXmlnsAttr(result);
/* 311 */       ns.getUnrenderedNodes(result);
/*     */     }
/*     */     
/*     */ 
/* 315 */     return result.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalizeXPathNodeSet(Set xpathNodeSet, String inclusiveNamespaces)
/*     */     throws CanonicalizationException
/*     */   {
/* 329 */     throw new CanonicalizationException("c14n.Canonicalizer.UnsupportedOperation");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalizeSubTree(Node rootNode, String inclusiveNamespaces)
/*     */     throws CanonicalizationException
/*     */   {
/* 345 */     throw new CanonicalizationException("c14n.Canonicalizer.UnsupportedOperation");
/*     */   }
/*     */   
/*     */   void circumventBugIfNeeded(XMLSignatureInput input) throws CanonicalizationException, ParserConfigurationException, IOException, SAXException {
/* 349 */     if (!input.isNeedsToBeExpanded())
/* 350 */       return;
/* 351 */     Document doc = null;
/* 352 */     if (input.getSubNode() != null) {
/* 353 */       doc = XMLUtils.getOwnerDocument(input.getSubNode());
/*     */     } else {
/* 355 */       doc = XMLUtils.getOwnerDocument(input.getNodeSet());
/*     */     }
/* 357 */     XMLUtils.circumventBug2650(doc);
/*     */   }
/*     */   
/*     */   void handleParent(Element e, NameSpaceSymbTable ns)
/*     */   {
/* 362 */     if (!e.hasAttributes()) {
/* 363 */       return;
/*     */     }
/* 365 */     this.xmlattrStack.push(-1);
/* 366 */     NamedNodeMap attrs = e.getAttributes();
/* 367 */     int attrsLength = attrs.getLength();
/* 368 */     for (int i = 0; i < attrsLength; i++) {
/* 369 */       Attr N = (Attr)attrs.item(i);
/* 370 */       if ("http://www.w3.org/2000/xmlns/" != N.getNamespaceURI())
/*     */       {
/* 372 */         if ("http://www.w3.org/XML/1998/namespace" == N.getNamespaceURI()) {
/* 373 */           this.xmlattrStack.addXmlnsAttr(N);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 378 */         String NName = N.getLocalName();
/* 379 */         String NValue = N.getNodeValue();
/* 380 */         if ((!"xml".equals(NName)) || (!"http://www.w3.org/XML/1998/namespace".equals(NValue)))
/*     */         {
/*     */ 
/*     */ 
/* 384 */           ns.addMapping(NName, NValue, N);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\c14n\implementations\Canonicalizer20010315.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */