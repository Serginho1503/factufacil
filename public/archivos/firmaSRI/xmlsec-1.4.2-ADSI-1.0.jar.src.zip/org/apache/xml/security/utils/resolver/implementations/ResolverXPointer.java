/*     */ package org.apache.xml.security.utils.resolver.implementations;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import org.apache.xml.security.utils.IdResolver;
/*     */ import org.apache.xml.security.utils.resolver.ResourceResolverException;
/*     */ import org.apache.xml.security.utils.resolver.ResourceResolverSpi;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResolverXPointer
/*     */   extends ResourceResolverSpi
/*     */ {
/*  48 */   static Log log = LogFactory.getLog(ResolverXPointer.class.getName());
/*     */   private static final String XP = "#xpointer(id(";
/*     */   
/*     */   public boolean engineIsThreadSafe()
/*     */   {
/*  53 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput engineResolve(Attr uri, String BaseURI)
/*     */     throws ResourceResolverException
/*     */   {
/*  61 */     Node resultNode = null;
/*  62 */     Document doc = uri.getOwnerElement().getOwnerDocument();
/*     */     
/*  64 */     String uriStr = uri.getNodeValue();
/*  65 */     if (isXPointerSlash(uriStr)) {
/*  66 */       resultNode = doc;
/*     */     }
/*  68 */     else if (isXPointerId(uriStr)) {
/*  69 */       String id = getXPointerId(uriStr);
/*  70 */       resultNode = IdResolver.getElementById(doc, id);
/*     */       
/*     */ 
/*     */ 
/*  74 */       if (resultNode == null) {
/*  75 */         Object[] exArgs = { id };
/*     */         
/*  77 */         throw new ResourceResolverException("signature.Verification.MissingID", exArgs, uri, BaseURI);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  88 */     XMLSignatureInput result = new XMLSignatureInput(resultNode);
/*     */     
/*  90 */     result.setMIMEType("text/xml");
/*  91 */     if ((BaseURI != null) && (BaseURI.length() > 0)) {
/*  92 */       result.setSourceURI(BaseURI.concat(uri.getNodeValue()));
/*     */     } else {
/*  94 */       result.setSourceURI(uri.getNodeValue());
/*     */     }
/*     */     
/*  97 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean engineCanResolve(Attr uri, String BaseURI)
/*     */   {
/* 105 */     if (uri == null) {
/* 106 */       return false;
/*     */     }
/* 108 */     String uriStr = uri.getNodeValue();
/* 109 */     if ((isXPointerSlash(uriStr)) || (isXPointerId(uriStr))) {
/* 110 */       return true;
/*     */     }
/*     */     
/* 113 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isXPointerSlash(String uri)
/*     */   {
/* 124 */     if (uri.equals("#xpointer(/)")) {
/* 125 */       return true;
/*     */     }
/*     */     
/* 128 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 133 */   private static final int XP_LENGTH = "#xpointer(id(".length();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isXPointerId(String uri)
/*     */   {
/* 144 */     if ((uri.startsWith("#xpointer(id(")) && (uri.endsWith("))")))
/*     */     {
/* 146 */       String idPlusDelim = uri.substring(XP_LENGTH, uri.length() - 2);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 151 */       int idLen = idPlusDelim.length() - 1;
/* 152 */       if (((idPlusDelim.charAt(0) == '"') && (idPlusDelim.charAt(idLen) == '"')) || ((idPlusDelim.charAt(0) == '\'') && (idPlusDelim.charAt(idLen) == '\'')))
/*     */       {
/*     */ 
/*     */ 
/* 156 */         if (log.isDebugEnabled()) {
/* 157 */           log.debug("Id=" + idPlusDelim.substring(1, idLen));
/*     */         }
/*     */         
/* 160 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 164 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String getXPointerId(String uri)
/*     */   {
/* 176 */     if ((uri.startsWith("#xpointer(id(")) && (uri.endsWith("))")))
/*     */     {
/* 178 */       String idPlusDelim = uri.substring(XP_LENGTH, uri.length() - 2);
/*     */       
/* 180 */       int idLen = idPlusDelim.length() - 1;
/* 181 */       if (((idPlusDelim.charAt(0) == '"') && (idPlusDelim.charAt(idLen) == '"')) || ((idPlusDelim.charAt(0) == '\'') && (idPlusDelim.charAt(idLen) == '\'')))
/*     */       {
/*     */ 
/*     */ 
/* 185 */         return idPlusDelim.substring(1, idLen);
/*     */       }
/*     */     }
/*     */     
/* 189 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\utils\resolver\implementations\ResolverXPointer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */