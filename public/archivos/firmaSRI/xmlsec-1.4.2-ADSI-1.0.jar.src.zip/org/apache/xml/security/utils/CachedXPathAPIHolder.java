/*    */ package org.apache.xml.security.utils;
/*    */ 
/*    */ import org.apache.xpath.CachedXPathAPI;
/*    */ import org.apache.xpath.XPathContext;
/*    */ import org.w3c.dom.Document;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CachedXPathAPIHolder
/*    */ {
/* 27 */   static ThreadLocal local = new ThreadLocal();
/* 28 */   static ThreadLocal localDoc = new ThreadLocal();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void setDoc(Document doc)
/*    */   {
/* 35 */     if (localDoc.get() != doc) {
/* 36 */       CachedXPathAPI cx = (CachedXPathAPI)local.get();
/* 37 */       if (cx == null) {
/* 38 */         cx = new CachedXPathAPI();
/* 39 */         local.set(cx);
/* 40 */         localDoc.set(doc);
/* 41 */         return;
/*    */       }
/*    */       
/* 44 */       cx.getXPathContext().reset();
/* 45 */       localDoc.set(doc);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static CachedXPathAPI getCachedXPathAPI()
/*    */   {
/* 53 */     CachedXPathAPI cx = (CachedXPathAPI)local.get();
/* 54 */     if (cx == null) {
/* 55 */       cx = new CachedXPathAPI();
/* 56 */       local.set(cx);
/* 57 */       localDoc.set(null);
/*    */     }
/* 59 */     return cx;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\utils\CachedXPathAPIHolder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */