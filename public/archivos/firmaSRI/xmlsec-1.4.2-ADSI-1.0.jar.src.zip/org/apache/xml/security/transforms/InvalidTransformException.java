/*    */ package org.apache.xml.security.transforms;
/*    */ 
/*    */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidTransformException
/*    */   extends XMLSecurityException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public InvalidTransformException() {}
/*    */   
/*    */   public InvalidTransformException(String _msgId)
/*    */   {
/* 50 */     super(_msgId);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InvalidTransformException(String _msgId, Object[] exArgs)
/*    */   {
/* 60 */     super(_msgId, exArgs);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InvalidTransformException(String _msgId, Exception _originalException)
/*    */   {
/* 70 */     super(_msgId, _originalException);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InvalidTransformException(String _msgId, Object[] exArgs, Exception _originalException)
/*    */   {
/* 82 */     super(_msgId, exArgs, _originalException);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\transforms\InvalidTransformException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */