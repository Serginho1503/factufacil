/*     */ package org.apache.xml.security.transforms.implementations;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import org.apache.xml.security.transforms.Transform;
/*     */ import org.apache.xml.security.transforms.TransformSpi;
/*     */ import org.apache.xml.security.transforms.TransformationException;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransformBase64Decode
/*     */   extends TransformSpi
/*     */ {
/*     */   public static final String implementedTransformURI = "http://www.w3.org/2000/09/xmldsig#base64";
/*     */   
/*     */   protected String engineGetURI()
/*     */   {
/*  81 */     return "http://www.w3.org/2000/09/xmldsig#base64";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, Transform _transformObject)
/*     */     throws IOException, CanonicalizationException, TransformationException
/*     */   {
/*  98 */     return enginePerformTransform(input, null, _transformObject);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, java.io.OutputStream os, Transform _transformObject)
/*     */     throws IOException, CanonicalizationException, TransformationException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: invokevirtual 4	org/apache/xml/security/signature/XMLSignatureInput:isElement	()Z
/*     */     //   4: ifeq +106 -> 110
/*     */     //   7: aload_1
/*     */     //   8: invokevirtual 5	org/apache/xml/security/signature/XMLSignatureInput:getSubNode	()Lorg/w3c/dom/Node;
/*     */     //   11: astore 4
/*     */     //   13: aload_1
/*     */     //   14: invokevirtual 5	org/apache/xml/security/signature/XMLSignatureInput:getSubNode	()Lorg/w3c/dom/Node;
/*     */     //   17: invokeinterface 6 1 0
/*     */     //   22: iconst_3
/*     */     //   23: if_icmpne +12 -> 35
/*     */     //   26: aload 4
/*     */     //   28: invokeinterface 7 1 0
/*     */     //   33: astore 4
/*     */     //   35: new 8	java/lang/StringBuffer
/*     */     //   38: dup
/*     */     //   39: invokespecial 9	java/lang/StringBuffer:<init>	()V
/*     */     //   42: astore 5
/*     */     //   44: aload_0
/*     */     //   45: aload 4
/*     */     //   47: checkcast 10	org/w3c/dom/Element
/*     */     //   50: aload 5
/*     */     //   52: invokevirtual 11	org/apache/xml/security/transforms/implementations/TransformBase64Decode:traverseElement	(Lorg/w3c/dom/Element;Ljava/lang/StringBuffer;)V
/*     */     //   55: aload_2
/*     */     //   56: ifnonnull +23 -> 79
/*     */     //   59: aload 5
/*     */     //   61: invokevirtual 12	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*     */     //   64: invokestatic 13	org/apache/xml/security/utils/Base64:decode	(Ljava/lang/String;)[B
/*     */     //   67: astore 6
/*     */     //   69: new 14	org/apache/xml/security/signature/XMLSignatureInput
/*     */     //   72: dup
/*     */     //   73: aload 6
/*     */     //   75: invokespecial 15	org/apache/xml/security/signature/XMLSignatureInput:<init>	([B)V
/*     */     //   78: areturn
/*     */     //   79: aload 5
/*     */     //   81: invokevirtual 12	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*     */     //   84: aload_2
/*     */     //   85: invokestatic 16	org/apache/xml/security/utils/Base64:decode	(Ljava/lang/String;Ljava/io/OutputStream;)V
/*     */     //   88: new 14	org/apache/xml/security/signature/XMLSignatureInput
/*     */     //   91: dup
/*     */     //   92: aconst_null
/*     */     //   93: checkcast 17	[B
/*     */     //   96: invokespecial 15	org/apache/xml/security/signature/XMLSignatureInput:<init>	([B)V
/*     */     //   99: astore 6
/*     */     //   101: aload 6
/*     */     //   103: aload_2
/*     */     //   104: invokevirtual 18	org/apache/xml/security/signature/XMLSignatureInput:setOutputStream	(Ljava/io/OutputStream;)V
/*     */     //   107: aload 6
/*     */     //   109: areturn
/*     */     //   110: aload_1
/*     */     //   111: invokevirtual 19	org/apache/xml/security/signature/XMLSignatureInput:isOctetStream	()Z
/*     */     //   114: ifne +10 -> 124
/*     */     //   117: aload_1
/*     */     //   118: invokevirtual 20	org/apache/xml/security/signature/XMLSignatureInput:isNodeSet	()Z
/*     */     //   121: ifeq +92 -> 213
/*     */     //   124: aload_2
/*     */     //   125: ifnonnull +26 -> 151
/*     */     //   128: aload_1
/*     */     //   129: invokevirtual 21	org/apache/xml/security/signature/XMLSignatureInput:getBytes	()[B
/*     */     //   132: astore 4
/*     */     //   134: aload 4
/*     */     //   136: invokestatic 22	org/apache/xml/security/utils/Base64:decode	([B)[B
/*     */     //   139: astore 5
/*     */     //   141: new 14	org/apache/xml/security/signature/XMLSignatureInput
/*     */     //   144: dup
/*     */     //   145: aload 5
/*     */     //   147: invokespecial 15	org/apache/xml/security/signature/XMLSignatureInput:<init>	([B)V
/*     */     //   150: areturn
/*     */     //   151: aload_1
/*     */     //   152: invokevirtual 23	org/apache/xml/security/signature/XMLSignatureInput:isByteArray	()Z
/*     */     //   155: ifne +10 -> 165
/*     */     //   158: aload_1
/*     */     //   159: invokevirtual 20	org/apache/xml/security/signature/XMLSignatureInput:isNodeSet	()Z
/*     */     //   162: ifeq +14 -> 176
/*     */     //   165: aload_1
/*     */     //   166: invokevirtual 21	org/apache/xml/security/signature/XMLSignatureInput:getBytes	()[B
/*     */     //   169: aload_2
/*     */     //   170: invokestatic 24	org/apache/xml/security/utils/Base64:decode	([BLjava/io/OutputStream;)V
/*     */     //   173: goto +18 -> 191
/*     */     //   176: new 25	java/io/BufferedInputStream
/*     */     //   179: dup
/*     */     //   180: aload_1
/*     */     //   181: invokevirtual 26	org/apache/xml/security/signature/XMLSignatureInput:getOctetStreamReal	()Ljava/io/InputStream;
/*     */     //   184: invokespecial 27	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
/*     */     //   187: aload_2
/*     */     //   188: invokestatic 28	org/apache/xml/security/utils/Base64:decode	(Ljava/io/InputStream;Ljava/io/OutputStream;)V
/*     */     //   191: new 14	org/apache/xml/security/signature/XMLSignatureInput
/*     */     //   194: dup
/*     */     //   195: aconst_null
/*     */     //   196: checkcast 17	[B
/*     */     //   199: invokespecial 15	org/apache/xml/security/signature/XMLSignatureInput:<init>	([B)V
/*     */     //   202: astore 4
/*     */     //   204: aload 4
/*     */     //   206: aload_2
/*     */     //   207: invokevirtual 18	org/apache/xml/security/signature/XMLSignatureInput:setOutputStream	(Ljava/io/OutputStream;)V
/*     */     //   210: aload 4
/*     */     //   212: areturn
/*     */     //   213: invokestatic 29	javax/xml/parsers/DocumentBuilderFactory:newInstance	()Ljavax/xml/parsers/DocumentBuilderFactory;
/*     */     //   216: invokevirtual 30	javax/xml/parsers/DocumentBuilderFactory:newDocumentBuilder	()Ljavax/xml/parsers/DocumentBuilder;
/*     */     //   219: aload_1
/*     */     //   220: invokevirtual 31	org/apache/xml/security/signature/XMLSignatureInput:getOctetStream	()Ljava/io/InputStream;
/*     */     //   223: invokevirtual 32	javax/xml/parsers/DocumentBuilder:parse	(Ljava/io/InputStream;)Lorg/w3c/dom/Document;
/*     */     //   226: astore 4
/*     */     //   228: aload 4
/*     */     //   230: invokeinterface 33 1 0
/*     */     //   235: astore 5
/*     */     //   237: new 8	java/lang/StringBuffer
/*     */     //   240: dup
/*     */     //   241: invokespecial 9	java/lang/StringBuffer:<init>	()V
/*     */     //   244: astore 6
/*     */     //   246: aload_0
/*     */     //   247: aload 5
/*     */     //   249: aload 6
/*     */     //   251: invokevirtual 11	org/apache/xml/security/transforms/implementations/TransformBase64Decode:traverseElement	(Lorg/w3c/dom/Element;Ljava/lang/StringBuffer;)V
/*     */     //   254: aload 6
/*     */     //   256: invokevirtual 12	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*     */     //   259: invokestatic 13	org/apache/xml/security/utils/Base64:decode	(Ljava/lang/String;)[B
/*     */     //   262: astore 7
/*     */     //   264: new 14	org/apache/xml/security/signature/XMLSignatureInput
/*     */     //   267: dup
/*     */     //   268: aload 7
/*     */     //   270: invokespecial 15	org/apache/xml/security/signature/XMLSignatureInput:<init>	([B)V
/*     */     //   273: areturn
/*     */     //   274: astore 4
/*     */     //   276: new 35	org/apache/xml/security/transforms/TransformationException
/*     */     //   279: dup
/*     */     //   280: ldc 36
/*     */     //   282: aload 4
/*     */     //   284: invokespecial 37	org/apache/xml/security/transforms/TransformationException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
/*     */     //   287: athrow
/*     */     //   288: astore 4
/*     */     //   290: new 35	org/apache/xml/security/transforms/TransformationException
/*     */     //   293: dup
/*     */     //   294: ldc 39
/*     */     //   296: aload 4
/*     */     //   298: invokespecial 37	org/apache/xml/security/transforms/TransformationException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
/*     */     //   301: athrow
/*     */     //   302: astore 4
/*     */     //   304: new 35	org/apache/xml/security/transforms/TransformationException
/*     */     //   307: dup
/*     */     //   308: ldc 41
/*     */     //   310: aload 4
/*     */     //   312: invokespecial 37	org/apache/xml/security/transforms/TransformationException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
/*     */     //   315: athrow
/*     */     // Line number table:
/*     */     //   Java source line #106	-> byte code offset #0
/*     */     //   Java source line #107	-> byte code offset #7
/*     */     //   Java source line #108	-> byte code offset #13
/*     */     //   Java source line #109	-> byte code offset #26
/*     */     //   Java source line #111	-> byte code offset #35
/*     */     //   Java source line #112	-> byte code offset #44
/*     */     //   Java source line #113	-> byte code offset #55
/*     */     //   Java source line #114	-> byte code offset #59
/*     */     //   Java source line #115	-> byte code offset #69
/*     */     //   Java source line #117	-> byte code offset #79
/*     */     //   Java source line #118	-> byte code offset #88
/*     */     //   Java source line #119	-> byte code offset #101
/*     */     //   Java source line #120	-> byte code offset #107
/*     */     //   Java source line #123	-> byte code offset #110
/*     */     //   Java source line #126	-> byte code offset #124
/*     */     //   Java source line #127	-> byte code offset #128
/*     */     //   Java source line #128	-> byte code offset #134
/*     */     //   Java source line #129	-> byte code offset #141
/*     */     //   Java source line #131	-> byte code offset #151
/*     */     //   Java source line #132	-> byte code offset #165
/*     */     //   Java source line #134	-> byte code offset #176
/*     */     //   Java source line #137	-> byte code offset #191
/*     */     //   Java source line #138	-> byte code offset #204
/*     */     //   Java source line #139	-> byte code offset #210
/*     */     //   Java source line #147	-> byte code offset #213
/*     */     //   Java source line #151	-> byte code offset #228
/*     */     //   Java source line #152	-> byte code offset #237
/*     */     //   Java source line #153	-> byte code offset #246
/*     */     //   Java source line #154	-> byte code offset #254
/*     */     //   Java source line #156	-> byte code offset #264
/*     */     //   Java source line #157	-> byte code offset #274
/*     */     //   Java source line #158	-> byte code offset #276
/*     */     //   Java source line #159	-> byte code offset #288
/*     */     //   Java source line #160	-> byte code offset #290
/*     */     //   Java source line #162	-> byte code offset #302
/*     */     //   Java source line #163	-> byte code offset #304
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	316	0	this	TransformBase64Decode
/*     */     //   0	316	1	input	XMLSignatureInput
/*     */     //   0	316	2	os	java.io.OutputStream
/*     */     //   0	316	3	_transformObject	Transform
/*     */     //   11	35	4	el	Node
/*     */     //   132	3	4	base64Bytes	byte[]
/*     */     //   202	9	4	output	XMLSignatureInput
/*     */     //   226	3	4	doc	org.w3c.dom.Document
/*     */     //   274	9	4	e	javax.xml.parsers.ParserConfigurationException
/*     */     //   288	9	4	e	org.xml.sax.SAXException
/*     */     //   302	9	4	e	org.apache.xml.security.exceptions.Base64DecodingException
/*     */     //   42	38	5	sb	StringBuffer
/*     */     //   139	7	5	decodedBytes	byte[]
/*     */     //   235	13	5	rootNode	Element
/*     */     //   67	7	6	decodedBytes	byte[]
/*     */     //   99	9	6	output	XMLSignatureInput
/*     */     //   244	11	6	sb	StringBuffer
/*     */     //   262	7	7	decodedBytes	byte[]
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   213	273	274	javax/xml/parsers/ParserConfigurationException
/*     */     //   213	273	288	org/xml/sax/SAXException
/*     */     //   0	78	302	org/apache/xml/security/exceptions/Base64DecodingException
/*     */     //   79	109	302	org/apache/xml/security/exceptions/Base64DecodingException
/*     */     //   110	150	302	org/apache/xml/security/exceptions/Base64DecodingException
/*     */     //   151	212	302	org/apache/xml/security/exceptions/Base64DecodingException
/*     */     //   213	273	302	org/apache/xml/security/exceptions/Base64DecodingException
/*     */     //   274	302	302	org/apache/xml/security/exceptions/Base64DecodingException
/*     */   }
/*     */   
/*     */   void traverseElement(Element node, StringBuffer sb)
/*     */   {
/* 168 */     Node sibling = node.getFirstChild();
/* 169 */     while (sibling != null) {
/* 170 */       switch (sibling.getNodeType()) {
/*     */       case 1: 
/* 172 */         traverseElement((Element)sibling, sb);
/* 173 */         break;
/*     */       case 3: 
/* 175 */         sb.append(((Text)sibling).getData());
/*     */       }
/* 177 */       sibling = sibling.getNextSibling();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\transforms\implementations\TransformBase64Decode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */