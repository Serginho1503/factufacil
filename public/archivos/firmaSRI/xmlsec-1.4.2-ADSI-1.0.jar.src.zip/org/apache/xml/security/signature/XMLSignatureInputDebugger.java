/*     */ package org.apache.xml.security.signature;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.apache.xml.security.c14n.helper.AttrCompare;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Comment;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.ProcessingInstruction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLSignatureInputDebugger
/*     */ {
/*     */   private Set _xpathNodeSet;
/*     */   private Set _inclusiveNamespaces;
/*  51 */   private Document _doc = null;
/*     */   
/*     */ 
/*  54 */   private Writer _writer = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String HTMLPrefix = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n<html>\n<head>\n<title>Caninical XML node set</title>\n<style type=\"text/css\">\n<!-- \n.INCLUDED { \n   color: #000000; \n   background-color: \n   #FFFFFF; \n   font-weight: bold; } \n.EXCLUDED { \n   color: #666666; \n   background-color: \n   #999999; } \n.INCLUDEDINCLUSIVENAMESPACE { \n   color: #0000FF; \n   background-color: #FFFFFF; \n   font-weight: bold; \n   font-style: italic; } \n.EXCLUDEDINCLUSIVENAMESPACE { \n   color: #0000FF; \n   background-color: #999999; \n   font-style: italic; } \n--> \n</style> \n</head>\n<body bgcolor=\"#999999\">\n<h1>Explanation of the output</h1>\n<p>The following text contains the nodeset of the given Reference before it is canonicalized. There exist four different styles to indicate how a given node is treated.</p>\n<ul>\n<li class=\"INCLUDED\">A node which is in the node set is labeled using the INCLUDED style.</li>\n<li class=\"EXCLUDED\">A node which is <em>NOT</em> in the node set is labeled EXCLUDED style.</li>\n<li class=\"INCLUDEDINCLUSIVENAMESPACE\">A namespace which is in the node set AND in the InclusiveNamespaces PrefixList is labeled using the INCLUDEDINCLUSIVENAMESPACE style.</li>\n<li class=\"EXCLUDEDINCLUSIVENAMESPACE\">A namespace which is in NOT the node set AND in the InclusiveNamespaces PrefixList is labeled using the INCLUDEDINCLUSIVENAMESPACE style.</li>\n</ul>\n<h1>Output</h1>\n<pre>\n";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String HTMLSuffix = "</pre></body></html>";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String HTMLExcludePrefix = "<span class=\"EXCLUDED\">";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String HTMLExcludeSuffix = "</span>";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String HTMLIncludePrefix = "<span class=\"INCLUDED\">";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String HTMLIncludeSuffix = "</span>";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String HTMLIncludedInclusiveNamespacePrefix = "<span class=\"INCLUDEDINCLUSIVENAMESPACE\">";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String HTMLIncludedInclusiveNamespaceSuffix = "</span>";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String HTMLExcludedInclusiveNamespacePrefix = "<span class=\"EXCLUDEDINCLUSIVENAMESPACE\">";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String HTMLExcludedInclusiveNamespaceSuffix = "</span>";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int NODE_BEFORE_DOCUMENT_ELEMENT = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int NODE_NOT_BEFORE_OR_AFTER_DOCUMENT_ELEMENT = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int NODE_AFTER_DOCUMENT_ELEMENT = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 129 */   static final AttrCompare ATTR_COMPARE = new AttrCompare();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private XMLSignatureInputDebugger() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInputDebugger(XMLSignatureInput xmlSignatureInput)
/*     */   {
/* 144 */     if (!xmlSignatureInput.isNodeSet()) {
/* 145 */       this._xpathNodeSet = null;
/*     */     } else {
/* 147 */       this._xpathNodeSet = xmlSignatureInput._inputNodeSet;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInputDebugger(XMLSignatureInput xmlSignatureInput, Set inclusiveNamespace)
/*     */   {
/* 160 */     this(xmlSignatureInput);
/*     */     
/* 162 */     this._inclusiveNamespaces = inclusiveNamespace;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHTMLRepresentation()
/*     */     throws XMLSignatureException
/*     */   {
/* 173 */     if ((this._xpathNodeSet == null) || (this._xpathNodeSet.size() == 0)) {
/* 174 */       return "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n<html>\n<head>\n<title>Caninical XML node set</title>\n<style type=\"text/css\">\n<!-- \n.INCLUDED { \n   color: #000000; \n   background-color: \n   #FFFFFF; \n   font-weight: bold; } \n.EXCLUDED { \n   color: #666666; \n   background-color: \n   #999999; } \n.INCLUDEDINCLUSIVENAMESPACE { \n   color: #0000FF; \n   background-color: #FFFFFF; \n   font-weight: bold; \n   font-style: italic; } \n.EXCLUDEDINCLUSIVENAMESPACE { \n   color: #0000FF; \n   background-color: #999999; \n   font-style: italic; } \n--> \n</style> \n</head>\n<body bgcolor=\"#999999\">\n<h1>Explanation of the output</h1>\n<p>The following text contains the nodeset of the given Reference before it is canonicalized. There exist four different styles to indicate how a given node is treated.</p>\n<ul>\n<li class=\"INCLUDED\">A node which is in the node set is labeled using the INCLUDED style.</li>\n<li class=\"EXCLUDED\">A node which is <em>NOT</em> in the node set is labeled EXCLUDED style.</li>\n<li class=\"INCLUDEDINCLUSIVENAMESPACE\">A namespace which is in the node set AND in the InclusiveNamespaces PrefixList is labeled using the INCLUDEDINCLUSIVENAMESPACE style.</li>\n<li class=\"EXCLUDEDINCLUSIVENAMESPACE\">A namespace which is in NOT the node set AND in the InclusiveNamespaces PrefixList is labeled using the INCLUDEDINCLUSIVENAMESPACE style.</li>\n</ul>\n<h1>Output</h1>\n<pre>\n<blink>no node set, sorry</blink></pre></body></html>";
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 181 */     Node n = (Node)this._xpathNodeSet.iterator().next();
/*     */     
/* 183 */     this._doc = XMLUtils.getOwnerDocument(n);
/*     */     
/*     */     try
/*     */     {
/* 187 */       this._writer = new StringWriter();
/*     */       
/* 189 */       canonicalizeXPathNodeSet(this._doc);
/* 190 */       this._writer.close();
/*     */       
/* 192 */       return this._writer.toString();
/*     */     } catch (IOException ex) {
/* 194 */       throw new XMLSignatureException("empty", ex);
/*     */     } finally {
/* 196 */       this._xpathNodeSet = null;
/* 197 */       this._doc = null;
/* 198 */       this._writer = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void canonicalizeXPathNodeSet(Node currentNode)
/*     */     throws XMLSignatureException, IOException
/*     */   {
/* 212 */     int currentNodeType = currentNode.getNodeType();
/* 213 */     int position; switch (currentNodeType)
/*     */     {
/*     */     case 5: 
/*     */     case 10: 
/*     */     default: 
/*     */       break;
/*     */     case 2: 
/*     */     case 6: 
/*     */     case 11: 
/*     */     case 12: 
/* 223 */       throw new XMLSignatureException("empty");
/*     */     case 9: 
/* 225 */       this._writer.write("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n<html>\n<head>\n<title>Caninical XML node set</title>\n<style type=\"text/css\">\n<!-- \n.INCLUDED { \n   color: #000000; \n   background-color: \n   #FFFFFF; \n   font-weight: bold; } \n.EXCLUDED { \n   color: #666666; \n   background-color: \n   #999999; } \n.INCLUDEDINCLUSIVENAMESPACE { \n   color: #0000FF; \n   background-color: #FFFFFF; \n   font-weight: bold; \n   font-style: italic; } \n.EXCLUDEDINCLUSIVENAMESPACE { \n   color: #0000FF; \n   background-color: #999999; \n   font-style: italic; } \n--> \n</style> \n</head>\n<body bgcolor=\"#999999\">\n<h1>Explanation of the output</h1>\n<p>The following text contains the nodeset of the given Reference before it is canonicalized. There exist four different styles to indicate how a given node is treated.</p>\n<ul>\n<li class=\"INCLUDED\">A node which is in the node set is labeled using the INCLUDED style.</li>\n<li class=\"EXCLUDED\">A node which is <em>NOT</em> in the node set is labeled EXCLUDED style.</li>\n<li class=\"INCLUDEDINCLUSIVENAMESPACE\">A namespace which is in the node set AND in the InclusiveNamespaces PrefixList is labeled using the INCLUDEDINCLUSIVENAMESPACE style.</li>\n<li class=\"EXCLUDEDINCLUSIVENAMESPACE\">A namespace which is in NOT the node set AND in the InclusiveNamespaces PrefixList is labeled using the INCLUDEDINCLUSIVENAMESPACE style.</li>\n</ul>\n<h1>Output</h1>\n<pre>\n");
/*     */       
/* 227 */       for (Node currentChild = currentNode.getFirstChild(); currentChild != null; currentChild = currentChild.getNextSibling())
/*     */       {
/* 229 */         canonicalizeXPathNodeSet(currentChild);
/*     */       }
/*     */       
/* 232 */       this._writer.write("</pre></body></html>");
/* 233 */       break;
/*     */     
/*     */     case 8: 
/* 236 */       if (this._xpathNodeSet.contains(currentNode)) {
/* 237 */         this._writer.write("<span class=\"INCLUDED\">");
/*     */       } else {
/* 239 */         this._writer.write("<span class=\"EXCLUDED\">");
/*     */       }
/*     */       
/* 242 */       position = getPositionRelativeToDocumentElement(currentNode);
/*     */       
/* 244 */       if (position == 1) {
/* 245 */         this._writer.write("\n");
/*     */       }
/*     */       
/* 248 */       outputCommentToWriter((Comment)currentNode);
/*     */       
/* 250 */       if (position == -1) {
/* 251 */         this._writer.write("\n");
/*     */       }
/*     */       
/* 254 */       if (this._xpathNodeSet.contains(currentNode)) {
/* 255 */         this._writer.write("</span>");
/*     */       } else {
/* 257 */         this._writer.write("</span>");
/*     */       }
/* 259 */       break;
/*     */     
/*     */     case 7: 
/* 262 */       if (this._xpathNodeSet.contains(currentNode)) {
/* 263 */         this._writer.write("<span class=\"INCLUDED\">");
/*     */       } else {
/* 265 */         this._writer.write("<span class=\"EXCLUDED\">");
/*     */       }
/*     */       
/* 268 */       position = getPositionRelativeToDocumentElement(currentNode);
/*     */       
/* 270 */       if (position == 1) {
/* 271 */         this._writer.write("\n");
/*     */       }
/*     */       
/* 274 */       outputPItoWriter((ProcessingInstruction)currentNode);
/*     */       
/* 276 */       if (position == -1) {
/* 277 */         this._writer.write("\n");
/*     */       }
/*     */       
/* 280 */       if (this._xpathNodeSet.contains(currentNode)) {
/* 281 */         this._writer.write("</span>");
/*     */       } else {
/* 283 */         this._writer.write("</span>");
/*     */       }
/* 285 */       break;
/*     */     
/*     */     case 3: 
/*     */     case 4: 
/* 289 */       if (this._xpathNodeSet.contains(currentNode)) {
/* 290 */         this._writer.write("<span class=\"INCLUDED\">");
/*     */       } else {
/* 292 */         this._writer.write("<span class=\"EXCLUDED\">");
/*     */       }
/*     */       
/* 295 */       outputTextToWriter(currentNode.getNodeValue());
/*     */       
/* 297 */       for (Node nextSibling = currentNode.getNextSibling(); 
/* 298 */           (nextSibling != null) && ((nextSibling.getNodeType() == 3) || (nextSibling.getNodeType() == 4)); 
/* 299 */           nextSibling = nextSibling.getNextSibling())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 309 */         outputTextToWriter(nextSibling.getNodeValue());
/*     */       }
/*     */       
/* 312 */       if (this._xpathNodeSet.contains(currentNode)) {
/* 313 */         this._writer.write("</span>");
/*     */       } else {
/* 315 */         this._writer.write("</span>");
/*     */       }
/* 317 */       break;
/*     */     
/*     */     case 1: 
/* 320 */       Element currentElement = (Element)currentNode;
/*     */       
/* 322 */       if (this._xpathNodeSet.contains(currentNode)) {
/* 323 */         this._writer.write("<span class=\"INCLUDED\">");
/*     */       } else {
/* 325 */         this._writer.write("<span class=\"EXCLUDED\">");
/*     */       }
/*     */       
/* 328 */       this._writer.write("&lt;");
/* 329 */       this._writer.write(currentElement.getTagName());
/*     */       
/* 331 */       if (this._xpathNodeSet.contains(currentNode)) {
/* 332 */         this._writer.write("</span>");
/*     */       } else {
/* 334 */         this._writer.write("</span>");
/*     */       }
/*     */       
/*     */ 
/* 338 */       NamedNodeMap attrs = currentElement.getAttributes();
/* 339 */       int attrsLength = attrs.getLength();
/* 340 */       Object[] attrs2 = new Object[attrsLength];
/*     */       
/* 342 */       for (int i = 0; i < attrsLength; i++) {
/* 343 */         attrs2[i] = attrs.item(i);
/*     */       }
/*     */       
/* 346 */       Arrays.sort(attrs2, ATTR_COMPARE);
/* 347 */       Object[] attrs3 = attrs2;
/*     */       
/* 349 */       for (int i = 0; i < attrsLength; i++) {
/* 350 */         Attr a = (Attr)attrs3[i];
/* 351 */         boolean included = this._xpathNodeSet.contains(a);
/* 352 */         boolean inclusive = this._inclusiveNamespaces.contains(a.getName());
/*     */         
/*     */ 
/* 355 */         if (included) {
/* 356 */           if (inclusive)
/*     */           {
/*     */ 
/* 359 */             this._writer.write("<span class=\"INCLUDEDINCLUSIVENAMESPACE\">");
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 364 */             this._writer.write("<span class=\"INCLUDED\">");
/*     */           }
/*     */         }
/* 367 */         else if (inclusive)
/*     */         {
/*     */ 
/* 370 */           this._writer.write("<span class=\"EXCLUDEDINCLUSIVENAMESPACE\">");
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 375 */           this._writer.write("<span class=\"EXCLUDED\">");
/*     */         }
/*     */         
/*     */ 
/* 379 */         outputAttrToWriter(a.getNodeName(), a.getNodeValue());
/*     */         
/* 381 */         if (included) {
/* 382 */           if (inclusive)
/*     */           {
/*     */ 
/* 385 */             this._writer.write("</span>");
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 390 */             this._writer.write("</span>");
/*     */           }
/*     */         }
/* 393 */         else if (inclusive)
/*     */         {
/*     */ 
/* 396 */           this._writer.write("</span>");
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 401 */           this._writer.write("</span>");
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 406 */       if (this._xpathNodeSet.contains(currentNode)) {
/* 407 */         this._writer.write("<span class=\"INCLUDED\">");
/*     */       } else {
/* 409 */         this._writer.write("<span class=\"EXCLUDED\">");
/*     */       }
/*     */       
/* 412 */       this._writer.write("&gt;");
/*     */       
/* 414 */       if (this._xpathNodeSet.contains(currentNode)) {
/* 415 */         this._writer.write("</span>");
/*     */       } else {
/* 417 */         this._writer.write("</span>");
/*     */       }
/*     */       
/*     */ 
/* 421 */       for (Node currentChild = currentNode.getFirstChild(); currentChild != null; currentChild = currentChild.getNextSibling())
/*     */       {
/* 423 */         canonicalizeXPathNodeSet(currentChild);
/*     */       }
/*     */       
/* 426 */       if (this._xpathNodeSet.contains(currentNode)) {
/* 427 */         this._writer.write("<span class=\"INCLUDED\">");
/*     */       } else {
/* 429 */         this._writer.write("<span class=\"EXCLUDED\">");
/*     */       }
/*     */       
/* 432 */       this._writer.write("&lt;/");
/* 433 */       this._writer.write(currentElement.getTagName());
/* 434 */       this._writer.write("&gt;");
/*     */       
/* 436 */       if (this._xpathNodeSet.contains(currentNode)) {
/* 437 */         this._writer.write("</span>");
/*     */       } else {
/* 439 */         this._writer.write("</span>");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int getPositionRelativeToDocumentElement(Node currentNode)
/*     */   {
/* 460 */     if (currentNode == null) {
/* 461 */       return 0;
/*     */     }
/*     */     
/* 464 */     Document doc = currentNode.getOwnerDocument();
/*     */     
/* 466 */     if (currentNode.getParentNode() != doc) {
/* 467 */       return 0;
/*     */     }
/*     */     
/* 470 */     Element documentElement = doc.getDocumentElement();
/*     */     
/* 472 */     if (documentElement == null) {
/* 473 */       return 0;
/*     */     }
/*     */     
/* 476 */     if (documentElement == currentNode) {
/* 477 */       return 0;
/*     */     }
/*     */     
/* 480 */     for (Node x = currentNode; x != null; x = x.getNextSibling()) {
/* 481 */       if (x == documentElement) {
/* 482 */         return -1;
/*     */       }
/*     */     }
/*     */     
/* 486 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void outputAttrToWriter(String name, String value)
/*     */     throws IOException
/*     */   {
/* 510 */     this._writer.write(" ");
/* 511 */     this._writer.write(name);
/* 512 */     this._writer.write("=\"");
/*     */     
/* 514 */     int length = value.length();
/*     */     
/* 516 */     for (int i = 0; i < length; i++) {
/* 517 */       char c = value.charAt(i);
/*     */       
/* 519 */       switch (c)
/*     */       {
/*     */       case '&': 
/* 522 */         this._writer.write("&amp;amp;");
/* 523 */         break;
/*     */       
/*     */       case '<': 
/* 526 */         this._writer.write("&amp;lt;");
/* 527 */         break;
/*     */       
/*     */       case '"': 
/* 530 */         this._writer.write("&amp;quot;");
/* 531 */         break;
/*     */       
/*     */       case '\t': 
/* 534 */         this._writer.write("&amp;#x9;");
/* 535 */         break;
/*     */       
/*     */       case '\n': 
/* 538 */         this._writer.write("&amp;#xA;");
/* 539 */         break;
/*     */       
/*     */       case '\r': 
/* 542 */         this._writer.write("&amp;#xD;");
/* 543 */         break;
/*     */       
/*     */       default: 
/* 546 */         this._writer.write(c);
/*     */       }
/*     */       
/*     */     }
/*     */     
/* 551 */     this._writer.write("\"");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void outputPItoWriter(ProcessingInstruction currentPI)
/*     */     throws IOException
/*     */   {
/* 563 */     if (currentPI == null) {
/* 564 */       return;
/*     */     }
/*     */     
/* 567 */     this._writer.write("&lt;?");
/*     */     
/* 569 */     String target = currentPI.getTarget();
/* 570 */     int length = target.length();
/*     */     
/* 572 */     for (int i = 0; i < length; i++) {
/* 573 */       char c = target.charAt(i);
/*     */       
/* 575 */       switch (c)
/*     */       {
/*     */       case '\r': 
/* 578 */         this._writer.write("&amp;#xD;");
/* 579 */         break;
/*     */       
/*     */       case ' ': 
/* 582 */         this._writer.write("&middot;");
/* 583 */         break;
/*     */       
/*     */       case '\n': 
/* 586 */         this._writer.write("&para;\n");
/* 587 */         break;
/*     */       
/*     */       default: 
/* 590 */         this._writer.write(c);
/*     */       }
/*     */       
/*     */     }
/*     */     
/* 595 */     String data = currentPI.getData();
/*     */     
/* 597 */     length = data.length();
/*     */     
/* 599 */     if (length > 0) {
/* 600 */       this._writer.write(" ");
/*     */       
/* 602 */       for (int i = 0; i < length; i++) {
/* 603 */         char c = data.charAt(i);
/*     */         
/* 605 */         switch (c)
/*     */         {
/*     */         case '\r': 
/* 608 */           this._writer.write("&amp;#xD;");
/* 609 */           break;
/*     */         
/*     */         default: 
/* 612 */           this._writer.write(c);
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */     
/* 618 */     this._writer.write("?&gt;");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void outputCommentToWriter(Comment currentComment)
/*     */     throws IOException
/*     */   {
/* 630 */     if (currentComment == null) {
/* 631 */       return;
/*     */     }
/*     */     
/* 634 */     this._writer.write("&lt;!--");
/*     */     
/* 636 */     String data = currentComment.getData();
/* 637 */     int length = data.length();
/*     */     
/* 639 */     for (int i = 0; i < length; i++) {
/* 640 */       char c = data.charAt(i);
/*     */       
/* 642 */       switch (c)
/*     */       {
/*     */       case '\r': 
/* 645 */         this._writer.write("&amp;#xD;");
/* 646 */         break;
/*     */       
/*     */       case ' ': 
/* 649 */         this._writer.write("&middot;");
/* 650 */         break;
/*     */       
/*     */       case '\n': 
/* 653 */         this._writer.write("&para;\n");
/* 654 */         break;
/*     */       
/*     */       default: 
/* 657 */         this._writer.write(c);
/*     */       }
/*     */       
/*     */     }
/*     */     
/* 662 */     this._writer.write("--&gt;");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void outputTextToWriter(String text)
/*     */     throws IOException
/*     */   {
/* 673 */     if (text == null) {
/* 674 */       return;
/*     */     }
/*     */     
/* 677 */     int length = text.length();
/*     */     
/* 679 */     for (int i = 0; i < length; i++) {
/* 680 */       char c = text.charAt(i);
/*     */       
/* 682 */       switch (c)
/*     */       {
/*     */       case '&': 
/* 685 */         this._writer.write("&amp;amp;");
/* 686 */         break;
/*     */       
/*     */       case '<': 
/* 689 */         this._writer.write("&amp;lt;");
/* 690 */         break;
/*     */       
/*     */       case '>': 
/* 693 */         this._writer.write("&amp;gt;");
/* 694 */         break;
/*     */       
/*     */       case '\r': 
/* 697 */         this._writer.write("&amp;#xD;");
/* 698 */         break;
/*     */       
/*     */       case ' ': 
/* 701 */         this._writer.write("&middot;");
/* 702 */         break;
/*     */       
/*     */       case '\n': 
/* 705 */         this._writer.write("&para;\n");
/* 706 */         break;
/*     */       
/*     */       default: 
/* 709 */         this._writer.write(c);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\signature\XMLSignatureInputDebugger.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */