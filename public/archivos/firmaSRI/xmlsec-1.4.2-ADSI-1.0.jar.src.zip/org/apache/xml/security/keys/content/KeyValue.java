/*     */ package org.apache.xml.security.keys.content;
/*     */ 
/*     */ import java.security.PublicKey;
/*     */ import java.security.interfaces.DSAPublicKey;
/*     */ import java.security.interfaces.RSAPublicKey;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.keys.content.keyvalues.DSAKeyValue;
/*     */ import org.apache.xml.security.keys.content.keyvalues.RSAKeyValue;
/*     */ import org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyValue
/*     */   extends SignatureElementProxy
/*     */   implements KeyInfoContent
/*     */ {
/*     */   public KeyValue(Document doc, DSAKeyValue dsaKeyValue)
/*     */   {
/*  50 */     super(doc);
/*     */     
/*  52 */     XMLUtils.addReturnToElement(this._constructionElement);
/*  53 */     this._constructionElement.appendChild(dsaKeyValue.getElement());
/*  54 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyValue(Document doc, RSAKeyValue rsaKeyValue)
/*     */   {
/*  65 */     super(doc);
/*     */     
/*  67 */     XMLUtils.addReturnToElement(this._constructionElement);
/*  68 */     this._constructionElement.appendChild(rsaKeyValue.getElement());
/*  69 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyValue(Document doc, Element unknownKeyValue)
/*     */   {
/*  80 */     super(doc);
/*     */     
/*  82 */     XMLUtils.addReturnToElement(this._constructionElement);
/*  83 */     this._constructionElement.appendChild(unknownKeyValue);
/*  84 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyValue(Document doc, PublicKey pk)
/*     */   {
/*  95 */     super(doc);
/*     */     
/*  97 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */     
/*  99 */     if ((pk instanceof DSAPublicKey)) {
/* 100 */       DSAKeyValue dsa = new DSAKeyValue(this._doc, pk);
/*     */       
/* 102 */       this._constructionElement.appendChild(dsa.getElement());
/* 103 */       XMLUtils.addReturnToElement(this._constructionElement);
/* 104 */     } else if ((pk instanceof RSAPublicKey)) {
/* 105 */       RSAKeyValue rsa = new RSAKeyValue(this._doc, pk);
/*     */       
/* 107 */       this._constructionElement.appendChild(rsa.getElement());
/* 108 */       XMLUtils.addReturnToElement(this._constructionElement);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyValue(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 121 */     super(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PublicKey getPublicKey()
/*     */     throws XMLSecurityException
/*     */   {
/* 132 */     Element rsa = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), "RSAKeyValue", 0);
/*     */     
/*     */ 
/*     */ 
/* 136 */     if (rsa != null) {
/* 137 */       RSAKeyValue kv = new RSAKeyValue(rsa, this._baseURI);
/* 138 */       return kv.getPublicKey();
/*     */     }
/*     */     
/* 141 */     Element dsa = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), "DSAKeyValue", 0);
/*     */     
/*     */ 
/*     */ 
/* 145 */     if (dsa != null) {
/* 146 */       DSAKeyValue kv = new DSAKeyValue(dsa, this._baseURI);
/* 147 */       return kv.getPublicKey();
/*     */     }
/*     */     
/* 150 */     return null;
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 155 */     return "KeyValue";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\content\KeyValue.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */