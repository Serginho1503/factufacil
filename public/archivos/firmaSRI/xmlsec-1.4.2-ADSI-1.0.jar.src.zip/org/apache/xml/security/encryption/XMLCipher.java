/*      */ package org.apache.xml.security.encryption;
/*      */ 
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.StringReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.security.InvalidAlgorithmParameterException;
/*      */ import java.security.InvalidKeyException;
/*      */ import java.security.Key;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.security.NoSuchProviderException;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import javax.crypto.BadPaddingException;
/*      */ import javax.crypto.Cipher;
/*      */ import javax.crypto.IllegalBlockSizeException;
/*      */ import javax.crypto.NoSuchPaddingException;
/*      */ import javax.crypto.spec.IvParameterSpec;
/*      */ import javax.xml.parsers.DocumentBuilder;
/*      */ import javax.xml.parsers.DocumentBuilderFactory;
/*      */ import javax.xml.parsers.ParserConfigurationException;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.apache.xml.security.algorithms.JCEMapper;
/*      */ import org.apache.xml.security.c14n.Canonicalizer;
/*      */ import org.apache.xml.security.c14n.InvalidCanonicalizerException;
/*      */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*      */ import org.apache.xml.security.keys.KeyInfo;
/*      */ import org.apache.xml.security.keys.keyresolver.KeyResolverException;
/*      */ import org.apache.xml.security.keys.keyresolver.implementations.EncryptedKeyResolver;
/*      */ import org.apache.xml.security.signature.XMLSignatureException;
/*      */ import org.apache.xml.security.transforms.InvalidTransformException;
/*      */ import org.apache.xml.security.transforms.TransformationException;
/*      */ import org.apache.xml.security.utils.Base64;
/*      */ import org.apache.xml.security.utils.ElementProxy;
/*      */ import org.apache.xml.security.utils.XMLUtils;
/*      */ import org.apache.xml.utils.URI;
/*      */ import org.apache.xml.utils.URI.MalformedURIException;
/*      */ import org.w3c.dom.Attr;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.DocumentFragment;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.NamedNodeMap;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ import org.xml.sax.InputSource;
/*      */ import org.xml.sax.SAXException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class XMLCipher
/*      */ {
/*   83 */   private static Log logger = LogFactory.getLog(XMLCipher.class.getName());
/*      */   
/*      */ 
/*      */ 
/*      */   public static final String TRIPLEDES = "http://www.w3.org/2001/04/xmlenc#tripledes-cbc";
/*      */   
/*      */ 
/*      */ 
/*      */   public static final String AES_128 = "http://www.w3.org/2001/04/xmlenc#aes128-cbc";
/*      */   
/*      */ 
/*      */   public static final String AES_256 = "http://www.w3.org/2001/04/xmlenc#aes256-cbc";
/*      */   
/*      */ 
/*      */   public static final String AES_192 = "http://www.w3.org/2001/04/xmlenc#aes192-cbc";
/*      */   
/*      */ 
/*      */   public static final String RSA_v1dot5 = "http://www.w3.org/2001/04/xmlenc#rsa-1_5";
/*      */   
/*      */ 
/*      */   public static final String RSA_OAEP = "http://www.w3.org/2001/04/xmlenc#rsa-oaep-mgf1p";
/*      */   
/*      */ 
/*      */   public static final String DIFFIE_HELLMAN = "http://www.w3.org/2001/04/xmlenc#dh";
/*      */   
/*      */ 
/*      */   public static final String TRIPLEDES_KeyWrap = "http://www.w3.org/2001/04/xmlenc#kw-tripledes";
/*      */   
/*      */ 
/*      */   public static final String AES_128_KeyWrap = "http://www.w3.org/2001/04/xmlenc#kw-aes128";
/*      */   
/*      */ 
/*      */   public static final String AES_256_KeyWrap = "http://www.w3.org/2001/04/xmlenc#kw-aes256";
/*      */   
/*      */ 
/*      */   public static final String AES_192_KeyWrap = "http://www.w3.org/2001/04/xmlenc#kw-aes192";
/*      */   
/*      */ 
/*      */   public static final String SHA1 = "http://www.w3.org/2000/09/xmldsig#sha1";
/*      */   
/*      */ 
/*      */   public static final String SHA256 = "http://www.w3.org/2001/04/xmlenc#sha256";
/*      */   
/*      */ 
/*      */   public static final String SHA512 = "http://www.w3.org/2001/04/xmlenc#sha512";
/*      */   
/*      */ 
/*      */   public static final String RIPEMD_160 = "http://www.w3.org/2001/04/xmlenc#ripemd160";
/*      */   
/*      */ 
/*      */   public static final String XML_DSIG = "http://www.w3.org/2000/09/xmldsig#";
/*      */   
/*      */ 
/*      */   public static final String N14C_XML = "http://www.w3.org/TR/2001/REC-xml-c14n-20010315";
/*      */   
/*      */ 
/*      */   public static final String N14C_XML_WITH_COMMENTS = "http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments";
/*      */   
/*      */ 
/*      */   public static final String EXCL_XML_N14C = "http://www.w3.org/2001/10/xml-exc-c14n#";
/*      */   
/*      */ 
/*      */   public static final String EXCL_XML_N14C_WITH_COMMENTS = "http://www.w3.org/2001/10/xml-exc-c14n#WithComments";
/*      */   
/*      */ 
/*      */   public static final String BASE64_ENCODING = "http://www.w3.org/2000/09/xmldsig#base64";
/*      */   
/*      */ 
/*      */   public static final int ENCRYPT_MODE = 1;
/*      */   
/*      */ 
/*      */   public static final int DECRYPT_MODE = 2;
/*      */   
/*      */ 
/*      */   public static final int UNWRAP_MODE = 4;
/*      */   
/*      */ 
/*      */   public static final int WRAP_MODE = 3;
/*      */   
/*      */ 
/*      */   private static final String ENC_ALGORITHMS = "http://www.w3.org/2001/04/xmlenc#tripledes-cbc\nhttp://www.w3.org/2001/04/xmlenc#aes128-cbc\nhttp://www.w3.org/2001/04/xmlenc#aes256-cbc\nhttp://www.w3.org/2001/04/xmlenc#aes192-cbc\nhttp://www.w3.org/2001/04/xmlenc#rsa-1_5\nhttp://www.w3.org/2001/04/xmlenc#rsa-oaep-mgf1p\nhttp://www.w3.org/2001/04/xmlenc#kw-tripledes\nhttp://www.w3.org/2001/04/xmlenc#kw-aes128\nhttp://www.w3.org/2001/04/xmlenc#kw-aes256\nhttp://www.w3.org/2001/04/xmlenc#kw-aes192\n";
/*      */   
/*      */ 
/*      */   private Cipher _contextCipher;
/*      */   
/*      */ 
/*  169 */   private int _cipherMode = Integer.MIN_VALUE;
/*      */   
/*  171 */   private String _algorithm = null;
/*      */   
/*  173 */   private String _requestedJCEProvider = null;
/*      */   
/*      */ 
/*      */ 
/*      */   private Canonicalizer _canon;
/*      */   
/*      */ 
/*      */ 
/*      */   private Document _contextDocument;
/*      */   
/*      */ 
/*      */   private Factory _factory;
/*      */   
/*      */ 
/*      */   private Serializer _serializer;
/*      */   
/*      */ 
/*      */   private Key _key;
/*      */   
/*      */ 
/*      */   private Key _kek;
/*      */   
/*      */ 
/*      */   private EncryptedKey _ek;
/*      */   
/*      */ 
/*      */   private EncryptedData _ed;
/*      */   
/*      */ 
/*      */ 
/*      */   private XMLCipher()
/*      */   {
/*  205 */     logger.debug("Constructing XMLCipher...");
/*      */     
/*  207 */     this._factory = new Factory(null);
/*  208 */     this._serializer = new Serializer();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static boolean isValidEncryptionAlgorithm(String algorithm)
/*      */   {
/*  220 */     boolean result = (algorithm.equals("http://www.w3.org/2001/04/xmlenc#tripledes-cbc")) || (algorithm.equals("http://www.w3.org/2001/04/xmlenc#aes128-cbc")) || (algorithm.equals("http://www.w3.org/2001/04/xmlenc#aes256-cbc")) || (algorithm.equals("http://www.w3.org/2001/04/xmlenc#aes192-cbc")) || (algorithm.equals("http://www.w3.org/2001/04/xmlenc#rsa-1_5")) || (algorithm.equals("http://www.w3.org/2001/04/xmlenc#rsa-oaep-mgf1p")) || (algorithm.equals("http://www.w3.org/2001/04/xmlenc#kw-tripledes")) || (algorithm.equals("http://www.w3.org/2001/04/xmlenc#kw-aes128")) || (algorithm.equals("http://www.w3.org/2001/04/xmlenc#kw-aes256")) || (algorithm.equals("http://www.w3.org/2001/04/xmlenc#kw-aes192"));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  233 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static XMLCipher getInstance(String transformation)
/*      */     throws XMLEncryptionException
/*      */   {
/*  267 */     logger.debug("Getting XMLCipher...");
/*  268 */     if (null == transformation)
/*  269 */       logger.error("Transformation unexpectedly null...");
/*  270 */     if (!isValidEncryptionAlgorithm(transformation)) {
/*  271 */       logger.warn("Algorithm non-standard, expected one of http://www.w3.org/2001/04/xmlenc#tripledes-cbc\nhttp://www.w3.org/2001/04/xmlenc#aes128-cbc\nhttp://www.w3.org/2001/04/xmlenc#aes256-cbc\nhttp://www.w3.org/2001/04/xmlenc#aes192-cbc\nhttp://www.w3.org/2001/04/xmlenc#rsa-1_5\nhttp://www.w3.org/2001/04/xmlenc#rsa-oaep-mgf1p\nhttp://www.w3.org/2001/04/xmlenc#kw-tripledes\nhttp://www.w3.org/2001/04/xmlenc#kw-aes128\nhttp://www.w3.org/2001/04/xmlenc#kw-aes256\nhttp://www.w3.org/2001/04/xmlenc#kw-aes192\n");
/*      */     }
/*  273 */     XMLCipher instance = new XMLCipher();
/*      */     
/*  275 */     instance._algorithm = transformation;
/*  276 */     instance._key = null;
/*  277 */     instance._kek = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  284 */       instance._canon = Canonicalizer.getInstance("http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments");
/*      */     }
/*      */     catch (InvalidCanonicalizerException ice)
/*      */     {
/*  288 */       throw new XMLEncryptionException("empty", ice);
/*      */     }
/*      */     
/*  291 */     String jceAlgorithm = JCEMapper.translateURItoJCEID(transformation);
/*      */     try
/*      */     {
/*  294 */       instance._contextCipher = Cipher.getInstance(jceAlgorithm);
/*  295 */       logger.debug("cihper.algoritm = " + instance._contextCipher.getAlgorithm());
/*      */     }
/*      */     catch (NoSuchAlgorithmException nsae) {
/*  298 */       throw new XMLEncryptionException("empty", nsae);
/*      */     } catch (NoSuchPaddingException nspe) {
/*  300 */       throw new XMLEncryptionException("empty", nspe);
/*      */     }
/*      */     
/*  303 */     return instance;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static XMLCipher getInstance(String transformation, String canon)
/*      */     throws XMLEncryptionException
/*      */   {
/*  325 */     XMLCipher instance = getInstance(transformation);
/*      */     
/*  327 */     if (canon != null) {
/*      */       try {
/*  329 */         instance._canon = Canonicalizer.getInstance(canon);
/*      */       } catch (InvalidCanonicalizerException ice) {
/*  331 */         throw new XMLEncryptionException("empty", ice);
/*      */       }
/*      */     }
/*      */     
/*  335 */     return instance;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static XMLCipher getProviderInstance(String transformation, String provider)
/*      */     throws XMLEncryptionException
/*      */   {
/*  354 */     logger.debug("Getting XMLCipher...");
/*  355 */     if (null == transformation)
/*  356 */       logger.error("Transformation unexpectedly null...");
/*  357 */     if (null == provider)
/*  358 */       logger.error("Provider unexpectedly null..");
/*  359 */     if ("" == provider)
/*  360 */       logger.error("Provider's value unexpectedly not specified...");
/*  361 */     if (!isValidEncryptionAlgorithm(transformation)) {
/*  362 */       logger.warn("Algorithm non-standard, expected one of http://www.w3.org/2001/04/xmlenc#tripledes-cbc\nhttp://www.w3.org/2001/04/xmlenc#aes128-cbc\nhttp://www.w3.org/2001/04/xmlenc#aes256-cbc\nhttp://www.w3.org/2001/04/xmlenc#aes192-cbc\nhttp://www.w3.org/2001/04/xmlenc#rsa-1_5\nhttp://www.w3.org/2001/04/xmlenc#rsa-oaep-mgf1p\nhttp://www.w3.org/2001/04/xmlenc#kw-tripledes\nhttp://www.w3.org/2001/04/xmlenc#kw-aes128\nhttp://www.w3.org/2001/04/xmlenc#kw-aes256\nhttp://www.w3.org/2001/04/xmlenc#kw-aes192\n");
/*      */     }
/*  364 */     XMLCipher instance = new XMLCipher();
/*      */     
/*  366 */     instance._algorithm = transformation;
/*  367 */     instance._requestedJCEProvider = provider;
/*  368 */     instance._key = null;
/*  369 */     instance._kek = null;
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  375 */       instance._canon = Canonicalizer.getInstance("http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments");
/*      */     }
/*      */     catch (InvalidCanonicalizerException ice) {
/*  378 */       throw new XMLEncryptionException("empty", ice);
/*      */     }
/*      */     try
/*      */     {
/*  382 */       String jceAlgorithm = JCEMapper.translateURItoJCEID(transformation);
/*      */       
/*      */ 
/*  385 */       instance._contextCipher = Cipher.getInstance(jceAlgorithm, provider);
/*      */       
/*  387 */       logger.debug("cipher._algorithm = " + instance._contextCipher.getAlgorithm());
/*      */       
/*  389 */       logger.debug("provider.name = " + provider);
/*      */     } catch (NoSuchAlgorithmException nsae) {
/*  391 */       throw new XMLEncryptionException("empty", nsae);
/*      */     } catch (NoSuchProviderException nspre) {
/*  393 */       throw new XMLEncryptionException("empty", nspre);
/*      */     } catch (NoSuchPaddingException nspe) {
/*  395 */       throw new XMLEncryptionException("empty", nspe);
/*      */     }
/*      */     
/*  398 */     return instance;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static XMLCipher getProviderInstance(String transformation, String provider, String canon)
/*      */     throws XMLEncryptionException
/*      */   {
/*  424 */     XMLCipher instance = getProviderInstance(transformation, provider);
/*  425 */     if (canon != null) {
/*      */       try {
/*  427 */         instance._canon = Canonicalizer.getInstance(canon);
/*      */       } catch (InvalidCanonicalizerException ice) {
/*  429 */         throw new XMLEncryptionException("empty", ice);
/*      */       }
/*      */     }
/*  432 */     return instance;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static XMLCipher getInstance()
/*      */     throws XMLEncryptionException
/*      */   {
/*  448 */     logger.debug("Getting XMLCipher for no transformation...");
/*      */     
/*  450 */     XMLCipher instance = new XMLCipher();
/*      */     
/*  452 */     instance._algorithm = null;
/*  453 */     instance._requestedJCEProvider = null;
/*  454 */     instance._key = null;
/*  455 */     instance._kek = null;
/*  456 */     instance._contextCipher = null;
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  462 */       instance._canon = Canonicalizer.getInstance("http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments");
/*      */     }
/*      */     catch (InvalidCanonicalizerException ice) {
/*  465 */       throw new XMLEncryptionException("empty", ice);
/*      */     }
/*      */     
/*  468 */     return instance;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static XMLCipher getProviderInstance(String provider)
/*      */     throws XMLEncryptionException
/*      */   {
/*  490 */     logger.debug("Getting XMLCipher, provider but no transformation");
/*  491 */     if (null == provider)
/*  492 */       logger.error("Provider unexpectedly null..");
/*  493 */     if ("" == provider) {
/*  494 */       logger.error("Provider's value unexpectedly not specified...");
/*      */     }
/*  496 */     XMLCipher instance = new XMLCipher();
/*      */     
/*  498 */     instance._algorithm = null;
/*  499 */     instance._requestedJCEProvider = provider;
/*  500 */     instance._key = null;
/*  501 */     instance._kek = null;
/*  502 */     instance._contextCipher = null;
/*      */     try
/*      */     {
/*  505 */       instance._canon = Canonicalizer.getInstance("http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments");
/*      */     }
/*      */     catch (InvalidCanonicalizerException ice) {
/*  508 */       throw new XMLEncryptionException("empty", ice);
/*      */     }
/*      */     
/*  511 */     return instance;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void init(int opmode, Key key)
/*      */     throws XMLEncryptionException
/*      */   {
/*  536 */     logger.debug("Initializing XMLCipher...");
/*      */     
/*  538 */     this._ek = null;
/*  539 */     this._ed = null;
/*      */     
/*  541 */     switch (opmode)
/*      */     {
/*      */     case 1: 
/*  544 */       logger.debug("opmode = ENCRYPT_MODE");
/*  545 */       this._ed = createEncryptedData(1, "NO VALUE YET");
/*  546 */       break;
/*      */     case 2: 
/*  548 */       logger.debug("opmode = DECRYPT_MODE");
/*  549 */       break;
/*      */     case 3: 
/*  551 */       logger.debug("opmode = WRAP_MODE");
/*  552 */       this._ek = createEncryptedKey(1, "NO VALUE YET");
/*  553 */       break;
/*      */     case 4: 
/*  555 */       logger.debug("opmode = UNWRAP_MODE");
/*  556 */       break;
/*      */     default: 
/*  558 */       logger.error("Mode unexpectedly invalid");
/*  559 */       throw new XMLEncryptionException("Invalid mode in init");
/*      */     }
/*      */     
/*  562 */     this._cipherMode = opmode;
/*  563 */     this._key = key;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptedData getEncryptedData()
/*      */   {
/*  580 */     logger.debug("Returning EncryptedData");
/*  581 */     return this._ed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptedKey getEncryptedKey()
/*      */   {
/*  598 */     logger.debug("Returning EncryptedKey");
/*  599 */     return this._ek;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setKEK(Key kek)
/*      */   {
/*  615 */     this._kek = kek;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Element martial(EncryptedData encryptedData)
/*      */   {
/*  635 */     return this._factory.toElement(encryptedData);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Element martial(EncryptedKey encryptedKey)
/*      */   {
/*  655 */     return this._factory.toElement(encryptedKey);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Element martial(Document context, EncryptedData encryptedData)
/*      */   {
/*  672 */     this._contextDocument = context;
/*  673 */     return this._factory.toElement(encryptedData);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Element martial(Document context, EncryptedKey encryptedKey)
/*      */   {
/*  690 */     this._contextDocument = context;
/*  691 */     return this._factory.toElement(encryptedKey);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Document encryptElement(Element element)
/*      */     throws Exception
/*      */   {
/*  708 */     logger.debug("Encrypting element...");
/*  709 */     if (null == element)
/*  710 */       logger.error("Element unexpectedly null...");
/*  711 */     if (this._cipherMode != 1) {
/*  712 */       logger.debug("XMLCipher unexpectedly not in ENCRYPT_MODE...");
/*      */     }
/*  714 */     if (this._algorithm == null) {
/*  715 */       throw new XMLEncryptionException("XMLCipher instance without transformation specified");
/*      */     }
/*  717 */     encryptData(this._contextDocument, element, false);
/*      */     
/*  719 */     Element encryptedElement = this._factory.toElement(this._ed);
/*      */     
/*  721 */     Node sourceParent = element.getParentNode();
/*  722 */     sourceParent.replaceChild(encryptedElement, element);
/*      */     
/*  724 */     return this._contextDocument;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Document encryptElementContent(Element element)
/*      */     throws Exception
/*      */   {
/*  743 */     logger.debug("Encrypting element content...");
/*  744 */     if (null == element)
/*  745 */       logger.error("Element unexpectedly null...");
/*  746 */     if (this._cipherMode != 1) {
/*  747 */       logger.debug("XMLCipher unexpectedly not in ENCRYPT_MODE...");
/*      */     }
/*  749 */     if (this._algorithm == null) {
/*  750 */       throw new XMLEncryptionException("XMLCipher instance without transformation specified");
/*      */     }
/*  752 */     encryptData(this._contextDocument, element, true);
/*      */     
/*  754 */     Element encryptedElement = this._factory.toElement(this._ed);
/*      */     
/*  756 */     removeContent(element);
/*  757 */     element.appendChild(encryptedElement);
/*      */     
/*  759 */     return this._contextDocument;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Document doFinal(Document context, Document source)
/*      */     throws Exception
/*      */   {
/*  773 */     logger.debug("Processing source document...");
/*  774 */     if (null == context)
/*  775 */       logger.error("Context document unexpectedly null...");
/*  776 */     if (null == source) {
/*  777 */       logger.error("Source document unexpectedly null...");
/*      */     }
/*  779 */     this._contextDocument = context;
/*      */     
/*  781 */     Document result = null;
/*      */     
/*  783 */     switch (this._cipherMode) {
/*      */     case 2: 
/*  785 */       result = decryptElement(source.getDocumentElement());
/*  786 */       break;
/*      */     case 1: 
/*  788 */       result = encryptElement(source.getDocumentElement());
/*  789 */       break;
/*      */     case 4: 
/*      */       break;
/*      */     case 3: 
/*      */       break;
/*      */     default: 
/*  795 */       throw new XMLEncryptionException("empty", new IllegalStateException());
/*      */     }
/*      */     
/*      */     
/*  799 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Document doFinal(Document context, Element element)
/*      */     throws Exception
/*      */   {
/*  813 */     logger.debug("Processing source element...");
/*  814 */     if (null == context)
/*  815 */       logger.error("Context document unexpectedly null...");
/*  816 */     if (null == element) {
/*  817 */       logger.error("Source element unexpectedly null...");
/*      */     }
/*  819 */     this._contextDocument = context;
/*      */     
/*  821 */     Document result = null;
/*      */     
/*  823 */     switch (this._cipherMode) {
/*      */     case 2: 
/*  825 */       result = decryptElement(element);
/*  826 */       break;
/*      */     case 1: 
/*  828 */       result = encryptElement(element);
/*  829 */       break;
/*      */     case 4: 
/*      */       break;
/*      */     case 3: 
/*      */       break;
/*      */     default: 
/*  835 */       throw new XMLEncryptionException("empty", new IllegalStateException());
/*      */     }
/*      */     
/*      */     
/*  839 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Document doFinal(Document context, Element element, boolean content)
/*      */     throws Exception
/*      */   {
/*  856 */     logger.debug("Processing source element...");
/*  857 */     if (null == context)
/*  858 */       logger.error("Context document unexpectedly null...");
/*  859 */     if (null == element) {
/*  860 */       logger.error("Source element unexpectedly null...");
/*      */     }
/*  862 */     this._contextDocument = context;
/*      */     
/*  864 */     Document result = null;
/*      */     
/*  866 */     switch (this._cipherMode) {
/*      */     case 2: 
/*  868 */       if (content) {
/*  869 */         result = decryptElementContent(element);
/*      */       } else {
/*  871 */         result = decryptElement(element);
/*      */       }
/*  873 */       break;
/*      */     case 1: 
/*  875 */       if (content) {
/*  876 */         result = encryptElementContent(element);
/*      */       } else {
/*  878 */         result = encryptElement(element);
/*      */       }
/*  880 */       break;
/*      */     case 4: 
/*      */       break;
/*      */     case 3: 
/*      */       break;
/*      */     default: 
/*  886 */       throw new XMLEncryptionException("empty", new IllegalStateException());
/*      */     }
/*      */     
/*      */     
/*  890 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptedData encryptData(Document context, Element element)
/*      */     throws Exception
/*      */   {
/*  907 */     return encryptData(context, element, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptedData encryptData(Document context, String type, InputStream serializedData)
/*      */     throws Exception
/*      */   {
/*  927 */     logger.debug("Encrypting element...");
/*  928 */     if (null == context)
/*  929 */       logger.error("Context document unexpectedly null...");
/*  930 */     if (null == serializedData)
/*  931 */       logger.error("Serialized data unexpectedly null...");
/*  932 */     if (this._cipherMode != 1) {
/*  933 */       logger.debug("XMLCipher unexpectedly not in ENCRYPT_MODE...");
/*      */     }
/*  935 */     return encryptData(context, null, type, serializedData);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptedData encryptData(Document context, Element element, boolean contentMode)
/*      */     throws Exception
/*      */   {
/*  956 */     logger.debug("Encrypting element...");
/*  957 */     if (null == context)
/*  958 */       logger.error("Context document unexpectedly null...");
/*  959 */     if (null == element)
/*  960 */       logger.error("Element unexpectedly null...");
/*  961 */     if (this._cipherMode != 1) {
/*  962 */       logger.debug("XMLCipher unexpectedly not in ENCRYPT_MODE...");
/*      */     }
/*  964 */     if (contentMode) {
/*  965 */       return encryptData(context, element, "http://www.w3.org/2001/04/xmlenc#Content", null);
/*      */     }
/*      */     
/*  968 */     return encryptData(context, element, "http://www.w3.org/2001/04/xmlenc#Element", null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private EncryptedData encryptData(Document context, Element element, String type, InputStream serializedData)
/*      */     throws Exception
/*      */   {
/*  977 */     this._contextDocument = context;
/*      */     
/*  979 */     if (this._algorithm == null) {
/*  980 */       throw new XMLEncryptionException("XMLCipher instance without transformation specified");
/*      */     }
/*      */     
/*      */ 
/*  984 */     String serializedOctets = null;
/*  985 */     if (serializedData == null) {
/*  986 */       if (type == "http://www.w3.org/2001/04/xmlenc#Content") {
/*  987 */         NodeList children = element.getChildNodes();
/*  988 */         if (null != children) {
/*  989 */           serializedOctets = this._serializer.serialize(children);
/*      */         } else {
/*  991 */           Object[] exArgs = { "Element has no content." };
/*  992 */           throw new XMLEncryptionException("empty", exArgs);
/*      */         }
/*      */       } else {
/*  995 */         serializedOctets = this._serializer.serialize(element);
/*      */       }
/*  997 */       logger.debug("Serialized octets:\n" + serializedOctets);
/*      */     }
/*      */     
/* 1000 */     byte[] encryptedBytes = null;
/*      */     
/*      */     Cipher c;
/*      */     
/* 1004 */     if (this._contextCipher == null) {
/* 1005 */       String jceAlgorithm = JCEMapper.translateURItoJCEID(this._algorithm);
/* 1006 */       logger.debug("alg = " + jceAlgorithm);
/*      */       try {
/*      */         Cipher c;
/* 1009 */         if (this._requestedJCEProvider == null) {
/* 1010 */           c = Cipher.getInstance(jceAlgorithm);
/*      */         } else
/* 1012 */           c = Cipher.getInstance(jceAlgorithm, this._requestedJCEProvider);
/*      */       } catch (NoSuchAlgorithmException nsae) { Cipher c;
/* 1014 */         throw new XMLEncryptionException("empty", nsae);
/*      */       } catch (NoSuchProviderException nspre) {
/* 1016 */         throw new XMLEncryptionException("empty", nspre);
/*      */       } catch (NoSuchPaddingException nspae) {
/* 1018 */         throw new XMLEncryptionException("empty", nspae);
/*      */       }
/*      */     } else {
/* 1021 */       c = this._contextCipher;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 1028 */       c.init(this._cipherMode, this._key);
/*      */     } catch (InvalidKeyException ike) {
/* 1030 */       throw new XMLEncryptionException("empty", ike);
/*      */     }
/*      */     try
/*      */     {
/* 1034 */       if (serializedData != null)
/*      */       {
/* 1036 */         byte[] buf = new byte[' '];
/* 1037 */         ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 1038 */         int numBytes; while ((numBytes = serializedData.read(buf)) != -1) {
/* 1039 */           byte[] data = c.update(buf, 0, numBytes);
/* 1040 */           baos.write(data);
/*      */         }
/* 1042 */         baos.write(c.doFinal());
/* 1043 */         encryptedBytes = baos.toByteArray();
/*      */       } else {
/* 1045 */         encryptedBytes = c.doFinal(serializedOctets.getBytes("UTF-8"));
/* 1046 */         logger.debug("Expected cipher.outputSize = " + Integer.toString(c.getOutputSize(serializedOctets.getBytes().length)));
/*      */       }
/*      */       
/*      */ 
/* 1050 */       logger.debug("Actual cipher.outputSize = " + Integer.toString(encryptedBytes.length));
/*      */     }
/*      */     catch (IllegalStateException ise) {
/* 1053 */       throw new XMLEncryptionException("empty", ise);
/*      */     } catch (IllegalBlockSizeException ibse) {
/* 1055 */       throw new XMLEncryptionException("empty", ibse);
/*      */     } catch (BadPaddingException bpe) {
/* 1057 */       throw new XMLEncryptionException("empty", bpe);
/*      */     } catch (UnsupportedEncodingException uee) {
/* 1059 */       throw new XMLEncryptionException("empty", uee);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1064 */     byte[] iv = c.getIV();
/* 1065 */     byte[] finalEncryptedBytes = new byte[iv.length + encryptedBytes.length];
/*      */     
/* 1067 */     System.arraycopy(iv, 0, finalEncryptedBytes, 0, iv.length);
/* 1068 */     System.arraycopy(encryptedBytes, 0, finalEncryptedBytes, iv.length, encryptedBytes.length);
/*      */     
/* 1070 */     String base64EncodedEncryptedOctets = Base64.encode(finalEncryptedBytes);
/*      */     
/* 1072 */     logger.debug("Encrypted octets:\n" + base64EncodedEncryptedOctets);
/* 1073 */     logger.debug("Encrypted octets length = " + base64EncodedEncryptedOctets.length());
/*      */     
/*      */     try
/*      */     {
/* 1077 */       CipherData cd = this._ed.getCipherData();
/* 1078 */       CipherValue cv = cd.getCipherValue();
/*      */       
/* 1080 */       cv.setValue(base64EncodedEncryptedOctets);
/*      */       
/* 1082 */       if (type != null) {
/* 1083 */         this._ed.setType(new URI(type).toString());
/*      */       }
/* 1085 */       EncryptionMethod method = this._factory.newEncryptionMethod(new URI(this._algorithm).toString());
/*      */       
/* 1087 */       this._ed.setEncryptionMethod(method);
/*      */     } catch (URI.MalformedURIException mfue) {
/* 1089 */       throw new XMLEncryptionException("empty", mfue);
/*      */     }
/* 1091 */     return this._ed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptedData loadEncryptedData(Document context, Element element)
/*      */     throws XMLEncryptionException
/*      */   {
/* 1106 */     logger.debug("Loading encrypted element...");
/* 1107 */     if (null == context)
/* 1108 */       logger.error("Context document unexpectedly null...");
/* 1109 */     if (null == element)
/* 1110 */       logger.error("Element unexpectedly null...");
/* 1111 */     if (this._cipherMode != 2) {
/* 1112 */       logger.error("XMLCipher unexpectedly not in DECRYPT_MODE...");
/*      */     }
/* 1114 */     this._contextDocument = context;
/* 1115 */     this._ed = this._factory.newEncryptedData(element);
/*      */     
/* 1117 */     return this._ed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptedKey loadEncryptedKey(Document context, Element element)
/*      */     throws XMLEncryptionException
/*      */   {
/* 1133 */     logger.debug("Loading encrypted key...");
/* 1134 */     if (null == context)
/* 1135 */       logger.error("Context document unexpectedly null...");
/* 1136 */     if (null == element)
/* 1137 */       logger.error("Element unexpectedly null...");
/* 1138 */     if ((this._cipherMode != 4) && (this._cipherMode != 2)) {
/* 1139 */       logger.debug("XMLCipher unexpectedly not in UNWRAP_MODE or DECRYPT_MODE...");
/*      */     }
/* 1141 */     this._contextDocument = context;
/* 1142 */     this._ek = this._factory.newEncryptedKey(element);
/* 1143 */     return this._ek;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptedKey loadEncryptedKey(Element element)
/*      */     throws XMLEncryptionException
/*      */   {
/* 1161 */     return loadEncryptedKey(element.getOwnerDocument(), element);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptedKey encryptKey(Document doc, Key key)
/*      */     throws XMLEncryptionException
/*      */   {
/* 1177 */     logger.debug("Encrypting key ...");
/*      */     
/* 1179 */     if (null == key)
/* 1180 */       logger.error("Key unexpectedly null...");
/* 1181 */     if (this._cipherMode != 3) {
/* 1182 */       logger.debug("XMLCipher unexpectedly not in WRAP_MODE...");
/*      */     }
/* 1184 */     if (this._algorithm == null)
/*      */     {
/* 1186 */       throw new XMLEncryptionException("XMLCipher instance without transformation specified");
/*      */     }
/*      */     
/* 1189 */     this._contextDocument = doc;
/*      */     
/* 1191 */     byte[] encryptedBytes = null;
/*      */     
/*      */     Cipher c;
/* 1194 */     if (this._contextCipher == null)
/*      */     {
/*      */ 
/* 1197 */       String jceAlgorithm = JCEMapper.translateURItoJCEID(this._algorithm);
/*      */       
/*      */ 
/* 1200 */       logger.debug("alg = " + jceAlgorithm);
/*      */       try {
/*      */         Cipher c;
/* 1203 */         if (this._requestedJCEProvider == null) {
/* 1204 */           c = Cipher.getInstance(jceAlgorithm);
/*      */         } else
/* 1206 */           c = Cipher.getInstance(jceAlgorithm, this._requestedJCEProvider);
/*      */       } catch (NoSuchAlgorithmException nsae) { Cipher c;
/* 1208 */         throw new XMLEncryptionException("empty", nsae);
/*      */       } catch (NoSuchProviderException nspre) {
/* 1210 */         throw new XMLEncryptionException("empty", nspre);
/*      */       } catch (NoSuchPaddingException nspae) {
/* 1212 */         throw new XMLEncryptionException("empty", nspae);
/*      */       }
/*      */     } else {
/* 1215 */       c = this._contextCipher;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 1222 */       c.init(3, this._key);
/* 1223 */       encryptedBytes = c.wrap(key);
/*      */     } catch (InvalidKeyException ike) {
/* 1225 */       throw new XMLEncryptionException("empty", ike);
/*      */     } catch (IllegalBlockSizeException ibse) {
/* 1227 */       throw new XMLEncryptionException("empty", ibse);
/*      */     }
/*      */     
/* 1230 */     String base64EncodedEncryptedOctets = Base64.encode(encryptedBytes);
/*      */     
/* 1232 */     logger.debug("Encrypted key octets:\n" + base64EncodedEncryptedOctets);
/* 1233 */     logger.debug("Encrypted key octets length = " + base64EncodedEncryptedOctets.length());
/*      */     
/*      */ 
/* 1236 */     CipherValue cv = this._ek.getCipherData().getCipherValue();
/* 1237 */     cv.setValue(base64EncodedEncryptedOctets);
/*      */     try
/*      */     {
/* 1240 */       EncryptionMethod method = this._factory.newEncryptionMethod(new URI(this._algorithm).toString());
/*      */       
/* 1242 */       this._ek.setEncryptionMethod(method);
/*      */     } catch (URI.MalformedURIException mfue) {
/* 1244 */       throw new XMLEncryptionException("empty", mfue);
/*      */     }
/* 1246 */     return this._ek;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Key decryptKey(EncryptedKey encryptedKey, String algorithm)
/*      */     throws XMLEncryptionException
/*      */   {
/* 1263 */     logger.debug("Decrypting key from previously loaded EncryptedKey...");
/*      */     
/* 1265 */     if (this._cipherMode != 4) {
/* 1266 */       logger.debug("XMLCipher unexpectedly not in UNWRAP_MODE...");
/*      */     }
/* 1268 */     if (algorithm == null) {
/* 1269 */       throw new XMLEncryptionException("Cannot decrypt a key without knowing the algorithm");
/*      */     }
/*      */     
/* 1272 */     if (this._key == null)
/*      */     {
/* 1274 */       logger.debug("Trying to find a KEK via key resolvers");
/*      */       
/* 1276 */       KeyInfo ki = encryptedKey.getKeyInfo();
/* 1277 */       if (ki != null) {
/*      */         try {
/* 1279 */           this._key = ki.getSecretKey();
/*      */         }
/*      */         catch (Exception e) {}
/*      */       }
/*      */       
/* 1284 */       if (this._key == null) {
/* 1285 */         logger.error("XMLCipher::decryptKey called without a KEK and cannot resolve");
/* 1286 */         throw new XMLEncryptionException("Unable to decrypt without a KEK");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1291 */     XMLCipherInput cipherInput = new XMLCipherInput(encryptedKey);
/* 1292 */     byte[] encryptedBytes = cipherInput.getBytes();
/*      */     
/* 1294 */     String jceKeyAlgorithm = JCEMapper.getJCEKeyAlgorithmFromURI(algorithm);
/*      */     
/*      */     Cipher c;
/*      */     
/* 1298 */     if (this._contextCipher == null)
/*      */     {
/*      */ 
/* 1301 */       String jceAlgorithm = JCEMapper.translateURItoJCEID(encryptedKey.getEncryptionMethod().getAlgorithm());
/*      */       
/*      */ 
/*      */ 
/* 1305 */       logger.debug("JCE Algorithm = " + jceAlgorithm);
/*      */       try {
/*      */         Cipher c;
/* 1308 */         if (this._requestedJCEProvider == null) {
/* 1309 */           c = Cipher.getInstance(jceAlgorithm);
/*      */         } else
/* 1311 */           c = Cipher.getInstance(jceAlgorithm, this._requestedJCEProvider);
/*      */       } catch (NoSuchAlgorithmException nsae) { Cipher c;
/* 1313 */         throw new XMLEncryptionException("empty", nsae);
/*      */       } catch (NoSuchProviderException nspre) {
/* 1315 */         throw new XMLEncryptionException("empty", nspre);
/*      */       } catch (NoSuchPaddingException nspae) {
/* 1317 */         throw new XMLEncryptionException("empty", nspae);
/*      */       }
/*      */     } else {
/* 1320 */       c = this._contextCipher;
/*      */     }
/*      */     
/*      */     Key ret;
/*      */     try
/*      */     {
/* 1326 */       c.init(4, this._key);
/* 1327 */       ret = c.unwrap(encryptedBytes, jceKeyAlgorithm, 3);
/*      */     }
/*      */     catch (InvalidKeyException ike) {
/* 1330 */       throw new XMLEncryptionException("empty", ike);
/*      */     } catch (NoSuchAlgorithmException nsae) {
/* 1332 */       throw new XMLEncryptionException("empty", nsae);
/*      */     }
/*      */     
/* 1335 */     logger.debug("Decryption of key type " + algorithm + " OK");
/*      */     
/* 1337 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Key decryptKey(EncryptedKey encryptedKey)
/*      */     throws XMLEncryptionException
/*      */   {
/* 1356 */     return decryptKey(encryptedKey, this._ed.getEncryptionMethod().getAlgorithm());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void removeContent(Node node)
/*      */   {
/* 1366 */     while (node.hasChildNodes()) {
/* 1367 */       node.removeChild(node.getFirstChild());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Document decryptElement(Element element)
/*      */     throws XMLEncryptionException
/*      */   {
/* 1381 */     logger.debug("Decrypting element...");
/*      */     
/* 1383 */     if (this._cipherMode != 2) {
/* 1384 */       logger.error("XMLCipher unexpectedly not in DECRYPT_MODE...");
/*      */     }
/*      */     String octets;
/*      */     try {
/* 1388 */       octets = new String(decryptToByteArray(element), "UTF-8");
/*      */     } catch (UnsupportedEncodingException uee) {
/* 1390 */       throw new XMLEncryptionException("empty", uee);
/*      */     }
/*      */     
/*      */ 
/* 1394 */     logger.debug("Decrypted octets:\n" + octets);
/*      */     
/* 1396 */     Node sourceParent = element.getParentNode();
/*      */     
/* 1398 */     DocumentFragment decryptedFragment = this._serializer.deserialize(octets, sourceParent);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1405 */     if ((sourceParent instanceof Document))
/*      */     {
/*      */ 
/*      */ 
/* 1409 */       this._contextDocument.removeChild(this._contextDocument.getDocumentElement());
/* 1410 */       this._contextDocument.appendChild(decryptedFragment);
/*      */     }
/*      */     else {
/* 1413 */       sourceParent.replaceChild(decryptedFragment, element);
/*      */     }
/*      */     
/*      */ 
/* 1417 */     return this._contextDocument;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Document decryptElementContent(Element element)
/*      */     throws XMLEncryptionException
/*      */   {
/* 1429 */     Element e = (Element)element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "EncryptedData").item(0);
/*      */     
/*      */ 
/*      */ 
/* 1433 */     if (null == e) {
/* 1434 */       throw new XMLEncryptionException("No EncryptedData child element.");
/*      */     }
/*      */     
/* 1437 */     return decryptElement(e);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] decryptToByteArray(Element element)
/*      */     throws XMLEncryptionException
/*      */   {
/* 1455 */     logger.debug("Decrypting to ByteArray...");
/*      */     
/* 1457 */     if (this._cipherMode != 2) {
/* 1458 */       logger.error("XMLCipher unexpectedly not in DECRYPT_MODE...");
/*      */     }
/* 1460 */     EncryptedData encryptedData = this._factory.newEncryptedData(element);
/*      */     
/* 1462 */     if (this._key == null)
/*      */     {
/* 1464 */       KeyInfo ki = encryptedData.getKeyInfo();
/*      */       
/* 1466 */       if (ki != null) {
/*      */         try
/*      */         {
/* 1469 */           ki.registerInternalKeyResolver(new EncryptedKeyResolver(encryptedData.getEncryptionMethod().getAlgorithm(), this._kek));
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 1474 */           this._key = ki.getSecretKey();
/*      */         }
/*      */         catch (KeyResolverException kre) {}
/*      */       }
/*      */       
/*      */ 
/* 1480 */       if (this._key == null) {
/* 1481 */         logger.error("XMLCipher::decryptElement called without a key and unable to resolve");
/*      */         
/* 1483 */         throw new XMLEncryptionException("encryption.nokey");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1488 */     XMLCipherInput cipherInput = new XMLCipherInput(encryptedData);
/* 1489 */     byte[] encryptedBytes = cipherInput.getBytes();
/*      */     
/*      */ 
/*      */ 
/* 1493 */     String jceAlgorithm = JCEMapper.translateURItoJCEID(encryptedData.getEncryptionMethod().getAlgorithm());
/*      */     Cipher c;
/*      */     try
/*      */     {
/*      */       Cipher c;
/* 1498 */       if (this._requestedJCEProvider == null) {
/* 1499 */         c = Cipher.getInstance(jceAlgorithm);
/*      */       } else
/* 1501 */         c = Cipher.getInstance(jceAlgorithm, this._requestedJCEProvider);
/*      */     } catch (NoSuchAlgorithmException nsae) {
/* 1503 */       throw new XMLEncryptionException("empty", nsae);
/*      */     } catch (NoSuchProviderException nspre) {
/* 1505 */       throw new XMLEncryptionException("empty", nspre);
/*      */     } catch (NoSuchPaddingException nspae) {
/* 1507 */       throw new XMLEncryptionException("empty", nspae);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1515 */     int ivLen = c.getBlockSize();
/* 1516 */     byte[] ivBytes = new byte[ivLen];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1523 */     System.arraycopy(encryptedBytes, 0, ivBytes, 0, ivLen);
/* 1524 */     IvParameterSpec iv = new IvParameterSpec(ivBytes);
/*      */     try
/*      */     {
/* 1527 */       c.init(this._cipherMode, this._key, iv);
/*      */     } catch (InvalidKeyException ike) {
/* 1529 */       throw new XMLEncryptionException("empty", ike);
/*      */     } catch (InvalidAlgorithmParameterException iape) {
/* 1531 */       throw new XMLEncryptionException("empty", iape);
/*      */     }
/*      */     
/*      */     byte[] plainBytes;
/*      */     try
/*      */     {
/* 1537 */       plainBytes = c.doFinal(encryptedBytes, ivLen, encryptedBytes.length - ivLen);
/*      */ 
/*      */     }
/*      */     catch (IllegalBlockSizeException ibse)
/*      */     {
/* 1542 */       throw new XMLEncryptionException("empty", ibse);
/*      */     } catch (BadPaddingException bpe) {
/* 1544 */       throw new XMLEncryptionException("empty", bpe);
/*      */     }
/*      */     
/* 1547 */     return plainBytes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptedData createEncryptedData(int type, String value)
/*      */     throws XMLEncryptionException
/*      */   {
/* 1591 */     EncryptedData result = null;
/* 1592 */     CipherData data = null;
/*      */     
/* 1594 */     switch (type) {
/*      */     case 2: 
/* 1596 */       CipherReference cipherReference = this._factory.newCipherReference(value);
/*      */       
/* 1598 */       data = this._factory.newCipherData(type);
/* 1599 */       data.setCipherReference(cipherReference);
/* 1600 */       result = this._factory.newEncryptedData(data);
/* 1601 */       break;
/*      */     case 1: 
/* 1603 */       CipherValue cipherValue = this._factory.newCipherValue(value);
/* 1604 */       data = this._factory.newCipherData(type);
/* 1605 */       data.setCipherValue(cipherValue);
/* 1606 */       result = this._factory.newEncryptedData(data);
/*      */     }
/*      */     
/* 1609 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptedKey createEncryptedKey(int type, String value)
/*      */     throws XMLEncryptionException
/*      */   {
/* 1649 */     EncryptedKey result = null;
/* 1650 */     CipherData data = null;
/*      */     
/* 1652 */     switch (type) {
/*      */     case 2: 
/* 1654 */       CipherReference cipherReference = this._factory.newCipherReference(value);
/*      */       
/* 1656 */       data = this._factory.newCipherData(type);
/* 1657 */       data.setCipherReference(cipherReference);
/* 1658 */       result = this._factory.newEncryptedKey(data);
/* 1659 */       break;
/*      */     case 1: 
/* 1661 */       CipherValue cipherValue = this._factory.newCipherValue(value);
/* 1662 */       data = this._factory.newCipherData(type);
/* 1663 */       data.setCipherValue(cipherValue);
/* 1664 */       result = this._factory.newEncryptedKey(data);
/*      */     }
/*      */     
/* 1667 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AgreementMethod createAgreementMethod(String algorithm)
/*      */   {
/* 1678 */     return this._factory.newAgreementMethod(algorithm);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CipherData createCipherData(int type)
/*      */   {
/* 1690 */     return this._factory.newCipherData(type);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CipherReference createCipherReference(String uri)
/*      */   {
/* 1701 */     return this._factory.newCipherReference(uri);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CipherValue createCipherValue(String value)
/*      */   {
/* 1712 */     return this._factory.newCipherValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptionMethod createEncryptionMethod(String algorithm)
/*      */   {
/* 1722 */     return this._factory.newEncryptionMethod(algorithm);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptionProperties createEncryptionProperties()
/*      */   {
/* 1730 */     return this._factory.newEncryptionProperties();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptionProperty createEncryptionProperty()
/*      */   {
/* 1738 */     return this._factory.newEncryptionProperty();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ReferenceList createReferenceList(int type)
/*      */   {
/* 1747 */     return this._factory.newReferenceList(type);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Transforms createTransforms()
/*      */   {
/* 1760 */     return this._factory.newTransforms();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Transforms createTransforms(Document doc)
/*      */   {
/* 1774 */     return this._factory.newTransforms(doc);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private class Serializer
/*      */   {
/*      */     Serializer() {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     String serialize(Document document)
/*      */       throws Exception
/*      */     {
/* 1812 */       return canonSerialize(document);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     String serialize(Element element)
/*      */       throws Exception
/*      */     {
/* 1827 */       return canonSerialize(element);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     String serialize(NodeList content)
/*      */       throws Exception
/*      */     {
/* 1853 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 1854 */       XMLCipher.this._canon.setWriter(baos);
/* 1855 */       XMLCipher.this._canon.notReset();
/* 1856 */       for (int i = 0; i < content.getLength(); i++) {
/* 1857 */         XMLCipher.this._canon.canonicalizeSubtree(content.item(i));
/*      */       }
/* 1859 */       baos.close();
/* 1860 */       return baos.toString("UTF-8");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     String canonSerialize(Node node)
/*      */       throws Exception
/*      */     {
/* 1870 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 1871 */       XMLCipher.this._canon.setWriter(baos);
/* 1872 */       XMLCipher.this._canon.notReset();
/* 1873 */       XMLCipher.this._canon.canonicalizeSubtree(node);
/* 1874 */       baos.close();
/* 1875 */       return baos.toString("UTF-8");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     DocumentFragment deserialize(String source, Node ctx)
/*      */       throws XMLEncryptionException
/*      */     {
/* 1886 */       String tagname = "fragment";
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1891 */       StringBuffer sb = new StringBuffer();
/* 1892 */       sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><fragment");
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1897 */       Node wk = ctx;
/*      */       
/* 1899 */       while (wk != null)
/*      */       {
/* 1901 */         NamedNodeMap atts = wk.getAttributes();
/*      */         int length;
/* 1903 */         int length; if (atts != null) {
/* 1904 */           length = atts.getLength();
/*      */         } else {
/* 1906 */           length = 0;
/*      */         }
/* 1908 */         for (int i = 0; i < length; i++) {
/* 1909 */           Node att = atts.item(i);
/* 1910 */           if ((att.getNodeName().startsWith("xmlns:")) || (att.getNodeName().equals("xmlns")))
/*      */           {
/*      */ 
/*      */ 
/* 1914 */             Node p = ctx;
/* 1915 */             boolean found = false;
/* 1916 */             while (p != wk) {
/* 1917 */               NamedNodeMap tstAtts = p.getAttributes();
/* 1918 */               if ((tstAtts != null) && (tstAtts.getNamedItem(att.getNodeName()) != null))
/*      */               {
/* 1920 */                 found = true;
/* 1921 */                 break;
/*      */               }
/* 1923 */               p = p.getParentNode();
/*      */             }
/* 1925 */             if (!found)
/*      */             {
/*      */ 
/* 1928 */               sb.append(" " + att.getNodeName() + "=\"" + att.getNodeValue() + "\"");
/*      */             }
/*      */           }
/*      */         }
/*      */         
/* 1933 */         wk = wk.getParentNode();
/*      */       }
/* 1935 */       sb.append(">" + source + "</" + "fragment" + ">");
/* 1936 */       String fragment = sb.toString();
/*      */       DocumentFragment result;
/*      */       try {
/* 1939 */         DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/*      */         
/* 1941 */         dbf.setNamespaceAware(true);
/* 1942 */         dbf.setAttribute("http://xml.org/sax/features/namespaces", Boolean.TRUE);
/* 1943 */         DocumentBuilder db = dbf.newDocumentBuilder();
/* 1944 */         Document d = db.parse(new InputSource(new StringReader(fragment)));
/*      */         
/*      */ 
/* 1947 */         Element fragElt = (Element)XMLCipher.this._contextDocument.importNode(d.getDocumentElement(), true);
/*      */         
/* 1949 */         result = XMLCipher.this._contextDocument.createDocumentFragment();
/* 1950 */         Node child = fragElt.getFirstChild();
/* 1951 */         while (child != null) {
/* 1952 */           fragElt.removeChild(child);
/* 1953 */           result.appendChild(child);
/* 1954 */           child = fragElt.getFirstChild();
/*      */         }
/*      */       }
/*      */       catch (SAXException se)
/*      */       {
/* 1959 */         throw new XMLEncryptionException("empty", se);
/*      */       } catch (ParserConfigurationException pce) {
/* 1961 */         throw new XMLEncryptionException("empty", pce);
/*      */       } catch (IOException ioe) {
/* 1963 */         throw new XMLEncryptionException("empty", ioe);
/*      */       }
/*      */       
/* 1966 */       return result;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private class Factory
/*      */   {
/*      */     private Factory() {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     AgreementMethod newAgreementMethod(String algorithm)
/*      */     {
/* 1982 */       return new AgreementMethodImpl(algorithm);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     CipherData newCipherData(int type)
/*      */     {
/* 1991 */       return new CipherDataImpl(type);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     CipherReference newCipherReference(String uri)
/*      */     {
/* 2000 */       return new CipherReferenceImpl(uri);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     CipherValue newCipherValue(String value)
/*      */     {
/* 2009 */       return new CipherValueImpl(value);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     EncryptedData newEncryptedData(CipherData data)
/*      */     {
/* 2025 */       return new EncryptedDataImpl(data);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     EncryptedKey newEncryptedKey(CipherData data)
/*      */     {
/* 2034 */       return new EncryptedKeyImpl(data);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     EncryptionMethod newEncryptionMethod(String algorithm)
/*      */     {
/* 2043 */       return new EncryptionMethodImpl(algorithm);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     EncryptionProperties newEncryptionProperties()
/*      */     {
/* 2051 */       return new EncryptionPropertiesImpl();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     EncryptionProperty newEncryptionProperty()
/*      */     {
/* 2059 */       return new EncryptionPropertyImpl();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     ReferenceList newReferenceList(int type)
/*      */     {
/* 2068 */       return new ReferenceListImpl(type);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     Transforms newTransforms()
/*      */     {
/* 2076 */       return new TransformsImpl();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Transforms newTransforms(Document doc)
/*      */     {
/* 2085 */       return new TransformsImpl(doc);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     AgreementMethod newAgreementMethod(Element element)
/*      */       throws XMLEncryptionException
/*      */     {
/* 2107 */       if (null == element) {
/* 2108 */         throw new NullPointerException("element is null");
/*      */       }
/*      */       
/* 2111 */       String algorithm = element.getAttributeNS(null, "Algorithm");
/*      */       
/* 2113 */       AgreementMethod result = newAgreementMethod(algorithm);
/*      */       
/* 2115 */       Element kaNonceElement = (Element)element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "KA-Nonce").item(0);
/*      */       
/*      */ 
/* 2118 */       if (null != kaNonceElement) {
/* 2119 */         result.setKANonce(kaNonceElement.getNodeValue().getBytes());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2127 */       Element originatorKeyInfoElement = (Element)element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "OriginatorKeyInfo").item(0);
/*      */       
/*      */ 
/*      */ 
/* 2131 */       if (null != originatorKeyInfoElement) {
/*      */         try {
/* 2133 */           result.setOriginatorKeyInfo(new KeyInfo(originatorKeyInfoElement, null));
/*      */         }
/*      */         catch (XMLSecurityException xse) {
/* 2136 */           throw new XMLEncryptionException("empty", xse);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2142 */       Element recipientKeyInfoElement = (Element)element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "RecipientKeyInfo").item(0);
/*      */       
/*      */ 
/*      */ 
/* 2146 */       if (null != recipientKeyInfoElement) {
/*      */         try {
/* 2148 */           result.setRecipientKeyInfo(new KeyInfo(recipientKeyInfoElement, null));
/*      */         }
/*      */         catch (XMLSecurityException xse) {
/* 2151 */           throw new XMLEncryptionException("empty", xse);
/*      */         }
/*      */       }
/*      */       
/* 2155 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     CipherData newCipherData(Element element)
/*      */       throws XMLEncryptionException
/*      */     {
/* 2173 */       if (null == element) {
/* 2174 */         throw new NullPointerException("element is null");
/*      */       }
/*      */       
/* 2177 */       int type = 0;
/* 2178 */       Element e = null;
/* 2179 */       if (element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "CipherValue").getLength() > 0)
/*      */       {
/*      */ 
/* 2182 */         type = 1;
/* 2183 */         e = (Element)element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "CipherValue").item(0);
/*      */ 
/*      */       }
/* 2186 */       else if (element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "CipherReference").getLength() > 0)
/*      */       {
/*      */ 
/* 2189 */         type = 2;
/* 2190 */         e = (Element)element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "CipherReference").item(0);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2195 */       CipherData result = newCipherData(type);
/* 2196 */       if (type == 1) {
/* 2197 */         result.setCipherValue(newCipherValue(e));
/* 2198 */       } else if (type == 2) {
/* 2199 */         result.setCipherReference(newCipherReference(e));
/*      */       }
/*      */       
/* 2202 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     CipherReference newCipherReference(Element element)
/*      */       throws XMLEncryptionException
/*      */     {
/* 2221 */       Attr URIAttr = element.getAttributeNodeNS(null, "URI");
/*      */       
/* 2223 */       CipherReference result = new CipherReferenceImpl(URIAttr);
/*      */       
/*      */ 
/*      */ 
/* 2227 */       NodeList transformsElements = element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "Transforms");
/*      */       
/*      */ 
/* 2230 */       Element transformsElement = (Element)transformsElements.item(0);
/*      */       
/*      */ 
/* 2233 */       if (transformsElement != null) {
/* 2234 */         XMLCipher.logger.debug("Creating a DSIG based Transforms element");
/*      */         try {
/* 2236 */           result.setTransforms(new TransformsImpl(transformsElement));
/*      */         }
/*      */         catch (XMLSignatureException xse) {
/* 2239 */           throw new XMLEncryptionException("empty", xse);
/*      */         } catch (InvalidTransformException ite) {
/* 2241 */           throw new XMLEncryptionException("empty", ite);
/*      */         } catch (XMLSecurityException xse) {
/* 2243 */           throw new XMLEncryptionException("empty", xse);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 2248 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     CipherValue newCipherValue(Element element)
/*      */     {
/* 2257 */       String value = XMLUtils.getFullTextChildrenFromElement(element);
/*      */       
/* 2259 */       CipherValue result = newCipherValue(value);
/*      */       
/* 2261 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     EncryptedData newEncryptedData(Element element)
/*      */       throws XMLEncryptionException
/*      */     {
/* 2291 */       EncryptedData result = null;
/*      */       
/* 2293 */       NodeList dataElements = element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "CipherData");
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2300 */       Element dataElement = (Element)dataElements.item(dataElements.getLength() - 1);
/*      */       
/*      */ 
/* 2303 */       CipherData data = newCipherData(dataElement);
/*      */       
/* 2305 */       result = newEncryptedData(data);
/*      */       
/* 2307 */       result.setId(element.getAttributeNS(null, "Id"));
/*      */       
/* 2309 */       result.setType(element.getAttributeNS(null, "Type"));
/*      */       
/* 2311 */       result.setMimeType(element.getAttributeNS(null, "MimeType"));
/*      */       
/* 2313 */       result.setEncoding(element.getAttributeNS(null, "Encoding"));
/*      */       
/*      */ 
/* 2316 */       Element encryptionMethodElement = (Element)element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "EncryptionMethod").item(0);
/*      */       
/*      */ 
/*      */ 
/* 2320 */       if (null != encryptionMethodElement) {
/* 2321 */         result.setEncryptionMethod(newEncryptionMethod(encryptionMethodElement));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2328 */       Element keyInfoElement = (Element)element.getElementsByTagNameNS("http://www.w3.org/2000/09/xmldsig#", "KeyInfo").item(0);
/*      */       
/*      */ 
/* 2331 */       if (null != keyInfoElement) {
/*      */         try {
/* 2333 */           result.setKeyInfo(new KeyInfo(keyInfoElement, null));
/*      */         } catch (XMLSecurityException xse) {
/* 2335 */           throw new XMLEncryptionException("Error loading Key Info", xse);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2341 */       Element encryptionPropertiesElement = (Element)element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "EncryptionProperties").item(0);
/*      */       
/*      */ 
/*      */ 
/* 2345 */       if (null != encryptionPropertiesElement) {
/* 2346 */         result.setEncryptionProperties(newEncryptionProperties(encryptionPropertiesElement));
/*      */       }
/*      */       
/*      */ 
/* 2350 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     EncryptedKey newEncryptedKey(Element element)
/*      */       throws XMLEncryptionException
/*      */     {
/* 2386 */       EncryptedKey result = null;
/* 2387 */       NodeList dataElements = element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "CipherData");
/*      */       
/*      */ 
/* 2390 */       Element dataElement = (Element)dataElements.item(dataElements.getLength() - 1);
/*      */       
/*      */ 
/* 2393 */       CipherData data = newCipherData(dataElement);
/* 2394 */       result = newEncryptedKey(data);
/*      */       
/* 2396 */       result.setId(element.getAttributeNS(null, "Id"));
/*      */       
/* 2398 */       result.setType(element.getAttributeNS(null, "Type"));
/*      */       
/* 2400 */       result.setMimeType(element.getAttributeNS(null, "MimeType"));
/*      */       
/* 2402 */       result.setEncoding(element.getAttributeNS(null, "Encoding"));
/*      */       
/* 2404 */       result.setRecipient(element.getAttributeNS(null, "Recipient"));
/*      */       
/*      */ 
/* 2407 */       Element encryptionMethodElement = (Element)element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "EncryptionMethod").item(0);
/*      */       
/*      */ 
/*      */ 
/* 2411 */       if (null != encryptionMethodElement) {
/* 2412 */         result.setEncryptionMethod(newEncryptionMethod(encryptionMethodElement));
/*      */       }
/*      */       
/*      */ 
/* 2416 */       Element keyInfoElement = (Element)element.getElementsByTagNameNS("http://www.w3.org/2000/09/xmldsig#", "KeyInfo").item(0);
/*      */       
/*      */ 
/* 2419 */       if (null != keyInfoElement) {
/*      */         try {
/* 2421 */           result.setKeyInfo(new KeyInfo(keyInfoElement, null));
/*      */         } catch (XMLSecurityException xse) {
/* 2423 */           throw new XMLEncryptionException("Error loading Key Info", xse);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2429 */       Element encryptionPropertiesElement = (Element)element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "EncryptionProperties").item(0);
/*      */       
/*      */ 
/*      */ 
/* 2433 */       if (null != encryptionPropertiesElement) {
/* 2434 */         result.setEncryptionProperties(newEncryptionProperties(encryptionPropertiesElement));
/*      */       }
/*      */       
/*      */ 
/* 2438 */       Element referenceListElement = (Element)element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "ReferenceList").item(0);
/*      */       
/*      */ 
/*      */ 
/* 2442 */       if (null != referenceListElement) {
/* 2443 */         result.setReferenceList(newReferenceList(referenceListElement));
/*      */       }
/*      */       
/* 2446 */       Element carriedNameElement = (Element)element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "CarriedKeyName").item(0);
/*      */       
/*      */ 
/*      */ 
/* 2450 */       if (null != carriedNameElement) {
/* 2451 */         result.setCarriedName(carriedNameElement.getFirstChild().getNodeValue());
/*      */       }
/*      */       
/*      */ 
/* 2455 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     EncryptionMethod newEncryptionMethod(Element element)
/*      */     {
/* 2472 */       String algorithm = element.getAttributeNS(null, "Algorithm");
/*      */       
/* 2474 */       EncryptionMethod result = newEncryptionMethod(algorithm);
/*      */       
/* 2476 */       Element keySizeElement = (Element)element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "KeySize").item(0);
/*      */       
/*      */ 
/*      */ 
/* 2480 */       if (null != keySizeElement) {
/* 2481 */         result.setKeySize(Integer.valueOf(keySizeElement.getFirstChild().getNodeValue()).intValue());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2486 */       Element oaepParamsElement = (Element)element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "OAEPparams").item(0);
/*      */       
/*      */ 
/*      */ 
/* 2490 */       if (null != oaepParamsElement) {
/* 2491 */         result.setOAEPparams(oaepParamsElement.getNodeValue().getBytes());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2498 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     EncryptionProperties newEncryptionProperties(Element element)
/*      */     {
/* 2514 */       EncryptionProperties result = newEncryptionProperties();
/*      */       
/* 2516 */       result.setId(element.getAttributeNS(null, "Id"));
/*      */       
/*      */ 
/* 2519 */       NodeList encryptionPropertyList = element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "EncryptionProperty");
/*      */       
/*      */ 
/*      */ 
/* 2523 */       for (int i = 0; i < encryptionPropertyList.getLength(); i++) {
/* 2524 */         Node n = encryptionPropertyList.item(i);
/* 2525 */         if (null != n) {
/* 2526 */           result.addEncryptionProperty(newEncryptionProperty((Element)n));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 2531 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     EncryptionProperty newEncryptionProperty(Element element)
/*      */     {
/* 2549 */       EncryptionProperty result = newEncryptionProperty();
/*      */       
/* 2551 */       result.setTarget(element.getAttributeNS(null, "Target"));
/*      */       
/* 2553 */       result.setId(element.getAttributeNS(null, "Id"));
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2561 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     ReferenceList newReferenceList(Element element)
/*      */     {
/* 2578 */       int type = 0;
/* 2579 */       if (null != element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "DataReference").item(0))
/*      */       {
/*      */ 
/* 2582 */         type = 1;
/* 2583 */       } else if (null != element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "KeyReference").item(0))
/*      */       {
/*      */ 
/* 2586 */         type = 2;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2591 */       ReferenceList result = new ReferenceListImpl(type);
/* 2592 */       NodeList list = null;
/* 2593 */       switch (type) {
/*      */       case 1: 
/* 2595 */         list = element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "DataReference");
/*      */         
/*      */ 
/* 2598 */         for (int i = 0; i < list.getLength(); i++) {
/* 2599 */           String uri = ((Element)list.item(i)).getAttribute("URI");
/* 2600 */           result.add(result.newDataReference(uri));
/*      */         }
/* 2602 */         break;
/*      */       case 2: 
/* 2604 */         list = element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "KeyReference");
/*      */         
/*      */ 
/* 2607 */         for (int i = 0; i < list.getLength(); i++) {
/* 2608 */           String uri = ((Element)list.item(i)).getAttribute("URI");
/* 2609 */           result.add(result.newKeyReference(uri));
/*      */         }
/*      */       }
/*      */       
/* 2613 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Transforms newTransforms(Element element)
/*      */     {
/* 2622 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Element toElement(AgreementMethod agreementMethod)
/*      */     {
/* 2631 */       return ((AgreementMethodImpl)agreementMethod).toElement();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Element toElement(CipherData cipherData)
/*      */     {
/* 2640 */       return ((CipherDataImpl)cipherData).toElement();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Element toElement(CipherReference cipherReference)
/*      */     {
/* 2649 */       return ((CipherReferenceImpl)cipherReference).toElement();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Element toElement(CipherValue cipherValue)
/*      */     {
/* 2658 */       return ((CipherValueImpl)cipherValue).toElement();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Element toElement(EncryptedData encryptedData)
/*      */     {
/* 2667 */       return ((EncryptedDataImpl)encryptedData).toElement();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Element toElement(EncryptedKey encryptedKey)
/*      */     {
/* 2676 */       return ((EncryptedKeyImpl)encryptedKey).toElement();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Element toElement(EncryptionMethod encryptionMethod)
/*      */     {
/* 2685 */       return ((EncryptionMethodImpl)encryptionMethod).toElement();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Element toElement(EncryptionProperties encryptionProperties)
/*      */     {
/* 2694 */       return ((EncryptionPropertiesImpl)encryptionProperties).toElement();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Element toElement(EncryptionProperty encryptionProperty)
/*      */     {
/* 2703 */       return ((EncryptionPropertyImpl)encryptionProperty).toElement();
/*      */     }
/*      */     
/*      */     Element toElement(ReferenceList referenceList) {
/* 2707 */       return ((ReferenceListImpl)referenceList).toElement();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Element toElement(Transforms transforms)
/*      */     {
/* 2716 */       return ((TransformsImpl)transforms).toElement();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private class AgreementMethodImpl
/*      */       implements AgreementMethod
/*      */     {
/* 2731 */       private byte[] kaNonce = null;
/* 2732 */       private List agreementMethodInformation = null;
/* 2733 */       private KeyInfo originatorKeyInfo = null;
/* 2734 */       private KeyInfo recipientKeyInfo = null;
/* 2735 */       private String algorithmURI = null;
/*      */       
/*      */ 
/*      */ 
/*      */       public AgreementMethodImpl(String algorithm)
/*      */       {
/* 2741 */         this.agreementMethodInformation = new LinkedList();
/* 2742 */         URI tmpAlgorithm = null;
/*      */         try {
/* 2744 */           tmpAlgorithm = new URI(algorithm);
/*      */         }
/*      */         catch (URI.MalformedURIException fmue) {}
/*      */         
/* 2748 */         this.algorithmURI = tmpAlgorithm.toString();
/*      */       }
/*      */       
/*      */       public byte[] getKANonce()
/*      */       {
/* 2753 */         return this.kaNonce;
/*      */       }
/*      */       
/*      */       public void setKANonce(byte[] kanonce)
/*      */       {
/* 2758 */         this.kaNonce = kanonce;
/*      */       }
/*      */       
/*      */       public Iterator getAgreementMethodInformation()
/*      */       {
/* 2763 */         return this.agreementMethodInformation.iterator();
/*      */       }
/*      */       
/*      */       public void addAgreementMethodInformation(Element info)
/*      */       {
/* 2768 */         this.agreementMethodInformation.add(info);
/*      */       }
/*      */       
/*      */       public void revoveAgreementMethodInformation(Element info)
/*      */       {
/* 2773 */         this.agreementMethodInformation.remove(info);
/*      */       }
/*      */       
/*      */       public KeyInfo getOriginatorKeyInfo()
/*      */       {
/* 2778 */         return this.originatorKeyInfo;
/*      */       }
/*      */       
/*      */       public void setOriginatorKeyInfo(KeyInfo keyInfo)
/*      */       {
/* 2783 */         this.originatorKeyInfo = keyInfo;
/*      */       }
/*      */       
/*      */       public KeyInfo getRecipientKeyInfo()
/*      */       {
/* 2788 */         return this.recipientKeyInfo;
/*      */       }
/*      */       
/*      */       public void setRecipientKeyInfo(KeyInfo keyInfo)
/*      */       {
/* 2793 */         this.recipientKeyInfo = keyInfo;
/*      */       }
/*      */       
/*      */       public String getAlgorithm()
/*      */       {
/* 2798 */         return this.algorithmURI;
/*      */       }
/*      */       
/*      */       public void setAlgorithm(String algorithm)
/*      */       {
/* 2803 */         URI tmpAlgorithm = null;
/*      */         try {
/* 2805 */           tmpAlgorithm = new URI(algorithm);
/*      */         }
/*      */         catch (URI.MalformedURIException mfue) {}
/*      */         
/* 2809 */         this.algorithmURI = tmpAlgorithm.toString();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       Element toElement()
/*      */       {
/* 2824 */         Element result = ElementProxy.createElementForFamily(XMLCipher.this._contextDocument, "http://www.w3.org/2001/04/xmlenc#", "AgreementMethod");
/*      */         
/*      */ 
/*      */ 
/* 2828 */         result.setAttributeNS(null, "Algorithm", this.algorithmURI);
/*      */         
/* 2830 */         if (null != this.kaNonce) {
/* 2831 */           result.appendChild(ElementProxy.createElementForFamily(XMLCipher.this._contextDocument, "http://www.w3.org/2001/04/xmlenc#", "KA-Nonce")).appendChild(XMLCipher.this._contextDocument.createTextNode(new String(this.kaNonce)));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2838 */         if (!this.agreementMethodInformation.isEmpty()) {
/* 2839 */           Iterator itr = this.agreementMethodInformation.iterator();
/* 2840 */           while (itr.hasNext()) {
/* 2841 */             result.appendChild((Element)itr.next());
/*      */           }
/*      */         }
/* 2844 */         if (null != this.originatorKeyInfo) {
/* 2845 */           result.appendChild(this.originatorKeyInfo.getElement());
/*      */         }
/* 2847 */         if (null != this.recipientKeyInfo) {
/* 2848 */           result.appendChild(this.recipientKeyInfo.getElement());
/*      */         }
/*      */         
/* 2851 */         return result;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private class CipherDataImpl
/*      */       implements CipherData
/*      */     {
/*      */       private static final String valueMessage = "Data type is reference type.";
/*      */       
/*      */ 
/*      */       private static final String referenceMessage = "Data type is value type.";
/*      */       
/*      */ 
/* 2867 */       private CipherValue cipherValue = null;
/* 2868 */       private CipherReference cipherReference = null;
/* 2869 */       private int cipherType = Integer.MIN_VALUE;
/*      */       
/*      */ 
/*      */ 
/*      */       public CipherDataImpl(int type)
/*      */       {
/* 2875 */         this.cipherType = type;
/*      */       }
/*      */       
/*      */       public CipherValue getCipherValue()
/*      */       {
/* 2880 */         return this.cipherValue;
/*      */       }
/*      */       
/*      */ 
/*      */       public void setCipherValue(CipherValue value)
/*      */         throws XMLEncryptionException
/*      */       {
/* 2887 */         if (this.cipherType == 2) {
/* 2888 */           throw new XMLEncryptionException("empty", new UnsupportedOperationException("Data type is reference type."));
/*      */         }
/*      */         
/*      */ 
/* 2892 */         this.cipherValue = value;
/*      */       }
/*      */       
/*      */       public CipherReference getCipherReference()
/*      */       {
/* 2897 */         return this.cipherReference;
/*      */       }
/*      */       
/*      */       public void setCipherReference(CipherReference reference)
/*      */         throws XMLEncryptionException
/*      */       {
/* 2903 */         if (this.cipherType == 1) {
/* 2904 */           throw new XMLEncryptionException("empty", new UnsupportedOperationException("Data type is value type."));
/*      */         }
/*      */         
/*      */ 
/* 2908 */         this.cipherReference = reference;
/*      */       }
/*      */       
/*      */       public int getDataType()
/*      */       {
/* 2913 */         return this.cipherType;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       Element toElement()
/*      */       {
/* 2924 */         Element result = ElementProxy.createElementForFamily(XMLCipher.this._contextDocument, "http://www.w3.org/2001/04/xmlenc#", "CipherData");
/*      */         
/*      */ 
/*      */ 
/* 2928 */         if (this.cipherType == 1) {
/* 2929 */           result.appendChild(((XMLCipher.Factory.CipherValueImpl)this.cipherValue).toElement());
/*      */         }
/* 2931 */         else if (this.cipherType == 2) {
/* 2932 */           result.appendChild(((XMLCipher.Factory.CipherReferenceImpl)this.cipherReference).toElement());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 2938 */         return result;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private class CipherReferenceImpl
/*      */       implements CipherReference
/*      */     {
/* 2950 */       private String referenceURI = null;
/* 2951 */       private Transforms referenceTransforms = null;
/* 2952 */       private Attr referenceNode = null;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       public CipherReferenceImpl(String uri)
/*      */       {
/* 2959 */         this.referenceURI = uri;
/* 2960 */         this.referenceNode = null;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public CipherReferenceImpl(Attr uri)
/*      */       {
/* 2967 */         this.referenceURI = uri.getNodeValue();
/* 2968 */         this.referenceNode = uri;
/*      */       }
/*      */       
/*      */       public String getURI()
/*      */       {
/* 2973 */         return this.referenceURI;
/*      */       }
/*      */       
/*      */       public Attr getURIAsAttr()
/*      */       {
/* 2978 */         return this.referenceNode;
/*      */       }
/*      */       
/*      */       public Transforms getTransforms()
/*      */       {
/* 2983 */         return this.referenceTransforms;
/*      */       }
/*      */       
/*      */       public void setTransforms(Transforms transforms)
/*      */       {
/* 2988 */         this.referenceTransforms = transforms;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       Element toElement()
/*      */       {
/* 2999 */         Element result = ElementProxy.createElementForFamily(XMLCipher.this._contextDocument, "http://www.w3.org/2001/04/xmlenc#", "CipherReference");
/*      */         
/*      */ 
/*      */ 
/* 3003 */         result.setAttributeNS(null, "URI", this.referenceURI);
/*      */         
/* 3005 */         if (null != this.referenceTransforms) {
/* 3006 */           result.appendChild(((XMLCipher.Factory.TransformsImpl)this.referenceTransforms).toElement());
/*      */         }
/*      */         
/*      */ 
/* 3010 */         return result;
/*      */       }
/*      */     }
/*      */     
/*      */     private class CipherValueImpl implements CipherValue {
/* 3015 */       private String cipherValue = null;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       public CipherValueImpl(String value)
/*      */       {
/* 3026 */         this.cipherValue = value;
/*      */       }
/*      */       
/*      */       public String getValue()
/*      */       {
/* 3031 */         return this.cipherValue;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       public void setValue(String value)
/*      */       {
/* 3041 */         this.cipherValue = value;
/*      */       }
/*      */       
/*      */       Element toElement() {
/* 3045 */         Element result = ElementProxy.createElementForFamily(XMLCipher.this._contextDocument, "http://www.w3.org/2001/04/xmlenc#", "CipherValue");
/*      */         
/*      */ 
/* 3048 */         result.appendChild(XMLCipher.this._contextDocument.createTextNode(this.cipherValue));
/*      */         
/*      */ 
/* 3051 */         return result;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private class EncryptedDataImpl
/*      */       extends XMLCipher.Factory.EncryptedTypeImpl
/*      */       implements EncryptedData
/*      */     {
/*      */       public EncryptedDataImpl(CipherData data)
/*      */       {
/* 3080 */         super(data);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       Element toElement()
/*      */       {
/* 3103 */         Element result = ElementProxy.createElementForFamily(XMLCipher.this._contextDocument, "http://www.w3.org/2001/04/xmlenc#", "EncryptedData");
/*      */         
/*      */ 
/*      */ 
/* 3107 */         if (null != super.getId()) {
/* 3108 */           result.setAttributeNS(null, "Id", super.getId());
/*      */         }
/*      */         
/* 3111 */         if (null != super.getType()) {
/* 3112 */           result.setAttributeNS(null, "Type", super.getType());
/*      */         }
/*      */         
/* 3115 */         if (null != super.getMimeType()) {
/* 3116 */           result.setAttributeNS(null, "MimeType", super.getMimeType());
/*      */         }
/*      */         
/*      */ 
/* 3120 */         if (null != super.getEncoding()) {
/* 3121 */           result.setAttributeNS(null, "Encoding", super.getEncoding());
/*      */         }
/*      */         
/*      */ 
/* 3125 */         if (null != super.getEncryptionMethod()) {
/* 3126 */           result.appendChild(((XMLCipher.Factory.EncryptionMethodImpl)super.getEncryptionMethod()).toElement());
/*      */         }
/*      */         
/* 3129 */         if (null != super.getKeyInfo()) {
/* 3130 */           result.appendChild(super.getKeyInfo().getElement());
/*      */         }
/*      */         
/* 3133 */         result.appendChild(((XMLCipher.Factory.CipherDataImpl)super.getCipherData()).toElement());
/*      */         
/* 3135 */         if (null != super.getEncryptionProperties()) {
/* 3136 */           result.appendChild(((XMLCipher.Factory.EncryptionPropertiesImpl)super.getEncryptionProperties()).toElement());
/*      */         }
/*      */         
/*      */ 
/* 3140 */         return result;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private class EncryptedKeyImpl
/*      */       extends XMLCipher.Factory.EncryptedTypeImpl
/*      */       implements EncryptedKey
/*      */     {
/* 3171 */       private String keyRecipient = null;
/* 3172 */       private ReferenceList referenceList = null;
/* 3173 */       private String carriedName = null;
/*      */       
/*      */ 
/*      */ 
/*      */       public EncryptedKeyImpl(CipherData data)
/*      */       {
/* 3179 */         super(data);
/*      */       }
/*      */       
/*      */       public String getRecipient()
/*      */       {
/* 3184 */         return this.keyRecipient;
/*      */       }
/*      */       
/*      */       public void setRecipient(String recipient)
/*      */       {
/* 3189 */         this.keyRecipient = recipient;
/*      */       }
/*      */       
/*      */       public ReferenceList getReferenceList()
/*      */       {
/* 3194 */         return this.referenceList;
/*      */       }
/*      */       
/*      */       public void setReferenceList(ReferenceList list)
/*      */       {
/* 3199 */         this.referenceList = list;
/*      */       }
/*      */       
/*      */       public String getCarriedName()
/*      */       {
/* 3204 */         return this.carriedName;
/*      */       }
/*      */       
/*      */       public void setCarriedName(String name)
/*      */       {
/* 3209 */         this.carriedName = name;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       Element toElement()
/*      */       {
/* 3238 */         Element result = ElementProxy.createElementForFamily(XMLCipher.this._contextDocument, "http://www.w3.org/2001/04/xmlenc#", "EncryptedKey");
/*      */         
/*      */ 
/*      */ 
/* 3242 */         if (null != super.getId()) {
/* 3243 */           result.setAttributeNS(null, "Id", super.getId());
/*      */         }
/*      */         
/* 3246 */         if (null != super.getType()) {
/* 3247 */           result.setAttributeNS(null, "Type", super.getType());
/*      */         }
/*      */         
/* 3250 */         if (null != super.getMimeType()) {
/* 3251 */           result.setAttributeNS(null, "MimeType", super.getMimeType());
/*      */         }
/*      */         
/* 3254 */         if (null != super.getEncoding()) {
/* 3255 */           result.setAttributeNS(null, "Encoding", super.getEncoding());
/*      */         }
/*      */         
/* 3258 */         if (null != getRecipient()) {
/* 3259 */           result.setAttributeNS(null, "Recipient", getRecipient());
/*      */         }
/*      */         
/* 3262 */         if (null != super.getEncryptionMethod()) {
/* 3263 */           result.appendChild(((XMLCipher.Factory.EncryptionMethodImpl)super.getEncryptionMethod()).toElement());
/*      */         }
/*      */         
/* 3266 */         if (null != super.getKeyInfo()) {
/* 3267 */           result.appendChild(super.getKeyInfo().getElement());
/*      */         }
/* 3269 */         result.appendChild(((XMLCipher.Factory.CipherDataImpl)super.getCipherData()).toElement());
/*      */         
/* 3271 */         if (null != super.getEncryptionProperties()) {
/* 3272 */           result.appendChild(((XMLCipher.Factory.EncryptionPropertiesImpl)super.getEncryptionProperties()).toElement());
/*      */         }
/*      */         
/* 3275 */         if ((this.referenceList != null) && (!this.referenceList.isEmpty())) {
/* 3276 */           result.appendChild(((XMLCipher.Factory.ReferenceListImpl)getReferenceList()).toElement());
/*      */         }
/*      */         
/* 3279 */         if (null != this.carriedName) {
/* 3280 */           Element element = ElementProxy.createElementForFamily(XMLCipher.this._contextDocument, "http://www.w3.org/2001/04/xmlenc#", "CarriedKeyName");
/*      */           
/*      */ 
/*      */ 
/* 3284 */           Node node = XMLCipher.this._contextDocument.createTextNode(this.carriedName);
/* 3285 */           element.appendChild(node);
/* 3286 */           result.appendChild(element);
/*      */         }
/*      */         
/* 3289 */         return result;
/*      */       }
/*      */     }
/*      */     
/*      */     private abstract class EncryptedTypeImpl {
/* 3294 */       private String id = null;
/* 3295 */       private String type = null;
/* 3296 */       private String mimeType = null;
/* 3297 */       private String encoding = null;
/* 3298 */       private EncryptionMethod encryptionMethod = null;
/* 3299 */       private KeyInfo keyInfo = null;
/* 3300 */       private CipherData cipherData = null;
/* 3301 */       private EncryptionProperties encryptionProperties = null;
/*      */       
/*      */       protected EncryptedTypeImpl(CipherData data) {
/* 3304 */         this.cipherData = data;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public String getId()
/*      */       {
/* 3311 */         return this.id;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public void setId(String id)
/*      */       {
/* 3318 */         this.id = id;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public String getType()
/*      */       {
/* 3325 */         return this.type;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public void setType(String type)
/*      */       {
/* 3332 */         if ((type == null) || (type.length() == 0)) {
/* 3333 */           this.type = null;
/*      */         } else {
/* 3335 */           URI tmpType = null;
/*      */           try {
/* 3337 */             tmpType = new URI(type);
/*      */           }
/*      */           catch (URI.MalformedURIException mfue) {}
/*      */           
/* 3341 */           this.type = tmpType.toString();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public String getMimeType()
/*      */       {
/* 3349 */         return this.mimeType;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public void setMimeType(String type)
/*      */       {
/* 3356 */         this.mimeType = type;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public String getEncoding()
/*      */       {
/* 3363 */         return this.encoding;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public void setEncoding(String encoding)
/*      */       {
/* 3370 */         if ((encoding == null) || (encoding.length() == 0)) {
/* 3371 */           this.encoding = null;
/*      */         } else {
/* 3373 */           URI tmpEncoding = null;
/*      */           try {
/* 3375 */             tmpEncoding = new URI(encoding);
/*      */           }
/*      */           catch (URI.MalformedURIException mfue) {}
/*      */           
/* 3379 */           this.encoding = tmpEncoding.toString();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public EncryptionMethod getEncryptionMethod()
/*      */       {
/* 3387 */         return this.encryptionMethod;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public void setEncryptionMethod(EncryptionMethod method)
/*      */       {
/* 3394 */         this.encryptionMethod = method;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public KeyInfo getKeyInfo()
/*      */       {
/* 3401 */         return this.keyInfo;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public void setKeyInfo(KeyInfo info)
/*      */       {
/* 3408 */         this.keyInfo = info;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public CipherData getCipherData()
/*      */       {
/* 3415 */         return this.cipherData;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public EncryptionProperties getEncryptionProperties()
/*      */       {
/* 3422 */         return this.encryptionProperties;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       public void setEncryptionProperties(EncryptionProperties properties)
/*      */       {
/* 3430 */         this.encryptionProperties = properties;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private class EncryptionMethodImpl
/*      */       implements EncryptionMethod
/*      */     {
/* 3443 */       private String algorithm = null;
/* 3444 */       private int keySize = Integer.MIN_VALUE;
/* 3445 */       private byte[] oaepParams = null;
/* 3446 */       private List encryptionMethodInformation = null;
/*      */       
/*      */ 
/*      */ 
/*      */       public EncryptionMethodImpl(String algorithm)
/*      */       {
/* 3452 */         URI tmpAlgorithm = null;
/*      */         try {
/* 3454 */           tmpAlgorithm = new URI(algorithm);
/*      */         }
/*      */         catch (URI.MalformedURIException mfue) {}
/*      */         
/* 3458 */         this.algorithm = tmpAlgorithm.toString();
/* 3459 */         this.encryptionMethodInformation = new LinkedList();
/*      */       }
/*      */       
/*      */       public String getAlgorithm() {
/* 3463 */         return this.algorithm;
/*      */       }
/*      */       
/*      */       public int getKeySize() {
/* 3467 */         return this.keySize;
/*      */       }
/*      */       
/*      */       public void setKeySize(int size) {
/* 3471 */         this.keySize = size;
/*      */       }
/*      */       
/*      */       public byte[] getOAEPparams() {
/* 3475 */         return this.oaepParams;
/*      */       }
/*      */       
/*      */       public void setOAEPparams(byte[] params) {
/* 3479 */         this.oaepParams = params;
/*      */       }
/*      */       
/*      */       public Iterator getEncryptionMethodInformation() {
/* 3483 */         return this.encryptionMethodInformation.iterator();
/*      */       }
/*      */       
/*      */       public void addEncryptionMethodInformation(Element info) {
/* 3487 */         this.encryptionMethodInformation.add(info);
/*      */       }
/*      */       
/*      */       public void removeEncryptionMethodInformation(Element info) {
/* 3491 */         this.encryptionMethodInformation.remove(info);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       Element toElement()
/*      */       {
/* 3503 */         Element result = ElementProxy.createElementForFamily(XMLCipher.this._contextDocument, "http://www.w3.org/2001/04/xmlenc#", "EncryptionMethod");
/*      */         
/*      */ 
/* 3506 */         result.setAttributeNS(null, "Algorithm", this.algorithm);
/*      */         
/* 3508 */         if (this.keySize > 0) {
/* 3509 */           result.appendChild(ElementProxy.createElementForFamily(XMLCipher.this._contextDocument, "http://www.w3.org/2001/04/xmlenc#", "KeySize").appendChild(XMLCipher.this._contextDocument.createTextNode(String.valueOf(this.keySize))));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3516 */         if (null != this.oaepParams) {
/* 3517 */           result.appendChild(ElementProxy.createElementForFamily(XMLCipher.this._contextDocument, "http://www.w3.org/2001/04/xmlenc#", "OAEPparams").appendChild(XMLCipher.this._contextDocument.createTextNode(new String(this.oaepParams))));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3524 */         if (!this.encryptionMethodInformation.isEmpty()) {
/* 3525 */           Iterator itr = this.encryptionMethodInformation.iterator();
/* 3526 */           result.appendChild((Element)itr.next());
/*      */         }
/*      */         
/* 3529 */         return result;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private class EncryptionPropertiesImpl
/*      */       implements EncryptionProperties
/*      */     {
/* 3541 */       private String id = null;
/* 3542 */       private List encryptionProperties = null;
/*      */       
/*      */ 
/*      */ 
/*      */       public EncryptionPropertiesImpl()
/*      */       {
/* 3548 */         this.encryptionProperties = new LinkedList();
/*      */       }
/*      */       
/*      */       public String getId() {
/* 3552 */         return this.id;
/*      */       }
/*      */       
/*      */       public void setId(String id) {
/* 3556 */         this.id = id;
/*      */       }
/*      */       
/*      */       public Iterator getEncryptionProperties() {
/* 3560 */         return this.encryptionProperties.iterator();
/*      */       }
/*      */       
/*      */       public void addEncryptionProperty(EncryptionProperty property) {
/* 3564 */         this.encryptionProperties.add(property);
/*      */       }
/*      */       
/*      */       public void removeEncryptionProperty(EncryptionProperty property) {
/* 3568 */         this.encryptionProperties.remove(property);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       Element toElement()
/*      */       {
/* 3579 */         Element result = ElementProxy.createElementForFamily(XMLCipher.this._contextDocument, "http://www.w3.org/2001/04/xmlenc#", "EncryptionProperties");
/*      */         
/*      */ 
/* 3582 */         if (null != this.id) {
/* 3583 */           result.setAttributeNS(null, "Id", this.id);
/*      */         }
/* 3585 */         Iterator itr = getEncryptionProperties();
/* 3586 */         while (itr.hasNext()) {
/* 3587 */           result.appendChild(((XMLCipher.Factory.EncryptionPropertyImpl)itr.next()).toElement());
/*      */         }
/*      */         
/*      */ 
/* 3591 */         return result;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private class EncryptionPropertyImpl
/*      */       implements EncryptionProperty
/*      */     {
/* 3605 */       private String target = null;
/* 3606 */       private String id = null;
/* 3607 */       private HashMap attributeMap = new HashMap();
/* 3608 */       private List encryptionInformation = null;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       public EncryptionPropertyImpl()
/*      */       {
/* 3615 */         this.encryptionInformation = new LinkedList();
/*      */       }
/*      */       
/*      */       public String getTarget() {
/* 3619 */         return this.target;
/*      */       }
/*      */       
/*      */       public void setTarget(String target) {
/* 3623 */         if ((target == null) || (target.length() == 0)) {
/* 3624 */           this.target = null;
/* 3625 */         } else if (target.startsWith("#"))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3631 */           this.target = target;
/*      */         } else {
/* 3633 */           URI tmpTarget = null;
/*      */           try {
/* 3635 */             tmpTarget = new URI(target);
/*      */           }
/*      */           catch (URI.MalformedURIException mfue) {}
/*      */           
/* 3639 */           this.target = tmpTarget.toString();
/*      */         }
/*      */       }
/*      */       
/*      */       public String getId() {
/* 3644 */         return this.id;
/*      */       }
/*      */       
/*      */       public void setId(String id) {
/* 3648 */         this.id = id;
/*      */       }
/*      */       
/*      */       public String getAttribute(String attribute) {
/* 3652 */         return (String)this.attributeMap.get(attribute);
/*      */       }
/*      */       
/*      */       public void setAttribute(String attribute, String value) {
/* 3656 */         this.attributeMap.put(attribute, value);
/*      */       }
/*      */       
/*      */       public Iterator getEncryptionInformation() {
/* 3660 */         return this.encryptionInformation.iterator();
/*      */       }
/*      */       
/*      */       public void addEncryptionInformation(Element info) {
/* 3664 */         this.encryptionInformation.add(info);
/*      */       }
/*      */       
/*      */       public void removeEncryptionInformation(Element info) {
/* 3668 */         this.encryptionInformation.remove(info);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       Element toElement()
/*      */       {
/* 3681 */         Element result = ElementProxy.createElementForFamily(XMLCipher.this._contextDocument, "http://www.w3.org/2001/04/xmlenc#", "EncryptionProperty");
/*      */         
/*      */ 
/* 3684 */         if (null != this.target) {
/* 3685 */           result.setAttributeNS(null, "Target", this.target);
/*      */         }
/*      */         
/* 3688 */         if (null != this.id) {
/* 3689 */           result.setAttributeNS(null, "Id", this.id);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 3695 */         return result;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private class TransformsImpl
/*      */       extends org.apache.xml.security.transforms.Transforms
/*      */       implements Transforms
/*      */     {
/*      */       public TransformsImpl()
/*      */       {
/* 3713 */         super();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public TransformsImpl(Document doc)
/*      */       {
/* 3720 */         if (doc == null) {
/* 3721 */           throw new RuntimeException("Document is null");
/*      */         }
/*      */         
/* 3724 */         this._doc = doc;
/* 3725 */         this._constructionElement = createElementForFamilyLocal(this._doc, getBaseNamespace(), getBaseLocalName());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       public TransformsImpl(Element element)
/*      */         throws XMLSignatureException, InvalidTransformException, XMLSecurityException, TransformationException
/*      */       {
/* 3742 */         super("");
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       public Element toElement()
/*      */       {
/* 3752 */         if (this._doc == null) {
/* 3753 */           this._doc = XMLCipher.this._contextDocument;
/*      */         }
/* 3755 */         return getElement();
/*      */       }
/*      */       
/*      */       public org.apache.xml.security.transforms.Transforms getDSTransforms()
/*      */       {
/* 3760 */         return this;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public String getBaseNamespace()
/*      */       {
/* 3767 */         return "http://www.w3.org/2001/04/xmlenc#";
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private class ReferenceListImpl
/*      */       implements ReferenceList
/*      */     {
/*      */       private Class sentry;
/*      */       
/*      */ 
/*      */ 
/*      */       private List references;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       public ReferenceListImpl(int type)
/*      */       {
/* 3788 */         if (type == 1) {
/* 3789 */           this.sentry = DataReference.class;
/* 3790 */         } else if (type == 2) {
/* 3791 */           this.sentry = KeyReference.class;
/*      */         } else {
/* 3793 */           throw new IllegalArgumentException();
/*      */         }
/* 3795 */         this.references = new LinkedList();
/*      */       }
/*      */       
/*      */       public void add(Reference reference) {
/* 3799 */         if (!reference.getClass().equals(this.sentry)) {
/* 3800 */           throw new IllegalArgumentException();
/*      */         }
/* 3802 */         this.references.add(reference);
/*      */       }
/*      */       
/*      */       public void remove(Reference reference) {
/* 3806 */         if (!reference.getClass().equals(this.sentry)) {
/* 3807 */           throw new IllegalArgumentException();
/*      */         }
/* 3809 */         this.references.remove(reference);
/*      */       }
/*      */       
/*      */       public int size() {
/* 3813 */         return this.references.size();
/*      */       }
/*      */       
/*      */       public boolean isEmpty() {
/* 3817 */         return this.references.isEmpty();
/*      */       }
/*      */       
/*      */       public Iterator getReferences() {
/* 3821 */         return this.references.iterator();
/*      */       }
/*      */       
/*      */       Element toElement() {
/* 3825 */         Element result = ElementProxy.createElementForFamily(XMLCipher.this._contextDocument, "http://www.w3.org/2001/04/xmlenc#", "ReferenceList");
/*      */         
/*      */ 
/*      */ 
/* 3829 */         Iterator eachReference = this.references.iterator();
/* 3830 */         while (eachReference.hasNext()) {
/* 3831 */           Reference reference = (Reference)eachReference.next();
/* 3832 */           result.appendChild(((ReferenceImpl)reference).toElement());
/*      */         }
/*      */         
/* 3835 */         return result;
/*      */       }
/*      */       
/*      */       public Reference newDataReference(String uri) {
/* 3839 */         return new DataReference(uri);
/*      */       }
/*      */       
/*      */       public Reference newKeyReference(String uri) {
/* 3843 */         return new KeyReference(uri);
/*      */       }
/*      */       
/*      */ 
/*      */       private abstract class ReferenceImpl
/*      */         implements Reference
/*      */       {
/*      */         private String uri;
/*      */         
/*      */         private List referenceInformation;
/*      */         
/*      */ 
/*      */         ReferenceImpl(String _uri)
/*      */         {
/* 3857 */           this.uri = _uri;
/* 3858 */           this.referenceInformation = new LinkedList();
/*      */         }
/*      */         
/*      */         public String getURI() {
/* 3862 */           return this.uri;
/*      */         }
/*      */         
/*      */         public Iterator getElementRetrievalInformation() {
/* 3866 */           return this.referenceInformation.iterator();
/*      */         }
/*      */         
/*      */         public void setURI(String _uri) {
/* 3870 */           this.uri = _uri;
/*      */         }
/*      */         
/*      */         public void removeElementRetrievalInformation(Element node) {
/* 3874 */           this.referenceInformation.remove(node);
/*      */         }
/*      */         
/*      */         public void addElementRetrievalInformation(Element node) {
/* 3878 */           this.referenceInformation.add(node);
/*      */         }
/*      */         
/*      */ 
/*      */         public abstract Element toElement();
/*      */         
/*      */ 
/*      */         Element toElement(String tagName)
/*      */         {
/* 3887 */           Element result = ElementProxy.createElementForFamily(XMLCipher.this._contextDocument, "http://www.w3.org/2001/04/xmlenc#", tagName);
/*      */           
/*      */ 
/*      */ 
/* 3891 */           result.setAttribute("URI", this.uri);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3897 */           return result;
/*      */         }
/*      */       }
/*      */       
/*      */       private class DataReference extends XMLCipher.Factory.ReferenceListImpl.ReferenceImpl {
/*      */         DataReference(String uri) {
/* 3903 */           super(uri);
/*      */         }
/*      */         
/*      */         public Element toElement() {
/* 3907 */           return super.toElement("DataReference");
/*      */         }
/*      */       }
/*      */       
/*      */       private class KeyReference extends XMLCipher.Factory.ReferenceListImpl.ReferenceImpl {
/*      */         KeyReference(String uri) {
/* 3913 */           super(uri);
/*      */         }
/*      */         
/*      */         public Element toElement() {
/* 3917 */           return super.toElement("KeyReference");
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\encryption\XMLCipher.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */