/*     */ package org.apache.xml.security.transforms.implementations;
/*     */ 
/*     */ import org.apache.xml.security.signature.NodeFilter;
/*     */ import org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import org.apache.xml.security.transforms.Transform;
/*     */ import org.apache.xml.security.transforms.TransformSpi;
/*     */ import org.apache.xml.security.transforms.TransformationException;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransformEnvelopedSignature
/*     */   extends TransformSpi
/*     */ {
/*     */   public static final String implementedTransformURI = "http://www.w3.org/2000/09/xmldsig#enveloped-signature";
/*     */   
/*     */   protected String engineGetURI()
/*     */   {
/*  48 */     return "http://www.w3.org/2000/09/xmldsig#enveloped-signature";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, Transform _transformObject)
/*     */     throws TransformationException
/*     */   {
/*  71 */     Node signatureElement = _transformObject.getElement();
/*     */     
/*     */ 
/*  74 */     signatureElement = searchSignatureElement(signatureElement);
/*  75 */     input.setExcludeNode(signatureElement);
/*  76 */     input.addNodeFilter(new EnvelopedNodeFilter(signatureElement));
/*  77 */     return input;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Node searchSignatureElement(Node signatureElement)
/*     */     throws TransformationException
/*     */   {
/*  90 */     boolean found = false;
/*     */     
/*     */ 
/*  93 */     while ((signatureElement != null) && (signatureElement.getNodeType() != 9))
/*     */     {
/*     */ 
/*     */ 
/*  97 */       Element el = (Element)signatureElement;
/*  98 */       if ((el.getNamespaceURI().equals("http://www.w3.org/2000/09/xmldsig#")) && (el.getLocalName().equals("Signature")))
/*     */       {
/*     */ 
/* 101 */         found = true;
/* 102 */         break;
/*     */       }
/*     */       
/* 105 */       signatureElement = signatureElement.getParentNode();
/*     */     }
/*     */     
/* 108 */     if (!found) {
/* 109 */       throw new TransformationException("envelopedSignatureTransformNotInSignatureElement");
/*     */     }
/*     */     
/* 112 */     return signatureElement;
/*     */   }
/*     */   
/*     */   static class EnvelopedNodeFilter implements NodeFilter { Node exclude;
/*     */     
/* 117 */     EnvelopedNodeFilter(Node n) { this.exclude = n; }
/*     */     
/*     */     public int isNodeIncludeDO(Node n, int level) {
/* 120 */       if (n == this.exclude)
/* 121 */         return -1;
/* 122 */       return 1;
/*     */     }
/*     */     
/*     */ 
/*     */     public int isNodeInclude(Node n)
/*     */     {
/* 128 */       if ((n == this.exclude) || (XMLUtils.isDescendantOrSelf(this.exclude, n)))
/* 129 */         return -1;
/* 130 */       return 1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\transforms\implementations\TransformEnvelopedSignature.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */