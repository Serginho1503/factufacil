/*     */ package org.apache.xml.security.transforms.implementations;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import org.apache.xml.dtm.DTM;
/*     */ import org.apache.xml.security.utils.I18n;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.apache.xpath.NodeSetDTM;
/*     */ import org.apache.xpath.XPathContext;
/*     */ import org.apache.xpath.functions.Function;
/*     */ import org.apache.xpath.objects.XNodeSet;
/*     */ import org.apache.xpath.objects.XObject;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FuncHere
/*     */   extends Function
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public XObject execute(XPathContext xctxt)
/*     */     throws TransformerException
/*     */   {
/*  74 */     Node xpathOwnerNode = (Node)xctxt.getOwnerObject();
/*     */     
/*  76 */     if (xpathOwnerNode == null) {
/*  77 */       return null;
/*     */     }
/*     */     
/*  80 */     int xpathOwnerNodeDTM = xctxt.getDTMHandleFromNode(xpathOwnerNode);
/*     */     
/*  82 */     int currentNode = xctxt.getCurrentNode();
/*  83 */     DTM dtm = xctxt.getDTM(currentNode);
/*  84 */     int docContext = dtm.getDocument();
/*     */     
/*  86 */     if (-1 == docContext) {
/*  87 */       error(xctxt, "ER_CONTEXT_HAS_NO_OWNERDOC", null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  94 */     Document currentDoc = XMLUtils.getOwnerDocument(dtm.getNode(currentNode));
/*     */     
/*  96 */     Document xpathOwnerDoc = XMLUtils.getOwnerDocument(xpathOwnerNode);
/*     */     
/*  98 */     if (currentDoc != xpathOwnerDoc) {
/*  99 */       throw new TransformerException(I18n.translate("xpath.funcHere.documentsDiffer"));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 104 */     XNodeSet nodes = new XNodeSet(xctxt.getDTMManager());
/* 105 */     NodeSetDTM nodeSet = nodes.mutableNodeset();
/*     */     
/*     */ 
/* 108 */     int hereNode = -1;
/*     */     
/* 110 */     switch (dtm.getNodeType(xpathOwnerNodeDTM))
/*     */     {
/*     */ 
/*     */     case 2: 
/* 114 */       hereNode = xpathOwnerNodeDTM;
/*     */       
/* 116 */       nodeSet.addNode(hereNode);
/*     */       
/* 118 */       break;
/*     */     
/*     */ 
/*     */     case 7: 
/* 122 */       hereNode = xpathOwnerNodeDTM;
/*     */       
/* 124 */       nodeSet.addNode(hereNode);
/*     */       
/* 126 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */     case 3: 
/* 131 */       hereNode = dtm.getParent(xpathOwnerNodeDTM);
/*     */       
/* 133 */       nodeSet.addNode(hereNode);
/*     */       
/* 135 */       break;
/*     */     }
/*     */     
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 143 */     nodeSet.detach();
/*     */     
/* 145 */     return nodes;
/*     */   }
/*     */   
/*     */   public void fixupVariables(Vector vars, int globalsSize) {}
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\transforms\implementations\FuncHere.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */