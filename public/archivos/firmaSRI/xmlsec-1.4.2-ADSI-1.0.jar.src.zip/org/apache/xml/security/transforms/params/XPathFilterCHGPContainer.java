/*     */ package org.apache.xml.security.transforms.params;
/*     */ 
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.transforms.TransformParam;
/*     */ import org.apache.xml.security.utils.ElementProxy;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XPathFilterCHGPContainer
/*     */   extends ElementProxy
/*     */   implements TransformParam
/*     */ {
/*     */   private static final String _TAG_INCLUDE_BUT_SEARCH = "IncludeButSearch";
/*     */   private static final String _TAG_EXCLUDE_BUT_SEARCH = "ExcludeButSearch";
/*     */   private static final String _TAG_EXCLUDE = "Exclude";
/*     */   public static final String _TAG_XPATHCHGP = "XPathAlternative";
/*     */   public static final String _ATT_INCLUDESLASH = "IncludeSlashPolicy";
/*     */   public static final boolean IncludeSlash = true;
/*     */   public static final boolean ExcludeSlash = false;
/*     */   
/*     */   private XPathFilterCHGPContainer() {}
/*     */   
/*     */   private XPathFilterCHGPContainer(Document doc, boolean includeSlashPolicy, String includeButSearch, String excludeButSearch, String exclude)
/*     */   {
/*  83 */     super(doc);
/*     */     
/*  85 */     if (includeSlashPolicy) {
/*  86 */       this._constructionElement.setAttributeNS(null, "IncludeSlashPolicy", "true");
/*     */     }
/*     */     else {
/*  89 */       this._constructionElement.setAttributeNS(null, "IncludeSlashPolicy", "false");
/*     */     }
/*     */     
/*     */ 
/*  93 */     if ((includeButSearch != null) && (includeButSearch.trim().length() > 0))
/*     */     {
/*  95 */       Element includeButSearchElem = ElementProxy.createElementForFamily(doc, getBaseNamespace(), "IncludeButSearch");
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 100 */       includeButSearchElem.appendChild(this._doc.createTextNode(indentXPathText(includeButSearch)));
/*     */       
/*     */ 
/* 103 */       XMLUtils.addReturnToElement(this._constructionElement);
/* 104 */       this._constructionElement.appendChild(includeButSearchElem);
/*     */     }
/*     */     
/* 107 */     if ((excludeButSearch != null) && (excludeButSearch.trim().length() > 0))
/*     */     {
/* 109 */       Element excludeButSearchElem = ElementProxy.createElementForFamily(doc, getBaseNamespace(), "ExcludeButSearch");
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 114 */       excludeButSearchElem.appendChild(this._doc.createTextNode(indentXPathText(excludeButSearch)));
/*     */       
/*     */ 
/* 117 */       XMLUtils.addReturnToElement(this._constructionElement);
/* 118 */       this._constructionElement.appendChild(excludeButSearchElem);
/*     */     }
/*     */     
/* 121 */     if ((exclude != null) && (exclude.trim().length() > 0)) {
/* 122 */       Element excludeElem = ElementProxy.createElementForFamily(doc, getBaseNamespace(), "Exclude");
/*     */       
/*     */ 
/*     */ 
/* 126 */       excludeElem.appendChild(this._doc.createTextNode(indentXPathText(exclude)));
/*     */       
/* 128 */       XMLUtils.addReturnToElement(this._constructionElement);
/* 129 */       this._constructionElement.appendChild(excludeElem);
/*     */     }
/*     */     
/* 132 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String indentXPathText(String xp)
/*     */   {
/* 143 */     if ((xp.length() > 2) && (!Character.isWhitespace(xp.charAt(0)))) {
/* 144 */       return "\n" + xp + "\n";
/*     */     }
/* 146 */     return xp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private XPathFilterCHGPContainer(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 159 */     super(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XPathFilterCHGPContainer getInstance(Document doc, boolean includeSlashPolicy, String includeButSearch, String excludeButSearch, String exclude)
/*     */   {
/* 176 */     return new XPathFilterCHGPContainer(doc, includeSlashPolicy, includeButSearch, excludeButSearch, exclude);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XPathFilterCHGPContainer getInstance(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 192 */     return new XPathFilterCHGPContainer(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getXStr(String type)
/*     */   {
/* 203 */     if (length(getBaseNamespace(), type) != 1) {
/* 204 */       return "";
/*     */     }
/*     */     
/* 207 */     Element xElem = XMLUtils.selectNode(this._constructionElement.getFirstChild(), getBaseNamespace(), type, 0);
/*     */     
/*     */ 
/* 210 */     return XMLUtils.getFullTextChildrenFromElement(xElem);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getIncludeButSearch()
/*     */   {
/* 219 */     return getXStr("IncludeButSearch");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getExcludeButSearch()
/*     */   {
/* 228 */     return getXStr("ExcludeButSearch");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getExclude()
/*     */   {
/* 237 */     return getXStr("Exclude");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getIncludeSlashPolicy()
/*     */   {
/* 247 */     return this._constructionElement.getAttributeNS(null, "IncludeSlashPolicy").equals("true");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Node getHereContextNode(String type)
/*     */   {
/* 263 */     if (length(getBaseNamespace(), type) != 1) {
/* 264 */       return null;
/*     */     }
/*     */     
/* 267 */     return XMLUtils.selectNodeText(this._constructionElement.getFirstChild(), getBaseNamespace(), type, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node getHereContextNodeIncludeButSearch()
/*     */   {
/* 277 */     return getHereContextNode("IncludeButSearch");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node getHereContextNodeExcludeButSearch()
/*     */   {
/* 287 */     return getHereContextNode("ExcludeButSearch");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node getHereContextNodeExclude()
/*     */   {
/* 297 */     return getHereContextNode("Exclude");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getBaseLocalName()
/*     */   {
/* 306 */     return "XPathAlternative";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getBaseNamespace()
/*     */   {
/* 315 */     return "http://www.nue.et-inf.uni-siegen.de/~geuer-pollmann/#xpathFilter";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\transforms\params\XPathFilterCHGPContainer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */