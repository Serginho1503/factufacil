/*     */ package org.apache.xml.security.signature;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import org.apache.xml.security.c14n.InvalidCanonicalizerException;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.transforms.Transforms;
/*     */ import org.apache.xml.security.utils.I18n;
/*     */ import org.apache.xml.security.utils.IdResolver;
/*     */ import org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.apache.xml.security.utils.resolver.ResourceResolver;
/*     */ import org.apache.xml.security.utils.resolver.ResourceResolverSpi;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Manifest
/*     */   extends SignatureElementProxy
/*     */ {
/*  57 */   static Log log = LogFactory.getLog(Manifest.class.getName());
/*     */   
/*     */ 
/*     */   List _references;
/*     */   
/*     */ 
/*     */   Element[] _referencesEl;
/*     */   
/*  65 */   private boolean[] verificationResults = null;
/*     */   
/*     */ 
/*  68 */   HashMap _resolverProperties = null;
/*     */   
/*     */ 
/*  71 */   List _perManifestResolvers = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Manifest(Document doc)
/*     */   {
/*  80 */     super(doc);
/*     */     
/*  82 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */     
/*  84 */     this._references = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Manifest(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  97 */     super(element, BaseURI);
/*     */     
/*     */ 
/* 100 */     this._referencesEl = XMLUtils.selectDsNodes(this._constructionElement.getFirstChild(), "Reference");
/*     */     
/* 102 */     int le = this._referencesEl.length;
/*     */     
/* 104 */     if (le == 0)
/*     */     {
/*     */ 
/* 107 */       Object[] exArgs = { "Reference", "Manifest" };
/*     */       
/*     */ 
/* 110 */       throw new DOMException((short)4, I18n.translate("xml.WrongContent", exArgs));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 116 */     this._references = new ArrayList(le);
/*     */     
/* 118 */     for (int i = 0; i < le; i++) {
/* 119 */       this._references.add(null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addDocument(String BaseURI, String referenceURI, Transforms transforms, String digestURI, String ReferenceId, String ReferenceType)
/*     */     throws XMLSignatureException
/*     */   {
/* 141 */     Reference ref = new Reference(this._doc, BaseURI, referenceURI, this, transforms, digestURI);
/*     */     
/*     */ 
/* 144 */     if (ReferenceId != null) {
/* 145 */       ref.setId(ReferenceId);
/*     */     }
/*     */     
/* 148 */     if (ReferenceType != null) {
/* 149 */       ref.setType(ReferenceType);
/*     */     }
/*     */     
/*     */ 
/* 153 */     this._references.add(ref);
/*     */     
/*     */ 
/* 156 */     this._constructionElement.appendChild(ref.getElement());
/* 157 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void generateDigestValues()
/*     */     throws XMLSignatureException, ReferenceNotInitializedException
/*     */   {
/* 171 */     for (int i = 0; i < getLength(); i++)
/*     */     {
/*     */ 
/* 174 */       Reference currentRef = (Reference)this._references.get(i);
/*     */       
/* 176 */       currentRef.generateDigestValue();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLength()
/*     */   {
/* 186 */     return this._references.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Reference item(int i)
/*     */     throws XMLSecurityException
/*     */   {
/* 199 */     if (this._references.get(i) == null)
/*     */     {
/*     */ 
/* 202 */       Reference ref = new Reference(this._referencesEl[i], this._baseURI, this);
/*     */       
/* 204 */       this._references.set(i, ref);
/*     */     }
/*     */     
/* 207 */     return (Reference)this._references.get(i);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setId(String Id)
/*     */   {
/* 218 */     if (Id != null) {
/* 219 */       this._constructionElement.setAttributeNS(null, "Id", Id);
/* 220 */       IdResolver.registerElementById(this._constructionElement, Id);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getId()
/*     */   {
/* 230 */     return this._constructionElement.getAttributeNS(null, "Id");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean verifyReferences()
/*     */     throws MissingResourceFailureException, XMLSecurityException
/*     */   {
/* 252 */     return verifyReferences(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean verifyReferences(boolean followManifests)
/*     */     throws MissingResourceFailureException, XMLSecurityException
/*     */   {
/* 275 */     if (this._referencesEl == null) {
/* 276 */       this._referencesEl = XMLUtils.selectDsNodes(this._constructionElement.getFirstChild(), "Reference");
/*     */     }
/*     */     
/*     */ 
/* 280 */     if (log.isDebugEnabled()) {
/* 281 */       log.debug("verify " + this._referencesEl.length + " References");
/* 282 */       log.debug("I am " + (followManifests ? "" : "not") + " requested to follow nested Manifests");
/*     */     }
/*     */     
/*     */ 
/* 286 */     boolean verify = true;
/*     */     
/* 288 */     if (this._referencesEl.length == 0) {
/* 289 */       throw new XMLSecurityException("empty");
/*     */     }
/*     */     
/* 292 */     this.verificationResults = new boolean[this._referencesEl.length];
/*     */     
/*     */ 
/* 295 */     for (int i = 0; 
/* 296 */         i < this._referencesEl.length; i++) {
/* 297 */       Reference currentRef = new Reference(this._referencesEl[i], this._baseURI, this);
/*     */       
/*     */ 
/* 300 */       this._references.set(i, currentRef);
/*     */       
/*     */       try
/*     */       {
/* 304 */         boolean currentRefVerified = currentRef.verify();
/*     */         
/* 306 */         setVerificationResult(i, currentRefVerified);
/*     */         
/* 308 */         if (!currentRefVerified) {
/* 309 */           verify = false;
/*     */         }
/* 311 */         if (log.isDebugEnabled()) {
/* 312 */           log.debug("The Reference has Type " + currentRef.getType());
/*     */         }
/*     */         
/* 315 */         if ((verify) && (followManifests) && (currentRef.typeIsReferenceToManifest()))
/*     */         {
/* 317 */           log.debug("We have to follow a nested Manifest");
/*     */           try
/*     */           {
/* 320 */             XMLSignatureInput signedManifestNodes = currentRef.dereferenceURIandPerformTransforms(null);
/*     */             
/* 322 */             Set nl = signedManifestNodes.getNodeSet();
/* 323 */             Manifest referencedManifest = null;
/* 324 */             Iterator nlIterator = nl.iterator();
/*     */             
/* 326 */             while (nlIterator.hasNext()) {
/* 327 */               Node n = (Node)nlIterator.next();
/*     */               
/* 329 */               if ((n.getNodeType() == 1) && (((Element)n).getNamespaceURI().equals("http://www.w3.org/2000/09/xmldsig#")) && (((Element)n).getLocalName().equals("Manifest")))
/*     */               {
/*     */                 try
/*     */                 {
/*     */ 
/* 334 */                   referencedManifest = new Manifest((Element)n, signedManifestNodes.getSourceURI());
/*     */                 }
/*     */                 catch (XMLSecurityException ex) {}
/*     */               }
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 346 */             if (referencedManifest == null)
/*     */             {
/*     */ 
/*     */ 
/* 350 */               throw new MissingResourceFailureException("empty", currentRef);
/*     */             }
/*     */             
/*     */ 
/* 354 */             referencedManifest._perManifestResolvers = this._perManifestResolvers;
/*     */             
/* 356 */             referencedManifest._resolverProperties = this._resolverProperties;
/*     */             
/*     */ 
/* 359 */             boolean referencedManifestValid = referencedManifest.verifyReferences(followManifests);
/*     */             
/*     */ 
/* 362 */             if (!referencedManifestValid) {
/* 363 */               verify = false;
/*     */               
/* 365 */               log.warn("The nested Manifest was invalid (bad)");
/*     */             } else {
/* 367 */               log.debug("The nested Manifest was valid (good)");
/*     */             }
/*     */           } catch (IOException ex) {
/* 370 */             throw new ReferenceNotInitializedException("empty", ex);
/*     */           } catch (ParserConfigurationException ex) {
/* 372 */             throw new ReferenceNotInitializedException("empty", ex);
/*     */           } catch (SAXException ex) {
/* 374 */             throw new ReferenceNotInitializedException("empty", ex);
/*     */           }
/*     */         }
/*     */       } catch (ReferenceNotInitializedException ex) {
/* 378 */         Object[] exArgs = { currentRef.getURI() };
/*     */         
/* 380 */         throw new MissingResourceFailureException("signature.Verification.Reference.NoInput", exArgs, ex, currentRef);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 386 */     return verify;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setVerificationResult(int index, boolean verify)
/*     */   {
/* 398 */     if (this.verificationResults == null) {
/* 399 */       this.verificationResults = new boolean[getLength()];
/*     */     }
/*     */     
/* 402 */     this.verificationResults[index] = verify;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getVerificationResult(int index)
/*     */     throws XMLSecurityException
/*     */   {
/* 416 */     if ((index < 0) || (index > getLength() - 1)) {
/* 417 */       Object[] exArgs = { Integer.toString(index), Integer.toString(getLength()) };
/*     */       
/* 419 */       Exception e = new IndexOutOfBoundsException(I18n.translate("signature.Verification.IndexOutOfBounds", exArgs));
/*     */       
/*     */ 
/*     */ 
/* 423 */       throw new XMLSecurityException("generic.EmptyMessage", e);
/*     */     }
/*     */     
/* 426 */     if (this.verificationResults == null) {
/*     */       try {
/* 428 */         verifyReferences();
/*     */       } catch (Exception ex) {
/* 430 */         throw new XMLSecurityException("generic.EmptyMessage", ex);
/*     */       }
/*     */     }
/*     */     
/* 434 */     return this.verificationResults[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addResourceResolver(ResourceResolver resolver)
/*     */   {
/* 444 */     if (resolver == null) {
/* 445 */       return;
/*     */     }
/* 447 */     if (this._perManifestResolvers == null)
/* 448 */       this._perManifestResolvers = new ArrayList();
/* 449 */     this._perManifestResolvers.add(resolver);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addResourceResolver(ResourceResolverSpi resolverSpi)
/*     */   {
/* 460 */     if (resolverSpi == null) {
/* 461 */       return;
/*     */     }
/* 463 */     if (this._perManifestResolvers == null)
/* 464 */       this._perManifestResolvers = new ArrayList();
/* 465 */     this._perManifestResolvers.add(new ResourceResolver(resolverSpi));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResolverProperty(String key, String value)
/*     */   {
/* 477 */     if (this._resolverProperties == null) {
/* 478 */       this._resolverProperties = new HashMap(10);
/*     */     }
/* 480 */     this._resolverProperties.put(key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getResolverProperty(String key)
/*     */   {
/* 490 */     return (String)this._resolverProperties.get(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getSignedContentItem(int i)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 504 */       return getReferencedContentAfterTransformsItem(i).getBytes();
/*     */     } catch (IOException ex) {
/* 506 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (CanonicalizationException ex) {
/* 508 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (InvalidCanonicalizerException ex) {
/* 510 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (XMLSecurityException ex) {
/* 512 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput getReferencedContentBeforeTransformsItem(int i)
/*     */     throws XMLSecurityException
/*     */   {
/* 525 */     return item(i).getContentsBeforeTransformation();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput getReferencedContentAfterTransformsItem(int i)
/*     */     throws XMLSecurityException
/*     */   {
/* 537 */     return item(i).getContentsAfterTransformation();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSignedContentLength()
/*     */   {
/* 546 */     return getLength();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBaseLocalName()
/*     */   {
/* 555 */     return "Manifest";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\signature\Manifest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */