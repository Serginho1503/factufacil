/*     */ package org.apache.xml.security.keys.content.keyvalues;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import java.security.Key;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PublicKey;
/*     */ import java.security.interfaces.RSAPublicKey;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import java.security.spec.RSAPublicKeySpec;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.utils.I18n;
/*     */ import org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RSAKeyValue
/*     */   extends SignatureElementProxy
/*     */   implements KeyValueContent
/*     */ {
/*     */   public RSAKeyValue(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  52 */     super(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RSAKeyValue(Document doc, BigInteger modulus, BigInteger exponent)
/*     */   {
/*  64 */     super(doc);
/*     */     
/*  66 */     XMLUtils.addReturnToElement(this._constructionElement);
/*  67 */     addBigIntegerElement(modulus, "Modulus");
/*  68 */     addBigIntegerElement(exponent, "Exponent");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RSAKeyValue(Document doc, Key key)
/*     */     throws IllegalArgumentException
/*     */   {
/*  80 */     super(doc);
/*     */     
/*  82 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */     
/*  84 */     if ((key instanceof RSAPublicKey)) {
/*  85 */       addBigIntegerElement(((RSAPublicKey)key).getModulus(), "Modulus");
/*     */       
/*  87 */       addBigIntegerElement(((RSAPublicKey)key).getPublicExponent(), "Exponent");
/*     */     }
/*     */     else {
/*  90 */       Object[] exArgs = { "RSAKeyValue", key.getClass().getName() };
/*     */       
/*     */ 
/*  93 */       throw new IllegalArgumentException(I18n.translate("KeyValue.IllegalArgument", exArgs));
/*     */     }
/*     */   }
/*     */   
/*     */   public PublicKey getPublicKey()
/*     */     throws XMLSecurityException
/*     */   {
/*     */     try
/*     */     {
/* 102 */       KeyFactory rsaFactory = KeyFactory.getInstance("RSA");
/*     */       
/*     */ 
/* 105 */       RSAPublicKeySpec rsaKeyspec = new RSAPublicKeySpec(getBigIntegerFromChildElement("Modulus", "http://www.w3.org/2000/09/xmldsig#"), getBigIntegerFromChildElement("Exponent", "http://www.w3.org/2000/09/xmldsig#"));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 111 */       return rsaFactory.generatePublic(rsaKeyspec);
/*     */     }
/*     */     catch (NoSuchAlgorithmException ex)
/*     */     {
/* 115 */       throw new XMLSecurityException("empty", ex);
/*     */     } catch (InvalidKeySpecException ex) {
/* 117 */       throw new XMLSecurityException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 123 */     return "RSAKeyValue";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\content\keyvalues\RSAKeyValue.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */