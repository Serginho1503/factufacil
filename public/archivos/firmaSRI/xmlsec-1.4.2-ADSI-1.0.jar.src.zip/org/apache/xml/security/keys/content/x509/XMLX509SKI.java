/*     */ package org.apache.xml.security.keys.content.x509;
/*     */ 
/*     */ import java.security.MessageDigest;
/*     */ import java.security.cert.X509Certificate;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.utils.Base64;
/*     */ import org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLX509SKI
/*     */   extends SignatureElementProxy
/*     */   implements XMLX509DataContent
/*     */ {
/*  43 */   static Log log = LogFactory.getLog(XMLX509SKI.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String SKI_OID = "2.5.29.14";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509SKI(Document doc, byte[] skiBytes)
/*     */   {
/*  64 */     super(doc);
/*  65 */     addBase64Text(skiBytes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509SKI(Document doc, X509Certificate x509certificate)
/*     */     throws XMLSecurityException
/*     */   {
/*  77 */     super(doc);
/*  78 */     addBase64Text(getSKIBytesFromCert(x509certificate));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509SKI(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  90 */     super(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getSKIBytes()
/*     */     throws XMLSecurityException
/*     */   {
/* 100 */     return getBytesFromTextChild();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] getSKIBytesFromCert(X509Certificate cert)
/*     */     throws XMLSecurityException
/*     */   {
/* 115 */     if (cert.getVersion() < 3) {
/* 116 */       Object[] exArgs = { new Integer(cert.getVersion()) };
/* 117 */       throw new XMLSecurityException("certificate.noSki.lowVersion", exArgs);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 127 */     byte[] extensionValue = cert.getExtensionValue("2.5.29.14");
/* 128 */     if (extensionValue == null) {
/* 129 */       throw new XMLSecurityException("certificate.noSki.null");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 138 */     byte[] skidValue = new byte[extensionValue.length - 4];
/*     */     
/* 140 */     System.arraycopy(extensionValue, 4, skidValue, 0, skidValue.length);
/*     */     
/* 142 */     if (log.isDebugEnabled()) {
/* 143 */       log.debug("Base64 of SKI is " + Base64.encode(skidValue));
/*     */     }
/*     */     
/* 146 */     return skidValue;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 151 */     if (obj == null) {
/* 152 */       return false;
/*     */     }
/* 154 */     if (!getClass().getName().equals(obj.getClass().getName())) {
/* 155 */       return false;
/*     */     }
/*     */     
/* 158 */     XMLX509SKI other = (XMLX509SKI)obj;
/*     */     try
/*     */     {
/* 161 */       return MessageDigest.isEqual(other.getSKIBytes(), getSKIBytes());
/*     */     }
/*     */     catch (XMLSecurityException ex) {}
/* 164 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 171 */     return 92;
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 176 */     return "X509SKI";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\content\x509\XMLX509SKI.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */