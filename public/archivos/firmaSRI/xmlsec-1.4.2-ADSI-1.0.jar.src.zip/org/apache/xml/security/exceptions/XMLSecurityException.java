/*     */ package org.apache.xml.security.exceptions;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.text.MessageFormat;
/*     */ import org.apache.xml.security.utils.I18n;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLSecurityException
/*     */   extends Exception
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  71 */   protected Exception originalException = null;
/*     */   
/*     */ 
/*     */ 
/*     */   protected String msgID;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSecurityException()
/*     */   {
/*  82 */     super("Missing message string");
/*     */     
/*  84 */     this.msgID = null;
/*  85 */     this.originalException = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSecurityException(String _msgID)
/*     */   {
/*  95 */     super(I18n.getExceptionMessage(_msgID));
/*     */     
/*  97 */     this.msgID = _msgID;
/*  98 */     this.originalException = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSecurityException(String _msgID, Object[] exArgs)
/*     */   {
/* 109 */     super(MessageFormat.format(I18n.getExceptionMessage(_msgID), exArgs));
/*     */     
/* 111 */     this.msgID = _msgID;
/* 112 */     this.originalException = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSecurityException(Exception _originalException)
/*     */   {
/* 122 */     super("Missing message ID to locate message string in resource bundle \"org/apache/xml/security/resource/xmlsecurity\". Original Exception was a " + _originalException.getClass().getName() + " and message " + _originalException.getMessage());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 128 */     this.originalException = _originalException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSecurityException(String _msgID, Exception _originalException)
/*     */   {
/* 139 */     super(I18n.getExceptionMessage(_msgID, _originalException));
/*     */     
/* 141 */     this.msgID = _msgID;
/* 142 */     this.originalException = _originalException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSecurityException(String _msgID, Object[] exArgs, Exception _originalException)
/*     */   {
/* 155 */     super(MessageFormat.format(I18n.getExceptionMessage(_msgID), exArgs));
/*     */     
/* 157 */     this.msgID = _msgID;
/* 158 */     this.originalException = _originalException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMsgID()
/*     */   {
/* 168 */     if (this.msgID == null) {
/* 169 */       return "Missing message ID";
/*     */     }
/* 171 */     return this.msgID;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 177 */     String s = getClass().getName();
/* 178 */     String message = super.getLocalizedMessage();
/*     */     
/* 180 */     if (message != null) {
/* 181 */       message = s + ": " + message;
/*     */     } else {
/* 183 */       message = s;
/*     */     }
/*     */     
/* 186 */     if (this.originalException != null) {
/* 187 */       message = message + "\nOriginal Exception was " + this.originalException.toString();
/*     */     }
/*     */     
/*     */ 
/* 191 */     return message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printStackTrace()
/*     */   {
/* 200 */     synchronized (System.err) {
/* 201 */       super.printStackTrace(System.err);
/*     */       
/* 203 */       if (this.originalException != null) {
/* 204 */         this.originalException.printStackTrace(System.err);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printStackTrace(PrintWriter printwriter)
/*     */   {
/* 216 */     super.printStackTrace(printwriter);
/*     */     
/* 218 */     if (this.originalException != null) {
/* 219 */       this.originalException.printStackTrace(printwriter);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printStackTrace(PrintStream printstream)
/*     */   {
/* 230 */     super.printStackTrace(printstream);
/*     */     
/* 232 */     if (this.originalException != null) {
/* 233 */       this.originalException.printStackTrace(printstream);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Exception getOriginalException()
/*     */   {
/* 243 */     return this.originalException;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\exceptions\XMLSecurityException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */