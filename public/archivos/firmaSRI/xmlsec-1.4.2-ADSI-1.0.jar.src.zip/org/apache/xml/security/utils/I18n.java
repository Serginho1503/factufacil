/*     */ package org.apache.xml.security.utils;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Locale;
/*     */ import java.util.ResourceBundle;
/*     */ import org.apache.xml.security.Init;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class I18n
/*     */ {
/*     */   public static final String NOT_INITIALIZED_MSG = "You must initialize the xml-security library correctly before you use it. Call the static method \"org.apache.xml.security.Init.init();\" to do that before you use any functionality from that library.";
/*     */   static String defaultLanguageCode;
/*     */   static String defaultCountryCode;
/*     */   static ResourceBundle resourceBundle;
/*  46 */   static boolean alreadyInitialized = false;
/*     */   
/*     */ 
/*  49 */   static String _languageCode = null;
/*     */   
/*     */ 
/*  52 */   static String _countryCode = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String translate(String message, Object[] args)
/*     */   {
/*  76 */     return getExceptionMessage(message, args);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String translate(String message)
/*     */   {
/*  89 */     return getExceptionMessage(message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getExceptionMessage(String msgID)
/*     */   {
/*     */     try
/*     */     {
/* 102 */       return resourceBundle.getString(msgID);
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 106 */       if (Init.isInitialized()) {
/* 107 */         return "No message with ID \"" + msgID + "\" found in resource bundle \"" + "org/apache/xml/security/resource/xmlsecurity" + "\"";
/*     */       }
/*     */     }
/*     */     
/* 111 */     return "You must initialize the xml-security library correctly before you use it. Call the static method \"org.apache.xml.security.Init.init();\" to do that before you use any functionality from that library.";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getExceptionMessage(String msgID, Exception originalException)
/*     */   {
/*     */     try
/*     */     {
/* 126 */       Object[] exArgs = { originalException.getMessage() };
/* 127 */       return MessageFormat.format(resourceBundle.getString(msgID), exArgs);
/*     */ 
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 132 */       if (Init.isInitialized()) {
/* 133 */         return "No message with ID \"" + msgID + "\" found in resource bundle \"" + "org/apache/xml/security/resource/xmlsecurity" + "\". Original Exception was a " + originalException.getClass().getName() + " and message " + originalException.getMessage();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 140 */     return "You must initialize the xml-security library correctly before you use it. Call the static method \"org.apache.xml.security.Init.init();\" to do that before you use any functionality from that library.";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getExceptionMessage(String msgID, Object[] exArgs)
/*     */   {
/*     */     try
/*     */     {
/* 154 */       return MessageFormat.format(resourceBundle.getString(msgID), exArgs);
/*     */ 
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 159 */       if (Init.isInitialized()) {
/* 160 */         return "No message with ID \"" + msgID + "\" found in resource bundle \"" + "org/apache/xml/security/resource/xmlsecurity" + "\"";
/*     */       }
/*     */     }
/*     */     
/* 164 */     return "You must initialize the xml-security library correctly before you use it. Call the static method \"org.apache.xml.security.Init.init();\" to do that before you use any functionality from that library.";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void init(String _defaultLanguageCode, String _defaultCountryCode)
/*     */   {
/* 177 */     defaultLanguageCode = _defaultLanguageCode;
/*     */     
/* 179 */     if (defaultLanguageCode == null) {
/* 180 */       defaultLanguageCode = Locale.getDefault().getLanguage();
/*     */     }
/*     */     
/* 183 */     defaultCountryCode = _defaultCountryCode;
/*     */     
/* 185 */     if (defaultCountryCode == null) {
/* 186 */       defaultCountryCode = Locale.getDefault().getCountry();
/*     */     }
/*     */     
/* 189 */     initLocale(defaultLanguageCode, defaultCountryCode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void initLocale(String languageCode, String countryCode)
/*     */   {
/* 200 */     if ((alreadyInitialized) && (languageCode.equals(_languageCode)) && (countryCode.equals(_countryCode)))
/*     */     {
/* 202 */       return;
/*     */     }
/*     */     
/* 205 */     if ((languageCode != null) && (countryCode != null) && (languageCode.length() > 0) && (countryCode.length() > 0))
/*     */     {
/* 207 */       _languageCode = languageCode;
/* 208 */       _countryCode = countryCode;
/*     */     } else {
/* 210 */       _countryCode = defaultCountryCode;
/* 211 */       _languageCode = defaultLanguageCode;
/*     */     }
/*     */     
/* 214 */     resourceBundle = ResourceBundle.getBundle("org/apache/xml/security/resource/xmlsecurity", new Locale(_languageCode, _countryCode));
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\utils\I18n.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */