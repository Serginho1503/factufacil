/*    */ package org.apache.xml.security.c14n.implementations;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Canonicalizer11_WithComments
/*    */   extends Canonicalizer11
/*    */ {
/*    */   public Canonicalizer11_WithComments()
/*    */   {
/* 27 */     super(true);
/*    */   }
/*    */   
/*    */   public final String engineGetURI() {
/* 31 */     return "http://www.w3.org/2006/12/xml-c14n11#WithComments";
/*    */   }
/*    */   
/*    */   public final boolean engineGetIncludeComments() {
/* 35 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\c14n\implementations\Canonicalizer11_WithComments.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */