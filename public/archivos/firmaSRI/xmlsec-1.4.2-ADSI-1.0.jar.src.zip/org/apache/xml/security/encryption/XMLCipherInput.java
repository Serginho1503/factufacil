/*     */ package org.apache.xml.security.encryption;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import org.apache.xml.security.exceptions.Base64DecodingException;
/*     */ import org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import org.apache.xml.security.transforms.TransformationException;
/*     */ import org.apache.xml.security.utils.Base64;
/*     */ import org.apache.xml.security.utils.resolver.ResourceResolver;
/*     */ import org.apache.xml.security.utils.resolver.ResourceResolverException;
/*     */ import org.w3c.dom.Attr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLCipherInput
/*     */ {
/*  48 */   private static Log logger = LogFactory.getLog(XMLCipher.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private CipherData _cipherData;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int _mode;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLCipherInput(CipherData data)
/*     */     throws XMLEncryptionException
/*     */   {
/*  66 */     this._cipherData = data;
/*  67 */     this._mode = 2;
/*  68 */     if (this._cipherData == null) {
/*  69 */       throw new XMLEncryptionException("CipherData is null");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLCipherInput(EncryptedType input)
/*     */     throws XMLEncryptionException
/*     */   {
/*  84 */     this._cipherData = (input == null ? null : input.getCipherData());
/*  85 */     this._mode = 2;
/*  86 */     if (this._cipherData == null) {
/*  87 */       throw new XMLEncryptionException("CipherData is null");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getBytes()
/*     */     throws XMLEncryptionException
/*     */   {
/* 101 */     if (this._mode == 2) {
/* 102 */       return getDecryptBytes();
/*     */     }
/* 104 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] getDecryptBytes()
/*     */     throws XMLEncryptionException
/*     */   {
/* 114 */     String base64EncodedEncryptedOctets = null;
/*     */     
/* 116 */     if (this._cipherData.getDataType() == 2)
/*     */     {
/* 118 */       logger.debug("Found a reference type CipherData");
/* 119 */       CipherReference cr = this._cipherData.getCipherReference();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 124 */       Attr uriAttr = cr.getURIAsAttr();
/* 125 */       XMLSignatureInput input = null;
/*     */       try
/*     */       {
/* 128 */         ResourceResolver resolver = ResourceResolver.getInstance(uriAttr, null);
/*     */         
/* 130 */         input = resolver.resolve(uriAttr, null);
/*     */       } catch (ResourceResolverException ex) {
/* 132 */         throw new XMLEncryptionException("empty", ex);
/*     */       }
/*     */       
/* 135 */       if (input != null) {
/* 136 */         logger.debug("Managed to resolve URI \"" + cr.getURI() + "\"");
/*     */       } else {
/* 138 */         logger.debug("Failed to resolve URI \"" + cr.getURI() + "\"");
/*     */       }
/*     */       
/*     */ 
/* 142 */       Transforms transforms = cr.getTransforms();
/* 143 */       if (transforms != null) {
/* 144 */         logger.debug("Have transforms in cipher reference");
/*     */         try {
/* 146 */           org.apache.xml.security.transforms.Transforms dsTransforms = transforms.getDSTransforms();
/*     */           
/* 148 */           input = dsTransforms.performTransforms(input);
/*     */         } catch (TransformationException ex) {
/* 150 */           throw new XMLEncryptionException("empty", ex);
/*     */         }
/*     */       }
/*     */       try
/*     */       {
/* 155 */         return input.getBytes();
/*     */       } catch (IOException ex) {
/* 157 */         throw new XMLEncryptionException("empty", ex);
/*     */       } catch (CanonicalizationException ex) {
/* 159 */         throw new XMLEncryptionException("empty", ex);
/*     */       }
/*     */     }
/*     */     
/* 163 */     if (this._cipherData.getDataType() == 1) {
/* 164 */       base64EncodedEncryptedOctets = this._cipherData.getCipherValue().getValue();
/*     */     }
/*     */     else {
/* 167 */       throw new XMLEncryptionException("CipherData.getDataType() returned unexpected value");
/*     */     }
/*     */     
/* 170 */     logger.debug("Encrypted octets:\n" + base64EncodedEncryptedOctets);
/*     */     
/* 172 */     byte[] encryptedBytes = null;
/*     */     try {
/* 174 */       encryptedBytes = Base64.decode(base64EncodedEncryptedOctets);
/*     */     } catch (Base64DecodingException bde) {
/* 176 */       throw new XMLEncryptionException("empty", bde);
/*     */     }
/*     */     
/* 179 */     return encryptedBytes;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\encryption\XMLCipherInput.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */