/*     */ package org.apache.xml.security.keys.storage.implementations;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import org.apache.xml.security.keys.content.x509.XMLX509SKI;
/*     */ import org.apache.xml.security.keys.storage.StorageResolverException;
/*     */ import org.apache.xml.security.keys.storage.StorageResolverSpi;
/*     */ import org.apache.xml.security.utils.Base64;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyStoreResolver
/*     */   extends StorageResolverSpi
/*     */ {
/*  39 */   KeyStore _keyStore = null;
/*     */   
/*     */ 
/*  42 */   Iterator _iterator = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyStoreResolver(KeyStore keyStore)
/*     */     throws StorageResolverException
/*     */   {
/*  51 */     this._keyStore = keyStore;
/*  52 */     this._iterator = new KeyStoreIterator(this._keyStore);
/*     */   }
/*     */   
/*     */   public Iterator getIterator()
/*     */   {
/*  57 */     return this._iterator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static class KeyStoreIterator
/*     */     implements Iterator
/*     */   {
/*  69 */     KeyStore _keyStore = null;
/*     */     
/*     */ 
/*  72 */     Enumeration _aliases = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public KeyStoreIterator(KeyStore keyStore)
/*     */       throws StorageResolverException
/*     */     {
/*     */       try
/*     */       {
/*  84 */         this._keyStore = keyStore;
/*  85 */         this._aliases = this._keyStore.aliases();
/*     */       } catch (KeyStoreException ex) {
/*  87 */         throw new StorageResolverException("generic.EmptyMessage", ex);
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean hasNext()
/*     */     {
/*  93 */       return this._aliases.hasMoreElements();
/*     */     }
/*     */     
/*     */ 
/*     */     public Object next()
/*     */     {
/*  99 */       String alias = (String)this._aliases.nextElement();
/*     */       try
/*     */       {
/* 102 */         return this._keyStore.getCertificate(alias);
/*     */       } catch (KeyStoreException ex) {}
/* 104 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void remove()
/*     */     {
/* 113 */       throw new UnsupportedOperationException("Can't remove keys from KeyStore");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] unused)
/*     */     throws Exception
/*     */   {
/* 126 */     KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
/*     */     
/* 128 */     ks.load(new FileInputStream("data/org/apache/xml/security/samples/input/keystore.jks"), "xmlsecurity".toCharArray());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 133 */     KeyStoreResolver krs = new KeyStoreResolver(ks);
/*     */     
/* 135 */     for (Iterator i = krs.getIterator(); i.hasNext();) {
/* 136 */       X509Certificate cert = (X509Certificate)i.next();
/* 137 */       byte[] ski = XMLX509SKI.getSKIBytesFromCert(cert);
/*     */       
/*     */ 
/*     */ 
/* 141 */       System.out.println(Base64.encode(ski));
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\storage\implementations\KeyStoreResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */