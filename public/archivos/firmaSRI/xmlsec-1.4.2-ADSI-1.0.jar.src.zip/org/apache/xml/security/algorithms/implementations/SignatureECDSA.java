/*     */ package org.apache.xml.security.algorithms.implementations;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.Key;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.Provider;
/*     */ import java.security.PublicKey;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.Signature;
/*     */ import java.security.SignatureException;
/*     */ import java.security.spec.AlgorithmParameterSpec;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.algorithms.JCEMapper;
/*     */ import org.apache.xml.security.algorithms.SignatureAlgorithmSpi;
/*     */ import org.apache.xml.security.signature.XMLSignatureException;
/*     */ import org.apache.xml.security.utils.Base64;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SignatureECDSA
/*     */   extends SignatureAlgorithmSpi
/*     */ {
/*  51 */   static Log log = LogFactory.getLog(SignatureECDSA.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  58 */   private Signature _signatureAlgorithm = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String engineGetURI();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static byte[] convertASN1toXMLDSIG(byte[] asn1Bytes)
/*     */     throws IOException
/*     */   {
/*  76 */     byte rLength = asn1Bytes[3];
/*     */     
/*     */ 
/*  79 */     for (int i = rLength; (i > 0) && (asn1Bytes[(4 + rLength - i)] == 0); i--) {}
/*     */     
/*  81 */     byte sLength = asn1Bytes[(5 + rLength)];
/*     */     
/*     */ 
/*  84 */     int j = sLength;
/*  85 */     while ((j > 0) && (asn1Bytes[(6 + rLength + sLength - j)] == 0)) { j--;
/*     */     }
/*  87 */     if ((asn1Bytes[0] != 48) || (asn1Bytes[1] != asn1Bytes.length - 2) || (asn1Bytes[2] != 2) || (i > 24) || (asn1Bytes[(4 + rLength)] != 2) || (j > 24))
/*     */     {
/*     */ 
/*  90 */       throw new IOException("Invalid ASN.1 format of ECDSA signature");
/*     */     }
/*  92 */     byte[] xmldsigBytes = new byte[48];
/*     */     
/*  94 */     System.arraycopy(asn1Bytes, 4 + rLength - i, xmldsigBytes, 24 - i, i);
/*     */     
/*  96 */     System.arraycopy(asn1Bytes, 6 + rLength + sLength - j, xmldsigBytes, 48 - j, j);
/*     */     
/*     */ 
/*  99 */     return xmldsigBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static byte[] convertXMLDSIGtoASN1(byte[] xmldsigBytes)
/*     */     throws IOException
/*     */   {
/* 118 */     if (xmldsigBytes.length != 48) {
/* 119 */       throw new IOException("Invalid XMLDSIG format of ECDSA signature");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 124 */     for (int i = 24; (i > 0) && (xmldsigBytes[(24 - i)] == 0); i--) {}
/*     */     
/* 126 */     int j = i;
/*     */     
/* 128 */     if (xmldsigBytes[(24 - i)] < 0) {
/* 129 */       j++;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 134 */     for (int k = 24; (k > 0) && (xmldsigBytes[(48 - k)] == 0); k--) {}
/*     */     
/* 136 */     int l = k;
/*     */     
/* 138 */     if (xmldsigBytes[(48 - k)] < 0) {
/* 139 */       l++;
/*     */     }
/*     */     
/* 142 */     byte[] asn1Bytes = new byte[6 + j + l];
/*     */     
/* 144 */     asn1Bytes[0] = 48;
/* 145 */     asn1Bytes[1] = ((byte)(4 + j + l));
/* 146 */     asn1Bytes[2] = 2;
/* 147 */     asn1Bytes[3] = ((byte)j);
/*     */     
/* 149 */     System.arraycopy(xmldsigBytes, 24 - i, asn1Bytes, 4 + j - i, i);
/*     */     
/* 151 */     asn1Bytes[(4 + j)] = 2;
/* 152 */     asn1Bytes[(5 + j)] = ((byte)l);
/*     */     
/* 154 */     System.arraycopy(xmldsigBytes, 48 - k, asn1Bytes, 6 + j + l - k, k);
/*     */     
/* 156 */     return asn1Bytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignatureECDSA()
/*     */     throws XMLSignatureException
/*     */   {
/* 166 */     String algorithmID = JCEMapper.translateURItoJCEID(engineGetURI());
/*     */     
/* 168 */     if (log.isDebugEnabled())
/* 169 */       log.debug("Created SignatureECDSA using " + algorithmID);
/* 170 */     Provider providerThread = JCEMapper.getProviderSignatureThread();
/* 171 */     String provider = null;
/* 172 */     if (providerThread == null) {
/* 173 */       provider = JCEMapper.getProviderId();
/*     */     }
/*     */     try {
/* 176 */       if (providerThread == null) {
/* 177 */         if (provider == null) {
/* 178 */           this._signatureAlgorithm = Signature.getInstance(algorithmID);
/*     */         } else {
/* 180 */           this._signatureAlgorithm = Signature.getInstance(algorithmID, provider);
/*     */         }
/*     */       } else {
/* 183 */         this._signatureAlgorithm = Signature.getInstance(algorithmID, providerThread);
/*     */       }
/*     */     } catch (NoSuchAlgorithmException ex) {
/* 186 */       Object[] exArgs = { algorithmID, ex.getLocalizedMessage() };
/*     */       
/*     */ 
/* 189 */       throw new XMLSignatureException("algorithms.NoSuchAlgorithm", exArgs);
/*     */     } catch (NoSuchProviderException ex) {
/* 191 */       Object[] exArgs = { algorithmID, ex.getLocalizedMessage() };
/*     */       
/*     */ 
/* 194 */       throw new XMLSignatureException("algorithms.NoSuchAlgorithm", exArgs);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void engineSetParameter(AlgorithmParameterSpec params)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 203 */       this._signatureAlgorithm.setParameter(params);
/*     */     } catch (InvalidAlgorithmParameterException ex) {
/* 205 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean engineVerify(byte[] signature)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 214 */       byte[] jcebytes = convertXMLDSIGtoASN1(signature);
/*     */       
/* 216 */       if (log.isDebugEnabled()) {
/* 217 */         log.debug("Called ECDSA.verify() on " + Base64.encode(signature));
/*     */       }
/* 219 */       return this._signatureAlgorithm.verify(jcebytes);
/*     */     } catch (SignatureException ex) {
/* 221 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (IOException ex) {
/* 223 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void engineInitVerify(Key publicKey)
/*     */     throws XMLSignatureException
/*     */   {
/* 230 */     if (!(publicKey instanceof PublicKey)) {
/* 231 */       String supplied = publicKey.getClass().getName();
/* 232 */       String needed = PublicKey.class.getName();
/* 233 */       Object[] exArgs = { supplied, needed };
/*     */       
/* 235 */       throw new XMLSignatureException("algorithms.WrongKeyForThisOperation", exArgs);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 240 */       this._signatureAlgorithm.initVerify((PublicKey)publicKey);
/*     */     }
/*     */     catch (InvalidKeyException ex)
/*     */     {
/* 244 */       Signature sig = this._signatureAlgorithm;
/*     */       try {
/* 246 */         this._signatureAlgorithm = Signature.getInstance(this._signatureAlgorithm.getAlgorithm());
/*     */ 
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 251 */         if (log.isDebugEnabled()) {
/* 252 */           log.debug("Exception when reinstantiating Signature:" + e);
/*     */         }
/* 254 */         this._signatureAlgorithm = sig;
/*     */       }
/* 256 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected byte[] engineSign() throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 264 */       byte[] jcebytes = this._signatureAlgorithm.sign();
/*     */       
/* 266 */       return convertASN1toXMLDSIG(jcebytes);
/*     */     } catch (SignatureException ex) {
/* 268 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (IOException ex) {
/* 270 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void engineInitSign(Key privateKey, SecureRandom secureRandom)
/*     */     throws XMLSignatureException
/*     */   {
/* 278 */     if (!(privateKey instanceof PrivateKey)) {
/* 279 */       String supplied = privateKey.getClass().getName();
/* 280 */       String needed = PrivateKey.class.getName();
/* 281 */       Object[] exArgs = { supplied, needed };
/*     */       
/* 283 */       throw new XMLSignatureException("algorithms.WrongKeyForThisOperation", exArgs);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 288 */       this._signatureAlgorithm.initSign((PrivateKey)privateKey, secureRandom);
/*     */     }
/*     */     catch (InvalidKeyException ex) {
/* 291 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void engineInitSign(Key privateKey)
/*     */     throws XMLSignatureException
/*     */   {
/* 298 */     if (!(privateKey instanceof PrivateKey)) {
/* 299 */       String supplied = privateKey.getClass().getName();
/* 300 */       String needed = PrivateKey.class.getName();
/* 301 */       Object[] exArgs = { supplied, needed };
/*     */       
/* 303 */       throw new XMLSignatureException("algorithms.WrongKeyForThisOperation", exArgs);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 308 */       this._signatureAlgorithm.initSign((PrivateKey)privateKey);
/*     */     } catch (InvalidKeyException ex) {
/* 310 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void engineUpdate(byte[] input) throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 318 */       this._signatureAlgorithm.update(input);
/*     */     } catch (SignatureException ex) {
/* 320 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void engineUpdate(byte input) throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 328 */       this._signatureAlgorithm.update(input);
/*     */     } catch (SignatureException ex) {
/* 330 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void engineUpdate(byte[] buf, int offset, int len)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 339 */       this._signatureAlgorithm.update(buf, offset, len);
/*     */     } catch (SignatureException ex) {
/* 341 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected String engineGetJCEAlgorithmString()
/*     */   {
/* 347 */     return this._signatureAlgorithm.getAlgorithm();
/*     */   }
/*     */   
/*     */   protected String engineGetJCEProviderName()
/*     */   {
/* 352 */     return this._signatureAlgorithm.getProvider().getName();
/*     */   }
/*     */   
/*     */   protected void engineSetHMACOutputLength(int HMACOutputLength)
/*     */     throws XMLSignatureException
/*     */   {
/* 358 */     throw new XMLSignatureException("algorithms.HMACOutputLengthOnlyForHMAC");
/*     */   }
/*     */   
/*     */ 
/*     */   protected void engineInitSign(Key signingKey, AlgorithmParameterSpec algorithmParameterSpec)
/*     */     throws XMLSignatureException
/*     */   {
/* 365 */     throw new XMLSignatureException("algorithms.CannotUseAlgorithmParameterSpecOnRSA");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class SignatureECDSASHA1
/*     */     extends SignatureECDSA
/*     */   {
/*     */     public SignatureECDSASHA1()
/*     */       throws XMLSignatureException
/*     */     {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String engineGetURI()
/*     */     {
/* 388 */       return "http://www.w3.org/2001/04/xmldsig-more#ecdsa-sha1";
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\algorithms\implementations\SignatureECDSA.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */