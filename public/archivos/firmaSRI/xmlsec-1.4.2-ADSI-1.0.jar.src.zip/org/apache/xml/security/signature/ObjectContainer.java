/*     */ package org.apache.xml.security.signature;
/*     */ 
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.utils.IdResolver;
/*     */ import org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjectContainer
/*     */   extends SignatureElementProxy
/*     */ {
/*     */   public ObjectContainer(Document doc)
/*     */   {
/*  44 */     super(doc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectContainer(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  57 */     super(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setId(String Id)
/*     */   {
/*  67 */     if (Id != null) {
/*  68 */       this._constructionElement.setAttributeNS(null, "Id", Id);
/*  69 */       IdResolver.registerElementById(this._constructionElement, Id);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getId()
/*     */   {
/*  79 */     return this._constructionElement.getAttributeNS(null, "Id");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMimeType(String MimeType)
/*     */   {
/*  89 */     if (MimeType != null) {
/*  90 */       this._constructionElement.setAttributeNS(null, "MimeType", MimeType);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMimeType()
/*     */   {
/* 101 */     return this._constructionElement.getAttributeNS(null, "MimeType");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEncoding(String Encoding)
/*     */   {
/* 111 */     if (Encoding != null) {
/* 112 */       this._constructionElement.setAttributeNS(null, "Encoding", Encoding);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getEncoding()
/*     */   {
/* 123 */     return this._constructionElement.getAttributeNS(null, "Encoding");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node appendChild(Node node)
/*     */   {
/* 134 */     Node result = null;
/*     */     
/* 136 */     result = this._constructionElement.appendChild(node);
/*     */     
/* 138 */     return result;
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 143 */     return "Object";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\signature\ObjectContainer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */