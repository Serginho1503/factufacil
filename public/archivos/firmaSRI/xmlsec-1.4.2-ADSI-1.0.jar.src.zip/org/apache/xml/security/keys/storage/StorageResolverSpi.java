package org.apache.xml.security.keys.storage;

import java.util.Iterator;

public abstract class StorageResolverSpi
{
  public abstract Iterator getIterator();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\storage\StorageResolverSpi.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */