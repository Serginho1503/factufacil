/*     */ package org.apache.xml.security.transforms;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import org.apache.xml.security.c14n.InvalidCanonicalizerException;
/*     */ import org.apache.xml.security.exceptions.AlgorithmAlreadyRegisteredException;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import org.apache.xml.security.utils.HelperNodeList;
/*     */ import org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Transform
/*     */   extends SignatureElementProxy
/*     */ {
/*  60 */   static Log log = LogFactory.getLog(Transform.class.getName());
/*     */   
/*     */ 
/*     */ 
/*  64 */   static boolean _alreadyInitialized = false;
/*     */   
/*     */ 
/*  67 */   static Map _transformHash = null;
/*     */   
/*  69 */   static HashMap classesHash = new HashMap();
/*     */   
/*     */ 
/*  72 */   protected TransformSpi transformSpi = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Transform(Document doc, String algorithmURI, NodeList contextNodes)
/*     */     throws InvalidTransformException
/*     */   {
/*  87 */     super(doc);
/*     */     
/*  89 */     this._constructionElement.setAttributeNS(null, "Algorithm", algorithmURI);
/*     */     
/*     */ 
/*  92 */     this.transformSpi = getImplementingClass(algorithmURI);
/*     */     
/*     */ 
/*  95 */     if (this.transformSpi == null) {
/*  96 */       Object[] exArgs = { algorithmURI };
/*     */       
/*  98 */       throw new InvalidTransformException("signature.Transform.UnknownTransform", exArgs);
/*     */     }
/*     */     
/* 101 */     if (log.isDebugEnabled()) {
/* 102 */       log.debug("Create URI \"" + algorithmURI + "\" class \"" + this.transformSpi.getClass() + "\"");
/*     */       
/* 104 */       log.debug("The NodeList is " + contextNodes);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 111 */     if (contextNodes != null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 118 */       for (int i = 0; i < contextNodes.getLength(); i++) {
/* 119 */         this._constructionElement.appendChild(contextNodes.item(i).cloneNode(true));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Transform(Element element, String BaseURI)
/*     */     throws InvalidTransformException, TransformationException, XMLSecurityException
/*     */   {
/* 140 */     super(element, BaseURI);
/*     */     
/*     */ 
/* 143 */     String AlgorithmURI = element.getAttributeNS(null, "Algorithm");
/*     */     
/* 145 */     if ((AlgorithmURI == null) || (AlgorithmURI.length() == 0)) {
/* 146 */       Object[] exArgs = { "Algorithm", "Transform" };
/*     */       
/*     */ 
/* 149 */       throw new TransformationException("xml.WrongContent", exArgs);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 154 */     this.transformSpi = getImplementingClass(AlgorithmURI);
/*     */     
/*     */ 
/* 157 */     if (this.transformSpi == null) {
/* 158 */       Object[] exArgs = { AlgorithmURI };
/*     */       
/* 160 */       throw new InvalidTransformException("signature.Transform.UnknownTransform", exArgs);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final Transform getInstance(Document doc, String algorithmURI)
/*     */     throws InvalidTransformException
/*     */   {
/* 175 */     return getInstance(doc, algorithmURI, (NodeList)null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final Transform getInstance(Document doc, String algorithmURI, Element contextChild)
/*     */     throws InvalidTransformException
/*     */   {
/* 191 */     HelperNodeList contextNodes = new HelperNodeList();
/*     */     
/* 193 */     XMLUtils.addReturnToElement(doc, contextNodes);
/* 194 */     contextNodes.appendChild(contextChild);
/* 195 */     XMLUtils.addReturnToElement(doc, contextNodes);
/*     */     
/* 197 */     return getInstance(doc, algorithmURI, contextNodes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final Transform getInstance(Document doc, String algorithmURI, NodeList contextNodes)
/*     */     throws InvalidTransformException
/*     */   {
/* 212 */     return new Transform(doc, algorithmURI, contextNodes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void init()
/*     */   {
/* 221 */     if (!_alreadyInitialized) {
/* 222 */       _transformHash = new HashMap(10);
/* 223 */       _alreadyInitialized = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void register(String algorithmURI, String implementingClass)
/*     */     throws AlgorithmAlreadyRegisteredException
/*     */   {
/* 241 */     Object registeredClass = null;
/*     */     try {
/* 243 */       registeredClass = getImplementingClass(algorithmURI);
/*     */     } catch (InvalidTransformException e1) {
/* 245 */       Object[] exArgs = { algorithmURI, registeredClass };
/* 246 */       throw new AlgorithmAlreadyRegisteredException("algorithm.alreadyRegistered", exArgs);
/*     */     }
/*     */     
/*     */ 
/* 250 */     if (registeredClass != null) {
/* 251 */       Object[] exArgs = { algorithmURI, registeredClass };
/* 252 */       throw new AlgorithmAlreadyRegisteredException("algorithm.alreadyRegistered", exArgs);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 257 */       _transformHash.put(algorithmURI, Class.forName(implementingClass));
/*     */     }
/*     */     catch (ClassNotFoundException e) {
/* 260 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getURI()
/*     */   {
/* 271 */     return this._constructionElement.getAttributeNS(null, "Algorithm");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput performTransform(XMLSignatureInput input)
/*     */     throws IOException, CanonicalizationException, InvalidCanonicalizerException, TransformationException
/*     */   {
/* 288 */     XMLSignatureInput result = null;
/*     */     try
/*     */     {
/* 291 */       result = this.transformSpi.enginePerformTransform(input, this);
/*     */     } catch (ParserConfigurationException ex) {
/* 293 */       Object[] exArgs = { getURI(), "ParserConfigurationException" };
/*     */       
/* 295 */       throw new CanonicalizationException("signature.Transform.ErrorDuringTransform", exArgs, ex);
/*     */     }
/*     */     catch (SAXException ex) {
/* 298 */       Object[] exArgs = { getURI(), "SAXException" };
/*     */       
/* 300 */       throw new CanonicalizationException("signature.Transform.ErrorDuringTransform", exArgs, ex);
/*     */     }
/*     */     
/*     */ 
/* 304 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput performTransform(XMLSignatureInput input, OutputStream os)
/*     */     throws IOException, CanonicalizationException, InvalidCanonicalizerException, TransformationException
/*     */   {
/* 322 */     XMLSignatureInput result = null;
/*     */     try
/*     */     {
/* 325 */       result = this.transformSpi.enginePerformTransform(input, os, this);
/*     */     } catch (ParserConfigurationException ex) {
/* 327 */       Object[] exArgs = { getURI(), "ParserConfigurationException" };
/*     */       
/* 329 */       throw new CanonicalizationException("signature.Transform.ErrorDuringTransform", exArgs, ex);
/*     */     }
/*     */     catch (SAXException ex) {
/* 332 */       Object[] exArgs = { getURI(), "SAXException" };
/*     */       
/* 334 */       throw new CanonicalizationException("signature.Transform.ErrorDuringTransform", exArgs, ex);
/*     */     }
/*     */     
/*     */ 
/* 338 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static TransformSpi getImplementingClass(String URI)
/*     */     throws InvalidTransformException
/*     */   {
/*     */     try
/*     */     {
/* 350 */       Object value = classesHash.get(URI);
/* 351 */       if (value != null) {
/* 352 */         return (TransformSpi)value;
/*     */       }
/* 354 */       Class cl = (Class)_transformHash.get(URI);
/* 355 */       if (cl != null) {
/* 356 */         TransformSpi tr = (TransformSpi)cl.newInstance();
/* 357 */         classesHash.put(URI, tr);
/* 358 */         return tr;
/*     */       }
/*     */     } catch (InstantiationException ex) {
/* 361 */       Object[] exArgs = { URI };
/* 362 */       throw new InvalidTransformException("signature.Transform.UnknownTransform", exArgs, ex);
/*     */     }
/*     */     catch (IllegalAccessException ex) {
/* 365 */       Object[] exArgs = { URI };
/* 366 */       throw new InvalidTransformException("signature.Transform.UnknownTransform", exArgs, ex);
/*     */     }
/*     */     
/* 369 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getBaseLocalName()
/*     */   {
/* 375 */     return "Transform";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\transforms\Transform.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */