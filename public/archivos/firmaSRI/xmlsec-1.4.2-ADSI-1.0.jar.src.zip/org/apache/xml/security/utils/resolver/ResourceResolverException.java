/*     */ package org.apache.xml.security.utils.resolver;
/*     */ 
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.w3c.dom.Attr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceResolverException
/*     */   extends XMLSecurityException
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public ResourceResolverException(String _msgID, Attr uri, String BaseURI)
/*     */   {
/*  47 */     super(_msgID);
/*     */     
/*  49 */     this._uri = uri;
/*  50 */     this._BaseURI = BaseURI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceResolverException(String _msgID, Object[] exArgs, Attr uri, String BaseURI)
/*     */   {
/*  64 */     super(_msgID, exArgs);
/*     */     
/*  66 */     this._uri = uri;
/*  67 */     this._BaseURI = BaseURI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceResolverException(String _msgID, Exception _originalException, Attr uri, String BaseURI)
/*     */   {
/*  81 */     super(_msgID, _originalException);
/*     */     
/*  83 */     this._uri = uri;
/*  84 */     this._BaseURI = BaseURI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceResolverException(String _msgID, Object[] exArgs, Exception _originalException, Attr uri, String BaseURI)
/*     */   {
/* 100 */     super(_msgID, exArgs, _originalException);
/*     */     
/* 102 */     this._uri = uri;
/* 103 */     this._BaseURI = BaseURI;
/*     */   }
/*     */   
/*     */ 
/* 107 */   Attr _uri = null;
/*     */   
/*     */   String _BaseURI;
/*     */   
/*     */   public void setURI(Attr uri)
/*     */   {
/* 113 */     this._uri = uri;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Attr getURI()
/*     */   {
/* 121 */     return this._uri;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBaseURI(String BaseURI)
/*     */   {
/* 131 */     this._BaseURI = BaseURI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBaseURI()
/*     */   {
/* 139 */     return this._BaseURI;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\utils\resolver\ResourceResolverException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */