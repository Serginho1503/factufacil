/*     */ package org.apache.xml.security.signature;
/*     */ 
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.utils.IdResolver;
/*     */ import org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignatureProperty
/*     */   extends SignatureElementProxy
/*     */ {
/*     */   public SignatureProperty(Document doc, String Target)
/*     */   {
/*  43 */     this(doc, Target, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignatureProperty(Document doc, String Target, String Id)
/*     */   {
/*  55 */     super(doc);
/*     */     
/*  57 */     setTarget(Target);
/*  58 */     setId(Id);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignatureProperty(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  69 */     super(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setId(String Id)
/*     */   {
/*  79 */     if (Id != null) {
/*  80 */       this._constructionElement.setAttributeNS(null, "Id", Id);
/*  81 */       IdResolver.registerElementById(this._constructionElement, Id);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getId()
/*     */   {
/*  91 */     return this._constructionElement.getAttributeNS(null, "Id");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTarget(String Target)
/*     */   {
/* 101 */     if (Target != null) {
/* 102 */       this._constructionElement.setAttributeNS(null, "Target", Target);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTarget()
/*     */   {
/* 112 */     return this._constructionElement.getAttributeNS(null, "Target");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node appendChild(Node node)
/*     */   {
/* 122 */     return this._constructionElement.appendChild(node);
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 127 */     return "SignatureProperty";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\signature\SignatureProperty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */