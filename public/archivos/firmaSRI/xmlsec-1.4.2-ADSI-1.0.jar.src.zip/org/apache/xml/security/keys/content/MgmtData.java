/*    */ package org.apache.xml.security.keys.content;
/*    */ 
/*    */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*    */ import org.apache.xml.security.utils.SignatureElementProxy;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MgmtData
/*    */   extends SignatureElementProxy
/*    */   implements KeyInfoContent
/*    */ {
/*    */   public MgmtData(Element element, String BaseURI)
/*    */     throws XMLSecurityException
/*    */   {
/* 40 */     super(element, BaseURI);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public MgmtData(Document doc, String mgmtData)
/*    */   {
/* 51 */     super(doc);
/*    */     
/* 53 */     addText(mgmtData);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getMgmtData()
/*    */   {
/* 62 */     return getTextFromTextChild();
/*    */   }
/*    */   
/*    */   public String getBaseLocalName()
/*    */   {
/* 67 */     return "MgmtData";
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\content\MgmtData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */