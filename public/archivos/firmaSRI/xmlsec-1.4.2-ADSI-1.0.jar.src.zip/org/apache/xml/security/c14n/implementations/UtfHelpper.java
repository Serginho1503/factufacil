/*     */ package org.apache.xml.security.c14n.implementations;
/*     */ 
/*     */ import java.io.OutputStream;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class UtfHelpper
/*     */ {
/*     */   static final void writeByte(String str, OutputStream out, Map cache) throws java.io.IOException
/*     */   {
/*  10 */     byte[] result = (byte[])cache.get(str);
/*  11 */     if (result == null) {
/*  12 */       result = getStringInUtf8(str);
/*  13 */       cache.put(str, result);
/*     */     }
/*     */     
/*  16 */     out.write(result);
/*     */   }
/*     */   
/*     */   static final void writeCharToUtf8(char c, OutputStream out) throws java.io.IOException
/*     */   {
/*  21 */     if (c < '') {
/*  22 */       out.write(c);
/*  23 */       return;
/*     */     }
/*  25 */     if (((c >= 55296) && (c <= 56319)) || ((c >= 56320) && (c <= 57343)))
/*     */     {
/*  27 */       out.write(63); return;
/*     */     }
/*     */     
/*     */     int bias;
/*     */     int write;
/*     */     int bias;
/*  33 */     if (c > '߿') {
/*  34 */       char ch = (char)(c >>> '\f');
/*  35 */       int write = 224;
/*  36 */       if (ch > 0) {
/*  37 */         write |= ch & 0xF;
/*     */       }
/*  39 */       out.write(write);
/*  40 */       write = 128;
/*  41 */       bias = 63;
/*     */     } else {
/*  43 */       write = 192;
/*  44 */       bias = 31;
/*     */     }
/*  46 */     char ch = (char)(c >>> '\006');
/*  47 */     if (ch > 0) {
/*  48 */       write |= ch & bias;
/*     */     }
/*  50 */     out.write(write);
/*  51 */     out.write(0x80 | c & 0x3F);
/*     */   }
/*     */   
/*     */   static final void writeStringToUtf8(String str, OutputStream out) throws java.io.IOException
/*     */   {
/*  56 */     int length = str.length();
/*  57 */     int i = 0;
/*     */     
/*  59 */     while (i < length) {
/*  60 */       char c = str.charAt(i++);
/*  61 */       if (c < '') {
/*  62 */         out.write(c);
/*     */ 
/*     */       }
/*  65 */       else if (((c >= 55296) && (c <= 56319)) || ((c >= 56320) && (c <= 57343)))
/*     */       {
/*  67 */         out.write(63);
/*     */       }
/*     */       else {
/*     */         int bias;
/*     */         int write;
/*     */         int bias;
/*  73 */         if (c > '߿') {
/*  74 */           char ch = (char)(c >>> '\f');
/*  75 */           int write = 224;
/*  76 */           if (ch > 0) {
/*  77 */             write |= ch & 0xF;
/*     */           }
/*  79 */           out.write(write);
/*  80 */           write = 128;
/*  81 */           bias = 63;
/*     */         } else {
/*  83 */           write = 192;
/*  84 */           bias = 31;
/*     */         }
/*  86 */         char ch = (char)(c >>> '\006');
/*  87 */         if (ch > 0) {
/*  88 */           write |= ch & bias;
/*     */         }
/*  90 */         out.write(write);
/*  91 */         out.write(0x80 | c & 0x3F);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static final byte[] getStringInUtf8(String str) {
/*  97 */     int length = str.length();
/*  98 */     boolean expanded = false;
/*  99 */     byte[] result = new byte[length];
/* 100 */     int i = 0;
/* 101 */     int out = 0;
/*     */     
/* 103 */     while (i < length) {
/* 104 */       char c = str.charAt(i++);
/* 105 */       if (c < '') {
/* 106 */         result[(out++)] = ((byte)c);
/*     */ 
/*     */       }
/* 109 */       else if (((c >= 55296) && (c <= 56319)) || ((c >= 56320) && (c <= 57343)))
/*     */       {
/* 111 */         result[(out++)] = 63;
/*     */       }
/*     */       else
/*     */       {
/* 115 */         if (!expanded) {
/* 116 */           byte[] newResult = new byte[3 * length];
/* 117 */           System.arraycopy(result, 0, newResult, 0, out);
/* 118 */           result = newResult;
/* 119 */           expanded = true;
/*     */         }
/*     */         int bias;
/*     */         byte write;
/*     */         int bias;
/* 124 */         if (c > '߿') {
/* 125 */           char ch = (char)(c >>> '\f');
/* 126 */           byte write = -32;
/* 127 */           if (ch > 0) {
/* 128 */             write = (byte)(write | ch & 0xF);
/*     */           }
/* 130 */           result[(out++)] = write;
/* 131 */           write = Byte.MIN_VALUE;
/* 132 */           bias = 63;
/*     */         } else {
/* 134 */           write = -64;
/* 135 */           bias = 31;
/*     */         }
/* 137 */         char ch = (char)(c >>> '\006');
/* 138 */         if (ch > 0) {
/* 139 */           write = (byte)(write | ch & bias);
/*     */         }
/* 141 */         result[(out++)] = write;
/* 142 */         result[(out++)] = ((byte)(0x80 | c & 0x3F));
/*     */       }
/*     */     }
/* 145 */     if (expanded) {
/* 146 */       byte[] newResult = new byte[out];
/* 147 */       System.arraycopy(result, 0, newResult, 0, out);
/* 148 */       result = newResult;
/*     */     }
/* 150 */     return result;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\c14n\implementations\UtfHelpper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */