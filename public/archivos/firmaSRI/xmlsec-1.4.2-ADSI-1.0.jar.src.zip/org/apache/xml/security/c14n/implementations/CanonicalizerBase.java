/*     */ package org.apache.xml.security.c14n.implementations;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import org.apache.xml.security.c14n.CanonicalizerSpi;
/*     */ import org.apache.xml.security.c14n.helper.AttrCompare;
/*     */ import org.apache.xml.security.signature.NodeFilter;
/*     */ import org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import org.apache.xml.security.utils.UnsyncByteArrayOutputStream;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Comment;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.ProcessingInstruction;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CanonicalizerBase
/*     */   extends CanonicalizerSpi
/*     */ {
/*  62 */   private static final byte[] _END_PI = { 63, 62 };
/*  63 */   private static final byte[] _BEGIN_PI = { 60, 63 };
/*  64 */   private static final byte[] _END_COMM = { 45, 45, 62 };
/*  65 */   private static final byte[] _BEGIN_COMM = { 60, 33, 45, 45 };
/*  66 */   private static final byte[] __XA_ = { 38, 35, 120, 65, 59 };
/*  67 */   private static final byte[] __X9_ = { 38, 35, 120, 57, 59 };
/*  68 */   private static final byte[] _QUOT_ = { 38, 113, 117, 111, 116, 59 };
/*  69 */   private static final byte[] __XD_ = { 38, 35, 120, 68, 59 };
/*  70 */   private static final byte[] _GT_ = { 38, 103, 116, 59 };
/*  71 */   private static final byte[] _LT_ = { 38, 108, 116, 59 };
/*  72 */   private static final byte[] _END_TAG = { 60, 47 };
/*  73 */   private static final byte[] _AMP_ = { 38, 97, 109, 112, 59 };
/*  74 */   static final AttrCompare COMPARE = new AttrCompare();
/*     */   static final String XML = "xml";
/*     */   static final String XMLNS = "xmlns";
/*  77 */   static final byte[] equalsStr = { 61, 34 };
/*     */   static final int NODE_BEFORE_DOCUMENT_ELEMENT = -1;
/*     */   static final int NODE_NOT_BEFORE_OR_AFTER_DOCUMENT_ELEMENT = 0;
/*     */   static final int NODE_AFTER_DOCUMENT_ELEMENT = 1;
/*     */   protected static final Attr nullNode;
/*     */   List nodeFilter;
/*     */   boolean _includeComments;
/*     */   
/*  85 */   static { try { nullNode = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument().createAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns");
/*     */       
/*  87 */       nullNode.setValue("");
/*     */     } catch (Exception e) {
/*  89 */       throw new RuntimeException("Unable to create nullNode" + e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  96 */   Set _xpathNodeSet = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 101 */   Node _excludeNode = null;
/* 102 */   OutputStream _writer = new UnsyncByteArrayOutputStream();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CanonicalizerBase(boolean includeComments)
/*     */   {
/* 110 */     this._includeComments = includeComments;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalizeSubTree(Node rootNode)
/*     */     throws CanonicalizationException
/*     */   {
/* 121 */     return engineCanonicalizeSubTree(rootNode, (Node)null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalizeXPathNodeSet(Set xpathNodeSet)
/*     */     throws CanonicalizationException
/*     */   {
/* 131 */     this._xpathNodeSet = xpathNodeSet;
/* 132 */     return engineCanonicalizeXPathNodeSetInternal(XMLUtils.getOwnerDocument(this._xpathNodeSet));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalize(XMLSignatureInput input)
/*     */     throws CanonicalizationException
/*     */   {
/*     */     try
/*     */     {
/* 144 */       if (input.isExcludeComments()) {
/* 145 */         this._includeComments = false;
/*     */       }
/* 147 */       if (input.isOctetStream()) {
/* 148 */         return engineCanonicalize(input.getBytes());
/*     */       }
/* 150 */       if (input.isElement()) {
/* 151 */         return engineCanonicalizeSubTree(input.getSubNode(), input.getExcludeNode());
/*     */       }
/*     */       
/* 154 */       if (input.isNodeSet()) {
/* 155 */         this.nodeFilter = input.getNodeFilters();
/*     */         
/* 157 */         circumventBugIfNeeded(input);
/*     */         byte[] bytes;
/* 159 */         if (input.getSubNode() != null) {
/* 160 */           bytes = engineCanonicalizeXPathNodeSetInternal(input.getSubNode());
/*     */         }
/* 162 */         return engineCanonicalizeXPathNodeSet(input.getNodeSet());
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 167 */       return null;
/*     */     } catch (CanonicalizationException ex) {
/* 169 */       throw new CanonicalizationException("empty", ex);
/*     */     } catch (ParserConfigurationException ex) {
/* 171 */       throw new CanonicalizationException("empty", ex);
/*     */     } catch (IOException ex) {
/* 173 */       throw new CanonicalizationException("empty", ex);
/*     */     } catch (SAXException ex) {
/* 175 */       throw new CanonicalizationException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void setWriter(OutputStream _writer)
/*     */   {
/* 182 */     this._writer = _writer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] engineCanonicalizeSubTree(Node rootNode, Node excludeNode)
/*     */     throws CanonicalizationException
/*     */   {
/* 197 */     this._excludeNode = excludeNode;
/*     */     try {
/* 199 */       NameSpaceSymbTable ns = new NameSpaceSymbTable();
/* 200 */       int nodeLevel = -1;
/* 201 */       if ((rootNode instanceof Element))
/*     */       {
/* 203 */         getParentNameSpaces((Element)rootNode, ns);
/* 204 */         nodeLevel = 0;
/*     */       }
/* 206 */       canonicalizeSubTree(rootNode, ns, rootNode, nodeLevel);
/* 207 */       this._writer.close();
/* 208 */       if ((this._writer instanceof ByteArrayOutputStream)) {
/* 209 */         byte[] result = ((ByteArrayOutputStream)this._writer).toByteArray();
/* 210 */         if (this.reset) {
/* 211 */           ((ByteArrayOutputStream)this._writer).reset();
/*     */         }
/* 213 */         return result; }
/* 214 */       if ((this._writer instanceof UnsyncByteArrayOutputStream)) {
/* 215 */         byte[] result = ((UnsyncByteArrayOutputStream)this._writer).toByteArray();
/* 216 */         if (this.reset) {
/* 217 */           ((UnsyncByteArrayOutputStream)this._writer).reset();
/*     */         }
/* 219 */         return result;
/*     */       }
/* 221 */       return null;
/*     */     }
/*     */     catch (UnsupportedEncodingException ex) {
/* 224 */       throw new CanonicalizationException("empty", ex);
/*     */     } catch (IOException ex) {
/* 226 */       throw new CanonicalizationException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final void canonicalizeSubTree(Node currentNode, NameSpaceSymbTable ns, Node endnode, int documentLevel)
/*     */     throws CanonicalizationException, IOException
/*     */   {
/* 243 */     if (isVisibleInt(currentNode) == -1)
/* 244 */       return;
/* 245 */     Node sibling = null;
/* 246 */     Node parentNode = null;
/* 247 */     OutputStream writer = this._writer;
/* 248 */     Node excludeNode = this._excludeNode;
/* 249 */     boolean includeComments = this._includeComments;
/* 250 */     Map cache = new HashMap();
/*     */     for (;;) {
/* 252 */       switch (currentNode.getNodeType())
/*     */       {
/*     */       case 5: 
/*     */       case 10: 
/*     */       default: 
/*     */         break;
/*     */       
/*     */       case 2: 
/*     */       case 6: 
/*     */       case 12: 
/* 262 */         throw new CanonicalizationException("empty");
/*     */       
/*     */       case 9: 
/*     */       case 11: 
/* 266 */         ns.outputNodePush();
/* 267 */         sibling = currentNode.getFirstChild();
/* 268 */         break;
/*     */       
/*     */       case 8: 
/* 271 */         if (includeComments) {
/* 272 */           outputCommentToWriter((Comment)currentNode, writer, documentLevel);
/*     */         }
/*     */         
/*     */         break;
/*     */       case 7: 
/* 277 */         outputPItoWriter((ProcessingInstruction)currentNode, writer, documentLevel);
/* 278 */         break;
/*     */       
/*     */       case 3: 
/*     */       case 4: 
/* 282 */         outputTextToWriter(currentNode.getNodeValue(), writer);
/* 283 */         break;
/*     */       
/*     */       case 1: 
/* 286 */         documentLevel = 0;
/* 287 */         if (currentNode != excludeNode)
/*     */         {
/*     */ 
/* 290 */           Element currentElement = (Element)currentNode;
/*     */           
/* 292 */           ns.outputNodePush();
/* 293 */           writer.write(60);
/* 294 */           String name = currentElement.getTagName();
/* 295 */           UtfHelpper.writeByte(name, writer, cache);
/*     */           
/* 297 */           Iterator attrs = handleAttributesSubtree(currentElement, ns);
/* 298 */           if (attrs != null)
/*     */           {
/* 300 */             while (attrs.hasNext()) {
/* 301 */               Attr attr = (Attr)attrs.next();
/* 302 */               outputAttrToWriter(attr.getNodeName(), attr.getNodeValue(), writer, cache);
/*     */             }
/*     */           }
/* 305 */           writer.write(62);
/* 306 */           sibling = currentNode.getFirstChild();
/* 307 */           if (sibling == null) {
/* 308 */             writer.write(_END_TAG);
/* 309 */             UtfHelpper.writeStringToUtf8(name, writer);
/* 310 */             writer.write(62);
/*     */             
/* 312 */             ns.outputNodePop();
/* 313 */             if (parentNode != null) {
/* 314 */               sibling = currentNode.getNextSibling();
/*     */             }
/*     */           } else {
/* 317 */             parentNode = currentElement;
/*     */           }
/*     */         }
/*     */         break; }
/* 321 */       while ((sibling == null) && (parentNode != null)) {
/* 322 */         writer.write(_END_TAG);
/* 323 */         UtfHelpper.writeByte(((Element)parentNode).getTagName(), writer, cache);
/* 324 */         writer.write(62);
/*     */         
/* 326 */         ns.outputNodePop();
/* 327 */         if (parentNode == endnode)
/* 328 */           return;
/* 329 */         sibling = parentNode.getNextSibling();
/* 330 */         parentNode = parentNode.getParentNode();
/* 331 */         if (!(parentNode instanceof Element)) {
/* 332 */           documentLevel = 1;
/* 333 */           parentNode = null;
/*     */         }
/*     */       }
/* 336 */       if (sibling == null)
/* 337 */         return;
/* 338 */       currentNode = sibling;
/* 339 */       sibling = currentNode.getNextSibling();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private byte[] engineCanonicalizeXPathNodeSetInternal(Node doc)
/*     */     throws CanonicalizationException
/*     */   {
/*     */     try
/*     */     {
/* 349 */       canonicalizeXPathNodeSet(doc, doc);
/* 350 */       this._writer.close();
/* 351 */       if ((this._writer instanceof ByteArrayOutputStream)) {
/* 352 */         byte[] sol = ((ByteArrayOutputStream)this._writer).toByteArray();
/* 353 */         if (this.reset) {
/* 354 */           ((ByteArrayOutputStream)this._writer).reset();
/*     */         }
/* 356 */         return sol; }
/* 357 */       if ((this._writer instanceof UnsyncByteArrayOutputStream)) {
/* 358 */         byte[] result = ((UnsyncByteArrayOutputStream)this._writer).toByteArray();
/* 359 */         if (this.reset) {
/* 360 */           ((UnsyncByteArrayOutputStream)this._writer).reset();
/*     */         }
/* 362 */         return result;
/*     */       }
/* 364 */       return null;
/*     */     } catch (UnsupportedEncodingException ex) {
/* 366 */       throw new CanonicalizationException("empty", ex);
/*     */     } catch (IOException ex) {
/* 368 */       throw new CanonicalizationException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final void canonicalizeXPathNodeSet(Node currentNode, Node endnode)
/*     */     throws CanonicalizationException, IOException
/*     */   {
/* 383 */     if (isVisibleInt(currentNode) == -1)
/* 384 */       return;
/* 385 */     boolean currentNodeIsVisible = false;
/* 386 */     NameSpaceSymbTable ns = new NameSpaceSymbTable();
/* 387 */     if ((currentNode instanceof Element))
/* 388 */       getParentNameSpaces((Element)currentNode, ns);
/* 389 */     Node sibling = null;
/* 390 */     Node parentNode = null;
/* 391 */     OutputStream writer = this._writer;
/* 392 */     int documentLevel = -1;
/* 393 */     Map cache = new HashMap();
/*     */     for (;;) {
/* 395 */       switch (currentNode.getNodeType())
/*     */       {
/*     */       case 5: 
/*     */       case 10: 
/*     */       default: 
/*     */         break;
/*     */       
/*     */       case 2: 
/*     */       case 6: 
/*     */       case 12: 
/* 405 */         throw new CanonicalizationException("empty");
/*     */       
/*     */       case 9: 
/*     */       case 11: 
/* 409 */         ns.outputNodePush();
/*     */         
/* 411 */         sibling = currentNode.getFirstChild();
/* 412 */         break;
/*     */       
/*     */       case 8: 
/* 415 */         if ((this._includeComments) && (isVisibleDO(currentNode, ns.getLevel()) == 1)) {
/* 416 */           outputCommentToWriter((Comment)currentNode, writer, documentLevel);
/*     */         }
/*     */         
/*     */         break;
/*     */       case 7: 
/* 421 */         if (isVisible(currentNode)) {
/* 422 */           outputPItoWriter((ProcessingInstruction)currentNode, writer, documentLevel);
/*     */         }
/*     */         break;
/*     */       case 3: 
/*     */       case 4: 
/* 427 */         if (isVisible(currentNode)) {
/* 428 */           outputTextToWriter(currentNode.getNodeValue(), writer);
/* 429 */           for (Node nextSibling = currentNode.getNextSibling(); 
/*     */               
/* 431 */               (nextSibling != null) && ((nextSibling.getNodeType() == 3) || (nextSibling.getNodeType() == 4)); 
/*     */               
/*     */ 
/* 434 */               nextSibling = nextSibling.getNextSibling()) {
/* 435 */             outputTextToWriter(nextSibling.getNodeValue(), writer);
/* 436 */             currentNode = nextSibling;
/* 437 */             sibling = currentNode.getNextSibling();
/*     */           }
/*     */         }
/* 434 */         break;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       case 1: 
/* 444 */         documentLevel = 0;
/* 445 */         Element currentElement = (Element)currentNode;
/*     */         
/* 447 */         String name = null;
/* 448 */         int i = isVisibleDO(currentNode, ns.getLevel());
/* 449 */         if (i == -1) {
/* 450 */           sibling = currentNode.getNextSibling();
/*     */         }
/*     */         else {
/* 453 */           currentNodeIsVisible = i == 1;
/* 454 */           if (currentNodeIsVisible) {
/* 455 */             ns.outputNodePush();
/* 456 */             writer.write(60);
/* 457 */             name = currentElement.getTagName();
/* 458 */             UtfHelpper.writeByte(name, writer, cache);
/*     */           } else {
/* 460 */             ns.push();
/*     */           }
/*     */           
/* 463 */           Iterator attrs = handleAttributes(currentElement, ns);
/* 464 */           if (attrs != null)
/*     */           {
/* 466 */             while (attrs.hasNext()) {
/* 467 */               Attr attr = (Attr)attrs.next();
/* 468 */               outputAttrToWriter(attr.getNodeName(), attr.getNodeValue(), writer, cache);
/*     */             }
/*     */           }
/* 471 */           if (currentNodeIsVisible) {
/* 472 */             writer.write(62);
/*     */           }
/* 474 */           sibling = currentNode.getFirstChild();
/*     */           
/* 476 */           if (sibling == null) {
/* 477 */             if (currentNodeIsVisible) {
/* 478 */               writer.write(_END_TAG);
/* 479 */               UtfHelpper.writeByte(name, writer, cache);
/* 480 */               writer.write(62);
/*     */               
/* 482 */               ns.outputNodePop();
/*     */             } else {
/* 484 */               ns.pop();
/*     */             }
/* 486 */             if (parentNode != null) {
/* 487 */               sibling = currentNode.getNextSibling();
/*     */             }
/*     */           } else {
/* 490 */             parentNode = currentElement;
/*     */           }
/*     */         }
/*     */         break; }
/* 494 */       while ((sibling == null) && (parentNode != null)) {
/* 495 */         if (isVisible(parentNode)) {
/* 496 */           writer.write(_END_TAG);
/* 497 */           UtfHelpper.writeByte(((Element)parentNode).getTagName(), writer, cache);
/* 498 */           writer.write(62);
/*     */           
/* 500 */           ns.outputNodePop();
/*     */         } else {
/* 502 */           ns.pop();
/*     */         }
/* 504 */         if (parentNode == endnode)
/* 505 */           return;
/* 506 */         sibling = parentNode.getNextSibling();
/* 507 */         parentNode = parentNode.getParentNode();
/* 508 */         if (!(parentNode instanceof Element)) {
/* 509 */           parentNode = null;
/* 510 */           documentLevel = 1;
/*     */         }
/*     */       }
/* 513 */       if (sibling == null)
/* 514 */         return;
/* 515 */       currentNode = sibling;
/* 516 */       sibling = currentNode.getNextSibling();
/*     */     }
/*     */   }
/*     */   
/* 520 */   int isVisibleDO(Node currentNode, int level) { if (this.nodeFilter != null) {
/* 521 */       Iterator it = this.nodeFilter.iterator();
/* 522 */       while (it.hasNext()) {
/* 523 */         int i = ((NodeFilter)it.next()).isNodeIncludeDO(currentNode, level);
/* 524 */         if (i != 1)
/* 525 */           return i;
/*     */       }
/*     */     }
/* 528 */     if ((this._xpathNodeSet != null) && (!this._xpathNodeSet.contains(currentNode)))
/* 529 */       return 0;
/* 530 */     return 1;
/*     */   }
/*     */   
/* 533 */   int isVisibleInt(Node currentNode) { if (this.nodeFilter != null) {
/* 534 */       Iterator it = this.nodeFilter.iterator();
/* 535 */       while (it.hasNext()) {
/* 536 */         int i = ((NodeFilter)it.next()).isNodeInclude(currentNode);
/* 537 */         if (i != 1)
/* 538 */           return i;
/*     */       }
/*     */     }
/* 541 */     if ((this._xpathNodeSet != null) && (!this._xpathNodeSet.contains(currentNode)))
/* 542 */       return 0;
/* 543 */     return 1;
/*     */   }
/*     */   
/*     */   boolean isVisible(Node currentNode) {
/* 547 */     if (this.nodeFilter != null) {
/* 548 */       Iterator it = this.nodeFilter.iterator();
/* 549 */       while (it.hasNext()) {
/* 550 */         if (((NodeFilter)it.next()).isNodeInclude(currentNode) != 1)
/* 551 */           return false;
/*     */       }
/*     */     }
/* 554 */     if ((this._xpathNodeSet != null) && (!this._xpathNodeSet.contains(currentNode)))
/* 555 */       return false;
/* 556 */     return true;
/*     */   }
/*     */   
/*     */   void handleParent(Element e, NameSpaceSymbTable ns) {
/* 560 */     if (!e.hasAttributes()) {
/* 561 */       return;
/*     */     }
/* 563 */     NamedNodeMap attrs = e.getAttributes();
/* 564 */     int attrsLength = attrs.getLength();
/* 565 */     for (int i = 0; i < attrsLength; i++) {
/* 566 */       Attr N = (Attr)attrs.item(i);
/* 567 */       if ("http://www.w3.org/2000/xmlns/" == N.getNamespaceURI())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 572 */         String NName = N.getLocalName();
/* 573 */         String NValue = N.getNodeValue();
/* 574 */         if ((!"xml".equals(NName)) || (!"http://www.w3.org/XML/1998/namespace".equals(NValue)))
/*     */         {
/*     */ 
/*     */ 
/* 578 */           ns.addMapping(NName, NValue, N);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   final void getParentNameSpaces(Element el, NameSpaceSymbTable ns)
/*     */   {
/* 588 */     List parents = new ArrayList(10);
/* 589 */     Node n1 = el.getParentNode();
/* 590 */     if (!(n1 instanceof Element)) {
/* 591 */       return;
/*     */     }
/*     */     
/* 594 */     Element parent = (Element)n1;
/* 595 */     while (parent != null) {
/* 596 */       parents.add(parent);
/* 597 */       Node n = parent.getParentNode();
/* 598 */       if (!(n instanceof Element)) {
/*     */         break;
/*     */       }
/* 601 */       parent = (Element)n;
/*     */     }
/*     */     
/* 604 */     ListIterator it = parents.listIterator(parents.size());
/* 605 */     while (it.hasPrevious()) {
/* 606 */       Element ele = (Element)it.previous();
/* 607 */       handleParent(ele, ns);
/*     */     }
/*     */     Attr nsprefix;
/* 610 */     if (((nsprefix = ns.getMappingWithoutRendered("xmlns")) != null) && ("".equals(nsprefix.getValue())))
/*     */     {
/* 612 */       ns.addMappingAndRender("xmlns", "", nullNode);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final void outputAttrToWriter(String name, String value, OutputStream writer, Map cache)
/*     */     throws IOException
/*     */   {
/* 660 */     writer.write(32);
/* 661 */     UtfHelpper.writeByte(name, writer, cache);
/* 662 */     writer.write(equalsStr);
/*     */     
/* 664 */     int length = value.length();
/* 665 */     int i = 0;
/* 666 */     while (i < length) {
/* 667 */       char c = value.charAt(i++);
/*     */       byte[] toWrite;
/* 669 */       switch (c)
/*     */       {
/*     */       case '&': 
/* 672 */         toWrite = _AMP_;
/* 673 */         break;
/*     */       
/*     */       case '<': 
/* 676 */         toWrite = _LT_;
/* 677 */         break;
/*     */       
/*     */       case '"': 
/* 680 */         toWrite = _QUOT_;
/* 681 */         break;
/*     */       
/*     */       case '\t': 
/* 684 */         toWrite = __X9_;
/* 685 */         break;
/*     */       
/*     */       case '\n': 
/* 688 */         toWrite = __XA_;
/* 689 */         break;
/*     */       
/*     */       case '\r': 
/* 692 */         toWrite = __XD_;
/* 693 */         break;
/*     */       
/*     */       default: 
/* 696 */         if (c < '') {
/* 697 */           writer.write(c); continue;
/*     */         }
/* 699 */         UtfHelpper.writeCharToUtf8(c, writer);
/*     */         
/* 701 */         break;
/*     */       }
/* 703 */       writer.write(toWrite);
/*     */     }
/*     */     
/* 706 */     writer.write(34);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final void outputPItoWriter(ProcessingInstruction currentPI, OutputStream writer, int position)
/*     */     throws IOException
/*     */   {
/* 718 */     if (position == 1) {
/* 719 */       writer.write(10);
/*     */     }
/* 721 */     writer.write(_BEGIN_PI);
/*     */     
/* 723 */     String target = currentPI.getTarget();
/* 724 */     int length = target.length();
/*     */     
/* 726 */     for (int i = 0; i < length; i++) {
/* 727 */       char c = target.charAt(i);
/* 728 */       if (c == '\r') {
/* 729 */         writer.write(__XD_);
/*     */       }
/* 731 */       else if (c < '') {
/* 732 */         writer.write(c);
/*     */       } else {
/* 734 */         UtfHelpper.writeCharToUtf8(c, writer);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 739 */     String data = currentPI.getData();
/*     */     
/* 741 */     length = data.length();
/*     */     
/* 743 */     if (length > 0) {
/* 744 */       writer.write(32);
/*     */       
/* 746 */       for (int i = 0; i < length; i++) {
/* 747 */         char c = data.charAt(i);
/* 748 */         if (c == '\r') {
/* 749 */           writer.write(__XD_);
/*     */         } else {
/* 751 */           UtfHelpper.writeCharToUtf8(c, writer);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 756 */     writer.write(_END_PI);
/* 757 */     if (position == -1) {
/* 758 */       writer.write(10);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final void outputCommentToWriter(Comment currentComment, OutputStream writer, int position)
/*     */     throws IOException
/*     */   {
/* 770 */     if (position == 1) {
/* 771 */       writer.write(10);
/*     */     }
/* 773 */     writer.write(_BEGIN_COMM);
/*     */     
/* 775 */     String data = currentComment.getData();
/* 776 */     int length = data.length();
/*     */     
/* 778 */     for (int i = 0; i < length; i++) {
/* 779 */       char c = data.charAt(i);
/* 780 */       if (c == '\r') {
/* 781 */         writer.write(__XD_);
/*     */       }
/* 783 */       else if (c < '') {
/* 784 */         writer.write(c);
/*     */       } else {
/* 786 */         UtfHelpper.writeCharToUtf8(c, writer);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 791 */     writer.write(_END_COMM);
/* 792 */     if (position == -1) {
/* 793 */       writer.write(10);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final void outputTextToWriter(String text, OutputStream writer)
/*     */     throws IOException
/*     */   {
/* 805 */     int length = text.length();
/*     */     
/* 807 */     for (int i = 0; i < length; i++) {
/* 808 */       char c = text.charAt(i);
/*     */       byte[] toWrite;
/* 810 */       switch (c)
/*     */       {
/*     */       case '&': 
/* 813 */         toWrite = _AMP_;
/* 814 */         break;
/*     */       
/*     */       case '<': 
/* 817 */         toWrite = _LT_;
/* 818 */         break;
/*     */       
/*     */       case '>': 
/* 821 */         toWrite = _GT_;
/* 822 */         break;
/*     */       
/*     */       case '\r': 
/* 825 */         toWrite = __XD_;
/* 826 */         break;
/*     */       
/*     */       default: 
/* 829 */         if (c < '') {
/* 830 */           writer.write(c);
/*     */         } else {
/* 832 */           UtfHelpper.writeCharToUtf8(c, writer);
/*     */         }
/* 834 */         break;
/*     */       }
/* 836 */       writer.write(toWrite);
/*     */     }
/*     */   }
/*     */   
/*     */   abstract Iterator handleAttributes(Element paramElement, NameSpaceSymbTable paramNameSpaceSymbTable)
/*     */     throws CanonicalizationException;
/*     */   
/*     */   abstract Iterator handleAttributesSubtree(Element paramElement, NameSpaceSymbTable paramNameSpaceSymbTable)
/*     */     throws CanonicalizationException;
/*     */   
/*     */   abstract void circumventBugIfNeeded(XMLSignatureInput paramXMLSignatureInput)
/*     */     throws CanonicalizationException, ParserConfigurationException, IOException, SAXException;
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\c14n\implementations\CanonicalizerBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */