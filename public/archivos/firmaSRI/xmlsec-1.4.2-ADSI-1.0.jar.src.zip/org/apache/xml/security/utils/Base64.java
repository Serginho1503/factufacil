/*     */ package org.apache.xml.security.utils;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.math.BigInteger;
/*     */ import org.apache.xml.security.exceptions.Base64DecodingException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Base64
/*     */ {
/*     */   public static final int BASE64DEFAULTLENGTH = 76;
/*     */   private static final int BASELENGTH = 255;
/*     */   private static final int LOOKUPLENGTH = 64;
/*     */   private static final int TWENTYFOURBITGROUP = 24;
/*     */   private static final int EIGHTBIT = 8;
/*     */   private static final int SIXTEENBIT = 16;
/*     */   private static final int FOURBYTE = 4;
/*     */   private static final int SIGN = -128;
/*     */   private static final char PAD = '=';
/*     */   
/*     */   static final byte[] getBytes(BigInteger big, int bitlen)
/*     */   {
/*  67 */     bitlen = bitlen + 7 >> 3 << 3;
/*     */     
/*  69 */     if (bitlen < big.bitLength()) {
/*  70 */       throw new IllegalArgumentException(I18n.translate("utils.Base64.IllegalBitlength"));
/*     */     }
/*     */     
/*     */ 
/*  74 */     byte[] bigBytes = big.toByteArray();
/*     */     
/*  76 */     if ((big.bitLength() % 8 != 0) && (big.bitLength() / 8 + 1 == bitlen / 8))
/*     */     {
/*  78 */       return bigBytes;
/*     */     }
/*     */     
/*     */ 
/*  82 */     int startSrc = 0;
/*  83 */     int bigLen = bigBytes.length;
/*     */     
/*  85 */     if (big.bitLength() % 8 == 0) {
/*  86 */       startSrc = 1;
/*     */       
/*  88 */       bigLen--;
/*     */     }
/*     */     
/*  91 */     int startDst = bitlen / 8 - bigLen;
/*  92 */     byte[] resizedBytes = new byte[bitlen / 8];
/*     */     
/*  94 */     System.arraycopy(bigBytes, startSrc, resizedBytes, startDst, bigLen);
/*     */     
/*  96 */     return resizedBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String encode(BigInteger big)
/*     */   {
/* 107 */     return encode(getBytes(big, big.bitLength()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final byte[] encode(BigInteger big, int bitlen)
/*     */   {
/* 124 */     bitlen = bitlen + 7 >> 3 << 3;
/*     */     
/* 126 */     if (bitlen < big.bitLength()) {
/* 127 */       throw new IllegalArgumentException(I18n.translate("utils.Base64.IllegalBitlength"));
/*     */     }
/*     */     
/*     */ 
/* 131 */     byte[] bigBytes = big.toByteArray();
/*     */     
/* 133 */     if ((big.bitLength() % 8 != 0) && (big.bitLength() / 8 + 1 == bitlen / 8))
/*     */     {
/* 135 */       return bigBytes;
/*     */     }
/*     */     
/*     */ 
/* 139 */     int startSrc = 0;
/* 140 */     int bigLen = bigBytes.length;
/*     */     
/* 142 */     if (big.bitLength() % 8 == 0) {
/* 143 */       startSrc = 1;
/*     */       
/* 145 */       bigLen--;
/*     */     }
/*     */     
/* 148 */     int startDst = bitlen / 8 - bigLen;
/* 149 */     byte[] resizedBytes = new byte[bitlen / 8];
/*     */     
/* 151 */     System.arraycopy(bigBytes, startSrc, resizedBytes, startDst, bigLen);
/*     */     
/* 153 */     return resizedBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final BigInteger decodeBigIntegerFromElement(Element element)
/*     */     throws Base64DecodingException
/*     */   {
/* 166 */     return new BigInteger(1, decode(element));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final BigInteger decodeBigIntegerFromText(Text text)
/*     */     throws Base64DecodingException
/*     */   {
/* 178 */     return new BigInteger(1, decode(text.getData()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void fillElementWithBigInteger(Element element, BigInteger biginteger)
/*     */   {
/* 191 */     String encodedInt = encode(biginteger);
/*     */     
/* 193 */     if (encodedInt.length() > 76) {
/* 194 */       encodedInt = "\n" + encodedInt + "\n";
/*     */     }
/*     */     
/* 197 */     Document doc = element.getOwnerDocument();
/* 198 */     Text text = doc.createTextNode(encodedInt);
/*     */     
/* 200 */     element.appendChild(text);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final byte[] decode(Element element)
/*     */     throws Base64DecodingException
/*     */   {
/* 216 */     Node sibling = element.getFirstChild();
/* 217 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 219 */     while (sibling != null) {
/* 220 */       if (sibling.getNodeType() == 3) {
/* 221 */         Text t = (Text)sibling;
/*     */         
/* 223 */         sb.append(t.getData());
/*     */       }
/* 225 */       sibling = sibling.getNextSibling();
/*     */     }
/*     */     
/* 228 */     return decode(sb.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final Element encodeToElement(Document doc, String localName, byte[] bytes)
/*     */   {
/* 243 */     Element el = XMLUtils.createElementInSignatureSpace(doc, localName);
/* 244 */     Text text = doc.createTextNode(encode(bytes));
/*     */     
/* 246 */     el.appendChild(text);
/*     */     
/* 248 */     return el;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final byte[] decode(byte[] base64)
/*     */     throws Base64DecodingException
/*     */   {
/* 261 */     return decodeInternal(base64, -1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String encode(byte[] binaryData)
/*     */   {
/* 274 */     return XMLUtils.ignoreLineBreaks() ? encode(binaryData, Integer.MAX_VALUE) : encode(binaryData, 76);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final byte[] decode(BufferedReader reader)
/*     */     throws IOException, Base64DecodingException
/*     */   {
/* 293 */     UnsyncByteArrayOutputStream baos = new UnsyncByteArrayOutputStream();
/*     */     
/*     */     String line;
/* 296 */     while (null != (line = reader.readLine())) {
/* 297 */       byte[] bytes = decode(line);
/*     */       
/* 299 */       baos.write(bytes);
/*     */     }
/*     */     
/* 302 */     return baos.toByteArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 313 */   private static final byte[] base64Alphabet = new byte['ÿ'];
/* 314 */   private static final char[] lookUpBase64Alphabet = new char[64];
/*     */   
/*     */   static
/*     */   {
/* 318 */     for (int i = 0; i < 255; i++) {
/* 319 */       base64Alphabet[i] = -1;
/*     */     }
/* 321 */     for (int i = 90; i >= 65; i--) {
/* 322 */       base64Alphabet[i] = ((byte)(i - 65));
/*     */     }
/* 324 */     for (int i = 122; i >= 97; i--) {
/* 325 */       base64Alphabet[i] = ((byte)(i - 97 + 26));
/*     */     }
/*     */     
/* 328 */     for (int i = 57; i >= 48; i--) {
/* 329 */       base64Alphabet[i] = ((byte)(i - 48 + 52));
/*     */     }
/*     */     
/* 332 */     base64Alphabet[43] = 62;
/* 333 */     base64Alphabet[47] = 63;
/*     */     
/* 335 */     for (int i = 0; i <= 25; i++) {
/* 336 */       lookUpBase64Alphabet[i] = ((char)(65 + i));
/*     */     }
/* 338 */     int i = 26; for (int j = 0; i <= 51; j++) {
/* 339 */       lookUpBase64Alphabet[i] = ((char)(97 + j));i++;
/*     */     }
/* 341 */     int i = 52; for (int j = 0; i <= 61; j++) {
/* 342 */       lookUpBase64Alphabet[i] = ((char)(48 + j));i++; }
/* 343 */     lookUpBase64Alphabet[62] = '+';
/* 344 */     lookUpBase64Alphabet[63] = '/';
/*     */   }
/*     */   
/*     */   protected static final boolean isWhiteSpace(byte octect)
/*     */   {
/* 349 */     return (octect == 32) || (octect == 13) || (octect == 10) || (octect == 9);
/*     */   }
/*     */   
/*     */   protected static final boolean isPad(byte octect) {
/* 353 */     return octect == 61;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String encode(byte[] binaryData, int length)
/*     */   {
/* 373 */     if (length < 4) {
/* 374 */       length = Integer.MAX_VALUE;
/*     */     }
/*     */     
/* 377 */     if (binaryData == null) {
/* 378 */       return null;
/*     */     }
/* 380 */     int lengthDataBits = binaryData.length * 8;
/* 381 */     if (lengthDataBits == 0) {
/* 382 */       return "";
/*     */     }
/*     */     
/* 385 */     int fewerThan24bits = lengthDataBits % 24;
/* 386 */     int numberTriplets = lengthDataBits / 24;
/* 387 */     int numberQuartet = fewerThan24bits != 0 ? numberTriplets + 1 : numberTriplets;
/* 388 */     int quartesPerLine = length / 4;
/* 389 */     int numberLines = (numberQuartet - 1) / quartesPerLine;
/* 390 */     char[] encodedData = null;
/*     */     
/* 392 */     encodedData = new char[numberQuartet * 4 + numberLines];
/*     */     
/* 394 */     byte k = 0;byte l = 0;byte b1 = 0;byte b2 = 0;byte b3 = 0;
/*     */     
/* 396 */     int encodedIndex = 0;
/* 397 */     int dataIndex = 0;
/* 398 */     int i = 0;
/*     */     
/*     */ 
/* 401 */     for (int line = 0; line < numberLines; line++) {
/* 402 */       for (int quartet = 0; quartet < 19; quartet++) {
/* 403 */         b1 = binaryData[(dataIndex++)];
/* 404 */         b2 = binaryData[(dataIndex++)];
/* 405 */         b3 = binaryData[(dataIndex++)];
/*     */         
/*     */ 
/* 408 */         l = (byte)(b2 & 0xF);
/* 409 */         k = (byte)(b1 & 0x3);
/*     */         
/* 411 */         byte val1 = (b1 & 0xFFFFFF80) == 0 ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/*     */         
/* 413 */         byte val2 = (b2 & 0xFFFFFF80) == 0 ? (byte)(b2 >> 4) : (byte)(b2 >> 4 ^ 0xF0);
/* 414 */         byte val3 = (b3 & 0xFFFFFF80) == 0 ? (byte)(b3 >> 6) : (byte)(b3 >> 6 ^ 0xFC);
/*     */         
/*     */ 
/* 417 */         encodedData[(encodedIndex++)] = lookUpBase64Alphabet[val1];
/* 418 */         encodedData[(encodedIndex++)] = lookUpBase64Alphabet[(val2 | k << 4)];
/* 419 */         encodedData[(encodedIndex++)] = lookUpBase64Alphabet[(l << 2 | val3)];
/* 420 */         encodedData[(encodedIndex++)] = lookUpBase64Alphabet[(b3 & 0x3F)];
/*     */         
/* 422 */         i++;
/*     */       }
/* 424 */       encodedData[(encodedIndex++)] = '\n';
/*     */     }
/* 427 */     for (; 
/* 427 */         i < numberTriplets; i++) {
/* 428 */       b1 = binaryData[(dataIndex++)];
/* 429 */       b2 = binaryData[(dataIndex++)];
/* 430 */       b3 = binaryData[(dataIndex++)];
/*     */       
/*     */ 
/* 433 */       l = (byte)(b2 & 0xF);
/* 434 */       k = (byte)(b1 & 0x3);
/*     */       
/* 436 */       byte val1 = (b1 & 0xFFFFFF80) == 0 ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/*     */       
/* 438 */       byte val2 = (b2 & 0xFFFFFF80) == 0 ? (byte)(b2 >> 4) : (byte)(b2 >> 4 ^ 0xF0);
/* 439 */       byte val3 = (b3 & 0xFFFFFF80) == 0 ? (byte)(b3 >> 6) : (byte)(b3 >> 6 ^ 0xFC);
/*     */       
/*     */ 
/* 442 */       encodedData[(encodedIndex++)] = lookUpBase64Alphabet[val1];
/* 443 */       encodedData[(encodedIndex++)] = lookUpBase64Alphabet[(val2 | k << 4)];
/* 444 */       encodedData[(encodedIndex++)] = lookUpBase64Alphabet[(l << 2 | val3)];
/* 445 */       encodedData[(encodedIndex++)] = lookUpBase64Alphabet[(b3 & 0x3F)];
/*     */     }
/*     */     
/*     */ 
/* 449 */     if (fewerThan24bits == 8) {
/* 450 */       b1 = binaryData[dataIndex];
/* 451 */       k = (byte)(b1 & 0x3);
/* 452 */       byte val1 = (b1 & 0xFFFFFF80) == 0 ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/* 453 */       encodedData[(encodedIndex++)] = lookUpBase64Alphabet[val1];
/* 454 */       encodedData[(encodedIndex++)] = lookUpBase64Alphabet[(k << 4)];
/* 455 */       encodedData[(encodedIndex++)] = '=';
/* 456 */       encodedData[(encodedIndex++)] = '=';
/* 457 */     } else if (fewerThan24bits == 16) {
/* 458 */       b1 = binaryData[dataIndex];
/* 459 */       b2 = binaryData[(dataIndex + 1)];
/* 460 */       l = (byte)(b2 & 0xF);
/* 461 */       k = (byte)(b1 & 0x3);
/*     */       
/* 463 */       byte val1 = (b1 & 0xFFFFFF80) == 0 ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/* 464 */       byte val2 = (b2 & 0xFFFFFF80) == 0 ? (byte)(b2 >> 4) : (byte)(b2 >> 4 ^ 0xF0);
/*     */       
/* 466 */       encodedData[(encodedIndex++)] = lookUpBase64Alphabet[val1];
/* 467 */       encodedData[(encodedIndex++)] = lookUpBase64Alphabet[(val2 | k << 4)];
/* 468 */       encodedData[(encodedIndex++)] = lookUpBase64Alphabet[(l << 2)];
/* 469 */       encodedData[(encodedIndex++)] = '=';
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 474 */     return new String(encodedData);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final byte[] decode(String encoded)
/*     */     throws Base64DecodingException
/*     */   {
/* 486 */     if (encoded == null)
/* 487 */       return null;
/* 488 */     byte[] bytes = new byte[encoded.length()];
/* 489 */     int len = getBytesInternal(encoded, bytes);
/* 490 */     return decodeInternal(bytes, len);
/*     */   }
/*     */   
/*     */   protected static final int getBytesInternal(String s, byte[] result) {
/* 494 */     int length = s.length();
/*     */     
/* 496 */     int newSize = 0;
/* 497 */     for (int i = 0; i < length; i++) {
/* 498 */       byte dataS = (byte)s.charAt(i);
/* 499 */       if (!isWhiteSpace(dataS))
/* 500 */         result[(newSize++)] = dataS;
/*     */     }
/* 502 */     return newSize;
/*     */   }
/*     */   
/*     */   protected static final byte[] decodeInternal(byte[] base64Data, int len) throws Base64DecodingException
/*     */   {
/* 507 */     if (len == -1) {
/* 508 */       len = removeWhiteSpace(base64Data);
/*     */     }
/* 510 */     if (len % 4 != 0) {
/* 511 */       throw new Base64DecodingException("decoding.divisible.four");
/*     */     }
/*     */     
/*     */ 
/* 515 */     int numberQuadruple = len / 4;
/*     */     
/* 517 */     if (numberQuadruple == 0) {
/* 518 */       return new byte[0];
/*     */     }
/* 520 */     byte[] decodedData = null;
/* 521 */     byte b1 = 0;byte b2 = 0;byte b3 = 0;byte b4 = 0;
/*     */     
/*     */ 
/* 524 */     int i = 0;
/* 525 */     int encodedIndex = 0;
/* 526 */     int dataIndex = 0;
/*     */     
/*     */ 
/* 529 */     dataIndex = (numberQuadruple - 1) * 4;
/* 530 */     encodedIndex = (numberQuadruple - 1) * 3;
/*     */     
/* 532 */     b1 = base64Alphabet[base64Data[(dataIndex++)]];
/* 533 */     b2 = base64Alphabet[base64Data[(dataIndex++)]];
/* 534 */     if ((b1 == -1) || (b2 == -1)) {
/* 535 */       throw new Base64DecodingException("decoding.general");
/*     */     }
/*     */     
/*     */     byte d3;
/*     */     
/* 540 */     b3 = base64Alphabet[(d3 = base64Data[(dataIndex++)])];
/* 541 */     byte d4; b4 = base64Alphabet[(d4 = base64Data[(dataIndex++)])];
/* 542 */     if ((b3 == -1) || (b4 == -1))
/*     */     {
/* 544 */       if ((isPad(d3)) && (isPad(d4))) {
/* 545 */         if ((b2 & 0xF) != 0)
/* 546 */           throw new Base64DecodingException("decoding.general");
/* 547 */         decodedData = new byte[encodedIndex + 1];
/* 548 */         decodedData[encodedIndex] = ((byte)(b1 << 2 | b2 >> 4));
/* 549 */       } else if ((!isPad(d3)) && (isPad(d4))) {
/* 550 */         if ((b3 & 0x3) != 0)
/* 551 */           throw new Base64DecodingException("decoding.general");
/* 552 */         decodedData = new byte[encodedIndex + 2];
/* 553 */         decodedData[(encodedIndex++)] = ((byte)(b1 << 2 | b2 >> 4));
/* 554 */         decodedData[encodedIndex] = ((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/*     */       } else {
/* 556 */         throw new Base64DecodingException("decoding.general");
/*     */       }
/*     */     }
/*     */     else {
/* 560 */       decodedData = new byte[encodedIndex + 3];
/* 561 */       decodedData[(encodedIndex++)] = ((byte)(b1 << 2 | b2 >> 4));
/* 562 */       decodedData[(encodedIndex++)] = ((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/* 563 */       decodedData[(encodedIndex++)] = ((byte)(b3 << 6 | b4));
/*     */     }
/* 565 */     encodedIndex = 0;
/* 566 */     dataIndex = 0;
/*     */     
/* 568 */     for (i = numberQuadruple - 1; i > 0; i--) {
/* 569 */       b1 = base64Alphabet[base64Data[(dataIndex++)]];
/* 570 */       b2 = base64Alphabet[base64Data[(dataIndex++)]];
/* 571 */       b3 = base64Alphabet[base64Data[(dataIndex++)]];
/* 572 */       b4 = base64Alphabet[base64Data[(dataIndex++)]];
/*     */       
/* 574 */       if ((b1 == -1) || (b2 == -1) || (b3 == -1) || (b4 == -1))
/*     */       {
/*     */ 
/*     */ 
/* 578 */         throw new Base64DecodingException("decoding.general");
/*     */       }
/*     */       
/* 581 */       decodedData[(encodedIndex++)] = ((byte)(b1 << 2 | b2 >> 4));
/* 582 */       decodedData[(encodedIndex++)] = ((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/* 583 */       decodedData[(encodedIndex++)] = ((byte)(b3 << 6 | b4));
/*     */     }
/* 585 */     return decodedData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void decode(String base64Data, OutputStream os)
/*     */     throws Base64DecodingException, IOException
/*     */   {
/* 597 */     byte[] bytes = new byte[base64Data.length()];
/* 598 */     int len = getBytesInternal(base64Data, bytes);
/* 599 */     decode(bytes, os, len);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void decode(byte[] base64Data, OutputStream os)
/*     */     throws Base64DecodingException, IOException
/*     */   {
/* 611 */     decode(base64Data, os, -1);
/*     */   }
/*     */   
/*     */   protected static final void decode(byte[] base64Data, OutputStream os, int len)
/*     */     throws Base64DecodingException, IOException
/*     */   {
/* 617 */     if (len == -1) {
/* 618 */       len = removeWhiteSpace(base64Data);
/*     */     }
/* 620 */     if (len % 4 != 0) {
/* 621 */       throw new Base64DecodingException("decoding.divisible.four");
/*     */     }
/*     */     
/*     */ 
/* 625 */     int numberQuadruple = len / 4;
/*     */     
/* 627 */     if (numberQuadruple == 0) {
/* 628 */       return;
/*     */     }
/*     */     
/* 631 */     byte b1 = 0;byte b2 = 0;byte b3 = 0;byte b4 = 0;
/*     */     
/* 633 */     int i = 0;
/*     */     
/* 635 */     int dataIndex = 0;
/*     */     
/*     */ 
/* 638 */     for (i = numberQuadruple - 1; i > 0; i--) {
/* 639 */       b1 = base64Alphabet[base64Data[(dataIndex++)]];
/* 640 */       b2 = base64Alphabet[base64Data[(dataIndex++)]];
/* 641 */       b3 = base64Alphabet[base64Data[(dataIndex++)]];
/* 642 */       b4 = base64Alphabet[base64Data[(dataIndex++)]];
/* 643 */       if ((b1 == -1) || (b2 == -1) || (b3 == -1) || (b4 == -1))
/*     */       {
/*     */ 
/*     */ 
/* 647 */         throw new Base64DecodingException("decoding.general");
/*     */       }
/*     */       
/*     */ 
/* 651 */       os.write((byte)(b1 << 2 | b2 >> 4));
/* 652 */       os.write((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/* 653 */       os.write((byte)(b3 << 6 | b4));
/*     */     }
/* 655 */     b1 = base64Alphabet[base64Data[(dataIndex++)]];
/* 656 */     b2 = base64Alphabet[base64Data[(dataIndex++)]];
/*     */     
/*     */ 
/* 659 */     if ((b1 == -1) || (b2 == -1))
/*     */     {
/* 661 */       throw new Base64DecodingException("decoding.general");
/*     */     }
/*     */     
/*     */     byte d3;
/* 665 */     b3 = base64Alphabet[(d3 = base64Data[(dataIndex++)])];
/* 666 */     byte d4; b4 = base64Alphabet[(d4 = base64Data[(dataIndex++)])];
/* 667 */     if ((b3 == -1) || (b4 == -1))
/*     */     {
/* 669 */       if ((isPad(d3)) && (isPad(d4))) {
/* 670 */         if ((b2 & 0xF) != 0)
/* 671 */           throw new Base64DecodingException("decoding.general");
/* 672 */         os.write((byte)(b1 << 2 | b2 >> 4));
/* 673 */       } else if ((!isPad(d3)) && (isPad(d4))) {
/* 674 */         if ((b3 & 0x3) != 0)
/* 675 */           throw new Base64DecodingException("decoding.general");
/* 676 */         os.write((byte)(b1 << 2 | b2 >> 4));
/* 677 */         os.write((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/*     */       } else {
/* 679 */         throw new Base64DecodingException("decoding.general");
/*     */       }
/*     */     }
/*     */     else {
/* 683 */       os.write((byte)(b1 << 2 | b2 >> 4));
/* 684 */       os.write((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/* 685 */       os.write((byte)(b3 << 6 | b4));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void decode(InputStream is, OutputStream os)
/*     */     throws Base64DecodingException, IOException
/*     */   {
/* 701 */     byte b1 = 0;byte b2 = 0;byte b3 = 0;byte b4 = 0;
/*     */     
/* 703 */     int index = 0;
/* 704 */     byte[] data = new byte[4];
/*     */     
/*     */     int read;
/* 707 */     while ((read = is.read()) > 0) {
/* 708 */       byte readed = (byte)read;
/* 709 */       if (!isWhiteSpace(readed))
/*     */       {
/*     */ 
/* 712 */         if (isPad(readed)) {
/* 713 */           data[(index++)] = readed;
/* 714 */           if (index != 3) break;
/* 715 */           data[(index++)] = ((byte)is.read()); break;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 720 */         if ((data[(index++)] = readed) == -1) {
/* 721 */           throw new Base64DecodingException("decoding.general");
/*     */         }
/*     */         
/* 724 */         if (index == 4)
/*     */         {
/*     */ 
/* 727 */           index = 0;
/* 728 */           b1 = base64Alphabet[data[0]];
/* 729 */           b2 = base64Alphabet[data[1]];
/* 730 */           b3 = base64Alphabet[data[2]];
/* 731 */           b4 = base64Alphabet[data[3]];
/*     */           
/* 733 */           os.write((byte)(b1 << 2 | b2 >> 4));
/* 734 */           os.write((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/* 735 */           os.write((byte)(b3 << 6 | b4));
/*     */         }
/*     */       }
/*     */     }
/* 739 */     byte d1 = data[0];byte d2 = data[1];byte d3 = data[2];byte d4 = data[3];
/* 740 */     b1 = base64Alphabet[d1];
/* 741 */     b2 = base64Alphabet[d2];
/* 742 */     b3 = base64Alphabet[d3];
/* 743 */     b4 = base64Alphabet[d4];
/* 744 */     if ((b3 == -1) || (b4 == -1))
/*     */     {
/* 746 */       if ((isPad(d3)) && (isPad(d4))) {
/* 747 */         if ((b2 & 0xF) != 0)
/* 748 */           throw new Base64DecodingException("decoding.general");
/* 749 */         os.write((byte)(b1 << 2 | b2 >> 4));
/* 750 */       } else if ((!isPad(d3)) && (isPad(d4))) {
/* 751 */         b3 = base64Alphabet[d3];
/* 752 */         if ((b3 & 0x3) != 0)
/* 753 */           throw new Base64DecodingException("decoding.general");
/* 754 */         os.write((byte)(b1 << 2 | b2 >> 4));
/* 755 */         os.write((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/*     */       } else {
/* 757 */         throw new Base64DecodingException("decoding.general");
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 762 */       os.write((byte)(b1 << 2 | b2 >> 4));
/* 763 */       os.write((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/* 764 */       os.write((byte)(b3 << 6 | b4));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static final int removeWhiteSpace(byte[] data)
/*     */   {
/* 776 */     if (data == null) {
/* 777 */       return 0;
/*     */     }
/*     */     
/* 780 */     int newSize = 0;
/* 781 */     int len = data.length;
/* 782 */     for (int i = 0; i < len; i++) {
/* 783 */       byte dataS = data[i];
/* 784 */       if (!isWhiteSpace(dataS))
/* 785 */         data[(newSize++)] = dataS;
/*     */     }
/* 787 */     return newSize;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\utils\Base64.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */