/*     */ package org.apache.xml.security.c14n.implementations;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import org.apache.xml.security.c14n.helper.C14nHelper;
/*     */ import org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Canonicalizer11
/*     */   extends CanonicalizerBase
/*     */ {
/*  57 */   boolean firstCall = true;
/*  58 */   final SortedSet result = new TreeSet(COMPARE);
/*     */   
/*     */   static final String XMLNS_URI = "http://www.w3.org/2000/xmlns/";
/*     */   static final String XML_LANG_URI = "http://www.w3.org/XML/1998/namespace";
/*  62 */   static Log log = LogFactory.getLog(Canonicalizer11.class.getName());
/*     */   
/*     */   static class XmlAttrStack {
/*  65 */     int currentLevel = 0;
/*  66 */     int lastlevel = 0;
/*     */     XmlsStackElement cur;
/*     */     
/*     */     static class XmlsStackElement { int level;
/*  70 */       boolean rendered = false;
/*  71 */       List nodes = new ArrayList(); }
/*     */     
/*  73 */     List levels = new ArrayList();
/*     */     
/*  75 */     void push(int level) { this.currentLevel = level;
/*  76 */       if (this.currentLevel == -1)
/*  77 */         return;
/*  78 */       this.cur = null;
/*  79 */       while (this.lastlevel >= this.currentLevel) {
/*  80 */         this.levels.remove(this.levels.size() - 1);
/*  81 */         if (this.levels.size() == 0) {
/*  82 */           this.lastlevel = 0;
/*  83 */           return;
/*     */         }
/*  85 */         this.lastlevel = ((XmlsStackElement)this.levels.get(this.levels.size() - 1)).level;
/*     */       }
/*     */     }
/*     */     
/*  89 */     void addXmlnsAttr(Attr n) { if (this.cur == null) {
/*  90 */         this.cur = new XmlsStackElement();
/*  91 */         this.cur.level = this.currentLevel;
/*  92 */         this.levels.add(this.cur);
/*  93 */         this.lastlevel = this.currentLevel;
/*     */       }
/*  95 */       this.cur.nodes.add(n);
/*     */     }
/*     */     
/*  98 */     void getXmlnsAttr(Collection col) { if (this.cur == null) {
/*  99 */         this.cur = new XmlsStackElement();
/* 100 */         this.cur.level = this.currentLevel;
/* 101 */         this.lastlevel = this.currentLevel;
/* 102 */         this.levels.add(this.cur);
/*     */       }
/* 104 */       int size = this.levels.size() - 2;
/* 105 */       boolean parentRendered = false;
/* 106 */       XmlsStackElement e = null;
/* 107 */       if (size == -1) {
/* 108 */         parentRendered = true;
/*     */       } else {
/* 110 */         e = (XmlsStackElement)this.levels.get(size);
/* 111 */         if ((e.rendered) && (e.level + 1 == this.currentLevel))
/* 112 */           parentRendered = true;
/*     */       }
/* 114 */       if (parentRendered) {
/* 115 */         col.addAll(this.cur.nodes);
/* 116 */         this.cur.rendered = true;
/* 117 */         return;
/*     */       }
/*     */       
/* 120 */       Map loa = new HashMap();
/* 121 */       List baseAttrs = new ArrayList();
/* 122 */       boolean successiveOmitted = true;
/* 123 */       for (; size >= 0; size--) {
/* 124 */         e = (XmlsStackElement)this.levels.get(size);
/* 125 */         if (e.rendered) {
/* 126 */           successiveOmitted = false;
/*     */         }
/* 128 */         Iterator it = e.nodes.iterator();
/* 129 */         while ((it.hasNext()) && (successiveOmitted)) {
/* 130 */           Attr n = (Attr)it.next();
/* 131 */           if (n.getLocalName().equals("base")) {
/* 132 */             if (!e.rendered) {
/* 133 */               baseAttrs.add(n);
/*     */             }
/* 135 */           } else if (!loa.containsKey(n.getName()))
/* 136 */             loa.put(n.getName(), n);
/*     */         }
/*     */       }
/* 139 */       if (!baseAttrs.isEmpty()) {
/* 140 */         Iterator it = this.cur.nodes.iterator();
/* 141 */         String base = null;
/* 142 */         Attr baseAttr = null;
/* 143 */         while (it.hasNext()) {
/* 144 */           Attr n = (Attr)it.next();
/* 145 */           if (n.getLocalName().equals("base")) {
/* 146 */             base = n.getValue();
/* 147 */             baseAttr = n;
/* 148 */             break;
/*     */           }
/*     */         }
/* 151 */         it = baseAttrs.iterator();
/* 152 */         while (it.hasNext()) {
/* 153 */           Attr n = (Attr)it.next();
/* 154 */           if (base == null) {
/* 155 */             base = n.getValue();
/* 156 */             baseAttr = n;
/*     */           } else {
/*     */             try {
/* 159 */               base = Canonicalizer11.joinURI(n.getValue(), base);
/*     */             } catch (URISyntaxException ue) {
/* 161 */               ue.printStackTrace();
/*     */             }
/*     */           }
/*     */         }
/* 165 */         if ((base != null) && (base.length() != 0)) {
/* 166 */           baseAttr.setValue(base);
/* 167 */           col.add(baseAttr);
/*     */         }
/*     */       }
/*     */       
/* 171 */       this.cur.rendered = true;
/* 172 */       col.addAll(loa.values());
/*     */     } }
/*     */   
/* 175 */   XmlAttrStack xmlattrStack = new XmlAttrStack();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Canonicalizer11(boolean includeComments)
/*     */   {
/* 183 */     super(includeComments);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Iterator handleAttributesSubtree(Element E, NameSpaceSymbTable ns)
/*     */     throws CanonicalizationException
/*     */   {
/* 203 */     if ((!E.hasAttributes()) && (!this.firstCall)) {
/* 204 */       return null;
/*     */     }
/*     */     
/* 207 */     SortedSet result = this.result;
/* 208 */     result.clear();
/* 209 */     NamedNodeMap attrs = E.getAttributes();
/* 210 */     int attrsLength = attrs.getLength();
/*     */     
/* 212 */     for (int i = 0; i < attrsLength; i++) {
/* 213 */       Attr N = (Attr)attrs.item(i);
/* 214 */       String NUri = N.getNamespaceURI();
/*     */       
/* 216 */       if ("http://www.w3.org/2000/xmlns/" != NUri)
/*     */       {
/*     */ 
/* 219 */         result.add(N);
/*     */       }
/*     */       else
/*     */       {
/* 223 */         String NName = N.getLocalName();
/* 224 */         String NValue = N.getValue();
/* 225 */         if ((!"xml".equals(NName)) || (!"http://www.w3.org/XML/1998/namespace".equals(NValue)))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 231 */           Node n = ns.addMappingAndRender(NName, NValue, N);
/*     */           
/* 233 */           if (n != null)
/*     */           {
/* 235 */             result.add(n);
/* 236 */             if (C14nHelper.namespaceIsRelative(N)) {
/* 237 */               Object[] exArgs = { E.getTagName(), NName, N.getNodeValue() };
/* 238 */               throw new CanonicalizationException("c14n.Canonicalizer.RelativeNamespace", exArgs);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 244 */     if (this.firstCall)
/*     */     {
/*     */ 
/*     */ 
/* 248 */       ns.getUnrenderedNodes(result);
/*     */       
/* 250 */       this.xmlattrStack.getXmlnsAttr(result);
/* 251 */       this.firstCall = false;
/*     */     }
/*     */     
/* 254 */     return result.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Iterator handleAttributes(Element E, NameSpaceSymbTable ns)
/*     */     throws CanonicalizationException
/*     */   {
/* 273 */     this.xmlattrStack.push(ns.getLevel());
/* 274 */     boolean isRealVisible = isVisibleDO(E, ns.getLevel()) == 1;
/* 275 */     NamedNodeMap attrs = null;
/* 276 */     int attrsLength = 0;
/* 277 */     if (E.hasAttributes()) {
/* 278 */       attrs = E.getAttributes();
/* 279 */       attrsLength = attrs.getLength();
/*     */     }
/*     */     
/* 282 */     SortedSet result = this.result;
/* 283 */     result.clear();
/*     */     
/* 285 */     for (int i = 0; i < attrsLength; i++) {
/* 286 */       Attr N = (Attr)attrs.item(i);
/* 287 */       String NUri = N.getNamespaceURI();
/*     */       
/* 289 */       if ("http://www.w3.org/2000/xmlns/" != NUri)
/*     */       {
/* 291 */         if ("http://www.w3.org/XML/1998/namespace" == NUri) {
/* 292 */           if (N.getLocalName().equals("id")) {
/* 293 */             if (isRealVisible)
/*     */             {
/*     */ 
/* 296 */               result.add(N);
/*     */             }
/*     */           } else {
/* 299 */             this.xmlattrStack.addXmlnsAttr(N);
/*     */           }
/* 301 */         } else if (isRealVisible)
/*     */         {
/*     */ 
/* 304 */           result.add(N);
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 310 */         String NName = N.getLocalName();
/* 311 */         String NValue = N.getValue();
/* 312 */         if ((!"xml".equals(NName)) || (!"http://www.w3.org/XML/1998/namespace".equals(NValue)))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 322 */           if (isVisible(N)) {
/* 323 */             if ((isRealVisible) || (!ns.removeMappingIfRender(NName)))
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 329 */               Node n = ns.addMappingAndRender(NName, NValue, N);
/* 330 */               if (n != null) {
/* 331 */                 result.add(n);
/* 332 */                 if (C14nHelper.namespaceIsRelative(N)) {
/* 333 */                   Object[] exArgs = { E.getTagName(), NName, N.getNodeValue() };
/*     */                   
/* 335 */                   throw new CanonicalizationException("c14n.Canonicalizer.RelativeNamespace", exArgs);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/* 340 */           else if ((isRealVisible) && (NName != "xmlns")) {
/* 341 */             ns.removeMapping(NName);
/*     */           } else
/* 343 */             ns.addMapping(NName, NValue, N);
/*     */         }
/*     */       }
/*     */     }
/* 347 */     if (isRealVisible)
/*     */     {
/* 349 */       Attr xmlns = E.getAttributeNodeNS("http://www.w3.org/2000/xmlns/", "xmlns");
/* 350 */       Node n = null;
/* 351 */       if (xmlns == null)
/*     */       {
/* 353 */         n = ns.getMapping("xmlns");
/* 354 */       } else if (!isVisible(xmlns))
/*     */       {
/*     */ 
/* 357 */         n = ns.addMappingAndRender("xmlns", "", nullNode);
/*     */       }
/*     */       
/* 360 */       if (n != null) {
/* 361 */         result.add(n);
/*     */       }
/*     */       
/*     */ 
/* 365 */       this.xmlattrStack.getXmlnsAttr(result);
/* 366 */       ns.getUnrenderedNodes(result);
/*     */     }
/*     */     
/* 369 */     return result.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalizeXPathNodeSet(Set xpathNodeSet, String inclusiveNamespaces)
/*     */     throws CanonicalizationException
/*     */   {
/* 382 */     throw new CanonicalizationException("c14n.Canonicalizer.UnsupportedOperation");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalizeSubTree(Node rootNode, String inclusiveNamespaces)
/*     */     throws CanonicalizationException
/*     */   {
/* 396 */     throw new CanonicalizationException("c14n.Canonicalizer.UnsupportedOperation");
/*     */   }
/*     */   
/*     */ 
/*     */   void circumventBugIfNeeded(XMLSignatureInput input)
/*     */     throws CanonicalizationException, ParserConfigurationException, IOException, SAXException
/*     */   {
/* 403 */     if (!input.isNeedsToBeExpanded())
/* 404 */       return;
/* 405 */     Document doc = null;
/* 406 */     if (input.getSubNode() != null) {
/* 407 */       doc = XMLUtils.getOwnerDocument(input.getSubNode());
/*     */     } else {
/* 409 */       doc = XMLUtils.getOwnerDocument(input.getNodeSet());
/*     */     }
/* 411 */     XMLUtils.circumventBug2650(doc);
/*     */   }
/*     */   
/*     */   void handleParent(Element e, NameSpaceSymbTable ns) {
/* 415 */     if (!e.hasAttributes()) {
/* 416 */       return;
/*     */     }
/* 418 */     this.xmlattrStack.push(-1);
/* 419 */     NamedNodeMap attrs = e.getAttributes();
/* 420 */     int attrsLength = attrs.getLength();
/* 421 */     for (int i = 0; i < attrsLength; i++) {
/* 422 */       Attr N = (Attr)attrs.item(i);
/* 423 */       if ("http://www.w3.org/2000/xmlns/" != N.getNamespaceURI())
/*     */       {
/* 425 */         if ("http://www.w3.org/XML/1998/namespace" == N.getNamespaceURI()) {
/* 426 */           this.xmlattrStack.addXmlnsAttr(N);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 431 */         String NName = N.getLocalName();
/* 432 */         String NValue = N.getNodeValue();
/* 433 */         if ((!"xml".equals(NName)) || (!"http://www.w3.org/XML/1998/namespace".equals(NValue)))
/*     */         {
/*     */ 
/*     */ 
/* 437 */           ns.addMapping(NName, NValue, N); }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static String joinURI(String baseURI, String relativeURI) throws URISyntaxException {
/* 443 */     String bscheme = null;
/* 444 */     String bauthority = null;
/* 445 */     String bpath = "";
/* 446 */     String bquery = null;
/* 447 */     String bfragment = null;
/*     */     
/*     */ 
/* 450 */     if (baseURI != null) {
/* 451 */       if (baseURI.endsWith("..")) {
/* 452 */         baseURI = baseURI + "/";
/*     */       }
/* 454 */       URI base = new URI(baseURI);
/* 455 */       bscheme = base.getScheme();
/* 456 */       bauthority = base.getAuthority();
/* 457 */       bpath = base.getPath();
/* 458 */       bquery = base.getQuery();
/* 459 */       bfragment = base.getFragment();
/*     */     }
/*     */     
/* 462 */     URI r = new URI(relativeURI);
/* 463 */     String rscheme = r.getScheme();
/* 464 */     String rauthority = r.getAuthority();
/* 465 */     String rpath = r.getPath();
/* 466 */     String rquery = r.getQuery();
/* 467 */     String rfragment = null;
/*     */     
/*     */ 
/* 470 */     if ((rscheme != null) && (rscheme.equals(bscheme)))
/* 471 */       rscheme = null;
/*     */     String tquery;
/* 473 */     String tpath; String tquery; String tauthority; String tscheme; if (rscheme != null) {
/* 474 */       String tscheme = rscheme;
/* 475 */       String tauthority = rauthority;
/* 476 */       String tpath = removeDotSegments(rpath);
/* 477 */       tquery = rquery;
/*     */     } else { String tquery;
/* 479 */       if (rauthority != null) {
/* 480 */         String tauthority = rauthority;
/* 481 */         String tpath = removeDotSegments(rpath);
/* 482 */         tquery = rquery;
/*     */       } else { String tquery;
/* 484 */         if (rpath.length() == 0) {
/* 485 */           String tpath = bpath;
/* 486 */           String tquery; if (rquery != null) {
/* 487 */             tquery = rquery;
/*     */           } else
/* 489 */             tquery = bquery;
/*     */         } else {
/*     */           String tpath;
/* 492 */           if (rpath.startsWith("/")) {
/* 493 */             tpath = removeDotSegments(rpath);
/*     */           } else { String tpath;
/* 495 */             if ((bauthority != null) && (bpath.length() == 0)) {
/* 496 */               tpath = "/" + rpath;
/*     */             } else {
/* 498 */               int last = bpath.lastIndexOf('/');
/* 499 */               String tpath; if (last == -1) {
/* 500 */                 tpath = rpath;
/*     */               } else {
/* 502 */                 tpath = bpath.substring(0, last + 1) + rpath;
/*     */               }
/*     */             }
/* 505 */             tpath = removeDotSegments(tpath);
/*     */           }
/* 507 */           tquery = rquery;
/*     */         }
/* 509 */         tauthority = bauthority;
/*     */       }
/* 511 */       tscheme = bscheme;
/*     */     }
/* 513 */     String tfragment = rfragment;
/* 514 */     return new URI(tscheme, tauthority, tpath, tquery, tfragment).toString();
/*     */   }
/*     */   
/*     */   private static String removeDotSegments(String path)
/*     */   {
/* 519 */     log.debug("STEP   OUTPUT BUFFER\t\tINPUT BUFFER");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 524 */     String input = path;
/* 525 */     while (input.indexOf("//") > -1) {
/* 526 */       input = input.replaceAll("//", "/");
/*     */     }
/*     */     
/*     */ 
/* 530 */     StringBuffer output = new StringBuffer();
/*     */     
/*     */ 
/*     */ 
/* 534 */     if (input.charAt(0) == '/') {
/* 535 */       output.append("/");
/* 536 */       input = input.substring(1);
/*     */     }
/*     */     
/* 539 */     printStep("1 ", output.toString(), input);
/*     */     
/*     */ 
/* 542 */     while (input.length() != 0)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 549 */       if (input.startsWith("./")) {
/* 550 */         input = input.substring(2);
/* 551 */         printStep("2A", output.toString(), input);
/* 552 */       } else if (input.startsWith("../")) {
/* 553 */         input = input.substring(3);
/* 554 */         if (!output.toString().equals("/")) {
/* 555 */           output.append("../");
/*     */         }
/* 557 */         printStep("2A", output.toString(), input);
/*     */ 
/*     */ 
/*     */       }
/* 561 */       else if (input.startsWith("/./")) {
/* 562 */         input = input.substring(2);
/* 563 */         printStep("2B", output.toString(), input);
/* 564 */       } else if (input.equals("/."))
/*     */       {
/* 566 */         input = input.replaceFirst("/.", "/");
/* 567 */         printStep("2B", output.toString(), input);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/* 578 */       else if (input.startsWith("/../")) {
/* 579 */         input = input.substring(3);
/* 580 */         if (output.length() == 0) {
/* 581 */           output.append("/");
/* 582 */         } else if (output.toString().endsWith("../")) {
/* 583 */           output.append("..");
/* 584 */         } else if (output.toString().endsWith("..")) {
/* 585 */           output.append("/..");
/*     */         } else {
/* 587 */           int index = output.lastIndexOf("/");
/* 588 */           if (index == -1) {
/* 589 */             output = new StringBuffer();
/* 590 */             if (input.charAt(0) == '/') {
/* 591 */               input = input.substring(1);
/*     */             }
/*     */           } else {
/* 594 */             output = output.delete(index, output.length());
/*     */           }
/*     */         }
/* 597 */         printStep("2C", output.toString(), input);
/* 598 */       } else if (input.equals("/.."))
/*     */       {
/* 600 */         input = input.replaceFirst("/..", "/");
/* 601 */         if (output.length() == 0) {
/* 602 */           output.append("/");
/* 603 */         } else if (output.toString().endsWith("../")) {
/* 604 */           output.append("..");
/* 605 */         } else if (output.toString().endsWith("..")) {
/* 606 */           output.append("/..");
/*     */         } else {
/* 608 */           int index = output.lastIndexOf("/");
/* 609 */           if (index == -1) {
/* 610 */             output = new StringBuffer();
/* 611 */             if (input.charAt(0) == '/') {
/* 612 */               input = input.substring(1);
/*     */             }
/*     */           } else {
/* 615 */             output = output.delete(index, output.length());
/*     */           }
/*     */         }
/* 618 */         printStep("2C", output.toString(), input);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/* 624 */       else if (input.equals(".")) {
/* 625 */         input = "";
/* 626 */         printStep("2D", output.toString(), input);
/* 627 */       } else if (input.equals("..")) {
/* 628 */         if (!output.toString().equals("/"))
/* 629 */           output.append("..");
/* 630 */         input = "";
/* 631 */         printStep("2D", output.toString(), input);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 637 */         int end = -1;
/* 638 */         int begin = input.indexOf('/');
/* 639 */         if (begin == 0) {
/* 640 */           end = input.indexOf('/', 1);
/*     */         } else {
/* 642 */           end = begin;
/* 643 */           begin = 0;
/*     */         }
/*     */         String segment;
/* 646 */         if (end == -1) {
/* 647 */           String segment = input.substring(begin);
/* 648 */           input = "";
/*     */         } else {
/* 650 */           segment = input.substring(begin, end);
/* 651 */           input = input.substring(end);
/*     */         }
/* 653 */         output.append(segment);
/* 654 */         printStep("2E", output.toString(), input);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 662 */     if (output.toString().endsWith("..")) {
/* 663 */       output.append("/");
/* 664 */       printStep("3 ", output.toString(), input);
/*     */     }
/*     */     
/* 667 */     return output.toString();
/*     */   }
/*     */   
/*     */   private static void printStep(String step, String output, String input) {
/* 671 */     if (log.isDebugEnabled()) {
/* 672 */       log.debug(" " + step + ":   " + output);
/* 673 */       if (output.length() == 0) {
/* 674 */         log.debug("\t\t\t\t" + input);
/*     */       } else {
/* 676 */         log.debug("\t\t\t" + input);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\c14n\implementations\Canonicalizer11.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */