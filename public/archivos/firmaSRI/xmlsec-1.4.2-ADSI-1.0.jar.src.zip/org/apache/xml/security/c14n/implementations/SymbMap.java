/*     */ package org.apache.xml.security.c14n.implementations;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SymbMap
/*     */   implements Cloneable
/*     */ {
/* 317 */   int free = 23;
/*     */   NameSpaceSymbEntry[] entries;
/*     */   String[] keys;
/*     */   
/* 321 */   SymbMap() { this.entries = new NameSpaceSymbEntry[this.free];
/* 322 */     this.keys = new String[this.free];
/*     */   }
/*     */   
/* 325 */   void put(String key, NameSpaceSymbEntry value) { int index = index(key);
/* 326 */     Object oldKey = this.keys[index];
/* 327 */     this.keys[index] = key;
/* 328 */     this.entries[index] = value;
/* 329 */     if (((oldKey == null) || (!oldKey.equals(key))) && 
/* 330 */       (--this.free == 0)) {
/* 331 */       this.free = this.entries.length;
/* 332 */       int newCapacity = this.free << 2;
/* 333 */       rehash(newCapacity);
/*     */     }
/*     */   }
/*     */   
/*     */   List entrySet()
/*     */   {
/* 339 */     List a = new ArrayList();
/* 340 */     for (int i = 0; i < this.entries.length; i++) {
/* 341 */       if ((this.entries[i] != null) && (!"".equals(this.entries[i].uri))) {
/* 342 */         a.add(this.entries[i]);
/*     */       }
/*     */     }
/* 345 */     return a;
/*     */   }
/*     */   
/*     */   protected int index(Object obj) {
/* 349 */     Object[] set = this.keys;
/* 350 */     int length = set.length;
/*     */     
/* 352 */     int index = (obj.hashCode() & 0x7FFFFFFF) % length;
/* 353 */     Object cur = set[index];
/*     */     
/* 355 */     if ((cur == null) || (cur.equals(obj))) {
/* 356 */       return index;
/*     */     }
/* 358 */     length -= 1;
/*     */     do {
/* 360 */       index++;index = index == length ? 0 : index;
/* 361 */       cur = set[index];
/* 362 */     } while ((cur != null) && (!cur.equals(obj)));
/* 363 */     return index;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void rehash(int newCapacity)
/*     */   {
/* 372 */     int oldCapacity = this.keys.length;
/* 373 */     String[] oldKeys = this.keys;
/* 374 */     NameSpaceSymbEntry[] oldVals = this.entries;
/*     */     
/* 376 */     this.keys = new String[newCapacity];
/* 377 */     this.entries = new NameSpaceSymbEntry[newCapacity];
/*     */     
/* 379 */     for (int i = oldCapacity; i-- > 0;) {
/* 380 */       if (oldKeys[i] != null) {
/* 381 */         String o = oldKeys[i];
/* 382 */         int index = index(o);
/* 383 */         this.keys[index] = o;
/* 384 */         this.entries[index] = oldVals[i];
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   NameSpaceSymbEntry get(String key) {
/* 390 */     return this.entries[index(key)];
/*     */   }
/*     */   
/*     */   protected Object clone() {
/*     */     try {
/* 395 */       SymbMap copy = (SymbMap)super.clone();
/* 396 */       copy.entries = new NameSpaceSymbEntry[this.entries.length];
/* 397 */       System.arraycopy(this.entries, 0, copy.entries, 0, this.entries.length);
/* 398 */       copy.keys = new String[this.keys.length];
/* 399 */       System.arraycopy(this.keys, 0, copy.keys, 0, this.keys.length);
/*     */       
/* 401 */       return copy;
/*     */     }
/*     */     catch (CloneNotSupportedException e) {
/* 404 */       e.printStackTrace();
/*     */     }
/* 406 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\c14n\implementations\SymbMap.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */