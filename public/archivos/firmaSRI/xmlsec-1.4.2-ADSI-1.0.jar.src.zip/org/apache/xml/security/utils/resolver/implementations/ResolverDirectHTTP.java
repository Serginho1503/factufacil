/*     */ package org.apache.xml.security.utils.resolver.implementations;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import org.apache.xml.security.utils.Base64;
/*     */ import org.apache.xml.security.utils.resolver.ResourceResolverException;
/*     */ import org.apache.xml.security.utils.resolver.ResourceResolverSpi;
/*     */ import org.apache.xml.utils.URI;
/*     */ import org.apache.xml.utils.URI.MalformedURIException;
/*     */ import org.w3c.dom.Attr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResolverDirectHTTP
/*     */   extends ResourceResolverSpi
/*     */ {
/*  61 */   static Log log = LogFactory.getLog(ResolverDirectHTTP.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  66 */   private static final String[] properties = { "http.proxy.host", "http.proxy.port", "http.proxy.username", "http.proxy.password", "http.basic.username", "http.basic.password" };
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int HttpProxyHost = 0;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int HttpProxyPort = 1;
/*     */   
/*     */ 
/*     */   private static final int HttpProxyUser = 2;
/*     */   
/*     */ 
/*     */   private static final int HttpProxyPass = 3;
/*     */   
/*     */ 
/*     */   private static final int HttpBasicUser = 4;
/*     */   
/*     */ 
/*     */   private static final int HttpBasicPass = 5;
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean engineIsThreadSafe()
/*     */   {
/*  92 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput engineResolve(Attr uri, String BaseURI)
/*     */     throws ResourceResolverException
/*     */   {
/*     */     try
/*     */     {
/* 108 */       boolean useProxy = false;
/* 109 */       String proxyHost = engineGetProperty(properties[0]);
/*     */       
/*     */ 
/* 112 */       String proxyPort = engineGetProperty(properties[1]);
/*     */       
/*     */ 
/*     */ 
/* 116 */       if ((proxyHost != null) && (proxyPort != null)) {
/* 117 */         useProxy = true;
/*     */       }
/*     */       
/* 120 */       String oldProxySet = null;
/* 121 */       String oldProxyHost = null;
/* 122 */       String oldProxyPort = null;
/*     */       
/* 124 */       if (useProxy) {
/* 125 */         if (log.isDebugEnabled()) {
/* 126 */           log.debug("Use of HTTP proxy enabled: " + proxyHost + ":" + proxyPort);
/*     */         }
/*     */         
/* 129 */         oldProxySet = System.getProperty("http.proxySet");
/* 130 */         oldProxyHost = System.getProperty("http.proxyHost");
/* 131 */         oldProxyPort = System.getProperty("http.proxyPort");
/* 132 */         System.setProperty("http.proxySet", "true");
/* 133 */         System.setProperty("http.proxyHost", proxyHost);
/* 134 */         System.setProperty("http.proxyPort", proxyPort);
/*     */       }
/*     */       
/* 137 */       boolean switchBackProxy = (oldProxySet != null) && (oldProxyHost != null) && (oldProxyPort != null);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 142 */       URI uriNew = getNewURI(uri.getNodeValue(), BaseURI);
/*     */       
/*     */ 
/* 145 */       URI uriNewNoFrag = new URI(uriNew);
/*     */       
/* 147 */       uriNewNoFrag.setFragment(null);
/*     */       
/* 149 */       URL url = new URL(uriNewNoFrag.toString());
/* 150 */       URLConnection urlConnection = url.openConnection();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 155 */       String proxyUser = engineGetProperty(properties[2]);
/*     */       
/*     */ 
/* 158 */       String proxyPass = engineGetProperty(properties[3]);
/*     */       
/*     */ 
/*     */ 
/* 162 */       if ((proxyUser != null) && (proxyPass != null)) {
/* 163 */         String password = proxyUser + ":" + proxyPass;
/* 164 */         String encodedPassword = Base64.encode(password.getBytes());
/*     */         
/*     */ 
/* 167 */         urlConnection.setRequestProperty("Proxy-Authorization", encodedPassword);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 175 */       String auth = urlConnection.getHeaderField("WWW-Authenticate");
/*     */       
/* 177 */       if (auth != null)
/*     */       {
/*     */ 
/* 180 */         if (auth.startsWith("Basic")) {
/* 181 */           String user = engineGetProperty(properties[4]);
/*     */           
/*     */ 
/* 184 */           String pass = engineGetProperty(properties[5]);
/*     */           
/*     */ 
/*     */ 
/* 188 */           if ((user != null) && (pass != null)) {
/* 189 */             urlConnection = url.openConnection();
/*     */             
/* 191 */             String password = user + ":" + pass;
/* 192 */             String encodedPassword = Base64.encode(password.getBytes());
/*     */             
/*     */ 
/*     */ 
/* 196 */             urlConnection.setRequestProperty("Authorization", "Basic " + encodedPassword);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 204 */       String mimeType = urlConnection.getHeaderField("Content-Type");
/* 205 */       InputStream inputStream = urlConnection.getInputStream();
/* 206 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 207 */       byte[] buf = new byte['က'];
/* 208 */       int read = 0;
/* 209 */       int summarized = 0;
/*     */       
/* 211 */       while ((read = inputStream.read(buf)) >= 0) {
/* 212 */         baos.write(buf, 0, read);
/*     */         
/* 214 */         summarized += read;
/*     */       }
/*     */       
/* 217 */       log.debug("Fetched " + summarized + " bytes from URI " + uriNew.toString());
/*     */       
/*     */ 
/* 220 */       XMLSignatureInput result = new XMLSignatureInput(baos.toByteArray());
/*     */       
/*     */ 
/* 223 */       result.setSourceURI(uriNew.toString());
/* 224 */       result.setMIMEType(mimeType);
/*     */       
/*     */ 
/* 227 */       if ((useProxy) && (switchBackProxy)) {
/* 228 */         System.setProperty("http.proxySet", oldProxySet);
/* 229 */         System.setProperty("http.proxyHost", oldProxyHost);
/* 230 */         System.setProperty("http.proxyPort", oldProxyPort);
/*     */       }
/*     */       
/* 233 */       return result;
/*     */     } catch (MalformedURLException ex) {
/* 235 */       throw new ResourceResolverException("generic.EmptyMessage", ex, uri, BaseURI);
/*     */     }
/*     */     catch (IOException ex) {
/* 238 */       throw new ResourceResolverException("generic.EmptyMessage", ex, uri, BaseURI);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean engineCanResolve(Attr uri, String BaseURI)
/*     */   {
/* 251 */     if (uri == null) {
/* 252 */       log.debug("quick fail, uri == null");
/*     */       
/* 254 */       return false;
/*     */     }
/*     */     
/* 257 */     String uriNodeValue = uri.getNodeValue();
/*     */     
/* 259 */     if ((uriNodeValue.equals("")) || (uriNodeValue.charAt(0) == '#')) {
/* 260 */       log.debug("quick fail for empty URIs and local ones");
/*     */       
/* 262 */       return false;
/*     */     }
/*     */     
/* 265 */     if (log.isDebugEnabled()) {
/* 266 */       log.debug("I was asked whether I can resolve " + uriNodeValue);
/*     */     }
/*     */     
/* 269 */     if ((uriNodeValue.startsWith("http:")) || ((BaseURI != null) && (BaseURI.startsWith("http:"))))
/*     */     {
/* 271 */       if (log.isDebugEnabled()) {
/* 272 */         log.debug("I state that I can resolve " + uriNodeValue);
/*     */       }
/*     */       
/* 275 */       return true;
/*     */     }
/*     */     
/* 278 */     if (log.isDebugEnabled()) {
/* 279 */       log.debug("I state that I can't resolve " + uriNodeValue);
/*     */     }
/*     */     
/* 282 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String[] engineGetPropertyKeys()
/*     */   {
/* 289 */     return (String[])properties.clone();
/*     */   }
/*     */   
/*     */   private URI getNewURI(String uri, String BaseURI)
/*     */     throws URI.MalformedURIException
/*     */   {
/* 295 */     if ((BaseURI == null) || ("".equals(BaseURI))) {
/* 296 */       return new URI(uri);
/*     */     }
/* 298 */     return new URI(new URI(BaseURI), uri);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\utils\resolver\implementations\ResolverDirectHTTP.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */