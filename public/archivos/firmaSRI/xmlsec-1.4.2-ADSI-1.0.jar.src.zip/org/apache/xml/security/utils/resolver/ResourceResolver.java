/*     */ package org.apache.xml.security.utils.resolver;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import org.w3c.dom.Attr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceResolver
/*     */ {
/*  52 */   static Log log = LogFactory.getLog(ResourceResolver.class.getName());
/*     */   
/*     */ 
/*     */ 
/*  56 */   static boolean _alreadyInitialized = false;
/*     */   
/*     */ 
/*  59 */   static List _resolverVector = null;
/*     */   
/*  61 */   static boolean allThreadSafeInList = true;
/*     */   
/*     */ 
/*  64 */   protected ResourceResolverSpi _resolverSpi = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ResourceResolver(String className)
/*     */     throws ClassNotFoundException, IllegalAccessException, InstantiationException
/*     */   {
/*  77 */     this._resolverSpi = ((ResourceResolverSpi)Class.forName(className).newInstance());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceResolver(ResourceResolverSpi resourceResolver)
/*     */   {
/*  87 */     this._resolverSpi = resourceResolver;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final ResourceResolver getInstance(Attr uri, String BaseURI)
/*     */     throws ResourceResolverException
/*     */   {
/* 102 */     int length = _resolverVector.size();
/* 103 */     for (int i = 0; i < length; i++) {
/* 104 */       ResourceResolver resolver = (ResourceResolver)_resolverVector.get(i);
/*     */       
/* 106 */       ResourceResolver resolverTmp = null;
/*     */       try {
/* 108 */         resolverTmp = (allThreadSafeInList) || (resolver._resolverSpi.engineIsThreadSafe()) ? resolver : new ResourceResolver((ResourceResolverSpi)resolver._resolverSpi.getClass().newInstance());
/*     */       }
/*     */       catch (InstantiationException e) {
/* 111 */         throw new ResourceResolverException("", e, uri, BaseURI);
/*     */       } catch (IllegalAccessException e) {
/* 113 */         throw new ResourceResolverException("", e, uri, BaseURI);
/*     */       }
/*     */       
/* 116 */       if (log.isDebugEnabled()) {
/* 117 */         log.debug("check resolvability by class " + resolver._resolverSpi.getClass().getName());
/*     */       }
/* 119 */       if ((resolver != null) && (resolverTmp.canResolve(uri, BaseURI))) {
/* 120 */         if (i != 0)
/*     */         {
/*     */ 
/* 123 */           List resolverVector = (List)((ArrayList)_resolverVector).clone();
/* 124 */           resolverVector.remove(i);
/* 125 */           resolverVector.add(0, resolver);
/* 126 */           _resolverVector = resolverVector;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 131 */         return resolverTmp;
/*     */       }
/*     */     }
/*     */     
/* 135 */     Object[] exArgs = { uri != null ? uri.getNodeValue() : "null", BaseURI };
/*     */     
/*     */ 
/*     */ 
/* 139 */     throw new ResourceResolverException("utils.resolver.noClass", exArgs, uri, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final ResourceResolver getInstance(Attr uri, String BaseURI, List individualResolvers)
/*     */     throws ResourceResolverException
/*     */   {
/* 155 */     if (log.isDebugEnabled())
/*     */     {
/* 157 */       log.debug("I was asked to create a ResourceResolver and got " + (individualResolvers == null ? 0 : individualResolvers.size()));
/* 158 */       log.debug(" extra resolvers to my existing " + _resolverVector.size() + " system-wide resolvers");
/*     */     }
/*     */     
/*     */ 
/* 162 */     int size = 0;
/* 163 */     if ((individualResolvers != null) && ((size = individualResolvers.size()) > 0)) {
/* 164 */       for (int i = 0; i < size; i++) {
/* 165 */         ResourceResolver resolver = (ResourceResolver)individualResolvers.get(i);
/*     */         
/*     */ 
/* 168 */         if (resolver != null) {
/* 169 */           String currentClass = resolver._resolverSpi.getClass().getName();
/* 170 */           if (log.isDebugEnabled()) {
/* 171 */             log.debug("check resolvability by class " + currentClass);
/*     */           }
/* 173 */           if (resolver.canResolve(uri, BaseURI)) {
/* 174 */             return resolver;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 180 */     return getInstance(uri, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void init()
/*     */   {
/* 188 */     if (!_alreadyInitialized) {
/* 189 */       _resolverVector = new ArrayList(10);
/* 190 */       _alreadyInitialized = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void register(String className)
/*     */   {
/* 202 */     register(className, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void registerAtStart(String className)
/*     */   {
/* 213 */     register(className, true);
/*     */   }
/*     */   
/*     */   private static void register(String className, boolean start) {
/*     */     try {
/* 218 */       ResourceResolver resolver = new ResourceResolver(className);
/* 219 */       if (start) {
/* 220 */         _resolverVector.add(0, resolver);
/* 221 */         log.debug("registered resolver");
/*     */       } else {
/* 223 */         _resolverVector.add(resolver);
/*     */       }
/* 225 */       if (!resolver._resolverSpi.engineIsThreadSafe()) {
/* 226 */         allThreadSafeInList = false;
/*     */       }
/*     */     } catch (Exception e) {
/* 229 */       log.warn("Error loading resolver " + className + " disabling it");
/*     */     } catch (NoClassDefFoundError e) {
/* 231 */       log.warn("Error loading resolver " + className + " disabling it");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XMLSignatureInput resolveStatic(Attr uri, String BaseURI)
/*     */     throws ResourceResolverException
/*     */   {
/* 247 */     ResourceResolver myResolver = getInstance(uri, BaseURI);
/*     */     
/* 249 */     return myResolver.resolve(uri, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput resolve(Attr uri, String BaseURI)
/*     */     throws ResourceResolverException
/*     */   {
/* 263 */     return this._resolverSpi.engineResolve(uri, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProperty(String key, String value)
/*     */   {
/* 273 */     this._resolverSpi.engineSetProperty(key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getProperty(String key)
/*     */   {
/* 283 */     return this._resolverSpi.engineGetProperty(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addProperties(Map properties)
/*     */   {
/* 292 */     this._resolverSpi.engineAddProperies(properties);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getPropertyKeys()
/*     */   {
/* 301 */     return this._resolverSpi.engineGetPropertyKeys();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean understandsProperty(String propertyToTest)
/*     */   {
/* 311 */     return this._resolverSpi.understandsProperty(propertyToTest);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean canResolve(Attr uri, String BaseURI)
/*     */   {
/* 322 */     return this._resolverSpi.engineCanResolve(uri, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean canAccessData()
/*     */   {
/* 331 */     return !this._resolverSpi.engineIsPrivateData();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\utils\resolver\ResourceResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */