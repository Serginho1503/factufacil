/*    */ package org.apache.xml.security.c14n.implementations;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Canonicalizer20010315ExclWithComments
/*    */   extends Canonicalizer20010315Excl
/*    */ {
/*    */   public Canonicalizer20010315ExclWithComments()
/*    */   {
/* 37 */     super(true);
/*    */   }
/*    */   
/*    */   public final String engineGetURI()
/*    */   {
/* 42 */     return "http://www.w3.org/2001/10/xml-exc-c14n#WithComments";
/*    */   }
/*    */   
/*    */   public final boolean engineGetIncludeComments()
/*    */   {
/* 47 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\c14n\implementations\Canonicalizer20010315ExclWithComments.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */