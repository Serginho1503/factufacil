/*     */ package org.apache.xml.security.utils;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import java.util.HashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.exceptions.Base64DecodingException;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ElementProxy
/*     */ {
/*  43 */   static Log log = LogFactory.getLog(ElementProxy.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  61 */   protected Element _constructionElement = null;
/*     */   
/*     */ 
/*  64 */   protected String _baseURI = null;
/*     */   
/*     */ 
/*  67 */   protected Document _doc = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract String getBaseNamespace();
/*     */   
/*     */ 
/*     */   public abstract String getBaseLocalName();
/*     */   
/*     */ 
/*     */   public ElementProxy() {}
/*     */   
/*     */ 
/*     */   public ElementProxy(Document doc)
/*     */   {
/*  82 */     if (doc == null) {
/*  83 */       throw new RuntimeException("Document is null");
/*     */     }
/*     */     
/*  86 */     this._doc = doc;
/*  87 */     this._constructionElement = createElementForFamilyLocal(this._doc, getBaseNamespace(), getBaseLocalName());
/*     */   }
/*     */   
/*     */   protected Element createElementForFamilyLocal(Document doc, String namespace, String localName)
/*     */   {
/*  92 */     Element result = null;
/*  93 */     if (namespace == null) {
/*  94 */       result = doc.createElementNS(null, localName);
/*     */     } else {
/*  96 */       String baseName = getBaseNamespace();
/*  97 */       String prefix = getDefaultPrefix(baseName);
/*  98 */       if ((prefix == null) || (prefix.length() == 0)) {
/*  99 */         result = doc.createElementNS(namespace, localName);
/*     */         
/* 101 */         result.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns", namespace);
/*     */       }
/*     */       else {
/* 104 */         String tagName = null;
/* 105 */         String defaultPrefixNaming = getDefaultPrefixBindings(baseName);
/* 106 */         StringBuffer sb = new StringBuffer(prefix);
/* 107 */         sb.append(':');
/* 108 */         sb.append(localName);
/* 109 */         tagName = sb.toString();
/* 110 */         result = doc.createElementNS(namespace, tagName);
/*     */         
/* 112 */         result.setAttributeNS("http://www.w3.org/2000/xmlns/", defaultPrefixNaming, namespace);
/*     */       }
/*     */     }
/*     */     
/* 116 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Element createElementForFamily(Document doc, String namespace, String localName)
/*     */   {
/* 135 */     Element result = null;
/* 136 */     String prefix = getDefaultPrefix(namespace);
/*     */     
/* 138 */     if (namespace == null) {
/* 139 */       result = doc.createElementNS(null, localName);
/*     */     }
/* 141 */     else if ((prefix == null) || (prefix.length() == 0)) {
/* 142 */       result = doc.createElementNS(namespace, localName);
/*     */       
/* 144 */       result.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns", namespace);
/*     */     }
/*     */     else {
/* 147 */       result = doc.createElementNS(namespace, prefix + ":" + localName);
/*     */       
/* 149 */       result.setAttributeNS("http://www.w3.org/2000/xmlns/", getDefaultPrefixBindings(namespace), namespace);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 154 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setElement(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 167 */     if (element == null) {
/* 168 */       throw new XMLSecurityException("ElementProxy.nullElement");
/*     */     }
/*     */     
/* 171 */     if (log.isDebugEnabled()) {
/* 172 */       log.debug("setElement(" + element.getTagName() + ", \"" + BaseURI + "\"");
/*     */     }
/*     */     
/* 175 */     this._doc = element.getOwnerDocument();
/* 176 */     this._constructionElement = element;
/* 177 */     this._baseURI = BaseURI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ElementProxy(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 189 */     if (element == null) {
/* 190 */       throw new XMLSecurityException("ElementProxy.nullElement");
/*     */     }
/*     */     
/* 193 */     if (log.isDebugEnabled()) {
/* 194 */       log.debug("setElement(\"" + element.getTagName() + "\", \"" + BaseURI + "\")");
/*     */     }
/*     */     
/*     */ 
/* 198 */     this._doc = element.getOwnerDocument();
/* 199 */     this._constructionElement = element;
/* 200 */     this._baseURI = BaseURI;
/*     */     
/* 202 */     guaranteeThatElementInCorrectSpace();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Element getElement()
/*     */   {
/* 211 */     return this._constructionElement;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final NodeList getElementPlusReturns()
/*     */   {
/* 221 */     HelperNodeList nl = new HelperNodeList();
/*     */     
/* 223 */     nl.appendChild(this._doc.createTextNode("\n"));
/* 224 */     nl.appendChild(getElement());
/* 225 */     nl.appendChild(this._doc.createTextNode("\n"));
/*     */     
/* 227 */     return nl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Document getDocument()
/*     */   {
/* 236 */     return this._doc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBaseURI()
/*     */   {
/* 245 */     return this._baseURI;
/*     */   }
/*     */   
/* 248 */   static ElementChecker checker = new ElementCheckerImpl.InternedNsChecker();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void guaranteeThatElementInCorrectSpace()
/*     */     throws XMLSecurityException
/*     */   {
/* 258 */     checker.guaranteeThatElementInCorrectSpace(this, this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addBigIntegerElement(BigInteger bi, String localname)
/*     */   {
/* 270 */     if (bi != null) {
/* 271 */       Element e = XMLUtils.createElementInSignatureSpace(this._doc, localname);
/*     */       
/*     */ 
/* 274 */       Base64.fillElementWithBigInteger(e, bi);
/* 275 */       this._constructionElement.appendChild(e);
/* 276 */       XMLUtils.addReturnToElement(this._constructionElement);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addBase64Element(byte[] bytes, String localname)
/*     */   {
/* 288 */     if (bytes != null)
/*     */     {
/* 290 */       Element e = Base64.encodeToElement(this._doc, localname, bytes);
/*     */       
/* 292 */       this._constructionElement.appendChild(e);
/* 293 */       if (!XMLUtils.ignoreLineBreaks()) {
/* 294 */         this._constructionElement.appendChild(this._doc.createTextNode("\n"));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addTextElement(String text, String localname)
/*     */   {
/* 307 */     Element e = XMLUtils.createElementInSignatureSpace(this._doc, localname);
/* 308 */     Text t = this._doc.createTextNode(text);
/*     */     
/* 310 */     e.appendChild(t);
/* 311 */     this._constructionElement.appendChild(e);
/* 312 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addBase64Text(byte[] bytes)
/*     */   {
/* 322 */     if (bytes != null) {
/* 323 */       Text t = XMLUtils.ignoreLineBreaks() ? this._doc.createTextNode(Base64.encode(bytes)) : this._doc.createTextNode("\n" + Base64.encode(bytes) + "\n");
/*     */       
/*     */ 
/* 326 */       this._constructionElement.appendChild(t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addText(String text)
/*     */   {
/* 337 */     if (text != null) {
/* 338 */       Text t = this._doc.createTextNode(text);
/*     */       
/* 340 */       this._constructionElement.appendChild(t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BigInteger getBigIntegerFromChildElement(String localname, String namespace)
/*     */     throws Base64DecodingException
/*     */   {
/* 355 */     return Base64.decodeBigIntegerFromText(XMLUtils.selectNodeText(this._constructionElement.getFirstChild(), namespace, localname, 0));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public byte[] getBytesFromChildElement(String localname, String namespace)
/*     */     throws XMLSecurityException
/*     */   {
/* 372 */     Element e = XMLUtils.selectNode(this._constructionElement.getFirstChild(), namespace, localname, 0);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 379 */     return Base64.decode(e);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTextFromChildElement(String localname, String namespace)
/*     */   {
/* 391 */     Text t = (Text)XMLUtils.selectNode(this._constructionElement.getFirstChild(), namespace, localname, 0).getFirstChild();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 398 */     return t.getData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getBytesFromTextChild()
/*     */     throws XMLSecurityException
/*     */   {
/* 408 */     return Base64.decode(XMLUtils.getFullTextChildrenFromElement(this._constructionElement));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTextFromTextChild()
/*     */   {
/* 419 */     return XMLUtils.getFullTextChildrenFromElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int length(String namespace, String localname)
/*     */   {
/* 430 */     int number = 0;
/* 431 */     Node sibling = this._constructionElement.getFirstChild();
/* 432 */     while (sibling != null) {
/* 433 */       if ((localname.equals(sibling.getLocalName())) && (namespace == sibling.getNamespaceURI()))
/*     */       {
/*     */ 
/* 436 */         number++;
/*     */       }
/* 438 */       sibling = sibling.getNextSibling();
/*     */     }
/* 440 */     return number;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXPathNamespaceContext(String prefix, String uri)
/*     */     throws XMLSecurityException
/*     */   {
/* 461 */     if ((prefix == null) || (prefix.length() == 0))
/* 462 */       throw new XMLSecurityException("defaultNamespaceCannotBeSetHere");
/* 463 */     if (prefix.equals("xmlns"))
/* 464 */       throw new XMLSecurityException("defaultNamespaceCannotBeSetHere");
/* 465 */     String ns; String ns; if (prefix.startsWith("xmlns:")) {
/* 466 */       ns = prefix;
/*     */     } else {
/* 468 */       ns = "xmlns:" + prefix;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 473 */     Attr a = this._constructionElement.getAttributeNodeNS("http://www.w3.org/2000/xmlns/", ns);
/*     */     
/* 475 */     if (a != null) {
/* 476 */       if (!a.getNodeValue().equals(uri)) {
/* 477 */         Object[] exArgs = { ns, this._constructionElement.getAttributeNS(null, ns) };
/*     */         
/*     */ 
/*     */ 
/* 481 */         throw new XMLSecurityException("namespacePrefixAlreadyUsedByOtherURI", exArgs);
/*     */       }
/*     */       
/* 484 */       return;
/*     */     }
/*     */     
/* 487 */     this._constructionElement.setAttributeNS("http://www.w3.org/2000/xmlns/", ns, uri);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 492 */   static HashMap _prefixMappings = new HashMap();
/* 493 */   static HashMap _prefixMappingsBindings = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setDefaultPrefix(String namespace, String prefix)
/*     */     throws XMLSecurityException
/*     */   {
/* 505 */     if (_prefixMappings.containsValue(prefix))
/*     */     {
/* 507 */       Object storedNamespace = _prefixMappings.get(namespace);
/* 508 */       if (!storedNamespace.equals(prefix)) {
/* 509 */         Object[] exArgs = { prefix, namespace, storedNamespace };
/*     */         
/* 511 */         throw new XMLSecurityException("prefix.AlreadyAssigned", exArgs);
/*     */       }
/*     */     }
/* 514 */     if ("http://www.w3.org/2000/09/xmldsig#".equals(namespace)) {
/* 515 */       XMLUtils.dsPrefix = prefix;
/*     */     }
/* 517 */     _prefixMappings.put(namespace, prefix.intern());
/* 518 */     if (prefix.length() == 0) {
/* 519 */       _prefixMappingsBindings.put(namespace, "xmlns");
/*     */     } else {
/* 521 */       _prefixMappingsBindings.put(namespace, ("xmlns:" + prefix).intern());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getDefaultPrefix(String namespace)
/*     */   {
/* 532 */     return (String)_prefixMappings.get(namespace);
/*     */   }
/*     */   
/*     */   public static String getDefaultPrefixBindings(String namespace) {
/* 536 */     return (String)_prefixMappingsBindings.get(namespace);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\utils\ElementProxy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */