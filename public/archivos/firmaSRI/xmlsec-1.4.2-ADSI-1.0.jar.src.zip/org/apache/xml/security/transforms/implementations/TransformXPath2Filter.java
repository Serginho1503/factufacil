/*     */ package org.apache.xml.security.transforms.implementations;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import org.apache.xml.security.c14n.InvalidCanonicalizerException;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import org.apache.xml.security.transforms.Transform;
/*     */ import org.apache.xml.security.transforms.TransformSpi;
/*     */ import org.apache.xml.security.transforms.TransformationException;
/*     */ import org.apache.xml.security.transforms.params.XPath2FilterContainer;
/*     */ import org.apache.xml.security.utils.CachedXPathAPIHolder;
/*     */ import org.apache.xml.security.utils.CachedXPathFuncHereAPI;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransformXPath2Filter
/*     */   extends TransformSpi
/*     */ {
/*     */   public static final String implementedTransformURI = "http://www.w3.org/2002/06/xmldsig-filter2";
/*     */   
/*     */   protected String engineGetURI()
/*     */   {
/*  79 */     return "http://www.w3.org/2002/06/xmldsig-filter2";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, Transform _transformObject)
/*     */     throws TransformationException
/*     */   {
/*  93 */     CachedXPathAPIHolder.setDoc(_transformObject.getElement().getOwnerDocument());
/*     */     try {
/*  95 */       List unionNodes = new ArrayList();
/*  96 */       List substractNodes = new ArrayList();
/*  97 */       List intersectNodes = new ArrayList();
/*     */       
/*  99 */       CachedXPathFuncHereAPI xPathFuncHereAPI = new CachedXPathFuncHereAPI(CachedXPathAPIHolder.getCachedXPathAPI());
/*     */       
/*     */ 
/*     */ 
/* 103 */       Element[] xpathElements = XMLUtils.selectNodes(_transformObject.getElement().getFirstChild(), "http://www.w3.org/2002/06/xmldsig-filter2", "XPath");
/*     */       
/*     */ 
/*     */ 
/* 107 */       int noOfSteps = xpathElements.length;
/*     */       
/*     */ 
/* 110 */       if (noOfSteps == 0) {
/* 111 */         Object[] exArgs = { "http://www.w3.org/2002/06/xmldsig-filter2", "XPath" };
/*     */         
/* 113 */         throw new TransformationException("xml.WrongContent", exArgs);
/*     */       }
/*     */       
/* 116 */       Document inputDoc = null;
/* 117 */       if (input.getSubNode() != null) {
/* 118 */         inputDoc = XMLUtils.getOwnerDocument(input.getSubNode());
/*     */       } else {
/* 120 */         inputDoc = XMLUtils.getOwnerDocument(input.getNodeSet());
/*     */       }
/*     */       
/* 123 */       for (int i = 0; i < noOfSteps; i++) {
/* 124 */         Element xpathElement = XMLUtils.selectNode(_transformObject.getElement().getFirstChild(), "http://www.w3.org/2002/06/xmldsig-filter2", "XPath", i);
/*     */         
/*     */ 
/*     */ 
/* 128 */         XPath2FilterContainer xpathContainer = XPath2FilterContainer.newInstance(xpathElement, input.getSourceURI());
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 133 */         NodeList subtreeRoots = xPathFuncHereAPI.selectNodeList(inputDoc, xpathContainer.getXPathFilterTextNode(), CachedXPathFuncHereAPI.getStrFromNode(xpathContainer.getXPathFilterTextNode()), xpathContainer.getElement());
/*     */         
/*     */ 
/*     */ 
/* 137 */         if (xpathContainer.isIntersect()) {
/* 138 */           intersectNodes.add(subtreeRoots);
/* 139 */         } else if (xpathContainer.isSubtract()) {
/* 140 */           substractNodes.add(subtreeRoots);
/* 141 */         } else if (xpathContainer.isUnion()) {
/* 142 */           unionNodes.add(subtreeRoots);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 147 */       input.addNodeFilter(new XPath2NodeFilter(convertNodeListToSet(unionNodes), convertNodeListToSet(substractNodes), convertNodeListToSet(intersectNodes)));
/*     */       
/* 149 */       input.setNodeSet(true);
/* 150 */       return input;
/*     */     } catch (TransformerException ex) {
/* 152 */       throw new TransformationException("empty", ex);
/*     */     } catch (DOMException ex) {
/* 154 */       throw new TransformationException("empty", ex);
/*     */     } catch (CanonicalizationException ex) {
/* 156 */       throw new TransformationException("empty", ex);
/*     */     } catch (InvalidCanonicalizerException ex) {
/* 158 */       throw new TransformationException("empty", ex);
/*     */     } catch (XMLSecurityException ex) {
/* 160 */       throw new TransformationException("empty", ex);
/*     */     } catch (SAXException ex) {
/* 162 */       throw new TransformationException("empty", ex);
/*     */     } catch (IOException ex) {
/* 164 */       throw new TransformationException("empty", ex);
/*     */     } catch (ParserConfigurationException ex) {
/* 166 */       throw new TransformationException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/* 170 */   static Set convertNodeListToSet(List l) { Set result = new HashSet();
/* 171 */     for (int j = 0; j < l.size(); j++) {
/* 172 */       NodeList rootNodes = (NodeList)l.get(j);
/* 173 */       int length = rootNodes.getLength();
/*     */       
/* 175 */       for (int i = 0; i < length; i++) {
/* 176 */         Node rootNode = rootNodes.item(i);
/* 177 */         result.add(rootNode);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 182 */     return result;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\transforms\implementations\TransformXPath2Filter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */