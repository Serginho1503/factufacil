/*     */ package org.apache.xml.security.algorithms.implementations;
/*     */ 
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.Key;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.Provider;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.spec.AlgorithmParameterSpec;
/*     */ import javax.crypto.Mac;
/*     */ import javax.crypto.SecretKey;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.algorithms.JCEMapper;
/*     */ import org.apache.xml.security.algorithms.MessageDigestAlgorithm;
/*     */ import org.apache.xml.security.algorithms.SignatureAlgorithmSpi;
/*     */ import org.apache.xml.security.signature.XMLSignatureException;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class IntegrityHmac
/*     */   extends SignatureAlgorithmSpi
/*     */ {
/*  49 */   static Log log = LogFactory.getLog(IntegrityHmacSHA1.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  60 */   private Mac _macAlgorithm = null;
/*     */   
/*     */ 
/*  63 */   int _HMACOutputLength = 0;
/*     */   
/*     */ 
/*     */   public abstract String engineGetURI();
/*     */   
/*     */ 
/*     */   public IntegrityHmac()
/*     */     throws XMLSignatureException
/*     */   {
/*  72 */     String algorithmID = JCEMapper.translateURItoJCEID(engineGetURI());
/*  73 */     if (log.isDebugEnabled()) {
/*  74 */       log.debug("Created IntegrityHmacSHA1 using " + algorithmID);
/*     */     }
/*     */     try {
/*  77 */       this._macAlgorithm = Mac.getInstance(algorithmID);
/*     */     } catch (NoSuchAlgorithmException ex) {
/*  79 */       Object[] exArgs = { algorithmID, ex.getLocalizedMessage() };
/*     */       
/*     */ 
/*  82 */       throw new XMLSignatureException("algorithms.NoSuchAlgorithm", exArgs);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineSetParameter(AlgorithmParameterSpec params)
/*     */     throws XMLSignatureException
/*     */   {
/*  95 */     throw new XMLSignatureException("empty");
/*     */   }
/*     */   
/*     */   public void reset() {
/*  99 */     this._HMACOutputLength = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean engineVerify(byte[] signature)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 114 */       byte[] completeResult = this._macAlgorithm.doFinal();
/*     */       
/* 116 */       if ((this._HMACOutputLength == 0) || (this._HMACOutputLength >= 160)) {
/* 117 */         return MessageDigestAlgorithm.isEqual(completeResult, signature);
/*     */       }
/* 119 */       byte[] stripped = reduceBitLength(completeResult, this._HMACOutputLength);
/*     */       
/* 121 */       return MessageDigestAlgorithm.isEqual(stripped, signature);
/*     */     } catch (IllegalStateException ex) {
/* 123 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineInitVerify(Key secretKey)
/*     */     throws XMLSignatureException
/*     */   {
/* 136 */     if (!(secretKey instanceof SecretKey)) {
/* 137 */       String supplied = secretKey.getClass().getName();
/* 138 */       String needed = SecretKey.class.getName();
/* 139 */       Object[] exArgs = { supplied, needed };
/*     */       
/* 141 */       throw new XMLSignatureException("algorithms.WrongKeyForThisOperation", exArgs);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 146 */       this._macAlgorithm.init(secretKey);
/*     */     }
/*     */     catch (InvalidKeyException ex)
/*     */     {
/* 150 */       Mac mac = this._macAlgorithm;
/*     */       try {
/* 152 */         this._macAlgorithm = Mac.getInstance(this._macAlgorithm.getAlgorithm());
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 156 */         if (log.isDebugEnabled()) {
/* 157 */           log.debug("Exception when reinstantiating Mac:" + e);
/*     */         }
/* 159 */         this._macAlgorithm = mac;
/*     */       }
/* 161 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected byte[] engineSign()
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 175 */       byte[] completeResult = this._macAlgorithm.doFinal();
/*     */       
/* 177 */       if ((this._HMACOutputLength == 0) || (this._HMACOutputLength >= 160)) {
/* 178 */         return completeResult;
/*     */       }
/* 180 */       return reduceBitLength(completeResult, this._HMACOutputLength);
/*     */     }
/*     */     catch (IllegalStateException ex)
/*     */     {
/* 184 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static byte[] reduceBitLength(byte[] completeResult, int length)
/*     */   {
/* 198 */     int bytes = length / 8;
/* 199 */     int abits = length % 8;
/* 200 */     byte[] strippedResult = new byte[bytes + (abits == 0 ? 0 : 1)];
/*     */     
/*     */ 
/*     */ 
/* 204 */     System.arraycopy(completeResult, 0, strippedResult, 0, bytes);
/*     */     
/* 206 */     if (abits > 0) {
/* 207 */       byte[] MASK = { 0, Byte.MIN_VALUE, -64, -32, -16, -8, -4, -2 };
/*     */       
/*     */ 
/* 210 */       strippedResult[bytes] = ((byte)(completeResult[bytes] & MASK[abits]));
/*     */     }
/*     */     
/* 213 */     return strippedResult;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineInitSign(Key secretKey)
/*     */     throws XMLSignatureException
/*     */   {
/* 224 */     if (!(secretKey instanceof SecretKey)) {
/* 225 */       String supplied = secretKey.getClass().getName();
/* 226 */       String needed = SecretKey.class.getName();
/* 227 */       Object[] exArgs = { supplied, needed };
/*     */       
/* 229 */       throw new XMLSignatureException("algorithms.WrongKeyForThisOperation", exArgs);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 234 */       this._macAlgorithm.init(secretKey);
/*     */     } catch (InvalidKeyException ex) {
/* 236 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineInitSign(Key secretKey, AlgorithmParameterSpec algorithmParameterSpec)
/*     */     throws XMLSignatureException
/*     */   {
/* 251 */     if (!(secretKey instanceof SecretKey)) {
/* 252 */       String supplied = secretKey.getClass().getName();
/* 253 */       String needed = SecretKey.class.getName();
/* 254 */       Object[] exArgs = { supplied, needed };
/*     */       
/* 256 */       throw new XMLSignatureException("algorithms.WrongKeyForThisOperation", exArgs);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 261 */       this._macAlgorithm.init(secretKey, algorithmParameterSpec);
/*     */     } catch (InvalidKeyException ex) {
/* 263 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (InvalidAlgorithmParameterException ex) {
/* 265 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineInitSign(Key secretKey, SecureRandom secureRandom)
/*     */     throws XMLSignatureException
/*     */   {
/* 278 */     throw new XMLSignatureException("algorithms.CannotUseSecureRandomOnMAC");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineUpdate(byte[] input)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 291 */       this._macAlgorithm.update(input);
/*     */     } catch (IllegalStateException ex) {
/* 293 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineUpdate(byte input)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 307 */       this._macAlgorithm.update(input);
/*     */     } catch (IllegalStateException ex) {
/* 309 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineUpdate(byte[] buf, int offset, int len)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 326 */       this._macAlgorithm.update(buf, offset, len);
/*     */     } catch (IllegalStateException ex) {
/* 328 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String engineGetJCEAlgorithmString()
/*     */   {
/* 339 */     log.debug("engineGetJCEAlgorithmString()");
/*     */     
/* 341 */     return this._macAlgorithm.getAlgorithm();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String engineGetJCEProviderName()
/*     */   {
/* 350 */     return this._macAlgorithm.getProvider().getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineSetHMACOutputLength(int HMACOutputLength)
/*     */   {
/* 359 */     this._HMACOutputLength = HMACOutputLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineGetContextFromElement(Element element)
/*     */   {
/* 369 */     super.engineGetContextFromElement(element);
/*     */     
/* 371 */     if (element == null) {
/* 372 */       throw new IllegalArgumentException("element null");
/*     */     }
/*     */     
/* 375 */     Text hmaclength = XMLUtils.selectDsNodeText(element.getFirstChild(), "HMACOutputLength", 0);
/*     */     
/*     */ 
/* 378 */     if (hmaclength != null) {
/* 379 */       this._HMACOutputLength = Integer.parseInt(hmaclength.getData());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void engineAddContextToElement(Element element)
/*     */   {
/* 392 */     if (element == null) {
/* 393 */       throw new IllegalArgumentException("null element");
/*     */     }
/*     */     
/* 396 */     if (this._HMACOutputLength != 0) {
/* 397 */       Document doc = element.getOwnerDocument();
/* 398 */       Element HMElem = XMLUtils.createElementInSignatureSpace(doc, "HMACOutputLength");
/*     */       
/* 400 */       Text HMText = doc.createTextNode(new Integer(this._HMACOutputLength).toString());
/*     */       
/*     */ 
/* 403 */       HMElem.appendChild(HMText);
/* 404 */       XMLUtils.addReturnToElement(element);
/* 405 */       element.appendChild(HMElem);
/* 406 */       XMLUtils.addReturnToElement(element);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class IntegrityHmacSHA1
/*     */     extends IntegrityHmac
/*     */   {
/*     */     public IntegrityHmacSHA1()
/*     */       throws XMLSignatureException
/*     */     {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String engineGetURI()
/*     */     {
/* 433 */       return "http://www.w3.org/2000/09/xmldsig#hmac-sha1";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class IntegrityHmacSHA256
/*     */     extends IntegrityHmac
/*     */   {
/*     */     public IntegrityHmacSHA256()
/*     */       throws XMLSignatureException
/*     */     {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String engineGetURI()
/*     */     {
/* 460 */       return "http://www.w3.org/2001/04/xmldsig-more#hmac-sha256";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class IntegrityHmacSHA384
/*     */     extends IntegrityHmac
/*     */   {
/*     */     public IntegrityHmacSHA384()
/*     */       throws XMLSignatureException
/*     */     {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String engineGetURI()
/*     */     {
/* 487 */       return "http://www.w3.org/2001/04/xmldsig-more#hmac-sha384";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class IntegrityHmacSHA512
/*     */     extends IntegrityHmac
/*     */   {
/*     */     public IntegrityHmacSHA512()
/*     */       throws XMLSignatureException
/*     */     {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String engineGetURI()
/*     */     {
/* 514 */       return "http://www.w3.org/2001/04/xmldsig-more#hmac-sha512";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class IntegrityHmacRIPEMD160
/*     */     extends IntegrityHmac
/*     */   {
/*     */     public IntegrityHmacRIPEMD160()
/*     */       throws XMLSignatureException
/*     */     {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String engineGetURI()
/*     */     {
/* 541 */       return "http://www.w3.org/2001/04/xmldsig-more#hmac-ripemd160";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class IntegrityHmacMD5
/*     */     extends IntegrityHmac
/*     */   {
/*     */     public IntegrityHmacMD5()
/*     */       throws XMLSignatureException
/*     */     {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String engineGetURI()
/*     */     {
/* 568 */       return "http://www.w3.org/2001/04/xmldsig-more#hmac-md5";
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\algorithms\implementations\IntegrityHmac.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */