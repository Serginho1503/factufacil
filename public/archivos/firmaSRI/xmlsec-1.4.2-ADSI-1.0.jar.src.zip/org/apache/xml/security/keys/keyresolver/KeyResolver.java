/*     */ package org.apache.xml.security.keys.keyresolver;
/*     */ 
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.crypto.SecretKey;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.keys.storage.StorageResolver;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyResolver
/*     */ {
/*  45 */   static Log log = LogFactory.getLog(KeyResolver.class.getName());
/*     */   
/*     */ 
/*     */ 
/*  49 */   static boolean _alreadyInitialized = false;
/*     */   
/*     */ 
/*  52 */   static List _resolverVector = null;
/*     */   
/*     */ 
/*  55 */   protected KeyResolverSpi _resolverSpi = null;
/*     */   
/*     */ 
/*  58 */   protected StorageResolver _storage = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private KeyResolver(String className)
/*     */     throws ClassNotFoundException, IllegalAccessException, InstantiationException
/*     */   {
/*  71 */     this._resolverSpi = ((KeyResolverSpi)Class.forName(className).newInstance());
/*     */     
/*  73 */     this._resolverSpi.setGlobalResolver(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int length()
/*     */   {
/*  82 */     return _resolverVector.size();
/*     */   }
/*     */   
/*     */   public static void hit(Iterator hintI) {
/*  86 */     ResolverIterator hint = (ResolverIterator)hintI;
/*  87 */     int i = hint.i;
/*  88 */     if ((i != 1) && (hint.res == _resolverVector)) {
/*  89 */       List resolverVector = (List)((ArrayList)_resolverVector).clone();
/*  90 */       Object ob = resolverVector.remove(i - 1);
/*  91 */       resolverVector.add(0, ob);
/*  92 */       _resolverVector = resolverVector;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final X509Certificate getX509Certificate(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/* 113 */     List resolverVector = _resolverVector;
/* 114 */     for (int i = 0; i < resolverVector.size(); i++) {
/* 115 */       KeyResolver resolver = (KeyResolver)resolverVector.get(i);
/*     */       
/*     */ 
/* 118 */       if (resolver == null) {
/* 119 */         Object[] exArgs = { (element != null) && (element.getNodeType() == 1) ? element.getTagName() : "null" };
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */         throw new KeyResolverException("utils.resolver.noClass", exArgs);
/*     */       }
/* 127 */       if (log.isDebugEnabled()) {
/* 128 */         log.debug("check resolvability by class " + resolver.getClass());
/*     */       }
/* 130 */       X509Certificate cert = resolver.resolveX509Certificate(element, BaseURI, storage);
/* 131 */       if (cert != null) {
/* 132 */         return cert;
/*     */       }
/*     */     }
/*     */     
/* 136 */     Object[] exArgs = { (element != null) && (element.getNodeType() == 1) ? element.getTagName() : "null" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 141 */     throw new KeyResolverException("utils.resolver.noClass", exArgs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final PublicKey getPublicKey(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/* 157 */     List resolverVector = _resolverVector;
/* 158 */     for (int i = 0; i < resolverVector.size(); i++) {
/* 159 */       KeyResolver resolver = (KeyResolver)resolverVector.get(i);
/*     */       
/*     */ 
/* 162 */       if (resolver == null) {
/* 163 */         Object[] exArgs = { (element != null) && (element.getNodeType() == 1) ? element.getTagName() : "null" };
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 169 */         throw new KeyResolverException("utils.resolver.noClass", exArgs);
/*     */       }
/* 171 */       if (log.isDebugEnabled()) {
/* 172 */         log.debug("check resolvability by class " + resolver.getClass());
/*     */       }
/* 174 */       PublicKey cert = resolver.resolvePublicKey(element, BaseURI, storage);
/* 175 */       if (cert != null) {
/* 176 */         if ((i != 0) && (resolverVector == _resolverVector))
/*     */         {
/* 178 */           resolverVector = (List)((ArrayList)_resolverVector).clone();
/* 179 */           Object ob = resolverVector.remove(i);
/* 180 */           resolverVector.add(0, ob);
/* 181 */           _resolverVector = resolverVector;
/*     */         }
/* 183 */         return cert;
/*     */       }
/*     */     }
/*     */     
/* 187 */     Object[] exArgs = { (element != null) && (element.getNodeType() == 1) ? element.getTagName() : "null" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 192 */     throw new KeyResolverException("utils.resolver.noClass", exArgs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void init()
/*     */   {
/* 200 */     if (!_alreadyInitialized) {
/* 201 */       _resolverVector = new ArrayList(10);
/* 202 */       _alreadyInitialized = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void register(String className)
/*     */     throws ClassNotFoundException, IllegalAccessException, InstantiationException
/*     */   {
/* 219 */     _resolverVector.add(new KeyResolver(className));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void registerAtStart(String className)
/*     */   {
/* 231 */     _resolverVector.add(0, className);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PublicKey resolvePublicKey(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/* 247 */     return this._resolverSpi.engineLookupAndResolvePublicKey(element, BaseURI, storage);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Certificate resolveX509Certificate(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/* 263 */     return this._resolverSpi.engineLookupResolveX509Certificate(element, BaseURI, storage);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SecretKey resolveSecretKey(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/* 277 */     return this._resolverSpi.engineLookupAndResolveSecretKey(element, BaseURI, storage);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProperty(String key, String value)
/*     */   {
/* 288 */     this._resolverSpi.engineSetProperty(key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getProperty(String key)
/*     */   {
/* 298 */     return this._resolverSpi.engineGetProperty(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean understandsProperty(String propertyToTest)
/*     */   {
/* 309 */     return this._resolverSpi.understandsProperty(propertyToTest);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 319 */   public String resolverClassName() { return this._resolverSpi.getClass().getName(); }
/*     */   
/*     */   static class ResolverIterator implements Iterator {
/*     */     List res;
/*     */     Iterator it;
/*     */     int i;
/*     */     
/*     */     public ResolverIterator(List list) {
/* 327 */       this.res = list;
/* 328 */       this.it = this.res.iterator();
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 332 */       return this.it.hasNext();
/*     */     }
/*     */     
/*     */     public Object next() {
/* 336 */       this.i += 1;
/* 337 */       KeyResolver resolver = (KeyResolver)this.it.next();
/* 338 */       if (resolver == null) {
/* 339 */         throw new RuntimeException("utils.resolver.noClass");
/*     */       }
/*     */       
/* 342 */       return resolver._resolverSpi;
/*     */     }
/*     */     
/*     */ 
/*     */     public void remove() {}
/*     */   }
/*     */   
/*     */ 
/*     */   public static Iterator iterator()
/*     */   {
/* 352 */     return new ResolverIterator(_resolverVector);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\keyresolver\KeyResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */