/*    */ package org.apache.xml.security.c14n.implementations;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Canonicalizer20010315WithComments
/*    */   extends Canonicalizer20010315
/*    */ {
/*    */   public Canonicalizer20010315WithComments()
/*    */   {
/* 33 */     super(true);
/*    */   }
/*    */   
/*    */   public final String engineGetURI()
/*    */   {
/* 38 */     return "http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments";
/*    */   }
/*    */   
/*    */   public final boolean engineGetIncludeComments()
/*    */   {
/* 43 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\c14n\implementations\Canonicalizer20010315WithComments.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */