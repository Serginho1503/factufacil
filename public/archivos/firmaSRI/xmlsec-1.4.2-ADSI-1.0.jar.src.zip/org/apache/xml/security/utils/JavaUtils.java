/*     */ package org.apache.xml.security.utils;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaUtils
/*     */ {
/*  33 */   static Log log = LogFactory.getLog(JavaUtils.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] getBytesFromFile(String fileName)
/*     */     throws FileNotFoundException, IOException
/*     */   {
/*  52 */     byte[] refBytes = null;
/*     */     
/*  54 */     FileInputStream fisRef = new FileInputStream(fileName);
/*     */     try {
/*  56 */       UnsyncByteArrayOutputStream baos = new UnsyncByteArrayOutputStream();
/*  57 */       byte[] buf = new byte['Ѐ'];
/*     */       
/*     */       int len;
/*  60 */       while ((len = fisRef.read(buf)) > 0) {
/*  61 */         baos.write(buf, 0, len);
/*     */       }
/*     */       
/*  64 */       refBytes = baos.toByteArray();
/*     */     } finally {
/*  66 */       fisRef.close();
/*     */     }
/*     */     
/*  69 */     return refBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void writeBytesToFilename(String filename, byte[] bytes)
/*     */   {
/*  80 */     FileOutputStream fos = null;
/*     */     try {
/*  82 */       if ((filename != null) && (bytes != null)) {
/*  83 */         File f = new File(filename);
/*     */         
/*  85 */         fos = new FileOutputStream(f);
/*     */         
/*  87 */         fos.write(bytes);
/*  88 */         fos.close();
/*     */       } else {
/*  90 */         log.debug("writeBytesToFilename got null byte[] pointed");
/*     */       }
/*     */     } catch (IOException ex) {
/*  93 */       if (fos != null) {
/*     */         try {
/*  95 */           fos.close();
/*     */         }
/*     */         catch (IOException ioe) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] getBytesFromStream(InputStream inputStream)
/*     */     throws IOException
/*     */   {
/* 114 */     byte[] refBytes = null;
/*     */     
/* 116 */     UnsyncByteArrayOutputStream baos = new UnsyncByteArrayOutputStream();
/* 117 */     byte[] buf = new byte['Ѐ'];
/*     */     
/*     */     int len;
/* 120 */     while ((len = inputStream.read(buf)) > 0) {
/* 121 */       baos.write(buf, 0, len);
/*     */     }
/*     */     
/* 124 */     refBytes = baos.toByteArray();
/* 125 */     return refBytes;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\utils\JavaUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */