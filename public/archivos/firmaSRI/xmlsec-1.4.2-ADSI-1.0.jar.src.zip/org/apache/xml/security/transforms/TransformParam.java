package org.apache.xml.security.transforms;

public abstract interface TransformParam {}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\transforms\TransformParam.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */