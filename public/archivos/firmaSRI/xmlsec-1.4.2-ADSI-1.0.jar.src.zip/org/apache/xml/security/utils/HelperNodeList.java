/*    */ package org.apache.xml.security.utils;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Node;
/*    */ import org.w3c.dom.NodeList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HelperNodeList
/*    */   implements NodeList
/*    */ {
/* 34 */   ArrayList nodes = new ArrayList(20);
/* 35 */   boolean _allNodesMustHaveSameParent = false;
/*    */   
/*    */ 
/*    */ 
/*    */   public HelperNodeList()
/*    */   {
/* 41 */     this(false);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public HelperNodeList(boolean allNodesMustHaveSameParent)
/*    */   {
/* 49 */     this._allNodesMustHaveSameParent = allNodesMustHaveSameParent;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Node item(int index)
/*    */   {
/* 62 */     return (Node)this.nodes.get(index);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getLength()
/*    */   {
/* 71 */     return this.nodes.size();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void appendChild(Node node)
/*    */     throws IllegalArgumentException
/*    */   {
/* 81 */     if ((this._allNodesMustHaveSameParent) && (getLength() > 0) && 
/* 82 */       (item(0).getParentNode() != node.getParentNode())) {
/* 83 */       throw new IllegalArgumentException("Nodes have not the same Parent");
/*    */     }
/*    */     
/* 86 */     this.nodes.add(node);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Document getOwnerDocument()
/*    */   {
/* 93 */     if (getLength() == 0) {
/* 94 */       return null;
/*    */     }
/* 96 */     return XMLUtils.getOwnerDocument(item(0));
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\utils\HelperNodeList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */