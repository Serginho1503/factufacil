/*    */ package org.apache.xml.security.keys;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.security.PublicKey;
/*    */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*    */ import org.apache.xml.security.keys.content.KeyName;
/*    */ import org.apache.xml.security.keys.content.KeyValue;
/*    */ import org.apache.xml.security.keys.content.MgmtData;
/*    */ import org.apache.xml.security.keys.content.X509Data;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KeyUtils
/*    */ {
/*    */   public static void prinoutKeyInfo(KeyInfo ki, PrintStream os)
/*    */     throws XMLSecurityException
/*    */   {
/* 53 */     for (int i = 0; i < ki.lengthKeyName(); i++) {
/* 54 */       KeyName x = ki.itemKeyName(i);
/*    */       
/* 56 */       os.println("KeyName(" + i + ")=\"" + x.getKeyName() + "\"");
/*    */     }
/*    */     
/* 59 */     for (int i = 0; i < ki.lengthKeyValue(); i++) {
/* 60 */       KeyValue x = ki.itemKeyValue(i);
/* 61 */       PublicKey pk = x.getPublicKey();
/*    */       
/* 63 */       os.println("KeyValue Nr. " + i);
/* 64 */       os.println(pk);
/*    */     }
/*    */     
/* 67 */     for (int i = 0; i < ki.lengthMgmtData(); i++) {
/* 68 */       MgmtData x = ki.itemMgmtData(i);
/*    */       
/* 70 */       os.println("MgmtData(" + i + ")=\"" + x.getMgmtData() + "\"");
/*    */     }
/*    */     
/* 73 */     for (int i = 0; i < ki.lengthX509Data(); i++) {
/* 74 */       X509Data x = ki.itemX509Data(i);
/*    */       
/* 76 */       os.println("X509Data(" + i + ")=\"" + (x.containsCertificate() ? "Certificate " : "") + (x.containsIssuerSerial() ? "IssuerSerial " : "") + "\"");
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\KeyUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */