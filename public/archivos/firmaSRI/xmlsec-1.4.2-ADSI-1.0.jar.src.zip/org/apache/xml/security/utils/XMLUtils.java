/*     */ package org.apache.xml.security.utils;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import org.apache.xml.security.c14n.Canonicalizer;
/*     */ import org.apache.xml.security.c14n.InvalidCanonicalizerException;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLUtils
/*     */ {
/*  50 */   private static boolean ignoreLineBreaks = false;
/*     */   
/*     */   static {
/*  53 */     try { ignoreLineBreaks = Boolean.getBoolean("org.apache.xml.security.ignoreLineBreaks");
/*     */     }
/*     */     catch (Exception e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Element getNextElement(Node el)
/*     */   {
/*  69 */     while ((el != null) && (el.getNodeType() != 1)) {
/*  70 */       el = el.getNextSibling();
/*     */     }
/*  72 */     return (Element)el;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void getSet(Node rootNode, Set result, Node exclude, boolean com)
/*     */   {
/*  83 */     if ((exclude != null) && (isDescendantOrSelf(exclude, rootNode))) {
/*  84 */       return;
/*     */     }
/*  86 */     getSetRec(rootNode, result, exclude, com);
/*     */   }
/*     */   
/*     */   static final void getSetRec(Node rootNode, Set result, Node exclude, boolean com)
/*     */   {
/*  91 */     if (rootNode == exclude) {
/*  92 */       return;
/*     */     }
/*  94 */     switch (rootNode.getNodeType()) {
/*     */     case 1: 
/*  96 */       result.add(rootNode);
/*  97 */       Element el = (Element)rootNode;
/*  98 */       if (el.hasAttributes()) {
/*  99 */         NamedNodeMap nl = ((Element)rootNode).getAttributes();
/* 100 */         for (int i = 0; i < nl.getLength(); i++) {
/* 101 */           result.add(nl.item(i));
/*     */         }
/*     */       }
/*     */     
/*     */     case 9: 
/* 106 */       for (Node r = rootNode.getFirstChild(); r != null; r = r.getNextSibling()) {
/* 107 */         if (r.getNodeType() == 3) {
/* 108 */           result.add(r);
/* 109 */           while ((r != null) && (r.getNodeType() == 3)) {
/* 110 */             r = r.getNextSibling();
/*     */           }
/* 112 */           if (r == null)
/* 113 */             return;
/*     */         }
/* 115 */         getSetRec(r, result, exclude, com);
/*     */       }
/* 117 */       return;
/*     */     case 8: 
/* 119 */       if (com) {
/* 120 */         result.add(rootNode);
/*     */       }
/* 122 */       return;
/*     */     case 10: 
/* 124 */       return;
/*     */     }
/* 126 */     result.add(rootNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void outputDOM(Node contextNode, OutputStream os)
/*     */   {
/* 139 */     outputDOM(contextNode, os, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void outputDOM(Node contextNode, OutputStream os, boolean addPreamble)
/*     */   {
/*     */     try
/*     */     {
/* 155 */       if (addPreamble) {
/* 156 */         os.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n".getBytes());
/*     */       }
/*     */       
/* 159 */       os.write(Canonicalizer.getInstance("http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments").canonicalizeSubtree(contextNode));
/*     */ 
/*     */     }
/*     */     catch (IOException ex) {}catch (InvalidCanonicalizerException ex)
/*     */     {
/*     */ 
/* 165 */       ex.printStackTrace();
/*     */     } catch (CanonicalizationException ex) {
/* 167 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void outputDOMc14nWithComments(Node contextNode, OutputStream os)
/*     */   {
/*     */     try
/*     */     {
/* 188 */       os.write(Canonicalizer.getInstance("http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments").canonicalizeSubtree(contextNode));
/*     */     }
/*     */     catch (IOException ex) {}catch (InvalidCanonicalizerException ex) {}catch (CanonicalizationException ex) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getFullTextChildrenFromElement(Element element)
/*     */   {
/* 213 */     StringBuffer sb = new StringBuffer();
/* 214 */     NodeList children = element.getChildNodes();
/* 215 */     int iMax = children.getLength();
/*     */     
/* 217 */     for (int i = 0; i < iMax; i++) {
/* 218 */       Node curr = children.item(i);
/*     */       
/* 220 */       if (curr.getNodeType() == 3) {
/* 221 */         sb.append(((Text)curr).getData());
/*     */       }
/*     */     }
/*     */     
/* 225 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/* 229 */   static String dsPrefix = null;
/* 230 */   static Map namePrefixes = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Element createElementInSignatureSpace(Document doc, String elementName)
/*     */   {
/* 241 */     if (doc == null) {
/* 242 */       throw new RuntimeException("Document is null");
/*     */     }
/*     */     
/* 245 */     if ((dsPrefix == null) || (dsPrefix.length() == 0)) {
/* 246 */       return doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", elementName);
/*     */     }
/* 248 */     String namePrefix = (String)namePrefixes.get(elementName);
/* 249 */     if (namePrefix == null) {
/* 250 */       StringBuffer tag = new StringBuffer(dsPrefix);
/* 251 */       tag.append(':');
/* 252 */       tag.append(elementName);
/* 253 */       namePrefix = tag.toString();
/* 254 */       namePrefixes.put(elementName, namePrefix);
/*     */     }
/* 256 */     return doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", namePrefix);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean elementIsInSignatureSpace(Element element, String localName)
/*     */   {
/* 269 */     return ElementProxy.checker.isNamespaceElement(element, localName, "http://www.w3.org/2000/09/xmldsig#");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean elementIsInEncryptionSpace(Element element, String localName)
/*     */   {
/* 282 */     return ElementProxy.checker.isNamespaceElement(element, localName, "http://www.w3.org/2001/04/xmlenc#");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Document getOwnerDocument(Node node)
/*     */   {
/* 296 */     if (node.getNodeType() == 9) {
/* 297 */       return (Document)node;
/*     */     }
/*     */     try {
/* 300 */       return node.getOwnerDocument();
/*     */     } catch (NullPointerException npe) {
/* 302 */       throw new NullPointerException(I18n.translate("endorsed.jdk1.4.0") + " Original message was \"" + npe.getMessage() + "\"");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Document getOwnerDocument(Set xpathNodeSet)
/*     */   {
/* 319 */     NullPointerException npe = null;
/* 320 */     Iterator iterator = xpathNodeSet.iterator();
/* 321 */     while (iterator.hasNext()) {
/* 322 */       Node node = (Node)iterator.next();
/* 323 */       int nodeType = node.getNodeType();
/* 324 */       if (nodeType == 9) {
/* 325 */         return (Document)node;
/*     */       }
/*     */       try {
/* 328 */         if (nodeType == 2) {
/* 329 */           return ((Attr)node).getOwnerElement().getOwnerDocument();
/*     */         }
/* 331 */         return node.getOwnerDocument();
/*     */       } catch (NullPointerException e) {
/* 333 */         npe = e;
/*     */       }
/*     */     }
/*     */     
/* 337 */     throw new NullPointerException(I18n.translate("endorsed.jdk1.4.0") + " Original message was \"" + (npe == null ? "" : npe.getMessage()) + "\"");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void addReturnToElement(Element e)
/*     */   {
/* 350 */     if (!ignoreLineBreaks) {
/* 351 */       Document doc = e.getOwnerDocument();
/* 352 */       e.appendChild(doc.createTextNode("\n"));
/*     */     }
/*     */   }
/*     */   
/*     */   public static void addReturnToElement(Document doc, HelperNodeList nl) {
/* 357 */     if (!ignoreLineBreaks) {
/* 358 */       nl.appendChild(doc.createTextNode("\n"));
/*     */     }
/*     */   }
/*     */   
/*     */   public static void addReturnBeforeChild(Element e, Node child) {
/* 363 */     if (!ignoreLineBreaks) {
/* 364 */       Document doc = e.getOwnerDocument();
/* 365 */       e.insertBefore(doc.createTextNode("\n"), child);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Set convertNodelistToSet(NodeList xpathNodeSet)
/*     */   {
/* 377 */     if (xpathNodeSet == null) {
/* 378 */       return new HashSet();
/*     */     }
/*     */     
/* 381 */     int length = xpathNodeSet.getLength();
/* 382 */     Set set = new HashSet(length);
/*     */     
/* 384 */     for (int i = 0; i < length; i++) {
/* 385 */       set.add(xpathNodeSet.item(i));
/*     */     }
/*     */     
/* 388 */     return set;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void circumventBug2650(Document doc)
/*     */   {
/* 405 */     Element documentElement = doc.getDocumentElement();
/*     */     
/*     */ 
/* 408 */     Attr xmlnsAttr = documentElement.getAttributeNodeNS("http://www.w3.org/2000/xmlns/", "xmlns");
/*     */     
/*     */ 
/* 411 */     if (xmlnsAttr == null) {
/* 412 */       documentElement.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns", "");
/*     */     }
/*     */     
/* 415 */     circumventBug2650internal(doc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void circumventBug2650internal(Node node)
/*     */   {
/* 425 */     Node parent = null;
/* 426 */     Node sibling = null;
/* 427 */     String namespaceNs = "http://www.w3.org/2000/xmlns/";
/*     */     for (;;) {
/* 429 */       switch (node.getNodeType()) {
/*     */       case 1: 
/* 431 */         Element element = (Element)node;
/* 432 */         if (element.hasChildNodes())
/*     */         {
/* 434 */           if (element.hasAttributes()) {
/* 435 */             NamedNodeMap attributes = element.getAttributes();
/* 436 */             int attributesLength = attributes.getLength();
/*     */             
/* 438 */             for (Node child = element.getFirstChild(); child != null; 
/* 439 */                 child = child.getNextSibling())
/*     */             {
/* 441 */               if (child.getNodeType() == 1)
/*     */               {
/*     */ 
/* 444 */                 Element childElement = (Element)child;
/*     */                 
/* 446 */                 for (int i = 0; i < attributesLength; i++) {
/* 447 */                   Attr currentAttr = (Attr)attributes.item(i);
/* 448 */                   if ("http://www.w3.org/2000/xmlns/" == currentAttr.getNamespaceURI())
/*     */                   {
/* 450 */                     if (!childElement.hasAttributeNS("http://www.w3.org/2000/xmlns/", currentAttr.getLocalName()))
/*     */                     {
/*     */ 
/*     */ 
/* 454 */                       childElement.setAttributeNS("http://www.w3.org/2000/xmlns/", currentAttr.getName(), currentAttr.getNodeValue());
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         break;
/*     */       case 5: case 9: 
/* 464 */         parent = node;
/* 465 */         sibling = node.getFirstChild();
/*     */       }
/*     */       
/* 468 */       while ((sibling == null) && (parent != null)) {
/* 469 */         sibling = parent.getNextSibling();
/* 470 */         parent = parent.getParentNode();
/*     */       }
/* 472 */       if (sibling == null) {
/* 473 */         return;
/*     */       }
/*     */       
/* 476 */       node = sibling;
/* 477 */       sibling = node.getNextSibling();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Element selectDsNode(Node sibling, String nodeName, int number)
/*     */   {
/* 488 */     while (sibling != null) {
/* 489 */       if (ElementProxy.checker.isNamespaceElement(sibling, nodeName, "http://www.w3.org/2000/09/xmldsig#")) {
/* 490 */         if (number == 0) {
/* 491 */           return (Element)sibling;
/*     */         }
/* 493 */         number--;
/*     */       }
/* 495 */       sibling = sibling.getNextSibling();
/*     */     }
/* 497 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Element selectXencNode(Node sibling, String nodeName, int number)
/*     */   {
/* 508 */     while (sibling != null) {
/* 509 */       if (ElementProxy.checker.isNamespaceElement(sibling, nodeName, "http://www.w3.org/2001/04/xmlenc#")) {
/* 510 */         if (number == 0) {
/* 511 */           return (Element)sibling;
/*     */         }
/* 513 */         number--;
/*     */       }
/* 515 */       sibling = sibling.getNextSibling();
/*     */     }
/* 517 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Text selectDsNodeText(Node sibling, String nodeName, int number)
/*     */   {
/* 528 */     Node n = selectDsNode(sibling, nodeName, number);
/* 529 */     if (n == null) {
/* 530 */       return null;
/*     */     }
/* 532 */     n = n.getFirstChild();
/* 533 */     while ((n != null) && (n.getNodeType() != 3)) {
/* 534 */       n = n.getNextSibling();
/*     */     }
/* 536 */     return (Text)n;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Text selectNodeText(Node sibling, String uri, String nodeName, int number)
/*     */   {
/* 547 */     Node n = selectNode(sibling, uri, nodeName, number);
/* 548 */     if (n == null) {
/* 549 */       return null;
/*     */     }
/* 551 */     n = n.getFirstChild();
/* 552 */     while ((n != null) && (n.getNodeType() != 3)) {
/* 553 */       n = n.getNextSibling();
/*     */     }
/* 555 */     return (Text)n;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Element selectNode(Node sibling, String uri, String nodeName, int number)
/*     */   {
/* 566 */     while (sibling != null) {
/* 567 */       if (ElementProxy.checker.isNamespaceElement(sibling, nodeName, uri)) {
/* 568 */         if (number == 0) {
/* 569 */           return (Element)sibling;
/*     */         }
/* 571 */         number--;
/*     */       }
/* 573 */       sibling = sibling.getNextSibling();
/*     */     }
/* 575 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Element[] selectDsNodes(Node sibling, String nodeName)
/*     */   {
/* 584 */     return selectNodes(sibling, "http://www.w3.org/2000/09/xmldsig#", nodeName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Element[] selectNodes(Node sibling, String uri, String nodeName)
/*     */   {
/* 593 */     int size = 20;
/* 594 */     Element[] a = new Element[size];
/* 595 */     int curr = 0;
/*     */     
/* 597 */     while (sibling != null) {
/* 598 */       if (ElementProxy.checker.isNamespaceElement(sibling, nodeName, uri)) {
/* 599 */         a[(curr++)] = ((Element)sibling);
/* 600 */         if (size <= curr) {
/* 601 */           int cursize = size << 2;
/* 602 */           Element[] cp = new Element[cursize];
/* 603 */           System.arraycopy(a, 0, cp, 0, size);
/* 604 */           a = cp;
/* 605 */           size = cursize;
/*     */         }
/*     */       }
/* 608 */       sibling = sibling.getNextSibling();
/*     */     }
/* 610 */     Element[] af = new Element[curr];
/* 611 */     System.arraycopy(a, 0, af, 0, curr);
/* 612 */     return af;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Set excludeNodeFromSet(Node signatureElement, Set inputSet)
/*     */   {
/* 621 */     Set resultSet = new HashSet();
/* 622 */     Iterator iterator = inputSet.iterator();
/*     */     
/* 624 */     while (iterator.hasNext()) {
/* 625 */       Node inputNode = (Node)iterator.next();
/*     */       
/* 627 */       if (!isDescendantOrSelf(signatureElement, inputNode))
/*     */       {
/* 629 */         resultSet.add(inputNode);
/*     */       }
/*     */     }
/* 632 */     return resultSet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isDescendantOrSelf(Node ctx, Node descendantOrSelf)
/*     */   {
/* 645 */     if (ctx == descendantOrSelf) {
/* 646 */       return true;
/*     */     }
/*     */     
/* 649 */     Node parent = descendantOrSelf;
/*     */     for (;;)
/*     */     {
/* 652 */       if (parent == null) {
/* 653 */         return false;
/*     */       }
/*     */       
/* 656 */       if (parent == ctx) {
/* 657 */         return true;
/*     */       }
/*     */       
/* 660 */       if (parent.getNodeType() == 2) {
/* 661 */         parent = ((Attr)parent).getOwnerElement();
/*     */       } else {
/* 663 */         parent = parent.getParentNode();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean ignoreLineBreaks() {
/* 669 */     return ignoreLineBreaks;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\utils\XMLUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */