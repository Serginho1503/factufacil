/*     */ package org.apache.xml.security.c14n.implementations;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import org.apache.xml.security.c14n.helper.C14nHelper;
/*     */ import org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import org.apache.xml.security.transforms.params.InclusiveNamespaces;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Canonicalizer20010315Excl
/*     */   extends CanonicalizerBase
/*     */ {
/*  61 */   TreeSet _inclusiveNSSet = new TreeSet();
/*     */   static final String XMLNS_URI = "http://www.w3.org/2000/xmlns/";
/*  63 */   final SortedSet result = new TreeSet(COMPARE);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Canonicalizer20010315Excl(boolean includeComments)
/*     */   {
/*  70 */     super(includeComments);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalizeSubTree(Node rootNode)
/*     */     throws CanonicalizationException
/*     */   {
/*  82 */     return engineCanonicalizeSubTree(rootNode, "", null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalizeSubTree(Node rootNode, String inclusiveNamespaces)
/*     */     throws CanonicalizationException
/*     */   {
/*  94 */     return engineCanonicalizeSubTree(rootNode, inclusiveNamespaces, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalizeSubTree(Node rootNode, String inclusiveNamespaces, Node excl)
/*     */     throws CanonicalizationException
/*     */   {
/* 106 */     this._inclusiveNSSet = ((TreeSet)InclusiveNamespaces.prefixStr2Set(inclusiveNamespaces));
/*     */     
/* 108 */     return super.engineCanonicalizeSubTree(rootNode, excl);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalize(XMLSignatureInput rootNode, String inclusiveNamespaces)
/*     */     throws CanonicalizationException
/*     */   {
/* 119 */     this._inclusiveNSSet = ((TreeSet)InclusiveNamespaces.prefixStr2Set(inclusiveNamespaces));
/*     */     
/* 121 */     return super.engineCanonicalize(rootNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Iterator handleAttributesSubtree(Element E, NameSpaceSymbTable ns)
/*     */     throws CanonicalizationException
/*     */   {
/* 135 */     SortedSet result = this.result;
/* 136 */     result.clear();
/* 137 */     NamedNodeMap attrs = null;
/*     */     
/* 139 */     int attrsLength = 0;
/* 140 */     if (E.hasAttributes()) {
/* 141 */       attrs = E.getAttributes();
/* 142 */       attrsLength = attrs.getLength();
/*     */     }
/*     */     
/* 145 */     SortedSet visiblyUtilized = (SortedSet)this._inclusiveNSSet.clone();
/*     */     
/* 147 */     for (int i = 0; i < attrsLength; i++) {
/* 148 */       Attr N = (Attr)attrs.item(i);
/*     */       
/* 150 */       if ("http://www.w3.org/2000/xmlns/" != N.getNamespaceURI())
/*     */       {
/*     */ 
/* 153 */         String prefix = N.getPrefix();
/* 154 */         if ((prefix != null) && (!prefix.equals("xml")) && (!prefix.equals("xmlns"))) {
/* 155 */           visiblyUtilized.add(prefix);
/*     */         }
/*     */         
/* 158 */         result.add(N);
/*     */       }
/*     */       else {
/* 161 */         String NName = N.getLocalName();
/* 162 */         String NNodeValue = N.getNodeValue();
/*     */         
/* 164 */         if (ns.addMapping(NName, NNodeValue, N))
/*     */         {
/* 166 */           if (C14nHelper.namespaceIsRelative(NNodeValue)) {
/* 167 */             Object[] exArgs = { E.getTagName(), NName, N.getNodeValue() };
/*     */             
/* 169 */             throw new CanonicalizationException("c14n.Canonicalizer.RelativeNamespace", exArgs);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     String prefix;
/* 175 */     if (E.getNamespaceURI() != null) {
/* 176 */       String prefix = E.getPrefix();
/* 177 */       if ((prefix == null) || (prefix.length() == 0)) {
/* 178 */         prefix = "xmlns";
/*     */       }
/*     */     }
/*     */     else {
/* 182 */       prefix = "xmlns";
/*     */     }
/* 184 */     visiblyUtilized.add(prefix);
/*     */     
/*     */ 
/* 187 */     Iterator it = visiblyUtilized.iterator();
/* 188 */     while (it.hasNext()) {
/* 189 */       String s = (String)it.next();
/* 190 */       Attr key = ns.getMapping(s);
/* 191 */       if (key != null)
/*     */       {
/*     */ 
/* 194 */         result.add(key);
/*     */       }
/*     */     }
/* 197 */     return result.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalizeXPathNodeSet(Set xpathNodeSet, String inclusiveNamespaces)
/*     */     throws CanonicalizationException
/*     */   {
/* 211 */     this._inclusiveNSSet = ((TreeSet)InclusiveNamespaces.prefixStr2Set(inclusiveNamespaces));
/*     */     
/* 213 */     return super.engineCanonicalizeXPathNodeSet(xpathNodeSet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final Iterator handleAttributes(Element E, NameSpaceSymbTable ns)
/*     */     throws CanonicalizationException
/*     */   {
/* 225 */     SortedSet result = this.result;
/* 226 */     result.clear();
/* 227 */     NamedNodeMap attrs = null;
/* 228 */     int attrsLength = 0;
/* 229 */     if (E.hasAttributes()) {
/* 230 */       attrs = E.getAttributes();
/* 231 */       attrsLength = attrs.getLength();
/*     */     }
/*     */     
/* 234 */     Set visiblyUtilized = null;
/*     */     
/* 236 */     boolean isOutputElement = isVisibleDO(E, ns.getLevel()) == 1;
/* 237 */     if (isOutputElement) {
/* 238 */       visiblyUtilized = (Set)this._inclusiveNSSet.clone();
/*     */     }
/*     */     
/* 241 */     for (int i = 0; i < attrsLength; i++) {
/* 242 */       Attr N = (Attr)attrs.item(i);
/*     */       
/*     */ 
/* 245 */       if ("http://www.w3.org/2000/xmlns/" != N.getNamespaceURI()) {
/* 246 */         if (isVisible(N))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 251 */           if (isOutputElement)
/*     */           {
/* 253 */             String prefix = N.getPrefix();
/* 254 */             if ((prefix != null) && (!prefix.equals("xml")) && (!prefix.equals("xmlns"))) {
/* 255 */               visiblyUtilized.add(prefix);
/*     */             }
/*     */             
/* 258 */             result.add(N);
/*     */           }
/*     */         }
/*     */       } else {
/* 262 */         String NName = N.getLocalName();
/* 263 */         if ((isOutputElement) && (!isVisible(N)) && (NName != "xmlns")) {
/* 264 */           ns.removeMappingIfNotRender(NName);
/*     */         }
/*     */         else {
/* 267 */           String NNodeValue = N.getNodeValue();
/*     */           
/* 269 */           if ((!isOutputElement) && (isVisible(N)) && (this._inclusiveNSSet.contains(NName)) && (!ns.removeMappingIfRender(NName))) {
/* 270 */             Node n = ns.addMappingAndRender(NName, NNodeValue, N);
/* 271 */             if (n != null) {
/* 272 */               result.add(n);
/* 273 */               if (C14nHelper.namespaceIsRelative(N)) {
/* 274 */                 Object[] exArgs = { E.getTagName(), NName, N.getNodeValue() };
/* 275 */                 throw new CanonicalizationException("c14n.Canonicalizer.RelativeNamespace", exArgs);
/*     */               }
/*     */             }
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 283 */           if (ns.addMapping(NName, NNodeValue, N))
/*     */           {
/* 285 */             if (C14nHelper.namespaceIsRelative(NNodeValue)) {
/* 286 */               Object[] exArgs = { E.getTagName(), NName, N.getNodeValue() };
/*     */               
/* 288 */               throw new CanonicalizationException("c14n.Canonicalizer.RelativeNamespace", exArgs);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 294 */     if (isOutputElement)
/*     */     {
/* 296 */       Attr xmlns = E.getAttributeNodeNS("http://www.w3.org/2000/xmlns/", "xmlns");
/* 297 */       if ((xmlns != null) && (!isVisible(xmlns)))
/*     */       {
/*     */ 
/* 300 */         ns.addMapping("xmlns", "", nullNode);
/*     */       }
/*     */       
/* 303 */       if (E.getNamespaceURI() != null) {
/* 304 */         String prefix = E.getPrefix();
/* 305 */         if ((prefix == null) || (prefix.length() == 0)) {
/* 306 */           visiblyUtilized.add("xmlns");
/*     */         } else {
/* 308 */           visiblyUtilized.add(prefix);
/*     */         }
/*     */       } else {
/* 311 */         visiblyUtilized.add("xmlns");
/*     */       }
/*     */       
/*     */ 
/* 315 */       Iterator it = visiblyUtilized.iterator();
/* 316 */       while (it.hasNext()) {
/* 317 */         String s = (String)it.next();
/* 318 */         Attr key = ns.getMapping(s);
/* 319 */         if (key != null)
/*     */         {
/*     */ 
/* 322 */           result.add(key);
/*     */         }
/*     */       }
/*     */     }
/* 326 */     return result.iterator();
/*     */   }
/*     */   
/* 329 */   void circumventBugIfNeeded(XMLSignatureInput input) throws CanonicalizationException, ParserConfigurationException, IOException, SAXException { if ((!input.isNeedsToBeExpanded()) || (this._inclusiveNSSet.isEmpty()))
/* 330 */       return;
/* 331 */     Document doc = null;
/* 332 */     if (input.getSubNode() != null) {
/* 333 */       doc = XMLUtils.getOwnerDocument(input.getSubNode());
/*     */     } else {
/* 335 */       doc = XMLUtils.getOwnerDocument(input.getNodeSet());
/*     */     }
/*     */     
/* 338 */     XMLUtils.circumventBug2650(doc);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\c14n\implementations\Canonicalizer20010315Excl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */