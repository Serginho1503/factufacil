/*     */ package org.apache.xml.security.keys.keyresolver;
/*     */ 
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.crypto.SecretKey;
/*     */ import org.apache.xml.security.keys.storage.StorageResolver;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class KeyResolverSpi
/*     */ {
/*     */   public boolean engineCanResolve(Element element, String BaseURI, StorageResolver storage)
/*     */   {
/*  53 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PublicKey engineResolvePublicKey(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/*  69 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PublicKey engineLookupAndResolvePublicKey(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/*  85 */     KeyResolverSpi tmp = cloneIfNeeded();
/*  86 */     if (!tmp.engineCanResolve(element, BaseURI, storage))
/*  87 */       return null;
/*  88 */     return tmp.engineResolvePublicKey(element, BaseURI, storage);
/*     */   }
/*     */   
/*     */   private KeyResolverSpi cloneIfNeeded() throws KeyResolverException {
/*  92 */     KeyResolverSpi tmp = this;
/*  93 */     if (this.globalResolver) {
/*     */       try {
/*  95 */         tmp = (KeyResolverSpi)getClass().newInstance();
/*     */       } catch (InstantiationException e) {
/*  97 */         throw new KeyResolverException("", e);
/*     */       } catch (IllegalAccessException e) {
/*  99 */         throw new KeyResolverException("", e);
/*     */       }
/*     */     }
/* 102 */     return tmp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Certificate engineResolveX509Certificate(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/* 118 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Certificate engineLookupResolveX509Certificate(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/* 134 */     KeyResolverSpi tmp = cloneIfNeeded();
/* 135 */     if (!tmp.engineCanResolve(element, BaseURI, storage))
/* 136 */       return null;
/* 137 */     return tmp.engineResolveX509Certificate(element, BaseURI, storage);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SecretKey engineResolveSecretKey(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/* 153 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SecretKey engineLookupAndResolveSecretKey(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/* 169 */     KeyResolverSpi tmp = cloneIfNeeded();
/* 170 */     if (!tmp.engineCanResolve(element, BaseURI, storage))
/* 171 */       return null;
/* 172 */     return tmp.engineResolveSecretKey(element, BaseURI, storage);
/*     */   }
/*     */   
/*     */ 
/* 176 */   protected Map _properties = null;
/*     */   
/* 178 */   protected boolean globalResolver = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void engineSetProperty(String key, String value)
/*     */   {
/* 187 */     if (this._properties == null)
/* 188 */       this._properties = new HashMap();
/* 189 */     this._properties.put(key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String engineGetProperty(String key)
/*     */   {
/* 199 */     if (this._properties == null) {
/* 200 */       return null;
/*     */     }
/* 202 */     return (String)this._properties.get(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean understandsProperty(String propertyToTest)
/*     */   {
/* 212 */     if (this._properties == null) {
/* 213 */       return false;
/*     */     }
/* 215 */     return this._properties.get(propertyToTest) != null;
/*     */   }
/*     */   
/* 218 */   public void setGlobalResolver(boolean globalResolver) { this.globalResolver = globalResolver; }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\keyresolver\KeyResolverSpi.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */