/*     */ package org.apache.xml.security.transforms;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import org.apache.xml.security.c14n.InvalidCanonicalizerException;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.signature.XMLSignatureException;
/*     */ import org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Transforms
/*     */   extends SignatureElementProxy
/*     */ {
/*  51 */   static Log log = LogFactory.getLog(Transforms.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String TRANSFORM_C14N_OMIT_COMMENTS = "http://www.w3.org/TR/2001/REC-xml-c14n-20010315";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_C14N_WITH_COMMENTS = "http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_C14N11_OMIT_COMMENTS = "http://www.w3.org/2006/12/xml-c14n11";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_C14N11_WITH_COMMENTS = "http://www.w3.org/2006/12/xml-c14n11#WithComments";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_C14N_EXCL_OMIT_COMMENTS = "http://www.w3.org/2001/10/xml-exc-c14n#";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_C14N_EXCL_WITH_COMMENTS = "http://www.w3.org/2001/10/xml-exc-c14n#WithComments";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_XSLT = "http://www.w3.org/TR/1999/REC-xslt-19991116";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_BASE64_DECODE = "http://www.w3.org/2000/09/xmldsig#base64";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_XPATH = "http://www.w3.org/TR/1999/REC-xpath-19991116";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_ENVELOPED_SIGNATURE = "http://www.w3.org/2000/09/xmldsig#enveloped-signature";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_XPOINTER = "http://www.w3.org/TR/2001/WD-xptr-20010108";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_XPATH2FILTER04 = "http://www.w3.org/2002/04/xmldsig-filter2";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_XPATH2FILTER = "http://www.w3.org/2002/06/xmldsig-filter2";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_XPATHFILTERCHGP = "http://www.nue.et-inf.uni-siegen.de/~geuer-pollmann/#xpathFilter";
/*     */   
/*     */ 
/*     */   Element[] transforms;
/*     */   
/*     */ 
/*     */ 
/*     */   protected Transforms() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public Transforms(Document doc)
/*     */   {
/* 107 */     super(doc);
/* 108 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Transforms(Element element, String BaseURI)
/*     */     throws DOMException, XMLSignatureException, InvalidTransformException, TransformationException, XMLSecurityException
/*     */   {
/* 128 */     super(element, BaseURI);
/*     */     
/* 130 */     int numberOfTransformElems = getLength();
/*     */     
/* 132 */     if (numberOfTransformElems == 0)
/*     */     {
/*     */ 
/* 135 */       Object[] exArgs = { "Transform", "Transforms" };
/*     */       
/*     */ 
/* 138 */       throw new TransformationException("xml.WrongContent", exArgs);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addTransform(String transformURI)
/*     */     throws TransformationException
/*     */   {
/*     */     try
/*     */     {
/* 154 */       if (log.isDebugEnabled()) {
/* 155 */         log.debug("Transforms.addTransform(" + transformURI + ")");
/*     */       }
/* 157 */       Transform transform = Transform.getInstance(this._doc, transformURI);
/*     */       
/*     */ 
/* 160 */       addTransform(transform);
/*     */     } catch (InvalidTransformException ex) {
/* 162 */       throw new TransformationException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addTransform(String transformURI, Element contextElement)
/*     */     throws TransformationException
/*     */   {
/*     */     try
/*     */     {
/* 180 */       if (log.isDebugEnabled()) {
/* 181 */         log.debug("Transforms.addTransform(" + transformURI + ")");
/*     */       }
/* 183 */       Transform transform = Transform.getInstance(this._doc, transformURI, contextElement);
/*     */       
/*     */ 
/* 186 */       addTransform(transform);
/*     */     } catch (InvalidTransformException ex) {
/* 188 */       throw new TransformationException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addTransform(String transformURI, NodeList contextNodes)
/*     */     throws TransformationException
/*     */   {
/*     */     try
/*     */     {
/* 206 */       Transform transform = Transform.getInstance(this._doc, transformURI, contextNodes);
/*     */       
/* 208 */       addTransform(transform);
/*     */     } catch (InvalidTransformException ex) {
/* 210 */       throw new TransformationException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addTransform(Transform transform)
/*     */   {
/* 220 */     if (log.isDebugEnabled()) {
/* 221 */       log.debug("Transforms.addTransform(" + transform.getURI() + ")");
/*     */     }
/* 223 */     Element transformElement = transform.getElement();
/*     */     
/* 225 */     this._constructionElement.appendChild(transformElement);
/* 226 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput performTransforms(XMLSignatureInput xmlSignatureInput)
/*     */     throws TransformationException
/*     */   {
/* 239 */     return performTransforms(xmlSignatureInput, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput performTransforms(XMLSignatureInput xmlSignatureInput, OutputStream os)
/*     */     throws TransformationException
/*     */   {
/*     */     try
/*     */     {
/* 256 */       int last = getLength() - 1;
/* 257 */       for (int i = 0; i < last; i++) {
/* 258 */         Transform t = item(i);
/* 259 */         if (log.isDebugEnabled()) {
/* 260 */           log.debug("Perform the (" + i + ")th " + t.getURI() + " transform");
/*     */         }
/*     */         
/* 263 */         xmlSignatureInput = t.performTransform(xmlSignatureInput); }
/*     */       Transform t;
/* 265 */       if (last >= 0)
/* 266 */         t = item(last);
/* 267 */       return t.performTransform(xmlSignatureInput, os);
/*     */ 
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 272 */       throw new TransformationException("empty", ex);
/*     */     } catch (CanonicalizationException ex) {
/* 274 */       throw new TransformationException("empty", ex);
/*     */     } catch (InvalidCanonicalizerException ex) {
/* 276 */       throw new TransformationException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLength()
/*     */   {
/* 287 */     if (this.transforms == null) {
/* 288 */       this.transforms = XMLUtils.selectDsNodes(this._constructionElement.getFirstChild(), "Transform");
/*     */     }
/*     */     
/* 291 */     return this.transforms.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Transform item(int i)
/*     */     throws TransformationException
/*     */   {
/*     */     try
/*     */     {
/* 305 */       if (this.transforms == null) {
/* 306 */         this.transforms = XMLUtils.selectDsNodes(this._constructionElement.getFirstChild(), "Transform");
/*     */       }
/*     */       
/* 309 */       return new Transform(this.transforms[i], this._baseURI);
/*     */     } catch (XMLSecurityException ex) {
/* 311 */       throw new TransformationException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 317 */     return "Transforms";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\transforms\Transforms.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */