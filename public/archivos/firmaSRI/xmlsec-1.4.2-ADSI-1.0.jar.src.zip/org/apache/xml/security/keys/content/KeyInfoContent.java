package org.apache.xml.security.keys.content;

public abstract interface KeyInfoContent {}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\content\KeyInfoContent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */