/*     */ package org.apache.xml.security.algorithms;
/*     */ 
/*     */ import java.security.Key;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.spec.AlgorithmParameterSpec;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.algorithms.implementations.IntegrityHmac;
/*     */ import org.apache.xml.security.exceptions.AlgorithmAlreadyRegisteredException;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.signature.XMLSignatureException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignatureAlgorithm
/*     */   extends Algorithm
/*     */ {
/*  43 */   static Log log = LogFactory.getLog(SignatureAlgorithm.class.getName());
/*     */   
/*     */ 
/*     */ 
/*  47 */   static boolean _alreadyInitialized = false;
/*     */   
/*     */ 
/*  50 */   static HashMap _algorithmHash = null;
/*     */   
/*  52 */   static ThreadLocal instancesSigning = new ThreadLocal() {
/*     */     protected Object initialValue() {
/*  54 */       return new HashMap();
/*     */     }
/*     */   };
/*     */   
/*  58 */   static ThreadLocal instancesVerify = new ThreadLocal() {
/*     */     protected Object initialValue() {
/*  60 */       return new HashMap();
/*     */     }
/*     */   };
/*     */   
/*  64 */   static ThreadLocal keysSigning = new ThreadLocal() {
/*     */     protected Object initialValue() {
/*  66 */       return new HashMap();
/*     */     }
/*     */   };
/*  69 */   static ThreadLocal keysVerify = new ThreadLocal() {
/*     */     protected Object initialValue() {
/*  71 */       return new HashMap();
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*  77 */   protected SignatureAlgorithmSpi _signatureAlgorithm = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String algorithmURI;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignatureAlgorithm(Document doc, String algorithmURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  90 */     super(doc, algorithmURI);
/*  91 */     this.algorithmURI = algorithmURI;
/*     */   }
/*     */   
/*     */   private void initializeAlgorithm(boolean isForSigning) throws XMLSignatureException
/*     */   {
/*  96 */     if (this._signatureAlgorithm != null) {
/*  97 */       return;
/*     */     }
/*  99 */     this._signatureAlgorithm = (isForSigning ? getInstanceForSigning(this.algorithmURI) : getInstanceForVerify(this.algorithmURI));
/* 100 */     this._signatureAlgorithm.engineGetContextFromElement(this._constructionElement);
/*     */   }
/*     */   
/*     */   private static SignatureAlgorithmSpi getInstanceForSigning(String algorithmURI) throws XMLSignatureException {
/* 104 */     SignatureAlgorithmSpi result = (SignatureAlgorithmSpi)((Map)instancesSigning.get()).get(algorithmURI);
/* 105 */     if (result != null) {
/* 106 */       result.reset();
/* 107 */       return result;
/*     */     }
/* 109 */     result = buildSigner(algorithmURI, result);
/* 110 */     ((Map)instancesSigning.get()).put(algorithmURI, result);
/* 111 */     return result;
/*     */   }
/*     */   
/* 114 */   public static void clearInstanceForSigning() { ((Map)instancesSigning.get()).clear(); }
/*     */   
/*     */   private static SignatureAlgorithmSpi getInstanceForVerify(String algorithmURI) throws XMLSignatureException {
/* 117 */     SignatureAlgorithmSpi result = (SignatureAlgorithmSpi)((Map)instancesVerify.get()).get(algorithmURI);
/* 118 */     if (result != null) {
/* 119 */       result.reset();
/* 120 */       return result;
/*     */     }
/* 122 */     result = buildSigner(algorithmURI, result);
/* 123 */     ((Map)instancesVerify.get()).put(algorithmURI, result);
/* 124 */     return result;
/*     */   }
/*     */   
/*     */   private static SignatureAlgorithmSpi buildSigner(String algorithmURI, SignatureAlgorithmSpi result) throws XMLSignatureException {
/*     */     try {
/* 129 */       Class implementingClass = getImplementingClass(algorithmURI);
/*     */       
/* 131 */       if (log.isDebugEnabled()) {
/* 132 */         log.debug("Create URI \"" + algorithmURI + "\" class \"" + implementingClass + "\"");
/*     */       }
/* 134 */       return (SignatureAlgorithmSpi)implementingClass.newInstance();
/*     */     }
/*     */     catch (IllegalAccessException ex) {
/* 137 */       Object[] exArgs = { algorithmURI, ex.getMessage() };
/*     */       
/* 139 */       throw new XMLSignatureException("algorithms.NoSuchAlgorithm", exArgs, ex);
/*     */     }
/*     */     catch (InstantiationException ex) {
/* 142 */       Object[] exArgs = { algorithmURI, ex.getMessage() };
/*     */       
/* 144 */       throw new XMLSignatureException("algorithms.NoSuchAlgorithm", exArgs, ex);
/*     */     }
/*     */     catch (NullPointerException ex) {
/* 147 */       Object[] exArgs = { algorithmURI, ex.getMessage() };
/*     */       
/* 149 */       throw new XMLSignatureException("algorithms.NoSuchAlgorithm", exArgs, ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignatureAlgorithm(Document doc, String algorithmURI, int HMACOutputLength)
/*     */     throws XMLSecurityException
/*     */   {
/* 166 */     this(doc, algorithmURI);
/* 167 */     this.algorithmURI = algorithmURI;
/* 168 */     initializeAlgorithm(true);
/* 169 */     this._signatureAlgorithm.engineSetHMACOutputLength(HMACOutputLength);
/* 170 */     ((IntegrityHmac)this._signatureAlgorithm).engineAddContextToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignatureAlgorithm(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 184 */     super(element, BaseURI);
/* 185 */     this.algorithmURI = getURI();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] sign()
/*     */     throws XMLSignatureException
/*     */   {
/* 196 */     return this._signatureAlgorithm.engineSign();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getJCEAlgorithmString()
/*     */   {
/*     */     try
/*     */     {
/* 207 */       return getInstanceForVerify(this.algorithmURI).engineGetJCEAlgorithmString();
/*     */     }
/*     */     catch (XMLSignatureException e) {}
/* 210 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getJCEProviderName()
/*     */   {
/*     */     try
/*     */     {
/* 221 */       return getInstanceForVerify(this.algorithmURI).engineGetJCEProviderName();
/*     */     } catch (XMLSignatureException e) {}
/* 223 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void update(byte[] input)
/*     */     throws XMLSignatureException
/*     */   {
/* 235 */     this._signatureAlgorithm.engineUpdate(input);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void update(byte input)
/*     */     throws XMLSignatureException
/*     */   {
/* 246 */     this._signatureAlgorithm.engineUpdate(input);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void update(byte[] buf, int offset, int len)
/*     */     throws XMLSignatureException
/*     */   {
/* 260 */     this._signatureAlgorithm.engineUpdate(buf, offset, len);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initSign(Key signingKey)
/*     */     throws XMLSignatureException
/*     */   {
/* 271 */     initializeAlgorithm(true);
/* 272 */     Map map = (Map)keysSigning.get();
/* 273 */     if (map.get(this.algorithmURI) == signingKey) {
/* 274 */       return;
/*     */     }
/* 276 */     map.put(this.algorithmURI, signingKey);
/* 277 */     this._signatureAlgorithm.engineInitSign(signingKey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initSign(Key signingKey, SecureRandom secureRandom)
/*     */     throws XMLSignatureException
/*     */   {
/* 290 */     initializeAlgorithm(true);
/* 291 */     this._signatureAlgorithm.engineInitSign(signingKey, secureRandom);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initSign(Key signingKey, AlgorithmParameterSpec algorithmParameterSpec)
/*     */     throws XMLSignatureException
/*     */   {
/* 305 */     initializeAlgorithm(true);
/* 306 */     this._signatureAlgorithm.engineInitSign(signingKey, algorithmParameterSpec);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParameter(AlgorithmParameterSpec params)
/*     */     throws XMLSignatureException
/*     */   {
/* 319 */     this._signatureAlgorithm.engineSetParameter(params);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initVerify(Key verificationKey)
/*     */     throws XMLSignatureException
/*     */   {
/* 330 */     initializeAlgorithm(false);
/* 331 */     Map map = (Map)keysVerify.get();
/* 332 */     if (map.get(this.algorithmURI) == verificationKey) {
/* 333 */       return;
/*     */     }
/* 335 */     map.put(this.algorithmURI, verificationKey);
/* 336 */     this._signatureAlgorithm.engineInitVerify(verificationKey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean verify(byte[] signature)
/*     */     throws XMLSignatureException
/*     */   {
/* 349 */     return this._signatureAlgorithm.engineVerify(signature);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getURI()
/*     */   {
/* 358 */     return this._constructionElement.getAttributeNS(null, "Algorithm");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void providerInit()
/*     */   {
/* 368 */     if (log == null) {
/* 369 */       log = LogFactory.getLog(SignatureAlgorithm.class.getName());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 374 */     log.debug("Init() called");
/*     */     
/* 376 */     if (!_alreadyInitialized) {
/* 377 */       _algorithmHash = new HashMap(10);
/* 378 */       _alreadyInitialized = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void register(String algorithmURI, String implementingClass)
/*     */     throws AlgorithmAlreadyRegisteredException, XMLSignatureException
/*     */   {
/* 394 */     if (log.isDebugEnabled()) {
/* 395 */       log.debug("Try to register " + algorithmURI + " " + implementingClass);
/*     */     }
/*     */     
/* 398 */     Class registeredClassClass = getImplementingClass(algorithmURI);
/*     */     
/* 400 */     if (registeredClassClass != null) {
/* 401 */       String registeredClass = registeredClassClass.getName();
/*     */       
/* 403 */       if ((registeredClass != null) && (registeredClass.length() != 0)) {
/* 404 */         Object[] exArgs = { algorithmURI, registeredClass };
/*     */         
/* 406 */         throw new AlgorithmAlreadyRegisteredException("algorithm.alreadyRegistered", exArgs);
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 411 */       _algorithmHash.put(algorithmURI, Class.forName(implementingClass));
/*     */     } catch (ClassNotFoundException ex) {
/* 413 */       Object[] exArgs = { algorithmURI, ex.getMessage() };
/*     */       
/* 415 */       throw new XMLSignatureException("algorithms.NoSuchAlgorithm", exArgs, ex);
/*     */     }
/*     */     catch (NullPointerException ex) {
/* 418 */       Object[] exArgs = { algorithmURI, ex.getMessage() };
/*     */       
/* 420 */       throw new XMLSignatureException("algorithms.NoSuchAlgorithm", exArgs, ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Class getImplementingClass(String URI)
/*     */   {
/* 435 */     if (_algorithmHash == null) {
/* 436 */       return null;
/*     */     }
/*     */     
/* 439 */     return (Class)_algorithmHash.get(URI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBaseNamespace()
/*     */   {
/* 448 */     return "http://www.w3.org/2000/09/xmldsig#";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBaseLocalName()
/*     */   {
/* 457 */     return "SignatureMethod";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\algorithms\SignatureAlgorithm.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */