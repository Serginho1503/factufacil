/*     */ package org.apache.xml.security.transforms.params;
/*     */ 
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.transforms.TransformParam;
/*     */ import org.apache.xml.security.utils.ElementProxy;
/*     */ import org.apache.xml.security.utils.HelperNodeList;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XPath2FilterContainer
/*     */   extends ElementProxy
/*     */   implements TransformParam
/*     */ {
/*     */   private static final String _ATT_FILTER = "Filter";
/*     */   private static final String _ATT_FILTER_VALUE_INTERSECT = "intersect";
/*     */   private static final String _ATT_FILTER_VALUE_SUBTRACT = "subtract";
/*     */   private static final String _ATT_FILTER_VALUE_UNION = "union";
/*     */   public static final String INTERSECT = "intersect";
/*     */   public static final String SUBTRACT = "subtract";
/*     */   public static final String UNION = "union";
/*     */   public static final String _TAG_XPATH2 = "XPath";
/*     */   public static final String XPathFilter2NS = "http://www.w3.org/2002/06/xmldsig-filter2";
/*     */   
/*     */   private XPath2FilterContainer() {}
/*     */   
/*     */   private XPath2FilterContainer(Document doc, String xpath2filter, String filterType)
/*     */   {
/*  93 */     super(doc);
/*     */     
/*  95 */     this._constructionElement.setAttributeNS(null, "Filter", filterType);
/*     */     
/*  97 */     this._constructionElement.appendChild(doc.createTextNode(xpath2filter));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private XPath2FilterContainer(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 110 */     super(element, BaseURI);
/*     */     
/* 112 */     String filterStr = this._constructionElement.getAttributeNS(null, "Filter");
/*     */     
/*     */ 
/* 115 */     if ((!filterStr.equals("intersect")) && (!filterStr.equals("subtract")) && (!filterStr.equals("union")))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 121 */       Object[] exArgs = { "Filter", filterStr, "intersect, subtract or union" };
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 128 */       throw new XMLSecurityException("attributeValueIllegal", exArgs);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XPath2FilterContainer newInstanceIntersect(Document doc, String xpath2filter)
/*     */   {
/* 142 */     return new XPath2FilterContainer(doc, xpath2filter, "intersect");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XPath2FilterContainer newInstanceSubtract(Document doc, String xpath2filter)
/*     */   {
/* 157 */     return new XPath2FilterContainer(doc, xpath2filter, "subtract");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XPath2FilterContainer newInstanceUnion(Document doc, String xpath2filter)
/*     */   {
/* 172 */     return new XPath2FilterContainer(doc, xpath2filter, "union");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static NodeList newInstances(Document doc, String[][] params)
/*     */   {
/* 186 */     HelperNodeList nl = new HelperNodeList();
/*     */     
/* 188 */     XMLUtils.addReturnToElement(doc, nl);
/*     */     
/* 190 */     for (int i = 0; i < params.length; i++) {
/* 191 */       String type = params[i][0];
/* 192 */       String xpath = params[i][1];
/*     */       
/* 194 */       if ((!type.equals("intersect")) && (!type.equals("subtract")) && (!type.equals("union")))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 200 */         throw new IllegalArgumentException("The type(" + i + ")=\"" + type + "\" is illegal");
/*     */       }
/*     */       
/*     */ 
/* 204 */       XPath2FilterContainer c = new XPath2FilterContainer(doc, xpath, type);
/*     */       
/* 206 */       nl.appendChild(c.getElement());
/* 207 */       XMLUtils.addReturnToElement(doc, nl);
/*     */     }
/*     */     
/* 210 */     return nl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XPath2FilterContainer newInstance(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 224 */     return new XPath2FilterContainer(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isIntersect()
/*     */   {
/* 234 */     return this._constructionElement.getAttributeNS(null, "Filter").equals("intersect");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSubtract()
/*     */   {
/* 246 */     return this._constructionElement.getAttributeNS(null, "Filter").equals("subtract");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isUnion()
/*     */   {
/* 258 */     return this._constructionElement.getAttributeNS(null, "Filter").equals("union");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getXPathFilterStr()
/*     */   {
/* 269 */     return getTextFromTextChild();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node getXPathFilterTextNode()
/*     */   {
/* 282 */     NodeList children = this._constructionElement.getChildNodes();
/* 283 */     int length = children.getLength();
/*     */     
/* 285 */     for (int i = 0; i < length; i++) {
/* 286 */       if (children.item(i).getNodeType() == 3) {
/* 287 */         return children.item(i);
/*     */       }
/*     */     }
/*     */     
/* 291 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getBaseLocalName()
/*     */   {
/* 300 */     return "XPath";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getBaseNamespace()
/*     */   {
/* 309 */     return "http://www.w3.org/2002/06/xmldsig-filter2";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\transforms\params\XPath2FilterContainer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */