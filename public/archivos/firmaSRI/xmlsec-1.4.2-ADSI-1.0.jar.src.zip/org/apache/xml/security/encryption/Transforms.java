package org.apache.xml.security.encryption;

public abstract interface Transforms
{
  public abstract org.apache.xml.security.transforms.Transforms getDSTransforms();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\encryption\Transforms.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */