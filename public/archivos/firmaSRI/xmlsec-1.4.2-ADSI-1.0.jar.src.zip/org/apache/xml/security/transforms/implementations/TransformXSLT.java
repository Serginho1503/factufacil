/*     */ package org.apache.xml.security.transforms.implementations;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerConfigurationException;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import org.apache.xml.security.transforms.Transform;
/*     */ import org.apache.xml.security.transforms.TransformSpi;
/*     */ import org.apache.xml.security.transforms.TransformationException;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransformXSLT
/*     */   extends TransformSpi
/*     */ {
/*     */   public static final String implementedTransformURI = "http://www.w3.org/TR/1999/REC-xslt-19991116";
/*     */   static final String XSLTSpecNS = "http://www.w3.org/1999/XSL/Transform";
/*     */   static final String defaultXSLTSpecNSprefix = "xslt";
/*     */   static final String XSLTSTYLESHEET = "stylesheet";
/*  62 */   private static Class xClass = null;
/*     */   
/*     */   static {
/*  65 */     try { xClass = Class.forName("javax.xml.XMLConstants");
/*     */     } catch (Exception e) {}
/*     */   }
/*     */   
/*  69 */   static Log log = LogFactory.getLog(TransformXSLT.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String engineGetURI()
/*     */   {
/*  79 */     return "http://www.w3.org/TR/1999/REC-xslt-19991116";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, Transform _transformObject)
/*     */     throws IOException, TransformationException
/*     */   {
/*  94 */     return enginePerformTransform(input, null, _transformObject);
/*     */   }
/*     */   
/*     */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, OutputStream baos, Transform _transformObject)
/*     */     throws IOException, TransformationException
/*     */   {
/* 100 */     if (xClass == null) {
/* 101 */       Object[] exArgs = { "SECURE_PROCESSING_FEATURE not supported" };
/* 102 */       throw new TransformationException("generic.EmptyMessage", exArgs);
/*     */     }
/*     */     try {
/* 105 */       Element transformElement = _transformObject.getElement();
/*     */       
/* 107 */       Element _xsltElement = XMLUtils.selectNode(transformElement.getFirstChild(), "http://www.w3.org/1999/XSL/Transform", "stylesheet", 0);
/*     */       
/*     */ 
/*     */ 
/* 111 */       if (_xsltElement == null) {
/* 112 */         Object[] exArgs = { "xslt:stylesheet", "Transform" };
/*     */         
/* 114 */         throw new TransformationException("xml.WrongContent", exArgs);
/*     */       }
/*     */       
/* 117 */       TransformerFactory tFactory = TransformerFactory.newInstance();
/* 118 */       Class c = tFactory.getClass();
/* 119 */       Method m = c.getMethod("setFeature", new Class[] { String.class, Boolean.TYPE });
/*     */       
/* 121 */       m.invoke(tFactory, new Object[] { "http://javax.xml.XMLConstants/feature/secure-processing", Boolean.TRUE });
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 129 */       Source xmlSource = new StreamSource(new ByteArrayInputStream(input.getBytes()));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 142 */       ByteArrayOutputStream os = new ByteArrayOutputStream();
/* 143 */       Transformer transformer = tFactory.newTransformer();
/* 144 */       DOMSource source = new DOMSource(_xsltElement);
/* 145 */       StreamResult result = new StreamResult(os);
/*     */       
/* 147 */       transformer.transform(source, result);
/*     */       
/* 149 */       Source stylesheet = new StreamSource(new ByteArrayInputStream(os.toByteArray()));
/*     */       
/*     */ 
/*     */ 
/* 153 */       Transformer transformer = tFactory.newTransformer(stylesheet);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/* 161 */         transformer.setOutputProperty("{http://xml.apache.org/xalan}line-separator", "\n");
/*     */       }
/*     */       catch (Exception e) {
/* 164 */         log.warn("Unable to set Xalan line-separator property: " + e.getMessage());
/*     */       }
/*     */       
/*     */ 
/* 168 */       if (baos == null) {
/* 169 */         ByteArrayOutputStream baos1 = new ByteArrayOutputStream();
/* 170 */         StreamResult outputTarget = new StreamResult(baos1);
/* 171 */         transformer.transform(xmlSource, outputTarget);
/* 172 */         return new XMLSignatureInput(baos1.toByteArray());
/*     */       }
/* 174 */       StreamResult outputTarget = new StreamResult(baos);
/*     */       
/* 176 */       transformer.transform(xmlSource, outputTarget);
/* 177 */       XMLSignatureInput output = new XMLSignatureInput((byte[])null);
/* 178 */       output.setOutputStream(baos);
/* 179 */       return output;
/*     */     } catch (XMLSecurityException ex) {
/* 181 */       Object[] exArgs = { ex.getMessage() };
/*     */       
/* 183 */       throw new TransformationException("generic.EmptyMessage", exArgs, ex);
/*     */     } catch (TransformerConfigurationException ex) {
/* 185 */       Object[] exArgs = { ex.getMessage() };
/*     */       
/* 187 */       throw new TransformationException("generic.EmptyMessage", exArgs, ex);
/*     */     } catch (TransformerException ex) {
/* 189 */       Object[] exArgs = { ex.getMessage() };
/*     */       
/* 191 */       throw new TransformationException("generic.EmptyMessage", exArgs, ex);
/*     */     } catch (NoSuchMethodException ex) {
/* 193 */       Object[] exArgs = { ex.getMessage() };
/*     */       
/* 195 */       throw new TransformationException("generic.EmptyMessage", exArgs, ex);
/*     */     } catch (IllegalAccessException ex) {
/* 197 */       Object[] exArgs = { ex.getMessage() };
/*     */       
/* 199 */       throw new TransformationException("generic.EmptyMessage", exArgs, ex);
/*     */     } catch (InvocationTargetException ex) {
/* 201 */       Object[] exArgs = { ex.getMessage() };
/*     */       
/* 203 */       throw new TransformationException("generic.EmptyMessage", exArgs, ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\transforms\implementations\TransformXSLT.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */