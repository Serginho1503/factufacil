/*     */ package org.apache.xml.security.signature;
/*     */ 
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.utils.IdResolver;
/*     */ import org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignatureProperties
/*     */   extends SignatureElementProxy
/*     */ {
/*     */   public SignatureProperties(Document doc)
/*     */   {
/*  46 */     super(doc);
/*     */     
/*  48 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignatureProperties(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  59 */     super(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLength()
/*     */   {
/*  69 */     Element[] propertyElems = XMLUtils.selectDsNodes(this._constructionElement, "SignatureProperty");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  74 */     return propertyElems.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignatureProperty item(int i)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/*  87 */       Element propertyElem = XMLUtils.selectDsNode(this._constructionElement, "SignatureProperty", i);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  92 */       if (propertyElem == null) {
/*  93 */         return null;
/*     */       }
/*  95 */       return new SignatureProperty(propertyElem, this._baseURI);
/*     */     } catch (XMLSecurityException ex) {
/*  97 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setId(String Id)
/*     */   {
/* 108 */     if (Id != null) {
/* 109 */       this._constructionElement.setAttributeNS(null, "Id", Id);
/* 110 */       IdResolver.registerElementById(this._constructionElement, Id);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getId()
/*     */   {
/* 120 */     return this._constructionElement.getAttributeNS(null, "Id");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSignatureProperty(SignatureProperty sp)
/*     */   {
/* 129 */     this._constructionElement.appendChild(sp.getElement());
/* 130 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 135 */     return "SignatureProperties";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\signature\SignatureProperties.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */