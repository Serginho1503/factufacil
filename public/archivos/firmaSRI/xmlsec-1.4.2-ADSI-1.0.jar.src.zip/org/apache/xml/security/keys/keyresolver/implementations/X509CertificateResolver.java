/*     */ package org.apache.xml.security.keys.keyresolver.implementations;
/*     */ 
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.crypto.SecretKey;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.keys.content.x509.XMLX509Certificate;
/*     */ import org.apache.xml.security.keys.keyresolver.KeyResolverException;
/*     */ import org.apache.xml.security.keys.keyresolver.KeyResolverSpi;
/*     */ import org.apache.xml.security.keys.storage.StorageResolver;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class X509CertificateResolver
/*     */   extends KeyResolverSpi
/*     */ {
/*  45 */   static Log log = LogFactory.getLog(X509CertificateResolver.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PublicKey engineLookupAndResolvePublicKey(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/*  63 */     X509Certificate cert = engineLookupResolveX509Certificate(element, BaseURI, storage);
/*     */     
/*     */ 
/*  66 */     if (cert != null) {
/*  67 */       return cert.getPublicKey();
/*     */     }
/*     */     
/*  70 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Certificate engineLookupResolveX509Certificate(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/*     */     try
/*     */     {
/*  87 */       Element[] els = XMLUtils.selectDsNodes(element.getFirstChild(), "X509Certificate");
/*     */       
/*  89 */       if ((els == null) || (els.length == 0)) {
/*  90 */         Element el = XMLUtils.selectDsNode(element.getFirstChild(), "X509Data", 0);
/*     */         
/*  92 */         if (el != null) {
/*  93 */           return engineLookupResolveX509Certificate(el, BaseURI, storage);
/*     */         }
/*  95 */         return null;
/*     */       }
/*     */       
/*     */ 
/*  99 */       for (int i = 0; i < els.length; i++) {
/* 100 */         XMLX509Certificate xmlCert = new XMLX509Certificate(els[i], BaseURI);
/* 101 */         X509Certificate cert = xmlCert.getX509Certificate();
/* 102 */         if (cert != null) {
/* 103 */           return cert;
/*     */         }
/*     */       }
/* 106 */       return null;
/*     */     } catch (XMLSecurityException ex) {
/* 108 */       log.debug("XMLSecurityException", ex);
/*     */       
/* 110 */       throw new KeyResolverException("generic.EmptyMessage", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SecretKey engineLookupAndResolveSecretKey(Element element, String BaseURI, StorageResolver storage)
/*     */   {
/* 125 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\keyresolver\implementations\X509CertificateResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */