/*     */ package org.apache.xml.security.transforms.implementations;
/*     */ 
/*     */ import org.apache.xml.dtm.DTMManager;
/*     */ import org.apache.xml.security.utils.I18n;
/*     */ import org.apache.xpath.CachedXPathAPI;
/*     */ import org.apache.xpath.XPathContext;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FuncHereContext
/*     */   extends XPathContext
/*     */ {
/*     */   private FuncHereContext() {}
/*     */   
/*     */   public FuncHereContext(Node owner)
/*     */   {
/*  80 */     super(owner);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FuncHereContext(Node owner, XPathContext xpathContext)
/*     */   {
/*  91 */     super(owner);
/*     */     try
/*     */     {
/*  94 */       this.m_dtmManager = xpathContext.getDTMManager();
/*     */     } catch (IllegalAccessError iae) {
/*  96 */       throw new IllegalAccessError(I18n.translate("endorsed.jdk1.4.0") + " Original message was \"" + iae.getMessage() + "\"");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FuncHereContext(Node owner, CachedXPathAPI previouslyUsed)
/*     */   {
/* 110 */     super(owner);
/*     */     try
/*     */     {
/* 113 */       this.m_dtmManager = previouslyUsed.getXPathContext().getDTMManager();
/*     */     } catch (IllegalAccessError iae) {
/* 115 */       throw new IllegalAccessError(I18n.translate("endorsed.jdk1.4.0") + " Original message was \"" + iae.getMessage() + "\"");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FuncHereContext(Node owner, DTMManager dtmManager)
/*     */   {
/* 129 */     super(owner);
/*     */     try
/*     */     {
/* 132 */       this.m_dtmManager = dtmManager;
/*     */     } catch (IllegalAccessError iae) {
/* 134 */       throw new IllegalAccessError(I18n.translate("endorsed.jdk1.4.0") + " Original message was \"" + iae.getMessage() + "\"");
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\transforms\implementations\FuncHereContext.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */