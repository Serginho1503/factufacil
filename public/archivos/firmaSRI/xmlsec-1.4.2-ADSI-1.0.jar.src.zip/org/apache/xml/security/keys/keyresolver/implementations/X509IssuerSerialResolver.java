/*     */ package org.apache.xml.security.keys.keyresolver.implementations;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.crypto.SecretKey;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.keys.content.X509Data;
/*     */ import org.apache.xml.security.keys.content.x509.XMLX509IssuerSerial;
/*     */ import org.apache.xml.security.keys.keyresolver.KeyResolverException;
/*     */ import org.apache.xml.security.keys.keyresolver.KeyResolverSpi;
/*     */ import org.apache.xml.security.keys.storage.StorageResolver;
/*     */ import org.apache.xml.security.signature.XMLSignatureException;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class X509IssuerSerialResolver
/*     */   extends KeyResolverSpi
/*     */ {
/*  43 */   static Log log = LogFactory.getLog(X509IssuerSerialResolver.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PublicKey engineLookupAndResolvePublicKey(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/*  53 */     X509Certificate cert = engineLookupResolveX509Certificate(element, BaseURI, storage);
/*     */     
/*     */ 
/*  56 */     if (cert != null) {
/*  57 */       return cert.getPublicKey();
/*     */     }
/*     */     
/*  60 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public X509Certificate engineLookupResolveX509Certificate(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/*  67 */     if (log.isDebugEnabled()) {
/*  68 */       log.debug("Can I resolve " + element.getTagName() + "?");
/*     */     }
/*  70 */     X509Data x509data = null;
/*     */     try {
/*  72 */       x509data = new X509Data(element, BaseURI);
/*     */     } catch (XMLSignatureException ex) {
/*  74 */       log.debug("I can't");
/*  75 */       return null;
/*     */     } catch (XMLSecurityException ex) {
/*  77 */       log.debug("I can't");
/*  78 */       return null;
/*     */     }
/*     */     
/*  81 */     if (x509data == null) {
/*  82 */       log.debug("I can't");
/*  83 */       return null;
/*     */     }
/*     */     
/*  86 */     if (!x509data.containsIssuerSerial()) {
/*  87 */       return null;
/*     */     }
/*     */     try {
/*  90 */       if (storage == null) {
/*  91 */         Object[] exArgs = { "X509IssuerSerial" };
/*  92 */         KeyResolverException ex = new KeyResolverException("KeyResolver.needStorageResolver", exArgs);
/*     */         
/*     */ 
/*     */ 
/*  96 */         log.info("", ex);
/*  97 */         throw ex;
/*     */       }
/*     */       
/* 100 */       int noOfISS = x509data.lengthIssuerSerial();
/*     */       
/* 102 */       while (storage.hasNext()) {
/* 103 */         X509Certificate cert = storage.next();
/* 104 */         XMLX509IssuerSerial certSerial = new XMLX509IssuerSerial(element.getOwnerDocument(), cert);
/*     */         
/* 106 */         if (log.isDebugEnabled()) {
/* 107 */           log.debug("Found Certificate Issuer: " + certSerial.getIssuerName());
/*     */           
/* 109 */           log.debug("Found Certificate Serial: " + certSerial.getSerialNumber().toString());
/*     */         }
/*     */         
/*     */ 
/* 113 */         for (int i = 0; i < noOfISS; i++) {
/* 114 */           XMLX509IssuerSerial xmliss = x509data.itemIssuerSerial(i);
/*     */           
/* 116 */           if (log.isDebugEnabled()) {
/* 117 */             log.debug("Found Element Issuer:     " + xmliss.getIssuerName());
/*     */             
/* 119 */             log.debug("Found Element Serial:     " + xmliss.getSerialNumber().toString());
/*     */           }
/*     */           
/*     */ 
/* 123 */           if (certSerial.equals(xmliss)) {
/* 124 */             log.debug("match !!! ");
/*     */             
/* 126 */             return cert;
/*     */           }
/* 128 */           log.debug("no match...");
/*     */         }
/*     */       }
/*     */       
/* 132 */       return null;
/*     */     } catch (XMLSecurityException ex) {
/* 134 */       log.debug("XMLSecurityException", ex);
/*     */       
/* 136 */       throw new KeyResolverException("generic.EmptyMessage", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public SecretKey engineLookupAndResolveSecretKey(Element element, String BaseURI, StorageResolver storage)
/*     */   {
/* 143 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\keyresolver\implementations\X509IssuerSerialResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */