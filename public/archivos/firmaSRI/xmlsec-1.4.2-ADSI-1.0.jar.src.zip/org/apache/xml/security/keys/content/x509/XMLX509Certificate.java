/*     */ package org.apache.xml.security.keys.content.x509;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.CertificateEncodingException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509Certificate;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLX509Certificate
/*     */   extends SignatureElementProxy
/*     */   implements XMLX509DataContent
/*     */ {
/*     */   public static final String JCA_CERT_ID = "X.509";
/*     */   
/*     */   public XMLX509Certificate(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  50 */     super(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509Certificate(Document doc, byte[] certificateBytes)
/*     */   {
/*  61 */     super(doc);
/*     */     
/*  63 */     addBase64Text(certificateBytes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509Certificate(Document doc, X509Certificate x509certificate)
/*     */     throws XMLSecurityException
/*     */   {
/*  76 */     super(doc);
/*     */     try
/*     */     {
/*  79 */       addBase64Text(x509certificate.getEncoded());
/*     */     } catch (CertificateEncodingException ex) {
/*  81 */       throw new XMLSecurityException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getCertificateBytes()
/*     */     throws XMLSecurityException
/*     */   {
/*  92 */     return getBytesFromTextChild();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Certificate getX509Certificate()
/*     */     throws XMLSecurityException
/*     */   {
/*     */     try
/*     */     {
/* 104 */       byte[] certbytes = getCertificateBytes();
/* 105 */       CertificateFactory certFact = CertificateFactory.getInstance("X.509");
/*     */       
/* 107 */       X509Certificate cert = (X509Certificate)certFact.generateCertificate(new ByteArrayInputStream(certbytes));
/*     */       
/*     */ 
/*     */ 
/* 111 */       if (cert != null) {
/* 112 */         return cert;
/*     */       }
/*     */       
/* 115 */       return null;
/*     */     } catch (CertificateException ex) {
/* 117 */       throw new XMLSecurityException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PublicKey getPublicKey()
/*     */     throws XMLSecurityException
/*     */   {
/* 129 */     X509Certificate cert = getX509Certificate();
/*     */     
/* 131 */     if (cert != null) {
/* 132 */       return cert.getPublicKey();
/*     */     }
/*     */     
/* 135 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 141 */     if (obj == null) {
/* 142 */       return false;
/*     */     }
/* 144 */     if (!getClass().getName().equals(obj.getClass().getName())) {
/* 145 */       return false;
/*     */     }
/* 147 */     XMLX509Certificate other = (XMLX509Certificate)obj;
/*     */     
/*     */     try
/*     */     {
/* 151 */       return MessageDigest.isEqual(other.getCertificateBytes(), getCertificateBytes());
/*     */     }
/*     */     catch (XMLSecurityException ex) {}
/* 154 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 161 */     return 72;
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 166 */     return "X509Certificate";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\content\x509\XMLX509Certificate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */