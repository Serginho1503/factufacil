/*    */ package org.apache.xml.security.utils;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.apache.xml.security.algorithms.MessageDigestAlgorithm;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DigesterOutputStream
/*    */   extends ByteArrayOutputStream
/*    */ {
/* 28 */   static final byte[] none = "error".getBytes();
/*    */   final MessageDigestAlgorithm mda;
/* 30 */   static Log log = LogFactory.getLog(DigesterOutputStream.class.getName());
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public DigesterOutputStream(MessageDigestAlgorithm mda)
/*    */   {
/* 38 */     this.mda = mda;
/*    */   }
/*    */   
/*    */   public byte[] toByteArray()
/*    */   {
/* 43 */     return none;
/*    */   }
/*    */   
/*    */   public void write(byte[] arg0)
/*    */   {
/* 48 */     write(arg0, 0, arg0.length);
/*    */   }
/*    */   
/*    */   public void write(int arg0)
/*    */   {
/* 53 */     this.mda.update((byte)arg0);
/*    */   }
/*    */   
/*    */   public void write(byte[] arg0, int arg1, int arg2)
/*    */   {
/* 58 */     if (log.isDebugEnabled()) {
/* 59 */       log.debug("Pre-digested input:");
/* 60 */       StringBuffer sb = new StringBuffer(arg2);
/* 61 */       for (int i = arg1; i < arg1 + arg2; i++) {
/* 62 */         sb.append((char)arg0[i]);
/*    */       }
/* 64 */       log.debug(sb.toString());
/*    */     }
/* 66 */     this.mda.update(arg0, arg1, arg2);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public byte[] getDigestValue()
/*    */   {
/* 73 */     return this.mda.digest();
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\utils\DigesterOutputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */