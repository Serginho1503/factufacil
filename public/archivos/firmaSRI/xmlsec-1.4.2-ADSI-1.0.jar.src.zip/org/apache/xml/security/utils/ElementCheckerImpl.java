/*    */ package org.apache.xml.security.utils;
/*    */ 
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ public abstract class ElementCheckerImpl implements ElementChecker
/*    */ {
/*    */   public boolean isNamespaceElement(org.w3c.dom.Node el, String type, String ns)
/*    */   {
/*  9 */     if ((el == null) || (ns != el.getNamespaceURI()) || (!el.getLocalName().equals(type)))
/*    */     {
/* 11 */       return false;
/*    */     }
/*    */     
/* 14 */     return true;
/*    */   }
/*    */   
/*    */   public static class InternedNsChecker extends ElementCheckerImpl
/*    */   {
/*    */     public void guaranteeThatElementInCorrectSpace(ElementProxy expected, Element actual) throws org.apache.xml.security.exceptions.XMLSecurityException
/*    */     {
/* 21 */       String localnameSHOULDBE = expected.getBaseLocalName();
/* 22 */       String namespaceSHOULDBE = expected.getBaseNamespace();
/*    */       
/* 24 */       String localnameIS = actual.getLocalName();
/* 25 */       String namespaceIS = actual.getNamespaceURI();
/* 26 */       if ((namespaceSHOULDBE != namespaceIS) || (!localnameSHOULDBE.equals(localnameIS)))
/*    */       {
/* 28 */         Object[] exArgs = { namespaceIS + ":" + localnameIS, namespaceSHOULDBE + ":" + localnameSHOULDBE };
/*    */         
/* 30 */         throw new org.apache.xml.security.exceptions.XMLSecurityException("xml.WrongElement", exArgs);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public static class FullChecker
/*    */     extends ElementCheckerImpl
/*    */   {
/*    */     public void guaranteeThatElementInCorrectSpace(ElementProxy expected, Element actual) throws org.apache.xml.security.exceptions.XMLSecurityException
/*    */     {
/* 40 */       String localnameSHOULDBE = expected.getBaseLocalName();
/* 41 */       String namespaceSHOULDBE = expected.getBaseNamespace();
/*    */       
/* 43 */       String localnameIS = actual.getLocalName();
/* 44 */       String namespaceIS = actual.getNamespaceURI();
/* 45 */       if ((!namespaceSHOULDBE.equals(namespaceIS)) || (!localnameSHOULDBE.equals(localnameIS)))
/*    */       {
/* 47 */         Object[] exArgs = { namespaceIS + ":" + localnameIS, namespaceSHOULDBE + ":" + localnameSHOULDBE };
/*    */         
/* 49 */         throw new org.apache.xml.security.exceptions.XMLSecurityException("xml.WrongElement", exArgs);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public static class EmptyChecker
/*    */     extends ElementCheckerImpl
/*    */   {
/*    */     public void guaranteeThatElementInCorrectSpace(ElementProxy expected, Element actual)
/*    */       throws org.apache.xml.security.exceptions.XMLSecurityException
/*    */     {}
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\utils\ElementCheckerImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */