/*     */ package org.apache.xml.security.utils.resolver.implementations;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import org.apache.xml.security.utils.IdResolver;
/*     */ import org.apache.xml.security.utils.resolver.ResourceResolverException;
/*     */ import org.apache.xml.security.utils.resolver.ResourceResolverSpi;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResolverFragment
/*     */   extends ResourceResolverSpi
/*     */ {
/*  41 */   static Log log = LogFactory.getLog(ResolverFragment.class.getName());
/*     */   
/*     */   public boolean engineIsThreadSafe()
/*     */   {
/*  45 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput engineResolve(Attr uri, String BaseURI)
/*     */     throws ResourceResolverException
/*     */   {
/*  61 */     String uriNodeValue = uri.getNodeValue();
/*  62 */     Document doc = uri.getOwnerElement().getOwnerDocument();
/*     */     
/*     */ 
/*  65 */     Node selectedElem = null;
/*  66 */     if (uriNodeValue.equals(""))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  73 */       log.debug("ResolverFragment with empty URI (means complete document)");
/*  74 */       selectedElem = doc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*  85 */       String id = uriNodeValue.substring(1);
/*     */       
/*     */ 
/*  88 */       selectedElem = IdResolver.getElementById(doc, id);
/*  89 */       if (selectedElem == null) {
/*  90 */         Object[] exArgs = { id };
/*  91 */         throw new ResourceResolverException("signature.Verification.MissingID", exArgs, uri, BaseURI);
/*     */       }
/*     */       
/*  94 */       if (log.isDebugEnabled()) {
/*  95 */         log.debug("Try to catch an Element with ID " + id + " and Element was " + selectedElem);
/*     */       }
/*     */     }
/*  98 */     XMLSignatureInput result = new XMLSignatureInput(selectedElem);
/*  99 */     result.setExcludeComments(true);
/*     */     
/*     */ 
/* 102 */     result.setMIMEType("text/xml");
/* 103 */     result.setSourceURI(BaseURI != null ? BaseURI.concat(uri.getNodeValue()) : uri.getNodeValue());
/*     */     
/* 105 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean engineCanResolve(Attr uri, String BaseURI)
/*     */   {
/* 117 */     if (uri == null) {
/* 118 */       log.debug("Quick fail for null uri");
/* 119 */       return false;
/*     */     }
/*     */     
/* 122 */     String uriNodeValue = uri.getNodeValue();
/*     */     
/* 124 */     if ((uriNodeValue.equals("")) || ((uriNodeValue.charAt(0) == '#') && ((uriNodeValue.charAt(1) != 'x') || (!uriNodeValue.startsWith("#xpointer(")))))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 130 */       if (log.isDebugEnabled())
/* 131 */         log.debug("State I can resolve reference: \"" + uriNodeValue + "\"");
/* 132 */       return true;
/*     */     }
/* 134 */     if (log.isDebugEnabled())
/* 135 */       log.debug("Do not seem to be able to resolve reference: \"" + uriNodeValue + "\"");
/* 136 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\utils\resolver\implementations\ResolverFragment.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */