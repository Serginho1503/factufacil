/*     */ package org.apache.xml.security.signature;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.algorithms.MessageDigestAlgorithm;
/*     */ import org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import org.apache.xml.security.c14n.InvalidCanonicalizerException;
/*     */ import org.apache.xml.security.exceptions.Base64DecodingException;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.transforms.InvalidTransformException;
/*     */ import org.apache.xml.security.transforms.Transform;
/*     */ import org.apache.xml.security.transforms.TransformationException;
/*     */ import org.apache.xml.security.transforms.Transforms;
/*     */ import org.apache.xml.security.transforms.params.InclusiveNamespaces;
/*     */ import org.apache.xml.security.utils.Base64;
/*     */ import org.apache.xml.security.utils.DigesterOutputStream;
/*     */ import org.apache.xml.security.utils.IdResolver;
/*     */ import org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import org.apache.xml.security.utils.UnsyncBufferedOutputStream;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.apache.xml.security.utils.resolver.ResourceResolver;
/*     */ import org.apache.xml.security.utils.resolver.ResourceResolverException;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Reference
/*     */   extends SignatureElementProxy
/*     */ {
/* 111 */   private static boolean useC14N11 = false;
/*     */   public static final boolean CacheSignedNodes = false;
/*     */   
/* 114 */   static { try { useC14N11 = Boolean.getBoolean("org.apache.xml.security.useC14N11");
/*     */     }
/*     */     catch (Exception e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 124 */   static Log log = LogFactory.getLog(Reference.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String OBJECT_URI = "http://www.w3.org/2000/09/xmldsig#Object";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String MANIFEST_URI = "http://www.w3.org/2000/09/xmldsig#Manifest";
/*     */   
/*     */ 
/* 135 */   Manifest _manifest = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   XMLSignatureInput _transformsOutput;
/*     */   
/*     */ 
/*     */ 
/*     */   private Transforms transforms;
/*     */   
/*     */ 
/*     */ 
/*     */   private Element digestMethodElem;
/*     */   
/*     */ 
/*     */ 
/*     */   private Element digestValueElement;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Reference(Document doc, String BaseURI, String ReferenceURI, Manifest manifest, Transforms transforms, String messageDigestAlgorithm)
/*     */     throws XMLSignatureException
/*     */   {
/* 160 */     super(doc);
/*     */     
/* 162 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */     
/* 164 */     this._baseURI = BaseURI;
/* 165 */     this._manifest = manifest;
/*     */     
/* 167 */     setURI(ReferenceURI);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 174 */     if (transforms != null) {
/* 175 */       this.transforms = transforms;
/* 176 */       this._constructionElement.appendChild(transforms.getElement());
/* 177 */       XMLUtils.addReturnToElement(this._constructionElement);
/*     */     }
/*     */     
/* 180 */     MessageDigestAlgorithm mda = MessageDigestAlgorithm.getInstance(this._doc, messageDigestAlgorithm);
/*     */     
/*     */ 
/*     */ 
/* 184 */     this.digestMethodElem = mda.getElement();
/* 185 */     this._constructionElement.appendChild(this.digestMethodElem);
/* 186 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */     
/*     */ 
/* 189 */     this.digestValueElement = XMLUtils.createElementInSignatureSpace(this._doc, "DigestValue");
/*     */     
/*     */ 
/*     */ 
/* 193 */     this._constructionElement.appendChild(this.digestValueElement);
/* 194 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Reference(Element element, String BaseURI, Manifest manifest)
/*     */     throws XMLSecurityException
/*     */   {
/* 210 */     super(element, BaseURI);
/* 211 */     this._baseURI = BaseURI;
/* 212 */     Element el = XMLUtils.getNextElement(element.getFirstChild());
/* 213 */     if (("Transforms".equals(el.getLocalName())) && ("http://www.w3.org/2000/09/xmldsig#".equals(el.getNamespaceURI())))
/*     */     {
/* 215 */       this.transforms = new Transforms(el, this._baseURI);
/* 216 */       el = XMLUtils.getNextElement(el.getNextSibling());
/*     */     }
/* 218 */     this.digestMethodElem = el;
/* 219 */     this.digestValueElement = XMLUtils.getNextElement(this.digestMethodElem.getNextSibling());
/* 220 */     this._manifest = manifest;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MessageDigestAlgorithm getMessageDigestAlgorithm()
/*     */     throws XMLSignatureException
/*     */   {
/* 234 */     if (this.digestMethodElem == null) {
/* 235 */       return null;
/*     */     }
/*     */     
/* 238 */     String uri = this.digestMethodElem.getAttributeNS(null, "Algorithm");
/*     */     
/*     */ 
/* 241 */     if (uri == null) {
/* 242 */       return null;
/*     */     }
/*     */     
/* 245 */     return MessageDigestAlgorithm.getInstance(this._doc, uri);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setURI(String URI)
/*     */   {
/* 255 */     if (URI != null) {
/* 256 */       this._constructionElement.setAttributeNS(null, "URI", URI);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getURI()
/*     */   {
/* 267 */     return this._constructionElement.getAttributeNS(null, "URI");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setId(String Id)
/*     */   {
/* 277 */     if (Id != null) {
/* 278 */       this._constructionElement.setAttributeNS(null, "Id", Id);
/* 279 */       IdResolver.registerElementById(this._constructionElement, Id);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getId()
/*     */   {
/* 289 */     return this._constructionElement.getAttributeNS(null, "Id");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setType(String Type)
/*     */   {
/* 299 */     if (Type != null) {
/* 300 */       this._constructionElement.setAttributeNS(null, "Type", Type);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getType()
/*     */   {
/* 311 */     return this._constructionElement.getAttributeNS(null, "Type");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean typeIsReferenceToObject()
/*     */   {
/* 325 */     if ("http://www.w3.org/2000/09/xmldsig#Object".equals(getType())) {
/* 326 */       return true;
/*     */     }
/*     */     
/* 329 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean typeIsReferenceToManifest()
/*     */   {
/* 342 */     if ("http://www.w3.org/2000/09/xmldsig#Manifest".equals(getType())) {
/* 343 */       return true;
/*     */     }
/*     */     
/* 346 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setDigestValueElement(byte[] digestValue)
/*     */   {
/* 356 */     Node n = this.digestValueElement.getFirstChild();
/* 357 */     while (n != null) {
/* 358 */       this.digestValueElement.removeChild(n);
/* 359 */       n = n.getNextSibling();
/*     */     }
/*     */     
/* 362 */     String base64codedValue = Base64.encode(digestValue);
/* 363 */     Text t = this._doc.createTextNode(base64codedValue);
/*     */     
/* 365 */     this.digestValueElement.appendChild(t);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void generateDigestValue()
/*     */     throws XMLSignatureException, ReferenceNotInitializedException
/*     */   {
/* 376 */     setDigestValueElement(calculateDigest(false));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected byte[] getDigestPrivateData()
/*     */     throws ReferenceNotInitializedException
/*     */   {
/*     */     try
/*     */     {
/* 386 */       ResourceResolver resolver = getResourceResolver();
/* 387 */       Attr URIAttr = this._constructionElement.getAttributeNodeNS(null, "URI");
/*     */       
/*     */ 
/*     */ 
/* 391 */       if (!resolver.understandsProperty("digest.algorithm")) {
/* 392 */         throw new ReferenceNotInitializedException("empty");
/*     */       }
/* 394 */       if (this.digestMethodElem == null) {
/* 395 */         throw new ReferenceNotInitializedException("empty");
/*     */       }
/* 397 */       String uri = this.digestMethodElem.getAttributeNS(null, "Algorithm");
/*     */       
/* 399 */       if (uri == null) {
/* 400 */         throw new ReferenceNotInitializedException("empty");
/*     */       }
/* 402 */       resolver.setProperty("digest.algorithm", uri);
/*     */       
/* 404 */       XMLSignatureInput input = resolver.resolve(URIAttr, this._baseURI);
/*     */       
/* 406 */       return input.getBytes();
/*     */     } catch (ReferenceNotInitializedException ex) {
/* 408 */       throw ex;
/*     */     } catch (ResourceResolverException ex) {
/* 410 */       throw new ReferenceNotInitializedException("empty", ex);
/*     */     } catch (CanonicalizationException ex) {
/* 412 */       throw new ReferenceNotInitializedException("empty", ex);
/*     */     } catch (IOException ex) {
/* 414 */       throw new ReferenceNotInitializedException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ResourceResolver getResourceResolver()
/*     */     throws ReferenceNotInitializedException
/*     */   {
/*     */     try
/*     */     {
/* 427 */       Attr URIAttr = this._constructionElement.getAttributeNodeNS(null, "URI");
/*     */       
/*     */ 
/* 430 */       ResourceResolver resolver = ResourceResolver.getInstance(URIAttr, this._baseURI, this._manifest._perManifestResolvers);
/*     */       
/*     */ 
/* 433 */       if (resolver == null) { String URI;
/*     */         String URI;
/* 435 */         if (URIAttr == null) {
/* 436 */           URI = null;
/*     */         } else {
/* 438 */           URI = URIAttr.getNodeValue();
/*     */         }
/* 440 */         Object[] exArgs = { URI };
/*     */         
/* 442 */         throw new ReferenceNotInitializedException("signature.Verification.Reference.NoInput", exArgs);
/*     */       }
/*     */       
/*     */ 
/* 446 */       resolver.addProperties(this._manifest._resolverProperties);
/*     */       
/* 448 */       return resolver;
/*     */     } catch (ResourceResolverException ex) {
/* 450 */       throw new ReferenceNotInitializedException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput getContentsBeforeTransformation()
/*     */     throws ReferenceNotInitializedException
/*     */   {
/*     */     try
/*     */     {
/* 462 */       ResourceResolver resolver = getResourceResolver();
/* 463 */       Attr URIAttr = this._constructionElement.getAttributeNodeNS(null, "URI");
/*     */       
/*     */ 
/* 466 */       return resolver.resolve(URIAttr, this._baseURI);
/*     */     }
/*     */     catch (ReferenceNotInitializedException ex)
/*     */     {
/* 470 */       throw ex;
/*     */     } catch (ResourceResolverException ex) {
/* 472 */       throw new ReferenceNotInitializedException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public XMLSignatureInput getTransformsInput()
/*     */     throws ReferenceNotInitializedException
/*     */   {
/* 486 */     XMLSignatureInput input = getContentsBeforeTransformation();
/*     */     XMLSignatureInput result;
/*     */     try {
/* 489 */       result = new XMLSignatureInput(input.getBytes());
/*     */     } catch (CanonicalizationException ex) {
/* 491 */       throw new ReferenceNotInitializedException("empty", ex);
/*     */     } catch (IOException ex) {
/* 493 */       throw new ReferenceNotInitializedException("empty", ex);
/*     */     }
/* 495 */     result.setSourceURI(input.getSourceURI());
/* 496 */     return result;
/*     */   }
/*     */   
/*     */   private XMLSignatureInput getContentsAfterTransformation(XMLSignatureInput input, OutputStream os)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 504 */       Transforms transforms = getTransforms();
/* 505 */       XMLSignatureInput output = null;
/*     */       
/* 507 */       if (transforms != null) {
/* 508 */         output = transforms.performTransforms(input, os);
/* 509 */         this._transformsOutput = output;
/*     */       }
/*     */       
/*     */ 
/* 513 */       return input;
/*     */ 
/*     */     }
/*     */     catch (ResourceResolverException ex)
/*     */     {
/* 518 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (CanonicalizationException ex) {
/* 520 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (InvalidCanonicalizerException ex) {
/* 522 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (TransformationException ex) {
/* 524 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (XMLSecurityException ex) {
/* 526 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput getContentsAfterTransformation()
/*     */     throws XMLSignatureException
/*     */   {
/* 538 */     XMLSignatureInput input = getContentsBeforeTransformation();
/*     */     
/* 540 */     return getContentsAfterTransformation(input, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput getNodesetBeforeFirstCanonicalization()
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 554 */       XMLSignatureInput input = getContentsBeforeTransformation();
/* 555 */       XMLSignatureInput output = input;
/* 556 */       Transforms transforms = getTransforms();
/*     */       
/* 558 */       if (transforms != null) {
/* 559 */         for (int i = 0; i < transforms.getLength(); i++) {
/* 560 */           Transform t = transforms.item(i);
/* 561 */           String URI = t.getURI();
/*     */           
/* 563 */           if ((URI.equals("http://www.w3.org/2001/10/xml-exc-c14n#")) || (URI.equals("http://www.w3.org/2001/10/xml-exc-c14n#WithComments")) || (URI.equals("http://www.w3.org/TR/2001/REC-xml-c14n-20010315")) || (URI.equals("http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments"))) {
/*     */             break;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 575 */           output = t.performTransform(output, null);
/*     */         }
/*     */         
/* 578 */         output.setSourceURI(input.getSourceURI());
/*     */       }
/* 580 */       return output;
/*     */     } catch (IOException ex) {
/* 582 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (ResourceResolverException ex) {
/* 584 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (CanonicalizationException ex) {
/* 586 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (InvalidCanonicalizerException ex) {
/* 588 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (TransformationException ex) {
/* 590 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (XMLSecurityException ex) {
/* 592 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHTMLRepresentation()
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 604 */       XMLSignatureInput nodes = getNodesetBeforeFirstCanonicalization();
/* 605 */       Set inclusiveNamespaces = new HashSet();
/*     */       
/*     */ 
/* 608 */       Transforms transforms = getTransforms();
/* 609 */       Transform c14nTransform = null;
/*     */       
/* 611 */       if (transforms != null) {
/* 612 */         for (int i = 0; i < transforms.getLength(); i++) {
/* 613 */           Transform t = transforms.item(i);
/* 614 */           String URI = t.getURI();
/*     */           
/* 616 */           if ((URI.equals("http://www.w3.org/2001/10/xml-exc-c14n#")) || (URI.equals("http://www.w3.org/2001/10/xml-exc-c14n#WithComments")))
/*     */           {
/*     */ 
/* 619 */             c14nTransform = t;
/*     */             
/* 621 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 626 */       if (c14nTransform != null)
/*     */       {
/* 628 */         if (c14nTransform.length("http://www.w3.org/2001/10/xml-exc-c14n#", "InclusiveNamespaces") == 1)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 634 */           InclusiveNamespaces in = new InclusiveNamespaces(XMLUtils.selectNode(c14nTransform.getElement().getFirstChild(), "http://www.w3.org/2001/10/xml-exc-c14n#", "InclusiveNamespaces", 0), getBaseURI());
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 640 */           inclusiveNamespaces = InclusiveNamespaces.prefixStr2Set(in.getInclusiveNamespaces());
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 646 */       return nodes.getHTMLRepresentation(inclusiveNamespaces);
/*     */     } catch (TransformationException ex) {
/* 648 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (InvalidTransformException ex) {
/* 650 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (XMLSecurityException ex) {
/* 652 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput getTransformsOutput()
/*     */   {
/* 661 */     return this._transformsOutput;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected XMLSignatureInput dereferenceURIandPerformTransforms(OutputStream os)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 677 */       XMLSignatureInput input = getContentsBeforeTransformation();
/* 678 */       XMLSignatureInput output = getContentsAfterTransformation(input, os);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 687 */       this._transformsOutput = output;
/*     */       
/*     */ 
/*     */ 
/* 691 */       return output;
/*     */     } catch (XMLSecurityException ex) {
/* 693 */       throw new ReferenceNotInitializedException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Transforms getTransforms()
/*     */     throws XMLSignatureException, InvalidTransformException, TransformationException, XMLSecurityException
/*     */   {
/* 710 */     return this.transforms;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getReferencedBytes()
/*     */     throws ReferenceNotInitializedException, XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 723 */       XMLSignatureInput output = dereferenceURIandPerformTransforms(null);
/*     */       
/* 725 */       return output.getBytes();
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 729 */       throw new ReferenceNotInitializedException("empty", ex);
/*     */     } catch (CanonicalizationException ex) {
/* 731 */       throw new ReferenceNotInitializedException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] calculateDigest(boolean validating)
/*     */     throws ReferenceNotInitializedException, XMLSignatureException
/*     */   {
/* 748 */     ResourceResolver rr = getResourceResolver();
/* 749 */     if (rr.canAccessData()) {
/*     */       try {
/* 751 */         MessageDigestAlgorithm mda = getMessageDigestAlgorithm();
/*     */         
/* 753 */         mda.reset();
/* 754 */         DigesterOutputStream diOs = new DigesterOutputStream(mda);
/* 755 */         OutputStream os = new UnsyncBufferedOutputStream(diOs);
/* 756 */         XMLSignatureInput output = dereferenceURIandPerformTransforms(os);
/*     */         
/*     */ 
/* 759 */         if ((useC14N11) && (!validating) && (!output.isOutputStreamSet()) && (!output.isOctetStream()))
/*     */         {
/* 761 */           if (this.transforms == null) {
/* 762 */             this.transforms = new Transforms(this._doc);
/* 763 */             this._constructionElement.insertBefore(this.transforms.getElement(), this.digestMethodElem);
/*     */           }
/* 765 */           this.transforms.addTransform("http://www.w3.org/2006/12/xml-c14n11");
/* 766 */           output.updateOutputStream(os, true);
/*     */         } else {
/* 768 */           output.updateOutputStream(os);
/*     */         }
/* 770 */         os.flush();
/*     */         
/*     */ 
/*     */ 
/* 774 */         return diOs.getDigestValue();
/*     */       } catch (XMLSecurityException ex) {
/* 776 */         throw new ReferenceNotInitializedException("empty", ex);
/*     */       } catch (IOException ex) {
/* 778 */         throw new ReferenceNotInitializedException("empty", ex);
/*     */       }
/*     */     }
/*     */     
/* 782 */     return getDigestPrivateData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getDigestValue()
/*     */     throws Base64DecodingException, XMLSecurityException
/*     */   {
/* 794 */     if (this.digestValueElement == null)
/*     */     {
/* 796 */       Object[] exArgs = { "DigestValue", "http://www.w3.org/2000/09/xmldsig#" };
/*     */       
/* 798 */       throw new XMLSecurityException("signature.Verification.NoSignatureElement", exArgs);
/*     */     }
/*     */     
/*     */ 
/* 802 */     byte[] elemDig = Base64.decode(this.digestValueElement);
/* 803 */     return elemDig;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean verify()
/*     */     throws ReferenceNotInitializedException, XMLSecurityException
/*     */   {
/* 817 */     byte[] elemDig = getDigestValue();
/* 818 */     byte[] calcDig = calculateDigest(true);
/* 819 */     boolean equal = MessageDigestAlgorithm.isEqual(elemDig, calcDig);
/*     */     
/* 821 */     if (!equal) {
/* 822 */       log.warn("Verification failed for URI \"" + getURI() + "\"");
/* 823 */       log.warn("Expected Digest: " + Base64.encode(elemDig));
/* 824 */       log.warn("Actual Digest: " + Base64.encode(calcDig));
/*     */     } else {
/* 826 */       log.info("Verification successful for URI \"" + getURI() + "\"");
/*     */     }
/*     */     
/* 829 */     return equal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBaseLocalName()
/*     */   {
/* 838 */     return "Reference";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\signature\Reference.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */