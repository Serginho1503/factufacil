/*    */ package org.apache.xml.security.keys;
/*    */ 
/*    */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContentHandlerAlreadyRegisteredException
/*    */   extends XMLSecurityException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public ContentHandlerAlreadyRegisteredException() {}
/*    */   
/*    */   public ContentHandlerAlreadyRegisteredException(String _msgID)
/*    */   {
/* 51 */     super(_msgID);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ContentHandlerAlreadyRegisteredException(String _msgID, Object[] exArgs)
/*    */   {
/* 62 */     super(_msgID, exArgs);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ContentHandlerAlreadyRegisteredException(String _msgID, Exception _originalException)
/*    */   {
/* 73 */     super(_msgID, _originalException);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ContentHandlerAlreadyRegisteredException(String _msgID, Object[] exArgs, Exception _originalException)
/*    */   {
/* 85 */     super(_msgID, exArgs, _originalException);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\ContentHandlerAlreadyRegisteredException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */