/*     */ package org.apache.xml.security.utils.resolver.implementations;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import org.apache.xml.security.utils.resolver.ResourceResolverException;
/*     */ import org.apache.xml.security.utils.resolver.ResourceResolverSpi;
/*     */ import org.apache.xml.utils.URI;
/*     */ import org.apache.xml.utils.URI.MalformedURIException;
/*     */ import org.w3c.dom.Attr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResolverLocalFilesystem
/*     */   extends ResourceResolverSpi
/*     */ {
/*  39 */   static Log log = LogFactory.getLog(ResolverLocalFilesystem.class.getName());
/*     */   
/*     */ 
/*     */   public boolean engineIsThreadSafe()
/*     */   {
/*  44 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public XMLSignatureInput engineResolve(Attr uri, String BaseURI)
/*     */     throws ResourceResolverException
/*     */   {
/*     */     try
/*     */     {
/*  53 */       URI uriNew = getNewURI(uri.getNodeValue(), BaseURI);
/*     */       
/*     */ 
/*  56 */       URI uriNewNoFrag = new URI(uriNew);
/*     */       
/*  58 */       uriNewNoFrag.setFragment(null);
/*     */       
/*  60 */       String fileName = translateUriToFilename(uriNewNoFrag.toString());
/*     */       
/*     */ 
/*  63 */       FileInputStream inputStream = new FileInputStream(fileName);
/*  64 */       XMLSignatureInput result = new XMLSignatureInput(inputStream);
/*     */       
/*  66 */       result.setSourceURI(uriNew.toString());
/*     */       
/*  68 */       return result;
/*     */     } catch (Exception e) {
/*  70 */       throw new ResourceResolverException("generic.EmptyMessage", e, uri, BaseURI);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*  75 */   private static int FILE_URI_LENGTH = "file:/".length();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static String translateUriToFilename(String uri)
/*     */   {
/*  84 */     String subStr = uri.substring(FILE_URI_LENGTH);
/*     */     
/*  86 */     if (subStr.indexOf("%20") > -1)
/*     */     {
/*  88 */       int offset = 0;
/*  89 */       int index = 0;
/*  90 */       StringBuffer temp = new StringBuffer(subStr.length());
/*     */       do
/*     */       {
/*  93 */         index = subStr.indexOf("%20", offset);
/*  94 */         if (index == -1) { temp.append(subStr.substring(offset));
/*     */         }
/*     */         else {
/*  97 */           temp.append(subStr.substring(offset, index));
/*  98 */           temp.append(' ');
/*  99 */           offset = index + 3;
/*     */         }
/*     */         
/* 102 */       } while (index != -1);
/* 103 */       subStr = temp.toString();
/*     */     }
/*     */     
/* 106 */     if (subStr.charAt(1) == ':')
/*     */     {
/* 108 */       return subStr;
/*     */     }
/*     */     
/* 111 */     return "/" + subStr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean engineCanResolve(Attr uri, String BaseURI)
/*     */   {
/* 119 */     if (uri == null) {
/* 120 */       return false;
/*     */     }
/*     */     
/* 123 */     String uriNodeValue = uri.getNodeValue();
/*     */     
/* 125 */     if ((uriNodeValue.equals("")) || (uriNodeValue.charAt(0) == '#') || (uriNodeValue.startsWith("http:")))
/*     */     {
/* 127 */       return false;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 132 */       if (log.isDebugEnabled()) {
/* 133 */         log.debug("I was asked whether I can resolve " + uriNodeValue);
/*     */       }
/* 135 */       if ((uriNodeValue.startsWith("file:")) || (BaseURI.startsWith("file:")))
/*     */       {
/* 137 */         if (log.isDebugEnabled()) {
/* 138 */           log.debug("I state that I can resolve " + uriNodeValue);
/*     */         }
/* 140 */         return true;
/*     */       }
/*     */     }
/*     */     catch (Exception e) {}
/* 144 */     log.debug("But I can't");
/*     */     
/* 146 */     return false;
/*     */   }
/*     */   
/*     */   protected static URI getNewURI(String uri, String BaseURI)
/*     */     throws URI.MalformedURIException
/*     */   {
/* 152 */     if ((BaseURI == null) || ("".equals(BaseURI))) {
/* 153 */       return new URI(uri);
/*     */     }
/* 155 */     return new URI(new URI(BaseURI), uri);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\utils\resolver\implementations\ResolverLocalFilesystem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */