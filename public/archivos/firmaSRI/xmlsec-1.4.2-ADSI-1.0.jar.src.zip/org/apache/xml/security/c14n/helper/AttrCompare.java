/*     */ package org.apache.xml.security.c14n.helper;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Comparator;
/*     */ import org.w3c.dom.Attr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AttrCompare
/*     */   implements Comparator, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -7113259629930576230L;
/*     */   private static final int ATTR0_BEFORE_ATTR1 = -1;
/*     */   private static final int ATTR1_BEFORE_ATTR0 = 1;
/*     */   private static final String XMLNS = "http://www.w3.org/2000/xmlns/";
/*     */   
/*     */   public int compare(Object obj0, Object obj1)
/*     */   {
/*  70 */     Attr attr0 = (Attr)obj0;
/*  71 */     Attr attr1 = (Attr)obj1;
/*  72 */     String namespaceURI0 = attr0.getNamespaceURI();
/*  73 */     String namespaceURI1 = attr1.getNamespaceURI();
/*     */     
/*  75 */     boolean isNamespaceAttr0 = "http://www.w3.org/2000/xmlns/" == namespaceURI0;
/*  76 */     boolean isNamespaceAttr1 = "http://www.w3.org/2000/xmlns/" == namespaceURI1;
/*     */     
/*  78 */     if (isNamespaceAttr0) {
/*  79 */       if (isNamespaceAttr1)
/*     */       {
/*  81 */         String localname0 = attr0.getLocalName();
/*  82 */         String localname1 = attr1.getLocalName();
/*     */         
/*  84 */         if (localname0.equals("xmlns")) {
/*  85 */           localname0 = "";
/*     */         }
/*     */         
/*  88 */         if (localname1.equals("xmlns")) {
/*  89 */           localname1 = "";
/*     */         }
/*     */         
/*  92 */         return localname0.compareTo(localname1);
/*     */       }
/*     */       
/*  95 */       return -1;
/*     */     }
/*     */     
/*  98 */     if (isNamespaceAttr1)
/*     */     {
/* 100 */       return 1;
/*     */     }
/*     */     
/*     */ 
/* 104 */     if (namespaceURI0 == null) {
/* 105 */       if (namespaceURI1 == null) {
/* 106 */         String name0 = attr0.getName();
/* 107 */         String name1 = attr1.getName();
/* 108 */         return name0.compareTo(name1);
/*     */       }
/* 110 */       return -1;
/*     */     }
/*     */     
/* 113 */     if (namespaceURI1 == null) {
/* 114 */       return 1;
/*     */     }
/*     */     
/* 117 */     int a = namespaceURI0.compareTo(namespaceURI1);
/* 118 */     if (a != 0) {
/* 119 */       return a;
/*     */     }
/*     */     
/* 122 */     return attr0.getLocalName().compareTo(attr1.getLocalName());
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\c14n\helper\AttrCompare.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */