/*    */ package org.apache.xml.security.transforms.implementations;
/*    */ 
/*    */ import java.io.OutputStream;
/*    */ import org.apache.xml.security.c14n.CanonicalizationException;
/*    */ import org.apache.xml.security.c14n.implementations.Canonicalizer20010315OmitComments;
/*    */ import org.apache.xml.security.signature.XMLSignatureInput;
/*    */ import org.apache.xml.security.transforms.Transform;
/*    */ import org.apache.xml.security.transforms.TransformSpi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransformC14N
/*    */   extends TransformSpi
/*    */ {
/*    */   public static final String implementedTransformURI = "http://www.w3.org/TR/2001/REC-xml-c14n-20010315";
/*    */   
/*    */   protected String engineGetURI()
/*    */   {
/* 45 */     return "http://www.w3.org/TR/2001/REC-xml-c14n-20010315";
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, Transform _transformObject)
/*    */     throws CanonicalizationException
/*    */   {
/* 54 */     return enginePerformTransform(input, null, _transformObject);
/*    */   }
/*    */   
/*    */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, OutputStream os, Transform _transformObject) throws CanonicalizationException
/*    */   {
/* 59 */     Canonicalizer20010315OmitComments c14n = new Canonicalizer20010315OmitComments();
/* 60 */     if (os != null) {
/* 61 */       c14n.setWriter(os);
/*    */     }
/* 63 */     byte[] result = null;
/* 64 */     result = c14n.engineCanonicalize(input);
/* 65 */     XMLSignatureInput output = new XMLSignatureInput(result);
/* 66 */     if (os != null) {
/* 67 */       output.setOutputStream(os);
/*    */     }
/* 69 */     return output;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\transforms\implementations\TransformC14N.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */