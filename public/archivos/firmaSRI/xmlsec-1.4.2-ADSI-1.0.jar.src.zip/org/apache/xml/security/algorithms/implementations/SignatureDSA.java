/*     */ package org.apache.xml.security.algorithms.implementations;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.Key;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.Provider;
/*     */ import java.security.PublicKey;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.Signature;
/*     */ import java.security.SignatureException;
/*     */ import java.security.spec.AlgorithmParameterSpec;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.algorithms.JCEMapper;
/*     */ import org.apache.xml.security.algorithms.SignatureAlgorithmSpi;
/*     */ import org.apache.xml.security.signature.XMLSignatureException;
/*     */ import org.apache.xml.security.utils.Base64;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignatureDSA
/*     */   extends SignatureAlgorithmSpi
/*     */ {
/*  47 */   static Log log = LogFactory.getLog(SignatureDSA.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String _URI = "http://www.w3.org/2000/09/xmldsig#dsa-sha1";
/*     */   
/*     */ 
/*  54 */   private Signature _signatureAlgorithm = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String engineGetURI()
/*     */   {
/*  62 */     return "http://www.w3.org/2000/09/xmldsig#dsa-sha1";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignatureDSA()
/*     */     throws XMLSignatureException
/*     */   {
/*  72 */     String algorithmID = JCEMapper.translateURItoJCEID("http://www.w3.org/2000/09/xmldsig#dsa-sha1");
/*  73 */     if (log.isDebugEnabled()) {
/*  74 */       log.debug("Created SignatureDSA using " + algorithmID);
/*     */     }
/*  76 */     Provider providerThread = JCEMapper.getProviderSignatureThread();
/*  77 */     String provider = null;
/*  78 */     if (providerThread == null) {
/*  79 */       provider = JCEMapper.getProviderId();
/*     */     }
/*     */     try {
/*  82 */       if (providerThread == null) {
/*  83 */         if (provider == null) {
/*  84 */           this._signatureAlgorithm = Signature.getInstance(algorithmID);
/*     */         } else {
/*  86 */           this._signatureAlgorithm = Signature.getInstance(algorithmID, provider);
/*     */         }
/*     */       } else {
/*  89 */         this._signatureAlgorithm = Signature.getInstance(algorithmID, providerThread);
/*     */       }
/*     */     } catch (NoSuchAlgorithmException ex) {
/*  92 */       Object[] exArgs = { algorithmID, ex.getLocalizedMessage() };
/*  93 */       throw new XMLSignatureException("algorithms.NoSuchAlgorithm", exArgs);
/*     */     } catch (NoSuchProviderException ex) {
/*  95 */       Object[] exArgs = { algorithmID, ex.getLocalizedMessage() };
/*  96 */       throw new XMLSignatureException("algorithms.NoSuchAlgorithm", exArgs);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void engineSetParameter(AlgorithmParameterSpec params)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 107 */       this._signatureAlgorithm.setParameter(params);
/*     */     } catch (InvalidAlgorithmParameterException ex) {
/* 109 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean engineVerify(byte[] signature)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 120 */       if (log.isDebugEnabled()) {
/* 121 */         log.debug("Called DSA.verify() on " + Base64.encode(signature));
/*     */       }
/* 123 */       byte[] jcebytes = convertXMLDSIGtoASN1(signature);
/*     */       
/* 125 */       return this._signatureAlgorithm.verify(jcebytes);
/*     */     } catch (SignatureException ex) {
/* 127 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (IOException ex) {
/* 129 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void engineInitVerify(Key publicKey)
/*     */     throws XMLSignatureException
/*     */   {
/* 138 */     if (!(publicKey instanceof PublicKey)) {
/* 139 */       String supplied = publicKey.getClass().getName();
/* 140 */       String needed = PublicKey.class.getName();
/* 141 */       Object[] exArgs = { supplied, needed };
/*     */       
/* 143 */       throw new XMLSignatureException("algorithms.WrongKeyForThisOperation", exArgs);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 148 */       this._signatureAlgorithm.initVerify((PublicKey)publicKey);
/*     */     }
/*     */     catch (InvalidKeyException ex)
/*     */     {
/* 152 */       Signature sig = this._signatureAlgorithm;
/*     */       try {
/* 154 */         this._signatureAlgorithm = Signature.getInstance(this._signatureAlgorithm.getAlgorithm());
/*     */ 
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 159 */         if (log.isDebugEnabled()) {
/* 160 */           log.debug("Exception when reinstantiating Signature:" + e);
/*     */         }
/* 162 */         this._signatureAlgorithm = sig;
/*     */       }
/* 164 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected byte[] engineSign()
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 174 */       byte[] jcebytes = this._signatureAlgorithm.sign();
/*     */       
/* 176 */       return convertASN1toXMLDSIG(jcebytes);
/*     */     } catch (IOException ex) {
/* 178 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (SignatureException ex) {
/* 180 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineInitSign(Key privateKey, SecureRandom secureRandom)
/*     */     throws XMLSignatureException
/*     */   {
/* 190 */     if (!(privateKey instanceof PrivateKey)) {
/* 191 */       String supplied = privateKey.getClass().getName();
/* 192 */       String needed = PrivateKey.class.getName();
/* 193 */       Object[] exArgs = { supplied, needed };
/*     */       
/* 195 */       throw new XMLSignatureException("algorithms.WrongKeyForThisOperation", exArgs);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 200 */       this._signatureAlgorithm.initSign((PrivateKey)privateKey, secureRandom);
/*     */     }
/*     */     catch (InvalidKeyException ex) {
/* 203 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void engineInitSign(Key privateKey)
/*     */     throws XMLSignatureException
/*     */   {
/* 212 */     if (!(privateKey instanceof PrivateKey)) {
/* 213 */       String supplied = privateKey.getClass().getName();
/* 214 */       String needed = PrivateKey.class.getName();
/* 215 */       Object[] exArgs = { supplied, needed };
/*     */       
/* 217 */       throw new XMLSignatureException("algorithms.WrongKeyForThisOperation", exArgs);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 222 */       this._signatureAlgorithm.initSign((PrivateKey)privateKey);
/*     */     } catch (InvalidKeyException ex) {
/* 224 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void engineUpdate(byte[] input)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 233 */       this._signatureAlgorithm.update(input);
/*     */     } catch (SignatureException ex) {
/* 235 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void engineUpdate(byte input)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 244 */       this._signatureAlgorithm.update(input);
/*     */     } catch (SignatureException ex) {
/* 246 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void engineUpdate(byte[] buf, int offset, int len)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 256 */       this._signatureAlgorithm.update(buf, offset, len);
/*     */     } catch (SignatureException ex) {
/* 258 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String engineGetJCEAlgorithmString()
/*     */   {
/* 268 */     return this._signatureAlgorithm.getAlgorithm();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String engineGetJCEProviderName()
/*     */   {
/* 277 */     return this._signatureAlgorithm.getProvider().getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static byte[] convertASN1toXMLDSIG(byte[] asn1Bytes)
/*     */     throws IOException
/*     */   {
/* 295 */     byte rLength = asn1Bytes[3];
/*     */     
/*     */ 
/* 298 */     for (int i = rLength; (i > 0) && (asn1Bytes[(4 + rLength - i)] == 0); i--) {}
/*     */     
/* 300 */     byte sLength = asn1Bytes[(5 + rLength)];
/*     */     
/*     */ 
/* 303 */     int j = sLength;
/* 304 */     while ((j > 0) && (asn1Bytes[(6 + rLength + sLength - j)] == 0)) { j--;
/*     */     }
/* 306 */     if ((asn1Bytes[0] != 48) || (asn1Bytes[1] != asn1Bytes.length - 2) || (asn1Bytes[2] != 2) || (i > 20) || (asn1Bytes[(4 + rLength)] != 2) || (j > 20))
/*     */     {
/*     */ 
/* 309 */       throw new IOException("Invalid ASN.1 format of DSA signature");
/*     */     }
/* 311 */     byte[] xmldsigBytes = new byte[40];
/*     */     
/* 313 */     System.arraycopy(asn1Bytes, 4 + rLength - i, xmldsigBytes, 20 - i, i);
/*     */     
/* 315 */     System.arraycopy(asn1Bytes, 6 + rLength + sLength - j, xmldsigBytes, 40 - j, j);
/*     */     
/*     */ 
/* 318 */     return xmldsigBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static byte[] convertXMLDSIGtoASN1(byte[] xmldsigBytes)
/*     */     throws IOException
/*     */   {
/* 336 */     if (xmldsigBytes.length != 40) {
/* 337 */       throw new IOException("Invalid XMLDSIG format of DSA signature");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 342 */     for (int i = 20; (i > 0) && (xmldsigBytes[(20 - i)] == 0); i--) {}
/*     */     
/* 344 */     int j = i;
/*     */     
/* 346 */     if (xmldsigBytes[(20 - i)] < 0) {
/* 347 */       j++;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 352 */     for (int k = 20; (k > 0) && (xmldsigBytes[(40 - k)] == 0); k--) {}
/*     */     
/* 354 */     int l = k;
/*     */     
/* 356 */     if (xmldsigBytes[(40 - k)] < 0) {
/* 357 */       l++;
/*     */     }
/*     */     
/* 360 */     byte[] asn1Bytes = new byte[6 + j + l];
/*     */     
/* 362 */     asn1Bytes[0] = 48;
/* 363 */     asn1Bytes[1] = ((byte)(4 + j + l));
/* 364 */     asn1Bytes[2] = 2;
/* 365 */     asn1Bytes[3] = ((byte)j);
/*     */     
/* 367 */     System.arraycopy(xmldsigBytes, 20 - i, asn1Bytes, 4 + j - i, i);
/*     */     
/* 369 */     asn1Bytes[(4 + j)] = 2;
/* 370 */     asn1Bytes[(5 + j)] = ((byte)l);
/*     */     
/* 372 */     System.arraycopy(xmldsigBytes, 40 - k, asn1Bytes, 6 + j + l - k, k);
/*     */     
/* 374 */     return asn1Bytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineSetHMACOutputLength(int HMACOutputLength)
/*     */     throws XMLSignatureException
/*     */   {
/* 385 */     throw new XMLSignatureException("algorithms.HMACOutputLengthOnlyForHMAC");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineInitSign(Key signingKey, AlgorithmParameterSpec algorithmParameterSpec)
/*     */     throws XMLSignatureException
/*     */   {
/* 399 */     throw new XMLSignatureException("algorithms.CannotUseAlgorithmParameterSpecOnDSA");
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\algorithms\implementations\SignatureDSA.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */