/*    */ package org.apache.xml.security.transforms.implementations;
/*    */ 
/*    */ import org.apache.xml.security.signature.XMLSignatureInput;
/*    */ import org.apache.xml.security.transforms.Transform;
/*    */ import org.apache.xml.security.transforms.TransformSpi;
/*    */ import org.apache.xml.security.transforms.TransformationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransformXPointer
/*    */   extends TransformSpi
/*    */ {
/*    */   public static final String implementedTransformURI = "http://www.w3.org/TR/2001/WD-xptr-20010108";
/*    */   
/*    */   protected String engineGetURI()
/*    */   {
/* 45 */     return "http://www.w3.org/TR/2001/WD-xptr-20010108";
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, Transform _transformObject)
/*    */     throws TransformationException
/*    */   {
/* 59 */     Object[] exArgs = { "http://www.w3.org/TR/2001/WD-xptr-20010108" };
/*    */     
/* 61 */     throw new TransformationException("signature.Transform.NotYetImplemented", exArgs);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\transforms\implementations\TransformXPointer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */