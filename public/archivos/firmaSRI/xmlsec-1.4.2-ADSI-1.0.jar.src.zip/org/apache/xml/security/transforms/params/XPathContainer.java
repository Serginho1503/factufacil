/*    */ package org.apache.xml.security.transforms.params;
/*    */ 
/*    */ import org.apache.xml.security.transforms.TransformParam;
/*    */ import org.apache.xml.security.utils.SignatureElementProxy;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.NodeList;
/*    */ import org.w3c.dom.Text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XPathContainer
/*    */   extends SignatureElementProxy
/*    */   implements TransformParam
/*    */ {
/*    */   public XPathContainer(Document doc)
/*    */   {
/* 44 */     super(doc);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setXPath(String xpath)
/*    */   {
/* 54 */     if (this._constructionElement.getChildNodes() != null) {
/* 55 */       NodeList nl = this._constructionElement.getChildNodes();
/*    */       
/* 57 */       for (int i = 0; i < nl.getLength(); i++) {
/* 58 */         this._constructionElement.removeChild(nl.item(i));
/*    */       }
/*    */     }
/*    */     
/* 62 */     Text xpathText = this._doc.createTextNode(xpath);
/* 63 */     this._constructionElement.appendChild(xpathText);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getXPath()
/*    */   {
/* 72 */     return getTextFromTextChild();
/*    */   }
/*    */   
/*    */   public String getBaseLocalName()
/*    */   {
/* 77 */     return "XPath";
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\transforms\params\XPathContainer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */