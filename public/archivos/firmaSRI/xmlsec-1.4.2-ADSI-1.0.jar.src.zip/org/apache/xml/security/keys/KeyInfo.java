/*      */ package org.apache.xml.security.keys;
/*      */ 
/*      */ import java.security.PublicKey;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import javax.crypto.SecretKey;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.apache.xml.security.encryption.EncryptedKey;
/*      */ import org.apache.xml.security.encryption.XMLCipher;
/*      */ import org.apache.xml.security.encryption.XMLEncryptionException;
/*      */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*      */ import org.apache.xml.security.keys.content.KeyName;
/*      */ import org.apache.xml.security.keys.content.KeyValue;
/*      */ import org.apache.xml.security.keys.content.MgmtData;
/*      */ import org.apache.xml.security.keys.content.PGPData;
/*      */ import org.apache.xml.security.keys.content.RetrievalMethod;
/*      */ import org.apache.xml.security.keys.content.SPKIData;
/*      */ import org.apache.xml.security.keys.content.X509Data;
/*      */ import org.apache.xml.security.keys.content.keyvalues.DSAKeyValue;
/*      */ import org.apache.xml.security.keys.content.keyvalues.RSAKeyValue;
/*      */ import org.apache.xml.security.keys.keyresolver.KeyResolver;
/*      */ import org.apache.xml.security.keys.keyresolver.KeyResolverException;
/*      */ import org.apache.xml.security.keys.keyresolver.KeyResolverSpi;
/*      */ import org.apache.xml.security.keys.storage.StorageResolver;
/*      */ import org.apache.xml.security.transforms.Transforms;
/*      */ import org.apache.xml.security.utils.IdResolver;
/*      */ import org.apache.xml.security.utils.SignatureElementProxy;
/*      */ import org.apache.xml.security.utils.XMLUtils;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class KeyInfo
/*      */   extends SignatureElementProxy
/*      */ {
/*   94 */   static Log log = LogFactory.getLog(KeyInfo.class.getName());
/*      */   
/*   96 */   List x509Datas = null;
/*   97 */   List encryptedKeys = null;
/*      */   static final List nullList;
/*      */   
/*      */   static {
/*  101 */     List list = new ArrayList();
/*  102 */     list.add(null);
/*  103 */     nullList = Collections.unmodifiableList(list);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public KeyInfo(Document doc)
/*      */   {
/*  112 */     super(doc);
/*      */     
/*  114 */     XMLUtils.addReturnToElement(this._constructionElement);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public KeyInfo(Element element, String BaseURI)
/*      */     throws XMLSecurityException
/*      */   {
/*  126 */     super(element, BaseURI);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setId(String Id)
/*      */   {
/*  138 */     if (Id != null) {
/*  139 */       this._constructionElement.setAttributeNS(null, "Id", Id);
/*  140 */       IdResolver.registerElementById(this._constructionElement, Id);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getId()
/*      */   {
/*  150 */     return this._constructionElement.getAttributeNS(null, "Id");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addKeyName(String keynameString)
/*      */   {
/*  159 */     add(new KeyName(this._doc, keynameString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(KeyName keyname)
/*      */   {
/*  169 */     this._constructionElement.appendChild(keyname.getElement());
/*  170 */     XMLUtils.addReturnToElement(this._constructionElement);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addKeyValue(PublicKey pk)
/*      */   {
/*  179 */     add(new KeyValue(this._doc, pk));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addKeyValue(Element unknownKeyValueElement)
/*      */   {
/*  188 */     add(new KeyValue(this._doc, unknownKeyValueElement));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(DSAKeyValue dsakeyvalue)
/*      */   {
/*  197 */     add(new KeyValue(this._doc, dsakeyvalue));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(RSAKeyValue rsakeyvalue)
/*      */   {
/*  206 */     add(new KeyValue(this._doc, rsakeyvalue));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(PublicKey pk)
/*      */   {
/*  215 */     add(new KeyValue(this._doc, pk));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(KeyValue keyvalue)
/*      */   {
/*  224 */     this._constructionElement.appendChild(keyvalue.getElement());
/*  225 */     XMLUtils.addReturnToElement(this._constructionElement);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addMgmtData(String mgmtdata)
/*      */   {
/*  234 */     add(new MgmtData(this._doc, mgmtdata));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(MgmtData mgmtdata)
/*      */   {
/*  243 */     this._constructionElement.appendChild(mgmtdata.getElement());
/*  244 */     XMLUtils.addReturnToElement(this._constructionElement);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(PGPData pgpdata)
/*      */   {
/*  253 */     this._constructionElement.appendChild(pgpdata.getElement());
/*  254 */     XMLUtils.addReturnToElement(this._constructionElement);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addRetrievalMethod(String URI, Transforms transforms, String Type)
/*      */   {
/*  266 */     add(new RetrievalMethod(this._doc, URI, transforms, Type));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(RetrievalMethod retrievalmethod)
/*      */   {
/*  275 */     this._constructionElement.appendChild(retrievalmethod.getElement());
/*  276 */     XMLUtils.addReturnToElement(this._constructionElement);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(SPKIData spkidata)
/*      */   {
/*  285 */     this._constructionElement.appendChild(spkidata.getElement());
/*  286 */     XMLUtils.addReturnToElement(this._constructionElement);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(X509Data x509data)
/*      */   {
/*  295 */     if (this.x509Datas == null)
/*  296 */       this.x509Datas = new ArrayList();
/*  297 */     this.x509Datas.add(x509data);
/*  298 */     this._constructionElement.appendChild(x509data.getElement());
/*  299 */     XMLUtils.addReturnToElement(this._constructionElement);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(EncryptedKey encryptedKey)
/*      */     throws XMLEncryptionException
/*      */   {
/*  311 */     if (this.encryptedKeys == null)
/*  312 */       this.encryptedKeys = new ArrayList();
/*  313 */     this.encryptedKeys.add(encryptedKey);
/*  314 */     XMLCipher cipher = XMLCipher.getInstance();
/*  315 */     this._constructionElement.appendChild(cipher.martial(encryptedKey));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addUnknownElement(Element element)
/*      */   {
/*  324 */     this._constructionElement.appendChild(element);
/*  325 */     XMLUtils.addReturnToElement(this._constructionElement);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int lengthKeyName()
/*      */   {
/*  334 */     return length("http://www.w3.org/2000/09/xmldsig#", "KeyName");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int lengthKeyValue()
/*      */   {
/*  343 */     return length("http://www.w3.org/2000/09/xmldsig#", "KeyValue");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int lengthMgmtData()
/*      */   {
/*  352 */     return length("http://www.w3.org/2000/09/xmldsig#", "MgmtData");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int lengthPGPData()
/*      */   {
/*  361 */     return length("http://www.w3.org/2000/09/xmldsig#", "PGPData");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int lengthRetrievalMethod()
/*      */   {
/*  370 */     return length("http://www.w3.org/2000/09/xmldsig#", "RetrievalMethod");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int lengthSPKIData()
/*      */   {
/*  380 */     return length("http://www.w3.org/2000/09/xmldsig#", "SPKIData");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int lengthX509Data()
/*      */   {
/*  389 */     if (this.x509Datas != null) {
/*  390 */       return this.x509Datas.size();
/*      */     }
/*  392 */     return length("http://www.w3.org/2000/09/xmldsig#", "X509Data");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int lengthUnknownElement()
/*      */   {
/*  402 */     int res = 0;
/*  403 */     NodeList nl = this._constructionElement.getChildNodes();
/*      */     
/*  405 */     for (int i = 0; i < nl.getLength(); i++) {
/*  406 */       Node current = nl.item(i);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  412 */       if ((current.getNodeType() == 1) && (current.getNamespaceURI().equals("http://www.w3.org/2000/09/xmldsig#")))
/*      */       {
/*      */ 
/*  415 */         res++;
/*      */       }
/*      */     }
/*      */     
/*  419 */     return res;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public KeyName itemKeyName(int i)
/*      */     throws XMLSecurityException
/*      */   {
/*  431 */     Element e = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), "KeyName", i);
/*      */     
/*      */ 
/*  434 */     if (e != null) {
/*  435 */       return new KeyName(e, this._baseURI);
/*      */     }
/*  437 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public KeyValue itemKeyValue(int i)
/*      */     throws XMLSecurityException
/*      */   {
/*  449 */     Element e = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), "KeyValue", i);
/*      */     
/*      */ 
/*  452 */     if (e != null) {
/*  453 */       return new KeyValue(e, this._baseURI);
/*      */     }
/*  455 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MgmtData itemMgmtData(int i)
/*      */     throws XMLSecurityException
/*      */   {
/*  467 */     Element e = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), "MgmtData", i);
/*      */     
/*      */ 
/*  470 */     if (e != null) {
/*  471 */       return new MgmtData(e, this._baseURI);
/*      */     }
/*  473 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PGPData itemPGPData(int i)
/*      */     throws XMLSecurityException
/*      */   {
/*  485 */     Element e = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), "PGPData", i);
/*      */     
/*      */ 
/*  488 */     if (e != null) {
/*  489 */       return new PGPData(e, this._baseURI);
/*      */     }
/*  491 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public RetrievalMethod itemRetrievalMethod(int i)
/*      */     throws XMLSecurityException
/*      */   {
/*  504 */     Element e = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), "RetrievalMethod", i);
/*      */     
/*      */ 
/*  507 */     if (e != null) {
/*  508 */       return new RetrievalMethod(e, this._baseURI);
/*      */     }
/*  510 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SPKIData itemSPKIData(int i)
/*      */     throws XMLSecurityException
/*      */   {
/*  522 */     Element e = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), "SPKIData", i);
/*      */     
/*      */ 
/*  525 */     if (e != null) {
/*  526 */       return new SPKIData(e, this._baseURI);
/*      */     }
/*  528 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public X509Data itemX509Data(int i)
/*      */     throws XMLSecurityException
/*      */   {
/*  539 */     if (this.x509Datas != null) {
/*  540 */       return (X509Data)this.x509Datas.get(i);
/*      */     }
/*  542 */     Element e = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), "X509Data", i);
/*      */     
/*      */ 
/*  545 */     if (e != null) {
/*  546 */       return new X509Data(e, this._baseURI);
/*      */     }
/*  548 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptedKey itemEncryptedKey(int i)
/*      */     throws XMLSecurityException
/*      */   {
/*  560 */     if (this.encryptedKeys != null) {
/*  561 */       return (EncryptedKey)this.encryptedKeys.get(i);
/*      */     }
/*  563 */     Element e = XMLUtils.selectXencNode(this._constructionElement.getFirstChild(), "EncryptedKey", i);
/*      */     
/*      */ 
/*      */ 
/*  567 */     if (e != null) {
/*  568 */       XMLCipher cipher = XMLCipher.getInstance();
/*  569 */       cipher.init(4, null);
/*  570 */       return cipher.loadEncryptedKey(e);
/*      */     }
/*  572 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Element itemUnknownElement(int i)
/*      */   {
/*  583 */     NodeList nl = this._constructionElement.getChildNodes();
/*  584 */     int res = 0;
/*      */     
/*  586 */     for (int j = 0; j < nl.getLength(); j++) {
/*  587 */       Node current = nl.item(j);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  593 */       if ((current.getNodeType() == 1) && (current.getNamespaceURI().equals("http://www.w3.org/2000/09/xmldsig#")))
/*      */       {
/*      */ 
/*  596 */         res++;
/*      */         
/*  598 */         if (res == i) {
/*  599 */           return (Element)current;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  604 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isEmpty()
/*      */   {
/*  613 */     return this._constructionElement.getFirstChild() == null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean containsKeyName()
/*      */   {
/*  622 */     return lengthKeyName() > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean containsKeyValue()
/*      */   {
/*  631 */     return lengthKeyValue() > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean containsMgmtData()
/*      */   {
/*  640 */     return lengthMgmtData() > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean containsPGPData()
/*      */   {
/*  649 */     return lengthPGPData() > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean containsRetrievalMethod()
/*      */   {
/*  658 */     return lengthRetrievalMethod() > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean containsSPKIData()
/*      */   {
/*  667 */     return lengthSPKIData() > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean containsUnknownElement()
/*      */   {
/*  676 */     return lengthUnknownElement() > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean containsX509Data()
/*      */   {
/*  685 */     return lengthX509Data() > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PublicKey getPublicKey()
/*      */     throws KeyResolverException
/*      */   {
/*  697 */     PublicKey pk = getPublicKeyFromInternalResolvers();
/*      */     
/*  699 */     if (pk != null) {
/*  700 */       log.debug("I could find a key using the per-KeyInfo key resolvers");
/*      */       
/*  702 */       return pk;
/*      */     }
/*  704 */     log.debug("I couldn't find a key using the per-KeyInfo key resolvers");
/*      */     
/*  706 */     pk = getPublicKeyFromStaticResolvers();
/*      */     
/*  708 */     if (pk != null) {
/*  709 */       log.debug("I could find a key using the system-wide key resolvers");
/*      */       
/*  711 */       return pk;
/*      */     }
/*  713 */     log.debug("I couldn't find a key using the system-wide key resolvers");
/*      */     
/*  715 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   PublicKey getPublicKeyFromStaticResolvers()
/*      */     throws KeyResolverException
/*      */   {
/*  725 */     int length = KeyResolver.length();
/*  726 */     int storageLength = this._storageResolvers.size();
/*  727 */     Iterator it = KeyResolver.iterator();
/*  728 */     for (int i = 0; i < length; i++) {
/*  729 */       KeyResolverSpi keyResolver = (KeyResolverSpi)it.next();
/*  730 */       Node currentChild = this._constructionElement.getFirstChild();
/*  731 */       String uri = getBaseURI();
/*  732 */       while (currentChild != null) {
/*  733 */         if (currentChild.getNodeType() == 1) {
/*  734 */           for (int k = 0; k < storageLength; k++) {
/*  735 */             StorageResolver storage = (StorageResolver)this._storageResolvers.get(k);
/*      */             
/*      */ 
/*  738 */             PublicKey pk = keyResolver.engineLookupAndResolvePublicKey((Element)currentChild, uri, storage);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*  743 */             if (pk != null) {
/*  744 */               KeyResolver.hit(it);
/*  745 */               return pk;
/*      */             }
/*      */           }
/*      */         }
/*  749 */         currentChild = currentChild.getNextSibling();
/*      */       }
/*      */     }
/*  752 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   PublicKey getPublicKeyFromInternalResolvers()
/*      */     throws KeyResolverException
/*      */   {
/*  762 */     int length = lengthInternalKeyResolver();
/*  763 */     int storageLength = this._storageResolvers.size();
/*  764 */     for (int i = 0; i < length; i++) {
/*  765 */       KeyResolverSpi keyResolver = itemInternalKeyResolver(i);
/*  766 */       if (log.isDebugEnabled()) {
/*  767 */         log.debug("Try " + keyResolver.getClass().getName());
/*      */       }
/*  769 */       Node currentChild = this._constructionElement.getFirstChild();
/*  770 */       String uri = getBaseURI();
/*  771 */       while (currentChild != null) {
/*  772 */         if (currentChild.getNodeType() == 1) {
/*  773 */           for (int k = 0; k < storageLength; k++) {
/*  774 */             StorageResolver storage = (StorageResolver)this._storageResolvers.get(k);
/*      */             
/*  776 */             PublicKey pk = keyResolver.engineLookupAndResolvePublicKey((Element)currentChild, uri, storage);
/*      */             
/*      */ 
/*  779 */             if (pk != null) {
/*  780 */               return pk;
/*      */             }
/*      */           }
/*      */         }
/*  784 */         currentChild = currentChild.getNextSibling();
/*      */       }
/*      */     }
/*      */     
/*  788 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public X509Certificate getX509Certificate()
/*      */     throws KeyResolverException
/*      */   {
/*  800 */     X509Certificate cert = getX509CertificateFromInternalResolvers();
/*      */     
/*  802 */     if (cert != null) {
/*  803 */       log.debug("I could find a X509Certificate using the per-KeyInfo key resolvers");
/*      */       
/*      */ 
/*  806 */       return cert;
/*      */     }
/*  808 */     log.debug("I couldn't find a X509Certificate using the per-KeyInfo key resolvers");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  813 */     cert = getX509CertificateFromStaticResolvers();
/*      */     
/*  815 */     if (cert != null) {
/*  816 */       log.debug("I could find a X509Certificate using the system-wide key resolvers");
/*      */       
/*      */ 
/*  819 */       return cert;
/*      */     }
/*  821 */     log.debug("I couldn't find a X509Certificate using the system-wide key resolvers");
/*      */     
/*      */ 
/*      */ 
/*  825 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   X509Certificate getX509CertificateFromStaticResolvers()
/*      */     throws KeyResolverException
/*      */   {
/*  838 */     if (log.isDebugEnabled()) {
/*  839 */       log.debug("Start getX509CertificateFromStaticResolvers() with " + KeyResolver.length() + " resolvers");
/*      */     }
/*  841 */     String uri = getBaseURI();
/*  842 */     int length = KeyResolver.length();
/*  843 */     int storageLength = this._storageResolvers.size();
/*  844 */     Iterator it = KeyResolver.iterator();
/*  845 */     for (int i = 0; i < length; i++) {
/*  846 */       KeyResolverSpi keyResolver = (KeyResolverSpi)it.next();
/*  847 */       X509Certificate cert = applyCurrentResolver(uri, storageLength, keyResolver);
/*  848 */       if (cert != null) {
/*  849 */         KeyResolver.hit(it);
/*  850 */         return cert;
/*      */       }
/*      */     }
/*  853 */     return null;
/*      */   }
/*      */   
/*      */   private X509Certificate applyCurrentResolver(String uri, int storageLength, KeyResolverSpi keyResolver) throws KeyResolverException {
/*  857 */     Node currentChild = this._constructionElement.getFirstChild();
/*  858 */     while (currentChild != null) {
/*  859 */       if (currentChild.getNodeType() == 1) {
/*  860 */         for (int k = 0; k < storageLength; k++) {
/*  861 */           StorageResolver storage = (StorageResolver)this._storageResolvers.get(k);
/*      */           
/*      */ 
/*  864 */           X509Certificate cert = keyResolver.engineLookupResolveX509Certificate((Element)currentChild, uri, storage);
/*      */           
/*      */ 
/*      */ 
/*  868 */           if (cert != null) {
/*  869 */             return cert;
/*      */           }
/*      */         }
/*      */       }
/*  873 */       currentChild = currentChild.getNextSibling();
/*      */     }
/*  875 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   X509Certificate getX509CertificateFromInternalResolvers()
/*      */     throws KeyResolverException
/*      */   {
/*  886 */     if (log.isDebugEnabled()) {
/*  887 */       log.debug("Start getX509CertificateFromInternalResolvers() with " + lengthInternalKeyResolver() + " resolvers");
/*      */     }
/*  889 */     String uri = getBaseURI();
/*  890 */     int storageLength = this._storageResolvers.size();
/*  891 */     for (int i = 0; i < lengthInternalKeyResolver(); i++) {
/*  892 */       KeyResolverSpi keyResolver = itemInternalKeyResolver(i);
/*  893 */       if (log.isDebugEnabled())
/*  894 */         log.debug("Try " + keyResolver.getClass().getName());
/*  895 */       X509Certificate cert = applyCurrentResolver(uri, storageLength, keyResolver);
/*  896 */       if (cert != null) {
/*  897 */         return cert;
/*      */       }
/*      */     }
/*      */     
/*  901 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public SecretKey getSecretKey()
/*      */     throws KeyResolverException
/*      */   {
/*  910 */     SecretKey sk = getSecretKeyFromInternalResolvers();
/*      */     
/*  912 */     if (sk != null) {
/*  913 */       log.debug("I could find a secret key using the per-KeyInfo key resolvers");
/*      */       
/*  915 */       return sk;
/*      */     }
/*  917 */     log.debug("I couldn't find a secret key using the per-KeyInfo key resolvers");
/*      */     
/*      */ 
/*  920 */     sk = getSecretKeyFromStaticResolvers();
/*      */     
/*  922 */     if (sk != null) {
/*  923 */       log.debug("I could find a secret key using the system-wide key resolvers");
/*      */       
/*  925 */       return sk;
/*      */     }
/*  927 */     log.debug("I couldn't find a secret key using the system-wide key resolvers");
/*      */     
/*      */ 
/*  930 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   SecretKey getSecretKeyFromStaticResolvers()
/*      */     throws KeyResolverException
/*      */   {
/*  941 */     int length = KeyResolver.length();
/*  942 */     int storageLength = this._storageResolvers.size();
/*  943 */     Iterator it = KeyResolver.iterator();
/*  944 */     for (int i = 0; i < length; i++) {
/*  945 */       KeyResolverSpi keyResolver = (KeyResolverSpi)it.next();
/*      */       
/*  947 */       Node currentChild = this._constructionElement.getFirstChild();
/*  948 */       String uri = getBaseURI();
/*  949 */       while (currentChild != null) {
/*  950 */         if (currentChild.getNodeType() == 1) {
/*  951 */           for (int k = 0; k < storageLength; k++) {
/*  952 */             StorageResolver storage = (StorageResolver)this._storageResolvers.get(k);
/*      */             
/*      */ 
/*  955 */             SecretKey sk = keyResolver.engineLookupAndResolveSecretKey((Element)currentChild, uri, storage);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*  960 */             if (sk != null) {
/*  961 */               return sk;
/*      */             }
/*      */           }
/*      */         }
/*  965 */         currentChild = currentChild.getNextSibling();
/*      */       }
/*      */     }
/*  968 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   SecretKey getSecretKeyFromInternalResolvers()
/*      */     throws KeyResolverException
/*      */   {
/*  979 */     int storageLength = this._storageResolvers.size();
/*  980 */     for (int i = 0; i < lengthInternalKeyResolver(); i++) {
/*  981 */       KeyResolverSpi keyResolver = itemInternalKeyResolver(i);
/*  982 */       if (log.isDebugEnabled()) {
/*  983 */         log.debug("Try " + keyResolver.getClass().getName());
/*      */       }
/*  985 */       Node currentChild = this._constructionElement.getFirstChild();
/*  986 */       String uri = getBaseURI();
/*  987 */       while (currentChild != null) {
/*  988 */         if (currentChild.getNodeType() == 1) {
/*  989 */           for (int k = 0; k < storageLength; k++) {
/*  990 */             StorageResolver storage = (StorageResolver)this._storageResolvers.get(k);
/*      */             
/*      */ 
/*  993 */             SecretKey sk = keyResolver.engineLookupAndResolveSecretKey((Element)currentChild, uri, storage);
/*      */             
/*      */ 
/*  996 */             if (sk != null) {
/*  997 */               return sk;
/*      */             }
/*      */           }
/*      */         }
/* 1001 */         currentChild = currentChild.getNextSibling();
/*      */       }
/*      */     }
/*      */     
/* 1005 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1011 */   List _internalKeyResolvers = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerInternalKeyResolver(KeyResolverSpi realKeyResolver)
/*      */   {
/* 1020 */     if (this._internalKeyResolvers == null) {
/* 1021 */       this._internalKeyResolvers = new ArrayList();
/*      */     }
/* 1023 */     this._internalKeyResolvers.add(realKeyResolver);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   int lengthInternalKeyResolver()
/*      */   {
/* 1031 */     if (this._internalKeyResolvers == null)
/* 1032 */       return 0;
/* 1033 */     return this._internalKeyResolvers.size();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   KeyResolverSpi itemInternalKeyResolver(int i)
/*      */   {
/* 1043 */     return (KeyResolverSpi)this._internalKeyResolvers.get(i);
/*      */   }
/*      */   
/*      */ 
/* 1047 */   List _storageResolvers = nullList;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addStorageResolver(StorageResolver storageResolver)
/*      */   {
/* 1055 */     if (this._storageResolvers == nullList) {
/* 1056 */       this._storageResolvers = new ArrayList();
/*      */     }
/* 1058 */     this._storageResolvers.add(storageResolver);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 1063 */   static boolean _alreadyInitialized = false;
/*      */   
/*      */   public static void init()
/*      */   {
/* 1067 */     if (!_alreadyInitialized) {
/* 1068 */       if (log == null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1074 */         log = LogFactory.getLog(KeyInfo.class.getName());
/*      */         
/*      */ 
/* 1077 */         log.error("Had to assign log in the init() function");
/*      */       }
/*      */       
/*      */ 
/* 1081 */       _alreadyInitialized = true;
/*      */     }
/*      */   }
/*      */   
/*      */   public String getBaseLocalName()
/*      */   {
/* 1087 */     return "KeyInfo";
/*      */   }
/*      */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\KeyInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */