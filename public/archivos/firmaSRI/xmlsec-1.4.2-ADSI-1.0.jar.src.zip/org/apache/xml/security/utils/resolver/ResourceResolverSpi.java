/*     */ package org.apache.xml.security.utils.resolver;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import org.w3c.dom.Attr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ResourceResolverSpi
/*     */ {
/*  41 */   static Log log = LogFactory.getLog(ResourceResolverSpi.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  46 */   protected Map _properties = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract XMLSignatureInput engineResolve(Attr paramAttr, String paramString)
/*     */     throws ResourceResolverException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void engineSetProperty(String key, String value)
/*     */   {
/*  67 */     if (this._properties == null) {
/*  68 */       this._properties = new HashMap();
/*     */     }
/*  70 */     this._properties.put(key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String engineGetProperty(String key)
/*     */   {
/*  80 */     if (this._properties == null) {
/*  81 */       return null;
/*     */     }
/*  83 */     return (String)this._properties.get(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void engineAddProperies(Map properties)
/*     */   {
/*  91 */     if (properties != null) {
/*  92 */       if (this._properties == null) {
/*  93 */         this._properties = new HashMap();
/*     */       }
/*  95 */       this._properties.putAll(properties);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean engineIsThreadSafe()
/*     */   {
/* 105 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean engineIsPrivateData()
/*     */   {
/* 116 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean engineCanResolve(Attr paramAttr, String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] engineGetPropertyKeys()
/*     */   {
/* 134 */     return new String[0];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean understandsProperty(String propertyToTest)
/*     */   {
/* 145 */     String[] understood = engineGetPropertyKeys();
/*     */     
/* 147 */     if (understood != null) {
/* 148 */       for (int i = 0; i < understood.length; i++) {
/* 149 */         if (understood[i].equals(propertyToTest)) {
/* 150 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 155 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String fixURI(String str)
/*     */   {
/* 169 */     str = str.replace(File.separatorChar, '/');
/*     */     
/* 171 */     if (str.length() >= 4)
/*     */     {
/*     */ 
/* 174 */       char ch0 = Character.toUpperCase(str.charAt(0));
/* 175 */       char ch1 = str.charAt(1);
/* 176 */       char ch2 = str.charAt(2);
/* 177 */       char ch3 = str.charAt(3);
/* 178 */       boolean isDosFilename = ('A' <= ch0) && (ch0 <= 'Z') && (ch1 == ':') && (ch2 == '/') && (ch3 != '/');
/*     */       
/*     */ 
/*     */ 
/* 182 */       if ((isDosFilename) && 
/* 183 */         (log.isDebugEnabled())) {
/* 184 */         log.debug("Found DOS filename: " + str);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 189 */     if (str.length() >= 2) {
/* 190 */       char ch1 = str.charAt(1);
/*     */       
/* 192 */       if (ch1 == ':') {
/* 193 */         char ch0 = Character.toUpperCase(str.charAt(0));
/*     */         
/* 195 */         if (('A' <= ch0) && (ch0 <= 'Z')) {
/* 196 */           str = "/" + str;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 202 */     return str;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\utils\resolver\ResourceResolverSpi.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */