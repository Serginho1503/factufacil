/*     */ package org.apache.xml.security.keys.content;
/*     */ 
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.signature.XMLSignatureException;
/*     */ import org.apache.xml.security.transforms.Transforms;
/*     */ import org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RetrievalMethod
/*     */   extends SignatureElementProxy
/*     */   implements KeyInfoContent
/*     */ {
/*     */   public static final String TYPE_DSA = "http://www.w3.org/2000/09/xmldsig#DSAKeyValue";
/*     */   public static final String TYPE_RSA = "http://www.w3.org/2000/09/xmldsig#RSAKeyValue";
/*     */   public static final String TYPE_PGP = "http://www.w3.org/2000/09/xmldsig#PGPData";
/*     */   public static final String TYPE_SPKI = "http://www.w3.org/2000/09/xmldsig#SPKIData";
/*     */   public static final String TYPE_MGMT = "http://www.w3.org/2000/09/xmldsig#MgmtData";
/*     */   public static final String TYPE_X509 = "http://www.w3.org/2000/09/xmldsig#X509Data";
/*     */   public static final String TYPE_RAWX509 = "http://www.w3.org/2000/09/xmldsig#rawX509Certificate";
/*     */   
/*     */   public RetrievalMethod(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  62 */     super(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RetrievalMethod(Document doc, String URI, Transforms transforms, String Type)
/*     */   {
/*  76 */     super(doc);
/*     */     
/*  78 */     this._constructionElement.setAttributeNS(null, "URI", URI);
/*     */     
/*  80 */     if (Type != null) {
/*  81 */       this._constructionElement.setAttributeNS(null, "Type", Type);
/*     */     }
/*     */     
/*  84 */     if (transforms != null) {
/*  85 */       this._constructionElement.appendChild(transforms.getElement());
/*  86 */       XMLUtils.addReturnToElement(this._constructionElement);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Attr getURIAttr()
/*     */   {
/*  96 */     return this._constructionElement.getAttributeNodeNS(null, "URI");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getURI()
/*     */   {
/* 106 */     return getURIAttr().getNodeValue();
/*     */   }
/*     */   
/*     */   public String getType()
/*     */   {
/* 111 */     return this._constructionElement.getAttributeNS(null, "Type");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Transforms getTransforms()
/*     */     throws XMLSecurityException
/*     */   {
/*     */     try
/*     */     {
/* 124 */       Element transformsElem = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), "Transforms", 0);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 129 */       if (transformsElem != null) {
/* 130 */         return new Transforms(transformsElem, this._baseURI);
/*     */       }
/*     */       
/* 133 */       return null;
/*     */     } catch (XMLSignatureException ex) {
/* 135 */       throw new XMLSecurityException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 141 */     return "RetrievalMethod";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\content\RetrievalMethod.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */