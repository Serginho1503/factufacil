/*     */ package org.apache.xml.security;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.algorithms.JCEMapper;
/*     */ import org.apache.xml.security.algorithms.SignatureAlgorithm;
/*     */ import org.apache.xml.security.c14n.Canonicalizer;
/*     */ import org.apache.xml.security.keys.KeyInfo;
/*     */ import org.apache.xml.security.keys.keyresolver.KeyResolver;
/*     */ import org.apache.xml.security.transforms.Transform;
/*     */ import org.apache.xml.security.utils.ElementProxy;
/*     */ import org.apache.xml.security.utils.I18n;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.apache.xml.security.utils.resolver.ResourceResolver;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Init
/*     */ {
/*  52 */   static Log log = LogFactory.getLog(Init.class.getName());
/*     */   
/*     */ 
/*     */ 
/*  56 */   private static boolean _alreadyInitialized = false;
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String CONF_NS = "http://www.xmlsecurity.org/NS/#configuration";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final boolean isInitialized()
/*     */   {
/*  67 */     return _alreadyInitialized;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized void init()
/*     */   {
/*  76 */     if (_alreadyInitialized) {
/*  77 */       return;
/*     */     }
/*  79 */     long XX_configure_i18n_end = 0L;
/*  80 */     long XX_configure_reg_c14n_start = 0L;
/*  81 */     long XX_configure_reg_c14n_end = 0L;
/*  82 */     long XX_configure_reg_jcemapper_end = 0L;
/*  83 */     long XX_configure_reg_keyInfo_start = 0L;
/*  84 */     long XX_configure_reg_keyResolver_end = 0L;
/*  85 */     long XX_configure_reg_prefixes_start = 0L;
/*  86 */     long XX_configure_reg_resourceresolver_start = 0L;
/*  87 */     long XX_configure_reg_sigalgos_end = 0L;
/*  88 */     long XX_configure_reg_transforms_end = 0L;
/*  89 */     long XX_configure_reg_keyInfo_end = 0L;
/*  90 */     long XX_configure_reg_keyResolver_start = 0L;
/*  91 */     _alreadyInitialized = true;
/*     */     try
/*     */     {
/*  94 */       long XX_init_start = System.currentTimeMillis();
/*  95 */       long XX_prng_start = System.currentTimeMillis();
/*     */       
/*     */ 
/*     */ 
/*  99 */       long XX_prng_end = System.currentTimeMillis();
/*     */       
/*     */ 
/* 102 */       long XX_parsing_start = System.currentTimeMillis();
/* 103 */       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/*     */       
/* 105 */       dbf.setNamespaceAware(true);
/* 106 */       dbf.setValidating(false);
/*     */       
/* 108 */       DocumentBuilder db = dbf.newDocumentBuilder();
/*     */       
/* 110 */       InputStream is = (InputStream)AccessController.doPrivileged(new PrivilegedAction()
/*     */       {
/*     */         public Object run() {
/* 113 */           String cfile = System.getProperty("org.apache.xml.security.resource.config");
/*     */           
/* 115 */           return getClass().getResourceAsStream(cfile != null ? cfile : "resource/config.xml");
/*     */         }
/*     */         
/*     */ 
/* 119 */       });
/* 120 */       Document doc = db.parse(is);
/* 121 */       long XX_parsing_end = System.currentTimeMillis();
/* 122 */       long XX_configure_i18n_start = 0L;
/*     */       
/*     */ 
/* 125 */       XX_configure_reg_keyInfo_start = System.currentTimeMillis();
/*     */       try {
/* 127 */         KeyInfo.init();
/*     */       } catch (Exception e) {
/* 129 */         e.printStackTrace();
/*     */         
/* 131 */         throw e;
/*     */       }
/* 133 */       XX_configure_reg_keyInfo_end = System.currentTimeMillis();
/*     */       
/*     */ 
/* 136 */       long XX_configure_reg_transforms_start = 0L;
/* 137 */       long XX_configure_reg_jcemapper_start = 0L;
/* 138 */       long XX_configure_reg_sigalgos_start = 0L;
/* 139 */       long XX_configure_reg_resourceresolver_end = 0L;
/* 140 */       long XX_configure_reg_prefixes_end = 0L;
/* 141 */       Node config = doc.getFirstChild();
/* 142 */       while ((config != null) && 
/* 143 */         (!"Configuration".equals(config.getLocalName()))) {
/* 142 */         config = config.getNextSibling();
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 147 */       for (Node el = config.getFirstChild(); el != null; el = el.getNextSibling()) {
/* 148 */         if ((el instanceof Element))
/*     */         {
/*     */ 
/* 151 */           String tag = el.getLocalName();
/* 152 */           if (tag.equals("ResourceBundles")) {
/* 153 */             XX_configure_i18n_start = System.currentTimeMillis();
/* 154 */             Element resource = (Element)el;
/*     */             
/* 156 */             Attr langAttr = resource.getAttributeNode("defaultLanguageCode");
/* 157 */             Attr countryAttr = resource.getAttributeNode("defaultCountryCode");
/* 158 */             String languageCode = langAttr == null ? null : langAttr.getNodeValue();
/*     */             
/*     */ 
/* 161 */             String countryCode = countryAttr == null ? null : countryAttr.getNodeValue();
/*     */             
/*     */ 
/*     */ 
/* 165 */             I18n.init(languageCode, countryCode);
/* 166 */             XX_configure_i18n_end = System.currentTimeMillis();
/*     */           }
/*     */           
/* 169 */           if (tag.equals("CanonicalizationMethods")) {
/* 170 */             XX_configure_reg_c14n_start = System.currentTimeMillis();
/* 171 */             Canonicalizer.init();
/* 172 */             Element[] list = XMLUtils.selectNodes(el.getFirstChild(), "http://www.xmlsecurity.org/NS/#configuration", "CanonicalizationMethod");
/*     */             
/* 174 */             for (int i = 0; i < list.length; i++) {
/* 175 */               String URI = list[i].getAttributeNS(null, "URI");
/*     */               
/* 177 */               String JAVACLASS = list[i].getAttributeNS(null, "JAVACLASS");
/*     */               
/*     */               try
/*     */               {
/* 181 */                 Class.forName(JAVACLASS);
/*     */                 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 192 */                 if (log.isDebugEnabled()) {
/* 193 */                   log.debug("Canonicalizer.register(" + URI + ", " + JAVACLASS + ")");
/*     */                 }
/* 195 */                 Canonicalizer.register(URI, JAVACLASS);
/*     */               } catch (ClassNotFoundException e) {
/* 197 */                 Object[] exArgs = { URI, JAVACLASS };
/*     */                 
/* 199 */                 log.fatal(I18n.translate("algorithm.classDoesNotExist", exArgs));
/*     */               }
/*     */             }
/*     */             
/* 203 */             XX_configure_reg_c14n_end = System.currentTimeMillis();
/*     */           }
/*     */           
/* 206 */           if (tag.equals("TransformAlgorithms")) {
/* 207 */             XX_configure_reg_transforms_start = System.currentTimeMillis();
/* 208 */             Transform.init();
/*     */             
/* 210 */             Element[] tranElem = XMLUtils.selectNodes(el.getFirstChild(), "http://www.xmlsecurity.org/NS/#configuration", "TransformAlgorithm");
/*     */             
/* 212 */             for (int i = 0; i < tranElem.length; i++) {
/* 213 */               String URI = tranElem[i].getAttributeNS(null, "URI");
/*     */               
/* 215 */               String JAVACLASS = tranElem[i].getAttributeNS(null, "JAVACLASS");
/*     */               
/*     */               try
/*     */               {
/* 219 */                 Class.forName(JAVACLASS);
/* 220 */                 if (log.isDebugEnabled()) {
/* 221 */                   log.debug("Transform.register(" + URI + ", " + JAVACLASS + ")");
/*     */                 }
/* 223 */                 Transform.register(URI, JAVACLASS);
/*     */               } catch (ClassNotFoundException e) {
/* 225 */                 Object[] exArgs = { URI, JAVACLASS };
/*     */                 
/* 227 */                 log.fatal(I18n.translate("algorithm.classDoesNotExist", exArgs));
/*     */               }
/*     */               catch (NoClassDefFoundError ex)
/*     */               {
/* 231 */                 log.warn("Not able to found dependecies for algorithm, I'm keep working.");
/*     */               }
/*     */             }
/* 234 */             XX_configure_reg_transforms_end = System.currentTimeMillis();
/*     */           }
/*     */           
/*     */ 
/* 238 */           if ("JCEAlgorithmMappings".equals(tag)) {
/* 239 */             XX_configure_reg_jcemapper_start = System.currentTimeMillis();
/* 240 */             JCEMapper.init((Element)el);
/* 241 */             XX_configure_reg_jcemapper_end = System.currentTimeMillis();
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 246 */           if (tag.equals("SignatureAlgorithms")) {
/* 247 */             XX_configure_reg_sigalgos_start = System.currentTimeMillis();
/* 248 */             SignatureAlgorithm.providerInit();
/*     */             
/* 250 */             Element[] sigElems = XMLUtils.selectNodes(el.getFirstChild(), "http://www.xmlsecurity.org/NS/#configuration", "SignatureAlgorithm");
/*     */             
/*     */ 
/* 253 */             for (int i = 0; i < sigElems.length; i++) {
/* 254 */               String URI = sigElems[i].getAttributeNS(null, "URI");
/*     */               
/* 256 */               String JAVACLASS = sigElems[i].getAttributeNS(null, "JAVACLASS");
/*     */               
/*     */ 
/*     */ 
/*     */ 
/*     */               try
/*     */               {
/* 263 */                 Class.forName(JAVACLASS);
/*     */                 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 274 */                 if (log.isDebugEnabled()) {
/* 275 */                   log.debug("SignatureAlgorithm.register(" + URI + ", " + JAVACLASS + ")");
/*     */                 }
/* 277 */                 SignatureAlgorithm.register(URI, JAVACLASS);
/*     */               } catch (ClassNotFoundException e) {
/* 279 */                 Object[] exArgs = { URI, JAVACLASS };
/*     */                 
/* 281 */                 log.fatal(I18n.translate("algorithm.classDoesNotExist", exArgs));
/*     */               }
/*     */             }
/*     */             
/*     */ 
/* 286 */             XX_configure_reg_sigalgos_end = System.currentTimeMillis();
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 291 */           if (tag.equals("ResourceResolvers")) {
/* 292 */             XX_configure_reg_resourceresolver_start = System.currentTimeMillis();
/* 293 */             ResourceResolver.init();
/*     */             
/* 295 */             Element[] resolverElem = XMLUtils.selectNodes(el.getFirstChild(), "http://www.xmlsecurity.org/NS/#configuration", "Resolver");
/*     */             
/*     */ 
/* 298 */             for (int i = 0; i < resolverElem.length; i++) {
/* 299 */               String JAVACLASS = resolverElem[i].getAttributeNS(null, "JAVACLASS");
/*     */               
/*     */ 
/* 302 */               String Description = resolverElem[i].getAttributeNS(null, "DESCRIPTION");
/*     */               
/*     */ 
/*     */ 
/* 306 */               if ((Description != null) && (Description.length() > 0)) {
/* 307 */                 if (log.isDebugEnabled()) {
/* 308 */                   log.debug("Register Resolver: " + JAVACLASS + ": " + Description);
/*     */                 }
/*     */               }
/* 311 */               else if (log.isDebugEnabled()) {
/* 312 */                 log.debug("Register Resolver: " + JAVACLASS + ": For unknown purposes");
/*     */               }
/*     */               try
/*     */               {
/* 316 */                 ResourceResolver.register(JAVACLASS);
/*     */               } catch (Throwable e) {
/* 318 */                 log.warn("Cannot register:" + JAVACLASS + " perhaps some needed jars are not installed", e);
/*     */               }
/* 320 */               XX_configure_reg_resourceresolver_end = System.currentTimeMillis();
/*     */             }
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 331 */           if (tag.equals("KeyResolver")) {
/* 332 */             XX_configure_reg_keyResolver_start = System.currentTimeMillis();
/* 333 */             KeyResolver.init();
/*     */             
/* 335 */             Element[] resolverElem = XMLUtils.selectNodes(el.getFirstChild(), "http://www.xmlsecurity.org/NS/#configuration", "Resolver");
/*     */             
/* 337 */             for (int i = 0; i < resolverElem.length; i++) {
/* 338 */               String JAVACLASS = resolverElem[i].getAttributeNS(null, "JAVACLASS");
/*     */               
/*     */ 
/* 341 */               String Description = resolverElem[i].getAttributeNS(null, "DESCRIPTION");
/*     */               
/*     */ 
/*     */ 
/* 345 */               if ((Description != null) && (Description.length() > 0)) {
/* 346 */                 if (log.isDebugEnabled()) {
/* 347 */                   log.debug("Register Resolver: " + JAVACLASS + ": " + Description);
/*     */                 }
/*     */               }
/* 350 */               else if (log.isDebugEnabled()) {
/* 351 */                 log.debug("Register Resolver: " + JAVACLASS + ": For unknown purposes");
/*     */               }
/*     */               
/*     */ 
/* 355 */               KeyResolver.register(JAVACLASS);
/*     */             }
/* 357 */             XX_configure_reg_keyResolver_end = System.currentTimeMillis();
/*     */           }
/*     */           
/*     */ 
/* 361 */           if (tag.equals("PrefixMappings")) {
/* 362 */             XX_configure_reg_prefixes_start = System.currentTimeMillis();
/* 363 */             if (log.isDebugEnabled()) {
/* 364 */               log.debug("Now I try to bind prefixes:");
/*     */             }
/* 366 */             Element[] nl = XMLUtils.selectNodes(el.getFirstChild(), "http://www.xmlsecurity.org/NS/#configuration", "PrefixMapping");
/*     */             
/* 368 */             for (int i = 0; i < nl.length; i++) {
/* 369 */               String namespace = nl[i].getAttributeNS(null, "namespace");
/*     */               
/* 371 */               String prefix = nl[i].getAttributeNS(null, "prefix");
/*     */               
/* 373 */               if (log.isDebugEnabled())
/* 374 */                 log.debug("Now I try to bind " + prefix + " to " + namespace);
/* 375 */               ElementProxy.setDefaultPrefix(namespace, prefix);
/*     */             }
/*     */             
/* 378 */             XX_configure_reg_prefixes_end = System.currentTimeMillis();
/*     */           }
/*     */         }
/*     */       }
/* 382 */       long XX_init_end = System.currentTimeMillis();
/*     */       
/*     */ 
/* 385 */       if (log.isDebugEnabled()) {
/* 386 */         log.debug("XX_init                             " + (int)(XX_init_end - XX_init_start) + " ms");
/* 387 */         log.debug("  XX_prng                           " + (int)(XX_prng_end - XX_prng_start) + " ms");
/* 388 */         log.debug("  XX_parsing                        " + (int)(XX_parsing_end - XX_parsing_start) + " ms");
/* 389 */         log.debug("  XX_configure_i18n                 " + (int)(XX_configure_i18n_end - XX_configure_i18n_start) + " ms");
/* 390 */         log.debug("  XX_configure_reg_c14n             " + (int)(XX_configure_reg_c14n_end - XX_configure_reg_c14n_start) + " ms");
/* 391 */         log.debug("  XX_configure_reg_jcemapper        " + (int)(XX_configure_reg_jcemapper_end - XX_configure_reg_jcemapper_start) + " ms");
/* 392 */         log.debug("  XX_configure_reg_keyInfo          " + (int)(XX_configure_reg_keyInfo_end - XX_configure_reg_keyInfo_start) + " ms");
/* 393 */         log.debug("  XX_configure_reg_keyResolver      " + (int)(XX_configure_reg_keyResolver_end - XX_configure_reg_keyResolver_start) + " ms");
/* 394 */         log.debug("  XX_configure_reg_prefixes         " + (int)(XX_configure_reg_prefixes_end - XX_configure_reg_prefixes_start) + " ms");
/* 395 */         log.debug("  XX_configure_reg_resourceresolver " + (int)(XX_configure_reg_resourceresolver_end - XX_configure_reg_resourceresolver_start) + " ms");
/* 396 */         log.debug("  XX_configure_reg_sigalgos         " + (int)(XX_configure_reg_sigalgos_end - XX_configure_reg_sigalgos_start) + " ms");
/* 397 */         log.debug("  XX_configure_reg_transforms       " + (int)(XX_configure_reg_transforms_end - XX_configure_reg_transforms_start) + " ms");
/*     */       }
/*     */     } catch (Exception e) {
/* 400 */       log.fatal("Bad: ", e);
/* 401 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\Init.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */