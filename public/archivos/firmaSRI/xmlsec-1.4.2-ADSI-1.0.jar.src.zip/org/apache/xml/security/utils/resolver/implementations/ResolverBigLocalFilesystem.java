/*    */ package org.apache.xml.security.utils.resolver.implementations;
/*    */ 
/*    */ import org.apache.xml.security.signature.XMLSignatureInput;
/*    */ import org.apache.xml.security.utils.resolver.ResourceResolverException;
/*    */ import org.apache.xml.utils.URI;
/*    */ import org.w3c.dom.Attr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResolverBigLocalFilesystem
/*    */   extends ResolverLocalFilesystem
/*    */ {
/*    */   public XMLSignatureInput engineResolve(Attr uri, String BaseURI)
/*    */     throws ResourceResolverException
/*    */   {
/*    */     try
/*    */     {
/* 30 */       URI uriNew = getNewURI(uri.getNodeValue(), BaseURI);
/*    */       
/*    */ 
/* 33 */       URI uriNewNoFrag = new URI(uriNew);
/*    */       
/* 35 */       uriNewNoFrag.setFragment(null);
/*    */       
/* 37 */       String fileName = ResolverLocalFilesystem.translateUriToFilename(uriNewNoFrag.toString());
/*    */       
/*    */ 
/* 40 */       ReseteableFileInputStream inputStream = new ReseteableFileInputStream(fileName);
/* 41 */       XMLSignatureInput result = new XMLSignatureInput(inputStream);
/*    */       
/* 43 */       result.setSourceURI(uriNew.toString());
/*    */       
/* 45 */       return result;
/*    */     } catch (Exception e) {
/* 47 */       throw new ResourceResolverException("generic.EmptyMessage", e, uri, BaseURI);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\utils\resolver\implementations\ResolverBigLocalFilesystem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */