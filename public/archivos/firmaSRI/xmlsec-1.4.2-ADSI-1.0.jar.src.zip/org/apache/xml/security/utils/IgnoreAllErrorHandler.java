/*    */ package org.apache.xml.security.utils;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.xml.sax.ErrorHandler;
/*    */ import org.xml.sax.SAXException;
/*    */ import org.xml.sax.SAXParseException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IgnoreAllErrorHandler
/*    */   implements ErrorHandler
/*    */ {
/* 34 */   static Log log = LogFactory.getLog(IgnoreAllErrorHandler.class.getName());
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 39 */   static final boolean warnOnExceptions = System.getProperty("org.apache.xml.security.test.warn.on.exceptions", "false").equals("true");
/*    */   
/*    */ 
/*    */ 
/* 43 */   static final boolean throwExceptions = System.getProperty("org.apache.xml.security.test.throw.exceptions", "false").equals("true");
/*    */   
/*    */ 
/*    */   public void warning(SAXParseException ex)
/*    */     throws SAXException
/*    */   {
/* 49 */     if (warnOnExceptions) {
/* 50 */       log.warn("", ex);
/*    */     }
/* 52 */     if (throwExceptions) {
/* 53 */       throw ex;
/*    */     }
/*    */   }
/*    */   
/*    */   public void error(SAXParseException ex)
/*    */     throws SAXException
/*    */   {
/* 60 */     if (warnOnExceptions) {
/* 61 */       log.error("", ex);
/*    */     }
/* 63 */     if (throwExceptions) {
/* 64 */       throw ex;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public void fatalError(SAXParseException ex)
/*    */     throws SAXException
/*    */   {
/* 72 */     if (warnOnExceptions) {
/* 73 */       log.warn("", ex);
/*    */     }
/* 75 */     if (throwExceptions) {
/* 76 */       throw ex;
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\utils\IgnoreAllErrorHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */