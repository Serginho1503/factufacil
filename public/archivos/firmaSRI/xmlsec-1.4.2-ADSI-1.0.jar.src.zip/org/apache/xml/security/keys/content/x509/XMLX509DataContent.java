package org.apache.xml.security.keys.content.x509;

public abstract interface XMLX509DataContent {}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\content\x509\XMLX509DataContent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */