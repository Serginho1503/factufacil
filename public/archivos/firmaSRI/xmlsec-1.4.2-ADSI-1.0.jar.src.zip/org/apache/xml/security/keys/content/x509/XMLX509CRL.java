/*    */ package org.apache.xml.security.keys.content.x509;
/*    */ 
/*    */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*    */ import org.apache.xml.security.utils.SignatureElementProxy;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMLX509CRL
/*    */   extends SignatureElementProxy
/*    */   implements XMLX509DataContent
/*    */ {
/*    */   public XMLX509CRL(Element element, String BaseURI)
/*    */     throws XMLSecurityException
/*    */   {
/* 42 */     super(element, BaseURI);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public XMLX509CRL(Document doc, byte[] crlBytes)
/*    */   {
/* 53 */     super(doc);
/*    */     
/* 55 */     addBase64Text(crlBytes);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getCRLBytes()
/*    */     throws XMLSecurityException
/*    */   {
/* 65 */     return getBytesFromTextChild();
/*    */   }
/*    */   
/*    */   public String getBaseLocalName()
/*    */   {
/* 70 */     return "X509CRL";
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\content\x509\XMLX509CRL.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */