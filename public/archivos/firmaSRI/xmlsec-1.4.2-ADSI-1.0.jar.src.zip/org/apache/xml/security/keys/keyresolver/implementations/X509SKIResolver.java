/*     */ package org.apache.xml.security.keys.keyresolver.implementations;
/*     */ 
/*     */ import java.security.Principal;
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.crypto.SecretKey;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.keys.content.x509.XMLX509SKI;
/*     */ import org.apache.xml.security.keys.keyresolver.KeyResolverException;
/*     */ import org.apache.xml.security.keys.keyresolver.KeyResolverSpi;
/*     */ import org.apache.xml.security.keys.storage.StorageResolver;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class X509SKIResolver
/*     */   extends KeyResolverSpi
/*     */ {
/*  44 */   static Log log = LogFactory.getLog(X509SKIResolver.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PublicKey engineLookupAndResolvePublicKey(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/*  61 */     X509Certificate cert = engineLookupResolveX509Certificate(element, BaseURI, storage);
/*     */     
/*     */ 
/*  64 */     if (cert != null) {
/*  65 */       return cert.getPublicKey();
/*     */     }
/*     */     
/*  68 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Certificate engineLookupResolveX509Certificate(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/*  83 */     if (log.isDebugEnabled()) {
/*  84 */       log.debug("Can I resolve " + element.getTagName() + "?");
/*     */     }
/*  86 */     if (!XMLUtils.elementIsInSignatureSpace(element, "X509Data"))
/*     */     {
/*  88 */       log.debug("I can't");
/*  89 */       return null;
/*     */     }
/*     */     
/*  92 */     XMLX509SKI[] x509childObject = null;
/*     */     
/*  94 */     Element[] x509childNodes = null;
/*  95 */     x509childNodes = XMLUtils.selectDsNodes(element.getFirstChild(), "X509SKI");
/*     */     
/*     */ 
/*  98 */     if ((x509childNodes == null) || (x509childNodes.length <= 0))
/*     */     {
/* 100 */       log.debug("I can't");
/* 101 */       return null;
/*     */     }
/*     */     try {
/* 104 */       if (storage == null) {
/* 105 */         Object[] exArgs = { "X509SKI" };
/* 106 */         KeyResolverException ex = new KeyResolverException("KeyResolver.needStorageResolver", exArgs);
/*     */         
/*     */ 
/*     */ 
/* 110 */         log.info("", ex);
/*     */         
/* 112 */         throw ex;
/*     */       }
/*     */       
/* 115 */       x509childObject = new XMLX509SKI[x509childNodes.length];
/*     */       
/* 117 */       for (int i = 0; i < x509childNodes.length; i++) {
/* 118 */         x509childObject[i] = new XMLX509SKI(x509childNodes[i], BaseURI);
/*     */       }
/*     */       
/*     */ 
/* 122 */       while (storage.hasNext()) {
/* 123 */         X509Certificate cert = storage.next();
/* 124 */         XMLX509SKI certSKI = new XMLX509SKI(element.getOwnerDocument(), cert);
/*     */         
/* 126 */         for (int i = 0; i < x509childObject.length; i++) {
/* 127 */           if (certSKI.equals(x509childObject[i])) {
/* 128 */             log.debug("Return PublicKey from " + cert.getSubjectDN().getName());
/*     */             
/*     */ 
/* 131 */             return cert;
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (XMLSecurityException ex) {
/* 136 */       throw new KeyResolverException("empty", ex);
/*     */     }
/*     */     
/* 139 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SecretKey engineLookupAndResolveSecretKey(Element element, String BaseURI, StorageResolver storage)
/*     */   {
/* 153 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\keyresolver\implementations\X509SKIResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */