/*    */ package org.apache.xml.security.signature;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReferenceNotInitializedException
/*    */   extends XMLSignatureException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ReferenceNotInitializedException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ReferenceNotInitializedException(String _msgID)
/*    */   {
/* 51 */     super(_msgID);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ReferenceNotInitializedException(String _msgID, Object[] exArgs)
/*    */   {
/* 61 */     super(_msgID, exArgs);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ReferenceNotInitializedException(String _msgID, Exception _originalException)
/*    */   {
/* 72 */     super(_msgID, _originalException);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ReferenceNotInitializedException(String _msgID, Object[] exArgs, Exception _originalException)
/*    */   {
/* 84 */     super(_msgID, exArgs, _originalException);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\signature\ReferenceNotInitializedException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */