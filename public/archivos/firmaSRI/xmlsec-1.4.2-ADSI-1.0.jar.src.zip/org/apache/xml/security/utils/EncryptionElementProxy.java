/*    */ package org.apache.xml.security.utils;
/*    */ 
/*    */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class EncryptionElementProxy
/*    */   extends ElementProxy
/*    */ {
/*    */   public EncryptionElementProxy(Document doc)
/*    */   {
/* 40 */     super(doc);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public EncryptionElementProxy(Element element, String BaseURI)
/*    */     throws XMLSecurityException
/*    */   {
/* 52 */     super(element, BaseURI);
/*    */   }
/*    */   
/*    */   public final String getBaseNamespace()
/*    */   {
/* 57 */     return "http://www.w3.org/2001/04/xmlenc#";
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\utils\EncryptionElementProxy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */