/*     */ package org.apache.xml.security.keys.keyresolver.implementations;
/*     */ 
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.crypto.SecretKey;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.keys.content.x509.XMLX509SubjectName;
/*     */ import org.apache.xml.security.keys.keyresolver.KeyResolverException;
/*     */ import org.apache.xml.security.keys.keyresolver.KeyResolverSpi;
/*     */ import org.apache.xml.security.keys.storage.StorageResolver;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class X509SubjectNameResolver
/*     */   extends KeyResolverSpi
/*     */ {
/*  42 */   static Log log = LogFactory.getLog(X509SubjectNameResolver.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PublicKey engineLookupAndResolvePublicKey(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/*  60 */     X509Certificate cert = engineLookupResolveX509Certificate(element, BaseURI, storage);
/*     */     
/*     */ 
/*  63 */     if (cert != null) {
/*  64 */       return cert.getPublicKey();
/*     */     }
/*     */     
/*  67 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Certificate engineLookupResolveX509Certificate(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/*  82 */     if (log.isDebugEnabled())
/*  83 */       log.debug("Can I resolve " + element.getTagName() + "?");
/*  84 */     Element[] x509childNodes = null;
/*  85 */     XMLX509SubjectName[] x509childObject = null;
/*     */     
/*  87 */     if (!XMLUtils.elementIsInSignatureSpace(element, "X509Data"))
/*     */     {
/*  89 */       log.debug("I can't");
/*  90 */       return null;
/*     */     }
/*  92 */     x509childNodes = XMLUtils.selectDsNodes(element.getFirstChild(), "X509SubjectName");
/*     */     
/*     */ 
/*  95 */     if ((x509childNodes == null) || (x509childNodes.length <= 0))
/*     */     {
/*  97 */       log.debug("I can't");
/*  98 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 102 */       if (storage == null) {
/* 103 */         Object[] exArgs = { "X509SubjectName" };
/* 104 */         KeyResolverException ex = new KeyResolverException("KeyResolver.needStorageResolver", exArgs);
/*     */         
/*     */ 
/*     */ 
/* 108 */         log.info("", ex);
/*     */         
/* 110 */         throw ex;
/*     */       }
/*     */       
/* 113 */       x509childObject = new XMLX509SubjectName[x509childNodes.length];
/*     */       
/*     */ 
/* 116 */       for (int i = 0; i < x509childNodes.length; i++) {
/* 117 */         x509childObject[i] = new XMLX509SubjectName(x509childNodes[i], BaseURI);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 122 */       while (storage.hasNext()) {
/* 123 */         X509Certificate cert = storage.next();
/* 124 */         XMLX509SubjectName certSN = new XMLX509SubjectName(element.getOwnerDocument(), cert);
/*     */         
/*     */ 
/* 127 */         log.debug("Found Certificate SN: " + certSN.getSubjectName());
/*     */         
/* 129 */         for (int i = 0; i < x509childObject.length; i++) {
/* 130 */           log.debug("Found Element SN:     " + x509childObject[i].getSubjectName());
/*     */           
/*     */ 
/* 133 */           if (certSN.equals(x509childObject[i])) {
/* 134 */             log.debug("match !!! ");
/*     */             
/* 136 */             return cert;
/*     */           }
/* 138 */           log.debug("no match...");
/*     */         }
/*     */       }
/*     */       
/* 142 */       return null;
/*     */     } catch (XMLSecurityException ex) {
/* 144 */       log.debug("XMLSecurityException", ex);
/*     */       
/* 146 */       throw new KeyResolverException("generic.EmptyMessage", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SecretKey engineLookupAndResolveSecretKey(Element element, String BaseURI, StorageResolver storage)
/*     */   {
/* 161 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\keyresolver\implementations\X509SubjectNameResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */