/*    */ package org.apache.xml.security.utils.resolver.implementations;
/*    */ 
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.apache.xml.security.signature.XMLSignatureInput;
/*    */ import org.apache.xml.security.utils.resolver.ResourceResolverSpi;
/*    */ import org.w3c.dom.Attr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResolverAnonymous
/*    */   extends ResourceResolverSpi
/*    */ {
/* 36 */   private XMLSignatureInput _input = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ResolverAnonymous(String filename)
/*    */     throws FileNotFoundException, IOException
/*    */   {
/* 44 */     this._input = new XMLSignatureInput(new FileInputStream(filename));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public ResolverAnonymous(InputStream is)
/*    */   {
/* 51 */     this._input = new XMLSignatureInput(is);
/*    */   }
/*    */   
/*    */   public XMLSignatureInput engineResolve(Attr uri, String BaseURI)
/*    */   {
/* 56 */     return this._input;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean engineCanResolve(Attr uri, String BaseURI)
/*    */   {
/* 63 */     if (uri == null) {
/* 64 */       return true;
/*    */     }
/* 66 */     return false;
/*    */   }
/*    */   
/*    */   public String[] engineGetPropertyKeys()
/*    */   {
/* 71 */     return new String[0];
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\utils\resolver\implementations\ResolverAnonymous.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */