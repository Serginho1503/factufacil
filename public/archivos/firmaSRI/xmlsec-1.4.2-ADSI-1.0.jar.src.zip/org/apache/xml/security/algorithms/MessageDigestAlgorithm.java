/*     */ package org.apache.xml.security.algorithms;
/*     */ 
/*     */ import java.security.DigestException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.Provider;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.xml.security.signature.XMLSignatureException;
/*     */ import org.w3c.dom.Document;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageDigestAlgorithm
/*     */   extends Algorithm
/*     */ {
/*     */   public static final String ALGO_ID_DIGEST_NOT_RECOMMENDED_MD5 = "http://www.w3.org/2001/04/xmldsig-more#md5";
/*     */   public static final String ALGO_ID_DIGEST_SHA1 = "http://www.w3.org/2000/09/xmldsig#sha1";
/*     */   public static final String ALGO_ID_DIGEST_SHA256 = "http://www.w3.org/2001/04/xmlenc#sha256";
/*     */   public static final String ALGO_ID_DIGEST_SHA384 = "http://www.w3.org/2001/04/xmldsig-more#sha384";
/*     */   public static final String ALGO_ID_DIGEST_SHA512 = "http://www.w3.org/2001/04/xmlenc#sha512";
/*     */   public static final String ALGO_ID_DIGEST_RIPEMD160 = "http://www.w3.org/2001/04/xmlenc#ripemd160";
/*  54 */   MessageDigest algorithm = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private MessageDigestAlgorithm(Document doc, MessageDigest messageDigest, String algorithmURI)
/*     */   {
/*  65 */     super(doc, algorithmURI);
/*     */     
/*  67 */     this.algorithm = messageDigest;
/*     */   }
/*     */   
/*  70 */   static ThreadLocal instances = new ThreadLocal() {
/*     */     protected Object initialValue() {
/*  72 */       return new HashMap();
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MessageDigestAlgorithm getInstance(Document doc, String algorithmURI)
/*     */     throws XMLSignatureException
/*     */   {
/*  86 */     MessageDigest md = getDigestInstance(algorithmURI);
/*  87 */     return new MessageDigestAlgorithm(doc, md, algorithmURI);
/*     */   }
/*     */   
/*     */   private static MessageDigest getDigestInstance(String algorithmURI) throws XMLSignatureException {
/*  91 */     MessageDigest result = (MessageDigest)((Map)instances.get()).get(algorithmURI);
/*  92 */     if (result != null)
/*  93 */       return result;
/*  94 */     String algorithmID = JCEMapper.translateURItoJCEID(algorithmURI);
/*     */     
/*  96 */     if (algorithmID == null) {
/*  97 */       Object[] exArgs = { algorithmURI };
/*  98 */       throw new XMLSignatureException("algorithms.NoSuchMap", exArgs);
/*     */     }
/*     */     
/*     */ 
/* 102 */     String provider = JCEMapper.getProviderId();
/*     */     MessageDigest md;
/* 104 */     try { MessageDigest md; if (provider == null) {
/* 105 */         md = MessageDigest.getInstance(algorithmID);
/*     */       } else {
/* 107 */         md = MessageDigest.getInstance(algorithmID, provider);
/*     */       }
/*     */     } catch (NoSuchAlgorithmException ex) {
/* 110 */       Object[] exArgs = { algorithmID, ex.getLocalizedMessage() };
/*     */       
/*     */ 
/* 113 */       throw new XMLSignatureException("algorithms.NoSuchAlgorithm", exArgs);
/*     */     } catch (NoSuchProviderException ex) {
/* 115 */       Object[] exArgs = { algorithmID, ex.getLocalizedMessage() };
/*     */       
/*     */ 
/* 118 */       throw new XMLSignatureException("algorithms.NoSuchAlgorithm", exArgs);
/*     */     }
/* 120 */     ((Map)instances.get()).put(algorithmURI, md);
/* 121 */     return md;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MessageDigest getAlgorithm()
/*     */   {
/* 130 */     return this.algorithm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isEqual(byte[] digesta, byte[] digestb)
/*     */   {
/* 142 */     return MessageDigest.isEqual(digesta, digestb);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] digest()
/*     */   {
/* 152 */     return this.algorithm.digest();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] digest(byte[] input)
/*     */   {
/* 163 */     return this.algorithm.digest(input);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int digest(byte[] buf, int offset, int len)
/*     */     throws DigestException
/*     */   {
/* 178 */     return this.algorithm.digest(buf, offset, len);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getJCEAlgorithmString()
/*     */   {
/* 188 */     return this.algorithm.getAlgorithm();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Provider getJCEProvider()
/*     */   {
/* 198 */     return this.algorithm.getProvider();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDigestLength()
/*     */   {
/* 208 */     return this.algorithm.getDigestLength();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/* 217 */     this.algorithm.reset();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void update(byte[] input)
/*     */   {
/* 227 */     this.algorithm.update(input);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void update(byte input)
/*     */   {
/* 237 */     this.algorithm.update(input);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void update(byte[] buf, int offset, int len)
/*     */   {
/* 249 */     this.algorithm.update(buf, offset, len);
/*     */   }
/*     */   
/*     */   public String getBaseNamespace()
/*     */   {
/* 254 */     return "http://www.w3.org/2000/09/xmldsig#";
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 259 */     return "DigestMethod";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\algorithms\MessageDigestAlgorithm.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */