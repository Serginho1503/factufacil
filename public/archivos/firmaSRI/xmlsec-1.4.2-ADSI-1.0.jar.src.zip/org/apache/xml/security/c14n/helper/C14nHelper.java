/*     */ package org.apache.xml.security.c14n.helper;
/*     */ 
/*     */ import org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class C14nHelper
/*     */ {
/*     */   public static boolean namespaceIsRelative(Attr namespace)
/*     */   {
/*  51 */     return !namespaceIsAbsolute(namespace);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean namespaceIsRelative(String namespaceValue)
/*     */   {
/*  61 */     return !namespaceIsAbsolute(namespaceValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean namespaceIsAbsolute(Attr namespace)
/*     */   {
/*  71 */     return namespaceIsAbsolute(namespace.getValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean namespaceIsAbsolute(String namespaceValue)
/*     */   {
/*  83 */     if (namespaceValue.length() == 0) {
/*  84 */       return true;
/*     */     }
/*  86 */     return namespaceValue.indexOf(':') > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotRelativeNS(Attr attr)
/*     */     throws CanonicalizationException
/*     */   {
/*  99 */     if (attr == null) {
/* 100 */       return;
/*     */     }
/*     */     
/* 103 */     String nodeAttrName = attr.getNodeName();
/* 104 */     boolean definesDefaultNS = nodeAttrName.equals("xmlns");
/* 105 */     boolean definesNonDefaultNS = nodeAttrName.startsWith("xmlns:");
/*     */     
/* 107 */     if (((definesDefaultNS) || (definesNonDefaultNS)) && 
/* 108 */       (namespaceIsRelative(attr))) {
/* 109 */       String parentName = attr.getOwnerElement().getTagName();
/* 110 */       String attrValue = attr.getValue();
/* 111 */       Object[] exArgs = { parentName, nodeAttrName, attrValue };
/*     */       
/* 113 */       throw new CanonicalizationException("c14n.Canonicalizer.RelativeNamespace", exArgs);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void checkTraversability(Document document)
/*     */     throws CanonicalizationException
/*     */   {
/* 129 */     if (!document.isSupported("Traversal", "2.0")) {
/* 130 */       Object[] exArgs = { document.getImplementation().getClass().getName() };
/*     */       
/*     */ 
/* 133 */       throw new CanonicalizationException("c14n.Canonicalizer.TraversalNotSupported", exArgs);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void checkForRelativeNamespace(Element ctxNode)
/*     */     throws CanonicalizationException
/*     */   {
/* 149 */     if (ctxNode != null) {
/* 150 */       NamedNodeMap attributes = ctxNode.getAttributes();
/*     */       
/* 152 */       for (int i = 0; i < attributes.getLength(); i++) {
/* 153 */         assertNotRelativeNS((Attr)attributes.item(i));
/*     */       }
/*     */     } else {
/* 156 */       throw new CanonicalizationException("Called checkForRelativeNamespace() on null");
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\c14n\helper\C14nHelper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */