/*     */ package org.apache.xml.security.transforms.implementations;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.apache.xml.security.signature.NodeFilter;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class XPath2NodeFilter
/*     */   implements NodeFilter
/*     */ {
/*     */   boolean hasUnionNodes;
/*     */   boolean hasSubstractNodes;
/*     */   boolean hasIntersectNodes;
/*     */   Set unionNodes;
/*     */   Set substractNodes;
/*     */   Set intersectNodes;
/*     */   
/*     */   XPath2NodeFilter(Set unionNodes, Set substractNodes, Set intersectNodes)
/*     */   {
/* 192 */     this.unionNodes = unionNodes;
/* 193 */     this.hasUnionNodes = (!unionNodes.isEmpty());
/* 194 */     this.substractNodes = substractNodes;
/* 195 */     this.hasSubstractNodes = (!substractNodes.isEmpty());
/* 196 */     this.intersectNodes = intersectNodes;
/* 197 */     this.hasIntersectNodes = (!intersectNodes.isEmpty());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int isNodeInclude(Node currentNode)
/*     */   {
/* 208 */     int result = 1;
/*     */     
/* 210 */     if ((this.hasSubstractNodes) && (rooted(currentNode, this.substractNodes))) {
/* 211 */       result = -1;
/* 212 */     } else if ((this.hasIntersectNodes) && (!rooted(currentNode, this.intersectNodes))) {
/* 213 */       result = 0;
/*     */     }
/*     */     
/*     */ 
/* 217 */     if (result == 1)
/* 218 */       return 1;
/* 219 */     if (this.hasUnionNodes) {
/* 220 */       if (rooted(currentNode, this.unionNodes)) {
/* 221 */         return 1;
/*     */       }
/* 223 */       result = 0;
/*     */     }
/* 225 */     return result;
/*     */   }
/*     */   
/* 228 */   int inSubstract = -1;
/* 229 */   int inIntersect = -1;
/* 230 */   int inUnion = -1;
/*     */   
/* 232 */   public int isNodeIncludeDO(Node n, int level) { int result = 1;
/* 233 */     if (this.hasSubstractNodes) {
/* 234 */       if ((this.inSubstract == -1) || (level <= this.inSubstract)) {
/* 235 */         if (inList(n, this.substractNodes)) {
/* 236 */           this.inSubstract = level;
/*     */         } else {
/* 238 */           this.inSubstract = -1;
/*     */         }
/*     */       }
/* 241 */       if (this.inSubstract != -1) {
/* 242 */         result = -1;
/*     */       }
/*     */     }
/* 245 */     if ((result != -1) && 
/* 246 */       (this.hasIntersectNodes) && (
/* 247 */       (this.inIntersect == -1) || (level <= this.inIntersect))) {
/* 248 */       if (!inList(n, this.intersectNodes)) {
/* 249 */         this.inIntersect = -1;
/* 250 */         result = 0;
/*     */       } else {
/* 252 */         this.inIntersect = level;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 258 */     if (level <= this.inUnion)
/* 259 */       this.inUnion = -1;
/* 260 */     if (result == 1)
/* 261 */       return 1;
/* 262 */     if (this.hasUnionNodes) {
/* 263 */       if ((this.inUnion == -1) && (inList(n, this.unionNodes))) {
/* 264 */         this.inUnion = level;
/*     */       }
/* 266 */       if (this.inUnion != -1)
/* 267 */         return 1;
/* 268 */       result = 0;
/*     */     }
/*     */     
/* 271 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean rooted(Node currentNode, Set nodeList)
/*     */   {
/* 282 */     if (nodeList.contains(currentNode)) {
/* 283 */       return true;
/*     */     }
/* 285 */     Iterator it = nodeList.iterator();
/* 286 */     while (it.hasNext()) {
/* 287 */       Node rootNode = (Node)it.next();
/* 288 */       if (XMLUtils.isDescendantOrSelf(rootNode, currentNode)) {
/* 289 */         return true;
/*     */       }
/*     */     }
/* 292 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean inList(Node currentNode, Set nodeList)
/*     */   {
/* 303 */     return nodeList.contains(currentNode);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\transforms\implementations\XPath2NodeFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */