/*     */ package org.apache.xml.security.transforms.params;
/*     */ 
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.transforms.TransformParam;
/*     */ import org.apache.xml.security.utils.ElementProxy;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XPath2FilterContainer04
/*     */   extends ElementProxy
/*     */   implements TransformParam
/*     */ {
/*     */   private static final String _ATT_FILTER = "Filter";
/*     */   private static final String _ATT_FILTER_VALUE_INTERSECT = "intersect";
/*     */   private static final String _ATT_FILTER_VALUE_SUBTRACT = "subtract";
/*     */   private static final String _ATT_FILTER_VALUE_UNION = "union";
/*     */   public static final String _TAG_XPATH2 = "XPath";
/*     */   public static final String XPathFilter2NS = "http://www.w3.org/2002/04/xmldsig-filter2";
/*     */   
/*     */   private XPath2FilterContainer04() {}
/*     */   
/*     */   private XPath2FilterContainer04(Document doc, String xpath2filter, String filterType)
/*     */   {
/*  80 */     super(doc);
/*     */     
/*  82 */     this._constructionElement.setAttributeNS(null, "Filter", filterType);
/*     */     
/*     */ 
/*  85 */     if ((xpath2filter.length() > 2) && (!Character.isWhitespace(xpath2filter.charAt(0))))
/*     */     {
/*  87 */       XMLUtils.addReturnToElement(this._constructionElement);
/*  88 */       this._constructionElement.appendChild(doc.createTextNode(xpath2filter));
/*  89 */       XMLUtils.addReturnToElement(this._constructionElement);
/*     */     } else {
/*  91 */       this._constructionElement.appendChild(doc.createTextNode(xpath2filter));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private XPath2FilterContainer04(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 106 */     super(element, BaseURI);
/*     */     
/* 108 */     String filterStr = this._constructionElement.getAttributeNS(null, "Filter");
/*     */     
/*     */ 
/*     */ 
/* 112 */     if ((!filterStr.equals("intersect")) && (!filterStr.equals("subtract")) && (!filterStr.equals("union")))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 118 */       Object[] exArgs = { "Filter", filterStr, "intersect, subtract or union" };
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */       throw new XMLSecurityException("attributeValueIllegal", exArgs);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XPath2FilterContainer04 newInstanceIntersect(Document doc, String xpath2filter)
/*     */   {
/* 139 */     return new XPath2FilterContainer04(doc, xpath2filter, "intersect");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XPath2FilterContainer04 newInstanceSubtract(Document doc, String xpath2filter)
/*     */   {
/* 154 */     return new XPath2FilterContainer04(doc, xpath2filter, "subtract");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XPath2FilterContainer04 newInstanceUnion(Document doc, String xpath2filter)
/*     */   {
/* 169 */     return new XPath2FilterContainer04(doc, xpath2filter, "union");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XPath2FilterContainer04 newInstance(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 185 */     return new XPath2FilterContainer04(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isIntersect()
/*     */   {
/* 195 */     return this._constructionElement.getAttributeNS(null, "Filter").equals("intersect");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSubtract()
/*     */   {
/* 207 */     return this._constructionElement.getAttributeNS(null, "Filter").equals("subtract");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isUnion()
/*     */   {
/* 219 */     return this._constructionElement.getAttributeNS(null, "Filter").equals("union");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getXPathFilterStr()
/*     */   {
/* 230 */     return getTextFromTextChild();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node getXPathFilterTextNode()
/*     */   {
/* 242 */     NodeList children = this._constructionElement.getChildNodes();
/* 243 */     int length = children.getLength();
/*     */     
/* 245 */     for (int i = 0; i < length; i++) {
/* 246 */       if (children.item(i).getNodeType() == 3) {
/* 247 */         return children.item(i);
/*     */       }
/*     */     }
/*     */     
/* 251 */     return null;
/*     */   }
/*     */   
/*     */   public final String getBaseLocalName()
/*     */   {
/* 256 */     return "XPath";
/*     */   }
/*     */   
/*     */   public final String getBaseNamespace()
/*     */   {
/* 261 */     return "http://www.w3.org/2002/04/xmldsig-filter2";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\transforms\params\XPath2FilterContainer04.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */