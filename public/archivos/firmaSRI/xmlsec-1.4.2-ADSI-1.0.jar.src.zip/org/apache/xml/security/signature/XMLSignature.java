/*     */ package org.apache.xml.security.signature;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.security.Key;
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.crypto.SecretKey;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.algorithms.SignatureAlgorithm;
/*     */ import org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import org.apache.xml.security.c14n.InvalidCanonicalizerException;
/*     */ import org.apache.xml.security.exceptions.Base64DecodingException;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.keys.KeyInfo;
/*     */ import org.apache.xml.security.keys.content.X509Data;
/*     */ import org.apache.xml.security.transforms.Transforms;
/*     */ import org.apache.xml.security.utils.Base64;
/*     */ import org.apache.xml.security.utils.I18n;
/*     */ import org.apache.xml.security.utils.IdResolver;
/*     */ import org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import org.apache.xml.security.utils.SignerOutputStream;
/*     */ import org.apache.xml.security.utils.UnsyncBufferedOutputStream;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.apache.xml.security.utils.resolver.ResourceResolver;
/*     */ import org.apache.xml.security.utils.resolver.ResourceResolverSpi;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class XMLSignature
/*     */   extends SignatureElementProxy
/*     */ {
/*  79 */   static Log log = LogFactory.getLog(XMLSignature.class.getName());
/*     */   
/*     */ 
/*     */   public static final String ALGO_ID_MAC_HMAC_SHA1 = "http://www.w3.org/2000/09/xmldsig#hmac-sha1";
/*     */   
/*     */ 
/*     */   public static final String ALGO_ID_SIGNATURE_DSA = "http://www.w3.org/2000/09/xmldsig#dsa-sha1";
/*     */   
/*     */ 
/*     */   public static final String ALGO_ID_SIGNATURE_RSA = "http://www.w3.org/2000/09/xmldsig#rsa-sha1";
/*     */   
/*     */ 
/*     */   public static final String ALGO_ID_SIGNATURE_RSA_SHA1 = "http://www.w3.org/2000/09/xmldsig#rsa-sha1";
/*     */   
/*     */ 
/*     */   public static final String ALGO_ID_SIGNATURE_NOT_RECOMMENDED_RSA_MD5 = "http://www.w3.org/2001/04/xmldsig-more#rsa-md5";
/*     */   
/*     */ 
/*     */   public static final String ALGO_ID_SIGNATURE_RSA_RIPEMD160 = "http://www.w3.org/2001/04/xmldsig-more#rsa-ripemd160";
/*     */   
/*     */ 
/*     */   public static final String ALGO_ID_SIGNATURE_RSA_SHA256 = "http://www.w3.org/2001/04/xmldsig-more#rsa-sha256";
/*     */   
/*     */ 
/*     */   public static final String ALGO_ID_SIGNATURE_RSA_SHA384 = "http://www.w3.org/2001/04/xmldsig-more#rsa-sha384";
/*     */   
/*     */ 
/*     */   public static final String ALGO_ID_SIGNATURE_RSA_SHA512 = "http://www.w3.org/2001/04/xmldsig-more#rsa-sha512";
/*     */   
/*     */ 
/*     */   public static final String ALGO_ID_MAC_HMAC_NOT_RECOMMENDED_MD5 = "http://www.w3.org/2001/04/xmldsig-more#hmac-md5";
/*     */   
/*     */   public static final String ALGO_ID_MAC_HMAC_RIPEMD160 = "http://www.w3.org/2001/04/xmldsig-more#hmac-ripemd160";
/*     */   
/*     */   public static final String ALGO_ID_MAC_HMAC_SHA256 = "http://www.w3.org/2001/04/xmldsig-more#hmac-sha256";
/*     */   
/*     */   public static final String ALGO_ID_MAC_HMAC_SHA384 = "http://www.w3.org/2001/04/xmldsig-more#hmac-sha384";
/*     */   
/*     */   public static final String ALGO_ID_MAC_HMAC_SHA512 = "http://www.w3.org/2001/04/xmldsig-more#hmac-sha512";
/*     */   
/*     */   public static final String ALGO_ID_SIGNATURE_ECDSA_SHA1 = "http://www.w3.org/2001/04/xmldsig-more#ecdsa-sha1";
/*     */   
/* 121 */   private SignedInfo _signedInfo = null;
/*     */   
/*     */ 
/* 124 */   private KeyInfo _keyInfo = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 131 */   private boolean _followManifestsDuringValidation = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Element signatureValueElement;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignature(Document doc, String BaseURI, String SignatureMethodURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 149 */     this(doc, BaseURI, SignatureMethodURI, 0, "http://www.w3.org/TR/2001/REC-xml-c14n-20010315");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignature(Document doc, String BaseURI, String SignatureMethodURI, int HMACOutputLength)
/*     */     throws XMLSecurityException
/*     */   {
/* 165 */     this(doc, BaseURI, SignatureMethodURI, HMACOutputLength, "http://www.w3.org/TR/2001/REC-xml-c14n-20010315");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignature(Document doc, String BaseURI, String SignatureMethodURI, String CanonicalizationMethodURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 181 */     this(doc, BaseURI, SignatureMethodURI, 0, CanonicalizationMethodURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignature(Document doc, String BaseURI, String SignatureMethodURI, int HMACOutputLength, String CanonicalizationMethodURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 198 */     super(doc);
/*     */     
/* 200 */     String xmlnsDsPrefix = getDefaultPrefixBindings("http://www.w3.org/2000/09/xmldsig#");
/*     */     
/* 202 */     if (xmlnsDsPrefix == null) {
/* 203 */       this._constructionElement.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns", "http://www.w3.org/2000/09/xmldsig#");
/*     */     }
/*     */     else {
/* 206 */       this._constructionElement.setAttributeNS("http://www.w3.org/2000/xmlns/", xmlnsDsPrefix, "http://www.w3.org/2000/09/xmldsig#");
/*     */     }
/*     */     
/* 209 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */     
/* 211 */     this._baseURI = BaseURI;
/* 212 */     this._signedInfo = new SignedInfo(this._doc, SignatureMethodURI, HMACOutputLength, CanonicalizationMethodURI);
/*     */     
/*     */ 
/*     */ 
/* 216 */     this._constructionElement.appendChild(this._signedInfo.getElement());
/* 217 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */     
/*     */ 
/* 220 */     this.signatureValueElement = XMLUtils.createElementInSignatureSpace(this._doc, "SignatureValue");
/*     */     
/*     */ 
/*     */ 
/* 224 */     this._constructionElement.appendChild(this.signatureValueElement);
/* 225 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignature(Document doc, String BaseURI, Element SignatureMethodElem, Element CanonicalizationMethodElem)
/*     */     throws XMLSecurityException
/*     */   {
/* 239 */     super(doc);
/*     */     
/* 241 */     String xmlnsDsPrefix = getDefaultPrefixBindings("http://www.w3.org/2000/09/xmldsig#");
/*     */     
/* 243 */     if (xmlnsDsPrefix == null) {
/* 244 */       this._constructionElement.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns", "http://www.w3.org/2000/09/xmldsig#");
/*     */     }
/*     */     else {
/* 247 */       this._constructionElement.setAttributeNS("http://www.w3.org/2000/xmlns/", xmlnsDsPrefix, "http://www.w3.org/2000/09/xmldsig#");
/*     */     }
/*     */     
/* 250 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */     
/* 252 */     this._baseURI = BaseURI;
/* 253 */     this._signedInfo = new SignedInfo(this._doc, SignatureMethodElem, CanonicalizationMethodElem);
/*     */     
/* 255 */     this._constructionElement.appendChild(this._signedInfo.getElement());
/* 256 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */     
/*     */ 
/* 259 */     this.signatureValueElement = XMLUtils.createElementInSignatureSpace(this._doc, "SignatureValue");
/*     */     
/*     */ 
/*     */ 
/* 263 */     this._constructionElement.appendChild(this.signatureValueElement);
/* 264 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignature(Element element, String BaseURI)
/*     */     throws XMLSignatureException, XMLSecurityException
/*     */   {
/* 279 */     super(element, BaseURI);
/*     */     
/*     */ 
/* 282 */     Element signedInfoElem = XMLUtils.getNextElement(element.getFirstChild());
/*     */     
/*     */ 
/*     */ 
/* 286 */     if (signedInfoElem == null) {
/* 287 */       Object[] exArgs = { "SignedInfo", "Signature" };
/*     */       
/*     */ 
/* 290 */       throw new XMLSignatureException("xml.WrongContent", exArgs);
/*     */     }
/*     */     
/*     */ 
/* 294 */     this._signedInfo = new SignedInfo(signedInfoElem, BaseURI);
/*     */     
/*     */ 
/* 297 */     this.signatureValueElement = XMLUtils.getNextElement(signedInfoElem.getNextSibling());
/*     */     
/*     */ 
/*     */ 
/* 301 */     if (this.signatureValueElement == null) {
/* 302 */       Object[] exArgs = { "SignatureValue", "Signature" };
/*     */       
/*     */ 
/* 305 */       throw new XMLSignatureException("xml.WrongContent", exArgs);
/*     */     }
/*     */     
/*     */ 
/* 309 */     Element keyInfoElem = XMLUtils.getNextElement(this.signatureValueElement.getNextSibling());
/*     */     
/*     */ 
/*     */ 
/* 313 */     if ((keyInfoElem != null) && (keyInfoElem.getNamespaceURI().equals("http://www.w3.org/2000/09/xmldsig#")) && (keyInfoElem.getLocalName().equals("KeyInfo")))
/*     */     {
/* 315 */       this._keyInfo = new KeyInfo(keyInfoElem, BaseURI);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setId(String Id)
/*     */   {
/* 326 */     if (Id != null) {
/* 327 */       this._constructionElement.setAttributeNS(null, "Id", Id);
/* 328 */       IdResolver.registerElementById(this._constructionElement, Id);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getId()
/*     */   {
/* 338 */     return this._constructionElement.getAttributeNS(null, "Id");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignedInfo getSignedInfo()
/*     */   {
/* 347 */     return this._signedInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getSignatureValue()
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 360 */       return Base64.decode(this.signatureValueElement);
/*     */     }
/*     */     catch (Base64DecodingException ex)
/*     */     {
/* 364 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setSignatureValueElement(byte[] bytes)
/*     */   {
/* 376 */     while (this.signatureValueElement.hasChildNodes()) {
/* 377 */       this.signatureValueElement.removeChild(this.signatureValueElement.getFirstChild());
/*     */     }
/*     */     
/*     */ 
/* 381 */     String base64codedValue = Base64.encode(bytes);
/*     */     
/* 383 */     if ((base64codedValue.length() > 76) && (!XMLUtils.ignoreLineBreaks())) {
/* 384 */       base64codedValue = "\n" + base64codedValue + "\n";
/*     */     }
/*     */     
/* 387 */     Text t = this._doc.createTextNode(base64codedValue);
/* 388 */     this.signatureValueElement.appendChild(t);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyInfo getKeyInfo()
/*     */   {
/* 402 */     if (this._keyInfo == null)
/*     */     {
/*     */ 
/* 405 */       this._keyInfo = new KeyInfo(this._doc);
/*     */       
/*     */ 
/* 408 */       Element keyInfoElement = this._keyInfo.getElement();
/* 409 */       Element firstObject = null;
/* 410 */       Node sibling = this._constructionElement.getFirstChild();
/* 411 */       firstObject = XMLUtils.selectDsNode(sibling, "Object", 0);
/*     */       
/* 413 */       if (firstObject != null)
/*     */       {
/*     */ 
/* 416 */         this._constructionElement.insertBefore(keyInfoElement, firstObject);
/*     */         
/* 418 */         XMLUtils.addReturnBeforeChild(this._constructionElement, firstObject);
/*     */       }
/*     */       else
/*     */       {
/* 422 */         this._constructionElement.appendChild(keyInfoElement);
/* 423 */         XMLUtils.addReturnToElement(this._constructionElement);
/*     */       }
/*     */     }
/*     */     
/* 427 */     return this._keyInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void appendObject(ObjectContainer object)
/*     */     throws XMLSignatureException
/*     */   {
/* 447 */     this._constructionElement.appendChild(object.getElement());
/* 448 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectContainer getObjectItem(int i)
/*     */   {
/* 463 */     Element objElem = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), "Object", i);
/*     */     
/*     */     try
/*     */     {
/* 467 */       return new ObjectContainer(objElem, this._baseURI);
/*     */     } catch (XMLSecurityException ex) {}
/* 469 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getObjectLength()
/*     */   {
/* 479 */     return length("http://www.w3.org/2000/09/xmldsig#", "Object");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void sign(Key signingKey)
/*     */     throws XMLSignatureException
/*     */   {
/* 491 */     if ((signingKey instanceof PublicKey)) {
/* 492 */       throw new IllegalArgumentException(I18n.translate("algorithms.operationOnlyVerification"));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 499 */       SignedInfo si = getSignedInfo();
/* 500 */       SignatureAlgorithm sa = si.getSignatureAlgorithm();
/*     */       
/* 502 */       sa.initSign(signingKey);
/*     */       
/*     */ 
/* 505 */       si.generateDigestValues();
/* 506 */       OutputStream so = new UnsyncBufferedOutputStream(new SignerOutputStream(sa));
/*     */       try {
/* 508 */         so.close();
/*     */       }
/*     */       catch (IOException e) {}
/*     */       
/*     */ 
/* 513 */       si.signInOctectStream(so);
/*     */       
/* 515 */       byte[] jcebytes = sa.sign();
/*     */       
/*     */ 
/* 518 */       setSignatureValueElement(jcebytes);
/*     */     }
/*     */     catch (CanonicalizationException ex) {
/* 521 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (InvalidCanonicalizerException ex) {
/* 523 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (XMLSecurityException ex) {
/* 525 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addResourceResolver(ResourceResolver resolver)
/*     */   {
/* 535 */     getSignedInfo().addResourceResolver(resolver);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addResourceResolver(ResourceResolverSpi resolver)
/*     */   {
/* 544 */     getSignedInfo().addResourceResolver(resolver);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean checkSignatureValue(X509Certificate cert)
/*     */     throws XMLSignatureException
/*     */   {
/* 561 */     if (cert != null)
/*     */     {
/*     */ 
/* 564 */       return checkSignatureValue(cert.getPublicKey());
/*     */     }
/*     */     
/* 567 */     Object[] exArgs = { "Didn't get a certificate" };
/* 568 */     throw new XMLSignatureException("empty", exArgs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean checkSignatureValue(Key pk)
/*     */     throws XMLSignatureException
/*     */   {
/* 585 */     if (pk == null) {
/* 586 */       Object[] exArgs = { "Didn't get a key" };
/*     */       
/* 588 */       throw new XMLSignatureException("empty", exArgs);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 596 */       SignedInfo si = getSignedInfo();
/*     */       
/*     */ 
/* 599 */       SignatureAlgorithm sa = si.getSignatureAlgorithm();
/* 600 */       if (log.isDebugEnabled()) {
/* 601 */         log.debug("SignatureMethodURI = " + sa.getAlgorithmURI());
/* 602 */         log.debug("jceSigAlgorithm    = " + sa.getJCEAlgorithmString());
/* 603 */         log.debug("jceSigProvider     = " + sa.getJCEProviderName());
/* 604 */         log.debug("PublicKey = " + pk);
/*     */       }
/* 606 */       sa.initVerify(pk);
/*     */       
/*     */ 
/* 609 */       SignerOutputStream so = new SignerOutputStream(sa);
/* 610 */       OutputStream bos = new UnsyncBufferedOutputStream(so);
/* 611 */       si.signInOctectStream(bos);
/*     */       try {
/* 613 */         bos.close();
/*     */       }
/*     */       catch (IOException e) {}
/*     */       
/*     */ 
/*     */ 
/* 619 */       byte[] sigBytes = getSignatureValue();
/*     */       
/*     */ 
/*     */ 
/* 623 */       if (!sa.verify(sigBytes)) {
/* 624 */         log.warn("Signature verification failed.");
/* 625 */         return false;
/*     */       }
/*     */       
/* 628 */       return si.verify(this._followManifestsDuringValidation);
/*     */     } catch (XMLSecurityException ex) {
/* 630 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addDocument(String referenceURI, Transforms trans, String digestURI, String ReferenceId, String ReferenceType)
/*     */     throws XMLSignatureException
/*     */   {
/* 650 */     this._signedInfo.addDocument(this._baseURI, referenceURI, trans, digestURI, ReferenceId, ReferenceType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addDocument(String referenceURI, Transforms trans, String digestURI)
/*     */     throws XMLSignatureException
/*     */   {
/* 666 */     this._signedInfo.addDocument(this._baseURI, referenceURI, trans, digestURI, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addDocument(String referenceURI, Transforms trans)
/*     */     throws XMLSignatureException
/*     */   {
/* 680 */     this._signedInfo.addDocument(this._baseURI, referenceURI, trans, "http://www.w3.org/2000/09/xmldsig#sha1", null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addDocument(String referenceURI)
/*     */     throws XMLSignatureException
/*     */   {
/* 692 */     this._signedInfo.addDocument(this._baseURI, referenceURI, null, "http://www.w3.org/2000/09/xmldsig#sha1", null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addKeyInfo(X509Certificate cert)
/*     */     throws XMLSecurityException
/*     */   {
/* 705 */     X509Data x509data = new X509Data(this._doc);
/*     */     
/* 707 */     x509data.addCertificate(cert);
/* 708 */     getKeyInfo().add(x509data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addKeyInfo(PublicKey pk)
/*     */   {
/* 718 */     getKeyInfo().add(pk);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SecretKey createSecretKey(byte[] secretKeyBytes)
/*     */   {
/* 732 */     return getSignedInfo().createSecretKey(secretKeyBytes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFollowNestedManifests(boolean followManifests)
/*     */   {
/* 745 */     this._followManifestsDuringValidation = followManifests;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBaseLocalName()
/*     */   {
/* 754 */     return "Signature";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\signature\XMLSignature.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */