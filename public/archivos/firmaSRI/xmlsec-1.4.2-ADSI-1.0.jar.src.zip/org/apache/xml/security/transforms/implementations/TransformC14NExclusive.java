/*    */ package org.apache.xml.security.transforms.implementations;
/*    */ 
/*    */ import java.io.OutputStream;
/*    */ import org.apache.xml.security.c14n.CanonicalizationException;
/*    */ import org.apache.xml.security.c14n.implementations.Canonicalizer20010315ExclOmitComments;
/*    */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*    */ import org.apache.xml.security.signature.XMLSignatureInput;
/*    */ import org.apache.xml.security.transforms.Transform;
/*    */ import org.apache.xml.security.transforms.TransformSpi;
/*    */ import org.apache.xml.security.transforms.params.InclusiveNamespaces;
/*    */ import org.apache.xml.security.utils.XMLUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransformC14NExclusive
/*    */   extends TransformSpi
/*    */ {
/*    */   public static final String implementedTransformURI = "http://www.w3.org/2001/10/xml-exc-c14n#";
/*    */   
/*    */   protected String engineGetURI()
/*    */   {
/* 50 */     return "http://www.w3.org/2001/10/xml-exc-c14n#";
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, Transform _transformObject)
/*    */     throws CanonicalizationException
/*    */   {
/* 63 */     return enginePerformTransform(input, null, _transformObject);
/*    */   }
/*    */   
/*    */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, OutputStream os, Transform _transformObject) throws CanonicalizationException
/*    */   {
/*    */     try {
/* 69 */       String inclusiveNamespaces = null;
/*    */       
/* 71 */       if (_transformObject.length("http://www.w3.org/2001/10/xml-exc-c14n#", "InclusiveNamespaces") == 1)
/*    */       {
/*    */ 
/*    */ 
/* 75 */         Element inclusiveElement = XMLUtils.selectNode(_transformObject.getElement().getFirstChild(), "http://www.w3.org/2001/10/xml-exc-c14n#", "InclusiveNamespaces", 0);
/*    */         
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 81 */         inclusiveNamespaces = new InclusiveNamespaces(inclusiveElement, _transformObject.getBaseURI()).getInclusiveNamespaces();
/*    */       }
/*    */       
/*    */ 
/* 85 */       Canonicalizer20010315ExclOmitComments c14n = new Canonicalizer20010315ExclOmitComments();
/*    */       
/* 87 */       if (os != null) {
/* 88 */         c14n.setWriter(os);
/*    */       }
/*    */       
/* 91 */       byte[] result = c14n.engineCanonicalize(input, inclusiveNamespaces);
/*    */       
/* 93 */       XMLSignatureInput output = new XMLSignatureInput(result);
/* 94 */       if (os != null) {
/* 95 */         output.setOutputStream(os);
/*    */       }
/* 97 */       return output;
/*    */     } catch (XMLSecurityException ex) {
/* 99 */       throw new CanonicalizationException("empty", ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\transforms\implementations\TransformC14NExclusive.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */