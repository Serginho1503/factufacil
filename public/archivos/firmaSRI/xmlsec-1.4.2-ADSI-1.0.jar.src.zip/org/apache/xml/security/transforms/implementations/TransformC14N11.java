/*    */ package org.apache.xml.security.transforms.implementations;
/*    */ 
/*    */ import java.io.OutputStream;
/*    */ import org.apache.xml.security.c14n.CanonicalizationException;
/*    */ import org.apache.xml.security.c14n.implementations.Canonicalizer11_OmitComments;
/*    */ import org.apache.xml.security.signature.XMLSignatureInput;
/*    */ import org.apache.xml.security.transforms.Transform;
/*    */ import org.apache.xml.security.transforms.TransformSpi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransformC14N11
/*    */   extends TransformSpi
/*    */ {
/*    */   protected String engineGetURI()
/*    */   {
/* 37 */     return "http://www.w3.org/2006/12/xml-c14n11";
/*    */   }
/*    */   
/*    */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, Transform transform)
/*    */     throws CanonicalizationException
/*    */   {
/* 43 */     return enginePerformTransform(input, null, transform);
/*    */   }
/*    */   
/*    */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, OutputStream os, Transform transform)
/*    */     throws CanonicalizationException
/*    */   {
/* 49 */     Canonicalizer11_OmitComments c14n = new Canonicalizer11_OmitComments();
/* 50 */     if (os != null) {
/* 51 */       c14n.setWriter(os);
/*    */     }
/* 53 */     byte[] result = null;
/* 54 */     result = c14n.engineCanonicalize(input);
/* 55 */     XMLSignatureInput output = new XMLSignatureInput(result);
/* 56 */     if (os != null) {
/* 57 */       output.setOutputStream(os);
/*    */     }
/* 59 */     return output;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\transforms\implementations\TransformC14N11.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */