/*     */ package org.apache.xml.security.signature;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.xml.security.algorithms.SignatureAlgorithm;
/*     */ import org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import org.apache.xml.security.c14n.Canonicalizer;
/*     */ import org.apache.xml.security.c14n.InvalidCanonicalizerException;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.transforms.params.InclusiveNamespaces;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignedInfo
/*     */   extends Manifest
/*     */ {
/*  49 */   private SignatureAlgorithm _signatureAlgorithm = null;
/*     */   
/*     */ 
/*  52 */   private byte[] _c14nizedBytes = null;
/*     */   
/*     */ 
/*     */ 
/*     */   private Element c14nMethod;
/*     */   
/*     */ 
/*     */   private Element signatureMethod;
/*     */   
/*     */ 
/*     */ 
/*     */   public SignedInfo(Document doc)
/*     */     throws XMLSecurityException
/*     */   {
/*  66 */     this(doc, "http://www.w3.org/2000/09/xmldsig#dsa-sha1", "http://www.w3.org/TR/2001/REC-xml-c14n-20010315");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignedInfo(Document doc, String signatureMethodURI, String canonicalizationMethodURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  84 */     this(doc, signatureMethodURI, 0, canonicalizationMethodURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignedInfo(Document doc, String signatureMethodURI, int hMACOutputLength, String canonicalizationMethodURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 102 */     super(doc);
/*     */     
/* 104 */     this.c14nMethod = XMLUtils.createElementInSignatureSpace(this._doc, "CanonicalizationMethod");
/*     */     
/*     */ 
/* 107 */     this.c14nMethod.setAttributeNS(null, "Algorithm", canonicalizationMethodURI);
/*     */     
/* 109 */     this._constructionElement.appendChild(this.c14nMethod);
/* 110 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */     
/* 112 */     if (hMACOutputLength > 0) {
/* 113 */       this._signatureAlgorithm = new SignatureAlgorithm(this._doc, signatureMethodURI, hMACOutputLength);
/*     */     }
/*     */     else {
/* 116 */       this._signatureAlgorithm = new SignatureAlgorithm(this._doc, signatureMethodURI);
/*     */     }
/*     */     
/*     */ 
/* 120 */     this.signatureMethod = this._signatureAlgorithm.getElement();
/* 121 */     this._constructionElement.appendChild(this.signatureMethod);
/* 122 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignedInfo(Document doc, Element signatureMethodElem, Element canonicalizationMethodElem)
/*     */     throws XMLSecurityException
/*     */   {
/* 134 */     super(doc);
/*     */     
/* 136 */     this.c14nMethod = canonicalizationMethodElem;
/* 137 */     this._constructionElement.appendChild(this.c14nMethod);
/* 138 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */     
/* 140 */     this._signatureAlgorithm = new SignatureAlgorithm(signatureMethodElem, null);
/*     */     
/*     */ 
/* 143 */     this.signatureMethod = this._signatureAlgorithm.getElement();
/* 144 */     this._constructionElement.appendChild(this.signatureMethod);
/*     */     
/* 146 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignedInfo(Element element, String baseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 162 */     super(element, baseURI);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 168 */     this.c14nMethod = XMLUtils.getNextElement(element.getFirstChild());
/* 169 */     String c14nMethodURI = getCanonicalizationMethodURI();
/* 170 */     if ((!c14nMethodURI.equals("http://www.w3.org/TR/2001/REC-xml-c14n-20010315")) && (!c14nMethodURI.equals("http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments")) && (!c14nMethodURI.equals("http://www.w3.org/2001/10/xml-exc-c14n#")) && (!c14nMethodURI.equals("http://www.w3.org/2001/10/xml-exc-c14n#WithComments")))
/*     */     {
/*     */ 
/*     */       try
/*     */       {
/*     */ 
/*     */ 
/* 177 */         Canonicalizer c14nizer = Canonicalizer.getInstance(getCanonicalizationMethodURI());
/*     */         
/*     */ 
/* 180 */         this._c14nizedBytes = c14nizer.canonicalizeSubtree(this._constructionElement);
/*     */         
/* 182 */         DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/*     */         
/* 184 */         dbf.setNamespaceAware(true);
/* 185 */         DocumentBuilder db = dbf.newDocumentBuilder();
/* 186 */         Document newdoc = db.parse(new ByteArrayInputStream(this._c14nizedBytes));
/*     */         
/* 188 */         Node imported = this._doc.importNode(newdoc.getDocumentElement(), true);
/*     */         
/*     */ 
/* 191 */         this._constructionElement.getParentNode().replaceChild(imported, this._constructionElement);
/*     */         
/*     */ 
/* 194 */         this._constructionElement = ((Element)imported);
/*     */       } catch (ParserConfigurationException ex) {
/* 196 */         throw new XMLSecurityException("empty", ex);
/*     */       } catch (IOException ex) {
/* 198 */         throw new XMLSecurityException("empty", ex);
/*     */       } catch (SAXException ex) {
/* 200 */         throw new XMLSecurityException("empty", ex);
/*     */       }
/*     */     }
/* 203 */     this.signatureMethod = XMLUtils.getNextElement(this.c14nMethod.getNextSibling());
/* 204 */     this._signatureAlgorithm = new SignatureAlgorithm(this.signatureMethod, getBaseURI());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean verify()
/*     */     throws MissingResourceFailureException, XMLSecurityException
/*     */   {
/* 217 */     return super.verifyReferences(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean verify(boolean followManifests)
/*     */     throws MissingResourceFailureException, XMLSecurityException
/*     */   {
/* 230 */     return super.verifyReferences(followManifests);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getCanonicalizedOctetStream()
/*     */     throws CanonicalizationException, InvalidCanonicalizerException, XMLSecurityException
/*     */   {
/* 245 */     if (this._c14nizedBytes == null)
/*     */     {
/* 247 */       Canonicalizer c14nizer = Canonicalizer.getInstance(getCanonicalizationMethodURI());
/*     */       
/*     */ 
/* 250 */       this._c14nizedBytes = c14nizer.canonicalizeSubtree(this._constructionElement);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 255 */     byte[] output = new byte[this._c14nizedBytes.length];
/*     */     
/* 257 */     System.arraycopy(this._c14nizedBytes, 0, output, 0, output.length);
/*     */     
/* 259 */     return output;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void signInOctectStream(OutputStream os)
/*     */     throws CanonicalizationException, InvalidCanonicalizerException, XMLSecurityException
/*     */   {
/* 273 */     if (this._c14nizedBytes == null) {
/* 274 */       Canonicalizer c14nizer = Canonicalizer.getInstance(getCanonicalizationMethodURI());
/*     */       
/* 276 */       c14nizer.setWriter(os);
/* 277 */       String inclusiveNamespaces = getInclusiveNamespaces();
/*     */       
/* 279 */       if (inclusiveNamespaces == null) {
/* 280 */         c14nizer.canonicalizeSubtree(this._constructionElement);
/*     */       } else
/* 282 */         c14nizer.canonicalizeSubtree(this._constructionElement, inclusiveNamespaces);
/*     */     } else {
/*     */       try {
/* 285 */         os.write(this._c14nizedBytes);
/*     */       } catch (IOException e) {
/* 287 */         throw new RuntimeException("" + e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCanonicalizationMethodURI()
/*     */   {
/* 300 */     return this.c14nMethod.getAttributeNS(null, "Algorithm");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSignatureMethodURI()
/*     */   {
/* 310 */     Element signatureElement = getSignatureMethodElement();
/*     */     
/* 312 */     if (signatureElement != null) {
/* 313 */       return signatureElement.getAttributeNS(null, "Algorithm");
/*     */     }
/*     */     
/* 316 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element getSignatureMethodElement()
/*     */   {
/* 325 */     return this.signatureMethod;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SecretKey createSecretKey(byte[] secretKeyBytes)
/*     */   {
/* 338 */     return new SecretKeySpec(secretKeyBytes, this._signatureAlgorithm.getJCEAlgorithmString());
/*     */   }
/*     */   
/*     */ 
/*     */   protected SignatureAlgorithm getSignatureAlgorithm()
/*     */   {
/* 344 */     return this._signatureAlgorithm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBaseLocalName()
/*     */   {
/* 352 */     return "SignedInfo";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getInclusiveNamespaces()
/*     */   {
/* 359 */     String c14nMethodURI = this.c14nMethod.getAttributeNS(null, "Algorithm");
/* 360 */     if ((!c14nMethodURI.equals("http://www.w3.org/2001/10/xml-exc-c14n#")) && (!c14nMethodURI.equals("http://www.w3.org/2001/10/xml-exc-c14n#WithComments")))
/*     */     {
/* 362 */       return null;
/*     */     }
/*     */     
/* 365 */     Element inclusiveElement = XMLUtils.getNextElement(this.c14nMethod.getFirstChild());
/*     */     
/*     */ 
/* 368 */     if (inclusiveElement != null)
/*     */     {
/*     */       try
/*     */       {
/* 372 */         return new InclusiveNamespaces(inclusiveElement, "http://www.w3.org/2001/10/xml-exc-c14n#").getInclusiveNamespaces();
/*     */ 
/*     */       }
/*     */       catch (XMLSecurityException e)
/*     */       {
/*     */ 
/* 378 */         return null;
/*     */       }
/*     */     }
/* 381 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\signature\SignedInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */