/*    */ package org.apache.xml.security.keys.keyresolver.implementations;
/*    */ 
/*    */ import java.security.PublicKey;
/*    */ import java.security.cert.X509Certificate;
/*    */ import javax.crypto.SecretKey;
/*    */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*    */ import org.apache.xml.security.keys.content.keyvalues.DSAKeyValue;
/*    */ import org.apache.xml.security.keys.keyresolver.KeyResolverSpi;
/*    */ import org.apache.xml.security.keys.storage.StorageResolver;
/*    */ import org.apache.xml.security.utils.XMLUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DSAKeyValueResolver
/*    */   extends KeyResolverSpi
/*    */ {
/*    */   public PublicKey engineLookupAndResolvePublicKey(Element element, String BaseURI, StorageResolver storage)
/*    */   {
/* 50 */     if (element == null) {
/* 51 */       return null;
/*    */     }
/* 53 */     Element dsaKeyElement = null;
/* 54 */     boolean isKeyValue = XMLUtils.elementIsInSignatureSpace(element, "KeyValue");
/*    */     
/* 56 */     if (isKeyValue) {
/* 57 */       dsaKeyElement = XMLUtils.selectDsNode(element.getFirstChild(), "DSAKeyValue", 0);
/*    */     }
/* 59 */     else if (XMLUtils.elementIsInSignatureSpace(element, "DSAKeyValue"))
/*    */     {
/*    */ 
/*    */ 
/* 63 */       dsaKeyElement = element;
/*    */     }
/*    */     
/* 66 */     if (dsaKeyElement == null) {
/* 67 */       return null;
/*    */     }
/*    */     try
/*    */     {
/* 71 */       DSAKeyValue dsaKeyValue = new DSAKeyValue(dsaKeyElement, BaseURI);
/*    */       
/* 73 */       return dsaKeyValue.getPublicKey();
/*    */     }
/*    */     catch (XMLSecurityException ex) {}
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 80 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public X509Certificate engineLookupResolveX509Certificate(Element element, String BaseURI, StorageResolver storage)
/*    */   {
/* 87 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */   public SecretKey engineLookupAndResolveSecretKey(Element element, String BaseURI, StorageResolver storage)
/*    */   {
/* 93 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\keyresolver\implementations\DSAKeyValueResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */