/*    */ package org.apache.xml.security.keys.storage.implementations;
/*    */ 
/*    */ import java.security.cert.X509Certificate;
/*    */ import java.util.Iterator;
/*    */ import org.apache.xml.security.keys.storage.StorageResolverSpi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SingleCertificateResolver
/*    */   extends StorageResolverSpi
/*    */ {
/* 35 */   X509Certificate _certificate = null;
/*    */   
/*    */ 
/* 38 */   Iterator _iterator = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SingleCertificateResolver(X509Certificate x509cert)
/*    */   {
/* 46 */     this._certificate = x509cert;
/* 47 */     this._iterator = new InternalIterator(this._certificate);
/*    */   }
/*    */   
/*    */   public Iterator getIterator()
/*    */   {
/* 52 */     return this._iterator;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static class InternalIterator
/*    */     implements Iterator
/*    */   {
/* 64 */     boolean _alreadyReturned = false;
/*    */     
/*    */ 
/* 67 */     X509Certificate _certificate = null;
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     public InternalIterator(X509Certificate x509cert)
/*    */     {
/* 75 */       this._certificate = x509cert;
/*    */     }
/*    */     
/*    */     public boolean hasNext()
/*    */     {
/* 80 */       return !this._alreadyReturned;
/*    */     }
/*    */     
/*    */ 
/*    */     public Object next()
/*    */     {
/* 86 */       this._alreadyReturned = true;
/*    */       
/* 88 */       return this._certificate;
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */     public void remove()
/*    */     {
/* 96 */       throw new UnsupportedOperationException("Can't remove keys from KeyStore");
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\storage\implementations\SingleCertificateResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */