/*     */ package org.apache.xml.security.utils;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.xml.transform.ErrorListener;
/*     */ import javax.xml.transform.SourceLocator;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.dtm.DTMManager;
/*     */ import org.apache.xml.security.transforms.implementations.FuncHere;
/*     */ import org.apache.xml.security.transforms.implementations.FuncHereContext;
/*     */ import org.apache.xml.utils.PrefixResolver;
/*     */ import org.apache.xml.utils.PrefixResolverDefault;
/*     */ import org.apache.xpath.CachedXPathAPI;
/*     */ import org.apache.xpath.Expression;
/*     */ import org.apache.xpath.XPath;
/*     */ import org.apache.xpath.XPathContext;
/*     */ import org.apache.xpath.compiler.FunctionTable;
/*     */ import org.apache.xpath.objects.XObject;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.ProcessingInstruction;
/*     */ import org.w3c.dom.Text;
/*     */ import org.w3c.dom.traversal.NodeIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CachedXPathFuncHereAPI
/*     */ {
/*  48 */   static Log log = LogFactory.getLog(CachedXPathFuncHereAPI.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  54 */   FuncHereContext _funcHereContext = null;
/*     */   
/*     */ 
/*  57 */   DTMManager _dtmManager = null;
/*     */   
/*  59 */   XPathContext _context = null;
/*     */   
/*  61 */   String xpathStr = null;
/*     */   
/*  63 */   XPath xpath = null;
/*     */   
/*  65 */   static FunctionTable _funcTable = null;
/*     */   
/*     */   static {
/*  68 */     fixupFunctionTable();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FuncHereContext getFuncHereContext()
/*     */   {
/*  77 */     return this._funcHereContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CachedXPathFuncHereAPI(XPathContext existingXPathContext)
/*     */   {
/*  92 */     this._dtmManager = existingXPathContext.getDTMManager();
/*  93 */     this._context = existingXPathContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CachedXPathFuncHereAPI(CachedXPathAPI previouslyUsed)
/*     */   {
/* 102 */     this._dtmManager = previouslyUsed.getXPathContext().getDTMManager();
/* 103 */     this._context = previouslyUsed.getXPathContext();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node selectSingleNode(Node contextNode, Node xpathnode)
/*     */     throws TransformerException
/*     */   {
/* 119 */     return selectSingleNode(contextNode, xpathnode, contextNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node selectSingleNode(Node contextNode, Node xpathnode, Node namespaceNode)
/*     */     throws TransformerException
/*     */   {
/* 138 */     NodeIterator nl = selectNodeIterator(contextNode, xpathnode, namespaceNode);
/*     */     
/*     */ 
/*     */ 
/* 142 */     return nl.nextNode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodeIterator selectNodeIterator(Node contextNode, Node xpathnode)
/*     */     throws TransformerException
/*     */   {
/* 157 */     return selectNodeIterator(contextNode, xpathnode, contextNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public NodeIterator selectNodeIterator(Node contextNode, Node xpathnode, Node namespaceNode)
/*     */     throws TransformerException
/*     */   {
/* 177 */     XObject list = eval(contextNode, xpathnode, getStrFromNode(xpathnode), namespaceNode);
/*     */     
/*     */ 
/* 180 */     return list.nodeset();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public NodeList selectNodeList(Node contextNode, Node xpathnode)
/*     */     throws TransformerException
/*     */   {
/* 196 */     return selectNodeList(contextNode, xpathnode, getStrFromNode(xpathnode), contextNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodeList selectNodeList(Node contextNode, Node xpathnode, String str, Node namespaceNode)
/*     */     throws TransformerException
/*     */   {
/* 216 */     XObject list = eval(contextNode, xpathnode, str, namespaceNode);
/*     */     
/*     */ 
/* 219 */     return list.nodelist();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public XObject eval(Node contextNode, Node xpathnode)
/*     */     throws TransformerException
/*     */   {
/* 240 */     return eval(contextNode, xpathnode, getStrFromNode(xpathnode), contextNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XObject eval(Node contextNode, Node xpathnode, String str, Node namespaceNode)
/*     */     throws TransformerException
/*     */   {
/* 274 */     if (this._funcHereContext == null) {
/* 275 */       this._funcHereContext = new FuncHereContext(xpathnode, this._dtmManager);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 283 */     PrefixResolverDefault prefixResolver = new PrefixResolverDefault(namespaceNode.getNodeType() == 9 ? ((Document)namespaceNode).getDocumentElement() : namespaceNode);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 291 */     if (str != this.xpathStr) {
/* 292 */       if (str.indexOf("here()") > 0) {
/* 293 */         this._context.reset();
/* 294 */         this._dtmManager = this._context.getDTMManager();
/*     */       }
/* 296 */       this.xpath = createXPath(str, prefixResolver);
/* 297 */       this.xpathStr = str;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 302 */     int ctxtNode = this._funcHereContext.getDTMHandleFromNode(contextNode);
/*     */     
/* 304 */     return this.xpath.execute(this._funcHereContext, ctxtNode, prefixResolver);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XObject eval(Node contextNode, Node xpathnode, String str, PrefixResolver prefixResolver)
/*     */     throws TransformerException
/*     */   {
/* 341 */     if (str != this.xpathStr) {
/* 342 */       if (str.indexOf("here()") > 0) {
/* 343 */         this._context.reset();
/* 344 */         this._dtmManager = this._context.getDTMManager();
/*     */       }
/*     */       try {
/* 347 */         this.xpath = createXPath(str, prefixResolver);
/*     */       }
/*     */       catch (TransformerException ex) {
/* 350 */         Throwable th = ex.getCause();
/* 351 */         if (((th instanceof ClassNotFoundException)) && 
/* 352 */           (th.getMessage().indexOf("FuncHere") > 0)) {
/* 353 */           throw new RuntimeException(I18n.translate("endorsed.jdk1.4.0") + ex);
/*     */         }
/*     */         
/* 356 */         throw ex;
/*     */       }
/* 358 */       this.xpathStr = str;
/*     */     }
/*     */     
/*     */ 
/* 362 */     if (this._funcHereContext == null) {
/* 363 */       this._funcHereContext = new FuncHereContext(xpathnode, this._dtmManager);
/*     */     }
/*     */     
/*     */ 
/* 367 */     int ctxtNode = this._funcHereContext.getDTMHandleFromNode(contextNode);
/*     */     
/* 369 */     return this.xpath.execute(this._funcHereContext, ctxtNode, prefixResolver);
/*     */   }
/*     */   
/*     */   private XPath createXPath(String str, PrefixResolver prefixResolver) throws TransformerException {
/* 373 */     XPath xpath = null;
/* 374 */     Class[] classes = { String.class, SourceLocator.class, PrefixResolver.class, Integer.TYPE, ErrorListener.class, FunctionTable.class };
/*     */     
/* 376 */     Object[] objects = { str, null, prefixResolver, new Integer(0), null, _funcTable };
/*     */     try {
/* 378 */       Constructor constructor = XPath.class.getConstructor(classes);
/* 379 */       xpath = (XPath)constructor.newInstance(objects);
/*     */     }
/*     */     catch (Throwable t) {}
/* 382 */     if (xpath == null) {
/* 383 */       xpath = new XPath(str, null, prefixResolver, 0, null);
/*     */     }
/* 385 */     return xpath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getStrFromNode(Node xpathnode)
/*     */   {
/* 396 */     if (xpathnode.getNodeType() == 3)
/*     */     {
/*     */ 
/*     */ 
/* 400 */       StringBuffer sb = new StringBuffer();
/*     */       
/* 402 */       for (Node currentSibling = xpathnode.getParentNode().getFirstChild(); 
/* 403 */           currentSibling != null; 
/* 404 */           currentSibling = currentSibling.getNextSibling()) {
/* 405 */         if (currentSibling.getNodeType() == 3) {
/* 406 */           sb.append(((Text)currentSibling).getData());
/*     */         }
/*     */       }
/*     */       
/* 410 */       return sb.toString(); }
/* 411 */     if (xpathnode.getNodeType() == 2)
/* 412 */       return ((Attr)xpathnode).getNodeValue();
/* 413 */     if (xpathnode.getNodeType() == 7) {
/* 414 */       return ((ProcessingInstruction)xpathnode).getNodeValue();
/*     */     }
/*     */     
/* 417 */     return null;
/*     */   }
/*     */   
/*     */   private static void fixupFunctionTable() {
/* 421 */     boolean installed = false;
/* 422 */     log.info("Registering Here function");
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 427 */       Class[] args = { String.class, Expression.class };
/* 428 */       Method installFunction = FunctionTable.class.getMethod("installFunction", args);
/* 429 */       if ((installFunction.getModifiers() & 0x8) != 0) {
/* 430 */         Object[] params = { "here", new FuncHere() };
/* 431 */         installFunction.invoke(null, params);
/* 432 */         installed = true;
/*     */       }
/*     */     } catch (Throwable t) {
/* 435 */       log.debug("Error installing function using the static installFunction method", t);
/*     */     }
/* 437 */     if (!installed) {
/*     */       try {
/* 439 */         _funcTable = new FunctionTable();
/* 440 */         Class[] args = { String.class, Class.class };
/* 441 */         Method installFunction = FunctionTable.class.getMethod("installFunction", args);
/* 442 */         Object[] params = { "here", FuncHere.class };
/* 443 */         installFunction.invoke(_funcTable, params);
/* 444 */         installed = true;
/*     */       } catch (Throwable t) {
/* 446 */         log.debug("Error installing function using the static installFunction method", t);
/*     */       }
/*     */     }
/* 449 */     if (log.isDebugEnabled()) {
/* 450 */       if (installed) {
/* 451 */         log.debug("Registered class " + FuncHere.class.getName() + " for XPath function 'here()' function in internal table");
/*     */       }
/*     */       else {
/* 454 */         log.debug("Unable to register class " + FuncHere.class.getName() + " for XPath function 'here()' function in internal table");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private CachedXPathFuncHereAPI() {}
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\utils\CachedXPathFuncHereAPI.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */