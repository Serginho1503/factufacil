/*    */ package org.apache.xml.security.c14n.implementations;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Canonicalizer20010315ExclOmitComments
/*    */   extends Canonicalizer20010315Excl
/*    */ {
/*    */   public Canonicalizer20010315ExclOmitComments()
/*    */   {
/* 33 */     super(false);
/*    */   }
/*    */   
/*    */   public final String engineGetURI()
/*    */   {
/* 38 */     return "http://www.w3.org/2001/10/xml-exc-c14n#";
/*    */   }
/*    */   
/*    */   public final boolean engineGetIncludeComments()
/*    */   {
/* 43 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\c14n\implementations\Canonicalizer20010315ExclOmitComments.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */