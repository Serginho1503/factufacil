/*    */ package org.apache.xml.security.algorithms;
/*    */ 
/*    */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*    */ import org.apache.xml.security.utils.SignatureElementProxy;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Algorithm
/*    */   extends SignatureElementProxy
/*    */ {
/*    */   public Algorithm(Document doc, String algorithmURI)
/*    */   {
/* 41 */     super(doc);
/*    */     
/* 43 */     setAlgorithmURI(algorithmURI);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Algorithm(Element element, String BaseURI)
/*    */     throws XMLSecurityException
/*    */   {
/* 55 */     super(element, BaseURI);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getAlgorithmURI()
/*    */   {
/* 64 */     return this._constructionElement.getAttributeNS(null, "Algorithm");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void setAlgorithmURI(String algorithmURI)
/*    */   {
/* 74 */     if (algorithmURI != null) {
/* 75 */       this._constructionElement.setAttributeNS(null, "Algorithm", algorithmURI);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\algorithms\Algorithm.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */