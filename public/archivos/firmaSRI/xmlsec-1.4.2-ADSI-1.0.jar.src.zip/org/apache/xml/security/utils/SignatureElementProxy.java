/*    */ package org.apache.xml.security.utils;
/*    */ 
/*    */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SignatureElementProxy
/*    */   extends ElementProxy
/*    */ {
/*    */   protected SignatureElementProxy() {}
/*    */   
/*    */   public SignatureElementProxy(Document doc)
/*    */   {
/* 41 */     if (doc == null) {
/* 42 */       throw new RuntimeException("Document is null");
/*    */     }
/*    */     
/* 45 */     this._doc = doc;
/* 46 */     this._constructionElement = XMLUtils.createElementInSignatureSpace(this._doc, getBaseLocalName());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SignatureElementProxy(Element element, String BaseURI)
/*    */     throws XMLSecurityException
/*    */   {
/* 59 */     super(element, BaseURI);
/*    */   }
/*    */   
/*    */ 
/*    */   public String getBaseNamespace()
/*    */   {
/* 65 */     return "http://www.w3.org/2000/09/xmldsig#";
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\utils\SignatureElementProxy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */