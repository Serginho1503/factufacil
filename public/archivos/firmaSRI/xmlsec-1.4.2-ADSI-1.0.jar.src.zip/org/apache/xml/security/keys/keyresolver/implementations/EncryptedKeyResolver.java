/*     */ package org.apache.xml.security.keys.keyresolver.implementations;
/*     */ 
/*     */ import java.security.Key;
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.crypto.SecretKey;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.encryption.EncryptedKey;
/*     */ import org.apache.xml.security.encryption.XMLCipher;
/*     */ import org.apache.xml.security.keys.keyresolver.KeyResolverSpi;
/*     */ import org.apache.xml.security.keys.storage.StorageResolver;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EncryptedKeyResolver
/*     */   extends KeyResolverSpi
/*     */ {
/*  50 */   static Log log = LogFactory.getLog(RSAKeyValueResolver.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */   Key _kek;
/*     */   
/*     */ 
/*     */ 
/*     */   String _algorithm;
/*     */   
/*     */ 
/*     */ 
/*     */   public EncryptedKeyResolver(String algorithm)
/*     */   {
/*  64 */     this._kek = null;
/*  65 */     this._algorithm = algorithm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EncryptedKeyResolver(String algorithm, Key kek)
/*     */   {
/*  75 */     this._algorithm = algorithm;
/*  76 */     this._kek = kek;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PublicKey engineLookupAndResolvePublicKey(Element element, String BaseURI, StorageResolver storage)
/*     */   {
/*  84 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public X509Certificate engineLookupResolveX509Certificate(Element element, String BaseURI, StorageResolver storage)
/*     */   {
/*  90 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public SecretKey engineLookupAndResolveSecretKey(Element element, String BaseURI, StorageResolver storage)
/*     */   {
/*  96 */     SecretKey key = null;
/*  97 */     if (log.isDebugEnabled()) {
/*  98 */       log.debug("EncryptedKeyResolver - Can I resolve " + element.getTagName());
/*     */     }
/* 100 */     if (element == null) {
/* 101 */       return null;
/*     */     }
/*     */     
/* 104 */     boolean isEncryptedKey = XMLUtils.elementIsInEncryptionSpace(element, "EncryptedKey");
/*     */     
/*     */ 
/* 107 */     if (isEncryptedKey) {
/* 108 */       log.debug("Passed an Encrypted Key");
/*     */       try {
/* 110 */         XMLCipher cipher = XMLCipher.getInstance();
/* 111 */         cipher.init(4, this._kek);
/* 112 */         EncryptedKey ek = cipher.loadEncryptedKey(element);
/* 113 */         key = (SecretKey)cipher.decryptKey(ek, this._algorithm);
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */     
/* 118 */     return key;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\keyresolver\implementations\EncryptedKeyResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */