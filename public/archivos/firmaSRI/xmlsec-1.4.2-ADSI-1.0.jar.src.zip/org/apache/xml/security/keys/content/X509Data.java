/*     */ package org.apache.xml.security.keys.content;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import java.security.cert.X509Certificate;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.keys.content.x509.XMLX509CRL;
/*     */ import org.apache.xml.security.keys.content.x509.XMLX509Certificate;
/*     */ import org.apache.xml.security.keys.content.x509.XMLX509IssuerSerial;
/*     */ import org.apache.xml.security.keys.content.x509.XMLX509SKI;
/*     */ import org.apache.xml.security.keys.content.x509.XMLX509SubjectName;
/*     */ import org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class X509Data
/*     */   extends SignatureElementProxy
/*     */   implements KeyInfoContent
/*     */ {
/*  45 */   static Log log = LogFactory.getLog(X509Data.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Data(Document doc)
/*     */   {
/*  55 */     super(doc);
/*     */     
/*  57 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Data(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  70 */     super(element, BaseURI);
/*  71 */     Node sibling = this._constructionElement.getFirstChild();
/*  72 */     while (sibling != null) {
/*  73 */       if (sibling.getNodeType() != 1) {
/*  74 */         sibling = sibling.getNextSibling();
/*     */       }
/*     */       else {
/*  77 */         return;
/*     */       }
/*     */     }
/*  80 */     Object[] exArgs = { "Elements", "X509Data" };
/*  81 */     throw new XMLSecurityException("xml.WrongContent", exArgs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addIssuerSerial(String X509IssuerName, BigInteger X509SerialNumber)
/*     */   {
/*  92 */     add(new XMLX509IssuerSerial(this._doc, X509IssuerName, X509SerialNumber));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addIssuerSerial(String X509IssuerName, String X509SerialNumber)
/*     */   {
/* 103 */     add(new XMLX509IssuerSerial(this._doc, X509IssuerName, X509SerialNumber));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addIssuerSerial(String X509IssuerName, int X509SerialNumber)
/*     */   {
/* 114 */     add(new XMLX509IssuerSerial(this._doc, X509IssuerName, X509SerialNumber));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(XMLX509IssuerSerial xmlX509IssuerSerial)
/*     */   {
/* 125 */     this._constructionElement.appendChild(xmlX509IssuerSerial.getElement());
/*     */     
/* 127 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSKI(byte[] skiBytes)
/*     */   {
/* 136 */     add(new XMLX509SKI(this._doc, skiBytes));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSKI(X509Certificate x509certificate)
/*     */     throws XMLSecurityException
/*     */   {
/* 147 */     add(new XMLX509SKI(this._doc, x509certificate));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(XMLX509SKI xmlX509SKI)
/*     */   {
/* 156 */     this._constructionElement.appendChild(xmlX509SKI.getElement());
/* 157 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSubjectName(String subjectName)
/*     */   {
/* 166 */     add(new XMLX509SubjectName(this._doc, subjectName));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSubjectName(X509Certificate x509certificate)
/*     */   {
/* 175 */     add(new XMLX509SubjectName(this._doc, x509certificate));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(XMLX509SubjectName xmlX509SubjectName)
/*     */   {
/* 184 */     this._constructionElement.appendChild(xmlX509SubjectName.getElement());
/* 185 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addCertificate(X509Certificate x509certificate)
/*     */     throws XMLSecurityException
/*     */   {
/* 196 */     add(new XMLX509Certificate(this._doc, x509certificate));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addCertificate(byte[] x509certificateBytes)
/*     */   {
/* 205 */     add(new XMLX509Certificate(this._doc, x509certificateBytes));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(XMLX509Certificate xmlX509Certificate)
/*     */   {
/* 214 */     this._constructionElement.appendChild(xmlX509Certificate.getElement());
/* 215 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addCRL(byte[] crlBytes)
/*     */   {
/* 224 */     add(new XMLX509CRL(this._doc, crlBytes));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(XMLX509CRL xmlX509CRL)
/*     */   {
/* 233 */     this._constructionElement.appendChild(xmlX509CRL.getElement());
/* 234 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addUnknownElement(Element element)
/*     */   {
/* 243 */     this._constructionElement.appendChild(element);
/* 244 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int lengthIssuerSerial()
/*     */   {
/* 253 */     return length("http://www.w3.org/2000/09/xmldsig#", "X509IssuerSerial");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int lengthSKI()
/*     */   {
/* 263 */     return length("http://www.w3.org/2000/09/xmldsig#", "X509SKI");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int lengthSubjectName()
/*     */   {
/* 272 */     return length("http://www.w3.org/2000/09/xmldsig#", "X509SubjectName");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int lengthCertificate()
/*     */   {
/* 282 */     return length("http://www.w3.org/2000/09/xmldsig#", "X509Certificate");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int lengthCRL()
/*     */   {
/* 292 */     return length("http://www.w3.org/2000/09/xmldsig#", "X509CRL");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int lengthUnknownElement()
/*     */   {
/* 302 */     int result = 0;
/* 303 */     Node n = this._constructionElement.getFirstChild();
/* 304 */     while (n != null)
/*     */     {
/* 306 */       if ((n.getNodeType() == 1) && (!n.getNamespaceURI().equals("http://www.w3.org/2000/09/xmldsig#")))
/*     */       {
/* 308 */         result++;
/*     */       }
/* 310 */       n = n.getNextSibling();
/*     */     }
/*     */     
/* 313 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509IssuerSerial itemIssuerSerial(int i)
/*     */     throws XMLSecurityException
/*     */   {
/* 326 */     Element e = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), "X509IssuerSerial", i);
/*     */     
/*     */ 
/*     */ 
/* 330 */     if (e != null) {
/* 331 */       return new XMLX509IssuerSerial(e, this._baseURI);
/*     */     }
/* 333 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509SKI itemSKI(int i)
/*     */     throws XMLSecurityException
/*     */   {
/* 345 */     Element e = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), "X509SKI", i);
/*     */     
/*     */ 
/* 348 */     if (e != null) {
/* 349 */       return new XMLX509SKI(e, this._baseURI);
/*     */     }
/* 351 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509SubjectName itemSubjectName(int i)
/*     */     throws XMLSecurityException
/*     */   {
/* 364 */     Element e = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), "X509SubjectName", i);
/*     */     
/*     */ 
/* 367 */     if (e != null) {
/* 368 */       return new XMLX509SubjectName(e, this._baseURI);
/*     */     }
/* 370 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509Certificate itemCertificate(int i)
/*     */     throws XMLSecurityException
/*     */   {
/* 383 */     Element e = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), "X509Certificate", i);
/*     */     
/*     */ 
/* 386 */     if (e != null) {
/* 387 */       return new XMLX509Certificate(e, this._baseURI);
/*     */     }
/* 389 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509CRL itemCRL(int i)
/*     */     throws XMLSecurityException
/*     */   {
/* 401 */     Element e = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), "X509CRL", i);
/*     */     
/*     */ 
/* 404 */     if (e != null) {
/* 405 */       return new XMLX509CRL(e, this._baseURI);
/*     */     }
/* 407 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element itemUnknownElement(int i)
/*     */   {
/* 418 */     log.debug("itemUnknownElement not implemented:" + i);
/* 419 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsIssuerSerial()
/*     */   {
/* 428 */     return lengthIssuerSerial() > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsSKI()
/*     */   {
/* 437 */     return lengthSKI() > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsSubjectName()
/*     */   {
/* 446 */     return lengthSubjectName() > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsCertificate()
/*     */   {
/* 455 */     return lengthCertificate() > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsCRL()
/*     */   {
/* 464 */     return lengthCRL() > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsUnknownElement()
/*     */   {
/* 473 */     return lengthUnknownElement() > 0;
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 478 */     return "X509Data";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\content\X509Data.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */