/*     */ package org.apache.xml.security.keys.content.x509;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import java.security.Principal;
/*     */ import java.security.cert.X509Certificate;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.utils.RFC2253Parser;
/*     */ import org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLX509IssuerSerial
/*     */   extends SignatureElementProxy
/*     */   implements XMLX509DataContent
/*     */ {
/*  38 */   static Log log = LogFactory.getLog(XMLX509IssuerSerial.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509IssuerSerial(Element element, String baseURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  51 */     super(element, baseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509IssuerSerial(Document doc, String x509IssuerName, BigInteger x509SerialNumber)
/*     */   {
/*  64 */     super(doc);
/*  65 */     XMLUtils.addReturnToElement(this._constructionElement);
/*  66 */     addTextElement(x509IssuerName, "X509IssuerName");
/*  67 */     addTextElement(x509SerialNumber.toString(), "X509SerialNumber");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509IssuerSerial(Document doc, String x509IssuerName, String x509SerialNumber)
/*     */   {
/*  79 */     this(doc, x509IssuerName, new BigInteger(x509SerialNumber));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509IssuerSerial(Document doc, String x509IssuerName, int x509SerialNumber)
/*     */   {
/*  91 */     this(doc, x509IssuerName, new BigInteger(Integer.toString(x509SerialNumber)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509IssuerSerial(Document doc, X509Certificate x509certificate)
/*     */   {
/* 103 */     this(doc, RFC2253Parser.normalize(x509certificate.getIssuerDN().getName()), x509certificate.getSerialNumber());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BigInteger getSerialNumber()
/*     */   {
/* 115 */     String text = getTextFromChildElement("X509SerialNumber", "http://www.w3.org/2000/09/xmldsig#");
/*     */     
/* 117 */     if (log.isDebugEnabled()) {
/* 118 */       log.debug("X509SerialNumber text: " + text);
/*     */     }
/* 120 */     return new BigInteger(text);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSerialNumberInteger()
/*     */   {
/* 129 */     return getSerialNumber().intValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getIssuerName()
/*     */   {
/* 139 */     return RFC2253Parser.normalize(getTextFromChildElement("X509IssuerName", "http://www.w3.org/2000/09/xmldsig#"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 148 */     if (obj == null) {
/* 149 */       return false;
/*     */     }
/* 151 */     if (!getClass().getName().equals(obj.getClass().getName())) {
/* 152 */       return false;
/*     */     }
/*     */     
/* 155 */     XMLX509IssuerSerial other = (XMLX509IssuerSerial)obj;
/*     */     
/* 157 */     return (getSerialNumber().equals(other.getSerialNumber())) && (getIssuerName().equals(other.getIssuerName()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 164 */     return 82;
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 169 */     return "X509IssuerSerial";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\content\x509\XMLX509IssuerSerial.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */