/*    */ package org.apache.xml.security.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AlgorithmAlreadyRegisteredException
/*    */   extends XMLSecurityException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public AlgorithmAlreadyRegisteredException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public AlgorithmAlreadyRegisteredException(String _msgID)
/*    */   {
/* 50 */     super(_msgID);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public AlgorithmAlreadyRegisteredException(String _msgID, Object[] exArgs)
/*    */   {
/* 60 */     super(_msgID, exArgs);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public AlgorithmAlreadyRegisteredException(String _msgID, Exception _originalException)
/*    */   {
/* 71 */     super(_msgID, _originalException);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public AlgorithmAlreadyRegisteredException(String _msgID, Object[] exArgs, Exception _originalException)
/*    */   {
/* 83 */     super(_msgID, exArgs, _originalException);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\exceptions\AlgorithmAlreadyRegisteredException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */