/*     */ package org.apache.xml.security.keys.content.x509;
/*     */ 
/*     */ import java.security.Principal;
/*     */ import java.security.cert.X509Certificate;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.apache.xml.security.utils.RFC2253Parser;
/*     */ import org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLX509SubjectName
/*     */   extends SignatureElementProxy
/*     */   implements XMLX509DataContent
/*     */ {
/*     */   public XMLX509SubjectName(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  44 */     super(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509SubjectName(Document doc, String X509SubjectNameString)
/*     */   {
/*  55 */     super(doc);
/*     */     
/*  57 */     addText(X509SubjectNameString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509SubjectName(Document doc, X509Certificate x509certificate)
/*     */   {
/*  67 */     this(doc, RFC2253Parser.normalize(x509certificate.getSubjectDN().getName()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSubjectName()
/*     */   {
/*  78 */     return RFC2253Parser.normalize(getTextFromTextChild());
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/*  83 */     if (obj == null) {
/*  84 */       return false;
/*     */     }
/*     */     
/*  87 */     if (!getClass().getName().equals(obj.getClass().getName())) {
/*  88 */       return false;
/*     */     }
/*     */     
/*  91 */     XMLX509SubjectName other = (XMLX509SubjectName)obj;
/*  92 */     String otherSubject = other.getSubjectName();
/*  93 */     String thisSubject = getSubjectName();
/*     */     
/*  95 */     return thisSubject.equals(otherSubject);
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 101 */     return 52;
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 106 */     return "X509SubjectName";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\keys\content\x509\XMLX509SubjectName.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */