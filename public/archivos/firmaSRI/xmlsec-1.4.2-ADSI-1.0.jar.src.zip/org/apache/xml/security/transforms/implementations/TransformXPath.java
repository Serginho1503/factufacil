/*     */ package org.apache.xml.security.transforms.implementations;
/*     */ 
/*     */ import javax.xml.transform.TransformerException;
/*     */ import org.apache.xml.security.exceptions.XMLSecurityRuntimeException;
/*     */ import org.apache.xml.security.signature.NodeFilter;
/*     */ import org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import org.apache.xml.security.transforms.Transform;
/*     */ import org.apache.xml.security.transforms.TransformSpi;
/*     */ import org.apache.xml.security.transforms.TransformationException;
/*     */ import org.apache.xml.security.utils.CachedXPathAPIHolder;
/*     */ import org.apache.xml.security.utils.CachedXPathFuncHereAPI;
/*     */ import org.apache.xml.security.utils.XMLUtils;
/*     */ import org.apache.xml.utils.PrefixResolverDefault;
/*     */ import org.apache.xpath.objects.XObject;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransformXPath
/*     */   extends TransformSpi
/*     */ {
/*     */   public static final String implementedTransformURI = "http://www.w3.org/TR/1999/REC-xpath-19991116";
/*     */   
/*     */   protected String engineGetURI()
/*     */   {
/*  60 */     return "http://www.w3.org/TR/1999/REC-xpath-19991116";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, Transform _transformObject)
/*     */     throws TransformationException
/*     */   {
/*     */     try
/*     */     {
/*  86 */       CachedXPathAPIHolder.setDoc(_transformObject.getElement().getOwnerDocument());
/*     */       
/*     */ 
/*     */ 
/*  90 */       Element xpathElement = XMLUtils.selectDsNode(_transformObject.getElement().getFirstChild(), "XPath", 0);
/*     */       
/*     */ 
/*     */ 
/*  94 */       if (xpathElement == null) {
/*  95 */         Object[] exArgs = { "ds:XPath", "Transform" };
/*     */         
/*  97 */         throw new TransformationException("xml.WrongContent", exArgs);
/*     */       }
/*  99 */       Node xpathnode = xpathElement.getChildNodes().item(0);
/* 100 */       String str = CachedXPathFuncHereAPI.getStrFromNode(xpathnode);
/* 101 */       input.setNeedsToBeExpanded(needsCircunvent(str));
/* 102 */       if (xpathnode == null) {
/* 103 */         throw new DOMException((short)3, "Text must be in ds:Xpath");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 108 */       input.addNodeFilter(new XPathNodeFilter(xpathElement, xpathnode, str));
/* 109 */       input.setNodeSet(true);
/* 110 */       return input;
/*     */     } catch (DOMException ex) {
/* 112 */       throw new TransformationException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean needsCircunvent(String str)
/*     */   {
/* 123 */     return (str.indexOf("namespace") != -1) || (str.indexOf("name()") != -1);
/*     */   }
/*     */   
/*     */   static class XPathNodeFilter implements NodeFilter {
/*     */     PrefixResolverDefault prefixResolver;
/* 128 */     CachedXPathFuncHereAPI xPathFuncHereAPI = new CachedXPathFuncHereAPI(CachedXPathAPIHolder.getCachedXPathAPI());
/*     */     Node xpathnode;
/*     */     String str;
/*     */     
/*     */     XPathNodeFilter(Element xpathElement, Node xpathnode, String str)
/*     */     {
/* 134 */       this.xpathnode = xpathnode;
/* 135 */       this.str = str;
/* 136 */       this.prefixResolver = new PrefixResolverDefault(xpathElement);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public int isNodeInclude(Node currentNode)
/*     */     {
/*     */       try
/*     */       {
/* 145 */         XObject includeInResult = this.xPathFuncHereAPI.eval(currentNode, this.xpathnode, this.str, this.prefixResolver);
/*     */         
/* 147 */         if (includeInResult.bool())
/* 148 */           return 1;
/* 149 */         return 0;
/*     */       } catch (TransformerException e) {
/* 151 */         Object[] eArgs = { currentNode };
/* 152 */         throw new XMLSecurityRuntimeException("signature.Transform.node", eArgs, e);
/*     */       }
/*     */       catch (Exception e) {
/* 155 */         Object[] eArgs = { currentNode, new Short(currentNode.getNodeType()) };
/* 156 */         throw new XMLSecurityRuntimeException("signature.Transform.nodeAndType", eArgs, e);
/*     */       }
/*     */     }
/*     */     
/*     */     public int isNodeIncludeDO(Node n, int level) {
/* 161 */       return isNodeInclude(n);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\org\apache\xml\security\transforms\implementations\TransformXPath.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */