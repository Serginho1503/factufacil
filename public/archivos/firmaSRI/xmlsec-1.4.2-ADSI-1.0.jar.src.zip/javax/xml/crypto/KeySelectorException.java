/*     */ package javax.xml.crypto;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeySelectorException
/*     */   extends Exception
/*     */ {
/*     */   private static final long serialVersionUID = -7480033639322531109L;
/*     */   private Throwable cause;
/*     */   
/*     */   public KeySelectorException() {}
/*     */   
/*     */   public KeySelectorException(String message)
/*     */   {
/*  65 */     super(message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeySelectorException(String message, Throwable cause)
/*     */   {
/*  80 */     super(message);
/*  81 */     this.cause = cause;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeySelectorException(Throwable cause)
/*     */   {
/*  95 */     super(cause == null ? null : cause.toString());
/*  96 */     this.cause = cause;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Throwable getCause()
/*     */   {
/* 109 */     return this.cause;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printStackTrace()
/*     */   {
/* 117 */     super.printStackTrace();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printStackTrace(PrintStream s)
/*     */   {
/* 128 */     super.printStackTrace(s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printStackTrace(PrintWriter s)
/*     */   {
/* 139 */     super.printStackTrace(s);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\javax\xml\crypto\KeySelectorException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */