/*     */ package javax.xml.crypto.dom;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.xml.crypto.KeySelector;
/*     */ import javax.xml.crypto.URIDereferencer;
/*     */ import javax.xml.crypto.XMLCryptoContext;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMCryptoContext
/*     */   implements XMLCryptoContext
/*     */ {
/*  44 */   private HashMap nsMap = new HashMap();
/*  45 */   private HashMap idMap = new HashMap();
/*  46 */   private HashMap objMap = new HashMap();
/*     */   private String baseURI;
/*     */   private KeySelector ks;
/*     */   private URIDereferencer dereferencer;
/*  50 */   private HashMap propMap = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String defaultPrefix;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getNamespacePrefix(String namespaceURI, String defaultPrefix)
/*     */   {
/*  67 */     if (namespaceURI == null) {
/*  68 */       throw new NullPointerException("namespaceURI cannot be null");
/*     */     }
/*  70 */     String prefix = (String)this.nsMap.get(namespaceURI);
/*  71 */     return prefix != null ? prefix : defaultPrefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String putNamespacePrefix(String namespaceURI, String prefix)
/*     */   {
/*  81 */     if (namespaceURI == null) {
/*  82 */       throw new NullPointerException("namespaceURI is null");
/*     */     }
/*  84 */     return (String)this.nsMap.put(namespaceURI, prefix);
/*     */   }
/*     */   
/*     */   public String getDefaultNamespacePrefix() {
/*  88 */     return this.defaultPrefix;
/*     */   }
/*     */   
/*     */   public void setDefaultNamespacePrefix(String defaultPrefix) {
/*  92 */     this.defaultPrefix = defaultPrefix;
/*     */   }
/*     */   
/*     */   public String getBaseURI() {
/*  96 */     return this.baseURI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setBaseURI(String baseURI)
/*     */   {
/* 103 */     if (baseURI != null) {
/* 104 */       URI.create(baseURI);
/*     */     }
/* 106 */     this.baseURI = baseURI;
/*     */   }
/*     */   
/*     */   public URIDereferencer getURIDereferencer() {
/* 110 */     return this.dereferencer;
/*     */   }
/*     */   
/*     */   public void setURIDereferencer(URIDereferencer dereferencer) {
/* 114 */     this.dereferencer = dereferencer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getProperty(String name)
/*     */   {
/* 124 */     if (name == null) {
/* 125 */       throw new NullPointerException("name is null");
/*     */     }
/* 127 */     return this.propMap.get(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object setProperty(String name, Object value)
/*     */   {
/* 137 */     if (name == null) {
/* 138 */       throw new NullPointerException("name is null");
/*     */     }
/* 140 */     return this.propMap.put(name, value);
/*     */   }
/*     */   
/*     */   public KeySelector getKeySelector() {
/* 144 */     return this.ks;
/*     */   }
/*     */   
/*     */   public void setKeySelector(KeySelector ks) {
/* 148 */     this.ks = ks;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element getElementById(String idValue)
/*     */   {
/* 164 */     if (idValue == null) {
/* 165 */       throw new NullPointerException("idValue is null");
/*     */     }
/* 167 */     return (Element)this.idMap.get(idValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIdAttributeNS(Element element, String namespaceURI, String localName)
/*     */   {
/* 190 */     if (element == null) {
/* 191 */       throw new NullPointerException("element is null");
/*     */     }
/* 193 */     if (localName == null) {
/* 194 */       throw new NullPointerException("localName is null");
/*     */     }
/* 196 */     String idValue = element.getAttributeNS(namespaceURI, localName);
/* 197 */     if ((idValue == null) || (idValue.length() == 0)) {
/* 198 */       throw new IllegalArgumentException(localName + " is not an " + "attribute");
/*     */     }
/*     */     
/* 201 */     this.idMap.put(idValue, element);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator iterator()
/*     */   {
/* 217 */     return Collections.unmodifiableMap(this.idMap).entrySet().iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object get(Object key)
/*     */   {
/* 225 */     return this.objMap.get(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object put(Object key, Object value)
/*     */   {
/* 235 */     return this.objMap.put(key, value);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\javax\xml\crypto\dom\DOMCryptoContext.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */