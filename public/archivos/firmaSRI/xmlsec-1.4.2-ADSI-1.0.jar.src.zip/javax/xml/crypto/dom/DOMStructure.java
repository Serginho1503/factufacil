/*    */ package javax.xml.crypto.dom;
/*    */ 
/*    */ import javax.xml.crypto.XMLStructure;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DOMStructure
/*    */   implements XMLStructure
/*    */ {
/*    */   private final Node node;
/*    */   
/*    */   public DOMStructure(Node node)
/*    */   {
/* 57 */     if (node == null) {
/* 58 */       throw new NullPointerException("node cannot be null");
/*    */     }
/* 60 */     this.node = node;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Node getNode()
/*    */   {
/* 69 */     return this.node;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean isFeatureSupported(String feature)
/*    */   {
/* 76 */     if (feature == null) {
/* 77 */       throw new NullPointerException();
/*    */     }
/* 79 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\javax\xml\crypto\dom\DOMStructure.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */