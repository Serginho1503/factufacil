package javax.xml.crypto;

public abstract interface Data {}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\javax\xml\crypto\Data.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */