/*     */ package javax.xml.crypto.dsig;
/*     */ 
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.Provider;
/*     */ import java.security.Security;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.xml.crypto.NoSuchMechanismException;
/*     */ import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class XMLDSigSecurity
/*     */ {
/*     */   private static ProviderProperty getEngineClassName(String alg, Map.Entry attr, String engineType, String key, boolean mech)
/*     */     throws NoSuchAlgorithmException
/*     */   {
/*  66 */     Provider[] provs = Security.getProviders();
/*     */     
/*     */ 
/*     */ 
/*  70 */     boolean found = false;
/*  71 */     ProviderProperty entry = null;
/*  72 */     for (int i = 0; (i < provs.length) && (!found); i++) {
/*     */       try {
/*  74 */         entry = getEngineClassName(alg, attr, engineType, key, provs[i], mech);
/*     */         
/*  76 */         found = true;
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */     
/*  81 */     if (!found) {
/*  82 */       if (mech) {
/*  83 */         throw new NoSuchMechanismException("Mechanism type " + alg + " not available");
/*     */       }
/*     */       
/*  86 */       throw new NoSuchAlgorithmException("Algorithm type " + alg + " not available");
/*     */     }
/*     */     
/*     */ 
/*  90 */     return entry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ProviderProperty getEngineClassName(String alg, Map.Entry attr, String engineType, String key, Provider provider, boolean mech)
/*     */     throws NoSuchAlgorithmException
/*     */   {
/* 100 */     String className = getProviderProperty(key, attr, provider);
/* 101 */     if (className == null)
/*     */     {
/* 103 */       String stdName = getStandardName(alg, engineType, provider);
/* 104 */       if (stdName != null) {
/* 105 */         key = engineType + "." + stdName;
/*     */       }
/* 107 */       if ((stdName == null) || ((className = getProviderProperty(key, attr, provider)) == null))
/*     */       {
/* 109 */         if (mech) {
/* 110 */           throw new NoSuchMechanismException("no such mechanism type: " + alg + " for provider " + provider.getName());
/*     */         }
/*     */         
/*     */ 
/* 114 */         throw new NoSuchAlgorithmException("no such algorithm: " + alg + " for provider " + provider.getName());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 121 */     ProviderProperty entry = new ProviderProperty(null);
/* 122 */     entry.className = className;
/* 123 */     entry.provider = provider;
/* 124 */     return entry;
/*     */   }
/*     */   
/*     */   private static boolean checkSuperclass(Class subclass, Class superclass) {
/* 128 */     return superclass.isAssignableFrom(subclass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Object[] getImpl(String mechType, String type, Provider provider)
/*     */     throws NoSuchAlgorithmException
/*     */   {
/* 142 */     return getImpl(mechType, null, type, provider);
/*     */   }
/*     */   
/*     */   static Object[] getImpl(String alg, Map.Entry attr, String type, Provider provider) throws NoSuchAlgorithmException
/*     */   {
/* 147 */     Class typeClass = null;
/* 148 */     boolean m = true;
/* 149 */     if (type.equals("XMLSignatureFactory")) {
/* 150 */       typeClass = XMLSignatureFactory.class;
/* 151 */     } else if (type.equals("KeyInfoFactory")) {
/* 152 */       typeClass = KeyInfoFactory.class;
/* 153 */     } else if (type.equals("TransformService")) {
/* 154 */       typeClass = TransformService.class;
/* 155 */       m = false;
/*     */     }
/* 157 */     String key = type + "." + alg;
/* 158 */     if (provider == null) {
/* 159 */       return doGetImpl(type, typeClass, getEngineClassName(alg, attr, type, key, m), m);
/*     */     }
/*     */     
/*     */ 
/* 163 */     return doGetImpl(type, typeClass, getEngineClassName(alg, attr, type, key, provider, m), m);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Object[] doGetImpl(String type, Class typeClass, ProviderProperty pp, boolean mech)
/*     */     throws NoSuchAlgorithmException
/*     */   {
/* 172 */     String className = pp.className;
/* 173 */     String providerName = pp.provider.getName();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 180 */       ClassLoader cl = typeClass.getClassLoader();
/*     */       Class implClass;
/* 182 */       Class implClass; if (cl != null) {
/* 183 */         implClass = cl.loadClass(className);
/*     */       } else {
/* 185 */         implClass = Class.forName(className);
/*     */       }
/*     */       
/* 188 */       if (checkSuperclass(implClass, typeClass)) {
/* 189 */         return new Object[] { implClass.newInstance(), pp.provider };
/*     */       }
/* 191 */       if (mech) {
/* 192 */         throw new NoSuchMechanismException("class configured for " + type + ": " + className + " not a " + type);
/*     */       }
/*     */       
/*     */ 
/* 196 */       throw new NoSuchAlgorithmException("class configured for " + type + ": " + className + " not a " + type);
/*     */ 
/*     */     }
/*     */     catch (ClassNotFoundException e)
/*     */     {
/*     */ 
/* 202 */       if (mech) {
/* 203 */         throw new NoSuchMechanismException("class configured for " + type + "(provider: " + providerName + ")" + "cannot be found.\n", e);
/*     */       }
/*     */       
/*     */ 
/* 207 */       throw ((NoSuchAlgorithmException)new NoSuchAlgorithmException("class configured for " + type + "(provider: " + providerName + ")" + "cannot be found.\n").initCause(e));
/*     */ 
/*     */     }
/*     */     catch (InstantiationException e)
/*     */     {
/* 212 */       if (mech) {
/* 213 */         throw new NoSuchMechanismException("class " + className + " configured for " + type + "(provider: " + providerName + ") cannot be " + "instantiated. ", e);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 218 */       throw ((NoSuchAlgorithmException)new NoSuchAlgorithmException("class " + className + " configured for " + type + "(provider: " + providerName + ") cannot be " + "instantiated. ").initCause(e));
/*     */ 
/*     */     }
/*     */     catch (IllegalAccessException e)
/*     */     {
/*     */ 
/* 224 */       if (mech) {
/* 225 */         throw new NoSuchMechanismException("class " + className + " configured for " + type + "(provider: " + providerName + ") cannot be accessed.\n", e);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 230 */       throw ((NoSuchAlgorithmException)new NoSuchAlgorithmException("class " + className + " configured for " + type + "(provider: " + providerName + ") cannot be accessed.\n").initCause(e));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String getProviderProperty(String key, Map.Entry attr, Provider prov)
/*     */   {
/* 243 */     String prop = prov.getProperty(key);
/* 244 */     Enumeration e; if (prop == null)
/*     */     {
/*     */ 
/* 247 */       for (e = prov.keys(); e.hasMoreElements();) {
/* 248 */         String matchKey = (String)e.nextElement();
/* 249 */         if (key.equalsIgnoreCase(matchKey)) {
/* 250 */           prop = prov.getProperty(matchKey);
/* 251 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 256 */     if ((prop != null) && (attr != null) && 
/* 257 */       (!prov.entrySet().contains(attr)))
/*     */     {
/* 259 */       if ((!attr.getValue().equals("DOM")) || (prov.get(attr.getKey()) != null))
/*     */       {
/* 261 */         prop = null;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 266 */     return prop;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String getStandardName(String alias, String engineType, Provider prov)
/*     */   {
/* 274 */     return getProviderProperty("Alg.Alias." + engineType + "." + alias, null, prov);
/*     */   }
/*     */   
/*     */   private static class ProviderProperty
/*     */   {
/*     */     String className;
/*     */     Provider provider;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\javax\xml\crypto\dsig\XMLDSigSecurity.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */