/*     */ package javax.xml.crypto.dsig.spec;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XPathType
/*     */ {
/*     */   private final String expression;
/*     */   private final Filter filter;
/*     */   private Map nsMap;
/*     */   
/*     */   public static class Filter
/*     */   {
/*     */     private final String operation;
/*     */     
/*     */     private Filter(String operation)
/*     */     {
/*  73 */       this.operation = operation;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/*  82 */       return this.operation;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  88 */     public static final Filter INTERSECT = new Filter("intersect");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  93 */     public static final Filter SUBTRACT = new Filter("subtract");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  98 */     public static final Filter UNION = new Filter("union");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XPathType(String expression, Filter filter)
/*     */   {
/* 116 */     if (expression == null) {
/* 117 */       throw new NullPointerException("expression cannot be null");
/*     */     }
/* 119 */     if (filter == null) {
/* 120 */       throw new NullPointerException("filter cannot be null");
/*     */     }
/* 122 */     this.expression = expression;
/* 123 */     this.filter = filter;
/* 124 */     this.nsMap = Collections.EMPTY_MAP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XPathType(String expression, Filter filter, Map namespaceMap)
/*     */   {
/* 145 */     this(expression, filter);
/* 146 */     if (namespaceMap == null) {
/* 147 */       throw new NullPointerException("namespaceMap cannot be null");
/*     */     }
/* 149 */     this.nsMap = new HashMap(namespaceMap);
/* 150 */     Iterator entries = this.nsMap.entrySet().iterator();
/* 151 */     while (entries.hasNext()) {
/* 152 */       Map.Entry me = (Map.Entry)entries.next();
/* 153 */       if ((!(me.getKey() instanceof String)) || (!(me.getValue() instanceof String)))
/*     */       {
/* 155 */         throw new ClassCastException("not a String");
/*     */       }
/*     */     }
/* 158 */     this.nsMap = Collections.unmodifiableMap(this.nsMap);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getExpression()
/*     */   {
/* 167 */     return this.expression;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Filter getFilter()
/*     */   {
/* 176 */     return this.filter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map getNamespaceMap()
/*     */   {
/* 191 */     return this.nsMap;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\javax\xml\crypto\dsig\spec\XPathType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */