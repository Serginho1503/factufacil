/*     */ package javax.xml.crypto.dsig;
/*     */ 
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.Provider;
/*     */ import java.security.Security;
/*     */ import java.util.Map.Entry;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.XMLCryptoContext;
/*     */ import javax.xml.crypto.XMLStructure;
/*     */ import javax.xml.crypto.dsig.spec.TransformParameterSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TransformService
/*     */   implements Transform
/*     */ {
/*     */   private String algorithm;
/*     */   private String mechanism;
/*     */   private Provider provider;
/*     */   
/*     */   public static TransformService getInstance(String algorithm, String mechanismType)
/*     */     throws NoSuchAlgorithmException
/*     */   {
/* 143 */     if ((mechanismType == null) || (algorithm == null)) {
/* 144 */       throw new NullPointerException();
/*     */     }
/* 146 */     return findInstance(algorithm, mechanismType, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static TransformService getInstance(String algorithm, String mechanismType, Provider provider)
/*     */     throws NoSuchAlgorithmException
/*     */   {
/* 172 */     if ((mechanismType == null) || (algorithm == null) || (provider == null)) {
/* 173 */       throw new NullPointerException();
/*     */     }
/* 175 */     return findInstance(algorithm, mechanismType, provider);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static TransformService getInstance(String algorithm, String mechanismType, String provider)
/*     */     throws NoSuchAlgorithmException, NoSuchProviderException
/*     */   {
/* 205 */     if ((mechanismType == null) || (algorithm == null) || (provider == null)) {
/* 206 */       throw new NullPointerException();
/*     */     }
/* 208 */     Provider prov = Security.getProvider(provider);
/* 209 */     if (prov == null) {
/* 210 */       throw new NoSuchProviderException("cannot find provider named " + provider);
/*     */     }
/*     */     
/* 213 */     return findInstance(algorithm, mechanismType, prov);
/*     */   }
/*     */   
/*     */ 
/*     */   private static TransformService findInstance(String algorithm, String mechanismType, Provider provider)
/*     */     throws NoSuchAlgorithmException
/*     */   {
/* 220 */     Object[] objs = (Object[])XMLDSigSecurity.getImpl(algorithm, new MechanismMapEntry(algorithm, mechanismType), "TransformService", provider);
/*     */     
/*     */ 
/*     */ 
/* 224 */     TransformService spi = (TransformService)objs[0];
/* 225 */     spi.mechanism = mechanismType;
/* 226 */     spi.algorithm = algorithm;
/* 227 */     spi.provider = ((Provider)objs[1]);
/* 228 */     return spi;
/*     */   }
/*     */   
/*     */   private static class MechanismMapEntry implements Map.Entry {
/*     */     private final String mechanism;
/*     */     private final String key;
/*     */     
/* 235 */     MechanismMapEntry(String algorithm, String mechanism) { this.mechanism = mechanism;
/* 236 */       this.key = ("TransformService." + algorithm + " MechanismType");
/*     */     }
/*     */     
/* 239 */     public boolean equals(Object o) { if (!(o instanceof Map.Entry)) {
/* 240 */         return false;
/*     */       }
/* 242 */       Map.Entry e = (Map.Entry)o;
/* 243 */       return (getKey() == null ? e.getKey() == null : getKey().equals(e.getKey())) && (getValue() == null ? e.getValue() == null : getValue().equals(e.getValue()));
/*     */     }
/*     */     
/*     */ 
/*     */     public Object getKey()
/*     */     {
/* 249 */       return this.key;
/*     */     }
/*     */     
/* 252 */     public Object getValue() { return this.mechanism; }
/*     */     
/*     */     public Object setValue(Object value) {
/* 255 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/* 258 */     public int hashCode() { return (getKey() == null ? 0 : getKey().hashCode()) ^ (getValue() == null ? 0 : getValue().hashCode()); }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getMechanismType()
/*     */   {
/* 269 */     return this.mechanism;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getAlgorithm()
/*     */   {
/* 279 */     return this.algorithm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Provider getProvider()
/*     */   {
/* 288 */     return this.provider;
/*     */   }
/*     */   
/*     */   public abstract void init(TransformParameterSpec paramTransformParameterSpec)
/*     */     throws InvalidAlgorithmParameterException;
/*     */   
/*     */   public abstract void marshalParams(XMLStructure paramXMLStructure, XMLCryptoContext paramXMLCryptoContext)
/*     */     throws MarshalException;
/*     */   
/*     */   public abstract void init(XMLStructure paramXMLStructure, XMLCryptoContext paramXMLCryptoContext)
/*     */     throws InvalidAlgorithmParameterException;
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\javax\xml\crypto\dsig\TransformService.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */