package javax.xml.crypto.dsig.keyinfo;

import javax.xml.crypto.XMLStructure;

public abstract interface KeyName
  extends XMLStructure
{
  public abstract String getName();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\javax\xml\crypto\dsig\keyinfo\KeyName.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */