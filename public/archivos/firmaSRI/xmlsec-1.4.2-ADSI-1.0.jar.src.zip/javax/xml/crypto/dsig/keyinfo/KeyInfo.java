package javax.xml.crypto.dsig.keyinfo;

import java.util.List;
import javax.xml.crypto.MarshalException;
import javax.xml.crypto.XMLCryptoContext;
import javax.xml.crypto.XMLStructure;

public abstract interface KeyInfo
  extends XMLStructure
{
  public abstract List getContent();
  
  public abstract String getId();
  
  public abstract void marshal(XMLStructure paramXMLStructure, XMLCryptoContext paramXMLCryptoContext)
    throws MarshalException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\javax\xml\crypto\dsig\keyinfo\KeyInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */