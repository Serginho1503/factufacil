/*     */ package javax.xml.crypto.dsig.keyinfo;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.math.BigInteger;
/*     */ import java.security.AccessController;
/*     */ import java.security.KeyException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.Provider;
/*     */ import java.security.PublicKey;
/*     */ import java.security.Security;
/*     */ import java.util.List;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.NoSuchMechanismException;
/*     */ import javax.xml.crypto.URIDereferencer;
/*     */ import javax.xml.crypto.XMLStructure;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class KeyInfoFactory
/*     */ {
/*     */   private String mechanismType;
/*     */   private Provider provider;
/*     */   private static Class cl;
/* 107 */   private static final Class[] getImplParams = { String.class, String.class, Provider.class };
/*     */   
/*     */   static
/*     */   {
/*     */     try {
/* 112 */       cl = Class.forName("javax.xml.crypto.dsig.XMLDSigSecurity"); } catch (ClassNotFoundException cnfe) {} }
/*     */   
/* 114 */   private static Method getImplMethod = (Method)AccessController.doPrivileged(new PrivilegedAction()
/*     */   {
/*     */     public Object run() {
/* 117 */       Method m = null;
/*     */       try {
/* 119 */         m = KeyInfoFactory.cl.getDeclaredMethod("getImpl", KeyInfoFactory.getImplParams);
/* 120 */         if (m != null)
/* 121 */           m.setAccessible(true);
/*     */       } catch (NoSuchMethodException nsme) {}
/* 123 */       return m;
/*     */     }
/* 114 */   });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static KeyInfoFactory getInstance(String mechanismType)
/*     */   {
/* 161 */     if (mechanismType == null) {
/* 162 */       throw new NullPointerException("mechanismType cannot be null");
/*     */     }
/*     */     
/* 165 */     return findInstance(mechanismType, null);
/*     */   }
/*     */   
/*     */ 
/*     */   private static KeyInfoFactory findInstance(String mechanismType, Provider provider)
/*     */   {
/* 171 */     if (getImplMethod == null) {
/* 172 */       throw new NoSuchMechanismException("Cannot find " + mechanismType + " mechanism type");
/*     */     }
/*     */     
/*     */ 
/* 176 */     Object[] objs = null;
/*     */     try {
/* 178 */       objs = (Object[])getImplMethod.invoke(null, new Object[] { mechanismType, "KeyInfoFactory", provider });
/*     */     }
/*     */     catch (IllegalAccessException iae) {
/* 181 */       throw new NoSuchMechanismException("Cannot find " + mechanismType + " mechanism type", iae);
/*     */     }
/*     */     catch (InvocationTargetException ite) {
/* 184 */       throw new NoSuchMechanismException("Cannot find " + mechanismType + " mechanism type", ite);
/*     */     }
/*     */     
/*     */ 
/* 188 */     KeyInfoFactory factory = (KeyInfoFactory)objs[0];
/* 189 */     factory.mechanismType = mechanismType;
/* 190 */     factory.provider = ((Provider)objs[1]);
/* 191 */     return factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static KeyInfoFactory getInstance(String mechanismType, Provider provider)
/*     */   {
/* 217 */     if (mechanismType == null)
/* 218 */       throw new NullPointerException("mechanismType cannot be null");
/* 219 */     if (provider == null) {
/* 220 */       throw new NullPointerException("provider cannot be null");
/*     */     }
/*     */     
/* 223 */     return findInstance(mechanismType, provider);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static KeyInfoFactory getInstance(String mechanismType, String provider)
/*     */     throws NoSuchProviderException
/*     */   {
/* 253 */     if (mechanismType == null)
/* 254 */       throw new NullPointerException("mechanismType cannot be null");
/* 255 */     if (provider == null) {
/* 256 */       throw new NullPointerException("provider cannot be null");
/*     */     }
/*     */     
/* 259 */     Provider prov = Security.getProvider(provider);
/* 260 */     if (prov == null) {
/* 261 */       throw new NoSuchProviderException("cannot find provider named " + provider);
/*     */     }
/*     */     
/*     */ 
/* 265 */     return findInstance(mechanismType, prov);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static KeyInfoFactory getInstance()
/*     */   {
/* 289 */     return getInstance("DOM");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getMechanismType()
/*     */   {
/* 300 */     return this.mechanismType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Provider getProvider()
/*     */   {
/* 309 */     return this.provider;
/*     */   }
/*     */   
/*     */   public abstract KeyInfo newKeyInfo(List paramList);
/*     */   
/*     */   public abstract KeyInfo newKeyInfo(List paramList, String paramString);
/*     */   
/*     */   public abstract KeyName newKeyName(String paramString);
/*     */   
/*     */   public abstract KeyValue newKeyValue(PublicKey paramPublicKey)
/*     */     throws KeyException;
/*     */   
/*     */   public abstract PGPData newPGPData(byte[] paramArrayOfByte);
/*     */   
/*     */   public abstract PGPData newPGPData(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, List paramList);
/*     */   
/*     */   public abstract PGPData newPGPData(byte[] paramArrayOfByte, List paramList);
/*     */   
/*     */   public abstract RetrievalMethod newRetrievalMethod(String paramString);
/*     */   
/*     */   public abstract RetrievalMethod newRetrievalMethod(String paramString1, String paramString2, List paramList);
/*     */   
/*     */   public abstract X509Data newX509Data(List paramList);
/*     */   
/*     */   public abstract X509IssuerSerial newX509IssuerSerial(String paramString, BigInteger paramBigInteger);
/*     */   
/*     */   public abstract boolean isFeatureSupported(String paramString);
/*     */   
/*     */   public abstract URIDereferencer getURIDereferencer();
/*     */   
/*     */   public abstract KeyInfo unmarshalKeyInfo(XMLStructure paramXMLStructure)
/*     */     throws MarshalException;
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\javax\xml\crypto\dsig\keyinfo\KeyInfoFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */