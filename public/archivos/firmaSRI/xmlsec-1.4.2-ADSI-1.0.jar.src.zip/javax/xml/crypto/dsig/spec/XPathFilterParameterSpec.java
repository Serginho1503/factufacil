/*     */ package javax.xml.crypto.dsig.spec;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class XPathFilterParameterSpec
/*     */   implements TransformParameterSpec
/*     */ {
/*     */   private String xPath;
/*     */   private Map nsMap;
/*     */   
/*     */   public XPathFilterParameterSpec(String xPath)
/*     */   {
/*  59 */     if (xPath == null) {
/*  60 */       throw new NullPointerException();
/*     */     }
/*  62 */     this.xPath = xPath;
/*  63 */     this.nsMap = Collections.EMPTY_MAP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XPathFilterParameterSpec(String xPath, Map namespaceMap)
/*     */   {
/*  81 */     if ((xPath == null) || (namespaceMap == null)) {
/*  82 */       throw new NullPointerException();
/*     */     }
/*  84 */     this.xPath = xPath;
/*  85 */     this.nsMap = new HashMap(namespaceMap);
/*  86 */     Iterator entries = this.nsMap.entrySet().iterator();
/*  87 */     while (entries.hasNext()) {
/*  88 */       Map.Entry me = (Map.Entry)entries.next();
/*  89 */       if ((!(me.getKey() instanceof String)) || (!(me.getValue() instanceof String)))
/*     */       {
/*  91 */         throw new ClassCastException("not a String");
/*     */       }
/*     */     }
/*  94 */     this.nsMap = Collections.unmodifiableMap(this.nsMap);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getXPath()
/*     */   {
/* 103 */     return this.xPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map getNamespaceMap()
/*     */   {
/* 118 */     return this.nsMap;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\javax\xml\crypto\dsig\spec\XPathFilterParameterSpec.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */