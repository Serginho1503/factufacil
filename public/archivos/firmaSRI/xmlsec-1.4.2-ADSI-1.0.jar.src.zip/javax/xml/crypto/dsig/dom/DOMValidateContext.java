/*     */ package javax.xml.crypto.dsig.dom;
/*     */ 
/*     */ import java.security.Key;
/*     */ import javax.xml.crypto.KeySelector;
/*     */ import javax.xml.crypto.dom.DOMCryptoContext;
/*     */ import javax.xml.crypto.dsig.XMLValidateContext;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMValidateContext
/*     */   extends DOMCryptoContext
/*     */   implements XMLValidateContext
/*     */ {
/*     */   private Node node;
/*     */   
/*     */   public DOMValidateContext(KeySelector ks, Node node)
/*     */   {
/*  68 */     if (ks == null) {
/*  69 */       throw new NullPointerException("key selector is null");
/*     */     }
/*  71 */     if (node == null) {
/*  72 */       throw new NullPointerException("node is null");
/*     */     }
/*  74 */     setKeySelector(ks);
/*  75 */     this.node = node;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMValidateContext(Key validatingKey, Node node)
/*     */   {
/*  91 */     if (validatingKey == null) {
/*  92 */       throw new NullPointerException("validatingKey is null");
/*     */     }
/*  94 */     if (node == null) {
/*  95 */       throw new NullPointerException("node is null");
/*     */     }
/*  97 */     setKeySelector(KeySelector.singletonKeySelector(validatingKey));
/*  98 */     this.node = node;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNode(Node node)
/*     */   {
/* 109 */     if (node == null) {
/* 110 */       throw new NullPointerException();
/*     */     }
/* 112 */     this.node = node;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node getNode()
/*     */   {
/* 122 */     return this.node;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\javax\xml\crypto\dsig\dom\DOMValidateContext.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */