package javax.xml.crypto.dsig.spec;

public abstract interface C14NMethodParameterSpec
  extends TransformParameterSpec
{}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\javax\xml\crypto\dsig\spec\C14NMethodParameterSpec.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */