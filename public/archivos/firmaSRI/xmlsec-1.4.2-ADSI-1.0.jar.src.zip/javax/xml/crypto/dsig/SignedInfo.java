package javax.xml.crypto.dsig;

import java.io.InputStream;
import java.util.List;
import javax.xml.crypto.XMLStructure;

public abstract interface SignedInfo
  extends XMLStructure
{
  public abstract CanonicalizationMethod getCanonicalizationMethod();
  
  public abstract SignatureMethod getSignatureMethod();
  
  public abstract List getReferences();
  
  public abstract String getId();
  
  public abstract InputStream getCanonicalizedData();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\javax\xml\crypto\dsig\SignedInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */