/*     */ package javax.xml.crypto.dsig;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLSignatureException
/*     */   extends Exception
/*     */ {
/*     */   private static final long serialVersionUID = -3438102491013869995L;
/*     */   private Throwable cause;
/*     */   
/*     */   public XMLSignatureException() {}
/*     */   
/*     */   public XMLSignatureException(String message)
/*     */   {
/*  63 */     super(message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureException(String message, Throwable cause)
/*     */   {
/*  78 */     super(message);
/*  79 */     this.cause = cause;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureException(Throwable cause)
/*     */   {
/*  93 */     super(cause == null ? null : cause.toString());
/*  94 */     this.cause = cause;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Throwable getCause()
/*     */   {
/* 107 */     return this.cause;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printStackTrace()
/*     */   {
/* 115 */     super.printStackTrace();
/* 116 */     if (this.cause != null) {
/* 117 */       this.cause.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printStackTrace(PrintStream s)
/*     */   {
/* 128 */     super.printStackTrace(s);
/* 129 */     if (this.cause != null) {
/* 130 */       this.cause.printStackTrace(s);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printStackTrace(PrintWriter s)
/*     */   {
/* 141 */     super.printStackTrace(s);
/* 142 */     if (this.cause != null) {
/* 143 */       this.cause.printStackTrace(s);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\javax\xml\crypto\dsig\XMLSignatureException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */