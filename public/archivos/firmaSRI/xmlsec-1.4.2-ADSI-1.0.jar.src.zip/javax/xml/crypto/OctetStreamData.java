/*     */ package javax.xml.crypto;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OctetStreamData
/*     */   implements Data
/*     */ {
/*     */   private InputStream octetStream;
/*     */   private String uri;
/*     */   private String mimeType;
/*     */   
/*     */   public OctetStreamData(InputStream octetStream)
/*     */   {
/*  47 */     if (octetStream == null) {
/*  48 */       throw new NullPointerException("octetStream is null");
/*     */     }
/*  50 */     this.octetStream = octetStream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OctetStreamData(InputStream octetStream, String uri, String mimeType)
/*     */   {
/*  66 */     if (octetStream == null) {
/*  67 */       throw new NullPointerException("octetStream is null");
/*     */     }
/*  69 */     this.octetStream = octetStream;
/*  70 */     this.uri = uri;
/*  71 */     this.mimeType = mimeType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputStream getOctetStream()
/*     */   {
/*  80 */     return this.octetStream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getURI()
/*     */   {
/*  90 */     return this.uri;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMimeType()
/*     */   {
/* 100 */     return this.mimeType;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\javax\xml\crypto\OctetStreamData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */