/*     */ package javax.xml.crypto;
/*     */ 
/*     */ import java.security.Key;
/*     */ import javax.xml.crypto.dsig.keyinfo.KeyInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class KeySelector
/*     */ {
/*     */   public abstract KeySelectorResult select(KeyInfo paramKeyInfo, Purpose paramPurpose, AlgorithmMethod paramAlgorithmMethod, XMLCryptoContext paramXMLCryptoContext)
/*     */     throws KeySelectorException;
/*     */   
/*     */   public static class Purpose
/*     */   {
/*     */     private final String name;
/*     */     
/*     */     private Purpose(String name)
/*     */     {
/*  50 */       this.name = name;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/*  58 */       return this.name;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  63 */     public static final Purpose SIGN = new Purpose("sign");
/*     */     
/*     */ 
/*     */ 
/*  67 */     public static final Purpose VERIFY = new Purpose("verify");
/*     */     
/*     */ 
/*     */ 
/*  71 */     public static final Purpose ENCRYPT = new Purpose("encrypt");
/*     */     
/*     */ 
/*     */ 
/*  75 */     public static final Purpose DECRYPT = new Purpose("decrypt");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static KeySelector singletonKeySelector(Key key)
/*     */   {
/* 122 */     return new SingletonKeySelector(key);
/*     */   }
/*     */   
/*     */   private static class SingletonKeySelector extends KeySelector {
/*     */     private final Key key;
/*     */     
/*     */     SingletonKeySelector(Key key) {
/* 129 */       if (key == null) {
/* 130 */         throw new NullPointerException();
/*     */       }
/* 132 */       this.key = key;
/*     */     }
/*     */     
/*     */ 
/*     */     public KeySelectorResult select(KeyInfo keyInfo, KeySelector.Purpose purpose, AlgorithmMethod method, XMLCryptoContext context)
/*     */       throws KeySelectorException
/*     */     {
/* 139 */       new KeySelectorResult() {
/*     */         public Key getKey() {
/* 141 */           return KeySelector.SingletonKeySelector.this.key;
/*     */         }
/*     */       };
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.0.jar!\javax\xml\crypto\KeySelector.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */