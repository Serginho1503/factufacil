package javax.xml.crypto.dsig;

import java.security.spec.AlgorithmParameterSpec;
import javax.xml.crypto.AlgorithmMethod;
import javax.xml.crypto.XMLStructure;

public abstract interface DigestMethod
  extends XMLStructure, AlgorithmMethod
{
  public static final String SHA1 = "http://www.w3.org/2000/09/xmldsig#sha1";
  public static final String SHA256 = "http://www.w3.org/2001/04/xmlenc#sha256";
  public static final String SHA512 = "http://www.w3.org/2001/04/xmlenc#sha512";
  public static final String RIPEMD160 = "http://www.w3.org/2001/04/xmlenc#ripemd160";
  
  public abstract AlgorithmParameterSpec getParameterSpec();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\javax\xml\crypto\dsig\DigestMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */