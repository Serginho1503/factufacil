/*    */ package javax.xml.crypto.dsig.spec;
/*    */ 
/*    */ import javax.xml.crypto.XMLStructure;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class XSLTTransformParameterSpec
/*    */   implements TransformParameterSpec
/*    */ {
/*    */   private XMLStructure stylesheet;
/*    */   
/*    */   public XSLTTransformParameterSpec(XMLStructure stylesheet)
/*    */   {
/* 58 */     if (stylesheet == null) {
/* 59 */       throw new NullPointerException();
/*    */     }
/* 61 */     this.stylesheet = stylesheet;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public XMLStructure getStylesheet()
/*    */   {
/* 70 */     return this.stylesheet;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\javax\xml\crypto\dsig\spec\XSLTTransformParameterSpec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */