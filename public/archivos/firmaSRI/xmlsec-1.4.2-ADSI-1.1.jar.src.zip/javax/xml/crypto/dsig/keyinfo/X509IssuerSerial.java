package javax.xml.crypto.dsig.keyinfo;

import java.math.BigInteger;
import javax.xml.crypto.XMLStructure;

public abstract interface X509IssuerSerial
  extends XMLStructure
{
  public abstract String getIssuerName();
  
  public abstract BigInteger getSerialNumber();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\javax\xml\crypto\dsig\keyinfo\X509IssuerSerial.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */