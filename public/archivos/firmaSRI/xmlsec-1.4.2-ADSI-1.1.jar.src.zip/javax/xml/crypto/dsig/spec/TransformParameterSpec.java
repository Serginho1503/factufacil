package javax.xml.crypto.dsig.spec;

import java.security.spec.AlgorithmParameterSpec;

public abstract interface TransformParameterSpec
  extends AlgorithmParameterSpec
{}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\javax\xml\crypto\dsig\spec\TransformParameterSpec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */