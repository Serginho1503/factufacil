/*     */ package javax.xml.crypto.dsig.dom;
/*     */ 
/*     */ import java.security.Key;
/*     */ import javax.xml.crypto.KeySelector;
/*     */ import javax.xml.crypto.dom.DOMCryptoContext;
/*     */ import javax.xml.crypto.dsig.XMLSignContext;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMSignContext
/*     */   extends DOMCryptoContext
/*     */   implements XMLSignContext
/*     */ {
/*     */   private Node parent;
/*     */   private Node nextSibling;
/*     */   
/*     */   public DOMSignContext(Key signingKey, Node parent)
/*     */   {
/*  67 */     if (signingKey == null) {
/*  68 */       throw new NullPointerException("signingKey cannot be null");
/*     */     }
/*  70 */     if (parent == null) {
/*  71 */       throw new NullPointerException("parent cannot be null");
/*     */     }
/*  73 */     setKeySelector(KeySelector.singletonKeySelector(signingKey));
/*  74 */     this.parent = parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMSignContext(Key signingKey, Node parent, Node nextSibling)
/*     */   {
/*  93 */     if (signingKey == null) {
/*  94 */       throw new NullPointerException("signingKey cannot be null");
/*     */     }
/*  96 */     if (parent == null) {
/*  97 */       throw new NullPointerException("parent cannot be null");
/*     */     }
/*  99 */     if (nextSibling == null) {
/* 100 */       throw new NullPointerException("nextSibling cannot be null");
/*     */     }
/* 102 */     setKeySelector(KeySelector.singletonKeySelector(signingKey));
/* 103 */     this.parent = parent;
/* 104 */     this.nextSibling = nextSibling;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMSignContext(KeySelector ks, Node parent)
/*     */   {
/* 120 */     if (ks == null) {
/* 121 */       throw new NullPointerException("key selector cannot be null");
/*     */     }
/* 123 */     if (parent == null) {
/* 124 */       throw new NullPointerException("parent cannot be null");
/*     */     }
/* 126 */     setKeySelector(ks);
/* 127 */     this.parent = parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMSignContext(KeySelector ks, Node parent, Node nextSibling)
/*     */   {
/* 143 */     if (ks == null) {
/* 144 */       throw new NullPointerException("key selector cannot be null");
/*     */     }
/* 146 */     if (parent == null) {
/* 147 */       throw new NullPointerException("parent cannot be null");
/*     */     }
/* 149 */     if (nextSibling == null) {
/* 150 */       throw new NullPointerException("nextSibling cannot be null");
/*     */     }
/* 152 */     setKeySelector(ks);
/* 153 */     this.parent = parent;
/* 154 */     this.nextSibling = nextSibling;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParent(Node parent)
/*     */   {
/* 166 */     if (parent == null) {
/* 167 */       throw new NullPointerException("parent is null");
/*     */     }
/* 169 */     this.parent = parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNextSibling(Node nextSibling)
/*     */   {
/* 181 */     this.nextSibling = nextSibling;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node getParent()
/*     */   {
/* 191 */     return this.parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node getNextSibling()
/*     */   {
/* 201 */     return this.nextSibling;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\javax\xml\crypto\dsig\dom\DOMSignContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */