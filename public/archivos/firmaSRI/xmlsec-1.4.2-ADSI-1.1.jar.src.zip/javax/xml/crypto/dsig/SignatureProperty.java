package javax.xml.crypto.dsig;

import java.util.List;
import javax.xml.crypto.XMLStructure;

public abstract interface SignatureProperty
  extends XMLStructure
{
  public abstract String getTarget();
  
  public abstract String getId();
  
  public abstract List getContent();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\javax\xml\crypto\dsig\SignatureProperty.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */