package javax.xml.crypto.dsig.keyinfo;

import java.util.List;
import javax.xml.crypto.XMLStructure;

public abstract interface PGPData
  extends XMLStructure
{
  public static final String TYPE = "http://www.w3.org/2000/09/xmldsig#PGPData";
  
  public abstract byte[] getKeyId();
  
  public abstract byte[] getKeyPacket();
  
  public abstract List getExternalElements();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\javax\xml\crypto\dsig\keyinfo\PGPData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */