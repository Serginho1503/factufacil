/*    */ package javax.xml.crypto.dsig.spec;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class XPathFilter2ParameterSpec
/*    */   implements TransformParameterSpec
/*    */ {
/*    */   private final List xPathList;
/*    */   
/*    */   public XPathFilter2ParameterSpec(List xPathList)
/*    */   {
/* 57 */     if (xPathList == null) {
/* 58 */       throw new NullPointerException("xPathList cannot be null");
/*    */     }
/* 60 */     List xPathListCopy = new ArrayList(xPathList);
/* 61 */     if (xPathListCopy.isEmpty()) {
/* 62 */       throw new IllegalArgumentException("xPathList cannot be empty");
/*    */     }
/* 64 */     int size = xPathListCopy.size();
/* 65 */     for (int i = 0; i < size; i++) {
/* 66 */       if (!(xPathListCopy.get(i) instanceof XPathType)) {
/* 67 */         throw new ClassCastException(
/* 68 */           "xPathList[" + i + "] is not a valid type");
/*    */       }
/*    */     }
/* 71 */     this.xPathList = Collections.unmodifiableList(xPathListCopy);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public List getXPathList()
/*    */   {
/* 84 */     return this.xPathList;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\javax\xml\crypto\dsig\spec\XPathFilter2ParameterSpec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */