package javax.xml.crypto.dsig;

import java.util.List;
import javax.xml.crypto.XMLStructure;

public abstract interface Manifest
  extends XMLStructure
{
  public static final String TYPE = "http://www.w3.org/2000/09/xmldsig#Manifest";
  
  public abstract String getId();
  
  public abstract List getReferences();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\javax\xml\crypto\dsig\Manifest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */