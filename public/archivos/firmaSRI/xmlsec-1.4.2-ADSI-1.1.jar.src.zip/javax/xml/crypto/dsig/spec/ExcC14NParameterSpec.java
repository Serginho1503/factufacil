/*     */ package javax.xml.crypto.dsig.spec;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExcC14NParameterSpec
/*     */   implements C14NMethodParameterSpec
/*     */ {
/*     */   private List preList;
/*     */   public static final String DEFAULT = "#default";
/*     */   
/*     */   public ExcC14NParameterSpec()
/*     */   {
/*  68 */     this.preList = Collections.EMPTY_LIST;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExcC14NParameterSpec(List prefixList)
/*     */   {
/*  84 */     if (prefixList == null) {
/*  85 */       throw new NullPointerException("prefixList cannot be null");
/*     */     }
/*  87 */     this.preList = new ArrayList(prefixList);
/*  88 */     int i = 0; for (int size = this.preList.size(); i < size; i++) {
/*  89 */       if (!(this.preList.get(i) instanceof String)) {
/*  90 */         throw new ClassCastException("not a String");
/*     */       }
/*     */     }
/*  93 */     this.preList = Collections.unmodifiableList(this.preList);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getPrefixList()
/*     */   {
/* 107 */     return this.preList;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\javax\xml\crypto\dsig\spec\ExcC14NParameterSpec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */