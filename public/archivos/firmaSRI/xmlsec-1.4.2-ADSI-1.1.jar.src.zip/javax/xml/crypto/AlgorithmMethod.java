package javax.xml.crypto;

import java.security.spec.AlgorithmParameterSpec;

public abstract interface AlgorithmMethod
{
  public abstract String getAlgorithm();
  
  public abstract AlgorithmParameterSpec getParameterSpec();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\javax\xml\crypto\AlgorithmMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */