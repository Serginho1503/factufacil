package javax.xml.crypto.dom;

import javax.xml.crypto.URIReference;
import org.w3c.dom.Node;

public abstract interface DOMURIReference
  extends URIReference
{
  public abstract Node getHere();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\javax\xml\crypto\dom\DOMURIReference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */