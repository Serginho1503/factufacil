package javax.xml.crypto;

public abstract interface URIReference
{
  public abstract String getURI();
  
  public abstract String getType();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\javax\xml\crypto\URIReference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */