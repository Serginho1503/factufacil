/*    */ package org.jcp.xml.dsig.internal.dom;
/*    */ 
/*    */ import adsi.org.apache.xml.security.Init;
/*    */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*    */ import adsi.org.apache.xml.security.utils.IdResolver;
/*    */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolver;
/*    */ import javax.xml.crypto.Data;
/*    */ import javax.xml.crypto.URIDereferencer;
/*    */ import javax.xml.crypto.URIReference;
/*    */ import javax.xml.crypto.URIReferenceException;
/*    */ import javax.xml.crypto.XMLCryptoContext;
/*    */ import javax.xml.crypto.dom.DOMCryptoContext;
/*    */ import javax.xml.crypto.dom.DOMURIReference;
/*    */ import org.w3c.dom.Attr;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DOMURIDereferencer
/*    */   implements URIDereferencer
/*    */ {
/* 45 */   static final URIDereferencer INSTANCE = new DOMURIDereferencer();
/*    */   
/*    */ 
/*    */   private DOMURIDereferencer()
/*    */   {
/* 50 */     Init.init();
/*    */   }
/*    */   
/*    */   public Data dereference(URIReference uriRef, XMLCryptoContext context)
/*    */     throws URIReferenceException
/*    */   {
/* 56 */     if (uriRef == null) {
/* 57 */       throw new NullPointerException("uriRef cannot be null");
/*    */     }
/* 59 */     if (context == null) {
/* 60 */       throw new NullPointerException("context cannot be null");
/*    */     }
/*    */     
/* 63 */     DOMURIReference domRef = (DOMURIReference)uriRef;
/* 64 */     Attr uriAttr = (Attr)domRef.getHere();
/* 65 */     String uri = uriRef.getURI();
/* 66 */     DOMCryptoContext dcc = (DOMCryptoContext)context;
/*    */     
/*    */ 
/* 69 */     if ((uri != null) && (uri.length() != 0) && (uri.charAt(0) == '#')) {
/* 70 */       String id = uri.substring(1);
/*    */       
/* 72 */       if (id.startsWith("xpointer(id(")) {
/* 73 */         int i1 = id.indexOf('\'');
/* 74 */         int i2 = id.indexOf('\'', i1 + 1);
/* 75 */         id = id.substring(i1 + 1, i2);
/*    */       }
/*    */       
/*    */ 
/*    */ 
/*    */ 
/* 81 */       Node referencedElem = dcc.getElementById(id);
/* 82 */       if (referencedElem != null) {
/* 83 */         IdResolver.registerElementById((Element)referencedElem, id);
/*    */       }
/*    */     }
/*    */     try
/*    */     {
/* 88 */       String baseURI = context.getBaseURI();
/* 89 */       ResourceResolver apacheResolver = 
/* 90 */         ResourceResolver.getInstance(uriAttr, baseURI);
/* 91 */       XMLSignatureInput in = apacheResolver.resolve(uriAttr, baseURI);
/* 92 */       if (in.isOctetStream()) {
/* 93 */         return new ApacheOctetStreamData(in);
/*    */       }
/* 95 */       return new ApacheNodeSetData(in);
/*    */     }
/*    */     catch (Exception e) {
/* 98 */       throw new URIReferenceException(e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\org\jcp\xml\dsig\internal\dom\DOMURIDereferencer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */