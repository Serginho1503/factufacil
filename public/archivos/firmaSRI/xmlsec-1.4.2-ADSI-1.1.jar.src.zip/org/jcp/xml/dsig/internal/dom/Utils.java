/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Utils
/*     */ {
/*     */   public static byte[] readBytesFromStream(InputStream is)
/*     */     throws IOException
/*     */   {
/*  43 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*  44 */     byte[] buf = new byte['Ѐ'];
/*     */     int read;
/*  46 */     do { read = is.read(buf);
/*  47 */       if (read == -1) {
/*     */         break;
/*     */       }
/*  50 */       baos.write(buf, 0, read);
/*  51 */     } while (read >= 1024);
/*     */     
/*     */ 
/*     */ 
/*  55 */     return baos.toByteArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Set toNodeSet(Iterator i)
/*     */   {
/*  66 */     Set nodeSet = new HashSet();
/*  67 */     while (i.hasNext()) {
/*  68 */       Node n = (Node)i.next();
/*  69 */       nodeSet.add(n);
/*     */       
/*  71 */       if (n.getNodeType() == 1) {
/*  72 */         NamedNodeMap nnm = n.getAttributes();
/*  73 */         int j = 0; for (int length = nnm.getLength(); j < length; j++) {
/*  74 */           nodeSet.add(nnm.item(j));
/*     */         }
/*     */       }
/*     */     }
/*  78 */     return nodeSet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String parseIdFromSameDocumentURI(String uri)
/*     */   {
/*  85 */     if (uri.length() == 0) {
/*  86 */       return null;
/*     */     }
/*  88 */     String id = uri.substring(1);
/*  89 */     if ((id != null) && (id.startsWith("xpointer(id("))) {
/*  90 */       int i1 = id.indexOf('\'');
/*  91 */       int i2 = id.indexOf('\'', i1 + 1);
/*  92 */       id = id.substring(i1 + 1, i2);
/*     */     }
/*  94 */     return id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean sameDocumentURI(String uri)
/*     */   {
/* 101 */     return (uri != null) && ((uri.length() == 0) || (uri.charAt(0) == '#'));
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\org\jcp\xml\dsig\internal\dom\Utils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */