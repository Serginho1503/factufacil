/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import adsi.org.apache.xml.security.c14n.Canonicalizer;
/*     */ import adsi.org.apache.xml.security.c14n.InvalidCanonicalizerException;
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.spec.AlgorithmParameterSpec;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.crypto.Data;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.XMLCryptoContext;
/*     */ import javax.xml.crypto.XMLStructure;
/*     */ import javax.xml.crypto.dsig.TransformException;
/*     */ import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
/*     */ import javax.xml.crypto.dsig.spec.ExcC14NParameterSpec;
/*     */ import javax.xml.crypto.dsig.spec.TransformParameterSpec;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DOMExcC14NMethod
/*     */   extends ApacheCanonicalizer
/*     */ {
/*     */   public void init(TransformParameterSpec params)
/*     */     throws InvalidAlgorithmParameterException
/*     */   {
/*  50 */     if (params != null) {
/*  51 */       if (!(params instanceof ExcC14NParameterSpec)) {
/*  52 */         throw new InvalidAlgorithmParameterException(
/*  53 */           "params must be of type ExcC14NParameterSpec");
/*     */       }
/*  55 */       this.params = ((C14NMethodParameterSpec)params);
/*     */     }
/*     */   }
/*     */   
/*     */   public void init(XMLStructure parent, XMLCryptoContext context) throws InvalidAlgorithmParameterException
/*     */   {
/*  61 */     super.init(parent, context);
/*  62 */     Element paramsElem = DOMUtils.getFirstChildElement(this.transformElem);
/*  63 */     if (paramsElem == null) {
/*  64 */       this.params = null;
/*  65 */       this.inclusiveNamespaces = null;
/*  66 */       return;
/*     */     }
/*  68 */     unmarshalParams(paramsElem);
/*     */   }
/*     */   
/*     */   private void unmarshalParams(Element paramsElem) {
/*  72 */     String prefixListAttr = paramsElem.getAttributeNS(null, "PrefixList");
/*  73 */     this.inclusiveNamespaces = prefixListAttr;
/*  74 */     int begin = 0;
/*  75 */     int end = prefixListAttr.indexOf(' ');
/*  76 */     List prefixList = new ArrayList();
/*  77 */     while (end != -1) {
/*  78 */       prefixList.add(prefixListAttr.substring(begin, end));
/*  79 */       begin = end + 1;
/*  80 */       end = prefixListAttr.indexOf(' ', begin);
/*     */     }
/*  82 */     if (begin <= prefixListAttr.length()) {
/*  83 */       prefixList.add(prefixListAttr.substring(begin));
/*     */     }
/*  85 */     this.params = new ExcC14NParameterSpec(prefixList);
/*     */   }
/*     */   
/*     */   public void marshalParams(XMLStructure parent, XMLCryptoContext context)
/*     */     throws MarshalException
/*     */   {
/*  91 */     super.marshalParams(parent, context);
/*  92 */     AlgorithmParameterSpec spec = getParameterSpec();
/*  93 */     if (spec == null) {
/*  94 */       return;
/*     */     }
/*     */     
/*  97 */     String prefix = 
/*  98 */       DOMUtils.getNSPrefix(context, "http://www.w3.org/2001/10/xml-exc-c14n#");
/*  99 */     Element excElem = DOMUtils.createElement(
/* 100 */       this.ownerDoc, "InclusiveNamespaces", 
/* 101 */       "http://www.w3.org/2001/10/xml-exc-c14n#", prefix);
/* 102 */     if ((prefix == null) || (prefix.length() == 0)) {
/* 103 */       excElem.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns", 
/* 104 */         "http://www.w3.org/2001/10/xml-exc-c14n#");
/*     */     } else {
/* 106 */       excElem.setAttributeNS("http://www.w3.org/2000/xmlns/", 
/* 107 */         "xmlns:" + prefix, "http://www.w3.org/2001/10/xml-exc-c14n#");
/*     */     }
/*     */     
/* 110 */     ExcC14NParameterSpec params = (ExcC14NParameterSpec)spec;
/* 111 */     StringBuffer prefixListAttr = new StringBuffer("");
/* 112 */     List prefixList = params.getPrefixList();
/* 113 */     int i = 0; for (int size = prefixList.size(); i < size; i++) {
/* 114 */       prefixListAttr.append((String)prefixList.get(i));
/* 115 */       if (i < size - 1) {
/* 116 */         prefixListAttr.append(" ");
/*     */       }
/*     */     }
/* 119 */     DOMUtils.setAttribute(excElem, "PrefixList", prefixListAttr.toString());
/* 120 */     this.inclusiveNamespaces = prefixListAttr.toString();
/* 121 */     this.transformElem.appendChild(excElem);
/*     */   }
/*     */   
/*     */   public String getParamsNSURI() {
/* 125 */     return "http://www.w3.org/2001/10/xml-exc-c14n#";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Data transform(Data data, XMLCryptoContext xc)
/*     */     throws TransformException
/*     */   {
/* 134 */     if ((data instanceof DOMSubTreeData)) {
/* 135 */       DOMSubTreeData subTree = (DOMSubTreeData)data;
/* 136 */       if (subTree.excludeComments()) {
/*     */         try {
/* 138 */           this.apacheCanonicalizer = Canonicalizer.getInstance(
/* 139 */             "http://www.w3.org/2001/10/xml-exc-c14n#");
/*     */         } catch (InvalidCanonicalizerException ice) {
/* 141 */           throw new TransformException(
/* 142 */             "Couldn't find Canonicalizer for: http://www.w3.org/2001/10/xml-exc-c14n#: " + 
/*     */             
/* 144 */             ice.getMessage(), ice);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 149 */     return canonicalize(data, xc);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\org\jcp\xml\dsig\internal\dom\DOMExcC14NMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */