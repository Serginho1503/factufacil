/*    */ package org.jcp.xml.dsig.internal.dom;
/*    */ 
/*    */ import javax.xml.crypto.MarshalException;
/*    */ import javax.xml.crypto.dom.DOMCryptoContext;
/*    */ import javax.xml.crypto.dsig.keyinfo.KeyName;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DOMKeyName
/*    */   extends DOMStructure
/*    */   implements KeyName
/*    */ {
/*    */   private final String name;
/*    */   
/*    */   public DOMKeyName(String name)
/*    */   {
/* 50 */     if (name == null) {
/* 51 */       throw new NullPointerException("name cannot be null");
/*    */     }
/* 53 */     this.name = name;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public DOMKeyName(Element knElem)
/*    */   {
/* 62 */     this.name = knElem.getFirstChild().getNodeValue();
/*    */   }
/*    */   
/*    */   public String getName() {
/* 66 */     return this.name;
/*    */   }
/*    */   
/*    */   public void marshal(Node parent, String dsPrefix, DOMCryptoContext context) throws MarshalException
/*    */   {
/* 71 */     Document ownerDoc = DOMUtils.getOwnerDocument(parent);
/*    */     
/* 73 */     Element knElem = DOMUtils.createElement(
/* 74 */       ownerDoc, "KeyName", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/* 75 */     knElem.appendChild(ownerDoc.createTextNode(this.name));
/* 76 */     parent.appendChild(knElem);
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 80 */     if (this == obj) {
/* 81 */       return true;
/*    */     }
/* 83 */     if (!(obj instanceof KeyName)) {
/* 84 */       return false;
/*    */     }
/* 86 */     KeyName okn = (KeyName)obj;
/* 87 */     return this.name.equals(okn.getName());
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 91 */     if (!$assertionsDisabled) throw new AssertionError("hashCode not designed");
/* 92 */     return 44;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\org\jcp\xml\dsig\internal\dom\DOMKeyName.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */