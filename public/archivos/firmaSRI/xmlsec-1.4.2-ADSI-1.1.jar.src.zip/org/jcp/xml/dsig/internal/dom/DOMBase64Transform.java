/*    */ package org.jcp.xml.dsig.internal.dom;
/*    */ 
/*    */ import java.security.InvalidAlgorithmParameterException;
/*    */ import javax.xml.crypto.dsig.spec.TransformParameterSpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DOMBase64Transform
/*    */   extends ApacheTransform
/*    */ {
/*    */   public void init(TransformParameterSpec params)
/*    */     throws InvalidAlgorithmParameterException
/*    */   {
/* 40 */     if (params != null) {
/* 41 */       throw new InvalidAlgorithmParameterException("params must be null");
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\org\jcp\xml\dsig\internal\dom\DOMBase64Transform.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */