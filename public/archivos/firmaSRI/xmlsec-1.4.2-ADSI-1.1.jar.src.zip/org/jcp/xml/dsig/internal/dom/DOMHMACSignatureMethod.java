/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.Key;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.SignatureException;
/*     */ import java.security.spec.AlgorithmParameterSpec;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.crypto.Mac;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.dsig.XMLSignContext;
/*     */ import javax.xml.crypto.dsig.XMLSignatureException;
/*     */ import javax.xml.crypto.dsig.XMLValidateContext;
/*     */ import javax.xml.crypto.dsig.spec.HMACParameterSpec;
/*     */ import javax.xml.crypto.dsig.spec.SignatureMethodParameterSpec;
/*     */ import org.jcp.xml.dsig.internal.MacOutputStream;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DOMHMACSignatureMethod
/*     */   extends DOMSignatureMethod
/*     */ {
/*  54 */   private static Logger log = Logger.getLogger("org.jcp.xml.dsig.internal.dom");
/*     */   
/*     */ 
/*     */   private Mac hmac;
/*     */   
/*     */ 
/*     */   private int outputLength;
/*     */   
/*     */ 
/*     */   DOMHMACSignatureMethod(AlgorithmParameterSpec params)
/*     */     throws InvalidAlgorithmParameterException
/*     */   {
/*  66 */     super(params);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   DOMHMACSignatureMethod(Element smElem)
/*     */     throws MarshalException
/*     */   {
/*  75 */     super(smElem);
/*     */   }
/*     */   
/*     */   void checkParams(SignatureMethodParameterSpec params) throws InvalidAlgorithmParameterException
/*     */   {
/*  80 */     if (params != null) {
/*  81 */       if (!(params instanceof HMACParameterSpec)) {
/*  82 */         throw new InvalidAlgorithmParameterException(
/*  83 */           "params must be of type HMACParameterSpec");
/*     */       }
/*  85 */       this.outputLength = ((HMACParameterSpec)params).getOutputLength();
/*  86 */       if (log.isLoggable(Level.FINE)) {
/*  87 */         log.log(Level.FINE, 
/*  88 */           "Setting outputLength from HMACParameterSpec to: " + 
/*  89 */           this.outputLength);
/*     */       }
/*     */     } else {
/*  92 */       this.outputLength = -1;
/*     */     }
/*     */   }
/*     */   
/*     */   SignatureMethodParameterSpec unmarshalParams(Element paramsElem) throws MarshalException
/*     */   {
/*  98 */     this.outputLength = new Integer(
/*  99 */       paramsElem.getFirstChild().getNodeValue()).intValue();
/* 100 */     if (log.isLoggable(Level.FINE)) {
/* 101 */       log.log(Level.FINE, "unmarshalled outputLength: " + this.outputLength);
/*     */     }
/* 103 */     return new HMACParameterSpec(this.outputLength);
/*     */   }
/*     */   
/*     */   void marshalParams(Element parent, String prefix)
/*     */     throws MarshalException
/*     */   {
/* 109 */     Document ownerDoc = DOMUtils.getOwnerDocument(parent);
/* 110 */     Element hmacElem = DOMUtils.createElement(ownerDoc, "HMACOutputLength", 
/* 111 */       "http://www.w3.org/2000/09/xmldsig#", prefix);
/* 112 */     hmacElem.appendChild(ownerDoc.createTextNode(
/* 113 */       String.valueOf(this.outputLength)));
/*     */     
/* 115 */     parent.appendChild(hmacElem);
/*     */   }
/*     */   
/*     */   boolean verify(Key key, DOMSignedInfo si, byte[] sig, XMLValidateContext context)
/*     */     throws InvalidKeyException, SignatureException, XMLSignatureException
/*     */   {
/* 121 */     if ((key == null) || (si == null) || (sig == null)) {
/* 122 */       throw new NullPointerException();
/*     */     }
/* 124 */     if (!(key instanceof SecretKey)) {
/* 125 */       throw new InvalidKeyException("key must be SecretKey");
/*     */     }
/* 127 */     if (this.hmac == null) {
/*     */       try {
/* 129 */         this.hmac = Mac.getInstance(getSignatureAlgorithm());
/*     */       } catch (NoSuchAlgorithmException nsae) {
/* 131 */         throw new XMLSignatureException(nsae);
/*     */       }
/*     */     }
/* 134 */     if (log.isLoggable(Level.FINE)) {
/* 135 */       log.log(Level.FINE, "outputLength = " + this.outputLength);
/*     */     }
/* 137 */     this.hmac.init((SecretKey)key);
/* 138 */     si.canonicalize(context, new MacOutputStream(this.hmac));
/* 139 */     byte[] result = this.hmac.doFinal();
/* 140 */     if (log.isLoggable(Level.FINE)) {
/* 141 */       log.log(Level.FINE, "resultLength = " + result.length);
/*     */     }
/* 143 */     if (this.outputLength != -1) {
/* 144 */       int byteLength = this.outputLength / 8;
/* 145 */       if (result.length > byteLength) {
/* 146 */         byte[] truncated = new byte[byteLength];
/* 147 */         System.arraycopy(result, 0, truncated, 0, byteLength);
/* 148 */         result = truncated;
/*     */       }
/*     */     }
/*     */     
/* 152 */     return MessageDigest.isEqual(sig, result);
/*     */   }
/*     */   
/*     */   byte[] sign(Key key, DOMSignedInfo si, XMLSignContext context) throws InvalidKeyException, XMLSignatureException
/*     */   {
/* 157 */     if ((key == null) || (si == null)) {
/* 158 */       throw new NullPointerException();
/*     */     }
/* 160 */     if (!(key instanceof SecretKey)) {
/* 161 */       throw new InvalidKeyException("key must be SecretKey");
/*     */     }
/* 163 */     if (this.hmac == null) {
/*     */       try {
/* 165 */         this.hmac = Mac.getInstance(getSignatureAlgorithm());
/*     */       } catch (NoSuchAlgorithmException nsae) {
/* 167 */         throw new XMLSignatureException(nsae);
/*     */       }
/*     */     }
/* 170 */     this.hmac.init((SecretKey)key);
/* 171 */     si.canonicalize(context, new MacOutputStream(this.hmac));
/* 172 */     byte[] result = this.hmac.doFinal();
/* 173 */     if (this.outputLength != -1) {
/* 174 */       int byteLength = this.outputLength / 8;
/* 175 */       if (result.length > byteLength) {
/* 176 */         byte[] truncated = new byte[byteLength];
/* 177 */         System.arraycopy(result, 0, truncated, 0, byteLength);
/* 178 */         result = truncated;
/*     */       }
/*     */     }
/* 181 */     return result;
/*     */   }
/*     */   
/*     */   boolean paramsEqual(AlgorithmParameterSpec spec) {
/* 185 */     if (getParameterSpec() == spec) {
/* 186 */       return true;
/*     */     }
/* 188 */     if (!(spec instanceof HMACParameterSpec)) {
/* 189 */       return false;
/*     */     }
/* 191 */     HMACParameterSpec ospec = (HMACParameterSpec)spec;
/*     */     
/* 193 */     return this.outputLength == ospec.getOutputLength();
/*     */   }
/*     */   
/*     */   static final class SHA1 extends DOMHMACSignatureMethod
/*     */   {
/*     */     SHA1(AlgorithmParameterSpec params) throws InvalidAlgorithmParameterException {
/* 199 */       super();
/*     */     }
/*     */     
/* 202 */     SHA1(Element dmElem) throws MarshalException { super(); }
/*     */     
/*     */     public String getAlgorithm() {
/* 205 */       return "http://www.w3.org/2000/09/xmldsig#hmac-sha1";
/*     */     }
/*     */     
/* 208 */     String getSignatureAlgorithm() { return "HmacSHA1"; }
/*     */   }
/*     */   
/*     */   static final class SHA256 extends DOMHMACSignatureMethod
/*     */   {
/*     */     SHA256(AlgorithmParameterSpec params) throws InvalidAlgorithmParameterException
/*     */     {
/* 215 */       super();
/*     */     }
/*     */     
/* 218 */     SHA256(Element dmElem) throws MarshalException { super(); }
/*     */     
/*     */     public String getAlgorithm() {
/* 221 */       return "http://www.w3.org/2001/04/xmldsig-more#hmac-sha256";
/*     */     }
/*     */     
/* 224 */     String getSignatureAlgorithm() { return "HmacSHA256"; }
/*     */   }
/*     */   
/*     */   static final class SHA384 extends DOMHMACSignatureMethod
/*     */   {
/*     */     SHA384(AlgorithmParameterSpec params) throws InvalidAlgorithmParameterException
/*     */     {
/* 231 */       super();
/*     */     }
/*     */     
/* 234 */     SHA384(Element dmElem) throws MarshalException { super(); }
/*     */     
/*     */     public String getAlgorithm() {
/* 237 */       return "http://www.w3.org/2001/04/xmldsig-more#hmac-sha384";
/*     */     }
/*     */     
/* 240 */     String getSignatureAlgorithm() { return "HmacSHA384"; }
/*     */   }
/*     */   
/*     */   static final class SHA512 extends DOMHMACSignatureMethod
/*     */   {
/*     */     SHA512(AlgorithmParameterSpec params) throws InvalidAlgorithmParameterException
/*     */     {
/* 247 */       super();
/*     */     }
/*     */     
/* 250 */     SHA512(Element dmElem) throws MarshalException { super(); }
/*     */     
/*     */     public String getAlgorithm() {
/* 253 */       return "http://www.w3.org/2001/04/xmldsig-more#hmac-sha512";
/*     */     }
/*     */     
/* 256 */     String getSignatureAlgorithm() { return "HmacSHA512"; }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\org\jcp\xml\dsig\internal\dom\DOMHMACSignatureMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */