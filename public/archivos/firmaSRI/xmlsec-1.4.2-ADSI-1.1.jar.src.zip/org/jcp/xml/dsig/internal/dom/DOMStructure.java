/*    */ package org.jcp.xml.dsig.internal.dom;
/*    */ 
/*    */ import javax.xml.crypto.MarshalException;
/*    */ import javax.xml.crypto.XMLStructure;
/*    */ import javax.xml.crypto.dom.DOMCryptoContext;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DOMStructure
/*    */   implements XMLStructure
/*    */ {
/*    */   public final boolean isFeatureSupported(String feature)
/*    */   {
/* 38 */     if (feature == null) {
/* 39 */       throw new NullPointerException();
/*    */     }
/* 41 */     return false;
/*    */   }
/*    */   
/*    */   public abstract void marshal(Node paramNode, String paramString, DOMCryptoContext paramDOMCryptoContext)
/*    */     throws MarshalException;
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\org\jcp\xml\dsig\internal\dom\DOMStructure.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */