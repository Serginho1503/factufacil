/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.security.KeyException;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PublicKey;
/*     */ import java.security.interfaces.DSAParams;
/*     */ import java.security.interfaces.DSAPublicKey;
/*     */ import java.security.interfaces.RSAPublicKey;
/*     */ import java.security.spec.DSAPublicKeySpec;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import java.security.spec.KeySpec;
/*     */ import java.security.spec.RSAPublicKeySpec;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.dom.DOMCryptoContext;
/*     */ import javax.xml.crypto.dsig.keyinfo.KeyValue;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DOMKeyValue
/*     */   extends DOMStructure
/*     */   implements KeyValue
/*     */ {
/*     */   private KeyFactory rsakf;
/*     */   private KeyFactory dsakf;
/*     */   private PublicKey publicKey;
/*     */   private javax.xml.crypto.dom.DOMStructure externalPublicKey;
/*     */   private DOMCryptoBinary p;
/*     */   private DOMCryptoBinary q;
/*     */   private DOMCryptoBinary g;
/*     */   private DOMCryptoBinary y;
/*     */   private DOMCryptoBinary j;
/*     */   private DOMCryptoBinary seed;
/*     */   private DOMCryptoBinary pgen;
/*     */   private DOMCryptoBinary modulus;
/*     */   private DOMCryptoBinary exponent;
/*     */   
/*     */   public DOMKeyValue(PublicKey key)
/*     */     throws KeyException
/*     */   {
/*  63 */     if (key == null) {
/*  64 */       throw new NullPointerException("key cannot be null");
/*     */     }
/*  66 */     this.publicKey = key;
/*  67 */     if ((key instanceof DSAPublicKey)) {
/*  68 */       DSAPublicKey dkey = (DSAPublicKey)key;
/*  69 */       DSAParams params = dkey.getParams();
/*  70 */       this.p = new DOMCryptoBinary(params.getP());
/*  71 */       this.q = new DOMCryptoBinary(params.getQ());
/*  72 */       this.g = new DOMCryptoBinary(params.getG());
/*  73 */       this.y = new DOMCryptoBinary(dkey.getY());
/*  74 */     } else if ((key instanceof RSAPublicKey)) {
/*  75 */       RSAPublicKey rkey = (RSAPublicKey)key;
/*  76 */       this.exponent = new DOMCryptoBinary(rkey.getPublicExponent());
/*  77 */       this.modulus = new DOMCryptoBinary(rkey.getModulus());
/*     */     } else {
/*  79 */       throw new KeyException("unsupported key algorithm: " + 
/*  80 */         key.getAlgorithm());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMKeyValue(Element kvElem)
/*     */     throws MarshalException
/*     */   {
/*  90 */     Element kvtElem = DOMUtils.getFirstChildElement(kvElem);
/*  91 */     if (kvtElem.getLocalName().equals("DSAKeyValue")) {
/*  92 */       this.publicKey = unmarshalDSAKeyValue(kvtElem);
/*  93 */     } else if (kvtElem.getLocalName().equals("RSAKeyValue")) {
/*  94 */       this.publicKey = unmarshalRSAKeyValue(kvtElem);
/*     */     } else {
/*  96 */       this.publicKey = null;
/*  97 */       this.externalPublicKey = new javax.xml.crypto.dom.DOMStructure(kvtElem);
/*     */     }
/*     */   }
/*     */   
/*     */   public PublicKey getPublicKey() throws KeyException {
/* 102 */     if (this.publicKey == null) {
/* 103 */       throw new KeyException("can't convert KeyValue to PublicKey");
/*     */     }
/* 105 */     return this.publicKey;
/*     */   }
/*     */   
/*     */   public void marshal(Node parent, String dsPrefix, DOMCryptoContext context)
/*     */     throws MarshalException
/*     */   {
/* 111 */     Document ownerDoc = DOMUtils.getOwnerDocument(parent);
/*     */     
/*     */ 
/* 114 */     Element kvElem = DOMUtils.createElement(
/* 115 */       ownerDoc, "KeyValue", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/* 116 */     marshalPublicKey(kvElem, ownerDoc, dsPrefix, context);
/*     */     
/* 118 */     parent.appendChild(kvElem);
/*     */   }
/*     */   
/*     */   private void marshalPublicKey(Node parent, Document doc, String dsPrefix, DOMCryptoContext context) throws MarshalException
/*     */   {
/* 123 */     if (this.publicKey != null) {
/* 124 */       if ((this.publicKey instanceof DSAPublicKey))
/*     */       {
/* 126 */         marshalDSAPublicKey(parent, doc, dsPrefix, context);
/* 127 */       } else if ((this.publicKey instanceof RSAPublicKey))
/*     */       {
/* 129 */         marshalRSAPublicKey(parent, doc, dsPrefix, context);
/*     */       } else {
/* 131 */         throw new MarshalException(this.publicKey.getAlgorithm() + 
/* 132 */           " public key algorithm not supported");
/*     */       }
/*     */     } else {
/* 135 */       parent.appendChild(this.externalPublicKey.getNode());
/*     */     }
/*     */   }
/*     */   
/*     */   private void marshalDSAPublicKey(Node parent, Document doc, String dsPrefix, DOMCryptoContext context) throws MarshalException
/*     */   {
/* 141 */     Element dsaElem = DOMUtils.createElement(
/* 142 */       doc, "DSAKeyValue", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */     
/* 144 */     Element pElem = DOMUtils.createElement(
/* 145 */       doc, "P", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/* 146 */     Element qElem = DOMUtils.createElement(
/* 147 */       doc, "Q", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/* 148 */     Element gElem = DOMUtils.createElement(
/* 149 */       doc, "G", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/* 150 */     Element yElem = DOMUtils.createElement(
/* 151 */       doc, "Y", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/* 152 */     this.p.marshal(pElem, dsPrefix, context);
/* 153 */     this.q.marshal(qElem, dsPrefix, context);
/* 154 */     this.g.marshal(gElem, dsPrefix, context);
/* 155 */     this.y.marshal(yElem, dsPrefix, context);
/* 156 */     dsaElem.appendChild(pElem);
/* 157 */     dsaElem.appendChild(qElem);
/* 158 */     dsaElem.appendChild(gElem);
/* 159 */     dsaElem.appendChild(yElem);
/* 160 */     parent.appendChild(dsaElem);
/*     */   }
/*     */   
/*     */   private void marshalRSAPublicKey(Node parent, Document doc, String dsPrefix, DOMCryptoContext context) throws MarshalException
/*     */   {
/* 165 */     Element rsaElem = DOMUtils.createElement(
/* 166 */       doc, "RSAKeyValue", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/* 167 */     Element modulusElem = DOMUtils.createElement(
/* 168 */       doc, "Modulus", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/* 169 */     Element exponentElem = DOMUtils.createElement(
/* 170 */       doc, "Exponent", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/* 171 */     this.modulus.marshal(modulusElem, dsPrefix, context);
/* 172 */     this.exponent.marshal(exponentElem, dsPrefix, context);
/* 173 */     rsaElem.appendChild(modulusElem);
/* 174 */     rsaElem.appendChild(exponentElem);
/* 175 */     parent.appendChild(rsaElem);
/*     */   }
/*     */   
/*     */   private DSAPublicKey unmarshalDSAKeyValue(Element kvtElem) throws MarshalException
/*     */   {
/* 180 */     if (this.dsakf == null) {
/*     */       try {
/* 182 */         this.dsakf = KeyFactory.getInstance("DSA");
/*     */       } catch (NoSuchAlgorithmException e) {
/* 184 */         throw new RuntimeException("unable to create DSA KeyFactory: " + 
/* 185 */           e.getMessage());
/*     */       }
/*     */     }
/* 188 */     Element curElem = DOMUtils.getFirstChildElement(kvtElem);
/*     */     
/* 190 */     if (curElem.getLocalName().equals("P")) {
/* 191 */       this.p = new DOMCryptoBinary(curElem.getFirstChild());
/* 192 */       curElem = DOMUtils.getNextSiblingElement(curElem);
/* 193 */       this.q = new DOMCryptoBinary(curElem.getFirstChild());
/* 194 */       curElem = DOMUtils.getNextSiblingElement(curElem);
/*     */     }
/* 196 */     if (curElem.getLocalName().equals("G")) {
/* 197 */       this.g = new DOMCryptoBinary(curElem.getFirstChild());
/* 198 */       curElem = DOMUtils.getNextSiblingElement(curElem);
/*     */     }
/* 200 */     this.y = new DOMCryptoBinary(curElem.getFirstChild());
/* 201 */     curElem = DOMUtils.getNextSiblingElement(curElem);
/* 202 */     if ((curElem != null) && (curElem.getLocalName().equals("J"))) {
/* 203 */       this.j = new DOMCryptoBinary(curElem.getFirstChild());
/* 204 */       curElem = DOMUtils.getNextSiblingElement(curElem);
/*     */     }
/* 206 */     if (curElem != null) {
/* 207 */       this.seed = new DOMCryptoBinary(curElem.getFirstChild());
/* 208 */       curElem = DOMUtils.getNextSiblingElement(curElem);
/* 209 */       this.pgen = new DOMCryptoBinary(curElem.getFirstChild());
/*     */     }
/*     */     
/* 212 */     DSAPublicKeySpec spec = new DSAPublicKeySpec(
/* 213 */       this.y.getBigNum(), this.p.getBigNum(), this.q.getBigNum(), this.g.getBigNum());
/* 214 */     return (DSAPublicKey)generatePublicKey(this.dsakf, spec);
/*     */   }
/*     */   
/*     */   private RSAPublicKey unmarshalRSAKeyValue(Element kvtElem) throws MarshalException
/*     */   {
/* 219 */     if (this.rsakf == null) {
/*     */       try {
/* 221 */         this.rsakf = KeyFactory.getInstance("RSA");
/*     */       } catch (NoSuchAlgorithmException e) {
/* 223 */         throw new RuntimeException("unable to create RSA KeyFactory: " + 
/* 224 */           e.getMessage());
/*     */       }
/*     */     }
/* 227 */     Element modulusElem = DOMUtils.getFirstChildElement(kvtElem);
/* 228 */     this.modulus = new DOMCryptoBinary(modulusElem.getFirstChild());
/* 229 */     Element exponentElem = DOMUtils.getNextSiblingElement(modulusElem);
/* 230 */     this.exponent = new DOMCryptoBinary(exponentElem.getFirstChild());
/* 231 */     RSAPublicKeySpec spec = new RSAPublicKeySpec(
/* 232 */       this.modulus.getBigNum(), this.exponent.getBigNum());
/* 233 */     return (RSAPublicKey)generatePublicKey(this.rsakf, spec);
/*     */   }
/*     */   
/*     */   private PublicKey generatePublicKey(KeyFactory kf, KeySpec keyspec) {
/*     */     try {
/* 238 */       return kf.generatePublic(keyspec);
/*     */     }
/*     */     catch (InvalidKeySpecException e) {}
/* 241 */     return null;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 246 */     if (this == obj) {
/* 247 */       return true;
/*     */     }
/* 249 */     if (!(obj instanceof KeyValue)) {
/* 250 */       return false;
/*     */     }
/*     */     try {
/* 253 */       KeyValue kv = (KeyValue)obj;
/* 254 */       if (this.publicKey == null) {
/* 255 */         if (kv.getPublicKey() != null) {
/* 256 */           return false;
/*     */         }
/* 258 */       } else if (!this.publicKey.equals(kv.getPublicKey())) {
/* 259 */         return false;
/*     */       }
/*     */     }
/*     */     catch (KeyException ke) {
/* 263 */       return false;
/*     */     }
/*     */     
/* 266 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 270 */     if (!$assertionsDisabled) throw new AssertionError("hashCode not designed");
/* 271 */     return 45;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\org\jcp\xml\dsig\internal\dom\DOMKeyValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */