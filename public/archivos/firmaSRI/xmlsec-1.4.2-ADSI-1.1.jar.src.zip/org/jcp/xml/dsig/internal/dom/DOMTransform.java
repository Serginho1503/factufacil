/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.io.OutputStream;
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.Provider;
/*     */ import java.security.spec.AlgorithmParameterSpec;
/*     */ import javax.xml.crypto.Data;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.XMLCryptoContext;
/*     */ import javax.xml.crypto.dom.DOMCryptoContext;
/*     */ import javax.xml.crypto.dsig.Transform;
/*     */ import javax.xml.crypto.dsig.TransformException;
/*     */ import javax.xml.crypto.dsig.TransformService;
/*     */ import javax.xml.crypto.dsig.dom.DOMSignContext;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMTransform
/*     */   extends DOMStructure
/*     */   implements Transform
/*     */ {
/*     */   protected TransformService spi;
/*     */   
/*     */   public DOMTransform(TransformService spi)
/*     */   {
/*  57 */     this.spi = spi;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMTransform(Element transElem, XMLCryptoContext context, Provider provider)
/*     */     throws MarshalException
/*     */   {
/*  69 */     String algorithm = DOMUtils.getAttributeValue(transElem, "Algorithm");
/*     */     try {
/*  71 */       this.spi = TransformService.getInstance(algorithm, "DOM");
/*     */     } catch (NoSuchAlgorithmException e1) {
/*     */       try {
/*  74 */         this.spi = TransformService.getInstance(algorithm, "DOM", provider);
/*     */       } catch (NoSuchAlgorithmException e2) {
/*  76 */         throw new MarshalException(e2);
/*     */       }
/*     */     }
/*     */     try {
/*  80 */       this.spi.init(new javax.xml.crypto.dom.DOMStructure(transElem), context);
/*     */     } catch (InvalidAlgorithmParameterException iape) {
/*  82 */       throw new MarshalException(iape);
/*     */     }
/*     */   }
/*     */   
/*     */   public final AlgorithmParameterSpec getParameterSpec() {
/*  87 */     return this.spi.getParameterSpec();
/*     */   }
/*     */   
/*     */   public final String getAlgorithm() {
/*  91 */     return this.spi.getAlgorithm();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void marshal(Node parent, String dsPrefix, DOMCryptoContext context)
/*     */     throws MarshalException
/*     */   {
/* 100 */     Document ownerDoc = DOMUtils.getOwnerDocument(parent);
/*     */     
/* 102 */     Element transformElem = null;
/* 103 */     if (parent.getLocalName().equals("Transforms")) {
/* 104 */       transformElem = DOMUtils.createElement(
/* 105 */         ownerDoc, "Transform", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */     } else {
/* 107 */       transformElem = DOMUtils.createElement(
/* 108 */         ownerDoc, "CanonicalizationMethod", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */     }
/* 110 */     DOMUtils.setAttribute(transformElem, "Algorithm", getAlgorithm());
/*     */     
/* 112 */     this.spi.marshalParams(
/* 113 */       new javax.xml.crypto.dom.DOMStructure(transformElem), context);
/*     */     
/* 115 */     parent.appendChild(transformElem);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Data transform(Data data, XMLCryptoContext xc)
/*     */     throws TransformException
/*     */   {
/* 131 */     return this.spi.transform(data, xc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Data transform(Data data, XMLCryptoContext xc, OutputStream os)
/*     */     throws TransformException
/*     */   {
/* 149 */     return this.spi.transform(data, xc, os);
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 153 */     if (this == o) {
/* 154 */       return true;
/*     */     }
/*     */     
/* 157 */     if (!(o instanceof Transform)) {
/* 158 */       return false;
/*     */     }
/* 160 */     Transform otransform = (Transform)o;
/*     */     
/*     */ 
/* 163 */     return (getAlgorithm().equals(otransform.getAlgorithm())) && (DOMUtils.paramsEqual(
/* 164 */       getParameterSpec(), otransform.getParameterSpec()));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 168 */     if (!$assertionsDisabled) throw new AssertionError("hashCode not designed");
/* 169 */     return 58;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Data transform(Data data, XMLCryptoContext xc, DOMSignContext context)
/*     */     throws MarshalException, TransformException
/*     */   {
/* 190 */     marshal(context.getParent(), 
/* 191 */       DOMUtils.getSignaturePrefix(context), context);
/* 192 */     return transform(data, xc);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\org\jcp\xml\dsig\internal\dom\DOMTransform.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */