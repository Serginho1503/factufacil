/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import adsi.org.apache.xml.security.Init;
/*     */ import adsi.org.apache.xml.security.exceptions.Base64DecodingException;
/*     */ import adsi.org.apache.xml.security.utils.Base64;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.Key;
/*     */ import java.security.Provider;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.xml.crypto.KeySelector;
/*     */ import javax.xml.crypto.KeySelector.Purpose;
/*     */ import javax.xml.crypto.KeySelectorException;
/*     */ import javax.xml.crypto.KeySelectorResult;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.XMLCryptoContext;
/*     */ import javax.xml.crypto.XMLStructure;
/*     */ import javax.xml.crypto.dom.DOMCryptoContext;
/*     */ import javax.xml.crypto.dsig.Manifest;
/*     */ import javax.xml.crypto.dsig.Reference;
/*     */ import javax.xml.crypto.dsig.SignatureMethod;
/*     */ import javax.xml.crypto.dsig.SignedInfo;
/*     */ import javax.xml.crypto.dsig.Transform;
/*     */ import javax.xml.crypto.dsig.XMLObject;
/*     */ import javax.xml.crypto.dsig.XMLSignContext;
/*     */ import javax.xml.crypto.dsig.XMLSignature;
/*     */ import javax.xml.crypto.dsig.XMLSignature.SignatureValue;
/*     */ import javax.xml.crypto.dsig.XMLSignatureException;
/*     */ import javax.xml.crypto.dsig.XMLValidateContext;
/*     */ import javax.xml.crypto.dsig.dom.DOMSignContext;
/*     */ import javax.xml.crypto.dsig.dom.DOMValidateContext;
/*     */ import javax.xml.crypto.dsig.keyinfo.KeyInfo;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DOMXMLSignature
/*     */   extends DOMStructure
/*     */   implements XMLSignature
/*     */ {
/*     */   private static Logger log;
/*     */   private String id;
/*     */   private XMLSignature.SignatureValue sv;
/*     */   private KeyInfo ki;
/*     */   private List objects;
/*     */   private SignedInfo si;
/*  71 */   private Document ownerDoc = null;
/*  72 */   private Element localSigElem = null;
/*  73 */   private Element sigElem = null;
/*     */   private boolean validationStatus;
/*  75 */   private boolean validated = false;
/*     */   private KeySelectorResult ksr;
/*     */   private HashMap signatureIdMap;
/*     */   
/*     */   static
/*     */   {
/*  65 */     log = Logger.getLogger("org.jcp.xml.dsig.internal.dom");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  80 */     Init.init();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMXMLSignature(SignedInfo si, KeyInfo ki, List objs, String id, String signatureValueId)
/*     */   {
/*  99 */     if (si == null) {
/* 100 */       throw new NullPointerException("signedInfo cannot be null");
/*     */     }
/* 102 */     this.si = si;
/* 103 */     this.id = id;
/* 104 */     this.sv = new DOMSignatureValue(signatureValueId);
/* 105 */     if (objs == null) {
/* 106 */       this.objects = Collections.EMPTY_LIST;
/*     */     } else {
/* 108 */       List objsCopy = new ArrayList(objs);
/* 109 */       int i = 0; for (int size = objsCopy.size(); i < size; i++) {
/* 110 */         if (!(objsCopy.get(i) instanceof XMLObject)) {
/* 111 */           throw new ClassCastException(
/* 112 */             "objs[" + i + "] is not an XMLObject");
/*     */         }
/*     */       }
/* 115 */       this.objects = Collections.unmodifiableList(objsCopy);
/*     */     }
/* 117 */     this.ki = ki;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMXMLSignature(Element sigElem, XMLCryptoContext context, Provider provider)
/*     */     throws MarshalException
/*     */   {
/* 128 */     this.localSigElem = sigElem;
/* 129 */     this.ownerDoc = this.localSigElem.getOwnerDocument();
/*     */     
/*     */ 
/* 132 */     this.id = DOMUtils.getAttributeValue(this.localSigElem, "Id");
/*     */     
/*     */ 
/* 135 */     Element siElem = DOMUtils.getFirstChildElement(this.localSigElem);
/* 136 */     this.si = new DOMSignedInfo(siElem, context, provider);
/*     */     
/*     */ 
/* 139 */     Element sigValElem = DOMUtils.getNextSiblingElement(siElem);
/* 140 */     this.sv = new DOMSignatureValue(sigValElem);
/*     */     
/*     */ 
/* 143 */     Element nextSibling = DOMUtils.getNextSiblingElement(sigValElem);
/* 144 */     if ((nextSibling != null) && (nextSibling.getLocalName().equals("KeyInfo"))) {
/* 145 */       this.ki = new DOMKeyInfo(nextSibling, context, provider);
/* 146 */       nextSibling = DOMUtils.getNextSiblingElement(nextSibling);
/*     */     }
/*     */     
/*     */ 
/* 150 */     if (nextSibling == null) {
/* 151 */       this.objects = Collections.EMPTY_LIST;
/*     */     } else {
/* 153 */       List tempObjects = new ArrayList();
/* 154 */       while (nextSibling != null) {
/* 155 */         tempObjects.add(
/* 156 */           new DOMXMLObject(nextSibling, context, provider));
/* 157 */         nextSibling = DOMUtils.getNextSiblingElement(nextSibling);
/*     */       }
/* 159 */       this.objects = Collections.unmodifiableList(tempObjects);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getId() {
/* 164 */     return this.id;
/*     */   }
/*     */   
/*     */   public KeyInfo getKeyInfo() {
/* 168 */     return this.ki;
/*     */   }
/*     */   
/*     */   public SignedInfo getSignedInfo() {
/* 172 */     return this.si;
/*     */   }
/*     */   
/*     */   public List getObjects() {
/* 176 */     return this.objects;
/*     */   }
/*     */   
/*     */   public XMLSignature.SignatureValue getSignatureValue() {
/* 180 */     return this.sv;
/*     */   }
/*     */   
/*     */   public KeySelectorResult getKeySelectorResult() {
/* 184 */     return this.ksr;
/*     */   }
/*     */   
/*     */   public void marshal(Node parent, String dsPrefix, DOMCryptoContext context) throws MarshalException
/*     */   {
/* 189 */     marshal(parent, null, dsPrefix, context);
/*     */   }
/*     */   
/*     */   public void marshal(Node parent, Node nextSibling, String dsPrefix, DOMCryptoContext context) throws MarshalException
/*     */   {
/* 194 */     this.ownerDoc = DOMUtils.getOwnerDocument(parent);
/*     */     
/* 196 */     this.sigElem = DOMUtils.createElement(
/* 197 */       this.ownerDoc, "Signature", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */     
/*     */ 
/* 200 */     if ((dsPrefix == null) || (dsPrefix.length() == 0)) {
/* 201 */       this.sigElem.setAttributeNS(
/* 202 */         "http://www.w3.org/2000/xmlns/", "xmlns", "http://www.w3.org/2000/09/xmldsig#");
/*     */     } else {
/* 204 */       this.sigElem.setAttributeNS(
/* 205 */         "http://www.w3.org/2000/xmlns/", "xmlns:" + dsPrefix, 
/* 206 */         "http://www.w3.org/2000/09/xmldsig#");
/*     */     }
/*     */     
/*     */ 
/* 210 */     ((DOMSignedInfo)this.si).marshal(this.sigElem, dsPrefix, context);
/*     */     
/*     */ 
/* 213 */     ((DOMSignatureValue)this.sv).marshal(this.sigElem, dsPrefix, context);
/*     */     
/*     */ 
/* 216 */     if (this.ki != null) {
/* 217 */       ((DOMKeyInfo)this.ki).marshal(this.sigElem, null, dsPrefix, context);
/*     */     }
/*     */     
/*     */ 
/* 221 */     int i = 0; for (int size = this.objects.size(); i < size; i++) {
/* 222 */       ((DOMXMLObject)this.objects.get(i)).marshal(this.sigElem, dsPrefix, context);
/*     */     }
/*     */     
/*     */ 
/* 226 */     DOMUtils.setAttributeID(this.sigElem, "Id", this.id);
/*     */     
/* 228 */     parent.insertBefore(this.sigElem, nextSibling);
/*     */   }
/*     */   
/*     */   public boolean validate(XMLValidateContext vc)
/*     */     throws XMLSignatureException
/*     */   {
/* 234 */     if (vc == null) {
/* 235 */       throw new NullPointerException("validateContext is null");
/*     */     }
/*     */     
/* 238 */     if (!(vc instanceof DOMValidateContext)) {
/* 239 */       throw new ClassCastException(
/* 240 */         "validateContext must be of type DOMValidateContext");
/*     */     }
/*     */     
/* 243 */     if (this.validated) {
/* 244 */       return this.validationStatus;
/*     */     }
/*     */     
/*     */ 
/* 248 */     boolean sigValidity = this.sv.validate(vc);
/* 249 */     if (!sigValidity) {
/* 250 */       this.validationStatus = false;
/* 251 */       this.validated = true;
/* 252 */       return this.validationStatus;
/*     */     }
/*     */     
/*     */ 
/* 256 */     List refs = this.si.getReferences();
/* 257 */     boolean validateRefs = true;
/* 258 */     int i = 0; for (int size = refs.size(); (validateRefs) && (i < size); i++) {
/* 259 */       Reference ref = (Reference)refs.get(i);
/* 260 */       boolean refValid = ref.validate(vc);
/* 261 */       if (log.isLoggable(Level.FINE)) {
/* 262 */         log.log(Level.FINE, "Reference[" + ref.getURI() + "] is valid: " + 
/* 263 */           refValid);
/*     */       }
/* 265 */       validateRefs &= refValid;
/*     */     }
/* 267 */     if (!validateRefs) {
/* 268 */       if (log.isLoggable(Level.FINE)) {
/* 269 */         log.log(Level.FINE, "Couldn't validate the References");
/*     */       }
/* 271 */       this.validationStatus = false;
/* 272 */       this.validated = true;
/* 273 */       return this.validationStatus;
/*     */     }
/*     */     
/*     */ 
/* 277 */     boolean validateMans = true;
/* 278 */     if (Boolean.TRUE.equals(vc.getProperty(
/* 279 */       "org.jcp.xml.dsig.validateManifests")))
/*     */     {
/* 281 */       int i = 0; for (int size = this.objects.size(); (validateMans) && (i < size); i++) {
/* 282 */         XMLObject xo = (XMLObject)this.objects.get(i);
/* 283 */         List content = xo.getContent();
/* 284 */         int csize = content.size();
/* 285 */         for (int j = 0; (validateMans) && (j < csize); j++) {
/* 286 */           XMLStructure xs = (XMLStructure)content.get(j);
/* 287 */           if ((xs instanceof Manifest)) {
/* 288 */             if (log.isLoggable(Level.FINE)) {
/* 289 */               log.log(Level.FINE, "validating manifest");
/*     */             }
/* 291 */             Manifest man = (Manifest)xs;
/* 292 */             List manRefs = man.getReferences();
/* 293 */             int rsize = manRefs.size();
/* 294 */             for (int k = 0; (validateMans) && (k < rsize); k++) {
/* 295 */               Reference ref = (Reference)manRefs.get(k);
/* 296 */               boolean refValid = ref.validate(vc);
/* 297 */               if (log.isLoggable(Level.FINE)) {
/* 298 */                 log.log(Level.FINE, "Manifest ref[" + 
/* 299 */                   ref.getURI() + "] is valid: " + refValid);
/*     */               }
/* 301 */               validateMans &= refValid;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 308 */     this.validationStatus = validateMans;
/* 309 */     this.validated = true;
/* 310 */     return this.validationStatus;
/*     */   }
/*     */   
/*     */   public void sign(XMLSignContext signContext) throws MarshalException, XMLSignatureException
/*     */   {
/* 315 */     if (signContext == null) {
/* 316 */       throw new NullPointerException("signContext cannot be null");
/*     */     }
/* 318 */     DOMSignContext context = (DOMSignContext)signContext;
/* 319 */     if (context != null) {
/* 320 */       marshal(context.getParent(), context.getNextSibling(), 
/* 321 */         DOMUtils.getSignaturePrefix(context), context);
/*     */     }
/*     */     
/*     */ 
/* 325 */     List allReferences = new ArrayList(this.si.getReferences());
/*     */     
/*     */ 
/*     */ 
/* 329 */     this.signatureIdMap = new HashMap();
/* 330 */     this.signatureIdMap.put(this.id, this);
/* 331 */     this.signatureIdMap.put(this.si.getId(), this.si);
/* 332 */     List refs = this.si.getReferences();
/* 333 */     int i = 0; for (int size = refs.size(); i < size; i++) {
/* 334 */       Reference ref = (Reference)refs.get(i);
/* 335 */       this.signatureIdMap.put(ref.getId(), ref);
/*     */     }
/* 337 */     int i = 0; for (int size = this.objects.size(); i < size; i++) {
/* 338 */       XMLObject obj = (XMLObject)this.objects.get(i);
/* 339 */       this.signatureIdMap.put(obj.getId(), obj);
/* 340 */       List content = obj.getContent();
/* 341 */       int j = 0; for (int csize = content.size(); j < csize; j++) {
/* 342 */         XMLStructure xs = (XMLStructure)content.get(j);
/* 343 */         if ((xs instanceof Manifest)) {
/* 344 */           Manifest man = (Manifest)xs;
/* 345 */           this.signatureIdMap.put(man.getId(), man);
/* 346 */           List manRefs = man.getReferences();
/* 347 */           int k = 0; for (int msize = manRefs.size(); k < msize; k++) {
/* 348 */             Reference ref = (Reference)manRefs.get(k);
/* 349 */             allReferences.add(ref);
/* 350 */             this.signatureIdMap.put(ref.getId(), ref);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 357 */     int i = 0; for (int size = allReferences.size(); i < size; i++) {
/* 358 */       DOMReference ref = (DOMReference)allReferences.get(i);
/* 359 */       digestReference(ref, signContext);
/*     */     }
/*     */     
/*     */ 
/* 363 */     int i = 0; for (int size = allReferences.size(); i < size; i++) {
/* 364 */       DOMReference ref = (DOMReference)allReferences.get(i);
/* 365 */       if (!ref.isDigested())
/*     */       {
/*     */ 
/* 368 */         ref.digest(signContext);
/*     */       }
/*     */     }
/* 371 */     Key signingKey = null;
/* 372 */     KeySelectorResult ksr = null;
/*     */     try {
/* 374 */       ksr = signContext.getKeySelector().select(
/* 375 */         this.ki, KeySelector.Purpose.SIGN, 
/* 376 */         this.si.getSignatureMethod(), signContext);
/* 377 */       signingKey = ksr.getKey();
/* 378 */       if (signingKey == null) {
/* 379 */         throw new XMLSignatureException("the keySelector did not find a signing key");
/*     */       }
/*     */     }
/*     */     catch (KeySelectorException kse) {
/* 383 */       throw new XMLSignatureException("cannot find signing key", kse);
/*     */     }
/*     */     
/*     */ 
/* 387 */     byte[] val = (byte[])null;
/*     */     try {
/* 389 */       val = ((DOMSignatureMethod)this.si.getSignatureMethod()).sign(
/* 390 */         signingKey, (DOMSignedInfo)this.si, signContext);
/*     */     } catch (InvalidKeyException ike) {
/* 392 */       throw new XMLSignatureException(ike);
/*     */     }
/*     */     
/* 395 */     if (log.isLoggable(Level.FINE)) {
/* 396 */       log.log(Level.FINE, "SignatureValue = " + val);
/*     */     }
/* 398 */     ((DOMSignatureValue)this.sv).setValue(val);
/*     */     
/* 400 */     this.localSigElem = this.sigElem;
/* 401 */     this.ksr = ksr;
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 405 */     if (this == o) {
/* 406 */       return true;
/*     */     }
/*     */     
/* 409 */     if (!(o instanceof XMLSignature)) {
/* 410 */       return false;
/*     */     }
/* 412 */     XMLSignature osig = (XMLSignature)o;
/*     */     
/* 414 */     boolean idEqual = 
/* 415 */       this.id == null ? false : osig.getId() == null ? true : this.id.equals(osig.getId());
/* 416 */     boolean keyInfoEqual = 
/* 417 */       this.ki == null ? false : osig.getKeyInfo() == null ? true : 
/* 418 */       this.ki.equals(osig.getKeyInfo());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 423 */     return (idEqual) && (keyInfoEqual) && (this.sv.equals(osig.getSignatureValue())) && (this.si.equals(osig.getSignedInfo())) && (this.objects.equals(osig.getObjects()));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 427 */     if (!$assertionsDisabled) throw new AssertionError("hashCode not designed");
/* 428 */     return 54;
/*     */   }
/*     */   
/*     */   private void digestReference(DOMReference ref, XMLSignContext signContext) throws XMLSignatureException
/*     */   {
/* 433 */     if (ref.isDigested()) {
/* 434 */       return;
/*     */     }
/*     */     
/* 437 */     String uri = ref.getURI();
/* 438 */     if (Utils.sameDocumentURI(uri)) {
/* 439 */       String id = Utils.parseIdFromSameDocumentURI(uri);
/* 440 */       if ((id != null) && (this.signatureIdMap.containsKey(id))) {
/* 441 */         Object obj = this.signatureIdMap.get(id);
/* 442 */         if ((obj instanceof DOMReference)) {
/* 443 */           digestReference((DOMReference)obj, signContext);
/* 444 */         } else if ((obj instanceof Manifest)) {
/* 445 */           Manifest man = (Manifest)obj;
/* 446 */           List manRefs = man.getReferences();
/* 447 */           int i = 0; for (int size = manRefs.size(); i < size; i++) {
/* 448 */             digestReference(
/* 449 */               (DOMReference)manRefs.get(i), signContext);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 456 */       if (uri.length() == 0) {
/* 457 */         List transforms = ref.getTransforms();
/* 458 */         int i = 0; for (int size = transforms.size(); i < size; i++) {
/* 459 */           Transform transform = (Transform)transforms.get(i);
/* 460 */           String transformAlg = transform.getAlgorithm();
/* 461 */           if ((transformAlg.equals("http://www.w3.org/TR/1999/REC-xpath-19991116")) || 
/* 462 */             (transformAlg.equals("http://www.w3.org/2002/06/xmldsig-filter2"))) {
/* 463 */             return;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 468 */     ref.digest(signContext);
/*     */   }
/*     */   
/*     */   public class DOMSignatureValue
/*     */     extends DOMStructure implements XMLSignature.SignatureValue
/*     */   {
/*     */     private String id;
/*     */     private byte[] value;
/*     */     private String valueBase64;
/*     */     private Element sigValueElem;
/* 478 */     private boolean validated = false;
/*     */     private boolean validationStatus;
/*     */     
/*     */     DOMSignatureValue(String id) {
/* 482 */       this.id = id;
/*     */     }
/*     */     
/*     */     DOMSignatureValue(Element sigValueElem) throws MarshalException
/*     */     {
/*     */       try {
/* 488 */         this.value = Base64.decode(sigValueElem);
/*     */       } catch (Base64DecodingException bde) {
/* 490 */         throw new MarshalException(bde);
/*     */       }
/*     */       
/* 493 */       this.id = DOMUtils.getAttributeValue(sigValueElem, "Id");
/* 494 */       this.sigValueElem = sigValueElem;
/*     */     }
/*     */     
/*     */     public String getId() {
/* 498 */       return this.id;
/*     */     }
/*     */     
/*     */     public byte[] getValue() {
/* 502 */       return this.value == null ? null : (byte[])this.value.clone();
/*     */     }
/*     */     
/*     */     public boolean validate(XMLValidateContext validateContext)
/*     */       throws XMLSignatureException
/*     */     {
/* 508 */       if (validateContext == null) {
/* 509 */         throw new NullPointerException("context cannot be null");
/*     */       }
/*     */       
/* 512 */       if (this.validated) {
/* 513 */         return this.validationStatus;
/*     */       }
/*     */       
/*     */ 
/* 517 */       SignatureMethod sm = DOMXMLSignature.this.si.getSignatureMethod();
/* 518 */       Key validationKey = null;
/*     */       try
/*     */       {
/* 521 */         KeySelectorResult ksResult = validateContext.getKeySelector().select(
/* 522 */           DOMXMLSignature.this.ki, KeySelector.Purpose.VERIFY, sm, validateContext);
/* 523 */         validationKey = ksResult.getKey();
/* 524 */         if (validationKey == null) {
/* 525 */           throw new XMLSignatureException("the keyselector did not find a validation key");
/*     */         }
/*     */       }
/*     */       catch (KeySelectorException kse) {
/* 529 */         throw new XMLSignatureException("cannot find validation key", 
/* 530 */           kse);
/*     */       }
/*     */       KeySelectorResult ksResult;
/*     */       try
/*     */       {
/* 535 */         this.validationStatus = ((DOMSignatureMethod)sm).verify(
/* 536 */           validationKey, (DOMSignedInfo)DOMXMLSignature.this.si, this.value, validateContext);
/*     */       } catch (Exception e) {
/* 538 */         throw new XMLSignatureException(e);
/*     */       }
/*     */       
/* 541 */       this.validated = true;
/* 542 */       DOMXMLSignature.this.ksr = ksResult;
/* 543 */       return this.validationStatus;
/*     */     }
/*     */     
/*     */     public boolean equals(Object o) {
/* 547 */       if (this == o) {
/* 548 */         return true;
/*     */       }
/*     */       
/* 551 */       if (!(o instanceof XMLSignature.SignatureValue)) {
/* 552 */         return false;
/*     */       }
/* 554 */       XMLSignature.SignatureValue osv = (XMLSignature.SignatureValue)o;
/*     */       
/* 556 */       boolean idEqual = 
/* 557 */         this.id == null ? false : osv.getId() == null ? true : this.id.equals(osv.getId());
/*     */       
/*     */ 
/* 560 */       return idEqual;
/*     */     }
/*     */     
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 566 */       return 55;
/*     */     }
/*     */     
/*     */ 
/*     */     public void marshal(Node parent, String dsPrefix, DOMCryptoContext context)
/*     */       throws MarshalException
/*     */     {
/* 573 */       this.sigValueElem = DOMUtils.createElement(
/* 574 */         DOMXMLSignature.this.ownerDoc, "SignatureValue", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/* 575 */       if (this.valueBase64 != null) {
/* 576 */         this.sigValueElem.appendChild(DOMXMLSignature.this.ownerDoc.createTextNode(this.valueBase64));
/*     */       }
/*     */       
/*     */ 
/* 580 */       DOMUtils.setAttributeID(this.sigValueElem, "Id", this.id);
/* 581 */       parent.appendChild(this.sigValueElem);
/*     */     }
/*     */     
/*     */     void setValue(byte[] value) {
/* 585 */       this.value = value;
/* 586 */       this.valueBase64 = Base64.encode(value);
/* 587 */       this.sigValueElem.appendChild(DOMXMLSignature.this.ownerDoc.createTextNode(this.valueBase64));
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\org\jcp\xml\dsig\internal\dom\DOMXMLSignature.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */