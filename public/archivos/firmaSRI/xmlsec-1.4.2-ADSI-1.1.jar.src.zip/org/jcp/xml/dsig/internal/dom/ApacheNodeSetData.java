/*    */ package org.jcp.xml.dsig.internal.dom;
/*    */ 
/*    */ import adsi.org.apache.xml.security.signature.NodeFilter;
/*    */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*    */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import javax.xml.crypto.NodeSetData;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApacheNodeSetData
/*    */   implements ApacheData, NodeSetData
/*    */ {
/*    */   private XMLSignatureInput xi;
/*    */   
/*    */   public ApacheNodeSetData(XMLSignatureInput xi)
/*    */   {
/* 43 */     this.xi = xi;
/*    */   }
/*    */   
/*    */   public Iterator iterator()
/*    */   {
/* 48 */     if (this.xi.getNodeFilters() != null) {
/* 49 */       return 
/* 50 */         Collections.unmodifiableSet(getNodeSet(this.xi.getNodeFilters())).iterator();
/*    */     }
/*    */     try {
/* 53 */       return Collections.unmodifiableSet(this.xi.getNodeSet()).iterator();
/*    */     }
/*    */     catch (Exception e) {
/* 56 */       throw new RuntimeException(
/* 57 */         "unrecoverable error retrieving nodeset", e);
/*    */     }
/*    */   }
/*    */   
/*    */   public XMLSignatureInput getXMLSignatureInput() {
/* 62 */     return this.xi;
/*    */   }
/*    */   
/*    */   private Set getNodeSet(List nodeFilters) {
/* 66 */     if (this.xi.isNeedsToBeExpanded()) {
/* 67 */       XMLUtils.circumventBug2650(
/* 68 */         XMLUtils.getOwnerDocument(this.xi.getSubNode()));
/*    */     }
/*    */     
/* 71 */     Set inputSet = new LinkedHashSet();
/* 72 */     XMLUtils.getSet(
/* 73 */       this.xi.getSubNode(), inputSet, null, !this.xi.isExcludeComments());
/* 74 */     Set nodeSet = new LinkedHashSet();
/* 75 */     Iterator i = inputSet.iterator();
/* 76 */     while (i.hasNext()) {
/* 77 */       Node currentNode = (Node)i.next();
/* 78 */       Iterator it = nodeFilters.iterator();
/* 79 */       boolean skipNode = false;
/* 80 */       while ((it.hasNext()) && (!skipNode)) {
/* 81 */         NodeFilter nf = (NodeFilter)it.next();
/* 82 */         if (nf.isNodeInclude(currentNode) != 1) {
/* 83 */           skipNode = true;
/*    */         }
/*    */       }
/* 86 */       if (!skipNode) {
/* 87 */         nodeSet.add(currentNode);
/*    */       }
/*    */     }
/* 90 */     return nodeSet;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\org\jcp\xml\dsig\internal\dom\ApacheNodeSetData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */