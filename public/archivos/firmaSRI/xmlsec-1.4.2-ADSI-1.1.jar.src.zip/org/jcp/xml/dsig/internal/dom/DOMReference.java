/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.Base64DecodingException;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import adsi.org.apache.xml.security.utils.Base64;
/*     */ import adsi.org.apache.xml.security.utils.UnsyncBufferedOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.Provider;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.xml.crypto.Data;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.NodeSetData;
/*     */ import javax.xml.crypto.OctetStreamData;
/*     */ import javax.xml.crypto.URIDereferencer;
/*     */ import javax.xml.crypto.URIReferenceException;
/*     */ import javax.xml.crypto.XMLCryptoContext;
/*     */ import javax.xml.crypto.dom.DOMCryptoContext;
/*     */ import javax.xml.crypto.dom.DOMURIReference;
/*     */ import javax.xml.crypto.dsig.DigestMethod;
/*     */ import javax.xml.crypto.dsig.Reference;
/*     */ import javax.xml.crypto.dsig.Transform;
/*     */ import javax.xml.crypto.dsig.TransformException;
/*     */ import javax.xml.crypto.dsig.TransformService;
/*     */ import javax.xml.crypto.dsig.XMLSignContext;
/*     */ import javax.xml.crypto.dsig.XMLSignatureException;
/*     */ import javax.xml.crypto.dsig.XMLValidateContext;
/*     */ import org.jcp.xml.dsig.internal.DigesterOutputStream;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DOMReference
/*     */   extends DOMStructure
/*     */   implements Reference, DOMURIReference
/*     */ {
/*     */   private static boolean useC14N11;
/*     */   
/*     */   static
/*     */   {
/*  72 */     useC14N11 = false;
/*     */     try
/*     */     {
/*  75 */       useC14N11 = Boolean.getBoolean("adsi.org.apache.xml.security.useC14N11");
/*     */     }
/*     */     catch (Exception localException) {}
/*     */   }
/*     */   
/*     */ 
/*  81 */   private static Logger log = Logger.getLogger("org.jcp.xml.dsig.internal.dom");
/*     */   
/*     */   private final DigestMethod digestMethod;
/*     */   private final String id;
/*     */   private final List transforms;
/*     */   private List allTransforms;
/*     */   private final Data appliedTransformData;
/*     */   private Attr here;
/*     */   private final String uri;
/*     */   private final String type;
/*     */   private byte[] digestValue;
/*     */   private byte[] calcDigestValue;
/*     */   private Element refElem;
/*  94 */   private boolean digested = false;
/*  95 */   private boolean validated = false;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean validationStatus;
/*     */   
/*     */ 
/*     */ 
/*     */   private Data derefData;
/*     */   
/*     */ 
/*     */ 
/*     */   private InputStream dis;
/*     */   
/*     */ 
/*     */   private MessageDigest md;
/*     */   
/*     */ 
/*     */   private Provider provider;
/*     */   
/*     */ 
/*     */ 
/*     */   public DOMReference(String uri, String type, DigestMethod dm, List transforms, String id, Provider provider)
/*     */   {
/* 119 */     this(uri, type, dm, null, null, transforms, id, null, provider);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public DOMReference(String uri, String type, DigestMethod dm, List appliedTransforms, Data result, List transforms, String id, Provider provider)
/*     */   {
/* 126 */     this(uri, type, dm, appliedTransforms, result, transforms, id, null, provider);
/*     */   }
/*     */   
/*     */ 
/*     */   public DOMReference(String uri, String type, DigestMethod dm, List appliedTransforms, Data result, List transforms, String id, byte[] digestValue, Provider provider)
/*     */   {
/* 132 */     if (dm == null) {
/* 133 */       throw new NullPointerException("DigestMethod must be non-null");
/*     */     }
/* 135 */     this.allTransforms = new ArrayList();
/* 136 */     if (appliedTransforms != null) {
/* 137 */       List transformsCopy = new ArrayList(appliedTransforms);
/* 138 */       int i = 0; for (int size = transformsCopy.size(); i < size; i++) {
/* 139 */         if (!(transformsCopy.get(i) instanceof Transform)) {
/* 140 */           throw new ClassCastException(
/* 141 */             "appliedTransforms[" + i + "] is not a valid type");
/*     */         }
/*     */       }
/* 144 */       this.allTransforms = transformsCopy;
/*     */     }
/* 146 */     if (transforms == null) {
/* 147 */       this.transforms = Collections.EMPTY_LIST;
/*     */     } else {
/* 149 */       List transformsCopy = new ArrayList(transforms);
/* 150 */       int i = 0; for (int size = transformsCopy.size(); i < size; i++) {
/* 151 */         if (!(transformsCopy.get(i) instanceof Transform)) {
/* 152 */           throw new ClassCastException(
/* 153 */             "transforms[" + i + "] is not a valid type");
/*     */         }
/*     */       }
/* 156 */       this.transforms = transformsCopy;
/* 157 */       this.allTransforms.addAll(transformsCopy);
/*     */     }
/* 159 */     this.digestMethod = dm;
/* 160 */     this.uri = uri;
/* 161 */     if ((uri != null) && (!uri.equals(""))) {
/*     */       try {
/* 163 */         new URI(uri);
/*     */       } catch (URISyntaxException e) {
/* 165 */         throw new IllegalArgumentException(e.getMessage());
/*     */       }
/*     */     }
/* 168 */     this.type = type;
/* 169 */     this.id = id;
/* 170 */     if (digestValue != null) {
/* 171 */       this.digestValue = ((byte[])digestValue.clone());
/* 172 */       this.digested = true;
/*     */     }
/* 174 */     this.appliedTransformData = result;
/* 175 */     this.provider = provider;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMReference(Element refElem, XMLCryptoContext context, Provider provider)
/*     */     throws MarshalException
/*     */   {
/* 186 */     Element nextSibling = DOMUtils.getFirstChildElement(refElem);
/* 187 */     List transforms = new ArrayList(5);
/* 188 */     if (nextSibling.getLocalName().equals("Transforms")) {
/* 189 */       Element transformElem = DOMUtils.getFirstChildElement(nextSibling);
/* 190 */       while (transformElem != null) {
/* 191 */         transforms.add(
/* 192 */           new DOMTransform(transformElem, context, provider));
/* 193 */         transformElem = DOMUtils.getNextSiblingElement(transformElem);
/*     */       }
/* 195 */       nextSibling = DOMUtils.getNextSiblingElement(nextSibling);
/*     */     }
/*     */     
/*     */ 
/* 199 */     Element dmElem = nextSibling;
/* 200 */     this.digestMethod = DOMDigestMethod.unmarshal(dmElem);
/*     */     
/*     */     try
/*     */     {
/* 204 */       Element dvElem = DOMUtils.getNextSiblingElement(dmElem);
/* 205 */       this.digestValue = Base64.decode(dvElem);
/*     */     } catch (Base64DecodingException bde) {
/* 207 */       throw new MarshalException(bde);
/*     */     }
/*     */     
/*     */ 
/* 211 */     this.uri = DOMUtils.getAttributeValue(refElem, "URI");
/* 212 */     this.id = DOMUtils.getAttributeValue(refElem, "Id");
/*     */     
/* 214 */     this.type = DOMUtils.getAttributeValue(refElem, "Type");
/* 215 */     this.here = refElem.getAttributeNodeNS(null, "URI");
/* 216 */     this.refElem = refElem;
/* 217 */     this.transforms = transforms;
/* 218 */     this.allTransforms = transforms;
/* 219 */     this.appliedTransformData = null;
/* 220 */     this.provider = provider;
/*     */   }
/*     */   
/*     */   public DigestMethod getDigestMethod() {
/* 224 */     return this.digestMethod;
/*     */   }
/*     */   
/*     */   public String getId() {
/* 228 */     return this.id;
/*     */   }
/*     */   
/*     */   public String getURI() {
/* 232 */     return this.uri;
/*     */   }
/*     */   
/*     */   public String getType() {
/* 236 */     return this.type;
/*     */   }
/*     */   
/*     */   public List getTransforms() {
/* 240 */     return Collections.unmodifiableList(this.allTransforms);
/*     */   }
/*     */   
/*     */   public byte[] getDigestValue() {
/* 244 */     return this.digestValue == null ? null : (byte[])this.digestValue.clone();
/*     */   }
/*     */   
/*     */   public byte[] getCalculatedDigestValue() {
/* 248 */     return this.calcDigestValue == null ? null : 
/* 249 */       (byte[])this.calcDigestValue.clone();
/*     */   }
/*     */   
/*     */   public void marshal(Node parent, String dsPrefix, DOMCryptoContext context) throws MarshalException
/*     */   {
/* 254 */     if (log.isLoggable(Level.FINE)) {
/* 255 */       log.log(Level.FINE, "Marshalling Reference");
/*     */     }
/* 257 */     Document ownerDoc = DOMUtils.getOwnerDocument(parent);
/*     */     
/* 259 */     this.refElem = DOMUtils.createElement(
/* 260 */       ownerDoc, "Reference", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */     
/*     */ 
/* 263 */     DOMUtils.setAttributeID(this.refElem, "Id", this.id);
/* 264 */     DOMUtils.setAttribute(this.refElem, "URI", this.uri);
/* 265 */     DOMUtils.setAttribute(this.refElem, "Type", this.type);
/*     */     
/*     */ 
/* 268 */     if (!this.allTransforms.isEmpty()) {
/* 269 */       Element transformsElem = DOMUtils.createElement(
/* 270 */         ownerDoc, "Transforms", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/* 271 */       this.refElem.appendChild(transformsElem);
/* 272 */       int i = 0; for (int size = this.allTransforms.size(); i < size; i++) {
/* 273 */         DOMStructure transform = 
/* 274 */           (DOMStructure)this.allTransforms.get(i);
/* 275 */         transform.marshal(transformsElem, dsPrefix, context);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 280 */     ((DOMDigestMethod)this.digestMethod).marshal(this.refElem, dsPrefix, context);
/*     */     
/*     */ 
/* 283 */     if (log.isLoggable(Level.FINE)) {
/* 284 */       log.log(Level.FINE, "Adding digestValueElem");
/*     */     }
/* 286 */     Element digestValueElem = DOMUtils.createElement(
/* 287 */       ownerDoc, "DigestValue", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/* 288 */     if (this.digestValue != null) {
/* 289 */       digestValueElem.appendChild(
/* 290 */         ownerDoc.createTextNode(Base64.encode(this.digestValue)));
/*     */     }
/* 292 */     this.refElem.appendChild(digestValueElem);
/*     */     
/* 294 */     parent.appendChild(this.refElem);
/* 295 */     this.here = this.refElem.getAttributeNodeNS(null, "URI");
/*     */   }
/*     */   
/*     */   public void digest(XMLSignContext signContext) throws XMLSignatureException
/*     */   {
/* 300 */     Data data = null;
/* 301 */     if (this.appliedTransformData == null) {
/* 302 */       data = dereference(signContext);
/*     */     } else {
/* 304 */       data = this.appliedTransformData;
/*     */     }
/* 306 */     this.digestValue = transform(data, signContext);
/*     */     
/*     */ 
/* 309 */     String encodedDV = Base64.encode(this.digestValue);
/* 310 */     if (log.isLoggable(Level.FINE)) {
/* 311 */       log.log(Level.FINE, "Reference object uri = " + this.uri);
/*     */     }
/* 313 */     Element digestElem = DOMUtils.getLastChildElement(this.refElem);
/* 314 */     if (digestElem == null) {
/* 315 */       throw new XMLSignatureException("DigestValue element expected");
/*     */     }
/* 317 */     DOMUtils.removeAllChildren(digestElem);
/* 318 */     digestElem.appendChild(
/* 319 */       this.refElem.getOwnerDocument().createTextNode(encodedDV));
/*     */     
/* 321 */     this.digested = true;
/* 322 */     if (log.isLoggable(Level.FINE)) {
/* 323 */       log.log(Level.FINE, "Reference digesting completed");
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean validate(XMLValidateContext validateContext) throws XMLSignatureException
/*     */   {
/* 329 */     if (validateContext == null) {
/* 330 */       throw new NullPointerException("validateContext cannot be null");
/*     */     }
/* 332 */     if (this.validated) {
/* 333 */       return this.validationStatus;
/*     */     }
/* 335 */     Data data = dereference(validateContext);
/* 336 */     this.calcDigestValue = transform(data, validateContext);
/*     */     
/* 338 */     if (log.isLoggable(Level.FINE)) {
/* 339 */       log.log(Level.FINE, "Expected digest: " + 
/* 340 */         Base64.encode(this.digestValue));
/* 341 */       log.log(Level.FINE, "Actual digest: " + 
/* 342 */         Base64.encode(this.calcDigestValue));
/*     */     }
/*     */     
/* 345 */     this.validationStatus = Arrays.equals(this.digestValue, this.calcDigestValue);
/* 346 */     this.validated = true;
/* 347 */     return this.validationStatus;
/*     */   }
/*     */   
/*     */   public Data getDereferencedData() {
/* 351 */     return this.derefData;
/*     */   }
/*     */   
/*     */   public InputStream getDigestInputStream() {
/* 355 */     return this.dis;
/*     */   }
/*     */   
/*     */   private Data dereference(XMLCryptoContext context) throws XMLSignatureException
/*     */   {
/* 360 */     Data data = null;
/*     */     
/*     */ 
/* 363 */     URIDereferencer deref = context.getURIDereferencer();
/* 364 */     if (deref == null) {
/* 365 */       deref = DOMURIDereferencer.INSTANCE;
/*     */     }
/*     */     try {
/* 368 */       data = deref.dereference(this, context);
/* 369 */       if (log.isLoggable(Level.FINE)) {
/* 370 */         log.log(Level.FINE, "URIDereferencer class name: " + 
/* 371 */           deref.getClass().getName());
/* 372 */         log.log(Level.FINE, "Data class name: " + 
/* 373 */           data.getClass().getName());
/*     */       }
/*     */     } catch (URIReferenceException ure) {
/* 376 */       throw new XMLSignatureException(ure);
/*     */     }
/*     */     
/* 379 */     return data;
/*     */   }
/*     */   
/*     */   private byte[] transform(Data dereferencedData, XMLCryptoContext context)
/*     */     throws XMLSignatureException
/*     */   {
/* 385 */     if (this.md == null) {
/*     */       try {
/* 387 */         this.md = MessageDigest.getInstance(
/* 388 */           ((DOMDigestMethod)this.digestMethod).getMessageDigestAlgorithm());
/*     */       } catch (NoSuchAlgorithmException nsae) {
/* 390 */         throw new XMLSignatureException(nsae);
/*     */       }
/*     */     }
/* 393 */     this.md.reset();
/*     */     
/* 395 */     Boolean cache = (Boolean)
/* 396 */       context.getProperty("javax.xml.crypto.dsig.cacheReference");
/* 397 */     DigesterOutputStream dos; DigesterOutputStream dos; if ((cache != null) && (cache.booleanValue())) {
/* 398 */       this.derefData = copyDerefData(dereferencedData);
/* 399 */       dos = new DigesterOutputStream(this.md, true);
/*     */     } else {
/* 401 */       dos = new DigesterOutputStream(this.md);
/*     */     }
/* 403 */     OutputStream os = new UnsyncBufferedOutputStream(dos);
/* 404 */     Data data = dereferencedData;
/* 405 */     int i = 0; for (int size = this.transforms.size(); i < size; i++) {
/* 406 */       DOMTransform transform = (DOMTransform)this.transforms.get(i);
/*     */       try {
/* 408 */         if (i < size - 1) {
/* 409 */           data = transform.transform(data, context);
/*     */         } else {
/* 411 */           data = transform.transform(data, context, os);
/*     */         }
/*     */       } catch (TransformException te) {
/* 414 */         throw new XMLSignatureException(te);
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 419 */       if (data != null)
/*     */       {
/*     */ 
/*     */ 
/* 423 */         boolean c14n11 = useC14N11;
/* 424 */         String c14nalg = "http://www.w3.org/TR/2001/REC-xml-c14n-20010315";
/* 425 */         if ((context instanceof XMLSignContext))
/* 426 */           if (!c14n11) {
/* 427 */             Boolean prop = (Boolean)context.getProperty(
/* 428 */               "adsi.org.apache.xml.security.useC14N11");
/* 429 */             c14n11 = (prop != null) && (prop.booleanValue());
/* 430 */             if (c14n11) {
/* 431 */               c14nalg = "http://www.w3.org/2006/12/xml-c14n11";
/*     */             }
/*     */           } else {
/* 434 */             c14nalg = "http://www.w3.org/2006/12/xml-c14n11";
/*     */           }
/*     */         XMLSignatureInput xi;
/* 437 */         if ((data instanceof ApacheData)) {
/* 438 */           xi = ((ApacheData)data).getXMLSignatureInput(); } else { XMLSignatureInput xi;
/* 439 */           if ((data instanceof OctetStreamData)) {
/* 440 */             xi = new XMLSignatureInput(
/* 441 */               ((OctetStreamData)data).getOctetStream()); } else { XMLSignatureInput xi;
/* 442 */             if ((data instanceof NodeSetData)) {
/* 443 */               TransformService spi = null;
/*     */               try {
/* 445 */                 spi = TransformService.getInstance(c14nalg, "DOM");
/*     */               } catch (NoSuchAlgorithmException nsae) {
/* 447 */                 spi = TransformService.getInstance(
/* 448 */                   c14nalg, "DOM", this.provider);
/*     */               }
/* 450 */               data = spi.transform(data, context);
/* 451 */               xi = new XMLSignatureInput(
/* 452 */                 ((OctetStreamData)data).getOctetStream());
/*     */             } else {
/* 454 */               throw new XMLSignatureException("unrecognized Data type"); } } }
/*     */         XMLSignatureInput xi;
/* 456 */         if (((context instanceof XMLSignContext)) && (c14n11) && 
/* 457 */           (!xi.isOctetStream()) && (!xi.isOutputStreamSet())) {
/* 458 */           DOMTransform t = new DOMTransform(
/* 459 */             TransformService.getInstance(c14nalg, "DOM"));
/* 460 */           Element transformsElem = null;
/* 461 */           String dsPrefix = DOMUtils.getSignaturePrefix(context);
/* 462 */           if (this.allTransforms.isEmpty()) {
/* 463 */             transformsElem = DOMUtils.createElement(
/* 464 */               this.refElem.getOwnerDocument(), 
/* 465 */               "Transforms", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/* 466 */             this.refElem.insertBefore(transformsElem, 
/* 467 */               DOMUtils.getFirstChildElement(this.refElem));
/*     */           } else {
/* 469 */             transformsElem = DOMUtils.getFirstChildElement(this.refElem);
/*     */           }
/* 471 */           t.marshal(transformsElem, dsPrefix, (DOMCryptoContext)context);
/* 472 */           this.allTransforms.add(t);
/* 473 */           xi.updateOutputStream(os, true);
/*     */         } else {
/* 475 */           xi.updateOutputStream(os);
/*     */         }
/*     */       }
/* 478 */       os.flush();
/* 479 */       if ((cache != null) && (cache.booleanValue())) {
/* 480 */         this.dis = dos.getInputStream();
/*     */       }
/* 482 */       return dos.getDigestValue();
/*     */     } catch (Exception e) {
/* 484 */       throw new XMLSignatureException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public Node getHere() {
/* 489 */     return this.here;
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 493 */     if (this == o) {
/* 494 */       return true;
/*     */     }
/*     */     
/* 497 */     if (!(o instanceof Reference)) {
/* 498 */       return false;
/*     */     }
/* 500 */     Reference oref = (Reference)o;
/*     */     
/* 502 */     boolean idsEqual = this.id == null ? false : oref.getId() == null ? true : 
/* 503 */       this.id.equals(oref.getId());
/* 504 */     boolean urisEqual = this.uri == null ? false : oref.getURI() == null ? true : 
/* 505 */       this.uri.equals(oref.getURI());
/* 506 */     boolean typesEqual = this.type == null ? false : oref.getType() == null ? true : 
/* 507 */       this.type.equals(oref.getType());
/* 508 */     boolean digestValuesEqual = 
/* 509 */       Arrays.equals(this.digestValue, oref.getDigestValue());
/*     */     
/*     */ 
/* 512 */     return (this.digestMethod.equals(oref.getDigestMethod())) && (idsEqual) && (urisEqual) && (typesEqual) && (this.allTransforms.equals(oref.getTransforms()));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 516 */     if (!$assertionsDisabled) throw new AssertionError("hashCode not designed");
/* 517 */     return 47;
/*     */   }
/*     */   
/*     */   boolean isDigested() {
/* 521 */     return this.digested;
/*     */   }
/*     */   
/*     */   private static Data copyDerefData(Data dereferencedData) {
/* 525 */     if ((dereferencedData instanceof ApacheData))
/*     */     {
/* 527 */       ApacheData ad = (ApacheData)dereferencedData;
/* 528 */       XMLSignatureInput xsi = ad.getXMLSignatureInput();
/* 529 */       if (xsi.isNodeSet())
/*     */         try {
/* 531 */           Set s = xsi.getNodeSet();
/* 532 */           new NodeSetData() {
/* 533 */             public Iterator iterator() { return DOMReference.this.iterator(); }
/*     */           };
/*     */         }
/*     */         catch (Exception e) {
/* 537 */           log.log(Level.WARNING, 
/* 538 */             "cannot cache dereferenced data: " + e);
/* 539 */           return null;
/*     */         }
/* 541 */       if (xsi.isElement())
/* 542 */         return new DOMSubTreeData(
/* 543 */           xsi.getSubNode(), xsi.isExcludeComments());
/* 544 */       if ((xsi.isOctetStream()) || (xsi.isByteArray())) {
/*     */         try {
/* 546 */           return new OctetStreamData(
/* 547 */             xsi.getOctetStream(), xsi.getSourceURI(), xsi.getMIMEType());
/*     */         }
/*     */         catch (IOException ioe) {
/* 550 */           log.log(Level.WARNING, 
/* 551 */             "cannot cache dereferenced data: " + ioe);
/* 552 */           return null;
/*     */         }
/*     */       }
/*     */     }
/* 556 */     return dereferencedData;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\org\jcp\xml\dsig\internal\dom\DOMReference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */