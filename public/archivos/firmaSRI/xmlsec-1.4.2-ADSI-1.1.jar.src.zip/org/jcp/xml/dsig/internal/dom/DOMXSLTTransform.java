/*    */ package org.jcp.xml.dsig.internal.dom;
/*    */ 
/*    */ import java.security.InvalidAlgorithmParameterException;
/*    */ import javax.xml.crypto.MarshalException;
/*    */ import javax.xml.crypto.XMLCryptoContext;
/*    */ import javax.xml.crypto.XMLStructure;
/*    */ import javax.xml.crypto.dom.DOMStructure;
/*    */ import javax.xml.crypto.dsig.spec.TransformParameterSpec;
/*    */ import javax.xml.crypto.dsig.spec.XSLTTransformParameterSpec;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DOMXSLTTransform
/*    */   extends ApacheTransform
/*    */ {
/*    */   public void init(TransformParameterSpec params)
/*    */     throws InvalidAlgorithmParameterException
/*    */   {
/* 44 */     if (params == null) {
/* 45 */       throw new InvalidAlgorithmParameterException("params are required");
/*    */     }
/* 47 */     if (!(params instanceof XSLTTransformParameterSpec)) {
/* 48 */       throw new InvalidAlgorithmParameterException("unrecognized params");
/*    */     }
/* 50 */     this.params = params;
/*    */   }
/*    */   
/*    */   public void init(XMLStructure parent, XMLCryptoContext context)
/*    */     throws InvalidAlgorithmParameterException
/*    */   {
/* 56 */     super.init(parent, context);
/* 57 */     unmarshalParams(DOMUtils.getFirstChildElement(this.transformElem));
/*    */   }
/*    */   
/*    */   private void unmarshalParams(Element sheet) {
/* 61 */     this.params = new XSLTTransformParameterSpec(
/* 62 */       new DOMStructure(sheet));
/*    */   }
/*    */   
/*    */   public void marshalParams(XMLStructure parent, XMLCryptoContext context) throws MarshalException
/*    */   {
/* 67 */     super.marshalParams(parent, context);
/* 68 */     XSLTTransformParameterSpec xp = 
/* 69 */       (XSLTTransformParameterSpec)getParameterSpec();
/* 70 */     Node xsltElem = 
/* 71 */       ((DOMStructure)xp.getStylesheet()).getNode();
/* 72 */     DOMUtils.appendChild(this.transformElem, xsltElem);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\org\jcp\xml\dsig\internal\dom\DOMXSLTTransform.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */