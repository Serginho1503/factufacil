package org.jcp.xml.dsig.internal.dom;

import adsi.org.apache.xml.security.signature.XMLSignatureInput;
import javax.xml.crypto.Data;

public abstract interface ApacheData
  extends Data
{
  public abstract XMLSignatureInput getXMLSignatureInput();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\org\jcp\xml\dsig\internal\dom\ApacheData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */