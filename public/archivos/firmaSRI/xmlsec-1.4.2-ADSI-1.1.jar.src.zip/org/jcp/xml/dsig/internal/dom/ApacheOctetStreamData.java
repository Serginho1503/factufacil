/*    */ package org.jcp.xml.dsig.internal.dom;
/*    */ 
/*    */ import adsi.org.apache.xml.security.c14n.CanonicalizationException;
/*    */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*    */ import java.io.IOException;
/*    */ import javax.xml.crypto.OctetStreamData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApacheOctetStreamData
/*    */   extends OctetStreamData
/*    */   implements ApacheData
/*    */ {
/*    */   private XMLSignatureInput xi;
/*    */   
/*    */   public ApacheOctetStreamData(XMLSignatureInput xi)
/*    */     throws CanonicalizationException, IOException
/*    */   {
/* 38 */     super(xi.getOctetStream(), xi.getSourceURI(), xi.getMIMEType());
/* 39 */     this.xi = xi;
/*    */   }
/*    */   
/*    */   public XMLSignatureInput getXMLSignatureInput() {
/* 43 */     return this.xi;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\org\jcp\xml\dsig\internal\dom\ApacheOctetStreamData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */