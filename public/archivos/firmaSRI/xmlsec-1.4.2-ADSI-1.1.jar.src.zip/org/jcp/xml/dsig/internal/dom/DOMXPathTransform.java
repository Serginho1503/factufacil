/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.XMLCryptoContext;
/*     */ import javax.xml.crypto.XMLStructure;
/*     */ import javax.xml.crypto.dsig.spec.TransformParameterSpec;
/*     */ import javax.xml.crypto.dsig.spec.XPathFilterParameterSpec;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DOMXPathTransform
/*     */   extends ApacheTransform
/*     */ {
/*     */   public void init(TransformParameterSpec params)
/*     */     throws InvalidAlgorithmParameterException
/*     */   {
/*  47 */     if (params == null)
/*  48 */       throw new InvalidAlgorithmParameterException("params are required");
/*  49 */     if (!(params instanceof XPathFilterParameterSpec)) {
/*  50 */       throw new InvalidAlgorithmParameterException(
/*  51 */         "params must be of type XPathFilterParameterSpec");
/*     */     }
/*  53 */     this.params = params;
/*     */   }
/*     */   
/*     */   public void init(XMLStructure parent, XMLCryptoContext context)
/*     */     throws InvalidAlgorithmParameterException
/*     */   {
/*  59 */     super.init(parent, context);
/*  60 */     unmarshalParams(DOMUtils.getFirstChildElement(this.transformElem));
/*     */   }
/*     */   
/*     */   private void unmarshalParams(Element paramsElem) {
/*  64 */     String xPath = paramsElem.getFirstChild().getNodeValue();
/*     */     
/*  66 */     NamedNodeMap attributes = paramsElem.getAttributes();
/*  67 */     if (attributes != null) {
/*  68 */       int length = attributes.getLength();
/*  69 */       Map namespaceMap = new HashMap(length);
/*  70 */       for (int i = 0; i < length; i++) {
/*  71 */         Attr attr = (Attr)attributes.item(i);
/*  72 */         String prefix = attr.getPrefix();
/*  73 */         if ((prefix != null) && (prefix.equals("xmlns"))) {
/*  74 */           namespaceMap.put(attr.getLocalName(), attr.getValue());
/*     */         }
/*     */       }
/*  77 */       this.params = new XPathFilterParameterSpec(xPath, namespaceMap);
/*     */     } else {
/*  79 */       this.params = new XPathFilterParameterSpec(xPath);
/*     */     }
/*     */   }
/*     */   
/*     */   public void marshalParams(XMLStructure parent, XMLCryptoContext context)
/*     */     throws MarshalException
/*     */   {
/*  86 */     super.marshalParams(parent, context);
/*  87 */     XPathFilterParameterSpec xp = 
/*  88 */       (XPathFilterParameterSpec)getParameterSpec();
/*  89 */     Element xpathElem = DOMUtils.createElement(
/*  90 */       this.ownerDoc, "XPath", "http://www.w3.org/2000/09/xmldsig#", 
/*  91 */       DOMUtils.getSignaturePrefix(context));
/*  92 */     xpathElem.appendChild(this.ownerDoc.createTextNode(xp.getXPath()));
/*     */     
/*     */ 
/*  95 */     Iterator i = xp.getNamespaceMap().entrySet().iterator();
/*  96 */     while (i.hasNext()) {
/*  97 */       Map.Entry entry = (Map.Entry)i.next();
/*  98 */       xpathElem.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns:" + 
/*  99 */         (String)entry.getKey(), (String)entry.getValue());
/*     */     }
/*     */     
/* 102 */     this.transformElem.appendChild(xpathElem);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\org\jcp\xml\dsig\internal\dom\DOMXPathTransform.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */