/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.dom.DOMCryptoContext;
/*     */ import javax.xml.crypto.dsig.SignatureProperties;
/*     */ import javax.xml.crypto.dsig.SignatureProperty;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DOMSignatureProperties
/*     */   extends DOMStructure
/*     */   implements SignatureProperties
/*     */ {
/*     */   private final String id;
/*     */   private final List properties;
/*     */   
/*     */   public DOMSignatureProperties(List properties, String id)
/*     */   {
/*  60 */     if (properties == null)
/*  61 */       throw new NullPointerException("properties cannot be null");
/*  62 */     if (properties.isEmpty()) {
/*  63 */       throw new IllegalArgumentException("properties cannot be empty");
/*     */     }
/*  65 */     List propsCopy = new ArrayList(properties);
/*  66 */     int i = 0; for (int size = propsCopy.size(); i < size; i++) {
/*  67 */       if (!(propsCopy.get(i) instanceof SignatureProperty)) {
/*  68 */         throw new ClassCastException(
/*  69 */           "properties[" + i + "] is not a valid type");
/*     */       }
/*     */     }
/*  72 */     this.properties = Collections.unmodifiableList(propsCopy);
/*     */     
/*  74 */     this.id = id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMSignatureProperties(Element propsElem)
/*     */     throws MarshalException
/*     */   {
/*  85 */     this.id = DOMUtils.getAttributeValue(propsElem, "Id");
/*     */     
/*  87 */     NodeList nodes = propsElem.getChildNodes();
/*  88 */     int length = nodes.getLength();
/*  89 */     List properties = new ArrayList(length);
/*  90 */     for (int i = 0; i < length; i++) {
/*  91 */       Node child = nodes.item(i);
/*  92 */       if (child.getNodeType() == 1) {
/*  93 */         properties.add(new DOMSignatureProperty((Element)child));
/*     */       }
/*     */     }
/*  96 */     if (properties.isEmpty()) {
/*  97 */       throw new MarshalException("properties cannot be empty");
/*     */     }
/*  99 */     this.properties = Collections.unmodifiableList(properties);
/*     */   }
/*     */   
/*     */   public List getProperties()
/*     */   {
/* 104 */     return this.properties;
/*     */   }
/*     */   
/*     */   public String getId() {
/* 108 */     return this.id;
/*     */   }
/*     */   
/*     */   public void marshal(Node parent, String dsPrefix, DOMCryptoContext context) throws MarshalException
/*     */   {
/* 113 */     Document ownerDoc = DOMUtils.getOwnerDocument(parent);
/*     */     
/* 115 */     Element propsElem = DOMUtils.createElement(
/* 116 */       ownerDoc, "SignatureProperties", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */     
/*     */ 
/* 119 */     DOMUtils.setAttributeID(propsElem, "Id", this.id);
/*     */     
/*     */ 
/* 122 */     int i = 0; for (int size = this.properties.size(); i < size; i++) {
/* 123 */       DOMSignatureProperty property = 
/* 124 */         (DOMSignatureProperty)this.properties.get(i);
/* 125 */       property.marshal(propsElem, dsPrefix, context);
/*     */     }
/*     */     
/* 128 */     parent.appendChild(propsElem);
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 132 */     if (this == o) {
/* 133 */       return true;
/*     */     }
/*     */     
/* 136 */     if (!(o instanceof SignatureProperties)) {
/* 137 */       return false;
/*     */     }
/* 139 */     SignatureProperties osp = (SignatureProperties)o;
/*     */     
/* 141 */     boolean idsEqual = this.id == null ? false : osp.getId() == null ? true : 
/* 142 */       this.id.equals(osp.getId());
/*     */     
/* 144 */     return (this.properties.equals(osp.getProperties())) && (idsEqual);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 148 */     if (!$assertionsDisabled) throw new AssertionError("hashCode not designed");
/* 149 */     return 49;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\org\jcp\xml\dsig\internal\dom\DOMSignatureProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */