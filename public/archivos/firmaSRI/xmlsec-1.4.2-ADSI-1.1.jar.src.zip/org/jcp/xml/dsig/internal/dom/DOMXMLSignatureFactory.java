/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.List;
/*     */ import javax.xml.crypto.Data;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.URIDereferencer;
/*     */ import javax.xml.crypto.XMLStructure;
/*     */ import javax.xml.crypto.dom.DOMStructure;
/*     */ import javax.xml.crypto.dsig.CanonicalizationMethod;
/*     */ import javax.xml.crypto.dsig.DigestMethod;
/*     */ import javax.xml.crypto.dsig.Manifest;
/*     */ import javax.xml.crypto.dsig.Reference;
/*     */ import javax.xml.crypto.dsig.SignatureMethod;
/*     */ import javax.xml.crypto.dsig.SignatureProperties;
/*     */ import javax.xml.crypto.dsig.SignatureProperty;
/*     */ import javax.xml.crypto.dsig.SignedInfo;
/*     */ import javax.xml.crypto.dsig.Transform;
/*     */ import javax.xml.crypto.dsig.TransformService;
/*     */ import javax.xml.crypto.dsig.XMLObject;
/*     */ import javax.xml.crypto.dsig.XMLSignature;
/*     */ import javax.xml.crypto.dsig.XMLSignatureFactory;
/*     */ import javax.xml.crypto.dsig.XMLValidateContext;
/*     */ import javax.xml.crypto.dsig.dom.DOMValidateContext;
/*     */ import javax.xml.crypto.dsig.keyinfo.KeyInfo;
/*     */ import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
/*     */ import javax.xml.crypto.dsig.spec.DigestMethodParameterSpec;
/*     */ import javax.xml.crypto.dsig.spec.SignatureMethodParameterSpec;
/*     */ import javax.xml.crypto.dsig.spec.TransformParameterSpec;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DOMXMLSignatureFactory
/*     */   extends XMLSignatureFactory
/*     */ {
/*     */   public XMLSignature newXMLSignature(SignedInfo si, KeyInfo ki)
/*     */   {
/*  52 */     return new DOMXMLSignature(si, ki, null, null, null);
/*     */   }
/*     */   
/*     */   public XMLSignature newXMLSignature(SignedInfo si, KeyInfo ki, List objects, String id, String signatureValueId)
/*     */   {
/*  57 */     return new DOMXMLSignature(si, ki, objects, id, signatureValueId);
/*     */   }
/*     */   
/*     */   public Reference newReference(String uri, DigestMethod dm) {
/*  61 */     return newReference(uri, dm, null, null, null);
/*     */   }
/*     */   
/*     */   public Reference newReference(String uri, DigestMethod dm, List transforms, String type, String id)
/*     */   {
/*  66 */     return new DOMReference(uri, type, dm, transforms, id, getProvider());
/*     */   }
/*     */   
/*     */ 
/*     */   public Reference newReference(String uri, DigestMethod dm, List appliedTransforms, Data result, List transforms, String type, String id)
/*     */   {
/*  72 */     if (appliedTransforms == null) {
/*  73 */       throw new NullPointerException("appliedTransforms cannot be null");
/*     */     }
/*  75 */     if (appliedTransforms.isEmpty()) {
/*  76 */       throw new NullPointerException("appliedTransforms cannot be empty");
/*     */     }
/*  78 */     if (result == null) {
/*  79 */       throw new NullPointerException("result cannot be null");
/*     */     }
/*  81 */     return new DOMReference(
/*  82 */       uri, type, dm, appliedTransforms, result, transforms, id, getProvider());
/*     */   }
/*     */   
/*     */   public Reference newReference(String uri, DigestMethod dm, List transforms, String type, String id, byte[] digestValue)
/*     */   {
/*  87 */     if (digestValue == null) {
/*  88 */       throw new NullPointerException("digestValue cannot be null");
/*     */     }
/*  90 */     return new DOMReference(
/*  91 */       uri, type, dm, null, null, transforms, id, digestValue, getProvider());
/*     */   }
/*     */   
/*     */   public SignedInfo newSignedInfo(CanonicalizationMethod cm, SignatureMethod sm, List references)
/*     */   {
/*  96 */     return newSignedInfo(cm, sm, references, null);
/*     */   }
/*     */   
/*     */   public SignedInfo newSignedInfo(CanonicalizationMethod cm, SignatureMethod sm, List references, String id)
/*     */   {
/* 101 */     return new DOMSignedInfo(cm, sm, references, id);
/*     */   }
/*     */   
/*     */ 
/*     */   public XMLObject newXMLObject(List content, String id, String mimeType, String encoding)
/*     */   {
/* 107 */     return new DOMXMLObject(content, id, mimeType, encoding);
/*     */   }
/*     */   
/*     */   public Manifest newManifest(List references) {
/* 111 */     return newManifest(references, null);
/*     */   }
/*     */   
/*     */   public Manifest newManifest(List references, String id) {
/* 115 */     return new DOMManifest(references, id);
/*     */   }
/*     */   
/*     */   public SignatureProperties newSignatureProperties(List props, String id) {
/* 119 */     return new DOMSignatureProperties(props, id);
/*     */   }
/*     */   
/*     */   public SignatureProperty newSignatureProperty(List info, String target, String id)
/*     */   {
/* 124 */     return new DOMSignatureProperty(info, target, id);
/*     */   }
/*     */   
/*     */   public XMLSignature unmarshalXMLSignature(XMLValidateContext context)
/*     */     throws MarshalException
/*     */   {
/* 130 */     if (context == null) {
/* 131 */       throw new NullPointerException("context cannot be null");
/*     */     }
/* 133 */     return unmarshal(((DOMValidateContext)context).getNode(), context);
/*     */   }
/*     */   
/*     */   public XMLSignature unmarshalXMLSignature(XMLStructure xmlStructure)
/*     */     throws MarshalException
/*     */   {
/* 139 */     if (xmlStructure == null) {
/* 140 */       throw new NullPointerException("xmlStructure cannot be null");
/*     */     }
/* 142 */     return unmarshal(
/* 143 */       ((DOMStructure)xmlStructure).getNode(), 
/* 144 */       null);
/*     */   }
/*     */   
/*     */   private XMLSignature unmarshal(Node node, XMLValidateContext context)
/*     */     throws MarshalException
/*     */   {
/* 150 */     node.normalize();
/*     */     
/* 152 */     Element element = null;
/* 153 */     if (node.getNodeType() == 9) {
/* 154 */       element = ((Document)node).getDocumentElement();
/* 155 */     } else if (node.getNodeType() == 1) {
/* 156 */       element = (Element)node;
/*     */     } else {
/* 158 */       throw new MarshalException(
/* 159 */         "Signature element is not a proper Node");
/*     */     }
/*     */     
/*     */ 
/* 163 */     String tag = element.getLocalName();
/* 164 */     if (tag == null) {
/* 165 */       throw new MarshalException("Document implementation must support DOM Level 2 and be namespace aware");
/*     */     }
/*     */     
/* 168 */     if (tag.equals("Signature")) {
/* 169 */       return new DOMXMLSignature(element, context, getProvider());
/*     */     }
/* 171 */     throw new MarshalException("invalid Signature tag: " + tag);
/*     */   }
/*     */   
/*     */   public boolean isFeatureSupported(String feature)
/*     */   {
/* 176 */     if (feature == null) {
/* 177 */       throw new NullPointerException();
/*     */     }
/* 179 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public DigestMethod newDigestMethod(String algorithm, DigestMethodParameterSpec params)
/*     */     throws NoSuchAlgorithmException, InvalidAlgorithmParameterException
/*     */   {
/* 186 */     if (algorithm == null) {
/* 187 */       throw new NullPointerException();
/*     */     }
/* 189 */     if (algorithm.equals("http://www.w3.org/2000/09/xmldsig#sha1"))
/* 190 */       return new DOMDigestMethod.SHA1(params);
/* 191 */     if (algorithm.equals("http://www.w3.org/2001/04/xmlenc#sha256"))
/* 192 */       return new DOMDigestMethod.SHA256(params);
/* 193 */     if (algorithm.equals("http://www.w3.org/2001/04/xmldsig-more#sha384"))
/* 194 */       return new DOMDigestMethod.SHA384(params);
/* 195 */     if (algorithm.equals("http://www.w3.org/2001/04/xmlenc#sha512")) {
/* 196 */       return new DOMDigestMethod.SHA512(params);
/*     */     }
/* 198 */     throw new NoSuchAlgorithmException("unsupported algorithm");
/*     */   }
/*     */   
/*     */ 
/*     */   public SignatureMethod newSignatureMethod(String algorithm, SignatureMethodParameterSpec params)
/*     */     throws NoSuchAlgorithmException, InvalidAlgorithmParameterException
/*     */   {
/* 205 */     if (algorithm == null) {
/* 206 */       throw new NullPointerException();
/*     */     }
/* 208 */     if (algorithm.equals("http://www.w3.org/2000/09/xmldsig#rsa-sha1"))
/* 209 */       return new DOMSignatureMethod.SHA1withRSA(params);
/* 210 */     if (algorithm.equals("http://www.w3.org/2001/04/xmldsig-more#rsa-sha256"))
/* 211 */       return new DOMSignatureMethod.SHA256withRSA(params);
/* 212 */     if (algorithm.equals("http://www.w3.org/2001/04/xmldsig-more#rsa-sha384"))
/* 213 */       return new DOMSignatureMethod.SHA384withRSA(params);
/* 214 */     if (algorithm.equals("http://www.w3.org/2001/04/xmldsig-more#rsa-sha512"))
/* 215 */       return new DOMSignatureMethod.SHA512withRSA(params);
/* 216 */     if (algorithm.equals("http://www.w3.org/2000/09/xmldsig#dsa-sha1"))
/* 217 */       return new DOMSignatureMethod.SHA1withDSA(params);
/* 218 */     if (algorithm.equals("http://www.w3.org/2000/09/xmldsig#hmac-sha1"))
/* 219 */       return new DOMHMACSignatureMethod.SHA1(params);
/* 220 */     if (algorithm.equals("http://www.w3.org/2001/04/xmldsig-more#hmac-sha256"))
/* 221 */       return new DOMHMACSignatureMethod.SHA256(params);
/* 222 */     if (algorithm.equals("http://www.w3.org/2001/04/xmldsig-more#hmac-sha384"))
/* 223 */       return new DOMHMACSignatureMethod.SHA384(params);
/* 224 */     if (algorithm.equals("http://www.w3.org/2001/04/xmldsig-more#hmac-sha512")) {
/* 225 */       return new DOMHMACSignatureMethod.SHA512(params);
/*     */     }
/* 227 */     throw new NoSuchAlgorithmException("unsupported algorithm");
/*     */   }
/*     */   
/*     */   public Transform newTransform(String algorithm, TransformParameterSpec params)
/*     */     throws NoSuchAlgorithmException, InvalidAlgorithmParameterException
/*     */   {
/*     */     TransformService spi;
/*     */     try
/*     */     {
/* 236 */       spi = TransformService.getInstance(algorithm, "DOM");
/*     */     } catch (NoSuchAlgorithmException nsae) { TransformService spi;
/* 238 */       spi = TransformService.getInstance(algorithm, "DOM", getProvider());
/*     */     }
/* 240 */     spi.init(params);
/* 241 */     return new DOMTransform(spi);
/*     */   }
/*     */   
/*     */   public Transform newTransform(String algorithm, XMLStructure params) throws NoSuchAlgorithmException, InvalidAlgorithmParameterException
/*     */   {
/*     */     TransformService spi;
/*     */     try
/*     */     {
/* 249 */       spi = TransformService.getInstance(algorithm, "DOM");
/*     */     } catch (NoSuchAlgorithmException nsae) { TransformService spi;
/* 251 */       spi = TransformService.getInstance(algorithm, "DOM", getProvider());
/*     */     }
/* 253 */     if (params == null) {
/* 254 */       spi.init(null);
/*     */     } else {
/* 256 */       spi.init(params, null);
/*     */     }
/* 258 */     return new DOMTransform(spi);
/*     */   }
/*     */   
/*     */   public CanonicalizationMethod newCanonicalizationMethod(String algorithm, C14NMethodParameterSpec params) throws NoSuchAlgorithmException, InvalidAlgorithmParameterException
/*     */   {
/*     */     TransformService spi;
/*     */     try
/*     */     {
/* 266 */       spi = TransformService.getInstance(algorithm, "DOM");
/*     */     } catch (NoSuchAlgorithmException nsae) { TransformService spi;
/* 268 */       spi = TransformService.getInstance(algorithm, "DOM", getProvider());
/*     */     }
/* 270 */     spi.init(params);
/* 271 */     return new DOMCanonicalizationMethod(spi);
/*     */   }
/*     */   
/*     */   public CanonicalizationMethod newCanonicalizationMethod(String algorithm, XMLStructure params) throws NoSuchAlgorithmException, InvalidAlgorithmParameterException
/*     */   {
/*     */     TransformService spi;
/*     */     try
/*     */     {
/* 279 */       spi = TransformService.getInstance(algorithm, "DOM");
/*     */     } catch (NoSuchAlgorithmException nsae) { TransformService spi;
/* 281 */       spi = TransformService.getInstance(algorithm, "DOM", getProvider());
/*     */     }
/* 283 */     if (params == null) {
/* 284 */       spi.init(null);
/*     */     } else {
/* 286 */       spi.init(params, null);
/*     */     }
/* 288 */     return new DOMCanonicalizationMethod(spi);
/*     */   }
/*     */   
/*     */   public URIDereferencer getURIDereferencer() {
/* 292 */     return DOMURIDereferencer.INSTANCE;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\org\jcp\xml\dsig\internal\dom\DOMXMLSignatureFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */