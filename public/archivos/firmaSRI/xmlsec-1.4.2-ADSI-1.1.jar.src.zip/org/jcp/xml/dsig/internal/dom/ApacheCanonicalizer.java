/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import adsi.org.apache.xml.security.Init;
/*     */ import adsi.org.apache.xml.security.c14n.Canonicalizer;
/*     */ import adsi.org.apache.xml.security.c14n.InvalidCanonicalizerException;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import adsi.org.apache.xml.security.transforms.Transform;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.spec.AlgorithmParameterSpec;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.xml.crypto.Data;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.NodeSetData;
/*     */ import javax.xml.crypto.OctetStreamData;
/*     */ import javax.xml.crypto.XMLCryptoContext;
/*     */ import javax.xml.crypto.XMLStructure;
/*     */ import javax.xml.crypto.dom.DOMCryptoContext;
/*     */ import javax.xml.crypto.dom.DOMStructure;
/*     */ import javax.xml.crypto.dsig.TransformException;
/*     */ import javax.xml.crypto.dsig.TransformService;
/*     */ import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ApacheCanonicalizer
/*     */   extends TransformService
/*     */ {
/*  56 */   private static Logger log = Logger.getLogger("org.jcp.xml.dsig.internal.dom");
/*     */   
/*     */   protected Canonicalizer apacheCanonicalizer;
/*     */   
/*     */   private Transform apacheTransform;
/*     */   protected String inclusiveNamespaces;
/*     */   
/*     */   static {}
/*     */   
/*  65 */   public final AlgorithmParameterSpec getParameterSpec() { return this.params; }
/*     */   
/*     */   protected C14NMethodParameterSpec params;
/*     */   protected Document ownerDoc;
/*     */   protected Element transformElem;
/*  70 */   public void init(XMLStructure parent, XMLCryptoContext context) throws InvalidAlgorithmParameterException { if ((context != null) && (!(context instanceof DOMCryptoContext))) {
/*  71 */       throw new ClassCastException(
/*  72 */         "context must be of type DOMCryptoContext");
/*     */     }
/*  74 */     this.transformElem = ((Element)
/*  75 */       ((DOMStructure)parent).getNode());
/*  76 */     this.ownerDoc = DOMUtils.getOwnerDocument(this.transformElem);
/*     */   }
/*     */   
/*     */   public void marshalParams(XMLStructure parent, XMLCryptoContext context) throws MarshalException
/*     */   {
/*  81 */     if ((context != null) && (!(context instanceof DOMCryptoContext))) {
/*  82 */       throw new ClassCastException(
/*  83 */         "context must be of type DOMCryptoContext");
/*     */     }
/*  85 */     this.transformElem = ((Element)
/*  86 */       ((DOMStructure)parent).getNode());
/*  87 */     this.ownerDoc = DOMUtils.getOwnerDocument(this.transformElem);
/*     */   }
/*     */   
/*     */   public Data canonicalize(Data data, XMLCryptoContext xc) throws TransformException
/*     */   {
/*  92 */     return canonicalize(data, xc, null);
/*     */   }
/*     */   
/*     */   public Data canonicalize(Data data, XMLCryptoContext xc, OutputStream os)
/*     */     throws TransformException
/*     */   {
/*  98 */     if (this.apacheCanonicalizer == null) {
/*     */       try {
/* 100 */         this.apacheCanonicalizer = Canonicalizer.getInstance(getAlgorithm());
/* 101 */         if (log.isLoggable(Level.FINE)) {
/* 102 */           log.log(Level.FINE, "Created canonicalizer for algorithm: " + 
/* 103 */             getAlgorithm());
/*     */         }
/*     */       } catch (InvalidCanonicalizerException ice) {
/* 106 */         throw new TransformException(
/* 107 */           "Couldn't find Canonicalizer for: " + getAlgorithm() + 
/* 108 */           ": " + ice.getMessage(), ice);
/*     */       }
/*     */     }
/*     */     
/* 112 */     if (os != null) {
/* 113 */       this.apacheCanonicalizer.setWriter(os);
/*     */     } else {
/* 115 */       this.apacheCanonicalizer.setWriter(new ByteArrayOutputStream());
/*     */     }
/*     */     try
/*     */     {
/* 119 */       Set nodeSet = null;
/* 120 */       if ((data instanceof ApacheData)) {
/* 121 */         XMLSignatureInput in = 
/* 122 */           ((ApacheData)data).getXMLSignatureInput();
/* 123 */         if (in.isElement()) {
/* 124 */           if (this.inclusiveNamespaces != null) {
/* 125 */             return new OctetStreamData(new ByteArrayInputStream(
/* 126 */               this.apacheCanonicalizer.canonicalizeSubtree(
/* 127 */               in.getSubNode(), this.inclusiveNamespaces)));
/*     */           }
/* 129 */           return new OctetStreamData(new ByteArrayInputStream(
/* 130 */             this.apacheCanonicalizer.canonicalizeSubtree(
/* 131 */             in.getSubNode())));
/*     */         }
/* 133 */         if (in.isNodeSet()) {
/* 134 */           nodeSet = in.getNodeSet();
/*     */         } else
/* 136 */           return new OctetStreamData(new ByteArrayInputStream(
/* 137 */             this.apacheCanonicalizer.canonicalize(
/* 138 */             Utils.readBytesFromStream(in.getOctetStream()))));
/*     */       } else {
/* 140 */         if ((data instanceof DOMSubTreeData)) {
/* 141 */           DOMSubTreeData subTree = (DOMSubTreeData)data;
/* 142 */           if (this.inclusiveNamespaces != null) {
/* 143 */             return new OctetStreamData(new ByteArrayInputStream(
/* 144 */               this.apacheCanonicalizer.canonicalizeSubtree(
/* 145 */               subTree.getRoot(), this.inclusiveNamespaces)));
/*     */           }
/* 147 */           return new OctetStreamData(new ByteArrayInputStream(
/* 148 */             this.apacheCanonicalizer.canonicalizeSubtree(
/* 149 */             subTree.getRoot())));
/*     */         }
/* 151 */         if ((data instanceof NodeSetData)) {
/* 152 */           NodeSetData nsd = (NodeSetData)data;
/*     */           
/* 154 */           nodeSet = Utils.toNodeSet(nsd.iterator());
/* 155 */           if (log.isLoggable(Level.FINE)) {
/* 156 */             log.log(Level.FINE, "Canonicalizing " + nodeSet.size() + 
/* 157 */               " nodes");
/*     */           }
/*     */         } else {
/* 160 */           return new OctetStreamData(new ByteArrayInputStream(
/* 161 */             this.apacheCanonicalizer.canonicalize(
/* 162 */             Utils.readBytesFromStream(
/* 163 */             ((OctetStreamData)data).getOctetStream()))));
/*     */         } }
/* 165 */       if (this.inclusiveNamespaces != null) {
/* 166 */         return new OctetStreamData(new ByteArrayInputStream(
/* 167 */           this.apacheCanonicalizer.canonicalizeXPathNodeSet(
/* 168 */           nodeSet, this.inclusiveNamespaces)));
/*     */       }
/* 170 */       return new OctetStreamData(new ByteArrayInputStream(
/* 171 */         this.apacheCanonicalizer.canonicalizeXPathNodeSet(nodeSet)));
/*     */     }
/*     */     catch (Exception e) {
/* 174 */       throw new TransformException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public Data transform(Data data, XMLCryptoContext xc, OutputStream os) throws TransformException
/*     */   {
/* 180 */     if (data == null) {
/* 181 */       throw new NullPointerException("data must not be null");
/*     */     }
/* 183 */     if (os == null) {
/* 184 */       throw new NullPointerException("output stream must not be null");
/*     */     }
/*     */     
/* 187 */     if (this.ownerDoc == null) {
/* 188 */       throw new TransformException("transform must be marshalled");
/*     */     }
/*     */     
/* 191 */     if (this.apacheTransform == null) {
/*     */       try {
/* 193 */         this.apacheTransform = Transform.getInstance(
/* 194 */           this.ownerDoc, getAlgorithm(), this.transformElem.getChildNodes());
/* 195 */         this.apacheTransform.setElement(this.transformElem, xc.getBaseURI());
/* 196 */         if (log.isLoggable(Level.FINE)) {
/* 197 */           log.log(Level.FINE, "Created transform for algorithm: " + 
/* 198 */             getAlgorithm());
/*     */         }
/*     */       } catch (Exception ex) {
/* 201 */         throw new TransformException(
/* 202 */           "Couldn't find Transform for: " + getAlgorithm(), ex);
/*     */       }
/*     */     }
/*     */     
/*     */     XMLSignatureInput in;
/* 207 */     if ((data instanceof ApacheData)) {
/* 208 */       if (log.isLoggable(Level.FINE)) {
/* 209 */         log.log(Level.FINE, "ApacheData = true");
/*     */       }
/* 211 */       in = ((ApacheData)data).getXMLSignatureInput(); } else { XMLSignatureInput in;
/* 212 */       if ((data instanceof NodeSetData)) {
/* 213 */         if (log.isLoggable(Level.FINE)) {
/* 214 */           log.log(Level.FINE, "isNodeSet() = true");
/*     */         }
/* 216 */         if ((data instanceof DOMSubTreeData)) {
/* 217 */           DOMSubTreeData subTree = (DOMSubTreeData)data;
/* 218 */           XMLSignatureInput in = new XMLSignatureInput(subTree.getRoot());
/* 219 */           in.setExcludeComments(subTree.excludeComments());
/*     */         } else {
/* 221 */           Set nodeSet = 
/* 222 */             Utils.toNodeSet(((NodeSetData)data).iterator());
/* 223 */           in = new XMLSignatureInput(nodeSet);
/*     */         }
/*     */       } else {
/* 226 */         if (log.isLoggable(Level.FINE)) {
/* 227 */           log.log(Level.FINE, "isNodeSet() = false");
/*     */         }
/*     */         try {
/* 230 */           in = new XMLSignatureInput(
/* 231 */             ((OctetStreamData)data).getOctetStream());
/*     */         } catch (Exception ex) { XMLSignatureInput in;
/* 233 */           throw new TransformException(ex);
/*     */         }
/*     */       }
/*     */     }
/*     */     try {
/* 238 */       XMLSignatureInput in = this.apacheTransform.performTransform(in, os);
/* 239 */       if ((!in.isNodeSet()) && (!in.isElement())) {
/* 240 */         return null;
/*     */       }
/* 242 */       if (in.isOctetStream()) {
/* 243 */         return new ApacheOctetStreamData(in);
/*     */       }
/* 245 */       return new ApacheNodeSetData(in);
/*     */     }
/*     */     catch (Exception ex) {
/* 248 */       throw new TransformException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public final boolean isFeatureSupported(String feature) {
/* 253 */     if (feature == null) {
/* 254 */       throw new NullPointerException();
/*     */     }
/* 256 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\org\jcp\xml\dsig\internal\dom\ApacheCanonicalizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */