/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.security.Provider;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.XMLCryptoContext;
/*     */ import javax.xml.crypto.XMLStructure;
/*     */ import javax.xml.crypto.dom.DOMCryptoContext;
/*     */ import javax.xml.crypto.dsig.XMLObject;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DOMXMLObject
/*     */   extends DOMStructure
/*     */   implements XMLObject
/*     */ {
/*     */   private final String id;
/*     */   private final String mimeType;
/*     */   private final String encoding;
/*     */   private final List content;
/*     */   
/*     */   public DOMXMLObject(List content, String id, String mimeType, String encoding)
/*     */   {
/*  63 */     if ((content == null) || (content.isEmpty())) {
/*  64 */       this.content = Collections.EMPTY_LIST;
/*     */     } else {
/*  66 */       List contentCopy = new ArrayList(content);
/*  67 */       int i = 0; for (int size = contentCopy.size(); i < size; i++) {
/*  68 */         if (!(contentCopy.get(i) instanceof XMLStructure)) {
/*  69 */           throw new ClassCastException(
/*  70 */             "content[" + i + "] is not a valid type");
/*     */         }
/*     */       }
/*  73 */       this.content = Collections.unmodifiableList(contentCopy);
/*     */     }
/*  75 */     this.id = id;
/*  76 */     this.mimeType = mimeType;
/*  77 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMXMLObject(Element objElem, XMLCryptoContext context, Provider provider)
/*     */     throws MarshalException
/*     */   {
/*  89 */     this.encoding = DOMUtils.getAttributeValue(objElem, "Encoding");
/*  90 */     this.id = DOMUtils.getAttributeValue(objElem, "Id");
/*  91 */     this.mimeType = DOMUtils.getAttributeValue(objElem, "MimeType");
/*     */     
/*  93 */     NodeList nodes = objElem.getChildNodes();
/*  94 */     int length = nodes.getLength();
/*  95 */     List content = new ArrayList(length);
/*  96 */     for (int i = 0; i < length; i++) {
/*  97 */       Node child = nodes.item(i);
/*  98 */       if (child.getNodeType() == 1) {
/*  99 */         Element childElem = (Element)child;
/* 100 */         String tag = childElem.getLocalName();
/* 101 */         if (tag.equals("Manifest")) {
/* 102 */           content.add(new DOMManifest(childElem, context, provider));
/* 103 */           continue; }
/* 104 */         if (tag.equals("SignatureProperties")) {
/* 105 */           content.add(new DOMSignatureProperties(childElem));
/* 106 */           continue; }
/* 107 */         if (tag.equals("X509Data")) {
/* 108 */           content.add(new DOMX509Data(childElem));
/* 109 */           continue;
/*     */         }
/*     */       }
/*     */       
/* 113 */       content.add(new javax.xml.crypto.dom.DOMStructure(child));
/*     */     }
/* 115 */     if (content.isEmpty()) {
/* 116 */       this.content = Collections.EMPTY_LIST;
/*     */     } else {
/* 118 */       this.content = Collections.unmodifiableList(content);
/*     */     }
/*     */   }
/*     */   
/*     */   public List getContent() {
/* 123 */     return this.content;
/*     */   }
/*     */   
/*     */   public String getId() {
/* 127 */     return this.id;
/*     */   }
/*     */   
/*     */   public String getMimeType() {
/* 131 */     return this.mimeType;
/*     */   }
/*     */   
/*     */   public String getEncoding() {
/* 135 */     return this.encoding;
/*     */   }
/*     */   
/*     */   public void marshal(Node parent, String dsPrefix, DOMCryptoContext context) throws MarshalException
/*     */   {
/* 140 */     Document ownerDoc = DOMUtils.getOwnerDocument(parent);
/*     */     
/* 142 */     Element objElem = DOMUtils.createElement(
/* 143 */       ownerDoc, "Object", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */     
/*     */ 
/* 146 */     DOMUtils.setAttributeID(objElem, "Id", this.id);
/* 147 */     DOMUtils.setAttribute(objElem, "MimeType", this.mimeType);
/* 148 */     DOMUtils.setAttribute(objElem, "Encoding", this.encoding);
/*     */     
/*     */ 
/* 151 */     int i = 0; for (int size = this.content.size(); i < size; i++) {
/* 152 */       XMLStructure object = (XMLStructure)this.content.get(i);
/* 153 */       if ((object instanceof DOMStructure)) {
/* 154 */         ((DOMStructure)object).marshal(objElem, dsPrefix, context);
/*     */       } else {
/* 156 */         javax.xml.crypto.dom.DOMStructure domObject = 
/* 157 */           (javax.xml.crypto.dom.DOMStructure)object;
/* 158 */         DOMUtils.appendChild(objElem, domObject.getNode());
/*     */       }
/*     */     }
/*     */     
/* 162 */     parent.appendChild(objElem);
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 166 */     if (this == o) {
/* 167 */       return true;
/*     */     }
/*     */     
/* 170 */     if (!(o instanceof XMLObject)) {
/* 171 */       return false;
/*     */     }
/* 173 */     XMLObject oxo = (XMLObject)o;
/*     */     
/* 175 */     boolean idsEqual = this.id == null ? false : oxo.getId() == null ? true : 
/* 176 */       this.id.equals(oxo.getId());
/* 177 */     boolean encodingsEqual = this.encoding == null ? false : oxo.getEncoding() == null ? true : 
/* 178 */       this.encoding.equals(oxo.getEncoding());
/* 179 */     boolean mimeTypesEqual = this.mimeType == null ? false : oxo.getMimeType() == null ? true : 
/* 180 */       this.mimeType.equals(oxo.getMimeType());
/*     */     
/*     */ 
/* 183 */     return (idsEqual) && (encodingsEqual) && (mimeTypesEqual) && (equalsContent(oxo.getContent()));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 187 */     if (!$assertionsDisabled) throw new AssertionError("hashCode not designed");
/* 188 */     return 53;
/*     */   }
/*     */   
/*     */   private boolean equalsContent(List otherContent) {
/* 192 */     if (this.content.size() != otherContent.size()) {
/* 193 */       return false;
/*     */     }
/* 195 */     int i = 0; for (int osize = otherContent.size(); i < osize; i++) {
/* 196 */       XMLStructure oxs = (XMLStructure)otherContent.get(i);
/* 197 */       XMLStructure xs = (XMLStructure)this.content.get(i);
/* 198 */       if ((oxs instanceof javax.xml.crypto.dom.DOMStructure)) {
/* 199 */         if (!(xs instanceof javax.xml.crypto.dom.DOMStructure)) {
/* 200 */           return false;
/*     */         }
/* 202 */         Node onode = 
/* 203 */           ((javax.xml.crypto.dom.DOMStructure)oxs).getNode();
/* 204 */         Node node = 
/* 205 */           ((javax.xml.crypto.dom.DOMStructure)xs).getNode();
/* 206 */         if (!DOMUtils.nodesEqual(node, onode)) {
/* 207 */           return false;
/*     */         }
/*     */       }
/* 210 */       else if (!xs.equals(oxs)) {
/* 211 */         return false;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 216 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\org\jcp\xml\dsig\internal\dom\DOMXMLObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */