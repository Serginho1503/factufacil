/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.Provider;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class XMLDSigRI
/*     */   extends Provider
/*     */ {
/*     */   static final long serialVersionUID = -5049765099299494554L;
/*     */   private static final String INFO = "XMLDSig (DOM XMLSignatureFactory; DOM KeyInfoFactory)";
/*     */   
/*     */   public XMLDSigRI()
/*     */   {
/*  56 */     super("XMLDSig", 1.0D, "XMLDSig (DOM XMLSignatureFactory; DOM KeyInfoFactory)");
/*     */     
/*  58 */     final Map map = new HashMap();
/*  59 */     map.put("XMLSignatureFactory.DOM", 
/*  60 */       "org.jcp.xml.dsig.internal.dom.DOMXMLSignatureFactory");
/*  61 */     map.put("KeyInfoFactory.DOM", 
/*  62 */       "org.jcp.xml.dsig.internal.dom.DOMKeyInfoFactory");
/*     */     
/*     */ 
/*     */ 
/*  66 */     map.put("TransformService.http://www.w3.org/TR/2001/REC-xml-c14n-20010315", 
/*  67 */       "org.jcp.xml.dsig.internal.dom.DOMCanonicalXMLC14NMethod");
/*  68 */     map.put("Alg.Alias.TransformService.INCLUSIVE", 
/*  69 */       "http://www.w3.org/TR/2001/REC-xml-c14n-20010315");
/*  70 */     map.put("TransformService.http://www.w3.org/TR/2001/REC-xml-c14n-20010315 MechanismType", 
/*  71 */       "DOM");
/*     */     
/*     */ 
/*  74 */     map.put("TransformService.http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments", 
/*     */     
/*  76 */       "org.jcp.xml.dsig.internal.dom.DOMCanonicalXMLC14NMethod");
/*  77 */     map.put("Alg.Alias.TransformService.INCLUSIVE_WITH_COMMENTS", 
/*  78 */       "http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments");
/*  79 */     map.put("TransformService.http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments MechanismType", 
/*     */     
/*  81 */       "DOM");
/*     */     
/*     */ 
/*  84 */     map.put("TransformService.http://www.w3.org/2006/12/xml-c14n11", 
/*     */     
/*  86 */       "org.jcp.xml.dsig.internal.dom.DOMCanonicalXMLC14N11Method");
/*  87 */     map.put("TransformService.http://www.w3.org/2006/12/xml-c14n11 MechanismType", 
/*     */     
/*  89 */       "DOM");
/*     */     
/*     */ 
/*  92 */     map.put("TransformService.http://www.w3.org/2006/12/xml-c14n11#WithComments", 
/*     */     
/*  94 */       "org.jcp.xml.dsig.internal.dom.DOMCanonicalXMLC14N11Method");
/*  95 */     map.put("TransformService.http://www.w3.org/2006/12/xml-c14n11#WithComments MechanismType", 
/*     */     
/*  97 */       "DOM");
/*     */     
/*     */ 
/* 100 */     map.put("TransformService.http://www.w3.org/2001/10/xml-exc-c14n#", 
/* 101 */       "org.jcp.xml.dsig.internal.dom.DOMExcC14NMethod");
/* 102 */     map.put("Alg.Alias.TransformService.EXCLUSIVE", 
/* 103 */       "http://www.w3.org/2001/10/xml-exc-c14n#");
/* 104 */     map.put("TransformService.http://www.w3.org/2001/10/xml-exc-c14n# MechanismType", 
/* 105 */       "DOM");
/*     */     
/*     */ 
/* 108 */     map.put("TransformService.http://www.w3.org/2001/10/xml-exc-c14n#WithComments", 
/*     */     
/* 110 */       "org.jcp.xml.dsig.internal.dom.DOMExcC14NMethod");
/* 111 */     map.put("Alg.Alias.TransformService.EXCLUSIVE_WITH_COMMENTS", 
/* 112 */       "http://www.w3.org/2001/10/xml-exc-c14n#WithComments");
/* 113 */     map.put("TransformService.http://www.w3.org/2001/10/xml-exc-c14n#WithComments MechanismType", 
/*     */     
/* 115 */       "DOM");
/*     */     
/*     */ 
/* 118 */     map.put("TransformService.http://www.w3.org/2000/09/xmldsig#base64", 
/* 119 */       "org.jcp.xml.dsig.internal.dom.DOMBase64Transform");
/* 120 */     map.put("Alg.Alias.TransformService.BASE64", "http://www.w3.org/2000/09/xmldsig#base64");
/* 121 */     map.put("TransformService.http://www.w3.org/2000/09/xmldsig#base64 MechanismType", 
/* 122 */       "DOM");
/*     */     
/*     */ 
/* 125 */     map.put("TransformService.http://www.w3.org/2000/09/xmldsig#enveloped-signature", 
/* 126 */       "org.jcp.xml.dsig.internal.dom.DOMEnvelopedTransform");
/* 127 */     map.put("Alg.Alias.TransformService.ENVELOPED", "http://www.w3.org/2000/09/xmldsig#enveloped-signature");
/* 128 */     map.put("TransformService.http://www.w3.org/2000/09/xmldsig#enveloped-signature MechanismType", 
/* 129 */       "DOM");
/*     */     
/*     */ 
/* 132 */     map.put("TransformService.http://www.w3.org/2002/06/xmldsig-filter2", 
/* 133 */       "org.jcp.xml.dsig.internal.dom.DOMXPathFilter2Transform");
/* 134 */     map.put("Alg.Alias.TransformService.XPATH2", "http://www.w3.org/2002/06/xmldsig-filter2");
/* 135 */     map.put("TransformService.http://www.w3.org/2002/06/xmldsig-filter2 MechanismType", 
/* 136 */       "DOM");
/*     */     
/*     */ 
/* 139 */     map.put("TransformService.http://www.w3.org/TR/1999/REC-xpath-19991116", 
/* 140 */       "org.jcp.xml.dsig.internal.dom.DOMXPathTransform");
/* 141 */     map.put("Alg.Alias.TransformService.XPATH", "http://www.w3.org/TR/1999/REC-xpath-19991116");
/* 142 */     map.put("TransformService.http://www.w3.org/TR/1999/REC-xpath-19991116 MechanismType", 
/* 143 */       "DOM");
/*     */     
/*     */ 
/* 146 */     map.put("TransformService.http://www.w3.org/TR/1999/REC-xslt-19991116", 
/* 147 */       "org.jcp.xml.dsig.internal.dom.DOMXSLTTransform");
/* 148 */     map.put("Alg.Alias.TransformService.XSLT", "http://www.w3.org/TR/1999/REC-xslt-19991116");
/* 149 */     map.put("TransformService.http://www.w3.org/TR/1999/REC-xslt-19991116 MechanismType", 
/* 150 */       "DOM");
/*     */     
/* 152 */     AccessController.doPrivileged(new PrivilegedAction() {
/*     */       public Object run() {
/* 154 */         XMLDSigRI.this.putAll(map);
/* 155 */         return null;
/*     */       }
/*     */     });
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\org\jcp\xml\dsig\internal\dom\XMLDSigRI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */