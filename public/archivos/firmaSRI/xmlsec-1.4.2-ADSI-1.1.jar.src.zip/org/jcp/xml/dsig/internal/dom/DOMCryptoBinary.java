/*    */ package org.jcp.xml.dsig.internal.dom;
/*    */ 
/*    */ import adsi.org.apache.xml.security.utils.Base64;
/*    */ import java.math.BigInteger;
/*    */ import javax.xml.crypto.MarshalException;
/*    */ import javax.xml.crypto.dom.DOMCryptoContext;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Node;
/*    */ import org.w3c.dom.Text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DOMCryptoBinary
/*    */   extends DOMStructure
/*    */ {
/*    */   private final BigInteger bigNum;
/*    */   private final String value;
/*    */   
/*    */   public DOMCryptoBinary(BigInteger bigNum)
/*    */   {
/* 61 */     if (bigNum == null) {
/* 62 */       throw new NullPointerException("bigNum is null");
/*    */     }
/* 64 */     this.bigNum = bigNum;
/*    */     
/* 66 */     this.value = Base64.encode(bigNum);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public DOMCryptoBinary(Node cbNode)
/*    */     throws MarshalException
/*    */   {
/* 76 */     this.value = cbNode.getNodeValue();
/*    */     try {
/* 78 */       this.bigNum = Base64.decodeBigIntegerFromText((Text)cbNode);
/*    */     } catch (Exception ex) {
/* 80 */       throw new MarshalException(ex);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public BigInteger getBigNum()
/*    */   {
/* 90 */     return this.bigNum;
/*    */   }
/*    */   
/*    */   public void marshal(Node parent, String prefix, DOMCryptoContext context) throws MarshalException
/*    */   {
/* 95 */     parent.appendChild(
/* 96 */       DOMUtils.getOwnerDocument(parent).createTextNode(this.value));
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\org\jcp\xml\dsig\internal\dom\DOMCryptoBinary.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */