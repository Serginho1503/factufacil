/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import adsi.org.apache.xml.security.utils.IdResolver;
/*     */ import java.security.spec.AlgorithmParameterSpec;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ import javax.xml.crypto.XMLCryptoContext;
/*     */ import javax.xml.crypto.XMLStructure;
/*     */ import javax.xml.crypto.dom.DOMStructure;
/*     */ import javax.xml.crypto.dsig.spec.ExcC14NParameterSpec;
/*     */ import javax.xml.crypto.dsig.spec.XPathFilter2ParameterSpec;
/*     */ import javax.xml.crypto.dsig.spec.XPathFilterParameterSpec;
/*     */ import javax.xml.crypto.dsig.spec.XPathType;
/*     */ import javax.xml.crypto.dsig.spec.XSLTTransformParameterSpec;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMUtils
/*     */ {
/*     */   public static Document getOwnerDocument(Node node)
/*     */   {
/*  56 */     if (node.getNodeType() == 9) {
/*  57 */       return (Document)node;
/*     */     }
/*  59 */     return node.getOwnerDocument();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Element createElement(Document doc, String tag, String nsURI, String prefix)
/*     */   {
/*  75 */     String qName = 
/*  76 */       prefix + ":" + tag;
/*  77 */     return doc.createElementNS(nsURI, qName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setAttribute(Element elem, String name, String value)
/*     */   {
/*  89 */     if (value == null) return;
/*  90 */     elem.setAttributeNS(null, name, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setAttributeID(Element elem, String name, String value)
/*     */   {
/* 104 */     if (value == null) return;
/* 105 */     elem.setAttributeNS(null, name, value);
/* 106 */     IdResolver.registerElementById(elem, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Element getFirstChildElement(Node node)
/*     */   {
/* 119 */     Node child = node.getFirstChild();
/* 120 */     while ((child != null) && (child.getNodeType() != 1)) {
/* 121 */       child = child.getNextSibling();
/*     */     }
/* 123 */     return (Element)child;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Element getLastChildElement(Node node)
/*     */   {
/* 136 */     Node child = node.getLastChild();
/* 137 */     while ((child != null) && (child.getNodeType() != 1)) {
/* 138 */       child = child.getPreviousSibling();
/*     */     }
/* 140 */     return (Element)child;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Element getNextSiblingElement(Node node)
/*     */   {
/* 153 */     Node sibling = node.getNextSibling();
/* 154 */     while ((sibling != null) && (sibling.getNodeType() != 1)) {
/* 155 */       sibling = sibling.getNextSibling();
/*     */     }
/* 157 */     return (Element)sibling;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getAttributeValue(Element elem, String name)
/*     */   {
/* 175 */     Attr attr = elem.getAttributeNodeNS(null, name);
/* 176 */     return attr == null ? null : attr.getValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Set nodeSet(NodeList nl)
/*     */   {
/* 187 */     return new NodeSet(nl);
/*     */   }
/*     */   
/*     */   static class NodeSet extends AbstractSet {
/*     */     private NodeList nl;
/*     */     
/* 193 */     public NodeSet(NodeList nl) { this.nl = nl; }
/*     */     
/*     */ 
/* 196 */     public int size() { return this.nl.getLength(); }
/*     */     
/* 198 */     public Iterator iterator() { new Iterator() {
/* 199 */         int index = 0;
/*     */         
/*     */ 
/* 202 */         public void remove() { throw new UnsupportedOperationException(); }
/*     */         
/*     */         public Object next() {
/* 205 */           if (!hasNext()) {
/* 206 */             throw new NoSuchElementException();
/*     */           }
/* 208 */           return DOMUtils.NodeSet.this.nl.item(this.index++);
/*     */         }
/*     */         
/* 211 */         public boolean hasNext() { return this.index < DOMUtils.NodeSet.this.nl.getLength(); }
/*     */       }; }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getNSPrefix(XMLCryptoContext context, String nsURI)
/*     */   {
/* 226 */     if (context != null) {
/* 227 */       return context.getNamespacePrefix(
/* 228 */         nsURI, context.getDefaultNamespacePrefix());
/*     */     }
/* 230 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getSignaturePrefix(XMLCryptoContext context)
/*     */   {
/* 242 */     return getNSPrefix(context, "http://www.w3.org/2000/09/xmldsig#");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void removeAllChildren(Node node)
/*     */   {
/* 251 */     NodeList children = node.getChildNodes();
/* 252 */     int i = 0; for (int length = children.getLength(); i < length; i++) {
/* 253 */       node.removeChild(children.item(i));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean nodesEqual(Node thisNode, Node otherNode)
/*     */   {
/* 261 */     if (thisNode == otherNode) {
/* 262 */       return true;
/*     */     }
/* 264 */     if (thisNode.getNodeType() != otherNode.getNodeType()) {
/* 265 */       return false;
/*     */     }
/*     */     
/* 268 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void appendChild(Node parent, Node child)
/*     */   {
/* 277 */     Document ownerDoc = getOwnerDocument(parent);
/* 278 */     if (child.getOwnerDocument() != ownerDoc) {
/* 279 */       parent.appendChild(ownerDoc.importNode(child, true));
/*     */     } else {
/* 281 */       parent.appendChild(child);
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean paramsEqual(AlgorithmParameterSpec spec1, AlgorithmParameterSpec spec2)
/*     */   {
/* 287 */     if (spec1 == spec2) {
/* 288 */       return true;
/*     */     }
/* 290 */     if (((spec1 instanceof XPathFilter2ParameterSpec)) && 
/* 291 */       ((spec2 instanceof XPathFilter2ParameterSpec))) {
/* 292 */       return paramsEqual((XPathFilter2ParameterSpec)spec1, 
/* 293 */         (XPathFilter2ParameterSpec)spec2);
/*     */     }
/* 295 */     if (((spec1 instanceof ExcC14NParameterSpec)) && 
/* 296 */       ((spec2 instanceof ExcC14NParameterSpec))) {
/* 297 */       return paramsEqual((ExcC14NParameterSpec)spec1, 
/* 298 */         (ExcC14NParameterSpec)spec2);
/*     */     }
/* 300 */     if (((spec1 instanceof XPathFilterParameterSpec)) && 
/* 301 */       ((spec2 instanceof XPathFilterParameterSpec))) {
/* 302 */       return paramsEqual((XPathFilterParameterSpec)spec1, 
/* 303 */         (XPathFilterParameterSpec)spec2);
/*     */     }
/* 305 */     if (((spec1 instanceof XSLTTransformParameterSpec)) && 
/* 306 */       ((spec2 instanceof XSLTTransformParameterSpec))) {
/* 307 */       return paramsEqual((XSLTTransformParameterSpec)spec1, 
/* 308 */         (XSLTTransformParameterSpec)spec2);
/*     */     }
/* 310 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   private static boolean paramsEqual(XPathFilter2ParameterSpec spec1, XPathFilter2ParameterSpec spec2)
/*     */   {
/* 316 */     List types = spec1.getXPathList();
/* 317 */     List otypes = spec2.getXPathList();
/* 318 */     int size = types.size();
/* 319 */     if (size != otypes.size()) {
/* 320 */       return false;
/*     */     }
/* 322 */     for (int i = 0; i < size; i++) {
/* 323 */       XPathType type = (XPathType)types.get(i);
/* 324 */       XPathType otype = (XPathType)otypes.get(i);
/* 325 */       if ((!type.getExpression().equals(otype.getExpression())) || 
/* 326 */         (!type.getNamespaceMap().equals(otype.getNamespaceMap())) || 
/* 327 */         (type.getFilter() != otype.getFilter())) {
/* 328 */         return false;
/*     */       }
/*     */     }
/* 331 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean paramsEqual(ExcC14NParameterSpec spec1, ExcC14NParameterSpec spec2)
/*     */   {
/* 336 */     return spec1.getPrefixList().equals(spec2.getPrefixList());
/*     */   }
/*     */   
/*     */ 
/*     */   private static boolean paramsEqual(XPathFilterParameterSpec spec1, XPathFilterParameterSpec spec2)
/*     */   {
/* 342 */     return (spec1.getXPath().equals(spec2.getXPath())) && (spec1.getNamespaceMap().equals(spec2.getNamespaceMap()));
/*     */   }
/*     */   
/*     */ 
/*     */   private static boolean paramsEqual(XSLTTransformParameterSpec spec1, XSLTTransformParameterSpec spec2)
/*     */   {
/* 348 */     XMLStructure ostylesheet = spec2.getStylesheet();
/* 349 */     if (!(ostylesheet instanceof DOMStructure)) {
/* 350 */       return false;
/*     */     }
/* 352 */     Node ostylesheetElem = 
/* 353 */       ((DOMStructure)ostylesheet).getNode();
/* 354 */     XMLStructure stylesheet = spec1.getStylesheet();
/* 355 */     Node stylesheetElem = 
/* 356 */       ((DOMStructure)stylesheet).getNode();
/* 357 */     return nodesEqual(stylesheetElem, ostylesheetElem);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\org\jcp\xml\dsig\internal\dom\DOMUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */