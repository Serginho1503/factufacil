/*     */ package org.jcp.xml.dsig.internal.dom;
/*     */ 
/*     */ import java.security.Provider;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.xml.crypto.MarshalException;
/*     */ import javax.xml.crypto.XMLCryptoContext;
/*     */ import javax.xml.crypto.dom.DOMCryptoContext;
/*     */ import javax.xml.crypto.dsig.Manifest;
/*     */ import javax.xml.crypto.dsig.Reference;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DOMManifest
/*     */   extends DOMStructure
/*     */   implements Manifest
/*     */ {
/*     */   private final List references;
/*     */   private final String id;
/*     */   
/*     */   public DOMManifest(List references, String id)
/*     */   {
/*  59 */     if (references == null) {
/*  60 */       throw new NullPointerException("references cannot be null");
/*     */     }
/*  62 */     List refCopy = new ArrayList(references);
/*  63 */     if (refCopy.isEmpty()) {
/*  64 */       throw new IllegalArgumentException("list of references must contain at least one entry");
/*     */     }
/*     */     
/*  67 */     int i = 0; for (int size = refCopy.size(); i < size; i++) {
/*  68 */       if (!(refCopy.get(i) instanceof Reference)) {
/*  69 */         throw new ClassCastException(
/*  70 */           "references[" + i + "] is not a valid type");
/*     */       }
/*     */     }
/*  73 */     this.references = Collections.unmodifiableList(refCopy);
/*  74 */     this.id = id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMManifest(Element manElem, XMLCryptoContext context, Provider provider)
/*     */     throws MarshalException
/*     */   {
/*  84 */     this.id = DOMUtils.getAttributeValue(manElem, "Id");
/*  85 */     Element refElem = DOMUtils.getFirstChildElement(manElem);
/*  86 */     List refs = new ArrayList();
/*  87 */     while (refElem != null) {
/*  88 */       refs.add(new DOMReference(refElem, context, provider));
/*  89 */       refElem = DOMUtils.getNextSiblingElement(refElem);
/*     */     }
/*  91 */     this.references = Collections.unmodifiableList(refs);
/*     */   }
/*     */   
/*     */   public String getId() {
/*  95 */     return this.id;
/*     */   }
/*     */   
/*     */   public List getReferences() {
/*  99 */     return this.references;
/*     */   }
/*     */   
/*     */   public void marshal(Node parent, String dsPrefix, DOMCryptoContext context) throws MarshalException
/*     */   {
/* 104 */     Document ownerDoc = DOMUtils.getOwnerDocument(parent);
/*     */     
/* 106 */     Element manElem = DOMUtils.createElement(
/* 107 */       ownerDoc, "Manifest", "http://www.w3.org/2000/09/xmldsig#", dsPrefix);
/*     */     
/* 109 */     DOMUtils.setAttributeID(manElem, "Id", this.id);
/*     */     
/*     */ 
/* 112 */     int i = 0; for (int size = this.references.size(); i < size; i++) {
/* 113 */       DOMReference ref = (DOMReference)this.references.get(i);
/* 114 */       ref.marshal(manElem, dsPrefix, context);
/*     */     }
/* 116 */     parent.appendChild(manElem);
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 120 */     if (this == o) {
/* 121 */       return true;
/*     */     }
/*     */     
/* 124 */     if (!(o instanceof Manifest)) {
/* 125 */       return false;
/*     */     }
/* 127 */     Manifest oman = (Manifest)o;
/*     */     
/* 129 */     boolean idsEqual = this.id == null ? false : oman.getId() == null ? true : 
/* 130 */       this.id.equals(oman.getId());
/*     */     
/* 132 */     return (idsEqual) && (this.references.equals(oman.getReferences()));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 136 */     if (!$assertionsDisabled) throw new AssertionError("hashCode not designed");
/* 137 */     return 46;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\org\jcp\xml\dsig\internal\dom\DOMManifest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */