/*     */ package adsi.org.apache.xml.security.encryption;
/*     */ 
/*     */ import adsi.org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import adsi.org.apache.xml.security.exceptions.Base64DecodingException;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import adsi.org.apache.xml.security.transforms.TransformationException;
/*     */ import adsi.org.apache.xml.security.utils.Base64;
/*     */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolver;
/*     */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolverException;
/*     */ import java.io.IOException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Attr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLCipherInput
/*     */ {
/*  50 */   private static Log logger = LogFactory.getLog(XMLCipher.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private CipherData _cipherData;
/*     */   
/*     */ 
/*     */ 
/*     */   private int _mode;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLCipherInput(CipherData data)
/*     */     throws XMLEncryptionException
/*     */   {
/*  67 */     this._cipherData = data;
/*  68 */     this._mode = 2;
/*  69 */     if (this._cipherData == null) {
/*  70 */       throw new XMLEncryptionException("CipherData is null");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLCipherInput(EncryptedType input)
/*     */     throws XMLEncryptionException
/*     */   {
/*  85 */     this._cipherData = (input == null ? null : input.getCipherData());
/*  86 */     this._mode = 2;
/*  87 */     if (this._cipherData == null) {
/*  88 */       throw new XMLEncryptionException("CipherData is null");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getBytes()
/*     */     throws XMLEncryptionException
/*     */   {
/* 102 */     if (this._mode == 2) {
/* 103 */       return getDecryptBytes();
/*     */     }
/* 105 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] getDecryptBytes()
/*     */     throws XMLEncryptionException
/*     */   {
/* 115 */     String base64EncodedEncryptedOctets = null;
/*     */     
/* 117 */     if (this._cipherData.getDataType() == 2)
/*     */     {
/* 119 */       logger.debug("Found a reference type CipherData");
/* 120 */       CipherReference cr = this._cipherData.getCipherReference();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 125 */       Attr uriAttr = cr.getURIAsAttr();
/* 126 */       XMLSignatureInput input = null;
/*     */       try
/*     */       {
/* 129 */         ResourceResolver resolver = 
/* 130 */           ResourceResolver.getInstance(uriAttr, null);
/* 131 */         input = resolver.resolve(uriAttr, null);
/*     */       } catch (ResourceResolverException ex) {
/* 133 */         throw new XMLEncryptionException("empty", ex);
/*     */       }
/*     */       
/* 136 */       if (input != null) {
/* 137 */         logger.debug("Managed to resolve URI \"" + cr.getURI() + "\"");
/*     */       } else {
/* 139 */         logger.debug("Failed to resolve URI \"" + cr.getURI() + "\"");
/*     */       }
/*     */       
/*     */ 
/* 143 */       Transforms transforms = cr.getTransforms();
/* 144 */       if (transforms != null) {
/* 145 */         logger.debug("Have transforms in cipher reference");
/*     */         try {
/* 147 */           adsi.org.apache.xml.security.transforms.Transforms dsTransforms = 
/* 148 */             transforms.getDSTransforms();
/* 149 */           input = dsTransforms.performTransforms(input);
/*     */         } catch (TransformationException ex) {
/* 151 */           throw new XMLEncryptionException("empty", ex);
/*     */         }
/*     */       }
/*     */       try
/*     */       {
/* 156 */         return input.getBytes();
/*     */       } catch (IOException ex) {
/* 158 */         throw new XMLEncryptionException("empty", ex);
/*     */       } catch (CanonicalizationException ex) {
/* 160 */         throw new XMLEncryptionException("empty", ex);
/*     */       }
/*     */     }
/*     */     
/* 164 */     if (this._cipherData.getDataType() == 1) {
/* 165 */       base64EncodedEncryptedOctets = 
/* 166 */         this._cipherData.getCipherValue().getValue();
/*     */     } else {
/* 168 */       throw new XMLEncryptionException("CipherData.getDataType() returned unexpected value");
/*     */     }
/*     */     
/* 171 */     logger.debug("Encrypted octets:\n" + base64EncodedEncryptedOctets);
/*     */     
/* 173 */     byte[] encryptedBytes = (byte[])null;
/*     */     try {
/* 175 */       encryptedBytes = Base64.decode(base64EncodedEncryptedOctets);
/*     */     } catch (Base64DecodingException bde) {
/* 177 */       throw new XMLEncryptionException("empty", bde);
/*     */     }
/*     */     
/* 180 */     return encryptedBytes;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\encryption\XMLCipherInput.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */