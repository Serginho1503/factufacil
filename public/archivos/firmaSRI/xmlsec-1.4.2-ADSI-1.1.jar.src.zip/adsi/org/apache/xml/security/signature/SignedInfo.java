/*     */ package adsi.org.apache.xml.security.signature;
/*     */ 
/*     */ import adsi.org.apache.xml.security.algorithms.SignatureAlgorithm;
/*     */ import adsi.org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import adsi.org.apache.xml.security.c14n.Canonicalizer;
/*     */ import adsi.org.apache.xml.security.c14n.InvalidCanonicalizerException;
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.transforms.params.InclusiveNamespaces;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignedInfo
/*     */   extends Manifest
/*     */ {
/*  50 */   private SignatureAlgorithm _signatureAlgorithm = null;
/*     */   
/*     */ 
/*  53 */   private byte[] _c14nizedBytes = null;
/*     */   
/*     */ 
/*     */ 
/*     */   private Element c14nMethod;
/*     */   
/*     */ 
/*     */ 
/*     */   private Element signatureMethod;
/*     */   
/*     */ 
/*     */ 
/*     */   public SignedInfo(Document doc)
/*     */     throws XMLSecurityException
/*     */   {
/*  68 */     this(doc, "http://www.w3.org/2000/09/xmldsig#dsa-sha1", "http://www.w3.org/TR/2001/REC-xml-c14n-20010315");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignedInfo(Document doc, String signatureMethodURI, String canonicalizationMethodURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  85 */     this(doc, signatureMethodURI, 0, canonicalizationMethodURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignedInfo(Document doc, String signatureMethodURI, int hMACOutputLength, String canonicalizationMethodURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 103 */     super(doc);
/*     */     
/* 105 */     this.c14nMethod = XMLUtils.createElementInSignatureSpace(this._doc, 
/* 106 */       "CanonicalizationMethod");
/*     */     
/* 108 */     this.c14nMethod.setAttributeNS(null, "Algorithm", 
/* 109 */       canonicalizationMethodURI);
/* 110 */     this._constructionElement.appendChild(this.c14nMethod);
/* 111 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */     
/* 113 */     if (hMACOutputLength > 0) {
/* 114 */       this._signatureAlgorithm = new SignatureAlgorithm(this._doc, 
/* 115 */         signatureMethodURI, hMACOutputLength);
/*     */     } else {
/* 117 */       this._signatureAlgorithm = new SignatureAlgorithm(this._doc, 
/* 118 */         signatureMethodURI);
/*     */     }
/*     */     
/* 121 */     this.signatureMethod = this._signatureAlgorithm.getElement();
/* 122 */     this._constructionElement.appendChild(this.signatureMethod);
/* 123 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignedInfo(Document doc, Element signatureMethodElem, Element canonicalizationMethodElem)
/*     */     throws XMLSecurityException
/*     */   {
/* 135 */     super(doc);
/*     */     
/* 137 */     this.c14nMethod = canonicalizationMethodElem;
/* 138 */     this._constructionElement.appendChild(this.c14nMethod);
/* 139 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */     
/* 141 */     this._signatureAlgorithm = 
/* 142 */       new SignatureAlgorithm(signatureMethodElem, null);
/*     */     
/* 144 */     this.signatureMethod = this._signatureAlgorithm.getElement();
/* 145 */     this._constructionElement.appendChild(this.signatureMethod);
/*     */     
/* 147 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignedInfo(Element element, String baseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 163 */     super(element, baseURI);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 169 */     this.c14nMethod = XMLUtils.getNextElement(element.getFirstChild());
/* 170 */     String c14nMethodURI = getCanonicalizationMethodURI();
/* 171 */     if ((!c14nMethodURI.equals("http://www.w3.org/TR/2001/REC-xml-c14n-20010315")) && 
/* 172 */       (!c14nMethodURI.equals("http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments")) && 
/* 173 */       (!c14nMethodURI.equals("http://www.w3.org/2001/10/xml-exc-c14n#")) && 
/* 174 */       (!c14nMethodURI.equals("http://www.w3.org/2001/10/xml-exc-c14n#WithComments")))
/*     */     {
/*     */       try
/*     */       {
/* 178 */         Canonicalizer c14nizer = 
/* 179 */           Canonicalizer.getInstance(getCanonicalizationMethodURI());
/*     */         
/* 181 */         this._c14nizedBytes = 
/* 182 */           c14nizer.canonicalizeSubtree(this._constructionElement);
/* 183 */         DocumentBuilderFactory dbf = 
/* 184 */           DocumentBuilderFactory.newInstance();
/* 185 */         dbf.setNamespaceAware(true);
/* 186 */         DocumentBuilder db = dbf.newDocumentBuilder();
/* 187 */         Document newdoc = 
/* 188 */           db.parse(new ByteArrayInputStream(this._c14nizedBytes));
/* 189 */         Node imported = 
/* 190 */           this._doc.importNode(newdoc.getDocumentElement(), true);
/*     */         
/* 192 */         this._constructionElement.getParentNode().replaceChild(imported, 
/* 193 */           this._constructionElement);
/*     */         
/* 195 */         this._constructionElement = ((Element)imported);
/*     */       } catch (ParserConfigurationException ex) {
/* 197 */         throw new XMLSecurityException("empty", ex);
/*     */       } catch (IOException ex) {
/* 199 */         throw new XMLSecurityException("empty", ex);
/*     */       } catch (SAXException ex) {
/* 201 */         throw new XMLSecurityException("empty", ex);
/*     */       }
/*     */     }
/* 204 */     this.signatureMethod = XMLUtils.getNextElement(this.c14nMethod.getNextSibling());
/* 205 */     this._signatureAlgorithm = 
/* 206 */       new SignatureAlgorithm(this.signatureMethod, getBaseURI());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean verify()
/*     */     throws MissingResourceFailureException, XMLSecurityException
/*     */   {
/* 218 */     return super.verifyReferences(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean verify(boolean followManifests)
/*     */     throws MissingResourceFailureException, XMLSecurityException
/*     */   {
/* 231 */     return super.verifyReferences(followManifests);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getCanonicalizedOctetStream()
/*     */     throws CanonicalizationException, InvalidCanonicalizerException, XMLSecurityException
/*     */   {
/* 246 */     if (this._c14nizedBytes == null)
/*     */     {
/* 248 */       Canonicalizer c14nizer = 
/* 249 */         Canonicalizer.getInstance(getCanonicalizationMethodURI());
/*     */       
/* 251 */       this._c14nizedBytes = 
/* 252 */         c14nizer.canonicalizeSubtree(this._constructionElement);
/*     */     }
/*     */     
/*     */ 
/* 256 */     byte[] output = new byte[this._c14nizedBytes.length];
/*     */     
/* 258 */     System.arraycopy(this._c14nizedBytes, 0, output, 0, output.length);
/*     */     
/* 260 */     return output;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void signInOctectStream(OutputStream os)
/*     */     throws CanonicalizationException, InvalidCanonicalizerException, XMLSecurityException
/*     */   {
/* 274 */     if (this._c14nizedBytes == null) {
/* 275 */       Canonicalizer c14nizer = 
/* 276 */         Canonicalizer.getInstance(getCanonicalizationMethodURI());
/* 277 */       c14nizer.setWriter(os);
/* 278 */       String inclusiveNamespaces = getInclusiveNamespaces();
/*     */       
/* 280 */       if (inclusiveNamespaces == null) {
/* 281 */         c14nizer.canonicalizeSubtree(this._constructionElement);
/*     */       } else
/* 283 */         c14nizer.canonicalizeSubtree(this._constructionElement, inclusiveNamespaces);
/*     */     } else {
/*     */       try {
/* 286 */         os.write(this._c14nizedBytes);
/*     */       } catch (IOException e) {
/* 288 */         throw new RuntimeException(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCanonicalizationMethodURI()
/*     */   {
/* 301 */     return this.c14nMethod.getAttributeNS(null, "Algorithm");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSignatureMethodURI()
/*     */   {
/* 311 */     Element signatureElement = getSignatureMethodElement();
/*     */     
/* 313 */     if (signatureElement != null) {
/* 314 */       return signatureElement.getAttributeNS(null, "Algorithm");
/*     */     }
/*     */     
/* 317 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element getSignatureMethodElement()
/*     */   {
/* 326 */     return this.signatureMethod;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SecretKey createSecretKey(byte[] secretKeyBytes)
/*     */   {
/* 339 */     return new SecretKeySpec(secretKeyBytes, 
/* 340 */       this._signatureAlgorithm
/* 341 */       .getJCEAlgorithmString());
/*     */   }
/*     */   
/*     */   protected SignatureAlgorithm getSignatureAlgorithm() {
/* 345 */     return this._signatureAlgorithm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBaseLocalName()
/*     */   {
/* 353 */     return "SignedInfo";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getInclusiveNamespaces()
/*     */   {
/* 360 */     String c14nMethodURI = this.c14nMethod.getAttributeNS(null, "Algorithm");
/* 361 */     if ((!c14nMethodURI.equals("http://www.w3.org/2001/10/xml-exc-c14n#")) && 
/* 362 */       (!c14nMethodURI.equals("http://www.w3.org/2001/10/xml-exc-c14n#WithComments"))) {
/* 363 */       return null;
/*     */     }
/*     */     
/* 366 */     Element inclusiveElement = XMLUtils.getNextElement(
/* 367 */       this.c14nMethod.getFirstChild());
/*     */     
/* 369 */     if (inclusiveElement != null)
/*     */     {
/*     */       try
/*     */       {
/* 373 */         return 
/* 374 */           new InclusiveNamespaces(inclusiveElement, "http://www.w3.org/2001/10/xml-exc-c14n#").getInclusiveNamespaces();
/*     */ 
/*     */       }
/*     */       catch (XMLSecurityException e)
/*     */       {
/* 379 */         return null;
/*     */       }
/*     */     }
/* 382 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\signature\SignedInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */