/*     */ package adsi.org.apache.xml.security.transforms.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.utils.I18n;
/*     */ import org.apache.xml.dtm.DTMManager;
/*     */ import org.apache.xpath.CachedXPathAPI;
/*     */ import org.apache.xpath.XPathContext;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FuncHereContext
/*     */   extends XPathContext
/*     */ {
/*     */   private FuncHereContext() {}
/*     */   
/*     */   public FuncHereContext(Node owner)
/*     */   {
/*  81 */     super(owner);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FuncHereContext(Node owner, XPathContext xpathContext)
/*     */   {
/*  92 */     super(owner);
/*     */     try
/*     */     {
/*  95 */       this.m_dtmManager = xpathContext.getDTMManager();
/*     */     } catch (IllegalAccessError iae) {
/*  97 */       throw new IllegalAccessError(I18n.translate("endorsed.jdk1.4.0") + 
/*  98 */         " Original message was \"" + 
/*  99 */         iae.getMessage() + "\"");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FuncHereContext(Node owner, CachedXPathAPI previouslyUsed)
/*     */   {
/* 111 */     super(owner);
/*     */     try
/*     */     {
/* 114 */       this.m_dtmManager = previouslyUsed.getXPathContext().getDTMManager();
/*     */     } catch (IllegalAccessError iae) {
/* 116 */       throw new IllegalAccessError(I18n.translate("endorsed.jdk1.4.0") + 
/* 117 */         " Original message was \"" + 
/* 118 */         iae.getMessage() + "\"");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FuncHereContext(Node owner, DTMManager dtmManager)
/*     */   {
/* 130 */     super(owner);
/*     */     try
/*     */     {
/* 133 */       this.m_dtmManager = dtmManager;
/*     */     } catch (IllegalAccessError iae) {
/* 135 */       throw new IllegalAccessError(I18n.translate("endorsed.jdk1.4.0") + 
/* 136 */         " Original message was \"" + 
/* 137 */         iae.getMessage() + "\"");
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\transforms\implementations\FuncHereContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */