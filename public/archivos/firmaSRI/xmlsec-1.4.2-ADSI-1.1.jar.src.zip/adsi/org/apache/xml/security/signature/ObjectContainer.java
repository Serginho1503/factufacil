/*     */ package adsi.org.apache.xml.security.signature;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.utils.IdResolver;
/*     */ import adsi.org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjectContainer
/*     */   extends SignatureElementProxy
/*     */ {
/*     */   public ObjectContainer(Document doc)
/*     */   {
/*  45 */     super(doc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectContainer(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  58 */     super(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setId(String Id)
/*     */   {
/*  68 */     if (Id != null) {
/*  69 */       this._constructionElement.setAttributeNS(null, "Id", Id);
/*  70 */       IdResolver.registerElementById(this._constructionElement, Id);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getId()
/*     */   {
/*  80 */     return this._constructionElement.getAttributeNS(null, "Id");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMimeType(String MimeType)
/*     */   {
/*  90 */     if (MimeType != null) {
/*  91 */       this._constructionElement.setAttributeNS(null, "MimeType", 
/*  92 */         MimeType);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMimeType()
/*     */   {
/* 102 */     return this._constructionElement.getAttributeNS(null, "MimeType");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEncoding(String Encoding)
/*     */   {
/* 112 */     if (Encoding != null) {
/* 113 */       this._constructionElement.setAttributeNS(null, "Encoding", 
/* 114 */         Encoding);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getEncoding()
/*     */   {
/* 124 */     return this._constructionElement.getAttributeNS(null, "Encoding");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node appendChild(Node node)
/*     */   {
/* 135 */     Node result = null;
/*     */     
/* 137 */     result = this._constructionElement.appendChild(node);
/*     */     
/* 139 */     return result;
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 144 */     return "Object";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\signature\ObjectContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */