/*     */ package adsi.org.apache.xml.security.utils.resolver.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolverException;
/*     */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolverSpi;
/*     */ import java.io.FileInputStream;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.utils.URI;
/*     */ import org.apache.xml.utils.URI.MalformedURIException;
/*     */ import org.w3c.dom.Attr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResolverLocalFilesystem
/*     */   extends ResourceResolverSpi
/*     */ {
/*  41 */   static Log log = LogFactory.getLog(
/*  42 */     ResolverLocalFilesystem.class.getName());
/*     */   
/*     */   public boolean engineIsThreadSafe() {
/*  45 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public XMLSignatureInput engineResolve(Attr uri, String BaseURI)
/*     */     throws ResourceResolverException
/*     */   {
/*     */     try
/*     */     {
/*  54 */       URI uriNew = getNewURI(uri.getNodeValue(), BaseURI);
/*     */       
/*     */ 
/*  57 */       URI uriNewNoFrag = new URI(uriNew);
/*     */       
/*  59 */       uriNewNoFrag.setFragment(null);
/*     */       
/*  61 */       String fileName = 
/*     */       
/*  63 */         translateUriToFilename(uriNewNoFrag.toString());
/*  64 */       FileInputStream inputStream = new FileInputStream(fileName);
/*  65 */       XMLSignatureInput result = new XMLSignatureInput(inputStream);
/*     */       
/*  67 */       result.setSourceURI(uriNew.toString());
/*     */       
/*  69 */       return result;
/*     */     } catch (Exception e) {
/*  71 */       throw new ResourceResolverException("generic.EmptyMessage", e, uri, 
/*  72 */         BaseURI);
/*     */     }
/*     */   }
/*     */   
/*  76 */   private static int FILE_URI_LENGTH = "file:/".length();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static String translateUriToFilename(String uri)
/*     */   {
/*  85 */     String subStr = uri.substring(FILE_URI_LENGTH);
/*     */     
/*  87 */     if (subStr.indexOf("%20") > -1)
/*     */     {
/*  89 */       int offset = 0;
/*  90 */       int index = 0;
/*  91 */       StringBuffer temp = new StringBuffer(subStr.length());
/*     */       do
/*     */       {
/*  94 */         index = subStr.indexOf("%20", offset);
/*  95 */         if (index == -1) { temp.append(subStr.substring(offset));
/*     */         }
/*     */         else {
/*  98 */           temp.append(subStr.substring(offset, index));
/*  99 */           temp.append(' ');
/* 100 */           offset = index + 3;
/*     */         }
/*     */         
/* 103 */       } while (index != -1);
/* 104 */       subStr = temp.toString();
/*     */     }
/*     */     
/* 107 */     if (subStr.charAt(1) == ':')
/*     */     {
/* 109 */       return subStr;
/*     */     }
/*     */     
/* 112 */     return "/" + subStr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean engineCanResolve(Attr uri, String BaseURI)
/*     */   {
/* 120 */     if (uri == null) {
/* 121 */       return false;
/*     */     }
/*     */     
/* 124 */     String uriNodeValue = uri.getNodeValue();
/*     */     
/* 126 */     if ((uriNodeValue.equals("")) || (uriNodeValue.charAt(0) == '#') || 
/* 127 */       (uriNodeValue.startsWith("http:"))) {
/* 128 */       return false;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 133 */       if (log.isDebugEnabled()) {
/* 134 */         log.debug("I was asked whether I can resolve " + uriNodeValue);
/*     */       }
/* 136 */       if ((uriNodeValue.startsWith("file:")) || 
/* 137 */         (BaseURI.startsWith("file:"))) {
/* 138 */         if (log.isDebugEnabled()) {
/* 139 */           log.debug("I state that I can resolve " + uriNodeValue);
/*     */         }
/* 141 */         return true;
/*     */       }
/*     */     }
/*     */     catch (Exception localException) {
/* 145 */       log.debug("But I can't");
/*     */     }
/* 147 */     return false;
/*     */   }
/*     */   
/*     */   protected static URI getNewURI(String uri, String BaseURI)
/*     */     throws URI.MalformedURIException
/*     */   {
/* 153 */     if ((BaseURI == null) || ("".equals(BaseURI))) {
/* 154 */       return new URI(uri);
/*     */     }
/* 156 */     return new URI(new URI(BaseURI), uri);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\utils\resolver\implementations\ResolverLocalFilesystem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */