/*     */ package adsi.org.apache.xml.security.keys.storage.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.keys.content.x509.XMLX509SKI;
/*     */ import adsi.org.apache.xml.security.keys.storage.StorageResolverException;
/*     */ import adsi.org.apache.xml.security.keys.storage.StorageResolverSpi;
/*     */ import adsi.org.apache.xml.security.utils.Base64;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.math.BigInteger;
/*     */ import java.security.Principal;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateExpiredException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.CertificateNotYetValidException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CertsInFilesystemDirectoryResolver
/*     */   extends StorageResolverSpi
/*     */ {
/*  47 */   static Log log = LogFactory.getLog(
/*  48 */     CertsInFilesystemDirectoryResolver.class.getName());
/*     */   
/*     */ 
/*  51 */   String _merlinsCertificatesDir = null;
/*     */   
/*     */ 
/*  54 */   private List _certs = new ArrayList();
/*     */   
/*     */ 
/*  57 */   Iterator _iterator = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CertsInFilesystemDirectoryResolver(String directoryName)
/*     */     throws StorageResolverException
/*     */   {
/*  68 */     this._merlinsCertificatesDir = directoryName;
/*     */     
/*  70 */     readCertsFromHarddrive();
/*     */     
/*  72 */     this._iterator = new FilesystemIterator(this._certs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readCertsFromHarddrive()
/*     */     throws StorageResolverException
/*     */   {
/*  82 */     File certDir = new File(this._merlinsCertificatesDir);
/*  83 */     ArrayList al = new ArrayList();
/*  84 */     String[] names = certDir.list();
/*     */     
/*  86 */     for (int i = 0; i < names.length; i++) {
/*  87 */       String currentFileName = names[i];
/*     */       
/*  89 */       if (currentFileName.endsWith(".crt")) {
/*  90 */         al.add(names[i]);
/*     */       }
/*     */     }
/*     */     
/*  94 */     CertificateFactory cf = null;
/*     */     try
/*     */     {
/*  97 */       cf = CertificateFactory.getInstance("X.509");
/*     */     } catch (CertificateException ex) {
/*  99 */       throw new StorageResolverException("empty", ex);
/*     */     }
/*     */     
/* 102 */     if (cf == null) {
/* 103 */       throw new StorageResolverException("empty");
/*     */     }
/*     */     
/* 106 */     for (int i = 0; i < al.size(); i++) {
/* 107 */       String filename = certDir.getAbsolutePath() + File.separator + 
/* 108 */         (String)al.get(i);
/* 109 */       File file = new File(filename);
/* 110 */       boolean added = false;
/* 111 */       String dn = null;
/*     */       try
/*     */       {
/* 114 */         FileInputStream fis = new FileInputStream(file);
/* 115 */         X509Certificate cert = 
/* 116 */           (X509Certificate)cf.generateCertificate(fis);
/*     */         
/* 118 */         fis.close();
/*     */         
/*     */ 
/* 121 */         cert.checkValidity();
/* 122 */         this._certs.add(cert);
/*     */         
/* 124 */         dn = cert.getSubjectDN().getName();
/* 125 */         added = true;
/*     */       } catch (FileNotFoundException ex) {
/* 127 */         log.debug("Could not add certificate from file " + filename, ex);
/*     */       } catch (IOException ex) {
/* 129 */         log.debug("Could not add certificate from file " + filename, ex);
/*     */       } catch (CertificateNotYetValidException ex) {
/* 131 */         log.debug("Could not add certificate from file " + filename, ex);
/*     */       } catch (CertificateExpiredException ex) {
/* 133 */         log.debug("Could not add certificate from file " + filename, ex);
/*     */       } catch (CertificateException ex) {
/* 135 */         log.debug("Could not add certificate from file " + filename, ex);
/*     */       }
/*     */       
/* 138 */       if ((added) && 
/* 139 */         (log.isDebugEnabled())) {
/* 140 */         log.debug("Added certificate: " + dn);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Iterator getIterator()
/*     */   {
/* 147 */     return this._iterator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class FilesystemIterator
/*     */     implements Iterator
/*     */   {
/* 159 */     List _certs = null;
/*     */     
/*     */ 
/*     */ 
/*     */     int _i;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public FilesystemIterator(List certs)
/*     */     {
/* 170 */       this._certs = certs;
/* 171 */       this._i = 0;
/*     */     }
/*     */     
/*     */     public boolean hasNext()
/*     */     {
/* 176 */       return this._i < this._certs.size();
/*     */     }
/*     */     
/*     */     public Object next()
/*     */     {
/* 181 */       return this._certs.get(this._i++);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void remove()
/*     */     {
/* 189 */       throw new UnsupportedOperationException(
/* 190 */         "Can't remove keys from KeyStore");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] unused)
/*     */     throws Exception
/*     */   {
/* 202 */     CertsInFilesystemDirectoryResolver krs = 
/* 203 */       new CertsInFilesystemDirectoryResolver(
/* 204 */       "data/ie/baltimore/merlin-examples/merlin-xmldsig-eighteen/certs");
/*     */     
/* 206 */     for (Iterator i = krs.getIterator(); i.hasNext();) {
/* 207 */       X509Certificate cert = (X509Certificate)i.next();
/* 208 */       byte[] ski = 
/*     */       
/* 210 */         XMLX509SKI.getSKIBytesFromCert(cert);
/*     */       
/* 212 */       System.out.println();
/* 213 */       System.out.println("Base64(SKI())=                 \"" + 
/* 214 */         Base64.encode(ski) + "\"");
/* 215 */       System.out.println("cert.getSerialNumber()=        \"" + 
/* 216 */         cert.getSerialNumber().toString() + "\"");
/* 217 */       System.out.println("cert.getSubjectDN().getName()= \"" + 
/* 218 */         cert.getSubjectDN().getName() + "\"");
/* 219 */       System.out.println("cert.getIssuerDN().getName()=  \"" + 
/* 220 */         cert.getIssuerDN().getName() + "\"");
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\storage\implementations\CertsInFilesystemDirectoryResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */