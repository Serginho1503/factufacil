/*    */ package adsi.org.apache.xml.security.keys.content;
/*    */ 
/*    */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*    */ import adsi.org.apache.xml.security.utils.SignatureElementProxy;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MgmtData
/*    */   extends SignatureElementProxy
/*    */   implements KeyInfoContent
/*    */ {
/*    */   public MgmtData(Element element, String BaseURI)
/*    */     throws XMLSecurityException
/*    */   {
/* 41 */     super(element, BaseURI);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public MgmtData(Document doc, String mgmtData)
/*    */   {
/* 52 */     super(doc);
/*    */     
/* 54 */     addText(mgmtData);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getMgmtData()
/*    */   {
/* 63 */     return getTextFromTextChild();
/*    */   }
/*    */   
/*    */   public String getBaseLocalName()
/*    */   {
/* 68 */     return "MgmtData";
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\content\MgmtData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */