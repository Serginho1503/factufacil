/*     */ package adsi.org.apache.xml.security.algorithms;
/*     */ 
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.security.Provider;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JCEMapper
/*     */ {
/*  46 */   static Log log = LogFactory.getLog(JCEMapper.class.getName());
/*     */   
/*     */ 
/*     */   private static Map uriToJCEName;
/*     */   
/*     */ 
/*     */   private static Map algorithmsMap;
/*     */   
/*  54 */   private static String providerName = null;
/*     */   
/*  56 */   private static ThreadLocal<Provider> providersThread = new ThreadLocal() {
/*     */     protected synchronized Provider initialValue() {
/*  58 */       return null;
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void init(Element mappingElement)
/*     */     throws Exception
/*     */   {
/*  71 */     loadAlgorithms((Element)mappingElement.getElementsByTagName("Algorithms").item(0));
/*     */   }
/*     */   
/*     */   static void loadAlgorithms(Element algorithmsEl) {
/*  75 */     Element[] algorithms = XMLUtils.selectNodes(algorithmsEl.getFirstChild(), "http://www.xmlsecurity.org/NS/#configuration", "Algorithm");
/*  76 */     uriToJCEName = new HashMap(algorithms.length * 2);
/*  77 */     algorithmsMap = new HashMap(algorithms.length * 2);
/*  78 */     for (int i = 0; i < algorithms.length; i++) {
/*  79 */       Element el = algorithms[i];
/*  80 */       String id = el.getAttribute("URI");
/*  81 */       String jceName = el.getAttribute("JCEName");
/*  82 */       uriToJCEName.put(id, jceName);
/*  83 */       algorithmsMap.put(id, new Algorithm(el));
/*     */     }
/*     */   }
/*     */   
/*     */   static Algorithm getAlgorithmMapping(String algoURI)
/*     */   {
/*  89 */     return (Algorithm)algorithmsMap.get(algoURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String translateURItoJCEID(String AlgorithmURI)
/*     */   {
/* 100 */     if (log.isDebugEnabled()) {
/* 101 */       log.debug("Request for URI " + AlgorithmURI);
/*     */     }
/* 103 */     String jceName = (String)uriToJCEName.get(AlgorithmURI);
/* 104 */     return jceName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getAlgorithmClassFromURI(String AlgorithmURI)
/*     */   {
/* 116 */     if (log.isDebugEnabled()) {
/* 117 */       log.debug("Request for URI " + AlgorithmURI);
/*     */     }
/* 119 */     return ((Algorithm)algorithmsMap.get(AlgorithmURI)).algorithmClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getKeyLengthFromURI(String AlgorithmURI)
/*     */   {
/* 129 */     return Integer.parseInt(((Algorithm)algorithmsMap.get(AlgorithmURI)).keyLength);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getJCEKeyAlgorithmFromURI(String AlgorithmURI)
/*     */   {
/* 141 */     return ((Algorithm)algorithmsMap.get(AlgorithmURI)).requiredKey;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getProviderId()
/*     */   {
/* 150 */     return providerName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setProviderId(String provider)
/*     */   {
/* 158 */     providerName = provider;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void removeProviderSignatureThread()
/*     */   {
/* 165 */     providersThread.remove();
/* 166 */     SignatureAlgorithm.clearInstanceForSigning();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setProviderSignatureThread(Provider provider)
/*     */   {
/* 174 */     Provider actualProv = (Provider)providersThread.get();
/* 175 */     if (actualProv != null) {
/* 176 */       String name = actualProv.getName();
/* 177 */       if ((name != null) && (!name.equals(provider.getName()))) {
/* 178 */         SignatureAlgorithm.clearInstanceForSigning();
/*     */       }
/*     */     }
/* 181 */     providersThread.set(provider);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Provider getProviderSignatureThread()
/*     */   {
/* 189 */     return (Provider)providersThread.get();
/*     */   }
/*     */   
/*     */ 
/*     */   public static class Algorithm
/*     */   {
/*     */     String algorithmClass;
/*     */     
/*     */     String keyLength;
/*     */     
/*     */     String requiredKey;
/*     */     
/*     */ 
/*     */     public Algorithm(Element el)
/*     */     {
/* 204 */       this.algorithmClass = el.getAttribute("AlgorithmClass");
/* 205 */       this.keyLength = el.getAttribute("KeyLength");
/* 206 */       this.requiredKey = el.getAttribute("RequiredKey");
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\algorithms\JCEMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */