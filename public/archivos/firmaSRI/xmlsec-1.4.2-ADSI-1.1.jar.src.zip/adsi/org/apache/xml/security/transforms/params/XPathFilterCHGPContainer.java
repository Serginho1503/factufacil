/*     */ package adsi.org.apache.xml.security.transforms.params;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.transforms.TransformParam;
/*     */ import adsi.org.apache.xml.security.utils.ElementProxy;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XPathFilterCHGPContainer
/*     */   extends ElementProxy
/*     */   implements TransformParam
/*     */ {
/*     */   private static final String _TAG_INCLUDE_BUT_SEARCH = "IncludeButSearch";
/*     */   private static final String _TAG_EXCLUDE_BUT_SEARCH = "ExcludeButSearch";
/*     */   private static final String _TAG_EXCLUDE = "Exclude";
/*     */   public static final String _TAG_XPATHCHGP = "XPathAlternative";
/*     */   public static final String _ATT_INCLUDESLASH = "IncludeSlashPolicy";
/*     */   public static final boolean IncludeSlash = true;
/*     */   public static final boolean ExcludeSlash = false;
/*     */   
/*     */   private XPathFilterCHGPContainer() {}
/*     */   
/*     */   private XPathFilterCHGPContainer(Document doc, boolean includeSlashPolicy, String includeButSearch, String excludeButSearch, String exclude)
/*     */   {
/*  84 */     super(doc);
/*     */     
/*  86 */     if (includeSlashPolicy)
/*     */     {
/*  88 */       this._constructionElement.setAttributeNS(null, "IncludeSlashPolicy", "true");
/*     */     }
/*     */     else {
/*  91 */       this._constructionElement.setAttributeNS(null, "IncludeSlashPolicy", "false");
/*     */     }
/*     */     
/*  94 */     if ((includeButSearch != null) && 
/*  95 */       (includeButSearch.trim().length() > 0)) {
/*  96 */       Element includeButSearchElem = 
/*  97 */         ElementProxy.createElementForFamily(doc, getBaseNamespace(), 
/*  98 */         "IncludeButSearch");
/*     */       
/*     */ 
/* 101 */       includeButSearchElem
/* 102 */         .appendChild(this._doc
/* 103 */         .createTextNode(indentXPathText(includeButSearch)));
/* 104 */       XMLUtils.addReturnToElement(this._constructionElement);
/* 105 */       this._constructionElement.appendChild(includeButSearchElem);
/*     */     }
/*     */     
/* 108 */     if ((excludeButSearch != null) && 
/* 109 */       (excludeButSearch.trim().length() > 0)) {
/* 110 */       Element excludeButSearchElem = 
/* 111 */         ElementProxy.createElementForFamily(doc, getBaseNamespace(), 
/* 112 */         "ExcludeButSearch");
/*     */       
/*     */ 
/* 115 */       excludeButSearchElem
/* 116 */         .appendChild(this._doc
/* 117 */         .createTextNode(indentXPathText(excludeButSearch)));
/* 118 */       XMLUtils.addReturnToElement(this._constructionElement);
/* 119 */       this._constructionElement.appendChild(excludeButSearchElem);
/*     */     }
/*     */     
/* 122 */     if ((exclude != null) && (exclude.trim().length() > 0)) {
/* 123 */       Element excludeElem = ElementProxy.createElementForFamily(doc, 
/* 124 */         getBaseNamespace(), 
/* 125 */         "Exclude");
/*     */       
/* 127 */       excludeElem
/* 128 */         .appendChild(this._doc.createTextNode(indentXPathText(exclude)));
/* 129 */       XMLUtils.addReturnToElement(this._constructionElement);
/* 130 */       this._constructionElement.appendChild(excludeElem);
/*     */     }
/*     */     
/* 133 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String indentXPathText(String xp)
/*     */   {
/* 144 */     if ((xp.length() > 2) && (!Character.isWhitespace(xp.charAt(0)))) {
/* 145 */       return "\n" + xp + "\n";
/*     */     }
/* 147 */     return xp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private XPathFilterCHGPContainer(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 160 */     super(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XPathFilterCHGPContainer getInstance(Document doc, boolean includeSlashPolicy, String includeButSearch, String excludeButSearch, String exclude)
/*     */   {
/* 177 */     return new XPathFilterCHGPContainer(doc, includeSlashPolicy, 
/* 178 */       includeButSearch, excludeButSearch, 
/* 179 */       exclude);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XPathFilterCHGPContainer getInstance(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 193 */     return new XPathFilterCHGPContainer(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getXStr(String type)
/*     */   {
/* 204 */     if (length(getBaseNamespace(), type) != 1) {
/* 205 */       return "";
/*     */     }
/*     */     
/* 208 */     Element xElem = XMLUtils.selectNode(this._constructionElement.getFirstChild(), getBaseNamespace(), 
/* 209 */       type, 0);
/*     */     
/* 211 */     return XMLUtils.getFullTextChildrenFromElement(xElem);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getIncludeButSearch()
/*     */   {
/* 220 */     return getXStr("IncludeButSearch");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getExcludeButSearch()
/*     */   {
/* 229 */     return getXStr("ExcludeButSearch");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getExclude()
/*     */   {
/* 238 */     return getXStr("Exclude");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getIncludeSlashPolicy()
/*     */   {
/* 248 */     return 
/*     */     
/* 250 */       this._constructionElement.getAttributeNS(null, "IncludeSlashPolicy").equals("true");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Node getHereContextNode(String type)
/*     */   {
/* 264 */     if (length(getBaseNamespace(), type) != 1) {
/* 265 */       return null;
/*     */     }
/*     */     
/* 268 */     return XMLUtils.selectNodeText(this._constructionElement.getFirstChild(), getBaseNamespace(), 
/* 269 */       type, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node getHereContextNodeIncludeButSearch()
/*     */   {
/* 278 */     return 
/* 279 */       getHereContextNode("IncludeButSearch");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node getHereContextNodeExcludeButSearch()
/*     */   {
/* 288 */     return 
/* 289 */       getHereContextNode("ExcludeButSearch");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node getHereContextNodeExclude()
/*     */   {
/* 298 */     return getHereContextNode("Exclude");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getBaseLocalName()
/*     */   {
/* 307 */     return "XPathAlternative";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getBaseNamespace()
/*     */   {
/* 316 */     return "http://www.nue.et-inf.uni-siegen.de/~geuer-pollmann/#xpathFilter";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\transforms\params\XPathFilterCHGPContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */