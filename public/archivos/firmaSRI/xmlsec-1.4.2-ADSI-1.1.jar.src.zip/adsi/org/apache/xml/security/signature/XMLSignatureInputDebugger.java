/*     */ package adsi.org.apache.xml.security.signature;
/*     */ 
/*     */ import adsi.org.apache.xml.security.c14n.helper.AttrCompare;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Comment;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.ProcessingInstruction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLSignatureInputDebugger
/*     */ {
/*     */   private Set _xpathNodeSet;
/*     */   private Set _inclusiveNamespaces;
/*  52 */   private Document _doc = null;
/*     */   
/*     */ 
/*  55 */   private Writer _writer = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String HTMLPrefix = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n<html>\n<head>\n<title>Caninical XML node set</title>\n<style type=\"text/css\">\n<!-- \n.INCLUDED { \n   color: #000000; \n   background-color: \n   #FFFFFF; \n   font-weight: bold; } \n.EXCLUDED { \n   color: #666666; \n   background-color: \n   #999999; } \n.INCLUDEDINCLUSIVENAMESPACE { \n   color: #0000FF; \n   background-color: #FFFFFF; \n   font-weight: bold; \n   font-style: italic; } \n.EXCLUDEDINCLUSIVENAMESPACE { \n   color: #0000FF; \n   background-color: #999999; \n   font-style: italic; } \n--> \n</style> \n</head>\n<body bgcolor=\"#999999\">\n<h1>Explanation of the output</h1>\n<p>The following text contains the nodeset of the given Reference before it is canonicalized. There exist four different styles to indicate how a given node is treated.</p>\n<ul>\n<li class=\"INCLUDED\">A node which is in the node set is labeled using the INCLUDED style.</li>\n<li class=\"EXCLUDED\">A node which is <em>NOT</em> in the node set is labeled EXCLUDED style.</li>\n<li class=\"INCLUDEDINCLUSIVENAMESPACE\">A namespace which is in the node set AND in the InclusiveNamespaces PrefixList is labeled using the INCLUDEDINCLUSIVENAMESPACE style.</li>\n<li class=\"EXCLUDEDINCLUSIVENAMESPACE\">A namespace which is in NOT the node set AND in the InclusiveNamespaces PrefixList is labeled using the INCLUDEDINCLUSIVENAMESPACE style.</li>\n</ul>\n<h1>Output</h1>\n<pre>\n";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String HTMLSuffix = "</pre></body></html>";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String HTMLExcludePrefix = "<span class=\"EXCLUDED\">";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String HTMLExcludeSuffix = "</span>";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String HTMLIncludePrefix = "<span class=\"INCLUDED\">";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String HTMLIncludeSuffix = "</span>";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String HTMLIncludedInclusiveNamespacePrefix = "<span class=\"INCLUDEDINCLUSIVENAMESPACE\">";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String HTMLIncludedInclusiveNamespaceSuffix = "</span>";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String HTMLExcludedInclusiveNamespacePrefix = "<span class=\"EXCLUDEDINCLUSIVENAMESPACE\">";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String HTMLExcludedInclusiveNamespaceSuffix = "</span>";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int NODE_BEFORE_DOCUMENT_ELEMENT = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int NODE_NOT_BEFORE_OR_AFTER_DOCUMENT_ELEMENT = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int NODE_AFTER_DOCUMENT_ELEMENT = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 130 */   static final AttrCompare ATTR_COMPARE = new AttrCompare();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private XMLSignatureInputDebugger() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInputDebugger(XMLSignatureInput xmlSignatureInput)
/*     */   {
/* 145 */     if (!xmlSignatureInput.isNodeSet()) {
/* 146 */       this._xpathNodeSet = null;
/*     */     } else {
/* 148 */       this._xpathNodeSet = xmlSignatureInput._inputNodeSet;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInputDebugger(XMLSignatureInput xmlSignatureInput, Set inclusiveNamespace)
/*     */   {
/* 161 */     this(xmlSignatureInput);
/*     */     
/* 163 */     this._inclusiveNamespaces = inclusiveNamespace;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHTMLRepresentation()
/*     */     throws XMLSignatureException
/*     */   {
/* 174 */     if ((this._xpathNodeSet == null) || (this._xpathNodeSet.size() == 0)) {
/* 175 */       return "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n<html>\n<head>\n<title>Caninical XML node set</title>\n<style type=\"text/css\">\n<!-- \n.INCLUDED { \n   color: #000000; \n   background-color: \n   #FFFFFF; \n   font-weight: bold; } \n.EXCLUDED { \n   color: #666666; \n   background-color: \n   #999999; } \n.INCLUDEDINCLUSIVENAMESPACE { \n   color: #0000FF; \n   background-color: #FFFFFF; \n   font-weight: bold; \n   font-style: italic; } \n.EXCLUDEDINCLUSIVENAMESPACE { \n   color: #0000FF; \n   background-color: #999999; \n   font-style: italic; } \n--> \n</style> \n</head>\n<body bgcolor=\"#999999\">\n<h1>Explanation of the output</h1>\n<p>The following text contains the nodeset of the given Reference before it is canonicalized. There exist four different styles to indicate how a given node is treated.</p>\n<ul>\n<li class=\"INCLUDED\">A node which is in the node set is labeled using the INCLUDED style.</li>\n<li class=\"EXCLUDED\">A node which is <em>NOT</em> in the node set is labeled EXCLUDED style.</li>\n<li class=\"INCLUDEDINCLUSIVENAMESPACE\">A namespace which is in the node set AND in the InclusiveNamespaces PrefixList is labeled using the INCLUDEDINCLUSIVENAMESPACE style.</li>\n<li class=\"EXCLUDEDINCLUSIVENAMESPACE\">A namespace which is in NOT the node set AND in the InclusiveNamespaces PrefixList is labeled using the INCLUDEDINCLUSIVENAMESPACE style.</li>\n</ul>\n<h1>Output</h1>\n<pre>\n<blink>no node set, sorry</blink></pre></body></html>";
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 182 */     Node n = (Node)this._xpathNodeSet.iterator().next();
/*     */     
/* 184 */     this._doc = XMLUtils.getOwnerDocument(n);
/*     */     
/*     */     try
/*     */     {
/* 188 */       this._writer = new StringWriter();
/*     */       
/* 190 */       canonicalizeXPathNodeSet(this._doc);
/* 191 */       this._writer.close();
/*     */       
/* 193 */       return this._writer.toString();
/*     */     } catch (IOException ex) {
/* 195 */       throw new XMLSignatureException("empty", ex);
/*     */     } finally {
/* 197 */       this._xpathNodeSet = null;
/* 198 */       this._doc = null;
/* 199 */       this._writer = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void canonicalizeXPathNodeSet(Node currentNode)
/*     */     throws XMLSignatureException, IOException
/*     */   {
/* 213 */     int currentNodeType = currentNode.getNodeType();
/* 214 */     switch (currentNodeType)
/*     */     {
/*     */     case 5: 
/*     */     case 10: 
/*     */     default: 
/*     */       break;
/*     */     case 2: 
/*     */     case 6: 
/*     */     case 11: 
/*     */     case 12: 
/* 224 */       throw new XMLSignatureException("empty");
/*     */     case 9: 
/* 226 */       this._writer.write("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n<html>\n<head>\n<title>Caninical XML node set</title>\n<style type=\"text/css\">\n<!-- \n.INCLUDED { \n   color: #000000; \n   background-color: \n   #FFFFFF; \n   font-weight: bold; } \n.EXCLUDED { \n   color: #666666; \n   background-color: \n   #999999; } \n.INCLUDEDINCLUSIVENAMESPACE { \n   color: #0000FF; \n   background-color: #FFFFFF; \n   font-weight: bold; \n   font-style: italic; } \n.EXCLUDEDINCLUSIVENAMESPACE { \n   color: #0000FF; \n   background-color: #999999; \n   font-style: italic; } \n--> \n</style> \n</head>\n<body bgcolor=\"#999999\">\n<h1>Explanation of the output</h1>\n<p>The following text contains the nodeset of the given Reference before it is canonicalized. There exist four different styles to indicate how a given node is treated.</p>\n<ul>\n<li class=\"INCLUDED\">A node which is in the node set is labeled using the INCLUDED style.</li>\n<li class=\"EXCLUDED\">A node which is <em>NOT</em> in the node set is labeled EXCLUDED style.</li>\n<li class=\"INCLUDEDINCLUSIVENAMESPACE\">A namespace which is in the node set AND in the InclusiveNamespaces PrefixList is labeled using the INCLUDEDINCLUSIVENAMESPACE style.</li>\n<li class=\"EXCLUDEDINCLUSIVENAMESPACE\">A namespace which is in NOT the node set AND in the InclusiveNamespaces PrefixList is labeled using the INCLUDEDINCLUSIVENAMESPACE style.</li>\n</ul>\n<h1>Output</h1>\n<pre>\n");
/*     */       
/* 228 */       for (Node currentChild = currentNode.getFirstChild(); currentChild != null; currentChild = currentChild
/* 229 */             .getNextSibling()) {
/* 230 */         canonicalizeXPathNodeSet(currentChild);
/*     */       }
/*     */       
/* 233 */       this._writer.write("</pre></body></html>");
/* 234 */       break;
/*     */     
/*     */     case 8: 
/* 237 */       if (this._xpathNodeSet.contains(currentNode)) {
/* 238 */         this._writer.write("<span class=\"INCLUDED\">");
/*     */       } else {
/* 240 */         this._writer.write("<span class=\"EXCLUDED\">");
/*     */       }
/*     */       
/* 243 */       int position = getPositionRelativeToDocumentElement(currentNode);
/*     */       
/* 245 */       if (position == 1) {
/* 246 */         this._writer.write("\n");
/*     */       }
/*     */       
/* 249 */       outputCommentToWriter((Comment)currentNode);
/*     */       
/* 251 */       if (position == -1) {
/* 252 */         this._writer.write("\n");
/*     */       }
/*     */       
/* 255 */       if (this._xpathNodeSet.contains(currentNode)) {
/* 256 */         this._writer.write("</span>");
/*     */       } else {
/* 258 */         this._writer.write("</span>");
/*     */       }
/* 260 */       break;
/*     */     
/*     */     case 7: 
/* 263 */       if (this._xpathNodeSet.contains(currentNode)) {
/* 264 */         this._writer.write("<span class=\"INCLUDED\">");
/*     */       } else {
/* 266 */         this._writer.write("<span class=\"EXCLUDED\">");
/*     */       }
/*     */       
/* 269 */       int position = getPositionRelativeToDocumentElement(currentNode);
/*     */       
/* 271 */       if (position == 1) {
/* 272 */         this._writer.write("\n");
/*     */       }
/*     */       
/* 275 */       outputPItoWriter((ProcessingInstruction)currentNode);
/*     */       
/* 277 */       if (position == -1) {
/* 278 */         this._writer.write("\n");
/*     */       }
/*     */       
/* 281 */       if (this._xpathNodeSet.contains(currentNode)) {
/* 282 */         this._writer.write("</span>");
/*     */       } else {
/* 284 */         this._writer.write("</span>");
/*     */       }
/* 286 */       break;
/*     */     
/*     */     case 3: 
/*     */     case 4: 
/* 290 */       if (this._xpathNodeSet.contains(currentNode)) {
/* 291 */         this._writer.write("<span class=\"INCLUDED\">");
/*     */       } else {
/* 293 */         this._writer.write("<span class=\"EXCLUDED\">");
/*     */       }
/*     */       
/* 296 */       outputTextToWriter(currentNode.getNodeValue());
/*     */       
/* 298 */       for (Node nextSibling = currentNode.getNextSibling(); (nextSibling != null) && (
/* 299 */             (nextSibling.getNodeType() == 3) || 
/* 300 */             (nextSibling.getNodeType() == 4)); nextSibling = nextSibling
/* 301 */             .getNextSibling())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 310 */         outputTextToWriter(nextSibling.getNodeValue());
/*     */       }
/*     */       
/* 313 */       if (this._xpathNodeSet.contains(currentNode)) {
/* 314 */         this._writer.write("</span>");
/*     */       } else {
/* 316 */         this._writer.write("</span>");
/*     */       }
/* 318 */       break;
/*     */     
/*     */     case 1: 
/* 321 */       Element currentElement = (Element)currentNode;
/*     */       
/* 323 */       if (this._xpathNodeSet.contains(currentNode)) {
/* 324 */         this._writer.write("<span class=\"INCLUDED\">");
/*     */       } else {
/* 326 */         this._writer.write("<span class=\"EXCLUDED\">");
/*     */       }
/*     */       
/* 329 */       this._writer.write("&lt;");
/* 330 */       this._writer.write(currentElement.getTagName());
/*     */       
/* 332 */       if (this._xpathNodeSet.contains(currentNode)) {
/* 333 */         this._writer.write("</span>");
/*     */       } else {
/* 335 */         this._writer.write("</span>");
/*     */       }
/*     */       
/*     */ 
/* 339 */       NamedNodeMap attrs = currentElement.getAttributes();
/* 340 */       int attrsLength = attrs.getLength();
/* 341 */       Object[] attrs2 = new Object[attrsLength];
/*     */       
/* 343 */       for (int i = 0; i < attrsLength; i++) {
/* 344 */         attrs2[i] = attrs.item(i);
/*     */       }
/*     */       
/* 347 */       Arrays.sort(attrs2, ATTR_COMPARE);
/* 348 */       Object[] attrs3 = attrs2;
/*     */       
/* 350 */       for (int i = 0; i < attrsLength; i++) {
/* 351 */         Attr a = (Attr)attrs3[i];
/* 352 */         boolean included = this._xpathNodeSet.contains(a);
/* 353 */         boolean inclusive = this._inclusiveNamespaces.contains(a
/* 354 */           .getName());
/*     */         
/* 356 */         if (included) {
/* 357 */           if (inclusive)
/*     */           {
/*     */ 
/*     */ 
/* 361 */             this._writer.write("<span class=\"INCLUDEDINCLUSIVENAMESPACE\">");
/*     */           }
/*     */           else
/*     */           {
/* 365 */             this._writer.write("<span class=\"INCLUDED\">");
/*     */           }
/*     */         }
/* 368 */         else if (inclusive)
/*     */         {
/*     */ 
/*     */ 
/* 372 */           this._writer.write("<span class=\"EXCLUDEDINCLUSIVENAMESPACE\">");
/*     */         }
/*     */         else
/*     */         {
/* 376 */           this._writer.write("<span class=\"EXCLUDED\">");
/*     */         }
/*     */         
/*     */ 
/* 380 */         outputAttrToWriter(a.getNodeName(), a.getNodeValue());
/*     */         
/* 382 */         if (included) {
/* 383 */           if (inclusive)
/*     */           {
/*     */ 
/*     */ 
/* 387 */             this._writer.write("</span>");
/*     */           }
/*     */           else
/*     */           {
/* 391 */             this._writer.write("</span>");
/*     */           }
/*     */         }
/* 394 */         else if (inclusive)
/*     */         {
/*     */ 
/*     */ 
/* 398 */           this._writer.write("</span>");
/*     */         }
/*     */         else
/*     */         {
/* 402 */           this._writer.write("</span>");
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 407 */       if (this._xpathNodeSet.contains(currentNode)) {
/* 408 */         this._writer.write("<span class=\"INCLUDED\">");
/*     */       } else {
/* 410 */         this._writer.write("<span class=\"EXCLUDED\">");
/*     */       }
/*     */       
/* 413 */       this._writer.write("&gt;");
/*     */       
/* 415 */       if (this._xpathNodeSet.contains(currentNode)) {
/* 416 */         this._writer.write("</span>");
/*     */       } else {
/* 418 */         this._writer.write("</span>");
/*     */       }
/*     */       
/*     */ 
/* 422 */       for (Node currentChild = currentNode.getFirstChild(); currentChild != null; currentChild = currentChild
/* 423 */             .getNextSibling()) {
/* 424 */         canonicalizeXPathNodeSet(currentChild);
/*     */       }
/*     */       
/* 427 */       if (this._xpathNodeSet.contains(currentNode)) {
/* 428 */         this._writer.write("<span class=\"INCLUDED\">");
/*     */       } else {
/* 430 */         this._writer.write("<span class=\"EXCLUDED\">");
/*     */       }
/*     */       
/* 433 */       this._writer.write("&lt;/");
/* 434 */       this._writer.write(currentElement.getTagName());
/* 435 */       this._writer.write("&gt;");
/*     */       
/* 437 */       if (this._xpathNodeSet.contains(currentNode)) {
/* 438 */         this._writer.write("</span>");
/*     */       } else {
/* 440 */         this._writer.write("</span>");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int getPositionRelativeToDocumentElement(Node currentNode)
/*     */   {
/* 461 */     if (currentNode == null) {
/* 462 */       return 0;
/*     */     }
/*     */     
/* 465 */     Document doc = currentNode.getOwnerDocument();
/*     */     
/* 467 */     if (currentNode.getParentNode() != doc) {
/* 468 */       return 0;
/*     */     }
/*     */     
/* 471 */     Element documentElement = doc.getDocumentElement();
/*     */     
/* 473 */     if (documentElement == null) {
/* 474 */       return 0;
/*     */     }
/*     */     
/* 477 */     if (documentElement == currentNode) {
/* 478 */       return 0;
/*     */     }
/*     */     
/* 481 */     for (Node x = currentNode; x != null; x = x.getNextSibling()) {
/* 482 */       if (x == documentElement) {
/* 483 */         return -1;
/*     */       }
/*     */     }
/*     */     
/* 487 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void outputAttrToWriter(String name, String value)
/*     */     throws IOException
/*     */   {
/* 511 */     this._writer.write(" ");
/* 512 */     this._writer.write(name);
/* 513 */     this._writer.write("=\"");
/*     */     
/* 515 */     int length = value.length();
/*     */     
/* 517 */     for (int i = 0; i < length; i++) {
/* 518 */       char c = value.charAt(i);
/*     */       
/* 520 */       switch (c)
/*     */       {
/*     */       case '&': 
/* 523 */         this._writer.write("&amp;amp;");
/* 524 */         break;
/*     */       
/*     */       case '<': 
/* 527 */         this._writer.write("&amp;lt;");
/* 528 */         break;
/*     */       
/*     */       case '"': 
/* 531 */         this._writer.write("&amp;quot;");
/* 532 */         break;
/*     */       
/*     */       case '\t': 
/* 535 */         this._writer.write("&amp;#x9;");
/* 536 */         break;
/*     */       
/*     */       case '\n': 
/* 539 */         this._writer.write("&amp;#xA;");
/* 540 */         break;
/*     */       
/*     */       case '\r': 
/* 543 */         this._writer.write("&amp;#xD;");
/* 544 */         break;
/*     */       
/*     */       default: 
/* 547 */         this._writer.write(c);
/*     */       }
/*     */       
/*     */     }
/*     */     
/* 552 */     this._writer.write("\"");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void outputPItoWriter(ProcessingInstruction currentPI)
/*     */     throws IOException
/*     */   {
/* 564 */     if (currentPI == null) {
/* 565 */       return;
/*     */     }
/*     */     
/* 568 */     this._writer.write("&lt;?");
/*     */     
/* 570 */     String target = currentPI.getTarget();
/* 571 */     int length = target.length();
/*     */     
/* 573 */     for (int i = 0; i < length; i++) {
/* 574 */       char c = target.charAt(i);
/*     */       
/* 576 */       switch (c)
/*     */       {
/*     */       case '\r': 
/* 579 */         this._writer.write("&amp;#xD;");
/* 580 */         break;
/*     */       
/*     */       case ' ': 
/* 583 */         this._writer.write("&middot;");
/* 584 */         break;
/*     */       
/*     */       case '\n': 
/* 587 */         this._writer.write("&para;\n");
/* 588 */         break;
/*     */       
/*     */       default: 
/* 591 */         this._writer.write(c);
/*     */       }
/*     */       
/*     */     }
/*     */     
/* 596 */     String data = currentPI.getData();
/*     */     
/* 598 */     length = data.length();
/*     */     
/* 600 */     if (length > 0) {
/* 601 */       this._writer.write(" ");
/*     */       
/* 603 */       for (int i = 0; i < length; i++) {
/* 604 */         char c = data.charAt(i);
/*     */         
/* 606 */         switch (c)
/*     */         {
/*     */         case '\r': 
/* 609 */           this._writer.write("&amp;#xD;");
/* 610 */           break;
/*     */         
/*     */         default: 
/* 613 */           this._writer.write(c);
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */     
/* 619 */     this._writer.write("?&gt;");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void outputCommentToWriter(Comment currentComment)
/*     */     throws IOException
/*     */   {
/* 631 */     if (currentComment == null) {
/* 632 */       return;
/*     */     }
/*     */     
/* 635 */     this._writer.write("&lt;!--");
/*     */     
/* 637 */     String data = currentComment.getData();
/* 638 */     int length = data.length();
/*     */     
/* 640 */     for (int i = 0; i < length; i++) {
/* 641 */       char c = data.charAt(i);
/*     */       
/* 643 */       switch (c)
/*     */       {
/*     */       case '\r': 
/* 646 */         this._writer.write("&amp;#xD;");
/* 647 */         break;
/*     */       
/*     */       case ' ': 
/* 650 */         this._writer.write("&middot;");
/* 651 */         break;
/*     */       
/*     */       case '\n': 
/* 654 */         this._writer.write("&para;\n");
/* 655 */         break;
/*     */       
/*     */       default: 
/* 658 */         this._writer.write(c);
/*     */       }
/*     */       
/*     */     }
/*     */     
/* 663 */     this._writer.write("--&gt;");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void outputTextToWriter(String text)
/*     */     throws IOException
/*     */   {
/* 674 */     if (text == null) {
/* 675 */       return;
/*     */     }
/*     */     
/* 678 */     int length = text.length();
/*     */     
/* 680 */     for (int i = 0; i < length; i++) {
/* 681 */       char c = text.charAt(i);
/*     */       
/* 683 */       switch (c)
/*     */       {
/*     */       case '&': 
/* 686 */         this._writer.write("&amp;amp;");
/* 687 */         break;
/*     */       
/*     */       case '<': 
/* 690 */         this._writer.write("&amp;lt;");
/* 691 */         break;
/*     */       
/*     */       case '>': 
/* 694 */         this._writer.write("&amp;gt;");
/* 695 */         break;
/*     */       
/*     */       case '\r': 
/* 698 */         this._writer.write("&amp;#xD;");
/* 699 */         break;
/*     */       
/*     */       case ' ': 
/* 702 */         this._writer.write("&middot;");
/* 703 */         break;
/*     */       
/*     */       case '\n': 
/* 706 */         this._writer.write("&para;\n");
/* 707 */         break;
/*     */       
/*     */       default: 
/* 710 */         this._writer.write(c);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\signature\XMLSignatureInputDebugger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */