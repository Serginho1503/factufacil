/*    */ package adsi.org.apache.xml.security.utils;
/*    */ 
/*    */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SignatureElementProxy
/*    */   extends ElementProxy
/*    */ {
/*    */   protected SignatureElementProxy() {}
/*    */   
/*    */   public SignatureElementProxy(Document doc)
/*    */   {
/* 42 */     if (doc == null) {
/* 43 */       throw new RuntimeException("Document is null");
/*    */     }
/*    */     
/* 46 */     this._doc = doc;
/* 47 */     this._constructionElement = XMLUtils.createElementInSignatureSpace(this._doc, 
/* 48 */       getBaseLocalName());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SignatureElementProxy(Element element, String BaseURI)
/*    */     throws XMLSecurityException
/*    */   {
/* 60 */     super(element, BaseURI);
/*    */   }
/*    */   
/*    */ 
/*    */   public String getBaseNamespace()
/*    */   {
/* 66 */     return "http://www.w3.org/2000/09/xmldsig#";
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\utils\SignatureElementProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */