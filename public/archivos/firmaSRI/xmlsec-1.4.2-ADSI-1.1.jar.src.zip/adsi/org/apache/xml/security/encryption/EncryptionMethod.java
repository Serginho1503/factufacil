package adsi.org.apache.xml.security.encryption;

import java.util.Iterator;
import org.w3c.dom.Element;

public abstract interface EncryptionMethod
{
  public abstract String getAlgorithm();
  
  public abstract int getKeySize();
  
  public abstract void setKeySize(int paramInt);
  
  public abstract byte[] getOAEPparams();
  
  public abstract void setOAEPparams(byte[] paramArrayOfByte);
  
  public abstract Iterator getEncryptionMethodInformation();
  
  public abstract void addEncryptionMethodInformation(Element paramElement);
  
  public abstract void removeEncryptionMethodInformation(Element paramElement);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\encryption\EncryptionMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */