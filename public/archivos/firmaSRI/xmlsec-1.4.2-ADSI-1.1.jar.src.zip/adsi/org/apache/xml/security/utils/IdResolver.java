/*     */ package adsi.org.apache.xml.security.utils;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.WeakHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IdResolver
/*     */ {
/*  49 */   private static Log log = LogFactory.getLog(IdResolver.class.getName());
/*     */   
/*  51 */   private static WeakHashMap docMap = new WeakHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static List names;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void registerElementById(Element element, String idValue)
/*     */   {
/*  68 */     Document doc = element.getOwnerDocument();
/*  69 */     WeakHashMap elementMap = (WeakHashMap)docMap.get(doc);
/*  70 */     if (elementMap == null) {
/*  71 */       elementMap = new WeakHashMap();
/*  72 */       docMap.put(doc, elementMap);
/*     */     }
/*  74 */     elementMap.put(idValue, new WeakReference(element));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void registerElementById(Element element, Attr id)
/*     */   {
/*  84 */     registerElementById(element, id.getNodeValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Element getElementById(Document doc, String id)
/*     */   {
/*  96 */     Element result = getElementByIdType(doc, id);
/*     */     
/*  98 */     if (result != null) {
/*  99 */       log.debug(
/* 100 */         "I could find an Element using the simple getElementByIdType method: " + 
/* 101 */         result.getTagName());
/*     */       
/* 103 */       return result;
/*     */     }
/*     */     
/* 106 */     result = getElementByIdUsingDOM(doc, id);
/*     */     
/* 108 */     if (result != null) {
/* 109 */       log.debug(
/* 110 */         "I could find an Element using the simple getElementByIdUsingDOM method: " + 
/* 111 */         result.getTagName());
/*     */       
/* 113 */       return result;
/*     */     }
/*     */     
/*     */ 
/* 117 */     result = getElementBySearching(doc, id);
/*     */     
/* 119 */     if (result != null) {
/* 120 */       registerElementById(result, id);
/*     */       
/* 122 */       return result;
/*     */     }
/*     */     
/* 125 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Element getElementByIdUsingDOM(Document doc, String id)
/*     */   {
/* 137 */     if (log.isDebugEnabled())
/* 138 */       log.debug("getElementByIdUsingDOM() Search for ID " + id);
/* 139 */     return doc.getElementById(id);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Element getElementByIdType(Document doc, String id)
/*     */   {
/* 150 */     if (log.isDebugEnabled())
/* 151 */       log.debug("getElementByIdType() Search for ID " + id);
/* 152 */     WeakHashMap elementMap = (WeakHashMap)docMap.get(doc);
/* 153 */     if (elementMap != null) {
/* 154 */       WeakReference weakReference = (WeakReference)elementMap.get(id);
/* 155 */       if (weakReference != null) {
/* 156 */         return (Element)weakReference.get();
/*     */       }
/*     */     }
/* 159 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   static
/*     */   {
/* 165 */     String[] namespaces = {
/* 166 */       "http://www.w3.org/2000/09/xmldsig#", 
/* 167 */       "http://www.w3.org/2001/04/xmlenc#", 
/* 168 */       "http://schemas.xmlsoap.org/soap/security/2000-12", 
/* 169 */       "http://www.w3.org/2002/03/xkms#", 
/* 170 */       "urn:oasis:names:tc:SAML:1.0:assertion", 
/* 171 */       "urn:oasis:names:tc:SAML:1.0:protocol" };
/*     */     
/* 173 */     names = Arrays.asList(namespaces); }
/* 174 */   private static int namesLength = names.size();
/*     */   
/*     */ 
/*     */   private static Element getElementBySearching(Node root, String id)
/*     */   {
/* 179 */     Element[] els = new Element[namesLength + 1];
/* 180 */     getEl(root, id, els);
/* 181 */     for (int i = 0; i < els.length; i++) {
/* 182 */       if (els[i] != null) {
/* 183 */         return els[i];
/*     */       }
/*     */     }
/* 186 */     return null;
/*     */   }
/*     */   
/*     */   private static int getEl(Node currentNode, String id, Element[] els) {
/* 190 */     Node sibling = null;
/* 191 */     Node parentNode = null;
/*     */     for (;;) {
/* 193 */       switch (currentNode.getNodeType()) {
/*     */       case 9: 
/*     */       case 11: 
/* 196 */         sibling = currentNode.getFirstChild();
/* 197 */         break;
/*     */       
/*     */ 
/*     */       case 1: 
/* 201 */         Element currentElement = (Element)currentNode;
/* 202 */         if (isElement(currentElement, id, els) == 1)
/* 203 */           return 1;
/* 204 */         sibling = currentNode.getFirstChild();
/* 205 */         if (sibling == null) {
/* 206 */           if (parentNode != null) {
/* 207 */             sibling = currentNode.getNextSibling();
/*     */           }
/*     */         } else
/* 210 */           parentNode = currentElement;
/*     */         break;
/*     */       }
/* 213 */       while ((sibling == null) && (parentNode != null)) {
/* 214 */         sibling = parentNode.getNextSibling();
/* 215 */         parentNode = parentNode.getParentNode();
/* 216 */         if (!(parentNode instanceof Element)) {
/* 217 */           parentNode = null;
/*     */         }
/*     */       }
/* 220 */       if (sibling == null)
/* 221 */         return 1;
/* 222 */       currentNode = sibling;
/* 223 */       sibling = currentNode.getNextSibling();
/*     */     }
/*     */   }
/*     */   
/*     */   public static int isElement(Element el, String id, Element[] els) {
/* 228 */     if (!el.hasAttributes()) {
/* 229 */       return 0;
/*     */     }
/* 231 */     NamedNodeMap ns = el.getAttributes();
/* 232 */     int elementIndex = names.indexOf(el.getNamespaceURI());
/* 233 */     elementIndex = elementIndex < 0 ? namesLength : elementIndex;
/* 234 */     int length = ns.getLength(); for (int i = 0; i < length; i++) {
/* 235 */       Attr n = (Attr)ns.item(i);
/* 236 */       String s = n.getNamespaceURI();
/*     */       
/* 238 */       int index = s == null ? elementIndex : names.indexOf(n.getNamespaceURI());
/* 239 */       index = index < 0 ? namesLength : index;
/* 240 */       String name = n.getLocalName();
/* 241 */       if (name.length() <= 2)
/*     */       {
/* 243 */         String value = n.getNodeValue();
/* 244 */         if (name.charAt(0) == 'I') {
/* 245 */           char ch = name.charAt(1);
/* 246 */           if ((ch == 'd') && (value.equals(id))) {
/* 247 */             els[index] = el;
/* 248 */             if (index == 0) {
/* 249 */               return 1;
/*     */             }
/* 251 */           } else if ((ch == 'D') && (value.endsWith(id))) {
/* 252 */             if (index != 3) {
/* 253 */               index = namesLength;
/*     */             }
/* 255 */             els[index] = el;
/*     */           }
/* 257 */         } else if (("id".equals(name)) && (value.equals(id))) {
/* 258 */           if (index != 2) {
/* 259 */             index = namesLength;
/*     */           }
/* 261 */           els[index] = el;
/*     */         }
/*     */       }
/*     */     }
/* 265 */     if ((elementIndex == 3) && (
/* 266 */       (el.getAttribute("OriginalRequestID").equals(id)) || 
/* 267 */       (el.getAttribute("RequestID").equals(id)) || 
/* 268 */       (el.getAttribute("ResponseID").equals(id)))) {
/* 269 */       els[3] = el;
/* 270 */     } else if ((elementIndex == 4) && 
/* 271 */       (el.getAttribute("AssertionID").equals(id))) {
/* 272 */       els[4] = el;
/* 273 */     } else if ((elementIndex == 5) && (
/* 274 */       (el.getAttribute("RequestID").equals(id)) || 
/* 275 */       (el.getAttribute("ResponseID").equals(id)))) {
/* 276 */       els[5] = el;
/*     */     }
/* 278 */     return 0;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\utils\IdResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */