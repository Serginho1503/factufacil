/*     */ package adsi.org.apache.xml.security.c14n;
/*     */ 
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Set;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CanonicalizerSpi
/*     */ {
/*     */   public byte[] engineCanonicalize(byte[] inputBytes)
/*     */     throws ParserConfigurationException, IOException, SAXException, CanonicalizationException
/*     */   {
/*  63 */     ByteArrayInputStream bais = new ByteArrayInputStream(inputBytes);
/*  64 */     InputSource in = new InputSource(bais);
/*  65 */     DocumentBuilderFactory dfactory = DocumentBuilderFactory.newInstance();
/*     */     
/*     */ 
/*  68 */     dfactory.setNamespaceAware(true);
/*     */     
/*  70 */     DocumentBuilder db = dfactory.newDocumentBuilder();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  97 */     Document document = db.parse(in);
/*  98 */     byte[] result = engineCanonicalizeSubTree(document);
/*  99 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalizeXPathNodeSet(NodeList xpathNodeSet)
/*     */     throws CanonicalizationException
/*     */   {
/* 112 */     return 
/* 113 */       engineCanonicalizeXPathNodeSet(
/* 114 */       XMLUtils.convertNodelistToSet(xpathNodeSet));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalizeXPathNodeSet(NodeList xpathNodeSet, String inclusiveNamespaces)
/*     */     throws CanonicalizationException
/*     */   {
/* 128 */     return 
/* 129 */       engineCanonicalizeXPathNodeSet(
/* 130 */       XMLUtils.convertNodelistToSet(xpathNodeSet), inclusiveNamespaces);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 194 */   protected boolean reset = false;
/*     */   
/*     */   public abstract String engineGetURI();
/*     */   
/*     */   public abstract boolean engineGetIncludeComments();
/*     */   
/*     */   public abstract byte[] engineCanonicalizeXPathNodeSet(Set paramSet)
/*     */     throws CanonicalizationException;
/*     */   
/*     */   public abstract byte[] engineCanonicalizeXPathNodeSet(Set paramSet, String paramString)
/*     */     throws CanonicalizationException;
/*     */   
/*     */   public abstract byte[] engineCanonicalizeSubTree(Node paramNode)
/*     */     throws CanonicalizationException;
/*     */   
/*     */   public abstract byte[] engineCanonicalizeSubTree(Node paramNode, String paramString)
/*     */     throws CanonicalizationException;
/*     */   
/*     */   public abstract void setWriter(OutputStream paramOutputStream);
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\c14n\CanonicalizerSpi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */