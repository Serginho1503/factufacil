/*     */ package adsi.org.apache.xml.security.transforms.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityRuntimeException;
/*     */ import adsi.org.apache.xml.security.signature.NodeFilter;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import adsi.org.apache.xml.security.transforms.Transform;
/*     */ import adsi.org.apache.xml.security.transforms.TransformSpi;
/*     */ import adsi.org.apache.xml.security.transforms.TransformationException;
/*     */ import adsi.org.apache.xml.security.utils.CachedXPathAPIHolder;
/*     */ import adsi.org.apache.xml.security.utils.CachedXPathFuncHereAPI;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import org.apache.xml.utils.PrefixResolverDefault;
/*     */ import org.apache.xpath.objects.XObject;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransformXPath
/*     */   extends TransformSpi
/*     */ {
/*     */   public static final String implementedTransformURI = "http://www.w3.org/TR/1999/REC-xpath-19991116";
/*     */   
/*     */   protected String engineGetURI()
/*     */   {
/*  61 */     return "http://www.w3.org/TR/1999/REC-xpath-19991116";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, Transform _transformObject)
/*     */     throws TransformationException
/*     */   {
/*     */     try
/*     */     {
/*  87 */       CachedXPathAPIHolder.setDoc(_transformObject.getElement().getOwnerDocument());
/*     */       
/*     */ 
/*     */ 
/*  91 */       Element xpathElement = XMLUtils.selectDsNode(
/*  92 */         _transformObject.getElement().getFirstChild(), 
/*  93 */         "XPath", 0);
/*     */       
/*  95 */       if (xpathElement == null) {
/*  96 */         Object[] exArgs = { "ds:XPath", "Transform" };
/*     */         
/*  98 */         throw new TransformationException("xml.WrongContent", exArgs);
/*     */       }
/* 100 */       Node xpathnode = xpathElement.getChildNodes().item(0);
/* 101 */       String str = CachedXPathFuncHereAPI.getStrFromNode(xpathnode);
/* 102 */       input.setNeedsToBeExpanded(needsCircunvent(str));
/* 103 */       if (xpathnode == null) {
/* 104 */         throw new DOMException((short)3, 
/* 105 */           "Text must be in ds:Xpath");
/*     */       }
/*     */       
/*     */ 
/* 109 */       input.addNodeFilter(new XPathNodeFilter(xpathElement, xpathnode, str));
/* 110 */       input.setNodeSet(true);
/* 111 */       return input;
/*     */     } catch (DOMException ex) {
/* 113 */       throw new TransformationException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean needsCircunvent(String str)
/*     */   {
/* 124 */     return (str.indexOf("namespace") != -1) || (str.indexOf("name()") != -1);
/*     */   }
/*     */   
/*     */   static class XPathNodeFilter implements NodeFilter
/*     */   {
/*     */     PrefixResolverDefault prefixResolver;
/* 130 */     CachedXPathFuncHereAPI xPathFuncHereAPI = new CachedXPathFuncHereAPI(CachedXPathAPIHolder.getCachedXPathAPI());
/*     */     Node xpathnode;
/*     */     String str;
/*     */     
/*     */     XPathNodeFilter(Element xpathElement, Node xpathnode, String str) {
/* 135 */       this.xpathnode = xpathnode;
/* 136 */       this.str = str;
/* 137 */       this.prefixResolver = new PrefixResolverDefault(xpathElement);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public int isNodeInclude(Node currentNode)
/*     */     {
/*     */       try
/*     */       {
/* 146 */         XObject includeInResult = this.xPathFuncHereAPI.eval(currentNode, 
/* 147 */           this.xpathnode, this.str, this.prefixResolver);
/* 148 */         if (includeInResult.bool())
/* 149 */           return 1;
/* 150 */         return 0;
/*     */       } catch (TransformerException e) {
/* 152 */         Object[] eArgs = { currentNode };
/* 153 */         throw new XMLSecurityRuntimeException(
/* 154 */           "signature.Transform.node", eArgs, e);
/*     */       } catch (Exception e) {
/* 156 */         Object[] eArgs = { currentNode, new Short(currentNode.getNodeType()) };
/* 157 */         throw new XMLSecurityRuntimeException(
/* 158 */           "signature.Transform.nodeAndType", eArgs, e);
/*     */       }
/*     */     }
/*     */     
/* 162 */     public int isNodeIncludeDO(Node n, int level) { return isNodeInclude(n); }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\transforms\implementations\TransformXPath.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */