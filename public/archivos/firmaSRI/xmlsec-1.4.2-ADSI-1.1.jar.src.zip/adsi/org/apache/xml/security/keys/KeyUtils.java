/*    */ package adsi.org.apache.xml.security.keys;
/*    */ 
/*    */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*    */ import adsi.org.apache.xml.security.keys.content.KeyName;
/*    */ import adsi.org.apache.xml.security.keys.content.KeyValue;
/*    */ import adsi.org.apache.xml.security.keys.content.MgmtData;
/*    */ import adsi.org.apache.xml.security.keys.content.X509Data;
/*    */ import java.io.PrintStream;
/*    */ import java.security.PublicKey;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KeyUtils
/*    */ {
/*    */   public static void prinoutKeyInfo(KeyInfo ki, PrintStream os)
/*    */     throws XMLSecurityException
/*    */   {
/* 53 */     for (int i = 0; i < ki.lengthKeyName(); i++) {
/* 54 */       KeyName x = ki.itemKeyName(i);
/*    */       
/* 56 */       os.println("KeyName(" + i + ")=\"" + x.getKeyName() + "\"");
/*    */     }
/*    */     
/* 59 */     for (int i = 0; i < ki.lengthKeyValue(); i++) {
/* 60 */       KeyValue x = ki.itemKeyValue(i);
/* 61 */       PublicKey pk = x.getPublicKey();
/*    */       
/* 63 */       os.println("KeyValue Nr. " + i);
/* 64 */       os.println(pk);
/*    */     }
/*    */     
/* 67 */     for (int i = 0; i < ki.lengthMgmtData(); i++) {
/* 68 */       MgmtData x = ki.itemMgmtData(i);
/*    */       
/* 70 */       os.println("MgmtData(" + i + ")=\"" + x.getMgmtData() + "\"");
/*    */     }
/*    */     
/* 73 */     for (int i = 0; i < ki.lengthX509Data(); i++) {
/* 74 */       X509Data x = ki.itemX509Data(i);
/*    */       
/* 76 */       os.println("X509Data(" + i + ")=\"" + (x.containsCertificate() ? 
/* 77 */         "Certificate " : 
/* 78 */         "") + (x
/* 79 */         .containsIssuerSerial() ? 
/* 80 */         "IssuerSerial " : 
/* 81 */         "") + "\"");
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\KeyUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */