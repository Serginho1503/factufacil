/*    */ package adsi.org.apache.xml.security.transforms.implementations;
/*    */ 
/*    */ import adsi.org.apache.xml.security.c14n.CanonicalizationException;
/*    */ import adsi.org.apache.xml.security.c14n.implementations.Canonicalizer11_WithComments;
/*    */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*    */ import adsi.org.apache.xml.security.transforms.Transform;
/*    */ import adsi.org.apache.xml.security.transforms.TransformSpi;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransformC14N11_WithComments
/*    */   extends TransformSpi
/*    */ {
/*    */   protected String engineGetURI()
/*    */   {
/* 37 */     return "http://www.w3.org/2006/12/xml-c14n11#WithComments";
/*    */   }
/*    */   
/*    */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, Transform transform)
/*    */     throws CanonicalizationException
/*    */   {
/* 43 */     return enginePerformTransform(input, null, transform);
/*    */   }
/*    */   
/*    */ 
/*    */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, OutputStream os, Transform transform)
/*    */     throws CanonicalizationException
/*    */   {
/* 50 */     Canonicalizer11_WithComments c14n = new Canonicalizer11_WithComments();
/* 51 */     if (os != null) {
/* 52 */       c14n.setWriter(os);
/*    */     }
/*    */     
/* 55 */     byte[] result = (byte[])null;
/* 56 */     result = c14n.engineCanonicalize(input);
/* 57 */     XMLSignatureInput output = new XMLSignatureInput(result);
/* 58 */     if (os != null) {
/* 59 */       output.setOutputStream(os);
/*    */     }
/* 61 */     return output;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\transforms\implementations\TransformC14N11_WithComments.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */