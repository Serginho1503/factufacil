/*     */ package adsi.org.apache.xml.security.exceptions;
/*     */ 
/*     */ import adsi.org.apache.xml.security.utils.I18n;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.text.MessageFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLSecurityRuntimeException
/*     */   extends RuntimeException
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  50 */   protected Exception originalException = null;
/*     */   
/*     */ 
/*     */ 
/*     */   protected String msgID;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSecurityRuntimeException()
/*     */   {
/*  61 */     super("Missing message string");
/*     */     
/*  63 */     this.msgID = null;
/*  64 */     this.originalException = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSecurityRuntimeException(String _msgID)
/*     */   {
/*  74 */     super(I18n.getExceptionMessage(_msgID));
/*     */     
/*  76 */     this.msgID = _msgID;
/*  77 */     this.originalException = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSecurityRuntimeException(String _msgID, Object[] exArgs)
/*     */   {
/*  88 */     super(MessageFormat.format(I18n.getExceptionMessage(_msgID), exArgs));
/*     */     
/*  90 */     this.msgID = _msgID;
/*  91 */     this.originalException = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSecurityRuntimeException(Exception _originalException)
/*     */   {
/* 105 */     super("Missing message ID to locate message string in resource bundle \"adsi/org/apache/xml/security/resource/xmlsecurity\". Original Exception was a " + _originalException.getClass().getName() + " and message " + _originalException.getMessage());
/*     */     
/* 107 */     this.originalException = _originalException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSecurityRuntimeException(String _msgID, Exception _originalException)
/*     */   {
/* 118 */     super(I18n.getExceptionMessage(_msgID, _originalException));
/*     */     
/* 120 */     this.msgID = _msgID;
/* 121 */     this.originalException = _originalException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSecurityRuntimeException(String _msgID, Object[] exArgs, Exception _originalException)
/*     */   {
/* 134 */     super(MessageFormat.format(I18n.getExceptionMessage(_msgID), exArgs));
/*     */     
/* 136 */     this.msgID = _msgID;
/* 137 */     this.originalException = _originalException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMsgID()
/*     */   {
/* 147 */     if (this.msgID == null) {
/* 148 */       return "Missing message ID";
/*     */     }
/* 150 */     return this.msgID;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 156 */     String s = getClass().getName();
/* 157 */     String message = super.getLocalizedMessage();
/*     */     
/* 159 */     if (message != null) {
/* 160 */       message = s + ": " + message;
/*     */     } else {
/* 162 */       message = s;
/*     */     }
/*     */     
/* 165 */     if (this.originalException != null) {
/* 166 */       message = 
/* 167 */         message + "\nOriginal Exception was " + this.originalException.toString();
/*     */     }
/*     */     
/* 170 */     return message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printStackTrace()
/*     */   {
/* 179 */     synchronized (System.err) {
/* 180 */       super.printStackTrace(System.err);
/*     */       
/* 182 */       if (this.originalException != null) {
/* 183 */         this.originalException.printStackTrace(System.err);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printStackTrace(PrintWriter printwriter)
/*     */   {
/* 195 */     super.printStackTrace(printwriter);
/*     */     
/* 197 */     if (this.originalException != null) {
/* 198 */       this.originalException.printStackTrace(printwriter);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printStackTrace(PrintStream printstream)
/*     */   {
/* 209 */     super.printStackTrace(printstream);
/*     */     
/* 211 */     if (this.originalException != null) {
/* 212 */       this.originalException.printStackTrace(printstream);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Exception getOriginalException()
/*     */   {
/* 222 */     return this.originalException;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\exceptions\XMLSecurityRuntimeException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */