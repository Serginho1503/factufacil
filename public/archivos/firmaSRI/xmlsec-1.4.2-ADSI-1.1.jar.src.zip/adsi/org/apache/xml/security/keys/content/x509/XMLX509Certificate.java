/*     */ package adsi.org.apache.xml.security.keys.content.x509;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.CertificateEncodingException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509Certificate;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLX509Certificate
/*     */   extends SignatureElementProxy
/*     */   implements XMLX509DataContent
/*     */ {
/*     */   public static final String JCA_CERT_ID = "X.509";
/*     */   
/*     */   public XMLX509Certificate(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  51 */     super(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509Certificate(Document doc, byte[] certificateBytes)
/*     */   {
/*  62 */     super(doc);
/*     */     
/*  64 */     addBase64Text(certificateBytes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509Certificate(Document doc, X509Certificate x509certificate)
/*     */     throws XMLSecurityException
/*     */   {
/*  77 */     super(doc);
/*     */     try
/*     */     {
/*  80 */       addBase64Text(x509certificate.getEncoded());
/*     */     } catch (CertificateEncodingException ex) {
/*  82 */       throw new XMLSecurityException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getCertificateBytes()
/*     */     throws XMLSecurityException
/*     */   {
/*  93 */     return getBytesFromTextChild();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Certificate getX509Certificate()
/*     */     throws XMLSecurityException
/*     */   {
/*     */     try
/*     */     {
/* 105 */       byte[] certbytes = getCertificateBytes();
/* 106 */       CertificateFactory certFact = 
/* 107 */         CertificateFactory.getInstance("X.509");
/* 108 */       X509Certificate cert = 
/* 109 */         (X509Certificate)certFact
/* 110 */         .generateCertificate(new ByteArrayInputStream(certbytes));
/*     */       
/* 112 */       if (cert != null) {
/* 113 */         return cert;
/*     */       }
/*     */       
/* 116 */       return null;
/*     */     } catch (CertificateException ex) {
/* 118 */       throw new XMLSecurityException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PublicKey getPublicKey()
/*     */     throws XMLSecurityException
/*     */   {
/* 130 */     X509Certificate cert = getX509Certificate();
/*     */     
/* 132 */     if (cert != null) {
/* 133 */       return cert.getPublicKey();
/*     */     }
/*     */     
/* 136 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 142 */     if (obj == null) {
/* 143 */       return false;
/*     */     }
/* 145 */     if (!getClass().getName().equals(obj.getClass().getName())) {
/* 146 */       return false;
/*     */     }
/* 148 */     XMLX509Certificate other = (XMLX509Certificate)obj;
/*     */     
/*     */     try
/*     */     {
/* 152 */       return MessageDigest.isEqual(
/* 153 */         other.getCertificateBytes(), getCertificateBytes());
/*     */     } catch (XMLSecurityException ex) {}
/* 155 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 162 */     return 72;
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 167 */     return "X509Certificate";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\content\x509\XMLX509Certificate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */