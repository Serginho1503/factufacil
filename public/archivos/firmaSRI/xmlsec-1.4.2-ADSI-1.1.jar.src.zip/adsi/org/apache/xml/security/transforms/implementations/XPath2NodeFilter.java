/*     */ package adsi.org.apache.xml.security.transforms.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.signature.NodeFilter;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class XPath2NodeFilter
/*     */   implements NodeFilter
/*     */ {
/*     */   boolean hasUnionNodes;
/*     */   boolean hasSubstractNodes;
/*     */   boolean hasIntersectNodes;
/*     */   Set unionNodes;
/*     */   Set substractNodes;
/*     */   Set intersectNodes;
/*     */   
/*     */   XPath2NodeFilter(Set unionNodes, Set substractNodes, Set intersectNodes)
/*     */   {
/* 193 */     this.unionNodes = unionNodes;
/* 194 */     this.hasUnionNodes = (!unionNodes.isEmpty());
/* 195 */     this.substractNodes = substractNodes;
/* 196 */     this.hasSubstractNodes = (!substractNodes.isEmpty());
/* 197 */     this.intersectNodes = intersectNodes;
/* 198 */     this.hasIntersectNodes = (!intersectNodes.isEmpty());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int isNodeInclude(Node currentNode)
/*     */   {
/* 209 */     int result = 1;
/*     */     
/* 211 */     if ((this.hasSubstractNodes) && (rooted(currentNode, this.substractNodes))) {
/* 212 */       result = -1;
/* 213 */     } else if ((this.hasIntersectNodes) && (!rooted(currentNode, this.intersectNodes))) {
/* 214 */       result = 0;
/*     */     }
/*     */     
/*     */ 
/* 218 */     if (result == 1)
/* 219 */       return 1;
/* 220 */     if (this.hasUnionNodes) {
/* 221 */       if (rooted(currentNode, this.unionNodes)) {
/* 222 */         return 1;
/*     */       }
/* 224 */       result = 0;
/*     */     }
/* 226 */     return result;
/*     */   }
/*     */   
/* 229 */   int inSubstract = -1;
/* 230 */   int inIntersect = -1;
/* 231 */   int inUnion = -1;
/*     */   
/* 233 */   public int isNodeIncludeDO(Node n, int level) { int result = 1;
/* 234 */     if (this.hasSubstractNodes) {
/* 235 */       if ((this.inSubstract == -1) || (level <= this.inSubstract)) {
/* 236 */         if (inList(n, this.substractNodes)) {
/* 237 */           this.inSubstract = level;
/*     */         } else {
/* 239 */           this.inSubstract = -1;
/*     */         }
/*     */       }
/* 242 */       if (this.inSubstract != -1) {
/* 243 */         result = -1;
/*     */       }
/*     */     }
/* 246 */     if ((result != -1) && 
/* 247 */       (this.hasIntersectNodes) && (
/* 248 */       (this.inIntersect == -1) || (level <= this.inIntersect))) {
/* 249 */       if (!inList(n, this.intersectNodes)) {
/* 250 */         this.inIntersect = -1;
/* 251 */         result = 0;
/*     */       } else {
/* 253 */         this.inIntersect = level;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 259 */     if (level <= this.inUnion)
/* 260 */       this.inUnion = -1;
/* 261 */     if (result == 1)
/* 262 */       return 1;
/* 263 */     if (this.hasUnionNodes) {
/* 264 */       if ((this.inUnion == -1) && (inList(n, this.unionNodes))) {
/* 265 */         this.inUnion = level;
/*     */       }
/* 267 */       if (this.inUnion != -1)
/* 268 */         return 1;
/* 269 */       result = 0;
/*     */     }
/*     */     
/* 272 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean rooted(Node currentNode, Set nodeList)
/*     */   {
/* 283 */     if (nodeList.contains(currentNode)) {
/* 284 */       return true;
/*     */     }
/* 286 */     Iterator it = nodeList.iterator();
/* 287 */     while (it.hasNext()) {
/* 288 */       Node rootNode = (Node)it.next();
/* 289 */       if (XMLUtils.isDescendantOrSelf(rootNode, currentNode)) {
/* 290 */         return true;
/*     */       }
/*     */     }
/* 293 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean inList(Node currentNode, Set nodeList)
/*     */   {
/* 304 */     return nodeList.contains(currentNode);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\transforms\implementations\XPath2NodeFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */