/*     */ package adsi.org.apache.xml.security.keys.keyresolver.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.keys.content.x509.XMLX509Certificate;
/*     */ import adsi.org.apache.xml.security.keys.keyresolver.KeyResolverException;
/*     */ import adsi.org.apache.xml.security.keys.keyresolver.KeyResolverSpi;
/*     */ import adsi.org.apache.xml.security.keys.storage.StorageResolver;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.crypto.SecretKey;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class X509CertificateResolver
/*     */   extends KeyResolverSpi
/*     */ {
/*  47 */   static Log log = LogFactory.getLog(X509CertificateResolver.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PublicKey engineLookupAndResolvePublicKey(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/*  64 */     X509Certificate cert = engineLookupResolveX509Certificate(element, 
/*  65 */       BaseURI, storage);
/*     */     
/*  67 */     if (cert != null) {
/*  68 */       return cert.getPublicKey();
/*     */     }
/*     */     
/*  71 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Certificate engineLookupResolveX509Certificate(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/*     */     try
/*     */     {
/*  88 */       Element[] els = XMLUtils.selectDsNodes(element.getFirstChild(), 
/*  89 */         "X509Certificate");
/*  90 */       if ((els == null) || (els.length == 0)) {
/*  91 */         Element el = XMLUtils.selectDsNode(element.getFirstChild(), 
/*  92 */           "X509Data", 0);
/*  93 */         if (el != null) {
/*  94 */           return engineLookupResolveX509Certificate(el, BaseURI, storage);
/*     */         }
/*  96 */         return null;
/*     */       }
/*     */       
/*     */ 
/* 100 */       for (int i = 0; i < els.length; i++) {
/* 101 */         XMLX509Certificate xmlCert = new XMLX509Certificate(els[i], BaseURI);
/* 102 */         X509Certificate cert = xmlCert.getX509Certificate();
/* 103 */         if (cert != null) {
/* 104 */           return cert;
/*     */         }
/*     */       }
/* 107 */       return null;
/*     */     } catch (XMLSecurityException ex) {
/* 109 */       log.debug("XMLSecurityException", ex);
/*     */       
/* 111 */       throw new KeyResolverException("generic.EmptyMessage", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SecretKey engineLookupAndResolveSecretKey(Element element, String BaseURI, StorageResolver storage)
/*     */   {
/* 126 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\keyresolver\implementations\X509CertificateResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */