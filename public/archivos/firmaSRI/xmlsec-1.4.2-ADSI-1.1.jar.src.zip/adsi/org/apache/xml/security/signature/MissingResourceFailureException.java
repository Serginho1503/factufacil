/*     */ package adsi.org.apache.xml.security.signature;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MissingResourceFailureException
/*     */   extends XMLSignatureException
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  39 */   Reference uninitializedReference = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MissingResourceFailureException(String _msgID, Reference reference)
/*     */   {
/*  49 */     super(_msgID);
/*     */     
/*  51 */     this.uninitializedReference = reference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MissingResourceFailureException(String _msgID, Object[] exArgs, Reference reference)
/*     */   {
/*  65 */     super(_msgID, exArgs);
/*     */     
/*  67 */     this.uninitializedReference = reference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MissingResourceFailureException(String _msgID, Exception _originalException, Reference reference)
/*     */   {
/*  82 */     super(_msgID, _originalException);
/*     */     
/*  84 */     this.uninitializedReference = reference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MissingResourceFailureException(String _msgID, Object[] exArgs, Exception _originalException, Reference reference)
/*     */   {
/* 100 */     super(_msgID, exArgs, _originalException);
/*     */     
/* 102 */     this.uninitializedReference = reference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReference(Reference reference)
/*     */   {
/* 112 */     this.uninitializedReference = reference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Reference getReference()
/*     */   {
/* 125 */     return this.uninitializedReference;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\signature\MissingResourceFailureException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */