/*     */ package adsi.org.apache.xml.security.keys.keyresolver;
/*     */ 
/*     */ import adsi.org.apache.xml.security.keys.storage.StorageResolver;
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.crypto.SecretKey;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class KeyResolverSpi
/*     */ {
/*     */   public boolean engineCanResolve(Element element, String BaseURI, StorageResolver storage)
/*     */   {
/*  54 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PublicKey engineResolvePublicKey(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/*  70 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PublicKey engineLookupAndResolvePublicKey(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/*  86 */     KeyResolverSpi tmp = cloneIfNeeded();
/*  87 */     if (!tmp.engineCanResolve(element, BaseURI, storage))
/*  88 */       return null;
/*  89 */     return tmp.engineResolvePublicKey(element, BaseURI, storage);
/*     */   }
/*     */   
/*     */   private KeyResolverSpi cloneIfNeeded() throws KeyResolverException {
/*  93 */     KeyResolverSpi tmp = this;
/*  94 */     if (this.globalResolver) {
/*     */       try {
/*  96 */         tmp = (KeyResolverSpi)getClass().newInstance();
/*     */       } catch (InstantiationException e) {
/*  98 */         throw new KeyResolverException("", e);
/*     */       } catch (IllegalAccessException e) {
/* 100 */         throw new KeyResolverException("", e);
/*     */       }
/*     */     }
/* 103 */     return tmp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Certificate engineResolveX509Certificate(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/* 119 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Certificate engineLookupResolveX509Certificate(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/* 135 */     KeyResolverSpi tmp = cloneIfNeeded();
/* 136 */     if (!tmp.engineCanResolve(element, BaseURI, storage))
/* 137 */       return null;
/* 138 */     return tmp.engineResolveX509Certificate(element, BaseURI, storage);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SecretKey engineResolveSecretKey(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/* 154 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SecretKey engineLookupAndResolveSecretKey(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/* 170 */     KeyResolverSpi tmp = cloneIfNeeded();
/* 171 */     if (!tmp.engineCanResolve(element, BaseURI, storage))
/* 172 */       return null;
/* 173 */     return tmp.engineResolveSecretKey(element, BaseURI, storage);
/*     */   }
/*     */   
/*     */ 
/* 177 */   protected Map _properties = null;
/*     */   
/* 179 */   protected boolean globalResolver = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void engineSetProperty(String key, String value)
/*     */   {
/* 188 */     if (this._properties == null)
/* 189 */       this._properties = new HashMap();
/* 190 */     this._properties.put(key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String engineGetProperty(String key)
/*     */   {
/* 200 */     if (this._properties == null) {
/* 201 */       return null;
/*     */     }
/* 203 */     return (String)this._properties.get(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean understandsProperty(String propertyToTest)
/*     */   {
/* 213 */     if (this._properties == null) {
/* 214 */       return false;
/*     */     }
/* 216 */     return this._properties.get(propertyToTest) != null;
/*     */   }
/*     */   
/* 219 */   public void setGlobalResolver(boolean globalResolver) { this.globalResolver = globalResolver; }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\keyresolver\KeyResolverSpi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */