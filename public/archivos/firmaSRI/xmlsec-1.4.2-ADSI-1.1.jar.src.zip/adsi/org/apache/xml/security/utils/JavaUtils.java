/*     */ package adsi.org.apache.xml.security.utils;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaUtils
/*     */ {
/*  34 */   static Log log = LogFactory.getLog(JavaUtils.class.getName());
/*     */   
/*     */   /* Error */
/*     */   public static byte[] getBytesFromFile(String fileName)
/*     */     throws java.io.FileNotFoundException, IOException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: checkcast 38	[B
/*     */     //   4: astore_1
/*     */     //   5: new 40	java/io/FileInputStream
/*     */     //   8: dup
/*     */     //   9: aload_0
/*     */     //   10: invokespecial 42	java/io/FileInputStream:<init>	(Ljava/lang/String;)V
/*     */     //   13: astore_2
/*     */     //   14: new 45	adsi/org/apache/xml/security/utils/UnsyncByteArrayOutputStream
/*     */     //   17: dup
/*     */     //   18: invokespecial 47	adsi/org/apache/xml/security/utils/UnsyncByteArrayOutputStream:<init>	()V
/*     */     //   21: astore_3
/*     */     //   22: sipush 1024
/*     */     //   25: newarray <illegal type>
/*     */     //   27: astore 4
/*     */     //   29: goto +12 -> 41
/*     */     //   32: aload_3
/*     */     //   33: aload 4
/*     */     //   35: iconst_0
/*     */     //   36: iload 5
/*     */     //   38: invokevirtual 48	adsi/org/apache/xml/security/utils/UnsyncByteArrayOutputStream:write	([BII)V
/*     */     //   41: aload_2
/*     */     //   42: aload 4
/*     */     //   44: invokevirtual 52	java/io/FileInputStream:read	([B)I
/*     */     //   47: dup
/*     */     //   48: istore 5
/*     */     //   50: ifgt -18 -> 32
/*     */     //   53: aload_3
/*     */     //   54: invokevirtual 56	adsi/org/apache/xml/security/utils/UnsyncByteArrayOutputStream:toByteArray	()[B
/*     */     //   57: astore_1
/*     */     //   58: goto +12 -> 70
/*     */     //   61: astore 6
/*     */     //   63: aload_2
/*     */     //   64: invokevirtual 60	java/io/FileInputStream:close	()V
/*     */     //   67: aload 6
/*     */     //   69: athrow
/*     */     //   70: aload_2
/*     */     //   71: invokevirtual 60	java/io/FileInputStream:close	()V
/*     */     //   74: aload_1
/*     */     //   75: areturn
/*     */     // Line number table:
/*     */     //   Java source line #52	-> byte code offset #0
/*     */     //   Java source line #54	-> byte code offset #5
/*     */     //   Java source line #56	-> byte code offset #14
/*     */     //   Java source line #57	-> byte code offset #22
/*     */     //   Java source line #60	-> byte code offset #29
/*     */     //   Java source line #61	-> byte code offset #32
/*     */     //   Java source line #60	-> byte code offset #41
/*     */     //   Java source line #64	-> byte code offset #53
/*     */     //   Java source line #65	-> byte code offset #61
/*     */     //   Java source line #66	-> byte code offset #63
/*     */     //   Java source line #67	-> byte code offset #67
/*     */     //   Java source line #66	-> byte code offset #70
/*     */     //   Java source line #69	-> byte code offset #74
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	76	0	fileName	String
/*     */     //   4	71	1	refBytes	byte[]
/*     */     //   13	58	2	fisRef	java.io.FileInputStream
/*     */     //   21	33	3	baos	UnsyncByteArrayOutputStream
/*     */     //   27	16	4	buf	byte[]
/*     */     //   32	5	5	len	int
/*     */     //   48	3	5	len	int
/*     */     //   61	7	6	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   14	61	61	finally
/*     */   }
/*     */   
/*     */   public static void writeBytesToFilename(String filename, byte[] bytes)
/*     */   {
/*  80 */     FileOutputStream fos = null;
/*     */     try {
/*  82 */       if ((filename != null) && (bytes != null)) {
/*  83 */         File f = new File(filename);
/*     */         
/*  85 */         fos = new FileOutputStream(f);
/*     */         
/*  87 */         fos.write(bytes);
/*  88 */         fos.close();
/*     */       } else {
/*  90 */         log.debug("writeBytesToFilename got null byte[] pointed");
/*     */       }
/*     */     } catch (IOException ex) {
/*  93 */       if (fos != null) {
/*     */         try {
/*  95 */           fos.close();
/*     */         }
/*     */         catch (IOException localIOException1) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] getBytesFromStream(InputStream inputStream)
/*     */     throws IOException
/*     */   {
/* 114 */     byte[] refBytes = (byte[])null;
/*     */     
/* 116 */     UnsyncByteArrayOutputStream baos = new UnsyncByteArrayOutputStream();
/* 117 */     byte[] buf = new byte['Ѐ'];
/*     */     
/*     */     int len;
/* 120 */     while ((len = inputStream.read(buf)) > 0) { int len;
/* 121 */       baos.write(buf, 0, len);
/*     */     }
/*     */     
/* 124 */     refBytes = baos.toByteArray();
/* 125 */     return refBytes;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\utils\JavaUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */