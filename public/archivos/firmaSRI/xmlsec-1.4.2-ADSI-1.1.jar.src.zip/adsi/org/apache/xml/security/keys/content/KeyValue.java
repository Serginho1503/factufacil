/*     */ package adsi.org.apache.xml.security.keys.content;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.keys.content.keyvalues.DSAKeyValue;
/*     */ import adsi.org.apache.xml.security.keys.content.keyvalues.RSAKeyValue;
/*     */ import adsi.org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.security.PublicKey;
/*     */ import java.security.interfaces.DSAPublicKey;
/*     */ import java.security.interfaces.RSAPublicKey;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyValue
/*     */   extends SignatureElementProxy
/*     */   implements KeyInfoContent
/*     */ {
/*     */   public KeyValue(Document doc, DSAKeyValue dsaKeyValue)
/*     */   {
/*  51 */     super(doc);
/*     */     
/*  53 */     XMLUtils.addReturnToElement(this._constructionElement);
/*  54 */     this._constructionElement.appendChild(dsaKeyValue.getElement());
/*  55 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyValue(Document doc, RSAKeyValue rsaKeyValue)
/*     */   {
/*  66 */     super(doc);
/*     */     
/*  68 */     XMLUtils.addReturnToElement(this._constructionElement);
/*  69 */     this._constructionElement.appendChild(rsaKeyValue.getElement());
/*  70 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyValue(Document doc, Element unknownKeyValue)
/*     */   {
/*  81 */     super(doc);
/*     */     
/*  83 */     XMLUtils.addReturnToElement(this._constructionElement);
/*  84 */     this._constructionElement.appendChild(unknownKeyValue);
/*  85 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyValue(Document doc, PublicKey pk)
/*     */   {
/*  96 */     super(doc);
/*     */     
/*  98 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */     
/* 100 */     if ((pk instanceof DSAPublicKey)) {
/* 101 */       DSAKeyValue dsa = new DSAKeyValue(this._doc, pk);
/*     */       
/* 103 */       this._constructionElement.appendChild(dsa.getElement());
/* 104 */       XMLUtils.addReturnToElement(this._constructionElement);
/* 105 */     } else if ((pk instanceof RSAPublicKey)) {
/* 106 */       RSAKeyValue rsa = new RSAKeyValue(this._doc, pk);
/*     */       
/* 108 */       this._constructionElement.appendChild(rsa.getElement());
/* 109 */       XMLUtils.addReturnToElement(this._constructionElement);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyValue(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 122 */     super(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PublicKey getPublicKey()
/*     */     throws XMLSecurityException
/*     */   {
/* 133 */     Element rsa = XMLUtils.selectDsNode(
/* 134 */       this._constructionElement.getFirstChild(), 
/* 135 */       "RSAKeyValue", 0);
/*     */     
/* 137 */     if (rsa != null) {
/* 138 */       RSAKeyValue kv = new RSAKeyValue(rsa, this._baseURI);
/* 139 */       return kv.getPublicKey();
/*     */     }
/*     */     
/* 142 */     Element dsa = XMLUtils.selectDsNode(
/* 143 */       this._constructionElement.getFirstChild(), 
/* 144 */       "DSAKeyValue", 0);
/*     */     
/* 146 */     if (dsa != null) {
/* 147 */       DSAKeyValue kv = new DSAKeyValue(dsa, this._baseURI);
/* 148 */       return kv.getPublicKey();
/*     */     }
/*     */     
/* 151 */     return null;
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 156 */     return "KeyValue";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\content\KeyValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */