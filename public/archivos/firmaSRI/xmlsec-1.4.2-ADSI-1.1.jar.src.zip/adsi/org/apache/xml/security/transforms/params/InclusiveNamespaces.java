/*     */ package adsi.org.apache.xml.security.transforms.params;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.transforms.TransformParam;
/*     */ import adsi.org.apache.xml.security.utils.ElementProxy;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.SortedSet;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.TreeSet;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InclusiveNamespaces
/*     */   extends ElementProxy
/*     */   implements TransformParam
/*     */ {
/*     */   public static final String _TAG_EC_INCLUSIVENAMESPACES = "InclusiveNamespaces";
/*     */   public static final String _ATT_EC_PREFIXLIST = "PrefixList";
/*     */   public static final String ExclusiveCanonicalizationNamespace = "http://www.w3.org/2001/10/xml-exc-c14n#";
/*     */   
/*     */   public InclusiveNamespaces(Document doc, String prefixList)
/*     */   {
/*  65 */     this(doc, prefixStr2Set(prefixList));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InclusiveNamespaces(Document doc, Set prefixes)
/*     */   {
/*  76 */     super(doc);
/*     */     
/*  78 */     StringBuffer sb = new StringBuffer();
/*  79 */     SortedSet prefixList = new TreeSet(prefixes);
/*     */     
/*     */ 
/*  82 */     Iterator it = prefixList.iterator();
/*     */     
/*  84 */     while (it.hasNext()) {
/*  85 */       String prefix = (String)it.next();
/*     */       
/*  87 */       if (prefix.equals("xmlns")) {
/*  88 */         sb.append("#default ");
/*     */       } else {
/*  90 */         sb.append(prefix + " ");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  95 */     this._constructionElement.setAttributeNS(null, "PrefixList", 
/*  96 */       sb.toString().trim());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getInclusiveNamespaces()
/*     */   {
/* 105 */     return 
/* 106 */       this._constructionElement.getAttributeNS(null, "PrefixList");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InclusiveNamespaces(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 118 */     super(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SortedSet prefixStr2Set(String inclusiveNamespaces)
/*     */   {
/* 140 */     SortedSet prefixes = new TreeSet();
/*     */     
/* 142 */     if ((inclusiveNamespaces == null) || 
/* 143 */       (inclusiveNamespaces.length() == 0)) {
/* 144 */       return prefixes;
/*     */     }
/*     */     
/* 147 */     StringTokenizer st = new StringTokenizer(inclusiveNamespaces, " \t\r\n");
/*     */     
/* 149 */     while (st.hasMoreTokens()) {
/* 150 */       String prefix = st.nextToken();
/*     */       
/* 152 */       if (prefix.equals("#default")) {
/* 153 */         prefixes.add("xmlns");
/*     */       } else {
/* 155 */         prefixes.add(prefix);
/*     */       }
/*     */     }
/*     */     
/* 159 */     return prefixes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBaseNamespace()
/*     */   {
/* 168 */     return "http://www.w3.org/2001/10/xml-exc-c14n#";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBaseLocalName()
/*     */   {
/* 177 */     return "InclusiveNamespaces";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\transforms\params\InclusiveNamespaces.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */