/*     */ package adsi.org.apache.xml.security.c14n;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.AlgorithmAlreadyRegisteredException;
/*     */ import adsi.org.apache.xml.security.utils.IgnoreAllErrorHandler;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Canonicalizer
/*     */ {
/*     */   public static final String ENCODING = "UTF8";
/*     */   public static final String XPATH_C14N_WITH_COMMENTS_SINGLE_NODE = "(.//. | .//@* | .//namespace::*)";
/*     */   public static final String ALGO_ID_C14N_OMIT_COMMENTS = "http://www.w3.org/TR/2001/REC-xml-c14n-20010315";
/*     */   public static final String ALGO_ID_C14N_WITH_COMMENTS = "http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments";
/*     */   public static final String ALGO_ID_C14N_EXCL_OMIT_COMMENTS = "http://www.w3.org/2001/10/xml-exc-c14n#";
/*     */   public static final String ALGO_ID_C14N_EXCL_WITH_COMMENTS = "http://www.w3.org/2001/10/xml-exc-c14n#WithComments";
/*     */   public static final String ALGO_ID_C14N11_OMIT_COMMENTS = "http://www.w3.org/2006/12/xml-c14n11";
/*     */   public static final String ALGO_ID_C14N11_WITH_COMMENTS = "http://www.w3.org/2006/12/xml-c14n11#WithComments";
/*  82 */   static boolean _alreadyInitialized = false;
/*  83 */   static Map _canonicalizerHash = null;
/*     */   
/*  85 */   protected CanonicalizerSpi canonicalizerSpi = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void init()
/*     */   {
/*  93 */     if (!_alreadyInitialized) {
/*  94 */       _canonicalizerHash = new HashMap(10);
/*  95 */       _alreadyInitialized = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Canonicalizer(String algorithmURI)
/*     */     throws InvalidCanonicalizerException
/*     */   {
/*     */     try
/*     */     {
/* 109 */       Class implementingClass = getImplementingClass(algorithmURI);
/*     */       
/* 111 */       this.canonicalizerSpi = 
/* 112 */         ((CanonicalizerSpi)implementingClass.newInstance());
/* 113 */       this.canonicalizerSpi.reset = true;
/*     */     } catch (Exception e) {
/* 115 */       Object[] exArgs = { algorithmURI };
/*     */       
/* 117 */       throw new InvalidCanonicalizerException(
/* 118 */         "signature.Canonicalizer.UnknownCanonicalizer", exArgs);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final Canonicalizer getInstance(String algorithmURI)
/*     */     throws InvalidCanonicalizerException
/*     */   {
/* 132 */     Canonicalizer c14nizer = new Canonicalizer(algorithmURI);
/*     */     
/* 134 */     return c14nizer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void register(String algorithmURI, String implementingClass)
/*     */     throws AlgorithmAlreadyRegisteredException
/*     */   {
/* 148 */     Class registeredClass = getImplementingClass(algorithmURI);
/*     */     
/* 150 */     if (registeredClass != null) {
/* 151 */       Object[] exArgs = { algorithmURI, registeredClass };
/*     */       
/* 153 */       throw new AlgorithmAlreadyRegisteredException(
/* 154 */         "algorithm.alreadyRegistered", exArgs);
/*     */     }
/*     */     try
/*     */     {
/* 158 */       _canonicalizerHash.put(algorithmURI, Class.forName(implementingClass));
/*     */     } catch (ClassNotFoundException e) {
/* 160 */       throw new RuntimeException("c14n class not found");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getURI()
/*     */   {
/* 170 */     return this.canonicalizerSpi.engineGetURI();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getIncludeComments()
/*     */   {
/* 179 */     return this.canonicalizerSpi.engineGetIncludeComments();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] canonicalize(byte[] inputBytes)
/*     */     throws ParserConfigurationException, IOException, SAXException, CanonicalizationException
/*     */   {
/* 199 */     ByteArrayInputStream bais = new ByteArrayInputStream(inputBytes);
/* 200 */     InputSource in = new InputSource(bais);
/* 201 */     DocumentBuilderFactory dfactory = DocumentBuilderFactory.newInstance();
/*     */     
/* 203 */     dfactory.setNamespaceAware(true);
/*     */     
/*     */ 
/* 206 */     dfactory.setValidating(true);
/*     */     
/* 208 */     DocumentBuilder db = dfactory.newDocumentBuilder();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 232 */     db.setErrorHandler(new IgnoreAllErrorHandler());
/*     */     
/*     */ 
/* 235 */     Document document = db.parse(in);
/* 236 */     byte[] result = canonicalizeSubtree(document);
/*     */     
/* 238 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] canonicalizeSubtree(Node node)
/*     */     throws CanonicalizationException
/*     */   {
/* 251 */     return this.canonicalizerSpi.engineCanonicalizeSubTree(node);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] canonicalizeSubtree(Node node, String inclusiveNamespaces)
/*     */     throws CanonicalizationException
/*     */   {
/* 264 */     return this.canonicalizerSpi.engineCanonicalizeSubTree(node, 
/* 265 */       inclusiveNamespaces);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] canonicalizeXPathNodeSet(NodeList xpathNodeSet)
/*     */     throws CanonicalizationException
/*     */   {
/* 278 */     return this.canonicalizerSpi.engineCanonicalizeXPathNodeSet(xpathNodeSet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] canonicalizeXPathNodeSet(NodeList xpathNodeSet, String inclusiveNamespaces)
/*     */     throws CanonicalizationException
/*     */   {
/* 293 */     return this.canonicalizerSpi.engineCanonicalizeXPathNodeSet(xpathNodeSet, 
/* 294 */       inclusiveNamespaces);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] canonicalizeXPathNodeSet(Set xpathNodeSet)
/*     */     throws CanonicalizationException
/*     */   {
/* 306 */     return this.canonicalizerSpi.engineCanonicalizeXPathNodeSet(xpathNodeSet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] canonicalizeXPathNodeSet(Set xpathNodeSet, String inclusiveNamespaces)
/*     */     throws CanonicalizationException
/*     */   {
/* 319 */     return this.canonicalizerSpi.engineCanonicalizeXPathNodeSet(xpathNodeSet, 
/* 320 */       inclusiveNamespaces);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWriter(OutputStream os)
/*     */   {
/* 329 */     this.canonicalizerSpi.setWriter(os);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getImplementingCanonicalizerClass()
/*     */   {
/* 338 */     return this.canonicalizerSpi.getClass().getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Class getImplementingClass(String URI)
/*     */   {
/* 348 */     return (Class)_canonicalizerHash.get(URI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void notReset()
/*     */   {
/* 355 */     this.canonicalizerSpi.reset = false;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\c14n\Canonicalizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */