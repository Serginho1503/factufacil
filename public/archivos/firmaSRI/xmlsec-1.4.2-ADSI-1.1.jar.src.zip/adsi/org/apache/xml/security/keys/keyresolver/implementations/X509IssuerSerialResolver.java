/*     */ package adsi.org.apache.xml.security.keys.keyresolver.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.keys.content.X509Data;
/*     */ import adsi.org.apache.xml.security.keys.content.x509.XMLX509IssuerSerial;
/*     */ import adsi.org.apache.xml.security.keys.keyresolver.KeyResolverException;
/*     */ import adsi.org.apache.xml.security.keys.keyresolver.KeyResolverSpi;
/*     */ import adsi.org.apache.xml.security.keys.storage.StorageResolver;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureException;
/*     */ import java.math.BigInteger;
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.crypto.SecretKey;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class X509IssuerSerialResolver
/*     */   extends KeyResolverSpi
/*     */ {
/*  45 */   static Log log = LogFactory.getLog(
/*  46 */     X509IssuerSerialResolver.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PublicKey engineLookupAndResolvePublicKey(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/*  54 */     X509Certificate cert = engineLookupResolveX509Certificate(element, 
/*  55 */       BaseURI, storage);
/*     */     
/*  57 */     if (cert != null) {
/*  58 */       return cert.getPublicKey();
/*     */     }
/*     */     
/*  61 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public X509Certificate engineLookupResolveX509Certificate(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/*  68 */     if (log.isDebugEnabled()) {
/*  69 */       log.debug("Can I resolve " + element.getTagName() + "?");
/*     */     }
/*  71 */     X509Data x509data = null;
/*     */     try {
/*  73 */       x509data = new X509Data(element, BaseURI);
/*     */     } catch (XMLSignatureException ex) {
/*  75 */       log.debug("I can't");
/*  76 */       return null;
/*     */     } catch (XMLSecurityException ex) {
/*  78 */       log.debug("I can't");
/*  79 */       return null;
/*     */     }
/*     */     
/*  82 */     if (x509data == null) {
/*  83 */       log.debug("I can't");
/*  84 */       return null;
/*     */     }
/*     */     
/*  87 */     if (!x509data.containsIssuerSerial()) {
/*  88 */       return null;
/*     */     }
/*     */     try {
/*  91 */       if (storage == null) {
/*  92 */         Object[] exArgs = { "X509IssuerSerial" };
/*  93 */         KeyResolverException ex = 
/*  94 */           new KeyResolverException("KeyResolver.needStorageResolver", 
/*  95 */           exArgs);
/*     */         
/*  97 */         log.info("", ex);
/*  98 */         throw ex;
/*     */       }
/*     */       
/* 101 */       int noOfISS = x509data.lengthIssuerSerial();
/*     */       int i;
/* 103 */       for (; storage.hasNext(); 
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 114 */           i < noOfISS)
/*     */       {
/* 104 */         X509Certificate cert = storage.next();
/* 105 */         XMLX509IssuerSerial certSerial = new XMLX509IssuerSerial(element.getOwnerDocument(), cert);
/*     */         
/* 107 */         if (log.isDebugEnabled()) {
/* 108 */           log.debug("Found Certificate Issuer: " + 
/* 109 */             certSerial.getIssuerName());
/* 110 */           log.debug("Found Certificate Serial: " + 
/* 111 */             certSerial.getSerialNumber().toString());
/*     */         }
/*     */         
/* 114 */         i = 0; continue;
/* 115 */         XMLX509IssuerSerial xmliss = x509data.itemIssuerSerial(i);
/*     */         
/* 117 */         if (log.isDebugEnabled()) {
/* 118 */           log.debug("Found Element Issuer:     " + 
/* 119 */             xmliss.getIssuerName());
/* 120 */           log.debug("Found Element Serial:     " + 
/* 121 */             xmliss.getSerialNumber().toString());
/*     */         }
/*     */         
/* 124 */         if (certSerial.equals(xmliss)) {
/* 125 */           log.debug("match !!! ");
/*     */           
/* 127 */           return cert;
/*     */         }
/* 129 */         log.debug("no match...");i++;
/*     */       }
/*     */       
/*     */ 
/* 133 */       return null;
/*     */     } catch (XMLSecurityException ex) {
/* 135 */       log.debug("XMLSecurityException", ex);
/*     */       
/* 137 */       throw new KeyResolverException("generic.EmptyMessage", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public SecretKey engineLookupAndResolveSecretKey(Element element, String BaseURI, StorageResolver storage)
/*     */   {
/* 144 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\keyresolver\implementations\X509IssuerSerialResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */