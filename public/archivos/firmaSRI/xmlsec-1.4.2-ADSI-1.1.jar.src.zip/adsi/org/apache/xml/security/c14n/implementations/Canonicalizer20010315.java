/*     */ package adsi.org.apache.xml.security.c14n.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import adsi.org.apache.xml.security.c14n.helper.C14nHelper;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Canonicalizer20010315
/*     */   extends CanonicalizerBase
/*     */ {
/*  57 */   boolean firstCall = true;
/*  58 */   final SortedSet result = new TreeSet(COMPARE);
/*     */   static final String XMLNS_URI = "http://www.w3.org/2000/xmlns/";
/*     */   static final String XML_LANG_URI = "http://www.w3.org/XML/1998/namespace";
/*     */   
/*  62 */   static class XmlAttrStack { int currentLevel = 0;
/*  63 */     int lastlevel = 0;
/*     */     XmlsStackElement cur;
/*     */     
/*     */     static class XmlsStackElement { int level;
/*  67 */       boolean rendered = false;
/*  68 */       List nodes = new ArrayList(); }
/*     */     
/*  70 */     List levels = new ArrayList();
/*     */     
/*  72 */     void push(int level) { this.currentLevel = level;
/*  73 */       if (this.currentLevel == -1)
/*  74 */         return;
/*  75 */       this.cur = null;
/*  76 */       while (this.lastlevel >= this.currentLevel) {
/*  77 */         this.levels.remove(this.levels.size() - 1);
/*  78 */         if (this.levels.size() == 0) {
/*  79 */           this.lastlevel = 0;
/*  80 */           return;
/*     */         }
/*  82 */         this.lastlevel = ((XmlsStackElement)this.levels.get(this.levels.size() - 1)).level;
/*     */       }
/*     */     }
/*     */     
/*  86 */     void addXmlnsAttr(Attr n) { if (this.cur == null) {
/*  87 */         this.cur = new XmlsStackElement();
/*  88 */         this.cur.level = this.currentLevel;
/*  89 */         this.levels.add(this.cur);
/*  90 */         this.lastlevel = this.currentLevel;
/*     */       }
/*  92 */       this.cur.nodes.add(n);
/*     */     }
/*     */     
/*  95 */     void getXmlnsAttr(Collection col) { int size = this.levels.size() - 1;
/*  96 */       if (this.cur == null) {
/*  97 */         this.cur = new XmlsStackElement();
/*  98 */         this.cur.level = this.currentLevel;
/*  99 */         this.lastlevel = this.currentLevel;
/* 100 */         this.levels.add(this.cur);
/*     */       }
/* 102 */       boolean parentRendered = false;
/* 103 */       XmlsStackElement e = null;
/* 104 */       if (size == -1) {
/* 105 */         parentRendered = true;
/*     */       } else {
/* 107 */         e = (XmlsStackElement)this.levels.get(size);
/* 108 */         if ((e.rendered) && (e.level + 1 == this.currentLevel)) {
/* 109 */           parentRendered = true;
/*     */         }
/*     */       }
/* 112 */       if (parentRendered) {
/* 113 */         col.addAll(this.cur.nodes);
/* 114 */         this.cur.rendered = true;
/* 115 */         return;
/*     */       }
/*     */       
/* 118 */       Map loa = new HashMap();
/* 119 */       for (; size >= 0; size--) {
/* 120 */         e = (XmlsStackElement)this.levels.get(size);
/* 121 */         Iterator it = e.nodes.iterator();
/* 122 */         while (it.hasNext()) {
/* 123 */           Attr n = (Attr)it.next();
/* 124 */           if (!loa.containsKey(n.getName())) {
/* 125 */             loa.put(n.getName(), n);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 133 */       this.cur.rendered = true;
/* 134 */       col.addAll(loa.values());
/*     */     }
/*     */   }
/*     */   
/* 138 */   XmlAttrStack xmlattrStack = new XmlAttrStack();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Canonicalizer20010315(boolean includeComments)
/*     */   {
/* 145 */     super(includeComments);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Iterator handleAttributesSubtree(Element E, NameSpaceSymbTable ns)
/*     */     throws CanonicalizationException
/*     */   {
/* 164 */     if ((!E.hasAttributes()) && (!this.firstCall)) {
/* 165 */       return null;
/*     */     }
/*     */     
/* 168 */     SortedSet result = this.result;
/* 169 */     result.clear();
/* 170 */     NamedNodeMap attrs = E.getAttributes();
/* 171 */     int attrsLength = attrs.getLength();
/*     */     
/* 173 */     for (int i = 0; i < attrsLength; i++) {
/* 174 */       Attr N = (Attr)attrs.item(i);
/* 175 */       String NUri = N.getNamespaceURI();
/*     */       
/* 177 */       if ("http://www.w3.org/2000/xmlns/" != NUri)
/*     */       {
/* 179 */         result.add(N);
/*     */       }
/*     */       else
/*     */       {
/* 183 */         String NName = N.getLocalName();
/* 184 */         String NValue = N.getValue();
/* 185 */         if ((!"xml".equals(NName)) || 
/* 186 */           (!"http://www.w3.org/XML/1998/namespace".equals(NValue)))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 191 */           Node n = ns.addMappingAndRender(NName, NValue, N);
/*     */           
/* 193 */           if (n != null)
/*     */           {
/* 195 */             result.add(n);
/* 196 */             if (C14nHelper.namespaceIsRelative(N)) {
/* 197 */               Object[] exArgs = { E.getTagName(), NName, N.getNodeValue() };
/* 198 */               throw new CanonicalizationException(
/* 199 */                 "c14n.Canonicalizer.RelativeNamespace", exArgs);
/*     */             }
/*     */           }
/*     */         }
/*     */       } }
/* 204 */     if (this.firstCall)
/*     */     {
/*     */ 
/* 207 */       ns.getUnrenderedNodes(result);
/*     */       
/* 209 */       this.xmlattrStack.getXmlnsAttr(result);
/* 210 */       this.firstCall = false;
/*     */     }
/*     */     
/* 213 */     return result.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Iterator handleAttributes(Element E, NameSpaceSymbTable ns)
/*     */     throws CanonicalizationException
/*     */   {
/* 230 */     this.xmlattrStack.push(ns.getLevel());
/* 231 */     boolean isRealVisible = isVisibleDO(E, ns.getLevel()) == 1;
/* 232 */     NamedNodeMap attrs = null;
/* 233 */     int attrsLength = 0;
/* 234 */     if (E.hasAttributes()) {
/* 235 */       attrs = E.getAttributes();
/* 236 */       attrsLength = attrs.getLength();
/*     */     }
/*     */     
/*     */ 
/* 240 */     SortedSet result = this.result;
/* 241 */     result.clear();
/*     */     
/* 243 */     for (int i = 0; i < attrsLength; i++) {
/* 244 */       Attr N = (Attr)attrs.item(i);
/* 245 */       String NUri = N.getNamespaceURI();
/*     */       
/* 247 */       if ("http://www.w3.org/2000/xmlns/" != NUri)
/*     */       {
/* 249 */         if ("http://www.w3.org/XML/1998/namespace" == NUri) {
/* 250 */           this.xmlattrStack.addXmlnsAttr(N);
/* 251 */         } else if (isRealVisible)
/*     */         {
/* 253 */           result.add(N);
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 259 */         String NName = N.getLocalName();
/* 260 */         String NValue = N.getValue();
/* 261 */         if ((!"xml".equals(NName)) || 
/* 262 */           (!"http://www.w3.org/XML/1998/namespace".equals(NValue)))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 270 */           if (isVisible(N)) {
/* 271 */             if ((isRealVisible) || (!ns.removeMappingIfRender(NName)))
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/* 276 */               Node n = ns.addMappingAndRender(NName, NValue, N);
/* 277 */               if (n != null) {
/* 278 */                 result.add(n);
/* 279 */                 if (C14nHelper.namespaceIsRelative(N)) {
/* 280 */                   Object[] exArgs = { E.getTagName(), NName, N.getNodeValue() };
/* 281 */                   throw new CanonicalizationException(
/* 282 */                     "c14n.Canonicalizer.RelativeNamespace", exArgs);
/*     */                 }
/*     */               }
/*     */             }
/* 286 */           } else if ((isRealVisible) && (NName != "xmlns")) {
/* 287 */             ns.removeMapping(NName);
/*     */           } else
/* 289 */             ns.addMapping(NName, NValue, N);
/*     */         }
/*     */       }
/*     */     }
/* 293 */     if (isRealVisible)
/*     */     {
/* 295 */       Attr xmlns = E.getAttributeNodeNS("http://www.w3.org/2000/xmlns/", "xmlns");
/* 296 */       Node n = null;
/* 297 */       if (xmlns == null)
/*     */       {
/* 299 */         n = ns.getMapping("xmlns");
/* 300 */       } else if (!isVisible(xmlns))
/*     */       {
/*     */ 
/* 303 */         n = ns.addMappingAndRender("xmlns", "", nullNode);
/*     */       }
/*     */       
/* 306 */       if (n != null) {
/* 307 */         result.add(n);
/*     */       }
/*     */       
/*     */ 
/* 311 */       this.xmlattrStack.getXmlnsAttr(result);
/* 312 */       ns.getUnrenderedNodes(result);
/*     */     }
/*     */     
/*     */ 
/* 316 */     return result.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalizeXPathNodeSet(Set xpathNodeSet, String inclusiveNamespaces)
/*     */     throws CanonicalizationException
/*     */   {
/* 330 */     throw new CanonicalizationException(
/* 331 */       "c14n.Canonicalizer.UnsupportedOperation");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalizeSubTree(Node rootNode, String inclusiveNamespaces)
/*     */     throws CanonicalizationException
/*     */   {
/* 346 */     throw new CanonicalizationException(
/* 347 */       "c14n.Canonicalizer.UnsupportedOperation");
/*     */   }
/*     */   
/* 350 */   void circumventBugIfNeeded(XMLSignatureInput input) throws CanonicalizationException, ParserConfigurationException, IOException, SAXException { if (!input.isNeedsToBeExpanded())
/* 351 */       return;
/* 352 */     Document doc = null;
/* 353 */     if (input.getSubNode() != null) {
/* 354 */       doc = XMLUtils.getOwnerDocument(input.getSubNode());
/*     */     } else {
/* 356 */       doc = XMLUtils.getOwnerDocument(input.getNodeSet());
/*     */     }
/* 358 */     XMLUtils.circumventBug2650(doc);
/*     */   }
/*     */   
/*     */   void handleParent(Element e, NameSpaceSymbTable ns)
/*     */   {
/* 363 */     if (!e.hasAttributes()) {
/* 364 */       return;
/*     */     }
/* 366 */     this.xmlattrStack.push(-1);
/* 367 */     NamedNodeMap attrs = e.getAttributes();
/* 368 */     int attrsLength = attrs.getLength();
/* 369 */     for (int i = 0; i < attrsLength; i++) {
/* 370 */       Attr N = (Attr)attrs.item(i);
/* 371 */       if ("http://www.w3.org/2000/xmlns/" != N.getNamespaceURI())
/*     */       {
/* 373 */         if ("http://www.w3.org/XML/1998/namespace" == N.getNamespaceURI()) {
/* 374 */           this.xmlattrStack.addXmlnsAttr(N);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 379 */         String NName = N.getLocalName();
/* 380 */         String NValue = N.getNodeValue();
/* 381 */         if ((!"xml".equals(NName)) || 
/* 382 */           (!"http://www.w3.org/XML/1998/namespace".equals(NValue)))
/*     */         {
/*     */ 
/* 385 */           ns.addMapping(NName, NValue, N);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\c14n\implementations\Canonicalizer20010315.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */