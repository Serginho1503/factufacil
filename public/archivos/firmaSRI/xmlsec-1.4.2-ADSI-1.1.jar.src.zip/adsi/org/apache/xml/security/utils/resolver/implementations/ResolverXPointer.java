/*     */ package adsi.org.apache.xml.security.utils.resolver.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import adsi.org.apache.xml.security.utils.IdResolver;
/*     */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolverException;
/*     */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolverSpi;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResolverXPointer
/*     */   extends ResourceResolverSpi
/*     */ {
/*  50 */   static Log log = LogFactory.getLog(
/*  51 */     ResolverXPointer.class.getName());
/*     */   private static final String XP = "#xpointer(id(";
/*     */   
/*  54 */   public boolean engineIsThreadSafe() { return true; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput engineResolve(Attr uri, String BaseURI)
/*     */     throws ResourceResolverException
/*     */   {
/*  62 */     Node resultNode = null;
/*  63 */     Document doc = uri.getOwnerElement().getOwnerDocument();
/*     */     
/*  65 */     String uriStr = uri.getNodeValue();
/*  66 */     if (isXPointerSlash(uriStr)) {
/*  67 */       resultNode = doc;
/*     */     }
/*  69 */     else if (isXPointerId(uriStr)) {
/*  70 */       String id = getXPointerId(uriStr);
/*  71 */       resultNode = IdResolver.getElementById(doc, id);
/*     */       
/*     */ 
/*     */ 
/*  75 */       if (resultNode == null) {
/*  76 */         Object[] exArgs = { id };
/*     */         
/*  78 */         throw new ResourceResolverException(
/*  79 */           "signature.Verification.MissingID", exArgs, uri, BaseURI);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  89 */     XMLSignatureInput result = new XMLSignatureInput(resultNode);
/*     */     
/*  91 */     result.setMIMEType("text/xml");
/*  92 */     if ((BaseURI != null) && (BaseURI.length() > 0)) {
/*  93 */       result.setSourceURI(BaseURI.concat(uri.getNodeValue()));
/*     */     } else {
/*  95 */       result.setSourceURI(uri.getNodeValue());
/*     */     }
/*     */     
/*  98 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean engineCanResolve(Attr uri, String BaseURI)
/*     */   {
/* 106 */     if (uri == null) {
/* 107 */       return false;
/*     */     }
/* 109 */     String uriStr = uri.getNodeValue();
/* 110 */     if ((isXPointerSlash(uriStr)) || (isXPointerId(uriStr))) {
/* 111 */       return true;
/*     */     }
/*     */     
/* 114 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isXPointerSlash(String uri)
/*     */   {
/* 125 */     if (uri.equals("#xpointer(/)")) {
/* 126 */       return true;
/*     */     }
/*     */     
/* 129 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 134 */   private static final int XP_LENGTH = "#xpointer(id(".length();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isXPointerId(String uri)
/*     */   {
/* 145 */     if ((uri.startsWith("#xpointer(id(")) && 
/* 146 */       (uri.endsWith("))"))) {
/* 147 */       String idPlusDelim = uri.substring(XP_LENGTH, 
/* 148 */         uri.length() - 
/* 149 */         2);
/*     */       
/*     */ 
/* 152 */       int idLen = idPlusDelim.length() - 1;
/* 153 */       if (((idPlusDelim.charAt(0) == '"') && 
/* 154 */         (idPlusDelim.charAt(idLen) == '"')) || (
/* 155 */         (idPlusDelim.charAt(0) == '\'') && 
/* 156 */         (idPlusDelim.charAt(idLen) == '\''))) {
/* 157 */         if (log.isDebugEnabled()) {
/* 158 */           log.debug("Id=" + 
/* 159 */             idPlusDelim.substring(1, idLen));
/*     */         }
/* 161 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 165 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String getXPointerId(String uri)
/*     */   {
/* 177 */     if ((uri.startsWith("#xpointer(id(")) && 
/* 178 */       (uri.endsWith("))"))) {
/* 179 */       String idPlusDelim = uri.substring(XP_LENGTH, uri.length() - 
/* 180 */         2);
/* 181 */       int idLen = idPlusDelim.length() - 1;
/* 182 */       if (((idPlusDelim.charAt(0) == '"') && 
/* 183 */         (idPlusDelim.charAt(idLen) == '"')) || (
/* 184 */         (idPlusDelim.charAt(0) == '\'') && 
/* 185 */         (idPlusDelim.charAt(idLen) == '\''))) {
/* 186 */         return idPlusDelim.substring(1, idLen);
/*     */       }
/*     */     }
/*     */     
/* 190 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\utils\resolver\implementations\ResolverXPointer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */