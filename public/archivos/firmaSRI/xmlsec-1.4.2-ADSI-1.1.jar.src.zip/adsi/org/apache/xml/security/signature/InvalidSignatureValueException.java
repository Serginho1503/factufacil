/*    */ package adsi.org.apache.xml.security.signature;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidSignatureValueException
/*    */   extends XMLSignatureException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InvalidSignatureValueException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InvalidSignatureValueException(String _msgID)
/*    */   {
/* 49 */     super(_msgID);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InvalidSignatureValueException(String _msgID, Object[] exArgs)
/*    */   {
/* 59 */     super(_msgID, exArgs);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InvalidSignatureValueException(String _msgID, Exception _originalException)
/*    */   {
/* 70 */     super(_msgID, _originalException);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InvalidSignatureValueException(String _msgID, Object[] exArgs, Exception _originalException)
/*    */   {
/* 82 */     super(_msgID, exArgs, _originalException);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\signature\InvalidSignatureValueException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */