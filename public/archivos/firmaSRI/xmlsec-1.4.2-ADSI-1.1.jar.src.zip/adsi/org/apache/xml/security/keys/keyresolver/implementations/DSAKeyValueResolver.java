/*    */ package adsi.org.apache.xml.security.keys.keyresolver.implementations;
/*    */ 
/*    */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*    */ import adsi.org.apache.xml.security.keys.content.keyvalues.DSAKeyValue;
/*    */ import adsi.org.apache.xml.security.keys.keyresolver.KeyResolverSpi;
/*    */ import adsi.org.apache.xml.security.keys.storage.StorageResolver;
/*    */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*    */ import java.security.PublicKey;
/*    */ import java.security.cert.X509Certificate;
/*    */ import javax.crypto.SecretKey;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DSAKeyValueResolver
/*    */   extends KeyResolverSpi
/*    */ {
/*    */   public PublicKey engineLookupAndResolvePublicKey(Element element, String BaseURI, StorageResolver storage)
/*    */   {
/* 51 */     if (element == null) {
/* 52 */       return null;
/*    */     }
/* 54 */     Element dsaKeyElement = null;
/* 55 */     boolean isKeyValue = XMLUtils.elementIsInSignatureSpace(element, 
/* 56 */       "KeyValue");
/* 57 */     if (isKeyValue) {
/* 58 */       dsaKeyElement = 
/* 59 */         XMLUtils.selectDsNode(element.getFirstChild(), "DSAKeyValue", 0);
/* 60 */     } else if (XMLUtils.elementIsInSignatureSpace(element, 
/* 61 */       "DSAKeyValue"))
/*    */     {
/*    */ 
/* 64 */       dsaKeyElement = element;
/*    */     }
/*    */     
/* 67 */     if (dsaKeyElement == null) {
/* 68 */       return null;
/*    */     }
/*    */     try
/*    */     {
/* 72 */       DSAKeyValue dsaKeyValue = new DSAKeyValue(dsaKeyElement, 
/* 73 */         BaseURI);
/* 74 */       return dsaKeyValue.getPublicKey();
/*    */     }
/*    */     catch (XMLSecurityException localXMLSecurityException) {}
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 81 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public X509Certificate engineLookupResolveX509Certificate(Element element, String BaseURI, StorageResolver storage)
/*    */   {
/* 88 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */   public SecretKey engineLookupAndResolveSecretKey(Element element, String BaseURI, StorageResolver storage)
/*    */   {
/* 94 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\keyresolver\implementations\DSAKeyValueResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */