/*     */ package adsi.org.apache.xml.security.utils;
/*     */ 
/*     */ import adsi.org.apache.xml.security.transforms.implementations.FuncHereContext;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import org.apache.xml.utils.PrefixResolver;
/*     */ import org.apache.xml.utils.PrefixResolverDefault;
/*     */ import org.apache.xpath.XPath;
/*     */ import org.apache.xpath.objects.XObject;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.ProcessingInstruction;
/*     */ import org.w3c.dom.Text;
/*     */ import org.w3c.dom.traversal.NodeIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XPathFuncHereAPI
/*     */ {
/*     */   public static Node selectSingleNode(Node contextNode, Node xpathnode)
/*     */     throws TransformerException
/*     */   {
/*  71 */     return selectSingleNode(contextNode, xpathnode, contextNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Node selectSingleNode(Node contextNode, Node xpathnode, Node namespaceNode)
/*     */     throws TransformerException
/*     */   {
/*  90 */     NodeIterator nl = selectNodeIterator(contextNode, xpathnode, 
/*  91 */       namespaceNode);
/*     */     
/*     */ 
/*  94 */     return nl.nextNode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static NodeIterator selectNodeIterator(Node contextNode, Node xpathnode)
/*     */     throws TransformerException
/*     */   {
/* 109 */     return selectNodeIterator(contextNode, xpathnode, contextNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static NodeIterator selectNodeIterator(Node contextNode, Node xpathnode, Node namespaceNode)
/*     */     throws TransformerException
/*     */   {
/* 128 */     XObject list = eval(contextNode, xpathnode, namespaceNode);
/*     */     
/*     */ 
/* 131 */     return list.nodeset();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static NodeList selectNodeList(Node contextNode, Node xpathnode)
/*     */     throws TransformerException
/*     */   {
/* 146 */     return selectNodeList(contextNode, xpathnode, contextNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static NodeList selectNodeList(Node contextNode, Node xpathnode, Node namespaceNode)
/*     */     throws TransformerException
/*     */   {
/* 165 */     XObject list = eval(contextNode, xpathnode, namespaceNode);
/*     */     
/*     */ 
/* 168 */     return list.nodelist();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XObject eval(Node contextNode, Node xpathnode)
/*     */     throws TransformerException
/*     */   {
/* 188 */     return eval(contextNode, xpathnode, contextNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XObject eval(Node contextNode, Node xpathnode, Node namespaceNode)
/*     */     throws TransformerException
/*     */   {
/* 220 */     FuncHereContext xpathSupport = new FuncHereContext(xpathnode);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 226 */     PrefixResolverDefault prefixResolver = 
/* 227 */       new PrefixResolverDefault(namespaceNode.getNodeType() == 
/* 228 */       9 ? 
/* 229 */       ((Document)namespaceNode)
/* 230 */       .getDocumentElement() : 
/* 231 */       namespaceNode);
/* 232 */     String str = getStrFromNode(xpathnode);
/*     */     
/*     */ 
/* 235 */     XPath xpath = new XPath(str, null, prefixResolver, 0, null);
/*     */     
/*     */ 
/*     */ 
/* 239 */     int ctxtNode = xpathSupport.getDTMHandleFromNode(contextNode);
/*     */     
/* 241 */     return xpath.execute(xpathSupport, ctxtNode, prefixResolver);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XObject eval(Node contextNode, Node xpathnode, PrefixResolver prefixResolver)
/*     */     throws TransformerException
/*     */   {
/* 269 */     String str = getStrFromNode(xpathnode);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 277 */     XPath xpath = new XPath(str, null, prefixResolver, 0, null);
/*     */     
/*     */ 
/* 280 */     FuncHereContext xpathSupport = new FuncHereContext(xpathnode);
/* 281 */     int ctxtNode = xpathSupport.getDTMHandleFromNode(contextNode);
/*     */     
/* 283 */     return xpath.execute(xpathSupport, ctxtNode, prefixResolver);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String getStrFromNode(Node xpathnode)
/*     */   {
/* 294 */     if (xpathnode.getNodeType() == 3)
/* 295 */       return ((Text)xpathnode).getData();
/* 296 */     if (xpathnode.getNodeType() == 2)
/* 297 */       return ((Attr)xpathnode).getNodeValue();
/* 298 */     if (xpathnode.getNodeType() == 7) {
/* 299 */       return ((ProcessingInstruction)xpathnode).getNodeValue();
/*     */     }
/*     */     
/* 302 */     return "";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\utils\XPathFuncHereAPI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */