/*     */ package adsi.org.apache.xml.security.keys.content.x509;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.utils.RFC2253Parser;
/*     */ import adsi.org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import java.security.Principal;
/*     */ import java.security.cert.X509Certificate;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLX509SubjectName
/*     */   extends SignatureElementProxy
/*     */   implements XMLX509DataContent
/*     */ {
/*     */   public XMLX509SubjectName(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  45 */     super(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509SubjectName(Document doc, String X509SubjectNameString)
/*     */   {
/*  56 */     super(doc);
/*     */     
/*  58 */     addText(X509SubjectNameString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509SubjectName(Document doc, X509Certificate x509certificate)
/*     */   {
/*  69 */     this(doc, RFC2253Parser.normalize(x509certificate.getSubjectDN().getName()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSubjectName()
/*     */   {
/*  79 */     return RFC2253Parser.normalize(getTextFromTextChild());
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/*  84 */     if (obj == null) {
/*  85 */       return false;
/*     */     }
/*     */     
/*  88 */     if (!getClass().getName().equals(obj.getClass().getName())) {
/*  89 */       return false;
/*     */     }
/*     */     
/*  92 */     XMLX509SubjectName other = (XMLX509SubjectName)obj;
/*  93 */     String otherSubject = other.getSubjectName();
/*  94 */     String thisSubject = getSubjectName();
/*     */     
/*  96 */     return thisSubject.equals(otherSubject);
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 102 */     return 52;
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 107 */     return "X509SubjectName";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\content\x509\XMLX509SubjectName.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */