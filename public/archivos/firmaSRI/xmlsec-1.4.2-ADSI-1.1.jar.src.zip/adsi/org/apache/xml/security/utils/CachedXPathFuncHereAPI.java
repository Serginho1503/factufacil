/*     */ package adsi.org.apache.xml.security.utils;
/*     */ 
/*     */ import adsi.org.apache.xml.security.transforms.implementations.FuncHere;
/*     */ import adsi.org.apache.xml.security.transforms.implementations.FuncHereContext;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.xml.transform.ErrorListener;
/*     */ import javax.xml.transform.SourceLocator;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.dtm.DTMManager;
/*     */ import org.apache.xml.utils.PrefixResolver;
/*     */ import org.apache.xml.utils.PrefixResolverDefault;
/*     */ import org.apache.xpath.CachedXPathAPI;
/*     */ import org.apache.xpath.Expression;
/*     */ import org.apache.xpath.XPath;
/*     */ import org.apache.xpath.XPathContext;
/*     */ import org.apache.xpath.compiler.FunctionTable;
/*     */ import org.apache.xpath.objects.XObject;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.ProcessingInstruction;
/*     */ import org.w3c.dom.Text;
/*     */ import org.w3c.dom.traversal.NodeIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CachedXPathFuncHereAPI
/*     */ {
/*  50 */   static Log log = LogFactory.getLog(CachedXPathFuncHereAPI.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  55 */   FuncHereContext _funcHereContext = null;
/*     */   
/*     */ 
/*  58 */   DTMManager _dtmManager = null;
/*     */   
/*  60 */   XPathContext _context = null;
/*     */   
/*  62 */   String xpathStr = null;
/*     */   
/*  64 */   XPath xpath = null;
/*     */   
/*  66 */   static FunctionTable _funcTable = null;
/*     */   
/*     */   static {
/*  69 */     fixupFunctionTable();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FuncHereContext getFuncHereContext()
/*     */   {
/*  78 */     return this._funcHereContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private CachedXPathFuncHereAPI() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CachedXPathFuncHereAPI(XPathContext existingXPathContext)
/*     */   {
/*  93 */     this._dtmManager = existingXPathContext.getDTMManager();
/*  94 */     this._context = existingXPathContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CachedXPathFuncHereAPI(CachedXPathAPI previouslyUsed)
/*     */   {
/* 103 */     this._dtmManager = previouslyUsed.getXPathContext().getDTMManager();
/* 104 */     this._context = previouslyUsed.getXPathContext();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node selectSingleNode(Node contextNode, Node xpathnode)
/*     */     throws TransformerException
/*     */   {
/* 120 */     return selectSingleNode(contextNode, xpathnode, contextNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node selectSingleNode(Node contextNode, Node xpathnode, Node namespaceNode)
/*     */     throws TransformerException
/*     */   {
/* 139 */     NodeIterator nl = selectNodeIterator(contextNode, xpathnode, 
/* 140 */       namespaceNode);
/*     */     
/*     */ 
/* 143 */     return nl.nextNode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodeIterator selectNodeIterator(Node contextNode, Node xpathnode)
/*     */     throws TransformerException
/*     */   {
/* 158 */     return selectNodeIterator(contextNode, xpathnode, contextNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public NodeIterator selectNodeIterator(Node contextNode, Node xpathnode, Node namespaceNode)
/*     */     throws TransformerException
/*     */   {
/* 178 */     XObject list = eval(contextNode, xpathnode, getStrFromNode(xpathnode), namespaceNode);
/*     */     
/*     */ 
/* 181 */     return list.nodeset();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public NodeList selectNodeList(Node contextNode, Node xpathnode)
/*     */     throws TransformerException
/*     */   {
/* 197 */     return selectNodeList(contextNode, xpathnode, getStrFromNode(xpathnode), contextNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodeList selectNodeList(Node contextNode, Node xpathnode, String str, Node namespaceNode)
/*     */     throws TransformerException
/*     */   {
/* 217 */     XObject list = eval(contextNode, xpathnode, str, namespaceNode);
/*     */     
/*     */ 
/* 220 */     return list.nodelist();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public XObject eval(Node contextNode, Node xpathnode)
/*     */     throws TransformerException
/*     */   {
/* 241 */     return eval(contextNode, xpathnode, getStrFromNode(xpathnode), contextNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XObject eval(Node contextNode, Node xpathnode, String str, Node namespaceNode)
/*     */     throws TransformerException
/*     */   {
/* 275 */     if (this._funcHereContext == null) {
/* 276 */       this._funcHereContext = new FuncHereContext(xpathnode, 
/* 277 */         this._dtmManager);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 284 */     PrefixResolverDefault prefixResolver = 
/* 285 */       new PrefixResolverDefault(namespaceNode.getNodeType() == 
/* 286 */       9 ? 
/* 287 */       ((Document)namespaceNode)
/* 288 */       .getDocumentElement() : 
/* 289 */       namespaceNode);
/*     */     
/*     */ 
/* 292 */     if (str != this.xpathStr) {
/* 293 */       if (str.indexOf("here()") > 0) {
/* 294 */         this._context.reset();
/* 295 */         this._dtmManager = this._context.getDTMManager();
/*     */       }
/* 297 */       this.xpath = createXPath(str, prefixResolver);
/* 298 */       this.xpathStr = str;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 303 */     int ctxtNode = this._funcHereContext.getDTMHandleFromNode(contextNode);
/*     */     
/* 305 */     return this.xpath.execute(this._funcHereContext, ctxtNode, prefixResolver);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XObject eval(Node contextNode, Node xpathnode, String str, PrefixResolver prefixResolver)
/*     */     throws TransformerException
/*     */   {
/* 342 */     if (str != this.xpathStr) {
/* 343 */       if (str.indexOf("here()") > 0) {
/* 344 */         this._context.reset();
/* 345 */         this._dtmManager = this._context.getDTMManager();
/*     */       }
/*     */       try {
/* 348 */         this.xpath = createXPath(str, prefixResolver);
/*     */       }
/*     */       catch (TransformerException ex) {
/* 351 */         Throwable th = ex.getCause();
/* 352 */         if (((th instanceof ClassNotFoundException)) && 
/* 353 */           (th.getMessage().indexOf("FuncHere") > 0)) {
/* 354 */           throw new RuntimeException(I18n.translate("endorsed.jdk1.4.0") + ex);
/*     */         }
/*     */         
/* 357 */         throw ex;
/*     */       }
/* 359 */       this.xpathStr = str;
/*     */     }
/*     */     
/*     */ 
/* 363 */     if (this._funcHereContext == null) {
/* 364 */       this._funcHereContext = new FuncHereContext(xpathnode, 
/* 365 */         this._dtmManager);
/*     */     }
/*     */     
/* 368 */     int ctxtNode = this._funcHereContext.getDTMHandleFromNode(contextNode);
/*     */     
/* 370 */     return this.xpath.execute(this._funcHereContext, ctxtNode, prefixResolver);
/*     */   }
/*     */   
/*     */   private XPath createXPath(String str, PrefixResolver prefixResolver) throws TransformerException {
/* 374 */     XPath xpath = null;
/* 375 */     Class[] classes = { String.class, SourceLocator.class, PrefixResolver.class, Integer.TYPE, 
/* 376 */       ErrorListener.class, FunctionTable.class };
/* 377 */     Object[] objects = { str, 0, prefixResolver, new Integer(0), 0, _funcTable };
/*     */     try {
/* 379 */       Constructor constructor = XPath.class.getConstructor(classes);
/* 380 */       xpath = (XPath)constructor.newInstance(objects);
/*     */     }
/*     */     catch (Throwable localThrowable) {}
/* 383 */     if (xpath == null) {
/* 384 */       xpath = new XPath(str, null, prefixResolver, 0, null);
/*     */     }
/* 386 */     return xpath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getStrFromNode(Node xpathnode)
/*     */   {
/* 397 */     if (xpathnode.getNodeType() == 3)
/*     */     {
/*     */ 
/*     */ 
/* 401 */       StringBuffer sb = new StringBuffer();
/*     */       
/* 403 */       for (Node currentSibling = xpathnode.getParentNode().getFirstChild(); 
/* 404 */           currentSibling != null; 
/* 405 */           currentSibling = currentSibling.getNextSibling()) {
/* 406 */         if (currentSibling.getNodeType() == 3) {
/* 407 */           sb.append(((Text)currentSibling).getData());
/*     */         }
/*     */       }
/*     */       
/* 411 */       return sb.toString(); }
/* 412 */     if (xpathnode.getNodeType() == 2)
/* 413 */       return ((Attr)xpathnode).getNodeValue();
/* 414 */     if (xpathnode.getNodeType() == 7) {
/* 415 */       return ((ProcessingInstruction)xpathnode).getNodeValue();
/*     */     }
/*     */     
/* 418 */     return null;
/*     */   }
/*     */   
/*     */   private static void fixupFunctionTable() {
/* 422 */     boolean installed = false;
/* 423 */     log.info("Registering Here function");
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 428 */       Class[] args = { String.class, Expression.class };
/* 429 */       Method installFunction = FunctionTable.class.getMethod("installFunction", args);
/* 430 */       if ((installFunction.getModifiers() & 0x8) != 0) {
/* 431 */         Object[] params = { "here", new FuncHere() };
/* 432 */         installFunction.invoke(null, params);
/* 433 */         installed = true;
/*     */       }
/*     */     } catch (Throwable t) {
/* 436 */       log.debug("Error installing function using the static installFunction method", t);
/*     */     }
/* 438 */     if (!installed) {
/*     */       try {
/* 440 */         _funcTable = new FunctionTable();
/* 441 */         Class[] args = { String.class, Class.class };
/* 442 */         Method installFunction = FunctionTable.class.getMethod("installFunction", args);
/* 443 */         Object[] params = { "here", FuncHere.class };
/* 444 */         installFunction.invoke(_funcTable, params);
/* 445 */         installed = true;
/*     */       } catch (Throwable t) {
/* 447 */         log.debug("Error installing function using the static installFunction method", t);
/*     */       }
/*     */     }
/* 450 */     if (log.isDebugEnabled()) {
/* 451 */       if (installed) {
/* 452 */         log.debug("Registered class " + FuncHere.class.getName() + 
/* 453 */           " for XPath function 'here()' function in internal table");
/*     */       } else {
/* 455 */         log.debug("Unable to register class " + FuncHere.class.getName() + 
/* 456 */           " for XPath function 'here()' function in internal table");
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\utils\CachedXPathFuncHereAPI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */