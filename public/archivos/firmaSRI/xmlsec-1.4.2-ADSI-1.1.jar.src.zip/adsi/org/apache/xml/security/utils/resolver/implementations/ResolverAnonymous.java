/*    */ package adsi.org.apache.xml.security.utils.resolver.implementations;
/*    */ 
/*    */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*    */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolverSpi;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.w3c.dom.Attr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResolverAnonymous
/*    */   extends ResourceResolverSpi
/*    */ {
/* 37 */   private XMLSignatureInput _input = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ResolverAnonymous(String filename)
/*    */     throws FileNotFoundException, IOException
/*    */   {
/* 45 */     this._input = new XMLSignatureInput(new FileInputStream(filename));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public ResolverAnonymous(InputStream is)
/*    */   {
/* 52 */     this._input = new XMLSignatureInput(is);
/*    */   }
/*    */   
/*    */   public XMLSignatureInput engineResolve(Attr uri, String BaseURI)
/*    */   {
/* 57 */     return this._input;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean engineCanResolve(Attr uri, String BaseURI)
/*    */   {
/* 64 */     if (uri == null) {
/* 65 */       return true;
/*    */     }
/* 67 */     return false;
/*    */   }
/*    */   
/*    */   public String[] engineGetPropertyKeys()
/*    */   {
/* 72 */     return new String[0];
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\utils\resolver\implementations\ResolverAnonymous.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */