/*    */ package adsi.org.apache.xml.security.c14n;
/*    */ 
/*    */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidCanonicalizerException
/*    */   extends XMLSecurityException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public InvalidCanonicalizerException() {}
/*    */   
/*    */   public InvalidCanonicalizerException(String _msgID)
/*    */   {
/* 50 */     super(_msgID);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InvalidCanonicalizerException(String _msgID, Object[] exArgs)
/*    */   {
/* 60 */     super(_msgID, exArgs);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InvalidCanonicalizerException(String _msgID, Exception _originalException)
/*    */   {
/* 71 */     super(_msgID, _originalException);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InvalidCanonicalizerException(String _msgID, Object[] exArgs, Exception _originalException)
/*    */   {
/* 83 */     super(_msgID, exArgs, _originalException);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\c14n\InvalidCanonicalizerException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */