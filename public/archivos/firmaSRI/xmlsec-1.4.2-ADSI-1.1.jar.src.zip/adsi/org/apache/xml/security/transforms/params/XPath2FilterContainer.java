/*     */ package adsi.org.apache.xml.security.transforms.params;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.transforms.TransformParam;
/*     */ import adsi.org.apache.xml.security.utils.ElementProxy;
/*     */ import adsi.org.apache.xml.security.utils.HelperNodeList;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XPath2FilterContainer
/*     */   extends ElementProxy
/*     */   implements TransformParam
/*     */ {
/*     */   private static final String _ATT_FILTER = "Filter";
/*     */   private static final String _ATT_FILTER_VALUE_INTERSECT = "intersect";
/*     */   private static final String _ATT_FILTER_VALUE_SUBTRACT = "subtract";
/*     */   private static final String _ATT_FILTER_VALUE_UNION = "union";
/*     */   public static final String INTERSECT = "intersect";
/*     */   public static final String SUBTRACT = "subtract";
/*     */   public static final String UNION = "union";
/*     */   public static final String _TAG_XPATH2 = "XPath";
/*     */   public static final String XPathFilter2NS = "http://www.w3.org/2002/06/xmldsig-filter2";
/*     */   
/*     */   private XPath2FilterContainer() {}
/*     */   
/*     */   private XPath2FilterContainer(Document doc, String xpath2filter, String filterType)
/*     */   {
/*  94 */     super(doc);
/*     */     
/*  96 */     this._constructionElement
/*  97 */       .setAttributeNS(null, "Filter", filterType);
/*  98 */     this._constructionElement.appendChild(doc.createTextNode(xpath2filter));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private XPath2FilterContainer(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 111 */     super(element, BaseURI);
/*     */     
/* 113 */     String filterStr = this._constructionElement.getAttributeNS(null, 
/* 114 */       "Filter");
/*     */     
/*     */ 
/* 117 */     if (!filterStr.equals("intersect"))
/*     */     {
/* 119 */       if (!filterStr.equals("subtract"))
/*     */       {
/* 121 */         if (!filterStr.equals("union")) {
/* 122 */           Object[] exArgs = { "Filter", filterStr, 
/* 123 */             "intersect, subtract or union" };
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 129 */           throw new XMLSecurityException("attributeValueIllegal", exArgs);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XPath2FilterContainer newInstanceIntersect(Document doc, String xpath2filter)
/*     */   {
/* 143 */     return new XPath2FilterContainer(doc, xpath2filter, 
/* 144 */       "intersect");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XPath2FilterContainer newInstanceSubtract(Document doc, String xpath2filter)
/*     */   {
/* 158 */     return new XPath2FilterContainer(doc, xpath2filter, 
/* 159 */       "subtract");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XPath2FilterContainer newInstanceUnion(Document doc, String xpath2filter)
/*     */   {
/* 173 */     return new XPath2FilterContainer(doc, xpath2filter, 
/* 174 */       "union");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static NodeList newInstances(Document doc, String[][] params)
/*     */   {
/* 187 */     HelperNodeList nl = new HelperNodeList();
/*     */     
/* 189 */     XMLUtils.addReturnToElement(doc, nl);
/*     */     
/* 191 */     for (int i = 0; i < params.length; i++) {
/* 192 */       String type = params[i][0];
/* 193 */       String xpath = params[i][1];
/*     */       
/* 195 */       if (!type.equals("intersect"))
/*     */       {
/* 197 */         if (!type.equals("subtract"))
/*     */         {
/* 199 */           if (!type.equals("union"))
/*     */           {
/* 201 */             throw new IllegalArgumentException("The type(" + i + ")=\"" + type + 
/* 202 */               "\" is illegal"); }
/*     */         }
/*     */       }
/* 205 */       XPath2FilterContainer c = new XPath2FilterContainer(doc, xpath, type);
/*     */       
/* 207 */       nl.appendChild(c.getElement());
/* 208 */       XMLUtils.addReturnToElement(doc, nl);
/*     */     }
/*     */     
/* 211 */     return nl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XPath2FilterContainer newInstance(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 225 */     return new XPath2FilterContainer(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isIntersect()
/*     */   {
/* 235 */     return 
/*     */     
/* 237 */       this._constructionElement.getAttributeNS(null, "Filter").equals("intersect");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSubtract()
/*     */   {
/* 247 */     return 
/*     */     
/* 249 */       this._constructionElement.getAttributeNS(null, "Filter").equals("subtract");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isUnion()
/*     */   {
/* 259 */     return 
/*     */     
/* 261 */       this._constructionElement.getAttributeNS(null, "Filter").equals("union");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getXPathFilterStr()
/*     */   {
/* 270 */     return getTextFromTextChild();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node getXPathFilterTextNode()
/*     */   {
/* 283 */     NodeList children = this._constructionElement.getChildNodes();
/* 284 */     int length = children.getLength();
/*     */     
/* 286 */     for (int i = 0; i < length; i++) {
/* 287 */       if (children.item(i).getNodeType() == 3) {
/* 288 */         return children.item(i);
/*     */       }
/*     */     }
/*     */     
/* 292 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getBaseLocalName()
/*     */   {
/* 301 */     return "XPath";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getBaseNamespace()
/*     */   {
/* 310 */     return "http://www.w3.org/2002/06/xmldsig-filter2";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\transforms\params\XPath2FilterContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */