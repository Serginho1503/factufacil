/*     */ package adsi.org.apache.xml.security.signature;
/*     */ 
/*     */ import adsi.org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import adsi.org.apache.xml.security.c14n.implementations.Canonicalizer11_OmitComments;
/*     */ import adsi.org.apache.xml.security.c14n.implementations.Canonicalizer20010315OmitComments;
/*     */ import adsi.org.apache.xml.security.c14n.implementations.CanonicalizerBase;
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityRuntimeException;
/*     */ import adsi.org.apache.xml.security.utils.IgnoreAllErrorHandler;
/*     */ import adsi.org.apache.xml.security.utils.JavaUtils;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLSignatureInput
/*     */   implements Cloneable
/*     */ {
/*  58 */   static Log log = LogFactory.getLog(
/*  59 */     XMLSignatureInput.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  74 */   InputStream _inputOctetStreamProxy = null;
/*     */   
/*     */ 
/*     */ 
/*  78 */   Set _inputNodeSet = null;
/*     */   
/*     */ 
/*     */ 
/*  82 */   Node _subNode = null;
/*     */   
/*     */ 
/*     */ 
/*  86 */   Node excludeNode = null;
/*     */   
/*     */ 
/*     */ 
/*  90 */   boolean excludeComments = false;
/*     */   
/*  92 */   boolean isNodeSet = false;
/*     */   
/*     */ 
/*     */ 
/*  96 */   byte[] bytes = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 101 */   private String _MIMEType = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 106 */   private String _SourceURI = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 111 */   List nodeFilters = new ArrayList();
/*     */   
/* 113 */   boolean needsToBeExpanded = false;
/* 114 */   OutputStream outputStream = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isNeedsToBeExpanded()
/*     */   {
/* 121 */     return this.needsToBeExpanded;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNeedsToBeExpanded(boolean needsToBeExpanded)
/*     */   {
/* 129 */     this.needsToBeExpanded = needsToBeExpanded;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput(byte[] inputOctets)
/*     */   {
/* 145 */     this.bytes = inputOctets;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput(InputStream inputOctetStream)
/*     */   {
/* 155 */     this._inputOctetStreamProxy = inputOctetStream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public XMLSignatureInput(String inputStr)
/*     */   {
/* 169 */     this(inputStr.getBytes());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public XMLSignatureInput(String inputStr, String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 185 */     this(inputStr.getBytes(encoding));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput(Node rootNode)
/*     */   {
/* 196 */     this._subNode = rootNode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput(Set inputNodeSet)
/*     */   {
/* 206 */     this._inputNodeSet = inputNodeSet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set getNodeSet()
/*     */     throws CanonicalizationException, ParserConfigurationException, IOException, SAXException
/*     */   {
/* 221 */     return getNodeSet(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set getNodeSet(boolean circumvent)
/*     */     throws ParserConfigurationException, IOException, SAXException, CanonicalizationException
/*     */   {
/* 238 */     if (this._inputNodeSet != null) {
/* 239 */       return this._inputNodeSet;
/*     */     }
/* 241 */     if ((this._inputOctetStreamProxy == null) && (this._subNode != null))
/*     */     {
/* 243 */       if (circumvent) {
/* 244 */         XMLUtils.circumventBug2650(XMLUtils.getOwnerDocument(this._subNode));
/*     */       }
/* 246 */       this._inputNodeSet = new HashSet();
/* 247 */       XMLUtils.getSet(this._subNode, this._inputNodeSet, this.excludeNode, this.excludeComments);
/*     */       
/* 249 */       return this._inputNodeSet; }
/* 250 */     if (isOctetStream()) {
/* 251 */       convertToNodes();
/* 252 */       HashSet result = new HashSet();
/* 253 */       XMLUtils.getSet(this._subNode, result, null, false);
/*     */       
/* 255 */       return result;
/*     */     }
/*     */     
/* 258 */     throw new RuntimeException(
/* 259 */       "getNodeSet() called but no input data present");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputStream getOctetStream()
/*     */     throws IOException
/*     */   {
/* 272 */     return getResetableInputStream();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public InputStream getOctetStreamReal()
/*     */   {
/* 279 */     return this._inputOctetStreamProxy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getBytes()
/*     */     throws IOException, CanonicalizationException
/*     */   {
/* 293 */     if (this.bytes != null) {
/* 294 */       return this.bytes;
/*     */     }
/* 296 */     InputStream is = getResetableInputStream();
/* 297 */     if (is != null)
/*     */     {
/* 299 */       if (this.bytes == null) {
/* 300 */         is.reset();
/* 301 */         this.bytes = JavaUtils.getBytesFromStream(is);
/*     */       }
/* 303 */       return this.bytes;
/*     */     }
/* 305 */     Canonicalizer20010315OmitComments c14nizer = 
/* 306 */       new Canonicalizer20010315OmitComments();
/* 307 */     this.bytes = c14nizer.engineCanonicalize(this);
/* 308 */     return this.bytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isNodeSet()
/*     */   {
/* 318 */     return ((this._inputOctetStreamProxy == null) && (this._inputNodeSet != null)) || (this.isNodeSet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isElement()
/*     */   {
/* 328 */     return (this._inputOctetStreamProxy == null) && (this._subNode != null) && (this._inputNodeSet == null) && (!this.isNodeSet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isOctetStream()
/*     */   {
/* 338 */     return ((this._inputOctetStreamProxy != null) || (this.bytes != null)) && (this._inputNodeSet == null) && (this._subNode == null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isOutputStreamSet()
/*     */   {
/* 349 */     return this.outputStream != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isByteArray()
/*     */   {
/* 359 */     return (this.bytes != null) && (this._inputNodeSet == null) && (this._subNode == null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isInitialized()
/*     */   {
/* 368 */     return (isOctetStream()) || (isNodeSet());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMIMEType()
/*     */   {
/* 377 */     return this._MIMEType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMIMEType(String MIMEType)
/*     */   {
/* 386 */     this._MIMEType = MIMEType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSourceURI()
/*     */   {
/* 395 */     return this._SourceURI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSourceURI(String SourceURI)
/*     */   {
/* 404 */     this._SourceURI = SourceURI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 412 */     if (isNodeSet()) {
/* 413 */       return 
/* 414 */         "XMLSignatureInput/NodeSet/" + this._inputNodeSet.size() + " nodes/" + getSourceURI();
/*     */     }
/* 416 */     if (isElement()) {
/* 417 */       return 
/*     */       
/* 419 */         "XMLSignatureInput/Element/" + this._subNode + " exclude " + this.excludeNode + " comments:" + this.excludeComments + "/" + getSourceURI();
/*     */     }
/*     */     try {
/* 422 */       return 
/* 423 */         "XMLSignatureInput/OctetStream/" + getBytes().length + " octets/" + getSourceURI();
/*     */     } catch (IOException iex) {
/* 425 */       return "XMLSignatureInput/OctetStream//" + getSourceURI();
/*     */     } catch (CanonicalizationException cex) {}
/* 427 */     return "XMLSignatureInput/OctetStream//" + getSourceURI();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHTMLRepresentation()
/*     */     throws XMLSignatureException
/*     */   {
/* 439 */     XMLSignatureInputDebugger db = new XMLSignatureInputDebugger(this);
/*     */     
/* 441 */     return db.getHTMLRepresentation();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHTMLRepresentation(Set inclusiveNamespaces)
/*     */     throws XMLSignatureException
/*     */   {
/* 454 */     XMLSignatureInputDebugger db = new XMLSignatureInputDebugger(this, 
/* 455 */       inclusiveNamespaces);
/*     */     
/* 457 */     return db.getHTMLRepresentation();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node getExcludeNode()
/*     */   {
/* 465 */     return this.excludeNode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExcludeNode(Node excludeNode)
/*     */   {
/* 473 */     this.excludeNode = excludeNode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node getSubNode()
/*     */   {
/* 481 */     return this._subNode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isExcludeComments()
/*     */   {
/* 488 */     return this.excludeComments;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setExcludeComments(boolean excludeComments)
/*     */   {
/* 495 */     this.excludeComments = excludeComments;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void updateOutputStream(OutputStream diOs)
/*     */     throws CanonicalizationException, IOException
/*     */   {
/* 505 */     updateOutputStream(diOs, false);
/*     */   }
/*     */   
/*     */   public void updateOutputStream(OutputStream diOs, boolean c14n11) throws CanonicalizationException, IOException
/*     */   {
/* 510 */     if (diOs == this.outputStream) {
/* 511 */       return;
/*     */     }
/* 513 */     if (this.bytes != null) {
/* 514 */       diOs.write(this.bytes);
/* 515 */       return; }
/* 516 */     if (this._inputOctetStreamProxy == null) {
/* 517 */       CanonicalizerBase c14nizer = null;
/* 518 */       if (c14n11) {
/* 519 */         c14nizer = new Canonicalizer11_OmitComments();
/*     */       } else {
/* 521 */         c14nizer = new Canonicalizer20010315OmitComments();
/*     */       }
/* 523 */       c14nizer.setWriter(diOs);
/* 524 */       c14nizer.engineCanonicalize(this);
/* 525 */       return;
/*     */     }
/* 527 */     InputStream is = getResetableInputStream();
/* 528 */     if (this.bytes != null)
/*     */     {
/* 530 */       diOs.write(this.bytes, 0, this.bytes.length);
/* 531 */       return;
/*     */     }
/* 533 */     is.reset();
/*     */     
/* 535 */     byte[] bytesT = new byte['က'];
/* 536 */     int num; while ((num = is.read(bytesT)) >= 0) { int num;
/* 537 */       diOs.write(bytesT, 0, num);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOutputStream(OutputStream os)
/*     */   {
/* 546 */     this.outputStream = os;
/*     */   }
/*     */   
/*     */   protected InputStream getResetableInputStream() throws IOException {
/* 550 */     if ((this._inputOctetStreamProxy instanceof ByteArrayInputStream)) {
/* 551 */       if (!this._inputOctetStreamProxy.markSupported()) {
/* 552 */         throw new RuntimeException("Accepted as Markable but not truly been" + this._inputOctetStreamProxy);
/*     */       }
/* 554 */       return this._inputOctetStreamProxy;
/*     */     }
/*     */     
/* 557 */     if ((this._inputOctetStreamProxy != null) && (this._inputOctetStreamProxy.markSupported())) {
/* 558 */       return this._inputOctetStreamProxy;
/*     */     }
/* 560 */     if (this.bytes != null) {
/* 561 */       this._inputOctetStreamProxy = new ByteArrayInputStream(this.bytes);
/* 562 */       return this._inputOctetStreamProxy;
/*     */     }
/* 564 */     if (this._inputOctetStreamProxy == null)
/* 565 */       return null;
/* 566 */     if (this._inputOctetStreamProxy.markSupported()) {
/* 567 */       log.info("Mark Suported but not used as reset");
/*     */     }
/* 569 */     this.bytes = JavaUtils.getBytesFromStream(this._inputOctetStreamProxy);
/* 570 */     this._inputOctetStreamProxy.close();
/* 571 */     this._inputOctetStreamProxy = new ByteArrayInputStream(this.bytes);
/* 572 */     return this._inputOctetStreamProxy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addNodeFilter(NodeFilter filter)
/*     */   {
/* 579 */     if (isOctetStream()) {
/*     */       try {
/* 581 */         convertToNodes();
/*     */       } catch (Exception e) {
/* 583 */         throw new XMLSecurityRuntimeException("signature.XMLSignatureInput.nodesetReference", e);
/*     */       }
/*     */     }
/* 586 */     this.nodeFilters.add(filter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getNodeFilters()
/*     */   {
/* 594 */     return this.nodeFilters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setNodeSet(boolean b)
/*     */   {
/* 601 */     this.isNodeSet = b;
/*     */   }
/*     */   
/*     */   void convertToNodes() throws CanonicalizationException, ParserConfigurationException, IOException, SAXException
/*     */   {
/* 606 */     DocumentBuilderFactory dfactory = DocumentBuilderFactory.newInstance();
/* 607 */     dfactory.setValidating(false);
/* 608 */     dfactory.setNamespaceAware(true);
/* 609 */     DocumentBuilder db = dfactory.newDocumentBuilder();
/*     */     try
/*     */     {
/* 612 */       db.setErrorHandler(new IgnoreAllErrorHandler());
/*     */       
/*     */ 
/* 615 */       Document doc = db.parse(getOctetStream());
/*     */       
/* 617 */       this._subNode = doc.getDocumentElement();
/*     */     }
/*     */     catch (SAXException ex)
/*     */     {
/* 621 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*     */       
/* 623 */       baos.write("<container>".getBytes());
/* 624 */       baos.write(getBytes());
/* 625 */       baos.write("</container>".getBytes());
/*     */       
/* 627 */       byte[] result = baos.toByteArray();
/* 628 */       Document document = db.parse(new ByteArrayInputStream(result));
/* 629 */       this._subNode = document.getDocumentElement().getFirstChild().getFirstChild();
/*     */     }
/* 631 */     this._inputOctetStreamProxy = null;
/* 632 */     this.bytes = null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\signature\XMLSignatureInput.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */