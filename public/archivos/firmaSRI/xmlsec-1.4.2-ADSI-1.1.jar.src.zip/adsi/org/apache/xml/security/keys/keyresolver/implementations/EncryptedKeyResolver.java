/*     */ package adsi.org.apache.xml.security.keys.keyresolver.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.encryption.EncryptedKey;
/*     */ import adsi.org.apache.xml.security.encryption.XMLCipher;
/*     */ import adsi.org.apache.xml.security.keys.keyresolver.KeyResolverSpi;
/*     */ import adsi.org.apache.xml.security.keys.storage.StorageResolver;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.security.Key;
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.crypto.SecretKey;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EncryptedKeyResolver
/*     */   extends KeyResolverSpi
/*     */ {
/*  52 */   static Log log = LogFactory.getLog(
/*  53 */     RSAKeyValueResolver.class.getName());
/*     */   
/*     */ 
/*     */   Key _kek;
/*     */   
/*     */ 
/*     */   String _algorithm;
/*     */   
/*     */ 
/*     */ 
/*     */   public EncryptedKeyResolver(String algorithm)
/*     */   {
/*  65 */     this._kek = null;
/*  66 */     this._algorithm = algorithm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EncryptedKeyResolver(String algorithm, Key kek)
/*     */   {
/*  76 */     this._algorithm = algorithm;
/*  77 */     this._kek = kek;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PublicKey engineLookupAndResolvePublicKey(Element element, String BaseURI, StorageResolver storage)
/*     */   {
/*  85 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public X509Certificate engineLookupResolveX509Certificate(Element element, String BaseURI, StorageResolver storage)
/*     */   {
/*  91 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public SecretKey engineLookupAndResolveSecretKey(Element element, String BaseURI, StorageResolver storage)
/*     */   {
/*  97 */     SecretKey key = null;
/*  98 */     if (log.isDebugEnabled()) {
/*  99 */       log.debug("EncryptedKeyResolver - Can I resolve " + element.getTagName());
/*     */     }
/* 101 */     if (element == null) {
/* 102 */       return null;
/*     */     }
/*     */     
/* 105 */     boolean isEncryptedKey = XMLUtils.elementIsInEncryptionSpace(element, 
/* 106 */       "EncryptedKey");
/*     */     
/* 108 */     if (isEncryptedKey) {
/* 109 */       log.debug("Passed an Encrypted Key");
/*     */       try {
/* 111 */         XMLCipher cipher = XMLCipher.getInstance();
/* 112 */         cipher.init(4, this._kek);
/* 113 */         EncryptedKey ek = cipher.loadEncryptedKey(element);
/* 114 */         key = (SecretKey)cipher.decryptKey(ek, this._algorithm);
/*     */       }
/*     */       catch (Exception localException) {}
/*     */     }
/*     */     
/* 119 */     return key;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\keyresolver\implementations\EncryptedKeyResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */