package adsi.org.apache.xml.security.encryption;

import java.util.Iterator;
import org.w3c.dom.Element;

public abstract interface Reference
{
  public abstract String getURI();
  
  public abstract void setURI(String paramString);
  
  public abstract Iterator getElementRetrievalInformation();
  
  public abstract void addElementRetrievalInformation(Element paramElement);
  
  public abstract void removeElementRetrievalInformation(Element paramElement);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\encryption\Reference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */