/*    */ package adsi.org.apache.xml.security.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Base64DecodingException
/*    */   extends XMLSecurityException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Base64DecodingException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Base64DecodingException(String _msgID)
/*    */   {
/* 47 */     super(_msgID);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Base64DecodingException(String _msgID, Object[] exArgs)
/*    */   {
/* 57 */     super(_msgID, exArgs);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Base64DecodingException(String _msgID, Exception _originalException)
/*    */   {
/* 68 */     super(_msgID, _originalException);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Base64DecodingException(String _msgID, Object[] exArgs, Exception _originalException)
/*    */   {
/* 80 */     super(_msgID, exArgs, _originalException);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\exceptions\Base64DecodingException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */