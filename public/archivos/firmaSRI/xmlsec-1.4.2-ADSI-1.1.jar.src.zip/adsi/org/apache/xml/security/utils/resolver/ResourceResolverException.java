/*     */ package adsi.org.apache.xml.security.utils.resolver;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import org.w3c.dom.Attr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceResolverException
/*     */   extends XMLSecurityException
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public ResourceResolverException(String _msgID, Attr uri, String BaseURI)
/*     */   {
/*  48 */     super(_msgID);
/*     */     
/*  50 */     this._uri = uri;
/*  51 */     this._BaseURI = BaseURI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceResolverException(String _msgID, Object[] exArgs, Attr uri, String BaseURI)
/*     */   {
/*  65 */     super(_msgID, exArgs);
/*     */     
/*  67 */     this._uri = uri;
/*  68 */     this._BaseURI = BaseURI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceResolverException(String _msgID, Exception _originalException, Attr uri, String BaseURI)
/*     */   {
/*  82 */     super(_msgID, _originalException);
/*     */     
/*  84 */     this._uri = uri;
/*  85 */     this._BaseURI = BaseURI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceResolverException(String _msgID, Object[] exArgs, Exception _originalException, Attr uri, String BaseURI)
/*     */   {
/* 101 */     super(_msgID, exArgs, _originalException);
/*     */     
/* 103 */     this._uri = uri;
/* 104 */     this._BaseURI = BaseURI;
/*     */   }
/*     */   
/*     */ 
/* 108 */   Attr _uri = null;
/*     */   
/*     */   String _BaseURI;
/*     */   
/*     */   public void setURI(Attr uri)
/*     */   {
/* 114 */     this._uri = uri;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Attr getURI()
/*     */   {
/* 122 */     return this._uri;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBaseURI(String BaseURI)
/*     */   {
/* 132 */     this._BaseURI = BaseURI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBaseURI()
/*     */   {
/* 140 */     return this._BaseURI;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\utils\resolver\ResourceResolverException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */