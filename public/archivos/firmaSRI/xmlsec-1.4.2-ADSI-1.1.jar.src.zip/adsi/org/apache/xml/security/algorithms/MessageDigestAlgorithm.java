/*     */ package adsi.org.apache.xml.security.algorithms;
/*     */ 
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureException;
/*     */ import java.security.DigestException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.Provider;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.w3c.dom.Document;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageDigestAlgorithm
/*     */   extends Algorithm
/*     */ {
/*     */   public static final String ALGO_ID_DIGEST_NOT_RECOMMENDED_MD5 = "http://www.w3.org/2001/04/xmldsig-more#md5";
/*     */   public static final String ALGO_ID_DIGEST_SHA1 = "http://www.w3.org/2000/09/xmldsig#sha1";
/*     */   public static final String ALGO_ID_DIGEST_SHA256 = "http://www.w3.org/2001/04/xmlenc#sha256";
/*     */   public static final String ALGO_ID_DIGEST_SHA384 = "http://www.w3.org/2001/04/xmldsig-more#sha384";
/*     */   public static final String ALGO_ID_DIGEST_SHA512 = "http://www.w3.org/2001/04/xmlenc#sha512";
/*     */   public static final String ALGO_ID_DIGEST_RIPEMD160 = "http://www.w3.org/2001/04/xmlenc#ripemd160";
/*  55 */   MessageDigest algorithm = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private MessageDigestAlgorithm(Document doc, MessageDigest messageDigest, String algorithmURI)
/*     */   {
/*  66 */     super(doc, algorithmURI);
/*     */     
/*  68 */     this.algorithm = messageDigest;
/*     */   }
/*     */   
/*  71 */   static ThreadLocal instances = new ThreadLocal() {
/*     */     protected Object initialValue() {
/*  73 */       return new HashMap();
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MessageDigestAlgorithm getInstance(Document doc, String algorithmURI)
/*     */     throws XMLSignatureException
/*     */   {
/*  87 */     MessageDigest md = getDigestInstance(algorithmURI);
/*  88 */     return new MessageDigestAlgorithm(doc, md, algorithmURI);
/*     */   }
/*     */   
/*     */   private static MessageDigest getDigestInstance(String algorithmURI) throws XMLSignatureException {
/*  92 */     MessageDigest result = (MessageDigest)((Map)instances.get()).get(algorithmURI);
/*  93 */     if (result != null)
/*  94 */       return result;
/*  95 */     String algorithmID = JCEMapper.translateURItoJCEID(algorithmURI);
/*     */     
/*  97 */     if (algorithmID == null) {
/*  98 */       Object[] exArgs = { algorithmURI };
/*  99 */       throw new XMLSignatureException("algorithms.NoSuchMap", exArgs);
/*     */     }
/*     */     
/*     */ 
/* 103 */     String provider = JCEMapper.getProviderId();
/*     */     try { MessageDigest md;
/* 105 */       if (provider == null) {
/* 106 */         md = MessageDigest.getInstance(algorithmID);
/*     */       } else
/* 108 */         md = MessageDigest.getInstance(algorithmID, provider);
/*     */     } catch (NoSuchAlgorithmException ex) {
/*     */       MessageDigest md;
/* 111 */       Object[] exArgs = { algorithmID, 
/* 112 */         ex.getLocalizedMessage() };
/*     */       
/* 114 */       throw new XMLSignatureException("algorithms.NoSuchAlgorithm", exArgs);
/*     */     } catch (NoSuchProviderException ex) {
/* 116 */       Object[] exArgs = { algorithmID, 
/* 117 */         ex.getLocalizedMessage() };
/*     */       
/* 119 */       throw new XMLSignatureException("algorithms.NoSuchAlgorithm", exArgs); }
/*     */     MessageDigest md;
/* 121 */     ((Map)instances.get()).put(algorithmURI, md);
/* 122 */     return md;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MessageDigest getAlgorithm()
/*     */   {
/* 131 */     return this.algorithm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isEqual(byte[] digesta, byte[] digestb)
/*     */   {
/* 143 */     return MessageDigest.isEqual(digesta, digestb);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] digest()
/*     */   {
/* 153 */     return this.algorithm.digest();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] digest(byte[] input)
/*     */   {
/* 164 */     return this.algorithm.digest(input);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int digest(byte[] buf, int offset, int len)
/*     */     throws DigestException
/*     */   {
/* 179 */     return this.algorithm.digest(buf, offset, len);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getJCEAlgorithmString()
/*     */   {
/* 189 */     return this.algorithm.getAlgorithm();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Provider getJCEProvider()
/*     */   {
/* 199 */     return this.algorithm.getProvider();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDigestLength()
/*     */   {
/* 209 */     return this.algorithm.getDigestLength();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/* 218 */     this.algorithm.reset();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void update(byte[] input)
/*     */   {
/* 228 */     this.algorithm.update(input);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void update(byte input)
/*     */   {
/* 238 */     this.algorithm.update(input);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void update(byte[] buf, int offset, int len)
/*     */   {
/* 250 */     this.algorithm.update(buf, offset, len);
/*     */   }
/*     */   
/*     */   public String getBaseNamespace()
/*     */   {
/* 255 */     return "http://www.w3.org/2000/09/xmldsig#";
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 260 */     return "DigestMethod";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\algorithms\MessageDigestAlgorithm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */