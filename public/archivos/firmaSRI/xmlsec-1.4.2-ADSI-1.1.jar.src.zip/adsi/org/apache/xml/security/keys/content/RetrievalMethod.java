/*     */ package adsi.org.apache.xml.security.keys.content;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureException;
/*     */ import adsi.org.apache.xml.security.transforms.Transforms;
/*     */ import adsi.org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RetrievalMethod
/*     */   extends SignatureElementProxy
/*     */   implements KeyInfoContent
/*     */ {
/*     */   public static final String TYPE_DSA = "http://www.w3.org/2000/09/xmldsig#DSAKeyValue";
/*     */   public static final String TYPE_RSA = "http://www.w3.org/2000/09/xmldsig#RSAKeyValue";
/*     */   public static final String TYPE_PGP = "http://www.w3.org/2000/09/xmldsig#PGPData";
/*     */   public static final String TYPE_SPKI = "http://www.w3.org/2000/09/xmldsig#SPKIData";
/*     */   public static final String TYPE_MGMT = "http://www.w3.org/2000/09/xmldsig#MgmtData";
/*     */   public static final String TYPE_X509 = "http://www.w3.org/2000/09/xmldsig#X509Data";
/*     */   public static final String TYPE_RAWX509 = "http://www.w3.org/2000/09/xmldsig#rawX509Certificate";
/*     */   
/*     */   public RetrievalMethod(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  63 */     super(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RetrievalMethod(Document doc, String URI, Transforms transforms, String Type)
/*     */   {
/*  77 */     super(doc);
/*     */     
/*  79 */     this._constructionElement.setAttributeNS(null, "URI", URI);
/*     */     
/*  81 */     if (Type != null) {
/*  82 */       this._constructionElement.setAttributeNS(null, "Type", Type);
/*     */     }
/*     */     
/*  85 */     if (transforms != null) {
/*  86 */       this._constructionElement.appendChild(transforms.getElement());
/*  87 */       XMLUtils.addReturnToElement(this._constructionElement);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Attr getURIAttr()
/*     */   {
/*  97 */     return this._constructionElement.getAttributeNodeNS(null, "URI");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getURI()
/*     */   {
/* 107 */     return getURIAttr().getNodeValue();
/*     */   }
/*     */   
/*     */   public String getType()
/*     */   {
/* 112 */     return this._constructionElement.getAttributeNS(null, "Type");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Transforms getTransforms()
/*     */     throws XMLSecurityException
/*     */   {
/*     */     try
/*     */     {
/* 125 */       Element transformsElem = 
/* 126 */         XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), 
/* 127 */         "Transforms", 
/* 128 */         0);
/*     */       
/* 130 */       if (transformsElem != null) {
/* 131 */         return new Transforms(transformsElem, this._baseURI);
/*     */       }
/*     */       
/* 134 */       return null;
/*     */     } catch (XMLSignatureException ex) {
/* 136 */       throw new XMLSecurityException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 142 */     return "RetrievalMethod";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\content\RetrievalMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */