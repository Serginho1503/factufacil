/*     */ package adsi.org.apache.xml.security.c14n.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import adsi.org.apache.xml.security.c14n.CanonicalizerSpi;
/*     */ import adsi.org.apache.xml.security.c14n.helper.AttrCompare;
/*     */ import adsi.org.apache.xml.security.signature.NodeFilter;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import adsi.org.apache.xml.security.utils.UnsyncByteArrayOutputStream;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Comment;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.ProcessingInstruction;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CanonicalizerBase
/*     */   extends CanonicalizerSpi
/*     */ {
/*  63 */   private static final byte[] _END_PI = { 63, 62 };
/*  64 */   private static final byte[] _BEGIN_PI = { 60, 63 };
/*  65 */   private static final byte[] _END_COMM = { 45, 45, 62 };
/*  66 */   private static final byte[] _BEGIN_COMM = { 60, 33, 45, 45 };
/*  67 */   private static final byte[] __XA_ = { 38, 35, 120, 65, 59 };
/*  68 */   private static final byte[] __X9_ = { 38, 35, 120, 57, 59 };
/*  69 */   private static final byte[] _QUOT_ = { 38, 113, 117, 111, 116, 59 };
/*  70 */   private static final byte[] __XD_ = { 38, 35, 120, 68, 59 };
/*  71 */   private static final byte[] _GT_ = { 38, 103, 116, 59 };
/*  72 */   private static final byte[] _LT_ = { 38, 108, 116, 59 };
/*  73 */   private static final byte[] _END_TAG = { 60, 47 };
/*  74 */   private static final byte[] _AMP_ = { 38, 97, 109, 112, 59 };
/*  75 */   static final AttrCompare COMPARE = new AttrCompare();
/*     */   static final String XML = "xml";
/*     */   static final String XMLNS = "xmlns";
/*  78 */   static final byte[] equalsStr = { 61, 34 };
/*     */   static final int NODE_BEFORE_DOCUMENT_ELEMENT = -1;
/*     */   static final int NODE_NOT_BEFORE_OR_AFTER_DOCUMENT_ELEMENT = 0;
/*     */   static final int NODE_AFTER_DOCUMENT_ELEMENT = 1;
/*     */   protected static final Attr nullNode;
/*     */   List nodeFilter;
/*     */   boolean _includeComments;
/*     */   
/*  86 */   static { try { nullNode = 
/*  87 */         DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument().createAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns");
/*  88 */       nullNode.setValue("");
/*     */     } catch (Exception e) {
/*  90 */       throw new RuntimeException("Unable to create nullNode" + e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  97 */   Set _xpathNodeSet = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 102 */   Node _excludeNode = null;
/* 103 */   OutputStream _writer = new UnsyncByteArrayOutputStream();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CanonicalizerBase(boolean includeComments)
/*     */   {
/* 111 */     this._includeComments = includeComments;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalizeSubTree(Node rootNode)
/*     */     throws CanonicalizationException
/*     */   {
/* 122 */     return engineCanonicalizeSubTree(rootNode, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalizeXPathNodeSet(Set xpathNodeSet)
/*     */     throws CanonicalizationException
/*     */   {
/* 132 */     this._xpathNodeSet = xpathNodeSet;
/* 133 */     return engineCanonicalizeXPathNodeSetInternal(XMLUtils.getOwnerDocument(this._xpathNodeSet));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalize(XMLSignatureInput input)
/*     */     throws CanonicalizationException
/*     */   {
/*     */     try
/*     */     {
/* 145 */       if (input.isExcludeComments()) {
/* 146 */         this._includeComments = false;
/*     */       }
/* 148 */       if (input.isOctetStream()) {
/* 149 */         return engineCanonicalize(input.getBytes());
/*     */       }
/* 151 */       if (input.isElement()) {
/* 152 */         return engineCanonicalizeSubTree(input.getSubNode(), input
/* 153 */           .getExcludeNode());
/*     */       }
/* 155 */       if (input.isNodeSet()) {
/* 156 */         this.nodeFilter = input.getNodeFilters();
/*     */         
/* 158 */         circumventBugIfNeeded(input);
/*     */         byte[] bytes;
/* 160 */         if (input.getSubNode() != null) {
/* 161 */           bytes = engineCanonicalizeXPathNodeSetInternal(input.getSubNode());
/*     */         }
/* 163 */         return engineCanonicalizeXPathNodeSet(input.getNodeSet());
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 168 */       return null;
/*     */     } catch (CanonicalizationException ex) {
/* 170 */       throw new CanonicalizationException("empty", ex);
/*     */     } catch (ParserConfigurationException ex) {
/* 172 */       throw new CanonicalizationException("empty", ex);
/*     */     } catch (IOException ex) {
/* 174 */       throw new CanonicalizationException("empty", ex);
/*     */     } catch (SAXException ex) {
/* 176 */       throw new CanonicalizationException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void setWriter(OutputStream _writer)
/*     */   {
/* 183 */     this._writer = _writer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] engineCanonicalizeSubTree(Node rootNode, Node excludeNode)
/*     */     throws CanonicalizationException
/*     */   {
/* 198 */     this._excludeNode = excludeNode;
/*     */     try {
/* 200 */       NameSpaceSymbTable ns = new NameSpaceSymbTable();
/* 201 */       int nodeLevel = -1;
/* 202 */       if ((rootNode instanceof Element))
/*     */       {
/* 204 */         getParentNameSpaces((Element)rootNode, ns);
/* 205 */         nodeLevel = 0;
/*     */       }
/* 207 */       canonicalizeSubTree(rootNode, ns, rootNode, nodeLevel);
/* 208 */       this._writer.close();
/* 209 */       if ((this._writer instanceof ByteArrayOutputStream)) {
/* 210 */         byte[] result = ((ByteArrayOutputStream)this._writer).toByteArray();
/* 211 */         if (this.reset) {
/* 212 */           ((ByteArrayOutputStream)this._writer).reset();
/*     */         }
/* 214 */         return result; }
/* 215 */       if ((this._writer instanceof UnsyncByteArrayOutputStream)) {
/* 216 */         byte[] result = ((UnsyncByteArrayOutputStream)this._writer).toByteArray();
/* 217 */         if (this.reset) {
/* 218 */           ((UnsyncByteArrayOutputStream)this._writer).reset();
/*     */         }
/* 220 */         return result;
/*     */       }
/* 222 */       return null;
/*     */     }
/*     */     catch (UnsupportedEncodingException ex) {
/* 225 */       throw new CanonicalizationException("empty", ex);
/*     */     } catch (IOException ex) {
/* 227 */       throw new CanonicalizationException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final void canonicalizeSubTree(Node currentNode, NameSpaceSymbTable ns, Node endnode, int documentLevel)
/*     */     throws CanonicalizationException, IOException
/*     */   {
/* 244 */     if (isVisibleInt(currentNode) == -1)
/* 245 */       return;
/* 246 */     Node sibling = null;
/* 247 */     Node parentNode = null;
/* 248 */     OutputStream writer = this._writer;
/* 249 */     Node excludeNode = this._excludeNode;
/* 250 */     boolean includeComments = this._includeComments;
/* 251 */     Map cache = new HashMap();
/*     */     for (;;) {
/* 253 */       switch (currentNode.getNodeType())
/*     */       {
/*     */       case 5: 
/*     */       case 10: 
/*     */       default: 
/*     */         break;
/*     */       
/*     */       case 2: 
/*     */       case 6: 
/*     */       case 12: 
/* 263 */         throw new CanonicalizationException("empty");
/*     */       
/*     */       case 9: 
/*     */       case 11: 
/* 267 */         ns.outputNodePush();
/* 268 */         sibling = currentNode.getFirstChild();
/* 269 */         break;
/*     */       
/*     */       case 8: 
/* 272 */         if (includeComments) {
/* 273 */           outputCommentToWriter((Comment)currentNode, writer, documentLevel);
/*     */         }
/* 275 */         break;
/*     */       
/*     */       case 7: 
/* 278 */         outputPItoWriter((ProcessingInstruction)currentNode, writer, documentLevel);
/* 279 */         break;
/*     */       
/*     */       case 3: 
/*     */       case 4: 
/* 283 */         outputTextToWriter(currentNode.getNodeValue(), writer);
/* 284 */         break;
/*     */       
/*     */       case 1: 
/* 287 */         documentLevel = 0;
/* 288 */         if (currentNode != excludeNode)
/*     */         {
/*     */ 
/* 291 */           Element currentElement = (Element)currentNode;
/*     */           
/* 293 */           ns.outputNodePush();
/* 294 */           writer.write(60);
/* 295 */           String name = currentElement.getTagName();
/* 296 */           UtfHelpper.writeByte(name, writer, cache);
/*     */           
/* 298 */           Iterator attrs = handleAttributesSubtree(currentElement, ns);
/* 299 */           if (attrs != null)
/*     */           {
/* 301 */             while (attrs.hasNext()) {
/* 302 */               Attr attr = (Attr)attrs.next();
/* 303 */               outputAttrToWriter(attr.getNodeName(), attr.getNodeValue(), writer, cache);
/*     */             }
/*     */           }
/* 306 */           writer.write(62);
/* 307 */           sibling = currentNode.getFirstChild();
/* 308 */           if (sibling == null) {
/* 309 */             writer.write(_END_TAG);
/* 310 */             UtfHelpper.writeStringToUtf8(name, writer);
/* 311 */             writer.write(62);
/*     */             
/* 313 */             ns.outputNodePop();
/* 314 */             if (parentNode != null) {
/* 315 */               sibling = currentNode.getNextSibling();
/*     */             }
/*     */           } else {
/* 318 */             parentNode = currentElement;
/*     */           }
/*     */         }
/*     */         break; }
/* 322 */       while ((sibling == null) && (parentNode != null)) {
/* 323 */         writer.write(_END_TAG);
/* 324 */         UtfHelpper.writeByte(((Element)parentNode).getTagName(), writer, cache);
/* 325 */         writer.write(62);
/*     */         
/* 327 */         ns.outputNodePop();
/* 328 */         if (parentNode == endnode)
/* 329 */           return;
/* 330 */         sibling = parentNode.getNextSibling();
/* 331 */         parentNode = parentNode.getParentNode();
/* 332 */         if (!(parentNode instanceof Element)) {
/* 333 */           documentLevel = 1;
/* 334 */           parentNode = null;
/*     */         }
/*     */       }
/* 337 */       if (sibling == null)
/* 338 */         return;
/* 339 */       currentNode = sibling;
/* 340 */       sibling = currentNode.getNextSibling();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private byte[] engineCanonicalizeXPathNodeSetInternal(Node doc)
/*     */     throws CanonicalizationException
/*     */   {
/*     */     try
/*     */     {
/* 350 */       canonicalizeXPathNodeSet(doc, doc);
/* 351 */       this._writer.close();
/* 352 */       if ((this._writer instanceof ByteArrayOutputStream)) {
/* 353 */         byte[] sol = ((ByteArrayOutputStream)this._writer).toByteArray();
/* 354 */         if (this.reset) {
/* 355 */           ((ByteArrayOutputStream)this._writer).reset();
/*     */         }
/* 357 */         return sol; }
/* 358 */       if ((this._writer instanceof UnsyncByteArrayOutputStream)) {
/* 359 */         byte[] result = ((UnsyncByteArrayOutputStream)this._writer).toByteArray();
/* 360 */         if (this.reset) {
/* 361 */           ((UnsyncByteArrayOutputStream)this._writer).reset();
/*     */         }
/* 363 */         return result;
/*     */       }
/* 365 */       return null;
/*     */     } catch (UnsupportedEncodingException ex) {
/* 367 */       throw new CanonicalizationException("empty", ex);
/*     */     } catch (IOException ex) {
/* 369 */       throw new CanonicalizationException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final void canonicalizeXPathNodeSet(Node currentNode, Node endnode)
/*     */     throws CanonicalizationException, IOException
/*     */   {
/* 384 */     if (isVisibleInt(currentNode) == -1)
/* 385 */       return;
/* 386 */     boolean currentNodeIsVisible = false;
/* 387 */     NameSpaceSymbTable ns = new NameSpaceSymbTable();
/* 388 */     if ((currentNode instanceof Element))
/* 389 */       getParentNameSpaces((Element)currentNode, ns);
/* 390 */     Node sibling = null;
/* 391 */     Node parentNode = null;
/* 392 */     OutputStream writer = this._writer;
/* 393 */     int documentLevel = -1;
/* 394 */     Map cache = new HashMap();
/*     */     for (;;) {
/* 396 */       switch (currentNode.getNodeType())
/*     */       {
/*     */       case 5: 
/*     */       case 10: 
/*     */       default: 
/*     */         break;
/*     */       
/*     */       case 2: 
/*     */       case 6: 
/*     */       case 12: 
/* 406 */         throw new CanonicalizationException("empty");
/*     */       
/*     */       case 9: 
/*     */       case 11: 
/* 410 */         ns.outputNodePush();
/*     */         
/* 412 */         sibling = currentNode.getFirstChild();
/* 413 */         break;
/*     */       
/*     */       case 8: 
/* 416 */         if ((this._includeComments) && (isVisibleDO(currentNode, ns.getLevel()) == 1)) {
/* 417 */           outputCommentToWriter((Comment)currentNode, writer, documentLevel);
/*     */         }
/* 419 */         break;
/*     */       
/*     */       case 7: 
/* 422 */         if (isVisible(currentNode))
/* 423 */           outputPItoWriter((ProcessingInstruction)currentNode, writer, documentLevel);
/* 424 */         break;
/*     */       
/*     */       case 3: 
/*     */       case 4: 
/* 428 */         if (isVisible(currentNode)) {
/* 429 */           outputTextToWriter(currentNode.getNodeValue(), writer);
/* 430 */           Node nextSibling = currentNode.getNextSibling();
/*     */           
/*     */ 
/*     */ 
/*     */           do
/*     */           {
/* 436 */             outputTextToWriter(nextSibling.getNodeValue(), writer);
/* 437 */             currentNode = nextSibling;
/* 438 */             sibling = currentNode.getNextSibling();nextSibling = nextSibling.getNextSibling();
/* 431 */             if (nextSibling == null) break;
/* 432 */           } while ((nextSibling.getNodeType() == 3) || 
/* 433 */             (nextSibling.getNodeType() == 
/* 434 */             4));
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 442 */         break;
/*     */       
/*     */       case 1: 
/* 445 */         documentLevel = 0;
/* 446 */         Element currentElement = (Element)currentNode;
/*     */         
/* 448 */         String name = null;
/* 449 */         int i = isVisibleDO(currentNode, ns.getLevel());
/* 450 */         if (i == -1) {
/* 451 */           sibling = currentNode.getNextSibling();
/*     */         }
/*     */         else {
/* 454 */           currentNodeIsVisible = i == 1;
/* 455 */           if (currentNodeIsVisible) {
/* 456 */             ns.outputNodePush();
/* 457 */             writer.write(60);
/* 458 */             name = currentElement.getTagName();
/* 459 */             UtfHelpper.writeByte(name, writer, cache);
/*     */           } else {
/* 461 */             ns.push();
/*     */           }
/*     */           
/* 464 */           Iterator attrs = handleAttributes(currentElement, ns);
/* 465 */           if (attrs != null)
/*     */           {
/* 467 */             while (attrs.hasNext()) {
/* 468 */               Attr attr = (Attr)attrs.next();
/* 469 */               outputAttrToWriter(attr.getNodeName(), attr.getNodeValue(), writer, cache);
/*     */             }
/*     */           }
/* 472 */           if (currentNodeIsVisible) {
/* 473 */             writer.write(62);
/*     */           }
/* 475 */           sibling = currentNode.getFirstChild();
/*     */           
/* 477 */           if (sibling == null) {
/* 478 */             if (currentNodeIsVisible) {
/* 479 */               writer.write(_END_TAG);
/* 480 */               UtfHelpper.writeByte(name, writer, cache);
/* 481 */               writer.write(62);
/*     */               
/* 483 */               ns.outputNodePop();
/*     */             } else {
/* 485 */               ns.pop();
/*     */             }
/* 487 */             if (parentNode != null) {
/* 488 */               sibling = currentNode.getNextSibling();
/*     */             }
/*     */           } else {
/* 491 */             parentNode = currentElement;
/*     */           }
/*     */         }
/*     */         break; }
/* 495 */       while ((sibling == null) && (parentNode != null)) {
/* 496 */         if (isVisible(parentNode)) {
/* 497 */           writer.write(_END_TAG);
/* 498 */           UtfHelpper.writeByte(((Element)parentNode).getTagName(), writer, cache);
/* 499 */           writer.write(62);
/*     */           
/* 501 */           ns.outputNodePop();
/*     */         } else {
/* 503 */           ns.pop();
/*     */         }
/* 505 */         if (parentNode == endnode)
/* 506 */           return;
/* 507 */         sibling = parentNode.getNextSibling();
/* 508 */         parentNode = parentNode.getParentNode();
/* 509 */         if (!(parentNode instanceof Element)) {
/* 510 */           parentNode = null;
/* 511 */           documentLevel = 1;
/*     */         }
/*     */       }
/* 514 */       if (sibling == null)
/* 515 */         return;
/* 516 */       currentNode = sibling;
/* 517 */       sibling = currentNode.getNextSibling();
/*     */     }
/*     */   }
/*     */   
/* 521 */   int isVisibleDO(Node currentNode, int level) { if (this.nodeFilter != null) {
/* 522 */       Iterator it = this.nodeFilter.iterator();
/* 523 */       while (it.hasNext()) {
/* 524 */         int i = ((NodeFilter)it.next()).isNodeIncludeDO(currentNode, level);
/* 525 */         if (i != 1)
/* 526 */           return i;
/*     */       }
/*     */     }
/* 529 */     if ((this._xpathNodeSet != null) && (!this._xpathNodeSet.contains(currentNode)))
/* 530 */       return 0;
/* 531 */     return 1;
/*     */   }
/*     */   
/* 534 */   int isVisibleInt(Node currentNode) { if (this.nodeFilter != null) {
/* 535 */       Iterator it = this.nodeFilter.iterator();
/* 536 */       while (it.hasNext()) {
/* 537 */         int i = ((NodeFilter)it.next()).isNodeInclude(currentNode);
/* 538 */         if (i != 1)
/* 539 */           return i;
/*     */       }
/*     */     }
/* 542 */     if ((this._xpathNodeSet != null) && (!this._xpathNodeSet.contains(currentNode)))
/* 543 */       return 0;
/* 544 */     return 1;
/*     */   }
/*     */   
/*     */   boolean isVisible(Node currentNode) {
/* 548 */     if (this.nodeFilter != null) {
/* 549 */       Iterator it = this.nodeFilter.iterator();
/* 550 */       while (it.hasNext()) {
/* 551 */         if (((NodeFilter)it.next()).isNodeInclude(currentNode) != 1)
/* 552 */           return false;
/*     */       }
/*     */     }
/* 555 */     if ((this._xpathNodeSet != null) && (!this._xpathNodeSet.contains(currentNode)))
/* 556 */       return false;
/* 557 */     return true;
/*     */   }
/*     */   
/*     */   void handleParent(Element e, NameSpaceSymbTable ns) {
/* 561 */     if (!e.hasAttributes()) {
/* 562 */       return;
/*     */     }
/* 564 */     NamedNodeMap attrs = e.getAttributes();
/* 565 */     int attrsLength = attrs.getLength();
/* 566 */     for (int i = 0; i < attrsLength; i++) {
/* 567 */       Attr N = (Attr)attrs.item(i);
/* 568 */       if ("http://www.w3.org/2000/xmlns/" == N.getNamespaceURI())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 573 */         String NName = N.getLocalName();
/* 574 */         String NValue = N.getNodeValue();
/* 575 */         if ((!"xml".equals(NName)) || 
/* 576 */           (!"http://www.w3.org/XML/1998/namespace".equals(NValue)))
/*     */         {
/*     */ 
/* 579 */           ns.addMapping(NName, NValue, N);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   final void getParentNameSpaces(Element el, NameSpaceSymbTable ns)
/*     */   {
/* 589 */     List parents = new ArrayList(10);
/* 590 */     Node n1 = el.getParentNode();
/* 591 */     if (!(n1 instanceof Element)) {
/* 592 */       return;
/*     */     }
/*     */     
/* 595 */     Element parent = (Element)n1;
/* 596 */     while (parent != null) {
/* 597 */       parents.add(parent);
/* 598 */       Node n = parent.getParentNode();
/* 599 */       if (!(n instanceof Element)) {
/*     */         break;
/*     */       }
/* 602 */       parent = (Element)n;
/*     */     }
/*     */     
/* 605 */     ListIterator it = parents.listIterator(parents.size());
/* 606 */     while (it.hasPrevious()) {
/* 607 */       Element ele = (Element)it.previous();
/* 608 */       handleParent(ele, ns);
/*     */     }
/*     */     Attr nsprefix;
/* 611 */     if (((nsprefix = ns.getMappingWithoutRendered("xmlns")) != null) && 
/* 612 */       ("".equals(nsprefix.getValue()))) {
/* 613 */       ns.addMappingAndRender("xmlns", "", nullNode);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   abstract Iterator handleAttributes(Element paramElement, NameSpaceSymbTable paramNameSpaceSymbTable)
/*     */     throws CanonicalizationException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   abstract Iterator handleAttributesSubtree(Element paramElement, NameSpaceSymbTable paramNameSpaceSymbTable)
/*     */     throws CanonicalizationException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   abstract void circumventBugIfNeeded(XMLSignatureInput paramXMLSignatureInput)
/*     */     throws CanonicalizationException, ParserConfigurationException, IOException, SAXException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final void outputAttrToWriter(String name, String value, OutputStream writer, Map cache)
/*     */     throws IOException
/*     */   {
/* 661 */     writer.write(32);
/* 662 */     UtfHelpper.writeByte(name, writer, cache);
/* 663 */     writer.write(equalsStr);
/*     */     
/* 665 */     int length = value.length();
/* 666 */     int i = 0;
/* 667 */     while (i < length) {
/* 668 */       char c = value.charAt(i++);
/*     */       byte[] toWrite;
/* 670 */       byte[] toWrite; byte[] toWrite; byte[] toWrite; byte[] toWrite; byte[] toWrite; switch (c)
/*     */       {
/*     */       case '&': 
/* 673 */         toWrite = _AMP_;
/* 674 */         break;
/*     */       
/*     */       case '<': 
/* 677 */         toWrite = _LT_;
/* 678 */         break;
/*     */       
/*     */       case '"': 
/* 681 */         toWrite = _QUOT_;
/* 682 */         break;
/*     */       
/*     */       case '\t': 
/* 685 */         toWrite = __X9_;
/* 686 */         break;
/*     */       
/*     */       case '\n': 
/* 689 */         toWrite = __XA_;
/* 690 */         break;
/*     */       
/*     */       case '\r': 
/* 693 */         toWrite = __XD_;
/* 694 */         break;
/*     */       
/*     */       default: 
/* 697 */         if (c < '') {
/* 698 */           writer.write(c);
/*     */         } else {
/* 700 */           UtfHelpper.writeCharToUtf8(c, writer);
/*     */         }
/* 702 */         break; }
/*     */       byte[] toWrite;
/* 704 */       writer.write(toWrite);
/*     */     }
/*     */     
/* 707 */     writer.write(34);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final void outputPItoWriter(ProcessingInstruction currentPI, OutputStream writer, int position)
/*     */     throws IOException
/*     */   {
/* 719 */     if (position == 1) {
/* 720 */       writer.write(10);
/*     */     }
/* 722 */     writer.write(_BEGIN_PI);
/*     */     
/* 724 */     String target = currentPI.getTarget();
/* 725 */     int length = target.length();
/*     */     
/* 727 */     for (int i = 0; i < length; i++) {
/* 728 */       char c = target.charAt(i);
/* 729 */       if (c == '\r') {
/* 730 */         writer.write(__XD_);
/*     */       }
/* 732 */       else if (c < '') {
/* 733 */         writer.write(c);
/*     */       } else {
/* 735 */         UtfHelpper.writeCharToUtf8(c, writer);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 740 */     String data = currentPI.getData();
/*     */     
/* 742 */     length = data.length();
/*     */     
/* 744 */     if (length > 0) {
/* 745 */       writer.write(32);
/*     */       
/* 747 */       for (int i = 0; i < length; i++) {
/* 748 */         char c = data.charAt(i);
/* 749 */         if (c == '\r') {
/* 750 */           writer.write(__XD_);
/*     */         } else {
/* 752 */           UtfHelpper.writeCharToUtf8(c, writer);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 757 */     writer.write(_END_PI);
/* 758 */     if (position == -1) {
/* 759 */       writer.write(10);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final void outputCommentToWriter(Comment currentComment, OutputStream writer, int position)
/*     */     throws IOException
/*     */   {
/* 771 */     if (position == 1) {
/* 772 */       writer.write(10);
/*     */     }
/* 774 */     writer.write(_BEGIN_COMM);
/*     */     
/* 776 */     String data = currentComment.getData();
/* 777 */     int length = data.length();
/*     */     
/* 779 */     for (int i = 0; i < length; i++) {
/* 780 */       char c = data.charAt(i);
/* 781 */       if (c == '\r') {
/* 782 */         writer.write(__XD_);
/*     */       }
/* 784 */       else if (c < '') {
/* 785 */         writer.write(c);
/*     */       } else {
/* 787 */         UtfHelpper.writeCharToUtf8(c, writer);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 792 */     writer.write(_END_COMM);
/* 793 */     if (position == -1) {
/* 794 */       writer.write(10);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final void outputTextToWriter(String text, OutputStream writer)
/*     */     throws IOException
/*     */   {
/* 806 */     int length = text.length();
/*     */     
/* 808 */     for (int i = 0; i < length; i++) {
/* 809 */       char c = text.charAt(i);
/*     */       byte[] toWrite;
/* 811 */       byte[] toWrite; byte[] toWrite; byte[] toWrite; switch (c)
/*     */       {
/*     */       case '&': 
/* 814 */         toWrite = _AMP_;
/* 815 */         break;
/*     */       
/*     */       case '<': 
/* 818 */         toWrite = _LT_;
/* 819 */         break;
/*     */       
/*     */       case '>': 
/* 822 */         toWrite = _GT_;
/* 823 */         break;
/*     */       
/*     */       case '\r': 
/* 826 */         toWrite = __XD_;
/* 827 */         break;
/*     */       
/*     */       default: 
/* 830 */         if (c < '') {
/* 831 */           writer.write(c);
/*     */         } else {
/* 833 */           UtfHelpper.writeCharToUtf8(c, writer);
/*     */         }
/* 835 */         break; }
/*     */       byte[] toWrite;
/* 837 */       writer.write(toWrite);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\c14n\implementations\CanonicalizerBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */