/*     */ package adsi.org.apache.xml.security.keys.keyresolver;
/*     */ 
/*     */ import adsi.org.apache.xml.security.keys.storage.StorageResolver;
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.crypto.SecretKey;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyResolver
/*     */ {
/*  47 */   static Log log = LogFactory.getLog(KeyResolver.class.getName());
/*     */   
/*     */ 
/*  50 */   static boolean _alreadyInitialized = false;
/*     */   
/*     */ 
/*  53 */   static List _resolverVector = null;
/*     */   
/*     */ 
/*  56 */   protected KeyResolverSpi _resolverSpi = null;
/*     */   
/*     */ 
/*  59 */   protected StorageResolver _storage = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private KeyResolver(String className)
/*     */     throws ClassNotFoundException, IllegalAccessException, InstantiationException
/*     */   {
/*  72 */     this._resolverSpi = 
/*  73 */       ((KeyResolverSpi)Class.forName(className).newInstance());
/*  74 */     this._resolverSpi.setGlobalResolver(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int length()
/*     */   {
/*  83 */     return _resolverVector.size();
/*     */   }
/*     */   
/*     */   public static void hit(Iterator hintI) {
/*  87 */     ResolverIterator hint = (ResolverIterator)hintI;
/*  88 */     int i = hint.i;
/*  89 */     if ((i != 1) && (hint.res == _resolverVector)) {
/*  90 */       List resolverVector = (List)((ArrayList)_resolverVector).clone();
/*  91 */       Object ob = resolverVector.remove(i - 1);
/*  92 */       resolverVector.add(0, ob);
/*  93 */       _resolverVector = resolverVector;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final X509Certificate getX509Certificate(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/* 114 */     List resolverVector = _resolverVector;
/* 115 */     for (int i = 0; i < resolverVector.size(); i++) {
/* 116 */       KeyResolver resolver = 
/* 117 */         (KeyResolver)resolverVector.get(i);
/*     */       
/* 119 */       if (resolver == null) {
/* 120 */         Object[] exArgs = {
/* 121 */           (element != null) && 
/* 122 */           (element.getNodeType() == 1) ? 
/* 123 */           element.getTagName() : 
/* 124 */           "null" };
/*     */         
/* 126 */         throw new KeyResolverException("utils.resolver.noClass", exArgs);
/*     */       }
/* 128 */       if (log.isDebugEnabled()) {
/* 129 */         log.debug("check resolvability by class " + resolver.getClass());
/*     */       }
/* 131 */       X509Certificate cert = resolver.resolveX509Certificate(element, BaseURI, storage);
/* 132 */       if (cert != null) {
/* 133 */         return cert;
/*     */       }
/*     */     }
/*     */     
/* 137 */     Object[] exArgs = {
/* 138 */       (element != null) && (element.getNodeType() == 1) ? 
/* 139 */       element.getTagName() : 
/* 140 */       "null" };
/*     */     
/* 142 */     throw new KeyResolverException("utils.resolver.noClass", exArgs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final PublicKey getPublicKey(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/* 158 */     List resolverVector = _resolverVector;
/* 159 */     for (int i = 0; i < resolverVector.size(); i++) {
/* 160 */       KeyResolver resolver = 
/* 161 */         (KeyResolver)resolverVector.get(i);
/*     */       
/* 163 */       if (resolver == null) {
/* 164 */         Object[] exArgs = {
/* 165 */           (element != null) && 
/* 166 */           (element.getNodeType() == 1) ? 
/* 167 */           element.getTagName() : 
/* 168 */           "null" };
/*     */         
/* 170 */         throw new KeyResolverException("utils.resolver.noClass", exArgs);
/*     */       }
/* 172 */       if (log.isDebugEnabled()) {
/* 173 */         log.debug("check resolvability by class " + resolver.getClass());
/*     */       }
/* 175 */       PublicKey cert = resolver.resolvePublicKey(element, BaseURI, storage);
/* 176 */       if (cert != null) {
/* 177 */         if ((i != 0) && (resolverVector == _resolverVector))
/*     */         {
/* 179 */           resolverVector = (List)((ArrayList)_resolverVector).clone();
/* 180 */           Object ob = resolverVector.remove(i);
/* 181 */           resolverVector.add(0, ob);
/* 182 */           _resolverVector = resolverVector;
/*     */         }
/* 184 */         return cert;
/*     */       }
/*     */     }
/*     */     
/* 188 */     Object[] exArgs = {
/* 189 */       (element != null) && (element.getNodeType() == 1) ? 
/* 190 */       element.getTagName() : 
/* 191 */       "null" };
/*     */     
/* 193 */     throw new KeyResolverException("utils.resolver.noClass", exArgs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void init()
/*     */   {
/* 201 */     if (!_alreadyInitialized) {
/* 202 */       _resolverVector = new ArrayList(10);
/* 203 */       _alreadyInitialized = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void register(String className)
/*     */     throws ClassNotFoundException, IllegalAccessException, InstantiationException
/*     */   {
/* 220 */     _resolverVector.add(new KeyResolver(className));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void registerAtStart(String className)
/*     */   {
/* 232 */     _resolverVector.add(0, className);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PublicKey resolvePublicKey(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/* 248 */     return this._resolverSpi.engineLookupAndResolvePublicKey(element, BaseURI, storage);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Certificate resolveX509Certificate(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/* 264 */     return this._resolverSpi.engineLookupResolveX509Certificate(element, BaseURI, 
/* 265 */       storage);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SecretKey resolveSecretKey(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/* 278 */     return this._resolverSpi.engineLookupAndResolveSecretKey(element, BaseURI, 
/* 279 */       storage);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProperty(String key, String value)
/*     */   {
/* 289 */     this._resolverSpi.engineSetProperty(key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getProperty(String key)
/*     */   {
/* 299 */     return this._resolverSpi.engineGetProperty(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean understandsProperty(String propertyToTest)
/*     */   {
/* 310 */     return this._resolverSpi.understandsProperty(propertyToTest);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 320 */   public String resolverClassName() { return this._resolverSpi.getClass().getName(); }
/*     */   
/*     */   static class ResolverIterator implements Iterator {
/*     */     List res;
/*     */     Iterator it;
/*     */     int i;
/*     */     
/*     */     public ResolverIterator(List list) {
/* 328 */       this.res = list;
/* 329 */       this.it = this.res.iterator();
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 333 */       return this.it.hasNext();
/*     */     }
/*     */     
/*     */     public Object next() {
/* 337 */       this.i += 1;
/* 338 */       KeyResolver resolver = (KeyResolver)this.it.next();
/* 339 */       if (resolver == null) {
/* 340 */         throw new RuntimeException("utils.resolver.noClass");
/*     */       }
/*     */       
/* 343 */       return resolver._resolverSpi;
/*     */     }
/*     */     
/*     */ 
/*     */     public void remove() {}
/*     */   }
/*     */   
/*     */ 
/*     */   public static Iterator iterator()
/*     */   {
/* 353 */     return new ResolverIterator(_resolverVector);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\keyresolver\KeyResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */