/*     */ package adsi.org.apache.xml.security.utils;
/*     */ 
/*     */ import adsi.org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import adsi.org.apache.xml.security.c14n.Canonicalizer;
/*     */ import adsi.org.apache.xml.security.c14n.InvalidCanonicalizerException;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLUtils
/*     */ {
/*  51 */   private static boolean ignoreLineBreaks = false;
/*     */   
/*     */   static {
/*  54 */     try { ignoreLineBreaks = Boolean.getBoolean(
/*  55 */         "adsi.org.apache.xml.security.ignoreLineBreaks");
/*     */     }
/*     */     catch (Exception localException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Element getNextElement(Node el)
/*     */   {
/*  70 */     while ((el != null) && (el.getNodeType() != 1)) {
/*  71 */       el = el.getNextSibling();
/*     */     }
/*  73 */     return (Element)el;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void getSet(Node rootNode, Set result, Node exclude, boolean com)
/*     */   {
/*  84 */     if ((exclude != null) && (isDescendantOrSelf(exclude, rootNode))) {
/*  85 */       return;
/*     */     }
/*  87 */     getSetRec(rootNode, result, exclude, com);
/*     */   }
/*     */   
/*     */   static final void getSetRec(Node rootNode, Set result, Node exclude, boolean com)
/*     */   {
/*  92 */     if (rootNode == exclude) {
/*  93 */       return;
/*     */     }
/*  95 */     switch (rootNode.getNodeType()) {
/*     */     case 1: 
/*  97 */       result.add(rootNode);
/*  98 */       Element el = (Element)rootNode;
/*  99 */       if (el.hasAttributes()) {
/* 100 */         NamedNodeMap nl = ((Element)rootNode).getAttributes();
/* 101 */         for (int i = 0; i < nl.getLength(); i++) {
/* 102 */           result.add(nl.item(i));
/*     */         }
/*     */       }
/*     */     
/*     */     case 9: 
/* 107 */       for (Node r = rootNode.getFirstChild(); r != null; r = r.getNextSibling()) {
/* 108 */         if (r.getNodeType() == 3) {
/* 109 */           result.add(r);
/* 110 */           while ((r != null) && (r.getNodeType() == 3)) {
/* 111 */             r = r.getNextSibling();
/*     */           }
/* 113 */           if (r == null)
/* 114 */             return;
/*     */         }
/* 116 */         getSetRec(r, result, exclude, com);
/*     */       }
/* 118 */       return;
/*     */     case 8: 
/* 120 */       if (com) {
/* 121 */         result.add(rootNode);
/*     */       }
/* 123 */       return;
/*     */     case 10: 
/* 125 */       return;
/*     */     }
/* 127 */     result.add(rootNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void outputDOM(Node contextNode, OutputStream os)
/*     */   {
/* 140 */     outputDOM(contextNode, os, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void outputDOM(Node contextNode, OutputStream os, boolean addPreamble)
/*     */   {
/*     */     try
/*     */     {
/* 156 */       if (addPreamble) {
/* 157 */         os.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n".getBytes());
/*     */       }
/*     */       
/* 160 */       os.write(
/* 161 */         Canonicalizer.getInstance(
/* 162 */         "http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments").canonicalizeSubtree(
/* 163 */         contextNode));
/*     */     }
/*     */     catch (IOException localIOException) {}catch (InvalidCanonicalizerException ex) {
/* 166 */       ex.printStackTrace();
/*     */     } catch (CanonicalizationException ex) {
/* 168 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void outputDOMc14nWithComments(Node contextNode, OutputStream os)
/*     */   {
/*     */     try
/*     */     {
/* 189 */       os.write(
/* 190 */         Canonicalizer.getInstance(
/* 191 */         "http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments").canonicalizeSubtree(
/* 192 */         contextNode));
/*     */     }
/*     */     catch (IOException localIOException) {}catch (InvalidCanonicalizerException localInvalidCanonicalizerException) {}catch (CanonicalizationException localCanonicalizationException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getFullTextChildrenFromElement(Element element)
/*     */   {
/* 214 */     StringBuffer sb = new StringBuffer();
/* 215 */     NodeList children = element.getChildNodes();
/* 216 */     int iMax = children.getLength();
/*     */     
/* 218 */     for (int i = 0; i < iMax; i++) {
/* 219 */       Node curr = children.item(i);
/*     */       
/* 221 */       if (curr.getNodeType() == 3) {
/* 222 */         sb.append(((Text)curr).getData());
/*     */       }
/*     */     }
/*     */     
/* 226 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/* 230 */   static String dsPrefix = null;
/* 231 */   static Map namePrefixes = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Element createElementInSignatureSpace(Document doc, String elementName)
/*     */   {
/* 242 */     if (doc == null) {
/* 243 */       throw new RuntimeException("Document is null");
/*     */     }
/*     */     
/* 246 */     if ((dsPrefix == null) || (dsPrefix.length() == 0)) {
/* 247 */       return doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", elementName);
/*     */     }
/* 249 */     String namePrefix = (String)namePrefixes.get(elementName);
/* 250 */     if (namePrefix == null) {
/* 251 */       StringBuffer tag = new StringBuffer(dsPrefix);
/* 252 */       tag.append(':');
/* 253 */       tag.append(elementName);
/* 254 */       namePrefix = tag.toString();
/* 255 */       namePrefixes.put(elementName, namePrefix);
/*     */     }
/* 257 */     return doc.createElementNS("http://www.w3.org/2000/09/xmldsig#", namePrefix);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean elementIsInSignatureSpace(Element element, String localName)
/*     */   {
/* 270 */     return ElementProxy.checker.isNamespaceElement(element, localName, "http://www.w3.org/2000/09/xmldsig#");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean elementIsInEncryptionSpace(Element element, String localName)
/*     */   {
/* 283 */     return ElementProxy.checker.isNamespaceElement(element, localName, "http://www.w3.org/2001/04/xmlenc#");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Document getOwnerDocument(Node node)
/*     */   {
/* 297 */     if (node.getNodeType() == 9) {
/* 298 */       return (Document)node;
/*     */     }
/*     */     try {
/* 301 */       return node.getOwnerDocument();
/*     */     } catch (NullPointerException npe) {
/* 303 */       throw new NullPointerException(I18n.translate("endorsed.jdk1.4.0") + 
/* 304 */         " Original message was \"" + 
/* 305 */         npe.getMessage() + "\"");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Document getOwnerDocument(Set xpathNodeSet)
/*     */   {
/* 320 */     NullPointerException npe = null;
/* 321 */     Iterator iterator = xpathNodeSet.iterator();
/* 322 */     while (iterator.hasNext()) {
/* 323 */       Node node = (Node)iterator.next();
/* 324 */       int nodeType = node.getNodeType();
/* 325 */       if (nodeType == 9) {
/* 326 */         return (Document)node;
/*     */       }
/*     */       try {
/* 329 */         if (nodeType == 2) {
/* 330 */           return ((Attr)node).getOwnerElement().getOwnerDocument();
/*     */         }
/* 332 */         return node.getOwnerDocument();
/*     */       } catch (NullPointerException e) {
/* 334 */         npe = e;
/*     */       }
/*     */     }
/*     */     
/* 338 */     throw new NullPointerException(I18n.translate("endorsed.jdk1.4.0") + 
/* 339 */       " Original message was \"" + (
/* 340 */       npe == null ? "" : npe.getMessage()) + "\"");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void addReturnToElement(Element e)
/*     */   {
/* 351 */     if (!ignoreLineBreaks) {
/* 352 */       Document doc = e.getOwnerDocument();
/* 353 */       e.appendChild(doc.createTextNode("\n"));
/*     */     }
/*     */   }
/*     */   
/*     */   public static void addReturnToElement(Document doc, HelperNodeList nl) {
/* 358 */     if (!ignoreLineBreaks) {
/* 359 */       nl.appendChild(doc.createTextNode("\n"));
/*     */     }
/*     */   }
/*     */   
/*     */   public static void addReturnBeforeChild(Element e, Node child) {
/* 364 */     if (!ignoreLineBreaks) {
/* 365 */       Document doc = e.getOwnerDocument();
/* 366 */       e.insertBefore(doc.createTextNode("\n"), child);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Set convertNodelistToSet(NodeList xpathNodeSet)
/*     */   {
/* 378 */     if (xpathNodeSet == null) {
/* 379 */       return new HashSet();
/*     */     }
/*     */     
/* 382 */     int length = xpathNodeSet.getLength();
/* 383 */     Set set = new HashSet(length);
/*     */     
/* 385 */     for (int i = 0; i < length; i++) {
/* 386 */       set.add(xpathNodeSet.item(i));
/*     */     }
/*     */     
/* 389 */     return set;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void circumventBug2650(Document doc)
/*     */   {
/* 406 */     Element documentElement = doc.getDocumentElement();
/*     */     
/*     */ 
/* 409 */     Attr xmlnsAttr = 
/* 410 */       documentElement.getAttributeNodeNS("http://www.w3.org/2000/xmlns/", "xmlns");
/*     */     
/* 412 */     if (xmlnsAttr == null) {
/* 413 */       documentElement.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns", "");
/*     */     }
/*     */     
/* 416 */     circumventBug2650internal(doc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void circumventBug2650internal(Node node)
/*     */   {
/* 426 */     Node parent = null;
/* 427 */     Node sibling = null;
/* 428 */     String namespaceNs = "http://www.w3.org/2000/xmlns/";
/*     */     for (;;) {
/* 430 */       switch (node.getNodeType()) {
/*     */       case 1: 
/* 432 */         Element element = (Element)node;
/* 433 */         if (element.hasChildNodes())
/*     */         {
/* 435 */           if (element.hasAttributes()) {
/* 436 */             NamedNodeMap attributes = element.getAttributes();
/* 437 */             int attributesLength = attributes.getLength();
/*     */             
/* 439 */             for (Node child = element.getFirstChild(); child != null; 
/* 440 */                 child = child.getNextSibling())
/*     */             {
/* 442 */               if (child.getNodeType() == 1)
/*     */               {
/*     */ 
/* 445 */                 Element childElement = (Element)child;
/*     */                 
/* 447 */                 for (int i = 0; i < attributesLength; i++) {
/* 448 */                   Attr currentAttr = (Attr)attributes.item(i);
/* 449 */                   if ("http://www.w3.org/2000/xmlns/" == currentAttr.getNamespaceURI())
/*     */                   {
/* 451 */                     if (!childElement.hasAttributeNS("http://www.w3.org/2000/xmlns/", 
/* 452 */                       currentAttr.getLocalName()))
/*     */                     {
/*     */ 
/* 455 */                       childElement.setAttributeNS("http://www.w3.org/2000/xmlns/", 
/* 456 */                         currentAttr.getName(), 
/* 457 */                         currentAttr.getNodeValue()); } }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         break;
/*     */       case 5: case 9: 
/* 465 */         parent = node;
/* 466 */         sibling = node.getFirstChild();
/*     */       }
/*     */       
/* 469 */       while ((sibling == null) && (parent != null)) {
/* 470 */         sibling = parent.getNextSibling();
/* 471 */         parent = parent.getParentNode();
/*     */       }
/* 473 */       if (sibling == null) {
/* 474 */         return;
/*     */       }
/*     */       
/* 477 */       node = sibling;
/* 478 */       sibling = node.getNextSibling();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Element selectDsNode(Node sibling, String nodeName, int number)
/*     */   {
/* 489 */     while (sibling != null) {
/* 490 */       if (ElementProxy.checker.isNamespaceElement(sibling, nodeName, "http://www.w3.org/2000/09/xmldsig#")) {
/* 491 */         if (number == 0) {
/* 492 */           return (Element)sibling;
/*     */         }
/* 494 */         number--;
/*     */       }
/* 496 */       sibling = sibling.getNextSibling();
/*     */     }
/* 498 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Element selectXencNode(Node sibling, String nodeName, int number)
/*     */   {
/* 509 */     while (sibling != null) {
/* 510 */       if (ElementProxy.checker.isNamespaceElement(sibling, nodeName, "http://www.w3.org/2001/04/xmlenc#")) {
/* 511 */         if (number == 0) {
/* 512 */           return (Element)sibling;
/*     */         }
/* 514 */         number--;
/*     */       }
/* 516 */       sibling = sibling.getNextSibling();
/*     */     }
/* 518 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Text selectDsNodeText(Node sibling, String nodeName, int number)
/*     */   {
/* 529 */     Node n = selectDsNode(sibling, nodeName, number);
/* 530 */     if (n == null) {
/* 531 */       return null;
/*     */     }
/* 533 */     n = n.getFirstChild();
/* 534 */     while ((n != null) && (n.getNodeType() != 3)) {
/* 535 */       n = n.getNextSibling();
/*     */     }
/* 537 */     return (Text)n;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Text selectNodeText(Node sibling, String uri, String nodeName, int number)
/*     */   {
/* 548 */     Node n = selectNode(sibling, uri, nodeName, number);
/* 549 */     if (n == null) {
/* 550 */       return null;
/*     */     }
/* 552 */     n = n.getFirstChild();
/* 553 */     while ((n != null) && (n.getNodeType() != 3)) {
/* 554 */       n = n.getNextSibling();
/*     */     }
/* 556 */     return (Text)n;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Element selectNode(Node sibling, String uri, String nodeName, int number)
/*     */   {
/* 567 */     while (sibling != null) {
/* 568 */       if (ElementProxy.checker.isNamespaceElement(sibling, nodeName, uri)) {
/* 569 */         if (number == 0) {
/* 570 */           return (Element)sibling;
/*     */         }
/* 572 */         number--;
/*     */       }
/* 574 */       sibling = sibling.getNextSibling();
/*     */     }
/* 576 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Element[] selectDsNodes(Node sibling, String nodeName)
/*     */   {
/* 585 */     return selectNodes(sibling, "http://www.w3.org/2000/09/xmldsig#", nodeName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Element[] selectNodes(Node sibling, String uri, String nodeName)
/*     */   {
/* 594 */     int size = 20;
/* 595 */     Element[] a = new Element[size];
/* 596 */     int curr = 0;
/*     */     
/* 598 */     while (sibling != null) {
/* 599 */       if (ElementProxy.checker.isNamespaceElement(sibling, nodeName, uri)) {
/* 600 */         a[(curr++)] = ((Element)sibling);
/* 601 */         if (size <= curr) {
/* 602 */           int cursize = size << 2;
/* 603 */           Element[] cp = new Element[cursize];
/* 604 */           System.arraycopy(a, 0, cp, 0, size);
/* 605 */           a = cp;
/* 606 */           size = cursize;
/*     */         }
/*     */       }
/* 609 */       sibling = sibling.getNextSibling();
/*     */     }
/* 611 */     Element[] af = new Element[curr];
/* 612 */     System.arraycopy(a, 0, af, 0, curr);
/* 613 */     return af;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Set excludeNodeFromSet(Node signatureElement, Set inputSet)
/*     */   {
/* 622 */     Set resultSet = new HashSet();
/* 623 */     Iterator iterator = inputSet.iterator();
/*     */     
/* 625 */     while (iterator.hasNext()) {
/* 626 */       Node inputNode = (Node)iterator.next();
/*     */       
/*     */ 
/* 629 */       if (!isDescendantOrSelf(signatureElement, inputNode)) {
/* 630 */         resultSet.add(inputNode);
/*     */       }
/*     */     }
/* 633 */     return resultSet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isDescendantOrSelf(Node ctx, Node descendantOrSelf)
/*     */   {
/* 646 */     if (ctx == descendantOrSelf) {
/* 647 */       return true;
/*     */     }
/*     */     
/* 650 */     Node parent = descendantOrSelf;
/*     */     for (;;)
/*     */     {
/* 653 */       if (parent == null) {
/* 654 */         return false;
/*     */       }
/*     */       
/* 657 */       if (parent == ctx) {
/* 658 */         return true;
/*     */       }
/*     */       
/* 661 */       if (parent.getNodeType() == 2) {
/* 662 */         parent = ((Attr)parent).getOwnerElement();
/*     */       } else {
/* 664 */         parent = parent.getParentNode();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean ignoreLineBreaks() {
/* 670 */     return ignoreLineBreaks;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\utils\XMLUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */