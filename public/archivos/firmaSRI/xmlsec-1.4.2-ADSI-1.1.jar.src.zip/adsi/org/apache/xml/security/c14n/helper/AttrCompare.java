/*     */ package adsi.org.apache.xml.security.c14n.helper;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Comparator;
/*     */ import org.w3c.dom.Attr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AttrCompare
/*     */   implements Comparator, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -7113259629930576230L;
/*     */   private static final int ATTR0_BEFORE_ATTR1 = -1;
/*     */   private static final int ATTR1_BEFORE_ATTR0 = 1;
/*     */   private static final String XMLNS = "http://www.w3.org/2000/xmlns/";
/*     */   
/*     */   public int compare(Object obj0, Object obj1)
/*     */   {
/*  72 */     Attr attr0 = (Attr)obj0;
/*  73 */     Attr attr1 = (Attr)obj1;
/*  74 */     String namespaceURI0 = attr0.getNamespaceURI();
/*  75 */     String namespaceURI1 = attr1.getNamespaceURI();
/*     */     
/*  77 */     boolean isNamespaceAttr0 = "http://www.w3.org/2000/xmlns/" == namespaceURI0;
/*  78 */     boolean isNamespaceAttr1 = "http://www.w3.org/2000/xmlns/" == namespaceURI1;
/*     */     
/*  80 */     if (isNamespaceAttr0) {
/*  81 */       if (isNamespaceAttr1)
/*     */       {
/*  83 */         String localname0 = attr0.getLocalName();
/*  84 */         String localname1 = attr1.getLocalName();
/*     */         
/*  86 */         if (localname0.equals("xmlns")) {
/*  87 */           localname0 = "";
/*     */         }
/*     */         
/*  90 */         if (localname1.equals("xmlns")) {
/*  91 */           localname1 = "";
/*     */         }
/*     */         
/*  94 */         return localname0.compareTo(localname1);
/*     */       }
/*     */       
/*  97 */       return -1;
/*     */     }
/*     */     
/* 100 */     if (isNamespaceAttr1)
/*     */     {
/* 102 */       return 1;
/*     */     }
/*     */     
/*     */ 
/* 106 */     if (namespaceURI0 == null) {
/* 107 */       if (namespaceURI1 == null) {
/* 108 */         String name0 = attr0.getName();
/* 109 */         String name1 = attr1.getName();
/* 110 */         return name0.compareTo(name1);
/*     */       }
/* 112 */       return -1;
/*     */     }
/*     */     
/* 115 */     if (namespaceURI1 == null) {
/* 116 */       return 1;
/*     */     }
/*     */     
/* 119 */     int a = namespaceURI0.compareTo(namespaceURI1);
/* 120 */     if (a != 0) {
/* 121 */       return a;
/*     */     }
/*     */     
/* 124 */     return attr0.getLocalName().compareTo(attr1.getLocalName());
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\c14n\helper\AttrCompare.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */