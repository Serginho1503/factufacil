/*    */ package adsi.org.apache.xml.security.keys.content.x509;
/*    */ 
/*    */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*    */ import adsi.org.apache.xml.security.utils.SignatureElementProxy;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMLX509CRL
/*    */   extends SignatureElementProxy
/*    */   implements XMLX509DataContent
/*    */ {
/*    */   public XMLX509CRL(Element element, String BaseURI)
/*    */     throws XMLSecurityException
/*    */   {
/* 43 */     super(element, BaseURI);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public XMLX509CRL(Document doc, byte[] crlBytes)
/*    */   {
/* 54 */     super(doc);
/*    */     
/* 56 */     addBase64Text(crlBytes);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getCRLBytes()
/*    */     throws XMLSecurityException
/*    */   {
/* 66 */     return getBytesFromTextChild();
/*    */   }
/*    */   
/*    */   public String getBaseLocalName()
/*    */   {
/* 71 */     return "X509CRL";
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\content\x509\XMLX509CRL.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */