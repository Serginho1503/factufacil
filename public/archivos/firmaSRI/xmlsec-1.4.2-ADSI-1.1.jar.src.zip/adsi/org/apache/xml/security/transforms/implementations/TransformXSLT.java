/*     */ package adsi.org.apache.xml.security.transforms.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import adsi.org.apache.xml.security.transforms.Transform;
/*     */ import adsi.org.apache.xml.security.transforms.TransformSpi;
/*     */ import adsi.org.apache.xml.security.transforms.TransformationException;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerConfigurationException;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransformXSLT
/*     */   extends TransformSpi
/*     */ {
/*     */   public static final String implementedTransformURI = "http://www.w3.org/TR/1999/REC-xslt-19991116";
/*     */   static final String XSLTSpecNS = "http://www.w3.org/1999/XSL/Transform";
/*     */   static final String defaultXSLTSpecNSprefix = "xslt";
/*     */   static final String XSLTSTYLESHEET = "stylesheet";
/*  63 */   private static Class xClass = null;
/*     */   
/*     */   static {
/*  66 */     try { xClass = Class.forName("javax.xml.XMLConstants");
/*     */     }
/*     */     catch (Exception localException) {}
/*     */   }
/*     */   
/*  71 */   static Log log = LogFactory.getLog(
/*  72 */     TransformXSLT.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String engineGetURI()
/*     */   {
/*  80 */     return "http://www.w3.org/TR/1999/REC-xslt-19991116";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, Transform _transformObject)
/*     */     throws IOException, TransformationException
/*     */   {
/*  95 */     return enginePerformTransform(input, null, _transformObject);
/*     */   }
/*     */   
/*     */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, OutputStream baos, Transform _transformObject)
/*     */     throws IOException, TransformationException
/*     */   {
/* 101 */     if (xClass == null) {
/* 102 */       Object[] exArgs = { "SECURE_PROCESSING_FEATURE not supported" };
/* 103 */       throw new TransformationException("generic.EmptyMessage", exArgs);
/*     */     }
/*     */     try {
/* 106 */       Element transformElement = _transformObject.getElement();
/*     */       
/* 108 */       Element _xsltElement = 
/* 109 */         XMLUtils.selectNode(transformElement.getFirstChild(), 
/* 110 */         "http://www.w3.org/1999/XSL/Transform", "stylesheet", 0);
/*     */       
/* 112 */       if (_xsltElement == null) {
/* 113 */         Object[] exArgs = { "xslt:stylesheet", "Transform" };
/*     */         
/* 115 */         throw new TransformationException("xml.WrongContent", exArgs);
/*     */       }
/*     */       
/* 118 */       TransformerFactory tFactory = TransformerFactory.newInstance();
/* 119 */       Class c = tFactory.getClass();
/* 120 */       Method m = c.getMethod("setFeature", new Class[] { String.class, Boolean.TYPE });
/*     */       
/* 122 */       m.invoke(tFactory, new Object[] { "http://javax.xml.XMLConstants/feature/secure-processing", Boolean.TRUE });
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 130 */       Source xmlSource = 
/* 131 */         new StreamSource(new ByteArrayInputStream(input.getBytes()));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 143 */       ByteArrayOutputStream os = new ByteArrayOutputStream();
/* 144 */       Transformer transformer = tFactory.newTransformer();
/* 145 */       DOMSource source = new DOMSource(_xsltElement);
/* 146 */       StreamResult result = new StreamResult(os);
/*     */       
/* 148 */       transformer.transform(source, result);
/*     */       
/* 150 */       Source stylesheet = 
/* 151 */         new StreamSource(new ByteArrayInputStream(os.toByteArray()));
/*     */       
/*     */ 
/* 154 */       Transformer transformer = tFactory.newTransformer(stylesheet);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/* 162 */         transformer.setOutputProperty(
/* 163 */           "{http://xml.apache.org/xalan}line-separator", "\n");
/*     */       } catch (Exception e) {
/* 165 */         log.warn("Unable to set Xalan line-separator property: " + 
/* 166 */           e.getMessage());
/*     */       }
/*     */       
/* 169 */       if (baos == null) {
/* 170 */         ByteArrayOutputStream baos1 = new ByteArrayOutputStream();
/* 171 */         StreamResult outputTarget = new StreamResult(baos1);
/* 172 */         transformer.transform(xmlSource, outputTarget);
/* 173 */         return new XMLSignatureInput(baos1.toByteArray());
/*     */       }
/* 175 */       StreamResult outputTarget = new StreamResult(baos);
/*     */       
/* 177 */       transformer.transform(xmlSource, outputTarget);
/* 178 */       XMLSignatureInput output = new XMLSignatureInput(null);
/* 179 */       output.setOutputStream(baos);
/* 180 */       return output;
/*     */     } catch (XMLSecurityException ex) {
/* 182 */       Object[] exArgs = { ex.getMessage() };
/*     */       
/* 184 */       throw new TransformationException("generic.EmptyMessage", exArgs, ex);
/*     */     } catch (TransformerConfigurationException ex) {
/* 186 */       Object[] exArgs = { ex.getMessage() };
/*     */       
/* 188 */       throw new TransformationException("generic.EmptyMessage", exArgs, ex);
/*     */     } catch (TransformerException ex) {
/* 190 */       Object[] exArgs = { ex.getMessage() };
/*     */       
/* 192 */       throw new TransformationException("generic.EmptyMessage", exArgs, ex);
/*     */     } catch (NoSuchMethodException ex) {
/* 194 */       Object[] exArgs = { ex.getMessage() };
/*     */       
/* 196 */       throw new TransformationException("generic.EmptyMessage", exArgs, ex);
/*     */     } catch (IllegalAccessException ex) {
/* 198 */       Object[] exArgs = { ex.getMessage() };
/*     */       
/* 200 */       throw new TransformationException("generic.EmptyMessage", exArgs, ex);
/*     */     } catch (InvocationTargetException ex) {
/* 202 */       Object[] exArgs = { ex.getMessage() };
/*     */       
/* 204 */       throw new TransformationException("generic.EmptyMessage", exArgs, ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\transforms\implementations\TransformXSLT.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */