package adsi.org.apache.xml.security.utils;

import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public abstract interface ElementChecker
{
  public abstract void guaranteeThatElementInCorrectSpace(ElementProxy paramElementProxy, Element paramElement)
    throws XMLSecurityException;
  
  public abstract boolean isNamespaceElement(Node paramNode, String paramString1, String paramString2);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\utils\ElementChecker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */