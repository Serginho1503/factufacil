/*    */ package adsi.org.apache.xml.security.utils.resolver.implementations;
/*    */ 
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReseteableFileInputStream
/*    */   extends InputStream
/*    */ {
/*    */   private FileInputStream fis;
/*    */   private String filename;
/*    */   
/*    */   public ReseteableFileInputStream(String filename)
/*    */     throws FileNotFoundException
/*    */   {
/* 26 */     this.filename = filename;
/* 27 */     this.fis = new FileInputStream(filename);
/*    */   }
/*    */   
/*    */   public int available() throws IOException
/*    */   {
/* 32 */     return this.fis.available();
/*    */   }
/*    */   
/*    */   public void close() throws IOException
/*    */   {
/* 37 */     this.fis.close();
/*    */   }
/*    */   
/*    */   public int read() throws IOException
/*    */   {
/* 42 */     return this.fis.read();
/*    */   }
/*    */   
/*    */   public int read(byte[] b, int off, int len) throws IOException
/*    */   {
/* 47 */     return this.fis.read(b, off, len);
/*    */   }
/*    */   
/*    */   public int read(byte[] b) throws IOException
/*    */   {
/* 52 */     return this.fis.read(b);
/*    */   }
/*    */   
/*    */   public long skip(long n) throws IOException
/*    */   {
/* 57 */     return this.fis.skip(n);
/*    */   }
/*    */   
/*    */   public synchronized void mark(int readlimit)
/*    */   {
/* 62 */     super.mark(readlimit);
/*    */   }
/*    */   
/*    */   public boolean markSupported()
/*    */   {
/* 67 */     return true;
/*    */   }
/*    */   
/*    */   public synchronized void reset() throws IOException
/*    */   {
/* 72 */     this.fis.close();
/* 73 */     this.fis = new FileInputStream(this.filename);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\utils\resolver\implementations\ReseteableFileInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */