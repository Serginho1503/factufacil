/*     */ package adsi.org.apache.xml.security.utils;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.Base64DecodingException;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.math.BigInteger;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Base64
/*     */ {
/*     */   public static final int BASE64DEFAULTLENGTH = 76;
/*     */   private static final int BASELENGTH = 255;
/*     */   private static final int LOOKUPLENGTH = 64;
/*     */   private static final int TWENTYFOURBITGROUP = 24;
/*     */   private static final int EIGHTBIT = 8;
/*     */   private static final int SIXTEENBIT = 16;
/*     */   private static final int FOURBYTE = 4;
/*     */   private static final int SIGN = -128;
/*     */   private static final char PAD = '=';
/*     */   
/*     */   static final byte[] getBytes(BigInteger big, int bitlen)
/*     */   {
/*  68 */     bitlen = bitlen + 7 >> 3 << 3;
/*     */     
/*  70 */     if (bitlen < big.bitLength()) {
/*  71 */       throw new IllegalArgumentException(
/*  72 */         I18n.translate("utils.Base64.IllegalBitlength"));
/*     */     }
/*     */     
/*  75 */     byte[] bigBytes = big.toByteArray();
/*     */     
/*  77 */     if ((big.bitLength() % 8 != 0) && 
/*  78 */       (big.bitLength() / 8 + 1 == bitlen / 8)) {
/*  79 */       return bigBytes;
/*     */     }
/*     */     
/*     */ 
/*  83 */     int startSrc = 0;
/*  84 */     int bigLen = bigBytes.length;
/*     */     
/*  86 */     if (big.bitLength() % 8 == 0) {
/*  87 */       startSrc = 1;
/*     */       
/*  89 */       bigLen--;
/*     */     }
/*     */     
/*  92 */     int startDst = bitlen / 8 - bigLen;
/*  93 */     byte[] resizedBytes = new byte[bitlen / 8];
/*     */     
/*  95 */     System.arraycopy(bigBytes, startSrc, resizedBytes, startDst, bigLen);
/*     */     
/*  97 */     return resizedBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String encode(BigInteger big)
/*     */   {
/* 108 */     return encode(getBytes(big, big.bitLength()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final byte[] encode(BigInteger big, int bitlen)
/*     */   {
/* 125 */     bitlen = bitlen + 7 >> 3 << 3;
/*     */     
/* 127 */     if (bitlen < big.bitLength()) {
/* 128 */       throw new IllegalArgumentException(
/* 129 */         I18n.translate("utils.Base64.IllegalBitlength"));
/*     */     }
/*     */     
/* 132 */     byte[] bigBytes = big.toByteArray();
/*     */     
/* 134 */     if ((big.bitLength() % 8 != 0) && 
/* 135 */       (big.bitLength() / 8 + 1 == bitlen / 8)) {
/* 136 */       return bigBytes;
/*     */     }
/*     */     
/*     */ 
/* 140 */     int startSrc = 0;
/* 141 */     int bigLen = bigBytes.length;
/*     */     
/* 143 */     if (big.bitLength() % 8 == 0) {
/* 144 */       startSrc = 1;
/*     */       
/* 146 */       bigLen--;
/*     */     }
/*     */     
/* 149 */     int startDst = bitlen / 8 - bigLen;
/* 150 */     byte[] resizedBytes = new byte[bitlen / 8];
/*     */     
/* 152 */     System.arraycopy(bigBytes, startSrc, resizedBytes, startDst, bigLen);
/*     */     
/* 154 */     return resizedBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final BigInteger decodeBigIntegerFromElement(Element element)
/*     */     throws Base64DecodingException
/*     */   {
/* 167 */     return new BigInteger(1, decode(element));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final BigInteger decodeBigIntegerFromText(Text text)
/*     */     throws Base64DecodingException
/*     */   {
/* 179 */     return new BigInteger(1, decode(text.getData()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void fillElementWithBigInteger(Element element, BigInteger biginteger)
/*     */   {
/* 192 */     String encodedInt = encode(biginteger);
/*     */     
/* 194 */     if (encodedInt.length() > 76) {
/* 195 */       encodedInt = "\n" + encodedInt + "\n";
/*     */     }
/*     */     
/* 198 */     Document doc = element.getOwnerDocument();
/* 199 */     Text text = doc.createTextNode(encodedInt);
/*     */     
/* 201 */     element.appendChild(text);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final byte[] decode(Element element)
/*     */     throws Base64DecodingException
/*     */   {
/* 217 */     Node sibling = element.getFirstChild();
/* 218 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 220 */     while (sibling != null) {
/* 221 */       if (sibling.getNodeType() == 3) {
/* 222 */         Text t = (Text)sibling;
/*     */         
/* 224 */         sb.append(t.getData());
/*     */       }
/* 226 */       sibling = sibling.getNextSibling();
/*     */     }
/*     */     
/* 229 */     return decode(sb.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final Element encodeToElement(Document doc, String localName, byte[] bytes)
/*     */   {
/* 244 */     Element el = XMLUtils.createElementInSignatureSpace(doc, localName);
/* 245 */     Text text = doc.createTextNode(encode(bytes));
/*     */     
/* 247 */     el.appendChild(text);
/*     */     
/* 249 */     return el;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final byte[] decode(byte[] base64)
/*     */     throws Base64DecodingException
/*     */   {
/* 262 */     return decodeInternal(base64, -1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String encode(byte[] binaryData)
/*     */   {
/* 275 */     return XMLUtils.ignoreLineBreaks() ? 
/* 276 */       encode(binaryData, Integer.MAX_VALUE) : 
/* 277 */       encode(binaryData, 76);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final byte[] decode(BufferedReader reader)
/*     */     throws IOException, Base64DecodingException
/*     */   {
/* 294 */     UnsyncByteArrayOutputStream baos = new UnsyncByteArrayOutputStream();
/*     */     
/*     */     String line;
/* 297 */     while ((line = reader.readLine()) != null) { String line;
/* 298 */       byte[] bytes = decode(line);
/*     */       
/* 300 */       baos.write(bytes);
/*     */     }
/*     */     
/* 303 */     return baos.toByteArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 314 */   private static final byte[] base64Alphabet = new byte['ÿ'];
/* 315 */   private static final char[] lookUpBase64Alphabet = new char[64];
/*     */   
/*     */   static
/*     */   {
/* 319 */     for (int i = 0; i < 255; i++) {
/* 320 */       base64Alphabet[i] = -1;
/*     */     }
/* 322 */     for (int i = 90; i >= 65; i--) {
/* 323 */       base64Alphabet[i] = ((byte)(i - 65));
/*     */     }
/* 325 */     for (int i = 122; i >= 97; i--) {
/* 326 */       base64Alphabet[i] = ((byte)(i - 97 + 26));
/*     */     }
/*     */     
/* 329 */     for (int i = 57; i >= 48; i--) {
/* 330 */       base64Alphabet[i] = ((byte)(i - 48 + 52));
/*     */     }
/*     */     
/* 333 */     base64Alphabet[43] = 62;
/* 334 */     base64Alphabet[47] = 63;
/*     */     
/* 336 */     for (int i = 0; i <= 25; i++) {
/* 337 */       lookUpBase64Alphabet[i] = ((char)(65 + i));
/*     */     }
/* 339 */     int i = 26; for (int j = 0; i <= 51; j++) {
/* 340 */       lookUpBase64Alphabet[i] = ((char)(97 + j));i++;
/*     */     }
/* 342 */     int i = 52; for (int j = 0; i <= 61; j++) {
/* 343 */       lookUpBase64Alphabet[i] = ((char)(48 + j));i++; }
/* 344 */     lookUpBase64Alphabet[62] = '+';
/* 345 */     lookUpBase64Alphabet[63] = '/';
/*     */   }
/*     */   
/*     */   protected static final boolean isWhiteSpace(byte octect)
/*     */   {
/* 350 */     return (octect == 32) || (octect == 13) || (octect == 10) || (octect == 9);
/*     */   }
/*     */   
/*     */   protected static final boolean isPad(byte octect) {
/* 354 */     return octect == 61;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String encode(byte[] binaryData, int length)
/*     */   {
/* 374 */     if (length < 4) {
/* 375 */       length = Integer.MAX_VALUE;
/*     */     }
/*     */     
/* 378 */     if (binaryData == null) {
/* 379 */       return null;
/*     */     }
/* 381 */     int lengthDataBits = binaryData.length * 8;
/* 382 */     if (lengthDataBits == 0) {
/* 383 */       return "";
/*     */     }
/*     */     
/* 386 */     int fewerThan24bits = lengthDataBits % 24;
/* 387 */     int numberTriplets = lengthDataBits / 24;
/* 388 */     int numberQuartet = fewerThan24bits != 0 ? numberTriplets + 1 : numberTriplets;
/* 389 */     int quartesPerLine = length / 4;
/* 390 */     int numberLines = (numberQuartet - 1) / quartesPerLine;
/* 391 */     char[] encodedData = (char[])null;
/*     */     
/* 393 */     encodedData = new char[numberQuartet * 4 + numberLines];
/*     */     
/* 395 */     byte k = 0;byte l = 0;byte b1 = 0;byte b2 = 0;byte b3 = 0;
/*     */     
/* 397 */     int encodedIndex = 0;
/* 398 */     int dataIndex = 0;
/* 399 */     int i = 0;
/*     */     
/*     */ 
/* 402 */     for (int line = 0; line < numberLines; line++) {
/* 403 */       for (int quartet = 0; quartet < 19; quartet++) {
/* 404 */         b1 = binaryData[(dataIndex++)];
/* 405 */         b2 = binaryData[(dataIndex++)];
/* 406 */         b3 = binaryData[(dataIndex++)];
/*     */         
/*     */ 
/* 409 */         l = (byte)(b2 & 0xF);
/* 410 */         k = (byte)(b1 & 0x3);
/*     */         
/* 412 */         byte val1 = (b1 & 0xFFFFFF80) == 0 ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/*     */         
/* 414 */         byte val2 = (b2 & 0xFFFFFF80) == 0 ? (byte)(b2 >> 4) : (byte)(b2 >> 4 ^ 0xF0);
/* 415 */         byte val3 = (b3 & 0xFFFFFF80) == 0 ? (byte)(b3 >> 6) : (byte)(b3 >> 6 ^ 0xFC);
/*     */         
/*     */ 
/* 418 */         encodedData[(encodedIndex++)] = lookUpBase64Alphabet[val1];
/* 419 */         encodedData[(encodedIndex++)] = lookUpBase64Alphabet[(val2 | k << 4)];
/* 420 */         encodedData[(encodedIndex++)] = lookUpBase64Alphabet[(l << 2 | val3)];
/* 421 */         encodedData[(encodedIndex++)] = lookUpBase64Alphabet[(b3 & 0x3F)];
/*     */         
/* 423 */         i++;
/*     */       }
/* 425 */       encodedData[(encodedIndex++)] = '\n';
/*     */     }
/* 428 */     for (; 
/* 428 */         i < numberTriplets; i++) {
/* 429 */       b1 = binaryData[(dataIndex++)];
/* 430 */       b2 = binaryData[(dataIndex++)];
/* 431 */       b3 = binaryData[(dataIndex++)];
/*     */       
/*     */ 
/* 434 */       l = (byte)(b2 & 0xF);
/* 435 */       k = (byte)(b1 & 0x3);
/*     */       
/* 437 */       byte val1 = (b1 & 0xFFFFFF80) == 0 ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/*     */       
/* 439 */       byte val2 = (b2 & 0xFFFFFF80) == 0 ? (byte)(b2 >> 4) : (byte)(b2 >> 4 ^ 0xF0);
/* 440 */       byte val3 = (b3 & 0xFFFFFF80) == 0 ? (byte)(b3 >> 6) : (byte)(b3 >> 6 ^ 0xFC);
/*     */       
/*     */ 
/* 443 */       encodedData[(encodedIndex++)] = lookUpBase64Alphabet[val1];
/* 444 */       encodedData[(encodedIndex++)] = lookUpBase64Alphabet[(val2 | k << 4)];
/* 445 */       encodedData[(encodedIndex++)] = lookUpBase64Alphabet[(l << 2 | val3)];
/* 446 */       encodedData[(encodedIndex++)] = lookUpBase64Alphabet[(b3 & 0x3F)];
/*     */     }
/*     */     
/*     */ 
/* 450 */     if (fewerThan24bits == 8) {
/* 451 */       b1 = binaryData[dataIndex];
/* 452 */       k = (byte)(b1 & 0x3);
/* 453 */       byte val1 = (b1 & 0xFFFFFF80) == 0 ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/* 454 */       encodedData[(encodedIndex++)] = lookUpBase64Alphabet[val1];
/* 455 */       encodedData[(encodedIndex++)] = lookUpBase64Alphabet[(k << 4)];
/* 456 */       encodedData[(encodedIndex++)] = '=';
/* 457 */       encodedData[(encodedIndex++)] = '=';
/* 458 */     } else if (fewerThan24bits == 16) {
/* 459 */       b1 = binaryData[dataIndex];
/* 460 */       b2 = binaryData[(dataIndex + 1)];
/* 461 */       l = (byte)(b2 & 0xF);
/* 462 */       k = (byte)(b1 & 0x3);
/*     */       
/* 464 */       byte val1 = (b1 & 0xFFFFFF80) == 0 ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/* 465 */       byte val2 = (b2 & 0xFFFFFF80) == 0 ? (byte)(b2 >> 4) : (byte)(b2 >> 4 ^ 0xF0);
/*     */       
/* 467 */       encodedData[(encodedIndex++)] = lookUpBase64Alphabet[val1];
/* 468 */       encodedData[(encodedIndex++)] = lookUpBase64Alphabet[(val2 | k << 4)];
/* 469 */       encodedData[(encodedIndex++)] = lookUpBase64Alphabet[(l << 2)];
/* 470 */       encodedData[(encodedIndex++)] = '=';
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 475 */     return new String(encodedData);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final byte[] decode(String encoded)
/*     */     throws Base64DecodingException
/*     */   {
/* 487 */     if (encoded == null)
/* 488 */       return null;
/* 489 */     byte[] bytes = new byte[encoded.length()];
/* 490 */     int len = getBytesInternal(encoded, bytes);
/* 491 */     return decodeInternal(bytes, len);
/*     */   }
/*     */   
/*     */   protected static final int getBytesInternal(String s, byte[] result) {
/* 495 */     int length = s.length();
/*     */     
/* 497 */     int newSize = 0;
/* 498 */     for (int i = 0; i < length; i++) {
/* 499 */       byte dataS = (byte)s.charAt(i);
/* 500 */       if (!isWhiteSpace(dataS))
/* 501 */         result[(newSize++)] = dataS;
/*     */     }
/* 503 */     return newSize;
/*     */   }
/*     */   
/*     */   protected static final byte[] decodeInternal(byte[] base64Data, int len) throws Base64DecodingException
/*     */   {
/* 508 */     if (len == -1) {
/* 509 */       len = removeWhiteSpace(base64Data);
/*     */     }
/* 511 */     if (len % 4 != 0) {
/* 512 */       throw new Base64DecodingException("decoding.divisible.four");
/*     */     }
/*     */     
/*     */ 
/* 516 */     int numberQuadruple = len / 4;
/*     */     
/* 518 */     if (numberQuadruple == 0) {
/* 519 */       return new byte[0];
/*     */     }
/* 521 */     byte[] decodedData = (byte[])null;
/* 522 */     byte b1 = 0;byte b2 = 0;byte b3 = 0;byte b4 = 0;
/*     */     
/*     */ 
/* 525 */     int i = 0;
/* 526 */     int encodedIndex = 0;
/* 527 */     int dataIndex = 0;
/*     */     
/*     */ 
/* 530 */     dataIndex = (numberQuadruple - 1) * 4;
/* 531 */     encodedIndex = (numberQuadruple - 1) * 3;
/*     */     
/* 533 */     b1 = base64Alphabet[base64Data[(dataIndex++)]];
/* 534 */     b2 = base64Alphabet[base64Data[(dataIndex++)]];
/* 535 */     if ((b1 == -1) || (b2 == -1)) {
/* 536 */       throw new Base64DecodingException("decoding.general");
/*     */     }
/*     */     
/*     */     byte d3;
/*     */     
/* 541 */     b3 = base64Alphabet[(d3 = base64Data[(dataIndex++)])];
/* 542 */     byte d4; b4 = base64Alphabet[(d4 = base64Data[(dataIndex++)])];
/* 543 */     if ((b3 == -1) || (b4 == -1))
/*     */     {
/* 545 */       if ((isPad(d3)) && (isPad(d4))) {
/* 546 */         if ((b2 & 0xF) != 0)
/* 547 */           throw new Base64DecodingException("decoding.general");
/* 548 */         decodedData = new byte[encodedIndex + 1];
/* 549 */         decodedData[encodedIndex] = ((byte)(b1 << 2 | b2 >> 4));
/* 550 */       } else if ((!isPad(d3)) && (isPad(d4))) {
/* 551 */         if ((b3 & 0x3) != 0)
/* 552 */           throw new Base64DecodingException("decoding.general");
/* 553 */         decodedData = new byte[encodedIndex + 2];
/* 554 */         decodedData[(encodedIndex++)] = ((byte)(b1 << 2 | b2 >> 4));
/* 555 */         decodedData[encodedIndex] = ((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/*     */       } else {
/* 557 */         throw new Base64DecodingException("decoding.general");
/*     */       }
/*     */     }
/*     */     else {
/* 561 */       decodedData = new byte[encodedIndex + 3];
/* 562 */       decodedData[(encodedIndex++)] = ((byte)(b1 << 2 | b2 >> 4));
/* 563 */       decodedData[(encodedIndex++)] = ((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/* 564 */       decodedData[(encodedIndex++)] = ((byte)(b3 << 6 | b4));
/*     */     }
/* 566 */     encodedIndex = 0;
/* 567 */     dataIndex = 0;
/*     */     
/* 569 */     for (i = numberQuadruple - 1; i > 0; i--) {
/* 570 */       b1 = base64Alphabet[base64Data[(dataIndex++)]];
/* 571 */       b2 = base64Alphabet[base64Data[(dataIndex++)]];
/* 572 */       b3 = base64Alphabet[base64Data[(dataIndex++)]];
/* 573 */       b4 = base64Alphabet[base64Data[(dataIndex++)]];
/*     */       
/* 575 */       if ((b1 == -1) || 
/* 576 */         (b2 == -1) || 
/* 577 */         (b3 == -1) || 
/* 578 */         (b4 == -1)) {
/* 579 */         throw new Base64DecodingException("decoding.general");
/*     */       }
/*     */       
/* 582 */       decodedData[(encodedIndex++)] = ((byte)(b1 << 2 | b2 >> 4));
/* 583 */       decodedData[(encodedIndex++)] = ((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/* 584 */       decodedData[(encodedIndex++)] = ((byte)(b3 << 6 | b4));
/*     */     }
/* 586 */     return decodedData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void decode(String base64Data, OutputStream os)
/*     */     throws Base64DecodingException, IOException
/*     */   {
/* 598 */     byte[] bytes = new byte[base64Data.length()];
/* 599 */     int len = getBytesInternal(base64Data, bytes);
/* 600 */     decode(bytes, os, len);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void decode(byte[] base64Data, OutputStream os)
/*     */     throws Base64DecodingException, IOException
/*     */   {
/* 612 */     decode(base64Data, os, -1);
/*     */   }
/*     */   
/*     */   protected static final void decode(byte[] base64Data, OutputStream os, int len)
/*     */     throws Base64DecodingException, IOException
/*     */   {
/* 618 */     if (len == -1) {
/* 619 */       len = removeWhiteSpace(base64Data);
/*     */     }
/* 621 */     if (len % 4 != 0) {
/* 622 */       throw new Base64DecodingException("decoding.divisible.four");
/*     */     }
/*     */     
/*     */ 
/* 626 */     int numberQuadruple = len / 4;
/*     */     
/* 628 */     if (numberQuadruple == 0) {
/* 629 */       return;
/*     */     }
/*     */     
/* 632 */     byte b1 = 0;byte b2 = 0;byte b3 = 0;byte b4 = 0;
/*     */     
/* 634 */     int i = 0;
/*     */     
/* 636 */     int dataIndex = 0;
/*     */     
/*     */ 
/* 639 */     for (i = numberQuadruple - 1; i > 0; i--) {
/* 640 */       b1 = base64Alphabet[base64Data[(dataIndex++)]];
/* 641 */       b2 = base64Alphabet[base64Data[(dataIndex++)]];
/* 642 */       b3 = base64Alphabet[base64Data[(dataIndex++)]];
/* 643 */       b4 = base64Alphabet[base64Data[(dataIndex++)]];
/* 644 */       if ((b1 == -1) || 
/* 645 */         (b2 == -1) || 
/* 646 */         (b3 == -1) || 
/* 647 */         (b4 == -1)) {
/* 648 */         throw new Base64DecodingException("decoding.general");
/*     */       }
/*     */       
/*     */ 
/* 652 */       os.write((byte)(b1 << 2 | b2 >> 4));
/* 653 */       os.write((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/* 654 */       os.write((byte)(b3 << 6 | b4));
/*     */     }
/* 656 */     b1 = base64Alphabet[base64Data[(dataIndex++)]];
/* 657 */     b2 = base64Alphabet[base64Data[(dataIndex++)]];
/*     */     
/*     */ 
/* 660 */     if ((b1 == -1) || 
/* 661 */       (b2 == -1)) {
/* 662 */       throw new Base64DecodingException("decoding.general");
/*     */     }
/*     */     
/*     */     byte d3;
/* 666 */     b3 = base64Alphabet[(d3 = base64Data[(dataIndex++)])];
/* 667 */     byte d4; b4 = base64Alphabet[(d4 = base64Data[(dataIndex++)])];
/* 668 */     if ((b3 == -1) || 
/* 669 */       (b4 == -1)) {
/* 670 */       if ((isPad(d3)) && (isPad(d4))) {
/* 671 */         if ((b2 & 0xF) != 0)
/* 672 */           throw new Base64DecodingException("decoding.general");
/* 673 */         os.write((byte)(b1 << 2 | b2 >> 4));
/* 674 */       } else if ((!isPad(d3)) && (isPad(d4))) {
/* 675 */         if ((b3 & 0x3) != 0)
/* 676 */           throw new Base64DecodingException("decoding.general");
/* 677 */         os.write((byte)(b1 << 2 | b2 >> 4));
/* 678 */         os.write((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/*     */       } else {
/* 680 */         throw new Base64DecodingException("decoding.general");
/*     */       }
/*     */     }
/*     */     else {
/* 684 */       os.write((byte)(b1 << 2 | b2 >> 4));
/* 685 */       os.write((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/* 686 */       os.write((byte)(b3 << 6 | b4));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void decode(InputStream is, OutputStream os)
/*     */     throws Base64DecodingException, IOException
/*     */   {
/* 702 */     byte b1 = 0;byte b2 = 0;byte b3 = 0;byte b4 = 0;
/*     */     
/* 704 */     int index = 0;
/* 705 */     byte[] data = new byte[4];
/*     */     
/*     */     int read;
/* 708 */     while ((read = is.read()) > 0) { int read;
/* 709 */       byte readed = (byte)read;
/* 710 */       if (!isWhiteSpace(readed))
/*     */       {
/*     */ 
/* 713 */         if (isPad(readed)) {
/* 714 */           data[(index++)] = readed;
/* 715 */           if (index != 3) break;
/* 716 */           data[(index++)] = ((byte)is.read());
/* 717 */           break;
/*     */         }
/*     */         
/*     */ 
/* 721 */         if ((data[(index++)] = readed) == -1) {
/* 722 */           throw new Base64DecodingException("decoding.general");
/*     */         }
/*     */         
/* 725 */         if (index == 4)
/*     */         {
/*     */ 
/* 728 */           index = 0;
/* 729 */           b1 = base64Alphabet[data[0]];
/* 730 */           b2 = base64Alphabet[data[1]];
/* 731 */           b3 = base64Alphabet[data[2]];
/* 732 */           b4 = base64Alphabet[data[3]];
/*     */           
/* 734 */           os.write((byte)(b1 << 2 | b2 >> 4));
/* 735 */           os.write((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/* 736 */           os.write((byte)(b3 << 6 | b4));
/*     */         }
/*     */       }
/*     */     }
/* 740 */     byte d1 = data[0];byte d2 = data[1];byte d3 = data[2];byte d4 = data[3];
/* 741 */     b1 = base64Alphabet[d1];
/* 742 */     b2 = base64Alphabet[d2];
/* 743 */     b3 = base64Alphabet[d3];
/* 744 */     b4 = base64Alphabet[d4];
/* 745 */     if ((b3 == -1) || 
/* 746 */       (b4 == -1)) {
/* 747 */       if ((isPad(d3)) && (isPad(d4))) {
/* 748 */         if ((b2 & 0xF) != 0)
/* 749 */           throw new Base64DecodingException("decoding.general");
/* 750 */         os.write((byte)(b1 << 2 | b2 >> 4));
/* 751 */       } else if ((!isPad(d3)) && (isPad(d4))) {
/* 752 */         b3 = base64Alphabet[d3];
/* 753 */         if ((b3 & 0x3) != 0)
/* 754 */           throw new Base64DecodingException("decoding.general");
/* 755 */         os.write((byte)(b1 << 2 | b2 >> 4));
/* 756 */         os.write((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/*     */       } else {
/* 758 */         throw new Base64DecodingException("decoding.general");
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 763 */       os.write((byte)(b1 << 2 | b2 >> 4));
/* 764 */       os.write((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/* 765 */       os.write((byte)(b3 << 6 | b4));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static final int removeWhiteSpace(byte[] data)
/*     */   {
/* 777 */     if (data == null) {
/* 778 */       return 0;
/*     */     }
/*     */     
/* 781 */     int newSize = 0;
/* 782 */     int len = data.length;
/* 783 */     for (int i = 0; i < len; i++) {
/* 784 */       byte dataS = data[i];
/* 785 */       if (!isWhiteSpace(dataS))
/* 786 */         data[(newSize++)] = dataS;
/*     */     }
/* 788 */     return newSize;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\utils\Base64.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */