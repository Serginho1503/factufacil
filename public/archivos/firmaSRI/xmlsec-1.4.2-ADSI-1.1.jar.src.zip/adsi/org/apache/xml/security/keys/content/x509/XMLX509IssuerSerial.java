/*     */ package adsi.org.apache.xml.security.keys.content.x509;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.utils.RFC2253Parser;
/*     */ import adsi.org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.math.BigInteger;
/*     */ import java.security.Principal;
/*     */ import java.security.cert.X509Certificate;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLX509IssuerSerial
/*     */   extends SignatureElementProxy
/*     */   implements XMLX509DataContent
/*     */ {
/*  40 */   static Log log = LogFactory.getLog(
/*  41 */     XMLX509IssuerSerial.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509IssuerSerial(Element element, String baseURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  52 */     super(element, baseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509IssuerSerial(Document doc, String x509IssuerName, BigInteger x509SerialNumber)
/*     */   {
/*  65 */     super(doc);
/*  66 */     XMLUtils.addReturnToElement(this._constructionElement);
/*  67 */     addTextElement(x509IssuerName, "X509IssuerName");
/*  68 */     addTextElement(x509SerialNumber.toString(), "X509SerialNumber");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509IssuerSerial(Document doc, String x509IssuerName, String x509SerialNumber)
/*     */   {
/*  80 */     this(doc, x509IssuerName, new BigInteger(x509SerialNumber));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509IssuerSerial(Document doc, String x509IssuerName, int x509SerialNumber)
/*     */   {
/*  93 */     this(doc, x509IssuerName, new BigInteger(Integer.toString(x509SerialNumber)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509IssuerSerial(Document doc, X509Certificate x509certificate)
/*     */   {
/* 106 */     this(doc, RFC2253Parser.normalize(x509certificate.getIssuerDN().getName()), x509certificate.getSerialNumber());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BigInteger getSerialNumber()
/*     */   {
/* 116 */     String text = getTextFromChildElement(
/* 117 */       "X509SerialNumber", "http://www.w3.org/2000/09/xmldsig#");
/* 118 */     if (log.isDebugEnabled()) {
/* 119 */       log.debug("X509SerialNumber text: " + text);
/*     */     }
/* 121 */     return new BigInteger(text);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSerialNumberInteger()
/*     */   {
/* 130 */     return getSerialNumber().intValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getIssuerName()
/*     */   {
/* 140 */     return 
/* 141 */       RFC2253Parser.normalize(
/* 142 */       getTextFromChildElement("X509IssuerName", 
/* 143 */       "http://www.w3.org/2000/09/xmldsig#"));
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 149 */     if (obj == null) {
/* 150 */       return false;
/*     */     }
/* 152 */     if (!getClass().getName().equals(obj.getClass().getName())) {
/* 153 */       return false;
/*     */     }
/*     */     
/* 156 */     XMLX509IssuerSerial other = (XMLX509IssuerSerial)obj;
/*     */     
/*     */ 
/* 159 */     return (getSerialNumber().equals(other.getSerialNumber())) && (getIssuerName().equals(other.getIssuerName()));
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 165 */     return 82;
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 170 */     return "X509IssuerSerial";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\content\x509\XMLX509IssuerSerial.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */