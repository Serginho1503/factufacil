/*     */ package adsi.org.apache.xml.security.transforms;
/*     */ 
/*     */ import adsi.org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import adsi.org.apache.xml.security.c14n.InvalidCanonicalizerException;
/*     */ import adsi.org.apache.xml.security.exceptions.AlgorithmAlreadyRegisteredException;
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import adsi.org.apache.xml.security.utils.HelperNodeList;
/*     */ import adsi.org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Transform
/*     */   extends SignatureElementProxy
/*     */ {
/*  62 */   static Log log = LogFactory.getLog(Transform.class.getName());
/*     */   
/*     */ 
/*  65 */   static boolean _alreadyInitialized = false;
/*     */   
/*     */ 
/*  68 */   static Map _transformHash = null;
/*     */   
/*  70 */   static HashMap classesHash = new HashMap();
/*     */   
/*     */ 
/*  73 */   protected TransformSpi transformSpi = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Transform(Document doc, String algorithmURI, NodeList contextNodes)
/*     */     throws InvalidTransformException
/*     */   {
/*  88 */     super(doc);
/*     */     
/*  90 */     this._constructionElement.setAttributeNS(null, "Algorithm", 
/*  91 */       algorithmURI);
/*     */     
/*  93 */     this.transformSpi = 
/*  94 */       getImplementingClass(algorithmURI);
/*     */     
/*  96 */     if (this.transformSpi == null) {
/*  97 */       Object[] exArgs = { algorithmURI };
/*     */       
/*  99 */       throw new InvalidTransformException(
/* 100 */         "signature.Transform.UnknownTransform", exArgs);
/*     */     }
/* 102 */     if (log.isDebugEnabled()) {
/* 103 */       log.debug("Create URI \"" + algorithmURI + "\" class \"" + 
/* 104 */         this.transformSpi.getClass() + "\"");
/* 105 */       log.debug("The NodeList is " + contextNodes);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 112 */     if (contextNodes != null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 119 */       for (int i = 0; i < contextNodes.getLength(); i++) {
/* 120 */         this._constructionElement.appendChild(contextNodes.item(i).cloneNode(true));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Transform(Element element, String BaseURI)
/*     */     throws InvalidTransformException, TransformationException, XMLSecurityException
/*     */   {
/* 141 */     super(element, BaseURI);
/*     */     
/*     */ 
/* 144 */     String AlgorithmURI = element.getAttributeNS(null, "Algorithm");
/*     */     
/* 146 */     if ((AlgorithmURI == null) || (AlgorithmURI.length() == 0)) {
/* 147 */       Object[] exArgs = { "Algorithm", 
/* 148 */         "Transform" };
/*     */       
/* 150 */       throw new TransformationException("xml.WrongContent", exArgs);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 155 */     this.transformSpi = getImplementingClass(AlgorithmURI);
/*     */     
/*     */ 
/* 158 */     if (this.transformSpi == null) {
/* 159 */       Object[] exArgs = { AlgorithmURI };
/*     */       
/* 161 */       throw new InvalidTransformException(
/* 162 */         "signature.Transform.UnknownTransform", exArgs);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final Transform getInstance(Document doc, String algorithmURI)
/*     */     throws InvalidTransformException
/*     */   {
/* 176 */     return getInstance(doc, algorithmURI, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final Transform getInstance(Document doc, String algorithmURI, Element contextChild)
/*     */     throws InvalidTransformException
/*     */   {
/* 192 */     HelperNodeList contextNodes = new HelperNodeList();
/*     */     
/* 194 */     XMLUtils.addReturnToElement(doc, contextNodes);
/* 195 */     contextNodes.appendChild(contextChild);
/* 196 */     XMLUtils.addReturnToElement(doc, contextNodes);
/*     */     
/* 198 */     return getInstance(doc, algorithmURI, contextNodes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final Transform getInstance(Document doc, String algorithmURI, NodeList contextNodes)
/*     */     throws InvalidTransformException
/*     */   {
/* 213 */     return new Transform(doc, algorithmURI, contextNodes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void init()
/*     */   {
/* 222 */     if (!_alreadyInitialized) {
/* 223 */       _transformHash = new HashMap(10);
/* 224 */       _alreadyInitialized = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void register(String algorithmURI, String implementingClass)
/*     */     throws AlgorithmAlreadyRegisteredException
/*     */   {
/* 242 */     Object registeredClass = null;
/*     */     try {
/* 244 */       registeredClass = getImplementingClass(algorithmURI);
/*     */     } catch (InvalidTransformException e1) {
/* 246 */       Object[] exArgs = { algorithmURI, registeredClass };
/* 247 */       throw new AlgorithmAlreadyRegisteredException(
/* 248 */         "algorithm.alreadyRegistered", exArgs);
/*     */     }
/*     */     
/* 251 */     if (registeredClass != null) {
/* 252 */       Object[] exArgs = { algorithmURI, registeredClass };
/* 253 */       throw new AlgorithmAlreadyRegisteredException(
/* 254 */         "algorithm.alreadyRegistered", exArgs);
/*     */     }
/*     */     try
/*     */     {
/* 258 */       _transformHash.put(algorithmURI, Class.forName(implementingClass));
/*     */     }
/*     */     catch (ClassNotFoundException e) {
/* 261 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getURI()
/*     */   {
/* 272 */     return this._constructionElement.getAttributeNS(null, "Algorithm");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput performTransform(XMLSignatureInput input)
/*     */     throws IOException, CanonicalizationException, InvalidCanonicalizerException, TransformationException
/*     */   {
/* 289 */     XMLSignatureInput result = null;
/*     */     try
/*     */     {
/* 292 */       result = this.transformSpi.enginePerformTransform(input, this);
/*     */     } catch (ParserConfigurationException ex) {
/* 294 */       Object[] exArgs = { getURI(), "ParserConfigurationException" };
/*     */       
/* 296 */       throw new CanonicalizationException(
/* 297 */         "signature.Transform.ErrorDuringTransform", exArgs, ex);
/*     */     } catch (SAXException ex) {
/* 299 */       Object[] exArgs = { getURI(), "SAXException" };
/*     */       
/* 301 */       throw new CanonicalizationException(
/* 302 */         "signature.Transform.ErrorDuringTransform", exArgs, ex);
/*     */     }
/*     */     
/* 305 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput performTransform(XMLSignatureInput input, OutputStream os)
/*     */     throws IOException, CanonicalizationException, InvalidCanonicalizerException, TransformationException
/*     */   {
/* 323 */     XMLSignatureInput result = null;
/*     */     try
/*     */     {
/* 326 */       result = this.transformSpi.enginePerformTransform(input, os, this);
/*     */     } catch (ParserConfigurationException ex) {
/* 328 */       Object[] exArgs = { getURI(), "ParserConfigurationException" };
/*     */       
/* 330 */       throw new CanonicalizationException(
/* 331 */         "signature.Transform.ErrorDuringTransform", exArgs, ex);
/*     */     } catch (SAXException ex) {
/* 333 */       Object[] exArgs = { getURI(), "SAXException" };
/*     */       
/* 335 */       throw new CanonicalizationException(
/* 336 */         "signature.Transform.ErrorDuringTransform", exArgs, ex);
/*     */     }
/*     */     
/* 339 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static TransformSpi getImplementingClass(String URI)
/*     */     throws InvalidTransformException
/*     */   {
/*     */     try
/*     */     {
/* 351 */       Object value = classesHash.get(URI);
/* 352 */       if (value != null) {
/* 353 */         return (TransformSpi)value;
/*     */       }
/* 355 */       Class cl = (Class)_transformHash.get(URI);
/* 356 */       if (cl != null) {
/* 357 */         TransformSpi tr = (TransformSpi)cl.newInstance();
/* 358 */         classesHash.put(URI, tr);
/* 359 */         return tr;
/*     */       }
/*     */     } catch (InstantiationException ex) {
/* 362 */       Object[] exArgs = { URI };
/* 363 */       throw new InvalidTransformException(
/* 364 */         "signature.Transform.UnknownTransform", exArgs, ex);
/*     */     } catch (IllegalAccessException ex) {
/* 366 */       Object[] exArgs = { URI };
/* 367 */       throw new InvalidTransformException(
/* 368 */         "signature.Transform.UnknownTransform", exArgs, ex);
/*     */     }
/* 370 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getBaseLocalName()
/*     */   {
/* 376 */     return "Transform";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\transforms\Transform.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */