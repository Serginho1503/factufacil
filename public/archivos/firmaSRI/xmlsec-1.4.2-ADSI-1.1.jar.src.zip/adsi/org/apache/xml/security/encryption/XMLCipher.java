/*      */ package adsi.org.apache.xml.security.encryption;
/*      */ 
/*      */ import adsi.org.apache.xml.security.algorithms.JCEMapper;
/*      */ import adsi.org.apache.xml.security.c14n.Canonicalizer;
/*      */ import adsi.org.apache.xml.security.c14n.InvalidCanonicalizerException;
/*      */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*      */ import adsi.org.apache.xml.security.keys.KeyInfo;
/*      */ import adsi.org.apache.xml.security.keys.keyresolver.KeyResolverException;
/*      */ import adsi.org.apache.xml.security.keys.keyresolver.implementations.EncryptedKeyResolver;
/*      */ import adsi.org.apache.xml.security.signature.XMLSignatureException;
/*      */ import adsi.org.apache.xml.security.transforms.InvalidTransformException;
/*      */ import adsi.org.apache.xml.security.transforms.TransformationException;
/*      */ import adsi.org.apache.xml.security.utils.Base64;
/*      */ import adsi.org.apache.xml.security.utils.ElementProxy;
/*      */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.StringReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.security.InvalidAlgorithmParameterException;
/*      */ import java.security.InvalidKeyException;
/*      */ import java.security.Key;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.security.NoSuchProviderException;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import javax.crypto.BadPaddingException;
/*      */ import javax.crypto.Cipher;
/*      */ import javax.crypto.IllegalBlockSizeException;
/*      */ import javax.crypto.NoSuchPaddingException;
/*      */ import javax.crypto.spec.IvParameterSpec;
/*      */ import javax.xml.parsers.DocumentBuilder;
/*      */ import javax.xml.parsers.DocumentBuilderFactory;
/*      */ import javax.xml.parsers.ParserConfigurationException;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.apache.xml.utils.URI;
/*      */ import org.apache.xml.utils.URI.MalformedURIException;
/*      */ import org.w3c.dom.Attr;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.DocumentFragment;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.NamedNodeMap;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ import org.xml.sax.InputSource;
/*      */ import org.xml.sax.SAXException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class XMLCipher
/*      */ {
/*   85 */   private static Log logger = LogFactory.getLog(XMLCipher.class.getName());
/*      */   
/*      */ 
/*      */ 
/*      */   public static final String TRIPLEDES = "http://www.w3.org/2001/04/xmlenc#tripledes-cbc";
/*      */   
/*      */ 
/*      */   public static final String AES_128 = "http://www.w3.org/2001/04/xmlenc#aes128-cbc";
/*      */   
/*      */ 
/*      */   public static final String AES_256 = "http://www.w3.org/2001/04/xmlenc#aes256-cbc";
/*      */   
/*      */ 
/*      */   public static final String AES_192 = "http://www.w3.org/2001/04/xmlenc#aes192-cbc";
/*      */   
/*      */ 
/*      */   public static final String RSA_v1dot5 = "http://www.w3.org/2001/04/xmlenc#rsa-1_5";
/*      */   
/*      */ 
/*      */   public static final String RSA_OAEP = "http://www.w3.org/2001/04/xmlenc#rsa-oaep-mgf1p";
/*      */   
/*      */ 
/*      */   public static final String DIFFIE_HELLMAN = "http://www.w3.org/2001/04/xmlenc#dh";
/*      */   
/*      */ 
/*      */   public static final String TRIPLEDES_KeyWrap = "http://www.w3.org/2001/04/xmlenc#kw-tripledes";
/*      */   
/*      */ 
/*      */   public static final String AES_128_KeyWrap = "http://www.w3.org/2001/04/xmlenc#kw-aes128";
/*      */   
/*      */ 
/*      */   public static final String AES_256_KeyWrap = "http://www.w3.org/2001/04/xmlenc#kw-aes256";
/*      */   
/*      */ 
/*      */   public static final String AES_192_KeyWrap = "http://www.w3.org/2001/04/xmlenc#kw-aes192";
/*      */   
/*      */ 
/*      */   public static final String SHA1 = "http://www.w3.org/2000/09/xmldsig#sha1";
/*      */   
/*      */ 
/*      */   public static final String SHA256 = "http://www.w3.org/2001/04/xmlenc#sha256";
/*      */   
/*      */ 
/*      */   public static final String SHA512 = "http://www.w3.org/2001/04/xmlenc#sha512";
/*      */   
/*      */ 
/*      */   public static final String RIPEMD_160 = "http://www.w3.org/2001/04/xmlenc#ripemd160";
/*      */   
/*      */ 
/*      */   public static final String XML_DSIG = "http://www.w3.org/2000/09/xmldsig#";
/*      */   
/*      */ 
/*      */   public static final String N14C_XML = "http://www.w3.org/TR/2001/REC-xml-c14n-20010315";
/*      */   
/*      */ 
/*      */   public static final String N14C_XML_WITH_COMMENTS = "http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments";
/*      */   
/*      */ 
/*      */   public static final String EXCL_XML_N14C = "http://www.w3.org/2001/10/xml-exc-c14n#";
/*      */   
/*      */ 
/*      */   public static final String EXCL_XML_N14C_WITH_COMMENTS = "http://www.w3.org/2001/10/xml-exc-c14n#WithComments";
/*      */   
/*      */ 
/*      */   public static final String BASE64_ENCODING = "http://www.w3.org/2000/09/xmldsig#base64";
/*      */   
/*      */ 
/*      */   public static final int ENCRYPT_MODE = 1;
/*      */   
/*      */ 
/*      */   public static final int DECRYPT_MODE = 2;
/*      */   
/*      */ 
/*      */   public static final int UNWRAP_MODE = 4;
/*      */   
/*      */ 
/*      */   public static final int WRAP_MODE = 3;
/*      */   
/*      */ 
/*      */   private static final String ENC_ALGORITHMS = "http://www.w3.org/2001/04/xmlenc#tripledes-cbc\nhttp://www.w3.org/2001/04/xmlenc#aes128-cbc\nhttp://www.w3.org/2001/04/xmlenc#aes256-cbc\nhttp://www.w3.org/2001/04/xmlenc#aes192-cbc\nhttp://www.w3.org/2001/04/xmlenc#rsa-1_5\nhttp://www.w3.org/2001/04/xmlenc#rsa-oaep-mgf1p\nhttp://www.w3.org/2001/04/xmlenc#kw-tripledes\nhttp://www.w3.org/2001/04/xmlenc#kw-aes128\nhttp://www.w3.org/2001/04/xmlenc#kw-aes256\nhttp://www.w3.org/2001/04/xmlenc#kw-aes192\n";
/*      */   
/*      */ 
/*      */   private Cipher _contextCipher;
/*      */   
/*      */ 
/*  170 */   private int _cipherMode = Integer.MIN_VALUE;
/*      */   
/*  172 */   private String _algorithm = null;
/*      */   
/*  174 */   private String _requestedJCEProvider = null;
/*      */   
/*      */ 
/*      */ 
/*      */   private Canonicalizer _canon;
/*      */   
/*      */ 
/*      */ 
/*      */   private Document _contextDocument;
/*      */   
/*      */ 
/*      */   private Factory _factory;
/*      */   
/*      */ 
/*      */   private Serializer _serializer;
/*      */   
/*      */ 
/*      */   private Key _key;
/*      */   
/*      */ 
/*      */   private Key _kek;
/*      */   
/*      */ 
/*      */   private EncryptedKey _ek;
/*      */   
/*      */ 
/*      */   private EncryptedData _ed;
/*      */   
/*      */ 
/*      */ 
/*      */   private XMLCipher()
/*      */   {
/*  206 */     logger.debug("Constructing XMLCipher...");
/*      */     
/*  208 */     this._factory = new Factory(null);
/*  209 */     this._serializer = new Serializer();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static boolean isValidEncryptionAlgorithm(String algorithm)
/*      */   {
/*  221 */     boolean result = 
/*  222 */       (algorithm.equals("http://www.w3.org/2001/04/xmlenc#tripledes-cbc")) || 
/*  223 */       (algorithm.equals("http://www.w3.org/2001/04/xmlenc#aes128-cbc")) || 
/*  224 */       (algorithm.equals("http://www.w3.org/2001/04/xmlenc#aes256-cbc")) || 
/*  225 */       (algorithm.equals("http://www.w3.org/2001/04/xmlenc#aes192-cbc")) || 
/*  226 */       (algorithm.equals("http://www.w3.org/2001/04/xmlenc#rsa-1_5")) || 
/*  227 */       (algorithm.equals("http://www.w3.org/2001/04/xmlenc#rsa-oaep-mgf1p")) || 
/*  228 */       (algorithm.equals("http://www.w3.org/2001/04/xmlenc#kw-tripledes")) || 
/*  229 */       (algorithm.equals("http://www.w3.org/2001/04/xmlenc#kw-aes128")) || 
/*  230 */       (algorithm.equals("http://www.w3.org/2001/04/xmlenc#kw-aes256")) || 
/*  231 */       (algorithm.equals("http://www.w3.org/2001/04/xmlenc#kw-aes192"));
/*      */     
/*      */ 
/*  234 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static XMLCipher getInstance(String transformation)
/*      */     throws XMLEncryptionException
/*      */   {
/*  268 */     logger.debug("Getting XMLCipher...");
/*  269 */     if (transformation == null)
/*  270 */       logger.error("Transformation unexpectedly null...");
/*  271 */     if (!isValidEncryptionAlgorithm(transformation)) {
/*  272 */       logger.warn("Algorithm non-standard, expected one of http://www.w3.org/2001/04/xmlenc#tripledes-cbc\nhttp://www.w3.org/2001/04/xmlenc#aes128-cbc\nhttp://www.w3.org/2001/04/xmlenc#aes256-cbc\nhttp://www.w3.org/2001/04/xmlenc#aes192-cbc\nhttp://www.w3.org/2001/04/xmlenc#rsa-1_5\nhttp://www.w3.org/2001/04/xmlenc#rsa-oaep-mgf1p\nhttp://www.w3.org/2001/04/xmlenc#kw-tripledes\nhttp://www.w3.org/2001/04/xmlenc#kw-aes128\nhttp://www.w3.org/2001/04/xmlenc#kw-aes256\nhttp://www.w3.org/2001/04/xmlenc#kw-aes192\n");
/*      */     }
/*  274 */     XMLCipher instance = new XMLCipher();
/*      */     
/*  276 */     instance._algorithm = transformation;
/*  277 */     instance._key = null;
/*  278 */     instance._kek = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  285 */       instance._canon = Canonicalizer.getInstance(
/*  286 */         "http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments");
/*      */     }
/*      */     catch (InvalidCanonicalizerException ice) {
/*  289 */       throw new XMLEncryptionException("empty", ice);
/*      */     }
/*      */     
/*  292 */     String jceAlgorithm = JCEMapper.translateURItoJCEID(transformation);
/*      */     try
/*      */     {
/*  295 */       instance._contextCipher = Cipher.getInstance(jceAlgorithm);
/*  296 */       logger.debug("cihper.algoritm = " + 
/*  297 */         instance._contextCipher.getAlgorithm());
/*      */     } catch (NoSuchAlgorithmException nsae) {
/*  299 */       throw new XMLEncryptionException("empty", nsae);
/*      */     } catch (NoSuchPaddingException nspe) {
/*  301 */       throw new XMLEncryptionException("empty", nspe);
/*      */     }
/*      */     
/*  304 */     return instance;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static XMLCipher getInstance(String transformation, String canon)
/*      */     throws XMLEncryptionException
/*      */   {
/*  326 */     XMLCipher instance = getInstance(transformation);
/*      */     
/*  328 */     if (canon != null) {
/*      */       try {
/*  330 */         instance._canon = Canonicalizer.getInstance(canon);
/*      */       } catch (InvalidCanonicalizerException ice) {
/*  332 */         throw new XMLEncryptionException("empty", ice);
/*      */       }
/*      */     }
/*      */     
/*  336 */     return instance;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static XMLCipher getProviderInstance(String transformation, String provider)
/*      */     throws XMLEncryptionException
/*      */   {
/*  355 */     logger.debug("Getting XMLCipher...");
/*  356 */     if (transformation == null)
/*  357 */       logger.error("Transformation unexpectedly null...");
/*  358 */     if (provider == null)
/*  359 */       logger.error("Provider unexpectedly null..");
/*  360 */     if ("" == provider)
/*  361 */       logger.error("Provider's value unexpectedly not specified...");
/*  362 */     if (!isValidEncryptionAlgorithm(transformation)) {
/*  363 */       logger.warn("Algorithm non-standard, expected one of http://www.w3.org/2001/04/xmlenc#tripledes-cbc\nhttp://www.w3.org/2001/04/xmlenc#aes128-cbc\nhttp://www.w3.org/2001/04/xmlenc#aes256-cbc\nhttp://www.w3.org/2001/04/xmlenc#aes192-cbc\nhttp://www.w3.org/2001/04/xmlenc#rsa-1_5\nhttp://www.w3.org/2001/04/xmlenc#rsa-oaep-mgf1p\nhttp://www.w3.org/2001/04/xmlenc#kw-tripledes\nhttp://www.w3.org/2001/04/xmlenc#kw-aes128\nhttp://www.w3.org/2001/04/xmlenc#kw-aes256\nhttp://www.w3.org/2001/04/xmlenc#kw-aes192\n");
/*      */     }
/*  365 */     XMLCipher instance = new XMLCipher();
/*      */     
/*  367 */     instance._algorithm = transformation;
/*  368 */     instance._requestedJCEProvider = provider;
/*  369 */     instance._key = null;
/*  370 */     instance._kek = null;
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  376 */       instance._canon = Canonicalizer.getInstance(
/*  377 */         "http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments");
/*      */     } catch (InvalidCanonicalizerException ice) {
/*  379 */       throw new XMLEncryptionException("empty", ice);
/*      */     }
/*      */     try
/*      */     {
/*  383 */       String jceAlgorithm = 
/*  384 */         JCEMapper.translateURItoJCEID(transformation);
/*      */       
/*  386 */       instance._contextCipher = Cipher.getInstance(jceAlgorithm, provider);
/*      */       
/*  388 */       logger.debug("cipher._algorithm = " + 
/*  389 */         instance._contextCipher.getAlgorithm());
/*  390 */       logger.debug("provider.name = " + provider);
/*      */     } catch (NoSuchAlgorithmException nsae) {
/*  392 */       throw new XMLEncryptionException("empty", nsae);
/*      */     } catch (NoSuchProviderException nspre) {
/*  394 */       throw new XMLEncryptionException("empty", nspre);
/*      */     } catch (NoSuchPaddingException nspe) {
/*  396 */       throw new XMLEncryptionException("empty", nspe);
/*      */     }
/*      */     
/*  399 */     return instance;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static XMLCipher getProviderInstance(String transformation, String provider, String canon)
/*      */     throws XMLEncryptionException
/*      */   {
/*  425 */     XMLCipher instance = getProviderInstance(transformation, provider);
/*  426 */     if (canon != null) {
/*      */       try {
/*  428 */         instance._canon = Canonicalizer.getInstance(canon);
/*      */       } catch (InvalidCanonicalizerException ice) {
/*  430 */         throw new XMLEncryptionException("empty", ice);
/*      */       }
/*      */     }
/*  433 */     return instance;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static XMLCipher getInstance()
/*      */     throws XMLEncryptionException
/*      */   {
/*  449 */     logger.debug("Getting XMLCipher for no transformation...");
/*      */     
/*  451 */     XMLCipher instance = new XMLCipher();
/*      */     
/*  453 */     instance._algorithm = null;
/*  454 */     instance._requestedJCEProvider = null;
/*  455 */     instance._key = null;
/*  456 */     instance._kek = null;
/*  457 */     instance._contextCipher = null;
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  463 */       instance._canon = Canonicalizer.getInstance(
/*  464 */         "http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments");
/*      */     } catch (InvalidCanonicalizerException ice) {
/*  466 */       throw new XMLEncryptionException("empty", ice);
/*      */     }
/*      */     
/*  469 */     return instance;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static XMLCipher getProviderInstance(String provider)
/*      */     throws XMLEncryptionException
/*      */   {
/*  491 */     logger.debug("Getting XMLCipher, provider but no transformation");
/*  492 */     if (provider == null)
/*  493 */       logger.error("Provider unexpectedly null..");
/*  494 */     if ("" == provider) {
/*  495 */       logger.error("Provider's value unexpectedly not specified...");
/*      */     }
/*  497 */     XMLCipher instance = new XMLCipher();
/*      */     
/*  499 */     instance._algorithm = null;
/*  500 */     instance._requestedJCEProvider = provider;
/*  501 */     instance._key = null;
/*  502 */     instance._kek = null;
/*  503 */     instance._contextCipher = null;
/*      */     try
/*      */     {
/*  506 */       instance._canon = Canonicalizer.getInstance(
/*  507 */         "http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments");
/*      */     } catch (InvalidCanonicalizerException ice) {
/*  509 */       throw new XMLEncryptionException("empty", ice);
/*      */     }
/*      */     
/*  512 */     return instance;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void init(int opmode, Key key)
/*      */     throws XMLEncryptionException
/*      */   {
/*  537 */     logger.debug("Initializing XMLCipher...");
/*      */     
/*  539 */     this._ek = null;
/*  540 */     this._ed = null;
/*      */     
/*  542 */     switch (opmode)
/*      */     {
/*      */     case 1: 
/*  545 */       logger.debug("opmode = ENCRYPT_MODE");
/*  546 */       this._ed = createEncryptedData(1, "NO VALUE YET");
/*  547 */       break;
/*      */     case 2: 
/*  549 */       logger.debug("opmode = DECRYPT_MODE");
/*  550 */       break;
/*      */     case 3: 
/*  552 */       logger.debug("opmode = WRAP_MODE");
/*  553 */       this._ek = createEncryptedKey(1, "NO VALUE YET");
/*  554 */       break;
/*      */     case 4: 
/*  556 */       logger.debug("opmode = UNWRAP_MODE");
/*  557 */       break;
/*      */     default: 
/*  559 */       logger.error("Mode unexpectedly invalid");
/*  560 */       throw new XMLEncryptionException("Invalid mode in init");
/*      */     }
/*      */     
/*  563 */     this._cipherMode = opmode;
/*  564 */     this._key = key;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptedData getEncryptedData()
/*      */   {
/*  581 */     logger.debug("Returning EncryptedData");
/*  582 */     return this._ed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptedKey getEncryptedKey()
/*      */   {
/*  599 */     logger.debug("Returning EncryptedKey");
/*  600 */     return this._ek;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setKEK(Key kek)
/*      */   {
/*  616 */     this._kek = kek;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Element martial(EncryptedData encryptedData)
/*      */   {
/*  636 */     return this._factory.toElement(encryptedData);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Element martial(EncryptedKey encryptedKey)
/*      */   {
/*  656 */     return this._factory.toElement(encryptedKey);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Element martial(Document context, EncryptedData encryptedData)
/*      */   {
/*  673 */     this._contextDocument = context;
/*  674 */     return this._factory.toElement(encryptedData);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Element martial(Document context, EncryptedKey encryptedKey)
/*      */   {
/*  691 */     this._contextDocument = context;
/*  692 */     return this._factory.toElement(encryptedKey);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Document encryptElement(Element element)
/*      */     throws Exception
/*      */   {
/*  709 */     logger.debug("Encrypting element...");
/*  710 */     if (element == null)
/*  711 */       logger.error("Element unexpectedly null...");
/*  712 */     if (this._cipherMode != 1) {
/*  713 */       logger.debug("XMLCipher unexpectedly not in ENCRYPT_MODE...");
/*      */     }
/*  715 */     if (this._algorithm == null) {
/*  716 */       throw new XMLEncryptionException("XMLCipher instance without transformation specified");
/*      */     }
/*  718 */     encryptData(this._contextDocument, element, false);
/*      */     
/*  720 */     Element encryptedElement = this._factory.toElement(this._ed);
/*      */     
/*  722 */     Node sourceParent = element.getParentNode();
/*  723 */     sourceParent.replaceChild(encryptedElement, element);
/*      */     
/*  725 */     return this._contextDocument;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Document encryptElementContent(Element element)
/*      */     throws Exception
/*      */   {
/*  744 */     logger.debug("Encrypting element content...");
/*  745 */     if (element == null)
/*  746 */       logger.error("Element unexpectedly null...");
/*  747 */     if (this._cipherMode != 1) {
/*  748 */       logger.debug("XMLCipher unexpectedly not in ENCRYPT_MODE...");
/*      */     }
/*  750 */     if (this._algorithm == null) {
/*  751 */       throw new XMLEncryptionException("XMLCipher instance without transformation specified");
/*      */     }
/*  753 */     encryptData(this._contextDocument, element, true);
/*      */     
/*  755 */     Element encryptedElement = this._factory.toElement(this._ed);
/*      */     
/*  757 */     removeContent(element);
/*  758 */     element.appendChild(encryptedElement);
/*      */     
/*  760 */     return this._contextDocument;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Document doFinal(Document context, Document source)
/*      */     throws Exception
/*      */   {
/*  774 */     logger.debug("Processing source document...");
/*  775 */     if (context == null)
/*  776 */       logger.error("Context document unexpectedly null...");
/*  777 */     if (source == null) {
/*  778 */       logger.error("Source document unexpectedly null...");
/*      */     }
/*  780 */     this._contextDocument = context;
/*      */     
/*  782 */     Document result = null;
/*      */     
/*  784 */     switch (this._cipherMode) {
/*      */     case 2: 
/*  786 */       result = decryptElement(source.getDocumentElement());
/*  787 */       break;
/*      */     case 1: 
/*  789 */       result = encryptElement(source.getDocumentElement());
/*  790 */       break;
/*      */     case 4: 
/*      */       break;
/*      */     case 3: 
/*      */       break;
/*      */     default: 
/*  796 */       throw new XMLEncryptionException(
/*  797 */         "empty", new IllegalStateException());
/*      */     }
/*      */     
/*  800 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Document doFinal(Document context, Element element)
/*      */     throws Exception
/*      */   {
/*  814 */     logger.debug("Processing source element...");
/*  815 */     if (context == null)
/*  816 */       logger.error("Context document unexpectedly null...");
/*  817 */     if (element == null) {
/*  818 */       logger.error("Source element unexpectedly null...");
/*      */     }
/*  820 */     this._contextDocument = context;
/*      */     
/*  822 */     Document result = null;
/*      */     
/*  824 */     switch (this._cipherMode) {
/*      */     case 2: 
/*  826 */       result = decryptElement(element);
/*  827 */       break;
/*      */     case 1: 
/*  829 */       result = encryptElement(element);
/*  830 */       break;
/*      */     case 4: 
/*      */       break;
/*      */     case 3: 
/*      */       break;
/*      */     default: 
/*  836 */       throw new XMLEncryptionException(
/*  837 */         "empty", new IllegalStateException());
/*      */     }
/*      */     
/*  840 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Document doFinal(Document context, Element element, boolean content)
/*      */     throws Exception
/*      */   {
/*  857 */     logger.debug("Processing source element...");
/*  858 */     if (context == null)
/*  859 */       logger.error("Context document unexpectedly null...");
/*  860 */     if (element == null) {
/*  861 */       logger.error("Source element unexpectedly null...");
/*      */     }
/*  863 */     this._contextDocument = context;
/*      */     
/*  865 */     Document result = null;
/*      */     
/*  867 */     switch (this._cipherMode) {
/*      */     case 2: 
/*  869 */       if (content) {
/*  870 */         result = decryptElementContent(element);
/*      */       } else {
/*  872 */         result = decryptElement(element);
/*      */       }
/*  874 */       break;
/*      */     case 1: 
/*  876 */       if (content) {
/*  877 */         result = encryptElementContent(element);
/*      */       } else {
/*  879 */         result = encryptElement(element);
/*      */       }
/*  881 */       break;
/*      */     case 4: 
/*      */       break;
/*      */     case 3: 
/*      */       break;
/*      */     default: 
/*  887 */       throw new XMLEncryptionException(
/*  888 */         "empty", new IllegalStateException());
/*      */     }
/*      */     
/*  891 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptedData encryptData(Document context, Element element)
/*      */     throws Exception
/*      */   {
/*  908 */     return encryptData(context, element, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptedData encryptData(Document context, String type, InputStream serializedData)
/*      */     throws Exception
/*      */   {
/*  928 */     logger.debug("Encrypting element...");
/*  929 */     if (context == null)
/*  930 */       logger.error("Context document unexpectedly null...");
/*  931 */     if (serializedData == null)
/*  932 */       logger.error("Serialized data unexpectedly null...");
/*  933 */     if (this._cipherMode != 1) {
/*  934 */       logger.debug("XMLCipher unexpectedly not in ENCRYPT_MODE...");
/*      */     }
/*  936 */     return encryptData(context, null, type, serializedData);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptedData encryptData(Document context, Element element, boolean contentMode)
/*      */     throws Exception
/*      */   {
/*  957 */     logger.debug("Encrypting element...");
/*  958 */     if (context == null)
/*  959 */       logger.error("Context document unexpectedly null...");
/*  960 */     if (element == null)
/*  961 */       logger.error("Element unexpectedly null...");
/*  962 */     if (this._cipherMode != 1) {
/*  963 */       logger.debug("XMLCipher unexpectedly not in ENCRYPT_MODE...");
/*      */     }
/*  965 */     if (contentMode) {
/*  966 */       return encryptData(
/*  967 */         context, element, "http://www.w3.org/2001/04/xmlenc#Content", null);
/*      */     }
/*  969 */     return encryptData(
/*  970 */       context, element, "http://www.w3.org/2001/04/xmlenc#Element", null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private EncryptedData encryptData(Document context, Element element, String type, InputStream serializedData)
/*      */     throws Exception
/*      */   {
/*  978 */     this._contextDocument = context;
/*      */     
/*  980 */     if (this._algorithm == null) {
/*  981 */       throw new XMLEncryptionException(
/*  982 */         "XMLCipher instance without transformation specified");
/*      */     }
/*      */     
/*  985 */     String serializedOctets = null;
/*  986 */     if (serializedData == null) {
/*  987 */       if (type == "http://www.w3.org/2001/04/xmlenc#Content") {
/*  988 */         NodeList children = element.getChildNodes();
/*  989 */         if (children != null) {
/*  990 */           serializedOctets = this._serializer.serialize(children);
/*      */         } else {
/*  992 */           Object[] exArgs = { "Element has no content." };
/*  993 */           throw new XMLEncryptionException("empty", exArgs);
/*      */         }
/*      */       } else {
/*  996 */         serializedOctets = this._serializer.serialize(element);
/*      */       }
/*  998 */       logger.debug("Serialized octets:\n" + serializedOctets);
/*      */     }
/*      */     
/* 1001 */     byte[] encryptedBytes = (byte[])null;
/*      */     
/*      */     Cipher c;
/*      */     
/* 1005 */     if (this._contextCipher == null) {
/* 1006 */       String jceAlgorithm = JCEMapper.translateURItoJCEID(this._algorithm);
/* 1007 */       logger.debug("alg = " + jceAlgorithm);
/*      */       try {
/*      */         Cipher c;
/* 1010 */         if (this._requestedJCEProvider == null) {
/* 1011 */           c = Cipher.getInstance(jceAlgorithm);
/*      */         } else
/* 1013 */           c = Cipher.getInstance(jceAlgorithm, this._requestedJCEProvider);
/*      */       } catch (NoSuchAlgorithmException nsae) { Cipher c;
/* 1015 */         throw new XMLEncryptionException("empty", nsae);
/*      */       } catch (NoSuchProviderException nspre) {
/* 1017 */         throw new XMLEncryptionException("empty", nspre);
/*      */       } catch (NoSuchPaddingException nspae) {
/* 1019 */         throw new XMLEncryptionException("empty", nspae);
/*      */       }
/*      */     } else {
/* 1022 */       c = this._contextCipher;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 1029 */       c.init(this._cipherMode, this._key);
/*      */     } catch (InvalidKeyException ike) {
/* 1031 */       throw new XMLEncryptionException("empty", ike);
/*      */     }
/*      */     try
/*      */     {
/* 1035 */       if (serializedData != null)
/*      */       {
/* 1037 */         byte[] buf = new byte[' '];
/* 1038 */         ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 1039 */         int numBytes; while ((numBytes = serializedData.read(buf)) != -1) { int numBytes;
/* 1040 */           byte[] data = c.update(buf, 0, numBytes);
/* 1041 */           baos.write(data);
/*      */         }
/* 1043 */         baos.write(c.doFinal());
/* 1044 */         encryptedBytes = baos.toByteArray();
/*      */       } else {
/* 1046 */         encryptedBytes = c.doFinal(serializedOctets.getBytes("UTF-8"));
/* 1047 */         logger.debug("Expected cipher.outputSize = " + 
/* 1048 */           Integer.toString(c.getOutputSize(
/* 1049 */           serializedOctets.getBytes().length)));
/*      */       }
/* 1051 */       logger.debug("Actual cipher.outputSize = " + 
/* 1052 */         Integer.toString(encryptedBytes.length));
/*      */     } catch (IllegalStateException ise) {
/* 1054 */       throw new XMLEncryptionException("empty", ise);
/*      */     } catch (IllegalBlockSizeException ibse) {
/* 1056 */       throw new XMLEncryptionException("empty", ibse);
/*      */     } catch (BadPaddingException bpe) {
/* 1058 */       throw new XMLEncryptionException("empty", bpe);
/*      */     } catch (UnsupportedEncodingException uee) {
/* 1060 */       throw new XMLEncryptionException("empty", uee);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1065 */     byte[] iv = c.getIV();
/* 1066 */     byte[] finalEncryptedBytes = 
/* 1067 */       new byte[iv.length + encryptedBytes.length];
/* 1068 */     System.arraycopy(iv, 0, finalEncryptedBytes, 0, iv.length);
/* 1069 */     System.arraycopy(encryptedBytes, 0, finalEncryptedBytes, iv.length, 
/* 1070 */       encryptedBytes.length);
/* 1071 */     String base64EncodedEncryptedOctets = Base64.encode(finalEncryptedBytes);
/*      */     
/* 1073 */     logger.debug("Encrypted octets:\n" + base64EncodedEncryptedOctets);
/* 1074 */     logger.debug("Encrypted octets length = " + 
/* 1075 */       base64EncodedEncryptedOctets.length());
/*      */     try
/*      */     {
/* 1078 */       CipherData cd = this._ed.getCipherData();
/* 1079 */       CipherValue cv = cd.getCipherValue();
/*      */       
/* 1081 */       cv.setValue(base64EncodedEncryptedOctets);
/*      */       
/* 1083 */       if (type != null) {
/* 1084 */         this._ed.setType(new URI(type).toString());
/*      */       }
/* 1086 */       EncryptionMethod method = 
/* 1087 */         this._factory.newEncryptionMethod(new URI(this._algorithm).toString());
/* 1088 */       this._ed.setEncryptionMethod(method);
/*      */     } catch (URI.MalformedURIException mfue) {
/* 1090 */       throw new XMLEncryptionException("empty", mfue);
/*      */     }
/* 1092 */     return this._ed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptedData loadEncryptedData(Document context, Element element)
/*      */     throws XMLEncryptionException
/*      */   {
/* 1107 */     logger.debug("Loading encrypted element...");
/* 1108 */     if (context == null)
/* 1109 */       logger.error("Context document unexpectedly null...");
/* 1110 */     if (element == null)
/* 1111 */       logger.error("Element unexpectedly null...");
/* 1112 */     if (this._cipherMode != 2) {
/* 1113 */       logger.error("XMLCipher unexpectedly not in DECRYPT_MODE...");
/*      */     }
/* 1115 */     this._contextDocument = context;
/* 1116 */     this._ed = this._factory.newEncryptedData(element);
/*      */     
/* 1118 */     return this._ed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptedKey loadEncryptedKey(Document context, Element element)
/*      */     throws XMLEncryptionException
/*      */   {
/* 1134 */     logger.debug("Loading encrypted key...");
/* 1135 */     if (context == null)
/* 1136 */       logger.error("Context document unexpectedly null...");
/* 1137 */     if (element == null)
/* 1138 */       logger.error("Element unexpectedly null...");
/* 1139 */     if ((this._cipherMode != 4) && (this._cipherMode != 2)) {
/* 1140 */       logger.debug("XMLCipher unexpectedly not in UNWRAP_MODE or DECRYPT_MODE...");
/*      */     }
/* 1142 */     this._contextDocument = context;
/* 1143 */     this._ek = this._factory.newEncryptedKey(element);
/* 1144 */     return this._ek;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptedKey loadEncryptedKey(Element element)
/*      */     throws XMLEncryptionException
/*      */   {
/* 1162 */     return loadEncryptedKey(element.getOwnerDocument(), element);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptedKey encryptKey(Document doc, Key key)
/*      */     throws XMLEncryptionException
/*      */   {
/* 1178 */     logger.debug("Encrypting key ...");
/*      */     
/* 1180 */     if (key == null)
/* 1181 */       logger.error("Key unexpectedly null...");
/* 1182 */     if (this._cipherMode != 3) {
/* 1183 */       logger.debug("XMLCipher unexpectedly not in WRAP_MODE...");
/*      */     }
/* 1185 */     if (this._algorithm == null)
/*      */     {
/* 1187 */       throw new XMLEncryptionException("XMLCipher instance without transformation specified");
/*      */     }
/*      */     
/* 1190 */     this._contextDocument = doc;
/*      */     
/* 1192 */     byte[] encryptedBytes = (byte[])null;
/*      */     
/*      */     Cipher c;
/* 1195 */     if (this._contextCipher == null)
/*      */     {
/*      */ 
/* 1198 */       String jceAlgorithm = 
/* 1199 */         JCEMapper.translateURItoJCEID(this._algorithm);
/*      */       
/* 1201 */       logger.debug("alg = " + jceAlgorithm);
/*      */       try {
/*      */         Cipher c;
/* 1204 */         if (this._requestedJCEProvider == null) {
/* 1205 */           c = Cipher.getInstance(jceAlgorithm);
/*      */         } else
/* 1207 */           c = Cipher.getInstance(jceAlgorithm, this._requestedJCEProvider);
/*      */       } catch (NoSuchAlgorithmException nsae) { Cipher c;
/* 1209 */         throw new XMLEncryptionException("empty", nsae);
/*      */       } catch (NoSuchProviderException nspre) {
/* 1211 */         throw new XMLEncryptionException("empty", nspre);
/*      */       } catch (NoSuchPaddingException nspae) {
/* 1213 */         throw new XMLEncryptionException("empty", nspae);
/*      */       }
/*      */     } else {
/* 1216 */       c = this._contextCipher;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 1223 */       c.init(3, this._key);
/* 1224 */       encryptedBytes = c.wrap(key);
/*      */     } catch (InvalidKeyException ike) {
/* 1226 */       throw new XMLEncryptionException("empty", ike);
/*      */     } catch (IllegalBlockSizeException ibse) {
/* 1228 */       throw new XMLEncryptionException("empty", ibse);
/*      */     }
/*      */     
/* 1231 */     String base64EncodedEncryptedOctets = Base64.encode(encryptedBytes);
/*      */     
/* 1233 */     logger.debug("Encrypted key octets:\n" + base64EncodedEncryptedOctets);
/* 1234 */     logger.debug("Encrypted key octets length = " + 
/* 1235 */       base64EncodedEncryptedOctets.length());
/*      */     
/* 1237 */     CipherValue cv = this._ek.getCipherData().getCipherValue();
/* 1238 */     cv.setValue(base64EncodedEncryptedOctets);
/*      */     try
/*      */     {
/* 1241 */       EncryptionMethod method = this._factory.newEncryptionMethod(
/* 1242 */         new URI(this._algorithm).toString());
/* 1243 */       this._ek.setEncryptionMethod(method);
/*      */     } catch (URI.MalformedURIException mfue) {
/* 1245 */       throw new XMLEncryptionException("empty", mfue);
/*      */     }
/* 1247 */     return this._ek;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Key decryptKey(EncryptedKey encryptedKey, String algorithm)
/*      */     throws XMLEncryptionException
/*      */   {
/* 1264 */     logger.debug("Decrypting key from previously loaded EncryptedKey...");
/*      */     
/* 1266 */     if (this._cipherMode != 4) {
/* 1267 */       logger.debug("XMLCipher unexpectedly not in UNWRAP_MODE...");
/*      */     }
/* 1269 */     if (algorithm == null) {
/* 1270 */       throw new XMLEncryptionException("Cannot decrypt a key without knowing the algorithm");
/*      */     }
/*      */     
/* 1273 */     if (this._key == null)
/*      */     {
/* 1275 */       logger.debug("Trying to find a KEK via key resolvers");
/*      */       
/* 1277 */       KeyInfo ki = encryptedKey.getKeyInfo();
/* 1278 */       if (ki != null) {
/*      */         try {
/* 1280 */           this._key = ki.getSecretKey();
/*      */         }
/*      */         catch (Exception localException) {}
/*      */       }
/*      */       
/* 1285 */       if (this._key == null) {
/* 1286 */         logger.error("XMLCipher::decryptKey called without a KEK and cannot resolve");
/* 1287 */         throw new XMLEncryptionException("Unable to decrypt without a KEK");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1292 */     XMLCipherInput cipherInput = new XMLCipherInput(encryptedKey);
/* 1293 */     byte[] encryptedBytes = cipherInput.getBytes();
/*      */     
/* 1295 */     String jceKeyAlgorithm = 
/* 1296 */       JCEMapper.getJCEKeyAlgorithmFromURI(algorithm);
/*      */     
/*      */     Cipher c;
/* 1299 */     if (this._contextCipher == null)
/*      */     {
/*      */ 
/* 1302 */       String jceAlgorithm = 
/* 1303 */         JCEMapper.translateURItoJCEID(
/* 1304 */         encryptedKey.getEncryptionMethod().getAlgorithm());
/*      */       
/* 1306 */       logger.debug("JCE Algorithm = " + jceAlgorithm);
/*      */       try {
/*      */         Cipher c;
/* 1309 */         if (this._requestedJCEProvider == null) {
/* 1310 */           c = Cipher.getInstance(jceAlgorithm);
/*      */         } else
/* 1312 */           c = Cipher.getInstance(jceAlgorithm, this._requestedJCEProvider);
/*      */       } catch (NoSuchAlgorithmException nsae) { Cipher c;
/* 1314 */         throw new XMLEncryptionException("empty", nsae);
/*      */       } catch (NoSuchProviderException nspre) {
/* 1316 */         throw new XMLEncryptionException("empty", nspre);
/*      */       } catch (NoSuchPaddingException nspae) {
/* 1318 */         throw new XMLEncryptionException("empty", nspae);
/*      */       }
/*      */     } else {
/* 1321 */       c = this._contextCipher;
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 1327 */       c.init(4, this._key);
/* 1328 */       ret = c.unwrap(encryptedBytes, jceKeyAlgorithm, 3);
/*      */     } catch (InvalidKeyException ike) {
/*      */       Key ret;
/* 1331 */       throw new XMLEncryptionException("empty", ike);
/*      */     } catch (NoSuchAlgorithmException nsae) {
/* 1333 */       throw new XMLEncryptionException("empty", nsae);
/*      */     }
/*      */     Key ret;
/* 1336 */     logger.debug("Decryption of key type " + algorithm + " OK");
/*      */     
/* 1338 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Key decryptKey(EncryptedKey encryptedKey)
/*      */     throws XMLEncryptionException
/*      */   {
/* 1357 */     return decryptKey(encryptedKey, this._ed.getEncryptionMethod().getAlgorithm());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void removeContent(Node node)
/*      */   {
/* 1367 */     while (node.hasChildNodes()) {
/* 1368 */       node.removeChild(node.getFirstChild());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Document decryptElement(Element element)
/*      */     throws XMLEncryptionException
/*      */   {
/* 1382 */     logger.debug("Decrypting element...");
/*      */     
/* 1384 */     if (this._cipherMode != 2) {
/* 1385 */       logger.error("XMLCipher unexpectedly not in DECRYPT_MODE...");
/*      */     }
/*      */     try
/*      */     {
/* 1389 */       octets = new String(decryptToByteArray(element), "UTF-8");
/*      */     } catch (UnsupportedEncodingException uee) { String octets;
/* 1391 */       throw new XMLEncryptionException("empty", uee);
/*      */     }
/*      */     
/*      */     String octets;
/* 1395 */     logger.debug("Decrypted octets:\n" + octets);
/*      */     
/* 1397 */     Node sourceParent = element.getParentNode();
/*      */     
/* 1399 */     DocumentFragment decryptedFragment = 
/* 1400 */       this._serializer.deserialize(octets, sourceParent);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1406 */     if ((sourceParent instanceof Document))
/*      */     {
/*      */ 
/*      */ 
/* 1410 */       this._contextDocument.removeChild(this._contextDocument.getDocumentElement());
/* 1411 */       this._contextDocument.appendChild(decryptedFragment);
/*      */     }
/*      */     else {
/* 1414 */       sourceParent.replaceChild(decryptedFragment, element);
/*      */     }
/*      */     
/*      */ 
/* 1418 */     return this._contextDocument;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Document decryptElementContent(Element element)
/*      */     throws XMLEncryptionException
/*      */   {
/* 1430 */     Element e = (Element)element.getElementsByTagNameNS(
/* 1431 */       "http://www.w3.org/2001/04/xmlenc#", 
/* 1432 */       "EncryptedData").item(0);
/*      */     
/* 1434 */     if (e == null) {
/* 1435 */       throw new XMLEncryptionException("No EncryptedData child element.");
/*      */     }
/*      */     
/* 1438 */     return decryptElement(e);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] decryptToByteArray(Element element)
/*      */     throws XMLEncryptionException
/*      */   {
/* 1456 */     logger.debug("Decrypting to ByteArray...");
/*      */     
/* 1458 */     if (this._cipherMode != 2) {
/* 1459 */       logger.error("XMLCipher unexpectedly not in DECRYPT_MODE...");
/*      */     }
/* 1461 */     EncryptedData encryptedData = this._factory.newEncryptedData(element);
/*      */     
/* 1463 */     if (this._key == null)
/*      */     {
/* 1465 */       KeyInfo ki = encryptedData.getKeyInfo();
/*      */       
/* 1467 */       if (ki != null) {
/*      */         try
/*      */         {
/* 1470 */           ki.registerInternalKeyResolver(
/* 1471 */             new EncryptedKeyResolver(encryptedData
/* 1472 */             .getEncryptionMethod()
/* 1473 */             .getAlgorithm(), 
/* 1474 */             this._kek));
/* 1475 */           this._key = ki.getSecretKey();
/*      */         }
/*      */         catch (KeyResolverException localKeyResolverException) {}
/*      */       }
/*      */       
/*      */ 
/* 1481 */       if (this._key == null) {
/* 1482 */         logger.error("XMLCipher::decryptElement called without a key and unable to resolve");
/*      */         
/* 1484 */         throw new XMLEncryptionException("encryption.nokey");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1489 */     XMLCipherInput cipherInput = new XMLCipherInput(encryptedData);
/* 1490 */     byte[] encryptedBytes = cipherInput.getBytes();
/*      */     
/*      */ 
/*      */ 
/* 1494 */     String jceAlgorithm = 
/* 1495 */       JCEMapper.translateURItoJCEID(encryptedData.getEncryptionMethod().getAlgorithm());
/*      */     try
/*      */     {
/*      */       Cipher c;
/* 1499 */       if (this._requestedJCEProvider == null) {
/* 1500 */         c = Cipher.getInstance(jceAlgorithm);
/*      */       } else
/* 1502 */         c = Cipher.getInstance(jceAlgorithm, this._requestedJCEProvider);
/*      */     } catch (NoSuchAlgorithmException nsae) { Cipher c;
/* 1504 */       throw new XMLEncryptionException("empty", nsae);
/*      */     } catch (NoSuchProviderException nspre) {
/* 1506 */       throw new XMLEncryptionException("empty", nspre);
/*      */     } catch (NoSuchPaddingException nspae) {
/* 1508 */       throw new XMLEncryptionException("empty", nspae);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     Cipher c;
/*      */     
/*      */ 
/* 1516 */     int ivLen = c.getBlockSize();
/* 1517 */     byte[] ivBytes = new byte[ivLen];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1524 */     System.arraycopy(encryptedBytes, 0, ivBytes, 0, ivLen);
/* 1525 */     IvParameterSpec iv = new IvParameterSpec(ivBytes);
/*      */     try
/*      */     {
/* 1528 */       c.init(this._cipherMode, this._key, iv);
/*      */     } catch (InvalidKeyException ike) {
/* 1530 */       throw new XMLEncryptionException("empty", ike);
/*      */     } catch (InvalidAlgorithmParameterException iape) {
/* 1532 */       throw new XMLEncryptionException("empty", iape);
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 1538 */       plainBytes = c.doFinal(encryptedBytes, 
/* 1539 */         ivLen, 
/* 1540 */         encryptedBytes.length - ivLen);
/*      */     } catch (IllegalBlockSizeException ibse) {
/*      */       byte[] plainBytes;
/* 1543 */       throw new XMLEncryptionException("empty", ibse);
/*      */     } catch (BadPaddingException bpe) {
/* 1545 */       throw new XMLEncryptionException("empty", bpe);
/*      */     }
/*      */     byte[] plainBytes;
/* 1548 */     return plainBytes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptedData createEncryptedData(int type, String value)
/*      */     throws XMLEncryptionException
/*      */   {
/* 1592 */     EncryptedData result = null;
/* 1593 */     CipherData data = null;
/*      */     
/* 1595 */     switch (type) {
/*      */     case 2: 
/* 1597 */       CipherReference cipherReference = this._factory.newCipherReference(
/* 1598 */         value);
/* 1599 */       data = this._factory.newCipherData(type);
/* 1600 */       data.setCipherReference(cipherReference);
/* 1601 */       result = this._factory.newEncryptedData(data);
/* 1602 */       break;
/*      */     case 1: 
/* 1604 */       CipherValue cipherValue = this._factory.newCipherValue(value);
/* 1605 */       data = this._factory.newCipherData(type);
/* 1606 */       data.setCipherValue(cipherValue);
/* 1607 */       result = this._factory.newEncryptedData(data);
/*      */     }
/*      */     
/* 1610 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptedKey createEncryptedKey(int type, String value)
/*      */     throws XMLEncryptionException
/*      */   {
/* 1650 */     EncryptedKey result = null;
/* 1651 */     CipherData data = null;
/*      */     
/* 1653 */     switch (type) {
/*      */     case 2: 
/* 1655 */       CipherReference cipherReference = this._factory.newCipherReference(
/* 1656 */         value);
/* 1657 */       data = this._factory.newCipherData(type);
/* 1658 */       data.setCipherReference(cipherReference);
/* 1659 */       result = this._factory.newEncryptedKey(data);
/* 1660 */       break;
/*      */     case 1: 
/* 1662 */       CipherValue cipherValue = this._factory.newCipherValue(value);
/* 1663 */       data = this._factory.newCipherData(type);
/* 1664 */       data.setCipherValue(cipherValue);
/* 1665 */       result = this._factory.newEncryptedKey(data);
/*      */     }
/*      */     
/* 1668 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AgreementMethod createAgreementMethod(String algorithm)
/*      */   {
/* 1679 */     return this._factory.newAgreementMethod(algorithm);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CipherData createCipherData(int type)
/*      */   {
/* 1691 */     return this._factory.newCipherData(type);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CipherReference createCipherReference(String uri)
/*      */   {
/* 1702 */     return this._factory.newCipherReference(uri);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CipherValue createCipherValue(String value)
/*      */   {
/* 1713 */     return this._factory.newCipherValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptionMethod createEncryptionMethod(String algorithm)
/*      */   {
/* 1723 */     return this._factory.newEncryptionMethod(algorithm);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptionProperties createEncryptionProperties()
/*      */   {
/* 1731 */     return this._factory.newEncryptionProperties();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptionProperty createEncryptionProperty()
/*      */   {
/* 1739 */     return this._factory.newEncryptionProperty();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ReferenceList createReferenceList(int type)
/*      */   {
/* 1748 */     return this._factory.newReferenceList(type);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Transforms createTransforms()
/*      */   {
/* 1761 */     return this._factory.newTransforms();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Transforms createTransforms(Document doc)
/*      */   {
/* 1775 */     return this._factory.newTransforms(doc);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private class Serializer
/*      */   {
/*      */     Serializer() {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     String serialize(Document document)
/*      */       throws Exception
/*      */     {
/* 1813 */       return canonSerialize(document);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     String serialize(Element element)
/*      */       throws Exception
/*      */     {
/* 1828 */       return canonSerialize(element);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     String serialize(NodeList content)
/*      */       throws Exception
/*      */     {
/* 1854 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 1855 */       XMLCipher.this._canon.setWriter(baos);
/* 1856 */       XMLCipher.this._canon.notReset();
/* 1857 */       for (int i = 0; i < content.getLength(); i++) {
/* 1858 */         XMLCipher.this._canon.canonicalizeSubtree(content.item(i));
/*      */       }
/* 1860 */       baos.close();
/* 1861 */       return baos.toString("UTF-8");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     String canonSerialize(Node node)
/*      */       throws Exception
/*      */     {
/* 1871 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 1872 */       XMLCipher.this._canon.setWriter(baos);
/* 1873 */       XMLCipher.this._canon.notReset();
/* 1874 */       XMLCipher.this._canon.canonicalizeSubtree(node);
/* 1875 */       baos.close();
/* 1876 */       return baos.toString("UTF-8");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     DocumentFragment deserialize(String source, Node ctx)
/*      */       throws XMLEncryptionException
/*      */     {
/* 1887 */       String tagname = "fragment";
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1892 */       StringBuffer sb = new StringBuffer();
/* 1893 */       sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><fragment");
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1898 */       Node wk = ctx;
/*      */       
/* 1900 */       while (wk != null)
/*      */       {
/* 1902 */         NamedNodeMap atts = wk.getAttributes();
/*      */         int length;
/* 1904 */         int length; if (atts != null) {
/* 1905 */           length = atts.getLength();
/*      */         } else {
/* 1907 */           length = 0;
/*      */         }
/* 1909 */         for (int i = 0; i < length; i++) {
/* 1910 */           Node att = atts.item(i);
/* 1911 */           if ((att.getNodeName().startsWith("xmlns:")) || 
/* 1912 */             (att.getNodeName().equals("xmlns")))
/*      */           {
/*      */ 
/* 1915 */             Node p = ctx;
/* 1916 */             boolean found = false;
/* 1917 */             while (p != wk) {
/* 1918 */               NamedNodeMap tstAtts = p.getAttributes();
/* 1919 */               if ((tstAtts != null) && 
/* 1920 */                 (tstAtts.getNamedItem(att.getNodeName()) != null)) {
/* 1921 */                 found = true;
/* 1922 */                 break;
/*      */               }
/* 1924 */               p = p.getParentNode();
/*      */             }
/* 1926 */             if (!found)
/*      */             {
/*      */ 
/* 1929 */               sb.append(" " + att.getNodeName() + "=\"" + 
/* 1930 */                 att.getNodeValue() + "\"");
/*      */             }
/*      */           }
/*      */         }
/* 1934 */         wk = wk.getParentNode();
/*      */       }
/* 1936 */       sb.append(">" + source + "</" + "fragment" + ">");
/* 1937 */       String fragment = sb.toString();
/*      */       try
/*      */       {
/* 1940 */         DocumentBuilderFactory dbf = 
/* 1941 */           DocumentBuilderFactory.newInstance();
/* 1942 */         dbf.setNamespaceAware(true);
/* 1943 */         dbf.setAttribute("http://xml.org/sax/features/namespaces", Boolean.TRUE);
/* 1944 */         DocumentBuilder db = dbf.newDocumentBuilder();
/* 1945 */         Document d = db.parse(
/* 1946 */           new InputSource(new StringReader(fragment)));
/*      */         
/* 1948 */         Element fragElt = (Element)XMLCipher.this._contextDocument.importNode(
/* 1949 */           d.getDocumentElement(), true);
/* 1950 */         DocumentFragment result = XMLCipher.this._contextDocument.createDocumentFragment();
/* 1951 */         Node child = fragElt.getFirstChild();
/* 1952 */         while (child != null) {
/* 1953 */           fragElt.removeChild(child);
/* 1954 */           result.appendChild(child);
/* 1955 */           child = fragElt.getFirstChild();
/*      */         }
/*      */       }
/*      */       catch (SAXException se)
/*      */       {
/* 1960 */         throw new XMLEncryptionException("empty", se);
/*      */       } catch (ParserConfigurationException pce) {
/* 1962 */         throw new XMLEncryptionException("empty", pce);
/*      */       } catch (IOException ioe) {
/* 1964 */         throw new XMLEncryptionException("empty", ioe);
/*      */       }
/*      */       DocumentFragment result;
/* 1967 */       return result;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private class Factory
/*      */   {
/*      */     private Factory() {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     AgreementMethod newAgreementMethod(String algorithm)
/*      */     {
/* 1983 */       return new AgreementMethodImpl(algorithm);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     CipherData newCipherData(int type)
/*      */     {
/* 1992 */       return new CipherDataImpl(type);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     CipherReference newCipherReference(String uri)
/*      */     {
/* 2001 */       return new CipherReferenceImpl(uri);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     CipherValue newCipherValue(String value)
/*      */     {
/* 2010 */       return new CipherValueImpl(value);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     EncryptedData newEncryptedData(CipherData data)
/*      */     {
/* 2026 */       return new EncryptedDataImpl(data);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     EncryptedKey newEncryptedKey(CipherData data)
/*      */     {
/* 2035 */       return new EncryptedKeyImpl(data);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     EncryptionMethod newEncryptionMethod(String algorithm)
/*      */     {
/* 2044 */       return new EncryptionMethodImpl(algorithm);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     EncryptionProperties newEncryptionProperties()
/*      */     {
/* 2052 */       return new EncryptionPropertiesImpl();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     EncryptionProperty newEncryptionProperty()
/*      */     {
/* 2060 */       return new EncryptionPropertyImpl();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     ReferenceList newReferenceList(int type)
/*      */     {
/* 2069 */       return new ReferenceListImpl(type);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     Transforms newTransforms()
/*      */     {
/* 2077 */       return new TransformsImpl();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Transforms newTransforms(Document doc)
/*      */     {
/* 2086 */       return new TransformsImpl(doc);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     AgreementMethod newAgreementMethod(Element element)
/*      */       throws XMLEncryptionException
/*      */     {
/* 2108 */       if (element == null) {
/* 2109 */         throw new NullPointerException("element is null");
/*      */       }
/*      */       
/* 2112 */       String algorithm = element.getAttributeNS(null, 
/* 2113 */         "Algorithm");
/* 2114 */       AgreementMethod result = newAgreementMethod(algorithm);
/*      */       
/* 2116 */       Element kaNonceElement = (Element)element.getElementsByTagNameNS(
/* 2117 */         "http://www.w3.org/2001/04/xmlenc#", 
/* 2118 */         "KA-Nonce").item(0);
/* 2119 */       if (kaNonceElement != null) {
/* 2120 */         result.setKANonce(kaNonceElement.getNodeValue().getBytes());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2128 */       Element originatorKeyInfoElement = 
/* 2129 */         (Element)element.getElementsByTagNameNS(
/* 2130 */         "http://www.w3.org/2001/04/xmlenc#", 
/* 2131 */         "OriginatorKeyInfo").item(0);
/* 2132 */       if (originatorKeyInfoElement != null) {
/*      */         try {
/* 2134 */           result.setOriginatorKeyInfo(
/* 2135 */             new KeyInfo(originatorKeyInfoElement, null));
/*      */         } catch (XMLSecurityException xse) {
/* 2137 */           throw new XMLEncryptionException("empty", xse);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2143 */       Element recipientKeyInfoElement = 
/* 2144 */         (Element)element.getElementsByTagNameNS(
/* 2145 */         "http://www.w3.org/2001/04/xmlenc#", 
/* 2146 */         "RecipientKeyInfo").item(0);
/* 2147 */       if (recipientKeyInfoElement != null) {
/*      */         try {
/* 2149 */           result.setRecipientKeyInfo(
/* 2150 */             new KeyInfo(recipientKeyInfoElement, null));
/*      */         } catch (XMLSecurityException xse) {
/* 2152 */           throw new XMLEncryptionException("empty", xse);
/*      */         }
/*      */       }
/*      */       
/* 2156 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     CipherData newCipherData(Element element)
/*      */       throws XMLEncryptionException
/*      */     {
/* 2174 */       if (element == null) {
/* 2175 */         throw new NullPointerException("element is null");
/*      */       }
/*      */       
/* 2178 */       int type = 0;
/* 2179 */       Element e = null;
/*      */       
/*      */ 
/* 2182 */       if (element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "CipherValue").getLength() > 0) {
/* 2183 */         type = 1;
/* 2184 */         e = (Element)element.getElementsByTagNameNS(
/* 2185 */           "http://www.w3.org/2001/04/xmlenc#", 
/* 2186 */           "CipherValue").item(0);
/*      */ 
/*      */       }
/* 2189 */       else if (element.getElementsByTagNameNS("http://www.w3.org/2001/04/xmlenc#", "CipherReference").getLength() > 0) {
/* 2190 */         type = 2;
/* 2191 */         e = (Element)element.getElementsByTagNameNS(
/* 2192 */           "http://www.w3.org/2001/04/xmlenc#", 
/* 2193 */           "CipherReference").item(0);
/*      */       }
/*      */       
/* 2196 */       CipherData result = newCipherData(type);
/* 2197 */       if (type == 1) {
/* 2198 */         result.setCipherValue(newCipherValue(e));
/* 2199 */       } else if (type == 2) {
/* 2200 */         result.setCipherReference(newCipherReference(e));
/*      */       }
/*      */       
/* 2203 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     CipherReference newCipherReference(Element element)
/*      */       throws XMLEncryptionException
/*      */     {
/* 2222 */       Attr URIAttr = 
/* 2223 */         element.getAttributeNodeNS(null, "URI");
/* 2224 */       CipherReference result = new CipherReferenceImpl(URIAttr);
/*      */       
/*      */ 
/*      */ 
/* 2228 */       NodeList transformsElements = element.getElementsByTagNameNS(
/* 2229 */         "http://www.w3.org/2001/04/xmlenc#", 
/* 2230 */         "Transforms");
/* 2231 */       Element transformsElement = 
/* 2232 */         (Element)transformsElements.item(0);
/*      */       
/* 2234 */       if (transformsElement != null) {
/* 2235 */         XMLCipher.logger.debug("Creating a DSIG based Transforms element");
/*      */         try {
/* 2237 */           result.setTransforms(new TransformsImpl(transformsElement));
/*      */         }
/*      */         catch (XMLSignatureException xse) {
/* 2240 */           throw new XMLEncryptionException("empty", xse);
/*      */         } catch (InvalidTransformException ite) {
/* 2242 */           throw new XMLEncryptionException("empty", ite);
/*      */         } catch (XMLSecurityException xse) {
/* 2244 */           throw new XMLEncryptionException("empty", xse);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 2249 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     CipherValue newCipherValue(Element element)
/*      */     {
/* 2258 */       String value = XMLUtils.getFullTextChildrenFromElement(element);
/*      */       
/* 2260 */       CipherValue result = newCipherValue(value);
/*      */       
/* 2262 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     EncryptedData newEncryptedData(Element element)
/*      */       throws XMLEncryptionException
/*      */     {
/* 2292 */       EncryptedData result = null;
/*      */       
/* 2294 */       NodeList dataElements = element.getElementsByTagNameNS(
/* 2295 */         "http://www.w3.org/2001/04/xmlenc#", 
/* 2296 */         "CipherData");
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2301 */       Element dataElement = 
/* 2302 */         (Element)dataElements.item(dataElements.getLength() - 1);
/*      */       
/* 2304 */       CipherData data = newCipherData(dataElement);
/*      */       
/* 2306 */       result = newEncryptedData(data);
/*      */       
/* 2308 */       result.setId(element.getAttributeNS(
/* 2309 */         null, "Id"));
/* 2310 */       result.setType(
/* 2311 */         element.getAttributeNS(null, "Type"));
/* 2312 */       result.setMimeType(element.getAttributeNS(
/* 2313 */         null, "MimeType"));
/* 2314 */       result.setEncoding(
/* 2315 */         element.getAttributeNS(null, "Encoding"));
/*      */       
/* 2317 */       Element encryptionMethodElement = 
/* 2318 */         (Element)element.getElementsByTagNameNS(
/* 2319 */         "http://www.w3.org/2001/04/xmlenc#", 
/* 2320 */         "EncryptionMethod").item(0);
/* 2321 */       if (encryptionMethodElement != null) {
/* 2322 */         result.setEncryptionMethod(newEncryptionMethod(
/* 2323 */           encryptionMethodElement));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2329 */       Element keyInfoElement = 
/* 2330 */         (Element)element.getElementsByTagNameNS(
/* 2331 */         "http://www.w3.org/2000/09/xmldsig#", "KeyInfo").item(0);
/* 2332 */       if (keyInfoElement != null) {
/*      */         try {
/* 2334 */           result.setKeyInfo(new KeyInfo(keyInfoElement, null));
/*      */         } catch (XMLSecurityException xse) {
/* 2336 */           throw new XMLEncryptionException("Error loading Key Info", 
/* 2337 */             xse);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 2342 */       Element encryptionPropertiesElement = 
/* 2343 */         (Element)element.getElementsByTagNameNS(
/* 2344 */         "http://www.w3.org/2001/04/xmlenc#", 
/* 2345 */         "EncryptionProperties").item(0);
/* 2346 */       if (encryptionPropertiesElement != null) {
/* 2347 */         result.setEncryptionProperties(
/* 2348 */           newEncryptionProperties(encryptionPropertiesElement));
/*      */       }
/*      */       
/* 2351 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     EncryptedKey newEncryptedKey(Element element)
/*      */       throws XMLEncryptionException
/*      */     {
/* 2387 */       EncryptedKey result = null;
/* 2388 */       NodeList dataElements = element.getElementsByTagNameNS(
/* 2389 */         "http://www.w3.org/2001/04/xmlenc#", 
/* 2390 */         "CipherData");
/* 2391 */       Element dataElement = 
/* 2392 */         (Element)dataElements.item(dataElements.getLength() - 1);
/*      */       
/* 2394 */       CipherData data = newCipherData(dataElement);
/* 2395 */       result = newEncryptedKey(data);
/*      */       
/* 2397 */       result.setId(element.getAttributeNS(
/* 2398 */         null, "Id"));
/* 2399 */       result.setType(
/* 2400 */         element.getAttributeNS(null, "Type"));
/* 2401 */       result.setMimeType(element.getAttributeNS(
/* 2402 */         null, "MimeType"));
/* 2403 */       result.setEncoding(
/* 2404 */         element.getAttributeNS(null, "Encoding"));
/* 2405 */       result.setRecipient(element.getAttributeNS(
/* 2406 */         null, "Recipient"));
/*      */       
/* 2408 */       Element encryptionMethodElement = 
/* 2409 */         (Element)element.getElementsByTagNameNS(
/* 2410 */         "http://www.w3.org/2001/04/xmlenc#", 
/* 2411 */         "EncryptionMethod").item(0);
/* 2412 */       if (encryptionMethodElement != null) {
/* 2413 */         result.setEncryptionMethod(newEncryptionMethod(
/* 2414 */           encryptionMethodElement));
/*      */       }
/*      */       
/* 2417 */       Element keyInfoElement = 
/* 2418 */         (Element)element.getElementsByTagNameNS(
/* 2419 */         "http://www.w3.org/2000/09/xmldsig#", "KeyInfo").item(0);
/* 2420 */       if (keyInfoElement != null) {
/*      */         try {
/* 2422 */           result.setKeyInfo(new KeyInfo(keyInfoElement, null));
/*      */         } catch (XMLSecurityException xse) {
/* 2424 */           throw new XMLEncryptionException(
/* 2425 */             "Error loading Key Info", xse);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 2430 */       Element encryptionPropertiesElement = 
/* 2431 */         (Element)element.getElementsByTagNameNS(
/* 2432 */         "http://www.w3.org/2001/04/xmlenc#", 
/* 2433 */         "EncryptionProperties").item(0);
/* 2434 */       if (encryptionPropertiesElement != null) {
/* 2435 */         result.setEncryptionProperties(
/* 2436 */           newEncryptionProperties(encryptionPropertiesElement));
/*      */       }
/*      */       
/* 2439 */       Element referenceListElement = 
/* 2440 */         (Element)element.getElementsByTagNameNS(
/* 2441 */         "http://www.w3.org/2001/04/xmlenc#", 
/* 2442 */         "ReferenceList").item(0);
/* 2443 */       if (referenceListElement != null) {
/* 2444 */         result.setReferenceList(newReferenceList(referenceListElement));
/*      */       }
/*      */       
/* 2447 */       Element carriedNameElement = 
/* 2448 */         (Element)element.getElementsByTagNameNS(
/* 2449 */         "http://www.w3.org/2001/04/xmlenc#", 
/* 2450 */         "CarriedKeyName").item(0);
/* 2451 */       if (carriedNameElement != null) {
/* 2452 */         result.setCarriedName(
/* 2453 */           carriedNameElement.getFirstChild().getNodeValue());
/*      */       }
/*      */       
/* 2456 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     EncryptionMethod newEncryptionMethod(Element element)
/*      */     {
/* 2473 */       String algorithm = element.getAttributeNS(
/* 2474 */         null, "Algorithm");
/* 2475 */       EncryptionMethod result = newEncryptionMethod(algorithm);
/*      */       
/* 2477 */       Element keySizeElement = 
/* 2478 */         (Element)element.getElementsByTagNameNS(
/* 2479 */         "http://www.w3.org/2001/04/xmlenc#", 
/* 2480 */         "KeySize").item(0);
/* 2481 */       if (keySizeElement != null) {
/* 2482 */         result.setKeySize(
/* 2483 */           Integer.valueOf(
/* 2484 */           keySizeElement.getFirstChild().getNodeValue()).intValue());
/*      */       }
/*      */       
/* 2487 */       Element oaepParamsElement = 
/* 2488 */         (Element)element.getElementsByTagNameNS(
/* 2489 */         "http://www.w3.org/2001/04/xmlenc#", 
/* 2490 */         "OAEPparams").item(0);
/* 2491 */       if (oaepParamsElement != null) {
/* 2492 */         result.setOAEPparams(
/* 2493 */           oaepParamsElement.getNodeValue().getBytes());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2499 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     EncryptionProperties newEncryptionProperties(Element element)
/*      */     {
/* 2515 */       EncryptionProperties result = newEncryptionProperties();
/*      */       
/* 2517 */       result.setId(element.getAttributeNS(
/* 2518 */         null, "Id"));
/*      */       
/* 2520 */       NodeList encryptionPropertyList = 
/* 2521 */         element.getElementsByTagNameNS(
/* 2522 */         "http://www.w3.org/2001/04/xmlenc#", 
/* 2523 */         "EncryptionProperty");
/* 2524 */       for (int i = 0; i < encryptionPropertyList.getLength(); i++) {
/* 2525 */         Node n = encryptionPropertyList.item(i);
/* 2526 */         if (n != null) {
/* 2527 */           result.addEncryptionProperty(
/* 2528 */             newEncryptionProperty((Element)n));
/*      */         }
/*      */       }
/*      */       
/* 2532 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     EncryptionProperty newEncryptionProperty(Element element)
/*      */     {
/* 2550 */       EncryptionProperty result = newEncryptionProperty();
/*      */       
/* 2552 */       result.setTarget(
/* 2553 */         element.getAttributeNS(null, "Target"));
/* 2554 */       result.setId(element.getAttributeNS(
/* 2555 */         null, "Id"));
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2562 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     ReferenceList newReferenceList(Element element)
/*      */     {
/* 2579 */       int type = 0;
/* 2580 */       if (element.getElementsByTagNameNS(
/* 2581 */         "http://www.w3.org/2001/04/xmlenc#", 
/* 2582 */         "DataReference").item(0) != null) {
/* 2583 */         type = 1;
/* 2584 */       } else if (element.getElementsByTagNameNS(
/* 2585 */         "http://www.w3.org/2001/04/xmlenc#", 
/* 2586 */         "KeyReference").item(0) != null) {
/* 2587 */         type = 2;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2592 */       ReferenceList result = new ReferenceListImpl(type);
/* 2593 */       NodeList list = null;
/* 2594 */       switch (type) {
/*      */       case 1: 
/* 2596 */         list = element.getElementsByTagNameNS(
/* 2597 */           "http://www.w3.org/2001/04/xmlenc#", 
/* 2598 */           "DataReference");
/* 2599 */         for (int i = 0; i < list.getLength(); i++) {
/* 2600 */           String uri = ((Element)list.item(i)).getAttribute("URI");
/* 2601 */           result.add(result.newDataReference(uri));
/*      */         }
/* 2603 */         break;
/*      */       case 2: 
/* 2605 */         list = element.getElementsByTagNameNS(
/* 2606 */           "http://www.w3.org/2001/04/xmlenc#", 
/* 2607 */           "KeyReference");
/* 2608 */         for (int i = 0; i < list.getLength(); i++) {
/* 2609 */           String uri = ((Element)list.item(i)).getAttribute("URI");
/* 2610 */           result.add(result.newKeyReference(uri));
/*      */         }
/*      */       }
/*      */       
/* 2614 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Transforms newTransforms(Element element)
/*      */     {
/* 2623 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Element toElement(AgreementMethod agreementMethod)
/*      */     {
/* 2632 */       return ((AgreementMethodImpl)agreementMethod).toElement();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Element toElement(CipherData cipherData)
/*      */     {
/* 2641 */       return ((CipherDataImpl)cipherData).toElement();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Element toElement(CipherReference cipherReference)
/*      */     {
/* 2650 */       return ((CipherReferenceImpl)cipherReference).toElement();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Element toElement(CipherValue cipherValue)
/*      */     {
/* 2659 */       return ((CipherValueImpl)cipherValue).toElement();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Element toElement(EncryptedData encryptedData)
/*      */     {
/* 2668 */       return ((EncryptedDataImpl)encryptedData).toElement();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Element toElement(EncryptedKey encryptedKey)
/*      */     {
/* 2677 */       return ((EncryptedKeyImpl)encryptedKey).toElement();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Element toElement(EncryptionMethod encryptionMethod)
/*      */     {
/* 2686 */       return ((EncryptionMethodImpl)encryptionMethod).toElement();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Element toElement(EncryptionProperties encryptionProperties)
/*      */     {
/* 2695 */       return ((EncryptionPropertiesImpl)encryptionProperties).toElement();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Element toElement(EncryptionProperty encryptionProperty)
/*      */     {
/* 2704 */       return ((EncryptionPropertyImpl)encryptionProperty).toElement();
/*      */     }
/*      */     
/*      */     Element toElement(ReferenceList referenceList) {
/* 2708 */       return ((ReferenceListImpl)referenceList).toElement();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Element toElement(Transforms transforms)
/*      */     {
/* 2717 */       return ((TransformsImpl)transforms).toElement();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private class AgreementMethodImpl
/*      */       implements AgreementMethod
/*      */     {
/* 2732 */       private byte[] kaNonce = null;
/* 2733 */       private List agreementMethodInformation = null;
/* 2734 */       private KeyInfo originatorKeyInfo = null;
/* 2735 */       private KeyInfo recipientKeyInfo = null;
/* 2736 */       private String algorithmURI = null;
/*      */       
/*      */ 
/*      */ 
/*      */       public AgreementMethodImpl(String algorithm)
/*      */       {
/* 2742 */         this.agreementMethodInformation = new LinkedList();
/* 2743 */         URI tmpAlgorithm = null;
/*      */         try {
/* 2745 */           tmpAlgorithm = new URI(algorithm);
/*      */         }
/*      */         catch (URI.MalformedURIException localMalformedURIException) {}
/*      */         
/* 2749 */         this.algorithmURI = tmpAlgorithm.toString();
/*      */       }
/*      */       
/*      */       public byte[] getKANonce()
/*      */       {
/* 2754 */         return this.kaNonce;
/*      */       }
/*      */       
/*      */       public void setKANonce(byte[] kanonce)
/*      */       {
/* 2759 */         this.kaNonce = kanonce;
/*      */       }
/*      */       
/*      */       public Iterator getAgreementMethodInformation()
/*      */       {
/* 2764 */         return this.agreementMethodInformation.iterator();
/*      */       }
/*      */       
/*      */       public void addAgreementMethodInformation(Element info)
/*      */       {
/* 2769 */         this.agreementMethodInformation.add(info);
/*      */       }
/*      */       
/*      */       public void revoveAgreementMethodInformation(Element info)
/*      */       {
/* 2774 */         this.agreementMethodInformation.remove(info);
/*      */       }
/*      */       
/*      */       public KeyInfo getOriginatorKeyInfo()
/*      */       {
/* 2779 */         return this.originatorKeyInfo;
/*      */       }
/*      */       
/*      */       public void setOriginatorKeyInfo(KeyInfo keyInfo)
/*      */       {
/* 2784 */         this.originatorKeyInfo = keyInfo;
/*      */       }
/*      */       
/*      */       public KeyInfo getRecipientKeyInfo()
/*      */       {
/* 2789 */         return this.recipientKeyInfo;
/*      */       }
/*      */       
/*      */       public void setRecipientKeyInfo(KeyInfo keyInfo)
/*      */       {
/* 2794 */         this.recipientKeyInfo = keyInfo;
/*      */       }
/*      */       
/*      */       public String getAlgorithm()
/*      */       {
/* 2799 */         return this.algorithmURI;
/*      */       }
/*      */       
/*      */       public void setAlgorithm(String algorithm)
/*      */       {
/* 2804 */         URI tmpAlgorithm = null;
/*      */         try {
/* 2806 */           tmpAlgorithm = new URI(algorithm);
/*      */         }
/*      */         catch (URI.MalformedURIException localMalformedURIException) {}
/*      */         
/* 2810 */         this.algorithmURI = tmpAlgorithm.toString();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       Element toElement()
/*      */       {
/* 2825 */         Element result = ElementProxy.createElementForFamily(
/* 2826 */           XMLCipher.this._contextDocument, 
/* 2827 */           "http://www.w3.org/2001/04/xmlenc#", 
/* 2828 */           "AgreementMethod");
/* 2829 */         result.setAttributeNS(
/* 2830 */           null, "Algorithm", this.algorithmURI);
/* 2831 */         if (this.kaNonce != null)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 2836 */           result.appendChild(ElementProxy.createElementForFamily(XMLCipher.this._contextDocument, "http://www.w3.org/2001/04/xmlenc#", "KA-Nonce")).appendChild(
/* 2837 */             XMLCipher.this._contextDocument.createTextNode(new String(this.kaNonce)));
/*      */         }
/* 2839 */         if (!this.agreementMethodInformation.isEmpty()) {
/* 2840 */           Iterator itr = this.agreementMethodInformation.iterator();
/* 2841 */           while (itr.hasNext()) {
/* 2842 */             result.appendChild((Element)itr.next());
/*      */           }
/*      */         }
/* 2845 */         if (this.originatorKeyInfo != null) {
/* 2846 */           result.appendChild(this.originatorKeyInfo.getElement());
/*      */         }
/* 2848 */         if (this.recipientKeyInfo != null) {
/* 2849 */           result.appendChild(this.recipientKeyInfo.getElement());
/*      */         }
/*      */         
/* 2852 */         return result;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private class CipherDataImpl
/*      */       implements CipherData
/*      */     {
/*      */       private static final String valueMessage = "Data type is reference type.";
/*      */       
/*      */ 
/*      */       private static final String referenceMessage = "Data type is value type.";
/*      */       
/*      */ 
/* 2868 */       private CipherValue cipherValue = null;
/* 2869 */       private CipherReference cipherReference = null;
/* 2870 */       private int cipherType = Integer.MIN_VALUE;
/*      */       
/*      */ 
/*      */ 
/*      */       public CipherDataImpl(int type)
/*      */       {
/* 2876 */         this.cipherType = type;
/*      */       }
/*      */       
/*      */       public CipherValue getCipherValue()
/*      */       {
/* 2881 */         return this.cipherValue;
/*      */       }
/*      */       
/*      */ 
/*      */       public void setCipherValue(CipherValue value)
/*      */         throws XMLEncryptionException
/*      */       {
/* 2888 */         if (this.cipherType == 2) {
/* 2889 */           throw new XMLEncryptionException("empty", 
/* 2890 */             new UnsupportedOperationException("Data type is reference type."));
/*      */         }
/*      */         
/* 2893 */         this.cipherValue = value;
/*      */       }
/*      */       
/*      */       public CipherReference getCipherReference()
/*      */       {
/* 2898 */         return this.cipherReference;
/*      */       }
/*      */       
/*      */       public void setCipherReference(CipherReference reference)
/*      */         throws XMLEncryptionException
/*      */       {
/* 2904 */         if (this.cipherType == 1) {
/* 2905 */           throw new XMLEncryptionException("empty", 
/* 2906 */             new UnsupportedOperationException("Data type is value type."));
/*      */         }
/*      */         
/* 2909 */         this.cipherReference = reference;
/*      */       }
/*      */       
/*      */       public int getDataType()
/*      */       {
/* 2914 */         return this.cipherType;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       Element toElement()
/*      */       {
/* 2925 */         Element result = ElementProxy.createElementForFamily(
/* 2926 */           XMLCipher.this._contextDocument, 
/* 2927 */           "http://www.w3.org/2001/04/xmlenc#", 
/* 2928 */           "CipherData");
/* 2929 */         if (this.cipherType == 1) {
/* 2930 */           result.appendChild(
/* 2931 */             ((XMLCipher.Factory.CipherValueImpl)this.cipherValue).toElement());
/* 2932 */         } else if (this.cipherType == 2) {
/* 2933 */           result.appendChild(
/* 2934 */             ((XMLCipher.Factory.CipherReferenceImpl)this.cipherReference).toElement());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 2939 */         return result;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private class CipherReferenceImpl
/*      */       implements CipherReference
/*      */     {
/* 2951 */       private String referenceURI = null;
/* 2952 */       private Transforms referenceTransforms = null;
/* 2953 */       private Attr referenceNode = null;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       public CipherReferenceImpl(String uri)
/*      */       {
/* 2960 */         this.referenceURI = uri;
/* 2961 */         this.referenceNode = null;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public CipherReferenceImpl(Attr uri)
/*      */       {
/* 2968 */         this.referenceURI = uri.getNodeValue();
/* 2969 */         this.referenceNode = uri;
/*      */       }
/*      */       
/*      */       public String getURI()
/*      */       {
/* 2974 */         return this.referenceURI;
/*      */       }
/*      */       
/*      */       public Attr getURIAsAttr()
/*      */       {
/* 2979 */         return this.referenceNode;
/*      */       }
/*      */       
/*      */       public Transforms getTransforms()
/*      */       {
/* 2984 */         return this.referenceTransforms;
/*      */       }
/*      */       
/*      */       public void setTransforms(Transforms transforms)
/*      */       {
/* 2989 */         this.referenceTransforms = transforms;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       Element toElement()
/*      */       {
/* 3000 */         Element result = ElementProxy.createElementForFamily(
/* 3001 */           XMLCipher.this._contextDocument, 
/* 3002 */           "http://www.w3.org/2001/04/xmlenc#", 
/* 3003 */           "CipherReference");
/* 3004 */         result.setAttributeNS(
/* 3005 */           null, "URI", this.referenceURI);
/* 3006 */         if (this.referenceTransforms != null) {
/* 3007 */           result.appendChild(
/* 3008 */             ((XMLCipher.Factory.TransformsImpl)this.referenceTransforms).toElement());
/*      */         }
/*      */         
/* 3011 */         return result;
/*      */       }
/*      */     }
/*      */     
/*      */     private class CipherValueImpl implements CipherValue {
/* 3016 */       private String cipherValue = null;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       public CipherValueImpl(String value)
/*      */       {
/* 3027 */         this.cipherValue = value;
/*      */       }
/*      */       
/*      */       public String getValue()
/*      */       {
/* 3032 */         return this.cipherValue;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       public void setValue(String value)
/*      */       {
/* 3042 */         this.cipherValue = value;
/*      */       }
/*      */       
/*      */       Element toElement() {
/* 3046 */         Element result = ElementProxy.createElementForFamily(
/* 3047 */           XMLCipher.this._contextDocument, "http://www.w3.org/2001/04/xmlenc#", 
/* 3048 */           "CipherValue");
/* 3049 */         result.appendChild(XMLCipher.this._contextDocument.createTextNode(
/* 3050 */           this.cipherValue));
/*      */         
/* 3052 */         return result;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private class EncryptedDataImpl
/*      */       extends XMLCipher.Factory.EncryptedTypeImpl
/*      */       implements EncryptedData
/*      */     {
/*      */       public EncryptedDataImpl(CipherData data)
/*      */       {
/* 3081 */         super(data);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       Element toElement()
/*      */       {
/* 3104 */         Element result = ElementProxy.createElementForFamily(
/* 3105 */           XMLCipher.this._contextDocument, "http://www.w3.org/2001/04/xmlenc#", 
/* 3106 */           "EncryptedData");
/*      */         
/* 3108 */         if (super.getId() != null) {
/* 3109 */           result.setAttributeNS(
/* 3110 */             null, "Id", super.getId());
/*      */         }
/* 3112 */         if (super.getType() != null) {
/* 3113 */           result.setAttributeNS(
/* 3114 */             null, "Type", super.getType());
/*      */         }
/* 3116 */         if (super.getMimeType() != null) {
/* 3117 */           result.setAttributeNS(
/* 3118 */             null, "MimeType", 
/* 3119 */             super.getMimeType());
/*      */         }
/* 3121 */         if (super.getEncoding() != null) {
/* 3122 */           result.setAttributeNS(
/* 3123 */             null, "Encoding", 
/* 3124 */             super.getEncoding());
/*      */         }
/* 3126 */         if (super.getEncryptionMethod() != null) {
/* 3127 */           result.appendChild(((XMLCipher.Factory.EncryptionMethodImpl)
/* 3128 */             super.getEncryptionMethod()).toElement());
/*      */         }
/* 3130 */         if (super.getKeyInfo() != null) {
/* 3131 */           result.appendChild(super.getKeyInfo().getElement());
/*      */         }
/*      */         
/* 3134 */         result.appendChild(
/* 3135 */           ((XMLCipher.Factory.CipherDataImpl)super.getCipherData()).toElement());
/* 3136 */         if (super.getEncryptionProperties() != null) {
/* 3137 */           result.appendChild(((XMLCipher.Factory.EncryptionPropertiesImpl)
/* 3138 */             super.getEncryptionProperties()).toElement());
/*      */         }
/*      */         
/* 3141 */         return result;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private class EncryptedKeyImpl
/*      */       extends XMLCipher.Factory.EncryptedTypeImpl
/*      */       implements EncryptedKey
/*      */     {
/* 3172 */       private String keyRecipient = null;
/* 3173 */       private ReferenceList referenceList = null;
/* 3174 */       private String carriedName = null;
/*      */       
/*      */ 
/*      */ 
/*      */       public EncryptedKeyImpl(CipherData data)
/*      */       {
/* 3180 */         super(data);
/*      */       }
/*      */       
/*      */       public String getRecipient()
/*      */       {
/* 3185 */         return this.keyRecipient;
/*      */       }
/*      */       
/*      */       public void setRecipient(String recipient)
/*      */       {
/* 3190 */         this.keyRecipient = recipient;
/*      */       }
/*      */       
/*      */       public ReferenceList getReferenceList()
/*      */       {
/* 3195 */         return this.referenceList;
/*      */       }
/*      */       
/*      */       public void setReferenceList(ReferenceList list)
/*      */       {
/* 3200 */         this.referenceList = list;
/*      */       }
/*      */       
/*      */       public String getCarriedName()
/*      */       {
/* 3205 */         return this.carriedName;
/*      */       }
/*      */       
/*      */       public void setCarriedName(String name)
/*      */       {
/* 3210 */         this.carriedName = name;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       Element toElement()
/*      */       {
/* 3239 */         Element result = ElementProxy.createElementForFamily(
/* 3240 */           XMLCipher.this._contextDocument, "http://www.w3.org/2001/04/xmlenc#", 
/* 3241 */           "EncryptedKey");
/*      */         
/* 3243 */         if (super.getId() != null) {
/* 3244 */           result.setAttributeNS(
/* 3245 */             null, "Id", super.getId());
/*      */         }
/* 3247 */         if (super.getType() != null) {
/* 3248 */           result.setAttributeNS(
/* 3249 */             null, "Type", super.getType());
/*      */         }
/* 3251 */         if (super.getMimeType() != null) {
/* 3252 */           result.setAttributeNS(null, 
/* 3253 */             "MimeType", super.getMimeType());
/*      */         }
/* 3255 */         if (super.getEncoding() != null) {
/* 3256 */           result.setAttributeNS(null, "Encoding", 
/* 3257 */             super.getEncoding());
/*      */         }
/* 3259 */         if (getRecipient() != null) {
/* 3260 */           result.setAttributeNS(null, 
/* 3261 */             "Recipient", getRecipient());
/*      */         }
/* 3263 */         if (super.getEncryptionMethod() != null) {
/* 3264 */           result.appendChild(((XMLCipher.Factory.EncryptionMethodImpl)
/* 3265 */             super.getEncryptionMethod()).toElement());
/*      */         }
/* 3267 */         if (super.getKeyInfo() != null) {
/* 3268 */           result.appendChild(super.getKeyInfo().getElement());
/*      */         }
/* 3270 */         result.appendChild(
/* 3271 */           ((XMLCipher.Factory.CipherDataImpl)super.getCipherData()).toElement());
/* 3272 */         if (super.getEncryptionProperties() != null) {
/* 3273 */           result.appendChild(((XMLCipher.Factory.EncryptionPropertiesImpl)
/* 3274 */             super.getEncryptionProperties()).toElement());
/*      */         }
/* 3276 */         if ((this.referenceList != null) && (!this.referenceList.isEmpty())) {
/* 3277 */           result.appendChild(((XMLCipher.Factory.ReferenceListImpl)
/* 3278 */             getReferenceList()).toElement());
/*      */         }
/* 3280 */         if (this.carriedName != null) {
/* 3281 */           Element element = ElementProxy.createElementForFamily(
/* 3282 */             XMLCipher.this._contextDocument, 
/* 3283 */             "http://www.w3.org/2001/04/xmlenc#", 
/* 3284 */             "CarriedKeyName");
/* 3285 */           Node node = XMLCipher.this._contextDocument.createTextNode(this.carriedName);
/* 3286 */           element.appendChild(node);
/* 3287 */           result.appendChild(element);
/*      */         }
/*      */         
/* 3290 */         return result;
/*      */       }
/*      */     }
/*      */     
/*      */     private abstract class EncryptedTypeImpl {
/* 3295 */       private String id = null;
/* 3296 */       private String type = null;
/* 3297 */       private String mimeType = null;
/* 3298 */       private String encoding = null;
/* 3299 */       private EncryptionMethod encryptionMethod = null;
/* 3300 */       private KeyInfo keyInfo = null;
/* 3301 */       private CipherData cipherData = null;
/* 3302 */       private EncryptionProperties encryptionProperties = null;
/*      */       
/*      */       protected EncryptedTypeImpl(CipherData data) {
/* 3305 */         this.cipherData = data;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public String getId()
/*      */       {
/* 3312 */         return this.id;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public void setId(String id)
/*      */       {
/* 3319 */         this.id = id;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public String getType()
/*      */       {
/* 3326 */         return this.type;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public void setType(String type)
/*      */       {
/* 3333 */         if ((type == null) || (type.length() == 0)) {
/* 3334 */           this.type = null;
/*      */         } else {
/* 3336 */           URI tmpType = null;
/*      */           try {
/* 3338 */             tmpType = new URI(type);
/*      */           }
/*      */           catch (URI.MalformedURIException localMalformedURIException) {}
/*      */           
/* 3342 */           this.type = tmpType.toString();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public String getMimeType()
/*      */       {
/* 3350 */         return this.mimeType;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public void setMimeType(String type)
/*      */       {
/* 3357 */         this.mimeType = type;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public String getEncoding()
/*      */       {
/* 3364 */         return this.encoding;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public void setEncoding(String encoding)
/*      */       {
/* 3371 */         if ((encoding == null) || (encoding.length() == 0)) {
/* 3372 */           this.encoding = null;
/*      */         } else {
/* 3374 */           URI tmpEncoding = null;
/*      */           try {
/* 3376 */             tmpEncoding = new URI(encoding);
/*      */           }
/*      */           catch (URI.MalformedURIException localMalformedURIException) {}
/*      */           
/* 3380 */           this.encoding = tmpEncoding.toString();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public EncryptionMethod getEncryptionMethod()
/*      */       {
/* 3388 */         return this.encryptionMethod;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public void setEncryptionMethod(EncryptionMethod method)
/*      */       {
/* 3395 */         this.encryptionMethod = method;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public KeyInfo getKeyInfo()
/*      */       {
/* 3402 */         return this.keyInfo;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public void setKeyInfo(KeyInfo info)
/*      */       {
/* 3409 */         this.keyInfo = info;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public CipherData getCipherData()
/*      */       {
/* 3416 */         return this.cipherData;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public EncryptionProperties getEncryptionProperties()
/*      */       {
/* 3423 */         return this.encryptionProperties;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       public void setEncryptionProperties(EncryptionProperties properties)
/*      */       {
/* 3431 */         this.encryptionProperties = properties;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private class EncryptionMethodImpl
/*      */       implements EncryptionMethod
/*      */     {
/* 3444 */       private String algorithm = null;
/* 3445 */       private int keySize = Integer.MIN_VALUE;
/* 3446 */       private byte[] oaepParams = null;
/* 3447 */       private List encryptionMethodInformation = null;
/*      */       
/*      */ 
/*      */ 
/*      */       public EncryptionMethodImpl(String algorithm)
/*      */       {
/* 3453 */         URI tmpAlgorithm = null;
/*      */         try {
/* 3455 */           tmpAlgorithm = new URI(algorithm);
/*      */         }
/*      */         catch (URI.MalformedURIException localMalformedURIException) {}
/*      */         
/* 3459 */         this.algorithm = tmpAlgorithm.toString();
/* 3460 */         this.encryptionMethodInformation = new LinkedList();
/*      */       }
/*      */       
/*      */       public String getAlgorithm() {
/* 3464 */         return this.algorithm;
/*      */       }
/*      */       
/*      */       public int getKeySize() {
/* 3468 */         return this.keySize;
/*      */       }
/*      */       
/*      */       public void setKeySize(int size) {
/* 3472 */         this.keySize = size;
/*      */       }
/*      */       
/*      */       public byte[] getOAEPparams() {
/* 3476 */         return this.oaepParams;
/*      */       }
/*      */       
/*      */       public void setOAEPparams(byte[] params) {
/* 3480 */         this.oaepParams = params;
/*      */       }
/*      */       
/*      */       public Iterator getEncryptionMethodInformation() {
/* 3484 */         return this.encryptionMethodInformation.iterator();
/*      */       }
/*      */       
/*      */       public void addEncryptionMethodInformation(Element info) {
/* 3488 */         this.encryptionMethodInformation.add(info);
/*      */       }
/*      */       
/*      */       public void removeEncryptionMethodInformation(Element info) {
/* 3492 */         this.encryptionMethodInformation.remove(info);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       Element toElement()
/*      */       {
/* 3504 */         Element result = ElementProxy.createElementForFamily(
/* 3505 */           XMLCipher.this._contextDocument, "http://www.w3.org/2001/04/xmlenc#", 
/* 3506 */           "EncryptionMethod");
/* 3507 */         result.setAttributeNS(null, "Algorithm", 
/* 3508 */           this.algorithm);
/* 3509 */         if (this.keySize > 0) {
/* 3510 */           result.appendChild(
/* 3511 */             ElementProxy.createElementForFamily(XMLCipher.this._contextDocument, 
/* 3512 */             "http://www.w3.org/2001/04/xmlenc#", 
/* 3513 */             "KeySize").appendChild(
/* 3514 */             XMLCipher.this._contextDocument.createTextNode(
/* 3515 */             String.valueOf(this.keySize))));
/*      */         }
/* 3517 */         if (this.oaepParams != null) {
/* 3518 */           result.appendChild(
/* 3519 */             ElementProxy.createElementForFamily(XMLCipher.this._contextDocument, 
/* 3520 */             "http://www.w3.org/2001/04/xmlenc#", 
/* 3521 */             "OAEPparams").appendChild(
/* 3522 */             XMLCipher.this._contextDocument.createTextNode(
/* 3523 */             new String(this.oaepParams))));
/*      */         }
/* 3525 */         if (!this.encryptionMethodInformation.isEmpty()) {
/* 3526 */           Iterator itr = this.encryptionMethodInformation.iterator();
/* 3527 */           result.appendChild((Element)itr.next());
/*      */         }
/*      */         
/* 3530 */         return result;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private class EncryptionPropertiesImpl
/*      */       implements EncryptionProperties
/*      */     {
/* 3542 */       private String id = null;
/* 3543 */       private List encryptionProperties = null;
/*      */       
/*      */ 
/*      */ 
/*      */       public EncryptionPropertiesImpl()
/*      */       {
/* 3549 */         this.encryptionProperties = new LinkedList();
/*      */       }
/*      */       
/*      */       public String getId() {
/* 3553 */         return this.id;
/*      */       }
/*      */       
/*      */       public void setId(String id) {
/* 3557 */         this.id = id;
/*      */       }
/*      */       
/*      */       public Iterator getEncryptionProperties() {
/* 3561 */         return this.encryptionProperties.iterator();
/*      */       }
/*      */       
/*      */       public void addEncryptionProperty(EncryptionProperty property) {
/* 3565 */         this.encryptionProperties.add(property);
/*      */       }
/*      */       
/*      */       public void removeEncryptionProperty(EncryptionProperty property) {
/* 3569 */         this.encryptionProperties.remove(property);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       Element toElement()
/*      */       {
/* 3580 */         Element result = ElementProxy.createElementForFamily(
/* 3581 */           XMLCipher.this._contextDocument, "http://www.w3.org/2001/04/xmlenc#", 
/* 3582 */           "EncryptionProperties");
/* 3583 */         if (this.id != null) {
/* 3584 */           result.setAttributeNS(null, "Id", this.id);
/*      */         }
/* 3586 */         Iterator itr = getEncryptionProperties();
/* 3587 */         while (itr.hasNext()) {
/* 3588 */           result.appendChild(
/* 3589 */             ((XMLCipher.Factory.EncryptionPropertyImpl)itr.next()).toElement());
/*      */         }
/*      */         
/* 3592 */         return result;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private class EncryptionPropertyImpl
/*      */       implements EncryptionProperty
/*      */     {
/* 3606 */       private String target = null;
/* 3607 */       private String id = null;
/* 3608 */       private HashMap attributeMap = new HashMap();
/* 3609 */       private List encryptionInformation = null;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       public EncryptionPropertyImpl()
/*      */       {
/* 3616 */         this.encryptionInformation = new LinkedList();
/*      */       }
/*      */       
/*      */       public String getTarget() {
/* 3620 */         return this.target;
/*      */       }
/*      */       
/*      */       public void setTarget(String target) {
/* 3624 */         if ((target == null) || (target.length() == 0)) {
/* 3625 */           this.target = null;
/* 3626 */         } else if (target.startsWith("#"))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3632 */           this.target = target;
/*      */         } else {
/* 3634 */           URI tmpTarget = null;
/*      */           try {
/* 3636 */             tmpTarget = new URI(target);
/*      */           }
/*      */           catch (URI.MalformedURIException localMalformedURIException) {}
/*      */           
/* 3640 */           this.target = tmpTarget.toString();
/*      */         }
/*      */       }
/*      */       
/*      */       public String getId() {
/* 3645 */         return this.id;
/*      */       }
/*      */       
/*      */       public void setId(String id) {
/* 3649 */         this.id = id;
/*      */       }
/*      */       
/*      */       public String getAttribute(String attribute) {
/* 3653 */         return (String)this.attributeMap.get(attribute);
/*      */       }
/*      */       
/*      */       public void setAttribute(String attribute, String value) {
/* 3657 */         this.attributeMap.put(attribute, value);
/*      */       }
/*      */       
/*      */       public Iterator getEncryptionInformation() {
/* 3661 */         return this.encryptionInformation.iterator();
/*      */       }
/*      */       
/*      */       public void addEncryptionInformation(Element info) {
/* 3665 */         this.encryptionInformation.add(info);
/*      */       }
/*      */       
/*      */       public void removeEncryptionInformation(Element info) {
/* 3669 */         this.encryptionInformation.remove(info);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       Element toElement()
/*      */       {
/* 3682 */         Element result = ElementProxy.createElementForFamily(
/* 3683 */           XMLCipher.this._contextDocument, "http://www.w3.org/2001/04/xmlenc#", 
/* 3684 */           "EncryptionProperty");
/* 3685 */         if (this.target != null) {
/* 3686 */           result.setAttributeNS(null, "Target", 
/* 3687 */             this.target);
/*      */         }
/* 3689 */         if (this.id != null) {
/* 3690 */           result.setAttributeNS(null, "Id", 
/* 3691 */             this.id);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 3696 */         return result;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private class TransformsImpl
/*      */       extends adsi.org.apache.xml.security.transforms.Transforms
/*      */       implements Transforms
/*      */     {
/*      */       public TransformsImpl()
/*      */       {
/* 3714 */         super();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public TransformsImpl(Document doc)
/*      */       {
/* 3721 */         if (doc == null) {
/* 3722 */           throw new RuntimeException("Document is null");
/*      */         }
/*      */         
/* 3725 */         this._doc = doc;
/* 3726 */         this._constructionElement = createElementForFamilyLocal(this._doc, 
/* 3727 */           getBaseNamespace(), getBaseLocalName());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       public TransformsImpl(Element element)
/*      */         throws XMLSignatureException, InvalidTransformException, XMLSecurityException, TransformationException
/*      */       {
/* 3743 */         super("");
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       public Element toElement()
/*      */       {
/* 3753 */         if (this._doc == null) {
/* 3754 */           this._doc = XMLCipher.this._contextDocument;
/*      */         }
/* 3756 */         return getElement();
/*      */       }
/*      */       
/*      */       public adsi.org.apache.xml.security.transforms.Transforms getDSTransforms()
/*      */       {
/* 3761 */         return this;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public String getBaseNamespace()
/*      */       {
/* 3768 */         return "http://www.w3.org/2001/04/xmlenc#";
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private class ReferenceListImpl
/*      */       implements ReferenceList
/*      */     {
/*      */       private Class sentry;
/*      */       
/*      */ 
/*      */ 
/*      */       private List references;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       public ReferenceListImpl(int type)
/*      */       {
/* 3789 */         if (type == 1) {
/* 3790 */           this.sentry = DataReference.class;
/* 3791 */         } else if (type == 2) {
/* 3792 */           this.sentry = KeyReference.class;
/*      */         } else {
/* 3794 */           throw new IllegalArgumentException();
/*      */         }
/* 3796 */         this.references = new LinkedList();
/*      */       }
/*      */       
/*      */       public void add(Reference reference) {
/* 3800 */         if (!reference.getClass().equals(this.sentry)) {
/* 3801 */           throw new IllegalArgumentException();
/*      */         }
/* 3803 */         this.references.add(reference);
/*      */       }
/*      */       
/*      */       public void remove(Reference reference) {
/* 3807 */         if (!reference.getClass().equals(this.sentry)) {
/* 3808 */           throw new IllegalArgumentException();
/*      */         }
/* 3810 */         this.references.remove(reference);
/*      */       }
/*      */       
/*      */       public int size() {
/* 3814 */         return this.references.size();
/*      */       }
/*      */       
/*      */       public boolean isEmpty() {
/* 3818 */         return this.references.isEmpty();
/*      */       }
/*      */       
/*      */       public Iterator getReferences() {
/* 3822 */         return this.references.iterator();
/*      */       }
/*      */       
/*      */       Element toElement() {
/* 3826 */         Element result = ElementProxy.createElementForFamily(
/* 3827 */           XMLCipher.this._contextDocument, 
/* 3828 */           "http://www.w3.org/2001/04/xmlenc#", 
/* 3829 */           "ReferenceList");
/* 3830 */         Iterator eachReference = this.references.iterator();
/* 3831 */         while (eachReference.hasNext()) {
/* 3832 */           Reference reference = (Reference)eachReference.next();
/* 3833 */           result.appendChild(
/* 3834 */             ((ReferenceImpl)reference).toElement());
/*      */         }
/* 3836 */         return result;
/*      */       }
/*      */       
/*      */       public Reference newDataReference(String uri) {
/* 3840 */         return new DataReference(uri);
/*      */       }
/*      */       
/*      */       public Reference newKeyReference(String uri) {
/* 3844 */         return new KeyReference(uri);
/*      */       }
/*      */       
/*      */ 
/*      */       private abstract class ReferenceImpl
/*      */         implements Reference
/*      */       {
/*      */         private String uri;
/*      */         
/*      */         private List referenceInformation;
/*      */         
/*      */ 
/*      */         ReferenceImpl(String _uri)
/*      */         {
/* 3858 */           this.uri = _uri;
/* 3859 */           this.referenceInformation = new LinkedList();
/*      */         }
/*      */         
/*      */         public String getURI() {
/* 3863 */           return this.uri;
/*      */         }
/*      */         
/*      */         public Iterator getElementRetrievalInformation() {
/* 3867 */           return this.referenceInformation.iterator();
/*      */         }
/*      */         
/*      */         public void setURI(String _uri) {
/* 3871 */           this.uri = _uri;
/*      */         }
/*      */         
/*      */         public void removeElementRetrievalInformation(Element node) {
/* 3875 */           this.referenceInformation.remove(node);
/*      */         }
/*      */         
/*      */         public void addElementRetrievalInformation(Element node) {
/* 3879 */           this.referenceInformation.add(node);
/*      */         }
/*      */         
/*      */ 
/*      */         public abstract Element toElement();
/*      */         
/*      */ 
/*      */         Element toElement(String tagName)
/*      */         {
/* 3888 */           Element result = ElementProxy.createElementForFamily(
/* 3889 */             XMLCipher.this._contextDocument, 
/* 3890 */             "http://www.w3.org/2001/04/xmlenc#", 
/* 3891 */             tagName);
/* 3892 */           result.setAttribute("URI", this.uri);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3898 */           return result;
/*      */         }
/*      */       }
/*      */       
/*      */       private class DataReference extends XMLCipher.Factory.ReferenceListImpl.ReferenceImpl {
/*      */         DataReference(String uri) {
/* 3904 */           super(uri);
/*      */         }
/*      */         
/*      */         public Element toElement() {
/* 3908 */           return super.toElement("DataReference");
/*      */         }
/*      */       }
/*      */       
/*      */       private class KeyReference extends XMLCipher.Factory.ReferenceListImpl.ReferenceImpl {
/*      */         KeyReference(String uri) {
/* 3914 */           super(uri);
/*      */         }
/*      */         
/*      */         public Element toElement() {
/* 3918 */           return super.toElement("KeyReference");
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\encryption\XMLCipher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */