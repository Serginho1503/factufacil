/*     */ package adsi.org.apache.xml.security.c14n.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import adsi.org.apache.xml.security.c14n.helper.C14nHelper;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import adsi.org.apache.xml.security.transforms.params.InclusiveNamespaces;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Canonicalizer20010315Excl
/*     */   extends CanonicalizerBase
/*     */ {
/*  62 */   TreeSet _inclusiveNSSet = new TreeSet();
/*     */   static final String XMLNS_URI = "http://www.w3.org/2000/xmlns/";
/*  64 */   final SortedSet result = new TreeSet(COMPARE);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Canonicalizer20010315Excl(boolean includeComments)
/*     */   {
/*  71 */     super(includeComments);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalizeSubTree(Node rootNode)
/*     */     throws CanonicalizationException
/*     */   {
/*  83 */     return engineCanonicalizeSubTree(rootNode, "", null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalizeSubTree(Node rootNode, String inclusiveNamespaces)
/*     */     throws CanonicalizationException
/*     */   {
/*  95 */     return engineCanonicalizeSubTree(rootNode, inclusiveNamespaces, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalizeSubTree(Node rootNode, String inclusiveNamespaces, Node excl)
/*     */     throws CanonicalizationException
/*     */   {
/* 107 */     this._inclusiveNSSet = ((TreeSet)
/* 108 */       InclusiveNamespaces.prefixStr2Set(inclusiveNamespaces));
/* 109 */     return super.engineCanonicalizeSubTree(rootNode, excl);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalize(XMLSignatureInput rootNode, String inclusiveNamespaces)
/*     */     throws CanonicalizationException
/*     */   {
/* 120 */     this._inclusiveNSSet = ((TreeSet)
/* 121 */       InclusiveNamespaces.prefixStr2Set(inclusiveNamespaces));
/* 122 */     return super.engineCanonicalize(rootNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Iterator handleAttributesSubtree(Element E, NameSpaceSymbTable ns)
/*     */     throws CanonicalizationException
/*     */   {
/* 136 */     SortedSet result = this.result;
/* 137 */     result.clear();
/* 138 */     NamedNodeMap attrs = null;
/*     */     
/* 140 */     int attrsLength = 0;
/* 141 */     if (E.hasAttributes()) {
/* 142 */       attrs = E.getAttributes();
/* 143 */       attrsLength = attrs.getLength();
/*     */     }
/*     */     
/* 146 */     SortedSet visiblyUtilized = (SortedSet)this._inclusiveNSSet.clone();
/*     */     
/* 148 */     for (int i = 0; i < attrsLength; i++) {
/* 149 */       Attr N = (Attr)attrs.item(i);
/*     */       
/* 151 */       if ("http://www.w3.org/2000/xmlns/" != N.getNamespaceURI())
/*     */       {
/*     */ 
/* 154 */         String prefix = N.getPrefix();
/* 155 */         if ((prefix != null) && (!prefix.equals("xml")) && (!prefix.equals("xmlns"))) {
/* 156 */           visiblyUtilized.add(prefix);
/*     */         }
/*     */         
/* 159 */         result.add(N);
/*     */       }
/*     */       else {
/* 162 */         String NName = N.getLocalName();
/* 163 */         String NNodeValue = N.getNodeValue();
/*     */         
/* 165 */         if (ns.addMapping(NName, NNodeValue, N))
/*     */         {
/* 167 */           if (C14nHelper.namespaceIsRelative(NNodeValue)) {
/* 168 */             Object[] exArgs = { E.getTagName(), NName, 
/* 169 */               N.getNodeValue() };
/* 170 */             throw new CanonicalizationException(
/* 171 */               "c14n.Canonicalizer.RelativeNamespace", exArgs);
/*     */           } }
/*     */       }
/*     */     }
/*     */     String prefix;
/* 176 */     if (E.getNamespaceURI() != null) {
/* 177 */       String prefix = E.getPrefix();
/* 178 */       if ((prefix == null) || (prefix.length() == 0)) {
/* 179 */         prefix = "xmlns";
/*     */       }
/*     */     }
/*     */     else {
/* 183 */       prefix = "xmlns";
/*     */     }
/* 185 */     visiblyUtilized.add(prefix);
/*     */     
/*     */ 
/* 188 */     Iterator it = visiblyUtilized.iterator();
/* 189 */     while (it.hasNext()) {
/* 190 */       String s = (String)it.next();
/* 191 */       Attr key = ns.getMapping(s);
/* 192 */       if (key != null)
/*     */       {
/*     */ 
/* 195 */         result.add(key);
/*     */       }
/*     */     }
/* 198 */     return result.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalizeXPathNodeSet(Set xpathNodeSet, String inclusiveNamespaces)
/*     */     throws CanonicalizationException
/*     */   {
/* 212 */     this._inclusiveNSSet = ((TreeSet)
/* 213 */       InclusiveNamespaces.prefixStr2Set(inclusiveNamespaces));
/* 214 */     return super.engineCanonicalizeXPathNodeSet(xpathNodeSet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final Iterator handleAttributes(Element E, NameSpaceSymbTable ns)
/*     */     throws CanonicalizationException
/*     */   {
/* 226 */     SortedSet result = this.result;
/* 227 */     result.clear();
/* 228 */     NamedNodeMap attrs = null;
/* 229 */     int attrsLength = 0;
/* 230 */     if (E.hasAttributes()) {
/* 231 */       attrs = E.getAttributes();
/* 232 */       attrsLength = attrs.getLength();
/*     */     }
/*     */     
/* 235 */     Set visiblyUtilized = null;
/*     */     
/* 237 */     boolean isOutputElement = isVisibleDO(E, ns.getLevel()) == 1;
/* 238 */     if (isOutputElement) {
/* 239 */       visiblyUtilized = (Set)this._inclusiveNSSet.clone();
/*     */     }
/*     */     
/* 242 */     for (int i = 0; i < attrsLength; i++) {
/* 243 */       Attr N = (Attr)attrs.item(i);
/*     */       
/*     */ 
/* 246 */       if ("http://www.w3.org/2000/xmlns/" != N.getNamespaceURI()) {
/* 247 */         if (isVisible(N))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 252 */           if (isOutputElement)
/*     */           {
/* 254 */             String prefix = N.getPrefix();
/* 255 */             if ((prefix != null) && (!prefix.equals("xml")) && (!prefix.equals("xmlns"))) {
/* 256 */               visiblyUtilized.add(prefix);
/*     */             }
/*     */             
/* 259 */             result.add(N);
/*     */           }
/*     */         }
/*     */       } else {
/* 263 */         String NName = N.getLocalName();
/* 264 */         if ((isOutputElement) && (!isVisible(N)) && (NName != "xmlns")) {
/* 265 */           ns.removeMappingIfNotRender(NName);
/*     */         }
/*     */         else {
/* 268 */           String NNodeValue = N.getNodeValue();
/*     */           
/* 270 */           if ((!isOutputElement) && (isVisible(N)) && (this._inclusiveNSSet.contains(NName)) && (!ns.removeMappingIfRender(NName))) {
/* 271 */             Node n = ns.addMappingAndRender(NName, NNodeValue, N);
/* 272 */             if (n != null) {
/* 273 */               result.add(n);
/* 274 */               if (C14nHelper.namespaceIsRelative(N)) {
/* 275 */                 Object[] exArgs = { E.getTagName(), NName, N.getNodeValue() };
/* 276 */                 throw new CanonicalizationException(
/* 277 */                   "c14n.Canonicalizer.RelativeNamespace", exArgs);
/*     */               }
/*     */             }
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 284 */           if (ns.addMapping(NName, NNodeValue, N))
/*     */           {
/* 286 */             if (C14nHelper.namespaceIsRelative(NNodeValue)) {
/* 287 */               Object[] exArgs = { E.getTagName(), NName, 
/* 288 */                 N.getNodeValue() };
/* 289 */               throw new CanonicalizationException(
/* 290 */                 "c14n.Canonicalizer.RelativeNamespace", exArgs);
/*     */             } }
/*     */         }
/*     */       }
/*     */     }
/* 295 */     if (isOutputElement)
/*     */     {
/* 297 */       Attr xmlns = E.getAttributeNodeNS("http://www.w3.org/2000/xmlns/", "xmlns");
/* 298 */       if ((xmlns != null) && (!isVisible(xmlns)))
/*     */       {
/*     */ 
/* 301 */         ns.addMapping("xmlns", "", nullNode);
/*     */       }
/*     */       
/* 304 */       if (E.getNamespaceURI() != null) {
/* 305 */         String prefix = E.getPrefix();
/* 306 */         if ((prefix == null) || (prefix.length() == 0)) {
/* 307 */           visiblyUtilized.add("xmlns");
/*     */         } else {
/* 309 */           visiblyUtilized.add(prefix);
/*     */         }
/*     */       } else {
/* 312 */         visiblyUtilized.add("xmlns");
/*     */       }
/*     */       
/*     */ 
/* 316 */       Iterator it = visiblyUtilized.iterator();
/* 317 */       while (it.hasNext()) {
/* 318 */         String s = (String)it.next();
/* 319 */         Attr key = ns.getMapping(s);
/* 320 */         if (key != null)
/*     */         {
/*     */ 
/* 323 */           result.add(key);
/*     */         }
/*     */       }
/*     */     }
/* 327 */     return result.iterator();
/*     */   }
/*     */   
/* 330 */   void circumventBugIfNeeded(XMLSignatureInput input) throws CanonicalizationException, ParserConfigurationException, IOException, SAXException { if ((!input.isNeedsToBeExpanded()) || (this._inclusiveNSSet.isEmpty()))
/* 331 */       return;
/* 332 */     Document doc = null;
/* 333 */     if (input.getSubNode() != null) {
/* 334 */       doc = XMLUtils.getOwnerDocument(input.getSubNode());
/*     */     } else {
/* 336 */       doc = XMLUtils.getOwnerDocument(input.getNodeSet());
/*     */     }
/*     */     
/* 339 */     XMLUtils.circumventBug2650(doc);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\c14n\implementations\Canonicalizer20010315Excl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */