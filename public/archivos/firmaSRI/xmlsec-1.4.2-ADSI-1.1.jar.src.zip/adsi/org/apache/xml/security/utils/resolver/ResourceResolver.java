/*     */ package adsi.org.apache.xml.security.utils.resolver;
/*     */ 
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Attr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceResolver
/*     */ {
/*  54 */   static Log log = LogFactory.getLog(ResourceResolver.class.getName());
/*     */   
/*     */ 
/*  57 */   static boolean _alreadyInitialized = false;
/*     */   
/*     */ 
/*  60 */   static List _resolverVector = null;
/*     */   
/*  62 */   static boolean allThreadSafeInList = true;
/*     */   
/*     */ 
/*  65 */   protected ResourceResolverSpi _resolverSpi = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ResourceResolver(String className)
/*     */     throws ClassNotFoundException, IllegalAccessException, InstantiationException
/*     */   {
/*  78 */     this._resolverSpi = 
/*  79 */       ((ResourceResolverSpi)Class.forName(className).newInstance());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceResolver(ResourceResolverSpi resourceResolver)
/*     */   {
/*  88 */     this._resolverSpi = resourceResolver;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final ResourceResolver getInstance(Attr uri, String BaseURI)
/*     */     throws ResourceResolverException
/*     */   {
/* 103 */     int length = _resolverVector.size();
/* 104 */     for (int i = 0; i < length; i++) {
/* 105 */       ResourceResolver resolver = 
/* 106 */         (ResourceResolver)_resolverVector.get(i);
/* 107 */       ResourceResolver resolverTmp = null;
/*     */       try {
/* 109 */         resolverTmp = (allThreadSafeInList) || (resolver._resolverSpi.engineIsThreadSafe()) ? resolver : 
/* 110 */           new ResourceResolver((ResourceResolverSpi)resolver._resolverSpi.getClass().newInstance());
/*     */       } catch (InstantiationException e) {
/* 112 */         throw new ResourceResolverException("", e, uri, BaseURI);
/*     */       } catch (IllegalAccessException e) {
/* 114 */         throw new ResourceResolverException("", e, uri, BaseURI);
/*     */       }
/*     */       
/* 117 */       if (log.isDebugEnabled()) {
/* 118 */         log.debug("check resolvability by class " + resolver._resolverSpi.getClass().getName());
/*     */       }
/* 120 */       if ((resolver != null) && (resolverTmp.canResolve(uri, BaseURI))) {
/* 121 */         if (i != 0)
/*     */         {
/*     */ 
/* 124 */           List resolverVector = (List)((ArrayList)_resolverVector).clone();
/* 125 */           resolverVector.remove(i);
/* 126 */           resolverVector.add(0, resolver);
/* 127 */           _resolverVector = resolverVector;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 132 */         return resolverTmp;
/*     */       }
/*     */     }
/*     */     
/* 136 */     Object[] exArgs = { uri != null ? 
/* 137 */       uri.getNodeValue() : 
/* 138 */       "null", BaseURI };
/*     */     
/* 140 */     throw new ResourceResolverException("utils.resolver.noClass", exArgs, 
/* 141 */       uri, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final ResourceResolver getInstance(Attr uri, String BaseURI, List individualResolvers)
/*     */     throws ResourceResolverException
/*     */   {
/* 156 */     if (log.isDebugEnabled())
/*     */     {
/* 158 */       log.debug("I was asked to create a ResourceResolver and got " + (individualResolvers == null ? 0 : individualResolvers.size()));
/* 159 */       log.debug(" extra resolvers to my existing " + _resolverVector.size() + " system-wide resolvers");
/*     */     }
/*     */     
/*     */ 
/* 163 */     int size = 0;
/* 164 */     if ((individualResolvers != null) && ((size = individualResolvers.size()) > 0)) {
/* 165 */       for (int i = 0; i < size; i++) {
/* 166 */         ResourceResolver resolver = 
/* 167 */           (ResourceResolver)individualResolvers.get(i);
/*     */         
/* 169 */         if (resolver != null) {
/* 170 */           String currentClass = resolver._resolverSpi.getClass().getName();
/* 171 */           if (log.isDebugEnabled()) {
/* 172 */             log.debug("check resolvability by class " + currentClass);
/*     */           }
/* 174 */           if (resolver.canResolve(uri, BaseURI)) {
/* 175 */             return resolver;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 181 */     return getInstance(uri, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void init()
/*     */   {
/* 189 */     if (!_alreadyInitialized) {
/* 190 */       _resolverVector = new ArrayList(10);
/* 191 */       _alreadyInitialized = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void register(String className)
/*     */   {
/* 203 */     register(className, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void registerAtStart(String className)
/*     */   {
/* 214 */     register(className, true);
/*     */   }
/*     */   
/*     */   private static void register(String className, boolean start) {
/*     */     try {
/* 219 */       ResourceResolver resolver = new ResourceResolver(className);
/* 220 */       if (start) {
/* 221 */         _resolverVector.add(0, resolver);
/* 222 */         log.debug("registered resolver");
/*     */       } else {
/* 224 */         _resolverVector.add(resolver);
/*     */       }
/* 226 */       if (!resolver._resolverSpi.engineIsThreadSafe()) {
/* 227 */         allThreadSafeInList = false;
/*     */       }
/*     */     } catch (Exception e) {
/* 230 */       log.warn("Error loading resolver " + className + " disabling it");
/*     */     } catch (NoClassDefFoundError e) {
/* 232 */       log.warn("Error loading resolver " + className + " disabling it");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XMLSignatureInput resolveStatic(Attr uri, String BaseURI)
/*     */     throws ResourceResolverException
/*     */   {
/* 248 */     ResourceResolver myResolver = getInstance(uri, BaseURI);
/*     */     
/* 250 */     return myResolver.resolve(uri, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput resolve(Attr uri, String BaseURI)
/*     */     throws ResourceResolverException
/*     */   {
/* 264 */     return this._resolverSpi.engineResolve(uri, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProperty(String key, String value)
/*     */   {
/* 274 */     this._resolverSpi.engineSetProperty(key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getProperty(String key)
/*     */   {
/* 284 */     return this._resolverSpi.engineGetProperty(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addProperties(Map properties)
/*     */   {
/* 293 */     this._resolverSpi.engineAddProperies(properties);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getPropertyKeys()
/*     */   {
/* 302 */     return this._resolverSpi.engineGetPropertyKeys();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean understandsProperty(String propertyToTest)
/*     */   {
/* 312 */     return this._resolverSpi.understandsProperty(propertyToTest);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean canResolve(Attr uri, String BaseURI)
/*     */   {
/* 323 */     return this._resolverSpi.engineCanResolve(uri, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean canAccessData()
/*     */   {
/* 332 */     return !this._resolverSpi.engineIsPrivateData();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\utils\resolver\ResourceResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */