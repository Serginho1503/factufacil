/*    */ package adsi.org.apache.xml.security.transforms.implementations;
/*    */ 
/*    */ import adsi.org.apache.xml.security.c14n.CanonicalizationException;
/*    */ import adsi.org.apache.xml.security.c14n.implementations.Canonicalizer20010315ExclWithComments;
/*    */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*    */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*    */ import adsi.org.apache.xml.security.transforms.Transform;
/*    */ import adsi.org.apache.xml.security.transforms.TransformSpi;
/*    */ import adsi.org.apache.xml.security.transforms.params.InclusiveNamespaces;
/*    */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*    */ import java.io.OutputStream;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransformC14NExclusiveWithComments
/*    */   extends TransformSpi
/*    */ {
/*    */   public static final String implementedTransformURI = "http://www.w3.org/2001/10/xml-exc-c14n#WithComments";
/*    */   
/*    */   protected String engineGetURI()
/*    */   {
/* 51 */     return "http://www.w3.org/2001/10/xml-exc-c14n#WithComments";
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, Transform _transformObject)
/*    */     throws CanonicalizationException
/*    */   {
/* 60 */     return enginePerformTransform(input, null, _transformObject);
/*    */   }
/*    */   
/*    */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, OutputStream os, Transform _transformObject) throws CanonicalizationException
/*    */   {
/*    */     try {
/* 66 */       String inclusiveNamespaces = null;
/*    */       
/* 68 */       if (_transformObject
/* 69 */         .length("http://www.w3.org/2001/10/xml-exc-c14n#", 
/* 70 */         "InclusiveNamespaces") == 
/* 71 */         1) {
/* 72 */         Element inclusiveElement = 
/* 73 */           XMLUtils.selectNode(
/* 74 */           _transformObject.getElement().getFirstChild(), 
/* 75 */           "http://www.w3.org/2001/10/xml-exc-c14n#", 
/* 76 */           "InclusiveNamespaces", 0);
/*    */         
/* 78 */         inclusiveNamespaces = new InclusiveNamespaces(inclusiveElement, 
/* 79 */           _transformObject.getBaseURI()).getInclusiveNamespaces();
/*    */       }
/*    */       
/* 82 */       Canonicalizer20010315ExclWithComments c14n = 
/* 83 */         new Canonicalizer20010315ExclWithComments();
/* 84 */       if (os != null) {
/* 85 */         c14n.setWriter(os);
/*    */       }
/*    */       
/* 88 */       byte[] result = c14n.engineCanonicalize(input, inclusiveNamespaces);
/* 89 */       return new XMLSignatureInput(result);
/*    */     }
/*    */     catch (XMLSecurityException ex)
/*    */     {
/* 93 */       throw new CanonicalizationException("empty", ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\transforms\implementations\TransformC14NExclusiveWithComments.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */