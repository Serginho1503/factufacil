/*     */ package adsi.org.apache.xml.security.signature;
/*     */ 
/*     */ import adsi.org.apache.xml.security.algorithms.MessageDigestAlgorithm;
/*     */ import adsi.org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import adsi.org.apache.xml.security.c14n.InvalidCanonicalizerException;
/*     */ import adsi.org.apache.xml.security.exceptions.Base64DecodingException;
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.transforms.InvalidTransformException;
/*     */ import adsi.org.apache.xml.security.transforms.Transform;
/*     */ import adsi.org.apache.xml.security.transforms.TransformationException;
/*     */ import adsi.org.apache.xml.security.transforms.Transforms;
/*     */ import adsi.org.apache.xml.security.transforms.params.InclusiveNamespaces;
/*     */ import adsi.org.apache.xml.security.utils.Base64;
/*     */ import adsi.org.apache.xml.security.utils.DigesterOutputStream;
/*     */ import adsi.org.apache.xml.security.utils.IdResolver;
/*     */ import adsi.org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import adsi.org.apache.xml.security.utils.UnsyncBufferedOutputStream;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolver;
/*     */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolverException;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Reference
/*     */   extends SignatureElementProxy
/*     */ {
/* 112 */   private static boolean useC14N11 = false;
/*     */   public static final boolean CacheSignedNodes = false;
/*     */   
/* 115 */   static { try { useC14N11 = Boolean.getBoolean("adsi.org.apache.xml.security.useC14N11");
/*     */     }
/*     */     catch (Exception localException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 126 */   static Log log = LogFactory.getLog(Reference.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String OBJECT_URI = "http://www.w3.org/2000/09/xmldsig#Object";
/*     */   
/*     */ 
/*     */   public static final String MANIFEST_URI = "http://www.w3.org/2000/09/xmldsig#Manifest";
/*     */   
/*     */ 
/* 136 */   Manifest _manifest = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   XMLSignatureInput _transformsOutput;
/*     */   
/*     */ 
/*     */ 
/*     */   private Transforms transforms;
/*     */   
/*     */ 
/*     */ 
/*     */   private Element digestMethodElem;
/*     */   
/*     */ 
/*     */ 
/*     */   private Element digestValueElement;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Reference(Document doc, String BaseURI, String ReferenceURI, Manifest manifest, Transforms transforms, String messageDigestAlgorithm)
/*     */     throws XMLSignatureException
/*     */   {
/* 161 */     super(doc);
/*     */     
/* 163 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */     
/* 165 */     this._baseURI = BaseURI;
/* 166 */     this._manifest = manifest;
/*     */     
/* 168 */     setURI(ReferenceURI);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 175 */     if (transforms != null) {
/* 176 */       this.transforms = transforms;
/* 177 */       this._constructionElement.appendChild(transforms.getElement());
/* 178 */       XMLUtils.addReturnToElement(this._constructionElement);
/*     */     }
/*     */     
/* 181 */     MessageDigestAlgorithm mda = 
/* 182 */       MessageDigestAlgorithm.getInstance(this._doc, 
/* 183 */       messageDigestAlgorithm);
/*     */     
/* 185 */     this.digestMethodElem = mda.getElement();
/* 186 */     this._constructionElement.appendChild(this.digestMethodElem);
/* 187 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */     
/*     */ 
/* 190 */     this.digestValueElement = 
/* 191 */       XMLUtils.createElementInSignatureSpace(this._doc, 
/* 192 */       "DigestValue");
/*     */     
/* 194 */     this._constructionElement.appendChild(this.digestValueElement);
/* 195 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Reference(Element element, String BaseURI, Manifest manifest)
/*     */     throws XMLSecurityException
/*     */   {
/* 211 */     super(element, BaseURI);
/* 212 */     this._baseURI = BaseURI;
/* 213 */     Element el = XMLUtils.getNextElement(element.getFirstChild());
/* 214 */     if (("Transforms".equals(el.getLocalName())) && 
/* 215 */       ("http://www.w3.org/2000/09/xmldsig#".equals(el.getNamespaceURI()))) {
/* 216 */       this.transforms = new Transforms(el, this._baseURI);
/* 217 */       el = XMLUtils.getNextElement(el.getNextSibling());
/*     */     }
/* 219 */     this.digestMethodElem = el;
/* 220 */     this.digestValueElement = XMLUtils.getNextElement(this.digestMethodElem.getNextSibling());
/* 221 */     this._manifest = manifest;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MessageDigestAlgorithm getMessageDigestAlgorithm()
/*     */     throws XMLSignatureException
/*     */   {
/* 235 */     if (this.digestMethodElem == null) {
/* 236 */       return null;
/*     */     }
/*     */     
/* 239 */     String uri = this.digestMethodElem.getAttributeNS(null, 
/* 240 */       "Algorithm");
/*     */     
/* 242 */     if (uri == null) {
/* 243 */       return null;
/*     */     }
/*     */     
/* 246 */     return MessageDigestAlgorithm.getInstance(this._doc, uri);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setURI(String URI)
/*     */   {
/* 256 */     if (URI != null) {
/* 257 */       this._constructionElement.setAttributeNS(null, "URI", 
/* 258 */         URI);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getURI()
/*     */   {
/* 268 */     return this._constructionElement.getAttributeNS(null, "URI");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setId(String Id)
/*     */   {
/* 278 */     if (Id != null) {
/* 279 */       this._constructionElement.setAttributeNS(null, "Id", Id);
/* 280 */       IdResolver.registerElementById(this._constructionElement, Id);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getId()
/*     */   {
/* 290 */     return this._constructionElement.getAttributeNS(null, "Id");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setType(String Type)
/*     */   {
/* 300 */     if (Type != null) {
/* 301 */       this._constructionElement.setAttributeNS(null, "Type", 
/* 302 */         Type);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getType()
/*     */   {
/* 312 */     return this._constructionElement.getAttributeNS(null, 
/* 313 */       "Type");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean typeIsReferenceToObject()
/*     */   {
/* 326 */     if ("http://www.w3.org/2000/09/xmldsig#Object".equals(getType())) {
/* 327 */       return true;
/*     */     }
/*     */     
/* 330 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean typeIsReferenceToManifest()
/*     */   {
/* 343 */     if ("http://www.w3.org/2000/09/xmldsig#Manifest".equals(getType())) {
/* 344 */       return true;
/*     */     }
/*     */     
/* 347 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setDigestValueElement(byte[] digestValue)
/*     */   {
/* 357 */     Node n = this.digestValueElement.getFirstChild();
/* 358 */     while (n != null) {
/* 359 */       this.digestValueElement.removeChild(n);
/* 360 */       n = n.getNextSibling();
/*     */     }
/*     */     
/* 363 */     String base64codedValue = Base64.encode(digestValue);
/* 364 */     Text t = this._doc.createTextNode(base64codedValue);
/*     */     
/* 366 */     this.digestValueElement.appendChild(t);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void generateDigestValue()
/*     */     throws XMLSignatureException, ReferenceNotInitializedException
/*     */   {
/* 377 */     setDigestValueElement(calculateDigest(false));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected byte[] getDigestPrivateData()
/*     */     throws ReferenceNotInitializedException
/*     */   {
/*     */     try
/*     */     {
/* 387 */       ResourceResolver resolver = getResourceResolver();
/* 388 */       Attr URIAttr = this._constructionElement.getAttributeNodeNS(null, 
/* 389 */         "URI");
/*     */       
/*     */ 
/* 392 */       if (!resolver.understandsProperty("digest.algorithm")) {
/* 393 */         throw new ReferenceNotInitializedException("empty");
/*     */       }
/* 395 */       if (this.digestMethodElem == null) {
/* 396 */         throw new ReferenceNotInitializedException("empty");
/*     */       }
/* 398 */       String uri = this.digestMethodElem.getAttributeNS(null, 
/* 399 */         "Algorithm");
/* 400 */       if (uri == null) {
/* 401 */         throw new ReferenceNotInitializedException("empty");
/*     */       }
/* 403 */       resolver.setProperty("digest.algorithm", uri);
/*     */       
/* 405 */       XMLSignatureInput input = resolver.resolve(URIAttr, this._baseURI);
/*     */       
/* 407 */       return input.getBytes();
/*     */     } catch (ReferenceNotInitializedException ex) {
/* 409 */       throw ex;
/*     */     } catch (ResourceResolverException ex) {
/* 411 */       throw new ReferenceNotInitializedException("empty", ex);
/*     */     } catch (CanonicalizationException ex) {
/* 413 */       throw new ReferenceNotInitializedException("empty", ex);
/*     */     } catch (IOException ex) {
/* 415 */       throw new ReferenceNotInitializedException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ResourceResolver getResourceResolver()
/*     */     throws ReferenceNotInitializedException
/*     */   {
/*     */     try
/*     */     {
/* 428 */       Attr URIAttr = this._constructionElement.getAttributeNodeNS(null, 
/* 429 */         "URI");
/*     */       
/* 431 */       ResourceResolver resolver = ResourceResolver.getInstance(URIAttr, 
/* 432 */         this._baseURI, this._manifest._perManifestResolvers);
/*     */       
/* 434 */       if (resolver == null) { String URI;
/*     */         String URI;
/* 436 */         if (URIAttr == null) {
/* 437 */           URI = null;
/*     */         } else {
/* 439 */           URI = URIAttr.getNodeValue();
/*     */         }
/* 441 */         Object[] exArgs = { URI };
/*     */         
/* 443 */         throw new ReferenceNotInitializedException(
/* 444 */           "signature.Verification.Reference.NoInput", exArgs);
/*     */       }
/*     */       
/* 447 */       resolver.addProperties(this._manifest._resolverProperties);
/*     */       
/* 449 */       return resolver;
/*     */     } catch (ResourceResolverException ex) {
/* 451 */       throw new ReferenceNotInitializedException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput getContentsBeforeTransformation()
/*     */     throws ReferenceNotInitializedException
/*     */   {
/*     */     try
/*     */     {
/* 463 */       ResourceResolver resolver = getResourceResolver();
/* 464 */       Attr URIAttr = this._constructionElement.getAttributeNodeNS(null, 
/* 465 */         "URI");
/*     */       
/* 467 */       return resolver.resolve(URIAttr, this._baseURI);
/*     */     }
/*     */     catch (ReferenceNotInitializedException ex)
/*     */     {
/* 471 */       throw ex;
/*     */     } catch (ResourceResolverException ex) {
/* 473 */       throw new ReferenceNotInitializedException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public XMLSignatureInput getTransformsInput()
/*     */     throws ReferenceNotInitializedException
/*     */   {
/* 487 */     XMLSignatureInput input = getContentsBeforeTransformation();
/*     */     try
/*     */     {
/* 490 */       result = new XMLSignatureInput(input.getBytes());
/*     */     } catch (CanonicalizationException ex) { XMLSignatureInput result;
/* 492 */       throw new ReferenceNotInitializedException("empty", ex);
/*     */     } catch (IOException ex) {
/* 494 */       throw new ReferenceNotInitializedException("empty", ex); }
/*     */     XMLSignatureInput result;
/* 496 */     result.setSourceURI(input.getSourceURI());
/* 497 */     return result;
/*     */   }
/*     */   
/*     */   private XMLSignatureInput getContentsAfterTransformation(XMLSignatureInput input, OutputStream os)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 505 */       Transforms transforms = getTransforms();
/* 506 */       XMLSignatureInput output = null;
/*     */       
/* 508 */       if (transforms != null) {
/* 509 */         output = transforms.performTransforms(input, os);
/* 510 */         this._transformsOutput = output;
/*     */       }
/*     */       
/*     */ 
/* 514 */       return input;
/*     */ 
/*     */     }
/*     */     catch (ResourceResolverException ex)
/*     */     {
/* 519 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (CanonicalizationException ex) {
/* 521 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (InvalidCanonicalizerException ex) {
/* 523 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (TransformationException ex) {
/* 525 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (XMLSecurityException ex) {
/* 527 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput getContentsAfterTransformation()
/*     */     throws XMLSignatureException
/*     */   {
/* 539 */     XMLSignatureInput input = getContentsBeforeTransformation();
/*     */     
/* 541 */     return getContentsAfterTransformation(input, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput getNodesetBeforeFirstCanonicalization()
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 555 */       XMLSignatureInput input = getContentsBeforeTransformation();
/* 556 */       XMLSignatureInput output = input;
/* 557 */       Transforms transforms = getTransforms();
/*     */       
/* 559 */       if (transforms != null) {
/* 560 */         for (int i = 0; i < transforms.getLength(); i++) {
/* 561 */           Transform t = transforms.item(i);
/* 562 */           String URI = t.getURI();
/*     */           
/* 564 */           if (URI.equals("http://www.w3.org/2001/10/xml-exc-c14n#"))
/*     */             break;
/* 566 */           if (URI.equals("http://www.w3.org/2001/10/xml-exc-c14n#WithComments"))
/*     */             break;
/* 568 */           if (URI.equals("http://www.w3.org/TR/2001/REC-xml-c14n-20010315"))
/*     */             break;
/* 570 */           if (URI.equals("http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments")) {
/*     */             break;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 576 */           output = t.performTransform(output, null);
/*     */         }
/*     */         
/* 579 */         output.setSourceURI(input.getSourceURI());
/*     */       }
/* 581 */       return output;
/*     */     } catch (IOException ex) {
/* 583 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (ResourceResolverException ex) {
/* 585 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (CanonicalizationException ex) {
/* 587 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (InvalidCanonicalizerException ex) {
/* 589 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (TransformationException ex) {
/* 591 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (XMLSecurityException ex) {
/* 593 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHTMLRepresentation()
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 605 */       XMLSignatureInput nodes = getNodesetBeforeFirstCanonicalization();
/* 606 */       Set inclusiveNamespaces = new HashSet();
/*     */       
/*     */ 
/* 609 */       Transforms transforms = getTransforms();
/* 610 */       Transform c14nTransform = null;
/*     */       
/* 612 */       if (transforms != null) {
/* 613 */         for (int i = 0; i < transforms.getLength(); i++) {
/* 614 */           Transform t = transforms.item(i);
/* 615 */           String URI = t.getURI();
/*     */           
/* 617 */           if ((URI.equals("http://www.w3.org/2001/10/xml-exc-c14n#")) || 
/* 618 */             (URI.equals(
/* 619 */             "http://www.w3.org/2001/10/xml-exc-c14n#WithComments"))) {
/* 620 */             c14nTransform = t;
/*     */             
/* 622 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 627 */       if (c14nTransform != null)
/*     */       {
/* 629 */         if (c14nTransform
/* 630 */           .length("http://www.w3.org/2001/10/xml-exc-c14n#", 
/* 631 */           "InclusiveNamespaces") == 
/* 632 */           1)
/*     */         {
/*     */ 
/* 635 */           InclusiveNamespaces in = new InclusiveNamespaces(
/* 636 */             XMLUtils.selectNode(
/* 637 */             c14nTransform.getElement().getFirstChild(), 
/* 638 */             "http://www.w3.org/2001/10/xml-exc-c14n#", 
/* 639 */             "InclusiveNamespaces", 0), getBaseURI());
/*     */           
/* 641 */           inclusiveNamespaces = InclusiveNamespaces.prefixStr2Set(
/* 642 */             in.getInclusiveNamespaces());
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 647 */       return nodes.getHTMLRepresentation(inclusiveNamespaces);
/*     */     } catch (TransformationException ex) {
/* 649 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (InvalidTransformException ex) {
/* 651 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (XMLSecurityException ex) {
/* 653 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput getTransformsOutput()
/*     */   {
/* 662 */     return this._transformsOutput;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected XMLSignatureInput dereferenceURIandPerformTransforms(OutputStream os)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 678 */       XMLSignatureInput input = getContentsBeforeTransformation();
/* 679 */       XMLSignatureInput output = getContentsAfterTransformation(input, os);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 688 */       this._transformsOutput = output;
/*     */       
/*     */ 
/*     */ 
/* 692 */       return output;
/*     */     } catch (XMLSecurityException ex) {
/* 694 */       throw new ReferenceNotInitializedException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Transforms getTransforms()
/*     */     throws XMLSignatureException, InvalidTransformException, TransformationException, XMLSecurityException
/*     */   {
/* 711 */     return this.transforms;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getReferencedBytes()
/*     */     throws ReferenceNotInitializedException, XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 724 */       XMLSignatureInput output = dereferenceURIandPerformTransforms(null);
/*     */       
/* 726 */       return output.getBytes();
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 730 */       throw new ReferenceNotInitializedException("empty", ex);
/*     */     } catch (CanonicalizationException ex) {
/* 732 */       throw new ReferenceNotInitializedException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] calculateDigest(boolean validating)
/*     */     throws ReferenceNotInitializedException, XMLSignatureException
/*     */   {
/* 749 */     ResourceResolver rr = getResourceResolver();
/* 750 */     if (rr.canAccessData()) {
/*     */       try {
/* 752 */         MessageDigestAlgorithm mda = getMessageDigestAlgorithm();
/*     */         
/* 754 */         mda.reset();
/* 755 */         DigesterOutputStream diOs = new DigesterOutputStream(mda);
/* 756 */         OutputStream os = new UnsyncBufferedOutputStream(diOs);
/* 757 */         XMLSignatureInput output = dereferenceURIandPerformTransforms(os);
/*     */         
/*     */ 
/* 760 */         if ((useC14N11) && (!validating) && 
/* 761 */           (!output.isOutputStreamSet()) && (!output.isOctetStream())) {
/* 762 */           if (this.transforms == null) {
/* 763 */             this.transforms = new Transforms(this._doc);
/* 764 */             this._constructionElement.insertBefore(this.transforms.getElement(), this.digestMethodElem);
/*     */           }
/* 766 */           this.transforms.addTransform("http://www.w3.org/2006/12/xml-c14n11");
/* 767 */           output.updateOutputStream(os, true);
/*     */         } else {
/* 769 */           output.updateOutputStream(os);
/*     */         }
/* 771 */         os.flush();
/*     */         
/*     */ 
/*     */ 
/* 775 */         return diOs.getDigestValue();
/*     */       } catch (XMLSecurityException ex) {
/* 777 */         throw new ReferenceNotInitializedException("empty", ex);
/*     */       } catch (IOException ex) {
/* 779 */         throw new ReferenceNotInitializedException("empty", ex);
/*     */       }
/*     */     }
/*     */     
/* 783 */     return getDigestPrivateData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getDigestValue()
/*     */     throws Base64DecodingException, XMLSecurityException
/*     */   {
/* 795 */     if (this.digestValueElement == null)
/*     */     {
/* 797 */       Object[] exArgs = { "DigestValue", 
/* 798 */         "http://www.w3.org/2000/09/xmldsig#" };
/* 799 */       throw new XMLSecurityException(
/* 800 */         "signature.Verification.NoSignatureElement", 
/* 801 */         exArgs);
/*     */     }
/* 803 */     byte[] elemDig = Base64.decode(this.digestValueElement);
/* 804 */     return elemDig;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean verify()
/*     */     throws ReferenceNotInitializedException, XMLSecurityException
/*     */   {
/* 818 */     byte[] elemDig = getDigestValue();
/* 819 */     byte[] calcDig = calculateDigest(true);
/* 820 */     boolean equal = MessageDigestAlgorithm.isEqual(elemDig, calcDig);
/*     */     
/* 822 */     if (!equal) {
/* 823 */       log.warn("Verification failed for URI \"" + getURI() + "\"");
/* 824 */       log.warn("Expected Digest: " + Base64.encode(elemDig));
/* 825 */       log.warn("Actual Digest: " + Base64.encode(calcDig));
/*     */     } else {
/* 827 */       log.info("Verification successful for URI \"" + getURI() + "\"");
/*     */     }
/*     */     
/* 830 */     return equal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBaseLocalName()
/*     */   {
/* 839 */     return "Reference";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\signature\Reference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */