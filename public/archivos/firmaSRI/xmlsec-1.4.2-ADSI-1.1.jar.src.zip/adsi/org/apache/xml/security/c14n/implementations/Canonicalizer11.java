/*     */ package adsi.org.apache.xml.security.c14n.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import adsi.org.apache.xml.security.c14n.helper.C14nHelper;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Canonicalizer11
/*     */   extends CanonicalizerBase
/*     */ {
/*  58 */   boolean firstCall = true;
/*  59 */   final SortedSet result = new TreeSet(COMPARE);
/*     */   
/*     */   static final String XMLNS_URI = "http://www.w3.org/2000/xmlns/";
/*     */   static final String XML_LANG_URI = "http://www.w3.org/XML/1998/namespace";
/*  63 */   static Log log = LogFactory.getLog(Canonicalizer11.class.getName());
/*     */   
/*     */   static class XmlAttrStack {
/*  66 */     int currentLevel = 0;
/*  67 */     int lastlevel = 0;
/*     */     XmlsStackElement cur;
/*     */     
/*     */     static class XmlsStackElement { int level;
/*  71 */       boolean rendered = false;
/*  72 */       List nodes = new ArrayList(); }
/*     */     
/*  74 */     List levels = new ArrayList();
/*     */     
/*  76 */     void push(int level) { this.currentLevel = level;
/*  77 */       if (this.currentLevel == -1)
/*  78 */         return;
/*  79 */       this.cur = null;
/*  80 */       while (this.lastlevel >= this.currentLevel) {
/*  81 */         this.levels.remove(this.levels.size() - 1);
/*  82 */         if (this.levels.size() == 0) {
/*  83 */           this.lastlevel = 0;
/*  84 */           return;
/*     */         }
/*  86 */         this.lastlevel = ((XmlsStackElement)this.levels.get(this.levels.size() - 1)).level;
/*     */       }
/*     */     }
/*     */     
/*  90 */     void addXmlnsAttr(Attr n) { if (this.cur == null) {
/*  91 */         this.cur = new XmlsStackElement();
/*  92 */         this.cur.level = this.currentLevel;
/*  93 */         this.levels.add(this.cur);
/*  94 */         this.lastlevel = this.currentLevel;
/*     */       }
/*  96 */       this.cur.nodes.add(n);
/*     */     }
/*     */     
/*  99 */     void getXmlnsAttr(Collection col) { if (this.cur == null) {
/* 100 */         this.cur = new XmlsStackElement();
/* 101 */         this.cur.level = this.currentLevel;
/* 102 */         this.lastlevel = this.currentLevel;
/* 103 */         this.levels.add(this.cur);
/*     */       }
/* 105 */       int size = this.levels.size() - 2;
/* 106 */       boolean parentRendered = false;
/* 107 */       XmlsStackElement e = null;
/* 108 */       if (size == -1) {
/* 109 */         parentRendered = true;
/*     */       } else {
/* 111 */         e = (XmlsStackElement)this.levels.get(size);
/* 112 */         if ((e.rendered) && (e.level + 1 == this.currentLevel))
/* 113 */           parentRendered = true;
/*     */       }
/* 115 */       if (parentRendered) {
/* 116 */         col.addAll(this.cur.nodes);
/* 117 */         this.cur.rendered = true;
/* 118 */         return;
/*     */       }
/*     */       
/* 121 */       Map loa = new HashMap();
/* 122 */       List baseAttrs = new ArrayList();
/* 123 */       boolean successiveOmitted = true;
/* 124 */       for (; size >= 0; size--) {
/* 125 */         e = (XmlsStackElement)this.levels.get(size);
/* 126 */         if (e.rendered) {
/* 127 */           successiveOmitted = false;
/*     */         }
/* 129 */         Iterator it = e.nodes.iterator();
/* 130 */         while ((it.hasNext()) && (successiveOmitted)) {
/* 131 */           Attr n = (Attr)it.next();
/* 132 */           if (n.getLocalName().equals("base")) {
/* 133 */             if (!e.rendered) {
/* 134 */               baseAttrs.add(n);
/*     */             }
/* 136 */           } else if (!loa.containsKey(n.getName()))
/* 137 */             loa.put(n.getName(), n);
/*     */         }
/*     */       }
/* 140 */       if (!baseAttrs.isEmpty()) {
/* 141 */         Iterator it = this.cur.nodes.iterator();
/* 142 */         String base = null;
/* 143 */         Attr baseAttr = null;
/* 144 */         while (it.hasNext()) {
/* 145 */           Attr n = (Attr)it.next();
/* 146 */           if (n.getLocalName().equals("base")) {
/* 147 */             base = n.getValue();
/* 148 */             baseAttr = n;
/* 149 */             break;
/*     */           }
/*     */         }
/* 152 */         it = baseAttrs.iterator();
/* 153 */         while (it.hasNext()) {
/* 154 */           Attr n = (Attr)it.next();
/* 155 */           if (base == null) {
/* 156 */             base = n.getValue();
/* 157 */             baseAttr = n;
/*     */           } else {
/*     */             try {
/* 160 */               base = Canonicalizer11.joinURI(n.getValue(), base);
/*     */             } catch (URISyntaxException ue) {
/* 162 */               ue.printStackTrace();
/*     */             }
/*     */           }
/*     */         }
/* 166 */         if ((base != null) && (base.length() != 0)) {
/* 167 */           baseAttr.setValue(base);
/* 168 */           col.add(baseAttr);
/*     */         }
/*     */       }
/*     */       
/* 172 */       this.cur.rendered = true;
/* 173 */       col.addAll(loa.values());
/*     */     } }
/*     */   
/* 176 */   XmlAttrStack xmlattrStack = new XmlAttrStack();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Canonicalizer11(boolean includeComments)
/*     */   {
/* 184 */     super(includeComments);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Iterator handleAttributesSubtree(Element E, NameSpaceSymbTable ns)
/*     */     throws CanonicalizationException
/*     */   {
/* 204 */     if ((!E.hasAttributes()) && (!this.firstCall)) {
/* 205 */       return null;
/*     */     }
/*     */     
/* 208 */     SortedSet result = this.result;
/* 209 */     result.clear();
/* 210 */     NamedNodeMap attrs = E.getAttributes();
/* 211 */     int attrsLength = attrs.getLength();
/*     */     
/* 213 */     for (int i = 0; i < attrsLength; i++) {
/* 214 */       Attr N = (Attr)attrs.item(i);
/* 215 */       String NUri = N.getNamespaceURI();
/*     */       
/* 217 */       if ("http://www.w3.org/2000/xmlns/" != NUri)
/*     */       {
/*     */ 
/* 220 */         result.add(N);
/*     */       }
/*     */       else
/*     */       {
/* 224 */         String NName = N.getLocalName();
/* 225 */         String NValue = N.getValue();
/* 226 */         if ((!"xml".equals(NName)) || 
/* 227 */           (!"http://www.w3.org/XML/1998/namespace".equals(NValue)))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 232 */           Node n = ns.addMappingAndRender(NName, NValue, N);
/*     */           
/* 234 */           if (n != null)
/*     */           {
/* 236 */             result.add(n);
/* 237 */             if (C14nHelper.namespaceIsRelative(N)) {
/* 238 */               Object[] exArgs = { E.getTagName(), NName, N.getNodeValue() };
/* 239 */               throw new CanonicalizationException(
/* 240 */                 "c14n.Canonicalizer.RelativeNamespace", exArgs);
/*     */             }
/*     */           }
/*     */         }
/*     */       } }
/* 245 */     if (this.firstCall)
/*     */     {
/*     */ 
/*     */ 
/* 249 */       ns.getUnrenderedNodes(result);
/*     */       
/* 251 */       this.xmlattrStack.getXmlnsAttr(result);
/* 252 */       this.firstCall = false;
/*     */     }
/*     */     
/* 255 */     return result.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Iterator handleAttributes(Element E, NameSpaceSymbTable ns)
/*     */     throws CanonicalizationException
/*     */   {
/* 274 */     this.xmlattrStack.push(ns.getLevel());
/* 275 */     boolean isRealVisible = isVisibleDO(E, ns.getLevel()) == 1;
/* 276 */     NamedNodeMap attrs = null;
/* 277 */     int attrsLength = 0;
/* 278 */     if (E.hasAttributes()) {
/* 279 */       attrs = E.getAttributes();
/* 280 */       attrsLength = attrs.getLength();
/*     */     }
/*     */     
/* 283 */     SortedSet result = this.result;
/* 284 */     result.clear();
/*     */     
/* 286 */     for (int i = 0; i < attrsLength; i++) {
/* 287 */       Attr N = (Attr)attrs.item(i);
/* 288 */       String NUri = N.getNamespaceURI();
/*     */       
/* 290 */       if ("http://www.w3.org/2000/xmlns/" != NUri)
/*     */       {
/* 292 */         if ("http://www.w3.org/XML/1998/namespace" == NUri) {
/* 293 */           if (N.getLocalName().equals("id")) {
/* 294 */             if (isRealVisible)
/*     */             {
/*     */ 
/* 297 */               result.add(N);
/*     */             }
/*     */           } else {
/* 300 */             this.xmlattrStack.addXmlnsAttr(N);
/*     */           }
/* 302 */         } else if (isRealVisible)
/*     */         {
/*     */ 
/* 305 */           result.add(N);
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 311 */         String NName = N.getLocalName();
/* 312 */         String NValue = N.getValue();
/* 313 */         if ((!"xml".equals(NName)) || 
/* 314 */           (!"http://www.w3.org/XML/1998/namespace".equals(NValue)))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 323 */           if (isVisible(N)) {
/* 324 */             if ((isRealVisible) || (!ns.removeMappingIfRender(NName)))
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 330 */               Node n = ns.addMappingAndRender(NName, NValue, N);
/* 331 */               if (n != null) {
/* 332 */                 result.add(n);
/* 333 */                 if (C14nHelper.namespaceIsRelative(N)) {
/* 334 */                   Object[] exArgs = 
/* 335 */                     { E.getTagName(), NName, N.getNodeValue() };
/* 336 */                   throw new CanonicalizationException(
/* 337 */                     "c14n.Canonicalizer.RelativeNamespace", exArgs);
/*     */                 }
/*     */               }
/*     */             }
/* 341 */           } else if ((isRealVisible) && (NName != "xmlns")) {
/* 342 */             ns.removeMapping(NName);
/*     */           } else
/* 344 */             ns.addMapping(NName, NValue, N);
/*     */         }
/*     */       }
/*     */     }
/* 348 */     if (isRealVisible)
/*     */     {
/* 350 */       Attr xmlns = E.getAttributeNodeNS("http://www.w3.org/2000/xmlns/", "xmlns");
/* 351 */       Node n = null;
/* 352 */       if (xmlns == null)
/*     */       {
/* 354 */         n = ns.getMapping("xmlns");
/* 355 */       } else if (!isVisible(xmlns))
/*     */       {
/*     */ 
/* 358 */         n = ns.addMappingAndRender("xmlns", "", nullNode);
/*     */       }
/*     */       
/* 361 */       if (n != null) {
/* 362 */         result.add(n);
/*     */       }
/*     */       
/*     */ 
/* 366 */       this.xmlattrStack.getXmlnsAttr(result);
/* 367 */       ns.getUnrenderedNodes(result);
/*     */     }
/*     */     
/* 370 */     return result.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalizeXPathNodeSet(Set xpathNodeSet, String inclusiveNamespaces)
/*     */     throws CanonicalizationException
/*     */   {
/* 383 */     throw new CanonicalizationException(
/* 384 */       "c14n.Canonicalizer.UnsupportedOperation");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineCanonicalizeSubTree(Node rootNode, String inclusiveNamespaces)
/*     */     throws CanonicalizationException
/*     */   {
/* 397 */     throw new CanonicalizationException(
/* 398 */       "c14n.Canonicalizer.UnsupportedOperation");
/*     */   }
/*     */   
/*     */   void circumventBugIfNeeded(XMLSignatureInput input)
/*     */     throws CanonicalizationException, ParserConfigurationException, IOException, SAXException
/*     */   {
/* 404 */     if (!input.isNeedsToBeExpanded())
/* 405 */       return;
/* 406 */     Document doc = null;
/* 407 */     if (input.getSubNode() != null) {
/* 408 */       doc = XMLUtils.getOwnerDocument(input.getSubNode());
/*     */     } else {
/* 410 */       doc = XMLUtils.getOwnerDocument(input.getNodeSet());
/*     */     }
/* 412 */     XMLUtils.circumventBug2650(doc);
/*     */   }
/*     */   
/*     */   void handleParent(Element e, NameSpaceSymbTable ns) {
/* 416 */     if (!e.hasAttributes()) {
/* 417 */       return;
/*     */     }
/* 419 */     this.xmlattrStack.push(-1);
/* 420 */     NamedNodeMap attrs = e.getAttributes();
/* 421 */     int attrsLength = attrs.getLength();
/* 422 */     for (int i = 0; i < attrsLength; i++) {
/* 423 */       Attr N = (Attr)attrs.item(i);
/* 424 */       if ("http://www.w3.org/2000/xmlns/" != N.getNamespaceURI())
/*     */       {
/* 426 */         if ("http://www.w3.org/XML/1998/namespace" == N.getNamespaceURI()) {
/* 427 */           this.xmlattrStack.addXmlnsAttr(N);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 432 */         String NName = N.getLocalName();
/* 433 */         String NValue = N.getNodeValue();
/* 434 */         if ((!"xml".equals(NName)) || 
/* 435 */           (!"http://www.w3.org/XML/1998/namespace".equals(NValue)))
/*     */         {
/*     */ 
/* 438 */           ns.addMapping(NName, NValue, N); }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static String joinURI(String baseURI, String relativeURI) throws URISyntaxException {
/* 444 */     String bscheme = null;
/* 445 */     String bauthority = null;
/* 446 */     String bpath = "";
/* 447 */     String bquery = null;
/* 448 */     String bfragment = null;
/*     */     
/*     */ 
/* 451 */     if (baseURI != null) {
/* 452 */       if (baseURI.endsWith("..")) {
/* 453 */         baseURI = baseURI + "/";
/*     */       }
/* 455 */       URI base = new URI(baseURI);
/* 456 */       bscheme = base.getScheme();
/* 457 */       bauthority = base.getAuthority();
/* 458 */       bpath = base.getPath();
/* 459 */       bquery = base.getQuery();
/* 460 */       bfragment = base.getFragment();
/*     */     }
/*     */     
/* 463 */     URI r = new URI(relativeURI);
/* 464 */     String rscheme = r.getScheme();
/* 465 */     String rauthority = r.getAuthority();
/* 466 */     String rpath = r.getPath();
/* 467 */     String rquery = r.getQuery();
/* 468 */     String rfragment = null;
/*     */     
/*     */ 
/* 471 */     if ((rscheme != null) && (rscheme.equals(bscheme)))
/* 472 */       rscheme = null;
/*     */     String tquery;
/* 474 */     String tpath; String tquery; String tauthority; String tscheme; if (rscheme != null) {
/* 475 */       String tscheme = rscheme;
/* 476 */       String tauthority = rauthority;
/* 477 */       String tpath = removeDotSegments(rpath);
/* 478 */       tquery = rquery;
/*     */     } else { String tquery;
/* 480 */       if (rauthority != null) {
/* 481 */         String tauthority = rauthority;
/* 482 */         String tpath = removeDotSegments(rpath);
/* 483 */         tquery = rquery;
/*     */       } else { String tquery;
/* 485 */         if (rpath.length() == 0) {
/* 486 */           String tpath = bpath;
/* 487 */           String tquery; if (rquery != null) {
/* 488 */             tquery = rquery;
/*     */           } else
/* 490 */             tquery = bquery;
/*     */         } else {
/*     */           String tpath;
/* 493 */           if (rpath.startsWith("/")) {
/* 494 */             tpath = removeDotSegments(rpath);
/*     */           } else { String tpath;
/* 496 */             if ((bauthority != null) && (bpath.length() == 0)) {
/* 497 */               tpath = "/" + rpath;
/*     */             } else {
/* 499 */               int last = bpath.lastIndexOf('/');
/* 500 */               String tpath; if (last == -1) {
/* 501 */                 tpath = rpath;
/*     */               } else {
/* 503 */                 tpath = bpath.substring(0, last + 1) + rpath;
/*     */               }
/*     */             }
/* 506 */             tpath = removeDotSegments(tpath);
/*     */           }
/* 508 */           tquery = rquery;
/*     */         }
/* 510 */         tauthority = bauthority;
/*     */       }
/* 512 */       tscheme = bscheme;
/*     */     }
/* 514 */     String tfragment = rfragment;
/* 515 */     return new URI(tscheme, tauthority, tpath, tquery, tfragment).toString();
/*     */   }
/*     */   
/*     */   private static String removeDotSegments(String path)
/*     */   {
/* 520 */     log.debug("STEP   OUTPUT BUFFER\t\tINPUT BUFFER");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 525 */     String input = path;
/* 526 */     while (input.indexOf("//") > -1) {
/* 527 */       input = input.replaceAll("//", "/");
/*     */     }
/*     */     
/*     */ 
/* 531 */     StringBuffer output = new StringBuffer();
/*     */     
/*     */ 
/*     */ 
/* 535 */     if (input.charAt(0) == '/') {
/* 536 */       output.append("/");
/* 537 */       input = input.substring(1);
/*     */     }
/*     */     
/* 540 */     printStep("1 ", output.toString(), input);
/*     */     
/*     */ 
/* 543 */     while (input.length() != 0)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 550 */       if (input.startsWith("./")) {
/* 551 */         input = input.substring(2);
/* 552 */         printStep("2A", output.toString(), input);
/* 553 */       } else if (input.startsWith("../")) {
/* 554 */         input = input.substring(3);
/* 555 */         if (!output.toString().equals("/")) {
/* 556 */           output.append("../");
/*     */         }
/* 558 */         printStep("2A", output.toString(), input);
/*     */ 
/*     */ 
/*     */       }
/* 562 */       else if (input.startsWith("/./")) {
/* 563 */         input = input.substring(2);
/* 564 */         printStep("2B", output.toString(), input);
/* 565 */       } else if (input.equals("/."))
/*     */       {
/* 567 */         input = input.replaceFirst("/.", "/");
/* 568 */         printStep("2B", output.toString(), input);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/* 579 */       else if (input.startsWith("/../")) {
/* 580 */         input = input.substring(3);
/* 581 */         if (output.length() == 0) {
/* 582 */           output.append("/");
/* 583 */         } else if (output.toString().endsWith("../")) {
/* 584 */           output.append("..");
/* 585 */         } else if (output.toString().endsWith("..")) {
/* 586 */           output.append("/..");
/*     */         } else {
/* 588 */           int index = output.lastIndexOf("/");
/* 589 */           if (index == -1) {
/* 590 */             output = new StringBuffer();
/* 591 */             if (input.charAt(0) == '/') {
/* 592 */               input = input.substring(1);
/*     */             }
/*     */           } else {
/* 595 */             output = output.delete(index, output.length());
/*     */           }
/*     */         }
/* 598 */         printStep("2C", output.toString(), input);
/* 599 */       } else if (input.equals("/.."))
/*     */       {
/* 601 */         input = input.replaceFirst("/..", "/");
/* 602 */         if (output.length() == 0) {
/* 603 */           output.append("/");
/* 604 */         } else if (output.toString().endsWith("../")) {
/* 605 */           output.append("..");
/* 606 */         } else if (output.toString().endsWith("..")) {
/* 607 */           output.append("/..");
/*     */         } else {
/* 609 */           int index = output.lastIndexOf("/");
/* 610 */           if (index == -1) {
/* 611 */             output = new StringBuffer();
/* 612 */             if (input.charAt(0) == '/') {
/* 613 */               input = input.substring(1);
/*     */             }
/*     */           } else {
/* 616 */             output = output.delete(index, output.length());
/*     */           }
/*     */         }
/* 619 */         printStep("2C", output.toString(), input);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/* 625 */       else if (input.equals(".")) {
/* 626 */         input = "";
/* 627 */         printStep("2D", output.toString(), input);
/* 628 */       } else if (input.equals("..")) {
/* 629 */         if (!output.toString().equals("/"))
/* 630 */           output.append("..");
/* 631 */         input = "";
/* 632 */         printStep("2D", output.toString(), input);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 638 */         int end = -1;
/* 639 */         int begin = input.indexOf('/');
/* 640 */         if (begin == 0) {
/* 641 */           end = input.indexOf('/', 1);
/*     */         } else {
/* 643 */           end = begin;
/* 644 */           begin = 0;
/*     */         }
/*     */         String segment;
/* 647 */         if (end == -1) {
/* 648 */           String segment = input.substring(begin);
/* 649 */           input = "";
/*     */         } else {
/* 651 */           segment = input.substring(begin, end);
/* 652 */           input = input.substring(end);
/*     */         }
/* 654 */         output.append(segment);
/* 655 */         printStep("2E", output.toString(), input);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 663 */     if (output.toString().endsWith("..")) {
/* 664 */       output.append("/");
/* 665 */       printStep("3 ", output.toString(), input);
/*     */     }
/*     */     
/* 668 */     return output.toString();
/*     */   }
/*     */   
/*     */   private static void printStep(String step, String output, String input) {
/* 672 */     if (log.isDebugEnabled()) {
/* 673 */       log.debug(" " + step + ":   " + output);
/* 674 */       if (output.length() == 0) {
/* 675 */         log.debug("\t\t\t\t" + input);
/*     */       } else {
/* 677 */         log.debug("\t\t\t" + input);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\c14n\implementations\Canonicalizer11.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */