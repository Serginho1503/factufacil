/*     */ package adsi.org.apache.xml.security.transforms;
/*     */ 
/*     */ import adsi.org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import adsi.org.apache.xml.security.c14n.InvalidCanonicalizerException;
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureException;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import adsi.org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Transforms
/*     */   extends SignatureElementProxy
/*     */ {
/*  53 */   static Log log = LogFactory.getLog(Transforms.class.getName());
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_C14N_OMIT_COMMENTS = "http://www.w3.org/TR/2001/REC-xml-c14n-20010315";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_C14N_WITH_COMMENTS = "http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_C14N11_OMIT_COMMENTS = "http://www.w3.org/2006/12/xml-c14n11";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_C14N11_WITH_COMMENTS = "http://www.w3.org/2006/12/xml-c14n11#WithComments";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_C14N_EXCL_OMIT_COMMENTS = "http://www.w3.org/2001/10/xml-exc-c14n#";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_C14N_EXCL_WITH_COMMENTS = "http://www.w3.org/2001/10/xml-exc-c14n#WithComments";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_XSLT = "http://www.w3.org/TR/1999/REC-xslt-19991116";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_BASE64_DECODE = "http://www.w3.org/2000/09/xmldsig#base64";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_XPATH = "http://www.w3.org/TR/1999/REC-xpath-19991116";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_ENVELOPED_SIGNATURE = "http://www.w3.org/2000/09/xmldsig#enveloped-signature";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_XPOINTER = "http://www.w3.org/TR/2001/WD-xptr-20010108";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_XPATH2FILTER04 = "http://www.w3.org/2002/04/xmldsig-filter2";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_XPATH2FILTER = "http://www.w3.org/2002/06/xmldsig-filter2";
/*     */   
/*     */ 
/*     */   public static final String TRANSFORM_XPATHFILTERCHGP = "http://www.nue.et-inf.uni-siegen.de/~geuer-pollmann/#xpathFilter";
/*     */   
/*     */ 
/*     */   Element[] transforms;
/*     */   
/*     */ 
/*     */ 
/*     */   protected Transforms() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public Transforms(Document doc)
/*     */   {
/* 108 */     super(doc);
/* 109 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Transforms(Element element, String BaseURI)
/*     */     throws DOMException, XMLSignatureException, InvalidTransformException, TransformationException, XMLSecurityException
/*     */   {
/* 129 */     super(element, BaseURI);
/*     */     
/* 131 */     int numberOfTransformElems = getLength();
/*     */     
/* 133 */     if (numberOfTransformElems == 0)
/*     */     {
/*     */ 
/* 136 */       Object[] exArgs = { "Transform", 
/* 137 */         "Transforms" };
/*     */       
/* 139 */       throw new TransformationException("xml.WrongContent", exArgs);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addTransform(String transformURI)
/*     */     throws TransformationException
/*     */   {
/*     */     try
/*     */     {
/* 155 */       if (log.isDebugEnabled()) {
/* 156 */         log.debug("Transforms.addTransform(" + transformURI + ")");
/*     */       }
/* 158 */       Transform transform = 
/* 159 */         Transform.getInstance(this._doc, transformURI);
/*     */       
/* 161 */       addTransform(transform);
/*     */     } catch (InvalidTransformException ex) {
/* 163 */       throw new TransformationException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addTransform(String transformURI, Element contextElement)
/*     */     throws TransformationException
/*     */   {
/*     */     try
/*     */     {
/* 181 */       if (log.isDebugEnabled()) {
/* 182 */         log.debug("Transforms.addTransform(" + transformURI + ")");
/*     */       }
/* 184 */       Transform transform = 
/* 185 */         Transform.getInstance(this._doc, transformURI, contextElement);
/*     */       
/* 187 */       addTransform(transform);
/*     */     } catch (InvalidTransformException ex) {
/* 189 */       throw new TransformationException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addTransform(String transformURI, NodeList contextNodes)
/*     */     throws TransformationException
/*     */   {
/*     */     try
/*     */     {
/* 207 */       Transform transform = 
/* 208 */         Transform.getInstance(this._doc, transformURI, contextNodes);
/* 209 */       addTransform(transform);
/*     */     } catch (InvalidTransformException ex) {
/* 211 */       throw new TransformationException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addTransform(Transform transform)
/*     */   {
/* 221 */     if (log.isDebugEnabled()) {
/* 222 */       log.debug("Transforms.addTransform(" + transform.getURI() + ")");
/*     */     }
/* 224 */     Element transformElement = transform.getElement();
/*     */     
/* 226 */     this._constructionElement.appendChild(transformElement);
/* 227 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput performTransforms(XMLSignatureInput xmlSignatureInput)
/*     */     throws TransformationException
/*     */   {
/* 240 */     return performTransforms(xmlSignatureInput, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput performTransforms(XMLSignatureInput xmlSignatureInput, OutputStream os)
/*     */     throws TransformationException
/*     */   {
/*     */     try
/*     */     {
/* 257 */       int last = getLength() - 1;
/* 258 */       for (int i = 0; i < last; i++) {
/* 259 */         Transform t = item(i);
/* 260 */         if (log.isDebugEnabled()) {
/* 261 */           log.debug("Perform the (" + i + ")th " + t.getURI() + 
/* 262 */             " transform");
/*     */         }
/* 264 */         xmlSignatureInput = t.performTransform(xmlSignatureInput); }
/*     */       Transform t;
/* 266 */       if (last >= 0)
/* 267 */         t = item(last);
/* 268 */       return t.performTransform(xmlSignatureInput, os);
/*     */ 
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 273 */       throw new TransformationException("empty", ex);
/*     */     } catch (CanonicalizationException ex) {
/* 275 */       throw new TransformationException("empty", ex);
/*     */     } catch (InvalidCanonicalizerException ex) {
/* 277 */       throw new TransformationException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLength()
/*     */   {
/* 288 */     if (this.transforms == null) {
/* 289 */       this.transforms = XMLUtils.selectDsNodes(
/* 290 */         this._constructionElement.getFirstChild(), "Transform");
/*     */     }
/* 292 */     return this.transforms.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Transform item(int i)
/*     */     throws TransformationException
/*     */   {
/*     */     try
/*     */     {
/* 306 */       if (this.transforms == null) {
/* 307 */         this.transforms = XMLUtils.selectDsNodes(
/* 308 */           this._constructionElement.getFirstChild(), "Transform");
/*     */       }
/* 310 */       return new Transform(this.transforms[i], this._baseURI);
/*     */     } catch (XMLSecurityException ex) {
/* 312 */       throw new TransformationException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 318 */     return "Transforms";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\transforms\Transforms.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */