/*      */ package adsi.org.apache.xml.security.keys;
/*      */ 
/*      */ import adsi.org.apache.xml.security.encryption.EncryptedKey;
/*      */ import adsi.org.apache.xml.security.encryption.XMLCipher;
/*      */ import adsi.org.apache.xml.security.encryption.XMLEncryptionException;
/*      */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*      */ import adsi.org.apache.xml.security.keys.content.KeyName;
/*      */ import adsi.org.apache.xml.security.keys.content.KeyValue;
/*      */ import adsi.org.apache.xml.security.keys.content.MgmtData;
/*      */ import adsi.org.apache.xml.security.keys.content.PGPData;
/*      */ import adsi.org.apache.xml.security.keys.content.RetrievalMethod;
/*      */ import adsi.org.apache.xml.security.keys.content.SPKIData;
/*      */ import adsi.org.apache.xml.security.keys.content.X509Data;
/*      */ import adsi.org.apache.xml.security.keys.content.keyvalues.DSAKeyValue;
/*      */ import adsi.org.apache.xml.security.keys.content.keyvalues.RSAKeyValue;
/*      */ import adsi.org.apache.xml.security.keys.keyresolver.KeyResolver;
/*      */ import adsi.org.apache.xml.security.keys.keyresolver.KeyResolverException;
/*      */ import adsi.org.apache.xml.security.keys.keyresolver.KeyResolverSpi;
/*      */ import adsi.org.apache.xml.security.keys.storage.StorageResolver;
/*      */ import adsi.org.apache.xml.security.transforms.Transforms;
/*      */ import adsi.org.apache.xml.security.utils.IdResolver;
/*      */ import adsi.org.apache.xml.security.utils.SignatureElementProxy;
/*      */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*      */ import java.security.PublicKey;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import javax.crypto.SecretKey;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class KeyInfo
/*      */   extends SignatureElementProxy
/*      */ {
/*   96 */   static Log log = LogFactory.getLog(KeyInfo.class.getName());
/*   97 */   List x509Datas = null;
/*   98 */   List encryptedKeys = null;
/*      */   static final List nullList;
/*      */   
/*      */   static {
/*  102 */     List list = new ArrayList();
/*  103 */     list.add(null);
/*  104 */     nullList = Collections.unmodifiableList(list);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public KeyInfo(Document doc)
/*      */   {
/*  113 */     super(doc);
/*      */     
/*  115 */     XMLUtils.addReturnToElement(this._constructionElement);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public KeyInfo(Element element, String BaseURI)
/*      */     throws XMLSecurityException
/*      */   {
/*  127 */     super(element, BaseURI);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setId(String Id)
/*      */   {
/*  139 */     if (Id != null) {
/*  140 */       this._constructionElement.setAttributeNS(null, "Id", Id);
/*  141 */       IdResolver.registerElementById(this._constructionElement, Id);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getId()
/*      */   {
/*  151 */     return this._constructionElement.getAttributeNS(null, "Id");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addKeyName(String keynameString)
/*      */   {
/*  160 */     add(new KeyName(this._doc, keynameString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(KeyName keyname)
/*      */   {
/*  170 */     this._constructionElement.appendChild(keyname.getElement());
/*  171 */     XMLUtils.addReturnToElement(this._constructionElement);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addKeyValue(PublicKey pk)
/*      */   {
/*  180 */     add(new KeyValue(this._doc, pk));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addKeyValue(Element unknownKeyValueElement)
/*      */   {
/*  189 */     add(new KeyValue(this._doc, unknownKeyValueElement));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(DSAKeyValue dsakeyvalue)
/*      */   {
/*  198 */     add(new KeyValue(this._doc, dsakeyvalue));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(RSAKeyValue rsakeyvalue)
/*      */   {
/*  207 */     add(new KeyValue(this._doc, rsakeyvalue));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(PublicKey pk)
/*      */   {
/*  216 */     add(new KeyValue(this._doc, pk));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(KeyValue keyvalue)
/*      */   {
/*  225 */     this._constructionElement.appendChild(keyvalue.getElement());
/*  226 */     XMLUtils.addReturnToElement(this._constructionElement);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addMgmtData(String mgmtdata)
/*      */   {
/*  235 */     add(new MgmtData(this._doc, mgmtdata));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(MgmtData mgmtdata)
/*      */   {
/*  244 */     this._constructionElement.appendChild(mgmtdata.getElement());
/*  245 */     XMLUtils.addReturnToElement(this._constructionElement);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(PGPData pgpdata)
/*      */   {
/*  254 */     this._constructionElement.appendChild(pgpdata.getElement());
/*  255 */     XMLUtils.addReturnToElement(this._constructionElement);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addRetrievalMethod(String URI, Transforms transforms, String Type)
/*      */   {
/*  267 */     add(new RetrievalMethod(this._doc, URI, transforms, Type));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(RetrievalMethod retrievalmethod)
/*      */   {
/*  276 */     this._constructionElement.appendChild(retrievalmethod.getElement());
/*  277 */     XMLUtils.addReturnToElement(this._constructionElement);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(SPKIData spkidata)
/*      */   {
/*  286 */     this._constructionElement.appendChild(spkidata.getElement());
/*  287 */     XMLUtils.addReturnToElement(this._constructionElement);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(X509Data x509data)
/*      */   {
/*  296 */     if (this.x509Datas == null)
/*  297 */       this.x509Datas = new ArrayList();
/*  298 */     this.x509Datas.add(x509data);
/*  299 */     this._constructionElement.appendChild(x509data.getElement());
/*  300 */     XMLUtils.addReturnToElement(this._constructionElement);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(EncryptedKey encryptedKey)
/*      */     throws XMLEncryptionException
/*      */   {
/*  312 */     if (this.encryptedKeys == null)
/*  313 */       this.encryptedKeys = new ArrayList();
/*  314 */     this.encryptedKeys.add(encryptedKey);
/*  315 */     XMLCipher cipher = XMLCipher.getInstance();
/*  316 */     this._constructionElement.appendChild(cipher.martial(encryptedKey));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addUnknownElement(Element element)
/*      */   {
/*  325 */     this._constructionElement.appendChild(element);
/*  326 */     XMLUtils.addReturnToElement(this._constructionElement);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int lengthKeyName()
/*      */   {
/*  335 */     return length("http://www.w3.org/2000/09/xmldsig#", "KeyName");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int lengthKeyValue()
/*      */   {
/*  344 */     return length("http://www.w3.org/2000/09/xmldsig#", "KeyValue");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int lengthMgmtData()
/*      */   {
/*  353 */     return length("http://www.w3.org/2000/09/xmldsig#", "MgmtData");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int lengthPGPData()
/*      */   {
/*  362 */     return length("http://www.w3.org/2000/09/xmldsig#", "PGPData");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int lengthRetrievalMethod()
/*      */   {
/*  371 */     return length("http://www.w3.org/2000/09/xmldsig#", 
/*  372 */       "RetrievalMethod");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int lengthSPKIData()
/*      */   {
/*  381 */     return length("http://www.w3.org/2000/09/xmldsig#", "SPKIData");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int lengthX509Data()
/*      */   {
/*  390 */     if (this.x509Datas != null) {
/*  391 */       return this.x509Datas.size();
/*      */     }
/*  393 */     return length("http://www.w3.org/2000/09/xmldsig#", "X509Data");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int lengthUnknownElement()
/*      */   {
/*  403 */     int res = 0;
/*  404 */     NodeList nl = this._constructionElement.getChildNodes();
/*      */     
/*  406 */     for (int i = 0; i < nl.getLength(); i++) {
/*  407 */       Node current = nl.item(i);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  413 */       if (current.getNodeType() == 1)
/*      */       {
/*  415 */         if (current.getNamespaceURI().equals("http://www.w3.org/2000/09/xmldsig#")) {
/*  416 */           res++;
/*      */         }
/*      */       }
/*      */     }
/*  420 */     return res;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public KeyName itemKeyName(int i)
/*      */     throws XMLSecurityException
/*      */   {
/*  432 */     Element e = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), 
/*  433 */       "KeyName", i);
/*      */     
/*  435 */     if (e != null) {
/*  436 */       return new KeyName(e, this._baseURI);
/*      */     }
/*  438 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public KeyValue itemKeyValue(int i)
/*      */     throws XMLSecurityException
/*      */   {
/*  450 */     Element e = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), 
/*  451 */       "KeyValue", i);
/*      */     
/*  453 */     if (e != null) {
/*  454 */       return new KeyValue(e, this._baseURI);
/*      */     }
/*  456 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MgmtData itemMgmtData(int i)
/*      */     throws XMLSecurityException
/*      */   {
/*  468 */     Element e = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), 
/*  469 */       "MgmtData", i);
/*      */     
/*  471 */     if (e != null) {
/*  472 */       return new MgmtData(e, this._baseURI);
/*      */     }
/*  474 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PGPData itemPGPData(int i)
/*      */     throws XMLSecurityException
/*      */   {
/*  486 */     Element e = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), 
/*  487 */       "PGPData", i);
/*      */     
/*  489 */     if (e != null) {
/*  490 */       return new PGPData(e, this._baseURI);
/*      */     }
/*  492 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public RetrievalMethod itemRetrievalMethod(int i)
/*      */     throws XMLSecurityException
/*      */   {
/*  505 */     Element e = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), 
/*  506 */       "RetrievalMethod", i);
/*      */     
/*  508 */     if (e != null) {
/*  509 */       return new RetrievalMethod(e, this._baseURI);
/*      */     }
/*  511 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SPKIData itemSPKIData(int i)
/*      */     throws XMLSecurityException
/*      */   {
/*  523 */     Element e = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), 
/*  524 */       "SPKIData", i);
/*      */     
/*  526 */     if (e != null) {
/*  527 */       return new SPKIData(e, this._baseURI);
/*      */     }
/*  529 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public X509Data itemX509Data(int i)
/*      */     throws XMLSecurityException
/*      */   {
/*  540 */     if (this.x509Datas != null) {
/*  541 */       return (X509Data)this.x509Datas.get(i);
/*      */     }
/*  543 */     Element e = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), 
/*  544 */       "X509Data", i);
/*      */     
/*  546 */     if (e != null) {
/*  547 */       return new X509Data(e, this._baseURI);
/*      */     }
/*  549 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EncryptedKey itemEncryptedKey(int i)
/*      */     throws XMLSecurityException
/*      */   {
/*  561 */     if (this.encryptedKeys != null) {
/*  562 */       return (EncryptedKey)this.encryptedKeys.get(i);
/*      */     }
/*  564 */     Element e = 
/*  565 */       XMLUtils.selectXencNode(this._constructionElement.getFirstChild(), 
/*  566 */       "EncryptedKey", i);
/*      */     
/*  568 */     if (e != null) {
/*  569 */       XMLCipher cipher = XMLCipher.getInstance();
/*  570 */       cipher.init(4, null);
/*  571 */       return cipher.loadEncryptedKey(e);
/*      */     }
/*  573 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Element itemUnknownElement(int i)
/*      */   {
/*  584 */     NodeList nl = this._constructionElement.getChildNodes();
/*  585 */     int res = 0;
/*      */     
/*  587 */     for (int j = 0; j < nl.getLength(); j++) {
/*  588 */       Node current = nl.item(j);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  594 */       if (current.getNodeType() == 1)
/*      */       {
/*  596 */         if (current.getNamespaceURI().equals("http://www.w3.org/2000/09/xmldsig#")) {
/*  597 */           res++;
/*      */           
/*  599 */           if (res == i) {
/*  600 */             return (Element)current;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  605 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isEmpty()
/*      */   {
/*  614 */     return this._constructionElement.getFirstChild() == null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean containsKeyName()
/*      */   {
/*  623 */     return lengthKeyName() > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean containsKeyValue()
/*      */   {
/*  632 */     return lengthKeyValue() > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean containsMgmtData()
/*      */   {
/*  641 */     return lengthMgmtData() > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean containsPGPData()
/*      */   {
/*  650 */     return lengthPGPData() > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean containsRetrievalMethod()
/*      */   {
/*  659 */     return lengthRetrievalMethod() > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean containsSPKIData()
/*      */   {
/*  668 */     return lengthSPKIData() > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean containsUnknownElement()
/*      */   {
/*  677 */     return lengthUnknownElement() > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean containsX509Data()
/*      */   {
/*  686 */     return lengthX509Data() > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PublicKey getPublicKey()
/*      */     throws KeyResolverException
/*      */   {
/*  698 */     PublicKey pk = getPublicKeyFromInternalResolvers();
/*      */     
/*  700 */     if (pk != null) {
/*  701 */       log.debug("I could find a key using the per-KeyInfo key resolvers");
/*      */       
/*  703 */       return pk;
/*      */     }
/*  705 */     log.debug("I couldn't find a key using the per-KeyInfo key resolvers");
/*      */     
/*  707 */     pk = getPublicKeyFromStaticResolvers();
/*      */     
/*  709 */     if (pk != null) {
/*  710 */       log.debug("I could find a key using the system-wide key resolvers");
/*      */       
/*  712 */       return pk;
/*      */     }
/*  714 */     log.debug("I couldn't find a key using the system-wide key resolvers");
/*      */     
/*  716 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   PublicKey getPublicKeyFromStaticResolvers()
/*      */     throws KeyResolverException
/*      */   {
/*  726 */     int length = KeyResolver.length();
/*  727 */     int storageLength = this._storageResolvers.size();
/*  728 */     Iterator it = KeyResolver.iterator();
/*  729 */     for (int i = 0; i < length; i++) {
/*  730 */       KeyResolverSpi keyResolver = (KeyResolverSpi)it.next();
/*  731 */       Node currentChild = this._constructionElement.getFirstChild();
/*  732 */       String uri = getBaseURI();
/*  733 */       while (currentChild != null) {
/*  734 */         if (currentChild.getNodeType() == 1) {
/*  735 */           for (int k = 0; k < storageLength; k++) {
/*  736 */             StorageResolver storage = 
/*  737 */               (StorageResolver)this._storageResolvers.get(k);
/*      */             
/*  739 */             PublicKey pk = 
/*  740 */               keyResolver.engineLookupAndResolvePublicKey((Element)currentChild, 
/*  741 */               uri, 
/*  742 */               storage);
/*      */             
/*  744 */             if (pk != null) {
/*  745 */               KeyResolver.hit(it);
/*  746 */               return pk;
/*      */             }
/*      */           }
/*      */         }
/*  750 */         currentChild = currentChild.getNextSibling();
/*      */       }
/*      */     }
/*  753 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   PublicKey getPublicKeyFromInternalResolvers()
/*      */     throws KeyResolverException
/*      */   {
/*  763 */     int length = lengthInternalKeyResolver();
/*  764 */     int storageLength = this._storageResolvers.size();
/*  765 */     for (int i = 0; i < length; i++) {
/*  766 */       KeyResolverSpi keyResolver = itemInternalKeyResolver(i);
/*  767 */       if (log.isDebugEnabled()) {
/*  768 */         log.debug("Try " + keyResolver.getClass().getName());
/*      */       }
/*  770 */       Node currentChild = this._constructionElement.getFirstChild();
/*  771 */       String uri = getBaseURI();
/*  772 */       while (currentChild != null) {
/*  773 */         if (currentChild.getNodeType() == 1) {
/*  774 */           for (int k = 0; k < storageLength; k++) {
/*  775 */             StorageResolver storage = 
/*  776 */               (StorageResolver)this._storageResolvers.get(k);
/*  777 */             PublicKey pk = keyResolver
/*  778 */               .engineLookupAndResolvePublicKey((Element)currentChild, uri, storage);
/*      */             
/*  780 */             if (pk != null) {
/*  781 */               return pk;
/*      */             }
/*      */           }
/*      */         }
/*  785 */         currentChild = currentChild.getNextSibling();
/*      */       }
/*      */     }
/*      */     
/*  789 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public X509Certificate getX509Certificate()
/*      */     throws KeyResolverException
/*      */   {
/*  801 */     X509Certificate cert = getX509CertificateFromInternalResolvers();
/*      */     
/*  803 */     if (cert != null) {
/*  804 */       log.debug(
/*  805 */         "I could find a X509Certificate using the per-KeyInfo key resolvers");
/*      */       
/*  807 */       return cert;
/*      */     }
/*  809 */     log.debug(
/*  810 */       "I couldn't find a X509Certificate using the per-KeyInfo key resolvers");
/*      */     
/*      */ 
/*      */ 
/*  814 */     cert = getX509CertificateFromStaticResolvers();
/*      */     
/*  816 */     if (cert != null) {
/*  817 */       log.debug(
/*  818 */         "I could find a X509Certificate using the system-wide key resolvers");
/*      */       
/*  820 */       return cert;
/*      */     }
/*  822 */     log.debug(
/*  823 */       "I couldn't find a X509Certificate using the system-wide key resolvers");
/*      */     
/*      */ 
/*  826 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   X509Certificate getX509CertificateFromStaticResolvers()
/*      */     throws KeyResolverException
/*      */   {
/*  839 */     if (log.isDebugEnabled())
/*  840 */       log.debug("Start getX509CertificateFromStaticResolvers() with " + 
/*  841 */         KeyResolver.length() + " resolvers");
/*  842 */     String uri = getBaseURI();
/*  843 */     int length = KeyResolver.length();
/*  844 */     int storageLength = this._storageResolvers.size();
/*  845 */     Iterator it = KeyResolver.iterator();
/*  846 */     for (int i = 0; i < length; i++) {
/*  847 */       KeyResolverSpi keyResolver = (KeyResolverSpi)it.next();
/*  848 */       X509Certificate cert = applyCurrentResolver(uri, storageLength, keyResolver);
/*  849 */       if (cert != null) {
/*  850 */         KeyResolver.hit(it);
/*  851 */         return cert;
/*      */       }
/*      */     }
/*  854 */     return null;
/*      */   }
/*      */   
/*      */   private X509Certificate applyCurrentResolver(String uri, int storageLength, KeyResolverSpi keyResolver) throws KeyResolverException {
/*  858 */     Node currentChild = this._constructionElement.getFirstChild();
/*  859 */     while (currentChild != null) {
/*  860 */       if (currentChild.getNodeType() == 1) {
/*  861 */         for (int k = 0; k < storageLength; k++) {
/*  862 */           StorageResolver storage = 
/*  863 */             (StorageResolver)this._storageResolvers.get(k);
/*      */           
/*  865 */           X509Certificate cert = keyResolver
/*  866 */             .engineLookupResolveX509Certificate((Element)currentChild, uri, 
/*  867 */             storage);
/*      */           
/*  869 */           if (cert != null) {
/*  870 */             return cert;
/*      */           }
/*      */         }
/*      */       }
/*  874 */       currentChild = currentChild.getNextSibling();
/*      */     }
/*  876 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   X509Certificate getX509CertificateFromInternalResolvers()
/*      */     throws KeyResolverException
/*      */   {
/*  887 */     if (log.isDebugEnabled())
/*  888 */       log.debug("Start getX509CertificateFromInternalResolvers() with " + 
/*  889 */         lengthInternalKeyResolver() + " resolvers");
/*  890 */     String uri = getBaseURI();
/*  891 */     int storageLength = this._storageResolvers.size();
/*  892 */     for (int i = 0; i < lengthInternalKeyResolver(); i++) {
/*  893 */       KeyResolverSpi keyResolver = itemInternalKeyResolver(i);
/*  894 */       if (log.isDebugEnabled())
/*  895 */         log.debug("Try " + keyResolver.getClass().getName());
/*  896 */       X509Certificate cert = applyCurrentResolver(uri, storageLength, keyResolver);
/*  897 */       if (cert != null) {
/*  898 */         return cert;
/*      */       }
/*      */     }
/*      */     
/*  902 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public SecretKey getSecretKey()
/*      */     throws KeyResolverException
/*      */   {
/*  911 */     SecretKey sk = getSecretKeyFromInternalResolvers();
/*      */     
/*  913 */     if (sk != null) {
/*  914 */       log.debug("I could find a secret key using the per-KeyInfo key resolvers");
/*      */       
/*  916 */       return sk;
/*      */     }
/*  918 */     log.debug("I couldn't find a secret key using the per-KeyInfo key resolvers");
/*      */     
/*      */ 
/*  921 */     sk = getSecretKeyFromStaticResolvers();
/*      */     
/*  923 */     if (sk != null) {
/*  924 */       log.debug("I could find a secret key using the system-wide key resolvers");
/*      */       
/*  926 */       return sk;
/*      */     }
/*  928 */     log.debug("I couldn't find a secret key using the system-wide key resolvers");
/*      */     
/*      */ 
/*  931 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   SecretKey getSecretKeyFromStaticResolvers()
/*      */     throws KeyResolverException
/*      */   {
/*  942 */     int length = KeyResolver.length();
/*  943 */     int storageLength = this._storageResolvers.size();
/*  944 */     Iterator it = KeyResolver.iterator();
/*  945 */     for (int i = 0; i < length; i++) {
/*  946 */       KeyResolverSpi keyResolver = (KeyResolverSpi)it.next();
/*      */       
/*  948 */       Node currentChild = this._constructionElement.getFirstChild();
/*  949 */       String uri = getBaseURI();
/*  950 */       while (currentChild != null) {
/*  951 */         if (currentChild.getNodeType() == 1) {
/*  952 */           for (int k = 0; k < storageLength; k++) {
/*  953 */             StorageResolver storage = 
/*  954 */               (StorageResolver)this._storageResolvers.get(k);
/*      */             
/*  956 */             SecretKey sk = 
/*  957 */               keyResolver.engineLookupAndResolveSecretKey((Element)currentChild, 
/*  958 */               uri, 
/*  959 */               storage);
/*      */             
/*  961 */             if (sk != null) {
/*  962 */               return sk;
/*      */             }
/*      */           }
/*      */         }
/*  966 */         currentChild = currentChild.getNextSibling();
/*      */       }
/*      */     }
/*  969 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   SecretKey getSecretKeyFromInternalResolvers()
/*      */     throws KeyResolverException
/*      */   {
/*  980 */     int storageLength = this._storageResolvers.size();
/*  981 */     for (int i = 0; i < lengthInternalKeyResolver(); i++) {
/*  982 */       KeyResolverSpi keyResolver = itemInternalKeyResolver(i);
/*  983 */       if (log.isDebugEnabled()) {
/*  984 */         log.debug("Try " + keyResolver.getClass().getName());
/*      */       }
/*  986 */       Node currentChild = this._constructionElement.getFirstChild();
/*  987 */       String uri = getBaseURI();
/*  988 */       while (currentChild != null) {
/*  989 */         if (currentChild.getNodeType() == 1) {
/*  990 */           for (int k = 0; k < storageLength; k++) {
/*  991 */             StorageResolver storage = 
/*  992 */               (StorageResolver)this._storageResolvers.get(k);
/*      */             
/*  994 */             SecretKey sk = keyResolver
/*  995 */               .engineLookupAndResolveSecretKey((Element)currentChild, uri, storage);
/*      */             
/*  997 */             if (sk != null) {
/*  998 */               return sk;
/*      */             }
/*      */           }
/*      */         }
/* 1002 */         currentChild = currentChild.getNextSibling();
/*      */       }
/*      */     }
/*      */     
/* 1006 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1012 */   List _internalKeyResolvers = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerInternalKeyResolver(KeyResolverSpi realKeyResolver)
/*      */   {
/* 1021 */     if (this._internalKeyResolvers == null) {
/* 1022 */       this._internalKeyResolvers = new ArrayList();
/*      */     }
/* 1024 */     this._internalKeyResolvers.add(realKeyResolver);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   int lengthInternalKeyResolver()
/*      */   {
/* 1032 */     if (this._internalKeyResolvers == null)
/* 1033 */       return 0;
/* 1034 */     return this._internalKeyResolvers.size();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   KeyResolverSpi itemInternalKeyResolver(int i)
/*      */   {
/* 1044 */     return (KeyResolverSpi)this._internalKeyResolvers.get(i);
/*      */   }
/*      */   
/*      */ 
/* 1048 */   List _storageResolvers = nullList;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addStorageResolver(StorageResolver storageResolver)
/*      */   {
/* 1056 */     if (this._storageResolvers == nullList) {
/* 1057 */       this._storageResolvers = new ArrayList();
/*      */     }
/* 1059 */     this._storageResolvers.add(storageResolver);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 1064 */   static boolean _alreadyInitialized = false;
/*      */   
/*      */   public static void init()
/*      */   {
/* 1068 */     if (!_alreadyInitialized) {
/* 1069 */       if (log == null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1075 */         log = 
/* 1076 */           LogFactory.getLog(KeyInfo.class.getName());
/*      */         
/* 1078 */         log.error("Had to assign log in the init() function");
/*      */       }
/*      */       
/*      */ 
/* 1082 */       _alreadyInitialized = true;
/*      */     }
/*      */   }
/*      */   
/*      */   public String getBaseLocalName()
/*      */   {
/* 1088 */     return "KeyInfo";
/*      */   }
/*      */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\KeyInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */