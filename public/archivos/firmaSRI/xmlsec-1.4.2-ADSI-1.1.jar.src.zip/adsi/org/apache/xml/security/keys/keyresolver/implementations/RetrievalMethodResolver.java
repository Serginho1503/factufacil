/*     */ package adsi.org.apache.xml.security.keys.keyresolver.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.keys.content.RetrievalMethod;
/*     */ import adsi.org.apache.xml.security.keys.keyresolver.KeyResolver;
/*     */ import adsi.org.apache.xml.security.keys.keyresolver.KeyResolverException;
/*     */ import adsi.org.apache.xml.security.keys.keyresolver.KeyResolverSpi;
/*     */ import adsi.org.apache.xml.security.keys.storage.StorageResolver;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import adsi.org.apache.xml.security.transforms.Transforms;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolver;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Set;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RetrievalMethodResolver
/*     */   extends KeyResolverSpi
/*     */ {
/*  70 */   static Log log = LogFactory.getLog(
/*  71 */     RetrievalMethodResolver.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PublicKey engineLookupAndResolvePublicKey(Element element, String BaseURI, StorageResolver storage)
/*     */   {
/*  84 */     if (!XMLUtils.elementIsInSignatureSpace(element, 
/*  85 */       "RetrievalMethod")) {
/*  86 */       return null;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/*  91 */       RetrievalMethod rm = new RetrievalMethod(element, BaseURI);
/*  92 */       String type = rm.getType();
/*  93 */       XMLSignatureInput resource = resolveInput(rm, BaseURI);
/*  94 */       if ("http://www.w3.org/2000/09/xmldsig#rawX509Certificate".equals(type))
/*     */       {
/*  96 */         X509Certificate cert = getRawCertificate(resource);
/*  97 */         if (cert != null) {
/*  98 */           return cert.getPublicKey();
/*     */         }
/* 100 */         return null;
/*     */       }
/* 102 */       Element e = obtainRefrenceElement(resource);
/* 103 */       return resolveKey(e, BaseURI, storage);
/*     */     } catch (XMLSecurityException ex) {
/* 105 */       log.debug("XMLSecurityException", ex);
/*     */     } catch (CertificateException ex) {
/* 107 */       log.debug("CertificateException", ex);
/*     */     } catch (IOException ex) {
/* 109 */       log.debug("IOException", ex);
/*     */     } catch (ParserConfigurationException e) {
/* 111 */       log.debug("ParserConfigurationException", e);
/*     */     } catch (SAXException e) {
/* 113 */       log.debug("SAXException", e);
/*     */     }
/* 115 */     return null;
/*     */   }
/*     */   
/*     */   private static Element obtainRefrenceElement(XMLSignatureInput resource) throws CanonicalizationException, ParserConfigurationException, IOException, SAXException, KeyResolverException { Element e;
/*     */     Element e;
/* 120 */     if (resource.isElement()) {
/* 121 */       e = (Element)resource.getSubNode(); } else { Element e;
/* 122 */       if (resource.isNodeSet())
/*     */       {
/* 124 */         e = getDocumentElement(resource.getNodeSet());
/*     */       }
/*     */       else {
/* 127 */         byte[] inputBytes = resource.getBytes();
/* 128 */         e = getDocFromBytes(inputBytes);
/*     */         
/* 130 */         if (log.isDebugEnabled())
/* 131 */           log.debug("we have to parse " + inputBytes.length + " bytes");
/*     */       } }
/* 133 */     return e;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Certificate engineLookupResolveX509Certificate(Element element, String BaseURI, StorageResolver storage)
/*     */   {
/* 147 */     if (!XMLUtils.elementIsInSignatureSpace(element, 
/* 148 */       "RetrievalMethod")) {
/* 149 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 153 */       RetrievalMethod rm = new RetrievalMethod(element, BaseURI);
/* 154 */       String type = rm.getType();
/* 155 */       XMLSignatureInput resource = resolveInput(rm, BaseURI);
/* 156 */       if ("http://www.w3.org/2000/09/xmldsig#rawX509Certificate".equals(type)) {
/* 157 */         return getRawCertificate(resource);
/*     */       }
/*     */       
/* 160 */       Element e = obtainRefrenceElement(resource);
/* 161 */       return resolveCertificate(e, BaseURI, storage);
/*     */     } catch (XMLSecurityException ex) {
/* 163 */       log.debug("XMLSecurityException", ex);
/*     */     } catch (CertificateException ex) {
/* 165 */       log.debug("CertificateException", ex);
/*     */     } catch (IOException ex) {
/* 167 */       log.debug("IOException", ex);
/*     */     } catch (ParserConfigurationException e) {
/* 169 */       log.debug("ParserConfigurationException", e);
/*     */     } catch (SAXException e) {
/* 171 */       log.debug("SAXException", e);
/*     */     }
/* 173 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static X509Certificate resolveCertificate(Element e, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/* 185 */     if (log.isDebugEnabled()) {
/* 186 */       log.debug("Now we have a {" + e.getNamespaceURI() + "}" + e.getLocalName() + " Element");
/*     */     }
/* 188 */     if (e != null) {
/* 189 */       return KeyResolver.getX509Certificate(e, BaseURI, storage);
/*     */     }
/* 191 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static PublicKey resolveKey(Element e, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/* 203 */     if (log.isDebugEnabled()) {
/* 204 */       log.debug("Now we have a {" + e.getNamespaceURI() + "}" + e.getLocalName() + " Element");
/*     */     }
/* 206 */     if (e != null) {
/* 207 */       return KeyResolver.getPublicKey(e, BaseURI, storage);
/*     */     }
/* 209 */     return null;
/*     */   }
/*     */   
/*     */   private static X509Certificate getRawCertificate(XMLSignatureInput resource) throws CanonicalizationException, IOException, CertificateException {
/* 213 */     byte[] inputBytes = resource.getBytes();
/*     */     
/* 215 */     CertificateFactory certFact = CertificateFactory.getInstance("X.509");
/* 216 */     X509Certificate cert = (X509Certificate)certFact.generateCertificate(new ByteArrayInputStream(inputBytes));
/* 217 */     return cert;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static XMLSignatureInput resolveInput(RetrievalMethod rm, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 225 */     Attr uri = rm.getURIAttr();
/*     */     
/* 227 */     Transforms transforms = rm.getTransforms();
/* 228 */     ResourceResolver resRes = ResourceResolver.getInstance(uri, BaseURI);
/* 229 */     if (resRes != null) {
/* 230 */       XMLSignatureInput resource = resRes.resolve(uri, BaseURI);
/* 231 */       if (transforms != null) {
/* 232 */         log.debug("We have Transforms");
/* 233 */         resource = transforms.performTransforms(resource);
/*     */       }
/* 235 */       return resource;
/*     */     }
/* 237 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Element getDocFromBytes(byte[] bytes)
/*     */     throws KeyResolverException
/*     */   {
/*     */     try
/*     */     {
/* 249 */       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 250 */       dbf.setNamespaceAware(true);
/* 251 */       DocumentBuilder db = dbf.newDocumentBuilder();
/* 252 */       Document doc = 
/* 253 */         db.parse(new ByteArrayInputStream(bytes));
/* 254 */       return doc.getDocumentElement();
/*     */     } catch (SAXException ex) {
/* 256 */       throw new KeyResolverException("empty", ex);
/*     */     } catch (IOException ex) {
/* 258 */       throw new KeyResolverException("empty", ex);
/*     */     } catch (ParserConfigurationException ex) {
/* 260 */       throw new KeyResolverException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SecretKey engineLookupAndResolveSecretKey(Element element, String BaseURI, StorageResolver storage)
/*     */   {
/* 275 */     return null;
/*     */   }
/*     */   
/*     */   static Element getDocumentElement(Set set) {
/* 279 */     Iterator it = set.iterator();
/* 280 */     Element e = null;
/* 281 */     while (it.hasNext()) {
/* 282 */       Node currentNode = (Node)it.next();
/* 283 */       if ((currentNode instanceof Element)) {
/* 284 */         e = (Element)currentNode;
/* 285 */         break;
/*     */       }
/*     */     }
/*     */     
/* 289 */     List parents = new ArrayList(10);
/*     */     
/*     */     do
/*     */     {
/* 293 */       parents.add(e);
/* 294 */       Node n = e.getParentNode();
/* 295 */       if (!(n instanceof Element)) {
/*     */         break;
/*     */       }
/* 298 */       e = (Element)n;
/* 299 */     } while (e != null);
/*     */     
/* 301 */     ListIterator it2 = parents.listIterator(parents.size() - 1);
/* 302 */     Element ele = null;
/* 303 */     while (it2.hasPrevious()) {
/* 304 */       ele = (Element)it2.previous();
/* 305 */       if (set.contains(ele)) {
/* 306 */         return ele;
/*     */       }
/*     */     }
/* 309 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\keyresolver\implementations\RetrievalMethodResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */