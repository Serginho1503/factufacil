/*     */ package adsi.org.apache.xml.security.c14n.helper;
/*     */ 
/*     */ import adsi.org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class C14nHelper
/*     */ {
/*     */   public static boolean namespaceIsRelative(Attr namespace)
/*     */   {
/*  52 */     return !namespaceIsAbsolute(namespace);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean namespaceIsRelative(String namespaceValue)
/*     */   {
/*  62 */     return !namespaceIsAbsolute(namespaceValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean namespaceIsAbsolute(Attr namespace)
/*     */   {
/*  72 */     return namespaceIsAbsolute(namespace.getValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean namespaceIsAbsolute(String namespaceValue)
/*     */   {
/*  84 */     if (namespaceValue.length() == 0) {
/*  85 */       return true;
/*     */     }
/*  87 */     return namespaceValue.indexOf(':') > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotRelativeNS(Attr attr)
/*     */     throws CanonicalizationException
/*     */   {
/* 100 */     if (attr == null) {
/* 101 */       return;
/*     */     }
/*     */     
/* 104 */     String nodeAttrName = attr.getNodeName();
/* 105 */     boolean definesDefaultNS = nodeAttrName.equals("xmlns");
/* 106 */     boolean definesNonDefaultNS = nodeAttrName.startsWith("xmlns:");
/*     */     
/* 108 */     if (((definesDefaultNS) || (definesNonDefaultNS)) && 
/* 109 */       (namespaceIsRelative(attr))) {
/* 110 */       String parentName = attr.getOwnerElement().getTagName();
/* 111 */       String attrValue = attr.getValue();
/* 112 */       Object[] exArgs = { parentName, nodeAttrName, attrValue };
/*     */       
/* 114 */       throw new CanonicalizationException(
/* 115 */         "c14n.Canonicalizer.RelativeNamespace", exArgs);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void checkTraversability(Document document)
/*     */     throws CanonicalizationException
/*     */   {
/* 130 */     if (!document.isSupported("Traversal", "2.0")) {
/* 131 */       Object[] exArgs = {
/* 132 */         document.getImplementation().getClass().getName() };
/*     */       
/* 134 */       throw new CanonicalizationException(
/* 135 */         "c14n.Canonicalizer.TraversalNotSupported", exArgs);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void checkForRelativeNamespace(Element ctxNode)
/*     */     throws CanonicalizationException
/*     */   {
/* 150 */     if (ctxNode != null) {
/* 151 */       NamedNodeMap attributes = ctxNode.getAttributes();
/*     */       
/* 153 */       for (int i = 0; i < attributes.getLength(); i++) {
/* 154 */         assertNotRelativeNS((Attr)attributes.item(i));
/*     */       }
/*     */     } else {
/* 157 */       throw new CanonicalizationException(
/* 158 */         "Called checkForRelativeNamespace() on null");
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\c14n\helper\C14nHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */