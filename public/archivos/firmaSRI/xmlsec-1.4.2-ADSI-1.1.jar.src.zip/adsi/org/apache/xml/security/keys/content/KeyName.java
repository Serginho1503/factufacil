/*    */ package adsi.org.apache.xml.security.keys.content;
/*    */ 
/*    */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*    */ import adsi.org.apache.xml.security.utils.SignatureElementProxy;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KeyName
/*    */   extends SignatureElementProxy
/*    */   implements KeyInfoContent
/*    */ {
/*    */   public KeyName(Element element, String BaseURI)
/*    */     throws XMLSecurityException
/*    */   {
/* 40 */     super(element, BaseURI);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public KeyName(Document doc, String keyName)
/*    */   {
/* 51 */     super(doc);
/*    */     
/* 53 */     addText(keyName);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getKeyName()
/*    */   {
/* 62 */     return getTextFromTextChild();
/*    */   }
/*    */   
/*    */   public String getBaseLocalName()
/*    */   {
/* 67 */     return "KeyName";
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\content\KeyName.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */