/*     */ package adsi.org.apache.xml.security.utils.resolver.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import adsi.org.apache.xml.security.utils.IdResolver;
/*     */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolverException;
/*     */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolverSpi;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResolverFragment
/*     */   extends ResourceResolverSpi
/*     */ {
/*  43 */   static Log log = LogFactory.getLog(
/*  44 */     ResolverFragment.class.getName());
/*     */   
/*  46 */   public boolean engineIsThreadSafe() { return true; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput engineResolve(Attr uri, String BaseURI)
/*     */     throws ResourceResolverException
/*     */   {
/*  62 */     String uriNodeValue = uri.getNodeValue();
/*  63 */     Document doc = uri.getOwnerElement().getOwnerDocument();
/*     */     
/*     */ 
/*  66 */     Node selectedElem = null;
/*  67 */     if (uriNodeValue.equals(""))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  74 */       log.debug("ResolverFragment with empty URI (means complete document)");
/*  75 */       selectedElem = doc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*  86 */       String id = uriNodeValue.substring(1);
/*     */       
/*     */ 
/*  89 */       selectedElem = IdResolver.getElementById(doc, id);
/*  90 */       if (selectedElem == null) {
/*  91 */         Object[] exArgs = { id };
/*  92 */         throw new ResourceResolverException(
/*  93 */           "signature.Verification.MissingID", exArgs, uri, BaseURI);
/*     */       }
/*  95 */       if (log.isDebugEnabled()) {
/*  96 */         log.debug("Try to catch an Element with ID " + id + " and Element was " + selectedElem);
/*     */       }
/*     */     }
/*  99 */     XMLSignatureInput result = new XMLSignatureInput(selectedElem);
/* 100 */     result.setExcludeComments(true);
/*     */     
/*     */ 
/* 103 */     result.setMIMEType("text/xml");
/* 104 */     result.setSourceURI(BaseURI != null ? BaseURI.concat(uri.getNodeValue()) : 
/* 105 */       uri.getNodeValue());
/* 106 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean engineCanResolve(Attr uri, String BaseURI)
/*     */   {
/* 118 */     if (uri == null) {
/* 119 */       log.debug("Quick fail for null uri");
/* 120 */       return false;
/*     */     }
/*     */     
/* 123 */     String uriNodeValue = uri.getNodeValue();
/*     */     
/* 125 */     if ((uriNodeValue.equals("")) || (
/*     */     
/* 127 */       (uriNodeValue.charAt(0) == '#') && (
/* 128 */       (uriNodeValue.charAt(1) != 'x') || (!uriNodeValue.startsWith("#xpointer(")))))
/*     */     {
/*     */ 
/* 131 */       if (log.isDebugEnabled())
/* 132 */         log.debug("State I can resolve reference: \"" + uriNodeValue + "\"");
/* 133 */       return true;
/*     */     }
/* 135 */     if (log.isDebugEnabled())
/* 136 */       log.debug("Do not seem to be able to resolve reference: \"" + uriNodeValue + "\"");
/* 137 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\utils\resolver\implementations\ResolverFragment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */