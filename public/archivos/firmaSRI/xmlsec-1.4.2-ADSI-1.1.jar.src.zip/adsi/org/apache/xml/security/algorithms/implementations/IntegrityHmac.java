/*     */ package adsi.org.apache.xml.security.algorithms.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.algorithms.JCEMapper;
/*     */ import adsi.org.apache.xml.security.algorithms.MessageDigestAlgorithm;
/*     */ import adsi.org.apache.xml.security.algorithms.SignatureAlgorithmSpi;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureException;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.Key;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.Provider;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.spec.AlgorithmParameterSpec;
/*     */ import javax.crypto.Mac;
/*     */ import javax.crypto.SecretKey;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class IntegrityHmac
/*     */   extends SignatureAlgorithmSpi
/*     */ {
/*  51 */   static Log log = LogFactory.getLog(IntegrityHmacSHA1.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  61 */   private Mac _macAlgorithm = null;
/*     */   
/*     */ 
/*  64 */   int _HMACOutputLength = 0;
/*     */   
/*     */ 
/*     */   public abstract String engineGetURI();
/*     */   
/*     */ 
/*     */   public IntegrityHmac()
/*     */     throws XMLSignatureException
/*     */   {
/*  73 */     String algorithmID = JCEMapper.translateURItoJCEID(engineGetURI());
/*  74 */     if (log.isDebugEnabled()) {
/*  75 */       log.debug("Created IntegrityHmacSHA1 using " + algorithmID);
/*     */     }
/*     */     try {
/*  78 */       this._macAlgorithm = Mac.getInstance(algorithmID);
/*     */     } catch (NoSuchAlgorithmException ex) {
/*  80 */       Object[] exArgs = { algorithmID, 
/*  81 */         ex.getLocalizedMessage() };
/*     */       
/*  83 */       throw new XMLSignatureException("algorithms.NoSuchAlgorithm", exArgs);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineSetParameter(AlgorithmParameterSpec params)
/*     */     throws XMLSignatureException
/*     */   {
/*  96 */     throw new XMLSignatureException("empty");
/*     */   }
/*     */   
/*     */   public void reset() {
/* 100 */     this._HMACOutputLength = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean engineVerify(byte[] signature)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 115 */       byte[] completeResult = this._macAlgorithm.doFinal();
/*     */       
/* 117 */       if ((this._HMACOutputLength == 0) || (this._HMACOutputLength >= 160)) {
/* 118 */         return MessageDigestAlgorithm.isEqual(completeResult, signature);
/*     */       }
/* 120 */       byte[] stripped = reduceBitLength(completeResult, 
/* 121 */         this._HMACOutputLength);
/* 122 */       return MessageDigestAlgorithm.isEqual(stripped, signature);
/*     */     } catch (IllegalStateException ex) {
/* 124 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineInitVerify(Key secretKey)
/*     */     throws XMLSignatureException
/*     */   {
/* 137 */     if (!(secretKey instanceof SecretKey)) {
/* 138 */       String supplied = secretKey.getClass().getName();
/* 139 */       String needed = SecretKey.class.getName();
/* 140 */       Object[] exArgs = { supplied, needed };
/*     */       
/* 142 */       throw new XMLSignatureException("algorithms.WrongKeyForThisOperation", 
/* 143 */         exArgs);
/*     */     }
/*     */     try
/*     */     {
/* 147 */       this._macAlgorithm.init(secretKey);
/*     */     }
/*     */     catch (InvalidKeyException ex)
/*     */     {
/* 151 */       Mac mac = this._macAlgorithm;
/*     */       try {
/* 153 */         this._macAlgorithm = Mac.getInstance(
/* 154 */           this._macAlgorithm.getAlgorithm());
/*     */       }
/*     */       catch (Exception e) {
/* 157 */         if (log.isDebugEnabled()) {
/* 158 */           log.debug("Exception when reinstantiating Mac:" + e);
/*     */         }
/* 160 */         this._macAlgorithm = mac;
/*     */       }
/* 162 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected byte[] engineSign()
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 176 */       byte[] completeResult = this._macAlgorithm.doFinal();
/*     */       
/* 178 */       if ((this._HMACOutputLength == 0) || (this._HMACOutputLength >= 160)) {
/* 179 */         return completeResult;
/*     */       }
/* 181 */       return reduceBitLength(completeResult, 
/* 182 */         this._HMACOutputLength);
/*     */     }
/*     */     catch (IllegalStateException ex) {
/* 185 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static byte[] reduceBitLength(byte[] completeResult, int length)
/*     */   {
/* 199 */     int bytes = length / 8;
/* 200 */     int abits = length % 8;
/* 201 */     byte[] strippedResult = new byte[bytes + (abits == 0 ? 
/* 202 */       0 : 
/* 203 */       1)];
/*     */     
/* 205 */     System.arraycopy(completeResult, 0, strippedResult, 0, bytes);
/*     */     
/* 207 */     if (abits > 0) {
/* 208 */       byte[] MASK = { 0, Byte.MIN_VALUE, -64, -32, 
/* 209 */         -16, -8, -4, -2 };
/*     */       
/* 211 */       strippedResult[bytes] = ((byte)(completeResult[bytes] & MASK[abits]));
/*     */     }
/*     */     
/* 214 */     return strippedResult;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineInitSign(Key secretKey)
/*     */     throws XMLSignatureException
/*     */   {
/* 225 */     if (!(secretKey instanceof SecretKey)) {
/* 226 */       String supplied = secretKey.getClass().getName();
/* 227 */       String needed = SecretKey.class.getName();
/* 228 */       Object[] exArgs = { supplied, needed };
/*     */       
/* 230 */       throw new XMLSignatureException("algorithms.WrongKeyForThisOperation", 
/* 231 */         exArgs);
/*     */     }
/*     */     try
/*     */     {
/* 235 */       this._macAlgorithm.init(secretKey);
/*     */     } catch (InvalidKeyException ex) {
/* 237 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineInitSign(Key secretKey, AlgorithmParameterSpec algorithmParameterSpec)
/*     */     throws XMLSignatureException
/*     */   {
/* 252 */     if (!(secretKey instanceof SecretKey)) {
/* 253 */       String supplied = secretKey.getClass().getName();
/* 254 */       String needed = SecretKey.class.getName();
/* 255 */       Object[] exArgs = { supplied, needed };
/*     */       
/* 257 */       throw new XMLSignatureException("algorithms.WrongKeyForThisOperation", 
/* 258 */         exArgs);
/*     */     }
/*     */     try
/*     */     {
/* 262 */       this._macAlgorithm.init(secretKey, algorithmParameterSpec);
/*     */     } catch (InvalidKeyException ex) {
/* 264 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (InvalidAlgorithmParameterException ex) {
/* 266 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineInitSign(Key secretKey, SecureRandom secureRandom)
/*     */     throws XMLSignatureException
/*     */   {
/* 279 */     throw new XMLSignatureException("algorithms.CannotUseSecureRandomOnMAC");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineUpdate(byte[] input)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 292 */       this._macAlgorithm.update(input);
/*     */     } catch (IllegalStateException ex) {
/* 294 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineUpdate(byte input)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 308 */       this._macAlgorithm.update(input);
/*     */     } catch (IllegalStateException ex) {
/* 310 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineUpdate(byte[] buf, int offset, int len)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 327 */       this._macAlgorithm.update(buf, offset, len);
/*     */     } catch (IllegalStateException ex) {
/* 329 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String engineGetJCEAlgorithmString()
/*     */   {
/* 340 */     log.debug("engineGetJCEAlgorithmString()");
/*     */     
/* 342 */     return this._macAlgorithm.getAlgorithm();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String engineGetJCEProviderName()
/*     */   {
/* 351 */     return this._macAlgorithm.getProvider().getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineSetHMACOutputLength(int HMACOutputLength)
/*     */   {
/* 360 */     this._HMACOutputLength = HMACOutputLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineGetContextFromElement(Element element)
/*     */   {
/* 370 */     super.engineGetContextFromElement(element);
/*     */     
/* 372 */     if (element == null) {
/* 373 */       throw new IllegalArgumentException("element null");
/*     */     }
/*     */     
/* 376 */     Text hmaclength = XMLUtils.selectDsNodeText(element.getFirstChild(), 
/* 377 */       "HMACOutputLength", 0);
/*     */     
/* 379 */     if (hmaclength != null) {
/* 380 */       this._HMACOutputLength = Integer.parseInt(hmaclength.getData());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void engineAddContextToElement(Element element)
/*     */   {
/* 393 */     if (element == null) {
/* 394 */       throw new IllegalArgumentException("null element");
/*     */     }
/*     */     
/* 397 */     if (this._HMACOutputLength != 0) {
/* 398 */       Document doc = element.getOwnerDocument();
/* 399 */       Element HMElem = XMLUtils.createElementInSignatureSpace(doc, 
/* 400 */         "HMACOutputLength");
/* 401 */       Text HMText = 
/* 402 */         doc.createTextNode(new Integer(this._HMACOutputLength).toString());
/*     */       
/* 404 */       HMElem.appendChild(HMText);
/* 405 */       XMLUtils.addReturnToElement(element);
/* 406 */       element.appendChild(HMElem);
/* 407 */       XMLUtils.addReturnToElement(element);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class IntegrityHmacSHA1
/*     */     extends IntegrityHmac
/*     */   {
/*     */     public IntegrityHmacSHA1()
/*     */       throws XMLSignatureException
/*     */     {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String engineGetURI()
/*     */     {
/* 434 */       return "http://www.w3.org/2000/09/xmldsig#hmac-sha1";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class IntegrityHmacSHA256
/*     */     extends IntegrityHmac
/*     */   {
/*     */     public IntegrityHmacSHA256()
/*     */       throws XMLSignatureException
/*     */     {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String engineGetURI()
/*     */     {
/* 461 */       return "http://www.w3.org/2001/04/xmldsig-more#hmac-sha256";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class IntegrityHmacSHA384
/*     */     extends IntegrityHmac
/*     */   {
/*     */     public IntegrityHmacSHA384()
/*     */       throws XMLSignatureException
/*     */     {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String engineGetURI()
/*     */     {
/* 488 */       return "http://www.w3.org/2001/04/xmldsig-more#hmac-sha384";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class IntegrityHmacSHA512
/*     */     extends IntegrityHmac
/*     */   {
/*     */     public IntegrityHmacSHA512()
/*     */       throws XMLSignatureException
/*     */     {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String engineGetURI()
/*     */     {
/* 515 */       return "http://www.w3.org/2001/04/xmldsig-more#hmac-sha512";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class IntegrityHmacRIPEMD160
/*     */     extends IntegrityHmac
/*     */   {
/*     */     public IntegrityHmacRIPEMD160()
/*     */       throws XMLSignatureException
/*     */     {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String engineGetURI()
/*     */     {
/* 542 */       return "http://www.w3.org/2001/04/xmldsig-more#hmac-ripemd160";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class IntegrityHmacMD5
/*     */     extends IntegrityHmac
/*     */   {
/*     */     public IntegrityHmacMD5()
/*     */       throws XMLSignatureException
/*     */     {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String engineGetURI()
/*     */     {
/* 569 */       return "http://www.w3.org/2001/04/xmldsig-more#hmac-md5";
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\algorithms\implementations\IntegrityHmac.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */