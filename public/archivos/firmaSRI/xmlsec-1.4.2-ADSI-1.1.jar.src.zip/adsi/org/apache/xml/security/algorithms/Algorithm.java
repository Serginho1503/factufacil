/*    */ package adsi.org.apache.xml.security.algorithms;
/*    */ 
/*    */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*    */ import adsi.org.apache.xml.security.utils.SignatureElementProxy;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Algorithm
/*    */   extends SignatureElementProxy
/*    */ {
/*    */   public Algorithm(Document doc, String algorithmURI)
/*    */   {
/* 42 */     super(doc);
/*    */     
/* 44 */     setAlgorithmURI(algorithmURI);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Algorithm(Element element, String BaseURI)
/*    */     throws XMLSecurityException
/*    */   {
/* 56 */     super(element, BaseURI);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getAlgorithmURI()
/*    */   {
/* 65 */     return this._constructionElement.getAttributeNS(null, "Algorithm");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void setAlgorithmURI(String algorithmURI)
/*    */   {
/* 75 */     if (algorithmURI != null) {
/* 76 */       this._constructionElement.setAttributeNS(null, "Algorithm", 
/* 77 */         algorithmURI);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\algorithms\Algorithm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */