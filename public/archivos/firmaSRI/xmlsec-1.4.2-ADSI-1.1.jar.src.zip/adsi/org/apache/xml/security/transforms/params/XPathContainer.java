/*    */ package adsi.org.apache.xml.security.transforms.params;
/*    */ 
/*    */ import adsi.org.apache.xml.security.transforms.TransformParam;
/*    */ import adsi.org.apache.xml.security.utils.SignatureElementProxy;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.NodeList;
/*    */ import org.w3c.dom.Text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XPathContainer
/*    */   extends SignatureElementProxy
/*    */   implements TransformParam
/*    */ {
/*    */   public XPathContainer(Document doc)
/*    */   {
/* 45 */     super(doc);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setXPath(String xpath)
/*    */   {
/* 55 */     if (this._constructionElement.getChildNodes() != null) {
/* 56 */       NodeList nl = this._constructionElement.getChildNodes();
/*    */       
/* 58 */       for (int i = 0; i < nl.getLength(); i++) {
/* 59 */         this._constructionElement.removeChild(nl.item(i));
/*    */       }
/*    */     }
/*    */     
/* 63 */     Text xpathText = this._doc.createTextNode(xpath);
/* 64 */     this._constructionElement.appendChild(xpathText);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getXPath()
/*    */   {
/* 73 */     return getTextFromTextChild();
/*    */   }
/*    */   
/*    */   public String getBaseLocalName()
/*    */   {
/* 78 */     return "XPath";
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\transforms\params\XPathContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */