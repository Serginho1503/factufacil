/*     */ package adsi.org.apache.xml.security.utils;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.StringReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RFC2253Parser
/*     */ {
/*  37 */   static boolean _TOXML = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String rfc2253toXMLdsig(String dn)
/*     */   {
/*  48 */     _TOXML = true;
/*     */     
/*     */ 
/*  51 */     String normalized = normalize(dn);
/*     */     
/*  53 */     return rfctoXML(normalized);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String xmldsigtoRFC2253(String dn)
/*     */   {
/*  64 */     _TOXML = false;
/*     */     
/*     */ 
/*  67 */     String normalized = normalize(dn);
/*     */     
/*  69 */     return xmltoRFC(normalized);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String normalize(String dn)
/*     */   {
/*  81 */     if ((dn == null) || (dn.equals(""))) {
/*  82 */       return "";
/*     */     }
/*     */     try
/*     */     {
/*  86 */       String _DN = semicolonToComma(dn);
/*  87 */       StringBuffer sb = new StringBuffer();
/*  88 */       int i = 0;
/*  89 */       int l = 0;
/*     */       
/*     */       int k;
/*     */       int k;
/*  93 */       for (int j = 0; (k = _DN.indexOf(",", j)) >= 0; j = k + 1) {
/*  94 */         l += countQuotes(_DN, j, k);
/*     */         
/*  96 */         if ((k > 0) && (_DN.charAt(k - 1) != '\\') && (l % 2 != 1)) {
/*  97 */           sb.append(parseRDN(_DN.substring(i, k).trim()) + ",");
/*     */           
/*  99 */           i = k + 1;
/* 100 */           l = 0;
/*     */         }
/*     */       }
/*     */       
/* 104 */       sb.append(parseRDN(trim(_DN.substring(i))));
/*     */       
/* 106 */       return sb.toString();
/*     */     } catch (IOException ex) {}
/* 108 */     return dn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String parseRDN(String str)
/*     */     throws IOException
/*     */   {
/* 121 */     StringBuffer sb = new StringBuffer();
/* 122 */     int i = 0;
/* 123 */     int l = 0;
/*     */     int k;
/*     */     int k;
/* 126 */     for (int j = 0; (k = str.indexOf("+", j)) >= 0; j = k + 1) {
/* 127 */       l += countQuotes(str, j, k);
/*     */       
/* 129 */       if ((k > 0) && (str.charAt(k - 1) != '\\') && (l % 2 != 1)) {
/* 130 */         sb.append(parseATAV(trim(str.substring(i, k))) + "+");
/*     */         
/* 132 */         i = k + 1;
/* 133 */         l = 0;
/*     */       }
/*     */     }
/*     */     
/* 137 */     sb.append(parseATAV(trim(str.substring(i))));
/*     */     
/* 139 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String parseATAV(String str)
/*     */     throws IOException
/*     */   {
/* 151 */     int i = str.indexOf("=");
/*     */     
/* 153 */     if ((i == -1) || ((i > 0) && (str.charAt(i - 1) == '\\'))) {
/* 154 */       return str;
/*     */     }
/* 156 */     String attrType = normalizeAT(str.substring(0, i));
/*     */     
/* 158 */     String attrValue = null;
/* 159 */     if ((attrType.charAt(0) >= '0') && (attrType.charAt(0) <= '9')) {
/* 160 */       attrValue = str.substring(i + 1);
/*     */     } else {
/* 162 */       attrValue = normalizeV(str.substring(i + 1));
/*     */     }
/*     */     
/* 165 */     return attrType + "=" + attrValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String normalizeAT(String str)
/*     */   {
/* 177 */     String at = str.toUpperCase().trim();
/*     */     
/* 179 */     if (at.startsWith("OID")) {
/* 180 */       at = at.substring(3);
/*     */     }
/*     */     
/* 183 */     return at;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String normalizeV(String str)
/*     */     throws IOException
/*     */   {
/* 195 */     String value = trim(str);
/*     */     
/* 197 */     if (value.startsWith("\"")) {
/* 198 */       StringBuffer sb = new StringBuffer();
/* 199 */       StringReader sr = new StringReader(value.substring(1, 
/* 200 */         value.length() - 1));
/* 201 */       int i = 0;
/*     */       
/*     */ 
/* 204 */       while ((i = sr.read()) > -1) {
/* 205 */         char c = (char)i;
/*     */         
/*     */ 
/* 208 */         if ((c == ',') || (c == '=') || (c == '+') || (c == '<') || 
/* 209 */           (c == '>') || (c == '#') || (c == ';')) {
/* 210 */           sb.append('\\');
/*     */         }
/*     */         
/* 213 */         sb.append(c);
/*     */       }
/*     */       
/* 216 */       value = trim(sb.toString());
/*     */     }
/*     */     
/* 219 */     if (_TOXML) {
/* 220 */       if (value.startsWith("#")) {
/* 221 */         value = '\\' + value;
/*     */       }
/*     */     }
/* 224 */     else if (value.startsWith("\\#")) {
/* 225 */       value = value.substring(1);
/*     */     }
/*     */     
/*     */ 
/* 229 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String rfctoXML(String string)
/*     */   {
/*     */     try
/*     */     {
/* 241 */       String s = changeLess32toXML(string);
/*     */       
/* 243 */       return changeWStoXML(s);
/*     */     } catch (Exception e) {}
/* 245 */     return string;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String xmltoRFC(String string)
/*     */   {
/*     */     try
/*     */     {
/* 258 */       String s = changeLess32toRFC(string);
/*     */       
/* 260 */       return changeWStoRFC(s);
/*     */     } catch (Exception e) {}
/* 262 */     return string;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String changeLess32toRFC(String string)
/*     */     throws IOException
/*     */   {
/* 275 */     StringBuffer sb = new StringBuffer();
/* 276 */     StringReader sr = new StringReader(string);
/* 277 */     int i = 0;
/*     */     
/*     */ 
/* 280 */     while ((i = sr.read()) > -1) {
/* 281 */       char c = (char)i;
/*     */       
/* 283 */       if (c == '\\') {
/* 284 */         sb.append(c);
/*     */         
/* 286 */         char c1 = (char)sr.read();
/* 287 */         char c2 = (char)sr.read();
/*     */         
/*     */ 
/* 290 */         if (((c1 >= '0') && (c1 <= '9')) || ((c1 >= 'A') && (c1 <= 'F')) || ((c1 >= 'a') && (c1 <= 'f') && (
/* 291 */           ((c2 >= '0') && (c2 <= '9')) || 
/* 292 */           ((c2 >= 'A') && (c2 <= 'F')) || (
/* 293 */           (c2 >= 'a') && (c2 <= 'f'))))) {
/* 294 */           char ch = (char)Byte.parseByte(c1 + c2, 16);
/*     */           
/* 296 */           sb.append(ch);
/*     */         } else {
/* 298 */           sb.append(c1);
/* 299 */           sb.append(c2);
/*     */         }
/*     */       } else {
/* 302 */         sb.append(c);
/*     */       }
/*     */     }
/*     */     
/* 306 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String changeLess32toXML(String string)
/*     */     throws IOException
/*     */   {
/* 318 */     StringBuffer sb = new StringBuffer();
/* 319 */     StringReader sr = new StringReader(string);
/* 320 */     int i = 0;
/*     */     
/* 322 */     while ((i = sr.read()) > -1) {
/* 323 */       if (i < 32) {
/* 324 */         sb.append('\\');
/* 325 */         sb.append(Integer.toHexString(i));
/*     */       } else {
/* 327 */         sb.append((char)i);
/*     */       }
/*     */     }
/*     */     
/* 331 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String changeWStoXML(String string)
/*     */     throws IOException
/*     */   {
/* 343 */     StringBuffer sb = new StringBuffer();
/* 344 */     StringReader sr = new StringReader(string);
/* 345 */     int i = 0;
/*     */     
/*     */ 
/* 348 */     while ((i = sr.read()) > -1) {
/* 349 */       char c = (char)i;
/*     */       
/* 351 */       if (c == '\\') {
/* 352 */         char c1 = (char)sr.read();
/*     */         
/* 354 */         if (c1 == ' ') {
/* 355 */           sb.append('\\');
/*     */           
/* 357 */           String s = "20";
/*     */           
/* 359 */           sb.append(s);
/*     */         } else {
/* 361 */           sb.append('\\');
/* 362 */           sb.append(c1);
/*     */         }
/*     */       } else {
/* 365 */         sb.append(c);
/*     */       }
/*     */     }
/*     */     
/* 369 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String changeWStoRFC(String string)
/*     */   {
/* 380 */     StringBuffer sb = new StringBuffer();
/* 381 */     int i = 0;
/*     */     int k;
/*     */     int k;
/* 384 */     for (int j = 0; (k = string.indexOf("\\20", j)) >= 0; j = k + 3) {
/* 385 */       sb.append(trim(string.substring(i, k)) + "\\ ");
/*     */       
/* 387 */       i = k + 3;
/*     */     }
/*     */     
/* 390 */     sb.append(string.substring(i));
/*     */     
/* 392 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String semicolonToComma(String str)
/*     */   {
/* 402 */     return removeWSandReplace(str, ";", ",");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String removeWhiteSpace(String str, String symbol)
/*     */   {
/* 413 */     return removeWSandReplace(str, symbol, symbol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String removeWSandReplace(String str, String symbol, String replace)
/*     */   {
/* 426 */     StringBuffer sb = new StringBuffer();
/* 427 */     int i = 0;
/* 428 */     int l = 0;
/*     */     int k;
/*     */     int k;
/* 431 */     for (int j = 0; (k = str.indexOf(symbol, j)) >= 0; j = k + 1) {
/* 432 */       l += countQuotes(str, j, k);
/*     */       
/* 434 */       if ((k > 0) && (str.charAt(k - 1) != '\\') && (l % 2 != 1)) {
/* 435 */         sb.append(trim(str.substring(i, k)) + replace);
/*     */         
/* 437 */         i = k + 1;
/* 438 */         l = 0;
/*     */       }
/*     */     }
/*     */     
/* 442 */     sb.append(trim(str.substring(i)));
/*     */     
/* 444 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int countQuotes(String s, int i, int j)
/*     */   {
/* 457 */     int k = 0;
/*     */     
/* 459 */     for (int l = i; l < j; l++) {
/* 460 */       if (s.charAt(l) == '"') {
/* 461 */         k++;
/*     */       }
/*     */     }
/*     */     
/* 465 */     return k;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String trim(String str)
/*     */   {
/* 478 */     String trimed = str.trim();
/* 479 */     int i = str.indexOf(trimed) + trimed.length();
/*     */     
/* 481 */     if ((str.length() > i) && (trimed.endsWith("\\")) && 
/* 482 */       (!trimed.endsWith("\\\\")) && 
/* 483 */       (str.charAt(i) == ' ')) {
/* 484 */       trimed = trimed + " ";
/*     */     }
/*     */     
/*     */ 
/* 488 */     return trimed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/* 499 */     testToXML("CN=\"Steve, Kille\",  O=Isode Limited, C=GB");
/* 500 */     testToXML("CN=Steve Kille    ,   O=Isode Limited,C=GB");
/* 501 */     testToXML("\\ OU=Sales+CN=J. Smith,O=Widget Inc.,C=US\\ \\ ");
/* 502 */     testToXML("CN=L. Eagle,O=Sue\\, Grabbit and Runn,C=GB");
/* 503 */     testToXML("CN=Before\\0DAfter,O=Test,C=GB");
/* 504 */     testToXML("CN=\"L. Eagle,O=Sue, = + < > # ;Grabbit and Runn\",C=GB");
/* 505 */     testToXML("1.3.6.1.4.1.1466.0=#04024869,O=Test,C=GB");
/*     */     
/*     */ 
/* 508 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 510 */     sb.append('L');
/* 511 */     sb.append('u');
/* 512 */     sb.append(50317);
/* 513 */     sb.append('i');
/* 514 */     sb.append(50311);
/*     */     
/* 516 */     String test7 = "SN=" + sb.toString();
/*     */     
/* 518 */     testToXML(test7);
/*     */     
/*     */ 
/* 521 */     testToRFC("CN=\"Steve, Kille\",  O=Isode Limited, C=GB");
/* 522 */     testToRFC("CN=Steve Kille    ,   O=Isode Limited,C=GB");
/* 523 */     testToRFC("\\20OU=Sales+CN=J. Smith,O=Widget Inc.,C=US\\20\\20 ");
/* 524 */     testToRFC("CN=L. Eagle,O=Sue\\, Grabbit and Runn,C=GB");
/* 525 */     testToRFC("CN=Before\\12After,O=Test,C=GB");
/* 526 */     testToRFC("CN=\"L. Eagle,O=Sue, = + < > # ;Grabbit and Runn\",C=GB");
/* 527 */     testToRFC("1.3.6.1.4.1.1466.0=\\#04024869,O=Test,C=GB");
/*     */     
/*     */ 
/* 530 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 532 */     sb.append('L');
/* 533 */     sb.append('u');
/* 534 */     sb.append(50317);
/* 535 */     sb.append('i');
/* 536 */     sb.append(50311);
/*     */     
/* 538 */     String test7 = "SN=" + sb.toString();
/*     */     
/* 540 */     testToRFC(test7);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 545 */   static int counter = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void testToXML(String st)
/*     */   {
/* 554 */     System.out.println("start " + counter++ + ": " + st);
/* 555 */     System.out.println("         " + rfc2253toXMLdsig(st));
/* 556 */     System.out.println("");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void testToRFC(String st)
/*     */   {
/* 566 */     System.out.println("start " + counter++ + ": " + st);
/* 567 */     System.out.println("         " + xmldsigtoRFC2253(st));
/* 568 */     System.out.println("");
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\utils\RFC2253Parser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */