/*     */ package adsi.org.apache.xml.security.signature;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.utils.IdResolver;
/*     */ import adsi.org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignatureProperty
/*     */   extends SignatureElementProxy
/*     */ {
/*     */   public SignatureProperty(Document doc, String Target)
/*     */   {
/*  44 */     this(doc, Target, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignatureProperty(Document doc, String Target, String Id)
/*     */   {
/*  56 */     super(doc);
/*     */     
/*  58 */     setTarget(Target);
/*  59 */     setId(Id);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignatureProperty(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  70 */     super(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setId(String Id)
/*     */   {
/*  80 */     if (Id != null) {
/*  81 */       this._constructionElement.setAttributeNS(null, "Id", Id);
/*  82 */       IdResolver.registerElementById(this._constructionElement, Id);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getId()
/*     */   {
/*  92 */     return this._constructionElement.getAttributeNS(null, "Id");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTarget(String Target)
/*     */   {
/* 102 */     if (Target != null) {
/* 103 */       this._constructionElement.setAttributeNS(null, "Target", Target);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTarget()
/*     */   {
/* 113 */     return this._constructionElement.getAttributeNS(null, "Target");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node appendChild(Node node)
/*     */   {
/* 123 */     return this._constructionElement.appendChild(node);
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 128 */     return "SignatureProperty";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\signature\SignatureProperty.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */