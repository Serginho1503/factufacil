/*    */ package adsi.org.apache.xml.security.utils.resolver.implementations;
/*    */ 
/*    */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*    */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolverException;
/*    */ import org.apache.xml.utils.URI;
/*    */ import org.w3c.dom.Attr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResolverBigLocalFilesystem
/*    */   extends ResolverLocalFilesystem
/*    */ {
/*    */   public XMLSignatureInput engineResolve(Attr uri, String BaseURI)
/*    */     throws ResourceResolverException
/*    */   {
/*    */     try
/*    */     {
/* 31 */       URI uriNew = getNewURI(uri.getNodeValue(), BaseURI);
/*    */       
/*    */ 
/* 34 */       URI uriNewNoFrag = new URI(uriNew);
/*    */       
/* 36 */       uriNewNoFrag.setFragment(null);
/*    */       
/* 38 */       String fileName = 
/*    */       
/* 40 */         ResolverLocalFilesystem.translateUriToFilename(uriNewNoFrag.toString());
/* 41 */       ReseteableFileInputStream inputStream = new ReseteableFileInputStream(fileName);
/* 42 */       XMLSignatureInput result = new XMLSignatureInput(inputStream);
/*    */       
/* 44 */       result.setSourceURI(uriNew.toString());
/*    */       
/* 46 */       return result;
/*    */     } catch (Exception e) {
/* 48 */       throw new ResourceResolverException("generic.EmptyMessage", e, uri, 
/* 49 */         BaseURI);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\utils\resolver\implementations\ResolverBigLocalFilesystem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */