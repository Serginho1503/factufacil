/*     */ package adsi.org.apache.xml.security.transforms.params;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.transforms.TransformParam;
/*     */ import adsi.org.apache.xml.security.utils.ElementProxy;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XPath2FilterContainer04
/*     */   extends ElementProxy
/*     */   implements TransformParam
/*     */ {
/*     */   private static final String _ATT_FILTER = "Filter";
/*     */   private static final String _ATT_FILTER_VALUE_INTERSECT = "intersect";
/*     */   private static final String _ATT_FILTER_VALUE_SUBTRACT = "subtract";
/*     */   private static final String _ATT_FILTER_VALUE_UNION = "union";
/*     */   public static final String _TAG_XPATH2 = "XPath";
/*     */   public static final String XPathFilter2NS = "http://www.w3.org/2002/04/xmldsig-filter2";
/*     */   
/*     */   private XPath2FilterContainer04() {}
/*     */   
/*     */   private XPath2FilterContainer04(Document doc, String xpath2filter, String filterType)
/*     */   {
/*  81 */     super(doc);
/*     */     
/*  83 */     this._constructionElement.setAttributeNS(null, "Filter", 
/*  84 */       filterType);
/*     */     
/*  86 */     if ((xpath2filter.length() > 2) && 
/*  87 */       (!Character.isWhitespace(xpath2filter.charAt(0)))) {
/*  88 */       XMLUtils.addReturnToElement(this._constructionElement);
/*  89 */       this._constructionElement.appendChild(doc.createTextNode(xpath2filter));
/*  90 */       XMLUtils.addReturnToElement(this._constructionElement);
/*     */     }
/*     */     else {
/*  93 */       this._constructionElement.appendChild(doc.createTextNode(xpath2filter));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private XPath2FilterContainer04(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 107 */     super(element, BaseURI);
/*     */     
/* 109 */     String filterStr = 
/* 110 */       this._constructionElement
/* 111 */       .getAttributeNS(null, "Filter");
/*     */     
/*     */ 
/* 114 */     if (!filterStr.equals("intersect"))
/*     */     {
/* 116 */       if (!filterStr.equals("subtract"))
/*     */       {
/* 118 */         if (!filterStr.equals("union")) {
/* 119 */           Object[] exArgs = { "Filter", filterStr, 
/* 120 */             "intersect, subtract or union" };
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 126 */           throw new XMLSecurityException("attributeValueIllegal", exArgs);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XPath2FilterContainer04 newInstanceIntersect(Document doc, String xpath2filter)
/*     */   {
/* 140 */     return new XPath2FilterContainer04(doc, xpath2filter, 
/* 141 */       "intersect");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XPath2FilterContainer04 newInstanceSubtract(Document doc, String xpath2filter)
/*     */   {
/* 155 */     return new XPath2FilterContainer04(doc, xpath2filter, 
/* 156 */       "subtract");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XPath2FilterContainer04 newInstanceUnion(Document doc, String xpath2filter)
/*     */   {
/* 170 */     return new XPath2FilterContainer04(doc, xpath2filter, 
/* 171 */       "union");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XPath2FilterContainer04 newInstance(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 186 */     return new XPath2FilterContainer04(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isIntersect()
/*     */   {
/* 196 */     return 
/*     */     
/* 198 */       this._constructionElement.getAttributeNS(null, "Filter").equals("intersect");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSubtract()
/*     */   {
/* 208 */     return 
/*     */     
/* 210 */       this._constructionElement.getAttributeNS(null, "Filter").equals("subtract");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isUnion()
/*     */   {
/* 220 */     return 
/*     */     
/* 222 */       this._constructionElement.getAttributeNS(null, "Filter").equals("union");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getXPathFilterStr()
/*     */   {
/* 231 */     return getTextFromTextChild();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node getXPathFilterTextNode()
/*     */   {
/* 243 */     NodeList children = this._constructionElement.getChildNodes();
/* 244 */     int length = children.getLength();
/*     */     
/* 246 */     for (int i = 0; i < length; i++) {
/* 247 */       if (children.item(i).getNodeType() == 3) {
/* 248 */         return children.item(i);
/*     */       }
/*     */     }
/*     */     
/* 252 */     return null;
/*     */   }
/*     */   
/*     */   public final String getBaseLocalName()
/*     */   {
/* 257 */     return "XPath";
/*     */   }
/*     */   
/*     */   public final String getBaseNamespace()
/*     */   {
/* 262 */     return "http://www.w3.org/2002/04/xmldsig-filter2";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\transforms\params\XPath2FilterContainer04.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */