/*     */ package adsi.org.apache.xml.security.signature;
/*     */ 
/*     */ import adsi.org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import adsi.org.apache.xml.security.c14n.InvalidCanonicalizerException;
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.transforms.Transforms;
/*     */ import adsi.org.apache.xml.security.utils.I18n;
/*     */ import adsi.org.apache.xml.security.utils.IdResolver;
/*     */ import adsi.org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolver;
/*     */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolverSpi;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Manifest
/*     */   extends SignatureElementProxy
/*     */ {
/*  59 */   static Log log = LogFactory.getLog(Manifest.class.getName());
/*     */   
/*     */ 
/*     */   List _references;
/*     */   
/*     */   Element[] _referencesEl;
/*     */   
/*  66 */   private boolean[] verificationResults = null;
/*     */   
/*     */ 
/*  69 */   HashMap _resolverProperties = null;
/*     */   
/*     */ 
/*  72 */   List _perManifestResolvers = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Manifest(Document doc)
/*     */   {
/*  81 */     super(doc);
/*     */     
/*  83 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */     
/*  85 */     this._references = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Manifest(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  98 */     super(element, BaseURI);
/*     */     
/*     */ 
/* 101 */     this._referencesEl = XMLUtils.selectDsNodes(this._constructionElement.getFirstChild(), 
/* 102 */       "Reference");
/* 103 */     int le = this._referencesEl.length;
/*     */     
/* 105 */     if (le == 0)
/*     */     {
/*     */ 
/* 108 */       Object[] exArgs = { "Reference", 
/* 109 */         "Manifest" };
/*     */       
/* 111 */       throw new DOMException((short)4, 
/* 112 */         I18n.translate("xml.WrongContent", exArgs));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 117 */     this._references = new ArrayList(le);
/*     */     
/* 119 */     for (int i = 0; i < le; i++) {
/* 120 */       this._references.add(null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addDocument(String BaseURI, String referenceURI, Transforms transforms, String digestURI, String ReferenceId, String ReferenceType)
/*     */     throws XMLSignatureException
/*     */   {
/* 142 */     Reference ref = new Reference(this._doc, BaseURI, referenceURI, this, 
/* 143 */       transforms, digestURI);
/*     */     
/* 145 */     if (ReferenceId != null) {
/* 146 */       ref.setId(ReferenceId);
/*     */     }
/*     */     
/* 149 */     if (ReferenceType != null) {
/* 150 */       ref.setType(ReferenceType);
/*     */     }
/*     */     
/*     */ 
/* 154 */     this._references.add(ref);
/*     */     
/*     */ 
/* 157 */     this._constructionElement.appendChild(ref.getElement());
/* 158 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void generateDigestValues()
/*     */     throws XMLSignatureException, ReferenceNotInitializedException
/*     */   {
/* 172 */     for (int i = 0; i < getLength(); i++)
/*     */     {
/*     */ 
/* 175 */       Reference currentRef = (Reference)this._references.get(i);
/*     */       
/* 177 */       currentRef.generateDigestValue();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLength()
/*     */   {
/* 187 */     return this._references.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Reference item(int i)
/*     */     throws XMLSecurityException
/*     */   {
/* 200 */     if (this._references.get(i) == null)
/*     */     {
/*     */ 
/* 203 */       Reference ref = new Reference(this._referencesEl[i], this._baseURI, this);
/*     */       
/* 205 */       this._references.set(i, ref);
/*     */     }
/*     */     
/* 208 */     return (Reference)this._references.get(i);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setId(String Id)
/*     */   {
/* 219 */     if (Id != null) {
/* 220 */       this._constructionElement.setAttributeNS(null, "Id", Id);
/* 221 */       IdResolver.registerElementById(this._constructionElement, Id);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getId()
/*     */   {
/* 231 */     return this._constructionElement.getAttributeNS(null, "Id");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean verifyReferences()
/*     */     throws MissingResourceFailureException, XMLSecurityException
/*     */   {
/* 253 */     return verifyReferences(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean verifyReferences(boolean followManifests)
/*     */     throws MissingResourceFailureException, XMLSecurityException
/*     */   {
/* 276 */     if (this._referencesEl == null) {
/* 277 */       this._referencesEl = 
/* 278 */         XMLUtils.selectDsNodes(this._constructionElement.getFirstChild(), 
/* 279 */         "Reference");
/*     */     }
/* 281 */     if (log.isDebugEnabled()) {
/* 282 */       log.debug("verify " + this._referencesEl.length + " References");
/* 283 */       log.debug("I am " + (followManifests ? 
/* 284 */         "" : 
/* 285 */         "not") + " requested to follow nested Manifests");
/*     */     }
/* 287 */     boolean verify = true;
/*     */     
/* 289 */     if (this._referencesEl.length == 0) {
/* 290 */       throw new XMLSecurityException("empty");
/*     */     }
/*     */     
/* 293 */     this.verificationResults = 
/* 294 */       new boolean[this._referencesEl.length];
/*     */     
/* 296 */     for (int i = 
/* 297 */           0; i < this._referencesEl.length; i++) {
/* 298 */       Reference currentRef = 
/* 299 */         new Reference(this._referencesEl[i], this._baseURI, this);
/*     */       
/* 301 */       this._references.set(i, currentRef);
/*     */       
/*     */       try
/*     */       {
/* 305 */         boolean currentRefVerified = currentRef.verify();
/*     */         
/* 307 */         setVerificationResult(i, currentRefVerified);
/*     */         
/* 309 */         if (!currentRefVerified) {
/* 310 */           verify = false;
/*     */         }
/* 312 */         if (log.isDebugEnabled()) {
/* 313 */           log.debug("The Reference has Type " + currentRef.getType());
/*     */         }
/*     */         
/* 316 */         if ((verify) && (followManifests) && 
/* 317 */           (currentRef.typeIsReferenceToManifest())) {
/* 318 */           log.debug("We have to follow a nested Manifest");
/*     */           try
/*     */           {
/* 321 */             XMLSignatureInput signedManifestNodes = 
/* 322 */               currentRef.dereferenceURIandPerformTransforms(null);
/* 323 */             Set nl = signedManifestNodes.getNodeSet();
/* 324 */             Manifest referencedManifest = null;
/* 325 */             Iterator nlIterator = nl.iterator();
/*     */             
/* 327 */             while (nlIterator.hasNext()) {
/* 328 */               Node n = (Node)nlIterator.next();
/*     */               
/* 330 */               if (n.getNodeType() == 1)
/*     */               {
/* 332 */                 if ((((Element)n).getNamespaceURI().equals("http://www.w3.org/2000/09/xmldsig#")) && 
/* 333 */                   (((Element)n).getLocalName().equals("Manifest"))) {
/*     */                   try {
/* 335 */                     referencedManifest = 
/* 336 */                       new Manifest((Element)n, 
/* 337 */                       signedManifestNodes.getSourceURI());
/*     */                   }
/*     */                   catch (XMLSecurityException localXMLSecurityException) {}
/*     */                 }
/*     */               }
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/* 347 */             if (referencedManifest == null)
/*     */             {
/*     */ 
/*     */ 
/* 351 */               throw new MissingResourceFailureException("empty", 
/* 352 */                 currentRef);
/*     */             }
/*     */             
/* 355 */             referencedManifest._perManifestResolvers = 
/* 356 */               this._perManifestResolvers;
/* 357 */             referencedManifest._resolverProperties = 
/* 358 */               this._resolverProperties;
/*     */             
/* 360 */             boolean referencedManifestValid = 
/* 361 */               referencedManifest.verifyReferences(followManifests);
/*     */             
/* 363 */             if (!referencedManifestValid) {
/* 364 */               verify = false;
/*     */               
/* 366 */               log.warn("The nested Manifest was invalid (bad)");
/*     */             } else {
/* 368 */               log.debug("The nested Manifest was valid (good)");
/*     */             }
/*     */           } catch (IOException ex) {
/* 371 */             throw new ReferenceNotInitializedException("empty", ex);
/*     */           } catch (ParserConfigurationException ex) {
/* 373 */             throw new ReferenceNotInitializedException("empty", ex);
/*     */           } catch (SAXException ex) {
/* 375 */             throw new ReferenceNotInitializedException("empty", ex);
/*     */           }
/*     */         }
/*     */       } catch (ReferenceNotInitializedException ex) {
/* 379 */         Object[] exArgs = { currentRef.getURI() };
/*     */         
/* 381 */         throw new MissingResourceFailureException(
/* 382 */           "signature.Verification.Reference.NoInput", exArgs, ex, 
/* 383 */           currentRef);
/*     */       }
/*     */     }
/*     */     
/* 387 */     return verify;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setVerificationResult(int index, boolean verify)
/*     */   {
/* 399 */     if (this.verificationResults == null) {
/* 400 */       this.verificationResults = new boolean[getLength()];
/*     */     }
/*     */     
/* 403 */     this.verificationResults[index] = verify;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getVerificationResult(int index)
/*     */     throws XMLSecurityException
/*     */   {
/* 417 */     if ((index < 0) || (index > getLength() - 1)) {
/* 418 */       Object[] exArgs = { Integer.toString(index), 
/* 419 */         Integer.toString(getLength()) };
/* 420 */       Exception e = 
/* 421 */         new IndexOutOfBoundsException(
/* 422 */         I18n.translate("signature.Verification.IndexOutOfBounds", exArgs));
/*     */       
/* 424 */       throw new XMLSecurityException("generic.EmptyMessage", e);
/*     */     }
/*     */     
/* 427 */     if (this.verificationResults == null) {
/*     */       try {
/* 429 */         verifyReferences();
/*     */       } catch (Exception ex) {
/* 431 */         throw new XMLSecurityException("generic.EmptyMessage", ex);
/*     */       }
/*     */     }
/*     */     
/* 435 */     return this.verificationResults[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addResourceResolver(ResourceResolver resolver)
/*     */   {
/* 445 */     if (resolver == null) {
/* 446 */       return;
/*     */     }
/* 448 */     if (this._perManifestResolvers == null)
/* 449 */       this._perManifestResolvers = new ArrayList();
/* 450 */     this._perManifestResolvers.add(resolver);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addResourceResolver(ResourceResolverSpi resolverSpi)
/*     */   {
/* 461 */     if (resolverSpi == null) {
/* 462 */       return;
/*     */     }
/* 464 */     if (this._perManifestResolvers == null)
/* 465 */       this._perManifestResolvers = new ArrayList();
/* 466 */     this._perManifestResolvers.add(new ResourceResolver(resolverSpi));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResolverProperty(String key, String value)
/*     */   {
/* 478 */     if (this._resolverProperties == null) {
/* 479 */       this._resolverProperties = new HashMap(10);
/*     */     }
/* 481 */     this._resolverProperties.put(key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getResolverProperty(String key)
/*     */   {
/* 491 */     return (String)this._resolverProperties.get(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getSignedContentItem(int i)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 505 */       return getReferencedContentAfterTransformsItem(i).getBytes();
/*     */     } catch (IOException ex) {
/* 507 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (CanonicalizationException ex) {
/* 509 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (InvalidCanonicalizerException ex) {
/* 511 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (XMLSecurityException ex) {
/* 513 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput getReferencedContentBeforeTransformsItem(int i)
/*     */     throws XMLSecurityException
/*     */   {
/* 526 */     return item(i).getContentsBeforeTransformation();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput getReferencedContentAfterTransformsItem(int i)
/*     */     throws XMLSecurityException
/*     */   {
/* 538 */     return item(i).getContentsAfterTransformation();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSignedContentLength()
/*     */   {
/* 547 */     return getLength();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBaseLocalName()
/*     */   {
/* 556 */     return "Manifest";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\signature\Manifest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */