/*    */ package adsi.org.apache.xml.security.utils;
/*    */ 
/*    */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ public abstract class ElementCheckerImpl implements ElementChecker
/*    */ {
/*    */   public boolean isNamespaceElement(org.w3c.dom.Node el, String type, String ns)
/*    */   {
/* 10 */     if ((el == null) || 
/* 11 */       (ns != el.getNamespaceURI()) || (!el.getLocalName().equals(type))) {
/* 12 */       return false;
/*    */     }
/*    */     
/* 15 */     return true;
/*    */   }
/*    */   
/*    */   public static class InternedNsChecker extends ElementCheckerImpl
/*    */   {
/*    */     public void guaranteeThatElementInCorrectSpace(ElementProxy expected, Element actual) throws XMLSecurityException
/*    */     {
/* 22 */       String localnameSHOULDBE = expected.getBaseLocalName();
/* 23 */       String namespaceSHOULDBE = expected.getBaseNamespace();
/*    */       
/* 25 */       String localnameIS = actual.getLocalName();
/* 26 */       String namespaceIS = actual.getNamespaceURI();
/* 27 */       if ((namespaceSHOULDBE != namespaceIS) || 
/* 28 */         (!localnameSHOULDBE.equals(localnameIS))) {
/* 29 */         Object[] exArgs = { namespaceIS + ":" + localnameIS, 
/* 30 */           namespaceSHOULDBE + ":" + localnameSHOULDBE };
/* 31 */         throw new XMLSecurityException("xml.WrongElement", exArgs);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public static class FullChecker
/*    */     extends ElementCheckerImpl
/*    */   {
/*    */     public void guaranteeThatElementInCorrectSpace(ElementProxy expected, Element actual) throws XMLSecurityException
/*    */     {
/* 41 */       String localnameSHOULDBE = expected.getBaseLocalName();
/* 42 */       String namespaceSHOULDBE = expected.getBaseNamespace();
/*    */       
/* 44 */       String localnameIS = actual.getLocalName();
/* 45 */       String namespaceIS = actual.getNamespaceURI();
/* 46 */       if ((!namespaceSHOULDBE.equals(namespaceIS)) || 
/* 47 */         (!localnameSHOULDBE.equals(localnameIS))) {
/* 48 */         Object[] exArgs = { namespaceIS + ":" + localnameIS, 
/* 49 */           namespaceSHOULDBE + ":" + localnameSHOULDBE };
/* 50 */         throw new XMLSecurityException("xml.WrongElement", exArgs);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public static class EmptyChecker
/*    */     extends ElementCheckerImpl
/*    */   {
/*    */     public void guaranteeThatElementInCorrectSpace(ElementProxy expected, Element actual)
/*    */       throws XMLSecurityException
/*    */     {}
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\utils\ElementCheckerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */