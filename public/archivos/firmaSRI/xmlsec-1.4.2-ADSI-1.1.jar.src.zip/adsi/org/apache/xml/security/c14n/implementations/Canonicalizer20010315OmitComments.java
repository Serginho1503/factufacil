/*    */ package adsi.org.apache.xml.security.c14n.implementations;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Canonicalizer20010315OmitComments
/*    */   extends Canonicalizer20010315
/*    */ {
/*    */   public Canonicalizer20010315OmitComments()
/*    */   {
/* 35 */     super(false);
/*    */   }
/*    */   
/*    */   public final String engineGetURI()
/*    */   {
/* 40 */     return "http://www.w3.org/TR/2001/REC-xml-c14n-20010315";
/*    */   }
/*    */   
/*    */   public final boolean engineGetIncludeComments()
/*    */   {
/* 45 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\c14n\implementations\Canonicalizer20010315OmitComments.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */