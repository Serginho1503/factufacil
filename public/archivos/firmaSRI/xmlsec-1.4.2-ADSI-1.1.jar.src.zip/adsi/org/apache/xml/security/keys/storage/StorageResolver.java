/*     */ package adsi.org.apache.xml.security.keys.storage;
/*     */ 
/*     */ import adsi.org.apache.xml.security.keys.storage.implementations.KeyStoreResolver;
/*     */ import adsi.org.apache.xml.security.keys.storage.implementations.SingleCertificateResolver;
/*     */ import java.security.KeyStore;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StorageResolver
/*     */ {
/*  39 */   static Log log = LogFactory.getLog(StorageResolver.class.getName());
/*     */   
/*     */ 
/*  42 */   List _storageResolvers = null;
/*     */   
/*     */ 
/*  45 */   Iterator _iterator = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StorageResolver() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StorageResolver(StorageResolverSpi resolver)
/*     */   {
/*  59 */     add(resolver);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(StorageResolverSpi resolver)
/*     */   {
/*  68 */     if (this._storageResolvers == null)
/*  69 */       this._storageResolvers = new ArrayList();
/*  70 */     this._storageResolvers.add(resolver);
/*     */     
/*  72 */     this._iterator = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StorageResolver(KeyStore keyStore)
/*     */   {
/*  81 */     add(keyStore);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(KeyStore keyStore)
/*     */   {
/*     */     try
/*     */     {
/*  92 */       add(new KeyStoreResolver(keyStore));
/*     */     } catch (StorageResolverException ex) {
/*  94 */       log.error("Could not add KeyStore because of: ", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StorageResolver(X509Certificate x509certificate)
/*     */   {
/* 104 */     add(x509certificate);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(X509Certificate x509certificate)
/*     */   {
/* 113 */     add(new SingleCertificateResolver(x509certificate));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator getIterator()
/*     */   {
/* 123 */     if (this._iterator == null) {
/* 124 */       if (this._storageResolvers == null)
/* 125 */         this._storageResolvers = new ArrayList();
/* 126 */       this._iterator = new StorageResolverIterator(this._storageResolvers.iterator());
/*     */     }
/*     */     
/* 129 */     return this._iterator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasNext()
/*     */   {
/* 139 */     if (this._iterator == null) {
/* 140 */       if (this._storageResolvers == null)
/* 141 */         this._storageResolvers = new ArrayList();
/* 142 */       this._iterator = new StorageResolverIterator(this._storageResolvers.iterator());
/*     */     }
/*     */     
/* 145 */     return this._iterator.hasNext();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Certificate next()
/*     */   {
/* 154 */     return (X509Certificate)this._iterator.next();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static class StorageResolverIterator
/*     */     implements Iterator
/*     */   {
/* 166 */     Iterator _resolvers = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public StorageResolverIterator(Iterator resolvers)
/*     */     {
/* 174 */       this._resolvers = resolvers;
/*     */     }
/*     */     
/*     */     public boolean hasNext()
/*     */     {
/* 179 */       return this._resolvers.hasNext();
/*     */     }
/*     */     
/*     */     public Object next()
/*     */     {
/* 184 */       return this._resolvers.next();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void remove()
/*     */     {
/* 191 */       throw new UnsupportedOperationException(
/* 192 */         "Can't remove keys from KeyStore");
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\storage\StorageResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */