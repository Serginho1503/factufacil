/*     */ package adsi.org.apache.xml.security.transforms.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import adsi.org.apache.xml.security.transforms.Transform;
/*     */ import adsi.org.apache.xml.security.transforms.TransformSpi;
/*     */ import adsi.org.apache.xml.security.transforms.TransformationException;
/*     */ import java.io.IOException;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransformBase64Decode
/*     */   extends TransformSpi
/*     */ {
/*     */   public static final String implementedTransformURI = "http://www.w3.org/2000/09/xmldsig#base64";
/*     */   
/*     */   protected String engineGetURI()
/*     */   {
/*  82 */     return "http://www.w3.org/2000/09/xmldsig#base64";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, Transform _transformObject)
/*     */     throws IOException, CanonicalizationException, TransformationException
/*     */   {
/*  99 */     return enginePerformTransform(input, null, _transformObject);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, java.io.OutputStream os, Transform _transformObject)
/*     */     throws IOException, CanonicalizationException, TransformationException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: invokevirtual 37	adsi/org/apache/xml/security/signature/XMLSignatureInput:isElement	()Z
/*     */     //   4: ifeq +103 -> 107
/*     */     //   7: aload_1
/*     */     //   8: invokevirtual 43	adsi/org/apache/xml/security/signature/XMLSignatureInput:getSubNode	()Lorg/w3c/dom/Node;
/*     */     //   11: astore 4
/*     */     //   13: aload_1
/*     */     //   14: invokevirtual 43	adsi/org/apache/xml/security/signature/XMLSignatureInput:getSubNode	()Lorg/w3c/dom/Node;
/*     */     //   17: invokeinterface 47 1 0
/*     */     //   22: iconst_3
/*     */     //   23: if_icmpne +12 -> 35
/*     */     //   26: aload 4
/*     */     //   28: invokeinterface 53 1 0
/*     */     //   33: astore 4
/*     */     //   35: new 56	java/lang/StringBuffer
/*     */     //   38: dup
/*     */     //   39: invokespecial 58	java/lang/StringBuffer:<init>	()V
/*     */     //   42: astore 5
/*     */     //   44: aload_0
/*     */     //   45: aload 4
/*     */     //   47: checkcast 59	org/w3c/dom/Element
/*     */     //   50: aload 5
/*     */     //   52: invokevirtual 61	adsi/org/apache/xml/security/transforms/implementations/TransformBase64Decode:traverseElement	(Lorg/w3c/dom/Element;Ljava/lang/StringBuffer;)V
/*     */     //   55: aload_2
/*     */     //   56: ifnonnull +23 -> 79
/*     */     //   59: aload 5
/*     */     //   61: invokevirtual 65	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*     */     //   64: invokestatic 68	adsi/org/apache/xml/security/utils/Base64:decode	(Ljava/lang/String;)[B
/*     */     //   67: astore 6
/*     */     //   69: new 38	adsi/org/apache/xml/security/signature/XMLSignatureInput
/*     */     //   72: dup
/*     */     //   73: aload 6
/*     */     //   75: invokespecial 74	adsi/org/apache/xml/security/signature/XMLSignatureInput:<init>	([B)V
/*     */     //   78: areturn
/*     */     //   79: aload 5
/*     */     //   81: invokevirtual 65	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*     */     //   84: aload_2
/*     */     //   85: invokestatic 77	adsi/org/apache/xml/security/utils/Base64:decode	(Ljava/lang/String;Ljava/io/OutputStream;)V
/*     */     //   88: new 38	adsi/org/apache/xml/security/signature/XMLSignatureInput
/*     */     //   91: dup
/*     */     //   92: aconst_null
/*     */     //   93: invokespecial 74	adsi/org/apache/xml/security/signature/XMLSignatureInput:<init>	([B)V
/*     */     //   96: astore 6
/*     */     //   98: aload 6
/*     */     //   100: aload_2
/*     */     //   101: invokevirtual 80	adsi/org/apache/xml/security/signature/XMLSignatureInput:setOutputStream	(Ljava/io/OutputStream;)V
/*     */     //   104: aload 6
/*     */     //   106: areturn
/*     */     //   107: aload_1
/*     */     //   108: invokevirtual 84	adsi/org/apache/xml/security/signature/XMLSignatureInput:isOctetStream	()Z
/*     */     //   111: ifne +10 -> 121
/*     */     //   114: aload_1
/*     */     //   115: invokevirtual 87	adsi/org/apache/xml/security/signature/XMLSignatureInput:isNodeSet	()Z
/*     */     //   118: ifeq +89 -> 207
/*     */     //   121: aload_2
/*     */     //   122: ifnonnull +26 -> 148
/*     */     //   125: aload_1
/*     */     //   126: invokevirtual 90	adsi/org/apache/xml/security/signature/XMLSignatureInput:getBytes	()[B
/*     */     //   129: astore 4
/*     */     //   131: aload 4
/*     */     //   133: invokestatic 94	adsi/org/apache/xml/security/utils/Base64:decode	([B)[B
/*     */     //   136: astore 5
/*     */     //   138: new 38	adsi/org/apache/xml/security/signature/XMLSignatureInput
/*     */     //   141: dup
/*     */     //   142: aload 5
/*     */     //   144: invokespecial 74	adsi/org/apache/xml/security/signature/XMLSignatureInput:<init>	([B)V
/*     */     //   147: areturn
/*     */     //   148: aload_1
/*     */     //   149: invokevirtual 97	adsi/org/apache/xml/security/signature/XMLSignatureInput:isByteArray	()Z
/*     */     //   152: ifne +10 -> 162
/*     */     //   155: aload_1
/*     */     //   156: invokevirtual 87	adsi/org/apache/xml/security/signature/XMLSignatureInput:isNodeSet	()Z
/*     */     //   159: ifeq +14 -> 173
/*     */     //   162: aload_1
/*     */     //   163: invokevirtual 90	adsi/org/apache/xml/security/signature/XMLSignatureInput:getBytes	()[B
/*     */     //   166: aload_2
/*     */     //   167: invokestatic 100	adsi/org/apache/xml/security/utils/Base64:decode	([BLjava/io/OutputStream;)V
/*     */     //   170: goto +18 -> 188
/*     */     //   173: new 103	java/io/BufferedInputStream
/*     */     //   176: dup
/*     */     //   177: aload_1
/*     */     //   178: invokevirtual 105	adsi/org/apache/xml/security/signature/XMLSignatureInput:getOctetStreamReal	()Ljava/io/InputStream;
/*     */     //   181: invokespecial 109	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
/*     */     //   184: aload_2
/*     */     //   185: invokestatic 112	adsi/org/apache/xml/security/utils/Base64:decode	(Ljava/io/InputStream;Ljava/io/OutputStream;)V
/*     */     //   188: new 38	adsi/org/apache/xml/security/signature/XMLSignatureInput
/*     */     //   191: dup
/*     */     //   192: aconst_null
/*     */     //   193: invokespecial 74	adsi/org/apache/xml/security/signature/XMLSignatureInput:<init>	([B)V
/*     */     //   196: astore 4
/*     */     //   198: aload 4
/*     */     //   200: aload_2
/*     */     //   201: invokevirtual 80	adsi/org/apache/xml/security/signature/XMLSignatureInput:setOutputStream	(Ljava/io/OutputStream;)V
/*     */     //   204: aload 4
/*     */     //   206: areturn
/*     */     //   207: invokestatic 115	javax/xml/parsers/DocumentBuilderFactory:newInstance	()Ljavax/xml/parsers/DocumentBuilderFactory;
/*     */     //   210: invokevirtual 121	javax/xml/parsers/DocumentBuilderFactory:newDocumentBuilder	()Ljavax/xml/parsers/DocumentBuilder;
/*     */     //   213: aload_1
/*     */     //   214: invokevirtual 125	adsi/org/apache/xml/security/signature/XMLSignatureInput:getOctetStream	()Ljava/io/InputStream;
/*     */     //   217: invokevirtual 128	javax/xml/parsers/DocumentBuilder:parse	(Ljava/io/InputStream;)Lorg/w3c/dom/Document;
/*     */     //   220: astore 4
/*     */     //   222: aload 4
/*     */     //   224: invokeinterface 134 1 0
/*     */     //   229: astore 5
/*     */     //   231: new 56	java/lang/StringBuffer
/*     */     //   234: dup
/*     */     //   235: invokespecial 58	java/lang/StringBuffer:<init>	()V
/*     */     //   238: astore 6
/*     */     //   240: aload_0
/*     */     //   241: aload 5
/*     */     //   243: aload 6
/*     */     //   245: invokevirtual 61	adsi/org/apache/xml/security/transforms/implementations/TransformBase64Decode:traverseElement	(Lorg/w3c/dom/Element;Ljava/lang/StringBuffer;)V
/*     */     //   248: aload 6
/*     */     //   250: invokevirtual 65	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*     */     //   253: invokestatic 68	adsi/org/apache/xml/security/utils/Base64:decode	(Ljava/lang/String;)[B
/*     */     //   256: astore 7
/*     */     //   258: new 38	adsi/org/apache/xml/security/signature/XMLSignatureInput
/*     */     //   261: dup
/*     */     //   262: aload 7
/*     */     //   264: invokespecial 74	adsi/org/apache/xml/security/signature/XMLSignatureInput:<init>	([B)V
/*     */     //   267: areturn
/*     */     //   268: astore 4
/*     */     //   270: new 28	adsi/org/apache/xml/security/transforms/TransformationException
/*     */     //   273: dup
/*     */     //   274: ldc -116
/*     */     //   276: aload 4
/*     */     //   278: invokespecial 142	adsi/org/apache/xml/security/transforms/TransformationException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
/*     */     //   281: athrow
/*     */     //   282: astore 4
/*     */     //   284: new 28	adsi/org/apache/xml/security/transforms/TransformationException
/*     */     //   287: dup
/*     */     //   288: ldc -111
/*     */     //   290: aload 4
/*     */     //   292: invokespecial 142	adsi/org/apache/xml/security/transforms/TransformationException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
/*     */     //   295: athrow
/*     */     //   296: astore 4
/*     */     //   298: new 28	adsi/org/apache/xml/security/transforms/TransformationException
/*     */     //   301: dup
/*     */     //   302: ldc -109
/*     */     //   304: aload 4
/*     */     //   306: invokespecial 142	adsi/org/apache/xml/security/transforms/TransformationException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
/*     */     //   309: athrow
/*     */     // Line number table:
/*     */     //   Java source line #107	-> byte code offset #0
/*     */     //   Java source line #108	-> byte code offset #7
/*     */     //   Java source line #109	-> byte code offset #13
/*     */     //   Java source line #110	-> byte code offset #26
/*     */     //   Java source line #112	-> byte code offset #35
/*     */     //   Java source line #113	-> byte code offset #44
/*     */     //   Java source line #114	-> byte code offset #55
/*     */     //   Java source line #115	-> byte code offset #59
/*     */     //   Java source line #116	-> byte code offset #69
/*     */     //   Java source line #118	-> byte code offset #79
/*     */     //   Java source line #119	-> byte code offset #88
/*     */     //   Java source line #120	-> byte code offset #98
/*     */     //   Java source line #121	-> byte code offset #104
/*     */     //   Java source line #124	-> byte code offset #107
/*     */     //   Java source line #127	-> byte code offset #121
/*     */     //   Java source line #128	-> byte code offset #125
/*     */     //   Java source line #129	-> byte code offset #131
/*     */     //   Java source line #130	-> byte code offset #138
/*     */     //   Java source line #132	-> byte code offset #148
/*     */     //   Java source line #133	-> byte code offset #162
/*     */     //   Java source line #135	-> byte code offset #173
/*     */     //   Java source line #136	-> byte code offset #184
/*     */     //   Java source line #135	-> byte code offset #185
/*     */     //   Java source line #138	-> byte code offset #188
/*     */     //   Java source line #139	-> byte code offset #198
/*     */     //   Java source line #140	-> byte code offset #204
/*     */     //   Java source line #149	-> byte code offset #207
/*     */     //   Java source line #150	-> byte code offset #213
/*     */     //   Java source line #149	-> byte code offset #217
/*     */     //   Java source line #148	-> byte code offset #220
/*     */     //   Java source line #152	-> byte code offset #222
/*     */     //   Java source line #153	-> byte code offset #231
/*     */     //   Java source line #154	-> byte code offset #240
/*     */     //   Java source line #155	-> byte code offset #248
/*     */     //   Java source line #157	-> byte code offset #258
/*     */     //   Java source line #158	-> byte code offset #268
/*     */     //   Java source line #159	-> byte code offset #270
/*     */     //   Java source line #160	-> byte code offset #282
/*     */     //   Java source line #161	-> byte code offset #284
/*     */     //   Java source line #163	-> byte code offset #296
/*     */     //   Java source line #164	-> byte code offset #298
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	310	0	this	TransformBase64Decode
/*     */     //   0	310	1	input	XMLSignatureInput
/*     */     //   0	310	2	os	java.io.OutputStream
/*     */     //   0	310	3	_transformObject	Transform
/*     */     //   11	35	4	el	Node
/*     */     //   129	3	4	base64Bytes	byte[]
/*     */     //   196	9	4	output	XMLSignatureInput
/*     */     //   220	3	4	doc	org.w3c.dom.Document
/*     */     //   268	9	4	e	javax.xml.parsers.ParserConfigurationException
/*     */     //   282	9	4	e	org.xml.sax.SAXException
/*     */     //   296	9	4	e	adsi.org.apache.xml.security.exceptions.Base64DecodingException
/*     */     //   42	38	5	sb	StringBuffer
/*     */     //   136	7	5	decodedBytes	byte[]
/*     */     //   229	13	5	rootNode	Element
/*     */     //   67	7	6	decodedBytes	byte[]
/*     */     //   96	9	6	output	XMLSignatureInput
/*     */     //   238	11	6	sb	StringBuffer
/*     */     //   256	7	7	decodedBytes	byte[]
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   207	267	268	javax/xml/parsers/ParserConfigurationException
/*     */     //   207	267	282	org/xml/sax/SAXException
/*     */     //   0	78	296	adsi/org/apache/xml/security/exceptions/Base64DecodingException
/*     */     //   79	106	296	adsi/org/apache/xml/security/exceptions/Base64DecodingException
/*     */     //   107	147	296	adsi/org/apache/xml/security/exceptions/Base64DecodingException
/*     */     //   148	206	296	adsi/org/apache/xml/security/exceptions/Base64DecodingException
/*     */     //   207	267	296	adsi/org/apache/xml/security/exceptions/Base64DecodingException
/*     */     //   268	296	296	adsi/org/apache/xml/security/exceptions/Base64DecodingException
/*     */   }
/*     */   
/*     */   void traverseElement(Element node, StringBuffer sb)
/*     */   {
/* 169 */     Node sibling = node.getFirstChild();
/* 170 */     while (sibling != null) {
/* 171 */       switch (sibling.getNodeType()) {
/*     */       case 1: 
/* 173 */         traverseElement((Element)sibling, sb);
/* 174 */         break;
/*     */       case 3: 
/* 176 */         sb.append(((Text)sibling).getData());
/*     */       }
/* 178 */       sibling = sibling.getNextSibling();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\transforms\implementations\TransformBase64Decode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */