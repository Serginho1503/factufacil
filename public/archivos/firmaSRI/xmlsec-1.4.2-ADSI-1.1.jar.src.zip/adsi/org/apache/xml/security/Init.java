/*     */ package adsi.org.apache.xml.security;
/*     */ 
/*     */ import adsi.org.apache.xml.security.algorithms.JCEMapper;
/*     */ import adsi.org.apache.xml.security.algorithms.SignatureAlgorithm;
/*     */ import adsi.org.apache.xml.security.c14n.Canonicalizer;
/*     */ import adsi.org.apache.xml.security.keys.KeyInfo;
/*     */ import adsi.org.apache.xml.security.keys.keyresolver.KeyResolver;
/*     */ import adsi.org.apache.xml.security.transforms.Transform;
/*     */ import adsi.org.apache.xml.security.utils.ElementProxy;
/*     */ import adsi.org.apache.xml.security.utils.I18n;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolver;
/*     */ import java.io.InputStream;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Init
/*     */ {
/*  54 */   static Log log = LogFactory.getLog(Init.class.getName());
/*     */   
/*     */ 
/*  57 */   private static boolean _alreadyInitialized = false;
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String CONF_NS = "http://www.xmlsecurity.org/NS/#configuration";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final boolean isInitialized()
/*     */   {
/*  68 */     return _alreadyInitialized;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized void init()
/*     */   {
/*  77 */     if (_alreadyInitialized) {
/*  78 */       return;
/*     */     }
/*  80 */     long XX_configure_i18n_end = 0L;
/*  81 */     long XX_configure_reg_c14n_start = 0L;
/*  82 */     long XX_configure_reg_c14n_end = 0L;
/*  83 */     long XX_configure_reg_jcemapper_end = 0L;
/*  84 */     long XX_configure_reg_keyInfo_start = 0L;
/*  85 */     long XX_configure_reg_keyResolver_end = 0L;
/*  86 */     long XX_configure_reg_prefixes_start = 0L;
/*  87 */     long XX_configure_reg_resourceresolver_start = 0L;
/*  88 */     long XX_configure_reg_sigalgos_end = 0L;
/*  89 */     long XX_configure_reg_transforms_end = 0L;
/*  90 */     long XX_configure_reg_keyInfo_end = 0L;
/*  91 */     long XX_configure_reg_keyResolver_start = 0L;
/*  92 */     _alreadyInitialized = true;
/*     */     try
/*     */     {
/*  95 */       long XX_init_start = System.currentTimeMillis();
/*  96 */       long XX_prng_start = System.currentTimeMillis();
/*     */       
/*     */ 
/*     */ 
/* 100 */       long XX_prng_end = System.currentTimeMillis();
/*     */       
/*     */ 
/* 103 */       long XX_parsing_start = System.currentTimeMillis();
/* 104 */       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/*     */       
/* 106 */       dbf.setNamespaceAware(true);
/* 107 */       dbf.setValidating(false);
/*     */       
/* 109 */       DocumentBuilder db = dbf.newDocumentBuilder();
/*     */       
/* 111 */       InputStream is = (InputStream)AccessController.doPrivileged(
/* 112 */         new PrivilegedAction() {
/*     */           public Object run() {
/* 114 */             String cfile = System.getProperty(
/* 115 */               "adsi.org.apache.xml.security.resource.config");
/* 116 */             return getClass().getResourceAsStream(
/* 117 */               cfile != null ? cfile : "resource/config.xml");
/*     */           }
/*     */           
/* 120 */         });
/* 121 */       Document doc = db.parse(is);
/* 122 */       long XX_parsing_end = System.currentTimeMillis();
/* 123 */       long XX_configure_i18n_start = 0L;
/*     */       
/*     */ 
/* 126 */       XX_configure_reg_keyInfo_start = System.currentTimeMillis();
/*     */       try {
/* 128 */         KeyInfo.init();
/*     */       } catch (Exception e) {
/* 130 */         e.printStackTrace();
/*     */         
/* 132 */         throw e;
/*     */       }
/* 134 */       XX_configure_reg_keyInfo_end = System.currentTimeMillis();
/*     */       
/*     */ 
/* 137 */       long XX_configure_reg_transforms_start = 0L;
/* 138 */       long XX_configure_reg_jcemapper_start = 0L;
/* 139 */       long XX_configure_reg_sigalgos_start = 0L;
/* 140 */       long XX_configure_reg_resourceresolver_end = 0L;
/* 141 */       long XX_configure_reg_prefixes_end = 0L;
/* 142 */       for (Node config = doc.getFirstChild(); 
/* 143 */           config != null; config = config.getNextSibling()) {
/* 144 */         if ("Configuration".equals(config.getLocalName())) {
/*     */           break;
/*     */         }
/*     */       }
/* 148 */       for (Node el = config.getFirstChild(); el != null; el = el.getNextSibling()) {
/* 149 */         if ((el instanceof Element))
/*     */         {
/*     */ 
/* 152 */           String tag = el.getLocalName();
/* 153 */           if (tag.equals("ResourceBundles")) {
/* 154 */             XX_configure_i18n_start = System.currentTimeMillis();
/* 155 */             Element resource = (Element)el;
/*     */             
/* 157 */             Attr langAttr = resource.getAttributeNode("defaultLanguageCode");
/* 158 */             Attr countryAttr = resource.getAttributeNode("defaultCountryCode");
/* 159 */             String languageCode = langAttr == null ? 
/* 160 */               null : 
/* 161 */               langAttr.getNodeValue();
/* 162 */             String countryCode = countryAttr == null ? 
/* 163 */               null : 
/* 164 */               countryAttr.getNodeValue();
/*     */             
/* 166 */             I18n.init(languageCode, countryCode);
/* 167 */             XX_configure_i18n_end = System.currentTimeMillis();
/*     */           }
/*     */           
/* 170 */           if (tag.equals("CanonicalizationMethods")) {
/* 171 */             XX_configure_reg_c14n_start = System.currentTimeMillis();
/* 172 */             Canonicalizer.init();
/* 173 */             Element[] list = XMLUtils.selectNodes(el.getFirstChild(), "http://www.xmlsecurity.org/NS/#configuration", "CanonicalizationMethod");
/*     */             
/* 175 */             for (int i = 0; i < list.length; i++) {
/* 176 */               String URI = list[i].getAttributeNS(null, 
/* 177 */                 "URI");
/* 178 */               String JAVACLASS = 
/* 179 */                 list[i].getAttributeNS(null, 
/* 180 */                 "JAVACLASS");
/*     */               try {
/* 182 */                 Class.forName(JAVACLASS);
/*     */                 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 193 */                 if (log.isDebugEnabled())
/* 194 */                   log.debug("Canonicalizer.register(" + URI + ", " + 
/* 195 */                     JAVACLASS + ")");
/* 196 */                 Canonicalizer.register(URI, JAVACLASS);
/*     */               } catch (ClassNotFoundException e) {
/* 198 */                 Object[] exArgs = { URI, JAVACLASS };
/*     */                 
/* 200 */                 log.fatal(I18n.translate("algorithm.classDoesNotExist", 
/* 201 */                   exArgs));
/*     */               }
/*     */             }
/* 204 */             XX_configure_reg_c14n_end = System.currentTimeMillis();
/*     */           }
/*     */           
/* 207 */           if (tag.equals("TransformAlgorithms")) {
/* 208 */             XX_configure_reg_transforms_start = System.currentTimeMillis();
/* 209 */             Transform.init();
/*     */             
/* 211 */             Element[] tranElem = XMLUtils.selectNodes(el.getFirstChild(), "http://www.xmlsecurity.org/NS/#configuration", "TransformAlgorithm");
/*     */             
/* 213 */             for (int i = 0; i < tranElem.length; i++) {
/* 214 */               String URI = tranElem[i].getAttributeNS(null, 
/* 215 */                 "URI");
/* 216 */               String JAVACLASS = 
/* 217 */                 tranElem[i].getAttributeNS(null, 
/* 218 */                 "JAVACLASS");
/*     */               try {
/* 220 */                 Class.forName(JAVACLASS);
/* 221 */                 if (log.isDebugEnabled())
/* 222 */                   log.debug("Transform.register(" + URI + ", " + JAVACLASS + 
/* 223 */                     ")");
/* 224 */                 Transform.register(URI, JAVACLASS);
/*     */               } catch (ClassNotFoundException e) {
/* 226 */                 Object[] exArgs = { URI, JAVACLASS };
/*     */                 
/* 228 */                 log.fatal(I18n.translate("algorithm.classDoesNotExist", 
/* 229 */                   exArgs));
/*     */               }
/*     */               catch (NoClassDefFoundError ex) {
/* 232 */                 log.warn("Not able to found dependecies for algorithm, I'm keep working.");
/*     */               }
/*     */             }
/* 235 */             XX_configure_reg_transforms_end = System.currentTimeMillis();
/*     */           }
/*     */           
/*     */ 
/* 239 */           if ("JCEAlgorithmMappings".equals(tag)) {
/* 240 */             XX_configure_reg_jcemapper_start = System.currentTimeMillis();
/* 241 */             JCEMapper.init((Element)el);
/* 242 */             XX_configure_reg_jcemapper_end = System.currentTimeMillis();
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 247 */           if (tag.equals("SignatureAlgorithms")) {
/* 248 */             XX_configure_reg_sigalgos_start = System.currentTimeMillis();
/* 249 */             SignatureAlgorithm.providerInit();
/*     */             
/* 251 */             Element[] sigElems = XMLUtils.selectNodes(el.getFirstChild(), "http://www.xmlsecurity.org/NS/#configuration", 
/* 252 */               "SignatureAlgorithm");
/*     */             
/* 254 */             for (int i = 0; i < sigElems.length; i++) {
/* 255 */               String URI = sigElems[i].getAttributeNS(null, 
/* 256 */                 "URI");
/* 257 */               String JAVACLASS = 
/* 258 */                 sigElems[i].getAttributeNS(null, 
/* 259 */                 "JAVACLASS");
/*     */               
/*     */ 
/*     */               try
/*     */               {
/* 264 */                 Class.forName(JAVACLASS);
/*     */                 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 275 */                 if (log.isDebugEnabled())
/* 276 */                   log.debug("SignatureAlgorithm.register(" + URI + ", " + 
/* 277 */                     JAVACLASS + ")");
/* 278 */                 SignatureAlgorithm.register(URI, JAVACLASS);
/*     */               } catch (ClassNotFoundException e) {
/* 280 */                 Object[] exArgs = { URI, JAVACLASS };
/*     */                 
/* 282 */                 log.fatal(I18n.translate("algorithm.classDoesNotExist", 
/* 283 */                   exArgs));
/*     */               }
/*     */             }
/*     */             
/* 287 */             XX_configure_reg_sigalgos_end = System.currentTimeMillis();
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 292 */           if (tag.equals("ResourceResolvers")) {
/* 293 */             XX_configure_reg_resourceresolver_start = System.currentTimeMillis();
/* 294 */             ResourceResolver.init();
/*     */             
/* 296 */             Element[] resolverElem = XMLUtils.selectNodes(el.getFirstChild(), "http://www.xmlsecurity.org/NS/#configuration", 
/* 297 */               "Resolver");
/*     */             
/* 299 */             for (int i = 0; i < resolverElem.length; i++) {
/* 300 */               String JAVACLASS = 
/* 301 */                 resolverElem[i].getAttributeNS(null, 
/* 302 */                 "JAVACLASS");
/* 303 */               String Description = 
/* 304 */                 resolverElem[i].getAttributeNS(null, 
/* 305 */                 "DESCRIPTION");
/*     */               
/* 307 */               if ((Description != null) && (Description.length() > 0)) {
/* 308 */                 if (log.isDebugEnabled()) {
/* 309 */                   log.debug("Register Resolver: " + JAVACLASS + ": " + 
/* 310 */                     Description);
/*     */                 }
/* 312 */               } else if (log.isDebugEnabled()) {
/* 313 */                 log.debug("Register Resolver: " + JAVACLASS + 
/* 314 */                   ": For unknown purposes");
/*     */               }
/*     */               try {
/* 317 */                 ResourceResolver.register(JAVACLASS);
/*     */               } catch (Throwable e) {
/* 319 */                 log.warn("Cannot register:" + JAVACLASS + " perhaps some needed jars are not installed", e);
/*     */               }
/* 321 */               XX_configure_reg_resourceresolver_end = 
/* 322 */                 System.currentTimeMillis();
/*     */             }
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 332 */           if (tag.equals("KeyResolver")) {
/* 333 */             XX_configure_reg_keyResolver_start = System.currentTimeMillis();
/* 334 */             KeyResolver.init();
/*     */             
/* 336 */             Element[] resolverElem = XMLUtils.selectNodes(el.getFirstChild(), "http://www.xmlsecurity.org/NS/#configuration", "Resolver");
/*     */             
/* 338 */             for (int i = 0; i < resolverElem.length; i++) {
/* 339 */               String JAVACLASS = 
/* 340 */                 resolverElem[i].getAttributeNS(null, 
/* 341 */                 "JAVACLASS");
/* 342 */               String Description = 
/* 343 */                 resolverElem[i].getAttributeNS(null, 
/* 344 */                 "DESCRIPTION");
/*     */               
/* 346 */               if ((Description != null) && (Description.length() > 0)) {
/* 347 */                 if (log.isDebugEnabled()) {
/* 348 */                   log.debug("Register Resolver: " + JAVACLASS + ": " + 
/* 349 */                     Description);
/*     */                 }
/* 351 */               } else if (log.isDebugEnabled()) {
/* 352 */                 log.debug("Register Resolver: " + JAVACLASS + 
/* 353 */                   ": For unknown purposes");
/*     */               }
/*     */               
/* 356 */               KeyResolver.register(JAVACLASS);
/*     */             }
/* 358 */             XX_configure_reg_keyResolver_end = System.currentTimeMillis();
/*     */           }
/*     */           
/*     */ 
/* 362 */           if (tag.equals("PrefixMappings")) {
/* 363 */             XX_configure_reg_prefixes_start = System.currentTimeMillis();
/* 364 */             if (log.isDebugEnabled()) {
/* 365 */               log.debug("Now I try to bind prefixes:");
/*     */             }
/* 367 */             Element[] nl = XMLUtils.selectNodes(el.getFirstChild(), "http://www.xmlsecurity.org/NS/#configuration", "PrefixMapping");
/*     */             
/* 369 */             for (int i = 0; i < nl.length; i++) {
/* 370 */               String namespace = nl[i].getAttributeNS(null, 
/* 371 */                 "namespace");
/* 372 */               String prefix = nl[i].getAttributeNS(null, 
/* 373 */                 "prefix");
/* 374 */               if (log.isDebugEnabled()) {
/* 375 */                 log.debug("Now I try to bind " + prefix + " to " + namespace);
/*     */               }
/* 377 */               ElementProxy.setDefaultPrefix(namespace, prefix);
/*     */             }
/* 379 */             XX_configure_reg_prefixes_end = System.currentTimeMillis();
/*     */           }
/*     */         }
/*     */       }
/* 383 */       long XX_init_end = System.currentTimeMillis();
/*     */       
/*     */ 
/* 386 */       if (log.isDebugEnabled()) {
/* 387 */         log.debug("XX_init                             " + (int)(XX_init_end - XX_init_start) + " ms");
/* 388 */         log.debug("  XX_prng                           " + (int)(XX_prng_end - XX_prng_start) + " ms");
/* 389 */         log.debug("  XX_parsing                        " + (int)(XX_parsing_end - XX_parsing_start) + " ms");
/* 390 */         log.debug("  XX_configure_i18n                 " + (int)(XX_configure_i18n_end - XX_configure_i18n_start) + " ms");
/* 391 */         log.debug("  XX_configure_reg_c14n             " + (int)(XX_configure_reg_c14n_end - XX_configure_reg_c14n_start) + " ms");
/* 392 */         log.debug("  XX_configure_reg_jcemapper        " + (int)(XX_configure_reg_jcemapper_end - XX_configure_reg_jcemapper_start) + " ms");
/* 393 */         log.debug("  XX_configure_reg_keyInfo          " + (int)(XX_configure_reg_keyInfo_end - XX_configure_reg_keyInfo_start) + " ms");
/* 394 */         log.debug("  XX_configure_reg_keyResolver      " + (int)(XX_configure_reg_keyResolver_end - XX_configure_reg_keyResolver_start) + " ms");
/* 395 */         log.debug("  XX_configure_reg_prefixes         " + (int)(XX_configure_reg_prefixes_end - XX_configure_reg_prefixes_start) + " ms");
/* 396 */         log.debug("  XX_configure_reg_resourceresolver " + (int)(XX_configure_reg_resourceresolver_end - XX_configure_reg_resourceresolver_start) + " ms");
/* 397 */         log.debug("  XX_configure_reg_sigalgos         " + (int)(XX_configure_reg_sigalgos_end - XX_configure_reg_sigalgos_start) + " ms");
/* 398 */         log.debug("  XX_configure_reg_transforms       " + (int)(XX_configure_reg_transforms_end - XX_configure_reg_transforms_start) + " ms");
/*     */       }
/*     */     } catch (Exception e) {
/* 401 */       log.fatal("Bad: ", e);
/* 402 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\Init.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */