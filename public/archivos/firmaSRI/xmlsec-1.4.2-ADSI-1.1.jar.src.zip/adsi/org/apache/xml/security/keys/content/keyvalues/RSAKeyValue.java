/*     */ package adsi.org.apache.xml.security.keys.content.keyvalues;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.utils.I18n;
/*     */ import adsi.org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.math.BigInteger;
/*     */ import java.security.Key;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PublicKey;
/*     */ import java.security.interfaces.RSAPublicKey;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import java.security.spec.RSAPublicKeySpec;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RSAKeyValue
/*     */   extends SignatureElementProxy
/*     */   implements KeyValueContent
/*     */ {
/*     */   public RSAKeyValue(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  53 */     super(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RSAKeyValue(Document doc, BigInteger modulus, BigInteger exponent)
/*     */   {
/*  65 */     super(doc);
/*     */     
/*  67 */     XMLUtils.addReturnToElement(this._constructionElement);
/*  68 */     addBigIntegerElement(modulus, "Modulus");
/*  69 */     addBigIntegerElement(exponent, "Exponent");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RSAKeyValue(Document doc, Key key)
/*     */     throws IllegalArgumentException
/*     */   {
/*  81 */     super(doc);
/*     */     
/*  83 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */     
/*  85 */     if ((key instanceof RSAPublicKey)) {
/*  86 */       addBigIntegerElement(((RSAPublicKey)key).getModulus(), 
/*  87 */         "Modulus");
/*  88 */       addBigIntegerElement(((RSAPublicKey)key).getPublicExponent(), 
/*  89 */         "Exponent");
/*     */     } else {
/*  91 */       Object[] exArgs = { "RSAKeyValue", 
/*  92 */         key.getClass().getName() };
/*     */       
/*  94 */       throw new IllegalArgumentException(
/*  95 */         I18n.translate("KeyValue.IllegalArgument", exArgs));
/*     */     }
/*     */   }
/*     */   
/*     */   public PublicKey getPublicKey() throws XMLSecurityException
/*     */   {
/*     */     try
/*     */     {
/* 103 */       KeyFactory rsaFactory = KeyFactory.getInstance("RSA");
/*     */       
/*     */ 
/* 106 */       RSAPublicKeySpec rsaKeyspec = 
/* 107 */         new RSAPublicKeySpec(
/* 108 */         getBigIntegerFromChildElement("Modulus", "http://www.w3.org/2000/09/xmldsig#"), 
/*     */         
/* 110 */         getBigIntegerFromChildElement("Exponent", 
/* 111 */         "http://www.w3.org/2000/09/xmldsig#"));
/* 112 */       return rsaFactory.generatePublic(rsaKeyspec);
/*     */     }
/*     */     catch (NoSuchAlgorithmException ex)
/*     */     {
/* 116 */       throw new XMLSecurityException("empty", ex);
/*     */     } catch (InvalidKeySpecException ex) {
/* 118 */       throw new XMLSecurityException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 124 */     return "RSAKeyValue";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\content\keyvalues\RSAKeyValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */