/*    */ package adsi.org.apache.xml.security.utils;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnsyncBufferedOutputStream
/*    */   extends OutputStream
/*    */ {
/*    */   final OutputStream out;
/*    */   final byte[] buf;
/*    */   static final int size = 8192;
/* 32 */   private static ThreadLocal bufCahce = new ThreadLocal() {
/*    */     protected synchronized Object initialValue() {
/* 34 */       return new byte[' '];
/*    */     }
/*    */   };
/* 37 */   int pointer = 0;
/*    */   
/*    */ 
/*    */ 
/*    */   public UnsyncBufferedOutputStream(OutputStream out)
/*    */   {
/* 43 */     this.buf = ((byte[])bufCahce.get());
/* 44 */     this.out = out;
/*    */   }
/*    */   
/*    */   public void write(byte[] arg0) throws IOException
/*    */   {
/* 49 */     write(arg0, 0, arg0.length);
/*    */   }
/*    */   
/*    */   public void write(byte[] arg0, int arg1, int len) throws IOException
/*    */   {
/* 54 */     int newLen = this.pointer + len;
/* 55 */     if (newLen > 8192) {
/* 56 */       flushBuffer();
/* 57 */       if (len > 8192) {
/* 58 */         this.out.write(arg0, arg1, len);
/* 59 */         return;
/*    */       }
/* 61 */       newLen = len;
/*    */     }
/* 63 */     System.arraycopy(arg0, arg1, this.buf, this.pointer, len);
/* 64 */     this.pointer = newLen;
/*    */   }
/*    */   
/*    */   private final void flushBuffer() throws IOException {
/* 68 */     if (this.pointer > 0)
/* 69 */       this.out.write(this.buf, 0, this.pointer);
/* 70 */     this.pointer = 0;
/*    */   }
/*    */   
/*    */   public void write(int arg0)
/*    */     throws IOException
/*    */   {
/* 76 */     if (this.pointer >= 8192) {
/* 77 */       flushBuffer();
/*    */     }
/* 79 */     this.buf[(this.pointer++)] = ((byte)arg0);
/*    */   }
/*    */   
/*    */   public void flush()
/*    */     throws IOException
/*    */   {
/* 85 */     flushBuffer();
/* 86 */     this.out.flush();
/*    */   }
/*    */   
/*    */   public void close() throws IOException
/*    */   {
/* 91 */     flush();
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\utils\UnsyncBufferedOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */