/*    */ package adsi.org.apache.xml.security.keys.keyresolver.implementations;
/*    */ 
/*    */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*    */ import adsi.org.apache.xml.security.keys.content.keyvalues.RSAKeyValue;
/*    */ import adsi.org.apache.xml.security.keys.keyresolver.KeyResolverSpi;
/*    */ import adsi.org.apache.xml.security.keys.storage.StorageResolver;
/*    */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*    */ import java.security.PublicKey;
/*    */ import java.security.cert.X509Certificate;
/*    */ import javax.crypto.SecretKey;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RSAKeyValueResolver
/*    */   extends KeyResolverSpi
/*    */ {
/* 44 */   static Log log = LogFactory.getLog(
/* 45 */     RSAKeyValueResolver.class.getName());
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PublicKey engineLookupAndResolvePublicKey(Element element, String BaseURI, StorageResolver storage)
/*    */   {
/* 53 */     if (log.isDebugEnabled())
/* 54 */       log.debug("Can I resolve " + element.getTagName());
/* 55 */     if (element == null) {
/* 56 */       return null;
/*    */     }
/*    */     
/* 59 */     boolean isKeyValue = XMLUtils.elementIsInSignatureSpace(element, 
/* 60 */       "KeyValue");
/* 61 */     Element rsaKeyElement = null;
/* 62 */     if (isKeyValue) {
/* 63 */       rsaKeyElement = XMLUtils.selectDsNode(element.getFirstChild(), 
/* 64 */         "RSAKeyValue", 0);
/* 65 */     } else if (XMLUtils.elementIsInSignatureSpace(element, 
/* 66 */       "RSAKeyValue"))
/*    */     {
/*    */ 
/* 69 */       rsaKeyElement = element;
/*    */     }
/*    */     
/*    */ 
/* 73 */     if (rsaKeyElement == null) {
/* 74 */       return null;
/*    */     }
/*    */     try
/*    */     {
/* 78 */       RSAKeyValue rsaKeyValue = new RSAKeyValue(rsaKeyElement, 
/* 79 */         BaseURI);
/*    */       
/* 81 */       return rsaKeyValue.getPublicKey();
/*    */     } catch (XMLSecurityException ex) {
/* 83 */       log.debug("XMLSecurityException", ex);
/*    */     }
/*    */     
/* 86 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */   public X509Certificate engineLookupResolveX509Certificate(Element element, String BaseURI, StorageResolver storage)
/*    */   {
/* 92 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */   public SecretKey engineLookupAndResolveSecretKey(Element element, String BaseURI, StorageResolver storage)
/*    */   {
/* 98 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\keyresolver\implementations\RSAKeyValueResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */