/*     */ package adsi.org.apache.xml.security.transforms.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import adsi.org.apache.xml.security.c14n.InvalidCanonicalizerException;
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import adsi.org.apache.xml.security.transforms.Transform;
/*     */ import adsi.org.apache.xml.security.transforms.TransformSpi;
/*     */ import adsi.org.apache.xml.security.transforms.TransformationException;
/*     */ import adsi.org.apache.xml.security.transforms.params.XPath2FilterContainer;
/*     */ import adsi.org.apache.xml.security.utils.CachedXPathAPIHolder;
/*     */ import adsi.org.apache.xml.security.utils.CachedXPathFuncHereAPI;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransformXPath2Filter
/*     */   extends TransformSpi
/*     */ {
/*     */   public static final String implementedTransformURI = "http://www.w3.org/2002/06/xmldsig-filter2";
/*     */   
/*     */   protected String engineGetURI()
/*     */   {
/*  80 */     return "http://www.w3.org/2002/06/xmldsig-filter2";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, Transform _transformObject)
/*     */     throws TransformationException
/*     */   {
/*  94 */     CachedXPathAPIHolder.setDoc(_transformObject.getElement().getOwnerDocument());
/*     */     try {
/*  96 */       List unionNodes = new ArrayList();
/*  97 */       List substractNodes = new ArrayList();
/*  98 */       List intersectNodes = new ArrayList();
/*     */       
/* 100 */       CachedXPathFuncHereAPI xPathFuncHereAPI = 
/* 101 */         new CachedXPathFuncHereAPI(CachedXPathAPIHolder.getCachedXPathAPI());
/*     */       
/*     */ 
/* 104 */       Element[] xpathElements = XMLUtils.selectNodes(
/* 105 */         _transformObject.getElement().getFirstChild(), 
/* 106 */         "http://www.w3.org/2002/06/xmldsig-filter2", 
/* 107 */         "XPath");
/* 108 */       int noOfSteps = xpathElements.length;
/*     */       
/*     */ 
/* 111 */       if (noOfSteps == 0) {
/* 112 */         Object[] exArgs = { "http://www.w3.org/2002/06/xmldsig-filter2", "XPath" };
/*     */         
/* 114 */         throw new TransformationException("xml.WrongContent", exArgs);
/*     */       }
/*     */       
/* 117 */       Document inputDoc = null;
/* 118 */       if (input.getSubNode() != null) {
/* 119 */         inputDoc = XMLUtils.getOwnerDocument(input.getSubNode());
/*     */       } else {
/* 121 */         inputDoc = XMLUtils.getOwnerDocument(input.getNodeSet());
/*     */       }
/*     */       
/* 124 */       for (int i = 0; i < noOfSteps; i++) {
/* 125 */         Element xpathElement = XMLUtils.selectNode(
/* 126 */           _transformObject.getElement().getFirstChild(), 
/* 127 */           "http://www.w3.org/2002/06/xmldsig-filter2", 
/* 128 */           "XPath", i);
/* 129 */         XPath2FilterContainer xpathContainer = 
/* 130 */           XPath2FilterContainer.newInstance(xpathElement, 
/* 131 */           input.getSourceURI());
/*     */         
/*     */ 
/* 134 */         NodeList subtreeRoots = xPathFuncHereAPI.selectNodeList(inputDoc, 
/* 135 */           xpathContainer.getXPathFilterTextNode(), 
/* 136 */           CachedXPathFuncHereAPI.getStrFromNode(xpathContainer.getXPathFilterTextNode()), 
/* 137 */           xpathContainer.getElement());
/* 138 */         if (xpathContainer.isIntersect()) {
/* 139 */           intersectNodes.add(subtreeRoots);
/* 140 */         } else if (xpathContainer.isSubtract()) {
/* 141 */           substractNodes.add(subtreeRoots);
/* 142 */         } else if (xpathContainer.isUnion()) {
/* 143 */           unionNodes.add(subtreeRoots);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 148 */       input.addNodeFilter(new XPath2NodeFilter(convertNodeListToSet(unionNodes), 
/* 149 */         convertNodeListToSet(substractNodes), convertNodeListToSet(intersectNodes)));
/* 150 */       input.setNodeSet(true);
/* 151 */       return input;
/*     */     } catch (TransformerException ex) {
/* 153 */       throw new TransformationException("empty", ex);
/*     */     } catch (DOMException ex) {
/* 155 */       throw new TransformationException("empty", ex);
/*     */     } catch (CanonicalizationException ex) {
/* 157 */       throw new TransformationException("empty", ex);
/*     */     } catch (InvalidCanonicalizerException ex) {
/* 159 */       throw new TransformationException("empty", ex);
/*     */     } catch (XMLSecurityException ex) {
/* 161 */       throw new TransformationException("empty", ex);
/*     */     } catch (SAXException ex) {
/* 163 */       throw new TransformationException("empty", ex);
/*     */     } catch (IOException ex) {
/* 165 */       throw new TransformationException("empty", ex);
/*     */     } catch (ParserConfigurationException ex) {
/* 167 */       throw new TransformationException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/* 171 */   static Set convertNodeListToSet(List l) { Set result = new HashSet();
/* 172 */     for (int j = 0; j < l.size(); j++) {
/* 173 */       NodeList rootNodes = (NodeList)l.get(j);
/* 174 */       int length = rootNodes.getLength();
/*     */       
/* 176 */       for (int i = 0; i < length; i++) {
/* 177 */         Node rootNode = rootNodes.item(i);
/* 178 */         result.add(rootNode);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 183 */     return result;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\transforms\implementations\TransformXPath2Filter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */