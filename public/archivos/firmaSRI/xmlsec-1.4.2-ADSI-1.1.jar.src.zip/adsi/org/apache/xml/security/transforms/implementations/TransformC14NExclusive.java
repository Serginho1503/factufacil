/*     */ package adsi.org.apache.xml.security.transforms.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import adsi.org.apache.xml.security.c14n.implementations.Canonicalizer20010315ExclOmitComments;
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import adsi.org.apache.xml.security.transforms.Transform;
/*     */ import adsi.org.apache.xml.security.transforms.TransformSpi;
/*     */ import adsi.org.apache.xml.security.transforms.params.InclusiveNamespaces;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.io.OutputStream;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransformC14NExclusive
/*     */   extends TransformSpi
/*     */ {
/*     */   public static final String implementedTransformURI = "http://www.w3.org/2001/10/xml-exc-c14n#";
/*     */   
/*     */   protected String engineGetURI()
/*     */   {
/*  51 */     return "http://www.w3.org/2001/10/xml-exc-c14n#";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, Transform _transformObject)
/*     */     throws CanonicalizationException
/*     */   {
/*  64 */     return enginePerformTransform(input, null, _transformObject);
/*     */   }
/*     */   
/*     */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, OutputStream os, Transform _transformObject) throws CanonicalizationException
/*     */   {
/*     */     try {
/*  70 */       String inclusiveNamespaces = null;
/*     */       
/*  72 */       if (_transformObject
/*  73 */         .length("http://www.w3.org/2001/10/xml-exc-c14n#", 
/*  74 */         "InclusiveNamespaces") == 
/*  75 */         1) {
/*  76 */         Element inclusiveElement = 
/*  77 */           XMLUtils.selectNode(
/*  78 */           _transformObject.getElement().getFirstChild(), 
/*  79 */           "http://www.w3.org/2001/10/xml-exc-c14n#", 
/*  80 */           "InclusiveNamespaces", 0);
/*     */         
/*  82 */         inclusiveNamespaces = new InclusiveNamespaces(inclusiveElement, 
/*  83 */           _transformObject.getBaseURI()).getInclusiveNamespaces();
/*     */       }
/*     */       
/*  86 */       Canonicalizer20010315ExclOmitComments c14n = 
/*  87 */         new Canonicalizer20010315ExclOmitComments();
/*  88 */       if (os != null) {
/*  89 */         c14n.setWriter(os);
/*     */       }
/*     */       
/*  92 */       byte[] result = c14n.engineCanonicalize(input, inclusiveNamespaces);
/*     */       
/*  94 */       XMLSignatureInput output = new XMLSignatureInput(result);
/*  95 */       if (os != null) {
/*  96 */         output.setOutputStream(os);
/*     */       }
/*  98 */       return output;
/*     */     } catch (XMLSecurityException ex) {
/* 100 */       throw new CanonicalizationException("empty", ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\transforms\implementations\TransformC14NExclusive.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */