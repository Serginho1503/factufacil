/*     */ package adsi.org.apache.xml.security.keys.content;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.keys.content.x509.XMLX509CRL;
/*     */ import adsi.org.apache.xml.security.keys.content.x509.XMLX509Certificate;
/*     */ import adsi.org.apache.xml.security.keys.content.x509.XMLX509IssuerSerial;
/*     */ import adsi.org.apache.xml.security.keys.content.x509.XMLX509SKI;
/*     */ import adsi.org.apache.xml.security.keys.content.x509.XMLX509SubjectName;
/*     */ import adsi.org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.math.BigInteger;
/*     */ import java.security.cert.X509Certificate;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class X509Data
/*     */   extends SignatureElementProxy
/*     */   implements KeyInfoContent
/*     */ {
/*  47 */   static Log log = LogFactory.getLog(X509Data.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Data(Document doc)
/*     */   {
/*  56 */     super(doc);
/*     */     
/*  58 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Data(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  71 */     super(element, BaseURI);
/*  72 */     Node sibling = this._constructionElement.getFirstChild();
/*  73 */     while (sibling != null) {
/*  74 */       if (sibling.getNodeType() != 1) {
/*  75 */         sibling = sibling.getNextSibling();
/*     */       }
/*     */       else {
/*  78 */         return;
/*     */       }
/*     */     }
/*  81 */     Object[] exArgs = { "Elements", "X509Data" };
/*  82 */     throw new XMLSecurityException("xml.WrongContent", exArgs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addIssuerSerial(String X509IssuerName, BigInteger X509SerialNumber)
/*     */   {
/*  93 */     add(new XMLX509IssuerSerial(this._doc, X509IssuerName, 
/*  94 */       X509SerialNumber));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addIssuerSerial(String X509IssuerName, String X509SerialNumber)
/*     */   {
/* 104 */     add(new XMLX509IssuerSerial(this._doc, X509IssuerName, 
/* 105 */       X509SerialNumber));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addIssuerSerial(String X509IssuerName, int X509SerialNumber)
/*     */   {
/* 115 */     add(new XMLX509IssuerSerial(this._doc, X509IssuerName, 
/* 116 */       X509SerialNumber));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(XMLX509IssuerSerial xmlX509IssuerSerial)
/*     */   {
/* 127 */     this._constructionElement.appendChild(xmlX509IssuerSerial.getElement());
/* 128 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSKI(byte[] skiBytes)
/*     */   {
/* 137 */     add(new XMLX509SKI(this._doc, skiBytes));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSKI(X509Certificate x509certificate)
/*     */     throws XMLSecurityException
/*     */   {
/* 148 */     add(new XMLX509SKI(this._doc, x509certificate));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(XMLX509SKI xmlX509SKI)
/*     */   {
/* 157 */     this._constructionElement.appendChild(xmlX509SKI.getElement());
/* 158 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSubjectName(String subjectName)
/*     */   {
/* 167 */     add(new XMLX509SubjectName(this._doc, subjectName));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSubjectName(X509Certificate x509certificate)
/*     */   {
/* 176 */     add(new XMLX509SubjectName(this._doc, x509certificate));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(XMLX509SubjectName xmlX509SubjectName)
/*     */   {
/* 185 */     this._constructionElement.appendChild(xmlX509SubjectName.getElement());
/* 186 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addCertificate(X509Certificate x509certificate)
/*     */     throws XMLSecurityException
/*     */   {
/* 197 */     add(new XMLX509Certificate(this._doc, x509certificate));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addCertificate(byte[] x509certificateBytes)
/*     */   {
/* 206 */     add(new XMLX509Certificate(this._doc, x509certificateBytes));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(XMLX509Certificate xmlX509Certificate)
/*     */   {
/* 215 */     this._constructionElement.appendChild(xmlX509Certificate.getElement());
/* 216 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addCRL(byte[] crlBytes)
/*     */   {
/* 225 */     add(new XMLX509CRL(this._doc, crlBytes));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(XMLX509CRL xmlX509CRL)
/*     */   {
/* 234 */     this._constructionElement.appendChild(xmlX509CRL.getElement());
/* 235 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addUnknownElement(Element element)
/*     */   {
/* 244 */     this._constructionElement.appendChild(element);
/* 245 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int lengthIssuerSerial()
/*     */   {
/* 254 */     return length("http://www.w3.org/2000/09/xmldsig#", 
/* 255 */       "X509IssuerSerial");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int lengthSKI()
/*     */   {
/* 264 */     return length("http://www.w3.org/2000/09/xmldsig#", "X509SKI");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int lengthSubjectName()
/*     */   {
/* 273 */     return length("http://www.w3.org/2000/09/xmldsig#", 
/* 274 */       "X509SubjectName");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int lengthCertificate()
/*     */   {
/* 283 */     return length("http://www.w3.org/2000/09/xmldsig#", 
/* 284 */       "X509Certificate");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int lengthCRL()
/*     */   {
/* 293 */     return length("http://www.w3.org/2000/09/xmldsig#", "X509CRL");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int lengthUnknownElement()
/*     */   {
/* 303 */     int result = 0;
/* 304 */     Node n = this._constructionElement.getFirstChild();
/* 305 */     while (n != null)
/*     */     {
/* 307 */       if ((n.getNodeType() == 1) && 
/* 308 */         (!n.getNamespaceURI().equals("http://www.w3.org/2000/09/xmldsig#"))) {
/* 309 */         result++;
/*     */       }
/* 311 */       n = n.getNextSibling();
/*     */     }
/*     */     
/* 314 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509IssuerSerial itemIssuerSerial(int i)
/*     */     throws XMLSecurityException
/*     */   {
/* 327 */     Element e = 
/* 328 */       XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), 
/* 329 */       "X509IssuerSerial", i);
/*     */     
/* 331 */     if (e != null) {
/* 332 */       return new XMLX509IssuerSerial(e, this._baseURI);
/*     */     }
/* 334 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509SKI itemSKI(int i)
/*     */     throws XMLSecurityException
/*     */   {
/* 346 */     Element e = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), 
/* 347 */       "X509SKI", i);
/*     */     
/* 349 */     if (e != null) {
/* 350 */       return new XMLX509SKI(e, this._baseURI);
/*     */     }
/* 352 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509SubjectName itemSubjectName(int i)
/*     */     throws XMLSecurityException
/*     */   {
/* 365 */     Element e = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), 
/* 366 */       "X509SubjectName", i);
/*     */     
/* 368 */     if (e != null) {
/* 369 */       return new XMLX509SubjectName(e, this._baseURI);
/*     */     }
/* 371 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509Certificate itemCertificate(int i)
/*     */     throws XMLSecurityException
/*     */   {
/* 384 */     Element e = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), 
/* 385 */       "X509Certificate", i);
/*     */     
/* 387 */     if (e != null) {
/* 388 */       return new XMLX509Certificate(e, this._baseURI);
/*     */     }
/* 390 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509CRL itemCRL(int i)
/*     */     throws XMLSecurityException
/*     */   {
/* 402 */     Element e = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), 
/* 403 */       "X509CRL", i);
/*     */     
/* 405 */     if (e != null) {
/* 406 */       return new XMLX509CRL(e, this._baseURI);
/*     */     }
/* 408 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element itemUnknownElement(int i)
/*     */   {
/* 419 */     log.debug("itemUnknownElement not implemented:" + i);
/* 420 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsIssuerSerial()
/*     */   {
/* 429 */     return lengthIssuerSerial() > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsSKI()
/*     */   {
/* 438 */     return lengthSKI() > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsSubjectName()
/*     */   {
/* 447 */     return lengthSubjectName() > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsCertificate()
/*     */   {
/* 456 */     return lengthCertificate() > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsCRL()
/*     */   {
/* 465 */     return lengthCRL() > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsUnknownElement()
/*     */   {
/* 474 */     return lengthUnknownElement() > 0;
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 479 */     return "X509Data";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\content\X509Data.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */