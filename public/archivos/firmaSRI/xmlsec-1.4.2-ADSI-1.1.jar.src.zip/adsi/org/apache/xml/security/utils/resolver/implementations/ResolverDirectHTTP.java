/*     */ package adsi.org.apache.xml.security.utils.resolver.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import adsi.org.apache.xml.security.utils.Base64;
/*     */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolverException;
/*     */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolverSpi;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.xml.utils.URI;
/*     */ import org.apache.xml.utils.URI.MalformedURIException;
/*     */ import org.w3c.dom.Attr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResolverDirectHTTP
/*     */   extends ResourceResolverSpi
/*     */ {
/*  63 */   static Log log = LogFactory.getLog(
/*  64 */     ResolverDirectHTTP.class.getName());
/*     */   
/*     */ 
/*     */ 
/*  68 */   private static final String[] properties = { "http.proxy.host", "http.proxy.port", 
/*  69 */     "http.proxy.username", 
/*  70 */     "http.proxy.password", 
/*  71 */     "http.basic.username", 
/*  72 */     "http.basic.password" };
/*     */   
/*     */ 
/*     */   private static final int HttpProxyHost = 0;
/*     */   
/*     */ 
/*     */   private static final int HttpProxyPort = 1;
/*     */   
/*     */ 
/*     */   private static final int HttpProxyUser = 2;
/*     */   
/*     */ 
/*     */   private static final int HttpProxyPass = 3;
/*     */   
/*     */   private static final int HttpBasicUser = 4;
/*     */   
/*     */   private static final int HttpBasicPass = 5;
/*     */   
/*     */ 
/*     */   public boolean engineIsThreadSafe()
/*     */   {
/*  93 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignatureInput engineResolve(Attr uri, String BaseURI)
/*     */     throws ResourceResolverException
/*     */   {
/*     */     try
/*     */     {
/* 109 */       boolean useProxy = false;
/* 110 */       String proxyHost = 
/* 111 */         engineGetProperty(
/* 112 */         properties[0]);
/* 113 */       String proxyPort = 
/* 114 */         engineGetProperty(
/* 115 */         properties[1]);
/*     */       
/* 117 */       if ((proxyHost != null) && (proxyPort != null)) {
/* 118 */         useProxy = true;
/*     */       }
/*     */       
/* 121 */       String oldProxySet = null;
/* 122 */       String oldProxyHost = null;
/* 123 */       String oldProxyPort = null;
/*     */       
/* 125 */       if (useProxy) {
/* 126 */         if (log.isDebugEnabled()) {
/* 127 */           log.debug("Use of HTTP proxy enabled: " + proxyHost + ":" + 
/* 128 */             proxyPort);
/*     */         }
/* 130 */         oldProxySet = System.getProperty("http.proxySet");
/* 131 */         oldProxyHost = System.getProperty("http.proxyHost");
/* 132 */         oldProxyPort = System.getProperty("http.proxyPort");
/* 133 */         System.setProperty("http.proxySet", "true");
/* 134 */         System.setProperty("http.proxyHost", proxyHost);
/* 135 */         System.setProperty("http.proxyPort", proxyPort);
/*     */       }
/*     */       
/* 138 */       boolean switchBackProxy = (oldProxySet != null) && 
/* 139 */         (oldProxyHost != null) && 
/* 140 */         (oldProxyPort != null);
/*     */       
/*     */ 
/* 143 */       URI uriNew = getNewURI(uri.getNodeValue(), BaseURI);
/*     */       
/*     */ 
/* 146 */       URI uriNewNoFrag = new URI(uriNew);
/*     */       
/* 148 */       uriNewNoFrag.setFragment(null);
/*     */       
/* 150 */       URL url = new URL(uriNewNoFrag.toString());
/* 151 */       URLConnection urlConnection = url.openConnection();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 156 */       String proxyUser = 
/* 157 */         engineGetProperty(
/* 158 */         properties[2]);
/* 159 */       String proxyPass = 
/* 160 */         engineGetProperty(
/* 161 */         properties[3]);
/*     */       
/* 163 */       if ((proxyUser != null) && (proxyPass != null)) {
/* 164 */         String password = proxyUser + ":" + proxyPass;
/* 165 */         String encodedPassword = Base64.encode(password.getBytes());
/*     */         
/*     */ 
/* 168 */         urlConnection.setRequestProperty("Proxy-Authorization", 
/* 169 */           encodedPassword);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 176 */       String auth = urlConnection.getHeaderField("WWW-Authenticate");
/*     */       
/* 178 */       if (auth != null)
/*     */       {
/*     */ 
/* 181 */         if (auth.startsWith("Basic")) {
/* 182 */           String user = 
/* 183 */             engineGetProperty(
/* 184 */             properties[4]);
/* 185 */           String pass = 
/* 186 */             engineGetProperty(
/* 187 */             properties[5]);
/*     */           
/* 189 */           if ((user != null) && (pass != null)) {
/* 190 */             urlConnection = url.openConnection();
/*     */             
/* 192 */             String password = user + ":" + pass;
/* 193 */             String encodedPassword = 
/* 194 */               Base64.encode(password.getBytes());
/*     */             
/*     */ 
/* 197 */             urlConnection.setRequestProperty("Authorization", 
/* 198 */               "Basic " + 
/* 199 */               encodedPassword);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 205 */       String mimeType = urlConnection.getHeaderField("Content-Type");
/* 206 */       InputStream inputStream = urlConnection.getInputStream();
/* 207 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 208 */       byte[] buf = new byte['က'];
/* 209 */       int read = 0;
/* 210 */       int summarized = 0;
/*     */       
/* 212 */       while ((read = inputStream.read(buf)) >= 0) {
/* 213 */         baos.write(buf, 0, read);
/*     */         
/* 215 */         summarized += read;
/*     */       }
/*     */       
/* 218 */       log.debug("Fetched " + summarized + " bytes from URI " + 
/* 219 */         uriNew.toString());
/*     */       
/* 221 */       XMLSignatureInput result = new XMLSignatureInput(baos.toByteArray());
/*     */       
/*     */ 
/* 224 */       result.setSourceURI(uriNew.toString());
/* 225 */       result.setMIMEType(mimeType);
/*     */       
/*     */ 
/* 228 */       if ((useProxy) && (switchBackProxy)) {
/* 229 */         System.setProperty("http.proxySet", oldProxySet);
/* 230 */         System.setProperty("http.proxyHost", oldProxyHost);
/* 231 */         System.setProperty("http.proxyPort", oldProxyPort);
/*     */       }
/*     */       
/* 234 */       return result;
/*     */     } catch (MalformedURLException ex) {
/* 236 */       throw new ResourceResolverException("generic.EmptyMessage", ex, uri, 
/* 237 */         BaseURI);
/*     */     } catch (IOException ex) {
/* 239 */       throw new ResourceResolverException("generic.EmptyMessage", ex, uri, 
/* 240 */         BaseURI);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean engineCanResolve(Attr uri, String BaseURI)
/*     */   {
/* 252 */     if (uri == null) {
/* 253 */       log.debug("quick fail, uri == null");
/*     */       
/* 255 */       return false;
/*     */     }
/*     */     
/* 258 */     String uriNodeValue = uri.getNodeValue();
/*     */     
/* 260 */     if ((uriNodeValue.equals("")) || (uriNodeValue.charAt(0) == '#')) {
/* 261 */       log.debug("quick fail for empty URIs and local ones");
/*     */       
/* 263 */       return false;
/*     */     }
/*     */     
/* 266 */     if (log.isDebugEnabled()) {
/* 267 */       log.debug("I was asked whether I can resolve " + uriNodeValue);
/*     */     }
/*     */     
/* 270 */     if ((uriNodeValue.startsWith("http:")) || (
/* 271 */       (BaseURI != null) && (BaseURI.startsWith("http:")))) {
/* 272 */       if (log.isDebugEnabled()) {
/* 273 */         log.debug("I state that I can resolve " + uriNodeValue);
/*     */       }
/*     */       
/* 276 */       return true;
/*     */     }
/*     */     
/* 279 */     if (log.isDebugEnabled()) {
/* 280 */       log.debug("I state that I can't resolve " + uriNodeValue);
/*     */     }
/*     */     
/* 283 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String[] engineGetPropertyKeys()
/*     */   {
/* 290 */     return (String[])properties.clone();
/*     */   }
/*     */   
/*     */   private URI getNewURI(String uri, String BaseURI)
/*     */     throws URI.MalformedURIException
/*     */   {
/* 296 */     if ((BaseURI == null) || ("".equals(BaseURI))) {
/* 297 */       return new URI(uri);
/*     */     }
/* 299 */     return new URI(new URI(BaseURI), uri);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\utils\resolver\implementations\ResolverDirectHTTP.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */