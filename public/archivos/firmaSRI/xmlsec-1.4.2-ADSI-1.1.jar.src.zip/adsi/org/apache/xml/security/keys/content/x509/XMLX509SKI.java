/*     */ package adsi.org.apache.xml.security.keys.content.x509;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.utils.Base64;
/*     */ import adsi.org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.cert.X509Certificate;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLX509SKI
/*     */   extends SignatureElementProxy
/*     */   implements XMLX509DataContent
/*     */ {
/*  45 */   static Log log = LogFactory.getLog(XMLX509SKI.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String SKI_OID = "2.5.29.14";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509SKI(Document doc, byte[] skiBytes)
/*     */   {
/*  65 */     super(doc);
/*  66 */     addBase64Text(skiBytes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509SKI(Document doc, X509Certificate x509certificate)
/*     */     throws XMLSecurityException
/*     */   {
/*  78 */     super(doc);
/*  79 */     addBase64Text(getSKIBytesFromCert(x509certificate));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLX509SKI(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  91 */     super(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getSKIBytes()
/*     */     throws XMLSecurityException
/*     */   {
/* 101 */     return getBytesFromTextChild();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] getSKIBytesFromCert(X509Certificate cert)
/*     */     throws XMLSecurityException
/*     */   {
/* 116 */     if (cert.getVersion() < 3) {
/* 117 */       Object[] exArgs = { new Integer(cert.getVersion()) };
/* 118 */       throw new XMLSecurityException("certificate.noSki.lowVersion", 
/* 119 */         exArgs);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 128 */     byte[] extensionValue = cert.getExtensionValue("2.5.29.14");
/* 129 */     if (extensionValue == null) {
/* 130 */       throw new XMLSecurityException("certificate.noSki.null");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 139 */     byte[] skidValue = new byte[extensionValue.length - 4];
/*     */     
/* 141 */     System.arraycopy(extensionValue, 4, skidValue, 0, skidValue.length);
/*     */     
/* 143 */     if (log.isDebugEnabled()) {
/* 144 */       log.debug("Base64 of SKI is " + Base64.encode(skidValue));
/*     */     }
/*     */     
/* 147 */     return skidValue;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 152 */     if (obj == null) {
/* 153 */       return false;
/*     */     }
/* 155 */     if (!getClass().getName().equals(obj.getClass().getName())) {
/* 156 */       return false;
/*     */     }
/*     */     
/* 159 */     XMLX509SKI other = (XMLX509SKI)obj;
/*     */     try
/*     */     {
/* 162 */       return MessageDigest.isEqual(other.getSKIBytes(), 
/* 163 */         getSKIBytes());
/*     */     } catch (XMLSecurityException ex) {}
/* 165 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 172 */     return 92;
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 177 */     return "X509SKI";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\content\x509\XMLX509SKI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */