/*    */ package adsi.org.apache.xml.security.utils;
/*    */ 
/*    */ import adsi.org.apache.xml.security.algorithms.SignatureAlgorithm;
/*    */ import adsi.org.apache.xml.security.signature.XMLSignatureException;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SignerOutputStream
/*    */   extends ByteArrayOutputStream
/*    */ {
/* 29 */   static final byte[] none = "error".getBytes();
/*    */   
/*    */   final SignatureAlgorithm sa;
/* 32 */   static Log log = LogFactory.getLog(
/* 33 */     SignerOutputStream.class.getName());
/*    */   
/*    */ 
/*    */ 
/*    */   public SignerOutputStream(SignatureAlgorithm sa)
/*    */   {
/* 39 */     this.sa = sa;
/*    */   }
/*    */   
/*    */   public byte[] toByteArray()
/*    */   {
/* 44 */     return none;
/*    */   }
/*    */   
/*    */   public void write(byte[] arg0)
/*    */   {
/*    */     try {
/* 50 */       this.sa.update(arg0);
/*    */     } catch (XMLSignatureException e) {
/* 52 */       throw new RuntimeException(e);
/*    */     }
/*    */   }
/*    */   
/*    */   public void write(int arg0)
/*    */   {
/*    */     try {
/* 59 */       this.sa.update((byte)arg0);
/*    */     } catch (XMLSignatureException e) {
/* 61 */       throw new RuntimeException(e);
/*    */     }
/*    */   }
/*    */   
/*    */   public void write(byte[] arg0, int arg1, int arg2)
/*    */   {
/* 67 */     if (log.isDebugEnabled()) {
/* 68 */       log.debug("Canonicalized SignedInfo:");
/* 69 */       StringBuffer sb = new StringBuffer(arg2);
/* 70 */       for (int i = arg1; i < arg1 + arg2; i++) {
/* 71 */         sb.append((char)arg0[i]);
/*    */       }
/* 73 */       log.debug(sb.toString());
/*    */     }
/*    */     try {
/* 76 */       this.sa.update(arg0, arg1, arg2);
/*    */     } catch (XMLSignatureException e) {
/* 78 */       if (log.isDebugEnabled()) {
/* 79 */         log.debug("", e);
/*    */       }
/* 81 */       throw new RuntimeException(e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\utils\SignerOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */