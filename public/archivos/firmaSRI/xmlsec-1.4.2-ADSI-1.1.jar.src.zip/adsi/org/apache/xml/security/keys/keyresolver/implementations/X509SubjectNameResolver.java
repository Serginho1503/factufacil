/*     */ package adsi.org.apache.xml.security.keys.keyresolver.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.keys.content.x509.XMLX509SubjectName;
/*     */ import adsi.org.apache.xml.security.keys.keyresolver.KeyResolverException;
/*     */ import adsi.org.apache.xml.security.keys.keyresolver.KeyResolverSpi;
/*     */ import adsi.org.apache.xml.security.keys.storage.StorageResolver;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.crypto.SecretKey;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class X509SubjectNameResolver
/*     */   extends KeyResolverSpi
/*     */ {
/*  44 */   static Log log = LogFactory.getLog(
/*  45 */     X509SubjectNameResolver.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PublicKey engineLookupAndResolvePublicKey(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/*  61 */     X509Certificate cert = engineLookupResolveX509Certificate(element, 
/*  62 */       BaseURI, storage);
/*     */     
/*  64 */     if (cert != null) {
/*  65 */       return cert.getPublicKey();
/*     */     }
/*     */     
/*  68 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Certificate engineLookupResolveX509Certificate(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/*  83 */     if (log.isDebugEnabled())
/*  84 */       log.debug("Can I resolve " + element.getTagName() + "?");
/*  85 */     Element[] x509childNodes = (Element[])null;
/*  86 */     XMLX509SubjectName[] x509childObject = (XMLX509SubjectName[])null;
/*     */     
/*  88 */     if (!XMLUtils.elementIsInSignatureSpace(element, 
/*  89 */       "X509Data")) {
/*  90 */       log.debug("I can't");
/*  91 */       return null;
/*     */     }
/*  93 */     x509childNodes = XMLUtils.selectDsNodes(element.getFirstChild(), 
/*  94 */       "X509SubjectName");
/*     */     
/*  96 */     if ((x509childNodes == null) || 
/*  97 */       (x509childNodes.length <= 0)) {
/*  98 */       log.debug("I can't");
/*  99 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 103 */       if (storage == null) {
/* 104 */         Object[] exArgs = { "X509SubjectName" };
/* 105 */         KeyResolverException ex = 
/* 106 */           new KeyResolverException("KeyResolver.needStorageResolver", 
/* 107 */           exArgs);
/*     */         
/* 109 */         log.info("", ex);
/*     */         
/* 111 */         throw ex;
/*     */       }
/*     */       
/* 114 */       x509childObject = 
/* 115 */         new XMLX509SubjectName[x509childNodes.length];
/*     */       
/* 117 */       for (int i = 0; i < x509childNodes.length; i++) {
/* 118 */         x509childObject[i] = 
/* 119 */           new XMLX509SubjectName(x509childNodes[i], 
/* 120 */           BaseURI);
/*     */       }
/*     */       int i;
/* 123 */       for (; storage.hasNext(); 
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 130 */           i < x509childObject.length)
/*     */       {
/* 124 */         X509Certificate cert = storage.next();
/* 125 */         XMLX509SubjectName certSN = 
/* 126 */           new XMLX509SubjectName(element.getOwnerDocument(), cert);
/*     */         
/* 128 */         log.debug("Found Certificate SN: " + certSN.getSubjectName());
/*     */         
/* 130 */         i = 0; continue;
/* 131 */         log.debug("Found Element SN:     " + 
/* 132 */           x509childObject[i].getSubjectName());
/*     */         
/* 134 */         if (certSN.equals(x509childObject[i])) {
/* 135 */           log.debug("match !!! ");
/*     */           
/* 137 */           return cert;
/*     */         }
/* 139 */         log.debug("no match...");i++;
/*     */       }
/*     */       
/*     */ 
/* 143 */       return null;
/*     */     } catch (XMLSecurityException ex) {
/* 145 */       log.debug("XMLSecurityException", ex);
/*     */       
/* 147 */       throw new KeyResolverException("generic.EmptyMessage", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SecretKey engineLookupAndResolveSecretKey(Element element, String BaseURI, StorageResolver storage)
/*     */   {
/* 162 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\keyresolver\implementations\X509SubjectNameResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */