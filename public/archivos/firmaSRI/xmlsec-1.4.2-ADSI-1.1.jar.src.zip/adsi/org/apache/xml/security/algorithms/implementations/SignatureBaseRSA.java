/*     */ package adsi.org.apache.xml.security.algorithms.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.algorithms.JCEMapper;
/*     */ import adsi.org.apache.xml.security.algorithms.SignatureAlgorithmSpi;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureException;
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.Key;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.Provider;
/*     */ import java.security.PublicKey;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.Signature;
/*     */ import java.security.SignatureException;
/*     */ import java.security.spec.AlgorithmParameterSpec;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SignatureBaseRSA
/*     */   extends SignatureAlgorithmSpi
/*     */ {
/*  48 */   static Log log = LogFactory.getLog(
/*  49 */     SignatureBaseRSA.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  55 */   private Signature _signatureAlgorithm = null;
/*     */   
/*     */ 
/*     */   public abstract String engineGetURI();
/*     */   
/*     */ 
/*     */   public SignatureBaseRSA()
/*     */     throws XMLSignatureException
/*     */   {
/*  64 */     String algorithmID = JCEMapper.translateURItoJCEID(engineGetURI());
/*     */     
/*  66 */     if (log.isDebugEnabled())
/*  67 */       log.debug("Created SignatureRSA using " + algorithmID);
/*  68 */     Provider providerThread = JCEMapper.getProviderSignatureThread();
/*  69 */     String provider = null;
/*  70 */     if (providerThread == null) {
/*  71 */       provider = JCEMapper.getProviderId();
/*     */     }
/*     */     try {
/*  74 */       if (providerThread == null) {
/*  75 */         if (provider == null) {
/*  76 */           this._signatureAlgorithm = Signature.getInstance(algorithmID);
/*     */         } else {
/*  78 */           this._signatureAlgorithm = Signature.getInstance(algorithmID, provider);
/*     */         }
/*     */       } else {
/*  81 */         this._signatureAlgorithm = Signature.getInstance(algorithmID, providerThread);
/*     */       }
/*     */     } catch (NoSuchAlgorithmException ex) {
/*  84 */       Object[] exArgs = { algorithmID, ex.getLocalizedMessage() };
/*     */       
/*  86 */       throw new XMLSignatureException("algorithms.NoSuchAlgorithm", exArgs);
/*     */     } catch (NoSuchProviderException ex) {
/*  88 */       Object[] exArgs = { algorithmID, ex.getLocalizedMessage() };
/*     */       
/*  90 */       throw new XMLSignatureException("algorithms.NoSuchAlgorithm", exArgs);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void engineSetParameter(AlgorithmParameterSpec params)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/*  99 */       this._signatureAlgorithm.setParameter(params);
/*     */     } catch (InvalidAlgorithmParameterException ex) {
/* 101 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean engineVerify(byte[] signature)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 110 */       return this._signatureAlgorithm.verify(signature);
/*     */     } catch (SignatureException ex) {
/* 112 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void engineInitVerify(Key publicKey)
/*     */     throws XMLSignatureException
/*     */   {
/* 119 */     if (!(publicKey instanceof PublicKey)) {
/* 120 */       String supplied = publicKey.getClass().getName();
/* 121 */       String needed = PublicKey.class.getName();
/* 122 */       Object[] exArgs = { supplied, needed };
/*     */       
/* 124 */       throw new XMLSignatureException(
/* 125 */         "algorithms.WrongKeyForThisOperation", exArgs);
/*     */     }
/*     */     try
/*     */     {
/* 129 */       this._signatureAlgorithm.initVerify((PublicKey)publicKey);
/*     */     }
/*     */     catch (InvalidKeyException ex)
/*     */     {
/* 133 */       Signature sig = this._signatureAlgorithm;
/*     */       try {
/* 135 */         this._signatureAlgorithm = Signature.getInstance(
/* 136 */           this._signatureAlgorithm.getAlgorithm());
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 140 */         if (log.isDebugEnabled()) {
/* 141 */           log.debug("Exception when reinstantiating Signature:" + e);
/*     */         }
/* 143 */         this._signatureAlgorithm = sig;
/*     */       }
/* 145 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected byte[] engineSign() throws XMLSignatureException
/*     */   {
/*     */     try {
/* 152 */       return this._signatureAlgorithm.sign();
/*     */     } catch (SignatureException ex) {
/* 154 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void engineInitSign(Key privateKey, SecureRandom secureRandom)
/*     */     throws XMLSignatureException
/*     */   {
/* 162 */     if (!(privateKey instanceof PrivateKey)) {
/* 163 */       String supplied = privateKey.getClass().getName();
/* 164 */       String needed = PrivateKey.class.getName();
/* 165 */       Object[] exArgs = { supplied, needed };
/*     */       
/* 167 */       throw new XMLSignatureException(
/* 168 */         "algorithms.WrongKeyForThisOperation", exArgs);
/*     */     }
/*     */     try
/*     */     {
/* 172 */       this._signatureAlgorithm.initSign(
/* 173 */         (PrivateKey)privateKey, secureRandom);
/*     */     } catch (InvalidKeyException ex) {
/* 175 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void engineInitSign(Key privateKey)
/*     */     throws XMLSignatureException
/*     */   {
/* 182 */     if (!(privateKey instanceof PrivateKey)) {
/* 183 */       String supplied = privateKey.getClass().getName();
/* 184 */       String needed = PrivateKey.class.getName();
/* 185 */       Object[] exArgs = { supplied, needed };
/*     */       
/* 187 */       throw new XMLSignatureException(
/* 188 */         "algorithms.WrongKeyForThisOperation", exArgs);
/*     */     }
/*     */     try
/*     */     {
/* 192 */       this._signatureAlgorithm.initSign((PrivateKey)privateKey);
/*     */     } catch (InvalidKeyException ex) {
/* 194 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void engineUpdate(byte[] input) throws XMLSignatureException
/*     */   {
/*     */     try {
/* 201 */       this._signatureAlgorithm.update(input);
/*     */     } catch (SignatureException ex) {
/* 203 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void engineUpdate(byte input) throws XMLSignatureException
/*     */   {
/*     */     try {
/* 210 */       this._signatureAlgorithm.update(input);
/*     */     } catch (SignatureException ex) {
/* 212 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void engineUpdate(byte[] buf, int offset, int len) throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 220 */       this._signatureAlgorithm.update(buf, offset, len);
/*     */     } catch (SignatureException ex) {
/* 222 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected String engineGetJCEAlgorithmString()
/*     */   {
/* 228 */     return this._signatureAlgorithm.getAlgorithm();
/*     */   }
/*     */   
/*     */   protected String engineGetJCEProviderName()
/*     */   {
/* 233 */     return this._signatureAlgorithm.getProvider().getName();
/*     */   }
/*     */   
/*     */   protected void engineSetHMACOutputLength(int HMACOutputLength)
/*     */     throws XMLSignatureException
/*     */   {
/* 239 */     throw new XMLSignatureException(
/* 240 */       "algorithms.HMACOutputLengthOnlyForHMAC");
/*     */   }
/*     */   
/*     */ 
/*     */   protected void engineInitSign(Key signingKey, AlgorithmParameterSpec algorithmParameterSpec)
/*     */     throws XMLSignatureException
/*     */   {
/* 247 */     throw new XMLSignatureException(
/* 248 */       "algorithms.CannotUseAlgorithmParameterSpecOnRSA");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class SignatureRSASHA1
/*     */     extends SignatureBaseRSA
/*     */   {
/*     */     public SignatureRSASHA1()
/*     */       throws XMLSignatureException
/*     */     {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String engineGetURI()
/*     */     {
/* 270 */       return "http://www.w3.org/2000/09/xmldsig#rsa-sha1";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class SignatureRSASHA256
/*     */     extends SignatureBaseRSA
/*     */   {
/*     */     public SignatureRSASHA256()
/*     */       throws XMLSignatureException
/*     */     {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String engineGetURI()
/*     */     {
/* 293 */       return "http://www.w3.org/2001/04/xmldsig-more#rsa-sha256";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class SignatureRSASHA384
/*     */     extends SignatureBaseRSA
/*     */   {
/*     */     public SignatureRSASHA384()
/*     */       throws XMLSignatureException
/*     */     {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String engineGetURI()
/*     */     {
/* 316 */       return "http://www.w3.org/2001/04/xmldsig-more#rsa-sha384";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class SignatureRSASHA512
/*     */     extends SignatureBaseRSA
/*     */   {
/*     */     public SignatureRSASHA512()
/*     */       throws XMLSignatureException
/*     */     {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String engineGetURI()
/*     */     {
/* 339 */       return "http://www.w3.org/2001/04/xmldsig-more#rsa-sha512";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class SignatureRSARIPEMD160
/*     */     extends SignatureBaseRSA
/*     */   {
/*     */     public SignatureRSARIPEMD160()
/*     */       throws XMLSignatureException
/*     */     {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String engineGetURI()
/*     */     {
/* 362 */       return "http://www.w3.org/2001/04/xmldsig-more#rsa-ripemd160";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class SignatureRSAMD5
/*     */     extends SignatureBaseRSA
/*     */   {
/*     */     public SignatureRSAMD5()
/*     */       throws XMLSignatureException
/*     */     {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String engineGetURI()
/*     */     {
/* 385 */       return "http://www.w3.org/2001/04/xmldsig-more#rsa-md5";
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\algorithms\implementations\SignatureBaseRSA.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */