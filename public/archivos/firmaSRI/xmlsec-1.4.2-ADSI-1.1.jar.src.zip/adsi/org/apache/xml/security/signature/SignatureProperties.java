/*     */ package adsi.org.apache.xml.security.signature;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.utils.IdResolver;
/*     */ import adsi.org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignatureProperties
/*     */   extends SignatureElementProxy
/*     */ {
/*     */   public SignatureProperties(Document doc)
/*     */   {
/*  47 */     super(doc);
/*     */     
/*  49 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignatureProperties(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  60 */     super(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLength()
/*     */   {
/*  70 */     Element[] propertyElems = 
/*  71 */       XMLUtils.selectDsNodes(this._constructionElement, 
/*  72 */       "SignatureProperty");
/*     */     
/*     */ 
/*  75 */     return propertyElems.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignatureProperty item(int i)
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/*  88 */       Element propertyElem = 
/*  89 */         XMLUtils.selectDsNode(this._constructionElement, 
/*  90 */         "SignatureProperty", 
/*  91 */         i);
/*     */       
/*  93 */       if (propertyElem == null) {
/*  94 */         return null;
/*     */       }
/*  96 */       return new SignatureProperty(propertyElem, this._baseURI);
/*     */     } catch (XMLSecurityException ex) {
/*  98 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setId(String Id)
/*     */   {
/* 109 */     if (Id != null) {
/* 110 */       this._constructionElement.setAttributeNS(null, "Id", Id);
/* 111 */       IdResolver.registerElementById(this._constructionElement, Id);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getId()
/*     */   {
/* 121 */     return this._constructionElement.getAttributeNS(null, "Id");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSignatureProperty(SignatureProperty sp)
/*     */   {
/* 130 */     this._constructionElement.appendChild(sp.getElement());
/* 131 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 136 */     return "SignatureProperties";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\signature\SignatureProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */