/*     */ package adsi.org.apache.xml.security.keys.content.keyvalues;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.utils.I18n;
/*     */ import adsi.org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.math.BigInteger;
/*     */ import java.security.Key;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PublicKey;
/*     */ import java.security.interfaces.DSAParams;
/*     */ import java.security.interfaces.DSAPublicKey;
/*     */ import java.security.spec.DSAPublicKeySpec;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DSAKeyValue
/*     */   extends SignatureElementProxy
/*     */   implements KeyValueContent
/*     */ {
/*     */   public DSAKeyValue(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  53 */     super(element, BaseURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DSAKeyValue(Document doc, BigInteger P, BigInteger Q, BigInteger G, BigInteger Y)
/*     */   {
/*  68 */     super(doc);
/*     */     
/*  70 */     XMLUtils.addReturnToElement(this._constructionElement);
/*  71 */     addBigIntegerElement(P, "P");
/*  72 */     addBigIntegerElement(Q, "Q");
/*  73 */     addBigIntegerElement(G, "G");
/*  74 */     addBigIntegerElement(Y, "Y");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DSAKeyValue(Document doc, Key key)
/*     */     throws IllegalArgumentException
/*     */   {
/*  86 */     super(doc);
/*     */     
/*  88 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */     
/*  90 */     if ((key instanceof DSAPublicKey)) {
/*  91 */       addBigIntegerElement(((DSAPublicKey)key).getParams().getP(), 
/*  92 */         "P");
/*  93 */       addBigIntegerElement(((DSAPublicKey)key).getParams().getQ(), 
/*  94 */         "Q");
/*  95 */       addBigIntegerElement(((DSAPublicKey)key).getParams().getG(), 
/*  96 */         "G");
/*  97 */       addBigIntegerElement(((DSAPublicKey)key).getY(), 
/*  98 */         "Y");
/*     */     } else {
/* 100 */       Object[] exArgs = { "DSAKeyValue", 
/* 101 */         key.getClass().getName() };
/*     */       
/* 103 */       throw new IllegalArgumentException(
/* 104 */         I18n.translate("KeyValue.IllegalArgument", exArgs));
/*     */     }
/*     */   }
/*     */   
/*     */   public PublicKey getPublicKey() throws XMLSecurityException
/*     */   {
/*     */     try
/*     */     {
/* 112 */       DSAPublicKeySpec pkspec = 
/* 113 */         new DSAPublicKeySpec(
/* 114 */         getBigIntegerFromChildElement("Y", "http://www.w3.org/2000/09/xmldsig#"), 
/*     */         
/* 116 */         getBigIntegerFromChildElement("P", "http://www.w3.org/2000/09/xmldsig#"), 
/*     */         
/* 118 */         getBigIntegerFromChildElement("Q", "http://www.w3.org/2000/09/xmldsig#"), 
/*     */         
/* 120 */         getBigIntegerFromChildElement("G", 
/* 121 */         "http://www.w3.org/2000/09/xmldsig#"));
/* 122 */       KeyFactory dsaFactory = KeyFactory.getInstance("DSA");
/* 123 */       return dsaFactory.generatePublic(pkspec);
/*     */     }
/*     */     catch (NoSuchAlgorithmException ex)
/*     */     {
/* 127 */       throw new XMLSecurityException("empty", ex);
/*     */     } catch (InvalidKeySpecException ex) {
/* 129 */       throw new XMLSecurityException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getBaseLocalName()
/*     */   {
/* 135 */     return "DSAKeyValue";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\content\keyvalues\DSAKeyValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */