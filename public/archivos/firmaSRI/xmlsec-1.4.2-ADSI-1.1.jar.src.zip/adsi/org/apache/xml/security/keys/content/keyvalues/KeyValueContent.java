package adsi.org.apache.xml.security.keys.content.keyvalues;

import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
import java.security.PublicKey;

public abstract interface KeyValueContent
{
  public abstract PublicKey getPublicKey()
    throws XMLSecurityException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\content\keyvalues\KeyValueContent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */