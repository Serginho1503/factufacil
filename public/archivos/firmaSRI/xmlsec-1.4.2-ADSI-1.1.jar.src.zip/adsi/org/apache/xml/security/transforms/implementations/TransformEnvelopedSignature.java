/*     */ package adsi.org.apache.xml.security.transforms.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.signature.NodeFilter;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import adsi.org.apache.xml.security.transforms.Transform;
/*     */ import adsi.org.apache.xml.security.transforms.TransformSpi;
/*     */ import adsi.org.apache.xml.security.transforms.TransformationException;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransformEnvelopedSignature
/*     */   extends TransformSpi
/*     */ {
/*     */   public static final String implementedTransformURI = "http://www.w3.org/2000/09/xmldsig#enveloped-signature";
/*     */   
/*     */   protected String engineGetURI()
/*     */   {
/*  49 */     return "http://www.w3.org/2000/09/xmldsig#enveloped-signature";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected XMLSignatureInput enginePerformTransform(XMLSignatureInput input, Transform _transformObject)
/*     */     throws TransformationException
/*     */   {
/*  72 */     Node signatureElement = _transformObject.getElement();
/*     */     
/*     */ 
/*  75 */     signatureElement = searchSignatureElement(signatureElement);
/*  76 */     input.setExcludeNode(signatureElement);
/*  77 */     input.addNodeFilter(new EnvelopedNodeFilter(signatureElement));
/*  78 */     return input;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Node searchSignatureElement(Node signatureElement)
/*     */     throws TransformationException
/*     */   {
/*  91 */     boolean found = false;
/*     */     
/*     */ 
/*  94 */     while ((signatureElement != null) && 
/*  95 */       (signatureElement.getNodeType() != 9))
/*     */     {
/*     */ 
/*  98 */       Element el = (Element)signatureElement;
/*  99 */       if (el.getNamespaceURI().equals("http://www.w3.org/2000/09/xmldsig#"))
/*     */       {
/* 101 */         if (el.getLocalName().equals("Signature")) {
/* 102 */           found = true;
/* 103 */           break;
/*     */         }
/*     */       }
/* 106 */       signatureElement = signatureElement.getParentNode();
/*     */     }
/*     */     
/* 109 */     if (!found) {
/* 110 */       throw new TransformationException(
/* 111 */         "envelopedSignatureTransformNotInSignatureElement");
/*     */     }
/* 113 */     return signatureElement;
/*     */   }
/*     */   
/*     */   static class EnvelopedNodeFilter implements NodeFilter { Node exclude;
/*     */     
/* 118 */     EnvelopedNodeFilter(Node n) { this.exclude = n; }
/*     */     
/*     */     public int isNodeIncludeDO(Node n, int level) {
/* 121 */       if (n == this.exclude)
/* 122 */         return -1;
/* 123 */       return 1;
/*     */     }
/*     */     
/*     */ 
/*     */     public int isNodeInclude(Node n)
/*     */     {
/* 129 */       if ((n == this.exclude) || (XMLUtils.isDescendantOrSelf(this.exclude, n)))
/* 130 */         return -1;
/* 131 */       return 1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\transforms\implementations\TransformEnvelopedSignature.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */