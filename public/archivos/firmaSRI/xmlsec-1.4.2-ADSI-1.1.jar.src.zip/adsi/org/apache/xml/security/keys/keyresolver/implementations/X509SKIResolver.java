/*     */ package adsi.org.apache.xml.security.keys.keyresolver.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.keys.content.x509.XMLX509SKI;
/*     */ import adsi.org.apache.xml.security.keys.keyresolver.KeyResolverException;
/*     */ import adsi.org.apache.xml.security.keys.keyresolver.KeyResolverSpi;
/*     */ import adsi.org.apache.xml.security.keys.storage.StorageResolver;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.security.Principal;
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.crypto.SecretKey;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class X509SKIResolver
/*     */   extends KeyResolverSpi
/*     */ {
/*  46 */   static Log log = LogFactory.getLog(X509SKIResolver.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PublicKey engineLookupAndResolvePublicKey(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/*  62 */     X509Certificate cert = engineLookupResolveX509Certificate(element, 
/*  63 */       BaseURI, storage);
/*     */     
/*  65 */     if (cert != null) {
/*  66 */       return cert.getPublicKey();
/*     */     }
/*     */     
/*  69 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Certificate engineLookupResolveX509Certificate(Element element, String BaseURI, StorageResolver storage)
/*     */     throws KeyResolverException
/*     */   {
/*  84 */     if (log.isDebugEnabled()) {
/*  85 */       log.debug("Can I resolve " + element.getTagName() + "?");
/*     */     }
/*  87 */     if (!XMLUtils.elementIsInSignatureSpace(element, 
/*  88 */       "X509Data")) {
/*  89 */       log.debug("I can't");
/*  90 */       return null;
/*     */     }
/*     */     
/*  93 */     XMLX509SKI[] x509childObject = (XMLX509SKI[])null;
/*     */     
/*  95 */     Element[] x509childNodes = (Element[])null;
/*  96 */     x509childNodes = XMLUtils.selectDsNodes(element.getFirstChild(), 
/*  97 */       "X509SKI");
/*     */     
/*  99 */     if ((x509childNodes == null) || 
/* 100 */       (x509childNodes.length <= 0)) {
/* 101 */       log.debug("I can't");
/* 102 */       return null;
/*     */     }
/*     */     try {
/* 105 */       if (storage == null) {
/* 106 */         Object[] exArgs = { "X509SKI" };
/* 107 */         KeyResolverException ex = 
/* 108 */           new KeyResolverException("KeyResolver.needStorageResolver", 
/* 109 */           exArgs);
/*     */         
/* 111 */         log.info("", ex);
/*     */         
/* 113 */         throw ex;
/*     */       }
/*     */       
/* 116 */       x509childObject = new XMLX509SKI[x509childNodes.length];
/*     */       
/* 118 */       for (int i = 0; i < x509childNodes.length; i++) {
/* 119 */         x509childObject[i] = 
/* 120 */           new XMLX509SKI(x509childNodes[i], BaseURI);
/*     */       }
/*     */       int i;
/* 123 */       for (; storage.hasNext(); 
/*     */           
/*     */ 
/*     */ 
/* 127 */           i < x509childObject.length)
/*     */       {
/* 124 */         X509Certificate cert = storage.next();
/* 125 */         XMLX509SKI certSKI = new XMLX509SKI(element.getOwnerDocument(), cert);
/*     */         
/* 127 */         i = 0; continue;
/* 128 */         if (certSKI.equals(x509childObject[i])) {
/* 129 */           log.debug("Return PublicKey from " + 
/* 130 */             cert.getSubjectDN().getName());
/*     */           
/* 132 */           return cert;
/*     */         }
/* 127 */         i++;
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (XMLSecurityException ex)
/*     */     {
/*     */ 
/* 137 */       throw new KeyResolverException("empty", ex);
/*     */     }
/*     */     
/* 140 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SecretKey engineLookupAndResolveSecretKey(Element element, String BaseURI, StorageResolver storage)
/*     */   {
/* 154 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\keys\keyresolver\implementations\X509SKIResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */