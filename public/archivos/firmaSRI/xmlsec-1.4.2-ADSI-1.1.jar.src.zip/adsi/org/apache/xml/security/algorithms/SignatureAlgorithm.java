/*     */ package adsi.org.apache.xml.security.algorithms;
/*     */ 
/*     */ import adsi.org.apache.xml.security.algorithms.implementations.IntegrityHmac;
/*     */ import adsi.org.apache.xml.security.exceptions.AlgorithmAlreadyRegisteredException;
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureException;
/*     */ import java.security.Key;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.spec.AlgorithmParameterSpec;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignatureAlgorithm
/*     */   extends Algorithm
/*     */ {
/*  45 */   static Log log = LogFactory.getLog(SignatureAlgorithm.class.getName());
/*     */   
/*     */ 
/*  48 */   static boolean _alreadyInitialized = false;
/*     */   
/*     */ 
/*  51 */   static HashMap _algorithmHash = null;
/*     */   
/*  53 */   static ThreadLocal instancesSigning = new ThreadLocal() {
/*     */     protected Object initialValue() {
/*  55 */       return new HashMap();
/*     */     }
/*     */   };
/*     */   
/*  59 */   static ThreadLocal instancesVerify = new ThreadLocal() {
/*     */     protected Object initialValue() {
/*  61 */       return new HashMap();
/*     */     }
/*     */   };
/*     */   
/*  65 */   static ThreadLocal keysSigning = new ThreadLocal() {
/*     */     protected Object initialValue() {
/*  67 */       return new HashMap();
/*     */     }
/*     */   };
/*  70 */   static ThreadLocal keysVerify = new ThreadLocal() {
/*     */     protected Object initialValue() {
/*  72 */       return new HashMap();
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*  78 */   protected SignatureAlgorithmSpi _signatureAlgorithm = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String algorithmURI;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignatureAlgorithm(Document doc, String algorithmURI)
/*     */     throws XMLSecurityException
/*     */   {
/*  91 */     super(doc, algorithmURI);
/*  92 */     this.algorithmURI = algorithmURI;
/*     */   }
/*     */   
/*     */   private void initializeAlgorithm(boolean isForSigning) throws XMLSignatureException
/*     */   {
/*  97 */     if (this._signatureAlgorithm != null) {
/*  98 */       return;
/*     */     }
/* 100 */     this._signatureAlgorithm = (isForSigning ? getInstanceForSigning(this.algorithmURI) : getInstanceForVerify(this.algorithmURI));
/* 101 */     this._signatureAlgorithm
/* 102 */       .engineGetContextFromElement(this._constructionElement);
/*     */   }
/*     */   
/* 105 */   private static SignatureAlgorithmSpi getInstanceForSigning(String algorithmURI) throws XMLSignatureException { SignatureAlgorithmSpi result = (SignatureAlgorithmSpi)((Map)instancesSigning.get()).get(algorithmURI);
/* 106 */     if (result != null) {
/* 107 */       result.reset();
/* 108 */       return result;
/*     */     }
/* 110 */     result = buildSigner(algorithmURI, result);
/* 111 */     ((Map)instancesSigning.get()).put(algorithmURI, result);
/* 112 */     return result;
/*     */   }
/*     */   
/* 115 */   public static void clearInstanceForSigning() { ((Map)instancesSigning.get()).clear(); }
/*     */   
/*     */   private static SignatureAlgorithmSpi getInstanceForVerify(String algorithmURI) throws XMLSignatureException {
/* 118 */     SignatureAlgorithmSpi result = (SignatureAlgorithmSpi)((Map)instancesVerify.get()).get(algorithmURI);
/* 119 */     if (result != null) {
/* 120 */       result.reset();
/* 121 */       return result;
/*     */     }
/* 123 */     result = buildSigner(algorithmURI, result);
/* 124 */     ((Map)instancesVerify.get()).put(algorithmURI, result);
/* 125 */     return result;
/*     */   }
/*     */   
/*     */   private static SignatureAlgorithmSpi buildSigner(String algorithmURI, SignatureAlgorithmSpi result) throws XMLSignatureException {
/*     */     try {
/* 130 */       Class implementingClass = 
/* 131 */         getImplementingClass(algorithmURI);
/* 132 */       if (log.isDebugEnabled())
/* 133 */         log.debug("Create URI \"" + algorithmURI + "\" class \"" + 
/* 134 */           implementingClass + "\"");
/* 135 */       return (SignatureAlgorithmSpi)implementingClass.newInstance();
/*     */     }
/*     */     catch (IllegalAccessException ex) {
/* 138 */       Object[] exArgs = { algorithmURI, ex.getMessage() };
/*     */       
/* 140 */       throw new XMLSignatureException("algorithms.NoSuchAlgorithm", exArgs, 
/* 141 */         ex);
/*     */     } catch (InstantiationException ex) {
/* 143 */       Object[] exArgs = { algorithmURI, ex.getMessage() };
/*     */       
/* 145 */       throw new XMLSignatureException("algorithms.NoSuchAlgorithm", exArgs, 
/* 146 */         ex);
/*     */     } catch (NullPointerException ex) {
/* 148 */       Object[] exArgs = { algorithmURI, ex.getMessage() };
/*     */       
/* 150 */       throw new XMLSignatureException("algorithms.NoSuchAlgorithm", exArgs, 
/* 151 */         ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignatureAlgorithm(Document doc, String algorithmURI, int HMACOutputLength)
/*     */     throws XMLSecurityException
/*     */   {
/* 167 */     this(doc, algorithmURI);
/* 168 */     this.algorithmURI = algorithmURI;
/* 169 */     initializeAlgorithm(true);
/* 170 */     this._signatureAlgorithm.engineSetHMACOutputLength(HMACOutputLength);
/* 171 */     ((IntegrityHmac)this._signatureAlgorithm)
/* 172 */       .engineAddContextToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignatureAlgorithm(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 185 */     super(element, BaseURI);
/* 186 */     this.algorithmURI = getURI();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] sign()
/*     */     throws XMLSignatureException
/*     */   {
/* 197 */     return this._signatureAlgorithm.engineSign();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getJCEAlgorithmString()
/*     */   {
/*     */     try
/*     */     {
/* 208 */       return getInstanceForVerify(this.algorithmURI).engineGetJCEAlgorithmString();
/*     */     }
/*     */     catch (XMLSignatureException e) {}
/* 211 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getJCEProviderName()
/*     */   {
/*     */     try
/*     */     {
/* 222 */       return getInstanceForVerify(this.algorithmURI).engineGetJCEProviderName();
/*     */     } catch (XMLSignatureException e) {}
/* 224 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void update(byte[] input)
/*     */     throws XMLSignatureException
/*     */   {
/* 236 */     this._signatureAlgorithm.engineUpdate(input);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void update(byte input)
/*     */     throws XMLSignatureException
/*     */   {
/* 247 */     this._signatureAlgorithm.engineUpdate(input);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void update(byte[] buf, int offset, int len)
/*     */     throws XMLSignatureException
/*     */   {
/* 261 */     this._signatureAlgorithm.engineUpdate(buf, offset, len);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initSign(Key signingKey)
/*     */     throws XMLSignatureException
/*     */   {
/* 272 */     initializeAlgorithm(true);
/* 273 */     Map map = (Map)keysSigning.get();
/* 274 */     if (map.get(this.algorithmURI) == signingKey) {
/* 275 */       return;
/*     */     }
/* 277 */     map.put(this.algorithmURI, signingKey);
/* 278 */     this._signatureAlgorithm.engineInitSign(signingKey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initSign(Key signingKey, SecureRandom secureRandom)
/*     */     throws XMLSignatureException
/*     */   {
/* 291 */     initializeAlgorithm(true);
/* 292 */     this._signatureAlgorithm.engineInitSign(signingKey, secureRandom);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initSign(Key signingKey, AlgorithmParameterSpec algorithmParameterSpec)
/*     */     throws XMLSignatureException
/*     */   {
/* 306 */     initializeAlgorithm(true);
/* 307 */     this._signatureAlgorithm.engineInitSign(signingKey, 
/* 308 */       algorithmParameterSpec);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParameter(AlgorithmParameterSpec params)
/*     */     throws XMLSignatureException
/*     */   {
/* 320 */     this._signatureAlgorithm.engineSetParameter(params);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initVerify(Key verificationKey)
/*     */     throws XMLSignatureException
/*     */   {
/* 331 */     initializeAlgorithm(false);
/* 332 */     Map map = (Map)keysVerify.get();
/* 333 */     if (map.get(this.algorithmURI) == verificationKey) {
/* 334 */       return;
/*     */     }
/* 336 */     map.put(this.algorithmURI, verificationKey);
/* 337 */     this._signatureAlgorithm.engineInitVerify(verificationKey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean verify(byte[] signature)
/*     */     throws XMLSignatureException
/*     */   {
/* 350 */     return this._signatureAlgorithm.engineVerify(signature);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getURI()
/*     */   {
/* 359 */     return this._constructionElement.getAttributeNS(null, 
/* 360 */       "Algorithm");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void providerInit()
/*     */   {
/* 369 */     if (log == null) {
/* 370 */       log = 
/*     */       
/* 372 */         LogFactory.getLog(SignatureAlgorithm.class.getName());
/*     */     }
/*     */     
/* 375 */     log.debug("Init() called");
/*     */     
/* 377 */     if (!_alreadyInitialized) {
/* 378 */       _algorithmHash = new HashMap(10);
/* 379 */       _alreadyInitialized = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void register(String algorithmURI, String implementingClass)
/*     */     throws AlgorithmAlreadyRegisteredException, XMLSignatureException
/*     */   {
/* 395 */     if (log.isDebugEnabled()) {
/* 396 */       log.debug("Try to register " + algorithmURI + " " + implementingClass);
/*     */     }
/*     */     
/* 399 */     Class registeredClassClass = 
/* 400 */       getImplementingClass(algorithmURI);
/* 401 */     if (registeredClassClass != null) {
/* 402 */       String registeredClass = registeredClassClass.getName();
/*     */       
/* 404 */       if ((registeredClass != null) && (registeredClass.length() != 0)) {
/* 405 */         Object[] exArgs = { algorithmURI, registeredClass };
/*     */         
/* 407 */         throw new AlgorithmAlreadyRegisteredException(
/* 408 */           "algorithm.alreadyRegistered", exArgs);
/*     */       }
/*     */     }
/*     */     try {
/* 412 */       _algorithmHash.put(algorithmURI, Class.forName(implementingClass));
/*     */     } catch (ClassNotFoundException ex) {
/* 414 */       Object[] exArgs = { algorithmURI, ex.getMessage() };
/*     */       
/* 416 */       throw new XMLSignatureException("algorithms.NoSuchAlgorithm", exArgs, 
/* 417 */         ex);
/*     */     } catch (NullPointerException ex) {
/* 419 */       Object[] exArgs = { algorithmURI, ex.getMessage() };
/*     */       
/* 421 */       throw new XMLSignatureException("algorithms.NoSuchAlgorithm", exArgs, 
/* 422 */         ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Class getImplementingClass(String URI)
/*     */   {
/* 436 */     if (_algorithmHash == null) {
/* 437 */       return null;
/*     */     }
/*     */     
/* 440 */     return (Class)_algorithmHash.get(URI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBaseNamespace()
/*     */   {
/* 449 */     return "http://www.w3.org/2000/09/xmldsig#";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBaseLocalName()
/*     */   {
/* 458 */     return "SignatureMethod";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\algorithms\SignatureAlgorithm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */