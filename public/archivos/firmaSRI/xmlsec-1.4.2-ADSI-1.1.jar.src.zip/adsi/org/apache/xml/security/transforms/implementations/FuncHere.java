/*     */ package adsi.org.apache.xml.security.transforms.implementations;
/*     */ 
/*     */ import adsi.org.apache.xml.security.utils.I18n;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import java.util.Vector;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import org.apache.xml.dtm.DTM;
/*     */ import org.apache.xpath.NodeSetDTM;
/*     */ import org.apache.xpath.XPathContext;
/*     */ import org.apache.xpath.functions.Function;
/*     */ import org.apache.xpath.objects.XNodeSet;
/*     */ import org.apache.xpath.objects.XObject;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FuncHere
/*     */   extends Function
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public XObject execute(XPathContext xctxt)
/*     */     throws TransformerException
/*     */   {
/*  75 */     Node xpathOwnerNode = (Node)xctxt.getOwnerObject();
/*     */     
/*  77 */     if (xpathOwnerNode == null) {
/*  78 */       return null;
/*     */     }
/*     */     
/*  81 */     int xpathOwnerNodeDTM = xctxt.getDTMHandleFromNode(xpathOwnerNode);
/*     */     
/*  83 */     int currentNode = xctxt.getCurrentNode();
/*  84 */     DTM dtm = xctxt.getDTM(currentNode);
/*  85 */     int docContext = dtm.getDocument();
/*     */     
/*  87 */     if (-1 == docContext) {
/*  88 */       error(xctxt, "ER_CONTEXT_HAS_NO_OWNERDOC", null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  95 */     Document currentDoc = 
/*  96 */       XMLUtils.getOwnerDocument(dtm.getNode(currentNode));
/*  97 */     Document xpathOwnerDoc = XMLUtils.getOwnerDocument(xpathOwnerNode);
/*     */     
/*  99 */     if (currentDoc != xpathOwnerDoc) {
/* 100 */       throw new TransformerException(
/* 101 */         I18n.translate("xpath.funcHere.documentsDiffer"));
/*     */     }
/*     */     
/*     */ 
/* 105 */     XNodeSet nodes = new XNodeSet(xctxt.getDTMManager());
/* 106 */     NodeSetDTM nodeSet = nodes.mutableNodeset();
/*     */     
/*     */ 
/* 109 */     int hereNode = -1;
/*     */     
/* 111 */     switch (dtm.getNodeType(xpathOwnerNodeDTM))
/*     */     {
/*     */ 
/*     */     case 2: 
/* 115 */       hereNode = xpathOwnerNodeDTM;
/*     */       
/* 117 */       nodeSet.addNode(hereNode);
/*     */       
/* 119 */       break;
/*     */     
/*     */ 
/*     */     case 7: 
/* 123 */       hereNode = xpathOwnerNodeDTM;
/*     */       
/* 125 */       nodeSet.addNode(hereNode);
/*     */       
/* 127 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */     case 3: 
/* 132 */       hereNode = dtm.getParent(xpathOwnerNodeDTM);
/*     */       
/* 134 */       nodeSet.addNode(hereNode);
/*     */       
/* 136 */       break;
/*     */     }
/*     */     
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 144 */     nodeSet.detach();
/*     */     
/* 146 */     return nodes;
/*     */   }
/*     */   
/*     */   public void fixupVariables(Vector vars, int globalsSize) {}
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\transforms\implementations\FuncHere.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */