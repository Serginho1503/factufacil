/*     */ package adsi.org.apache.xml.security.signature;
/*     */ 
/*     */ import adsi.org.apache.xml.security.algorithms.SignatureAlgorithm;
/*     */ import adsi.org.apache.xml.security.c14n.CanonicalizationException;
/*     */ import adsi.org.apache.xml.security.c14n.InvalidCanonicalizerException;
/*     */ import adsi.org.apache.xml.security.exceptions.Base64DecodingException;
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import adsi.org.apache.xml.security.keys.KeyInfo;
/*     */ import adsi.org.apache.xml.security.keys.content.X509Data;
/*     */ import adsi.org.apache.xml.security.transforms.Transforms;
/*     */ import adsi.org.apache.xml.security.utils.Base64;
/*     */ import adsi.org.apache.xml.security.utils.I18n;
/*     */ import adsi.org.apache.xml.security.utils.IdResolver;
/*     */ import adsi.org.apache.xml.security.utils.SignatureElementProxy;
/*     */ import adsi.org.apache.xml.security.utils.SignerOutputStream;
/*     */ import adsi.org.apache.xml.security.utils.UnsyncBufferedOutputStream;
/*     */ import adsi.org.apache.xml.security.utils.XMLUtils;
/*     */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolver;
/*     */ import adsi.org.apache.xml.security.utils.resolver.ResourceResolverSpi;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.security.Key;
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.crypto.SecretKey;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class XMLSignature
/*     */   extends SignatureElementProxy
/*     */ {
/*  81 */   static Log log = LogFactory.getLog(XMLSignature.class.getName());
/*     */   
/*     */ 
/*     */   public static final String ALGO_ID_MAC_HMAC_SHA1 = "http://www.w3.org/2000/09/xmldsig#hmac-sha1";
/*     */   
/*     */ 
/*     */   public static final String ALGO_ID_SIGNATURE_DSA = "http://www.w3.org/2000/09/xmldsig#dsa-sha1";
/*     */   
/*     */ 
/*     */   public static final String ALGO_ID_SIGNATURE_RSA = "http://www.w3.org/2000/09/xmldsig#rsa-sha1";
/*     */   
/*     */ 
/*     */   public static final String ALGO_ID_SIGNATURE_RSA_SHA1 = "http://www.w3.org/2000/09/xmldsig#rsa-sha1";
/*     */   
/*     */ 
/*     */   public static final String ALGO_ID_SIGNATURE_NOT_RECOMMENDED_RSA_MD5 = "http://www.w3.org/2001/04/xmldsig-more#rsa-md5";
/*     */   
/*     */ 
/*     */   public static final String ALGO_ID_SIGNATURE_RSA_RIPEMD160 = "http://www.w3.org/2001/04/xmldsig-more#rsa-ripemd160";
/*     */   
/*     */ 
/*     */   public static final String ALGO_ID_SIGNATURE_RSA_SHA256 = "http://www.w3.org/2001/04/xmldsig-more#rsa-sha256";
/*     */   
/*     */ 
/*     */   public static final String ALGO_ID_SIGNATURE_RSA_SHA384 = "http://www.w3.org/2001/04/xmldsig-more#rsa-sha384";
/*     */   
/*     */ 
/*     */   public static final String ALGO_ID_SIGNATURE_RSA_SHA512 = "http://www.w3.org/2001/04/xmldsig-more#rsa-sha512";
/*     */   
/*     */   public static final String ALGO_ID_MAC_HMAC_NOT_RECOMMENDED_MD5 = "http://www.w3.org/2001/04/xmldsig-more#hmac-md5";
/*     */   
/*     */   public static final String ALGO_ID_MAC_HMAC_RIPEMD160 = "http://www.w3.org/2001/04/xmldsig-more#hmac-ripemd160";
/*     */   
/*     */   public static final String ALGO_ID_MAC_HMAC_SHA256 = "http://www.w3.org/2001/04/xmldsig-more#hmac-sha256";
/*     */   
/*     */   public static final String ALGO_ID_MAC_HMAC_SHA384 = "http://www.w3.org/2001/04/xmldsig-more#hmac-sha384";
/*     */   
/*     */   public static final String ALGO_ID_MAC_HMAC_SHA512 = "http://www.w3.org/2001/04/xmldsig-more#hmac-sha512";
/*     */   
/*     */   public static final String ALGO_ID_SIGNATURE_ECDSA_SHA1 = "http://www.w3.org/2001/04/xmldsig-more#ecdsa-sha1";
/*     */   
/* 122 */   private SignedInfo _signedInfo = null;
/*     */   
/*     */ 
/* 125 */   private KeyInfo _keyInfo = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 132 */   private boolean _followManifestsDuringValidation = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Element signatureValueElement;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignature(Document doc, String BaseURI, String SignatureMethodURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 151 */     this(doc, BaseURI, SignatureMethodURI, 0, "http://www.w3.org/TR/2001/REC-xml-c14n-20010315");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignature(Document doc, String BaseURI, String SignatureMethodURI, int HMACOutputLength)
/*     */     throws XMLSecurityException
/*     */   {
/* 167 */     this(doc, BaseURI, SignatureMethodURI, HMACOutputLength, "http://www.w3.org/TR/2001/REC-xml-c14n-20010315");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignature(Document doc, String BaseURI, String SignatureMethodURI, String CanonicalizationMethodURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 182 */     this(doc, BaseURI, SignatureMethodURI, 0, CanonicalizationMethodURI);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignature(Document doc, String BaseURI, String SignatureMethodURI, int HMACOutputLength, String CanonicalizationMethodURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 199 */     super(doc);
/*     */     
/* 201 */     String xmlnsDsPrefix = 
/* 202 */       getDefaultPrefixBindings("http://www.w3.org/2000/09/xmldsig#");
/* 203 */     if (xmlnsDsPrefix == null) {
/* 204 */       this._constructionElement.setAttributeNS(
/* 205 */         "http://www.w3.org/2000/xmlns/", "xmlns", "http://www.w3.org/2000/09/xmldsig#");
/*     */     } else {
/* 207 */       this._constructionElement.setAttributeNS(
/* 208 */         "http://www.w3.org/2000/xmlns/", xmlnsDsPrefix, "http://www.w3.org/2000/09/xmldsig#");
/*     */     }
/* 210 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */     
/* 212 */     this._baseURI = BaseURI;
/* 213 */     this._signedInfo = new SignedInfo(this._doc, SignatureMethodURI, 
/* 214 */       HMACOutputLength, 
/* 215 */       CanonicalizationMethodURI);
/*     */     
/* 217 */     this._constructionElement.appendChild(this._signedInfo.getElement());
/* 218 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */     
/*     */ 
/* 221 */     this.signatureValueElement = 
/* 222 */       XMLUtils.createElementInSignatureSpace(this._doc, 
/* 223 */       "SignatureValue");
/*     */     
/* 225 */     this._constructionElement.appendChild(this.signatureValueElement);
/* 226 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignature(Document doc, String BaseURI, Element SignatureMethodElem, Element CanonicalizationMethodElem)
/*     */     throws XMLSecurityException
/*     */   {
/* 240 */     super(doc);
/*     */     
/* 242 */     String xmlnsDsPrefix = 
/* 243 */       getDefaultPrefixBindings("http://www.w3.org/2000/09/xmldsig#");
/* 244 */     if (xmlnsDsPrefix == null) {
/* 245 */       this._constructionElement.setAttributeNS(
/* 246 */         "http://www.w3.org/2000/xmlns/", "xmlns", "http://www.w3.org/2000/09/xmldsig#");
/*     */     } else {
/* 248 */       this._constructionElement.setAttributeNS(
/* 249 */         "http://www.w3.org/2000/xmlns/", xmlnsDsPrefix, "http://www.w3.org/2000/09/xmldsig#");
/*     */     }
/* 251 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */     
/* 253 */     this._baseURI = BaseURI;
/* 254 */     this._signedInfo = new SignedInfo(this._doc, SignatureMethodElem, CanonicalizationMethodElem);
/*     */     
/* 256 */     this._constructionElement.appendChild(this._signedInfo.getElement());
/* 257 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */     
/*     */ 
/* 260 */     this.signatureValueElement = 
/* 261 */       XMLUtils.createElementInSignatureSpace(this._doc, 
/* 262 */       "SignatureValue");
/*     */     
/* 264 */     this._constructionElement.appendChild(this.signatureValueElement);
/* 265 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLSignature(Element element, String BaseURI)
/*     */     throws XMLSignatureException, XMLSecurityException
/*     */   {
/* 280 */     super(element, BaseURI);
/*     */     
/*     */ 
/* 283 */     Element signedInfoElem = XMLUtils.getNextElement(element.getFirstChild());
/*     */     
/*     */ 
/*     */ 
/* 287 */     if (signedInfoElem == null) {
/* 288 */       Object[] exArgs = { "SignedInfo", 
/* 289 */         "Signature" };
/*     */       
/* 291 */       throw new XMLSignatureException("xml.WrongContent", exArgs);
/*     */     }
/*     */     
/*     */ 
/* 295 */     this._signedInfo = new SignedInfo(signedInfoElem, BaseURI);
/*     */     
/*     */ 
/* 298 */     this.signatureValueElement = XMLUtils.getNextElement(signedInfoElem.getNextSibling());
/*     */     
/*     */ 
/*     */ 
/* 302 */     if (this.signatureValueElement == null) {
/* 303 */       Object[] exArgs = { "SignatureValue", 
/* 304 */         "Signature" };
/*     */       
/* 306 */       throw new XMLSignatureException("xml.WrongContent", exArgs);
/*     */     }
/*     */     
/*     */ 
/* 310 */     Element keyInfoElem = XMLUtils.getNextElement(this.signatureValueElement.getNextSibling());
/*     */     
/*     */ 
/*     */ 
/* 314 */     if ((keyInfoElem != null) && (keyInfoElem.getNamespaceURI().equals("http://www.w3.org/2000/09/xmldsig#")) && 
/* 315 */       (keyInfoElem.getLocalName().equals("KeyInfo"))) {
/* 316 */       this._keyInfo = new KeyInfo(keyInfoElem, BaseURI);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setId(String Id)
/*     */   {
/* 327 */     if (Id != null) {
/* 328 */       this._constructionElement.setAttributeNS(null, "Id", Id);
/* 329 */       IdResolver.registerElementById(this._constructionElement, Id);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getId()
/*     */   {
/* 339 */     return this._constructionElement.getAttributeNS(null, "Id");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SignedInfo getSignedInfo()
/*     */   {
/* 348 */     return this._signedInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getSignatureValue()
/*     */     throws XMLSignatureException
/*     */   {
/*     */     try
/*     */     {
/* 361 */       return Base64.decode(this.signatureValueElement);
/*     */     }
/*     */     catch (Base64DecodingException ex)
/*     */     {
/* 365 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setSignatureValueElement(byte[] bytes)
/*     */   {
/* 377 */     while (this.signatureValueElement.hasChildNodes()) {
/* 378 */       this.signatureValueElement.removeChild(
/* 379 */         this.signatureValueElement.getFirstChild());
/*     */     }
/*     */     
/* 382 */     String base64codedValue = Base64.encode(bytes);
/*     */     
/* 384 */     if ((base64codedValue.length() > 76) && (!XMLUtils.ignoreLineBreaks())) {
/* 385 */       base64codedValue = "\n" + base64codedValue + "\n";
/*     */     }
/*     */     
/* 388 */     Text t = this._doc.createTextNode(base64codedValue);
/* 389 */     this.signatureValueElement.appendChild(t);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyInfo getKeyInfo()
/*     */   {
/* 403 */     if (this._keyInfo == null)
/*     */     {
/*     */ 
/* 406 */       this._keyInfo = new KeyInfo(this._doc);
/*     */       
/*     */ 
/* 409 */       Element keyInfoElement = this._keyInfo.getElement();
/* 410 */       Element firstObject = null;
/* 411 */       Node sibling = this._constructionElement.getFirstChild();
/* 412 */       firstObject = XMLUtils.selectDsNode(sibling, "Object", 0);
/*     */       
/* 414 */       if (firstObject != null)
/*     */       {
/*     */ 
/* 417 */         this._constructionElement.insertBefore(keyInfoElement, 
/* 418 */           firstObject);
/* 419 */         XMLUtils.addReturnBeforeChild(this._constructionElement, firstObject);
/*     */       }
/*     */       else
/*     */       {
/* 423 */         this._constructionElement.appendChild(keyInfoElement);
/* 424 */         XMLUtils.addReturnToElement(this._constructionElement);
/*     */       }
/*     */     }
/*     */     
/* 428 */     return this._keyInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void appendObject(ObjectContainer object)
/*     */     throws XMLSignatureException
/*     */   {
/* 448 */     this._constructionElement.appendChild(object.getElement());
/* 449 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectContainer getObjectItem(int i)
/*     */   {
/* 464 */     Element objElem = XMLUtils.selectDsNode(this._constructionElement.getFirstChild(), 
/* 465 */       "Object", i);
/*     */     try
/*     */     {
/* 468 */       return new ObjectContainer(objElem, this._baseURI);
/*     */     } catch (XMLSecurityException ex) {}
/* 470 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getObjectLength()
/*     */   {
/* 480 */     return length("http://www.w3.org/2000/09/xmldsig#", "Object");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void sign(Key signingKey)
/*     */     throws XMLSignatureException
/*     */   {
/* 492 */     if ((signingKey instanceof PublicKey)) {
/* 493 */       throw new IllegalArgumentException(
/* 494 */         I18n.translate("algorithms.operationOnlyVerification"));
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 500 */       SignedInfo si = getSignedInfo();
/* 501 */       SignatureAlgorithm sa = si.getSignatureAlgorithm();
/*     */       
/* 503 */       sa.initSign(signingKey);
/*     */       
/*     */ 
/* 506 */       si.generateDigestValues();
/* 507 */       OutputStream so = new UnsyncBufferedOutputStream(new SignerOutputStream(sa));
/*     */       try {
/* 509 */         so.close();
/*     */       }
/*     */       catch (IOException localIOException) {}
/*     */       
/*     */ 
/* 514 */       si.signInOctectStream(so);
/*     */       
/* 516 */       byte[] jcebytes = sa.sign();
/*     */       
/*     */ 
/* 519 */       setSignatureValueElement(jcebytes);
/*     */     }
/*     */     catch (CanonicalizationException ex) {
/* 522 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (InvalidCanonicalizerException ex) {
/* 524 */       throw new XMLSignatureException("empty", ex);
/*     */     } catch (XMLSecurityException ex) {
/* 526 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addResourceResolver(ResourceResolver resolver)
/*     */   {
/* 536 */     getSignedInfo().addResourceResolver(resolver);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addResourceResolver(ResourceResolverSpi resolver)
/*     */   {
/* 545 */     getSignedInfo().addResourceResolver(resolver);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean checkSignatureValue(X509Certificate cert)
/*     */     throws XMLSignatureException
/*     */   {
/* 562 */     if (cert != null)
/*     */     {
/*     */ 
/* 565 */       return checkSignatureValue(cert.getPublicKey());
/*     */     }
/*     */     
/* 568 */     Object[] exArgs = { "Didn't get a certificate" };
/* 569 */     throw new XMLSignatureException("empty", exArgs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean checkSignatureValue(Key pk)
/*     */     throws XMLSignatureException
/*     */   {
/* 586 */     if (pk == null) {
/* 587 */       Object[] exArgs = { "Didn't get a key" };
/*     */       
/* 589 */       throw new XMLSignatureException("empty", exArgs);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 597 */       SignedInfo si = getSignedInfo();
/*     */       
/*     */ 
/* 600 */       SignatureAlgorithm sa = si.getSignatureAlgorithm();
/* 601 */       if (log.isDebugEnabled()) {
/* 602 */         log.debug("SignatureMethodURI = " + sa.getAlgorithmURI());
/* 603 */         log.debug("jceSigAlgorithm    = " + sa.getJCEAlgorithmString());
/* 604 */         log.debug("jceSigProvider     = " + sa.getJCEProviderName());
/* 605 */         log.debug("PublicKey = " + pk);
/*     */       }
/* 607 */       sa.initVerify(pk);
/*     */       
/*     */ 
/* 610 */       SignerOutputStream so = new SignerOutputStream(sa);
/* 611 */       OutputStream bos = new UnsyncBufferedOutputStream(so);
/* 612 */       si.signInOctectStream(bos);
/*     */       try {
/* 614 */         bos.close();
/*     */       }
/*     */       catch (IOException localIOException) {}
/*     */       
/*     */ 
/*     */ 
/* 620 */       byte[] sigBytes = getSignatureValue();
/*     */       
/*     */ 
/*     */ 
/* 624 */       if (!sa.verify(sigBytes)) {
/* 625 */         log.warn("Signature verification failed.");
/* 626 */         return false;
/*     */       }
/*     */       
/* 629 */       return si.verify(this._followManifestsDuringValidation);
/*     */     } catch (XMLSecurityException ex) {
/* 631 */       throw new XMLSignatureException("empty", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addDocument(String referenceURI, Transforms trans, String digestURI, String ReferenceId, String ReferenceType)
/*     */     throws XMLSignatureException
/*     */   {
/* 651 */     this._signedInfo.addDocument(this._baseURI, referenceURI, trans, 
/* 652 */       digestURI, ReferenceId, ReferenceType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addDocument(String referenceURI, Transforms trans, String digestURI)
/*     */     throws XMLSignatureException
/*     */   {
/* 667 */     this._signedInfo.addDocument(this._baseURI, referenceURI, trans, 
/* 668 */       digestURI, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addDocument(String referenceURI, Transforms trans)
/*     */     throws XMLSignatureException
/*     */   {
/* 681 */     this._signedInfo.addDocument(this._baseURI, referenceURI, trans, 
/* 682 */       "http://www.w3.org/2000/09/xmldsig#sha1", null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addDocument(String referenceURI)
/*     */     throws XMLSignatureException
/*     */   {
/* 693 */     this._signedInfo.addDocument(this._baseURI, referenceURI, null, 
/* 694 */       "http://www.w3.org/2000/09/xmldsig#sha1", null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addKeyInfo(X509Certificate cert)
/*     */     throws XMLSecurityException
/*     */   {
/* 706 */     X509Data x509data = new X509Data(this._doc);
/*     */     
/* 708 */     x509data.addCertificate(cert);
/* 709 */     getKeyInfo().add(x509data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addKeyInfo(PublicKey pk)
/*     */   {
/* 719 */     getKeyInfo().add(pk);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SecretKey createSecretKey(byte[] secretKeyBytes)
/*     */   {
/* 733 */     return getSignedInfo().createSecretKey(secretKeyBytes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFollowNestedManifests(boolean followManifests)
/*     */   {
/* 746 */     this._followManifestsDuringValidation = followManifests;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBaseLocalName()
/*     */   {
/* 755 */     return "Signature";
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\signature\XMLSignature.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */