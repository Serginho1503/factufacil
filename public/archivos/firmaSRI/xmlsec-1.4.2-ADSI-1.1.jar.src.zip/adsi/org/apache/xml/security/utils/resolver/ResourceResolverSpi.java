/*     */ package adsi.org.apache.xml.security.utils.resolver;
/*     */ 
/*     */ import adsi.org.apache.xml.security.signature.XMLSignatureInput;
/*     */ import java.io.File;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Attr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ResourceResolverSpi
/*     */ {
/*  43 */   static Log log = LogFactory.getLog(
/*  44 */     ResourceResolverSpi.class.getName());
/*     */   
/*     */ 
/*  47 */   protected Map _properties = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract XMLSignatureInput engineResolve(Attr paramAttr, String paramString)
/*     */     throws ResourceResolverException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void engineSetProperty(String key, String value)
/*     */   {
/*  68 */     if (this._properties == null) {
/*  69 */       this._properties = new HashMap();
/*     */     }
/*  71 */     this._properties.put(key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String engineGetProperty(String key)
/*     */   {
/*  81 */     if (this._properties == null) {
/*  82 */       return null;
/*     */     }
/*  84 */     return (String)this._properties.get(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void engineAddProperies(Map properties)
/*     */   {
/*  92 */     if (properties != null) {
/*  93 */       if (this._properties == null) {
/*  94 */         this._properties = new HashMap();
/*     */       }
/*  96 */       this._properties.putAll(properties);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean engineIsThreadSafe()
/*     */   {
/* 106 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean engineIsPrivateData()
/*     */   {
/* 117 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean engineCanResolve(Attr paramAttr, String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] engineGetPropertyKeys()
/*     */   {
/* 135 */     return new String[0];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean understandsProperty(String propertyToTest)
/*     */   {
/* 146 */     String[] understood = engineGetPropertyKeys();
/*     */     
/* 148 */     if (understood != null) {
/* 149 */       for (int i = 0; i < understood.length; i++) {
/* 150 */         if (understood[i].equals(propertyToTest)) {
/* 151 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 156 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String fixURI(String str)
/*     */   {
/* 170 */     str = str.replace(File.separatorChar, '/');
/*     */     
/* 172 */     if (str.length() >= 4)
/*     */     {
/*     */ 
/* 175 */       char ch0 = Character.toUpperCase(str.charAt(0));
/* 176 */       char ch1 = str.charAt(1);
/* 177 */       char ch2 = str.charAt(2);
/* 178 */       char ch3 = str.charAt(3);
/* 179 */       boolean isDosFilename = ('A' <= ch0) && (ch0 <= 'Z') && 
/* 180 */         (ch1 == ':') && (ch2 == '/') && 
/* 181 */         (ch3 != '/');
/*     */       
/* 183 */       if ((isDosFilename) && 
/* 184 */         (log.isDebugEnabled())) {
/* 185 */         log.debug("Found DOS filename: " + str);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 190 */     if (str.length() >= 2) {
/* 191 */       char ch1 = str.charAt(1);
/*     */       
/* 193 */       if (ch1 == ':') {
/* 194 */         char ch0 = Character.toUpperCase(str.charAt(0));
/*     */         
/* 196 */         if (('A' <= ch0) && (ch0 <= 'Z')) {
/* 197 */           str = "/" + str;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 203 */     return str;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\utils\resolver\ResourceResolverSpi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */