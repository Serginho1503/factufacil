/*     */ package adsi.org.apache.xml.security.utils;
/*     */ 
/*     */ import adsi.org.apache.xml.security.exceptions.Base64DecodingException;
/*     */ import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
/*     */ import java.math.BigInteger;
/*     */ import java.util.HashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ElementProxy
/*     */ {
/*  45 */   static Log log = LogFactory.getLog(ElementProxy.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  62 */   protected Element _constructionElement = null;
/*     */   
/*     */ 
/*  65 */   protected String _baseURI = null;
/*     */   
/*     */ 
/*  68 */   protected Document _doc = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract String getBaseNamespace();
/*     */   
/*     */ 
/*     */   public abstract String getBaseLocalName();
/*     */   
/*     */ 
/*     */   public ElementProxy() {}
/*     */   
/*     */ 
/*     */   public ElementProxy(Document doc)
/*     */   {
/*  83 */     if (doc == null) {
/*  84 */       throw new RuntimeException("Document is null");
/*     */     }
/*     */     
/*  87 */     this._doc = doc;
/*  88 */     this._constructionElement = createElementForFamilyLocal(this._doc, 
/*  89 */       getBaseNamespace(), getBaseLocalName());
/*     */   }
/*     */   
/*     */   protected Element createElementForFamilyLocal(Document doc, String namespace, String localName) {
/*  93 */     Element result = null;
/*  94 */     if (namespace == null) {
/*  95 */       result = doc.createElementNS(null, localName);
/*     */     } else {
/*  97 */       String baseName = getBaseNamespace();
/*  98 */       String prefix = getDefaultPrefix(baseName);
/*  99 */       if ((prefix == null) || (prefix.length() == 0)) {
/* 100 */         result = doc.createElementNS(namespace, localName);
/*     */         
/* 102 */         result.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns", 
/* 103 */           namespace);
/*     */       } else {
/* 105 */         String tagName = null;
/* 106 */         String defaultPrefixNaming = getDefaultPrefixBindings(baseName);
/* 107 */         StringBuffer sb = new StringBuffer(prefix);
/* 108 */         sb.append(':');
/* 109 */         sb.append(localName);
/* 110 */         tagName = sb.toString();
/* 111 */         result = doc.createElementNS(namespace, tagName);
/*     */         
/* 113 */         result.setAttributeNS("http://www.w3.org/2000/xmlns/", defaultPrefixNaming, 
/* 114 */           namespace);
/*     */       }
/*     */     }
/* 117 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Element createElementForFamily(Document doc, String namespace, String localName)
/*     */   {
/* 136 */     Element result = null;
/* 137 */     String prefix = getDefaultPrefix(namespace);
/*     */     
/* 139 */     if (namespace == null) {
/* 140 */       result = doc.createElementNS(null, localName);
/*     */     }
/* 142 */     else if ((prefix == null) || (prefix.length() == 0)) {
/* 143 */       result = doc.createElementNS(namespace, localName);
/*     */       
/* 145 */       result.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns", 
/* 146 */         namespace);
/*     */     } else {
/* 148 */       result = doc.createElementNS(namespace, prefix + ":" + localName);
/*     */       
/* 150 */       result.setAttributeNS("http://www.w3.org/2000/xmlns/", getDefaultPrefixBindings(namespace), 
/* 151 */         namespace);
/*     */     }
/*     */     
/*     */ 
/* 155 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setElement(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 168 */     if (element == null) {
/* 169 */       throw new XMLSecurityException("ElementProxy.nullElement");
/*     */     }
/*     */     
/* 172 */     if (log.isDebugEnabled()) {
/* 173 */       log.debug("setElement(" + element.getTagName() + ", \"" + BaseURI + "\"");
/*     */     }
/*     */     
/* 176 */     this._doc = element.getOwnerDocument();
/* 177 */     this._constructionElement = element;
/* 178 */     this._baseURI = BaseURI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ElementProxy(Element element, String BaseURI)
/*     */     throws XMLSecurityException
/*     */   {
/* 190 */     if (element == null) {
/* 191 */       throw new XMLSecurityException("ElementProxy.nullElement");
/*     */     }
/*     */     
/* 194 */     if (log.isDebugEnabled()) {
/* 195 */       log.debug("setElement(\"" + element.getTagName() + "\", \"" + BaseURI + 
/* 196 */         "\")");
/*     */     }
/*     */     
/* 199 */     this._doc = element.getOwnerDocument();
/* 200 */     this._constructionElement = element;
/* 201 */     this._baseURI = BaseURI;
/*     */     
/* 203 */     guaranteeThatElementInCorrectSpace();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Element getElement()
/*     */   {
/* 212 */     return this._constructionElement;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final NodeList getElementPlusReturns()
/*     */   {
/* 222 */     HelperNodeList nl = new HelperNodeList();
/*     */     
/* 224 */     nl.appendChild(this._doc.createTextNode("\n"));
/* 225 */     nl.appendChild(getElement());
/* 226 */     nl.appendChild(this._doc.createTextNode("\n"));
/*     */     
/* 228 */     return nl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Document getDocument()
/*     */   {
/* 237 */     return this._doc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBaseURI()
/*     */   {
/* 246 */     return this._baseURI;
/*     */   }
/*     */   
/* 249 */   static ElementChecker checker = new ElementCheckerImpl.InternedNsChecker();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void guaranteeThatElementInCorrectSpace()
/*     */     throws XMLSecurityException
/*     */   {
/* 259 */     checker.guaranteeThatElementInCorrectSpace(this, this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addBigIntegerElement(BigInteger bi, String localname)
/*     */   {
/* 271 */     if (bi != null) {
/* 272 */       Element e = XMLUtils.createElementInSignatureSpace(this._doc, 
/* 273 */         localname);
/*     */       
/* 275 */       Base64.fillElementWithBigInteger(e, bi);
/* 276 */       this._constructionElement.appendChild(e);
/* 277 */       XMLUtils.addReturnToElement(this._constructionElement);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addBase64Element(byte[] bytes, String localname)
/*     */   {
/* 289 */     if (bytes != null)
/*     */     {
/* 291 */       Element e = Base64.encodeToElement(this._doc, localname, bytes);
/*     */       
/* 293 */       this._constructionElement.appendChild(e);
/* 294 */       if (!XMLUtils.ignoreLineBreaks()) {
/* 295 */         this._constructionElement.appendChild(this._doc.createTextNode("\n"));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addTextElement(String text, String localname)
/*     */   {
/* 308 */     Element e = XMLUtils.createElementInSignatureSpace(this._doc, localname);
/* 309 */     Text t = this._doc.createTextNode(text);
/*     */     
/* 311 */     e.appendChild(t);
/* 312 */     this._constructionElement.appendChild(e);
/* 313 */     XMLUtils.addReturnToElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addBase64Text(byte[] bytes)
/*     */   {
/* 323 */     if (bytes != null) {
/* 324 */       Text t = XMLUtils.ignoreLineBreaks() ? 
/* 325 */         this._doc.createTextNode(Base64.encode(bytes)) : 
/* 326 */         this._doc.createTextNode("\n" + Base64.encode(bytes) + "\n");
/* 327 */       this._constructionElement.appendChild(t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addText(String text)
/*     */   {
/* 338 */     if (text != null) {
/* 339 */       Text t = this._doc.createTextNode(text);
/*     */       
/* 341 */       this._constructionElement.appendChild(t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BigInteger getBigIntegerFromChildElement(String localname, String namespace)
/*     */     throws Base64DecodingException
/*     */   {
/* 356 */     return Base64.decodeBigIntegerFromText(
/* 357 */       XMLUtils.selectNodeText(this._constructionElement.getFirstChild(), 
/* 358 */       namespace, localname, 0));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public byte[] getBytesFromChildElement(String localname, String namespace)
/*     */     throws XMLSecurityException
/*     */   {
/* 373 */     Element e = 
/* 374 */       XMLUtils.selectNode(
/* 375 */       this._constructionElement.getFirstChild(), 
/* 376 */       namespace, 
/* 377 */       localname, 
/* 378 */       0);
/*     */     
/* 380 */     return Base64.decode(e);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTextFromChildElement(String localname, String namespace)
/*     */   {
/* 392 */     Text t = 
/* 393 */       (Text)XMLUtils.selectNode(
/* 394 */       this._constructionElement.getFirstChild(), 
/* 395 */       namespace, 
/* 396 */       localname, 
/* 397 */       0).getFirstChild();
/*     */     
/* 399 */     return t.getData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getBytesFromTextChild()
/*     */     throws XMLSecurityException
/*     */   {
/* 409 */     return Base64.decode(
/* 410 */       XMLUtils.getFullTextChildrenFromElement(this._constructionElement));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTextFromTextChild()
/*     */   {
/* 420 */     return XMLUtils.getFullTextChildrenFromElement(this._constructionElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int length(String namespace, String localname)
/*     */   {
/* 431 */     int number = 0;
/* 432 */     Node sibling = this._constructionElement.getFirstChild();
/* 433 */     while (sibling != null) {
/* 434 */       if (localname.equals(sibling.getLocalName()))
/*     */       {
/* 436 */         if (namespace == sibling.getNamespaceURI())
/* 437 */           number++;
/*     */       }
/* 439 */       sibling = sibling.getNextSibling();
/*     */     }
/* 441 */     return number;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXPathNamespaceContext(String prefix, String uri)
/*     */     throws XMLSecurityException
/*     */   {
/* 462 */     if ((prefix == null) || (prefix.length() == 0))
/* 463 */       throw new XMLSecurityException("defaultNamespaceCannotBeSetHere");
/* 464 */     if (prefix.equals("xmlns"))
/* 465 */       throw new XMLSecurityException("defaultNamespaceCannotBeSetHere");
/* 466 */     String ns; String ns; if (prefix.startsWith("xmlns:")) {
/* 467 */       ns = prefix;
/*     */     } else {
/* 469 */       ns = "xmlns:" + prefix;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 474 */     Attr a = this._constructionElement.getAttributeNodeNS("http://www.w3.org/2000/xmlns/", ns);
/*     */     
/* 476 */     if (a != null) {
/* 477 */       if (!a.getNodeValue().equals(uri)) {
/* 478 */         Object[] exArgs = { ns, 
/* 479 */           this._constructionElement.getAttributeNS(null, 
/* 480 */           ns) };
/*     */         
/* 482 */         throw new XMLSecurityException("namespacePrefixAlreadyUsedByOtherURI", 
/* 483 */           exArgs);
/*     */       }
/* 485 */       return;
/*     */     }
/*     */     
/* 488 */     this._constructionElement.setAttributeNS("http://www.w3.org/2000/xmlns/", ns, 
/* 489 */       uri);
/*     */   }
/*     */   
/*     */ 
/* 493 */   static HashMap _prefixMappings = new HashMap();
/* 494 */   static HashMap _prefixMappingsBindings = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setDefaultPrefix(String namespace, String prefix)
/*     */     throws XMLSecurityException
/*     */   {
/* 506 */     if (_prefixMappings.containsValue(prefix))
/*     */     {
/* 508 */       Object storedNamespace = _prefixMappings.get(namespace);
/* 509 */       if (!storedNamespace.equals(prefix)) {
/* 510 */         Object[] exArgs = { prefix, namespace, storedNamespace };
/*     */         
/* 512 */         throw new XMLSecurityException("prefix.AlreadyAssigned", exArgs);
/*     */       }
/*     */     }
/* 515 */     if ("http://www.w3.org/2000/09/xmldsig#".equals(namespace)) {
/* 516 */       XMLUtils.dsPrefix = prefix;
/*     */     }
/* 518 */     _prefixMappings.put(namespace, prefix.intern());
/* 519 */     if (prefix.length() == 0) {
/* 520 */       _prefixMappingsBindings.put(namespace, "xmlns");
/*     */     } else {
/* 522 */       _prefixMappingsBindings.put(namespace, ("xmlns:" + prefix).intern());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getDefaultPrefix(String namespace)
/*     */   {
/* 533 */     return (String)_prefixMappings.get(namespace);
/*     */   }
/*     */   
/*     */   public static String getDefaultPrefixBindings(String namespace) {
/* 537 */     return (String)_prefixMappingsBindings.get(namespace);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xmlsec-1.4.2-ADSI-1.1.jar!\adsi\org\apache\xml\security\utils\ElementProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */