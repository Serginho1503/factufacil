package es.mityc.javasign.ts;

public final class ConstantsTSA
{
  public static final String LIB_NAME = "MITyCLibTSA";
  public static final String FORMATO_FECHA = "dd/MM/yyyy H:mm:ss.SSS";
  public static final String AFIRMA_ID_APLICACION_OID = "1.3.4.6.1.3.4.6";
  public static final String MENSAJE_NO_ALGORITMO_HASH = "No se ha encontrado un algoritmo hash válido para el Sello de Tiempo. Se va a utilizar el algoritmo SHA1 por defecto";
  public static final String MENSAJE_NO_DATOS_SELLO_TIEMPO = "No se han especificado los datos sobre los que generar el sello de tiempo";
  public static final String MENSAJE_GENERANDO_SELLO_TIEMPO = "Se va a generar el sello de tiempo ...";
  public static final String MENSAJE_PETICION_TSA_GENERADA = "Petición TSA generada";
  public static final String MENSAJE_ERROR_PETICION_TSA = "Ha ocurrido un error al generar la petición TSA";
  public static final String CONTENT_TYPE = "Content-Type";
  public static final String APPLICATION_TIMESTAMP_QUERY = "application/timestamp-query";
  public static final String MENSAJE_ERROR_PETICION = "Error al leer la petición: ";
  public static final String MENSAJE_PETICION_TSA_ENVIADA = "Petición TSA enviada.";
  public static final String MENSAJE_FALLO_EJECUCION_METODO = "Fallo la ejecución del método: ";
  public static final String MENSAJE_RESPUESTA_TSA_OBTENIDA = "Respuesta TSA obtenida.";
  public static final String MENSAJE_RESPUESTA_TSA_VALIDADA_OK = "Respuesta TSA validada OK";
  public static final String MENSAJE_RESPUESTA_NO_VALIDA = "La respuesta no es válida para la petición enviada: ";
  public static final String MENSAJE_RESPUESTA_MAL_FORMADA = "La respuesta está mal formada: ";
  public static final String MENSAJE_SECUENCIA_BYTES_MAL_CODIFICADA = "La secuencia de bytes de respuesta no está codificada en ASN.1: ";
  public static final String MENSAJE_VIOLACION_PROTOCOLO_HTTP = "Violación del protocolo HTTP: ";
  public static final String MENSAJE_ERROR_CONEXION_SERVIDOR_TSA = "Error en la conexión con el servidor TSA: ";
  public static final String MENSAJE_SE_UTILIZA_PROXY = "Se utiliza un servidor Proxy: ";
  public static final String CADENA_VACIA = "";
  public static final String I18N_VALIDATE_1 = "i18n.mityc.ts.validate.1";
  public static final String I18N_VALIDATE_2 = "i18n.mityc.ts.validate.2";
  public static final String I18N_VALIDATE_3 = "i18n.mityc.ts.validate.3";
  public static final String I18N_VALIDATE_4 = "i18n.mityc.ts.validate.4";
  public static final String I18N_VALIDATE_5 = "i18n.mityc.ts.validate.5";
  public static final String I18N_VALIDATE_6 = "i18n.mityc.ts.validate.6";
  public static final String I18N_VALIDATE_7 = "i18n.mityc.ts.validate.7";
  public static final String I18N_VALIDATE_8 = "i18n.mityc.ts.validate.8";
  public static final String LIBRERIA_TSA_ERROR_1 = "i18n.mityc.ts.error1";
  public static final String LIBRERIA_TSA_ERROR_2 = "i18n.mityc.ts.error2";
  public static final String LIBRERIA_TSA_ERROR_3 = "i18n.mityc.ts.error3";
  public static final String LIBRERIA_TSA_ERROR_4 = "i18n.mityc.ts.error4";
  public static final String LIBRERIA_TSA_ERROR_6 = "i18n.mityc.ts.error6";
  public static final String LIBRERIA_TSA_ERROR_7 = "i18n.mityc.ts.error7";
  public static final String LIBRERIA_TSA_ERROR_8 = "i18n.mityc.ts.error8";
  public static final String LIBRERIA_TSA_ERROR_9 = "i18n.mityc.ts.error9";
  public static final String LIBRERIA_TSA_ERROR_10 = "i18n.mityc.ts.error10";
  public static final String LIBRERIA_TSA_ERROR_11 = "i18n.mityc.ts.error11";
  public static final String LIBRERIA_TSA_ERROR_12 = "i18n.mityc.ts.error12";
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibTSA-1.1.7.jar!\es\mityc\javasign\ts\ConstantsTSA.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */