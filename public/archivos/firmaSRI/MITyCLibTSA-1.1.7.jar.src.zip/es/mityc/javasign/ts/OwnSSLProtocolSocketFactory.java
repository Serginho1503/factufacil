/*     */ package es.mityc.javasign.ts;
/*     */ 
/*     */ import es.mityc.javasign.ssl.ISSLErrorManager;
/*     */ import es.mityc.javasign.ssl.ISSLManager;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.security.KeyManagementException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.Principal;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.util.Vector;
/*     */ import javax.net.SocketFactory;
/*     */ import javax.net.ssl.KeyManager;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLPeerUnverifiedException;
/*     */ import javax.net.ssl.SSLSession;
/*     */ import javax.net.ssl.SSLSessionContext;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import javax.net.ssl.TrustManager;
/*     */ import javax.security.cert.CertificateEncodingException;
/*     */ import org.apache.commons.httpclient.ConnectTimeoutException;
/*     */ import org.apache.commons.httpclient.params.HttpConnectionParams;
/*     */ import org.apache.commons.httpclient.protocol.SecureProtocolSocketFactory;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.bouncycastle.asn1.x509.X509Name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OwnSSLProtocolSocketFactory
/*     */   implements SecureProtocolSocketFactory
/*     */ {
/*  96 */   private static final Log LOG = LogFactory.getLog(OwnSSLProtocolSocketFactory.class);
/*     */   
/*     */ 
/*     */   private static final int SSL_TIME_OUT = 30;
/*     */   
/* 101 */   private ISSLManager sslManager = null;
/* 102 */   private SSLContext sslcontext = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OwnSSLProtocolSocketFactory(ISSLManager ssl)
/*     */   {
/* 122 */     this.sslManager = ssl;
/*     */   }
/*     */   
/*     */ 
/*     */   public OwnSSLProtocolSocketFactory() {}
/*     */   
/*     */ 
/*     */   private SSLContext createSSLContext()
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 134 */       KeyManager[] keymanagers = null;
/* 135 */       TrustManager[] trustmanagers = null;
/* 136 */       if (this.sslManager != null) {
/* 137 */         KeyManager km = this.sslManager.getKeyManager();
/* 138 */         if (km != null) {
/* 139 */           keymanagers = new KeyManager[] { km };
/*     */         }
/* 141 */         TrustManager tm = this.sslManager.getTrustManager();
/* 142 */         if (tm != null) {
/* 143 */           trustmanagers = new TrustManager[] { tm };
/*     */         }
/*     */       }
/* 146 */       SSLContext sslcontext = SSLContext.getInstance("SSL");
/* 147 */       sslcontext.init(keymanagers, trustmanagers, null);
/* 148 */       sslcontext.getClientSessionContext().setSessionTimeout(30);
/* 149 */       return sslcontext;
/*     */     } catch (NoSuchAlgorithmException ex) {
/* 151 */       LOG.error(ex.getMessage(), ex);
/* 152 */       throw new IOException(ex.getMessage());
/*     */     } catch (KeyManagementException ex) {
/* 154 */       LOG.error(ex.getMessage(), ex);
/* 155 */       throw new IOException(ex.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */   public SSLContext getSSLContext() throws IOException {
/* 160 */     if (this.sslcontext == null) {
/* 161 */       this.sslcontext = createSSLContext();
/*     */     }
/* 163 */     return this.sslcontext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Socket createSocket(String host, int port, InetAddress localAddress, int localPort, HttpConnectionParams params)
/*     */     throws IOException, UnknownHostException, ConnectTimeoutException
/*     */   {
/* 195 */     if (params == null) {
/* 196 */       throw new IllegalArgumentException("Parameters may not be null");
/*     */     }
/* 198 */     int timeout = params.getConnectionTimeout();
/* 199 */     Socket socket = null;
/*     */     
/* 201 */     SocketFactory socketfactory = getSSLContext().getSocketFactory();
/* 202 */     if (timeout == 0) {
/* 203 */       socket = socketfactory.createSocket(host, port, localAddress, localPort);
/*     */     } else {
/* 205 */       socket = socketfactory.createSocket();
/* 206 */       SocketAddress localaddr = new InetSocketAddress(localAddress, localPort);
/* 207 */       SocketAddress remoteaddr = new InetSocketAddress(host, port);
/* 208 */       socket.bind(localaddr);
/* 209 */       socket.connect(remoteaddr, timeout);
/*     */     }
/* 211 */     verifyHostname((SSLSocket)socket);
/* 212 */     return socket;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Socket createSocket(String host, int port, InetAddress clientHost, int clientPort)
/*     */     throws IOException, UnknownHostException
/*     */   {
/* 225 */     SSLSocketFactory sf = getSSLContext().getSocketFactory();
/* 226 */     SSLSocket sslSocket = (SSLSocket)sf.createSocket(host, port, 
/* 227 */       clientHost, 
/* 228 */       clientPort);
/* 229 */     verifyHostname(sslSocket);
/*     */     
/* 231 */     return sslSocket;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Socket createSocket(String host, int port)
/*     */     throws IOException, UnknownHostException
/*     */   {
/* 240 */     SSLSocketFactory sf = getSSLContext().getSocketFactory();
/* 241 */     SSLSocket sslSocket = (SSLSocket)sf.createSocket(host, port);
/* 242 */     verifyHostname(sslSocket);
/*     */     
/* 244 */     return sslSocket;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Socket createSocket(Socket socket, String host, int port, boolean autoClose)
/*     */     throws IOException, UnknownHostException
/*     */   {
/* 257 */     SSLSocketFactory sf = getSSLContext().getSocketFactory();
/* 258 */     SSLSocket sslSocket = (SSLSocket)sf.createSocket(socket, host, 
/* 259 */       port, autoClose);
/* 260 */     verifyHostname(sslSocket);
/*     */     
/* 262 */     return sslSocket;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void verifyHostname(SSLSocket socket)
/*     */     throws SSLPeerUnverifiedException, UnknownHostException
/*     */   {
/* 278 */     if (this.sslManager == null) {
/* 279 */       return;
/*     */     }
/* 281 */     ISSLErrorManager errorMng = this.sslManager.getSSLErrorManager();
/* 282 */     if (errorMng == null) {
/* 283 */       return;
/*     */     }
/*     */     
/* 286 */     SSLSession session = socket.getSession();
/* 287 */     String hostname = session.getPeerHost();
/*     */     try {
/* 289 */       InetAddress.getByName(hostname);
/*     */     } catch (UnknownHostException uhe) {
/* 291 */       throw new UnknownHostException("Could not resolve SSL sessions server hostname: " + 
/* 292 */         hostname);
/*     */     }
/*     */     
/* 295 */     javax.security.cert.X509Certificate[] certs = session.getPeerCertificateChain();
/* 296 */     if ((certs == null) || (certs.length == 0)) {
/* 297 */       throw new SSLPeerUnverifiedException("No server certificates found!");
/*     */     }
/*     */     
/* 300 */     String dn = certs[0].getSubjectDN().getName();
/*     */     
/*     */ 
/*     */ 
/* 304 */     if (LOG.isDebugEnabled()) {
/* 305 */       LOG.debug("Server certificate chain:");
/* 306 */       for (int i = 0; i < certs.length; i++) {
/* 307 */         LOG.debug("X509Certificate[" + i + "]=" + certs[i]);
/*     */       }
/*     */     }
/*     */     
/* 311 */     String cn = getCN(dn);
/* 312 */     if (hostname.equalsIgnoreCase(cn)) {
/* 313 */       if (LOG.isDebugEnabled()) {
/* 314 */         LOG.debug("Target hostname valid: " + cn);
/*     */       }
/*     */     } else {
/*     */       try {
/* 318 */         CertificateFactory cf = CertificateFactory.getInstance("X.509");
/* 319 */         java.security.cert.X509Certificate servCert = (java.security.cert.X509Certificate)cf.generateCertificate(new ByteArrayInputStream(certs[0].getEncoded()));
/* 320 */         if (!errorMng.continueErrorPeer(hostname, servCert)) {
/* 321 */           throw new SSLPeerUnverifiedException(
/* 322 */             "HTTPS hostname invalid: expected '" + hostname + "', received '" + cn + "'");
/*     */         }
/*     */       } catch (CertificateException ex) {
/* 325 */         LOG.error(ex.getMessage(), ex);
/* 326 */         throw new SSLPeerUnverifiedException("Unexpected error checking HTTPS hostname: " + ex.getMessage());
/*     */       } catch (CertificateEncodingException ex) {
/* 328 */         LOG.error(ex.getMessage(), ex);
/* 329 */         throw new SSLPeerUnverifiedException("Unexpected error checking HTTPS hostname: " + ex.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getCN(String dn)
/*     */   {
/* 345 */     X509Name name = new X509Name(dn);
/* 346 */     Vector<?> vector = name.getValues(X509Name.CN);
/* 347 */     if ((vector != null) && (vector.size() > 0)) {
/* 348 */       return (String)vector.get(0);
/*     */     }
/* 350 */     return null;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 355 */     if ((obj != null) && (obj.getClass().equals(OwnSSLProtocolSocketFactory.class))) {
/* 356 */       return true;
/*     */     }
/* 358 */     return false;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 363 */     return OwnSSLProtocolSocketFactory.class.hashCode();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibTSA-1.1.7.jar!\es\mityc\javasign\ts\OwnSSLProtocolSocketFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */