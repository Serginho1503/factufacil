/*    */ package es.mityc.javasign.ts;
/*    */ 
/*    */ import java.net.Authenticator;
/*    */ import java.net.Authenticator.RequestorType;
/*    */ import java.net.PasswordAuthentication;
/*    */ import org.apache.commons.httpclient.NTCredentials;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticatorProxyCredentials
/*    */   extends NTCredentials
/*    */ {
/* 32 */   protected PasswordAuthentication pa = null;
/*    */   
/*    */   public AuthenticatorProxyCredentials(String host, String domain) {
/* 35 */     super("username", "password", host, domain);
/*    */   }
/*    */   
/*    */   private void refreshAuthenticator() {
/* 39 */     String proxyHost = System.getProperty("http.proxyHost");
/* 40 */     int proxyPort = 80;
/*    */     try {
/* 42 */       proxyPort = Integer.parseInt(System.getProperty("http.proxyPort"));
/*    */     }
/*    */     catch (NumberFormatException localNumberFormatException) {}
/*    */     try {
/* 46 */       this.pa = Authenticator.requestPasswordAuthentication(proxyHost, null, proxyPort, "HTTP", "", "http", null, Authenticator.RequestorType.PROXY);
/*    */     } catch (SecurityException ex) {
/* 48 */       this.pa = null;
/*    */     }
/*    */   }
/*    */   
/*    */   public String getUserName()
/*    */   {
/* 54 */     refreshAuthenticator();
/* 55 */     if (this.pa == null)
/* 56 */       return super.getUserName();
/* 57 */     return this.pa.getUserName();
/*    */   }
/*    */   
/*    */   public String getPassword()
/*    */   {
/* 62 */     if (this.pa == null)
/* 63 */       refreshAuthenticator();
/* 64 */     if (this.pa == null)
/* 65 */       return super.getPassword();
/* 66 */     return new String(this.pa.getPassword());
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibTSA-1.1.7.jar!\es\mityc\javasign\ts\AuthenticatorProxyCredentials.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */