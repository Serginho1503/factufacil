/*     */ package es.mityc.javasign.ts;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.tsa.ITimeStampValidator;
/*     */ import es.mityc.javasign.tsa.TSValidationResult;
/*     */ import es.mityc.javasign.tsa.TimeStampException;
/*     */ import es.mityc.javasign.utils.Base64Coder;
/*     */ import java.io.IOException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.cert.CertStore;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.bouncycastle.asn1.x509.GeneralName;
/*     */ import org.bouncycastle.asn1.x509.X509Name;
/*     */ import org.bouncycastle.cms.CMSException;
/*     */ import org.bouncycastle.cms.CMSSignedData;
/*     */ import org.bouncycastle.tsp.GenTimeAccuracy;
/*     */ import org.bouncycastle.tsp.TSPException;
/*     */ import org.bouncycastle.tsp.TimeStampResponse;
/*     */ import org.bouncycastle.tsp.TimeStampToken;
/*     */ import org.bouncycastle.tsp.TimeStampTokenInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimeStampValidator
/*     */   implements ITimeStampValidator
/*     */ {
/*  59 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibTSA");
/*     */   
/*  61 */   static Log log = LogFactory.getLog(TimeStampValidator.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TSValidationResult validateTimeStamp(byte[] sealedData, byte[] timeStamp)
/*     */     throws TimeStampException
/*     */   {
/*  73 */     TimeStampToken tst = null;
/*  74 */     TSValidationResult tsv = new TSValidationResult();
/*     */     try
/*     */     {
/*  77 */       tst = new TimeStampToken(new CMSSignedData(timeStamp));
/*     */     }
/*     */     catch (CMSException e) {
/*     */       try {
/*  81 */         TimeStampResponse tsr = new TimeStampResponse(timeStamp);
/*  82 */         tst = tsr.getTimeStampToken();
/*  83 */         if (tst == null) {
/*  84 */           throw new TimeStampException(I18N.getLocalMessage("i18n.mityc.ts.error2"));
/*     */         }
/*     */       } catch (TSPException ex) {
/*  87 */         throw new TimeStampException(I18N.getLocalMessage("i18n.mityc.ts.error2"));
/*     */       } catch (IOException ex) {
/*  89 */         throw new TimeStampException(I18N.getLocalMessage("i18n.mityc.ts.error2"));
/*     */       }
/*     */     } catch (TSPException e) {
/*  92 */       throw new TimeStampException(I18N.getLocalMessage("i18n.mityc.ts.error2"), e);
/*     */     } catch (IOException e) {
/*  94 */       throw new TimeStampException(I18N.getLocalMessage("i18n.mityc.ts.error2"), e);
/*     */     }
/*     */     try
/*     */     {
/*  98 */       tsv.setTimeStamRawToken(tst.toCMSSignedData().getEncoded());
/*     */     } catch (IOException e) {
/* 100 */       throw new TimeStampException(I18N.getLocalMessage("i18n.mityc.ts.error2"));
/*     */     }
/* 102 */     TimeStampTokenInfo tokenInfo = tst.getTimeStampInfo();
/*     */     
/* 104 */     MessageDigest resumen = TSPAlgoritmos.getDigest(tokenInfo.getMessageImprintAlgOID());
/* 105 */     if (resumen == null) {
/* 106 */       throw new TimeStampException(I18N.getLocalMessage("i18n.mityc.ts.validate.1", new Object[] { tokenInfo.getMessageImprintAlgOID() }));
/*     */     }
/*     */     
/* 109 */     resumen.update(sealedData);
/* 110 */     if (MessageDigest.isEqual(resumen.digest(), tst.getTimeStampInfo().getMessageImprintDigest())) {
/* 111 */       SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy H:mm:ss.SSS");
/* 112 */       tsv.setFormattedDate(formato.format(tokenInfo.getGenTime()));
/* 113 */       tsv.setDate(tokenInfo.getGenTime());
/*     */       
/* 115 */       GenTimeAccuracy precision = tokenInfo.getGenTimeAccuracy();
/*     */       
/* 117 */       long accuLong = 0L;
/* 118 */       if (precision != null) {
/* 119 */         accuLong = precision.getMicros() * 1L + 
/* 120 */           precision.getMillis() * 1000L + 
/* 121 */           precision.getSeconds() * 1000000L;
/*     */       }
/* 123 */       tsv.setTimeAccurracy(accuLong);
/*     */       
/* 125 */       tsv.setStamp(tokenInfo.getSerialNumber());
/* 126 */       tsv.setSignDigest(new String(Base64Coder.encode(tokenInfo.getMessageImprintDigest())));
/* 127 */       tsv.setStampAlg(tokenInfo.getMessageImprintAlgOID());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 132 */       X500Principal signer = null;
/* 133 */       GeneralName gn = tokenInfo.getTsa();
/* 134 */       if (gn != null)
/*     */       {
/* 136 */         if (gn.getTagNo() == 4) {
/*     */           try {
/* 138 */             signer = new X500Principal(X509Name.getInstance(gn.getName()).getEncoded());
/*     */           }
/*     */           catch (IOException localIOException1) {}
/*     */         }
/*     */       }
/*     */       try
/*     */       {
/* 145 */         CertStore cs = tst.getCertificatesAndCRLs("Collection", null);
/* 146 */         Collection<? extends Certificate> certs = cs.getCertificates(null);
/* 147 */         if (certs.size() > 0) {
/* 148 */           tsv.setCadena(CertificateFactory.getInstance("X.509").generateCertPath(new ArrayList(certs)));
/*     */           
/* 150 */           Certificate cert = (Certificate)certs.iterator().next();
/* 151 */           if ((signer == null) && ((cert instanceof X509Certificate))) {
/* 152 */             signer = ((X509Certificate)cert).getSubjectX500Principal();
/*     */           }
/*     */         }
/*     */       } catch (Exception e) {
/* 156 */         log.error(e);
/*     */       }
/* 158 */       tsv.setTimeStampIssuer(signer);
/*     */     }
/*     */     else {
/* 161 */       throw new TimeStampException(I18N.getLocalMessage("i18n.mityc.ts.validate.2"));
/*     */     }
/* 163 */     return tsv;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibTSA-1.1.7.jar!\es\mityc\javasign\ts\TimeStampValidator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */