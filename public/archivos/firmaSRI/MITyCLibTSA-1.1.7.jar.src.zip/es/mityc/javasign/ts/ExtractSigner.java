/*     */ package es.mityc.javasign.ts;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.tsa.ITimeStampValidator;
/*     */ import es.mityc.javasign.tsa.TSValidationResult;
/*     */ import es.mityc.javasign.tsa.TimeStampException;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.cert.CertStore;
/*     */ import java.security.cert.CertStoreException;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.CertificateEncodingException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import org.bouncycastle.cms.CMSSignedData;
/*     */ import org.bouncycastle.tsp.TimeStampToken;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExtractSigner
/*     */ {
/*  48 */   private static final II18nManager i18n = I18nFactory.getI18nManager("MITyCLibTSA");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int BUFFER_SIZE = 32000;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String CERT_FILE_NAME = "tsasigner.cer";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  65 */     if ((args == null) || (args.length < 1)) {
/*  66 */       System.out.println("Modo de uso:");
/*  67 */       System.out.println("       ExtractSigner  <ts-file>");
/*  68 */       System.out.println("            <ts-file>     Fichero donde se encuentra en sello de tiempo en binario");
/*     */     } else {
/*     */       try {
/*  71 */         File file = new File(args[0]);
/*  72 */         if (file.exists()) {
/*  73 */           if (file.length() > 32000L) {
/*  74 */             System.out.println("El fichero indicado es demasiado grande");
/*     */           } else {
/*  76 */             FileInputStream fis = new FileInputStream(file);
/*  77 */             byte[] ts = new byte[(int)file.length()];
/*  78 */             fis.read(ts);
/*  79 */             fis.close();
/*     */             
/*  81 */             X509Certificate cert = null;
/*     */             try {
/*  83 */               ITimeStampValidator tsValidator = new TimeStampValidator();
/*  84 */               TSValidationResult data = tsValidator.validateTimeStamp(ts, ts);
/*     */               
/*     */ 
/*  87 */               TimeStampToken timeStampToken = new TimeStampToken(new CMSSignedData(data.getTimeStampRawToken()));
/*  88 */               CertStore cs = timeStampToken.getCertificatesAndCRLs("Collection", null);
/*  89 */               Collection<? extends Certificate> certs = cs.getCertificates(null);
/*  90 */               if (certs.size() > 0) {
/*  91 */                 Certificate cer = (Certificate)certs.iterator().next();
/*  92 */                 if ((cer instanceof X509Certificate)) {
/*  93 */                   cert = (X509Certificate)cer;
/*     */                 }
/*     */               }
/*     */             } catch (NoSuchAlgorithmException ex) {
/*  97 */               System.out.println(i18n.getLocalMessage("i18n.mityc.ts.validate.8", new Object[] { ex.getMessage() }));
/*     */             } catch (NoSuchProviderException ex) {
/*  99 */               System.out.println(i18n.getLocalMessage("i18n.mityc.ts.validate.8", new Object[] { ex.getMessage() }));
/*     */             } catch (CertStoreException ex) {
/* 101 */               System.out.println(i18n.getLocalMessage("i18n.mityc.ts.validate.8", new Object[] { ex.getMessage() }));
/*     */             } catch (TimeStampException ex) {
/* 103 */               System.out.println("Error procesando el sello de tiempo: " + ex.getMessage());
/*     */             } catch (Exception ex) {
/* 105 */               System.out.println(i18n.getLocalMessage("i18n.mityc.ts.validate.8", new Object[] { ex.getMessage() }));
/*     */             }
/*     */             
/* 108 */             if (cert != null) {
/* 109 */               FileOutputStream fos = new FileOutputStream("tsasigner.cer", false);
/* 110 */               fos.write(cert.getEncoded());
/* 111 */               fos.flush();
/* 112 */               fos.close();
/* 113 */               System.out.println("Certificado extraido y disponible en tsasigner.cer");
/*     */             } else {
/* 115 */               System.out.println("El sello de tiempo no incluye el certificado firmante");
/*     */             }
/*     */           }
/*     */         } else {
/* 119 */           System.out.println("El fichero indicado no existe");
/*     */         }
/*     */       } catch (FileNotFoundException ex) {
/* 122 */         System.out.println("El fichero indicado no existe");
/*     */       } catch (IOException ex) {
/* 124 */         System.out.println("Error leyendo el fichero con el sello de tiempo: " + ex.getMessage());
/*     */       } catch (CertificateEncodingException ex) {
/* 126 */         System.out.println("Error procesando formato de certificado firmante: " + ex.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibTSA-1.1.7.jar!\es\mityc\javasign\ts\ExtractSigner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */