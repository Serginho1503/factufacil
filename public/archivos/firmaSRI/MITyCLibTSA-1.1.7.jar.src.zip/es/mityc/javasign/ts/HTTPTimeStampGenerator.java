/*     */ package es.mityc.javasign.ts;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.ssl.ISSLManager;
/*     */ import es.mityc.javasign.tsa.ITimeStampGenerator;
/*     */ import es.mityc.javasign.tsa.TimeStampException;
/*     */ import java.io.IOException;
/*     */ import java.util.Set;
/*     */ import javax.net.ssl.HttpsURLConnection;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import org.apache.commons.httpclient.protocol.Protocol;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTTPTimeStampGenerator
/*     */   implements ITimeStampGenerator
/*     */ {
/*  69 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibTSA");
/*     */   
/*  71 */   private String servidorTSA = null;
/*     */   
/*  73 */   private String algoritmoHash = null;
/*     */   
/*  75 */   private static final Integer INT10000 = new Integer(10000);
/*     */   
/*  77 */   private Integer timeOut = INT10000;
/*     */   
/*  79 */   static Log log = LogFactory.getLog(HTTPTimeStampGenerator.class.getName());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HTTPTimeStampGenerator(String nombreServidor, String algoritmoHash)
/*     */   {
/*  88 */     this.servidorTSA = nombreServidor;
/*     */     
/*     */ 
/*  91 */     this.algoritmoHash = "SHA-1";
/*     */     
/*     */ 
/*     */ 
/*  95 */     if (algoritmoHash != null) {
/*  96 */       String temp = algoritmoHash.trim().toUpperCase();
/*  97 */       if (TSPAlgoritmos.getPermitidos().contains(algoritmoHash)) {
/*  98 */         this.algoritmoHash = temp;
/*     */       } else {
/* 100 */         log.warn("No se ha encontrado un algoritmo hash válido para el Sello de Tiempo. Se va a utilizar el algoritmo SHA1 por defecto");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setSSLManager(ISSLManager sslmanager)
/*     */   {
/* 111 */     OwnSSLProtocolSocketFactory ospsf = new OwnSSLProtocolSocketFactory(sslmanager);
/* 112 */     Protocol authhttps = new Protocol("https", ospsf, 443);
/* 113 */     Protocol.registerProtocol("https", authhttps);
/*     */     try {
/* 115 */       HttpsURLConnection.setDefaultSSLSocketFactory(ospsf.getSSLContext().getSocketFactory());
/*     */     } catch (IOException e) {
/* 117 */       log.error("Error estableciendo socket factory: " + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] generateTimeStamp(byte[] dataToSeal)
/*     */     throws TimeStampException
/*     */   {
/* 128 */     return generateTimeStamp(dataToSeal, null);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public byte[] generateTimeStamp(byte[] dataToSeal, String idApplication)
/*     */     throws TimeStampException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ifnonnull +31 -> 32
/*     */     //   4: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   7: ldc -82
/*     */     //   9: invokeinterface 176 2 0
/*     */     //   14: new 167	es/mityc/javasign/tsa/TimeStampException
/*     */     //   17: dup
/*     */     //   18: getstatic 28	es/mityc/javasign/ts/HTTPTimeStampGenerator:I18N	Les/mityc/javasign/i18n/II18nManager;
/*     */     //   21: ldc -78
/*     */     //   23: invokeinterface 180 2 0
/*     */     //   28: invokespecial 186	es/mityc/javasign/tsa/TimeStampException:<init>	(Ljava/lang/String;)V
/*     */     //   31: athrow
/*     */     //   32: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   35: ldc -69
/*     */     //   37: invokeinterface 189 2 0
/*     */     //   42: new 192	org/apache/commons/httpclient/HttpClient
/*     */     //   45: dup
/*     */     //   46: invokespecial 194	org/apache/commons/httpclient/HttpClient:<init>	()V
/*     */     //   49: astore_3
/*     */     //   50: new 195	org/bouncycastle/tsp/TimeStampRequestGenerator
/*     */     //   53: dup
/*     */     //   54: invokespecial 197	org/bouncycastle/tsp/TimeStampRequestGenerator:<init>	()V
/*     */     //   57: astore 4
/*     */     //   59: aload 4
/*     */     //   61: iconst_1
/*     */     //   62: invokevirtual 198	org/bouncycastle/tsp/TimeStampRequestGenerator:setCertReq	(Z)V
/*     */     //   65: aload_2
/*     */     //   66: ifnull +22 -> 88
/*     */     //   69: aload_2
/*     */     //   70: invokevirtual 202	java/lang/String:length	()I
/*     */     //   73: ifle +15 -> 88
/*     */     //   76: aload 4
/*     */     //   78: ldc -50
/*     */     //   80: iconst_0
/*     */     //   81: aload_2
/*     */     //   82: invokevirtual 208	java/lang/String:getBytes	()[B
/*     */     //   85: invokevirtual 212	org/bouncycastle/tsp/TimeStampRequestGenerator:addExtension	(Ljava/lang/String;Z[B)V
/*     */     //   88: aconst_null
/*     */     //   89: astore 5
/*     */     //   91: aconst_null
/*     */     //   92: astore 6
/*     */     //   94: aload_3
/*     */     //   95: invokevirtual 216	org/apache/commons/httpclient/HttpClient:getHttpConnectionManager	()Lorg/apache/commons/httpclient/HttpConnectionManager;
/*     */     //   98: ldc2_w 220
/*     */     //   101: invokeinterface 222 3 0
/*     */     //   106: aload_0
/*     */     //   107: getfield 59	es/mityc/javasign/ts/HTTPTimeStampGenerator:algoritmoHash	Ljava/lang/String;
/*     */     //   110: invokestatic 228	java/security/MessageDigest:getInstance	(Ljava/lang/String;)Ljava/security/MessageDigest;
/*     */     //   113: astore 7
/*     */     //   115: aload 7
/*     */     //   117: aload_1
/*     */     //   118: invokevirtual 234	java/security/MessageDigest:update	([B)V
/*     */     //   121: aload 4
/*     */     //   123: aload_0
/*     */     //   124: getfield 59	es/mityc/javasign/ts/HTTPTimeStampGenerator:algoritmoHash	Ljava/lang/String;
/*     */     //   127: invokestatic 238	es/mityc/javasign/ts/TSPAlgoritmos:getOID	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   130: aload 7
/*     */     //   132: invokevirtual 241	java/security/MessageDigest:digest	()[B
/*     */     //   135: invokevirtual 244	org/bouncycastle/tsp/TimeStampRequestGenerator:generate	(Ljava/lang/String;[B)Lorg/bouncycastle/tsp/TimeStampRequest;
/*     */     //   138: astore 5
/*     */     //   140: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   143: ldc -8
/*     */     //   145: invokeinterface 189 2 0
/*     */     //   150: goto +47 -> 197
/*     */     //   153: astore 7
/*     */     //   155: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   158: ldc -6
/*     */     //   160: aload 7
/*     */     //   162: invokeinterface 150 3 0
/*     */     //   167: new 167	es/mityc/javasign/tsa/TimeStampException
/*     */     //   170: dup
/*     */     //   171: getstatic 28	es/mityc/javasign/ts/HTTPTimeStampGenerator:I18N	Les/mityc/javasign/i18n/II18nManager;
/*     */     //   174: ldc -4
/*     */     //   176: iconst_1
/*     */     //   177: anewarray 3	java/lang/Object
/*     */     //   180: dup
/*     */     //   181: iconst_0
/*     */     //   182: aload 7
/*     */     //   184: invokevirtual 254	java/lang/Exception:getMessage	()Ljava/lang/String;
/*     */     //   187: aastore
/*     */     //   188: invokeinterface 257 3 0
/*     */     //   193: invokespecial 186	es/mityc/javasign/tsa/TimeStampException:<init>	(Ljava/lang/String;)V
/*     */     //   196: athrow
/*     */     //   197: aload_3
/*     */     //   198: invokevirtual 260	org/apache/commons/httpclient/HttpClient:getParams	()Lorg/apache/commons/httpclient/params/HttpClientParams;
/*     */     //   201: ldc_w 264
/*     */     //   204: aload_0
/*     */     //   205: getfield 61	es/mityc/javasign/ts/HTTPTimeStampGenerator:timeOut	Ljava/lang/Integer;
/*     */     //   208: invokevirtual 266	org/apache/commons/httpclient/params/HttpClientParams:setParameter	(Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   211: ldc_w 272
/*     */     //   214: invokestatic 274	java/lang/System:getProperty	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   217: astore 7
/*     */     //   219: aload 7
/*     */     //   221: ifnull +60 -> 281
/*     */     //   224: bipush 80
/*     */     //   226: istore 8
/*     */     //   228: ldc_w 279
/*     */     //   231: invokestatic 274	java/lang/System:getProperty	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   234: invokestatic 281	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*     */     //   237: istore 8
/*     */     //   239: goto +5 -> 244
/*     */     //   242: astore 9
/*     */     //   244: aload_3
/*     */     //   245: invokevirtual 285	org/apache/commons/httpclient/HttpClient:getHostConfiguration	()Lorg/apache/commons/httpclient/HostConfiguration;
/*     */     //   248: aload 7
/*     */     //   250: iload 8
/*     */     //   252: invokevirtual 289	org/apache/commons/httpclient/HostConfiguration:setProxy	(Ljava/lang/String;I)V
/*     */     //   255: new 295	es/mityc/javasign/ts/AuthenticatorProxyCredentials
/*     */     //   258: dup
/*     */     //   259: aload 7
/*     */     //   261: ldc_w 297
/*     */     //   264: invokespecial 299	es/mityc/javasign/ts/AuthenticatorProxyCredentials:<init>	(Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   267: astore 9
/*     */     //   269: aload_3
/*     */     //   270: invokevirtual 301	org/apache/commons/httpclient/HttpClient:getState	()Lorg/apache/commons/httpclient/HttpState;
/*     */     //   273: getstatic 305	org/apache/commons/httpclient/auth/AuthScope:ANY	Lorg/apache/commons/httpclient/auth/AuthScope;
/*     */     //   276: aload 9
/*     */     //   278: invokevirtual 311	org/apache/commons/httpclient/HttpState:setProxyCredentials	(Lorg/apache/commons/httpclient/auth/AuthScope;Lorg/apache/commons/httpclient/Credentials;)V
/*     */     //   281: new 317	org/apache/commons/httpclient/methods/PostMethod
/*     */     //   284: dup
/*     */     //   285: aload_0
/*     */     //   286: getfield 57	es/mityc/javasign/ts/HTTPTimeStampGenerator:servidorTSA	Ljava/lang/String;
/*     */     //   289: invokespecial 319	org/apache/commons/httpclient/methods/PostMethod:<init>	(Ljava/lang/String;)V
/*     */     //   292: astore 8
/*     */     //   294: aload 8
/*     */     //   296: ldc_w 320
/*     */     //   299: ldc_w 322
/*     */     //   302: invokevirtual 324	org/apache/commons/httpclient/methods/PostMethod:addRequestHeader	(Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   305: aconst_null
/*     */     //   306: astore 9
/*     */     //   308: new 327	java/io/ByteArrayInputStream
/*     */     //   311: dup
/*     */     //   312: aload 5
/*     */     //   314: invokevirtual 329	org/bouncycastle/tsp/TimeStampRequest:getEncoded	()[B
/*     */     //   317: invokespecial 334	java/io/ByteArrayInputStream:<init>	([B)V
/*     */     //   320: astore 9
/*     */     //   322: goto +67 -> 389
/*     */     //   325: astore 10
/*     */     //   327: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   330: new 131	java/lang/StringBuilder
/*     */     //   333: dup
/*     */     //   334: ldc_w 336
/*     */     //   337: invokespecial 135	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   340: aload 10
/*     */     //   342: invokevirtual 138	java/io/IOException:getMessage	()Ljava/lang/String;
/*     */     //   345: invokevirtual 143	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   348: invokevirtual 147	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   351: aload 10
/*     */     //   353: invokeinterface 150 3 0
/*     */     //   358: new 167	es/mityc/javasign/tsa/TimeStampException
/*     */     //   361: dup
/*     */     //   362: getstatic 28	es/mityc/javasign/ts/HTTPTimeStampGenerator:I18N	Les/mityc/javasign/i18n/II18nManager;
/*     */     //   365: ldc_w 338
/*     */     //   368: iconst_1
/*     */     //   369: anewarray 3	java/lang/Object
/*     */     //   372: dup
/*     */     //   373: iconst_0
/*     */     //   374: aload 10
/*     */     //   376: invokevirtual 138	java/io/IOException:getMessage	()Ljava/lang/String;
/*     */     //   379: aastore
/*     */     //   380: invokeinterface 257 3 0
/*     */     //   385: invokespecial 186	es/mityc/javasign/tsa/TimeStampException:<init>	(Ljava/lang/String;)V
/*     */     //   388: athrow
/*     */     //   389: new 340	org/apache/commons/httpclient/methods/InputStreamRequestEntity
/*     */     //   392: dup
/*     */     //   393: aload 9
/*     */     //   395: invokespecial 342	org/apache/commons/httpclient/methods/InputStreamRequestEntity:<init>	(Ljava/io/InputStream;)V
/*     */     //   398: astore 10
/*     */     //   400: aload 8
/*     */     //   402: aload 10
/*     */     //   404: invokevirtual 345	org/apache/commons/httpclient/methods/PostMethod:setRequestEntity	(Lorg/apache/commons/httpclient/methods/RequestEntity;)V
/*     */     //   407: aload 8
/*     */     //   409: invokevirtual 349	org/apache/commons/httpclient/methods/PostMethod:getParams	()Lorg/apache/commons/httpclient/params/HttpMethodParams;
/*     */     //   412: ldc_w 352
/*     */     //   415: new 354	org/apache/commons/httpclient/DefaultHttpMethodRetryHandler
/*     */     //   418: dup
/*     */     //   419: iconst_3
/*     */     //   420: iconst_0
/*     */     //   421: invokespecial 356	org/apache/commons/httpclient/DefaultHttpMethodRetryHandler:<init>	(IZ)V
/*     */     //   424: invokevirtual 359	org/apache/commons/httpclient/params/HttpMethodParams:setParameter	(Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   427: aconst_null
/*     */     //   428: astore 11
/*     */     //   430: iconst_0
/*     */     //   431: istore 12
/*     */     //   433: aload_3
/*     */     //   434: aload 8
/*     */     //   436: invokevirtual 362	org/apache/commons/httpclient/HttpClient:executeMethod	(Lorg/apache/commons/httpclient/HttpMethod;)I
/*     */     //   439: istore 12
/*     */     //   441: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   444: ldc_w 366
/*     */     //   447: invokeinterface 189 2 0
/*     */     //   452: goto +39 -> 491
/*     */     //   455: astore 13
/*     */     //   457: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   460: new 131	java/lang/StringBuilder
/*     */     //   463: dup
/*     */     //   464: ldc_w 368
/*     */     //   467: invokespecial 135	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   470: aload 13
/*     */     //   472: invokevirtual 138	java/io/IOException:getMessage	()Ljava/lang/String;
/*     */     //   475: invokevirtual 143	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   478: invokevirtual 147	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   481: invokeinterface 176 2 0
/*     */     //   486: sipush 408
/*     */     //   489: istore 12
/*     */     //   491: iload 12
/*     */     //   493: sipush 200
/*     */     //   496: if_icmpeq +687 -> 1183
/*     */     //   499: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   502: ldc_w 370
/*     */     //   505: invokeinterface 189 2 0
/*     */     //   510: aconst_null
/*     */     //   511: astore 13
/*     */     //   513: aconst_null
/*     */     //   514: astore 14
/*     */     //   516: aload_0
/*     */     //   517: getfield 57	es/mityc/javasign/ts/HTTPTimeStampGenerator:servidorTSA	Ljava/lang/String;
/*     */     //   520: invokestatic 372	es/mityc/javasign/utils/ProxyUtil:getConnection	(Ljava/lang/String;)Ljava/net/HttpURLConnection;
/*     */     //   523: astore 13
/*     */     //   525: aload 13
/*     */     //   527: sipush 5000
/*     */     //   530: invokevirtual 378	java/net/HttpURLConnection:setConnectTimeout	(I)V
/*     */     //   533: aload 13
/*     */     //   535: ldc_w 383
/*     */     //   538: invokevirtual 385	java/net/HttpURLConnection:setRequestMethod	(Ljava/lang/String;)V
/*     */     //   541: aload 13
/*     */     //   543: ldc_w 320
/*     */     //   546: ldc_w 322
/*     */     //   549: invokevirtual 388	java/net/HttpURLConnection:setRequestProperty	(Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   552: aload 13
/*     */     //   554: ldc_w 391
/*     */     //   557: ldc_w 393
/*     */     //   560: invokevirtual 388	java/net/HttpURLConnection:setRequestProperty	(Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   563: aload 13
/*     */     //   565: ldc_w 395
/*     */     //   568: aload 5
/*     */     //   570: invokevirtual 329	org/bouncycastle/tsp/TimeStampRequest:getEncoded	()[B
/*     */     //   573: arraylength
/*     */     //   574: invokestatic 397	java/lang/String:valueOf	(I)Ljava/lang/String;
/*     */     //   577: invokevirtual 388	java/net/HttpURLConnection:setRequestProperty	(Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   580: aload 13
/*     */     //   582: iconst_0
/*     */     //   583: invokevirtual 401	java/net/HttpURLConnection:setUseCaches	(Z)V
/*     */     //   586: aload 13
/*     */     //   588: iconst_1
/*     */     //   589: invokevirtual 404	java/net/HttpURLConnection:setDoOutput	(Z)V
/*     */     //   592: new 407	java/io/DataOutputStream
/*     */     //   595: dup
/*     */     //   596: aload 13
/*     */     //   598: invokevirtual 409	java/net/HttpURLConnection:getOutputStream	()Ljava/io/OutputStream;
/*     */     //   601: invokespecial 413	java/io/DataOutputStream:<init>	(Ljava/io/OutputStream;)V
/*     */     //   604: astore 15
/*     */     //   606: aload 15
/*     */     //   608: aload 5
/*     */     //   610: invokevirtual 329	org/bouncycastle/tsp/TimeStampRequest:getEncoded	()[B
/*     */     //   613: invokevirtual 416	java/io/DataOutputStream:write	([B)V
/*     */     //   616: aload 15
/*     */     //   618: invokevirtual 419	java/io/DataOutputStream:flush	()V
/*     */     //   621: aload 15
/*     */     //   623: invokevirtual 422	java/io/DataOutputStream:close	()V
/*     */     //   626: aload 13
/*     */     //   628: invokevirtual 425	java/net/HttpURLConnection:getResponseCode	()I
/*     */     //   631: sipush 200
/*     */     //   634: if_icmpne +229 -> 863
/*     */     //   637: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   640: invokeinterface 428 1 0
/*     */     //   645: ifeq +32 -> 677
/*     */     //   648: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   651: new 131	java/lang/StringBuilder
/*     */     //   654: dup
/*     */     //   655: ldc_w 432
/*     */     //   658: invokespecial 135	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   661: aload 13
/*     */     //   663: invokevirtual 434	java/net/HttpURLConnection:usingProxy	()Z
/*     */     //   666: invokevirtual 437	java/lang/StringBuilder:append	(Z)Ljava/lang/StringBuilder;
/*     */     //   669: invokevirtual 147	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   672: invokeinterface 440 2 0
/*     */     //   677: aload 13
/*     */     //   679: invokevirtual 443	java/net/HttpURLConnection:getContent	()Ljava/lang/Object;
/*     */     //   682: astore 16
/*     */     //   684: aload 16
/*     */     //   686: ifnull +148 -> 834
/*     */     //   689: aload 16
/*     */     //   691: instanceof 447
/*     */     //   694: ifeq +75 -> 769
/*     */     //   697: aload 16
/*     */     //   699: checkcast 447	java/io/InputStream
/*     */     //   702: astore 17
/*     */     //   704: aload 17
/*     */     //   706: ifnull +92 -> 798
/*     */     //   709: aload 17
/*     */     //   711: invokevirtual 449	java/io/InputStream:available	()I
/*     */     //   714: ifle +84 -> 798
/*     */     //   717: iconst_0
/*     */     //   718: istore 18
/*     */     //   720: aload 17
/*     */     //   722: invokevirtual 449	java/io/InputStream:available	()I
/*     */     //   725: newarray <illegal type>
/*     */     //   727: astore 11
/*     */     //   729: iconst_0
/*     */     //   730: istore 19
/*     */     //   732: goto +21 -> 753
/*     */     //   735: aload 17
/*     */     //   737: invokevirtual 452	java/io/InputStream:read	()I
/*     */     //   740: istore 18
/*     */     //   742: aload 11
/*     */     //   744: iload 19
/*     */     //   746: iload 18
/*     */     //   748: i2b
/*     */     //   749: bastore
/*     */     //   750: iinc 19 1
/*     */     //   753: iload 18
/*     */     //   755: iflt +43 -> 798
/*     */     //   758: iload 19
/*     */     //   760: aload 11
/*     */     //   762: arraylength
/*     */     //   763: if_icmplt -28 -> 735
/*     */     //   766: goto +32 -> 798
/*     */     //   769: new 255	java/lang/Exception
/*     */     //   772: dup
/*     */     //   773: new 131	java/lang/StringBuilder
/*     */     //   776: dup
/*     */     //   777: ldc_w 455
/*     */     //   780: invokespecial 135	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   783: aload 13
/*     */     //   785: invokevirtual 457	java/net/HttpURLConnection:getContentType	()Ljava/lang/String;
/*     */     //   788: invokevirtual 143	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   791: invokevirtual 147	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   794: invokespecial 460	java/lang/Exception:<init>	(Ljava/lang/String;)V
/*     */     //   797: athrow
/*     */     //   798: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   801: invokeinterface 428 1 0
/*     */     //   806: ifeq +14 -> 820
/*     */     //   809: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   812: ldc_w 461
/*     */     //   815: invokeinterface 440 2 0
/*     */     //   820: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   823: ldc_w 463
/*     */     //   826: invokeinterface 189 2 0
/*     */     //   831: goto +300 -> 1131
/*     */     //   834: new 255	java/lang/Exception
/*     */     //   837: dup
/*     */     //   838: new 131	java/lang/StringBuilder
/*     */     //   841: dup
/*     */     //   842: ldc_w 465
/*     */     //   845: invokespecial 135	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   848: aload 13
/*     */     //   850: invokevirtual 425	java/net/HttpURLConnection:getResponseCode	()I
/*     */     //   853: invokevirtual 467	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*     */     //   856: invokevirtual 147	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   859: invokespecial 460	java/lang/Exception:<init>	(Ljava/lang/String;)V
/*     */     //   862: athrow
/*     */     //   863: new 255	java/lang/Exception
/*     */     //   866: dup
/*     */     //   867: new 131	java/lang/StringBuilder
/*     */     //   870: dup
/*     */     //   871: ldc_w 470
/*     */     //   874: invokespecial 135	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   877: aload 13
/*     */     //   879: invokevirtual 425	java/net/HttpURLConnection:getResponseCode	()I
/*     */     //   882: invokevirtual 467	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*     */     //   885: ldc_w 472
/*     */     //   888: invokevirtual 143	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   891: aload 13
/*     */     //   893: invokevirtual 474	java/net/HttpURLConnection:getResponseMessage	()Ljava/lang/String;
/*     */     //   896: invokevirtual 143	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   899: invokevirtual 147	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   902: invokespecial 460	java/lang/Exception:<init>	(Ljava/lang/String;)V
/*     */     //   905: athrow
/*     */     //   906: astore 15
/*     */     //   908: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   911: invokeinterface 428 1 0
/*     */     //   916: ifeq +16 -> 932
/*     */     //   919: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   922: ldc_w 477
/*     */     //   925: aload 15
/*     */     //   927: invokeinterface 479 3 0
/*     */     //   932: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   935: new 131	java/lang/StringBuilder
/*     */     //   938: dup
/*     */     //   939: ldc_w 481
/*     */     //   942: invokespecial 135	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   945: aload 8
/*     */     //   947: invokevirtual 483	org/apache/commons/httpclient/methods/PostMethod:getStatusLine	()Lorg/apache/commons/httpclient/StatusLine;
/*     */     //   950: invokevirtual 487	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   953: invokevirtual 147	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   956: invokeinterface 176 2 0
/*     */     //   961: aload 8
/*     */     //   963: invokevirtual 483	org/apache/commons/httpclient/methods/PostMethod:getStatusLine	()Lorg/apache/commons/httpclient/StatusLine;
/*     */     //   966: ifnull +77 -> 1043
/*     */     //   969: aload 8
/*     */     //   971: invokevirtual 483	org/apache/commons/httpclient/methods/PostMethod:getStatusLine	()Lorg/apache/commons/httpclient/StatusLine;
/*     */     //   974: invokevirtual 490	org/apache/commons/httpclient/StatusLine:getReasonPhrase	()Ljava/lang/String;
/*     */     //   977: astore 16
/*     */     //   979: aload 16
/*     */     //   981: ldc_w 495
/*     */     //   984: invokevirtual 497	java/lang/String:contains	(Ljava/lang/CharSequence;)Z
/*     */     //   987: ifeq +16 -> 1003
/*     */     //   990: aload 16
/*     */     //   992: ldc_w 495
/*     */     //   995: ldc_w 500
/*     */     //   998: invokevirtual 502	java/lang/String:replaceAll	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*     */     //   1001: astore 16
/*     */     //   1003: new 167	es/mityc/javasign/tsa/TimeStampException
/*     */     //   1006: dup
/*     */     //   1007: getstatic 28	es/mityc/javasign/ts/HTTPTimeStampGenerator:I18N	Les/mityc/javasign/i18n/II18nManager;
/*     */     //   1010: ldc_w 506
/*     */     //   1013: iconst_1
/*     */     //   1014: anewarray 3	java/lang/Object
/*     */     //   1017: dup
/*     */     //   1018: iconst_0
/*     */     //   1019: aload 16
/*     */     //   1021: ldc_w 508
/*     */     //   1024: invokevirtual 510	java/lang/String:getBytes	(Ljava/lang/String;)[B
/*     */     //   1027: ldc_w 508
/*     */     //   1030: invokestatic 513	org/apache/commons/httpclient/util/EncodingUtil:getString	([BLjava/lang/String;)Ljava/lang/String;
/*     */     //   1033: aastore
/*     */     //   1034: invokeinterface 257 3 0
/*     */     //   1039: invokespecial 186	es/mityc/javasign/tsa/TimeStampException:<init>	(Ljava/lang/String;)V
/*     */     //   1042: athrow
/*     */     //   1043: new 167	es/mityc/javasign/tsa/TimeStampException
/*     */     //   1046: dup
/*     */     //   1047: getstatic 28	es/mityc/javasign/ts/HTTPTimeStampGenerator:I18N	Les/mityc/javasign/i18n/II18nManager;
/*     */     //   1050: ldc_w 506
/*     */     //   1053: iconst_1
/*     */     //   1054: anewarray 3	java/lang/Object
/*     */     //   1057: dup
/*     */     //   1058: iconst_0
/*     */     //   1059: aload 8
/*     */     //   1061: invokevirtual 519	org/apache/commons/httpclient/methods/PostMethod:getStatusCode	()I
/*     */     //   1064: invokestatic 522	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
/*     */     //   1067: aastore
/*     */     //   1068: invokeinterface 257 3 0
/*     */     //   1073: invokespecial 186	es/mityc/javasign/tsa/TimeStampException:<init>	(Ljava/lang/String;)V
/*     */     //   1076: athrow
/*     */     //   1077: astore 20
/*     */     //   1079: aload 13
/*     */     //   1081: ifnull +8 -> 1089
/*     */     //   1084: aload 13
/*     */     //   1086: invokevirtual 525	java/net/HttpURLConnection:disconnect	()V
/*     */     //   1089: aload 14
/*     */     //   1091: ifnull +37 -> 1128
/*     */     //   1094: aload 14
/*     */     //   1096: invokevirtual 528	java/io/BufferedReader:close	()V
/*     */     //   1099: goto +29 -> 1128
/*     */     //   1102: astore 21
/*     */     //   1104: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   1107: invokeinterface 428 1 0
/*     */     //   1112: ifeq +16 -> 1128
/*     */     //   1115: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   1118: ldc_w 531
/*     */     //   1121: aload 21
/*     */     //   1123: invokeinterface 479 3 0
/*     */     //   1128: aload 20
/*     */     //   1130: athrow
/*     */     //   1131: aload 13
/*     */     //   1133: ifnull +8 -> 1141
/*     */     //   1136: aload 13
/*     */     //   1138: invokevirtual 525	java/net/HttpURLConnection:disconnect	()V
/*     */     //   1141: aload 14
/*     */     //   1143: ifnull +66 -> 1209
/*     */     //   1146: aload 14
/*     */     //   1148: invokevirtual 528	java/io/BufferedReader:close	()V
/*     */     //   1151: goto +58 -> 1209
/*     */     //   1154: astore 21
/*     */     //   1156: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   1159: invokeinterface 428 1 0
/*     */     //   1164: ifeq +45 -> 1209
/*     */     //   1167: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   1170: ldc_w 531
/*     */     //   1173: aload 21
/*     */     //   1175: invokeinterface 479 3 0
/*     */     //   1180: goto +29 -> 1209
/*     */     //   1183: aload 8
/*     */     //   1185: invokevirtual 533	org/apache/commons/httpclient/methods/PostMethod:getResponseBody	()[B
/*     */     //   1188: astore 11
/*     */     //   1190: new 66	java/lang/String
/*     */     //   1193: aload 11
/*     */     //   1195: invokespecial 536	java/lang/String:<init>	([B)V
/*     */     //   1198: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   1201: ldc_w 463
/*     */     //   1204: invokeinterface 189 2 0
/*     */     //   1209: new 537	org/bouncycastle/tsp/TimeStampResponse
/*     */     //   1212: dup
/*     */     //   1213: aload 11
/*     */     //   1215: invokespecial 539	org/bouncycastle/tsp/TimeStampResponse:<init>	([B)V
/*     */     //   1218: astore 6
/*     */     //   1220: aload 6
/*     */     //   1222: aload 5
/*     */     //   1224: invokevirtual 540	org/bouncycastle/tsp/TimeStampResponse:validate	(Lorg/bouncycastle/tsp/TimeStampRequest;)V
/*     */     //   1227: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   1230: ldc_w 544
/*     */     //   1233: invokeinterface 189 2 0
/*     */     //   1238: new 546	org/bouncycastle/asn1/ASN1InputStream
/*     */     //   1241: dup
/*     */     //   1242: aload 11
/*     */     //   1244: invokespecial 548	org/bouncycastle/asn1/ASN1InputStream:<init>	([B)V
/*     */     //   1247: astore 13
/*     */     //   1249: aload 13
/*     */     //   1251: invokevirtual 549	org/bouncycastle/asn1/ASN1InputStream:readObject	()Lorg/bouncycastle/asn1/DERObject;
/*     */     //   1254: invokestatic 553	org/bouncycastle/asn1/ASN1Sequence:getInstance	(Ljava/lang/Object;)Lorg/bouncycastle/asn1/ASN1Sequence;
/*     */     //   1257: astore 14
/*     */     //   1259: aconst_null
/*     */     //   1260: astore 15
/*     */     //   1262: aload 14
/*     */     //   1264: invokevirtual 558	org/bouncycastle/asn1/ASN1Sequence:size	()I
/*     */     //   1267: iconst_1
/*     */     //   1268: if_icmple +11 -> 1279
/*     */     //   1271: aload 14
/*     */     //   1273: iconst_1
/*     */     //   1274: invokevirtual 561	org/bouncycastle/asn1/ASN1Sequence:getObjectAt	(I)Lorg/bouncycastle/asn1/DEREncodable;
/*     */     //   1277: astore 15
/*     */     //   1279: aload 15
/*     */     //   1281: ifnonnull +67 -> 1348
/*     */     //   1284: new 290	org/apache/commons/httpclient/HostConfiguration
/*     */     //   1287: dup
/*     */     //   1288: invokespecial 565	org/apache/commons/httpclient/HostConfiguration:<init>	()V
/*     */     //   1291: astore 24
/*     */     //   1293: aload 24
/*     */     //   1295: aload_0
/*     */     //   1296: getfield 57	es/mityc/javasign/ts/HTTPTimeStampGenerator:servidorTSA	Ljava/lang/String;
/*     */     //   1299: invokevirtual 566	org/apache/commons/httpclient/HostConfiguration:setHost	(Ljava/lang/String;)V
/*     */     //   1302: aload_3
/*     */     //   1303: invokevirtual 216	org/apache/commons/httpclient/HttpClient:getHttpConnectionManager	()Lorg/apache/commons/httpclient/HttpConnectionManager;
/*     */     //   1306: aload 24
/*     */     //   1308: invokeinterface 569 2 0
/*     */     //   1313: astore 25
/*     */     //   1315: aload 25
/*     */     //   1317: ifnull +24 -> 1341
/*     */     //   1320: aload_3
/*     */     //   1321: invokevirtual 216	org/apache/commons/httpclient/HttpClient:getHttpConnectionManager	()Lorg/apache/commons/httpclient/HttpConnectionManager;
/*     */     //   1324: aload 25
/*     */     //   1326: invokeinterface 572 2 0
/*     */     //   1331: aload 25
/*     */     //   1333: invokevirtual 576	org/apache/commons/httpclient/HttpConnection:close	()V
/*     */     //   1336: aload 25
/*     */     //   1338: invokevirtual 579	org/apache/commons/httpclient/HttpConnection:releaseConnection	()V
/*     */     //   1341: aload 8
/*     */     //   1343: invokevirtual 581	org/apache/commons/httpclient/methods/PostMethod:releaseConnection	()V
/*     */     //   1346: aconst_null
/*     */     //   1347: areturn
/*     */     //   1348: aload 15
/*     */     //   1350: invokeinterface 582 1 0
/*     */     //   1355: invokevirtual 587	org/bouncycastle/asn1/DERObject:getEncoded	()[B
/*     */     //   1358: astore 23
/*     */     //   1360: new 290	org/apache/commons/httpclient/HostConfiguration
/*     */     //   1363: dup
/*     */     //   1364: invokespecial 565	org/apache/commons/httpclient/HostConfiguration:<init>	()V
/*     */     //   1367: astore 24
/*     */     //   1369: aload 24
/*     */     //   1371: aload_0
/*     */     //   1372: getfield 57	es/mityc/javasign/ts/HTTPTimeStampGenerator:servidorTSA	Ljava/lang/String;
/*     */     //   1375: invokevirtual 566	org/apache/commons/httpclient/HostConfiguration:setHost	(Ljava/lang/String;)V
/*     */     //   1378: aload_3
/*     */     //   1379: invokevirtual 216	org/apache/commons/httpclient/HttpClient:getHttpConnectionManager	()Lorg/apache/commons/httpclient/HttpConnectionManager;
/*     */     //   1382: aload 24
/*     */     //   1384: invokeinterface 569 2 0
/*     */     //   1389: astore 25
/*     */     //   1391: aload 25
/*     */     //   1393: ifnull +24 -> 1417
/*     */     //   1396: aload_3
/*     */     //   1397: invokevirtual 216	org/apache/commons/httpclient/HttpClient:getHttpConnectionManager	()Lorg/apache/commons/httpclient/HttpConnectionManager;
/*     */     //   1400: aload 25
/*     */     //   1402: invokeinterface 572 2 0
/*     */     //   1407: aload 25
/*     */     //   1409: invokevirtual 576	org/apache/commons/httpclient/HttpConnection:close	()V
/*     */     //   1412: aload 25
/*     */     //   1414: invokevirtual 579	org/apache/commons/httpclient/HttpConnection:releaseConnection	()V
/*     */     //   1417: aload 8
/*     */     //   1419: invokevirtual 581	org/apache/commons/httpclient/methods/PostMethod:releaseConnection	()V
/*     */     //   1422: aload 23
/*     */     //   1424: areturn
/*     */     //   1425: astore 13
/*     */     //   1427: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   1430: new 131	java/lang/StringBuilder
/*     */     //   1433: dup
/*     */     //   1434: ldc_w 590
/*     */     //   1437: invokespecial 135	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   1440: aload 13
/*     */     //   1442: invokevirtual 592	org/bouncycastle/tsp/TSPException:getMessage	()Ljava/lang/String;
/*     */     //   1445: invokevirtual 143	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   1448: invokevirtual 147	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   1451: aload 13
/*     */     //   1453: invokeinterface 150 3 0
/*     */     //   1458: new 167	es/mityc/javasign/tsa/TimeStampException
/*     */     //   1461: dup
/*     */     //   1462: getstatic 28	es/mityc/javasign/ts/HTTPTimeStampGenerator:I18N	Les/mityc/javasign/i18n/II18nManager;
/*     */     //   1465: ldc_w 595
/*     */     //   1468: iconst_1
/*     */     //   1469: anewarray 3	java/lang/Object
/*     */     //   1472: dup
/*     */     //   1473: iconst_0
/*     */     //   1474: aload 13
/*     */     //   1476: invokevirtual 592	org/bouncycastle/tsp/TSPException:getMessage	()Ljava/lang/String;
/*     */     //   1479: aastore
/*     */     //   1480: invokeinterface 257 3 0
/*     */     //   1485: invokespecial 186	es/mityc/javasign/tsa/TimeStampException:<init>	(Ljava/lang/String;)V
/*     */     //   1488: athrow
/*     */     //   1489: astore 13
/*     */     //   1491: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   1494: new 131	java/lang/StringBuilder
/*     */     //   1497: dup
/*     */     //   1498: ldc_w 597
/*     */     //   1501: invokespecial 135	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   1504: aload 13
/*     */     //   1506: invokevirtual 592	org/bouncycastle/tsp/TSPException:getMessage	()Ljava/lang/String;
/*     */     //   1509: invokevirtual 143	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   1512: invokevirtual 147	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   1515: aload 13
/*     */     //   1517: invokeinterface 150 3 0
/*     */     //   1522: new 167	es/mityc/javasign/tsa/TimeStampException
/*     */     //   1525: dup
/*     */     //   1526: getstatic 28	es/mityc/javasign/ts/HTTPTimeStampGenerator:I18N	Les/mityc/javasign/i18n/II18nManager;
/*     */     //   1529: ldc_w 599
/*     */     //   1532: iconst_1
/*     */     //   1533: anewarray 3	java/lang/Object
/*     */     //   1536: dup
/*     */     //   1537: iconst_0
/*     */     //   1538: aload 13
/*     */     //   1540: invokevirtual 592	org/bouncycastle/tsp/TSPException:getMessage	()Ljava/lang/String;
/*     */     //   1543: aastore
/*     */     //   1544: invokeinterface 257 3 0
/*     */     //   1549: invokespecial 186	es/mityc/javasign/tsa/TimeStampException:<init>	(Ljava/lang/String;)V
/*     */     //   1552: athrow
/*     */     //   1553: astore 13
/*     */     //   1555: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   1558: new 131	java/lang/StringBuilder
/*     */     //   1561: dup
/*     */     //   1562: ldc_w 601
/*     */     //   1565: invokespecial 135	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   1568: aload 13
/*     */     //   1570: invokevirtual 138	java/io/IOException:getMessage	()Ljava/lang/String;
/*     */     //   1573: invokevirtual 143	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   1576: invokevirtual 147	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   1579: aload 13
/*     */     //   1581: invokeinterface 150 3 0
/*     */     //   1586: new 167	es/mityc/javasign/tsa/TimeStampException
/*     */     //   1589: dup
/*     */     //   1590: getstatic 28	es/mityc/javasign/ts/HTTPTimeStampGenerator:I18N	Les/mityc/javasign/i18n/II18nManager;
/*     */     //   1593: ldc_w 603
/*     */     //   1596: iconst_1
/*     */     //   1597: anewarray 3	java/lang/Object
/*     */     //   1600: dup
/*     */     //   1601: iconst_0
/*     */     //   1602: aload 13
/*     */     //   1604: invokevirtual 138	java/io/IOException:getMessage	()Ljava/lang/String;
/*     */     //   1607: aastore
/*     */     //   1608: invokeinterface 257 3 0
/*     */     //   1613: invokespecial 186	es/mityc/javasign/tsa/TimeStampException:<init>	(Ljava/lang/String;)V
/*     */     //   1616: athrow
/*     */     //   1617: astore 12
/*     */     //   1619: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   1622: new 131	java/lang/StringBuilder
/*     */     //   1625: dup
/*     */     //   1626: ldc_w 605
/*     */     //   1629: invokespecial 135	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   1632: aload 12
/*     */     //   1634: invokevirtual 607	org/apache/commons/httpclient/HttpException:getMessage	()Ljava/lang/String;
/*     */     //   1637: invokevirtual 143	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   1640: invokevirtual 147	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   1643: aload 12
/*     */     //   1645: invokeinterface 150 3 0
/*     */     //   1650: new 167	es/mityc/javasign/tsa/TimeStampException
/*     */     //   1653: dup
/*     */     //   1654: getstatic 28	es/mityc/javasign/ts/HTTPTimeStampGenerator:I18N	Les/mityc/javasign/i18n/II18nManager;
/*     */     //   1657: ldc_w 610
/*     */     //   1660: iconst_1
/*     */     //   1661: anewarray 3	java/lang/Object
/*     */     //   1664: dup
/*     */     //   1665: iconst_0
/*     */     //   1666: aload 12
/*     */     //   1668: invokevirtual 607	org/apache/commons/httpclient/HttpException:getMessage	()Ljava/lang/String;
/*     */     //   1671: aastore
/*     */     //   1672: invokeinterface 257 3 0
/*     */     //   1677: invokespecial 186	es/mityc/javasign/tsa/TimeStampException:<init>	(Ljava/lang/String;)V
/*     */     //   1680: athrow
/*     */     //   1681: astore 12
/*     */     //   1683: getstatic 28	es/mityc/javasign/ts/HTTPTimeStampGenerator:I18N	Les/mityc/javasign/i18n/II18nManager;
/*     */     //   1686: ldc_w 612
/*     */     //   1689: iconst_2
/*     */     //   1690: anewarray 3	java/lang/Object
/*     */     //   1693: dup
/*     */     //   1694: iconst_0
/*     */     //   1695: aload_0
/*     */     //   1696: getfield 57	es/mityc/javasign/ts/HTTPTimeStampGenerator:servidorTSA	Ljava/lang/String;
/*     */     //   1699: aastore
/*     */     //   1700: dup
/*     */     //   1701: iconst_1
/*     */     //   1702: aload 12
/*     */     //   1704: aastore
/*     */     //   1705: invokeinterface 257 3 0
/*     */     //   1710: astore 13
/*     */     //   1712: getstatic 50	es/mityc/javasign/ts/HTTPTimeStampGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   1715: new 131	java/lang/StringBuilder
/*     */     //   1718: dup
/*     */     //   1719: ldc_w 368
/*     */     //   1722: invokespecial 135	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   1725: aload 12
/*     */     //   1727: invokevirtual 138	java/io/IOException:getMessage	()Ljava/lang/String;
/*     */     //   1730: invokevirtual 143	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   1733: invokevirtual 147	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   1736: invokeinterface 176 2 0
/*     */     //   1741: new 167	es/mityc/javasign/tsa/TimeStampException
/*     */     //   1744: dup
/*     */     //   1745: aload 13
/*     */     //   1747: invokespecial 186	es/mityc/javasign/tsa/TimeStampException:<init>	(Ljava/lang/String;)V
/*     */     //   1750: athrow
/*     */     //   1751: astore 22
/*     */     //   1753: new 290	org/apache/commons/httpclient/HostConfiguration
/*     */     //   1756: dup
/*     */     //   1757: invokespecial 565	org/apache/commons/httpclient/HostConfiguration:<init>	()V
/*     */     //   1760: astore 24
/*     */     //   1762: aload 24
/*     */     //   1764: aload_0
/*     */     //   1765: getfield 57	es/mityc/javasign/ts/HTTPTimeStampGenerator:servidorTSA	Ljava/lang/String;
/*     */     //   1768: invokevirtual 566	org/apache/commons/httpclient/HostConfiguration:setHost	(Ljava/lang/String;)V
/*     */     //   1771: aload_3
/*     */     //   1772: invokevirtual 216	org/apache/commons/httpclient/HttpClient:getHttpConnectionManager	()Lorg/apache/commons/httpclient/HttpConnectionManager;
/*     */     //   1775: aload 24
/*     */     //   1777: invokeinterface 569 2 0
/*     */     //   1782: astore 25
/*     */     //   1784: aload 25
/*     */     //   1786: ifnull +24 -> 1810
/*     */     //   1789: aload_3
/*     */     //   1790: invokevirtual 216	org/apache/commons/httpclient/HttpClient:getHttpConnectionManager	()Lorg/apache/commons/httpclient/HttpConnectionManager;
/*     */     //   1793: aload 25
/*     */     //   1795: invokeinterface 572 2 0
/*     */     //   1800: aload 25
/*     */     //   1802: invokevirtual 576	org/apache/commons/httpclient/HttpConnection:close	()V
/*     */     //   1805: aload 25
/*     */     //   1807: invokevirtual 579	org/apache/commons/httpclient/HttpConnection:releaseConnection	()V
/*     */     //   1810: aload 8
/*     */     //   1812: invokevirtual 581	org/apache/commons/httpclient/methods/PostMethod:releaseConnection	()V
/*     */     //   1815: aload 22
/*     */     //   1817: athrow
/*     */     // Line number table:
/*     */     //   Java source line #138	-> byte code offset #0
/*     */     //   Java source line #139	-> byte code offset #4
/*     */     //   Java source line #140	-> byte code offset #14
/*     */     //   Java source line #142	-> byte code offset #32
/*     */     //   Java source line #144	-> byte code offset #42
/*     */     //   Java source line #145	-> byte code offset #50
/*     */     //   Java source line #146	-> byte code offset #59
/*     */     //   Java source line #147	-> byte code offset #65
/*     */     //   Java source line #148	-> byte code offset #76
/*     */     //   Java source line #150	-> byte code offset #88
/*     */     //   Java source line #151	-> byte code offset #91
/*     */     //   Java source line #153	-> byte code offset #94
/*     */     //   Java source line #156	-> byte code offset #106
/*     */     //   Java source line #157	-> byte code offset #115
/*     */     //   Java source line #158	-> byte code offset #121
/*     */     //   Java source line #159	-> byte code offset #140
/*     */     //   Java source line #160	-> byte code offset #150
/*     */     //   Java source line #161	-> byte code offset #155
/*     */     //   Java source line #162	-> byte code offset #167
/*     */     //   Java source line #165	-> byte code offset #197
/*     */     //   Java source line #167	-> byte code offset #211
/*     */     //   Java source line #168	-> byte code offset #219
/*     */     //   Java source line #169	-> byte code offset #224
/*     */     //   Java source line #171	-> byte code offset #228
/*     */     //   Java source line #172	-> byte code offset #239
/*     */     //   Java source line #173	-> byte code offset #244
/*     */     //   Java source line #175	-> byte code offset #255
/*     */     //   Java source line #176	-> byte code offset #269
/*     */     //   Java source line #179	-> byte code offset #281
/*     */     //   Java source line #180	-> byte code offset #294
/*     */     //   Java source line #181	-> byte code offset #305
/*     */     //   Java source line #183	-> byte code offset #308
/*     */     //   Java source line #184	-> byte code offset #322
/*     */     //   Java source line #185	-> byte code offset #327
/*     */     //   Java source line #186	-> byte code offset #358
/*     */     //   Java source line #189	-> byte code offset #389
/*     */     //   Java source line #190	-> byte code offset #400
/*     */     //   Java source line #192	-> byte code offset #407
/*     */     //   Java source line #193	-> byte code offset #415
/*     */     //   Java source line #192	-> byte code offset #424
/*     */     //   Java source line #195	-> byte code offset #427
/*     */     //   Java source line #197	-> byte code offset #430
/*     */     //   Java source line #199	-> byte code offset #433
/*     */     //   Java source line #200	-> byte code offset #441
/*     */     //   Java source line #201	-> byte code offset #452
/*     */     //   Java source line #202	-> byte code offset #457
/*     */     //   Java source line #203	-> byte code offset #486
/*     */     //   Java source line #206	-> byte code offset #491
/*     */     //   Java source line #207	-> byte code offset #499
/*     */     //   Java source line #208	-> byte code offset #510
/*     */     //   Java source line #209	-> byte code offset #513
/*     */     //   Java source line #211	-> byte code offset #516
/*     */     //   Java source line #213	-> byte code offset #525
/*     */     //   Java source line #214	-> byte code offset #533
/*     */     //   Java source line #215	-> byte code offset #541
/*     */     //   Java source line #216	-> byte code offset #552
/*     */     //   Java source line #217	-> byte code offset #563
/*     */     //   Java source line #218	-> byte code offset #580
/*     */     //   Java source line #219	-> byte code offset #586
/*     */     //   Java source line #221	-> byte code offset #592
/*     */     //   Java source line #222	-> byte code offset #606
/*     */     //   Java source line #223	-> byte code offset #616
/*     */     //   Java source line #224	-> byte code offset #621
/*     */     //   Java source line #226	-> byte code offset #626
/*     */     //   Java source line #227	-> byte code offset #637
/*     */     //   Java source line #228	-> byte code offset #648
/*     */     //   Java source line #230	-> byte code offset #677
/*     */     //   Java source line #231	-> byte code offset #684
/*     */     //   Java source line #232	-> byte code offset #689
/*     */     //   Java source line #233	-> byte code offset #697
/*     */     //   Java source line #234	-> byte code offset #704
/*     */     //   Java source line #235	-> byte code offset #717
/*     */     //   Java source line #236	-> byte code offset #720
/*     */     //   Java source line #237	-> byte code offset #729
/*     */     //   Java source line #238	-> byte code offset #735
/*     */     //   Java source line #239	-> byte code offset #742
/*     */     //   Java source line #237	-> byte code offset #750
/*     */     //   Java source line #242	-> byte code offset #766
/*     */     //   Java source line #243	-> byte code offset #769
/*     */     //   Java source line #245	-> byte code offset #798
/*     */     //   Java source line #246	-> byte code offset #809
/*     */     //   Java source line #248	-> byte code offset #820
/*     */     //   Java source line #249	-> byte code offset #831
/*     */     //   Java source line #250	-> byte code offset #834
/*     */     //   Java source line #253	-> byte code offset #863
/*     */     //   Java source line #255	-> byte code offset #906
/*     */     //   Java source line #256	-> byte code offset #908
/*     */     //   Java source line #257	-> byte code offset #919
/*     */     //   Java source line #259	-> byte code offset #932
/*     */     //   Java source line #260	-> byte code offset #961
/*     */     //   Java source line #261	-> byte code offset #969
/*     */     //   Java source line #262	-> byte code offset #979
/*     */     //   Java source line #263	-> byte code offset #990
/*     */     //   Java source line #265	-> byte code offset #1003
/*     */     //   Java source line #267	-> byte code offset #1043
/*     */     //   Java source line #269	-> byte code offset #1077
/*     */     //   Java source line #270	-> byte code offset #1079
/*     */     //   Java source line #271	-> byte code offset #1084
/*     */     //   Java source line #273	-> byte code offset #1089
/*     */     //   Java source line #274	-> byte code offset #1094
/*     */     //   Java source line #275	-> byte code offset #1104
/*     */     //   Java source line #276	-> byte code offset #1115
/*     */     //   Java source line #280	-> byte code offset #1128
/*     */     //   Java source line #270	-> byte code offset #1131
/*     */     //   Java source line #271	-> byte code offset #1136
/*     */     //   Java source line #273	-> byte code offset #1141
/*     */     //   Java source line #274	-> byte code offset #1146
/*     */     //   Java source line #275	-> byte code offset #1156
/*     */     //   Java source line #276	-> byte code offset #1167
/*     */     //   Java source line #281	-> byte code offset #1180
/*     */     //   Java source line #282	-> byte code offset #1183
/*     */     //   Java source line #283	-> byte code offset #1190
/*     */     //   Java source line #284	-> byte code offset #1198
/*     */     //   Java source line #288	-> byte code offset #1209
/*     */     //   Java source line #292	-> byte code offset #1220
/*     */     //   Java source line #294	-> byte code offset #1227
/*     */     //   Java source line #298	-> byte code offset #1238
/*     */     //   Java source line #299	-> byte code offset #1249
/*     */     //   Java source line #300	-> byte code offset #1259
/*     */     //   Java source line #301	-> byte code offset #1262
/*     */     //   Java source line #302	-> byte code offset #1271
/*     */     //   Java source line #303	-> byte code offset #1279
/*     */     //   Java source line #330	-> byte code offset #1284
/*     */     //   Java source line #331	-> byte code offset #1293
/*     */     //   Java source line #332	-> byte code offset #1302
/*     */     //   Java source line #333	-> byte code offset #1315
/*     */     //   Java source line #334	-> byte code offset #1320
/*     */     //   Java source line #335	-> byte code offset #1331
/*     */     //   Java source line #336	-> byte code offset #1336
/*     */     //   Java source line #338	-> byte code offset #1341
/*     */     //   Java source line #304	-> byte code offset #1346
/*     */     //   Java source line #306	-> byte code offset #1348
/*     */     //   Java source line #330	-> byte code offset #1360
/*     */     //   Java source line #331	-> byte code offset #1369
/*     */     //   Java source line #332	-> byte code offset #1378
/*     */     //   Java source line #333	-> byte code offset #1391
/*     */     //   Java source line #334	-> byte code offset #1396
/*     */     //   Java source line #335	-> byte code offset #1407
/*     */     //   Java source line #336	-> byte code offset #1412
/*     */     //   Java source line #338	-> byte code offset #1417
/*     */     //   Java source line #306	-> byte code offset #1422
/*     */     //   Java source line #308	-> byte code offset #1425
/*     */     //   Java source line #309	-> byte code offset #1427
/*     */     //   Java source line #310	-> byte code offset #1458
/*     */     //   Java source line #312	-> byte code offset #1489
/*     */     //   Java source line #313	-> byte code offset #1491
/*     */     //   Java source line #314	-> byte code offset #1522
/*     */     //   Java source line #315	-> byte code offset #1553
/*     */     //   Java source line #316	-> byte code offset #1555
/*     */     //   Java source line #317	-> byte code offset #1586
/*     */     //   Java source line #320	-> byte code offset #1617
/*     */     //   Java source line #321	-> byte code offset #1619
/*     */     //   Java source line #322	-> byte code offset #1650
/*     */     //   Java source line #323	-> byte code offset #1681
/*     */     //   Java source line #324	-> byte code offset #1683
/*     */     //   Java source line #325	-> byte code offset #1712
/*     */     //   Java source line #327	-> byte code offset #1741
/*     */     //   Java source line #328	-> byte code offset #1751
/*     */     //   Java source line #330	-> byte code offset #1753
/*     */     //   Java source line #331	-> byte code offset #1762
/*     */     //   Java source line #332	-> byte code offset #1771
/*     */     //   Java source line #333	-> byte code offset #1784
/*     */     //   Java source line #334	-> byte code offset #1789
/*     */     //   Java source line #335	-> byte code offset #1800
/*     */     //   Java source line #336	-> byte code offset #1805
/*     */     //   Java source line #338	-> byte code offset #1810
/*     */     //   Java source line #339	-> byte code offset #1815
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	1818	0	this	HTTPTimeStampGenerator
/*     */     //   0	1818	1	dataToSeal	byte[]
/*     */     //   0	1818	2	idApplication	String
/*     */     //   49	1741	3	CLIENTE	org.apache.commons.httpclient.HttpClient
/*     */     //   57	65	4	generadorPeticion	org.bouncycastle.tsp.TimeStampRequestGenerator
/*     */     //   89	1134	5	peticion	org.bouncycastle.tsp.TimeStampRequest
/*     */     //   92	1129	6	respuesta	org.bouncycastle.tsp.TimeStampResponse
/*     */     //   113	18	7	resumen	java.security.MessageDigest
/*     */     //   153	30	7	e	Exception
/*     */     //   217	43	7	servidorProxy	String
/*     */     //   226	25	8	puertoProxy	int
/*     */     //   292	1519	8	metodo	org.apache.commons.httpclient.methods.PostMethod
/*     */     //   242	1	9	localNumberFormatException	NumberFormatException
/*     */     //   267	10	9	defaultcreds	org.apache.commons.httpclient.Credentials
/*     */     //   306	88	9	datos	java.io.ByteArrayInputStream
/*     */     //   325	50	10	e	IOException
/*     */     //   398	5	10	rq	org.apache.commons.httpclient.methods.InputStreamRequestEntity
/*     */     //   428	815	11	cuerpoRespuesta	byte[]
/*     */     //   431	61	12	estadoCodigo	int
/*     */     //   1617	50	12	e	org.apache.commons.httpclient.HttpException
/*     */     //   1681	45	12	e	IOException
/*     */     //   455	16	13	e	IOException
/*     */     //   511	626	13	conn	java.net.HttpURLConnection
/*     */     //   1247	3	13	is	org.bouncycastle.asn1.ASN1InputStream
/*     */     //   1425	50	13	e	org.bouncycastle.tsp.TSPException
/*     */     //   1489	50	13	e	org.bouncycastle.tsp.TSPException
/*     */     //   1553	50	13	e	IOException
/*     */     //   1710	36	13	mensajeError	String
/*     */     //   514	633	14	brr	java.io.BufferedReader
/*     */     //   1257	15	14	seq	org.bouncycastle.asn1.ASN1Sequence
/*     */     //   604	18	15	wr	java.io.DataOutputStream
/*     */     //   906	20	15	e1	Exception
/*     */     //   1260	89	15	enc	org.bouncycastle.asn1.DEREncodable
/*     */     //   682	16	16	response	Object
/*     */     //   977	43	16	m	String
/*     */     //   702	34	17	in	java.io.InputStream
/*     */     //   718	36	18	b	int
/*     */     //   730	29	19	i	int
/*     */     //   1077	52	20	localObject1	Object
/*     */     //   1102	20	21	e1	IOException
/*     */     //   1154	20	21	e1	IOException
/*     */     //   1751	65	22	localObject2	Object
/*     */     //   1358	65	23	arrayOfByte1	byte[]
/*     */     //   1291	16	24	hostConf	org.apache.commons.httpclient.HostConfiguration
/*     */     //   1367	16	24	hostConf	org.apache.commons.httpclient.HostConfiguration
/*     */     //   1760	16	24	hostConf	org.apache.commons.httpclient.HostConfiguration
/*     */     //   1313	24	25	conn	org.apache.commons.httpclient.HttpConnection
/*     */     //   1389	24	25	conn	org.apache.commons.httpclient.HttpConnection
/*     */     //   1782	24	25	conn	org.apache.commons.httpclient.HttpConnection
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   106	150	153	java/lang/Exception
/*     */     //   228	239	242	java/lang/NumberFormatException
/*     */     //   308	322	325	java/io/IOException
/*     */     //   433	452	455	java/io/IOException
/*     */     //   516	906	906	java/lang/Exception
/*     */     //   516	1077	1077	finally
/*     */     //   1094	1099	1102	java/io/IOException
/*     */     //   1146	1151	1154	java/io/IOException
/*     */     //   1220	1284	1425	org/bouncycastle/tsp/TSPException
/*     */     //   1348	1360	1425	org/bouncycastle/tsp/TSPException
/*     */     //   1209	1284	1489	org/bouncycastle/tsp/TSPException
/*     */     //   1348	1360	1489	org/bouncycastle/tsp/TSPException
/*     */     //   1425	1489	1489	org/bouncycastle/tsp/TSPException
/*     */     //   1209	1284	1553	java/io/IOException
/*     */     //   1348	1360	1553	java/io/IOException
/*     */     //   1425	1489	1553	java/io/IOException
/*     */     //   430	1284	1617	org/apache/commons/httpclient/HttpException
/*     */     //   1348	1360	1617	org/apache/commons/httpclient/HttpException
/*     */     //   1425	1617	1617	org/apache/commons/httpclient/HttpException
/*     */     //   430	1284	1681	java/io/IOException
/*     */     //   1348	1360	1681	java/io/IOException
/*     */     //   1425	1617	1681	java/io/IOException
/*     */     //   430	1284	1751	finally
/*     */     //   1348	1360	1751	finally
/*     */     //   1425	1751	1751	finally
/*     */   }
/*     */   
/*     */   public void setTimeOut(Integer timeMilis)
/*     */   {
/* 348 */     if ((timeMilis != null) && (timeMilis.intValue() > 0)) {
/* 349 */       log.debug("Se establece el tiempo máximo de espera a " + timeMilis);
/* 350 */       this.timeOut = timeMilis;
/*     */     } else {
/* 352 */       log.error("No se pudo establecer el valor de TimeOut a " + timeMilis + ". Se toma el valor por defecto.");
/* 353 */       this.timeOut = INT10000;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibTSA-1.1.7.jar!\es\mityc\javasign\ts\HTTPTimeStampGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */