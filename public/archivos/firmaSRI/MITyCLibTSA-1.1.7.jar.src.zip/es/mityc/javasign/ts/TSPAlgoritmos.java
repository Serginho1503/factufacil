/*     */ package es.mityc.javasign.ts;
/*     */ 
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.bouncycastle.tsp.TSPAlgorithms;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TSPAlgoritmos
/*     */ {
/*     */   public static final String SHA1 = "SHA-1";
/*     */   public static final String SHA2 = "SHA-2";
/*     */   public static final String SHA224 = "SHA-224";
/*     */   public static final String SHA256 = "SHA-256";
/*     */   public static final String SHA384 = "SHA-384";
/*     */   public static final String SHA512 = "SHA-512";
/*     */   public static final String MD5 = "MD5";
/*     */   
/*     */   public static Set<String> getPermitidos()
/*     */   {
/*  67 */     Set<String> permitidos = new HashSet(Arrays.asList(getValoresPermitidos()));
/*     */     
/*  69 */     return permitidos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getAlgName(String oid)
/*     */   {
/*  78 */     if (TSPAlgorithms.SHA1.equals(oid))
/*  79 */       return "SHA-1";
/*  80 */     if (TSPAlgorithms.SHA256.equals(oid))
/*  81 */       return "SHA-2";
/*  82 */     if (TSPAlgorithms.SHA224.equals(oid))
/*  83 */       return "SHA-224";
/*  84 */     if (TSPAlgorithms.SHA256.equals(oid))
/*  85 */       return "SHA-256";
/*  86 */     if (TSPAlgorithms.SHA384.equals(oid))
/*  87 */       return "SHA-384";
/*  88 */     if (TSPAlgorithms.SHA512.equals(oid)) {
/*  89 */       return "SHA-512";
/*     */     }
/*     */     
/*  92 */     return oid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getOID(String algoritmo)
/*     */   {
/* 101 */     Set<String> permitidos = new HashSet(Arrays.asList(getValoresPermitidos()));
/*     */     
/* 103 */     if (permitidos.contains(algoritmo)) {
/* 104 */       if ("SHA-1".equals(algoritmo))
/* 105 */         return TSPAlgorithms.SHA1;
/* 106 */       if ("SHA-2".equals(algoritmo))
/* 107 */         return TSPAlgorithms.SHA256;
/* 108 */       if ("SHA-224".equals(algoritmo))
/* 109 */         return TSPAlgorithms.SHA224;
/* 110 */       if ("SHA-256".equals(algoritmo))
/* 111 */         return TSPAlgorithms.SHA256;
/* 112 */       if ("SHA-384".equals(algoritmo))
/* 113 */         return TSPAlgorithms.SHA384;
/* 114 */       if ("SHA-512".equals(algoritmo)) {
/* 115 */         return TSPAlgorithms.SHA512;
/*     */       }
/*     */     }
/*     */     
/* 119 */     return null;
/*     */   }
/*     */   
/*     */ 
/* 123 */   private static HashMap<String, String> algoritmosVSoids = null;
/*     */   
/* 125 */   static { algoritmosVSoids = new HashMap();
/*     */     
/* 127 */     algoritmosVSoids.put(TSPAlgorithms.SHA1, "SHA-1");
/* 128 */     algoritmosVSoids.put(TSPAlgorithms.SHA224, "SHA-224");
/* 129 */     algoritmosVSoids.put(TSPAlgorithms.SHA256, "SHA-256");
/* 130 */     algoritmosVSoids.put(TSPAlgorithms.SHA384, "SHA-384");
/* 131 */     algoritmosVSoids.put(TSPAlgorithms.SHA512, "SHA-512");
/* 132 */     algoritmosVSoids.put(TSPAlgorithms.MD5, "MD5");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MessageDigest getDigest(String oid)
/*     */   {
/* 143 */     String algName = (String)algoritmosVSoids.get(oid);
/* 144 */     if (algName == null) {
/* 145 */       return null;
/*     */     }
/*     */     try {
/* 148 */       return MessageDigest.getInstance(algName);
/*     */     }
/*     */     catch (NoSuchAlgorithmException e) {}
/* 151 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String[] getValoresPermitidos()
/*     */   {
/* 160 */     String[] valoresPermitidos = new String[6];
/* 161 */     valoresPermitidos[0] = "SHA-1";
/* 162 */     valoresPermitidos[1] = "SHA-2";
/* 163 */     valoresPermitidos[2] = "SHA-224";
/* 164 */     valoresPermitidos[3] = "SHA-256";
/* 165 */     valoresPermitidos[4] = "SHA-384";
/* 166 */     valoresPermitidos[5] = "SHA-512";
/*     */     
/* 168 */     return valoresPermitidos;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibTSA-1.1.7.jar!\es\mityc\javasign\ts\TSPAlgoritmos.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */