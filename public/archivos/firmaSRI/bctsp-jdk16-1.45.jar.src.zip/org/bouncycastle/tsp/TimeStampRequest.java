package org.bouncycastle.tsp;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.NoSuchProviderException;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DERBoolean;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.tsp.MessageImprint;
import org.bouncycastle.asn1.tsp.TimeStampReq;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.X509Extensions;

public class TimeStampRequest
  implements java.security.cert.X509Extension
{
  TimeStampReq req;
  
  public TimeStampRequest(TimeStampReq paramTimeStampReq)
  {
    this.req = paramTimeStampReq;
  }
  
  public TimeStampRequest(byte[] paramArrayOfByte)
    throws IOException
  {
    this(new ByteArrayInputStream(paramArrayOfByte));
  }
  
  public TimeStampRequest(InputStream paramInputStream)
    throws IOException
  {
    try
    {
      this.req = TimeStampReq.getInstance(new ASN1InputStream(paramInputStream).readObject());
    }
    catch (ClassCastException localClassCastException)
    {
      throw new IOException("malformed request: " + localClassCastException);
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      throw new IOException("malformed request: " + localIllegalArgumentException);
    }
  }
  
  public int getVersion()
  {
    return this.req.getVersion().getValue().intValue();
  }
  
  public String getMessageImprintAlgOID()
  {
    return this.req.getMessageImprint().getHashAlgorithm().getObjectId().getId();
  }
  
  public byte[] getMessageImprintDigest()
  {
    return this.req.getMessageImprint().getHashedMessage();
  }
  
  public String getReqPolicy()
  {
    if (this.req.getReqPolicy() != null) {
      return this.req.getReqPolicy().getId();
    }
    return null;
  }
  
  public BigInteger getNonce()
  {
    if (this.req.getNonce() != null) {
      return this.req.getNonce().getValue();
    }
    return null;
  }
  
  public boolean getCertReq()
  {
    if (this.req.getCertReq() != null) {
      return this.req.getCertReq().isTrue();
    }
    return false;
  }
  
  public void validate(Set paramSet1, Set paramSet2, Set paramSet3, String paramString)
    throws TSPException, NoSuchProviderException
  {
    if (!paramSet1.contains(getMessageImprintAlgOID())) {
      throw new TSPValidationException("request contains unknown algorithm.", 128);
    }
    if ((paramSet2 != null) && (getReqPolicy() != null) && (!paramSet2.contains(getReqPolicy()))) {
      throw new TSPValidationException("request contains unknown policy.", 256);
    }
    if ((getExtensions() != null) && (paramSet3 != null))
    {
      Enumeration localEnumeration = getExtensions().oids();
      while (localEnumeration.hasMoreElements())
      {
        String str = ((DERObjectIdentifier)localEnumeration.nextElement()).getId();
        if (!paramSet3.contains(str)) {
          throw new TSPValidationException("request contains unknown extension.", 8388608);
        }
      }
    }
    int i = TSPUtil.getDigestLength(getMessageImprintAlgOID(), paramString);
    if (i != getMessageImprintDigest().length) {
      throw new TSPValidationException("imprint digest the wrong length.", 4);
    }
  }
  
  public byte[] getEncoded()
    throws IOException
  {
    return this.req.getEncoded();
  }
  
  X509Extensions getExtensions()
  {
    return this.req.getExtensions();
  }
  
  public byte[] getExtensionValue(String paramString)
  {
    X509Extensions localX509Extensions = this.req.getExtensions();
    if (localX509Extensions != null)
    {
      org.bouncycastle.asn1.x509.X509Extension localX509Extension = localX509Extensions.getExtension(new DERObjectIdentifier(paramString));
      if (localX509Extension != null) {
        try
        {
          return localX509Extension.getValue().getEncoded();
        }
        catch (Exception localException)
        {
          throw new RuntimeException("error encoding " + localException.toString());
        }
      }
    }
    return null;
  }
  
  private Set getExtensionOIDS(boolean paramBoolean)
  {
    HashSet localHashSet = new HashSet();
    X509Extensions localX509Extensions = this.req.getExtensions();
    if (localX509Extensions != null)
    {
      Enumeration localEnumeration = localX509Extensions.oids();
      while (localEnumeration.hasMoreElements())
      {
        DERObjectIdentifier localDERObjectIdentifier = (DERObjectIdentifier)localEnumeration.nextElement();
        org.bouncycastle.asn1.x509.X509Extension localX509Extension = localX509Extensions.getExtension(localDERObjectIdentifier);
        if (localX509Extension.isCritical() == paramBoolean) {
          localHashSet.add(localDERObjectIdentifier.getId());
        }
      }
      return localHashSet;
    }
    return null;
  }
  
  public Set getNonCriticalExtensionOIDs()
  {
    return getExtensionOIDS(false);
  }
  
  public Set getCriticalExtensionOIDs()
  {
    return getExtensionOIDS(true);
  }
  
  public boolean hasUnsupportedCriticalExtension()
  {
    return false;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bctsp-jdk16-1.45.jar!\org\bouncycastle\tsp\TimeStampRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */