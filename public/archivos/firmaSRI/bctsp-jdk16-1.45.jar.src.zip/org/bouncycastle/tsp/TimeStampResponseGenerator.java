package org.bouncycastle.tsp;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.Date;
import java.util.Set;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERUTF8String;
import org.bouncycastle.asn1.cmp.PKIFreeText;
import org.bouncycastle.asn1.cmp.PKIStatusInfo;
import org.bouncycastle.asn1.cms.ContentInfo;
import org.bouncycastle.asn1.tsp.TimeStampResp;
import org.bouncycastle.cms.CMSSignedData;

public class TimeStampResponseGenerator
{
  int status;
  ASN1EncodableVector statusStrings;
  int failInfo;
  private TimeStampTokenGenerator tokenGenerator;
  private Set acceptedAlgorithms;
  private Set acceptedPolicies;
  private Set acceptedExtensions;
  
  public TimeStampResponseGenerator(TimeStampTokenGenerator paramTimeStampTokenGenerator, Set paramSet)
  {
    this(paramTimeStampTokenGenerator, paramSet, null, null);
  }
  
  public TimeStampResponseGenerator(TimeStampTokenGenerator paramTimeStampTokenGenerator, Set paramSet1, Set paramSet2)
  {
    this(paramTimeStampTokenGenerator, paramSet1, paramSet2, null);
  }
  
  public TimeStampResponseGenerator(TimeStampTokenGenerator paramTimeStampTokenGenerator, Set paramSet1, Set paramSet2, Set paramSet3)
  {
    this.tokenGenerator = paramTimeStampTokenGenerator;
    this.acceptedAlgorithms = paramSet1;
    this.acceptedPolicies = paramSet2;
    this.acceptedExtensions = paramSet3;
    this.statusStrings = new ASN1EncodableVector();
  }
  
  private void addStatusString(String paramString)
  {
    this.statusStrings.add(new DERUTF8String(paramString));
  }
  
  private void setFailInfoField(int paramInt)
  {
    this.failInfo |= paramInt;
  }
  
  private PKIStatusInfo getPKIStatusInfo()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(new DERInteger(this.status));
    if (this.statusStrings.size() > 0) {
      localASN1EncodableVector.add(new PKIFreeText(new DERSequence(this.statusStrings)));
    }
    if (this.failInfo != 0)
    {
      FailInfo localFailInfo = new FailInfo(this.failInfo);
      localASN1EncodableVector.add(localFailInfo);
    }
    return new PKIStatusInfo(new DERSequence(localASN1EncodableVector));
  }
  
  public TimeStampResponse generate(TimeStampRequest paramTimeStampRequest, BigInteger paramBigInteger, Date paramDate, String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException, TSPException
  {
    TimeStampResp localTimeStampResp;
    try
    {
      paramTimeStampRequest.validate(this.acceptedAlgorithms, this.acceptedPolicies, this.acceptedExtensions, paramString);
      this.status = 0;
      addStatusString("Operation Okay");
      PKIStatusInfo localPKIStatusInfo = getPKIStatusInfo();
      localObject = null;
      try
      {
        ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(this.tokenGenerator.generate(paramTimeStampRequest, paramBigInteger, paramDate, paramString).toCMSSignedData().getEncoded());
        ASN1InputStream localASN1InputStream = new ASN1InputStream(localByteArrayInputStream);
        localObject = ContentInfo.getInstance(localASN1InputStream.readObject());
      }
      catch (IOException localIOException2)
      {
        throw new TSPException("Timestamp token received cannot be converted to ContentInfo", localIOException2);
      }
      localTimeStampResp = new TimeStampResp(localPKIStatusInfo, (ContentInfo)localObject);
    }
    catch (TSPValidationException localTSPValidationException)
    {
      this.status = 2;
      setFailInfoField(localTSPValidationException.getFailureCode());
      addStatusString(localTSPValidationException.getMessage());
      Object localObject = getPKIStatusInfo();
      localTimeStampResp = new TimeStampResp((PKIStatusInfo)localObject, null);
    }
    try
    {
      return new TimeStampResponse(localTimeStampResp);
    }
    catch (IOException localIOException1)
    {
      throw new TSPException("created badly formatted response!");
    }
  }
  
  class FailInfo
    extends DERBitString
  {
    FailInfo(int paramInt)
    {
      super(getPadBits(paramInt));
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bctsp-jdk16-1.45.jar!\org\bouncycastle\tsp\TimeStampResponseGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */