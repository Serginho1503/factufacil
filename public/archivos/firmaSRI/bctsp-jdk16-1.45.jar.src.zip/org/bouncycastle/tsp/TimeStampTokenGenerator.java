package org.bouncycastle.tsp;

import java.io.IOException;
import java.math.BigInteger;
import java.security.InvalidAlgorithmParameterException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.cert.CertStore;
import java.security.cert.CertStoreException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CollectionCertStoreParameters;
import java.security.cert.X509Certificate;
import java.util.Date;
import java.util.Hashtable;
import org.bouncycastle.asn1.DERBoolean;
import org.bouncycastle.asn1.DERGeneralizedTime;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.cms.Attribute;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.ess.ESSCertID;
import org.bouncycastle.asn1.ess.SigningCertificate;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.tsp.Accuracy;
import org.bouncycastle.asn1.tsp.MessageImprint;
import org.bouncycastle.asn1.tsp.TSTInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.CMSSignedDataGenerator;

public class TimeStampTokenGenerator
{
  int accuracySeconds = -1;
  int accuracyMillis = -1;
  int accuracyMicros = -1;
  boolean ordering = false;
  GeneralName tsa = null;
  private String tsaPolicyOID;
  PrivateKey key;
  X509Certificate cert;
  String digestOID;
  AttributeTable signedAttr;
  AttributeTable unsignedAttr;
  CertStore certsAndCrls;
  
  public TimeStampTokenGenerator(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2)
    throws IllegalArgumentException, TSPException
  {
    this(paramPrivateKey, paramX509Certificate, paramString1, paramString2, null, null);
  }
  
  public TimeStampTokenGenerator(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, String paramString1, String paramString2, AttributeTable paramAttributeTable1, AttributeTable paramAttributeTable2)
    throws IllegalArgumentException, TSPException
  {
    this.key = paramPrivateKey;
    this.cert = paramX509Certificate;
    this.digestOID = paramString1;
    this.tsaPolicyOID = paramString2;
    this.unsignedAttr = paramAttributeTable2;
    TSPUtil.validateCertificate(paramX509Certificate);
    Hashtable localHashtable = null;
    if (paramAttributeTable1 != null) {
      localHashtable = paramAttributeTable1.toHashtable();
    } else {
      localHashtable = new Hashtable();
    }
    try
    {
      ESSCertID localESSCertID = new ESSCertID(MessageDigest.getInstance("SHA-1").digest(paramX509Certificate.getEncoded()));
      localHashtable.put(PKCSObjectIdentifiers.id_aa_signingCertificate, new Attribute(PKCSObjectIdentifiers.id_aa_signingCertificate, new DERSet(new SigningCertificate(localESSCertID))));
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new TSPException("Can't find a SHA-1 implementation.", localNoSuchAlgorithmException);
    }
    catch (CertificateEncodingException localCertificateEncodingException)
    {
      throw new TSPException("Exception processing certificate.", localCertificateEncodingException);
    }
    this.signedAttr = new AttributeTable(localHashtable);
  }
  
  public void setCertificatesAndCRLs(CertStore paramCertStore)
    throws CertStoreException, TSPException
  {
    this.certsAndCrls = paramCertStore;
  }
  
  public void setAccuracySeconds(int paramInt)
  {
    this.accuracySeconds = paramInt;
  }
  
  public void setAccuracyMillis(int paramInt)
  {
    this.accuracyMillis = paramInt;
  }
  
  public void setAccuracyMicros(int paramInt)
  {
    this.accuracyMicros = paramInt;
  }
  
  public void setOrdering(boolean paramBoolean)
  {
    this.ordering = paramBoolean;
  }
  
  public void setTSA(GeneralName paramGeneralName)
  {
    this.tsa = paramGeneralName;
  }
  
  public TimeStampToken generate(TimeStampRequest paramTimeStampRequest, BigInteger paramBigInteger, Date paramDate, String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException, TSPException
  {
    DERObjectIdentifier localDERObjectIdentifier = new DERObjectIdentifier(paramTimeStampRequest.getMessageImprintAlgOID());
    AlgorithmIdentifier localAlgorithmIdentifier = new AlgorithmIdentifier(localDERObjectIdentifier, new DERNull());
    MessageImprint localMessageImprint = new MessageImprint(localAlgorithmIdentifier, paramTimeStampRequest.getMessageImprintDigest());
    Accuracy localAccuracy = null;
    if ((this.accuracySeconds > 0) || (this.accuracyMillis > 0) || (this.accuracyMicros > 0))
    {
      localObject1 = null;
      if (this.accuracySeconds > 0) {
        localObject1 = new DERInteger(this.accuracySeconds);
      }
      localDERInteger = null;
      if (this.accuracyMillis > 0) {
        localDERInteger = new DERInteger(this.accuracyMillis);
      }
      localObject2 = null;
      if (this.accuracyMicros > 0) {
        localObject2 = new DERInteger(this.accuracyMicros);
      }
      localAccuracy = new Accuracy((DERInteger)localObject1, localDERInteger, (DERInteger)localObject2);
    }
    Object localObject1 = null;
    if (this.ordering) {
      localObject1 = new DERBoolean(this.ordering);
    }
    DERInteger localDERInteger = null;
    if (paramTimeStampRequest.getNonce() != null) {
      localDERInteger = new DERInteger(paramTimeStampRequest.getNonce());
    }
    Object localObject2 = new DERObjectIdentifier(this.tsaPolicyOID);
    if (paramTimeStampRequest.getReqPolicy() != null) {
      localObject2 = new DERObjectIdentifier(paramTimeStampRequest.getReqPolicy());
    }
    TSTInfo localTSTInfo = new TSTInfo((DERObjectIdentifier)localObject2, localMessageImprint, new DERInteger(paramBigInteger), new DERGeneralizedTime(paramDate), localAccuracy, (DERBoolean)localObject1, localDERInteger, this.tsa, paramTimeStampRequest.getExtensions());
    try
    {
      CMSSignedDataGenerator localCMSSignedDataGenerator = new CMSSignedDataGenerator();
      byte[] arrayOfByte = localTSTInfo.getEncoded("DER");
      CertStore localCertStore;
      if (paramTimeStampRequest.getCertReq()) {
        localCertStore = this.certsAndCrls;
      } else {
        localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(this.certsAndCrls.getCRLs(null)));
      }
      localCMSSignedDataGenerator.addCertificatesAndCRLs(localCertStore);
      localCMSSignedDataGenerator.addSigner(this.key, this.cert, this.digestOID, this.signedAttr, this.unsignedAttr);
      CMSSignedData localCMSSignedData = localCMSSignedDataGenerator.generate(PKCSObjectIdentifiers.id_ct_TSTInfo.getId(), new CMSProcessableByteArray(arrayOfByte), true, paramString);
      return new TimeStampToken(localCMSSignedData);
    }
    catch (CMSException localCMSException)
    {
      throw new TSPException("Error generating time-stamp token", localCMSException);
    }
    catch (IOException localIOException)
    {
      throw new TSPException("Exception encoding info", localIOException);
    }
    catch (CertStoreException localCertStoreException)
    {
      throw new TSPException("Exception handling CertStore", localCertStoreException);
    }
    catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
    {
      throw new TSPException("Exception handling CertStore CRLs", localInvalidAlgorithmParameterException);
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bctsp-jdk16-1.45.jar!\org\bouncycastle\tsp\TimeStampTokenGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */