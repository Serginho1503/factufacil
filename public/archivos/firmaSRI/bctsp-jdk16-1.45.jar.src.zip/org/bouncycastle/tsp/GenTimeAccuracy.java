package org.bouncycastle.tsp;

import java.math.BigInteger;
import java.text.DecimalFormat;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.tsp.Accuracy;

public class GenTimeAccuracy
{
  private Accuracy accuracy;
  
  public GenTimeAccuracy(Accuracy paramAccuracy)
  {
    this.accuracy = paramAccuracy;
  }
  
  public int getSeconds()
  {
    return getTimeComponent(this.accuracy.getSeconds());
  }
  
  public int getMillis()
  {
    return getTimeComponent(this.accuracy.getMillis());
  }
  
  public int getMicros()
  {
    return getTimeComponent(this.accuracy.getMicros());
  }
  
  private int getTimeComponent(DERInteger paramDERInteger)
  {
    if (paramDERInteger != null) {
      return paramDERInteger.getValue().intValue();
    }
    return 0;
  }
  
  public String toString()
  {
    DecimalFormat localDecimalFormat = new DecimalFormat("000");
    return getSeconds() + "." + localDecimalFormat.format(getMillis()) + localDecimalFormat.format(getMicros());
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bctsp-jdk16-1.45.jar!\org\bouncycastle\tsp\GenTimeAccuracy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */