/*     */ package es.mityc.javasign.pkstore.pkcs11;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.pkstore.CertStoreException;
/*     */ import es.mityc.javasign.pkstore.IPKStoreManager;
/*     */ import es.mityc.javasign.pkstore.IPassStoreKS;
/*     */ import java.io.IOException;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStore.CallbackHandlerProtection;
/*     */ import java.security.KeyStore.LoadStoreParameter;
/*     */ import java.security.KeyStore.PrivateKeyEntry;
/*     */ import java.security.KeyStore.ProtectionParameter;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.Provider;
/*     */ import java.security.UnrecoverableEntryException;
/*     */ import java.security.cert.CertPath;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.security.auth.callback.Callback;
/*     */ import javax.security.auth.callback.CallbackHandler;
/*     */ import javax.security.auth.callback.PasswordCallback;
/*     */ import javax.security.auth.callback.UnsupportedCallbackException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultiPKCS11Store
/*     */   implements IPKStoreManager
/*     */ {
/*  59 */   private static final Log LOG = LogFactory.getLog(MultiPKCS11Store.class);
/*     */   
/*  61 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*     */   
/*     */ 
/*     */ 
/*  65 */   private ArrayList<IModuleData> providers = null;
/*     */   
/*  67 */   private IPassStoreKS passHandler = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected class InternCallbackHandlerProtection
/*     */     implements CallbackHandler
/*     */   {
/*     */     private IPassStoreKS passHandler;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public InternCallbackHandlerProtection(IPassStoreKS passwordHandler)
/*     */     {
/*  82 */       this.passHandler = passwordHandler;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void handle(Callback[] callbacks)
/*     */       throws IOException, UnsupportedCallbackException
/*     */     {
/*  93 */       for (int i = 0; i < callbacks.length; i++) {
/*  94 */         if ((this.passHandler != null) && 
/*  95 */           ((callbacks[i] instanceof PasswordCallback))) {
/*  96 */           PasswordCallback pc = (PasswordCallback)callbacks[i];
/*  97 */           pc.setPassword(this.passHandler.getPassword(null, pc.getPrompt()));
/*     */         } else {
/*  99 */           throw new UnsupportedCallbackException(callbacks[i], MultiPKCS11Store.I18N.getLocalMessage("i18n.mityc.cert.p11.3"));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MultiPKCS11Store(ConfigMultiPKCS11 config, IPassStoreKS passwordHandler)
/*     */   {
/* 114 */     this.passHandler = passwordHandler;
/* 115 */     this.providers = new ArrayList();
/*     */     
/* 117 */     if (config != null) {
/* 118 */       List<IModuleData> list = config.getProviders();
/* 119 */       if (list != null) {
/* 120 */         Iterator<IModuleData> itProvider = list.iterator();
/* 121 */         while (itProvider.hasNext()) {
/* 122 */           IModuleData pd = (IModuleData)itProvider.next();
/* 123 */           this.providers.add(pd);
/* 124 */           if (LOG.isTraceEnabled()) {
/* 125 */             LOG.trace(I18N.getLocalMessage("i18n.mityc.cert.p11.9", new Object[] { pd.getName() }));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void updateModules()
/*     */   {
/* 136 */     Iterator<IModuleData> itProv = this.providers.iterator();
/* 137 */     while (itProv.hasNext()) {
/* 138 */       IModuleData providerData = (IModuleData)itProv.next();
/* 139 */       if (LOG.isTraceEnabled()) {
/* 140 */         LOG.trace(I18N.getLocalMessage("i18n.mityc.cert.p11.10", new Object[] { providerData.getName() }));
/*     */       }
/* 142 */       providerData.updateModule();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CertPath getCertPath(X509Certificate certificate)
/*     */     throws CertStoreException
/*     */   {
/* 155 */     throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.p11.6"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PrivateKey getPrivateKey(X509Certificate certificate)
/*     */     throws CertStoreException
/*     */   {
/* 166 */     if ((certificate instanceof P11CertificateProxy)) {
/* 167 */       Provider provider = ((P11CertificateProxy)certificate).getProvider();
/*     */       try {
/* 169 */         KeyStore.LoadStoreParameter passwordHnd = new KeyStore.LoadStoreParameter() {
/*     */           public KeyStore.ProtectionParameter getProtectionParameter() {
/* 171 */             return new KeyStore.CallbackHandlerProtection(new MultiPKCS11Store.InternCallbackHandlerProtection(MultiPKCS11Store.this, MultiPKCS11Store.this.passHandler));
/*     */           }
/* 173 */         };
/* 174 */         KeyStore ks = KeyStore.getInstance("PKCS11", provider);
/* 175 */         ks.load(passwordHnd);
/* 176 */         String alias = ks.getCertificateAlias(((P11CertificateProxy)certificate).getInternalCertificate());
/* 177 */         if (ks.entryInstanceOf(alias, KeyStore.PrivateKeyEntry.class)) {
/* 178 */           KeyStore.PrivateKeyEntry pkEntry = (KeyStore.PrivateKeyEntry)ks.getEntry(alias, new KeyStore.CallbackHandlerProtection(new InternCallbackHandlerProtection(this.passHandler)));
/* 179 */           if (pkEntry != null)
/*     */           {
/* 181 */             return pkEntry.getPrivateKey();
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (KeyStoreException localKeyStoreException) {}catch (CertificateException localCertificateException) {}catch (NoSuchAlgorithmException localNoSuchAlgorithmException) {}catch (IOException localIOException) {}catch (UnrecoverableEntryException localUnrecoverableEntryException) {}
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 190 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.p11.5"));
/*     */     }
/* 192 */     throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.p11.4"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Provider getProvider(X509Certificate cert)
/*     */   {
/* 203 */     Provider prov = null;
/* 204 */     if ((cert instanceof P11CertificateProxy)) {
/* 205 */       prov = ((P11CertificateProxy)cert).getProvider();
/*     */     }
/* 207 */     return prov;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<X509Certificate> getSignCertificates()
/*     */     throws CertStoreException
/*     */   {
/* 217 */     ArrayList<X509Certificate> certificates = new ArrayList();
/* 218 */     updateModules();
/* 219 */     Iterator<IModuleData> itProvData = this.providers.iterator();
/* 220 */     Iterator<IProviderData> itProvider; for (; itProvData.hasNext(); 
/*     */         
/*     */ 
/* 223 */         itProvider.hasNext())
/*     */     {
/* 221 */       IModuleData providerData = (IModuleData)itProvData.next();
/* 222 */       itProvider = providerData.getProvidersData().iterator();
/* 223 */       continue;
/* 224 */       IProviderData provider = (IProviderData)itProvider.next();
/*     */       try {
/* 226 */         KeyStore.LoadStoreParameter passwordHnd = new KeyStore.LoadStoreParameter() {
/*     */           public KeyStore.ProtectionParameter getProtectionParameter() {
/* 228 */             return new KeyStore.CallbackHandlerProtection(new MultiPKCS11Store.InternCallbackHandlerProtection(MultiPKCS11Store.this, MultiPKCS11Store.this.passHandler));
/*     */           }
/* 230 */         };
/* 231 */         KeyStore ks = KeyStore.getInstance(provider.getKeyStoreTypeName(), provider.getProvider());
/* 232 */         ks.load(passwordHnd);
/* 233 */         Enumeration<String> aliases = ks.aliases();
/* 234 */         while (aliases.hasMoreElements()) {
/* 235 */           String alias = (String)aliases.nextElement();
/* 236 */           if (ks.entryInstanceOf(alias, KeyStore.PrivateKeyEntry.class)) {
/* 237 */             Certificate cert = ks.getCertificate(alias);
/* 238 */             if ((cert instanceof X509Certificate)) {
/* 239 */               certificates.add(new P11CertificateProxy((X509Certificate)cert, provider.getProvider()));
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (KeyStoreException localKeyStoreException) {}catch (CertificateException localCertificateException) {}catch (NoSuchAlgorithmException localNoSuchAlgorithmException) {}catch (IOException localIOException) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 250 */     return certificates;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<X509Certificate> getTrustCertificates()
/*     */     throws CertStoreException
/*     */   {
/* 261 */     throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.p11.6"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<X509Certificate> getPublicCertificates()
/*     */     throws CertStoreException
/*     */   {
/* 273 */     throw new UnsupportedOperationException("Not implemented yet");
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\pkcs11\MultiPKCS11Store.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */