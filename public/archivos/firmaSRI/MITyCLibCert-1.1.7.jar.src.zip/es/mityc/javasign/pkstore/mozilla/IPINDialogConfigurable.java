/*    */ package es.mityc.javasign.pkstore.mozilla;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface IPINDialogConfigurable
/*    */ {
/*    */   public abstract void setTitle(String paramString);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract void setPINMessage(String paramString);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract void setMessagesMode(MESSAGES_MODE paramMESSAGES_MODE);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static enum MESSAGES_MODE
/*    */   {
/* 27 */     AUTO,  AUTO_TOKEN,  EXPLICIT;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mozilla\IPINDialogConfigurable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */