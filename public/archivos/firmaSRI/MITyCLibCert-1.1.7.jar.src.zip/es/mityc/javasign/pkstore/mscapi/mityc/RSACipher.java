/*     */ package es.mityc.javasign.pkstore.mscapi.mityc;
/*     */ 
/*     */ import java.security.AlgorithmParameters;
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.KeyException;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.ProviderException;
/*     */ import java.security.PublicKey;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.spec.AlgorithmParameterSpec;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import java.security.spec.PKCS8EncodedKeySpec;
/*     */ import java.security.spec.X509EncodedKeySpec;
/*     */ import javax.crypto.BadPaddingException;
/*     */ import javax.crypto.CipherSpi;
/*     */ import javax.crypto.IllegalBlockSizeException;
/*     */ import javax.crypto.NoSuchPaddingException;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.ShortBufferException;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RSACipher
/*     */   extends CipherSpi
/*     */ {
/*  77 */   private static final byte[] B0 = new byte[0];
/*     */   
/*     */ 
/*     */   private static final int MODE_ENCRYPT = 1;
/*     */   
/*     */ 
/*     */   private static final int MODE_DECRYPT = 2;
/*     */   
/*     */   private static final int MODE_SIGN = 3;
/*     */   
/*     */   private static final int MODE_VERIFY = 4;
/*     */   
/*     */   private static final String PAD_PKCS1 = "PKCS1Padding";
/*     */   
/*     */   private static final int PAD_PKCS1_LENGTH = 11;
/*     */   
/*     */   private int mode;
/*     */   
/*     */   private String paddingType;
/*     */   
/*  97 */   private int paddingLength = 0;
/*     */   
/*     */ 
/*     */   private byte[] buffer;
/*     */   
/*     */   private int bufOfs;
/*     */   
/*     */   private int outputSize;
/*     */   
/*     */   private Key publicKey;
/*     */   
/*     */   private Key privateKey;
/*     */   
/*     */ 
/*     */   public RSACipher()
/*     */   {
/* 113 */     this.paddingType = "PKCS1Padding";
/*     */   }
/*     */   
/*     */ 
/*     */   protected void engineSetMode(String mode)
/*     */     throws NoSuchAlgorithmException
/*     */   {
/* 120 */     if (!mode.equalsIgnoreCase("ECB")) {
/* 121 */       throw new NoSuchAlgorithmException("Unsupported mode " + mode);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void engineSetPadding(String paddingName)
/*     */     throws NoSuchPaddingException
/*     */   {
/* 130 */     if (paddingName.equalsIgnoreCase("PKCS1Padding")) {
/* 131 */       this.paddingType = "PKCS1Padding";
/*     */     } else {
/* 133 */       throw new NoSuchPaddingException(
/* 134 */         "Padding " + paddingName + " not supported");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected int engineGetBlockSize()
/*     */   {
/* 142 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected int engineGetOutputSize(int inputLen)
/*     */   {
/* 149 */     return this.outputSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected byte[] engineGetIV()
/*     */   {
/* 156 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected AlgorithmParameters engineGetParameters()
/*     */   {
/* 163 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void engineInit(int opmode, java.security.Key key, SecureRandom random)
/*     */     throws InvalidKeyException
/*     */   {
/* 170 */     init(opmode, key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineInit(int opmode, java.security.Key key, AlgorithmParameterSpec params, SecureRandom random)
/*     */     throws InvalidKeyException, InvalidAlgorithmParameterException
/*     */   {
/* 179 */     if (params != null) {
/* 180 */       throw new InvalidAlgorithmParameterException(
/* 181 */         "Parameters not supported");
/*     */     }
/* 183 */     init(opmode, key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineInit(int opmode, java.security.Key key, AlgorithmParameters params, SecureRandom random)
/*     */     throws InvalidKeyException, InvalidAlgorithmParameterException
/*     */   {
/* 192 */     if (params != null) {
/* 193 */       throw new InvalidAlgorithmParameterException(
/* 194 */         "Parameters not supported");
/*     */     }
/* 196 */     init(opmode, key);
/*     */   }
/*     */   
/*     */   private void init(int opmode, java.security.Key key)
/*     */     throws InvalidKeyException
/*     */   {
/*     */     boolean encrypt;
/*     */     boolean encrypt;
/* 204 */     switch (opmode) {
/*     */     case 1: 
/*     */     case 3: 
/* 207 */       this.paddingLength = 11;
/* 208 */       encrypt = true;
/* 209 */       break;
/*     */     case 2: 
/*     */     case 4: 
/* 212 */       this.paddingLength = 0;
/* 213 */       encrypt = false;
/* 214 */       break;
/*     */     default: 
/* 216 */       throw new InvalidKeyException("Unknown mode: " + opmode); }
/*     */     boolean encrypt;
/* 218 */     if (!(key instanceof Key)) {
/* 219 */       throw new InvalidKeyException("Unsupported key type: " + key);
/*     */     }
/*     */     
/* 222 */     if ((key instanceof PublicKey)) {
/* 223 */       this.mode = (encrypt ? 1 : 4);
/* 224 */       this.publicKey = ((Key)key);
/* 225 */       this.privateKey = null;
/* 226 */       this.outputSize = (this.publicKey.bitLength() / 8);
/* 227 */     } else if ((key instanceof PrivateKey)) {
/* 228 */       this.mode = (encrypt ? 3 : 2);
/* 229 */       this.privateKey = ((Key)key);
/* 230 */       this.publicKey = null;
/* 231 */       this.outputSize = (this.privateKey.bitLength() / 8);
/*     */     } else {
/* 233 */       throw new InvalidKeyException("Unknown key type: " + key);
/*     */     }
/*     */     
/* 236 */     this.bufOfs = 0;
/* 237 */     this.buffer = new byte[this.outputSize];
/*     */   }
/*     */   
/*     */   private void update(byte[] in, int inOfs, int inLen)
/*     */   {
/* 242 */     if ((inLen == 0) || (in == null)) {
/* 243 */       return;
/*     */     }
/* 245 */     if (this.bufOfs + inLen > this.buffer.length - this.paddingLength) {
/* 246 */       this.bufOfs = (this.buffer.length + 1);
/* 247 */       return;
/*     */     }
/* 249 */     System.arraycopy(in, inOfs, this.buffer, this.bufOfs, inLen);
/* 250 */     this.bufOfs += inLen;
/*     */   }
/*     */   
/*     */   private byte[] doFinal()
/*     */     throws BadPaddingException, IllegalBlockSizeException
/*     */   {
/* 256 */     if (this.bufOfs > this.buffer.length) {
/* 257 */       throw new IllegalBlockSizeException("Data must not be longer than " + (
/* 258 */         this.buffer.length - this.paddingLength) + " bytes");
/*     */     }
/*     */     try
/*     */     {
/* 262 */       byte[] data = this.buffer;
/* 263 */       byte[] arrayOfByte1; switch (this.mode) {
/*     */       case 3: 
/* 265 */         return encryptDecrypt(data, this.bufOfs, 
/* 266 */           this.privateKey.getHCryptKey(), true);
/*     */       
/*     */       case 4: 
/* 269 */         return encryptDecrypt(data, this.bufOfs, 
/* 270 */           this.publicKey.getHCryptKey(), false);
/*     */       
/*     */       case 1: 
/* 273 */         return encryptDecrypt(data, this.bufOfs, 
/* 274 */           this.publicKey.getHCryptKey(), true);
/*     */       
/*     */       case 2: 
/* 277 */         return encryptDecrypt(data, this.bufOfs, 
/* 278 */           this.privateKey.getHCryptKey(), false);
/*     */       }
/*     */       
/* 281 */       throw new AssertionError("Internal error");
/*     */     }
/*     */     catch (KeyException e)
/*     */     {
/* 285 */       throw new ProviderException(e);
/*     */     }
/*     */     finally {
/* 288 */       this.bufOfs = 0;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected byte[] engineUpdate(byte[] in, int inOfs, int inLen)
/*     */   {
/* 295 */     update(in, inOfs, inLen);
/* 296 */     return B0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected int engineUpdate(byte[] in, int inOfs, int inLen, byte[] out, int outOfs)
/*     */   {
/* 303 */     update(in, inOfs, inLen);
/* 304 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */   protected byte[] engineDoFinal(byte[] in, int inOfs, int inLen)
/*     */     throws BadPaddingException, IllegalBlockSizeException
/*     */   {
/* 311 */     update(in, inOfs, inLen);
/* 312 */     return doFinal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected int engineDoFinal(byte[] in, int inOfs, int inLen, byte[] out, int outOfs)
/*     */     throws ShortBufferException, BadPaddingException, IllegalBlockSizeException
/*     */   {
/* 320 */     if (this.outputSize > out.length - outOfs) {
/* 321 */       throw new ShortBufferException(
/* 322 */         "Need " + this.outputSize + " bytes for output");
/*     */     }
/* 324 */     update(in, inOfs, inLen);
/* 325 */     byte[] result = doFinal();
/* 326 */     int n = result.length;
/* 327 */     System.arraycopy(result, 0, out, outOfs, n);
/* 328 */     return n;
/*     */   }
/*     */   
/*     */ 
/*     */   protected byte[] engineWrap(java.security.Key key)
/*     */     throws InvalidKeyException, IllegalBlockSizeException
/*     */   {
/* 335 */     byte[] encoded = key.getEncoded();
/* 336 */     if ((encoded == null) || (encoded.length == 0)) {
/* 337 */       throw new InvalidKeyException("Could not obtain encoded key");
/*     */     }
/* 339 */     if (encoded.length > this.buffer.length) {
/* 340 */       throw new InvalidKeyException("Key is too long for wrapping");
/*     */     }
/* 342 */     update(encoded, 0, encoded.length);
/*     */     try {
/* 344 */       return doFinal();
/*     */     }
/*     */     catch (BadPaddingException e) {
/* 347 */       throw new InvalidKeyException("Wrapping failed", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected java.security.Key engineUnwrap(byte[] wrappedKey, String algorithm, int type)
/*     */     throws InvalidKeyException, NoSuchAlgorithmException
/*     */   {
/* 356 */     if (wrappedKey.length > this.buffer.length) {
/* 357 */       throw new InvalidKeyException("Key is too long for unwrapping");
/*     */     }
/* 359 */     update(wrappedKey, 0, wrappedKey.length);
/*     */     try
/*     */     {
/* 362 */       byte[] encoding = doFinal();
/*     */       
/* 364 */       switch (type) {
/*     */       case 1: 
/* 366 */         return constructPublicKey(encoding, algorithm);
/*     */       
/*     */       case 2: 
/* 369 */         return constructPrivateKey(encoding, algorithm);
/*     */       
/*     */       case 3: 
/* 372 */         return constructSecretKey(encoding, algorithm);
/*     */       }
/*     */       
/* 375 */       throw new InvalidKeyException("Unknown key type " + type);
/*     */ 
/*     */     }
/*     */     catch (BadPaddingException e)
/*     */     {
/* 380 */       throw new InvalidKeyException("Unwrapping failed", e);
/*     */     }
/*     */     catch (IllegalBlockSizeException e)
/*     */     {
/* 384 */       throw new InvalidKeyException("Unwrapping failed", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected int engineGetKeySize(java.security.Key key)
/*     */     throws InvalidKeyException
/*     */   {
/* 392 */     if ((key instanceof Key)) {
/* 393 */       return ((Key)key).bitLength();
/*     */     }
/* 395 */     throw new InvalidKeyException("Unsupported key type: " + key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static PublicKey constructPublicKey(byte[] encodedKey, String encodedKeyAlgorithm)
/*     */     throws InvalidKeyException, NoSuchAlgorithmException
/*     */   {
/*     */     try
/*     */     {
/* 405 */       KeyFactory keyFactory = KeyFactory.getInstance(encodedKeyAlgorithm);
/* 406 */       X509EncodedKeySpec keySpec = new X509EncodedKeySpec(encodedKey);
/*     */       
/* 408 */       return keyFactory.generatePublic(keySpec);
/*     */     }
/*     */     catch (NoSuchAlgorithmException nsae) {
/* 411 */       throw new NoSuchAlgorithmException("No installed provider supports the " + 
/* 412 */         encodedKeyAlgorithm + " algorithm", nsae);
/*     */     }
/*     */     catch (InvalidKeySpecException ike) {
/* 415 */       throw new InvalidKeyException("Cannot construct public key", ike);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static PrivateKey constructPrivateKey(byte[] encodedKey, String encodedKeyAlgorithm)
/*     */     throws InvalidKeyException, NoSuchAlgorithmException
/*     */   {
/*     */     try
/*     */     {
/* 425 */       KeyFactory keyFactory = KeyFactory.getInstance(encodedKeyAlgorithm);
/* 426 */       PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(encodedKey);
/*     */       
/* 428 */       return keyFactory.generatePrivate(keySpec);
/*     */     }
/*     */     catch (NoSuchAlgorithmException nsae) {
/* 431 */       throw new NoSuchAlgorithmException("No installed provider supports the " + 
/* 432 */         encodedKeyAlgorithm + " algorithm", nsae);
/*     */     }
/*     */     catch (InvalidKeySpecException ike) {
/* 435 */       throw new InvalidKeyException("Cannot construct private key", ike);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static SecretKey constructSecretKey(byte[] encodedKey, String encodedKeyAlgorithm)
/*     */   {
/* 443 */     return new SecretKeySpec(encodedKey, encodedKeyAlgorithm);
/*     */   }
/*     */   
/*     */   private static native byte[] encryptDecrypt(byte[] paramArrayOfByte, int paramInt, long paramLong, boolean paramBoolean)
/*     */     throws KeyException;
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mscapi\mityc\RSACipher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */