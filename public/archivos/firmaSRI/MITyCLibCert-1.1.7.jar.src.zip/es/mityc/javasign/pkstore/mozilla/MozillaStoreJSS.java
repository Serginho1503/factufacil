/*     */ package es.mityc.javasign.pkstore.mozilla;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.pkstore.CertStoreException;
/*     */ import es.mityc.javasign.pkstore.IPKStoreManager;
/*     */ import java.math.BigInteger;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.Principal;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.Provider;
/*     */ import java.security.cert.CertPath;
/*     */ import java.security.cert.CertificateEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.mozilla.jss.CertDatabaseException;
/*     */ import org.mozilla.jss.CryptoManager;
/*     */ import org.mozilla.jss.CryptoManager.InitializationValues;
/*     */ import org.mozilla.jss.CryptoManager.NotInitializedException;
/*     */ import org.mozilla.jss.JSSProvider;
/*     */ import org.mozilla.jss.KeyDatabaseException;
/*     */ import org.mozilla.jss.asn1.INTEGER;
/*     */ import org.mozilla.jss.crypto.AlreadyInitializedException;
/*     */ import org.mozilla.jss.crypto.CryptoStore;
/*     */ import org.mozilla.jss.crypto.CryptoToken;
/*     */ import org.mozilla.jss.crypto.ObjectNotFoundException;
/*     */ import org.mozilla.jss.crypto.TokenException;
/*     */ import org.mozilla.jss.pkcs11.PK11Module;
/*     */ import org.mozilla.jss.pkcs11.PK11Token;
/*     */ import org.mozilla.jss.util.IncorrectPasswordException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MozillaStoreJSS
/*     */   implements IPKStoreManager
/*     */ {
/*  61 */   private static final Log LOG = LogFactory.getLog(MozillaStoreJSS.class);
/*     */   
/*  63 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*     */   
/*     */ 
/*     */   private static final String STR_FIX_JSS_BUILT_IN = "Builtin Object Token";
/*     */   
/*  68 */   private MozillaTokenLoginModeEnum loginMode = MozillaTokenLoginModeEnum.getDefault();
/*     */   
/*  70 */   private int loginTimeoutMinutes = 5;
/*     */   
/*     */ 
/*  73 */   private static CryptoManager cm = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public MozillaStoreJSS(String profile)
/*     */     throws CertStoreException
/*     */   {
/*  80 */     this(profile, MozillaStoreUtils.LIB_MODE.ONLY_JSS);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MozillaStoreJSS(String profile, MozillaStoreUtils.LIB_MODE mode)
/*     */     throws CertStoreException
/*     */   {
/*  89 */     if (cm == null) {
/*  90 */       initialize(profile, mode);
/*     */     }
/*     */   }
/*     */   
/*     */   public CertPath getCertPath(java.security.cert.X509Certificate certificate)
/*     */     throws CertStoreException
/*     */   {
/*  97 */     throw new UnsupportedOperationException("Not implemented yet");
/*     */   }
/*     */   
/*     */ 
/*     */   public PrivateKey getPrivateKey(java.security.cert.X509Certificate certificate)
/*     */     throws CertStoreException
/*     */   {
/* 104 */     byte[] certIssuerName = null;
/* 105 */     INTEGER serialNumber = null;
/*     */     try {
/* 107 */       if (LOG.isDebugEnabled()) {
/* 108 */         LOG.debug("Cargando JSS con el manager ");
/* 109 */         LOG.debug(cm != null ? cm.getClass() : "Nulo");
/*     */       }
/* 111 */       certIssuerName = certificate.getIssuerX500Principal().getEncoded();
/* 112 */       serialNumber = new INTEGER(certificate.getSerialNumber());
/* 113 */       if (LOG.isDebugEnabled()) {
/* 114 */         LOG.debug("Buscando en el almacén el certificado expedido por " + new String(certIssuerName) + " y serial " + serialNumber);
/*     */       }
/* 116 */       org.mozilla.jss.crypto.X509Certificate certJSS = cm.findCertByIssuerAndSerialNumber(certIssuerName, serialNumber);
/* 117 */       if (LOG.isDebugEnabled()) {
/* 118 */         LOG.debug("Certificado encontrado en el almacén: " + certJSS.getSubjectDN());
/*     */       }
/*     */       
/* 121 */       PrivateKey pk = cm.findPrivKeyByCert(certJSS);
/* 122 */       if (LOG.isDebugEnabled()) {
/* 123 */         LOG.debug("Clave privada asociada encontrada:" + pk != null ? pk.toString() : "No encontrada");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 128 */       String certIssuer = certificate.getIssuerDN().getName().replaceAll(" ", "");
/* 129 */       Enumeration<?> enModules = cm.getModules();
/* 130 */       boolean modulesHasMore = enModules.hasMoreElements();
/* 131 */       boolean tokHasMore; for (; modulesHasMore; 
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 139 */           tokHasMore)
/*     */       {
/* 132 */         PK11Module module = (PK11Module)enModules.nextElement();
/* 133 */         if (LOG.isTraceEnabled()) {
/* 134 */           LOG.trace("Modulo: " + module.getName());
/*     */         }
/* 136 */         modulesHasMore = enModules.hasMoreElements();
/* 137 */         Enumeration<?> enTok = module.getTokens();
/* 138 */         tokHasMore = enTok.hasMoreElements();
/* 139 */         continue;
/* 140 */         PK11Token token = (PK11Token)enTok.nextElement();
/* 141 */         if (LOG.isTraceEnabled()) {
/* 142 */           LOG.trace("Token: " + token.getName());
/*     */         }
/* 144 */         tokHasMore = enTok.hasMoreElements();
/*     */         try
/*     */         {
/* 147 */           CryptoStore store = token.getCryptoStore();
/* 148 */           org.mozilla.jss.crypto.X509Certificate[] certs = store.getCertificates();
/* 149 */           org.mozilla.jss.crypto.X509Certificate[] arrayOfX509Certificate1; int j = (arrayOfX509Certificate1 = certs).length; for (int i = 0; i < j; i++) { org.mozilla.jss.crypto.X509Certificate current = arrayOfX509Certificate1[i];
/* 150 */             String currentIssuer = current.getIssuerDN().getName().replaceAll(" ", "");
/* 151 */             if ((currentIssuer.equals(certIssuer)) && 
/* 152 */               (current.getSerialNumber().equals(certificate.getSerialNumber()))) {
/* 153 */               if (LOG.isTraceEnabled()) {
/* 154 */                 LOG.trace("Se ha encontrado coincidencia en el token " + token.getName());
/*     */               }
/* 156 */               cm.setThreadToken(cm.getTokenByName(token.getName()));
/* 157 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */         catch (Exception e) {
/* 162 */           if (LOG.isTraceEnabled()) {
/* 163 */             LOG.error(e);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 170 */       return pk;
/*     */     } catch (Exception ex) {
/* 172 */       if (LOG.isDebugEnabled()) {
/* 173 */         LOG.debug("Error al acceder al token criptográfico. Reintentando logarse", ex);
/*     */       }
/*     */       
/*     */       try
/*     */       {
/* 178 */         if (LOG.isTraceEnabled()) {
/* 179 */           LOG.trace("Procesando modulos");
/*     */         }
/* 181 */         Enumeration<?> enModules = cm.getModules();
/* 182 */         boolean modulesHasMore = enModules.hasMoreElements();
/* 183 */         boolean tokHasMore; for (; modulesHasMore; 
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 192 */             tokHasMore)
/*     */         {
/* 184 */           if (LOG.isTraceEnabled()) {
/* 185 */             LOG.trace("Procesando modulo PK11 de mozilla");
/*     */           }
/* 187 */           PK11Module module = (PK11Module)enModules.nextElement();
/* 188 */           modulesHasMore = enModules.hasMoreElements();
/* 189 */           module.reloadTokens();
/* 190 */           Enumeration<?> enTok = module.getTokens();
/* 191 */           tokHasMore = enTok.hasMoreElements();
/* 192 */           continue;
/* 193 */           if (LOG.isTraceEnabled()) {
/* 194 */             LOG.trace("Procesando token");
/*     */           }
/* 196 */           PK11Token token = (PK11Token)enTok.nextElement();
/* 197 */           if (LOG.isTraceEnabled()) {
/* 198 */             LOG.trace("Token: " + token.getName());
/*     */           }
/* 200 */           tokHasMore = enTok.hasMoreElements();
/*     */           
/*     */ 
/* 203 */           if (!"Builtin Object Token".equals(token.getName()))
/*     */           {
/*     */ 
/*     */ 
/* 207 */             if ((!token.isInternalCryptoToken()) && (!token.isInternalKeyStorageToken())) {
/* 208 */               if (LOG.isTraceEnabled()) {
/* 209 */                 LOG.trace("Procesando token externo");
/*     */               }
/* 211 */               if (token.isPresent()) {
/* 212 */                 if (token.isLoggedIn()) {
/* 213 */                   token.logout();
/*     */                 }
/* 215 */                 if (LOG.isTraceEnabled()) {
/* 216 */                   LOG.trace("Loggin de token...");
/*     */                 }
/* 218 */                 int tries = 0;
/* 219 */                 while (tries < 3) {
/*     */                   try {
/* 221 */                     token.setLoginMode(this.loginMode.getInteger());
/* 222 */                     if (this.loginMode == MozillaTokenLoginModeEnum.TIMEOUT) {
/* 223 */                       token.setLoginTimeoutMinutes(this.loginTimeoutMinutes);
/*     */                     }
/* 225 */                     token.login(MozillaStoreUtils.getPassHandler(IPINDialogConfigurable.MESSAGES_MODE.AUTO_TOKEN, null, I18N.getLocalMessage("i18n.mityc.cert.mozilla.8")));
/* 226 */                     tries += 3;
/* 227 */                     if (LOG.isTraceEnabled()) {
/* 228 */                       LOG.trace("Loggin de token correcto!");
/*     */                     }
/*     */                   } catch (IncorrectPasswordException ex2) {
/* 231 */                     LOG.info(I18N.getLocalMessage("i18n.mityc.cert.mozilla.6"));
/* 232 */                     tries++;
/*     */                   } catch (TokenException ex2) {
/* 234 */                     LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.7", new Object[] { token.getName() }), ex2);
/* 235 */                     tries++;
/*     */                   }
/*     */                 }
/*     */               }
/* 239 */               if (token.isLoggedIn()) {
/* 240 */                 if (LOG.isTraceEnabled()) {
/* 241 */                   LOG.trace("Accediendo a token...");
/*     */                 }
/* 243 */                 CryptoStore store = token.getCryptoStore();
/*     */                 
/* 245 */                 org.mozilla.jss.crypto.X509Certificate[] certs = store.getCertificates();
/* 246 */                 org.mozilla.jss.crypto.X509Certificate certCandidato = null;
/* 247 */                 boolean isFound = false;
/* 248 */                 for (int i = 0; i < certs.length; i++) {
/* 249 */                   certCandidato = certs[i];
/* 250 */                   if (LOG.isTraceEnabled()) {
/* 251 */                     LOG.trace("Certificado candidato: " + certCandidato.getNickname());
/*     */                   }
/*     */                   try {
/* 254 */                     if (new String(certCandidato.getEncoded()).equals(new String(certificate.getEncoded()))) {
/* 255 */                       if (LOG.isDebugEnabled()) {
/* 256 */                         LOG.debug("Correspondencia encontrada");
/*     */                       }
/* 258 */                       isFound = true;
/*     */                     }
/*     */                   }
/*     */                   catch (CertificateEncodingException e) {
/* 262 */                     LOG.error("No se pudo recuperar el certificado:" + certCandidato.getNickname());
/*     */                   }
/*     */                 }
/*     */                 
/*     */ 
/* 267 */                 if (!isFound) {
/* 268 */                   if (LOG.isDebugEnabled()) {
/* 269 */                     LOG.debug("No se han encontrado correspondencias en este token. Se continua");
/*     */                   }
/*     */                 }
/*     */                 else
/*     */                 {
/* 274 */                   org.mozilla.jss.crypto.X509Certificate certJSS = cm.findCertByIssuerAndSerialNumber(certIssuerName, serialNumber);
/* 275 */                   if (LOG.isDebugEnabled()) {
/* 276 */                     LOG.debug("Certificado encontrado en el almacén: " + certJSS.getSubjectDN());
/*     */                   }
/* 278 */                   Object pk = cm.findPrivKeyByCert(certJSS);
/* 279 */                   if (LOG.isDebugEnabled()) {
/* 280 */                     LOG.debug("Clave privada asociada encontrada:" + pk != null ? pk.toString() : "No encontrada");
/*     */                   }
/* 282 */                   return (PrivateKey)pk;
/*     */                 }
/*     */               }
/*     */             } }
/*     */         }
/* 287 */         if (LOG.isDebugEnabled()) {
/* 288 */           LOG.debug("Modulos procesados sin encontrar correspondencia");
/*     */         }
/* 290 */         throw new CertStoreException("No se encuentra la clave privada", ex);
/*     */       }
/*     */       catch (SecurityException ex1) {
/* 293 */         LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.9"), ex1);
/* 294 */         throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mozilla.9"), ex1);
/*     */       } catch (TokenException ex1) {
/* 296 */         LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.9"), ex1);
/* 297 */         throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mozilla.9"), ex1);
/*     */       } catch (ObjectNotFoundException ex1) {
/* 299 */         if (LOG.isDebugEnabled()) {
/* 300 */           LOG.debug("Error al buscar la clave privada", ex);
/*     */         }
/* 302 */         throw new CertStoreException(ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Provider getProvider(java.security.cert.X509Certificate cert)
/*     */   {
/* 313 */     return new JSSProvider();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<java.security.cert.X509Certificate> getSignCertificates()
/*     */     throws CertStoreException
/*     */   {
/* 321 */     return getCertificates(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<java.security.cert.X509Certificate> getPublicCertificates()
/*     */     throws CertStoreException
/*     */   {
/* 329 */     return getCertificates(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<java.security.cert.X509Certificate> getCertificates(boolean getPrivates)
/*     */     throws CertStoreException
/*     */   {
/* 341 */     if (cm == null) {
/* 342 */       LOG.error("No se ha cargado el módulo CSP para Mozilla");
/* 343 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mozilla.9"));
/*     */     }
/*     */     
/* 346 */     ArrayList<java.security.cert.X509Certificate> allCertsPublic = new ArrayList();
/* 347 */     ArrayList<java.security.cert.X509Certificate> allCertsPrivate = new ArrayList();
/*     */     try
/*     */     {
/* 350 */       if (LOG.isTraceEnabled()) {
/* 351 */         LOG.trace("Procesando modulos");
/*     */       }
/* 353 */       Enumeration<?> enModules = cm.getModules();
/* 354 */       boolean modulesHasMore = enModules.hasMoreElements();
/* 355 */       while (modulesHasMore) {
/* 356 */         if (LOG.isTraceEnabled()) {
/* 357 */           LOG.trace("Procesando modulo PK11 de mozilla");
/*     */         }
/* 359 */         PK11Module module = (PK11Module)enModules.nextElement();
/* 360 */         if (LOG.isTraceEnabled()) {
/* 361 */           LOG.trace("Modulo: " + module.getName());
/*     */         }
/* 363 */         modulesHasMore = enModules.hasMoreElements();
/* 364 */         if (LOG.isTraceEnabled()) {
/* 365 */           LOG.trace("Recargando tokens");
/*     */         }
/* 367 */         module.reloadTokens();
/* 368 */         if (LOG.isTraceEnabled()) {
/* 369 */           LOG.trace("Tokens recargados");
/*     */         }
/* 371 */         Enumeration<?> enTok = module.getTokens();
/* 372 */         if (LOG.isTraceEnabled()) {
/* 373 */           LOG.trace("Tokens del módulo obtenidos: " + enTok.hasMoreElements());
/*     */         }
/* 375 */         boolean tokHasMore = enTok.hasMoreElements();
/* 376 */         while (tokHasMore) {
/* 377 */           if (LOG.isTraceEnabled()) {
/* 378 */             LOG.trace("Procesando token");
/*     */           }
/* 380 */           PK11Token token = (PK11Token)enTok.nextElement();
/* 381 */           if (LOG.isTraceEnabled()) {
/* 382 */             LOG.trace("Token: " + token.getName());
/*     */           }
/* 384 */           tokHasMore = enTok.hasMoreElements();
/*     */           
/*     */ 
/* 387 */           if (!"Builtin Object Token".equals(token.getName()))
/*     */           {
/*     */ 
/*     */ 
/* 391 */             if ((!token.isInternalCryptoToken()) && (!token.isInternalKeyStorageToken())) {
/* 392 */               if (LOG.isTraceEnabled()) {
/* 393 */                 LOG.trace("Procesando token externo");
/*     */               }
/* 395 */               if (token.isPresent()) {
/* 396 */                 if (token.isLoggedIn())
/*     */                 {
/* 398 */                   boolean doLogout = this.loginMode != MozillaTokenLoginModeEnum.getLoginMode(token.getLoginMode());
/* 399 */                   if ((!doLogout) && (this.loginMode == MozillaTokenLoginModeEnum.TIMEOUT)) {
/* 400 */                     doLogout = this.loginTimeoutMinutes != token.getLoginTimeoutMinutes();
/*     */                   }
/*     */                   
/*     */ 
/* 404 */                   if (doLogout) {
/* 405 */                     token.logout();
/*     */                   }
/*     */                 }
/* 408 */                 if (!token.isLoggedIn()) {
/* 409 */                   if (LOG.isTraceEnabled()) {
/* 410 */                     LOG.trace("Loggin de token...");
/*     */                   }
/* 412 */                   int tries = 0;
/* 413 */                   while (tries < 3) {
/*     */                     try {
/* 415 */                       token.setLoginMode(this.loginMode.getInteger());
/* 416 */                       if (this.loginMode == MozillaTokenLoginModeEnum.TIMEOUT) {
/* 417 */                         token.setLoginTimeoutMinutes(this.loginTimeoutMinutes);
/*     */                       }
/* 419 */                       token.login(MozillaStoreUtils.getPassHandler(IPINDialogConfigurable.MESSAGES_MODE.AUTO_TOKEN, null, I18N.getLocalMessage("i18n.mityc.cert.mozilla.8")));
/* 420 */                       tries += 3;
/* 421 */                       if (LOG.isTraceEnabled()) {
/* 422 */                         LOG.trace("Loggin de token correcto!");
/*     */                       }
/* 424 */                       cm.setThreadToken(token);
/*     */                     } catch (IncorrectPasswordException ex) {
/* 426 */                       LOG.info(I18N.getLocalMessage("i18n.mityc.cert.mozilla.6"));
/* 427 */                       tries++;
/*     */                     } catch (TokenException ex) {
/* 429 */                       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.7", new Object[] { token.getName() }), ex);
/* 430 */                       tries++;
/*     */                     }
/*     */                   }
/*     */                 }
/* 434 */                 if (token.isLoggedIn()) {
/* 435 */                   if (LOG.isTraceEnabled()) {
/* 436 */                     LOG.trace("Accediendo a token...");
/*     */                   }
/* 438 */                   CryptoStore store = token.getCryptoStore();
/* 439 */                   org.mozilla.jss.crypto.X509Certificate[] certs = store.getCertificates();
/* 440 */                   for (int i = 0; i < certs.length; i++) {
/* 441 */                     java.security.cert.X509Certificate cert = MozillaStoreUtils.convert(certs[i]);
/* 442 */                     boolean[] usage = cert.getKeyUsage();
/*     */                     
/* 444 */                     if ((cert != null) && ((usage == null) || (usage[0] != 0) || (usage[1] != 0))) {
/* 445 */                       allCertsPrivate.add(cert);
/*     */                     }
/*     */                     else
/* 448 */                       allCertsPublic.add(cert);
/*     */                   }
/*     */                 }
/*     */               }
/*     */             } }
/*     */         }
/* 454 */         if (LOG.isTraceEnabled()) {
/* 455 */           LOG.trace("Modulo P11 procesado");
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 460 */       if (LOG.isTraceEnabled()) {
/* 461 */         LOG.trace("Pide certificados");
/*     */       }
/* 463 */       org.mozilla.jss.crypto.X509Certificate[] certs = cm.getInternalKeyStorageToken().getCryptoStore().getCertificates();
/* 464 */       if (LOG.isTraceEnabled()) {
/* 465 */         if (certs != null) {
/* 466 */           LOG.trace("Se han obtenido " + certs.length + " certificados");
/*     */         } else {
/* 468 */           LOG.trace("No hay certificados disponibles");
/*     */         }
/*     */       }
/*     */       
/* 472 */       for (int i = 0; i < certs.length; i++) {
/*     */         try {
/* 474 */           if (LOG.isTraceEnabled()) {
/* 475 */             LOG.trace("Buscando clave privada para: " + certs[i]);
/*     */           }
/* 477 */           if (cm.findPrivKeyByCert(certs[i]) != null) {
/* 478 */             java.security.cert.X509Certificate cert = MozillaStoreUtils.convert(certs[i]);
/* 479 */             allCertsPrivate.add(cert);
/*     */           } else {
/* 481 */             allCertsPublic.add(MozillaStoreUtils.convert(certs[i]));
/*     */           }
/*     */         } catch (ObjectNotFoundException ex) {
/* 484 */           if (LOG.isTraceEnabled()) {
/* 485 */             LOG.trace("No hay clave privada");
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (SecurityException ex) {
/* 491 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.9"), ex);
/* 492 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mozilla.9"), ex);
/*     */     }
/*     */     catch (TokenException ex) {
/* 495 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.9"), ex);
/* 496 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mozilla.9"), ex);
/*     */     }
/*     */     
/* 499 */     if (getPrivates) {
/* 500 */       return allCertsPrivate;
/*     */     }
/* 502 */     return allCertsPublic;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<java.security.cert.X509Certificate> getTrustCertificates()
/*     */     throws CertStoreException
/*     */   {
/* 511 */     throw new UnsupportedOperationException("Not implemented yet");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized void initialize(String profile, MozillaStoreUtils.LIB_MODE mode)
/*     */     throws CertStoreException
/*     */   {
/* 521 */     MozillaStoreUtils.initialize(profile, mode);
/*     */     try
/*     */     {
/* 524 */       if (LOG.isDebugEnabled()) {
/* 525 */         LOG.debug("Se levanta el proveedor JSS");
/*     */       }
/* 527 */       CryptoManager.InitializationValues iv = new CryptoManager.InitializationValues(profile);
/* 528 */       iv.installJSSProvider = false;
/* 529 */       CryptoManager.initialize(iv);
/* 530 */       cm = CryptoManager.getInstance();
/*     */     } catch (UnsatisfiedLinkError e) {
/* 532 */       LOG.debug("No se pudo cargar la instancia de la librería JSS: " + e.getMessage(), e);
/* 533 */       throw new CertStoreException(e);
/*     */     } catch (KeyDatabaseException ex) {
/* 535 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.2", new Object[] { ex.getMessage() }), ex);
/*     */     } catch (CertDatabaseException ex) {
/* 537 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.2", new Object[] { ex.getMessage() }), ex);
/*     */     }
/*     */     catch (AlreadyInitializedException localAlreadyInitializedException) {}catch (GeneralSecurityException ex) {
/* 540 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.2", new Object[] { ex.getMessage() }), ex);
/*     */     } catch (CryptoManager.NotInitializedException ex) {
/* 542 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.2", new Object[] { ex.getMessage() }), ex);
/*     */     }
/* 544 */     if (cm != null) {
/* 545 */       if (LOG.isDebugEnabled()) {
/* 546 */         LOG.debug("Capturando slot para peticiones de PIN");
/*     */       }
/* 548 */       cm.setPasswordCallback(MozillaStoreUtils.getPassHandler(IPINDialogConfigurable.MESSAGES_MODE.AUTO, null, null));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MozillaTokenLoginModeEnum getLoginMode()
/*     */   {
/* 557 */     return this.loginMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLoginMode(MozillaTokenLoginModeEnum mode)
/*     */   {
/* 565 */     this.loginMode = mode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLoginTimeoutMinutes()
/*     */   {
/* 573 */     return this.loginTimeoutMinutes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLoginTimeoutMinutes(int timeoutMinutes)
/*     */   {
/* 581 */     this.loginTimeoutMinutes = timeoutMinutes;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mozilla\MozillaStoreJSS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */