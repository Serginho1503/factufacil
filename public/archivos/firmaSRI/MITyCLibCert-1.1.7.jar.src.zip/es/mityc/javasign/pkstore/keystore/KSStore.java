/*     */ package es.mityc.javasign.pkstore.keystore;
/*     */ 
/*     */ import es.mityc.javasign.pkstore.CertStoreException;
/*     */ import es.mityc.javasign.pkstore.IPKStoreManager;
/*     */ import es.mityc.javasign.pkstore.IPassStoreKS;
/*     */ import java.security.KeyStore;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.Provider;
/*     */ import java.security.cert.CertPath;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KSStore
/*     */   implements IPKStoreManager
/*     */ {
/*     */   private KeyStore ks;
/*     */   private IPassStoreKS passHandler;
/*     */   private Provider provider;
/*  42 */   private char[] nullPassword = KeyTool.EMPTY_STRING;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KSStore(KeyStore keystore, IPassStoreKS passwordHandler)
/*     */   {
/*  51 */     this.ks = keystore;
/*  52 */     this.passHandler = passwordHandler;
/*  53 */     this.provider = keystore.getProvider();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KSStore(KeyStore keystore, IPassStoreKS passwordHandler, char[] nullpass)
/*     */   {
/*  64 */     this.ks = keystore;
/*  65 */     this.passHandler = passwordHandler;
/*  66 */     this.provider = keystore.getProvider();
/*  67 */     this.nullPassword = nullpass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KSStore(KeyStore keystore, Provider specificProvider, IPassStoreKS passwordHandler)
/*     */   {
/*  77 */     this.ks = keystore;
/*  78 */     this.passHandler = passwordHandler;
/*  79 */     this.provider = specificProvider;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KSStore(KeyStore keystore, Provider specificProvider, IPassStoreKS passwordHandler, char[] nullpass)
/*     */   {
/*  90 */     this.ks = keystore;
/*  91 */     this.passHandler = passwordHandler;
/*  92 */     this.provider = specificProvider;
/*  93 */     this.nullPassword = nullpass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CertPath getCertPath(X509Certificate certificate)
/*     */     throws CertStoreException
/*     */   {
/* 106 */     throw new UnsupportedOperationException("Not implemented yet");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PrivateKey getPrivateKey(X509Certificate certificate)
/*     */     throws CertStoreException
/*     */   {
/* 122 */     return KeyTool.findPrivateKey(this.ks, certificate, this.passHandler, this.nullPassword);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Provider getProvider(X509Certificate cert)
/*     */   {
/* 131 */     return this.provider;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<X509Certificate> getSignCertificates()
/*     */     throws CertStoreException
/*     */   {
/* 141 */     return KeyTool.getCertificatesWithKeys(this.ks);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<X509Certificate> getTrustCertificates()
/*     */     throws CertStoreException
/*     */   {
/* 151 */     return KeyTool.getTrustCertificates(this.ks);
/*     */   }
/*     */   
/*     */   public List<X509Certificate> getPublicCertificates() throws CertStoreException
/*     */   {
/* 156 */     return KeyTool.getCertificatesWithoutKeys(this.ks);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\keystore\KSStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */