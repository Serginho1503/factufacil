/*     */ package es.mityc.javasign.pkstore.mitycstore;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CertUtil
/*     */ {
/*     */   public static String extractName(X500Principal dname)
/*     */   {
/*  48 */     return extractName(dname.getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String extractName(String dname)
/*     */   {
/*  61 */     String res = null;
/*  62 */     String[] col = splitAttributes(dname);
/*  63 */     res = searchAttribute(col, "CN");
/*  64 */     if (res == null) {
/*  65 */       res = searchAttribute(col, "OU");
/*     */     }
/*  67 */     if (res == null) {
/*  68 */       res = searchAttribute(col, "O");
/*     */     }
/*  70 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String searchAttribute(String[] col, String att)
/*     */   {
/*  80 */     String res = null;
/*  81 */     String attmod = att.toLowerCase() + "=";
/*  82 */     for (int i = 0; i < col.length; i++) {
/*  83 */       if (col[i].trim().toLowerCase().startsWith(attmod)) {
/*  84 */         res = col[i].trim().substring(attmod.length());
/*  85 */         break;
/*     */       }
/*     */     }
/*  88 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String[] splitAttributes(String dname)
/*     */   {
/*  97 */     List<String> results = new ArrayList();
/*  98 */     String[] col = dname.split(",");
/*  99 */     for (int i = 0; i < col.length; i++) {
/* 100 */       String piece = col[i];
/* 101 */       while (i < col.length - 1) {
/* 102 */         if (col[(i + 1)].contains("=")) break;
/* 103 */         piece = piece + "," + col[(++i)];
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 108 */       results.add(piece);
/*     */     }
/* 110 */     return (String[])results.toArray(new String[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String convertDate(Date date)
/*     */   {
/* 119 */     DateFormat formatoFecha = DateFormat.getDateInstance(3);
/* 120 */     String fecha = formatoFecha.format(date);
/*     */     
/* 122 */     return fecha.replace("/", "-");
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mitycstore\CertUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */