/*     */ package es.mityc.javasign.pkstore.iexplorer;
/*     */ 
/*     */ import es.mityc.javasign.exception.CopyFileException;
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.utils.CopyFilesTool;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.InvalidParameterException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.PublicKey;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.SignatureException;
/*     */ import java.security.SignatureSpi;
/*     */ import java.security.cert.CertificateEncodingException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.security.spec.AlgorithmParameterSpec;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class IESignEngine
/*     */   extends SignatureSpi
/*     */ {
/*  44 */   private static final Log LOG = LogFactory.getLog(IESignEngine.class);
/*     */   
/*  46 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*     */   
/*     */ 
/*  49 */   private static IECSPJNI cspBridge = null;
/*     */   
/*  51 */   private byte[] paraFirmar = null;
/*     */   
/*  53 */   private byte[] certificadoBinario = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public IESignEngine()
/*     */   {
/*  59 */     loadLibrary();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public Object engineGetParameter(String parametro)
/*     */     throws InvalidParameterException
/*     */   {
/*  82 */     throw new InvalidParameterException(I18N.getLocalMessage("i18n.mityc.cert.ie.3"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void engineInitSign(PrivateKey clavePrivada)
/*     */     throws InvalidKeyException
/*     */   {
/*     */     try
/*     */     {
/*  95 */       this.certificadoBinario = ((PKProxyIE)clavePrivada).getCertificate().getEncoded();
/*     */     } catch (CertificateEncodingException ex) {
/*  97 */       LOG.error("Error al obtener certificado de firma en codificación DER", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void engineUpdate(byte[] b, int off, int len)
/*     */     throws SignatureException
/*     */   {
/* 112 */     byte[] copia = new byte[len];
/* 113 */     System.arraycopy(b, off, copia, 0, len);
/* 114 */     setToSign(copia);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void engineSetParameter(String param, Object value)
/*     */     throws InvalidParameterException
/*     */   {
/* 132 */     throw new InvalidParameterException(I18N.getLocalMessage("i18n.mityc.cert.ie.2"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void engineSetParameter(AlgorithmParameterSpec paramSpec)
/*     */     throws InvalidParameterException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void engineUpdate(byte b)
/*     */     throws SignatureException
/*     */   {
/* 157 */     throw new UnsupportedOperationException(I18N.getLocalMessage("i18n.mityc.cert.ie.2"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean engineVerify(byte[] firmaBytes)
/*     */     throws SignatureException
/*     */   {
/* 171 */     throw new SignatureException(I18N.getLocalMessage("i18n.mityc.cert.ie.4"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void engineInitVerify(PublicKey clavePublica)
/*     */     throws InvalidKeyException
/*     */   {
/* 185 */     throw new InvalidKeyException(I18N.getLocalMessage("i18n.mityc.cert.ie.4"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void copyLibrary()
/*     */     throws CopyFileException
/*     */   {
/* 193 */     CopyFilesTool cft = new CopyFilesTool("libs/iexplorer/MITyCLibCertJNI_iexplorer.properties", getClass().getClassLoader());
/* 194 */     cft.copyFilesOS(null, "explorer", true);
/*     */   }
/*     */   
/*     */ 
/*     */   private synchronized void loadLibrary()
/*     */   {
/*     */     try
/*     */     {
/* 202 */       if (cspBridge == null) {
/* 203 */         copyLibrary();
/* 204 */         cspBridge = new IECSPJNI();
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/* 208 */       LOG.fatal(I18N.getLocalMessage("i18n.mityc.cert.ie.1", new Object[] { ex.getMessage() }));
/* 209 */       if (LOG.isDebugEnabled()) {
/* 210 */         LOG.error(ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] engineSign()
/*     */     throws SignatureException
/*     */   {
/* 226 */     if (this.certificadoBinario == null) {
/* 227 */       throw new SignatureException(I18N.getLocalMessage("i18n.mityc.cert.ie.5"));
/*     */     }
/* 229 */     if (getToSign() == null) {
/* 230 */       throw new SignatureException(I18N.getLocalMessage("i18n.mityc.cert.ie.6"));
/*     */     }
/* 232 */     byte[] firma = cspBridge.signHash(getToSign(), this.certificadoBinario);
/* 233 */     if (firma == null) {
/* 234 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.ie.7", new Object[] { Integer.valueOf(cspBridge.getLastErrorCode()) }));
/* 235 */       throw new SignatureException(I18N.getLocalMessage("i18n.mityc.cert.ie.7", new Object[] { Integer.valueOf(cspBridge.getLastErrorCode()) }));
/*     */     }
/* 237 */     byte[] copia = new byte[firma.length];
/* 238 */     System.arraycopy(firma, 0, copia, 0, firma.length);
/* 239 */     return copia;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean engineVerify(byte[] firmaBytes, int offset, int longitud)
/*     */     throws SignatureException
/*     */   {
/* 258 */     throw new SignatureException(I18N.getLocalMessage("i18n.mityc.cert.ie.4"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineInitSign(PrivateKey clavePrivada, SecureRandom random)
/*     */     throws InvalidKeyException
/*     */   {
/* 277 */     engineInitSign(clavePrivada);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getToSign()
/*     */   {
/* 286 */     return (byte[])this.paraFirmar.clone();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setToSign(byte[] paraFirmar)
/*     */   {
/* 294 */     this.paraFirmar = ((byte[])paraFirmar.clone());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getBinaryCertificate()
/*     */   {
/* 302 */     return (byte[])this.certificadoBinario.clone();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBinaryCertificate(byte[] certificadoBinario)
/*     */   {
/* 310 */     this.certificadoBinario = ((byte[])certificadoBinario.clone());
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\iexplorer\IESignEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */