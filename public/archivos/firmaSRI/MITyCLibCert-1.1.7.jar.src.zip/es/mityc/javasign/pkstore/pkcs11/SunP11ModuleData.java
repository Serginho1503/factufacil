/*     */ package es.mityc.javasign.pkstore.pkcs11;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.Provider;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import sun.security.action.GetPropertyAction;
/*     */ import sun.security.pkcs11.SunPKCS11;
/*     */ import sun.security.pkcs11.wrapper.CK_C_INITIALIZE_ARGS;
/*     */ import sun.security.pkcs11.wrapper.CK_TOKEN_INFO;
/*     */ import sun.security.pkcs11.wrapper.PKCS11;
/*     */ import sun.security.pkcs11.wrapper.PKCS11Exception;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SunP11ModuleData
/*     */   implements IModuleData
/*     */ {
/*  53 */   private static final Log LOG = LogFactory.getLog(SunP11ModuleData.class);
/*     */   
/*  55 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String SUN_CLASS = "sun.security.pkcs11.SunPKCS11";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String CONFIG_BASE = "name={0}\r\nlibrary={1}\r\nattributes=compatibility\r\nshowInfo=true\r\nnssArgs=\"configdir='C:\\Users\\msomavilla\\AppData\\Roaming\\Mozilla\\Firefox\\Profiles\\krsd57o8.default' certPrefix='' keyPrefix='' secmod='secmod.db'\"\r\nslot={2}";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String KEYSTORE_TYPE = "PKCS11";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String PKCS11_INSTANTIATE_METHOD = "getInstance";
/*     */   
/*     */ 
/*     */   private static final String PKCS11_PARAM_JAVA6 = "C_GetFunctionList";
/*     */   
/*     */ 
/*  77 */   private static final long[] SLOTS_DEFAULT = new long[0];
/*     */   
/*     */   private static final long CKR_DEVICE_ERROR_CODE = 48L;
/*     */   
/*  81 */   private Method pkcs11MethodJ6 = null;
/*     */   
/*  83 */   private Method pkcs11MethodJ5 = null;
/*     */   
/*     */ 
/*     */   private String name;
/*     */   
/*     */   private String lib;
/*     */   
/*  90 */   private ArrayList<IProviderData> providers = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SunP11ModuleData(String provName, String provLib)
/*     */     throws NoSuchProviderException
/*     */   {
/* 100 */     this.name = new String(provName);
/* 101 */     this.lib = new String(provLib);
/* 102 */     testSunPKCS11Library();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void testSunPKCS11Library()
/*     */     throws NoSuchProviderException
/*     */   {
/*     */     try
/*     */     {
/* 112 */       Class<?> prov = Class.forName("sun.security.pkcs11.SunPKCS11");
/* 113 */       if (prov == null) {
/* 114 */         throw new NoSuchProviderException(I18N.getLocalMessage("i18n.mityc.cert.p11.16", new Object[] { I18N.getLocalMessage("i18n.mityc.cert.p11.17") }));
/*     */       }
/*     */     } catch (ClassNotFoundException ex) {
/* 117 */       throw new NoSuchProviderException(I18N.getLocalMessage("i18n.mityc.cert.p11.16", new Object[] { ex.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLib()
/*     */   {
/* 126 */     return this.lib;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 134 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized List<IProviderData> getProvidersData()
/*     */   {
/* 143 */     return this.providers != null ? (List)this.providers.clone() : new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized void adjustProviders(long[] slots)
/*     */   {
/* 153 */     ArrayList<IProviderData> newProviders = new ArrayList();
/* 154 */     for (int i = 0; i < slots.length; i++) {
/* 155 */       int pos = this.providers.indexOf(new Long(slots[i]));
/* 156 */       if (pos > -1) {
/* 157 */         newProviders.add((IProviderData)this.providers.get(pos));
/*     */       } else {
/*     */         try
/*     */         {
/* 161 */           String config = MessageFormat.format("name={0}\r\nlibrary={1}\r\nattributes=compatibility\r\nshowInfo=true\r\nnssArgs=\"configdir='C:\\Users\\msomavilla\\AppData\\Roaming\\Mozilla\\Firefox\\Profiles\\krsd57o8.default' certPrefix='' keyPrefix='' secmod='secmod.db'\"\r\nslot={2}", new Object[] { getName() + slots[i], getLib(), Long.valueOf(slots[i]) });
/* 162 */           Provider provider = getSunPKCS11(new ByteArrayInputStream(config.getBytes()));
/* 163 */           newProviders.add(new SunP11SlotData(provider, slots[i], "PKCS11"));
/* 164 */           if (LOG.isTraceEnabled()) {
/* 165 */             LOG.trace(I18N.getLocalMessage("i18n.mityc.cert.p11.8", new Object[] { provider.getName(), Long.valueOf(slots[i]) }));
/*     */           }
/*     */         } catch (NoSuchProviderException ex) {
/* 168 */           if (LOG.isTraceEnabled()) {
/* 169 */             LOG.trace(I18N.getLocalMessage("i18n.mityc.cert.p11.2", new Object[] { getName(), Long.valueOf(slots[i]) }));
/* 170 */             LOG.error("", ex);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 175 */     this.providers = newProviders;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Provider getSunPKCS11(InputStream is)
/*     */     throws NoSuchProviderException
/*     */   {
/*     */     try
/*     */     {
/* 187 */       Class<?> prov = Class.forName("sun.security.pkcs11.SunPKCS11");
/* 188 */       Constructor<?> constructor = prov.getConstructor(new Class[] { InputStream.class });
/* 189 */       AccessController.doPrivileged(new GetPropertyAction("sun.security.pkcs11.allowSingleThreadedModules"));
/* 190 */       return new SunPKCS11(is);
/*     */     } catch (ClassNotFoundException ex) {
/* 192 */       throw new NoSuchProviderException(I18N.getLocalMessage("i18n.mityc.cert.p11.16", new Object[] { ex.getMessage() }));
/*     */     } catch (SecurityException ex) {
/* 194 */       throw new NoSuchProviderException(I18N.getLocalMessage("i18n.mityc.cert.p11.16", new Object[] { ex.getMessage() }));
/*     */     } catch (NoSuchMethodException ex) {
/* 196 */       throw new NoSuchProviderException(I18N.getLocalMessage("i18n.mityc.cert.p11.16", new Object[] { ex.getMessage() }));
/*     */     } catch (IllegalArgumentException ex) {
/* 198 */       throw new NoSuchProviderException(I18N.getLocalMessage("i18n.mityc.cert.p11.16", new Object[] { ex.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void updateModule()
/*     */   {
/* 207 */     long[] slots = getSlots();
/* 208 */     if (LOG.isTraceEnabled()) {
/* 209 */       LOG.trace(I18N.getLocalMessage("i18n.mityc.cert.p11.11", new Object[] { Integer.valueOf(slots.length) }));
/*     */     }
/* 211 */     slots = new long[2];
/* 212 */     slots[0] = 1L;
/* 213 */     adjustProviders(slots);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void logSlots(long[] slots, String message)
/*     */   {
/* 222 */     StringBuffer sb = new StringBuffer("");
/* 223 */     if ((slots != null) && 
/* 224 */       (slots.length > 0)) {
/* 225 */       for (int i = 0; i < slots.length; i++) {
/* 226 */         sb.append(slots[i]);
/* 227 */         if (i < slots.length - 1) {
/* 228 */           sb.append(", ");
/*     */         }
/*     */       }
/*     */     } else {
/* 232 */       sb.append(I18N.getLocalMessage("i18n.mityc.cert.p11.13"));
/*     */     }
/* 234 */     LOG.trace(I18N.getLocalMessage("i18n.mityc.cert.p11.12", new Object[] { message, Integer.valueOf(slots != null ? slots.length : 0), sb.toString() }));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private long[] filterSlots(PKCS11 pkcs11, long[] slots)
/*     */   {
/* 244 */     ArrayList<Long> list = new ArrayList();
/* 245 */     if (slots != null) {
/* 246 */       for (int i = 0; i < slots.length; i++) {
/*     */         try {
/* 248 */           CK_TOKEN_INFO tokenInfo = pkcs11.C_GetTokenInfo(slots[i]);
/* 249 */           list.add(new Long(slots[i]));
/*     */         }
/*     */         catch (PKCS11Exception ex)
/*     */         {
/* 253 */           if (ex.getErrorCode() == 48L) {
/*     */             try {
/* 255 */               CK_TOKEN_INFO tokenInfo = pkcs11.C_GetTokenInfo(slots[i]);
/* 256 */               list.add(new Long(slots[i]));
/*     */             }
/*     */             catch (PKCS11Exception localPKCS11Exception1) {}
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 263 */     long[] newSlots = new long[list.size()];
/* 264 */     for (int i = 0; i < list.size(); i++) {
/* 265 */       newSlots[i] = ((Long)list.get(i)).longValue();
/*     */     }
/* 267 */     return newSlots;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private long[] getSlots()
/*     */   {
/* 275 */     long[] slots = null;
/* 276 */     CK_C_INITIALIZE_ARGS ckCInitializeArgs = new CK_C_INITIALIZE_ARGS();
/* 277 */     ckCInitializeArgs.flags = 2L;
/* 278 */     PKCS11 pkcs11 = getPKSC11(getLib(), ckCInitializeArgs);
/* 279 */     if (pkcs11 != null) {
/*     */       try
/*     */       {
/* 282 */         slots = pkcs11.C_GetSlotList(true);
/* 283 */         if (LOG.isTraceEnabled()) {
/* 284 */           logSlots(slots, I18N.getLocalMessage("i18n.mityc.cert.p11.14"));
/*     */         }
/*     */         
/* 287 */         slots = filterSlots(pkcs11, slots);
/* 288 */         if (LOG.isTraceEnabled()) {
/* 289 */           logSlots(slots, I18N.getLocalMessage("i18n.mityc.cert.p11.15", new Object[] { getName() }));
/*     */         }
/*     */       }
/*     */       catch (PKCS11Exception localPKCS11Exception) {}
/*     */     }
/*     */     
/* 295 */     return slots != null ? slots : SLOTS_DEFAULT;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private PKCS11 getPKSC11(String libname, CK_C_INITIALIZE_ARGS args)
/*     */   {
/* 306 */     PKCS11 pkcs11 = null;
/*     */     try
/*     */     {
/* 309 */       if ((this.pkcs11MethodJ6 == null) && (this.pkcs11MethodJ5 == null)) {
/* 310 */         this.pkcs11MethodJ6 = PKCS11.class.getMethod("getInstance", new Class[] { String.class, String.class, CK_C_INITIALIZE_ARGS.class, Boolean.TYPE });
/*     */       }
/* 312 */       if (this.pkcs11MethodJ6 != null) {
/* 313 */         Object res = this.pkcs11MethodJ6.invoke(null, new Object[] { libname, "C_GetFunctionList", args, Boolean.valueOf(false) });
/* 314 */         if ((res != null) && 
/* 315 */           ((res instanceof PKCS11))) {
/* 316 */           pkcs11 = (PKCS11)res;
/*     */         }
/*     */       }
/*     */     } catch (NoSuchMethodException ex) {
/* 320 */       if (LOG.isTraceEnabled()) {
/* 321 */         LOG.error("", ex);
/*     */       }
/*     */     } catch (InvocationTargetException ex) {
/* 324 */       if (LOG.isTraceEnabled()) {
/* 325 */         LOG.error("", ex);
/*     */       }
/*     */     } catch (IllegalAccessException ex) {
/* 328 */       if (LOG.isTraceEnabled()) {
/* 329 */         LOG.error("", ex);
/*     */       }
/*     */     } catch (IllegalArgumentException ex) {
/* 332 */       if (LOG.isTraceEnabled()) {
/* 333 */         LOG.error("", ex);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 338 */     if (pkcs11 == null) {
/*     */       try {
/* 340 */         if (this.pkcs11MethodJ5 == null) {
/* 341 */           this.pkcs11MethodJ5 = PKCS11.class.getMethod("getInstance", new Class[] { String.class, CK_C_INITIALIZE_ARGS.class, Boolean.TYPE });
/*     */         }
/* 343 */         if (this.pkcs11MethodJ5 != null) {
/* 344 */           Object res = this.pkcs11MethodJ5.invoke(null, new Object[] { libname, args, Boolean.valueOf(false) });
/* 345 */           if ((res != null) && 
/* 346 */             ((res instanceof PKCS11))) {
/* 347 */             pkcs11 = (PKCS11)res;
/*     */           }
/*     */         }
/*     */       } catch (NoSuchMethodException ex) {
/* 351 */         if (LOG.isTraceEnabled()) {
/* 352 */           LOG.error("", ex);
/*     */         }
/*     */       } catch (InvocationTargetException ex) {
/* 355 */         if (LOG.isTraceEnabled()) {
/* 356 */           LOG.error("", ex);
/*     */         }
/*     */       } catch (IllegalAccessException ex) {
/* 359 */         if (LOG.isTraceEnabled()) {
/* 360 */           LOG.error("", ex);
/*     */         }
/*     */       } catch (IllegalArgumentException ex) {
/* 363 */         if (LOG.isTraceEnabled()) {
/* 364 */           LOG.error("", ex);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 369 */     return pkcs11;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\pkcs11\SunP11ModuleData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */