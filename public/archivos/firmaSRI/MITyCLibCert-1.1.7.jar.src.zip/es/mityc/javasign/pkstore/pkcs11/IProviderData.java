package es.mityc.javasign.pkstore.pkcs11;

import java.security.Provider;

public abstract interface IProviderData
{
  public abstract Provider getProvider();
  
  public abstract String getKeyStoreTypeName();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\pkcs11\IProviderData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */