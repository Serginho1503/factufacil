/*    */ package es.mityc.javasign.pkstore.mitycstore.mantainer;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import javax.accessibility.AccessibleContext;
/*    */ import javax.swing.JTable;
/*    */ import javax.swing.table.DefaultTableCellRenderer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CertCellRenderer
/*    */   extends DefaultTableCellRenderer
/*    */ {
/*    */   public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
/*    */   {
/* 52 */     super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
/*    */     
/*    */ 
/* 55 */     setToolTipText((String)value);
/* 56 */     getAccessibleContext().setAccessibleName((String)value);
/*    */     
/*    */ 
/* 59 */     if (column == 0) {
/* 60 */       setHorizontalAlignment(2);
/* 61 */     } else if (column == 1) {
/* 62 */       setHorizontalAlignment(2);
/* 63 */     } else if (column == 2) {
/* 64 */       setHorizontalAlignment(0);
/*    */     }
/*    */     
/* 67 */     return this;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mitycstore\mantainer\CertCellRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */