/*     */ package es.mityc.javasign.pkstore.mscapi.mityc;
/*     */ 
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.KeyPair;
/*     */ import java.security.KeyPairGeneratorSpi;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.spec.AlgorithmParameterSpec;
/*     */ import java.security.spec.RSAKeyGenParameterSpec;
/*     */ import java.util.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RSAKeyPairGenerator
/*     */   extends KeyPairGeneratorSpi
/*     */ {
/*     */   static final int KEY_SIZE_MIN = 512;
/*     */   static final int KEY_SIZE_MAX = 16384;
/*     */   private static final int KEY_SIZE_DEFAULT = 1024;
/*     */   private int keySize;
/*     */   
/*     */   public RSAKeyPairGenerator()
/*     */   {
/*  56 */     initialize(1024, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initialize(int keySize, SecureRandom random)
/*     */   {
/*  71 */     this.keySize = keySize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void initialize(AlgorithmParameterSpec params, SecureRandom random)
/*     */     throws InvalidAlgorithmParameterException
/*     */   {
/*     */     int tmpSize;
/*     */     
/*  81 */     if (params == null) {
/*  82 */       tmpSize = 1024; } else { int tmpSize;
/*  83 */       if ((params instanceof RSAKeyGenParameterSpec))
/*     */       {
/*  85 */         if (((RSAKeyGenParameterSpec)params).getPublicExponent() != null) {
/*  86 */           throw new InvalidAlgorithmParameterException(
/*  87 */             "Exponent parameter is not supported");
/*     */         }
/*  89 */         tmpSize = ((RSAKeyGenParameterSpec)params).getKeysize();
/*     */       }
/*     */       else {
/*  92 */         throw new InvalidAlgorithmParameterException(
/*  93 */           "Params must be an instance of RSAKeyGenParameterSpec");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     int tmpSize;
/*     */     
/*     */ 
/*     */ 
/* 104 */     this.keySize = tmpSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyPair generateKeyPair()
/*     */   {
/* 112 */     RSAKeyPair keys = 
/* 113 */       generateRSAKeyPair(this.keySize, 
/* 114 */       "{" + UUID.randomUUID().toString() + "}");
/*     */     
/* 116 */     return new KeyPair(keys.getPublic(), keys.getPrivate());
/*     */   }
/*     */   
/*     */   private static native RSAKeyPair generateRSAKeyPair(int paramInt, String paramString);
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mscapi\mityc\RSAKeyPairGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */