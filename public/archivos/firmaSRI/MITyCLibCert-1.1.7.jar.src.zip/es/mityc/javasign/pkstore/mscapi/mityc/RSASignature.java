/*     */ package es.mityc.javasign.pkstore.mscapi.mityc;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.InvalidParameterException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.ProviderException;
/*     */ import java.security.PublicKey;
/*     */ import java.security.SignatureException;
/*     */ import java.security.SignatureSpi;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class RSASignature
/*     */   extends SignatureSpi
/*     */ {
/*     */   private final MessageDigest messageDigest;
/*     */   private boolean needsReset;
/*  63 */   private Key privateKey = null;
/*     */   
/*     */ 
/*  66 */   private Key publicKey = null;
/*     */   
/*     */   RSASignature(String digestName)
/*     */   {
/*     */     try
/*     */     {
/*  72 */       this.messageDigest = MessageDigest.getInstance(digestName);
/*     */     }
/*     */     catch (NoSuchAlgorithmException e) {
/*  75 */       throw new ProviderException(e);
/*     */     }
/*     */     
/*  78 */     this.needsReset = false;
/*     */   }
/*     */   
/*     */   public static final class SHA1 extends RSASignature {
/*     */     public SHA1() {
/*  83 */       super();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class SHA256 extends RSASignature {
/*     */     public SHA256() {
/*  89 */       super();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class SHA384 extends RSASignature {
/*     */     public SHA384() {
/*  95 */       super();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class SHA512 extends RSASignature {
/*     */     public SHA512() {
/* 101 */       super();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class MD5 extends RSASignature {
/*     */     public MD5() {
/* 107 */       super();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class MD2 extends RSASignature {
/*     */     public MD2() {
/* 113 */       super();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineInitVerify(PublicKey key)
/*     */     throws InvalidKeyException
/*     */   {
/* 132 */     if (!(key instanceof java.security.interfaces.RSAPublicKey)) {
/* 133 */       throw new InvalidKeyException("Key type not supported");
/*     */     }
/*     */     
/* 136 */     java.security.interfaces.RSAPublicKey rsaKey = 
/* 137 */       (java.security.interfaces.RSAPublicKey)key;
/*     */     
/* 139 */     if (!(key instanceof RSAPublicKey))
/*     */     {
/*     */ 
/*     */ 
/* 143 */       BigInteger modulus = rsaKey.getModulus();
/* 144 */       BigInteger exponent = rsaKey.getPublicExponent();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 151 */       byte[] modulusBytes = modulus.toByteArray();
/* 152 */       byte[] exponentBytes = exponent.toByteArray();
/*     */       
/*     */ 
/* 155 */       int keyBitLength = modulusBytes[0] == 0 ? 
/* 156 */         (modulusBytes.length - 1) * 8 : 
/* 157 */         modulusBytes.length * 8;
/*     */       
/* 159 */       byte[] keyBlob = generatePublicKeyBlob(
/* 160 */         keyBitLength, modulusBytes, exponentBytes);
/*     */       
/* 162 */       this.publicKey = importPublicKey(keyBlob, keyBitLength);
/*     */     }
/*     */     else {
/* 165 */       this.publicKey = ((RSAPublicKey)key);
/*     */     }
/*     */     
/* 168 */     if (this.needsReset) {
/* 169 */       this.messageDigest.reset();
/* 170 */       this.needsReset = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineInitSign(PrivateKey key)
/*     */     throws InvalidKeyException
/*     */   {
/* 189 */     if (!(key instanceof RSAPrivateKey)) {
/* 190 */       throw new InvalidKeyException("Key type not supported");
/*     */     }
/* 192 */     this.privateKey = ((RSAPrivateKey)key);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 200 */     if (this.needsReset) {
/* 201 */       this.messageDigest.reset();
/* 202 */       this.needsReset = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineUpdate(byte b)
/*     */     throws SignatureException
/*     */   {
/* 218 */     this.messageDigest.update(b);
/* 219 */     this.needsReset = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineUpdate(byte[] b, int off, int len)
/*     */     throws SignatureException
/*     */   {
/* 237 */     this.messageDigest.update(b, off, len);
/* 238 */     this.needsReset = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void engineUpdate(ByteBuffer input)
/*     */   {
/* 250 */     this.messageDigest.update(input);
/* 251 */     this.needsReset = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected byte[] engineSign()
/*     */     throws SignatureException
/*     */   {
/* 269 */     byte[] hash = this.messageDigest.digest();
/* 270 */     this.needsReset = false;
/*     */     
/*     */ 
/*     */ 
/* 274 */     byte[] result = signHash(hash, hash.length, 
/* 275 */       this.messageDigest.getAlgorithm(), this.privateKey.getHCryptProvider(), 
/* 276 */       this.privateKey.getHCryptKey());
/*     */     
/*     */ 
/* 279 */     return convertEndianArray(result);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] convertEndianArray(byte[] byteArray)
/*     */   {
/* 287 */     if ((byteArray == null) || (byteArray.length == 0)) {
/* 288 */       return byteArray;
/*     */     }
/* 290 */     byte[] retval = new byte[byteArray.length];
/*     */     
/*     */ 
/* 293 */     for (int i = 0; i < byteArray.length; i++) {
/* 294 */       retval[i] = byteArray[(byteArray.length - i - 1)];
/*     */     }
/* 296 */     return retval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static native byte[] signHash(byte[] paramArrayOfByte, int paramInt, String paramString, long paramLong1, long paramLong2)
/*     */     throws SignatureException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static native boolean verifySignedHash(byte[] paramArrayOfByte1, int paramInt1, String paramString, byte[] paramArrayOfByte2, int paramInt2, long paramLong1, long paramLong2)
/*     */     throws SignatureException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean engineVerify(byte[] sigBytes)
/*     */     throws SignatureException
/*     */   {
/* 330 */     byte[] hash = this.messageDigest.digest();
/* 331 */     this.needsReset = false;
/*     */     
/* 333 */     return verifySignedHash(hash, hash.length, 
/* 334 */       this.messageDigest.getAlgorithm(), convertEndianArray(sigBytes), 
/* 335 */       sigBytes.length, this.publicKey.getHCryptProvider(), 
/* 336 */       this.publicKey.getHCryptKey());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   protected void engineSetParameter(String param, Object value)
/*     */     throws InvalidParameterException
/*     */   {
/* 367 */     throw new InvalidParameterException("Parameter not supported");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   protected Object engineGetParameter(String param)
/*     */     throws InvalidParameterException
/*     */   {
/* 397 */     throw new InvalidParameterException("Parameter not supported");
/*     */   }
/*     */   
/*     */   private native byte[] generatePublicKeyBlob(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
/*     */   
/*     */   private native RSAPublicKey importPublicKey(byte[] paramArrayOfByte, int paramInt);
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mscapi\mityc\RSASignature.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */