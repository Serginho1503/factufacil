/*    */ package es.mityc.javasign.pkstore.iexplorer;
/*    */ 
/*    */ import java.security.PrivateKey;
/*    */ import java.security.cert.X509Certificate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PKProxyIE
/*    */   implements PrivateKey
/*    */ {
/*    */   private X509Certificate certificatePK;
/*    */   
/*    */   public PKProxyIE(X509Certificate certificate)
/*    */   {
/* 37 */     this.certificatePK = certificate;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public X509Certificate getCertificate()
/*    */   {
/* 45 */     return this.certificatePK;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getAlgorithm()
/*    */   {
/* 54 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getEncoded()
/*    */   {
/* 63 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getFormat()
/*    */   {
/* 72 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\iexplorer\PKProxyIE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */