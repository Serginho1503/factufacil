/*    */ package es.mityc.javasign.pkstore.mscapi.mityc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RSAKeyPair
/*    */ {
/*    */   private final RSAPrivateKey privateKey;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private final RSAPublicKey publicKey;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   RSAKeyPair(long hCryptProv, long hCryptKey, int keyLength)
/*    */   {
/* 44 */     this.privateKey = new RSAPrivateKey(hCryptProv, hCryptKey, keyLength);
/* 45 */     this.publicKey = new RSAPublicKey(hCryptProv, hCryptKey, keyLength);
/*    */   }
/*    */   
/*    */   public RSAPrivateKey getPrivate() {
/* 49 */     return this.privateKey;
/*    */   }
/*    */   
/*    */   public RSAPublicKey getPublic() {
/* 53 */     return this.publicKey;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mscapi\mityc\RSAKeyPair.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */