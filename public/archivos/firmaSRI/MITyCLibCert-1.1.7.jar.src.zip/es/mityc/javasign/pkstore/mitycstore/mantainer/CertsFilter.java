/*    */ package es.mityc.javasign.pkstore.mitycstore.mantainer;
/*    */ 
/*    */ import es.mityc.javasign.i18n.I18nFactory;
/*    */ import es.mityc.javasign.i18n.II18nManager;
/*    */ import java.io.File;
/*    */ import javax.swing.filechooser.FileFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CertsFilter
/*    */   extends FileFilter
/*    */ {
/* 33 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*    */   
/*    */   private static final String P12 = "p12";
/*    */   
/*    */   private static final String CER = "cer";
/*    */   
/*    */   private static final String CRT = "crt";
/*    */   
/*    */   private static final char CHAR_DOT = '.';
/*    */   
/* 43 */   private boolean isSign = false;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CertsFilter(boolean isCertForSign)
/*    */   {
/* 52 */     this.isSign = isCertForSign;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean accept(File f)
/*    */   {
/* 63 */     if (f.isDirectory()) {
/* 64 */       return true;
/*    */     }
/*    */     
/* 67 */     String s = f.getName();
/* 68 */     int i = s.lastIndexOf('.');
/*    */     
/* 70 */     if ((i > 0) && (i < s.length() - 1)) {
/* 71 */       String extension = s.substring(i + 1).toLowerCase();
/* 72 */       if (("p12".equals(extension)) && (this.isSign))
/* 73 */         return true;
/* 74 */       if ("cer".equals(extension))
/* 75 */         return true;
/* 76 */       if ("crt".equals(extension)) {
/* 77 */         return true;
/*    */       }
/* 79 */       return false;
/*    */     }
/*    */     
/*    */ 
/* 83 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getDescription()
/*    */   {
/* 94 */     return I18N.getLocalMessage("i18n.mityc.cert.mityc.46");
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mitycstore\mantainer\CertsFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */