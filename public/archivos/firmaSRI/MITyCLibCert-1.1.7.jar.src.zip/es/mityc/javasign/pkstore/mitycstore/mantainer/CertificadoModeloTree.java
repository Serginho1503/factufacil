/*     */ package es.mityc.javasign.pkstore.mitycstore.mantainer;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.pkstore.mitycstore.CertUtil;
/*     */ import java.math.BigInteger;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Date;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ import javax.swing.tree.DefaultMutableTreeNode;
/*     */ import javax.swing.tree.DefaultTreeModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CertificadoModeloTree
/*     */   extends DefaultTreeModel
/*     */ {
/*  37 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CertificadoModeloTree(DefaultMutableTreeNode root, X509Certificate cert)
/*     */   {
/*  46 */     super(root);
/*     */     
/*  48 */     String datos = "";
/*     */     
/*     */ 
/*  51 */     DefaultMutableTreeNode sujeto = new DefaultMutableTreeNode(new TypeTreeNode(
/*  52 */       I18N.getLocalMessage("i18n.mityc.cert.mityc.25", new Object[] {
/*  53 */       CertUtil.extractName(cert.getSubjectX500Principal().getName()) }), 
/*  54 */       null));
/*     */     
/*     */ 
/*  57 */     DefaultMutableTreeNode sujetoDN = new DefaultMutableTreeNode(new TypeTreeNode(
/*  58 */       I18N.getLocalMessage("i18n.mityc.cert.mityc.26", new Object[] { cert.getSubjectDN() }), 
/*  59 */       null));
/*     */     
/*  61 */     sujeto.add(sujetoDN);
/*  62 */     root.add(sujeto);
/*     */     
/*     */ 
/*  65 */     DefaultMutableTreeNode emisor = new DefaultMutableTreeNode(new TypeTreeNode(
/*  66 */       I18N.getLocalMessage("i18n.mityc.cert.mityc.27", new Object[] {
/*  67 */       CertUtil.extractName(cert.getIssuerX500Principal().getName()) }), 
/*  68 */       null));
/*     */     
/*     */ 
/*  71 */     DefaultMutableTreeNode emisorDN = new DefaultMutableTreeNode(new TypeTreeNode(
/*  72 */       I18N.getLocalMessage("i18n.mityc.cert.mityc.26", new Object[] { cert.getIssuerDN() }), 
/*  73 */       null));
/*     */     
/*  75 */     emisor.add(emisorDN);
/*  76 */     root.add(emisor);
/*     */     
/*  78 */     String aviso = "";
/*  79 */     if (new Date().before(cert.getNotBefore()))
/*     */     {
/*  81 */       aviso = I18N.getLocalMessage("i18n.mityc.cert.mityc.32");
/*     */     }
/*  83 */     if (new Date().after(cert.getNotAfter()))
/*     */     {
/*  85 */       aviso = I18N.getLocalMessage("i18n.mityc.cert.mityc.33");
/*     */     }
/*     */     
/*     */ 
/*  89 */     datos = 
/*  90 */       I18N.getLocalMessage("i18n.mityc.cert.mityc.34", new Object[] { CertUtil.convertDate(cert.getNotBefore()), CertUtil.convertDate(cert.getNotAfter()) }) + aviso;
/*     */     
/*     */ 
/*  93 */     DefaultMutableTreeNode validez = new DefaultMutableTreeNode(new TypeTreeNode(
/*  94 */       I18N.getLocalMessage("i18n.mityc.cert.mityc.28", new Object[] { datos }), 
/*  95 */       null));
/*     */     
/*  97 */     root.add(validez);
/*     */     
/*  99 */     datos = cert.getSerialNumber().toString();
/*     */     
/*     */ 
/* 102 */     DefaultMutableTreeNode nroSerie = new DefaultMutableTreeNode(new TypeTreeNode(
/* 103 */       I18N.getLocalMessage("i18n.mityc.cert.mityc.29", new Object[] { datos }), 
/* 104 */       null));
/*     */     
/* 106 */     root.add(nroSerie);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 113 */     StringBuilder claveUsoString = new StringBuilder("");
/* 114 */     String[] clavesUsadasArray = new String[9];
/*     */     
/*     */ 
/* 117 */     clavesUsadasArray[0] = I18N.getLocalMessage("i18n.mityc.cert.mityc.35");
/*     */     
/* 119 */     clavesUsadasArray[1] = I18N.getLocalMessage("i18n.mityc.cert.mityc.36");
/*     */     
/* 121 */     clavesUsadasArray[2] = I18N.getLocalMessage("i18n.mityc.cert.mityc.37");
/*     */     
/* 123 */     clavesUsadasArray[3] = I18N.getLocalMessage("i18n.mityc.cert.mityc.38");
/*     */     
/* 125 */     clavesUsadasArray[4] = I18N.getLocalMessage("i18n.mityc.cert.mityc.39");
/*     */     
/* 127 */     clavesUsadasArray[5] = I18N.getLocalMessage("i18n.mityc.cert.mityc.40");
/*     */     
/* 129 */     clavesUsadasArray[6] = I18N.getLocalMessage("i18n.mityc.cert.mityc.41");
/*     */     
/* 131 */     clavesUsadasArray[7] = I18N.getLocalMessage("i18n.mityc.cert.mityc.42");
/*     */     
/* 133 */     clavesUsadasArray[8] = I18N.getLocalMessage("i18n.mityc.cert.mityc.43");
/*     */     
/*     */ 
/* 136 */     boolean[] claveUso = cert.getKeyUsage();
/* 137 */     if (claveUso != null) {
/* 138 */       for (int z = 0; z < claveUso.length; z++) {
/* 139 */         if (claveUso[z] != 0) {
/* 140 */           claveUsoString.append(clavesUsadasArray[z]);
/* 141 */           claveUsoString.append(", ");
/*     */         }
/*     */       }
/* 144 */       claveUsoString.deleteCharAt(claveUsoString.length() - 1);
/*     */     }
/*     */     else {
/* 147 */       claveUsoString.append(I18N.getLocalMessage("i18n.mityc.cert.mityc.44"));
/*     */     }
/*     */     
/*     */ 
/* 151 */     DefaultMutableTreeNode uso = new DefaultMutableTreeNode(new TypeTreeNode(
/* 152 */       I18N.getLocalMessage("i18n.mityc.cert.mityc.30", new Object[] { claveUsoString.toString() }), 
/* 153 */       null));
/*     */     
/* 155 */     root.add(uso);
/*     */     try
/*     */     {
/* 158 */       datos = cert.getSigAlgName();
/*     */     }
/*     */     catch (Throwable t) {
/* 161 */       datos = I18N.getLocalMessage("i18n.mityc.cert.mityc.45");
/*     */     }
/*     */     
/*     */ 
/* 165 */     DefaultMutableTreeNode algoritmo = new DefaultMutableTreeNode(new TypeTreeNode(
/* 166 */       I18N.getLocalMessage("i18n.mityc.cert.mityc.31", new Object[] { datos }), 
/* 167 */       null));
/*     */     
/* 169 */     root.add(algoritmo);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mitycstore\mantainer\CertificadoModeloTree.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */