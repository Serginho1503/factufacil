/*    */ package es.mityc.javasign.pkstore.mozilla;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum MozillaTokenLoginModeEnum
/*    */ {
/* 23 */   ONE_TIME(
/* 24 */     0), 
/* 25 */   TIMEOUT(
/* 26 */     1), 
/* 27 */   EVERY_TIME(
/* 28 */     2);
/*    */   
/*    */ 
/* 31 */   private int emode = 0;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private MozillaTokenLoginModeEnum(int mode)
/*    */   {
/* 38 */     this.emode = mode;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static MozillaTokenLoginModeEnum getDefault()
/*    */   {
/* 47 */     return ONE_TIME;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static MozillaTokenLoginModeEnum getLoginMode(int mode)
/*    */   {
/*    */     MozillaTokenLoginModeEnum emod;
/*    */     
/*    */ 
/*    */     MozillaTokenLoginModeEnum emod;
/*    */     
/*    */     MozillaTokenLoginModeEnum emod;
/*    */     
/*    */     MozillaTokenLoginModeEnum emod;
/*    */     
/* 63 */     switch (mode) {
/*    */     case 0: 
/* 65 */       emod = ONE_TIME;
/* 66 */       break;
/*    */     case 1: 
/* 68 */       emod = TIMEOUT;
/* 69 */       break;
/*    */     case 2: 
/* 71 */       emod = EVERY_TIME;
/* 72 */       break;
/*    */     default: 
/* 74 */       emod = ONE_TIME;
/*    */     }
/* 76 */     return emod;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getInteger()
/*    */   {
/* 84 */     return this.emode;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mozilla\MozillaTokenLoginModeEnum.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */