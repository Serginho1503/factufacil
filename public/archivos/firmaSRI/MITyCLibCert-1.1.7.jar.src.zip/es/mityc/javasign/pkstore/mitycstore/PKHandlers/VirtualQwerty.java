/*     */ package es.mityc.javasign.pkstore.mitycstore.PKHandlers;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import java.awt.Color;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Frame;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.io.PrintStream;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPasswordField;
/*     */ import javax.swing.JRootPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VirtualQwerty
/*     */ {
/*  50 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*     */   
/*     */   private static final String NOT_VISIBLE = "NoVisible";
/*     */   
/*     */   private static final String UNIR_SUPERIOR = "UnirSuperior";
/*     */   private static final String UNIR_IZQUIERDA = "UnirIzquierda";
/*  56 */   private static final String[] keyMatrixUpperCase = {
/*  57 */     "Esc", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "'", "¡", "Retroceso", "/", 
/*  58 */     "Tab", "Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "`", "+", "Intro", ".", 
/*  59 */     "Mayus", "A", "S", "D", "F", "G", "H", "J", "K", "L", "Ñ", "´", "Ç", "UnirSuperior", "NoVisible", 
/*  60 */     "Shift", "<", "Z", "X", "C", "V", "B", "N", "M", ",", ".", "-", "Shift", "NoVisible", "NoVisible", 
/*  61 */     "Ctrl", "Alt", "NoVisible", "Espacio", "UnirIzquierda", "UnirIzquierda", "UnirIzquierda", "UnirIzquierda", "UnirIzquierda", "UnirIzquierda", "NoVisible", "Alt", "NoVisible", "NoVisible", "NoVisible", "NoVisible", "NoVisible", "NoVisible" };
/*     */   
/*  63 */   private static final String[] keyMatrixLowerCase = {
/*  64 */     "Esc", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "'", "¡", "Retroceso", "/", 
/*  65 */     "Tab", "q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "`", "+", "Intro", ".", 
/*  66 */     "Mayus", "a", "s", "d", "f", "g", "h", "j", "k", "l", "ñ", "´", "Ç", "UnirSuperior", "NoVisible", 
/*  67 */     "Shift", "<", "z", "x", "c", "v", "b", "n", "m", ",", ".", "-", "Shift", "NoVisible", "NoVisible", 
/*  68 */     "Ctrl", "Alt", "NoVisible", "Espacio", "UnirIzquierda", "UnirIzquierda", "UnirIzquierda", "UnirIzquierda", "UnirIzquierda", "UnirIzquierda", "NoVisible", "Alt", "NoVisible", "NoVisible", "NoVisible", "NoVisible", "NoVisible", "NoVisible" };
/*     */   
/*  70 */   private static final String[] keyMatrixShiftCase = {
/*  71 */     "Esc", "!", "\"", "·", "$", "%", "&", "/", "(", ")", "=", "?", "¿", "Retroceso", "/", 
/*  72 */     "Tab", "", "", "", "", "", "", "", "", "", "", "^", "*", "Intro", ".", 
/*  73 */     "Mayus", "", "", "", "", "", "", "", "", "", "", "¨", "Ç", "UnirSuperior", "NoVisible", 
/*  74 */     "Shift", ">", "", "", "", "", "", "", "", ";", ":", "_", "Shift", "NoVisible", "NoVisible", 
/*  75 */     "Ctrl", "Alt", "NoVisible", "Espacio", "UnirIzquierda", "UnirIzquierda", "UnirIzquierda", "UnirIzquierda", "UnirIzquierda", "UnirIzquierda", "NoVisible", "Alt", "NoVisible", "NoVisible", "NoVisible", "NoVisible", "NoVisible", "NoVisible" };
/*     */   
/*  77 */   private static final String[] keyMatrixAltCase = {
/*  78 */     "Esc", "|", "@", "#", "~", "€", "¬", "7", "8", "9", "0", "'", "¡", "Retroceso", "/", 
/*  79 */     "Tab", "", "", "", "", "", "", "", "", "", "", "[", "]", "Intro", ".", 
/*  80 */     "Mayus", "", "", "", "", "", "", "", "", "", "", "{", "}", "UnirSuperior", "NoVisible", 
/*  81 */     "Shift", "<", "", "", "", "", "", "", "", ",", ".", "-", "Shift", "NoVisible", "NoVisible", 
/*  82 */     "Ctrl", "Alt", "NoVisible", "Espacio", "UnirIzquierda", "UnirIzquierda", "UnirIzquierda", "UnirIzquierda", "UnirIzquierda", "UnirIzquierda", "NoVisible", "Alt", "NoVisible", "NoVisible", "NoVisible", "NoVisible", "NoVisible", "NoVisible" };
/*     */   
/*  84 */   private Frame owner = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public VirtualQwerty(Frame owner)
/*     */   {
/*  90 */     this.dialog = new JDialog(owner, I18N.getLocalMessage("i18n.mityc.cert.smartcards.GUI.title"), true);
/*  91 */     this.owner = owner;
/*  92 */     init();
/*     */   }
/*     */   
/*     */   private class HotKey {
/*  96 */     public int[] posicion = new int[2];
/*  97 */     public JButton tecla = null;
/*     */     
/*     */     public HotKey(int x, int y, String text, int width, int height) {
/* 100 */       this.posicion[0] = x;
/* 101 */       this.posicion[1] = y;
/*     */       
/* 103 */       this.tecla = new JButton(text);
/* 104 */       this.tecla.setMargin(new Insets(0, 1, 1, 0));
/* 105 */       this.tecla.setBackground(new Color(150, 217, 250));
/* 106 */       this.tecla.setContentAreaFilled(false);
/* 107 */       this.tecla.setSize(new Dimension(width, height));
/* 108 */       this.tecla.setPreferredSize(new Dimension(width, height));
/* 109 */       this.tecla.setMaximumSize(new Dimension(width, height));
/* 110 */       this.tecla.setMinimumSize(new Dimension(width, height));
/* 111 */       this.tecla.addMouseListener(
/* 112 */         new MouseListener() {
/*     */           public void mousePressed(MouseEvent e) {
/* 114 */             JButton boton = (JButton)e.getSource();
/* 115 */             String buttonText = boton.getText();
/* 116 */             if ((buttonText != null) && (buttonText.equalsIgnoreCase("SHIFT"))) {
/* 117 */               if (boton.isContentAreaFilled()) {
/* 118 */                 boton.setContentAreaFilled(false);
/* 119 */                 VirtualQwerty.HotKey.this.changeKeyBoard(VirtualQwerty.keyMatrixLowerCase);
/*     */               } else {
/* 121 */                 boton.setContentAreaFilled(true);
/* 122 */                 VirtualQwerty.HotKey.this.changeKeyBoard(VirtualQwerty.keyMatrixShiftCase);
/*     */               }
/* 124 */             } else if ((buttonText != null) && (buttonText.equalsIgnoreCase("Mayus"))) {
/* 125 */               if (boton.isContentAreaFilled()) {
/* 126 */                 boton.setContentAreaFilled(false);
/* 127 */                 VirtualQwerty.HotKey.this.changeKeyBoard(VirtualQwerty.keyMatrixLowerCase);
/*     */               } else {
/* 129 */                 boton.setContentAreaFilled(true);
/* 130 */                 VirtualQwerty.HotKey.this.changeKeyBoard(VirtualQwerty.keyMatrixUpperCase);
/*     */               }
/* 132 */             } else if ((buttonText != null) && (buttonText.equalsIgnoreCase("Retroceso"))) {
/* 133 */               String password = new String(VirtualQwerty.this.pass.getPassword());
/* 134 */               int size = password.length() - 1;
/* 135 */               if (size >= 0) {
/* 136 */                 VirtualQwerty.this.pass.setText(password.substring(0, size));
/* 137 */                 System.out.println(new String(VirtualQwerty.this.pass.getPassword()));
/*     */               }
/* 139 */             } else if ((buttonText != null) && (buttonText.equalsIgnoreCase("Alt"))) {
/* 140 */               if (boton.isContentAreaFilled()) {
/* 141 */                 boton.setContentAreaFilled(false);
/* 142 */                 VirtualQwerty.HotKey.this.changeKeyBoard(VirtualQwerty.keyMatrixLowerCase);
/*     */               } else {
/* 144 */                 boton.setContentAreaFilled(true);
/* 145 */                 VirtualQwerty.HotKey.this.changeKeyBoard(VirtualQwerty.keyMatrixAltCase);
/*     */               }
/*     */             } else {
/* 148 */               VirtualQwerty.this.pass.setText(new String(VirtualQwerty.this.pass.getPassword()) + boton.getText());
/* 149 */               System.out.println(new String(VirtualQwerty.this.pass.getPassword()));
/*     */             }
/*     */           }
/*     */           
/*     */           public void mouseExited(MouseEvent e) {
/* 154 */             VirtualQwerty.this.mainPanel.setCursor(new Cursor(0));
/*     */           }
/*     */           
/* 157 */           public void mouseEntered(MouseEvent e) { VirtualQwerty.this.mainPanel.setCursor(new Cursor(12)); }
/*     */           
/*     */           public void mouseClicked(MouseEvent e) {}
/*     */           
/*     */           public void mouseReleased(MouseEvent e) {}
/*     */         });
/*     */     }
/*     */     
/* 165 */     public void changeKeyBoard(String[] newValue) { int y = 1;
/* 166 */       HotKey teclaItem = null;
/* 167 */       for (int x = 1; y < 6; x++) {
/* 168 */         String valueToShow = newValue[(x - 1 + (y - 1) * 15)];
/* 169 */         teclaItem = VirtualQwerty.this.teclado[(x - 1 + (y - 1) * 15)];
/* 170 */         String before = null;
/* 171 */         if (teclaItem == null) {
/* 172 */           if (x > 14) {
/* 173 */             x = 0;
/* 174 */             y++;
/*     */           }
/*     */         }
/*     */         else {
/* 178 */           before = teclaItem.tecla.getText();
/*     */           
/*     */ 
/* 181 */           if ((before == null) || (before.equals("NoVisible")) || 
/* 182 */             (before.equals("UnirSuperior")) || 
/* 183 */             (before.equals("UnirIzquierda"))) {
/* 184 */             if (x > 14) {
/* 185 */               x = 0;
/* 186 */               y++;
/*     */             }
/*     */           }
/*     */           else {
/* 190 */             teclaItem.tecla.setText(valueToShow);
/*     */             
/*     */ 
/* 193 */             if (x > 14) {
/* 194 */               x = 0;
/* 195 */               y++;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 203 */   private void init() { this.teclado = new HotKey[75];
/*     */     
/* 205 */     this.mainPanel = new JPanel();
/* 206 */     JButton aceptar = new JButton(I18N.getLocalMessage("i18n.mityc.cert.smartcards.GUI.accept"));
/* 207 */     JButton cancelar = new JButton(I18N.getLocalMessage("i18n.mityc.cert.smartcards.GUI.cancel"));
/*     */     
/* 209 */     aceptar.setActionCommand("OK");
/* 210 */     cancelar.setActionCommand("CLOSE");
/*     */     
/* 212 */     this.pass = new JPasswordField(15);
/* 213 */     GridBagConstraints g = new GridBagConstraints();
/* 214 */     this.mainPanel.setLayout(new GridBagLayout());
/*     */     
/* 216 */     g.insets = new Insets(5, 15, 3, 15);
/* 217 */     g.gridx = 0;
/* 218 */     g.gridy = 2;
/* 219 */     g.gridwidth = 1;
/* 220 */     g.fill = 0;
/* 221 */     g.weightx = 0.0D;
/*     */     
/* 223 */     this.lblMessage = new JLabel(I18N.getLocalMessage("i18n.mityc.cert.smartcards.GUI.pin"));
/* 224 */     this.mainPanel.add(this.lblMessage, g, 0);
/*     */     
/* 226 */     g.gridy = 2;
/* 227 */     g.gridx = -1;
/* 228 */     g.gridwidth = 0;
/* 229 */     g.fill = 2;
/* 230 */     g.weightx = 1.0D;
/* 231 */     this.mainPanel.add(this.pass, g, 1);
/*     */     
/* 233 */     g.gridy = 3;
/* 234 */     g.gridx = 0;
/* 235 */     g.fill = 1;
/* 236 */     g.weightx = 1.0D;
/* 237 */     this.mainPanel.add(paintKeyBoard(keyMatrixLowerCase), g, 2);
/*     */     
/* 239 */     g.gridx = 0;
/* 240 */     g.gridy = 4;
/* 241 */     g.fill = 0;
/* 242 */     g.weightx = 0.0D;
/* 243 */     g.gridwidth = 6;
/* 244 */     g.anchor = 17;
/*     */     
/* 246 */     this.mainPanel.add(aceptar, g, 3);
/*     */     
/* 248 */     g.gridx = -1;
/* 249 */     g.gridy = 4;
/* 250 */     g.fill = 0;
/* 251 */     g.weightx = 0.0D;
/* 252 */     g.gridwidth = 0;
/* 253 */     g.anchor = 13;
/* 254 */     this.mainPanel.add(cancelar, g, 4);
/*     */     
/* 256 */     this.mainPanel.doLayout();
/* 257 */     this.dialog.add(this.mainPanel);
/* 258 */     this.dialog.setResizable(true);
/*     */     
/* 260 */     this.dialog.getRootPane().setDefaultButton(aceptar);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 265 */     Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
/* 266 */     this.dialog.setBounds((screenSize.width - 660) / 2, (screenSize.height - 500) / 2, 660, 500);
/*     */     
/*     */ 
/* 269 */     aceptar.addActionListener(
/* 270 */       new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 272 */           if (e.getActionCommand().equals("OK")) {
/* 273 */             VirtualQwerty.this.dialog.setVisible(false);
/*     */           }
/*     */           
/*     */         }
/* 277 */       });
/* 278 */     cancelar.addActionListener(
/* 279 */       new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 281 */           if (e.getActionCommand().equals("CLOSE")) {
/* 282 */             VirtualQwerty.this.cancelado = true;
/* 283 */             VirtualQwerty.this.dialog.setVisible(false);
/* 284 */             System.exit(0);
/*     */           }
/*     */         }
/* 287 */       });
/* 288 */     this.dialog.setSize(new Dimension(900, 300));
/*     */   }
/*     */   
/*     */ 
/*     */   private JPanel paintKeyBoard(String[] value)
/*     */   {
/* 294 */     HotKey tecla = null;
/* 295 */     Dimension teclaSize = new Dimension(40, 30);
/*     */     
/* 297 */     JPanel tecladoPanel = new JPanel();
/* 298 */     tecladoPanel.setLayout(new GridBagLayout());
/* 299 */     int y = 1;
/* 300 */     for (int x = 1; y < 6; x++) {
/* 301 */       String valueToShow = value[(x - 1 + (y - 1) * 15)];
/* 302 */       if (valueToShow.equals("NoVisible")) {
/* 303 */         if (x > 14) {
/* 304 */           x = 0;
/* 305 */           y++;
/*     */         }
/* 307 */       } else if (!valueToShow.equals("UnirSuperior"))
/*     */       {
/*     */ 
/* 310 */         int width = (int)teclaSize.getWidth();
/* 311 */         int celdasUnidas = 0;
/* 312 */         String nextElement = null;
/* 313 */         for (int neXt = x; neXt < 14; neXt++) {
/* 314 */           nextElement = value[(neXt + (y - 1) * 15)];
/* 315 */           if (!nextElement.equals("UnirIzquierda")) break;
/* 316 */           width += (int)teclaSize.getWidth();
/* 317 */           celdasUnidas++;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 323 */         int height = (int)teclaSize.getHeight();
/* 324 */         int columnasUnidas = 0;
/* 325 */         for (int down = y; down < 5; down++) {
/* 326 */           nextElement = value[(x - 1 + down * 15)];
/* 327 */           if (!nextElement.equals("UnirSuperior")) break;
/* 328 */           height += (int)teclaSize.getHeight();
/* 329 */           columnasUnidas++;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 335 */         tecla = new HotKey(x, y, valueToShow, width, height);
/* 336 */         this.teclado[(x - 1 + (y - 1) * 15)] = tecla;
/*     */         
/* 338 */         GridBagConstraints g = new GridBagConstraints();
/* 339 */         g.insets = new Insets(1, 1, 0, 0);
/* 340 */         g.gridx = x;
/* 341 */         g.gridy = y;
/* 342 */         if (celdasUnidas > 0)
/* 343 */           g.gridwidth = (celdasUnidas + 1);
/* 344 */         if (columnasUnidas > 0)
/* 345 */           g.gridheight = (columnasUnidas + 1);
/* 346 */         tecladoPanel.add(tecla.tecla, g);
/*     */         
/* 348 */         x += celdasUnidas;
/*     */       }
/*     */       
/* 351 */       if (x > 14) {
/* 352 */         x = 0;
/* 353 */         y++;
/*     */       }
/*     */     }
/*     */     
/* 357 */     return tecladoPanel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTitle(String newTitle)
/*     */   {
/* 365 */     this.dialog.setTitle(newTitle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPINMessage(String newMessage)
/*     */   {
/* 373 */     this.lblMessage.setText(newMessage);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void pack()
/*     */   {
/* 380 */     this.dialog.pack();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVisible(boolean flag)
/*     */   {
/* 390 */     if (flag) {
/* 391 */       this.cancelado = false;
/* 392 */       this.pass.setText("");
/*     */     }
/* 394 */     this.dialog.setVisible(flag);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] getPassword()
/*     */   {
/* 402 */     return this.pass.getPassword();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void dispose()
/*     */   {
/* 409 */     this.dialog.dispose();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCancelado()
/*     */   {
/* 417 */     return this.cancelado;
/*     */   }
/*     */   
/* 420 */   private HotKey[] teclado = null;
/*     */   
/*     */ 
/* 423 */   protected JPanel mainPanel = null;
/*     */   
/* 425 */   protected JDialog dialog = null;
/*     */   
/* 427 */   protected JLabel lblMessage = null;
/*     */   
/* 429 */   private JPasswordField pass = null;
/*     */   
/*     */   private static final String STR_OK = "OK";
/*     */   
/*     */   private static final String STR_CLOSE = "CLOSE";
/*     */   
/* 435 */   private boolean cancelado = false;
/*     */   
/*     */   public static void main(String[] args) {
/* 438 */     VirtualQwerty vq = new VirtualQwerty(new JFrame());
/*     */     
/* 440 */     vq.setVisible(true);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mitycstore\PKHandlers\VirtualQwerty.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */