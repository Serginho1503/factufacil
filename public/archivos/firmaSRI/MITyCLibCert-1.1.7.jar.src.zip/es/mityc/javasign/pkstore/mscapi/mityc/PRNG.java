/*    */ package es.mityc.javasign.pkstore.mscapi.mityc;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.security.ProviderException;
/*    */ import java.security.SecureRandomSpi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PRNG
/*    */   extends SecureRandomSpi
/*    */   implements Serializable
/*    */ {
/*    */   private static native byte[] generateSeed(int paramInt, byte[] paramArrayOfByte);
/*    */   
/*    */   protected void engineSetSeed(byte[] seed)
/*    */   {
/* 61 */     if (seed != null) {
/* 62 */       generateSeed(-1, seed);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void engineNextBytes(byte[] bytes)
/*    */   {
/* 73 */     if ((bytes != null) && 
/* 74 */       (generateSeed(0, bytes) == null)) {
/* 75 */       throw new ProviderException("Error generating random bytes");
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected byte[] engineGenerateSeed(int numBytes)
/*    */   {
/* 90 */     byte[] seed = generateSeed(numBytes, null);
/*    */     
/* 92 */     if (seed == null) {
/* 93 */       throw new ProviderException("Error generating seed bytes");
/*    */     }
/* 95 */     return seed;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mscapi\mityc\PRNG.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */