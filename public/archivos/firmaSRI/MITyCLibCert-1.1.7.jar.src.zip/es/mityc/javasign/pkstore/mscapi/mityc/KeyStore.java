/*     */ package es.mityc.javasign.pkstore.mscapi.mityc;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.math.BigInteger;
/*     */ import java.security.AccessController;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.KeyStoreSpi;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.SecurityPermission;
/*     */ import java.security.UnrecoverableKeyException;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.CertificateEncodingException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.security.interfaces.RSAPrivateCrtKey;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class KeyStore
/*     */   extends KeyStoreSpi
/*     */ {
/*     */   public static final class MY
/*     */     extends KeyStore
/*     */   {
/*     */     public MY()
/*     */     {
/*  61 */       super();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class ROOT extends KeyStore {
/*     */     public ROOT() {
/*  67 */       super();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class CA extends KeyStore {
/*     */     public CA() {
/*  73 */       super();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class LocalMachineMY extends KeyStore {
/*     */     public LocalMachineMY() {
/*  79 */       super();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class LocalMachineROOT extends KeyStore {
/*     */     public LocalMachineROOT() {
/*  85 */       super();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class LocalMachineCA extends KeyStore {
/*     */     public LocalMachineCA() {
/*  91 */       super();
/*     */     }
/*     */   }
/*     */   
/*     */   class KeyEntry
/*     */   {
/*     */     private Key privateKey;
/*     */     private X509Certificate[] certChain;
/*     */     private String alias;
/*     */     private String oldAlias;
/*     */     
/*     */     KeyEntry(Key key, X509Certificate[] chain) {
/* 103 */       this(null, key, chain);
/*     */     }
/*     */     
/*     */     KeyEntry(String alias, Key key, X509Certificate[] chain) {
/* 107 */       this.privateKey = key;
/* 108 */       this.certChain = chain;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 113 */       if (alias == null) {
/* 114 */         this.oldAlias = Integer.toString(chain[0].hashCode());
/*     */       } else {
/* 116 */         this.oldAlias = alias;
/*     */       }
/* 118 */       this.alias = Long.toString(KeyStore.this.getEntryCount());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     String getAlias()
/*     */     {
/* 126 */       return this.alias;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     void setAlias(String alias)
/*     */     {
/* 135 */       this.alias = alias;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     Key getPrivateKey()
/*     */     {
/* 143 */       return this.privateKey;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     void setPrivateKey(RSAPrivateCrtKey key)
/*     */     {
/* 151 */       byte[] modulusBytes = key.getModulus().toByteArray();
/*     */       
/*     */ 
/* 154 */       int keyBitLength = modulusBytes[0] == 0 ? 
/* 155 */         (modulusBytes.length - 1) * 8 : 
/* 156 */         modulusBytes.length * 8;
/*     */       
/* 158 */       byte[] keyBlob = KeyStore.this.generatePrivateKeyBlob(
/* 159 */         keyBitLength, 
/* 160 */         modulusBytes, 
/* 161 */         key.getPublicExponent().toByteArray(), 
/* 162 */         key.getPrivateExponent().toByteArray(), 
/* 163 */         key.getPrimeP().toByteArray(), 
/* 164 */         key.getPrimeQ().toByteArray(), 
/* 165 */         key.getPrimeExponentP().toByteArray(), 
/* 166 */         key.getPrimeExponentQ().toByteArray(), 
/* 167 */         key.getCrtCoefficient().toByteArray());
/*     */       
/* 169 */       this.privateKey = KeyStore.this.storePrivateKey(keyBlob, 
/* 170 */         "{" + UUID.randomUUID().toString() + "}", keyBitLength);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     X509Certificate[] getCertificateChain()
/*     */     {
/* 178 */       return this.certChain;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     void setCertificateChain(X509Certificate[] chain)
/*     */       throws CertificateException
/*     */     {
/* 187 */       for (int i = 0; i < chain.length; i++) {
/* 188 */         byte[] encoding = chain[i].getEncoded();
/* 189 */         if ((i == 0) && (this.privateKey != null)) {
/* 190 */           KeyStore.this.storeCertificate(KeyStore.access$3(KeyStore.this), this.alias, encoding, 
/* 191 */             encoding.length, this.privateKey.getHCryptProvider(), 
/* 192 */             this.privateKey.getHCryptKey());
/*     */         }
/*     */         else {
/* 195 */           KeyStore.this.storeCertificate(KeyStore.access$3(KeyStore.this), this.alias, encoding, 
/* 196 */             encoding.length, 0L, 0L);
/*     */         }
/*     */       }
/* 199 */       this.certChain = chain;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 207 */   private CertificateFactory certificateFactory = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String KEYSTORE_COMPATIBILITY_MODE_PROP = "sun.security.mscapi.keyStoreCompatibilityMode";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final boolean keyStoreCompatibilityMode;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 222 */   private Collection<KeyEntry> entries = new ArrayList();
/*     */   
/* 224 */   private long entriesCount = 0L;
/*     */   
/*     */ 
/*     */ 
/*     */   private final String storeName;
/*     */   
/*     */ 
/*     */ 
/*     */   KeyStore(String storeName)
/*     */   {
/* 234 */     String prop = 
/* 235 */       (String)AccessController.doPrivileged(new PrivilegedAction() {
/*     */         public String run() {
/* 237 */           return System.getProperty("sun.security.mscapi.keyStoreCompatibilityMode");
/*     */         }
/*     */       });
/*     */     
/* 241 */     if ("false".equalsIgnoreCase(prop)) {
/* 242 */       this.keyStoreCompatibilityMode = false;
/*     */     } else {
/* 244 */       this.keyStoreCompatibilityMode = true;
/*     */     }
/*     */     
/* 247 */     this.storeName = storeName;
/*     */   }
/*     */   
/*     */   private synchronized long getEntryCount() {
/* 251 */     return this.entriesCount++;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public java.security.Key engineGetKey(String alias, char[] password)
/*     */     throws NoSuchAlgorithmException, UnrecoverableKeyException
/*     */   {
/* 283 */     if (alias == null) {
/* 284 */       return null;
/*     */     }
/*     */     
/* 287 */     if ((password != null) && (!this.keyStoreCompatibilityMode)) {
/* 288 */       throw new UnrecoverableKeyException("Password must be null");
/*     */     }
/*     */     
/* 291 */     if (!engineIsKeyEntry(alias)) {
/* 292 */       return null;
/*     */     }
/* 294 */     for (KeyEntry entry : this.entries) {
/* 295 */       if (alias.equals(entry.getAlias())) {
/* 296 */         return entry.getPrivateKey();
/*     */       }
/*     */     }
/*     */     
/* 300 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Certificate[] engineGetCertificateChain(String alias)
/*     */   {
/* 317 */     if (alias == null) {
/* 318 */       return null;
/*     */     }
/*     */     
/* 321 */     for (KeyEntry entry : this.entries) {
/* 322 */       if (alias.equals(entry.getAlias())) {
/* 323 */         X509Certificate[] certChain = entry.getCertificateChain();
/*     */         
/* 325 */         return (Certificate[])certChain.clone();
/*     */       }
/*     */     }
/*     */     
/* 329 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Certificate engineGetCertificate(String alias)
/*     */   {
/* 350 */     if (alias == null) {
/* 351 */       return null;
/*     */     }
/*     */     
/* 354 */     for (KeyEntry entry : this.entries) {
/* 355 */       if (alias.equals(entry.getAlias()))
/*     */       {
/* 357 */         X509Certificate[] certChain = entry.getCertificateChain();
/* 358 */         return certChain[0];
/*     */       }
/*     */     }
/*     */     
/* 362 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date engineGetCreationDate(String alias)
/*     */   {
/* 375 */     if (alias == null) {
/* 376 */       return null;
/*     */     }
/* 378 */     return new Date();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void engineSetKeyEntry(String alias, java.security.Key key, char[] password, Certificate[] chain)
/*     */     throws KeyStoreException
/*     */   {
/* 418 */     if (alias == null) {
/* 419 */       throw new KeyStoreException("alias must not be null");
/*     */     }
/*     */     
/* 422 */     if ((password != null) && (!this.keyStoreCompatibilityMode)) {
/* 423 */       throw new KeyStoreException("Password must be null");
/*     */     }
/*     */     
/* 426 */     if ((key instanceof RSAPrivateCrtKey))
/*     */     {
/* 428 */       KeyEntry entry = null;
/* 429 */       boolean found = false;
/*     */       
/* 431 */       for (KeyEntry e : this.entries) {
/* 432 */         if (alias.equals(e.getAlias())) {
/* 433 */           found = true;
/* 434 */           entry = e;
/* 435 */           break;
/*     */         }
/*     */       }
/*     */       
/* 439 */       if (!found) {
/* 440 */         entry = 
/*     */         
/* 442 */           new KeyEntry(alias, null, (X509Certificate[])chain);
/* 443 */         this.entries.add(entry);
/*     */       }
/*     */       
/* 446 */       entry.setAlias(alias);
/* 447 */       entry.setPrivateKey((RSAPrivateCrtKey)key);
/*     */       try
/*     */       {
/* 450 */         entry.setCertificateChain((X509Certificate[])chain);
/*     */       }
/*     */       catch (CertificateException ce) {
/* 453 */         throw new KeyStoreException(ce);
/*     */       }
/*     */     }
/*     */     else {
/* 457 */       throw new UnsupportedOperationException(
/* 458 */         "Cannot assign the key to the given alias.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void engineSetKeyEntry(String alias, byte[] key, Certificate[] chain)
/*     */     throws KeyStoreException
/*     */   {
/* 490 */     throw new UnsupportedOperationException(
/* 491 */       "Cannot assign the encoded key to the given alias.");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void engineSetCertificateEntry(String alias, Certificate cert)
/*     */     throws KeyStoreException
/*     */   {
/* 512 */     if (alias == null) {
/* 513 */       throw new KeyStoreException("alias must not be null");
/*     */     }
/*     */     
/* 516 */     if ((cert instanceof X509Certificate))
/*     */     {
/*     */ 
/* 519 */       X509Certificate[] chain = 
/* 520 */         { (X509Certificate)cert };
/* 521 */       KeyEntry entry = null;
/* 522 */       boolean found = false;
/*     */       
/* 524 */       for (KeyEntry e : this.entries) {
/* 525 */         if (alias.equals(e.getAlias())) {
/* 526 */           found = true;
/* 527 */           entry = e;
/* 528 */           break;
/*     */         }
/*     */       }
/*     */       
/* 532 */       if (!found) {
/* 533 */         entry = 
/* 534 */           new KeyEntry(alias, null, chain);
/* 535 */         this.entries.add(entry);
/*     */       }
/*     */       
/* 538 */       if (entry.getPrivateKey() == null) {
/* 539 */         entry.setAlias(alias);
/*     */         try
/*     */         {
/* 542 */           entry.setCertificateChain(chain);
/*     */         }
/*     */         catch (CertificateException ce) {
/* 545 */           throw new KeyStoreException(ce);
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 550 */       throw new UnsupportedOperationException(
/* 551 */         "Cannot assign the certificate to the given alias.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void engineDeleteEntry(String alias)
/*     */     throws KeyStoreException
/*     */   {
/* 566 */     if (alias == null) {
/* 567 */       throw new KeyStoreException("alias must not be null");
/*     */     }
/*     */     
/* 570 */     for (KeyEntry entry : this.entries) {
/* 571 */       if (alias.equals(entry.getAlias()))
/*     */       {
/*     */ 
/* 574 */         X509Certificate[] certChain = entry.getCertificateChain();
/* 575 */         if (certChain != null)
/*     */         {
/*     */           try
/*     */           {
/* 579 */             byte[] encoding = certChain[0].getEncoded();
/* 580 */             removeCertificate(getName(), alias, encoding, 
/* 581 */               encoding.length);
/*     */           }
/*     */           catch (CertificateEncodingException e) {
/* 584 */             throw new KeyStoreException("Cannot remove entry: " + 
/* 585 */               e);
/*     */           }
/*     */         }
/* 588 */         Key privateKey = entry.getPrivateKey();
/* 589 */         if (privateKey != null) {
/* 590 */           destroyKeyContainer(
/* 591 */             Key.getContainerName(privateKey.getHCryptProvider()));
/*     */         }
/*     */         
/* 594 */         this.entries.remove(entry);
/* 595 */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Enumeration engineAliases()
/*     */   {
/* 608 */     final Iterator iter = this.entries.iterator();
/*     */     
/* 610 */     new Enumeration()
/*     */     {
/*     */       public boolean hasMoreElements()
/*     */       {
/* 614 */         return iter.hasNext();
/*     */       }
/*     */       
/*     */       public Object nextElement()
/*     */       {
/* 619 */         KeyStore.KeyEntry entry = (KeyStore.KeyEntry)iter.next();
/* 620 */         return entry.getAlias();
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean engineContainsAlias(String alias)
/*     */   {
/* 634 */     Enumeration enumerator = engineAliases();
/* 635 */     while (enumerator.hasMoreElements())
/*     */     {
/* 637 */       String a = (String)enumerator.nextElement();
/*     */       
/* 639 */       if (a.equals(alias))
/* 640 */         return true;
/*     */     }
/* 642 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int engineSize()
/*     */   {
/* 652 */     return this.entries.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean engineIsKeyEntry(String alias)
/*     */   {
/* 665 */     if (alias == null) {
/* 666 */       return false;
/*     */     }
/*     */     
/* 669 */     for (KeyEntry entry : this.entries) {
/* 670 */       if (alias.equals(entry.getAlias())) {
/* 671 */         return entry.getPrivateKey() != null;
/*     */       }
/*     */     }
/*     */     
/* 675 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean engineIsCertificateEntry(String alias)
/*     */   {
/* 688 */     for (KeyEntry entry : this.entries) {
/* 689 */       if (alias.equals(entry.getAlias())) {
/* 690 */         return entry.getPrivateKey() == null;
/*     */       }
/*     */     }
/*     */     
/* 694 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String engineGetCertificateAlias(Certificate cert)
/*     */   {
/* 716 */     for (KeyEntry entry : this.entries) {
/* 717 */       if ((entry.certChain != null) && (entry.certChain[0].equals(cert))) {
/* 718 */         return entry.getAlias();
/*     */       }
/*     */     }
/*     */     
/* 722 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void engineStore(OutputStream stream, char[] password)
/*     */     throws IOException, NoSuchAlgorithmException, CertificateException
/*     */   {
/* 748 */     if ((stream != null) && (!this.keyStoreCompatibilityMode)) {
/* 749 */       throw new IOException("Keystore output stream must be null");
/*     */     }
/*     */     
/* 752 */     if ((password != null) && (!this.keyStoreCompatibilityMode)) {
/* 753 */       throw new IOException("Keystore password must be null");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void engineLoad(InputStream stream, char[] password)
/*     */     throws IOException, NoSuchAlgorithmException, CertificateException
/*     */   {
/* 788 */     if ((stream != null) && (!this.keyStoreCompatibilityMode)) {
/* 789 */       throw new IOException("Keystore input stream must be null");
/*     */     }
/*     */     
/* 792 */     if ((password != null) && (!this.keyStoreCompatibilityMode)) {
/* 793 */       throw new IOException("Keystore password must be null");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 799 */     SecurityManager sm = System.getSecurityManager();
/* 800 */     if (sm != null) {
/* 801 */       sm.checkPermission(new SecurityPermission(
/* 802 */         "authProvider.SunMSCAPI"));
/*     */     }
/*     */     
/*     */ 
/* 806 */     this.entries.clear();
/* 807 */     this.entriesCount = 0L;
/*     */     
/*     */ 
/* 810 */     loadKeysOrCertificateChains(getName(), this.entries);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void generateCertificateChain(String alias, Collection certCollection, Collection<KeyEntry> entries)
/*     */   {
/*     */     try
/*     */     {
/* 822 */       X509Certificate[] certChain = 
/* 823 */         new X509Certificate[certCollection.size()];
/*     */       
/* 825 */       int i = 0;
/* 826 */       for (Iterator iter = certCollection.iterator(); iter.hasNext(); i++)
/*     */       {
/* 828 */         certChain[i] = ((X509Certificate)iter.next());
/*     */       }
/*     */       
/* 831 */       KeyEntry entry = new KeyEntry(alias, null, certChain);
/*     */       
/*     */ 
/* 834 */       entries.add(entry);
/*     */     }
/*     */     catch (Throwable localThrowable) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void generateRSAKeyAndCertificateChain(String alias, long hCryptProv, long hCryptKey, int keyLength, Collection certCollection, Collection<KeyEntry> entries)
/*     */   {
/*     */     try
/*     */     {
/* 853 */       X509Certificate[] certChain = 
/* 854 */         new X509Certificate[certCollection.size()];
/*     */       
/* 856 */       int i = 0;
/* 857 */       for (Iterator iter = certCollection.iterator(); iter.hasNext(); i++)
/*     */       {
/* 859 */         certChain[i] = ((X509Certificate)iter.next());
/*     */       }
/*     */       
/* 862 */       KeyEntry entry = new KeyEntry(alias, new RSAPrivateKey(hCryptProv, 
/* 863 */         hCryptKey, keyLength), certChain);
/*     */       
/*     */ 
/* 866 */       entries.add(entry);
/*     */     }
/*     */     catch (Throwable localThrowable) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void generateCertificate(byte[] data, Collection certCollection)
/*     */   {
/*     */     try
/*     */     {
/* 885 */       ByteArrayInputStream bis = new ByteArrayInputStream(data);
/*     */       
/*     */ 
/* 888 */       if (this.certificateFactory == null) {
/* 889 */         this.certificateFactory = CertificateFactory.getInstance("X.509");
/*     */       }
/*     */       
/*     */ 
/* 893 */       Collection c = this.certificateFactory.generateCertificates(bis);
/* 894 */       certCollection.addAll(c);
/*     */     }
/*     */     catch (CertificateException localCertificateException) {}catch (Throwable localThrowable) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getName()
/*     */   {
/* 913 */     return this.storeName;
/*     */   }
/*     */   
/*     */   private native void loadKeysOrCertificateChains(String paramString, Collection<KeyEntry> paramCollection);
/*     */   
/*     */   private native void storeCertificate(String paramString1, String paramString2, byte[] paramArrayOfByte, int paramInt, long paramLong1, long paramLong2);
/*     */   
/*     */   private native void removeCertificate(String paramString1, String paramString2, byte[] paramArrayOfByte, int paramInt);
/*     */   
/*     */   private native void destroyKeyContainer(String paramString);
/*     */   
/*     */   private native byte[] generatePrivateKeyBlob(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4, byte[] paramArrayOfByte5, byte[] paramArrayOfByte6, byte[] paramArrayOfByte7, byte[] paramArrayOfByte8);
/*     */   
/*     */   private native RSAPrivateKey storePrivateKey(byte[] paramArrayOfByte, String paramString, int paramInt);
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mscapi\mityc\KeyStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */