/*     */ package es.mityc.javasign.pkstore.mitycstore.mantainer;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.pkstore.mitycstore.CertUtil;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.List;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CertTblModel
/*     */   extends AbstractTableModel
/*     */ {
/*  37 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*     */   
/*     */ 
/*     */ 
/*     */   public static enum SUBJECT_OR_ISSUER
/*     */   {
/*  43 */     SUBJECT, 
/*     */     
/*  45 */     ISSUER;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*  50 */   private String[] columnNames = null;
/*     */   
/*  52 */   private Object[][] data = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CertTblModel(List<X509Certificate> listCertificates)
/*     */   {
/*  60 */     this.columnNames = new String[3];
/*     */     
/*  62 */     this.columnNames[0] = I18N.getLocalMessage("i18n.mityc.cert.mityc.47");
/*     */     
/*  64 */     this.columnNames[1] = I18N.getLocalMessage("i18n.mityc.cert.mityc.48");
/*     */     
/*  66 */     this.columnNames[2] = I18N.getLocalMessage("i18n.mityc.cert.mityc.49");
/*  67 */     int rows = 0;
/*  68 */     if (listCertificates != null) {
/*  69 */       rows = listCertificates.size();
/*     */     }
/*  71 */     this.data = new Object[rows][4];
/*  72 */     SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
/*  73 */     X509Certificate certTemp = null;
/*  74 */     for (int a = 0; a < rows; a++) {
/*  75 */       certTemp = (X509Certificate)listCertificates.get(a);
/*     */       
/*     */ 
/*  78 */       this.data[a][0] = getName(certTemp, SUBJECT_OR_ISSUER.SUBJECT);
/*     */       
/*     */ 
/*  81 */       this.data[a][1] = getName(certTemp, SUBJECT_OR_ISSUER.ISSUER);
/*     */       
/*     */ 
/*  84 */       this.data[a][2] = sdf.format(certTemp.getNotAfter());
/*     */       
/*     */ 
/*  87 */       this.data[a][3] = certTemp;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/*  96 */     return this.columnNames.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRowCount()
/*     */   {
/* 104 */     return this.data.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getValueAt(int fil, int col)
/*     */   {
/* 114 */     return this.data[fil][col];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Certificate getCertificate(int row)
/*     */   {
/* 123 */     if ((row >= 0) && (row < getRowCount())) {
/* 124 */       return (X509Certificate)this.data[row][3];
/*     */     }
/* 126 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getColumnName(int col)
/*     */   {
/* 137 */     return this.columnNames[col];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> getColumnClass(int columnIndex)
/*     */   {
/* 147 */     return String.class;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getName(X509Certificate cert, SUBJECT_OR_ISSUER tipo)
/*     */   {
/* 159 */     String retorno = "";
/*     */     
/*     */ 
/* 162 */     if (tipo == SUBJECT_OR_ISSUER.ISSUER) {
/* 163 */       retorno = CertUtil.extractName(cert.getIssuerX500Principal());
/*     */     } else {
/* 165 */       retorno = CertUtil.extractName(cert.getSubjectX500Principal());
/*     */     }
/*     */     
/* 168 */     return retorno;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mitycstore\mantainer\CertTblModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */