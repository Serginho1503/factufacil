/*     */ package es.mityc.javasign.pkstore.mscapi.mityc;
/*     */ 
/*     */ import es.mityc.javasign.exception.CopyFileException;
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.pkstore.CertStoreException;
/*     */ import es.mityc.javasign.pkstore.IPKStoreManager;
/*     */ import es.mityc.javasign.pkstore.IPassStoreKS;
/*     */ import es.mityc.javasign.pkstore.keystore.KeyTool;
/*     */ import es.mityc.javasign.utils.CopyFilesTool;
/*     */ import java.io.IOException;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.Provider;
/*     */ import java.security.cert.CertPath;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MSCAPIMITyCStore
/*     */   implements IPKStoreManager
/*     */ {
/*     */   public static enum LocationStoreType
/*     */   {
/*  58 */     CurrentUser,  LocalMachine;
/*     */   }
/*     */   
/*  61 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*     */   
/*     */ 
/*     */   private static final String MY_STORE = "Windows-MY";
/*     */   
/*     */ 
/*     */   private static final String ROOT_STORE = "Windows-ROOT";
/*     */   
/*     */ 
/*     */   private static final String CA_STORE = "Windows-CA";
/*     */   
/*     */   private static final String LOCAL_MACHINE_MY_STORE = "Windows-LocalMachine-MY";
/*     */   
/*     */   private static final String LOCAL_MACHINE_ROOT_STORE = "Windows-LocalMachine-ROOT";
/*     */   
/*     */   private static final String LOCAL_MACHINE_CA_STORE = "Windows-LocalMachine-CA";
/*     */   
/*  78 */   private static boolean initialized = false;
/*     */   
/*     */ 
/*     */ 
/*     */   private IPassStoreKS passHandler;
/*     */   
/*     */ 
/*     */ 
/*     */   private LocationStoreType locationStore;
/*     */   
/*     */ 
/*     */ 
/*     */   public class NullPassStorePK
/*     */     implements IPassStoreKS
/*     */   {
/*     */     public NullPassStorePK() {}
/*     */     
/*     */ 
/*     */ 
/*     */     public char[] getPassword(X509Certificate certificate, String alias)
/*     */     {
/*  99 */       return new char[0];
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private synchronized void copyLibrary()
/*     */     throws CopyFileException
/*     */   {
/* 108 */     if (!initialized) {
/* 109 */       CopyFilesTool cft = new CopyFilesTool("libs/sunmscapimityc/MITyCLibCertJNI_sunmscapimityc.properties", getClass().getClassLoader());
/* 110 */       cft.copyFilesOS(null, "explorer", true);
/* 111 */       initialized = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MSCAPIMITyCStore(IPassStoreKS passStoreHandler)
/*     */     throws CertStoreException
/*     */   {
/* 123 */     this(passStoreHandler, LocationStoreType.CurrentUser);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MSCAPIMITyCStore(IPassStoreKS passStoreHandler, LocationStoreType location)
/*     */     throws CertStoreException
/*     */   {
/* 135 */     this.locationStore = location;
/*     */     try {
/* 137 */       copyLibrary();
/*     */     } catch (CopyFileException ex) {
/* 139 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapimityc.1"), ex);
/*     */     }
/* 141 */     if (passStoreHandler == null) {
/* 142 */       this.passHandler = new NullPassStorePK();
/*     */     } else {
/* 144 */       this.passHandler = passStoreHandler;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CertPath getCertPath(X509Certificate certificate)
/*     */     throws CertStoreException
/*     */   {
/* 156 */     throw new UnsupportedOperationException("Not implemented yet");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PrivateKey getPrivateKey(X509Certificate certificate)
/*     */     throws CertStoreException
/*     */   {
/*     */     try
/*     */     {
/* 173 */       String storeName = null;
/* 174 */       switch (this.locationStore) {
/*     */       case CurrentUser: 
/* 176 */         storeName = "Windows-MY";
/* 177 */         break;
/*     */       case LocalMachine: 
/* 179 */         storeName = "Windows-LocalMachine-MY";
/*     */       }
/*     */       
/*     */       
/* 183 */       KeyStore ks = KeyStore.getInstance(storeName, new SunMSCAPI_MITyC());
/* 184 */       ks.load(null, null);
/* 185 */       return KeyTool.findPrivateKey(ks, certificate, this.passHandler);
/*     */     }
/*     */     catch (KeyStoreException ex) {
/* 188 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.1", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (NoSuchAlgorithmException ex) {
/* 190 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.2", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (CertificateException ex) {
/* 192 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.3", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (IOException ex) {
/* 194 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.4", new Object[] { ex.getMessage(), ex }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Provider getProvider(X509Certificate certificate)
/*     */   {
/* 204 */     return new SunMSCAPI_MITyC();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<X509Certificate> getSignCertificates()
/*     */     throws CertStoreException
/*     */   {
/*     */     try
/*     */     {
/* 215 */       String storeName = null;
/* 216 */       switch (this.locationStore) {
/*     */       case CurrentUser: 
/* 218 */         storeName = "Windows-MY";
/* 219 */         break;
/*     */       case LocalMachine: 
/* 221 */         storeName = "Windows-LocalMachine-MY";
/*     */       }
/*     */       
/*     */       
/* 225 */       KeyStore ks = KeyStore.getInstance(storeName, new SunMSCAPI_MITyC());
/* 226 */       ks.load(null, null);
/* 227 */       return KeyTool.getCertificatesWithKeys(ks);
/*     */     } catch (KeyStoreException ex) {
/* 229 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.1", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (NoSuchAlgorithmException ex) {
/* 231 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.2", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (CertificateException ex) {
/* 233 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.3", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (IOException ex) {
/* 235 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.4", new Object[] { ex.getMessage(), ex }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<X509Certificate> getTrustCertificates()
/*     */     throws CertStoreException
/*     */   {
/*     */     try
/*     */     {
/* 247 */       String storeName = null;
/* 248 */       switch (this.locationStore) {
/*     */       case CurrentUser: 
/* 250 */         storeName = "Windows-ROOT";
/* 251 */         break;
/*     */       case LocalMachine: 
/* 253 */         storeName = "Windows-LocalMachine-ROOT";
/*     */       }
/*     */       
/*     */       
/* 257 */       KeyStore ks = KeyStore.getInstance(storeName, new SunMSCAPI_MITyC());
/* 258 */       ks.load(null, null);
/* 259 */       ArrayList<X509Certificate> lista = new ArrayList();
/* 260 */       lista.addAll(KeyTool.getTrustCertificates(ks));
/*     */       
/* 262 */       switch (this.locationStore) {
/*     */       case CurrentUser: 
/* 264 */         storeName = "Windows-CA";
/* 265 */         break;
/*     */       case LocalMachine: 
/* 267 */         storeName = "Windows-LocalMachine-CA";
/*     */       }
/*     */       
/*     */       
/* 271 */       ks = KeyStore.getInstance(storeName, new SunMSCAPI_MITyC());
/* 272 */       ks.load(null, null);
/* 273 */       lista.addAll(KeyTool.getTrustCertificates(ks));
/* 274 */       return lista;
/*     */     } catch (KeyStoreException ex) {
/* 276 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.1", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (NoSuchAlgorithmException ex) {
/* 278 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.2", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (CertificateException ex) {
/* 280 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.3", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (IOException ex) {
/* 282 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.4", new Object[] { ex.getMessage(), ex }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<X509Certificate> getPublicCertificates()
/*     */     throws CertStoreException
/*     */   {
/*     */     try
/*     */     {
/* 294 */       String storeName = null;
/* 295 */       switch (this.locationStore) {
/*     */       case CurrentUser: 
/* 297 */         storeName = "Windows-MY";
/* 298 */         break;
/*     */       case LocalMachine: 
/* 300 */         storeName = "Windows-LocalMachine-MY";
/*     */       }
/*     */       
/*     */       
/* 304 */       KeyStore ks = KeyStore.getInstance(storeName, new SunMSCAPI_MITyC());
/* 305 */       ks.load(null, null);
/* 306 */       return KeyTool.getCertificatesWithoutKeys(ks);
/*     */     } catch (KeyStoreException ex) {
/* 308 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.1", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (NoSuchAlgorithmException ex) {
/* 310 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.2", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (CertificateException ex) {
/* 312 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.3", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (IOException ex) {
/* 314 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.4", new Object[] { ex.getMessage(), ex }));
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mscapi\mityc\MSCAPIMITyCStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */