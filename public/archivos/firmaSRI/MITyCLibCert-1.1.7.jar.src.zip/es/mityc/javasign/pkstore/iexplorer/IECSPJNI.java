/*     */ package es.mityc.javasign.pkstore.iexplorer;
/*     */ 
/*     */ import es.mityc.javasign.utils.CopyFilesTool;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class IECSPJNI
/*     */ {
/*  36 */   private static final Log LOG = LogFactory.getLog(IECSPJNI.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public native byte[] signHash(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public native byte[][] getCertificatesInSystemStore(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public native String getIssuerDN(byte[] paramArrayOfByte);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public native byte[] getSerialNumber(byte[] paramArrayOfByte);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public native String getSubjectDn(byte[] paramArrayOfByte);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public native int getLastErrorCode();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IECSPJNI()
/*     */   {
/* 102 */     AccessController.doPrivileged(new PrivilegedAction() {
/*     */       public Object run() {
/* 104 */         String key = "DLLFirmaVC";
/*     */         try {
/* 106 */           System.loadLibrary(key);
/*     */         } catch (Throwable e) {
/* 108 */           IECSPJNI.LOG.debug("No se pudo cargar la instancia de la librería DLLFirmaVC: " + e.getMessage(), e);
/*     */           try
/*     */           {
/* 111 */             String random = new Long(System.currentTimeMillis()).toString();
/* 112 */             CopyFilesTool cft = new CopyFilesTool("libs/iexplorer/MITyCLibCertJNI_iexplorer.properties", getClass().getClassLoader());
/* 113 */             cft.copyFilesOS(null, "explorer", true, random);
/* 114 */             System.loadLibrary(key + random);
/*     */           } catch (Exception e2) {
/* 116 */             IECSPJNI.LOG.debug("No se pudo cargar definitivamente la instancia de la librería DLLFirmaVC: " + e2.getMessage(), e2);
/*     */           }
/*     */         }
/* 119 */         return null;
/*     */       }
/*     */     });
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\iexplorer\IECSPJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */