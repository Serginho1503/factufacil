/*     */ package es.mityc.javasign.pkstore.pkcs11;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.Principal;
/*     */ import java.security.Provider;
/*     */ import java.security.PublicKey;
/*     */ import java.security.SignatureException;
/*     */ import java.security.cert.CertificateEncodingException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateExpiredException;
/*     */ import java.security.cert.CertificateNotYetValidException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Date;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class P11CertificateProxy
/*     */   extends X509Certificate
/*     */ {
/*     */   private X509Certificate internalCert;
/*     */   private Provider provider;
/*     */   
/*     */   P11CertificateProxy(X509Certificate cert, Provider prov)
/*     */   {
/*  51 */     this.internalCert = cert;
/*  52 */     this.provider = prov;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void checkValidity()
/*     */     throws CertificateExpiredException, CertificateNotYetValidException
/*     */   {
/*  62 */     this.internalCert.checkValidity();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void checkValidity(Date date)
/*     */     throws CertificateExpiredException, CertificateNotYetValidException
/*     */   {
/*  74 */     this.internalCert.checkValidity(date);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBasicConstraints()
/*     */   {
/*  84 */     return this.internalCert.getBasicConstraints();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Principal getIssuerDN()
/*     */   {
/*  94 */     return this.internalCert.getIssuerDN();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean[] getIssuerUniqueID()
/*     */   {
/* 104 */     return this.internalCert.getIssuerUniqueID();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean[] getKeyUsage()
/*     */   {
/* 114 */     return this.internalCert.getKeyUsage();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getNotAfter()
/*     */   {
/* 124 */     return this.internalCert.getNotAfter();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getNotBefore()
/*     */   {
/* 134 */     return this.internalCert.getNotBefore();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BigInteger getSerialNumber()
/*     */   {
/* 144 */     return this.internalCert.getSerialNumber();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSigAlgName()
/*     */   {
/* 154 */     return this.internalCert.getSigAlgName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSigAlgOID()
/*     */   {
/* 164 */     return this.internalCert.getSigAlgOID();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getSigAlgParams()
/*     */   {
/* 174 */     return this.internalCert.getSigAlgParams();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getSignature()
/*     */   {
/* 184 */     return this.internalCert.getSignature();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Principal getSubjectDN()
/*     */   {
/* 194 */     return this.internalCert.getSubjectDN();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean[] getSubjectUniqueID()
/*     */   {
/* 204 */     return this.internalCert.getSubjectUniqueID();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getTBSCertificate()
/*     */     throws CertificateEncodingException
/*     */   {
/* 215 */     return this.internalCert.getTBSCertificate();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getVersion()
/*     */   {
/* 225 */     return this.internalCert.getVersion();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getEncoded()
/*     */     throws CertificateEncodingException
/*     */   {
/* 236 */     return this.internalCert.getEncoded();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PublicKey getPublicKey()
/*     */   {
/* 246 */     return this.internalCert.getPublicKey();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 256 */     return this.internalCert.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void verify(PublicKey key)
/*     */     throws CertificateException, NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException, SignatureException
/*     */   {
/* 271 */     this.internalCert.verify(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void verify(PublicKey key, String sigProvider)
/*     */     throws CertificateException, NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException, SignatureException
/*     */   {
/* 287 */     this.internalCert.verify(key, sigProvider);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<String> getCriticalExtensionOIDs()
/*     */   {
/* 297 */     return this.internalCert.getCriticalExtensionOIDs();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getExtensionValue(String oid)
/*     */   {
/* 308 */     return this.internalCert.getExtensionValue(oid);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<String> getNonCriticalExtensionOIDs()
/*     */   {
/* 318 */     return this.internalCert.getNonCriticalExtensionOIDs();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasUnsupportedCriticalExtension()
/*     */   {
/* 327 */     return this.internalCert.hasUnsupportedCriticalExtension();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Provider getProvider()
/*     */   {
/* 335 */     return this.provider;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Certificate getInternalCertificate()
/*     */   {
/* 343 */     return this.internalCert;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 353 */     return this.internalCert.hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 364 */     return this.internalCert.equals(other);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\pkcs11\P11CertificateProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */