/*     */ package es.mityc.javasign.pkstore.keystore;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.pkstore.CertStoreException;
/*     */ import es.mityc.javasign.pkstore.IPassStoreKS;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.UnrecoverableKeyException;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class KeyTool
/*     */ {
/*  46 */   private static final Log LOG = LogFactory.getLog(KeyTool.class);
/*     */   
/*  48 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*     */   
/*     */ 
/*  51 */   static final char[] EMPTY_STRING = "".toCharArray();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<X509Certificate> getCertificatesWithKeys(KeyStore ks)
/*     */     throws CertStoreException
/*     */   {
/*  60 */     return getCertificates(ks, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<X509Certificate> getCertificatesWithoutKeys(KeyStore ks)
/*     */     throws CertStoreException
/*     */   {
/*  70 */     return getCertificates(ks, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static List<X509Certificate> getCertificates(KeyStore ks, boolean getPrivates)
/*     */     throws CertStoreException
/*     */   {
/*     */     try
/*     */     {
/*  83 */       Enumeration<String> total = ks.aliases();
/*  84 */       ArrayList<X509Certificate> listaPrivada = new ArrayList();
/*  85 */       ArrayList<X509Certificate> listaPublica = new ArrayList();
/*  86 */       while (total.hasMoreElements()) {
/*  87 */         String alias = (String)total.nextElement();
/*  88 */         Certificate cert = ks.getCertificate(alias);
/*  89 */         if (ks.isKeyEntry(alias)) {
/*  90 */           if (LOG.isTraceEnabled()) {
/*  91 */             LOG.trace("Certificado con alias " + alias + " tiene un key asociada");
/*     */           }
/*     */           
/*  94 */           if ((cert instanceof X509Certificate)) {
/*  95 */             listaPrivada.add((X509Certificate)cert);
/*     */           }
/*     */         } else {
/*  98 */           if (LOG.isTraceEnabled()) {
/*  99 */             LOG.trace("Certificado con alias " + alias + " no tiene un key asociada");
/*     */           }
/*     */           
/* 102 */           if ((cert instanceof X509Certificate)) {
/* 103 */             listaPublica.add((X509Certificate)cert);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 108 */       if (getPrivates) {
/* 109 */         return listaPrivada;
/*     */       }
/* 111 */       return listaPublica;
/*     */     }
/*     */     catch (KeyStoreException ex) {
/* 114 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.ks.1", new Object[] { ks.getType(), ex.getMessage(), ex }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PrivateKey findPrivateKey(KeyStore ks, X509Certificate certificate, IPassStoreKS passHandler, char[] nullPassword)
/*     */     throws CertStoreException
/*     */   {
/*     */     try
/*     */     {
/* 136 */       String alias = ks.getCertificateAlias(certificate);
/* 137 */       if (!ks.isKeyEntry(alias)) {
/* 138 */         LOG.trace("Certificado con alias " + alias + " no tiene clave. Se procede a búsqueda de todos los certificados con clave.");
/*     */         try {
/* 140 */           Enumeration<String> total = ks.aliases();
/* 141 */           while (total.hasMoreElements()) {
/* 142 */             String keyAlias = (String)total.nextElement();
/* 143 */             if (ks.isKeyEntry(keyAlias)) {
/* 144 */               Certificate cert = ks.getCertificate(keyAlias);
/* 145 */               if (((cert instanceof X509Certificate)) && 
/* 146 */                 (cert.equals(certificate))) {
/* 147 */                 alias = keyAlias;
/* 148 */                 LOG.trace("Certificado con clave coincide con certificado buscado: " + alias);
/* 149 */                 break;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         catch (KeyStoreException ex) {
/* 155 */           throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.ks.1", new Object[] { ex.getMessage(), ex }));
/*     */         }
/*     */       }
/* 158 */       if (alias == null) {
/* 159 */         throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.ks.6"));
/*     */       }
/*     */       
/* 162 */       if (LOG.isTraceEnabled()) {
/* 163 */         LOG.trace("Pidiendo key asociado al alias " + alias);
/*     */       }
/* 165 */       PrivateKey resultado = null;
/*     */       try {
/* 167 */         resultado = (PrivateKey)ks.getKey(alias, nullPassword);
/*     */       } catch (UnrecoverableKeyException e) {
/* 169 */         char[] passwd = passHandler.getPassword(certificate, alias);
/* 170 */         resultado = (PrivateKey)ks.getKey(alias, passwd);
/*     */       }
/* 172 */       if (resultado == null) {
/* 173 */         throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.ks.5"));
/*     */       }
/* 175 */       return resultado;
/*     */     }
/*     */     catch (KeyStoreException ex) {
/* 178 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.ks.1", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (NoSuchAlgorithmException ex) {
/* 180 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.ks.2", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (UnrecoverableKeyException ex) {
/* 182 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.ks.4", new Object[] { ex.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PrivateKey findPrivateKey(KeyStore ks, X509Certificate certificate, IPassStoreKS passHandler)
/*     */     throws CertStoreException
/*     */   {
/* 204 */     return findPrivateKey(ks, certificate, passHandler, EMPTY_STRING);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<X509Certificate> getTrustCertificates(KeyStore ks)
/*     */     throws CertStoreException
/*     */   {
/*     */     try
/*     */     {
/* 215 */       Enumeration<String> total = ks.aliases();
/* 216 */       ArrayList<X509Certificate> lista = new ArrayList();
/* 217 */       while (total.hasMoreElements()) {
/* 218 */         String alias = (String)total.nextElement();
/* 219 */         if ((ks.isCertificateEntry(alias)) && (!ks.isKeyEntry(alias))) {
/* 220 */           Certificate cert = ks.getCertificate(alias);
/* 221 */           if ((cert instanceof X509Certificate)) {
/* 222 */             lista.add((X509Certificate)cert);
/*     */           }
/*     */         }
/*     */       }
/* 226 */       return lista;
/*     */     } catch (KeyStoreException ex) {
/* 228 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.ks.1", new Object[] { ex.getMessage(), ex }));
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\keystore\KeyTool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */