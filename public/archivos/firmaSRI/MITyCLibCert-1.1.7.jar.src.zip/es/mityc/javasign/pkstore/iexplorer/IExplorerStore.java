/*     */ package es.mityc.javasign.pkstore.iexplorer;
/*     */ 
/*     */ import es.mityc.javasign.exception.CopyFileException;
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.pkstore.CertStoreException;
/*     */ import es.mityc.javasign.pkstore.IPKStoreManager;
/*     */ import es.mityc.javasign.utils.CopyFilesTool;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.Provider;
/*     */ import java.security.cert.CertPath;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IExplorerStore
/*     */   implements IPKStoreManager
/*     */ {
/*  46 */   private static final Log LOG = LogFactory.getLog(IExplorerStore.class);
/*     */   
/*  48 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*     */   
/*     */ 
/*  51 */   private static IECSPJNI cspBridge = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public IExplorerStore()
/*     */   {
/*  57 */     loadLibrary();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void copyLibrary()
/*     */     throws CopyFileException
/*     */   {
/*  65 */     CopyFilesTool cft = new CopyFilesTool("libs/iexplorer/MITyCLibCertJNI_iexplorer.properties", getClass().getClassLoader());
/*  66 */     cft.copyFilesOS(null, "explorer", true);
/*     */   }
/*     */   
/*     */ 
/*     */   private synchronized void loadLibrary()
/*     */   {
/*     */     try
/*     */     {
/*  74 */       if (cspBridge == null) {
/*  75 */         copyLibrary();
/*  76 */         cspBridge = new IECSPJNI();
/*     */       }
/*     */     } catch (Exception ex) {
/*  79 */       LOG.fatal(I18N.getLocalMessage("i18n.mityc.cert.ie.1", new Object[] { ex.getMessage() }));
/*  80 */       if (LOG.isDebugEnabled()) {
/*  81 */         LOG.error("", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CertPath getCertPath(X509Certificate certificate)
/*     */     throws CertStoreException
/*     */   {
/*  97 */     throw new UnsupportedOperationException("Not implemented yet");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PrivateKey getPrivateKey(X509Certificate certificate)
/*     */     throws CertStoreException
/*     */   {
/* 108 */     return new PKProxyIE(certificate);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Provider getProvider(X509Certificate cert)
/*     */   {
/* 119 */     return new MITyCMSProvider();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<X509Certificate> getSignCertificates()
/*     */     throws CertStoreException
/*     */   {
/* 129 */     ArrayList<X509Certificate> allCerts = new ArrayList();
/* 130 */     if (cspBridge != null) {
/* 131 */       byte[][] bCertificados = cspBridge.getCertificatesInSystemStore("MY");
/* 132 */       for (int i = 0; i < bCertificados.length; i++) {
/* 133 */         byte[] bc = bCertificados[i];
/*     */         
/*     */ 
/*     */         try
/*     */         {
/* 138 */           CertificateFactory cfTemporal = CertificateFactory.getInstance("X.509");
/* 139 */           X509Certificate certX509Temporal = 
/* 140 */             (X509Certificate)cfTemporal.generateCertificate(
/* 141 */             new ByteArrayInputStream(bc));
/* 142 */           allCerts.add(certX509Temporal);
/*     */         }
/*     */         catch (CertificateException ex) {
/* 145 */           LOG.error(ex.getMessage(), ex);
/*     */         }
/*     */       }
/*     */     }
/* 149 */     return allCerts;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<X509Certificate> getTrustCertificates()
/*     */     throws CertStoreException
/*     */   {
/* 161 */     throw new UnsupportedOperationException("Not implemented yet");
/*     */   }
/*     */   
/*     */   public List<X509Certificate> getPublicCertificates() throws CertStoreException
/*     */   {
/* 166 */     throw new UnsupportedOperationException("Not implemented yet");
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\iexplorer\IExplorerStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */