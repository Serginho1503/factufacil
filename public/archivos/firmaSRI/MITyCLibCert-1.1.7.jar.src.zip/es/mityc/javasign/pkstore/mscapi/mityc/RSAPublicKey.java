/*     */ package es.mityc.javasign.pkstore.mscapi.mityc;
/*     */ 
/*     */ import java.io.ObjectStreamException;
/*     */ import java.math.BigInteger;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.KeyRep;
/*     */ import java.security.KeyRep.Type;
/*     */ import sun.security.rsa.RSAPublicKeyImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RSAPublicKey
/*     */   extends Key
/*     */   implements java.security.interfaces.RSAPublicKey
/*     */ {
/*  41 */   private byte[] publicKeyBlob = null;
/*  42 */   private byte[] encoding = null;
/*  43 */   private BigInteger modulus = null;
/*  44 */   private BigInteger exponent = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   RSAPublicKey(long hCryptProv, long hCryptKey, int keyLength)
/*     */   {
/*  51 */     super(hCryptProv, hCryptKey, keyLength);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAlgorithm()
/*     */   {
/*  67 */     return "RSA";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  76 */     StringBuffer sb = new StringBuffer();
/*     */     
/*  78 */     sb.append("RSAPublicKey [size=").append(this.keyLength)
/*  79 */       .append(" bits, type=").append(getKeyType(this.hCryptKey))
/*  80 */       .append(", container=").append(getContainerName(this.hCryptProv))
/*  81 */       .append("]\n  modulus: ").append(getModulus())
/*  82 */       .append("\n  public exponent: ").append(getPublicExponent());
/*     */     
/*  84 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public BigInteger getPublicExponent()
/*     */   {
/*  92 */     if (this.exponent == null) {
/*  93 */       this.publicKeyBlob = getPublicKeyBlob(this.hCryptKey);
/*     */       
/*  95 */       this.exponent = new BigInteger(getExponent(this.publicKeyBlob));
/*     */     }
/*     */     
/*  98 */     return this.exponent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public BigInteger getModulus()
/*     */   {
/* 106 */     if (this.modulus == null) {
/* 107 */       this.publicKeyBlob = getPublicKeyBlob(this.hCryptKey);
/* 108 */       this.modulus = new BigInteger(getModulus(this.publicKeyBlob));
/*     */     }
/*     */     
/* 111 */     return this.modulus;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFormat()
/*     */   {
/* 134 */     return "X.509";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getEncoded()
/*     */   {
/* 147 */     if (this.encoding == null) {
/*     */       try
/*     */       {
/* 150 */         this.encoding = new RSAPublicKeyImpl(getModulus(), 
/* 151 */           getPublicExponent()).getEncoded();
/*     */       }
/*     */       catch (InvalidKeyException localInvalidKeyException) {}
/*     */     }
/*     */     
/*     */ 
/* 157 */     return this.encoding;
/*     */   }
/*     */   
/*     */   protected Object writeReplace() throws ObjectStreamException {
/* 161 */     return new KeyRep(KeyRep.Type.PUBLIC, 
/* 162 */       getAlgorithm(), 
/* 163 */       getFormat(), 
/* 164 */       getEncoded());
/*     */   }
/*     */   
/*     */   private native byte[] getPublicKeyBlob(long paramLong);
/*     */   
/*     */   private native byte[] getExponent(byte[] paramArrayOfByte);
/*     */   
/*     */   private native byte[] getModulus(byte[] paramArrayOfByte);
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mscapi\mityc\RSAPublicKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */