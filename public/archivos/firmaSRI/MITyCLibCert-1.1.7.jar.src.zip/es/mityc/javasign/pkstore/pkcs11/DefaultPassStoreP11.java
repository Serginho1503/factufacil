/*    */ package es.mityc.javasign.pkstore.pkcs11;
/*    */ 
/*    */ import es.mityc.javasign.pkstore.DefaultPassStoreKS;
/*    */ import java.security.cert.X509Certificate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultPassStoreP11
/*    */   extends DefaultPassStoreKS
/*    */ {
/*    */   protected void processData(X509Certificate certificate, String alias)
/*    */   {
/* 37 */     if (alias != null) {
/* 38 */       setPINMessage(alias);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\pkcs11\DefaultPassStoreP11.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */