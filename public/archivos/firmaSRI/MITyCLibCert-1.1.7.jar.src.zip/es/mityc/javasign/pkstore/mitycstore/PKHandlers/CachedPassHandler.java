/*    */ package es.mityc.javasign.pkstore.mitycstore.PKHandlers;
/*    */ 
/*    */ import es.mityc.javasign.i18n.I18nFactory;
/*    */ import es.mityc.javasign.i18n.II18nManager;
/*    */ import es.mityc.javasign.pkstore.DefaultPassStoreKS;
/*    */ import es.mityc.javasign.pkstore.mitycstore.CertUtil;
/*    */ import java.security.cert.X509Certificate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CachedPassHandler
/*    */   extends DefaultPassStoreKS
/*    */ {
/* 34 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*    */   
/*    */ 
/* 37 */   private String pinMessage = I18N.getLocalMessage("i18n.mityc.cert.smartcards.GUI.pin");
/*    */   
/*    */ 
/* 40 */   private transient char[] pass = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public char[] getPassword(X509Certificate certificate, String alias)
/*    */   {
/* 55 */     if (this.pass == null) {
/* 56 */       this.pass = super.getPassword(certificate, alias);
/*    */     }
/*    */     
/* 59 */     return this.pass;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void processData(X509Certificate certificate, String alias)
/*    */   {
/* 70 */     if ((certificate == null) && (alias == null))
/*    */     {
/* 72 */       setPINMessage(I18N.getLocalMessage("i18n.mityc.cert.mityc.86"));
/* 73 */       setCancelBtnVisible(false);
/* 74 */     } else if (alias != null) {
/* 75 */       setPINMessage(this.pinMessage + " " + alias);
/*    */     } else {
/* 77 */       setPINMessage(this.pinMessage + " " + CertUtil.extractName(certificate.getSubjectX500Principal()));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void reset()
/*    */   {
/* 85 */     this.pass = null;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mitycstore\PKHandlers\CachedPassHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */