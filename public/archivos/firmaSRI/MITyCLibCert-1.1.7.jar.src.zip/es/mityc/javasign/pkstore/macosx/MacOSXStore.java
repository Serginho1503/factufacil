/*     */ package es.mityc.javasign.pkstore.macosx;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.pkstore.CertStoreException;
/*     */ import es.mityc.javasign.pkstore.IPKStoreManager;
/*     */ import es.mityc.javasign.pkstore.IPassStoreKS;
/*     */ import es.mityc.javasign.pkstore.NullPassStorePK;
/*     */ import es.mityc.javasign.pkstore.keystore.KSStore;
/*     */ import es.mityc.javasign.pkstore.mozilla.MozillaStoreUtils;
/*     */ import java.io.IOException;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.Provider;
/*     */ import java.security.Provider.Service;
/*     */ import java.security.Security;
/*     */ import java.security.cert.CertPath;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MacOSXStore
/*     */   implements IPKStoreManager
/*     */ {
/*  54 */   private static final Log LOG = LogFactory.getLog(MozillaStoreUtils.class);
/*     */   
/*  56 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*     */   
/*     */ 
/*     */   private static final String APPLE_KEYSTORE = "Apple";
/*     */   
/*     */ 
/*     */   private static final String SUN_KEYSTORE = "SunRsaSign";
/*     */   
/*  64 */   private static final char[] APPLE_EMPTY_STRING = "-".toCharArray();
/*     */   
/*     */ 
/*     */   private IPKStoreManager pkStore;
/*     */   
/*     */ 
/*     */ 
/*     */   public MacOSXStore()
/*     */     throws CertStoreException
/*     */   {
/*  74 */     this(new NullPassStorePK());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MacOSXStore(IPassStoreKS passwordHandler)
/*     */     throws CertStoreException
/*     */   {
/*     */     try
/*     */     {
/*  85 */       KeyStore appleKs = KeyStore.getInstance("KeychainStore", "Apple");
/*  86 */       appleKs.load(null, null);
/*  87 */       this.pkStore = new KSStore(appleKs, passwordHandler, APPLE_EMPTY_STRING);
/*     */       
/*  89 */       if (LOG.isDebugEnabled()) {
/*  90 */         Iterator<Provider.Service> services = Security.getProvider("SunRsaSign").getServices().iterator();
/*  91 */         LOG.debug("Servicios disponibles: ");
/*  92 */         while (services.hasNext()) {
/*  93 */           Provider.Service ser = (Provider.Service)services.next();
/*  94 */           LOG.debug(ser);
/*  95 */           LOG.debug("Algoritmo disponible: " + ser.getAlgorithm());
/*     */         }
/*     */       }
/*     */       
/*  99 */       if (LOG.isDebugEnabled()) {
/* 100 */         Iterator<Provider.Service> services = Security.getProvider("Apple").getServices().iterator();
/* 101 */         LOG.debug("Servicios disponibles: ");
/* 102 */         while (services.hasNext()) {
/* 103 */           Provider.Service ser = (Provider.Service)services.next();
/* 104 */           LOG.debug(ser);
/* 105 */           LOG.debug("Algoritmo disponible: " + ser.getAlgorithm());
/*     */         }
/*     */       }
/*     */     } catch (NoSuchProviderException ex) {
/* 109 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.macosx.1", new Object[] { ex.getMessage() }), ex);
/*     */     } catch (KeyStoreException ex) {
/* 111 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.macosx.1", new Object[] { ex.getMessage() }), ex);
/*     */     } catch (NoSuchAlgorithmException ex) {
/* 113 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.macosx.1", new Object[] { ex.getMessage() }), ex);
/*     */     } catch (CertificateException ex) {
/* 115 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.macosx.1", new Object[] { ex.getMessage() }), ex);
/*     */     } catch (IOException ex) {
/* 117 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.macosx.1", new Object[] { ex.getMessage() }), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Provider getProvider(X509Certificate cert)
/*     */   {
/* 127 */     return Security.getProvider("SunRsaSign");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CertPath getCertPath(X509Certificate certificate)
/*     */     throws CertStoreException
/*     */   {
/* 138 */     return this.pkStore != null ? this.pkStore.getCertPath(certificate) : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PrivateKey getPrivateKey(X509Certificate certificate)
/*     */     throws CertStoreException
/*     */   {
/* 149 */     return this.pkStore != null ? this.pkStore.getPrivateKey(certificate) : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<X509Certificate> getSignCertificates()
/*     */     throws CertStoreException
/*     */   {
/* 158 */     return this.pkStore != null ? this.pkStore.getSignCertificates() : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<X509Certificate> getTrustCertificates()
/*     */     throws CertStoreException
/*     */   {
/* 167 */     return this.pkStore != null ? this.pkStore.getTrustCertificates() : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<X509Certificate> getPublicCertificates()
/*     */     throws CertStoreException
/*     */   {
/* 175 */     return this.pkStore != null ? this.pkStore.getPublicCertificates() : null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\macosx\MacOSXStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */