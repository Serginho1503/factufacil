/*     */ package es.mityc.javasign.pkstore.mitycstore.mantainer;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.pkstore.CertStoreException;
/*     */ import es.mityc.javasign.pkstore.IPKStoreMaintainer;
/*     */ import es.mityc.javasign.pkstore.IPKStoreManager;
/*     */ import es.mityc.javasign.pkstore.mitycstore.PKHandlers.PlainPassHandler;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.Frame;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.datatransfer.DataFlavor;
/*     */ import java.awt.datatransfer.Transferable;
/*     */ import java.awt.datatransfer.UnsupportedFlavorException;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.InputEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStore.PasswordProtection;
/*     */ import java.security.KeyStore.PrivateKeyEntry;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.UnrecoverableEntryException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.ActionMap;
/*     */ import javax.swing.InputMap;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.KeyStroke;
/*     */ import javax.swing.ListSelectionModel;
/*     */ import javax.swing.TransferHandler;
/*     */ import javax.swing.border.TitledBorder;
/*     */ import javax.swing.event.ListSelectionEvent;
/*     */ import javax.swing.event.ListSelectionListener;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import javax.swing.table.TableModel;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KSManagerPanel
/*     */   extends JPanel
/*     */ {
/*  88 */   private static final Log LOG = LogFactory.getLog(KSManagerDialog.class);
/*     */   
/*  90 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*     */   
/*     */ 
/*  93 */   private IPKStoreManager pksm = null;
/*     */   
/*  95 */   private IPKStoreMaintainer pksma = null;
/*     */   
/*     */ 
/*  98 */   private List<X509Certificate> signCerts = new ArrayList();
/*     */   
/* 100 */   private List<X509Certificate> authCerts = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/* 104 */   private JPanel signPanel = null;
/*     */   
/* 106 */   private JPanel authPanel = null;
/*     */   
/* 108 */   private JPanel prefPanel = null;
/*     */   
/* 110 */   private JTabbedPane tabs = null;
/*     */   
/* 112 */   private JScrollPane scrollPaneSign = null;
/*     */   
/* 114 */   private JScrollPane scrollPaneAuth = null;
/*     */   
/* 116 */   private JTable signCrtTbl = null;
/*     */   
/* 118 */   private JTable authCrtTbl = null;
/*     */   
/* 120 */   private JButton updateSignBtn = null;
/*     */   
/* 122 */   private JButton deleteSignBtn = null;
/*     */   
/* 124 */   private JButton addSignBtn = null;
/*     */   
/* 126 */   private JButton updateAuthBtn = null;
/*     */   
/* 128 */   private JButton deleteAuthBtn = null;
/*     */   
/* 130 */   private JButton addAuthBtn = null;
/*     */   
/* 132 */   private JButton showPreferences = null;
/*     */   
/*     */ 
/* 135 */   private DialogoCert dc = null;
/*     */   
/*     */ 
/* 138 */   private Frame ownerFrame = null;
/*     */   
/*     */ 
/* 141 */   private KSManagerPanel ksmp = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public static enum ACTION_FOR
/*     */   {
/* 147 */     SIGN, 
/*     */     
/* 149 */     AUTH;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KSManagerPanel(Frame owner, IPKStoreManager pksManager, IPKStoreMaintainer pksMaintainer)
/*     */   {
/* 161 */     this.ownerFrame = owner;
/* 162 */     this.pksm = pksManager;
/* 163 */     this.pksma = pksMaintainer;
/* 164 */     loadKeyStore();
/* 165 */     panelInit();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSignCertificates(List<X509Certificate> certs)
/*     */   {
/* 173 */     this.signCerts = certs;
/* 174 */     this.signCrtTbl.setModel(new CertTblModel(certs));
/* 175 */     repaint();
/*     */     
/* 177 */     this.ksmp = this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAuthCertificates(List<X509Certificate> certs)
/*     */   {
/* 185 */     this.authCerts = certs;
/* 186 */     this.authCrtTbl.setModel(new CertTblModel(certs));
/* 187 */     repaint();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void panelInit()
/*     */   {
/* 195 */     Action cancelAction = new AbstractAction("cancel") {
/*     */       public void actionPerformed(ActionEvent e) {
/* 197 */         KSManagerPanel.this.signCrtTbl.clearSelection();
/* 198 */         KSManagerPanel.this.authCrtTbl.clearSelection();
/*     */       }
/*     */       
/* 201 */     };
/* 202 */     Action showInfo = new AbstractAction("showInfo") {
/*     */       public void actionPerformed(ActionEvent e) {
/* 204 */         JTable source = (JTable)e.getSource();
/* 205 */         X509Certificate cert = ((CertTblModel)source.getModel()).getCertificate(source.getSelectedRow());
/* 206 */         KSManagerPanel.this.dc.muestraInfo(cert);
/*     */       }
/*     */       
/*     */ 
/* 210 */     };
/* 211 */     this.dc = new DialogoCert(this.ownerFrame);
/*     */     
/*     */ 
/* 214 */     this.signPanel = new JPanel();
/* 215 */     this.authPanel = new JPanel();
/* 216 */     this.prefPanel = new JPanel();
/*     */     
/*     */ 
/* 219 */     this.tabs = new JTabbedPane();
/*     */     
/* 221 */     this.tabs.addTab(I18N.getLocalMessage("i18n.mityc.cert.mityc.67"), this.signPanel);
/*     */     
/* 223 */     this.tabs.addTab(I18N.getLocalMessage("i18n.mityc.cert.mityc.68"), this.authPanel);
/*     */     
/*     */ 
/* 226 */     this.signCrtTbl = new JTable();
/* 227 */     this.signCrtTbl.setDefaultRenderer(Object.class, new CertCellRenderer());
/* 228 */     this.signCrtTbl.setSelectionMode(0);
/* 229 */     this.signCrtTbl.setPreferredScrollableViewportSize(new Dimension(500, 200));
/* 230 */     this.signCrtTbl.setModel(new CertTblModel(this.signCerts));
/* 231 */     this.signCrtTbl.setAutoResizeMode(4);
/* 232 */     this.signCrtTbl.getColumnModel().getColumn(2).setPreferredWidth(100);
/* 233 */     this.signCrtTbl.getColumnModel().getColumn(2).setMaxWidth(100);
/* 234 */     this.signCrtTbl.getColumnModel().getColumn(2).setMinWidth(100);
/* 235 */     this.signCrtTbl.getColumnModel().getColumn(2).setWidth(100);
/* 236 */     this.scrollPaneSign = new JScrollPane(this.signCrtTbl);
/* 237 */     this.signCrtTbl.getActionMap().put(showInfo.getValue("Name"), showInfo);
/* 238 */     this.signCrtTbl.getActionMap().put(cancelAction.getValue("Name"), cancelAction);
/* 239 */     this.signCrtTbl.getInputMap().put(KeyStroke.getKeyStroke(10, 0), showInfo.getValue("Name"));
/* 240 */     this.signCrtTbl.getInputMap().put(KeyStroke.getKeyStroke(27, 0), cancelAction.getValue("Name"));
/* 241 */     this.signCrtTbl.addMouseListener(new MouseAdapter()
/*     */     {
/*     */       public void mouseClicked(MouseEvent evt) {
/* 244 */         if (evt.getClickCount() == 2) {
/* 245 */           X509Certificate cert = ((CertTblModel)KSManagerPanel.this.signCrtTbl.getModel()).getCertificate(KSManagerPanel.this.signCrtTbl.getSelectedRow());
/* 246 */           KSManagerPanel.this.dc.muestraInfo(cert);
/*     */         }
/*     */       }
/* 249 */     });
/* 250 */     this.signCrtTbl.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
/*     */       public void valueChanged(ListSelectionEvent e) {
/* 252 */         X509Certificate cert = ((CertTblModel)KSManagerPanel.this.signCrtTbl.getModel()).getCertificate(KSManagerPanel.this.signCrtTbl.getSelectedRow());
/* 253 */         KSManagerPanel.this.deleteSignBtn.setEnabled(KSManagerPanel.this.pksma.isDeletable(cert));
/*     */       }
/*     */       
/*     */ 
/* 257 */     });
/* 258 */     this.authCrtTbl = new JTable();
/* 259 */     this.authCrtTbl.setDefaultRenderer(Object.class, new CertCellRenderer());
/* 260 */     this.authCrtTbl.setSelectionMode(0);
/* 261 */     this.authCrtTbl.setPreferredScrollableViewportSize(new Dimension(500, 200));
/* 262 */     this.authCrtTbl.setModel(new CertTblModel(this.authCerts));
/* 263 */     this.authCrtTbl.setAutoResizeMode(4);
/* 264 */     this.authCrtTbl.getColumnModel().getColumn(2).setPreferredWidth(100);
/* 265 */     this.authCrtTbl.getColumnModel().getColumn(2).setMaxWidth(100);
/* 266 */     this.authCrtTbl.getColumnModel().getColumn(2).setMinWidth(100);
/* 267 */     this.authCrtTbl.getColumnModel().getColumn(2).setWidth(100);
/* 268 */     this.scrollPaneAuth = new JScrollPane(this.authCrtTbl);
/* 269 */     this.authCrtTbl.getActionMap().put(showInfo.getValue("Name"), showInfo);
/* 270 */     this.authCrtTbl.getActionMap().put(cancelAction.getValue("Name"), cancelAction);
/* 271 */     this.authCrtTbl.getInputMap().put(KeyStroke.getKeyStroke(10, 0), showInfo.getValue("Name"));
/* 272 */     this.authCrtTbl.getInputMap().put(KeyStroke.getKeyStroke(10, 0), showInfo.getValue("Name"));
/* 273 */     this.authCrtTbl.getInputMap().put(KeyStroke.getKeyStroke(27, 0), cancelAction.getValue("Name"));
/* 274 */     this.authCrtTbl.addMouseListener(new MouseAdapter()
/*     */     {
/*     */       public void mouseClicked(MouseEvent evt) {
/* 277 */         if (evt.getClickCount() == 2) {
/* 278 */           X509Certificate cert = ((CertTblModel)KSManagerPanel.this.authCrtTbl.getModel()).getCertificate(KSManagerPanel.this.authCrtTbl.getSelectedRow());
/* 279 */           KSManagerPanel.this.dc.muestraInfo(cert);
/*     */         }
/*     */       }
/* 282 */     });
/* 283 */     this.authCrtTbl.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
/*     */       public void valueChanged(ListSelectionEvent e) {
/* 285 */         X509Certificate cert = ((CertTblModel)KSManagerPanel.this.authCrtTbl.getModel()).getCertificate(KSManagerPanel.this.authCrtTbl.getSelectedRow());
/* 286 */         KSManagerPanel.this.deleteAuthBtn.setEnabled(KSManagerPanel.this.pksma.isDeletable(cert));
/*     */ 
/*     */       }
/*     */       
/*     */ 
/* 291 */     });
/* 292 */     this.updateSignBtn = new JButton(I18N.getLocalMessage("i18n.mityc.cert.mityc.69"));
/* 293 */     this.updateSignBtn.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 295 */         KSManagerPanel.this.jButtonUpdateActionPerformed(KSManagerPanel.ACTION_FOR.SIGN);
/*     */       }
/*     */       
/* 298 */     });
/* 299 */     this.deleteSignBtn = new JButton(I18N.getLocalMessage("i18n.mityc.cert.mityc.70"));
/* 300 */     this.deleteSignBtn.setEnabled(false);
/* 301 */     this.deleteSignBtn.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 303 */         KSManagerPanel.this.jButtonDelActionPerformed(KSManagerPanel.ACTION_FOR.SIGN);
/*     */       }
/*     */       
/* 306 */     });
/* 307 */     this.addSignBtn = new JButton(I18N.getLocalMessage("i18n.mityc.cert.mityc.71"));
/* 308 */     this.addSignBtn.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 310 */         KSManagerPanel.this.jButtonAddActionPerformed(KSManagerPanel.ACTION_FOR.SIGN);
/*     */       }
/*     */       
/*     */ 
/* 314 */     });
/* 315 */     this.updateAuthBtn = new JButton(I18N.getLocalMessage("i18n.mityc.cert.mityc.69"));
/* 316 */     this.updateAuthBtn.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 318 */         KSManagerPanel.this.jButtonUpdateActionPerformed(KSManagerPanel.ACTION_FOR.AUTH);
/*     */       }
/* 320 */     });
/* 321 */     this.updateAuthBtn.setEnabled(false);
/*     */     
/*     */ 
/* 324 */     this.deleteAuthBtn = new JButton(I18N.getLocalMessage("i18n.mityc.cert.mityc.70"));
/* 325 */     this.deleteAuthBtn.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 327 */         KSManagerPanel.this.jButtonDelActionPerformed(KSManagerPanel.ACTION_FOR.AUTH);
/*     */       }
/*     */       
/*     */ 
/* 331 */     });
/* 332 */     this.addAuthBtn = new JButton(I18N.getLocalMessage("i18n.mityc.cert.mityc.71"));
/* 333 */     this.addAuthBtn.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 335 */         KSManagerPanel.this.jButtonAddActionPerformed(KSManagerPanel.ACTION_FOR.AUTH);
/*     */       }
/*     */       
/*     */ 
/* 339 */     });
/* 340 */     this.showPreferences = new JButton(I18N.getLocalMessage("i18n.mityc.cert.mityc.84"));
/* 341 */     this.showPreferences.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 343 */         KSManagerPanel.this.jButtonShowPrefActionPerformed();
/*     */       }
/*     */       
/*     */ 
/* 347 */     });
/* 348 */     this.signPanel.setTransferHandler(new DragDropHandler(null));
/* 349 */     this.signCrtTbl.setDragEnabled(false);
/*     */     
/* 351 */     this.authPanel.setTransferHandler(new DragDropHandler(null));
/* 352 */     this.authCrtTbl.setDragEnabled(false);
/*     */     
/*     */ 
/* 355 */     this.signPanel.setLayout(new GridBagLayout());
/*     */     
/* 357 */     GridBagConstraints signTblGrid = new GridBagConstraints();
/* 358 */     signTblGrid.gridx = 0;
/* 359 */     signTblGrid.gridy = 0;
/* 360 */     signTblGrid.gridwidth = 6;
/* 361 */     signTblGrid.fill = 1;
/* 362 */     signTblGrid.weightx = 1.0D;
/* 363 */     signTblGrid.weighty = 0.8D;
/* 364 */     this.signPanel.add(this.scrollPaneSign, signTblGrid);
/*     */     
/* 366 */     GridBagConstraints signAddBtnGrid = new GridBagConstraints();
/* 367 */     signAddBtnGrid.gridx = 1;
/* 368 */     signAddBtnGrid.gridy = 1;
/* 369 */     signAddBtnGrid.insets = new Insets(10, 80, 10, 75);
/* 370 */     this.signPanel.add(this.addSignBtn, signAddBtnGrid);
/*     */     
/* 372 */     GridBagConstraints signDelBtnGrid = new GridBagConstraints();
/* 373 */     signDelBtnGrid.gridx = 2;
/* 374 */     signDelBtnGrid.gridy = 1;
/* 375 */     signDelBtnGrid.insets = new Insets(10, 0, 10, 75);
/* 376 */     this.signPanel.add(this.deleteSignBtn, signDelBtnGrid);
/*     */     
/* 378 */     GridBagConstraints signUpdBtnGrid = new GridBagConstraints();
/* 379 */     signUpdBtnGrid.gridx = 3;
/* 380 */     signUpdBtnGrid.gridy = 1;
/* 381 */     signUpdBtnGrid.insets = new Insets(10, 0, 10, 50);
/* 382 */     this.signPanel.add(this.updateSignBtn, signUpdBtnGrid);
/*     */     
/* 384 */     this.authPanel.setLayout(new GridBagLayout());
/*     */     
/* 386 */     GridBagConstraints authTblGrid = new GridBagConstraints();
/* 387 */     authTblGrid.gridx = 0;
/* 388 */     authTblGrid.gridy = 0;
/* 389 */     authTblGrid.gridwidth = 6;
/* 390 */     authTblGrid.fill = 1;
/* 391 */     authTblGrid.weightx = 1.0D;
/* 392 */     authTblGrid.weighty = 0.8D;
/* 393 */     this.authPanel.add(this.scrollPaneAuth, authTblGrid);
/*     */     
/* 395 */     GridBagConstraints authAddBtnGrid = new GridBagConstraints();
/* 396 */     authAddBtnGrid.gridx = 1;
/* 397 */     authAddBtnGrid.gridy = 1;
/* 398 */     authAddBtnGrid.insets = new Insets(10, 80, 10, 75);
/* 399 */     this.authPanel.add(this.addAuthBtn, authAddBtnGrid);
/*     */     
/* 401 */     GridBagConstraints authDelBtnGrid = new GridBagConstraints();
/* 402 */     authDelBtnGrid.gridx = 2;
/* 403 */     authDelBtnGrid.gridy = 1;
/* 404 */     authDelBtnGrid.insets = new Insets(10, 0, 10, 75);
/* 405 */     this.authPanel.add(this.deleteAuthBtn, authDelBtnGrid);
/*     */     
/* 407 */     GridBagConstraints authUpdBtnGrid = new GridBagConstraints();
/* 408 */     authUpdBtnGrid.gridx = 3;
/* 409 */     authUpdBtnGrid.gridy = 1;
/* 410 */     authUpdBtnGrid.insets = new Insets(10, 0, 10, 50);
/* 411 */     this.authPanel.add(this.updateAuthBtn, authUpdBtnGrid);
/*     */     
/*     */ 
/* 414 */     this.prefPanel.setLayout(new GridBagLayout());
/*     */     
/* 416 */     GridBagConstraints prefGrid = new GridBagConstraints();
/* 417 */     prefGrid.gridx = 0;
/* 418 */     prefGrid.gridy = 0;
/* 419 */     prefGrid.gridwidth = 4;
/* 420 */     prefGrid.insets = new Insets(3, 20, 3, 20);
/* 421 */     prefGrid.anchor = 10;
/* 422 */     this.prefPanel.add(this.showPreferences, prefGrid);
/*     */     
/* 424 */     this.prefPanel.setBorder(new TitledBorder(I18N.getLocalMessage("i18n.mityc.cert.mityc.84")));
/*     */     
/*     */ 
/*     */ 
/* 428 */     setLayout(new GridBagLayout());
/*     */     
/* 430 */     GridBagConstraints tabsGrid = new GridBagConstraints();
/* 431 */     tabsGrid.gridx = 0;
/* 432 */     tabsGrid.gridy = 0;
/* 433 */     tabsGrid.gridwidth = 4;
/* 434 */     tabsGrid.insets = new Insets(3, 3, 0, 3);
/* 435 */     tabsGrid.fill = 1;
/* 436 */     tabsGrid.weightx = 1.0D;
/* 437 */     tabsGrid.weighty = 1.0D;
/* 438 */     add(this.tabs, tabsGrid);
/*     */     
/* 440 */     GridBagConstraints prefPanelGrid = new GridBagConstraints();
/* 441 */     prefPanelGrid.gridx = 0;
/* 442 */     prefPanelGrid.gridy = 1;
/* 443 */     prefPanelGrid.gridwidth = 4;
/* 444 */     prefPanelGrid.insets = new Insets(3, 3, 10, 3);
/* 445 */     prefPanelGrid.fill = 2;
/* 446 */     prefPanelGrid.weightx = 1.0D;
/* 447 */     prefPanelGrid.ipady = 5;
/* 448 */     add(this.prefPanel, prefPanelGrid);
/*     */     
/*     */ 
/* 451 */     setBorder(new TitledBorder(I18N.getLocalMessage("i18n.mityc.cert.mityc.72")));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void jButtonAddActionPerformed(final ACTION_FOR action)
/*     */   {
/* 459 */     Thread th = new Thread(new Runnable() {
/*     */       public void run() {
/* 461 */         JFileChooser chooser = new JFileChooser();
/*     */         
/* 463 */         chooser.setDialogTitle(KSManagerPanel.I18N.getLocalMessage("i18n.mityc.cert.mityc.73"));
/* 464 */         chooser.setDialogType(0);
/* 465 */         chooser.setFileFilter(new CertsFilter(KSManagerPanel.ACTION_FOR.SIGN.equals(action)));
/* 466 */         int returnVal = chooser.showOpenDialog(KSManagerPanel.this.ksmp);
/* 467 */         if (returnVal == 0) {
/* 468 */           KSManagerPanel.this.addCertFromPath(chooser.getSelectedFile().getAbsolutePath(), action);
/*     */         }
/*     */         else {}
/*     */       }
/*     */       
/*     */ 
/* 474 */     });
/* 475 */     th.run();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void jButtonDelActionPerformed(final ACTION_FOR action)
/*     */   {
/* 483 */     Thread th = new Thread(new Runnable() {
/*     */       public void run() {
/* 485 */         int row = 0;
/* 486 */         if (action.equals(KSManagerPanel.ACTION_FOR.SIGN)) {
/* 487 */           row = KSManagerPanel.this.signCrtTbl.getSelectedRow();
/* 488 */           KSManagerPanel.this.deleteSignCert(row);
/* 489 */           if (KSManagerPanel.this.signCrtTbl.getModel().getRowCount() > 0) {
/* 490 */             KSManagerPanel.this.signCrtTbl.setRowSelectionInterval(0, 0);
/*     */           }
/*     */         } else {
/* 493 */           row = KSManagerPanel.this.authCrtTbl.getSelectedRow();
/* 494 */           KSManagerPanel.this.deleteTrustCert(row);
/* 495 */           if (KSManagerPanel.this.authCrtTbl.getModel().getRowCount() > 0) {
/* 496 */             KSManagerPanel.this.authCrtTbl.setRowSelectionInterval(0, 0);
/*     */           }
/*     */           
/*     */         }
/*     */       }
/* 501 */     });
/* 502 */     th.run();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void jButtonUpdateActionPerformed(ACTION_FOR action)
/*     */   {
/* 511 */     if (action.equals(ACTION_FOR.AUTH))
/*     */     {
/* 513 */       return;
/*     */     }
/*     */     
/* 516 */     JFileChooser chooser = new JFileChooser();
/*     */     
/* 518 */     chooser.setDialogTitle(I18N.getLocalMessage("i18n.mityc.cert.mityc.73"));
/* 519 */     chooser.setDialogType(0);
/* 520 */     chooser.setFileFilter(new CertsFilter(true));
/* 521 */     int returnVal = chooser.showOpenDialog(this.ksmp);
/* 522 */     if (returnVal == 0) {
/* 523 */       addCertFromPath(chooser.getSelectedFile().getAbsolutePath(), null);
/* 524 */       deleteSignCert(this.signCrtTbl.getSelectedRow());
/* 525 */       if (this.signCrtTbl.getModel().getRowCount() > 0) {
/* 526 */         this.signCrtTbl.setRowSelectionInterval(0, 0);
/*     */       }
/*     */     }
/*     */     else {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void jButtonShowPrefActionPerformed()
/*     */   {
/* 537 */     JDialog pref = new JDialog(this.ownerFrame);
/* 538 */     JPanel panel = this.pksma.getPreferencesPanel();
/*     */     
/* 540 */     pref.add(panel);
/*     */     
/*     */ 
/* 543 */     pref.setSize(panel.getSize());
/* 544 */     pref.setTitle(I18N.getLocalMessage("i18n.mityc.cert.mityc.90"));
/* 545 */     pref.setLocationRelativeTo(this.ownerFrame);
/* 546 */     if (this.ownerFrame == null) {
/* 547 */       Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
/* 548 */       pref.setLocation(screenSize.width / 2 - pref.getWidth() / 2, screenSize.height / 2 - pref.getHeight() / 2);
/*     */     }
/*     */     
/* 551 */     pref.setModal(true);
/* 552 */     pref.setResizable(false);
/* 553 */     pref.setVisible(true);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void loadKeyStore()
/*     */   {
/*     */     try
/*     */     {
/* 561 */       if (this.pksm == null)
/*     */       {
/*     */ 
/* 564 */         JOptionPane.showMessageDialog(this, 
/* 565 */           I18N.getLocalMessage("i18n.mityc.cert.mityc.59"), 
/* 566 */           I18N.getLocalMessage("i18n.mityc.cert.mityc.15"), 
/* 567 */           0);
/* 568 */         return;
/*     */       }
/* 570 */       this.signCerts = this.pksm.getSignCertificates();
/* 571 */       this.authCerts = this.pksm.getTrustCertificates();
/*     */     } catch (CertStoreException e) {
/* 573 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addSignCert(PrivateKey pk, X509Certificate cert, char[] password)
/*     */   {
/* 585 */     if (this.pksm == null) {
/* 586 */       return;
/*     */     }
/*     */     try {
/* 589 */       this.pksma.importSignCert(pk, cert, password);
/* 590 */       refreshTbl();
/*     */     }
/*     */     catch (CertStoreException e) {
/* 593 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mityc.74"), e);
/* 594 */       return;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addTrustCert(X509Certificate cert)
/*     */   {
/* 604 */     if (this.pksm == null) {
/* 605 */       return;
/*     */     }
/*     */     try {
/* 608 */       this.pksma.addTrustCert(cert);
/* 609 */       refreshTbl();
/*     */     }
/*     */     catch (CertStoreException e) {
/* 612 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mityc.74"), e);
/* 613 */       return;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void deleteSignCert(int row)
/*     */   {
/* 623 */     if (this.pksm == null) {
/* 624 */       return;
/*     */     }
/* 626 */     if (row != -1) {
/*     */       try {
/* 628 */         this.pksma.removeSignCert(((CertTblModel)this.signCrtTbl.getModel()).getCertificate(row));
/* 629 */         refreshTbl();
/*     */       } catch (CertStoreException e) {
/* 631 */         JOptionPane.showMessageDialog(this, 
/* 632 */           e.getMessage(), 
/* 633 */           I18N.getLocalMessage("i18n.mityc.cert.mityc.19"), 
/* 634 */           2);
/*     */       }
/*     */     } else {
/* 637 */       LOG.debug("No se puede borrar, no hay certificado seleccionado.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void deleteTrustCert(int row)
/*     */   {
/* 647 */     if (this.pksm == null) {
/* 648 */       return;
/*     */     }
/* 650 */     if (row != -1) {
/*     */       try {
/* 652 */         this.pksma.removeTrustCert(((CertTblModel)this.authCrtTbl.getModel()).getCertificate(row));
/* 653 */         refreshTbl();
/*     */       } catch (CertStoreException e) {
/* 655 */         JOptionPane.showMessageDialog(this, 
/* 656 */           e.getMessage(), 
/* 657 */           I18N.getLocalMessage("i18n.mityc.cert.mityc.19"), 
/* 658 */           2);
/*     */       }
/*     */     } else {
/* 661 */       LOG.debug("No se puede borrar, no hay certificado seleccionado.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void updateSignCert(X509Certificate cert)
/*     */   {
/* 672 */     if (this.pksm == null) {
/* 673 */       return;
/*     */     }
/*     */     try {
/* 676 */       this.pksma.updateSignCert(cert);
/* 677 */       refreshTbl();
/*     */     } catch (CertStoreException e) {
/* 679 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void refreshTbl()
/*     */   {
/*     */     try
/*     */     {
/* 690 */       this.signCerts = this.pksm.getSignCertificates();
/* 691 */       this.authCerts = this.pksm.getTrustCertificates();
/*     */     } catch (CertStoreException e) {
/* 693 */       e.printStackTrace();
/*     */     }
/*     */     
/* 696 */     this.signCrtTbl.setModel(new CertTblModel(this.signCerts));
/* 697 */     this.authCrtTbl.setModel(new CertTblModel(this.authCerts));
/*     */     
/* 699 */     this.signCrtTbl.repaint();
/* 700 */     this.authCrtTbl.repaint();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Certificate getSignCertificate()
/*     */   {
/* 709 */     int sel = this.signCrtTbl.getSelectedRow();
/* 710 */     if ((sel > -1) && (sel < this.signCerts.size())) {
/* 711 */       return (X509Certificate)this.signCerts.get(sel);
/*     */     }
/* 713 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public X509Certificate getAuthCertificate()
/*     */   {
/* 723 */     int sel = this.authCrtTbl.getSelectedRow();
/* 724 */     if ((sel > -1) && (sel < this.authCerts.size())) {
/* 725 */       return (X509Certificate)this.authCerts.get(sel);
/*     */     }
/* 727 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addCertFromPath(String path, ACTION_FOR action)
/*     */   {
/* 737 */     if (!new File(path).exists())
/*     */     {
/* 739 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mityc.75"));
/* 740 */       return;
/*     */     }
/*     */     
/* 743 */     FileInputStream fis = null;
/*     */     
/* 745 */     X509Certificate cert = null;
/* 746 */     PrivateKey pk12 = null;
/* 747 */     char[] passwordP12 = null;
/*     */     
/* 749 */     if (path.endsWith("p12")) {
/*     */       try
/*     */       {
/* 752 */         KeyStore ks12 = KeyStore.getInstance("PKCS12");
/* 753 */         passwordP12 = null;
/*     */         try {
/* 755 */           fis = new FileInputStream(path);
/* 756 */           PlainPassHandler passHandler = new PlainPassHandler();
/* 757 */           passwordP12 = passHandler.getPassword(null, path.substring(path.lastIndexOf(File.separator) + 1));
/*     */           try {
/* 759 */             ks12.load(fis, passwordP12);
/*     */           }
/*     */           catch (IOException e) {
/* 762 */             LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mityc.76"));
/* 763 */             JOptionPane.showMessageDialog(this, 
/* 764 */               I18N.getLocalMessage("i18n.mityc.cert.mityc.76"), 
/* 765 */               I18N.getLocalMessage("i18n.mityc.cert.mityc.77"), 
/* 766 */               2);
/* 767 */             return;
/*     */           }
/*     */           
/*     */ 
/* 771 */           Enumeration<String> contenidoP12 = ks12.aliases();
/* 772 */           String alias = null;
/* 773 */           if (ks12.size() == 1) {
/* 774 */             alias = (String)contenidoP12.nextElement();
/* 775 */             LOG.debug("P12.- Alias del certificado: " + alias);
/*     */           }
/*     */           else {
/* 778 */             JOptionPane.showMessageDialog(this, 
/* 779 */               I18N.getLocalMessage("i18n.mityc.cert.mityc.78"), 
/* 780 */               I18N.getLocalMessage("i18n.mityc.cert.mityc.77"), 
/* 781 */               2);
/* 782 */             return;
/*     */           }
/*     */           
/*     */           try
/*     */           {
/* 787 */             cert = (X509Certificate)ks12.getCertificate(alias);
/*     */           } catch (KeyStoreException e1) {
/* 789 */             e1.printStackTrace();
/* 790 */             return;
/*     */           }
/*     */           
/*     */ 
/* 794 */           if (ks12.isKeyEntry(alias))
/*     */           {
/* 796 */             passwordP12 = passHandler.getPassword(null, I18N.getLocalMessage("i18n.mityc.cert.mityc.80"));
/* 797 */             KeyStore.PasswordProtection kpp12 = new KeyStore.PasswordProtection(passwordP12);
/* 798 */             KeyStore.PrivateKeyEntry pkEntry12 = null;
/*     */             try {
/* 800 */               pkEntry12 = (KeyStore.PrivateKeyEntry)ks12.getEntry(alias, kpp12);
/*     */             } catch (NoSuchAlgorithmException e1) {
/* 802 */               e1.printStackTrace();
/*     */             }
/*     */             catch (UnrecoverableEntryException e) {
/* 805 */               JOptionPane.showMessageDialog(this, 
/* 806 */                 I18N.getLocalMessage("i18n.mityc.cert.mityc.79"), 
/* 807 */                 I18N.getLocalMessage("i18n.mityc.cert.mityc.77"), 
/* 808 */                 2);
/* 809 */               return;
/*     */             }
/* 811 */             if (pkEntry12 != null) {
/* 812 */               pk12 = pkEntry12.getPrivateKey();
/*     */             } else {
/* 814 */               LOG.debug("P12.- No se encontró la clave privada");
/*     */             }
/*     */           }
/*     */         } catch (NoSuchAlgorithmException e) {
/* 818 */           e.printStackTrace();
/* 819 */           return;
/*     */         } catch (CertificateException e) {
/* 821 */           e.printStackTrace();
/* 822 */           return;
/*     */         } catch (FileNotFoundException e) {
/* 824 */           e.printStackTrace();
/* 825 */           return;
/*     */         } finally {
/* 827 */           if (fis != null) {
/*     */             try {
/* 829 */               fis.close();
/*     */             }
/*     */             catch (IOException localIOException8) {}
/*     */           }
/*     */         }
/* 827 */         if (fis == null)
/*     */           break label634;
/* 829 */         try { fis.close();
/*     */         }
/*     */         catch (IOException localIOException9) {}
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 837 */         if (path.endsWith("cer")) {
/*     */           break label582;
/*     */         }
/*     */       }
/*     */       catch (KeyStoreException e1)
/*     */       {
/* 834 */         e1.printStackTrace();
/* 835 */         return;
/*     */       }
/* 837 */     } else if (path.endsWith("crt")) {
/*     */       try { label582:
/* 839 */         CertificateFactory cfTemporal = CertificateFactory.getInstance("X.509");
/* 840 */         cert = (X509Certificate)cfTemporal.generateCertificate(new FileInputStream(new File(path)));
/*     */       } catch (IOException e) {
/* 842 */         e.printStackTrace();
/* 843 */         return;
/*     */       } catch (CertificateException e) {
/* 845 */         e.printStackTrace();
/* 846 */         return;
/*     */       }
/*     */     }
/*     */     label634:
/* 850 */     if (action == null) {
/* 851 */       updateSignCert(cert);
/* 852 */     } else if (action.equals(ACTION_FOR.SIGN)) {
/* 853 */       addSignCert(pk12, cert, passwordP12);
/*     */     } else {
/* 855 */       addTrustCert(cert);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private class DragDropHandler
/*     */     extends TransferHandler
/*     */   {
/*     */     private DragDropHandler() {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean canImport(JComponent comp, DataFlavor[] transferFlavors)
/*     */     {
/* 872 */       boolean res = false;
/*     */       DataFlavor[] arrayOfDataFlavor;
/* 874 */       int j = (arrayOfDataFlavor = transferFlavors).length; for (int i = 0; i < j; i++) { DataFlavor dataFlavor = arrayOfDataFlavor[i];
/* 875 */         if (dataFlavor.isFlavorJavaFileListType()) {
/* 876 */           res = true;
/* 877 */           break;
/*     */         }
/*     */       }
/*     */       
/* 881 */       return res ? true : super.canImport(comp, transferFlavors);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean importData(JComponent comp, Transferable t)
/*     */     {
/* 892 */       boolean res = false;
/* 893 */       DataFlavor[] trasnferFlavors = t.getTransferDataFlavors();
/* 894 */       File file = null;
/* 895 */       DataFlavor[] arrayOfDataFlavor1; int j = (arrayOfDataFlavor1 = trasnferFlavors).length; for (int i = 0; i < j; i++) { DataFlavor dataFlavor = arrayOfDataFlavor1[i];
/* 896 */         if (dataFlavor.isFlavorJavaFileListType()) {
/*     */           try {
/* 898 */             List<?> files = (List)t.getTransferData(dataFlavor);
/* 899 */             if (files.size() > 0) {
/* 900 */               file = (File)files.get(0);
/* 901 */               if (file.exists()) {
/* 902 */                 if ((file.getName().endsWith("cer")) || 
/* 903 */                   (file.getName().endsWith("crt")) || 
/* 904 */                   (file.getName().endsWith("p12")))
/*     */                 {
/* 906 */                   if (KSManagerPanel.this.signPanel.equals(comp)) {
/* 907 */                     KSManagerPanel.this.addCertFromPath(file.getAbsolutePath(), KSManagerPanel.ACTION_FOR.SIGN);
/*     */                   } else {
/* 909 */                     KSManagerPanel.this.addCertFromPath(file.getAbsolutePath(), KSManagerPanel.ACTION_FOR.AUTH);
/*     */                   }
/*     */                 }
/*     */                 else {
/* 913 */                   EventQueue.invokeLater(new Runnable() {
/*     */                     public void run() {
/* 915 */                       JOptionPane.showMessageDialog(KSManagerPanel.this.tabs, 
/* 916 */                         KSManagerPanel.I18N.getLocalMessage("i18n.mityc.cert.mityc.56"), 
/* 917 */                         KSManagerPanel.I18N.getLocalMessage("i18n.mityc.cert.mityc.77"), 
/* 918 */                         0);
/*     */                     }
/*     */                   });
/*     */                 }
/*     */               } else {
/* 923 */                 EventQueue.invokeLater(new Runnable() {
/*     */                   public void run() {
/* 925 */                     JOptionPane.showMessageDialog(KSManagerPanel.this.tabs, 
/* 926 */                       KSManagerPanel.I18N.getLocalMessage("i18n.mityc.cert.mityc.75"), 
/* 927 */                       KSManagerPanel.I18N.getLocalMessage("i18n.mityc.cert.mityc.77"), 
/* 928 */                       0);
/*     */                   }
/*     */                 });
/*     */               }
/*     */               
/* 933 */               res = true;
/*     */             }
/*     */           }
/*     */           catch (UnsupportedFlavorException localUnsupportedFlavorException) {}catch (IOException localIOException) {}
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 941 */       return res ? true : super.importData(comp, t);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void exportAsDrag(JComponent comp, InputEvent e, int action)
/*     */     {
/* 949 */       KSManagerPanel.LOG.warn("Not implemented yet.");
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mitycstore\mantainer\KSManagerPanel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */