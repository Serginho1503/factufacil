/*    */ package es.mityc.javasign.pkstore.mitycstore.PKHandlers;
/*    */ 
/*    */ import es.mityc.javasign.i18n.I18nFactory;
/*    */ import es.mityc.javasign.i18n.II18nManager;
/*    */ import es.mityc.javasign.pkstore.DefaultPassStoreKS;
/*    */ import es.mityc.javasign.pkstore.mitycstore.CertUtil;
/*    */ import java.security.cert.X509Certificate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlainPassHandler
/*    */   extends DefaultPassStoreKS
/*    */ {
/* 34 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*    */   
/*    */ 
/* 37 */   private String pinMessage = I18N.getLocalMessage("i18n.mityc.cert.smartcards.GUI.pin");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void processData(X509Certificate certificate, String alias)
/*    */   {
/* 47 */     if (alias != null) {
/* 48 */       setPINMessage(this.pinMessage + " " + alias);
/*    */     } else {
/* 50 */       setPINMessage(this.pinMessage + " " + CertUtil.extractName(certificate.getSubjectX500Principal()));
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mitycstore\PKHandlers\PlainPassHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */