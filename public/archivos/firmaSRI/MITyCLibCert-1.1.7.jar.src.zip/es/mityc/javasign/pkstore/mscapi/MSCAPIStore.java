/*     */ package es.mityc.javasign.pkstore.mscapi;
/*     */ 
/*     */ import es.mityc.javasign.exception.CopyFileException;
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.pkstore.CertStoreException;
/*     */ import es.mityc.javasign.pkstore.IPKStoreManager;
/*     */ import es.mityc.javasign.pkstore.IPassStoreKS;
/*     */ import es.mityc.javasign.pkstore.keystore.KeyTool;
/*     */ import es.mityc.javasign.utils.CopyFilesTool;
/*     */ import es.mityc.javasign.utils.ProvidersUtil;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.Provider;
/*     */ import java.security.Security;
/*     */ import java.security.cert.CertPath;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MSCAPIStore
/*     */   implements IPKStoreManager
/*     */ {
/*     */   public static enum LocationStoreType
/*     */   {
/*  58 */     CurrentUser,  LocalMachine;
/*     */   }
/*     */   
/*  61 */   private static final Log LOG = LogFactory.getLog(MSCAPIStore.class);
/*     */   
/*  63 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*     */   
/*     */ 
/*     */   private static final String MY_STORE = "Windows-MY";
/*     */   
/*     */ 
/*     */   private static final String ROOT_STORE = "Windows-ROOT";
/*     */   
/*     */ 
/*     */   private static final String CA_STORE = "Windows-CA";
/*     */   
/*     */ 
/*     */   private static final String LOCAL_MACHINE_MY_STORE = "Windows-LocalMachine-MY";
/*     */   
/*     */ 
/*     */   private static final String LOCAL_MACHINE_ROOT_STORE = "Windows-LocalMachine-ROOT";
/*     */   
/*     */ 
/*     */   private static final String LOCAL_MACHINE_CA_STORE = "Windows-LocalMachine-CA";
/*     */   
/*     */ 
/*     */   private static final String SUN_MSCAPI_PROVIDER = "SunMSCAPI";
/*     */   
/*     */   private static final String SUN_MSCAPI_MITYC_KEY_STORE_CLASS = "es.mityc.javasign.pkstore.mscapi.mityc.KeyStore";
/*     */   
/*     */   private static final String SUN_MSCAPI_MITYC_PROVIDER_CLASS = "es.mityc.javasign.pkstore.mscapi.mityc.SunMSCAPI_MITyC";
/*     */   
/*  90 */   private static boolean initialized = false;
/*     */   
/*     */ 
/*     */   private IPassStoreKS passHandler;
/*     */   
/*     */ 
/*     */   private Provider provider;
/*     */   
/*     */ 
/*     */   private LocationStoreType locationStore;
/*     */   
/*     */ 
/* 102 */   private boolean usingSunMSCAPIMITyC = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public class NullPassStorePK
/*     */     implements IPassStoreKS
/*     */   {
/*     */     public NullPassStorePK() {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public char[] getPassword(X509Certificate certificate, String alias)
/*     */     {
/* 117 */       return new char[0];
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private synchronized void copyLibrary(boolean retry)
/*     */     throws CopyFileException
/*     */   {
/* 126 */     LOG.debug("Copiando librerías: " + initialized);
/* 127 */     if (!initialized) {
/* 128 */       CopyFilesTool cft = new CopyFilesTool("libs/sunmscapimityc/MITyCLibCertJNI_sunmscapimityc.properties", getClass().getClassLoader());
/* 129 */       if (retry) {
/* 130 */         String random = new Long(System.currentTimeMillis()).toString();
/* 131 */         cft.copyFilesOS(null, "explorer", true, random);
/*     */       } else {
/* 133 */         cft.copyFilesOS(null, "explorer", true);
/*     */       }
/* 135 */       initialized = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MSCAPIStore(IPassStoreKS passStoreHandler)
/*     */     throws CertStoreException
/*     */   {
/* 147 */     this(passStoreHandler, LocationStoreType.CurrentUser);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MSCAPIStore(IPassStoreKS passStoreHandler, LocationStoreType location)
/*     */     throws CertStoreException
/*     */   {
/* 159 */     this.locationStore = location;
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 165 */       Class.forName("es.mityc.javasign.pkstore.mscapi.mityc.KeyStore");
/* 166 */       copyLibrary(false);
/* 167 */       Class<?> sunMscapiMITyCProviderClass = Class.forName("es.mityc.javasign.pkstore.mscapi.mityc.SunMSCAPI_MITyC");
/* 168 */       Constructor<?> constructor = sunMscapiMITyCProviderClass.getConstructor(new Class[0]);
/* 169 */       this.provider = ((Provider)constructor.newInstance(new Object[0]));
/* 170 */       LOG.info(I18N.getLocalMessage("i18n.mityc.cert.mscapi.9"));
/*     */     } catch (Exception ex) {
/* 172 */       if (LOG.isDebugEnabled()) {
/* 173 */         LOG.debug(ex);
/*     */       }
/*     */       try {
/* 176 */         copyLibrary(true);
/* 177 */         Class<?> sunMscapiMITyCProviderClass = Class.forName("es.mityc.javasign.pkstore.mscapi.mityc.SunMSCAPI_MITyC");
/* 178 */         Constructor<?> constructor = sunMscapiMITyCProviderClass.getConstructor(new Class[0]);
/* 179 */         this.provider = ((Provider)constructor.newInstance(new Object[0]));
/* 180 */         LOG.info(I18N.getLocalMessage("i18n.mityc.cert.mscapi.9"));
/*     */       } catch (Throwable e) {
/* 182 */         if (LOG.isDebugEnabled()) {
/* 183 */           LOG.debug(I18N.getLocalMessage("i18n.mityc.cert.mscapi.8", new Object[] { e.getMessage() }), e);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 191 */     if (this.provider == null) {
/* 192 */       this.provider = Security.getProvider("SunMSCAPI");
/* 193 */       if (this.provider == null) {
/* 194 */         throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.7"));
/*     */       }
/* 196 */       ProvidersUtil.registerProvider(this.provider.getClass().getName());
/* 197 */       LOG.info(I18N.getLocalMessage("i18n.mityc.cert.mscapi.10"));
/*     */     }
/*     */     else {
/* 200 */       this.usingSunMSCAPIMITyC = true;
/*     */     }
/* 202 */     if (passStoreHandler == null) {
/* 203 */       this.passHandler = new NullPassStorePK();
/*     */     } else {
/* 205 */       this.passHandler = passStoreHandler;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CertPath getCertPath(X509Certificate certificate)
/*     */     throws CertStoreException
/*     */   {
/* 217 */     throw new UnsupportedOperationException("Not implemented yet");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PrivateKey getPrivateKey(X509Certificate certificate)
/*     */     throws CertStoreException
/*     */   {
/*     */     try
/*     */     {
/* 234 */       String storeName = null;
/* 235 */       switch (this.locationStore) {
/*     */       case CurrentUser: 
/* 237 */         storeName = "Windows-MY";
/* 238 */         break;
/*     */       case LocalMachine: 
/* 240 */         storeName = "Windows-LocalMachine-MY";
/*     */       }
/*     */       
/*     */       
/* 244 */       KeyStore ks = KeyStore.getInstance(storeName, this.provider);
/* 245 */       ks.load(null, null);
/* 246 */       return KeyTool.findPrivateKey(ks, certificate, this.passHandler);
/*     */     }
/*     */     catch (KeyStoreException ex) {
/* 249 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.1", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (NoSuchAlgorithmException ex) {
/* 251 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.2", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (CertificateException ex) {
/* 253 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.3", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (IOException ex) {
/* 255 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.4", new Object[] { ex.getMessage(), ex }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Provider getProvider(X509Certificate certificate)
/*     */   {
/* 265 */     return this.provider;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<X509Certificate> getSignCertificates()
/*     */     throws CertStoreException
/*     */   {
/*     */     try
/*     */     {
/* 276 */       String storeName = null;
/* 277 */       switch (this.locationStore) {
/*     */       case CurrentUser: 
/* 279 */         storeName = "Windows-MY";
/* 280 */         break;
/*     */       case LocalMachine: 
/* 282 */         storeName = "Windows-LocalMachine-MY";
/*     */       }
/*     */       
/*     */       
/* 286 */       KeyStore ks = KeyStore.getInstance(storeName, this.provider);
/* 287 */       ks.load(null, null);
/* 288 */       return KeyTool.getCertificatesWithKeys(ks);
/*     */     } catch (KeyStoreException ex) {
/* 290 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.1", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (NoSuchAlgorithmException ex) {
/* 292 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.2", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (CertificateException ex) {
/* 294 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.3", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (IOException ex) {
/* 296 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.4", new Object[] { ex.getMessage(), ex }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<X509Certificate> getPublicCertificates()
/*     */     throws CertStoreException
/*     */   {
/*     */     try
/*     */     {
/* 308 */       String storeName = null;
/* 309 */       switch (this.locationStore) {
/*     */       case CurrentUser: 
/* 311 */         storeName = "Windows-MY";
/* 312 */         break;
/*     */       case LocalMachine: 
/* 314 */         storeName = "Windows-LocalMachine-MY";
/*     */       }
/*     */       
/*     */       
/* 318 */       KeyStore ks = KeyStore.getInstance(storeName, this.provider);
/* 319 */       ks.load(null, null);
/* 320 */       return KeyTool.getCertificatesWithoutKeys(ks);
/*     */     } catch (KeyStoreException ex) {
/* 322 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.1", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (NoSuchAlgorithmException ex) {
/* 324 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.2", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (CertificateException ex) {
/* 326 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.3", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (IOException ex) {
/* 328 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.4", new Object[] { ex.getMessage(), ex }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<X509Certificate> getTrustCertificates()
/*     */     throws CertStoreException
/*     */   {
/*     */     try
/*     */     {
/* 341 */       String storeName = null;
/* 342 */       switch (this.locationStore) {
/*     */       case CurrentUser: 
/* 344 */         storeName = "Windows-ROOT";
/* 345 */         break;
/*     */       case LocalMachine: 
/* 347 */         storeName = "Windows-LocalMachine-ROOT";
/*     */       }
/*     */       
/*     */       
/* 351 */       KeyStore ks = KeyStore.getInstance(storeName, this.provider);
/* 352 */       ks.load(null, null);
/* 353 */       ArrayList<X509Certificate> lista = new ArrayList();
/* 354 */       lista.addAll(KeyTool.getTrustCertificates(ks));
/*     */       
/* 356 */       if (this.usingSunMSCAPIMITyC) {
/* 357 */         switch (this.locationStore) {
/*     */         case CurrentUser: 
/* 359 */           storeName = "Windows-CA";
/* 360 */           break;
/*     */         case LocalMachine: 
/* 362 */           storeName = "Windows-LocalMachine-CA";
/*     */         }
/*     */         
/*     */         
/* 366 */         ks = KeyStore.getInstance(storeName, this.provider);
/* 367 */         ks.load(null, null);
/* 368 */         lista.addAll(KeyTool.getTrustCertificates(ks));
/*     */       }
/* 370 */       return lista;
/*     */     } catch (KeyStoreException ex) {
/* 372 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.1", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (NoSuchAlgorithmException ex) {
/* 374 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.2", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (CertificateException ex) {
/* 376 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.3", new Object[] { ex.getMessage(), ex }));
/*     */     } catch (IOException ex) {
/* 378 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mscapi.4", new Object[] { ex.getMessage(), ex }));
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mscapi\MSCAPIStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */