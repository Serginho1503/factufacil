/*    */ package es.mityc.javasign.pkstore.keystore;
/*    */ 
/*    */ import es.mityc.javasign.i18n.I18nFactory;
/*    */ import es.mityc.javasign.i18n.II18nManager;
/*    */ import es.mityc.javasign.pkstore.IPassStoreKS;
/*    */ import java.io.IOException;
/*    */ import javax.security.auth.callback.Callback;
/*    */ import javax.security.auth.callback.CallbackHandler;
/*    */ import javax.security.auth.callback.PasswordCallback;
/*    */ import javax.security.auth.callback.UnsupportedCallbackException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PassCallbackHandlerProtection
/*    */   implements CallbackHandler
/*    */ {
/* 37 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*    */   
/*    */ 
/*    */ 
/*    */   private IPassStoreKS passHandler;
/*    */   
/*    */ 
/*    */ 
/*    */   public PassCallbackHandlerProtection(IPassStoreKS passwordHandler)
/*    */   {
/* 47 */     this.passHandler = passwordHandler;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void handle(Callback[] callbacks)
/*    */     throws IOException, UnsupportedCallbackException
/*    */   {
/* 58 */     for (int i = 0; i < callbacks.length; i++) {
/* 59 */       if ((this.passHandler != null) && 
/* 60 */         ((callbacks[i] instanceof PasswordCallback))) {
/* 61 */         PasswordCallback pc = (PasswordCallback)callbacks[i];
/* 62 */         pc.setPassword(this.passHandler.getPassword(null, pc.getPrompt()));
/*    */       } else {
/* 64 */         throw new UnsupportedCallbackException(callbacks[i], I18N.getLocalMessage("i18n.mityc.cert.ks.3"));
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\keystore\PassCallbackHandlerProtection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */