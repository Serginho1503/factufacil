/*    */ package es.mityc.javasign.pkstore.iexplorer;
/*    */ 
/*    */ import java.security.Provider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MITyCMSProvider
/*    */   extends Provider
/*    */ {
/*    */   public static final String PROVIDER_MS = "MITyCMSProvider";
/*    */   private static final String PROVIDER_MS_DESCRIPTION = "MITyCMSProvider v1.0, implementación de SHA1withRSA basado en KeyStore de Microsoft y OpenOCES - OpenSign";
/*    */   private static final String SIGNATURE_SHA1_WITH_RSA = "Signature.SHA1withRSA";
/* 36 */   private static final String ENGINE_CLASS = IESignEngine.class.getName();
/*    */   
/*    */ 
/*    */ 
/*    */   public MITyCMSProvider()
/*    */   {
/* 42 */     super("MITyCMSProvider", 1.0D, "MITyCMSProvider v1.0, implementación de SHA1withRSA basado en KeyStore de Microsoft y OpenOCES - OpenSign");
/* 43 */     super.put("Signature.SHA1withRSA", ENGINE_CLASS);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\iexplorer\MITyCMSProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */