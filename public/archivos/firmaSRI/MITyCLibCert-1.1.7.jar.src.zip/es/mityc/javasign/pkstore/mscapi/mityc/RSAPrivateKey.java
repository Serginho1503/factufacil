/*    */ package es.mityc.javasign.pkstore.mscapi.mityc;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.NotSerializableException;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.security.PrivateKey;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RSAPrivateKey
/*    */   extends Key
/*    */   implements PrivateKey
/*    */ {
/*    */   RSAPrivateKey(long hCryptProv, long hCryptKey, int keyLength)
/*    */   {
/* 43 */     super(hCryptProv, hCryptKey, keyLength);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getAlgorithm()
/*    */   {
/* 59 */     return "RSA";
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 65 */     return 
/*    */     
/* 67 */       "RSAPrivateKey [size=" + this.keyLength + " bits, type=" + getKeyType(this.hCryptKey) + ", container=" + getContainerName(this.hCryptProv) + "]";
/*    */   }
/*    */   
/*    */ 
/*    */   private void writeObject(ObjectOutputStream out)
/*    */     throws IOException
/*    */   {
/* 74 */     throw new NotSerializableException();
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mscapi\mityc\RSAPrivateKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */