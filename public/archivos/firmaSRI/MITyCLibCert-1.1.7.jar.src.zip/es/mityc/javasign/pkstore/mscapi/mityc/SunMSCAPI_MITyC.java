/*     */ package es.mityc.javasign.pkstore.mscapi.mityc;
/*     */ 
/*     */ import es.mityc.javasign.utils.CopyFilesTool;
/*     */ import es.mityc.javasign.utils.OSTool;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.Provider;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import sun.security.action.PutAllAction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SunMSCAPI_MITyC
/*     */   extends Provider
/*     */ {
/*     */   private static final long serialVersionUID = -7526518963202322999L;
/*     */   private static final String INFO = "Sun's Microsoft Crypto API provider with MITyC modifications";
/*  59 */   private static final Log LOG = LogFactory.getLog(SunMSCAPI_MITyC.class);
/*     */   
/*     */   static {
/*  62 */     AccessController.doPrivileged(new PrivilegedAction() {
/*     */       public Void run() {
/*  64 */         String key = "sunmscapimityc";
/*     */         
/*     */         try
/*     */         {
/*  68 */           String absKey = "";
/*     */           try {
/*  70 */             absKey = new File(OSTool.getTempDir()).getCanonicalPath() + File.separator + key + ".dll";
/*     */           } catch (IOException e) {
/*  72 */             absKey = new File(OSTool.getTempDir()).getAbsolutePath() + File.separator + key + ".dll";
/*     */           }
/*  74 */           if (SunMSCAPI_MITyC.LOG.isDebugEnabled()) {
/*  75 */             SunMSCAPI_MITyC.LOG.debug("Cargando la librería: " + absKey);
/*     */           }
/*  77 */           if (new File(absKey).exists()) {
/*  78 */             System.load(absKey);
/*     */           } else {
/*  80 */             SunMSCAPI_MITyC.LOG.error("Unable to find " + absKey);
/*     */             try {
/*  82 */               System.loadLibrary(key);
/*     */             } catch (Exception e) {
/*  84 */               throw new FileNotFoundException(key);
/*     */             }
/*     */           }
/*     */         } catch (Throwable e) {
/*  88 */           SunMSCAPI_MITyC.LOG.debug("No se pudo cargar la instancia de la librería sunmscapi: " + e.getMessage(), e);
/*     */           try {
/*  90 */             String random = new Long(System.currentTimeMillis()).toString();
/*  91 */             CopyFilesTool cft = new CopyFilesTool("libs/sunmscapimityc/MITyCLibCertJNI_sunmscapimityc.properties", getClass().getClassLoader());
/*  92 */             String dir = cft.copyFilesOS(null, "explorer", true, random);
/*  93 */             String libPath = System.getProperty("java.library.path");
/*  94 */             if (!libPath.contains(dir)) {
/*  95 */               libPath = dir + File.pathSeparator + libPath;
/*  96 */               System.setProperty("java.library.path", libPath);
/*     */             }
/*  98 */             System.loadLibrary(key + random);
/*     */           } catch (Throwable e2) {
/* 100 */             SunMSCAPI_MITyC.LOG.debug("No se pudo cargar definitivamente la instancia de la librería sunmscapi: " + e2.getMessage(), e2);
/*     */           }
/*     */         }
/* 103 */         return null;
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public SunMSCAPI_MITyC() {
/* 109 */     super("SunMSCAPI_MITyC", 1.71D, "Sun's Microsoft Crypto API provider with MITyC modifications");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 114 */     Map<Object, Object> map = System.getSecurityManager() == null ? 
/* 115 */       this : new HashMap();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 120 */     map.put("SecureRandom.Windows-PRNG", "es.mityc.javasign.pkstore.mscapi.mityc.PRNG");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 125 */     map.put("KeyStore.Windows-MY", "es.mityc.javasign.pkstore.mscapi.mityc.KeyStore$MY");
/* 126 */     map.put("KeyStore.Windows-ROOT", "es.mityc.javasign.pkstore.mscapi.mityc.KeyStore$ROOT");
/* 127 */     map.put("KeyStore.Windows-CA", "es.mityc.javasign.pkstore.mscapi.mityc.KeyStore$CA");
/* 128 */     map.put("KeyStore.Windows-LocalMachine-MY", "es.mityc.javasign.pkstore.mscapi.mityc.KeyStore$LocalMachineMY");
/* 129 */     map.put("KeyStore.Windows-LocalMachine-ROOT", "es.mityc.javasign.pkstore.mscapi.mityc.KeyStore$LocalMachineROOT");
/* 130 */     map.put("KeyStore.Windows-LocalMachine-CA", "es.mityc.javasign.pkstore.mscapi.mityc.KeyStore$LocalMachineCA");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 135 */     map.put("Signature.SHA1withRSA", 
/* 136 */       "es.mityc.javasign.pkstore.mscapi.mityc.RSASignature$SHA1");
/* 137 */     map.put("Signature.SHA256withRSA", 
/* 138 */       "es.mityc.javasign.pkstore.mscapi.mityc.RSASignature$SHA256");
/* 139 */     map.put("Signature.SHA384withRSA", 
/* 140 */       "es.mityc.javasign.pkstore.mscapi.mityc.RSASignature$SHA384");
/* 141 */     map.put("Signature.SHA512withRSA", 
/* 142 */       "es.mityc.javasign.pkstore.mscapi.mityc.RSASignature$SHA512");
/* 143 */     map.put("Signature.MD5withRSA", 
/* 144 */       "es.mityc.javasign.pkstore.mscapi.mityc.RSASignature$MD5");
/* 145 */     map.put("Signature.MD2withRSA", 
/* 146 */       "es.mityc.javasign.pkstore.mscapi.mityc.RSASignature$MD2");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 151 */     map.put("Alg.Alias.Signature.RSA", "SHA1withRSA");
/* 152 */     map.put("Alg.Alias.Signature.SHA/RSA", "SHA1withRSA");
/* 153 */     map.put("Alg.Alias.Signature.SHA-1/RSA", "SHA1withRSA");
/* 154 */     map.put("Alg.Alias.Signature.SHA1/RSA", "SHA1withRSA");
/* 155 */     map.put("Alg.Alias.Signature.SHAwithRSA", "SHA1witRSA");
/* 156 */     map.put("Alg.Alias.Signature.RSAWithSHA1", "SHA1withRSA");
/* 157 */     map.put("Alg.Alias.Signature.1.2.840.113549.1.1.5", "SHA1withRSA");
/* 158 */     map.put("Alg.Alias.Signature.OID.1.2.840.113549.1.1.5", "SHA1withRSA");
/* 159 */     map.put("Alg.Alias.Signature.1.3.14.3.2.29", "SHA1withRSA");
/* 160 */     map.put("Alg.Alias.Signature.OID.1.3.14.3.2.29", "SHA1withRSA");
/* 161 */     map.put("Alg.Alias.Signature.SHA1withRSAEncryption", "SHA1withRSA");
/* 162 */     map.put("Alg.Alias.Signature.SHA1WithRSAEncryption", "SHA1withRSA");
/* 163 */     map.put("Alg.Alias.Signature.SHA1RSA", "SHA1withRSA");
/* 164 */     map.put("Alg.Alias.Signature.SHA1WITHRSAENCRYPTION", "SHA1withRSA");
/* 165 */     map.put("Alg.Alias.Signature.1.3.14.3.2.26with1.2.840.113549.1.1.1", "SHA1withRSA");
/* 166 */     map.put("Alg.Alias.Signature.1.3.14.3.2.26with1.2.840.113549.1.1.5", "SHA1withRSA");
/*     */     
/* 168 */     map.put("Alg.Alias.Signature.1.2.840.113549.1.1.11", "SHA256withRSA");
/* 169 */     map.put("Alg.Alias.Signature.OID.1.2.840.113549.1.1.11", "SHA256withRSA");
/* 170 */     map.put("Alg.Alias.Signature.SHA256withRSAEncryption", "SHA256withRSA");
/* 171 */     map.put("Alg.Alias.Signature.SHA256WithRSAEncryption", "SHA256withRSA");
/* 172 */     map.put("Alg.Alias.Signature.SHA256/RSA", "SHA256withRSA");
/* 173 */     map.put("Alg.Alias.Signature.SHA-256/RSA", "SHA256withRSA");
/* 174 */     map.put("Alg.Alias.Signature.SHA256RSA", "SHA256withRSA");
/* 175 */     map.put("Alg.Alias.Signature.SHA256WITHRSAENCRYPTION", "SHA256withRSA");
/*     */     
/* 177 */     map.put("Alg.Alias.Signature.SHA384withRSA", "SHA384withRSA");
/* 178 */     map.put("Alg.Alias.Signature.1.2.840.113549.1.1.12", "SHA384withRSA");
/* 179 */     map.put("Alg.Alias.Signature.OID.1.2.840.113549.1.1.12", "SHA384withRSA");
/* 180 */     map.put("Alg.Alias.Signature.SHA384withRSAEncryption", "SHA384withRSA");
/* 181 */     map.put("Alg.Alias.Signature.SHA384WithRSAEncryption", "SHA384withRSA");
/* 182 */     map.put("Alg.Alias.Signature.SHA384/RSA", "SHA384withRSA");
/* 183 */     map.put("Alg.Alias.Signature.SHA-384/RSA", "SHA384withRSA");
/* 184 */     map.put("Alg.Alias.Signature.SHA384RSA", "SHA384withRSA");
/* 185 */     map.put("Alg.Alias.Signature.SHA384WITHRSAENCRYPTION", "SHA384withRSA");
/*     */     
/* 187 */     map.put("Alg.Alias.Signature.SHA512withRSA", "SHA512withRSA");
/* 188 */     map.put("Alg.Alias.Signature.1.2.840.113549.1.1.13", "SHA512withRSA");
/* 189 */     map.put("Alg.Alias.Signature.OID.1.2.840.113549.1.1.13", "SHA512withRSA");
/* 190 */     map.put("Alg.Alias.Signature.SHA512withRSAEncryption", "SHA512withRSA");
/* 191 */     map.put("Alg.Alias.Signature.SHA512WithRSAEncryption", "SHA512withRSA");
/* 192 */     map.put("Alg.Alias.Signature.SHA512/RSA", "SHA512withRSA");
/* 193 */     map.put("Alg.Alias.Signature.SHA-512/RSA", "SHA512withRSA");
/* 194 */     map.put("Alg.Alias.Signature.SHA512RSA", "SHA512withRSA");
/* 195 */     map.put("Alg.Alias.Signature.SHA512WITHRSAENCRYPTION", "SHA512withRSA");
/*     */     
/*     */ 
/* 198 */     map.put("Signature.SHA1withRSA SupportedKeyClasses", 
/* 199 */       "es.mityc.javasign.pkstore.mscapi.mityc.Key");
/* 200 */     map.put("Signature.SHA256withRSA SupportedKeyClasses", 
/* 201 */       "es.mityc.javasign.pkstore.mscapi.mityc.Key");
/* 202 */     map.put("Signature.SHA384withRSA SupportedKeyClasses", 
/* 203 */       "es.mityc.javasign.pkstore.mscapi.mityc.Key");
/* 204 */     map.put("Signature.SHA512withRSA SupportedKeyClasses", 
/* 205 */       "es.mityc.javasign.pkstore.mscapi.mityc.Key");
/* 206 */     map.put("Signature.MD5withRSA SupportedKeyClasses", 
/* 207 */       "es.mityc.javasign.pkstore.mscapi.mityc.Key");
/* 208 */     map.put("Signature.MD2withRSA SupportedKeyClasses", 
/* 209 */       "es.mityc.javasign.pkstore.mscapi.mityc.Key");
/* 210 */     map.put("Signature.NONEwithRSA SupportedKeyClasses", 
/* 211 */       "es.mityc.javasign.pkstore.mscapi.mityc.Key");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 216 */     map.put("KeyPairGenerator.RSA", 
/* 217 */       "es.mityc.javasign.pkstore.mscapi.mityc.RSAKeyPairGenerator");
/* 218 */     map.put("KeyPairGenerator.RSA KeySize", "1024");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 223 */     map.put("Cipher.RSA", "es.mityc.javasign.pkstore.mscapi.mityc.RSACipher");
/* 224 */     map.put("Cipher.RSA/ECB/PKCS1Padding", 
/* 225 */       "es.mityc.javasign.pkstore.mscapi.mityc.RSACipher");
/* 226 */     map.put("Cipher.RSA SupportedModes", "ECB");
/* 227 */     map.put("Cipher.RSA SupportedPaddings", "PKCS1PADDING");
/* 228 */     map.put("Cipher.RSA SupportedKeyClasses", "es.mityc.javasign.pkstore.mscapi.mityc.Key");
/*     */     
/* 230 */     if (map != this) {
/* 231 */       AccessController.doPrivileged(new PutAllAction(this, map));
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mscapi\mityc\SunMSCAPI_MITyC.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */