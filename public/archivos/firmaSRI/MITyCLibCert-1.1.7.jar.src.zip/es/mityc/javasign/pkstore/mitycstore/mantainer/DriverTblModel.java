/*     */ package es.mityc.javasign.pkstore.mitycstore.mantainer;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DriverTblModel
/*     */   extends AbstractTableModel
/*     */ {
/*  36 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*     */   
/*     */ 
/*  39 */   private String[] columnNames = null;
/*     */   
/*  41 */   private Object[][] data = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DriverTblModel(HashMap<String, String> drvrList)
/*     */   {
/*  48 */     this.columnNames = new String[2];
/*     */     
/*  50 */     this.columnNames[0] = I18N.getLocalMessage("i18n.mityc.cert.mityc.94");
/*     */     
/*  52 */     this.columnNames[1] = I18N.getLocalMessage("i18n.mityc.cert.mityc.95");
/*     */     
/*  54 */     int rows = 0;
/*  55 */     if (drvrList != null) {
/*  56 */       rows = drvrList.size();
/*     */     } else {
/*  58 */       return;
/*     */     }
/*  60 */     this.data = new Object[rows][2];
/*     */     
/*  62 */     Iterator<Map.Entry<String, String>> contents = drvrList.entrySet().iterator();
/*  63 */     Map.Entry<String, String> content = null;
/*  64 */     int i = 0;
/*  65 */     while (contents.hasNext()) {
/*  66 */       content = (Map.Entry)contents.next();
/*     */       
/*  68 */       this.data[i][0] = content.getKey();
/*     */       
/*     */ 
/*  71 */       this.data[i][1] = content.getValue();
/*  72 */       i++;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/*  81 */     return this.columnNames.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRowCount()
/*     */   {
/*  89 */     return this.data.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getValueAt(int fil, int col)
/*     */   {
/*  99 */     if ((fil >= 0) && (fil < this.data.length) && (col >= 0) && (col < 2)) {
/* 100 */       return this.data[fil][col];
/*     */     }
/* 102 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getColumnName(int col)
/*     */   {
/* 113 */     return this.columnNames[col];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> getColumnClass(int columnIndex)
/*     */   {
/* 123 */     return String.class;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addRow(String name, String value)
/*     */   {
/* 132 */     Object[][] newData = new Object[this.data.length + 1][2];
/* 133 */     for (int i = 0; i < this.data.length; i++) {
/* 134 */       newData[i][0] = this.data[i][0];
/* 135 */       newData[i][1] = this.data[i][1];
/*     */     }
/* 137 */     newData[this.data.length][0] = name;
/* 138 */     newData[this.data.length][1] = value;
/* 139 */     this.data = newData;
/* 140 */     fireTableDataChanged();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeRow(int index)
/*     */   {
/* 148 */     if ((index >= 0) && (index < this.data.length)) {
/* 149 */       Object[][] newData = new Object[this.data.length - 1][2];
/* 150 */       int newIndex = 0;
/* 151 */       for (int i = 0; i < this.data.length; i++)
/* 152 */         if (i != index)
/*     */         {
/*     */ 
/*     */ 
/* 156 */           newData[newIndex][0] = this.data[i][0];
/* 157 */           newData[newIndex][1] = this.data[i][1];
/* 158 */           newIndex++;
/*     */         }
/* 160 */       this.data = newData;
/* 161 */       fireTableRowsDeleted(index, index);
/*     */     }
/*     */     else {}
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mitycstore\mantainer\DriverTblModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */