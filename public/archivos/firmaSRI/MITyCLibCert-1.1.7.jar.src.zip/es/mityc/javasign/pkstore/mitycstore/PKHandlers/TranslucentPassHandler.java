/*    */ package es.mityc.javasign.pkstore.mitycstore.PKHandlers;
/*    */ 
/*    */ import es.mityc.javasign.pkstore.DefaultPassStoreKS;
/*    */ import java.security.cert.X509Certificate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TranslucentPassHandler
/*    */   extends DefaultPassStoreKS
/*    */ {
/*    */   public char[] getPassword(X509Certificate certificate, String alias)
/*    */   {
/* 30 */     return new char[0];
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mitycstore\PKHandlers\TranslucentPassHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */