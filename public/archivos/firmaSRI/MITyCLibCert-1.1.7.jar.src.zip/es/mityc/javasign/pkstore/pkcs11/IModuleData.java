package es.mityc.javasign.pkstore.pkcs11;

import java.util.List;

public abstract interface IModuleData
{
  public abstract List<IProviderData> getProvidersData();
  
  public abstract void updateModule();
  
  public abstract String getName();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\pkcs11\IModuleData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */