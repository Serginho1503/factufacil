/*    */ package es.mityc.javasign.pkstore.mitycstore.mantainer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeTreeNode
/*    */ {
/* 26 */   private String nombre = null;
/*    */   
/* 28 */   private String toolTip = null;
/*    */   
/* 30 */   private Object datosAsociados = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public TypeTreeNode() {}
/*    */   
/*    */ 
/*    */ 
/*    */   public TypeTreeNode(String nombreNodo, Object datosAsoc)
/*    */   {
/* 41 */     this.nombre = nombreNodo;
/* 42 */     this.toolTip = nombreNodo;
/* 43 */     this.datosAsociados = datosAsoc;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getNombre()
/*    */   {
/* 51 */     return this.nombre;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setNombre(String name)
/*    */   {
/* 58 */     this.nombre = name;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getToolTip()
/*    */   {
/* 65 */     return this.toolTip;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setToolTip(String toolTipNodo)
/*    */   {
/* 72 */     this.toolTip = toolTipNodo;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Object getDatosAsociados()
/*    */   {
/* 79 */     return this.datosAsociados;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setDatosAsociados(Object datosAsoc)
/*    */   {
/* 86 */     this.datosAsociados = datosAsoc;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 95 */     return this.nombre;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mitycstore\mantainer\TypeTreeNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */