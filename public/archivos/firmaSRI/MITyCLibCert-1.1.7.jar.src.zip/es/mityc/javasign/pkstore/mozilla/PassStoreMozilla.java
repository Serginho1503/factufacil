/*     */ package es.mityc.javasign.pkstore.mozilla;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import java.util.MissingResourceException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.mozilla.jss.util.Password;
/*     */ import org.mozilla.jss.util.PasswordCallback;
/*     */ import org.mozilla.jss.util.PasswordCallback.GiveUpException;
/*     */ import org.mozilla.jss.util.PasswordCallbackInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PassStoreMozilla
/*     */   implements PasswordCallback, IPINDialogConfigurable
/*     */ {
/*  37 */   private static final Log LOG = LogFactory.getLog(PassStoreMozilla.class);
/*     */   
/*  39 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*     */   
/*     */ 
/*  42 */   private String title = null;
/*     */   
/*  44 */   private String pinMessage = null;
/*     */   
/*  46 */   private IPINDialogConfigurable.MESSAGES_MODE mode = IPINDialogConfigurable.MESSAGES_MODE.AUTO;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Password getPasswordAgain(PasswordCallbackInfo info)
/*     */     throws PasswordCallback.GiveUpException
/*     */   {
/*     */     try
/*     */     {
/*  59 */       PINDialog pinDialog = new PINDialog(null);
/*  60 */       switch (this.mode) {
/*     */       case AUTO_TOKEN: 
/*  62 */         pinDialog.setTitle(info.getName());
/*  63 */         if (this.pinMessage != null) {
/*  64 */           pinDialog.setPINMessage(this.pinMessage);
/*     */         }
/*  66 */         break;
/*     */       case EXPLICIT: 
/*  68 */         if (this.title != null) {
/*  69 */           pinDialog.setTitle(this.title);
/*     */         }
/*  71 */         if (this.pinMessage != null) {
/*  72 */           pinDialog.setPINMessage(this.pinMessage);
/*     */         }
/*     */         break;
/*     */       }
/*     */       
/*  77 */       pinDialog.pack();
/*  78 */       pinDialog.setVisible(true);
/*     */       
/*  80 */       if (pinDialog.isCancelado()) {
/*  81 */         throw new PasswordCallback.GiveUpException();
/*     */       }
/*     */       
/*  84 */       char[] pass = pinDialog.getPassword();
/*  85 */       pinDialog.dispose();
/*  86 */       return new Password(pass);
/*     */     } catch (MissingResourceException ex) {
/*  88 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.smartcards.GUI.1"), ex);
/*  89 */       throw new PasswordCallback.GiveUpException();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Password getPasswordFirstAttempt(PasswordCallbackInfo info)
/*     */     throws PasswordCallback.GiveUpException
/*     */   {
/*     */     try
/*     */     {
/* 104 */       PINDialog pinDialog = new PINDialog(null);
/* 105 */       switch (this.mode) {
/*     */       case AUTO_TOKEN: 
/* 107 */         pinDialog.setTitle(info.getName());
/* 108 */         if (this.pinMessage != null) {
/* 109 */           pinDialog.setPINMessage(this.pinMessage);
/*     */         }
/* 111 */         break;
/*     */       case EXPLICIT: 
/* 113 */         if (this.title != null) {
/* 114 */           pinDialog.setTitle(this.title);
/*     */         }
/* 116 */         if (this.pinMessage != null) {
/* 117 */           pinDialog.setPINMessage(this.pinMessage);
/*     */         }
/*     */         break;
/*     */       }
/*     */       
/* 122 */       pinDialog.pack();
/* 123 */       pinDialog.setVisible(true);
/* 124 */       if (pinDialog.isCancelado()) {
/* 125 */         throw new PasswordCallback.GiveUpException();
/*     */       }
/* 127 */       char[] pass = pinDialog.getPassword();
/* 128 */       pinDialog.dispose();
/* 129 */       return new Password(pass);
/*     */     } catch (MissingResourceException ex) {
/* 131 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.smartcards.GUI.1"), ex);
/* 132 */       throw new PasswordCallback.GiveUpException();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPINMessage(String message)
/*     */   {
/* 143 */     this.pinMessage = new String(message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTitle(String titleWindow)
/*     */   {
/* 152 */     this.title = new String(titleWindow);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessagesMode(IPINDialogConfigurable.MESSAGES_MODE messagesMode)
/*     */   {
/* 163 */     this.mode = messagesMode;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mozilla\PassStoreMozilla.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */