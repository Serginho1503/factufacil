/*     */ package es.mityc.javasign.pkstore.pkcs11;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigMultiPKCS11
/*     */ {
/*  34 */   private ArrayList<IModuleData> providers = new ArrayList();
/*     */   
/*  36 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String MODULE_CLASS = "es.mityc.javasign.pkstore.pkcs11.SunP11ModuleData";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String SUN_CLASS = "sun.security.pkcs11.SunPKCS11";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSunProvider(String name, String lib)
/*     */     throws NoSuchProviderException
/*     */   {
/*  56 */     testSunPKCS11Library();
/*  57 */     this.providers.add(getSunP11ModuleData(name, lib));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private IModuleData getSunP11ModuleData(String name, String lib)
/*     */     throws NoSuchProviderException
/*     */   {
/*     */     try
/*     */     {
/*  69 */       Class<?> prov = Class.forName("es.mityc.javasign.pkstore.pkcs11.SunP11ModuleData");
/*  70 */       Constructor<?> constructor = prov.getConstructor(new Class[] { String.class, String.class });
/*  71 */       return (IModuleData)constructor.newInstance(new Object[] { name, lib });
/*     */     } catch (ClassNotFoundException ex) {
/*  73 */       throw new NoSuchProviderException(I18N.getLocalMessage("i18n.mityc.cert.p11.16", new Object[] { ex.getMessage() }));
/*     */     } catch (SecurityException ex) {
/*  75 */       throw new NoSuchProviderException(I18N.getLocalMessage("i18n.mityc.cert.p11.16", new Object[] { ex.getMessage() }));
/*     */     } catch (NoSuchMethodException ex) {
/*  77 */       throw new NoSuchProviderException(I18N.getLocalMessage("i18n.mityc.cert.p11.16", new Object[] { ex.getMessage() }));
/*     */     } catch (IllegalArgumentException ex) {
/*  79 */       throw new NoSuchProviderException(I18N.getLocalMessage("i18n.mityc.cert.p11.16", new Object[] { ex.getMessage() }));
/*     */     } catch (InstantiationException ex) {
/*  81 */       throw new NoSuchProviderException(I18N.getLocalMessage("i18n.mityc.cert.p11.16", new Object[] { ex.getMessage() }));
/*     */     } catch (IllegalAccessException ex) {
/*  83 */       throw new NoSuchProviderException(I18N.getLocalMessage("i18n.mityc.cert.p11.16", new Object[] { ex.getMessage() }));
/*     */     } catch (InvocationTargetException ex) {
/*  85 */       throw new NoSuchProviderException(I18N.getLocalMessage("i18n.mityc.cert.p11.16", new Object[] { ex.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void testSunPKCS11Library()
/*     */     throws NoSuchProviderException
/*     */   {
/*     */     try
/*     */     {
/*  96 */       Class<?> prov = Class.forName("sun.security.pkcs11.SunPKCS11");
/*  97 */       if (prov == null) {
/*  98 */         throw new NoSuchProviderException(I18N.getLocalMessage("i18n.mityc.cert.p11.16", new Object[] { I18N.getLocalMessage("i18n.mityc.cert.p11.17") }));
/*     */       }
/*     */     } catch (ClassNotFoundException ex) {
/* 101 */       throw new NoSuchProviderException(I18N.getLocalMessage("i18n.mityc.cert.p11.16", new Object[] { ex.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<IModuleData> getProviders()
/*     */   {
/* 111 */     return this.providers;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\pkcs11\ConfigMultiPKCS11.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */