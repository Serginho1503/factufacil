/*    */ package es.mityc.javasign.pkstore.mitycstore.PKHandlers;
/*    */ 
/*    */ import es.mityc.javasign.i18n.I18nFactory;
/*    */ import es.mityc.javasign.i18n.II18nManager;
/*    */ import es.mityc.javasign.pkstore.DefaultPassStoreKS;
/*    */ import es.mityc.javasign.pkstore.mitycstore.CertUtil;
/*    */ import es.mityc.javasign.pkstore.mitycstore.mantainer.DialogoCert;
/*    */ import java.security.cert.X509Certificate;
/*    */ import javax.swing.JOptionPane;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WarnPassHandler
/*    */   extends DefaultPassStoreKS
/*    */ {
/* 40 */   Log LOG = LogFactory.getLog(DialogoCert.class);
/*    */   
/* 42 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*    */   
/*    */   public char[] getPassword(X509Certificate certificate, String alias)
/*    */   {
/* 46 */     String certCN = CertUtil.extractName(certificate.getSubjectX500Principal());
/*    */     
/*    */ 
/* 49 */     int res = JOptionPane.showConfirmDialog(null, 
/* 50 */       I18N.getLocalMessage("i18n.mityc.cert.mityc.4", new Object[] { certCN }), 
/* 51 */       I18N.getLocalMessage("i18n.mityc.cert.mityc.5"), 
/* 52 */       2);
/* 53 */     if (res == 2) {
/* 54 */       if (this.LOG.isDebugEnabled()) {
/* 55 */         this.LOG.debug("Acceso a clave privada cancelado por el usuario");
/*    */       }
/* 57 */       return null;
/*    */     }
/* 59 */     return new char[0];
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mitycstore\PKHandlers\WarnPassHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */