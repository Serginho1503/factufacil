/*     */ package es.mityc.javasign.pkstore.dniejava;
/*     */ 
/*     */ import es.gob.jmulticard.apdu.connection.ApduConnectionException;
/*     */ import es.gob.jmulticard.apdu.connection.CardNotPresentException;
/*     */ import es.gob.jmulticard.apdu.connection.NoReadersFoundException;
/*     */ import es.gob.jmulticard.card.AuthenticationModeLockedException;
/*     */ import es.gob.jmulticard.card.CardException;
/*     */ import es.gob.jmulticard.card.InvalidCardException;
/*     */ import es.gob.jmulticard.jse.provider.DnieProvider;
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.pkstore.CertStoreException;
/*     */ import es.mityc.javasign.pkstore.IPKStoreManager;
/*     */ import es.mityc.javasign.pkstore.keystore.KSStore;
/*     */ import java.io.IOException;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.Provider;
/*     */ import java.security.Provider.Service;
/*     */ import java.security.ProviderException;
/*     */ import java.security.Security;
/*     */ import java.security.cert.CertPath;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DNIeJavaStore
/*     */   implements IPKStoreManager
/*     */ {
/*  58 */   private static final Log LOG = LogFactory.getLog(DNIeJavaStore.class);
/*     */   
/*  60 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*     */   
/*     */   private static final String DNI_KEYSTORE = "DNI";
/*     */   private static final String DNI_PROVIDER = "DNIeJCAProvider";
/*  64 */   private IPKStoreManager pkStore = null;
/*     */   
/*     */   public DNIeJavaStore() throws CertStoreException {
/*     */     try {
/*  68 */       Provider p = new DnieProvider();
/*  69 */       Security.addProvider(p);
/*  70 */       KeyStore ks = KeyStore.getInstance("DNI");
/*  71 */       ks.load(null, null);
/*     */       
/*  73 */       this.pkStore = new KSStore(ks, null, "".toCharArray());
/*  74 */       if (LOG.isDebugEnabled()) {
/*  75 */         Iterator<Provider.Service> services = Security.getProvider("DNIeJCAProvider").getServices().iterator();
/*  76 */         LOG.debug("Servicios disponibles: ");
/*  77 */         while (services.hasNext()) {
/*  78 */           Provider.Service ser = (Provider.Service)services.next();
/*  79 */           LOG.debug(ser);
/*  80 */           LOG.debug("Algoritmo disponible: " + ser.getAlgorithm());
/*     */         }
/*     */       }
/*     */     } catch (KeyStoreException ex) {
/*  84 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.dnie.1", new Object[] { ex.getMessage() }), ex);
/*     */     } catch (NoSuchAlgorithmException ex) {
/*  86 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.dnie.1", new Object[] { ex.getMessage() }), ex);
/*     */     } catch (CertificateException ex) {
/*  88 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.dnie.1", new Object[] { ex.getMessage() }), ex);
/*     */     } catch (CardNotPresentException ex) {
/*  90 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.dnie.2", new Object[] { ex.getMessage() }), ex);
/*     */     } catch (AuthenticationModeLockedException ex) {
/*  92 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.dnie.3", new Object[] { ex.getMessage() }), ex);
/*     */     } catch (InvalidCardException ex) {
/*  94 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.dnie.4", new Object[] { ex.getMessage() }), ex);
/*     */     } catch (NoReadersFoundException ex) {
/*  96 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.dnie.5", new Object[] { ex.getMessage() }), ex);
/*     */     } catch (IllegalStateException ex) {
/*  98 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.dnie.6", new Object[] { ex.getMessage() }), ex);
/*     */     } catch (CardException ex) {
/* 100 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.dnie.7", new Object[] { ex.getMessage() }), ex);
/*     */     } catch (ApduConnectionException ex) {
/* 102 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.dnie.7", new Object[] { ex.getMessage() }), ex);
/*     */     } catch (IOException ex) {
/* 104 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.dnie.1", new Object[] { ex.getMessage() }), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Provider getProvider(X509Certificate cert)
/*     */   {
/* 114 */     return Security.getProvider("DNIeJCAProvider");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CertPath getCertPath(X509Certificate certificate)
/*     */     throws CertStoreException
/*     */   {
/*     */     try
/*     */     {
/* 126 */       return this.pkStore != null ? this.pkStore.getCertPath(certificate) : null;
/*     */     } catch (AuthenticationModeLockedException ex) {
/* 128 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.dnie.3", new Object[] { ex.getMessage() }), ex);
/*     */     } catch (ProviderException ex) {
/* 130 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.dnie.7", new Object[] { ex.getMessage() }), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PrivateKey getPrivateKey(X509Certificate certificate)
/*     */     throws CertStoreException
/*     */   {
/*     */     try
/*     */     {
/* 143 */       return this.pkStore != null ? this.pkStore.getPrivateKey(certificate) : null;
/*     */     } catch (AuthenticationModeLockedException ex) {
/* 145 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.dnie.3", new Object[] { ex.getMessage() }), ex);
/*     */     } catch (ProviderException ex) {
/* 147 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.dnie.7", new Object[] { ex.getMessage() }), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<X509Certificate> getSignCertificates()
/*     */     throws CertStoreException
/*     */   {
/*     */     try
/*     */     {
/* 159 */       return this.pkStore != null ? this.pkStore.getSignCertificates() : null;
/*     */     } catch (AuthenticationModeLockedException ex) {
/* 161 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.dnie.3", new Object[] { ex.getMessage() }), ex);
/*     */     } catch (ProviderException ex) {
/* 163 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.dnie.7", new Object[] { ex.getMessage() }), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<X509Certificate> getTrustCertificates()
/*     */     throws CertStoreException
/*     */   {
/*     */     try
/*     */     {
/* 175 */       return this.pkStore != null ? this.pkStore.getTrustCertificates() : null;
/*     */     } catch (AuthenticationModeLockedException ex) {
/* 177 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.dnie.3", new Object[] { ex.getMessage() }), ex);
/*     */     } catch (ProviderException ex) {
/* 179 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.dnie.7", new Object[] { ex.getMessage() }), ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public List<X509Certificate> getPublicCertificates() throws CertStoreException {
/*     */     try {
/* 185 */       return this.pkStore != null ? this.pkStore.getPublicCertificates() : null;
/*     */     } catch (AuthenticationModeLockedException ex) {
/* 187 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.dnie.3", new Object[] { ex.getMessage() }), ex);
/*     */     } catch (ProviderException ex) {
/* 189 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.dnie.7", new Object[] { ex.getMessage() }), ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\dniejava\DNIeJavaStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */