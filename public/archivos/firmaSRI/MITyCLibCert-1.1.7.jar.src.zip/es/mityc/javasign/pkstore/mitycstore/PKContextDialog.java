/*     */ package es.mityc.javasign.pkstore.mitycstore;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Frame;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPasswordField;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PKContextDialog
/*     */   extends JDialog
/*     */ {
/*  56 */   Log logger = LogFactory.getLog(PKContextDialog.class);
/*     */   
/*  58 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*     */   
/*     */ 
/*  61 */   private MITyCStore ks = null;
/*     */   
/*     */ 
/*  64 */   private Frame owner = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PKContextDialog(Frame ownerFrame, MITyCStore keyStore)
/*     */   {
/*  72 */     super(ownerFrame);
/*  73 */     this.owner = ownerFrame;
/*  74 */     this.ks = keyStore;
/*  75 */     dialogInit();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getContext()
/*     */   {
/*  83 */     MITyCStore tmp8_5 = this.ks;tmp8_5.getClass();MITyCStore.AliasFormat context = new MITyCStore.AliasFormat(tmp8_5, "");
/*  84 */     boolean isPro = this.protectedRadio.isSelected();
/*  85 */     boolean isCached = this.cachedCheck.isSelected();
/*  86 */     boolean mayWarn = this.alertCheck.isSelected();
/*     */     
/*  88 */     return context.genAliasPrefix(isPro, isCached, mayWarn);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected char[] getPass()
/*     */   {
/*  96 */     return this.passField.getPassword();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void dialogInit()
/*     */   {
/* 104 */     super.dialogInit();
/* 105 */     this.panPrincipal = new JPanel();
/*     */     
/* 107 */     this.panPrincipal.setBorder(BorderFactory.createTitledBorder(I18N.getLocalMessage("i18n.mityc.cert.mityc.18")));
/*     */     
/*     */ 
/* 110 */     this.protectedRadio = new JRadioButton(I18N.getLocalMessage("i18n.mityc.cert.mityc.19"));
/*     */     
/* 112 */     this.passLabel = new JLabel(I18N.getLocalMessage("i18n.mityc.cert.mityc.20"));
/* 113 */     this.passField = new JPasswordField();
/*     */     
/* 115 */     this.cachedCheck = new JCheckBox(I18N.getLocalMessage("i18n.mityc.cert.mityc.21"));
/*     */     
/* 117 */     this.unprotectedRadio = new JRadioButton(I18N.getLocalMessage("i18n.mityc.cert.mityc.22"));
/*     */     
/* 119 */     this.alertCheck = new JCheckBox(I18N.getLocalMessage("i18n.mityc.cert.mityc.23"));
/*     */     
/* 121 */     this.aceptarButton = new JButton();
/*     */     
/* 123 */     ButtonGroup group = new ButtonGroup();
/* 124 */     group.add(this.protectedRadio);
/* 125 */     group.add(this.unprotectedRadio);
/*     */     
/* 127 */     this.protectedRadio.addChangeListener(new ChangeListener() {
/*     */       public void stateChanged(ChangeEvent e) {
/* 129 */         boolean sel = ((JRadioButton)e.getSource()).isSelected();
/* 130 */         PKContextDialog.this.passLabel.setEnabled(sel);
/* 131 */         PKContextDialog.this.passField.setEnabled(sel);
/* 132 */         PKContextDialog.this.cachedCheck.setEnabled(sel);
/*     */         
/* 134 */         PKContextDialog.this.panPrincipal.repaint();
/*     */       }
/*     */       
/* 137 */     });
/* 138 */     this.unprotectedRadio.addChangeListener(new ChangeListener() {
/*     */       public void stateChanged(ChangeEvent e) {
/* 140 */         PKContextDialog.this.alertCheck.setEnabled(((JRadioButton)e.getSource()).isSelected());
/*     */         
/* 142 */         PKContextDialog.this.panPrincipal.repaint();
/*     */       }
/*     */       
/*     */ 
/* 146 */     });
/* 147 */     this.protectedRadio.setSelected(true);
/* 148 */     this.alertCheck.setEnabled(false);
/*     */     
/* 150 */     setLayout(new GridBagLayout());
/* 151 */     this.panPrincipal.setLayout(new GridBagLayout());
/*     */     
/*     */ 
/* 154 */     GridBagConstraints protectedRadioConstraints = new GridBagConstraints();
/* 155 */     protectedRadioConstraints.gridx = 0;
/* 156 */     protectedRadioConstraints.gridy = 0;
/* 157 */     protectedRadioConstraints.weightx = 1.0D;
/* 158 */     protectedRadioConstraints.gridwidth = 4;
/* 159 */     protectedRadioConstraints.fill = 2;
/* 160 */     protectedRadioConstraints.insets = new Insets(3, 10, 0, 0);
/* 161 */     this.panPrincipal.add(this.protectedRadio, protectedRadioConstraints);
/*     */     
/* 163 */     GridBagConstraints passLabelConstraints = new GridBagConstraints();
/* 164 */     passLabelConstraints.gridx = 1;
/* 165 */     passLabelConstraints.gridy = 1;
/* 166 */     passLabelConstraints.insets = new Insets(3, 30, 0, 5);
/* 167 */     this.panPrincipal.add(this.passLabel, passLabelConstraints);
/*     */     
/* 169 */     GridBagConstraints passFieldConstraints = new GridBagConstraints();
/* 170 */     passFieldConstraints.gridx = 2;
/* 171 */     passFieldConstraints.gridy = 1;
/* 172 */     passFieldConstraints.weightx = 1.0D;
/* 173 */     passFieldConstraints.gridwidth = 2;
/* 174 */     passFieldConstraints.fill = 2;
/* 175 */     passFieldConstraints.insets = new Insets(3, 0, 2, 20);
/* 176 */     this.panPrincipal.add(this.passField, passFieldConstraints);
/*     */     
/* 178 */     GridBagConstraints cachedCheckConstraints = new GridBagConstraints();
/* 179 */     cachedCheckConstraints.gridx = 2;
/* 180 */     cachedCheckConstraints.gridy = 2;
/* 181 */     cachedCheckConstraints.weightx = 1.0D;
/* 182 */     cachedCheckConstraints.weighty = 1.0D;
/* 183 */     cachedCheckConstraints.gridwidth = 4;
/* 184 */     cachedCheckConstraints.fill = 2;
/* 185 */     this.panPrincipal.add(this.cachedCheck, cachedCheckConstraints);
/*     */     
/* 187 */     GridBagConstraints unprotectedRadioConstraints = new GridBagConstraints();
/* 188 */     unprotectedRadioConstraints.gridx = 0;
/* 189 */     unprotectedRadioConstraints.gridy = 3;
/* 190 */     unprotectedRadioConstraints.weightx = 1.0D;
/* 191 */     unprotectedRadioConstraints.gridwidth = 4;
/* 192 */     unprotectedRadioConstraints.fill = 2;
/* 193 */     unprotectedRadioConstraints.insets = new Insets(5, 10, 0, 0);
/* 194 */     this.panPrincipal.add(this.unprotectedRadio, unprotectedRadioConstraints);
/*     */     
/* 196 */     GridBagConstraints alertCheckConstraints = new GridBagConstraints();
/* 197 */     alertCheckConstraints.gridx = 2;
/* 198 */     alertCheckConstraints.gridy = 4;
/* 199 */     alertCheckConstraints.weightx = 1.0D;
/* 200 */     alertCheckConstraints.gridwidth = 2;
/* 201 */     alertCheckConstraints.fill = 2;
/* 202 */     this.panPrincipal.add(this.alertCheck, alertCheckConstraints);
/*     */     
/* 204 */     GridBagConstraints aceptarButtonConstraints = new GridBagConstraints();
/* 205 */     aceptarButtonConstraints.gridx = 2;
/* 206 */     aceptarButtonConstraints.gridy = 5;
/* 207 */     aceptarButtonConstraints.insets = new Insets(30, 60, 10, 0);
/*     */     
/* 209 */     this.aceptarButton.setText(I18N.getLocalMessage("i18n.mityc.cert.smartcards.GUI.accept"));
/* 210 */     this.aceptarButton.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 212 */         PKContextDialog.this.jAceptarButtonActionPerformed();
/*     */       }
/* 214 */     });
/* 215 */     this.panPrincipal.add(this.aceptarButton, aceptarButtonConstraints);
/*     */     
/*     */ 
/* 218 */     GridBagConstraints panPrincipalConstraints = new GridBagConstraints();
/* 219 */     panPrincipalConstraints.fill = 1;
/* 220 */     panPrincipalConstraints.weightx = 1.0D;
/* 221 */     panPrincipalConstraints.weighty = 1.0D;
/*     */     
/* 223 */     add(this.panPrincipal, panPrincipalConstraints);
/*     */     
/*     */ 
/* 226 */     setTitle(I18N.getLocalMessage("i18n.mityc.cert.mityc.24"));
/* 227 */     setSize(400, 250);
/* 228 */     setLocationRelativeTo(this.owner);
/* 229 */     if (this.owner == null) {
/* 230 */       Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
/* 231 */       setLocation(screenSize.width / 2 - getWidth() / 2, screenSize.height / 2 - getHeight() / 2);
/*     */     }
/* 233 */     setModal(true);
/* 234 */     setResizable(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void jAceptarButtonActionPerformed()
/*     */   {
/* 242 */     setVisible(false);
/* 243 */     dispose();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 248 */   private JPanel panPrincipal = null;
/*     */   
/*     */ 
/* 251 */   private JButton aceptarButton = null;
/*     */   
/*     */ 
/* 254 */   private JRadioButton protectedRadio = null;
/*     */   
/* 256 */   private JRadioButton unprotectedRadio = null;
/*     */   
/*     */ 
/* 259 */   private JLabel passLabel = null;
/*     */   
/* 261 */   private JPasswordField passField = null;
/*     */   
/*     */ 
/* 264 */   private JCheckBox cachedCheck = null;
/*     */   
/* 266 */   private JCheckBox alertCheck = null;
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mitycstore\PKContextDialog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */