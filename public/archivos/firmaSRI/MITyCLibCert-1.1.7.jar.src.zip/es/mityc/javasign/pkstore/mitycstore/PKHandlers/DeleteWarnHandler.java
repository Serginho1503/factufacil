/*    */ package es.mityc.javasign.pkstore.mitycstore.PKHandlers;
/*    */ 
/*    */ import es.mityc.javasign.i18n.I18nFactory;
/*    */ import es.mityc.javasign.i18n.II18nManager;
/*    */ import es.mityc.javasign.pkstore.DefaultPassStoreKS;
/*    */ import es.mityc.javasign.pkstore.mitycstore.CertUtil;
/*    */ import es.mityc.javasign.pkstore.mitycstore.mantainer.DialogoCert;
/*    */ import java.security.cert.X509Certificate;
/*    */ import javax.swing.JDialog;
/*    */ import javax.swing.JOptionPane;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeleteWarnHandler
/*    */   extends DefaultPassStoreKS
/*    */ {
/* 41 */   Log logger = LogFactory.getLog(DialogoCert.class);
/*    */   
/* 43 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public char[] getPassword(X509Certificate certificate, String alias)
/*    */   {
/* 54 */     String certCN = CertUtil.extractName(certificate.getSubjectX500Principal());
/*    */     
/* 56 */     Object[] options = {
/* 57 */       I18N.getLocalMessage("i18n.mityc.cert.smartcards.GUI.cancel"), 
/* 58 */       I18N.getLocalMessage("i18n.mityc.cert.smartcards.GUI.accept") };
/*    */     
/* 60 */     JOptionPane confirmDialog = new JOptionPane(
/*    */     
/* 62 */       I18N.getLocalMessage("i18n.mityc.cert.mityc.83", new Object[] { certCN }), 
/* 63 */       3, 
/* 64 */       1, 
/* 65 */       null, 
/* 66 */       options, 
/* 67 */       options[0]);
/*    */     
/*    */ 
/* 70 */     JDialog dialog = confirmDialog.createDialog(null, I18N.getLocalMessage("i18n.mityc.cert.mityc.5"));
/*    */     
/* 72 */     dialog.setVisible(true);
/* 73 */     dialog.dispose();
/*    */     
/*    */ 
/* 76 */     Object selectedValue = confirmDialog.getValue();
/* 77 */     String res = null;
/* 78 */     if ((selectedValue != null) && ((selectedValue instanceof String))) {
/* 79 */       res = String.valueOf(selectedValue);
/*    */     }
/*    */     
/* 82 */     if ((res != null) && (options[1].equals(res))) {
/* 83 */       return new char[0];
/*    */     }
/* 85 */     if (this.logger.isDebugEnabled()) {
/* 86 */       this.logger.debug("Acceso a clave privada cancelado por el usuario");
/*    */     }
/* 88 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mitycstore\PKHandlers\DeleteWarnHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */