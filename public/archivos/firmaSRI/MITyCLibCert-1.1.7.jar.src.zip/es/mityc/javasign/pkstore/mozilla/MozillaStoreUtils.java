/*      */ package es.mityc.javasign.pkstore.mozilla;
/*      */ 
/*      */ import es.mityc.javasign.exception.CopyFileException;
/*      */ import es.mityc.javasign.i18n.I18nFactory;
/*      */ import es.mityc.javasign.i18n.II18nManager;
/*      */ import es.mityc.javasign.pkstore.CertStoreException;
/*      */ import es.mityc.javasign.utils.CopyFilesTool;
/*      */ import es.mityc.javasign.utils.OSTool;
/*      */ import es.mityc.javasign.utils.OSTool.OS;
/*      */ import es.mityc.javasign.utils.WinRegistryUtils;
/*      */ import iaik.pkcs.pkcs11.objects.ByteArrayAttribute;
/*      */ import iaik.pkcs.pkcs11.objects.X509PublicKeyCertificate;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.lang.reflect.Method;
/*      */ import java.security.cert.CertificateEncodingException;
/*      */ import java.security.cert.CertificateException;
/*      */ import java.security.cert.CertificateFactory;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.List;
/*      */ import java.util.MissingResourceException;
/*      */ import java.util.ResourceBundle;
/*      */ import java.util.Vector;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.mozilla.jss.util.PasswordCallback;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MozillaStoreUtils
/*      */ {
/*   65 */   private static final Log LOG = LogFactory.getLog(MozillaStoreUtils.class);
/*      */   
/*   67 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*      */   private static final String STR_MOZILLA = "mozilla";
/*      */   
/*   70 */   public static enum LIB_MODE { FULL,  ONLY_JSS,  ONLY_PKCS11;
/*      */   }
/*      */   
/*      */   private static final String STR_PASS_HANDLER = "passCallbackHandler";
/*      */   public MozillaStoreUtils()
/*      */     throws CertStoreException
/*      */   {}
/*      */   
/*   78 */   private static String tmpDir = "";
/*      */   
/*      */   private static final String SOFTOKN3_DLL = "softokn3.dll";
/*      */   
/*      */   private static final String MSVCR100_DLL = "msvcr100.dll";
/*      */   
/*      */   private static final String MOZGLUE_DLL = "mozglue.dll";
/*      */   
/*      */   private static final String NSS3_DLL = "nss3.dll";
/*      */   
/*      */   private static final String NSPR4_SO = "/lib/libnspr4.so";
/*      */   
/*      */   protected static synchronized String initialize(String profile, LIB_MODE mode)
/*      */     throws CertStoreException
/*      */   {
/*   93 */     if (LOG.isDebugEnabled()) {
/*   94 */       LOG.debug("Inicializando CSP Firefox. Profile: " + profile + "\nModo: " + mode);
/*      */     }
/*      */     
/*   97 */     if (profile == null) {
/*      */       try {
/*   99 */         profile = getMozillaUserProfileDirectory();
/*  100 */         if (LOG.isDebugEnabled()) {
/*  101 */           LOG.debug("Encontrada ruta al perfil de firefox: " + profile);
/*      */         }
/*      */       } catch (Exception e) {
/*  104 */         LOG.debug("No se encontró la ruta al perfil", e);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  109 */     String rutaFirefox = null;
/*      */     try {
/*  111 */       rutaFirefox = getSystemNSSLibDir();
/*  112 */       if (LOG.isDebugEnabled()) {
/*  113 */         LOG.debug("Encontrada ruta al NSS de firefox: " + rutaFirefox);
/*      */       }
/*      */     } catch (Exception e) {
/*  116 */       LOG.debug("No se pudo encontrar la ruta al NSS de Firefox", e);
/*      */     }
/*      */     
/*  119 */     Vector<String> arrayACargar = new Vector();
/*      */     
/*  121 */     if (rutaFirefox != null) {
/*  122 */       int i = rutaFirefox.indexOf("firefox.exe");
/*  123 */       if (i != -1) {
/*  124 */         if ((rutaFirefox = rutaFirefox.substring(0, i)).startsWith("\""))
/*  125 */           rutaFirefox = rutaFirefox.substring(1);
/*  126 */         tmpDir = rutaFirefox;
/*      */       }
/*      */       
/*  129 */       arrayACargar = getNSSDependencies(rutaFirefox);
/*      */       
/*  131 */       Vector<String> dlls = copyLibraries(mode, rutaFirefox);
/*  132 */       if (dlls != null) {
/*  133 */         arrayACargar.addAll(dlls);
/*      */       } else
/*  135 */         throw new CertStoreException("No se pudo copiar la librería de enlace con NSS");
/*      */     } else {
/*  137 */       if (LOG.isDebugEnabled()) {
/*  138 */         LOG.debug("No se detectó NSS.- Se provee de una copia interna");
/*      */       }
/*  140 */       arrayACargar.add("NeedCopy");
/*      */     }
/*      */     try
/*      */     {
/*  144 */       load(arrayACargar);
/*      */       
/*  146 */       return tmpDir;
/*      */     } catch (Throwable ex) {
/*  148 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.2", new Object[] { ex.getMessage() }), ex);
/*  149 */       throw new CertStoreException(ex);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static synchronized Vector<String> copyLibraries(LIB_MODE mode, String dir)
/*      */   {
/*      */     try
/*      */     {
/*  158 */       CopyFilesTool cft = new CopyFilesTool("libs/mozilla/MITyCLibCertJNI_mozilla.properties", MozillaStoreUtils.class.getClassLoader());
/*  159 */       switch (mode) {
/*      */       case FULL: 
/*  161 */         tmpDir = cft.copyFilesOS(dir, "mozilla.cliente", true);
/*  162 */         if (LOG.isDebugEnabled())
/*  163 */           LOG.debug("Librerías copiadas: " + cft.getCopiedLibraries() + " en dir " + tmpDir);
/*  164 */         break;
/*      */       case ONLY_JSS: 
/*  166 */         tmpDir = cft.copyFilesOS(dir, "mozilla.jss", true);
/*  167 */         if (LOG.isDebugEnabled())
/*  168 */           LOG.debug("Librería copiada: " + cft.getCopiedLibraries() + " en dir " + tmpDir);
/*  169 */         break;
/*      */       case ONLY_PKCS11: 
/*  171 */         tmpDir = cft.copyFilesOS(dir, "mozilla.pkcs11", true);
/*  172 */         if (LOG.isDebugEnabled())
/*  173 */           LOG.debug("Librería copiada: " + cft.getCopiedLibraries() + " en dir " + tmpDir);
/*  174 */         break;
/*      */       default: 
/*  176 */         if (LOG.isDebugEnabled())
/*  177 */           LOG.debug("Modo de librerías no soportado");
/*      */         break;
/*      */       }
/*  180 */       if (LOG.isDebugEnabled()) {
/*  181 */         LOG.debug("Se terminaron de copiar las dependencias para el CSP de Mozilla");
/*      */       }
/*      */       
/*  184 */       if ((tmpDir != null) && (!tmpDir.trim().equals(""))) {
/*  185 */         if (!tmpDir.endsWith(File.separator)) {
/*  186 */           tmpDir += File.separator;
/*      */         }
/*  188 */         Vector<String> copiedLibraries = cft.getCopiedLibraries();
/*  189 */         Vector<String> absoluteLibraries = new Vector();
/*  190 */         for (int i = 0; i < copiedLibraries.size(); i++) {
/*  191 */           absoluteLibraries.add(tmpDir + (String)copiedLibraries.get(i));
/*      */         }
/*  193 */         return absoluteLibraries;
/*      */       }
/*  195 */       return cft.getCopiedLibraries();
/*      */     }
/*      */     catch (SecurityException ex) {
/*  198 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.1", new Object[] { ex.getMessage() }), ex);
/*      */     } catch (UnsatisfiedLinkError ex) {
/*  200 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.1", new Object[] { ex.getMessage() }), ex);
/*      */     } catch (CopyFileException ex) {
/*  202 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.1", new Object[] { ex.getMessage() }), ex);
/*      */     } catch (Throwable e) {
/*  204 */       LOG.debug("No se pudo cargar la instancia de la librería: " + e.getMessage(), e);
/*      */     }
/*      */     
/*  207 */     return null;
/*      */   }
/*      */   
/*      */   private static void load(Vector<String> keys) throws Exception {
/*  211 */     if ((keys == null) || (keys.size() == 0)) throw new IOException("La cadena de librerias a cargar está vacía");
/*      */     try {
/*  213 */       String key = null;
/*  214 */       for (int i = 0; i < keys.size(); i++) {
/*  215 */         key = (String)keys.get(i);
/*  216 */         if (key != null) {
/*  217 */           if (LOG.isDebugEnabled()) {
/*  218 */             LOG.debug("Cargando la librería: " + key);
/*      */           }
/*  220 */           if (new File(key).exists()) {
/*  221 */             System.load(key);
/*      */           } else {
/*      */             try {
/*  224 */               System.loadLibrary(key.substring(key.lastIndexOf(File.separator) + 1));
/*      */             } catch (Exception e) {
/*  226 */               throw new FileNotFoundException(key);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     } catch (Throwable e) {
/*  232 */       LOG.debug("No se pudo cargar la instancia de la pasarela con Firefox: " + e.getMessage(), e);
/*      */       try {
/*  234 */         keys = copyLibraries(LIB_MODE.FULL, null);
/*  235 */         String key = null;
/*  236 */         for (int i = 0; i < keys.size(); i++) {
/*  237 */           key = (String)keys.get(i);
/*  238 */           if (key != null) {
/*  239 */             if (LOG.isDebugEnabled()) {
/*  240 */               LOG.debug("Cargando la librería: " + key);
/*      */             }
/*  242 */             File lib = new File(key);
/*  243 */             if (lib.exists()) {
/*  244 */               System.load(lib.getAbsolutePath());
/*      */             } else {
/*  246 */               int j = -1;
/*  247 */               if ((j = key.indexOf(".")) != -1) {
/*  248 */                 key = key.substring(0, j);
/*      */               }
/*  250 */               if (key.startsWith("lib")) {
/*  251 */                 key = key.substring(3);
/*      */               }
/*      */               try
/*      */               {
/*  255 */                 System.loadLibrary(key.substring(key.lastIndexOf(File.separator) + 1));
/*      */               } catch (Exception ex) {
/*  257 */                 throw new FileNotFoundException(key);
/*      */               }
/*      */             }
/*      */           } else {
/*  261 */             LOG.error("No se pudieron copiar las dependencias de NSS para Firefox");
/*  262 */             break;
/*      */           }
/*      */         }
/*      */       } catch (Throwable e2) {
/*      */         try {
/*  267 */           LOG.debug("No se han cargado las dependencias tal cual, se intenta con un nombre alternativo.");
/*  268 */           String random = new Long(System.currentTimeMillis()).toString();
/*  269 */           CopyFilesTool cft = new CopyFilesTool("libs/mozilla/MITyCLibCertJNI_mozilla.properties", MozillaStoreUtils.class.getClassLoader());
/*  270 */           tmpDir = cft.copyFilesOS(null, "mozilla.cliente", true, random);
/*  271 */           keys = cft.getCopiedLibraries();
/*  272 */           String key = null;
/*  273 */           for (int i = 0; i < keys.size(); i++) {
/*  274 */             key = (String)keys.get(i);
/*  275 */             if (key != null) {
/*  276 */               File lib = new File(tmpDir + File.separator + key);
/*  277 */               if (lib.exists()) {
/*  278 */                 if (LOG.isDebugEnabled()) {
/*  279 */                   LOG.debug("Cargando la librería alternativa: " + lib.getAbsolutePath());
/*      */                 }
/*  281 */                 System.load(lib.getAbsolutePath());
/*      */               } else {
/*  283 */                 int j = -1;
/*  284 */                 if ((j = key.indexOf(".")) != -1) {
/*  285 */                   key = key.substring(0, j);
/*      */                 }
/*      */                 try {
/*  288 */                   if (LOG.isDebugEnabled()) {
/*  289 */                     LOG.debug("Cargando la librería alternativa dos: " + key.substring(key.lastIndexOf(File.separator) + 1));
/*      */                   }
/*  291 */                   System.loadLibrary(key.substring(key.lastIndexOf(File.separator) + 1));
/*      */                 } catch (Exception e3) {
/*  293 */                   throw new FileNotFoundException(key);
/*      */                 }
/*      */               }
/*      */             } else {
/*  297 */               LOG.error("No se pudieron copiar las dependencias de NSS para Firefox");
/*  298 */               break;
/*      */             }
/*      */           }
/*      */         } catch (Throwable e3) {
/*  302 */           LOG.debug("No se pudo cargar definitivamente la instancia de las librerías de Firefox: " + e3.getMessage(), e3);
/*  303 */           throw new Exception(e3);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static PasswordCallback getPassHandler(IPINDialogConfigurable.MESSAGES_MODE mode, String title, String pinMessage)
/*      */   {
/*  318 */     PasswordCallback handler = null;
/*      */     try {
/*  320 */       if (LOG.isTraceEnabled()) {
/*  321 */         LOG.trace("Obteniendo Passhandler...");
/*      */       }
/*  323 */       ResourceBundle rb = ResourceBundle.getBundle("mozilla");
/*  324 */       String handlerClass = rb.getString("passCallbackHandler");
/*  325 */       if (LOG.isTraceEnabled()) {
/*  326 */         LOG.trace("Nombre de ventana de pin: " + handlerClass);
/*      */       }
/*  328 */       handler = (PasswordCallback)Class.forName(handlerClass).newInstance();
/*  329 */       ((IPINDialogConfigurable)handler).setMessagesMode(mode);
/*  330 */       if (title != null) {
/*  331 */         ((IPINDialogConfigurable)handler).setTitle(title);
/*      */       }
/*  333 */       if (pinMessage != null) {
/*  334 */         ((IPINDialogConfigurable)handler).setPINMessage(pinMessage);
/*      */       }
/*  336 */       if (LOG.isTraceEnabled()) {
/*  337 */         LOG.trace("Pashandler configurado");
/*      */       }
/*      */     } catch (MissingResourceException ex) {
/*  340 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.3", new Object[] { ex.getMessage() }));
/*  341 */       handler = new PassStoreMozilla();
/*      */     } catch (InstantiationException ex) {
/*  343 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.3", new Object[] { ex.getMessage() }));
/*  344 */       if (LOG.isDebugEnabled()) {
/*  345 */         LOG.error(ex);
/*      */       }
/*  347 */       handler = new PassStoreMozilla();
/*      */     } catch (IllegalAccessException ex) {
/*  349 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.3", new Object[] { ex.getMessage() }));
/*  350 */       if (LOG.isDebugEnabled()) {
/*  351 */         LOG.error(ex);
/*      */       }
/*  353 */       handler = new PassStoreMozilla();
/*      */     } catch (ClassNotFoundException ex) {
/*  355 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.3", new Object[] { ex.getMessage() }));
/*  356 */       if (LOG.isDebugEnabled()) {
/*  357 */         LOG.error(ex);
/*      */       }
/*  359 */       handler = new PassStoreMozilla();
/*      */     } catch (ClassCastException ex) {
/*  361 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.3", new Object[] { ex.getMessage() }));
/*  362 */       if (LOG.isDebugEnabled()) {
/*  363 */         LOG.error(ex);
/*      */       }
/*  365 */       handler = new PassStoreMozilla();
/*      */     }
/*  367 */     return handler;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static java.security.cert.X509Certificate convert(org.mozilla.jss.crypto.X509Certificate certificate)
/*      */   {
/*      */     try
/*      */     {
/*  378 */       if (LOG.isTraceEnabled()) {
/*  379 */         LOG.trace("Convirtiendo certificado JSS: " + certificate.getSubjectDN());
/*      */       }
/*  381 */       byte[] certFirma = certificate.getEncoded();
/*  382 */       CertificateFactory cf = CertificateFactory.getInstance("X.509");
/*  383 */       return (java.security.cert.X509Certificate)cf.generateCertificate(new ByteArrayInputStream(certFirma));
/*      */     } catch (CertificateEncodingException ex) {
/*  385 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.4", new Object[] { ex.getMessage() }), ex);
/*      */     } catch (CertificateException ex) {
/*  387 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.4", new Object[] { ex.getMessage() }), ex);
/*      */     }
/*  389 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static java.security.cert.X509Certificate convert(X509PublicKeyCertificate certificate)
/*      */   {
/*      */     try
/*      */     {
/*  400 */       if (LOG.isTraceEnabled()) {
/*  401 */         LOG.trace("Convirtiendo certificado PKCS11: " + certificate.getLabel());
/*      */       }
/*  403 */       byte[] encCert = certificate.getValue().getByteArrayValue();
/*  404 */       CertificateFactory cf = CertificateFactory.getInstance("X.509");
/*  405 */       return (java.security.cert.X509Certificate)cf.generateCertificate(new ByteArrayInputStream(encCert));
/*      */     } catch (CertificateEncodingException ex) {
/*  407 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.4", new Object[] { ex.getMessage() }), ex);
/*      */     } catch (CertificateException ex) {
/*  409 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.4", new Object[] { ex.getMessage() }), ex);
/*      */     }
/*  411 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  437 */   private static String nssLibDir = null;
/*      */   
/*      */ 
/*      */ 
/*      */   private static final String DIR_TAG = "<DIR>";
/*      */   
/*      */ 
/*      */   private static final String P11_CONFIG_VALID_CHARS = ":\\0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_.~";
/*      */   
/*      */ 
/*      */ 
/*      */   static String createPKCS11NSSConfigFile(String userProfileDirectory, String libDir)
/*      */   {
/*  450 */     String softoknLib = "libsoftokn3.so";
/*  451 */     if (OSTool.getSO().isWindows()) {
/*  452 */       softoknLib = "softokn3.dll";
/*      */     }
/*  454 */     else if (OSTool.getSO().isMacOsX()) {
/*  455 */       softoknLib = "libsoftokn3.dylib";
/*      */     }
/*  457 */     if (libDir == null) {
/*  458 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.9"));
/*  459 */       return "";
/*      */     }
/*  461 */     if (!libDir.endsWith(File.separator)) {
/*  462 */       libDir.concat(File.separator);
/*      */     }
/*      */     
/*  465 */     StringBuilder buffer = new StringBuilder("name=NSS-PKCS11\r\n");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  470 */     buffer.append("library=")
/*  471 */       .append(libDir)
/*  472 */       .append(softoknLib)
/*  473 */       .append("\r\n")
/*  474 */       .append("attributes=compatibility\r\n")
/*  475 */       .append("configdir='")
/*  476 */       .append(userProfileDirectory)
/*  477 */       .append("' ")
/*  478 */       .append("certPrefix='' ")
/*  479 */       .append("keyPrefix='' ")
/*  480 */       .append("secmod='secmod.db' ")
/*  481 */       .append("flags=readOnly");
/*      */     
/*  483 */     return buffer.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static String getSystemNSSLibDir()
/*      */     throws Exception
/*      */   {
/*  491 */     if (nssLibDir != null) {
/*  492 */       return nssLibDir;
/*      */     }
/*      */     
/*  495 */     if (OSTool.getSO().isWindows()) {
/*  496 */       return getSystemNSSLibDirWindows();
/*      */     }
/*  498 */     if ((OSTool.getSO().isLinux()) || (OSTool.getSO().getVersion().contains("olaris"))) {
/*  499 */       return getSystemNSSLibDirUnix();
/*      */     }
/*  501 */     if (OSTool.getSO().isMacOsX()) {
/*  502 */       return getSystemNSSLibDirMacOsX();
/*      */     }
/*      */     
/*  505 */     LOG.debug("No se han encontrado bibliotecas NSS instaladas en su sistema operativo");
/*  506 */     return null;
/*      */   }
/*      */   
/*      */   private static String getSystemNSSLibDirWindows() throws Exception
/*      */   {
/*  511 */     String dir = WinRegistryUtils.readString(-2147483647, 
/*  512 */       "Software\\Classes\\FirefoxURL\\shell\\open\\command", "");
/*  513 */     if (dir == null) {
/*  514 */       dir = WinRegistryUtils.readString(-2147483646, 
/*  515 */         "SOFTWARE\\Classes\\FirefoxURL\\shell\\open\\command", "");
/*  516 */       if (dir == null) {
/*  517 */         throw new FileNotFoundException("No se ha podido localizar el directorio de Firefox a traves del registro de Windows");
/*      */       }
/*      */     }
/*      */     
/*  521 */     String regKeyLowCase = dir.toLowerCase();
/*  522 */     int pos = regKeyLowCase.indexOf("firefox.exe");
/*  523 */     if (pos != -1) {
/*  524 */       dir = dir.substring(0, pos);
/*  525 */       if (dir.startsWith("\"")) {
/*  526 */         dir = dir.substring(1);
/*      */       }
/*  528 */       if (dir.endsWith(File.separator)) {
/*  529 */         dir = dir.substring(0, dir.length() - 1);
/*      */       }
/*      */       
/*  532 */       File tmpFile = new File(dir);
/*  533 */       if ((tmpFile.exists()) && (tmpFile.isDirectory())) {
/*  534 */         tmpFile = new File(dir + File.separator + "softokn3.dll");
/*  535 */         if (tmpFile.exists()) {
/*      */           try {
/*  537 */             dir = tmpFile.getParentFile().getCanonicalPath();
/*      */           } catch (Exception e) {
/*  539 */             if (dir.contains("~")) {
/*  540 */               throw new FileNotFoundException("No se ha podido obtener el nombre del directorio del modulo PKCS#11, parece estar establecido como un nombre corto (8+3): " + 
/*  541 */                 e);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*  546 */           boolean illegalChars = false;
/*  547 */           char[] arrayOfChar; int j = (arrayOfChar = dir.toCharArray()).length; for (int i = 0; i < j; i++) { char c = arrayOfChar[i];
/*  548 */             if (":\\0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_.~".indexOf(c) == -1) {
/*  549 */               illegalChars = true;
/*  550 */               break;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*  555 */           if ((illegalChars) || (dir.contains("~")))
/*      */           {
/*      */ 
/*  558 */             LOG.error("Si esta version de JRE esta afectada por el error 6581254 de Java es posible que no pueda cargarse: " + dir);
/*      */           }
/*      */           
/*  561 */           j = (arrayOfChar = dir.toCharArray()).length; for (i = 0; i < j; i++) { char c = arrayOfChar[i];
/*  562 */             if (":\\0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_.~".indexOf(c) == -1) {
/*  563 */               dir = dir.replace(System.getProperty("user.home"), 
/*  564 */                 getShort(System.getProperty("user.home")));
/*  565 */               break;
/*      */             }
/*      */           }
/*  568 */           return dir;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  573 */     if (LOG.isDebugEnabled()) {
/*  574 */       LOG.debug("No se ha encontrado un NSS compatible en Windows");
/*      */     }
/*      */     
/*  577 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static String getShort(String longPath)
/*      */   {
/*  586 */     if (longPath == null) {
/*  587 */       return longPath;
/*      */     }
/*      */     
/*  590 */     File dir = new File(longPath);
/*  591 */     if ((!dir.exists()) || (!dir.isDirectory())) {
/*  592 */       return longPath;
/*      */     }
/*      */     try
/*      */     {
/*  596 */       Process p = new ProcessBuilder(new String[] {
/*  597 */         "cmd.exe", "/c", "dir /ad /x \"" + longPath + "\\..\\?" + longPath.substring(longPath.lastIndexOf(92) + 2) + "\"" })
/*  598 */         .start();
/*      */       
/*  600 */       InputStream is = p.getInputStream();
/*  601 */       if (is == null) {
/*  602 */         return null;
/*      */       }
/*  604 */       int nBytes = 0;
/*  605 */       byte[] buffer = new byte['က'];
/*  606 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*  607 */       while ((nBytes = is.read(buffer)) != -1) {
/*  608 */         baos.write(buffer, 0, nBytes);
/*      */       }
/*      */       
/*  611 */       BufferedReader br = new BufferedReader(new InputStreamReader(
/*  612 */         new ByteArrayInputStream(baos.toByteArray())));
/*  613 */       String line = br.readLine();
/*  614 */       while (line != null) {
/*  615 */         if (line.contains("<DIR>")) {
/*  616 */           String path = longPath.substring(0, longPath.lastIndexOf('\\') + 1);
/*  617 */           String filenames = line.substring(line.indexOf("<DIR>") + "<DIR>".length()).trim();
/*  618 */           int index = filenames.indexOf(" ");
/*  619 */           String shortName = null;
/*  620 */           if (index > 0) {
/*  621 */             shortName = filenames.substring(0, filenames.indexOf(" "));
/*      */           } else {
/*  623 */             shortName = filenames.substring(0);
/*      */           }
/*      */           
/*  626 */           if (!"".equals(shortName)) {
/*  627 */             return path + shortName;
/*      */           }
/*  629 */           return longPath;
/*      */         }
/*  631 */         line = br.readLine();
/*      */       }
/*      */     } catch (Exception e) {
/*  634 */       LOG.error("No se ha podido obtener el nombre corto de " + longPath, e);
/*      */     }
/*  636 */     return longPath;
/*      */   }
/*      */   
/*      */   private static String getSystemNSSLibDirMacOsX() throws FileNotFoundException
/*      */   {
/*  641 */     String[] posiblesRutas = {
/*  642 */       "/Applications/Firefox.app/Contents/MacOS", 
/*  643 */       "/lib", 
/*  644 */       "/usr/lib", 
/*  645 */       "/usr/lib/nss", 
/*  646 */       "/Applications/Minefield.app/Contents/MacOS" };
/*      */     
/*      */ 
/*  649 */     String[] arrayOfString1 = posiblesRutas;int j = posiblesRutas.length; for (int i = 0; i < j; i++) { String path = arrayOfString1[i];
/*  650 */       if (new File(path + "/libsoftokn3.dylib").exists()) {
/*  651 */         nssLibDir = path;
/*      */       }
/*      */     }
/*      */     
/*  655 */     if (nssLibDir == null) {
/*  656 */       throw new FileNotFoundException("No se ha podido determinar la localizacion de NSS en Mac OS X");
/*      */     }
/*      */     
/*  659 */     return nssLibDir;
/*      */   }
/*      */   
/*      */   private static String getSystemNSSLibDirUnix() throws FileNotFoundException
/*      */   {
/*  664 */     if ((new File("/usr/lib/libsoftokn3.so").exists()) && (new File("/lib/libnspr4.so").exists())) {
/*      */       try {
/*  666 */         System.load("/lib/libnspr4.so");
/*  667 */         nssLibDir = "/usr/lib";
/*      */       } catch (Exception e) {
/*  669 */         nssLibDir = null;
/*  670 */         LOG.debug("Se descarta el NSS situado entre /lib y /usr/lib. No puede ser cargado: " + e);
/*      */       }
/*  672 */       if (nssLibDir != null) {
/*  673 */         return nssLibDir;
/*      */       }
/*      */     }
/*      */     
/*  677 */     String[] posiblesRutas = {
/*  678 */       "/usr/lib/firefox-" + searchLastFirefoxVersion("/usr/lib/"), 
/*  679 */       "/usr/lib/firefox", 
/*  680 */       "/opt/firefox", 
/*  681 */       "/opt/firefox-" + searchLastFirefoxVersion("/opt/"), 
/*  682 */       "/lib", 
/*  683 */       "/usr/lib", 
/*  684 */       "/usr/lib/nss", 
/*  685 */       "/opt/fedora-ds/clients/lib" };
/*      */     
/*      */ 
/*  688 */     String[] arrayOfString1 = posiblesRutas;int j = posiblesRutas.length; for (int i = 0; i < j; i++) { String path = arrayOfString1[i];
/*  689 */       if ((new File(path + "/libsoftokn3.so").exists()) && (new File(path + "/libnspr4.so").exists())) {
/*      */         try {
/*  691 */           System.load(path + "/libnspr4.so");
/*  692 */           nssLibDir = path;
/*      */         } catch (Exception e) {
/*  694 */           nssLibDir = null;
/*  695 */           LOG.error("Se descarta el NSS situado en '" + path + 
/*  696 */             "' porque no puede cargarse adecuadamente: " + e);
/*      */         }
/*  698 */         if (nssLibDir != null) {
/*  699 */           return nssLibDir;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  704 */     if (nssLibDir == null) {
/*  705 */       throw new FileNotFoundException("No se ha podido determinar la localizacion de NSS en UNIX");
/*      */     }
/*      */     
/*  708 */     return nssLibDir;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static String searchLastFirefoxVersion(String startDir)
/*      */   {
/*  715 */     File directoryLib = new File(startDir);
/*  716 */     if (directoryLib.isDirectory()) {
/*  717 */       String[] filenames = directoryLib.list();
/*  718 */       List<String> firefoxDirectories = new ArrayList();
/*  719 */       String[] arrayOfString1; int j = (arrayOfString1 = filenames).length; for (int i = 0; i < j; i++) { String filename = arrayOfString1[i];
/*  720 */         if (filename.startsWith("firefox-")) {
/*  721 */           firefoxDirectories.add(filename.replace("firefox-", ""));
/*      */         }
/*      */       }
/*  724 */       if (firefoxDirectories.isEmpty()) {
/*  725 */         return "";
/*      */       }
/*  727 */       for (int i = 0; i < firefoxDirectories.size(); i++) {
/*      */         try {
/*  729 */           Integer.getInteger((String)firefoxDirectories.get(i));
/*      */         }
/*      */         catch (Exception e) {
/*  732 */           firefoxDirectories.remove(i);
/*      */         }
/*      */       }
/*  735 */       if (firefoxDirectories.size() == 1) {
/*  736 */         return (String)firefoxDirectories.get(0);
/*      */       }
/*  738 */       Collections.sort(firefoxDirectories, new Comparator() {
/*      */         public int compare(String o1, String o2) {
/*  740 */           return o1.compareTo(o2);
/*      */         }
/*  742 */       });
/*  743 */       return (String)firefoxDirectories.get(0);
/*      */     }
/*  745 */     return "";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static Vector<String> getNSSDependencies(String nssDirectory)
/*      */   {
/*  754 */     if (LOG.isDebugEnabled()) {
/*  755 */       LOG.debug("Buscando dependencias NSS");
/*      */     }
/*  757 */     Vector<String> dependList = new Vector();
/*      */     
/*      */ 
/*  760 */     if ((OSTool.getSO().isLinux()) && (new File("/usr/lib/libsoftokn3.so").exists()) && 
/*  761 */       (new File("/lib/libnspr4.so").exists())) {
/*  762 */       dependList.add("/lib/libnspr4.so");
/*  763 */       dependList.add("/lib/libplds4.so");
/*  764 */       dependList.add("/usr/lib/libplds4.so");
/*  765 */       dependList.add("/lib/libplc4.so");
/*  766 */       dependList.add("/usr/lib/libplc4.so");
/*  767 */       dependList.add("/lib/libnssutil3.so");
/*  768 */       dependList.add("/usr/lib/libnssutil3.so");
/*  769 */       dependList.add("/lib/libsqlite3.so");
/*  770 */       dependList.add("/usr/lib/libsqlite3.so");
/*  771 */       dependList.add("/lib/libmozsqlite3.so");
/*  772 */       dependList.add("/usr/lib/libmozsqlite3.so");
/*  773 */       if (LOG.isDebugEnabled()) {
/*  774 */         LOG.debug("Encontrado NSS Fedora: " + dependList);
/*      */       }
/*      */     } else {
/*  777 */       String path = nssDirectory + (nssDirectory.endsWith(File.separator) ? "" : File.separator);
/*  778 */       String[] dependList2 = getSoftkn3Dependencies(path);
/*  779 */       dependList.addAll(Arrays.asList(dependList2));
/*  780 */       if (LOG.isDebugEnabled()) {
/*  781 */         LOG.debug("Encontrado NSS: " + dependList);
/*      */       }
/*      */     }
/*      */     
/*  785 */     return dependList;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static String[] getSoftkn3Dependencies(String path)
/*      */   {
/*  798 */     if (path == null) {
/*  799 */       return new String[0];
/*      */     }
/*      */     
/*  802 */     if (OSTool.getSO().isMacOsX()) {
/*  803 */       LOG.error("NSS MacOS no soportado: ");
/*  804 */       return new String[0];
/*      */     }
/*      */     
/*  807 */     String nssPath = !path.endsWith(File.separator) ? path + File.separator : path;
/*      */     
/*  809 */     if (OSTool.getSO().isWindows()) {
/*  810 */       if (LOG.isDebugEnabled()) {
/*  811 */         LOG.debug("NSS Windows");
/*      */       }
/*  813 */       if (OSTool.getSO().is64bits()) {
/*  814 */         return new String[] {
/*  815 */           nssPath + "msvcr100.dll", 
/*  816 */           nssPath + "mozglue.dll", 
/*  817 */           nssPath + "nss3.dll", 
/*  818 */           nssPath + "softokn3.dll" };
/*      */       }
/*      */       
/*  821 */       return new String[] {
/*  822 */         nssPath + "msvcr100.dll", 
/*  823 */         nssPath + "mozglue.dll", 
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  828 */         nssPath + "nss3.dll", 
/*      */         
/*      */ 
/*      */ 
/*  832 */         nssPath + "softokn3.dll" };
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  852 */     if ((OSTool.getSO().isLinux()) || (OSTool.getSO().getVersion().contains("olaris"))) {
/*  853 */       if (LOG.isDebugEnabled()) {
/*  854 */         LOG.debug("NSS Linux");
/*      */       }
/*  856 */       return new String[] {
/*  857 */         nssPath + "libnspr4.so", 
/*  858 */         nssPath + "libplds4.so", 
/*  859 */         nssPath + "libplc4.so", 
/*  860 */         nssPath + "libnssutil3.so", 
/*  861 */         nssPath + "libsqlite3.so", 
/*  862 */         nssPath + "libmozsqlite3.so", 
/*  863 */         nssPath + "libsoftokn3.so" };
/*      */     }
/*      */     
/*      */ 
/*  867 */     LOG.error("Plataforma no soportada para la precarga de las bibliotecas NSS: " + OSTool.getSO() + 
/*  868 */       " + Java " + OSTool.getSO().getVersion());
/*  869 */     return new String[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getMozillaUserProfileDirectory()
/*      */     throws Exception
/*      */   {
/*  879 */     if (OSTool.getSO().isWindows())
/*  880 */       return getMozillaUserProfileDirectoryWindows();
/*  881 */     if (OSTool.getSO().isMacOsX()) {
/*  882 */       return getMozillaUserProfileDirectoryMacOsX();
/*      */     }
/*  884 */     return getMozillaUserProfileDirectoryUnix();
/*      */   }
/*      */   
/*      */ 
/*      */   private static String getMozillaUserProfileDirectoryUnix()
/*      */   {
/*  890 */     File regFile = new File(System.getProperty("user.home") + "/.mozilla/firefox/profiles.ini");
/*      */     try {
/*  892 */       if (regFile.exists()) {
/*  893 */         return getFireFoxUserProfileDirectory(regFile);
/*      */       }
/*      */     } catch (Exception e) {
/*  896 */       LOG.error("Error obteniendo el directorio de perfil de Firefox (UNIX): " + e);
/*      */     }
/*  898 */     return null;
/*      */   }
/*      */   
/*      */   private static String getMozillaUserProfileDirectoryWindows() throws Exception {
/*  902 */     String appDataDir = WinRegistryUtils.readString(-2147483647, 
/*  903 */       "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders", "AppData");
/*      */     
/*  905 */     if (appDataDir != null) {
/*  906 */       String finalDir = null;
/*      */       
/*  908 */       File regFile = new File(appDataDir + "\\Mozilla\\Firefox\\profiles.ini");
/*      */       try {
/*  910 */         if (regFile.exists()) {
/*  911 */           finalDir = getFireFoxUserProfileDirectory(regFile);
/*      */         }
/*      */       } catch (Exception e) {
/*  914 */         LOG.error("Error obteniendo el directorio de perfil de Firefox: " + e);
/*  915 */         return null;
/*      */       }
/*  917 */       if (finalDir != null) { char[] arrayOfChar;
/*  918 */         int j = (arrayOfChar = finalDir.toCharArray()).length; for (int i = 0; i < j; i++) { char c = arrayOfChar[i];
/*  919 */           if (":\\0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_.~".indexOf(c) == -1) {
/*  920 */             finalDir = finalDir.replace(System.getProperty("user.home"), 
/*  921 */               getShort(System.getProperty("user.home")));
/*  922 */             break;
/*      */           }
/*      */         }
/*  925 */         return finalDir.replace('\\', '/');
/*      */       }
/*      */     }
/*  928 */     LOG.error("Error obteniendo el directorio de perfil de usuario de Mozilla Firefox (Windows)");
/*  929 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   private static String getMozillaUserProfileDirectoryMacOsX()
/*      */   {
/*  935 */     File regFile = new File(System.getProperty("user.home") + "/Library/Application Support/Firefox/profiles.ini");
/*      */     try {
/*  937 */       if (regFile.exists()) {
/*  938 */         return getFireFoxUserProfileDirectory(regFile);
/*      */       }
/*      */     } catch (Exception e) {
/*  941 */       LOG.error("Error obteniendo el directorio de perfil de Firefox (" + regFile.getAbsolutePath() + "): " + e);
/*      */     }
/*  943 */     return null;
/*      */   }
/*      */   
/*      */   static void configureMacNSS(String binDir) throws Exception
/*      */   {
/*  948 */     if (!OSTool.getSO().isMacOsX()) {
/*  949 */       LOG.error("No se ha detectado MacOS: " + OSTool.getSO());
/*  950 */       return;
/*      */     }
/*      */     
/*  953 */     if (binDir == null) {
/*  954 */       LOG.error("El directorio de NSS para configurar proporcionado es nulo, no se realizara ninguna accion");
/*  955 */       return;
/*      */     }
/*      */     
/*  958 */     String nssBinDir = binDir + "/";
/*      */     
/*      */     try
/*      */     {
/*  962 */       System.load(nssBinDir + "libsoftokn3.dylib");
/*  963 */       return;
/*      */     }
/*      */     catch (Exception localException1) {}catch (UnsatisfiedLinkError localUnsatisfiedLinkError1) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  970 */     String[] libs = {
/*  971 */       "libmozutils.dylib", 
/*  972 */       "libnspr4.dylib", 
/*  973 */       "libplds4.dylib", 
/*  974 */       "libplc4.dylib", 
/*  975 */       "libmozsqlite3.dylib", 
/*  976 */       "libnssutil3.dylib" };
/*      */     
/*      */ 
/*      */ 
/*  980 */     StringBuilder sb = new StringBuilder();
/*  981 */     String[] arrayOfString1; int j = (arrayOfString1 = libs).length; for (int i = 0; i < j; i++) { String lib = arrayOfString1[i];
/*  982 */       if (new File(nssBinDir + lib).exists()) {
/*  983 */         sb.append("ln -s ");
/*  984 */         sb.append(nssBinDir);
/*  985 */         sb.append(lib);
/*  986 */         sb.append(" /usr/lib/");
/*  987 */         sb.append(lib);
/*  988 */         sb.append("; ");
/*      */       }
/*      */     }
/*      */     try {
/*  992 */       Class<?> scriptEngineManagerClass = Class.forName("javax.script.ScriptEngineManager");
/*  993 */       Object scriptEngineManager = scriptEngineManagerClass.newInstance();
/*  994 */       Method getEngineByNameMethod = scriptEngineManagerClass.getMethod("getEngineByName", new Class[] { String.class });
/*  995 */       Object scriptEngine = getEngineByNameMethod.invoke(scriptEngineManager, new Object[] { "AppleScript" });
/*  996 */       Class<?> scriptEngineClass = Class.forName("javax.script.ScriptEngine");
/*  997 */       Method evalMethod = scriptEngineClass.getMethod("eval", new Class[] { String.class });
/*  998 */       evalMethod.invoke(scriptEngine, new Object[] { "do shell script \"" + sb.toString() + "\" with administrator privileges" });
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1002 */       LOG.error("No se ha podido crear los enlaces simbolicos para NSS: " + e);
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1007 */       System.load(nssBinDir + "libsoftokn3.dylib");
/*      */     } catch (Exception e) {
/* 1009 */       throw new Exception("La configuracion de NSS para Mac OS X ha fallado por motivos de seguridad: " + e);
/*      */     } catch (UnsatisfiedLinkError e) {
/* 1011 */       throw new Exception("La configuracion de NSS para Mac OS X ha fallado: " + e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static String getFireFoxUserProfileDirectory(File iniFile)
/*      */     throws IOException
/*      */   {
/* 1023 */     if (iniFile == null)
/* 1024 */       throw new IllegalArgumentException("El fichero INI es nulo y no se podra determinar el directorio del usuario de firefox");
/* 1025 */     if ((!iniFile.exists()) || (!iniFile.isFile())) {
/* 1026 */       throw new IOException("No se ha encontrado el fichero con los perfiles de firefox");
/*      */     }
/*      */     
/* 1029 */     String currentProfilePath = null;
/*      */     
/*      */ 
/* 1032 */     FirefoxProfile[] profiles = readProfiles(iniFile);
/* 1033 */     FirefoxProfile[] arrayOfFirefoxProfile1; int j = (arrayOfFirefoxProfile1 = profiles).length; for (int i = 0; i < j; i++) { FirefoxProfile profile = arrayOfFirefoxProfile1[i];
/* 1034 */       if (isProfileLocked(profile)) {
/* 1035 */         currentProfilePath = profile.getAbsolutePath();
/* 1036 */         break;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1041 */     if (currentProfilePath == null) {
/* 1042 */       j = (arrayOfFirefoxProfile1 = profiles).length; for (i = 0; i < j; i++) { FirefoxProfile profile = arrayOfFirefoxProfile1[i];
/* 1043 */         if (profile.isDefault()) {
/* 1044 */           currentProfilePath = profile.getAbsolutePath();
/* 1045 */           break;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1051 */     if (profiles.length > 0) {
/* 1052 */       currentProfilePath = profiles[0].getAbsolutePath();
/*      */     }
/*      */     
/* 1055 */     return currentProfilePath;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   private static FirefoxProfile[] readProfiles(File iniFile)
/*      */     throws IOException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: ldc_w 1040
/*      */     //   3: astore_1
/*      */     //   4: ldc_w 1042
/*      */     //   7: astore_2
/*      */     //   8: ldc_w 1044
/*      */     //   11: astore_3
/*      */     //   12: ldc_w 1046
/*      */     //   15: astore 4
/*      */     //   17: aconst_null
/*      */     //   18: astore 5
/*      */     //   20: new 797	java/util/ArrayList
/*      */     //   23: dup
/*      */     //   24: invokespecial 799	java/util/ArrayList:<init>	()V
/*      */     //   27: astore 6
/*      */     //   29: new 709	java/io/BufferedReader
/*      */     //   32: dup
/*      */     //   33: new 1048	java/io/FileReader
/*      */     //   36: dup
/*      */     //   37: aload_0
/*      */     //   38: invokespecial 1050	java/io/FileReader:<init>	(Ljava/io/File;)V
/*      */     //   41: invokespecial 719	java/io/BufferedReader:<init>	(Ljava/io/Reader;)V
/*      */     //   44: astore 7
/*      */     //   46: goto +306 -> 352
/*      */     //   49: aload 5
/*      */     //   51: invokevirtual 264	java/lang/String:trim	()Ljava/lang/String;
/*      */     //   54: invokevirtual 619	java/lang/String:toLowerCase	()Ljava/lang/String;
/*      */     //   57: ldc_w 1053
/*      */     //   60: invokevirtual 145	java/lang/String:startsWith	(Ljava/lang/String;)Z
/*      */     //   63: ifne +6 -> 69
/*      */     //   66: goto +286 -> 352
/*      */     //   69: new 1029	es/mityc/javasign/pkstore/mozilla/MozillaStoreUtils$FirefoxProfile
/*      */     //   72: dup
/*      */     //   73: aconst_null
/*      */     //   74: invokespecial 1055	es/mityc/javasign/pkstore/mozilla/MozillaStoreUtils$FirefoxProfile:<init>	(Les/mityc/javasign/pkstore/mozilla/MozillaStoreUtils$FirefoxProfile;)V
/*      */     //   77: astore 8
/*      */     //   79: goto +168 -> 247
/*      */     //   82: aload 5
/*      */     //   84: invokevirtual 264	java/lang/String:trim	()Ljava/lang/String;
/*      */     //   87: invokevirtual 619	java/lang/String:toLowerCase	()Ljava/lang/String;
/*      */     //   90: ldc_w 1040
/*      */     //   93: invokevirtual 145	java/lang/String:startsWith	(Ljava/lang/String;)Z
/*      */     //   96: ifeq +25 -> 121
/*      */     //   99: aload 8
/*      */     //   101: aload 5
/*      */     //   103: invokevirtual 264	java/lang/String:trim	()Ljava/lang/String;
/*      */     //   106: ldc_w 1040
/*      */     //   109: invokevirtual 622	java/lang/String:length	()I
/*      */     //   112: invokevirtual 149	java/lang/String:substring	(I)Ljava/lang/String;
/*      */     //   115: invokevirtual 1058	es/mityc/javasign/pkstore/mozilla/MozillaStoreUtils$FirefoxProfile:setName	(Ljava/lang/String;)V
/*      */     //   118: goto +129 -> 247
/*      */     //   121: aload 5
/*      */     //   123: invokevirtual 264	java/lang/String:trim	()Ljava/lang/String;
/*      */     //   126: invokevirtual 619	java/lang/String:toLowerCase	()Ljava/lang/String;
/*      */     //   129: ldc_w 1042
/*      */     //   132: invokevirtual 145	java/lang/String:startsWith	(Ljava/lang/String;)Z
/*      */     //   135: ifeq +31 -> 166
/*      */     //   138: aload 8
/*      */     //   140: aload 5
/*      */     //   142: invokevirtual 264	java/lang/String:trim	()Ljava/lang/String;
/*      */     //   145: ldc_w 1042
/*      */     //   148: invokevirtual 622	java/lang/String:length	()I
/*      */     //   151: invokevirtual 149	java/lang/String:substring	(I)Ljava/lang/String;
/*      */     //   154: ldc_w 1061
/*      */     //   157: invokevirtual 267	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   160: invokevirtual 1063	es/mityc/javasign/pkstore/mozilla/MozillaStoreUtils$FirefoxProfile:setRelative	(Z)V
/*      */     //   163: goto +84 -> 247
/*      */     //   166: aload 5
/*      */     //   168: invokevirtual 264	java/lang/String:trim	()Ljava/lang/String;
/*      */     //   171: invokevirtual 619	java/lang/String:toLowerCase	()Ljava/lang/String;
/*      */     //   174: ldc_w 1044
/*      */     //   177: invokevirtual 145	java/lang/String:startsWith	(Ljava/lang/String;)Z
/*      */     //   180: ifeq +25 -> 205
/*      */     //   183: aload 8
/*      */     //   185: aload 5
/*      */     //   187: invokevirtual 264	java/lang/String:trim	()Ljava/lang/String;
/*      */     //   190: ldc_w 1044
/*      */     //   193: invokevirtual 622	java/lang/String:length	()I
/*      */     //   196: invokevirtual 149	java/lang/String:substring	(I)Ljava/lang/String;
/*      */     //   199: invokevirtual 1067	es/mityc/javasign/pkstore/mozilla/MozillaStoreUtils$FirefoxProfile:setPath	(Ljava/lang/String;)V
/*      */     //   202: goto +45 -> 247
/*      */     //   205: aload 5
/*      */     //   207: invokevirtual 264	java/lang/String:trim	()Ljava/lang/String;
/*      */     //   210: invokevirtual 619	java/lang/String:toLowerCase	()Ljava/lang/String;
/*      */     //   213: ldc_w 1046
/*      */     //   216: invokevirtual 145	java/lang/String:startsWith	(Ljava/lang/String;)Z
/*      */     //   219: ifeq +67 -> 286
/*      */     //   222: aload 8
/*      */     //   224: aload 5
/*      */     //   226: invokevirtual 264	java/lang/String:trim	()Ljava/lang/String;
/*      */     //   229: ldc_w 1046
/*      */     //   232: invokevirtual 622	java/lang/String:length	()I
/*      */     //   235: invokevirtual 149	java/lang/String:substring	(I)Ljava/lang/String;
/*      */     //   238: ldc_w 1061
/*      */     //   241: invokevirtual 267	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   244: invokevirtual 1070	es/mityc/javasign/pkstore/mozilla/MozillaStoreUtils$FirefoxProfile:setDefault	(Z)V
/*      */     //   247: aload 7
/*      */     //   249: invokevirtual 722	java/io/BufferedReader:readLine	()Ljava/lang/String;
/*      */     //   252: dup
/*      */     //   253: astore 5
/*      */     //   255: ifnull +31 -> 286
/*      */     //   258: aload 5
/*      */     //   260: invokevirtual 264	java/lang/String:trim	()Ljava/lang/String;
/*      */     //   263: invokevirtual 622	java/lang/String:length	()I
/*      */     //   266: ifle +20 -> 286
/*      */     //   269: aload 5
/*      */     //   271: invokevirtual 264	java/lang/String:trim	()Ljava/lang/String;
/*      */     //   274: invokevirtual 619	java/lang/String:toLowerCase	()Ljava/lang/String;
/*      */     //   277: ldc_w 1053
/*      */     //   280: invokevirtual 145	java/lang/String:startsWith	(Ljava/lang/String;)Z
/*      */     //   283: ifeq -201 -> 82
/*      */     //   286: aload 8
/*      */     //   288: invokevirtual 1073	es/mityc/javasign/pkstore/mozilla/MozillaStoreUtils$FirefoxProfile:getName	()Ljava/lang/String;
/*      */     //   291: ifnonnull +11 -> 302
/*      */     //   294: aload 8
/*      */     //   296: invokevirtual 1076	es/mityc/javasign/pkstore/mozilla/MozillaStoreUtils$FirefoxProfile:getPath	()Ljava/lang/String;
/*      */     //   299: ifnull +53 -> 352
/*      */     //   302: aload 8
/*      */     //   304: aload 8
/*      */     //   306: invokevirtual 1079	es/mityc/javasign/pkstore/mozilla/MozillaStoreUtils$FirefoxProfile:isRelative	()Z
/*      */     //   309: ifeq +25 -> 334
/*      */     //   312: new 271	java/io/File
/*      */     //   315: dup
/*      */     //   316: aload_0
/*      */     //   317: invokevirtual 1082	java/io/File:getParent	()Ljava/lang/String;
/*      */     //   320: aload 8
/*      */     //   322: invokevirtual 1076	es/mityc/javasign/pkstore/mozilla/MozillaStoreUtils$FirefoxProfile:getPath	()Ljava/lang/String;
/*      */     //   325: invokespecial 1085	java/io/File:<init>	(Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   328: invokevirtual 1088	java/io/File:toString	()Ljava/lang/String;
/*      */     //   331: goto +8 -> 339
/*      */     //   334: aload 8
/*      */     //   336: invokevirtual 1076	es/mityc/javasign/pkstore/mozilla/MozillaStoreUtils$FirefoxProfile:getPath	()Ljava/lang/String;
/*      */     //   339: invokevirtual 1089	es/mityc/javasign/pkstore/mozilla/MozillaStoreUtils$FirefoxProfile:setAbsolutePath	(Ljava/lang/String;)V
/*      */     //   342: aload 6
/*      */     //   344: aload 8
/*      */     //   346: invokeinterface 802 2 0
/*      */     //   351: pop
/*      */     //   352: aload 7
/*      */     //   354: invokevirtual 722	java/io/BufferedReader:readLine	()Ljava/lang/String;
/*      */     //   357: dup
/*      */     //   358: astore 5
/*      */     //   360: ifnonnull -311 -> 49
/*      */     //   363: goto +46 -> 409
/*      */     //   366: astore 8
/*      */     //   368: new 311	java/io/IOException
/*      */     //   371: dup
/*      */     //   372: new 87	java/lang/StringBuilder
/*      */     //   375: dup
/*      */     //   376: ldc_w 1092
/*      */     //   379: invokespecial 91	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   382: aload 8
/*      */     //   384: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*      */     //   387: invokevirtual 103	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   390: invokespecial 315	java/io/IOException:<init>	(Ljava/lang/String;)V
/*      */     //   393: athrow
/*      */     //   394: astore 9
/*      */     //   396: aload 7
/*      */     //   398: invokevirtual 1094	java/io/BufferedReader:close	()V
/*      */     //   401: goto +5 -> 406
/*      */     //   404: astore 10
/*      */     //   406: aload 9
/*      */     //   408: athrow
/*      */     //   409: aload 7
/*      */     //   411: invokevirtual 1094	java/io/BufferedReader:close	()V
/*      */     //   414: goto +5 -> 419
/*      */     //   417: astore 10
/*      */     //   419: aload 6
/*      */     //   421: aload 6
/*      */     //   423: invokeinterface 818 1 0
/*      */     //   428: anewarray 1029	es/mityc/javasign/pkstore/mozilla/MozillaStoreUtils$FirefoxProfile
/*      */     //   431: invokeinterface 1097 2 0
/*      */     //   436: checkcast 1039	[Les/mityc/javasign/pkstore/mozilla/MozillaStoreUtils$FirefoxProfile;
/*      */     //   439: areturn
/*      */     // Line number table:
/*      */     //   Java source line #1070	-> byte code offset #0
/*      */     //   Java source line #1071	-> byte code offset #4
/*      */     //   Java source line #1072	-> byte code offset #8
/*      */     //   Java source line #1073	-> byte code offset #12
/*      */     //   Java source line #1075	-> byte code offset #17
/*      */     //   Java source line #1076	-> byte code offset #20
/*      */     //   Java source line #1077	-> byte code offset #29
/*      */     //   Java source line #1079	-> byte code offset #46
/*      */     //   Java source line #1082	-> byte code offset #49
/*      */     //   Java source line #1083	-> byte code offset #66
/*      */     //   Java source line #1086	-> byte code offset #69
/*      */     //   Java source line #1087	-> byte code offset #79
/*      */     //   Java source line #1088	-> byte code offset #82
/*      */     //   Java source line #1089	-> byte code offset #99
/*      */     //   Java source line #1090	-> byte code offset #118
/*      */     //   Java source line #1091	-> byte code offset #138
/*      */     //   Java source line #1092	-> byte code offset #163
/*      */     //   Java source line #1093	-> byte code offset #183
/*      */     //   Java source line #1094	-> byte code offset #202
/*      */     //   Java source line #1095	-> byte code offset #222
/*      */     //   Java source line #1087	-> byte code offset #247
/*      */     //   Java source line #1101	-> byte code offset #286
/*      */     //   Java source line #1102	-> byte code offset #302
/*      */     //   Java source line #1103	-> byte code offset #342
/*      */     //   Java source line #1079	-> byte code offset #352
/*      */     //   Java source line #1106	-> byte code offset #363
/*      */     //   Java source line #1107	-> byte code offset #368
/*      */     //   Java source line #1108	-> byte code offset #394
/*      */     //   Java source line #1109	-> byte code offset #396
/*      */     //   Java source line #1110	-> byte code offset #406
/*      */     //   Java source line #1109	-> byte code offset #409
/*      */     //   Java source line #1112	-> byte code offset #419
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	440	0	iniFile	File
/*      */     //   3	2	1	nameAtr	String
/*      */     //   7	2	2	isRelativeAtr	String
/*      */     //   11	2	3	pathProfilesAtr	String
/*      */     //   15	3	4	isDefaultAtr	String
/*      */     //   18	341	5	line	String
/*      */     //   27	395	6	profiles	List<FirefoxProfile>
/*      */     //   44	366	7	in	BufferedReader
/*      */     //   77	268	8	profile	FirefoxProfile
/*      */     //   366	17	8	e	Exception
/*      */     //   394	13	9	localObject	Object
/*      */     //   404	1	10	localException1	Exception
/*      */     //   417	1	10	localException2	Exception
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   46	363	366	java/lang/Exception
/*      */     //   46	394	394	finally
/*      */     //   396	401	404	java/lang/Exception
/*      */     //   409	414	417	java/lang/Exception
/*      */   }
/*      */   
/*      */   private static boolean isProfileLocked(FirefoxProfile profile)
/*      */   {
/* 1121 */     return (new File(profile.getAbsolutePath(), "parent.lock").exists()) || 
/* 1122 */       (new File(profile.getAbsolutePath(), "lock").exists());
/*      */   }
/*      */   
/*      */ 
/*      */   private static final class FirefoxProfile
/*      */   {
/* 1128 */     private String name = null;
/*      */     
/*      */     String getName() {
/* 1131 */       return this.name;
/*      */     }
/*      */     
/* 1134 */     void setName(String n) { this.name = n; }
/*      */     
/*      */ 
/* 1137 */     private boolean relative = true;
/*      */     
/*      */     boolean isRelative() {
/* 1140 */       return this.relative;
/*      */     }
/*      */     
/* 1143 */     void setRelative(boolean r) { this.relative = r; }
/*      */     
/*      */ 
/* 1146 */     private String path = null;
/*      */     
/*      */     String getPath() {
/* 1149 */       return this.path;
/*      */     }
/*      */     
/* 1152 */     void setPath(String p) { this.path = p; }
/*      */     
/*      */ 
/* 1155 */     private String absolutePath = null;
/*      */     
/*      */     String getAbsolutePath() {
/* 1158 */       return this.absolutePath;
/*      */     }
/*      */     
/* 1161 */     void setAbsolutePath(String ap) { this.absolutePath = ap; }
/*      */     
/*      */ 
/* 1164 */     private boolean def = false;
/*      */     
/*      */     boolean isDefault() {
/* 1167 */       return this.def;
/*      */     }
/*      */     
/* 1170 */     void setDefault(boolean d) { this.def = d; }
/*      */   }
/*      */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mozilla\MozillaStoreUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */