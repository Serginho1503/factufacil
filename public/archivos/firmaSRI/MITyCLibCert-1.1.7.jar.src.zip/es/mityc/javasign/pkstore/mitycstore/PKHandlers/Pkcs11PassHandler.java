/*    */ package es.mityc.javasign.pkstore.mitycstore.PKHandlers;
/*    */ 
/*    */ import es.mityc.javasign.i18n.I18nFactory;
/*    */ import es.mityc.javasign.i18n.II18nManager;
/*    */ import es.mityc.javasign.pkstore.DefaultPassStoreKS;
/*    */ import es.mityc.javasign.pkstore.mitycstore.CertUtil;
/*    */ import java.security.cert.X509Certificate;
/*    */ import javax.swing.ImageIcon;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Pkcs11PassHandler
/*    */   extends DefaultPassStoreKS
/*    */ {
/* 36 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*    */   
/*    */ 
/* 39 */   private String pinMessage = I18N.getLocalMessage("i18n.mityc.cert.smartcards.GUI.pin");
/*    */   
/*    */ 
/* 42 */   private static final ImageIcon PIN_ICON = new ImageIcon(Pkcs11PassHandler.class.getResource("/es/mityc/javasign/pkstore/mitycstore/Images/SIM.png"));
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void processData(X509Certificate certificate, String alias)
/*    */   {
/* 52 */     if (alias != null) {
/* 53 */       setPINMessage(alias);
/*    */     } else {
/* 55 */       setPINMessage(this.pinMessage + " " + CertUtil.extractName(certificate.getSubjectX500Principal()));
/*    */     }
/*    */     
/* 58 */     setIcon(PIN_ICON);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mitycstore\PKHandlers\Pkcs11PassHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */