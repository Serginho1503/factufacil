/*     */ package es.mityc.javasign.pkstore.mozilla;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Frame;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPasswordField;
/*     */ import javax.swing.JRootPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PINDialog
/*     */ {
/*  46 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*     */   
/*     */ 
/*     */   private static final String STR_OK = "OK";
/*     */   
/*     */ 
/*     */   private static final String STR_CLOSE = "CLOSE";
/*     */   
/*  54 */   private boolean cancelado = false;
/*     */   
/*  56 */   protected JDialog dialog = null;
/*     */   
/*  58 */   protected JLabel lblMessage = null;
/*     */   
/*  60 */   private JPasswordField pass = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PINDialog(Frame owner)
/*     */   {
/*  67 */     this.dialog = new JDialog(owner, I18N.getLocalMessage("i18n.mityc.cert.smartcards.GUI.title"), true);
/*  68 */     dialogInit();
/*     */   }
/*     */   
/*     */ 
/*     */   protected void dialogInit()
/*     */   {
/*     */     try
/*     */     {
/*  76 */       JPanel distr = new JPanel();
/*  77 */       JButton aceptar = new JButton(I18N.getLocalMessage("i18n.mityc.cert.smartcards.GUI.accept"));
/*  78 */       JButton cancelar = new JButton(I18N.getLocalMessage("i18n.mityc.cert.smartcards.GUI.cancel"));
/*     */       
/*  80 */       aceptar.setActionCommand("OK");
/*  81 */       cancelar.setActionCommand("CLOSE");
/*     */       
/*  83 */       this.pass = new JPasswordField(15);
/*  84 */       GridBagConstraints g = new GridBagConstraints();
/*  85 */       distr.setLayout(new GridBagLayout());
/*  86 */       this.dialog.setResizable(false);
/*     */       
/*  88 */       g.insets = new Insets(5, 15, 3, 15);
/*  89 */       g.gridx = 0;
/*  90 */       g.gridy = 2;
/*  91 */       g.gridwidth = 1;
/*  92 */       g.fill = 0;
/*  93 */       g.weightx = 0.0D;
/*     */       
/*  95 */       this.lblMessage = new JLabel(I18N.getLocalMessage("i18n.mityc.cert.smartcards.GUI.pin"));
/*  96 */       distr.add(this.lblMessage, g);
/*     */       
/*  98 */       g.gridy = 2;
/*  99 */       g.gridx = -1;
/* 100 */       g.gridwidth = 0;
/* 101 */       g.fill = 2;
/* 102 */       g.weightx = 1.0D;
/* 103 */       distr.add(this.pass, g);
/*     */       
/* 105 */       g.gridx = 0;
/* 106 */       g.gridy = 3;
/* 107 */       g.fill = 0;
/* 108 */       g.weightx = 0.0D;
/* 109 */       g.gridwidth = 6;
/* 110 */       g.anchor = 17;
/*     */       
/* 112 */       distr.add(aceptar, g);
/*     */       
/* 114 */       g.gridx = -1;
/* 115 */       g.gridy = 3;
/* 116 */       g.fill = 0;
/* 117 */       g.weightx = 0.0D;
/* 118 */       g.gridwidth = 0;
/* 119 */       g.anchor = 13;
/* 120 */       distr.add(cancelar, g);
/*     */       
/* 122 */       distr.doLayout();
/* 123 */       this.dialog.add(distr);
/* 124 */       this.dialog.setResizable(false);
/* 125 */       this.dialog.setDefaultCloseOperation(0);
/* 126 */       this.dialog.getRootPane().setDefaultButton(aceptar);
/* 127 */       this.dialog.setLocationRelativeTo(null);
/*     */       
/* 129 */       aceptar.addActionListener(
/* 130 */         new ActionListener() {
/*     */           public void actionPerformed(ActionEvent e) {
/* 132 */             if (e.getActionCommand().equals("OK")) {
/* 133 */               PINDialog.this.dialog.setVisible(false);
/*     */             }
/*     */             
/*     */           }
/* 137 */         });
/* 138 */       cancelar.addActionListener(
/* 139 */         new ActionListener() {
/*     */           public void actionPerformed(ActionEvent e) {
/* 141 */             if (e.getActionCommand().equals("CLOSE")) {
/* 142 */               PINDialog.this.cancelado = true;
/* 143 */               PINDialog.this.dialog.setVisible(false);
/*     */             }
/*     */           }
/* 146 */         });
/* 147 */       this.dialog.setSize(new Dimension(300, 300));
/*     */     }
/*     */     catch (Exception e) {
/* 150 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTitle(String newTitle)
/*     */   {
/* 159 */     this.dialog.setTitle(newTitle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPINMessage(String newMessage)
/*     */   {
/* 167 */     this.lblMessage.setText(newMessage);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void pack()
/*     */   {
/* 174 */     this.dialog.pack();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVisible(boolean flag)
/*     */   {
/* 184 */     if (flag) {
/* 185 */       this.cancelado = false;
/* 186 */       this.pass.setText("");
/*     */     }
/* 188 */     this.dialog.setVisible(flag);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] getPassword()
/*     */   {
/* 196 */     return this.pass.getPassword();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void dispose()
/*     */   {
/* 203 */     this.dialog.dispose();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCancelado()
/*     */   {
/* 211 */     return this.cancelado;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mozilla\PINDialog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */