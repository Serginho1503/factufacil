/*     */ package es.mityc.javasign.pkstore.mitycstore.mantainer;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.pkstore.CertStoreException;
/*     */ import es.mityc.javasign.pkstore.IPKStoreMaintainer;
/*     */ import es.mityc.javasign.pkstore.IPKStoreManager;
/*     */ import es.mityc.javasign.pkstore.mitycstore.MITyCStore;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FileDialog;
/*     */ import java.awt.Frame;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FilenameFilter;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JProgressBar;
/*     */ import javax.swing.JSeparator;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class KSManagerDialog
/*     */   extends JDialog
/*     */ {
/*  66 */   private static final Log LOG = LogFactory.getLog(KSManagerDialog.class);
/*     */   
/*  68 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*     */   
/*     */ 
/*     */   private static final int WIDTH = 600;
/*     */   
/*     */ 
/*     */   private static final int HEIGHT = 500;
/*     */   
/*     */ 
/*  77 */   private JMenuBar menuBar = null;
/*     */   
/*  79 */   private JMenu fileMenu = null;
/*     */   
/*  81 */   private JMenuItem loadItem = null;
/*     */   
/*  83 */   private JMenuItem exitMenuItem = null;
/*     */   
/*  85 */   private JMenu helpMenu = null;
/*     */   
/*  87 */   private JMenuItem showHelpMenuItem = null;
/*     */   
/*     */ 
/*  90 */   private JButton acceptBtn = null;
/*     */   
/*  92 */   private JButton cancelBtn = null;
/*     */   
/*     */ 
/*  95 */   private JSeparator statusPanelSeparator = null;
/*     */   
/*  97 */   private JPanel statusPanel = null;
/*     */   
/*  99 */   private JProgressBar progressBar = null;
/*     */   
/*     */ 
/* 102 */   private KSManagerPanel ksmp = null;
/*     */   
/* 104 */   private Frame owner = null;
/*     */   
/*     */ 
/* 107 */   private static KSManagerDialog ksm = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static KSManagerDialog getInstance(Frame owner, boolean modal, IPKStoreManager pksm, IPKStoreMaintainer pksma)
/*     */   {
/* 119 */     if (ksm == null) {
/* 120 */       ksm = new KSManagerDialog(owner, modal, pksm, pksma);
/*     */     }
/*     */     
/* 123 */     return ksm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private KSManagerDialog(Frame own, boolean modal, IPKStoreManager pksm, IPKStoreMaintainer pksma)
/*     */   {
/* 134 */     super(own, I18N.getLocalMessage("i18n.mityc.cert.mityc.57"), modal);
/* 135 */     this.owner = own;
/* 136 */     dialogInit(pksm, pksma);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void dialogInit(IPKStoreManager pksm, IPKStoreMaintainer pksma)
/*     */   {
/*     */     try
/*     */     {
/* 147 */       this.ksmp = new KSManagerPanel(this.owner, pksm, pksma);
/*     */       
/*     */ 
/*     */ 
/* 151 */       Action loadAction = new AbstractAction("load") {
/*     */         public void actionPerformed(ActionEvent arg0) {
/* 153 */           File fichero = null;
/*     */           
/* 155 */           FileDialog fd = new FileDialog(KSManagerDialog.ksm, KSManagerDialog.I18N.getLocalMessage("i18n.mityc.cert.mityc.58"), 0);
/* 156 */           fd.setFilenameFilter(new KSManagerDialog.PropFilter(KSManagerDialog.this, null));
/* 157 */           fd.setVisible(true);
/*     */           try {
/* 159 */             fichero = new File(fd.getFile());
/*     */           }
/*     */           catch (NullPointerException e) {
/* 162 */             return;
/*     */           }
/* 164 */           if ((fichero != null) && (fichero.exists())) {
/*     */             try {
/* 166 */               MITyCStore ksMityc = new MITyCStore(new FileInputStream(fichero.getAbsolutePath()), false);
/* 167 */               KSManagerDialog.this.ksmp = new KSManagerPanel(KSManagerDialog.this.owner, ksMityc, ksMityc);
/* 168 */               KSManagerDialog.this.ksmp.repaint();
/*     */             }
/*     */             catch (CertStoreException e)
/*     */             {
/* 172 */               JOptionPane.showMessageDialog(KSManagerDialog.ksm, 
/* 173 */                 KSManagerDialog.I18N.getLocalMessage("i18n.mityc.cert.mityc.59"), 
/* 174 */                 KSManagerDialog.I18N.getLocalMessage("i18n.mityc.cert.mityc.15"), 
/* 175 */                 0);
/* 176 */               return;
/*     */             }
/*     */             catch (FileNotFoundException e)
/*     */             {
/* 180 */               JOptionPane.showMessageDialog(KSManagerDialog.ksm, 
/* 181 */                 KSManagerDialog.I18N.getLocalMessage("i18n.mityc.cert.mityc.59"), 
/* 182 */                 KSManagerDialog.I18N.getLocalMessage("i18n.mityc.cert.mityc.15"), 
/* 183 */                 0);
/* 184 */               return;
/*     */             }
/*     */             
/*     */           }
/*     */         }
/* 189 */       };
/* 190 */       Action quitAction = new AbstractAction("quit") {
/*     */         public void actionPerformed(ActionEvent e) {
/* 192 */           KSManagerDialog.ksm.setVisible(false);
/* 193 */           KSManagerDialog.ksm.dispose();
/*     */         }
/*     */         
/* 196 */       };
/* 197 */       Action showHelpAction = new AbstractAction("showHelp")
/*     */       {
/*     */ 
/*     */         public void actionPerformed(ActionEvent arg0) {}
/*     */ 
/* 202 */       };
/* 203 */       this.menuBar = new JMenuBar();
/* 204 */       this.menuBar.setName("menuBar");
/*     */       
/* 206 */       this.fileMenu = new JMenu();
/*     */       
/* 208 */       this.fileMenu.setText(I18N.getLocalMessage("i18n.mityc.cert.mityc.60"));
/* 209 */       this.fileMenu.setName("fileMenu");
/*     */       
/* 211 */       this.loadItem = new JMenuItem();
/* 212 */       this.loadItem.setAction(loadAction);
/*     */       
/* 214 */       this.loadItem.setText(I18N.getLocalMessage("i18n.mityc.cert.mityc.61"));
/* 215 */       this.loadItem.setName("LoadMenuItem");
/* 216 */       this.fileMenu.add(this.loadItem);
/*     */       
/* 218 */       this.fileMenu.addSeparator();
/*     */       
/* 220 */       this.exitMenuItem = new JMenuItem();
/* 221 */       this.exitMenuItem.setAction(quitAction);
/*     */       
/* 223 */       this.exitMenuItem.setText(I18N.getLocalMessage("i18n.mityc.cert.mityc.62"));
/* 224 */       this.exitMenuItem.setName("exitMenuItem");
/* 225 */       this.fileMenu.add(this.exitMenuItem);
/*     */       
/* 227 */       this.menuBar.add(this.fileMenu);
/*     */       
/* 229 */       this.helpMenu = new JMenu();
/*     */       
/* 231 */       this.helpMenu.setText(I18N.getLocalMessage("i18n.mityc.cert.mityc.63"));
/* 232 */       this.helpMenu.setName("helpMenu");
/*     */       
/* 234 */       this.showHelpMenuItem = new JMenuItem();
/* 235 */       this.showHelpMenuItem.setAction(showHelpAction);
/* 236 */       this.showHelpMenuItem.setName("exitMenuItem");
/*     */       
/* 238 */       this.showHelpMenuItem.setText(I18N.getLocalMessage("i18n.mityc.cert.mityc.64"));
/* 239 */       this.helpMenu.add(this.showHelpMenuItem);
/*     */       
/* 241 */       this.menuBar.add(this.helpMenu);
/*     */       
/* 243 */       this.acceptBtn = new JButton();
/* 244 */       this.acceptBtn.setAction(null);
/* 245 */       this.acceptBtn.setMnemonic(10);
/*     */       
/* 247 */       this.acceptBtn.setText(I18N.getLocalMessage("i18n.mityc.cert.mityc.65"));
/*     */       
/* 249 */       this.acceptBtn.setVisible(false);
/*     */       
/* 251 */       this.cancelBtn = new JButton();
/* 252 */       this.cancelBtn.setAction(quitAction);
/* 253 */       this.cancelBtn.setMnemonic(27);
/*     */       
/* 255 */       this.cancelBtn.setText(I18N.getLocalMessage("i18n.mityc.cert.mityc.62"));
/*     */       
/*     */ 
/* 258 */       this.statusPanel = new JPanel();
/* 259 */       this.statusPanelSeparator = new JSeparator();
/* 260 */       this.progressBar = new JProgressBar();
/*     */       
/*     */ 
/* 263 */       this.statusPanel.setLayout(new GridBagLayout());
/*     */       
/* 265 */       GridBagConstraints statusGrid = new GridBagConstraints();
/* 266 */       statusGrid.gridx = 0;
/* 267 */       statusGrid.gridy = 0;
/* 268 */       statusGrid.gridwidth = 6;
/* 269 */       statusGrid.fill = 2;
/* 270 */       statusGrid.weightx = 1.0D;
/* 271 */       statusGrid.insets = new Insets(0, 10, 0, 10);
/* 272 */       this.statusPanel.add(this.statusPanelSeparator, statusGrid);
/*     */       
/* 274 */       GridBagConstraints progressGrid = new GridBagConstraints();
/* 275 */       progressGrid.gridx = 0;
/* 276 */       progressGrid.gridy = 1;
/* 277 */       progressGrid.insets = new Insets(8, 480, 0, 10);
/* 278 */       progressGrid.ipadx = 70;
/* 279 */       this.statusPanel.add(this.progressBar, progressGrid);
/*     */       
/* 281 */       setLayout(new GridBagLayout());
/* 282 */       GridBagConstraints mainPanelGrid = new GridBagConstraints();
/* 283 */       mainPanelGrid.gridx = 0;
/* 284 */       mainPanelGrid.gridy = 0;
/* 285 */       mainPanelGrid.gridwidth = 4;
/* 286 */       mainPanelGrid.insets = new Insets(10, 10, 10, 10);
/* 287 */       mainPanelGrid.fill = 1;
/* 288 */       mainPanelGrid.weightx = 1.0D;
/* 289 */       mainPanelGrid.weighty = 1.0D;
/* 290 */       add(this.ksmp, mainPanelGrid);
/*     */       
/* 292 */       GridBagConstraints accBtnGrid = new GridBagConstraints();
/* 293 */       accBtnGrid.gridx = 2;
/* 294 */       accBtnGrid.gridy = 1;
/* 295 */       accBtnGrid.insets = new Insets(10, 130, 10, 10);
/* 296 */       add(this.acceptBtn, accBtnGrid);
/*     */       
/* 298 */       GridBagConstraints cancBtnGrid = new GridBagConstraints();
/* 299 */       cancBtnGrid.gridx = 3;
/* 300 */       cancBtnGrid.gridy = 1;
/* 301 */       cancBtnGrid.insets = new Insets(10, 20, 10, 10);
/* 302 */       add(this.cancelBtn, cancBtnGrid);
/*     */       
/* 304 */       GridBagConstraints statusPanelGrid = new GridBagConstraints();
/* 305 */       statusPanelGrid.gridx = 0;
/* 306 */       statusPanelGrid.gridy = 2;
/* 307 */       statusPanelGrid.gridwidth = 4;
/* 308 */       statusPanelGrid.fill = 2;
/* 309 */       statusPanelGrid.weightx = 1.0D;
/* 310 */       statusPanelGrid.ipady = 10;
/* 311 */       add(this.statusPanel, statusPanelGrid);
/*     */       
/*     */ 
/* 314 */       setJMenuBar(this.menuBar);
/* 315 */       setBackground(this.ksmp.getBackground());
/* 316 */       setLocationRelativeTo(this.owner);
/* 317 */       setSize(600, 500);
/* 318 */       if (this.owner == null) {
/* 319 */         Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
/* 320 */         setLocation(screenSize.width / 2 - getWidth() / 2, screenSize.height / 2 - getHeight() / 2);
/*     */       }
/* 322 */       setResizable(false);
/* 323 */       setDefaultCloseOperation(0);
/* 324 */       addWindowListener(new WindowAdapter()
/*     */       {
/*     */         public void windowClosing(WindowEvent e) {
/* 327 */           KSManagerDialog.ksm.setVisible(false);
/* 328 */           KSManagerDialog.ksm.dispose();
/*     */         }
/*     */         
/* 331 */       });
/* 332 */       doLayout();
/*     */     }
/*     */     catch (Exception ex) {
/* 335 */       ex.printStackTrace();
/* 336 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mityc.66", new Object[] { ex.getMessage() }));
/* 337 */       if (LOG.isDebugEnabled()) {
/* 338 */         LOG.debug(I18N.getLocalMessage("i18n.mityc.cert.mityc.66"), ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class PropFilter
/*     */     implements FilenameFilter
/*     */   {
/*     */     private PropFilter() {}
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean accept(File dir, String name)
/*     */     {
/* 354 */       return name.endsWith(".properties");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 364 */     File ficheroConf = new File(args[0]);
/*     */     try
/*     */     {
/* 367 */       MITyCStore mks = MITyCStore.getInstance(ficheroConf, true);
/* 368 */       KSManagerDialog manager = getInstance(null, true, mks, mks);
/* 369 */       manager.setVisible(true);
/*     */     } catch (CertStoreException e) {
/* 371 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mitycstore\mantainer\KSManagerDialog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */