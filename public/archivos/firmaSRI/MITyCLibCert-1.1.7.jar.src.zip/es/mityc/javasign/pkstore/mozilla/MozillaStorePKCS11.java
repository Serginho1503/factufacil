/*     */ package es.mityc.javasign.pkstore.mozilla;
/*     */ 
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.pkstore.CertStoreException;
/*     */ import es.mityc.javasign.pkstore.IPKStoreManager;
/*     */ import es.mityc.javasign.utils.OSTool;
/*     */ import es.mityc.javasign.utils.OSTool.OS;
/*     */ import iaik.pkcs.pkcs11.DefaultInitializeArgs;
/*     */ import iaik.pkcs.pkcs11.Module;
/*     */ import iaik.pkcs.pkcs11.PkProxyProvider;
/*     */ import iaik.pkcs.pkcs11.PkcsProvider;
/*     */ import iaik.pkcs.pkcs11.Session;
/*     */ import iaik.pkcs.pkcs11.Slot;
/*     */ import iaik.pkcs.pkcs11.Token;
/*     */ import iaik.pkcs.pkcs11.TokenInfo;
/*     */ import iaik.pkcs.pkcs11.objects.BooleanAttribute;
/*     */ import iaik.pkcs.pkcs11.objects.ByteArrayAttribute;
/*     */ import iaik.pkcs.pkcs11.objects.CharArrayAttribute;
/*     */ import iaik.pkcs.pkcs11.objects.RSAPrivateKey;
/*     */ import iaik.pkcs.pkcs11.objects.X509PublicKeyCertificate;
/*     */ import java.io.File;
/*     */ import java.math.BigInteger;
/*     */ import java.security.Principal;
/*     */ import java.security.Provider;
/*     */ import java.security.cert.CertPath;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.mozilla.jss.util.Password;
/*     */ import org.mozilla.jss.util.PasswordCallback;
/*     */ import org.mozilla.jss.util.PasswordCallbackInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MozillaStorePKCS11
/*     */   implements IPKStoreManager
/*     */ {
/*  63 */   private static final Log LOG = LogFactory.getLog(MozillaStorePKCS11.class);
/*     */   
/*  65 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*     */   
/*     */ 
/*  68 */   private static Module cmNss = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public MozillaStorePKCS11(String profile)
/*     */     throws CertStoreException
/*     */   {
/*  75 */     this(profile, MozillaStoreUtils.LIB_MODE.ONLY_PKCS11);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MozillaStorePKCS11(String profile, MozillaStoreUtils.LIB_MODE mode)
/*     */     throws CertStoreException
/*     */   {
/*  84 */     if (cmNss == null) {
/*  85 */       initialize(profile, mode);
/*     */     }
/*     */   }
/*     */   
/*     */   public CertPath getCertPath(X509Certificate certificate)
/*     */     throws CertStoreException
/*     */   {
/*  92 */     throw new UnsupportedOperationException("Not implemented yet");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public java.security.PrivateKey getPrivateKey(X509Certificate certificate)
/*     */     throws CertStoreException
/*     */   {
/* 100 */     if (cmNss != null) {
/*     */       try {
/* 102 */         Slot[] availSlots = cmNss.getSlotList(false);
/* 103 */         if (availSlots.length == 0) {
/* 104 */           LOG.error("No se puede acceder a Firefox, no se han encontrado slots libres.");
/* 105 */           return null;
/*     */         }
/* 107 */         for (int i = 0; i < availSlots.length; i++) {
/* 108 */           if (LOG.isDebugEnabled()) {
/* 109 */             LOG.debug("Procesando slot " + i);
/*     */           }
/*     */           
/* 112 */           Token tok = availSlots[i].getToken();
/* 113 */           Session sess = tok.openSession(true, false, null, null);
/* 114 */           if (LOG.isDebugEnabled()) {
/* 115 */             LOG.debug("Session: " + sess.getSessionInfo());
/*     */           }
/*     */           
/* 118 */           if (tok.getTokenInfo().isLoginRequired()) {
/* 119 */             if (LOG.isDebugEnabled()) {
/* 120 */               LOG.debug("Solicitando contraseña de acceso");
/*     */             }
/* 122 */             PasswordCallback passDialog = MozillaStoreUtils.getPassHandler(IPINDialogConfigurable.MESSAGES_MODE.AUTO_TOKEN, null, I18N.getLocalMessage("i18n.mityc.cert.mozilla.8"));
/* 123 */             Password pass = passDialog.getPasswordFirstAttempt(new PasswordCallbackInfo("Firefox", 1));
/* 124 */             if (LOG.isDebugEnabled()) {
/* 125 */               LOG.debug("PIN obtenido, Autenticando");
/*     */             }
/*     */             try {
/* 128 */               sess.login(true, pass.getCharCopy());
/*     */             } catch (Exception e) {
/* 130 */               throw new CertStoreException("Contraseña incorrecta", e);
/*     */             }
/*     */           }
/*     */           
/* 134 */           if (LOG.isDebugEnabled()) {
/* 135 */             LOG.debug("Resolviendo alias del certificado");
/*     */           }
/* 137 */           X509PublicKeyCertificate tempCert = new X509PublicKeyCertificate();
/* 138 */           sess.findObjectsInit(tempCert);
/* 139 */           iaik.pkcs.pkcs11.objects.Object[] foundCerts = sess.findObjects(100);
/* 140 */           LOG.debug("Se han encontrado " + foundCerts.length + " certificados en el almacén de Firefox");
/* 141 */           sess.findObjectsFinal();
/* 142 */           String labelToFind = null;
/* 143 */           for (int j = 0; j < foundCerts.length; j++)
/*     */           {
/* 145 */             if (Arrays.equals(certificate.getIssuerX500Principal().getEncoded(), ((X509PublicKeyCertificate)foundCerts[j]).getIssuer().getByteArrayValue()))
/*     */             {
/* 147 */               byte[] serialPkcs11 = ((X509PublicKeyCertificate)foundCerts[j]).getSerialNumber().getByteArrayValue();
/* 148 */               serialPkcs11 = Arrays.copyOfRange(serialPkcs11, 2, serialPkcs11.length);
/* 149 */               if (Arrays.equals(certificate.getSerialNumber().toByteArray(), serialPkcs11)) {
/* 150 */                 labelToFind = ((X509PublicKeyCertificate)foundCerts[j]).getLabel().toString();
/* 151 */                 break;
/*     */               }
/*     */             }
/*     */           }
/*     */           
/* 156 */           if (LOG.isDebugEnabled()) {
/* 157 */             LOG.debug("Buscando clave privada asociada al alias " + labelToFind);
/*     */           }
/* 159 */           RSAPrivateKey tempKey = new RSAPrivateKey();
/* 160 */           tempKey.getSign().setBooleanValue(Boolean.TRUE);
/* 161 */           sess.findObjectsInit(tempKey);
/* 162 */           iaik.pkcs.pkcs11.objects.Object[] foundKeys = sess.findObjects(100);
/* 163 */           sess.findObjectsFinal();
/* 164 */           LOG.debug("Encontradas " + foundKeys.length + " claves privadas");
/*     */           
/* 166 */           if ((foundKeys != null) && (foundKeys.length > 0)) {
/* 167 */             for (int j = 0; j < foundKeys.length; j++) {
/* 168 */               RSAPrivateKey tokenkey = (RSAPrivateKey)foundKeys[j];
/* 169 */               if (labelToFind.equals(new String(tokenkey.getLabel().getCharArrayValue()))) {
/* 170 */                 if (LOG.isDebugEnabled()) {
/* 171 */                   LOG.debug("Devolviendo pasarela a la clave privada");
/*     */                 }
/* 173 */                 return new PkProxyProvider(certificate, (RSAPrivateKey)foundKeys[j], sess);
/*     */               }
/*     */             }
/* 176 */             if (LOG.isDebugEnabled()) {
/* 177 */               LOG.debug("Clave privada no encontrada");
/*     */             }
/* 179 */             return null;
/*     */           }
/*     */         }
/* 182 */         if (LOG.isDebugEnabled()) {
/* 183 */           LOG.debug("Clave privada no encontrada");
/*     */         }
/* 185 */         return null;
/*     */       } catch (Exception e) {
/* 187 */         throw new CertStoreException("No se pudo acceder al repositorio de certificados de Firefox", e);
/*     */       }
/*     */     }
/* 190 */     throw new CertStoreException("No se pudo acceder al repositorio de certificados de Firefox");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Provider getProvider(X509Certificate cert)
/*     */   {
/* 200 */     if (LOG.isDebugEnabled()) {
/* 201 */       LOG.debug("Devolviendo instancia del proveedor criptográfico PKCS11Wrapper+NSS");
/*     */     }
/* 203 */     return new PkcsProvider();
/*     */   }
/*     */   
/*     */ 
/*     */   public List<X509Certificate> getSignCertificates()
/*     */     throws CertStoreException
/*     */   {
/* 210 */     return getCertificates(true);
/*     */   }
/*     */   
/*     */   public List<X509Certificate> getPublicCertificates() throws CertStoreException {
/* 214 */     return getCertificates(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<X509Certificate> getCertificates(boolean getPrivates)
/*     */     throws CertStoreException
/*     */   {
/* 225 */     if (cmNss == null) {
/* 226 */       LOG.error("No se ha cargado el módulo CSP-PKCS11 para Mozilla");
/* 227 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mozilla.9"));
/*     */     }
/* 229 */     ArrayList<X509Certificate> allCertsPublic = new ArrayList();
/* 230 */     ArrayList<X509Certificate> allCertsPrivate = new ArrayList();
/* 231 */     int foundCertsTotal = 0;
/*     */     try {
/* 233 */       Slot[] availSlots = cmNss.getSlotList(false);
/* 234 */       if (availSlots.length == 0) {
/* 235 */         LOG.error("No se puede acceder a Firefox, no se han encontrado slots libres.");
/* 236 */         return null; }
/* 237 */       if (LOG.isDebugEnabled()) {
/* 238 */         LOG.debug("Slots disponibles: " + availSlots.length);
/*     */       }
/*     */       
/* 241 */       for (int i = 0; i < availSlots.length; i++) {
/* 242 */         if (LOG.isTraceEnabled()) {
/* 243 */           LOG.trace("Procesando slot " + i);
/*     */         }
/*     */         
/* 246 */         Token tok = availSlots[i].getToken();
/* 247 */         Session sess = tok.openSession(true, false, null, null);
/* 248 */         if (LOG.isTraceEnabled()) {
/* 249 */           LOG.trace("Session: " + sess.getSessionInfo());
/*     */         }
/*     */         
/* 252 */         if (tok.getTokenInfo().isLoginRequired()) {
/* 253 */           if (LOG.isDebugEnabled()) {
/* 254 */             LOG.debug("Solicitando contraseña de acceso");
/*     */           }
/* 256 */           PasswordCallback passDialog = MozillaStoreUtils.getPassHandler(IPINDialogConfigurable.MESSAGES_MODE.AUTO_TOKEN, null, I18N.getLocalMessage("i18n.mityc.cert.mozilla.8"));
/* 257 */           Password pass = passDialog.getPasswordFirstAttempt(new PasswordCallbackInfo("Firefox", 1));
/* 258 */           if (LOG.isDebugEnabled()) {
/* 259 */             LOG.debug("PIN obtenido, Autenticando");
/*     */           }
/*     */           try {
/* 262 */             sess.login(true, pass.getCharCopy());
/*     */           } catch (Exception e) {
/* 264 */             LOG.error("Contraseña incorrecta", e);
/* 265 */             continue;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 270 */         X509PublicKeyCertificate tempCert = new X509PublicKeyCertificate();
/* 271 */         sess.findObjectsInit(tempCert);
/* 272 */         iaik.pkcs.pkcs11.objects.Object[] foundCerts = sess.findObjects(100);
/* 273 */         LOG.debug("Se han encontrado " + foundCerts.length + " certificados");
/* 274 */         foundCertsTotal += foundCerts.length;
/* 275 */         sess.findObjectsFinal();
/*     */         
/* 277 */         if (getPrivates)
/*     */         {
/* 279 */           iaik.pkcs.pkcs11.objects.PrivateKey tempKey = new iaik.pkcs.pkcs11.objects.PrivateKey();
/* 280 */           sess.findObjectsInit(tempKey);
/* 281 */           iaik.pkcs.pkcs11.objects.Object[] privateKeys = sess.findObjects(100);
/* 282 */           LOG.debug("Encontradas " + privateKeys.length + " claves privadas");
/* 283 */           sess.findObjectsFinal();
/*     */           
/*     */ 
/* 286 */           iaik.pkcs.pkcs11.objects.PublicKey tempKey2 = new iaik.pkcs.pkcs11.objects.PublicKey();
/* 287 */           sess.findObjectsInit(tempKey2);
/* 288 */           iaik.pkcs.pkcs11.objects.Object[] publicKeys = sess.findObjects(100);
/* 289 */           LOG.debug("Encontradas " + publicKeys.length + " claves publicas");
/* 290 */           sess.findObjectsFinal();
/*     */           
/*     */ 
/* 293 */           for (int j = 0; j < foundCerts.length; j++) {
/* 294 */             X509Certificate cert = MozillaStoreUtils.convert((X509PublicKeyCertificate)foundCerts[j]);
/* 295 */             boolean[] usage = cert.getKeyUsage();
/*     */             
/* 297 */             if ((cert != null) && ((usage == null) || (usage[0] != 0) || (usage[1] != 0)))
/*     */             {
/* 299 */               if (!"RSA".equals(cert.getPublicKey().getAlgorithm())) {
/* 300 */                 if (LOG.isDebugEnabled()) {
/* 301 */                   LOG.debug("Encontrado certificado incompatible: " + cert.getSubjectDN().getName());
/* 302 */                   LOG.debug("Algoritmo incompatible de tipo: " + cert.getPublicKey().getAlgorithm());
/*     */                 }
/*     */               }
/*     */               else
/*     */               {
/* 307 */                 java.security.PublicKey pubKey = cert.getPublicKey();
/* 308 */                 if (!(pubKey instanceof java.security.interfaces.RSAPublicKey)) {
/* 309 */                   if (LOG.isDebugEnabled()) {
/* 310 */                     LOG.debug("Encontrado certificado incompatible: " + cert.getSubjectDN().getName());
/* 311 */                     LOG.debug("Clave pública incompatible de tipo: " + pubKey.getClass());
/*     */                   }
/*     */                 }
/*     */                 else {
/* 315 */                   BigInteger moduloCert = ((java.security.interfaces.RSAPublicKey)pubKey).getModulus();
/* 316 */                   BigInteger exponenteCert = ((java.security.interfaces.RSAPublicKey)pubKey).getPublicExponent();
/* 317 */                   iaik.pkcs.pkcs11.objects.PublicKey foundPublicKey = null;
/* 318 */                   for (int k = 0; k < publicKeys.length; k++) {
/* 319 */                     if (publicKeys[k] != null)
/*     */                     {
/*     */ 
/* 322 */                       String moduloPKHex = ((iaik.pkcs.pkcs11.objects.RSAPublicKey)publicKeys[k]).getModulus().toString();
/* 323 */                       BigInteger moduloPK = new BigInteger(moduloPKHex, 16);
/* 324 */                       if (moduloCert.equals(moduloPK)) {
/* 325 */                         String exponentePKHex = ((iaik.pkcs.pkcs11.objects.RSAPublicKey)publicKeys[k]).getPublicExponent().toString();
/* 326 */                         BigInteger exponentePK = new BigInteger(exponentePKHex, 16);
/* 327 */                         if (exponenteCert.equals(exponentePK)) {
/* 328 */                           foundPublicKey = (iaik.pkcs.pkcs11.objects.RSAPublicKey)publicKeys[k];
/* 329 */                           publicKeys[k] = null;
/* 330 */                           break;
/*     */                         }
/*     */                       }
/*     */                     }
/*     */                   }
/* 335 */                   if (foundPublicKey != null)
/*     */                   {
/* 337 */                     for (int k = 0; k < privateKeys.length; k++)
/* 338 */                       if (privateKeys[k] != null)
/*     */                       {
/*     */ 
/* 341 */                         iaik.pkcs.pkcs11.objects.PrivateKey pk = (iaik.pkcs.pkcs11.objects.PrivateKey)privateKeys[k];
/*     */                         
/* 343 */                         if ((pk.getId() != null) && (pk.getId().equals(foundPublicKey.getId())))
/*     */                         {
/* 345 */                           if (LOG.isDebugEnabled()) {
/* 346 */                             LOG.debug("Se ha encontrado un certificado asociado a una clave privada presente");
/*     */                           }
/* 348 */                           privateKeys[k] = null;
/* 349 */                           allCertsPrivate.add(cert);
/* 350 */                           break;
/*     */                         }
/*     */                       } }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         } else {
/* 358 */           for (int j = 0; j < foundCerts.length; j++) {
/* 359 */             X509Certificate cert = MozillaStoreUtils.convert((X509PublicKeyCertificate)foundCerts[j]);
/* 360 */             allCertsPublic.add(cert);
/*     */           }
/*     */         }
/*     */       }
/* 364 */       if (LOG.isTraceEnabled()) {
/* 365 */         LOG.trace("Modulo P11 procesado");
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/* 369 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mozilla.9"), ex);
/* 370 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mozilla.9"), ex);
/*     */     }
/*     */     
/* 373 */     if (getPrivates) {
/* 374 */       if (LOG.isDebugEnabled()) {
/* 375 */         LOG.debug("Se devuelven " + allCertsPrivate.size() + " certificados privados de un total de " + foundCertsTotal);
/*     */       }
/* 377 */       return allCertsPrivate;
/*     */     }
/* 379 */     return allCertsPublic;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<X509Certificate> getTrustCertificates()
/*     */     throws CertStoreException
/*     */   {
/* 387 */     throw new UnsupportedOperationException("Not implemented yet");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized void initialize(String profile, MozillaStoreUtils.LIB_MODE mode)
/*     */     throws CertStoreException
/*     */   {
/* 397 */     String tmpDir = MozillaStoreUtils.initialize(profile, mode);
/*     */     try
/*     */     {
/* 400 */       if (LOG.isDebugEnabled()) {
/* 401 */         LOG.debug("Se levanta el proveedor PKCS11Wrapper+NSS");
/*     */       }
/* 403 */       if ((tmpDir != null) && (!tmpDir.endsWith(File.separator))) {
/* 404 */         tmpDir = tmpDir + File.separator;
/*     */       }
/*     */       
/* 407 */       if (OSTool.getSO().isMacOsX()) {
/* 408 */         MozillaStoreUtils.configureMacNSS(tmpDir);
/*     */       }
/*     */       
/*     */ 
/* 412 */       cmNss = Module.getInstance("softokn3.dll");
/* 413 */       DefaultInitializeArgs arguments = new DefaultInitializeArgs();
/* 414 */       byte[] stringBytes = null;
/* 415 */       stringBytes = MozillaStoreUtils.createPKCS11NSSConfigFile(profile, tmpDir).getBytes();
/*     */       
/* 417 */       byte[] reservedBytes = new byte[stringBytes.length + 5];
/* 418 */       System.arraycopy(stringBytes, 0, reservedBytes, 0, stringBytes.length);
/* 419 */       arguments.setReserved(reservedBytes);
/* 420 */       if (LOG.isDebugEnabled()) {
/* 421 */         LOG.debug("Módulo instanciado. Incializando con " + new String(stringBytes));
/*     */       }
/* 423 */       cmNss.initialize(arguments);
/*     */     } catch (Throwable e) {
/* 425 */       LOG.error("No se pudo cargar la instancia de la librería NSS: " + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mozilla\MozillaStorePKCS11.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */