/*      */ package es.mityc.javasign.pkstore.mitycstore;
/*      */ 
/*      */ import es.mityc.javasign.i18n.I18nFactory;
/*      */ import es.mityc.javasign.i18n.II18nManager;
/*      */ import es.mityc.javasign.pkstore.CertStoreException;
/*      */ import es.mityc.javasign.pkstore.IPKStoreMaintainer;
/*      */ import es.mityc.javasign.pkstore.IPKStoreManager;
/*      */ import es.mityc.javasign.pkstore.IPassStoreKS;
/*      */ import es.mityc.javasign.pkstore.mitycstore.PKHandlers.CachedPassHandler;
/*      */ import es.mityc.javasign.pkstore.mitycstore.PKHandlers.DeleteWarnHandler;
/*      */ import es.mityc.javasign.pkstore.mitycstore.PKHandlers.Pkcs11PassHandler;
/*      */ import es.mityc.javasign.pkstore.mitycstore.PKHandlers.PlainPassHandler;
/*      */ import es.mityc.javasign.pkstore.mitycstore.PKHandlers.TranslucentPassHandler;
/*      */ import es.mityc.javasign.pkstore.mitycstore.PKHandlers.WarnPassHandler;
/*      */ import es.mityc.javasign.pkstore.mitycstore.mantainer.CertCellRenderer;
/*      */ import es.mityc.javasign.pkstore.mitycstore.mantainer.DriverTblModel;
/*      */ import es.mityc.javasign.pkstore.mitycstore.mantainer.KSManagerDialog;
/*      */ import es.mityc.javasign.pkstore.pkcs11.ConfigMultiPKCS11;
/*      */ import es.mityc.javasign.pkstore.pkcs11.MultiPKCS11Store;
/*      */ import java.awt.Container;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.GridBagConstraints;
/*      */ import java.awt.GridBagLayout;
/*      */ import java.awt.Insets;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.ItemEvent;
/*      */ import java.awt.event.ItemListener;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.security.KeyStore;
/*      */ import java.security.KeyStore.PasswordProtection;
/*      */ import java.security.KeyStore.PrivateKeyEntry;
/*      */ import java.security.KeyStore.TrustedCertificateEntry;
/*      */ import java.security.KeyStoreException;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.security.NoSuchProviderException;
/*      */ import java.security.PrivateKey;
/*      */ import java.security.Provider;
/*      */ import java.security.PublicKey;
/*      */ import java.security.UnrecoverableEntryException;
/*      */ import java.security.cert.CertPath;
/*      */ import java.security.cert.Certificate;
/*      */ import java.security.cert.CertificateException;
/*      */ import java.security.cert.CertificateFactory;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.MissingResourceException;
/*      */ import java.util.Properties;
/*      */ import java.util.Random;
/*      */ import java.util.Set;
/*      */ import javax.swing.BorderFactory;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JCheckBox;
/*      */ import javax.swing.JDialog;
/*      */ import javax.swing.JFileChooser;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JOptionPane;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JPasswordField;
/*      */ import javax.swing.JScrollPane;
/*      */ import javax.swing.JTabbedPane;
/*      */ import javax.swing.JTable;
/*      */ import javax.swing.table.TableColumn;
/*      */ import javax.swing.table.TableColumnModel;
/*      */ import javax.swing.table.TableModel;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MITyCStore
/*      */   implements IPKStoreManager, IPKStoreMaintainer
/*      */ {
/*  101 */   private static final Log LOG = LogFactory.getLog(MITyCStore.class);
/*      */   
/*  103 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibCert");
/*      */   
/*      */   private static final int RND_MAX_SIZE = 10000;
/*      */   
/*  107 */   private final String ksAlias = "MITyCKeyStoreAlias";
/*      */   
/*      */ 
/*  110 */   private static File confFile = null;
/*      */   
/*  112 */   private Properties prop = null;
/*      */   
/*  114 */   private boolean autocreate = false;
/*      */   
/*  116 */   private static String ksURL = null;
/*      */   
/*  118 */   private IPassStoreKS passKs = null;
/*      */   
/*  120 */   private HashMap<String, CachedPassHandler> passKsCachedList = null;
/*      */   
/*  122 */   private IPassStoreKS noPassWarnKs = null;
/*      */   
/*  124 */   private IPassStoreKS noPassNoWarnKs = null;
/*      */   
/*  126 */   private IPassStoreKS smartCrdPassKs = null;
/*      */   
/*  128 */   private KeyStore ks = null;
/*      */   
/*  130 */   private HashMap<String, String> drvrList = new HashMap();
/*      */   
/*  132 */   private MultiPKCS11Store pkcs11s = null;
/*      */   
/*  134 */   private AliasFormat aliasFormat = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static MITyCStore getInstance(File config, boolean auto)
/*      */     throws CertStoreException
/*      */   {
/*  145 */     InputStream is = null;
/*  146 */     if (config != null) {
/*  147 */       confFile = config;
/*      */       try
/*      */       {
/*  150 */         is = new FileInputStream(confFile);
/*      */       } catch (FileNotFoundException e) {
/*  152 */         LOG.error("No se pudo cargar la configuración indicada: " + 
/*  153 */           confFile.getPath() + 
/*  154 */           "\nSe carga la configuración por defecto");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  159 */     if (is == null) {
/*  160 */       is = KSManagerDialog.class.getResourceAsStream("/MITyC_KS.properties");
/*      */     }
/*      */     
/*  163 */     return new MITyCStore(is, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MITyCStore(InputStream config)
/*      */     throws CertStoreException
/*      */   {
/*  174 */     this(config, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MITyCStore(InputStream config, boolean auto)
/*      */     throws CertStoreException
/*      */   {
/*  193 */     this.prop = new Properties();
/*      */     try {
/*  195 */       this.prop.load(config);
/*      */     }
/*      */     catch (IOException e) {
/*  198 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mityc.59"), e);
/*      */     }
/*      */     
/*  201 */     this.autocreate = auto;
/*      */     
/*  203 */     init();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initPassHandlers()
/*      */   {
/*  212 */     this.passKs = new PlainPassHandler();
/*  213 */     this.passKsCachedList = new HashMap();
/*  214 */     this.noPassWarnKs = new WarnPassHandler();
/*  215 */     this.noPassNoWarnKs = new TranslucentPassHandler();
/*  216 */     this.smartCrdPassKs = new Pkcs11PassHandler();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CertPath getCertPath(X509Certificate certificate)
/*      */     throws CertStoreException
/*      */   {
/*  227 */     CertPath cp = null;
/*      */     
/*  229 */     if (certificate == null) {
/*  230 */       if (LOG.isDebugEnabled()) {
/*  231 */         LOG.debug("Faltan parámetros de entrada.");
/*      */       }
/*  233 */       return null;
/*      */     }
/*      */     
/*  236 */     if (this.ks == null) {
/*  237 */       if (LOG.isDebugEnabled()) {
/*  238 */         LOG.debug("El almacén no está inicializado.");
/*      */       }
/*  240 */       return null;
/*      */     }
/*      */     try
/*      */     {
/*  244 */       String alias = this.ks.getCertificateAlias(certificate);
/*      */       
/*  246 */       if (alias != null) {
/*  247 */         if (LOG.isDebugEnabled()) {
/*  248 */           LOG.debug("CertPath.- Certificado encontrado en el almacén: " + alias);
/*      */         }
/*  250 */         Certificate[] certArray = this.ks.getCertificateChain(alias);
/*      */         
/*  252 */         ArrayList<X509Certificate> certChain = new ArrayList();
/*  253 */         X509Certificate rootCert = (X509Certificate)certArray[0];
/*  254 */         certChain.add(rootCert);
/*      */         
/*  256 */         for (int i = 1; i < certArray.length; i++) {
/*  257 */           certChain.add((X509Certificate)certArray[i]);
/*      */         }
/*      */         
/*  260 */         cp = CertificateFactory.getInstance("X.509", "BC").generateCertPath(certChain);
/*      */       }
/*      */     }
/*      */     catch (KeyStoreException e1) {
/*  264 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mityc.1"), e1);
/*  265 */       return null;
/*      */     }
/*      */     catch (CertificateException e) {
/*  268 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mityc.2"), e);
/*      */     }
/*      */     catch (NoSuchProviderException e) {
/*  271 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mityc.3"), e);
/*  272 */       return null;
/*      */     }
/*      */     
/*  275 */     return cp;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PrivateKey getPrivateKey(X509Certificate certificate)
/*      */     throws CertStoreException
/*      */   {
/*  286 */     if (certificate == null) {
/*  287 */       if (LOG.isDebugEnabled()) {
/*  288 */         LOG.debug("Faltan parámetros de entrada.");
/*      */       }
/*  290 */       return null;
/*      */     }
/*      */     
/*  293 */     if (this.ks == null) {
/*  294 */       if (LOG.isDebugEnabled()) {
/*  295 */         LOG.debug("El almacén no está inicializado.");
/*      */       }
/*  297 */       return null;
/*      */     }
/*      */     
/*  300 */     String alias = null;
/*      */     try {
/*  302 */       alias = this.ks.getCertificateAlias(certificate);
/*      */       
/*  304 */       if (alias != null) {
/*  305 */         if (LOG.isDebugEnabled()) {
/*  306 */           LOG.debug("PrivateKey.- Certificado encontrado en el almacén: " + alias);
/*      */         }
/*  308 */         if (this.ks.entryInstanceOf(alias, KeyStore.PrivateKeyEntry.class))
/*      */         {
/*  310 */           KeyStore.PasswordProtection kpp = null;
/*  311 */           this.aliasFormat = new AliasFormat(alias);
/*  312 */           if (this.aliasFormat.isProtected()) {
/*  313 */             if (this.aliasFormat.isPassCached()) {
/*  314 */               CachedPassHandler handler = null;
/*  315 */               synchronized (this.passKsCachedList) {
/*  316 */                 handler = (CachedPassHandler)this.passKsCachedList.get(alias);
/*  317 */                 if (handler == null) {
/*  318 */                   handler = new CachedPassHandler();
/*  319 */                   this.passKsCachedList.put(alias, handler);
/*      */                 }
/*      */               }
/*  322 */               kpp = new KeyStore.PasswordProtection(handler.getPassword(certificate, null));
/*      */             } else {
/*  324 */               kpp = new KeyStore.PasswordProtection(this.passKs.getPassword(certificate, null));
/*      */             }
/*  326 */           } else if (this.aliasFormat.isMayWarning()) {
/*  327 */             kpp = new KeyStore.PasswordProtection(this.noPassWarnKs.getPassword(certificate, alias));
/*      */           } else {
/*  329 */             kpp = new KeyStore.PasswordProtection(this.noPassNoWarnKs.getPassword(certificate, alias));
/*      */           }
/*      */           
/*  332 */           if (kpp.getPassword() == null)
/*      */           {
/*  334 */             LOG.info(I18N.getLocalMessage("i18n.mityc.cert.mityc.81"));
/*  335 */             throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mityc.81"));
/*      */           }
/*      */           
/*      */ 
/*  339 */           KeyStore.PrivateKeyEntry pke = (KeyStore.PrivateKeyEntry)this.ks.getEntry(alias, kpp);
/*  340 */           if (pke != null) {
/*  341 */             return pke.getPrivateKey();
/*      */           }
/*      */           
/*  344 */           LOG.warn(I18N.getLocalMessage("i18n.mityc.cert.mityc.6"));
/*  345 */           return null;
/*      */         }
/*      */         
/*      */ 
/*  349 */         LOG.warn(I18N.getLocalMessage("i18n.mityc.cert.mityc.6"));
/*  350 */         return null;
/*      */       }
/*      */       
/*  353 */       return this.pkcs11s.getPrivateKey(certificate);
/*      */ 
/*      */     }
/*      */     catch (KeyStoreException e1)
/*      */     {
/*  358 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mityc.1"), e1);
/*  359 */       return null;
/*      */     }
/*      */     catch (NoSuchAlgorithmException e) {
/*  362 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mityc.7"), e);
/*  363 */       return null;
/*      */     }
/*      */     catch (UnrecoverableEntryException e) {
/*  366 */       CachedPassHandler handler = (CachedPassHandler)this.passKsCachedList.get(alias);
/*  367 */       if (handler != null) {
/*  368 */         handler.reset();
/*      */       }
/*      */       
/*  371 */       LOG.warn(I18N.getLocalMessage("i18n.mityc.cert.mityc.8")); }
/*  372 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Provider getProvider(X509Certificate cert)
/*      */   {
/*  383 */     Provider certProvider = null;
/*      */     
/*  385 */     if (this.pkcs11s != null) {
/*  386 */       certProvider = this.pkcs11s.getProvider(cert);
/*      */     }
/*      */     
/*  389 */     if (certProvider != null)
/*  390 */       return certProvider;
/*  391 */     if (this.ks != null)
/*      */     {
/*  393 */       return null;
/*      */     }
/*  395 */     if (LOG.isDebugEnabled()) {
/*  396 */       LOG.debug("El almacén de certificados aún no ha sido inicializado");
/*      */     }
/*  398 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<X509Certificate> getSignCertificates()
/*      */     throws CertStoreException
/*      */   {
/*  409 */     List<X509Certificate> certs = new ArrayList();
/*      */     
/*  411 */     if (this.ks == null) {
/*  412 */       if (LOG.isDebugEnabled()) {
/*  413 */         LOG.debug("El almacén no está inicializado.");
/*      */       }
/*  415 */       return null;
/*      */     }
/*      */     try
/*      */     {
/*  419 */       if (LOG.isDebugEnabled()) {
/*  420 */         LOG.debug("Obteniendo certificados de firma: Tamaño del almacén: " + this.ks.size());
/*      */       }
/*  422 */       Enumeration<String> aliases = this.ks.aliases();
/*  423 */       String alias = null;
/*  424 */       while (aliases.hasMoreElements()) {
/*  425 */         alias = (String)aliases.nextElement();
/*  426 */         if (LOG.isDebugEnabled()) {
/*  427 */           LOG.debug("  - Alias del certificado: " + alias);
/*      */         }
/*  429 */         if (this.ks.entryInstanceOf(alias, KeyStore.PrivateKeyEntry.class)) {
/*  430 */           certs.add((X509Certificate)this.ks.getCertificate(alias));
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (KeyStoreException e1) {
/*  435 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mityc.1"), e1);
/*  436 */       return null;
/*      */     }
/*      */     
/*  439 */     if (LOG.isDebugEnabled()) {
/*  440 */       LOG.debug("Lectura.- Accediendo a los módulos PKCS11");
/*      */     }
/*  442 */     List<X509Certificate> signCerts11 = this.pkcs11s.getSignCertificates();
/*  443 */     if (signCerts11 != null) {
/*  444 */       certs.addAll(signCerts11);
/*      */     }
/*      */     
/*  447 */     return certs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<X509Certificate> getTrustCertificates()
/*      */     throws CertStoreException
/*      */   {
/*  457 */     List<X509Certificate> certs = new ArrayList();
/*      */     
/*  459 */     if (this.ks == null) {
/*  460 */       if (LOG.isDebugEnabled()) {
/*  461 */         LOG.debug("El almacén no está inicializado.");
/*      */       }
/*  463 */       return null;
/*      */     }
/*      */     try
/*      */     {
/*  467 */       if (LOG.isDebugEnabled()) {
/*  468 */         LOG.debug("Obteniendo certificados de autenticación.- Tamaño del almacén: " + this.ks.size());
/*      */       }
/*  470 */       Enumeration<String> aliases = this.ks.aliases();
/*  471 */       String alias = null;
/*  472 */       while (aliases.hasMoreElements()) {
/*  473 */         alias = (String)aliases.nextElement();
/*  474 */         if (LOG.isDebugEnabled()) {
/*  475 */           LOG.debug("  - Alias del certificado: " + alias);
/*      */         }
/*  477 */         if (this.ks.entryInstanceOf(alias, KeyStore.TrustedCertificateEntry.class)) {
/*  478 */           certs.add((X509Certificate)this.ks.getCertificate(alias));
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (KeyStoreException e1) {
/*  483 */       LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mityc.9"), e1);
/*  484 */       return null;
/*      */     }
/*  486 */     return certs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<X509Certificate> getPublicCertificates()
/*      */     throws CertStoreException
/*      */   {
/*  495 */     throw new UnsupportedOperationException("Not implemented yet.");
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public void init()
/*      */     throws CertStoreException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aconst_null
/*      */     //   1: astore_1
/*      */     //   2: aload_0
/*      */     //   3: ldc_w 454
/*      */     //   6: invokestatic 456	java/security/KeyStore:getInstance	(Ljava/lang/String;)Ljava/security/KeyStore;
/*      */     //   9: putfield 156	es/mityc/javasign/pkstore/mitycstore/MITyCStore:ks	Ljava/security/KeyStore;
/*      */     //   12: goto +24 -> 36
/*      */     //   15: astore_2
/*      */     //   16: new 75	es/mityc/javasign/pkstore/CertStoreException
/*      */     //   19: dup
/*      */     //   20: getstatic 64	es/mityc/javasign/pkstore/mitycstore/MITyCStore:I18N	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   23: ldc_w 459
/*      */     //   26: invokeinterface 175 2 0
/*      */     //   31: aload_2
/*      */     //   32: invokespecial 181	es/mityc/javasign/pkstore/CertStoreException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
/*      */     //   35: athrow
/*      */     //   36: aload_0
/*      */     //   37: getfield 156	es/mityc/javasign/pkstore/mitycstore/MITyCStore:ks	Ljava/security/KeyStore;
/*      */     //   40: ifnonnull +26 -> 66
/*      */     //   43: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   46: invokeinterface 205 1 0
/*      */     //   51: ifeq +14 -> 65
/*      */     //   54: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   57: ldc_w 461
/*      */     //   60: invokeinterface 211 2 0
/*      */     //   65: return
/*      */     //   66: aload_0
/*      */     //   67: invokespecial 463	es/mityc/javasign/pkstore/mitycstore/MITyCStore:initPassHandlers	()V
/*      */     //   70: aload_0
/*      */     //   71: getfield 142	es/mityc/javasign/pkstore/mitycstore/MITyCStore:prop	Ljava/util/Properties;
/*      */     //   74: ldc_w 465
/*      */     //   77: invokevirtual 467	java/util/Properties:getProperty	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   80: putstatic 68	es/mityc/javasign/pkstore/mitycstore/MITyCStore:ksURL	Ljava/lang/String;
/*      */     //   83: getstatic 68	es/mityc/javasign/pkstore/mitycstore/MITyCStore:ksURL	Ljava/lang/String;
/*      */     //   86: ifnonnull +22 -> 108
/*      */     //   89: new 75	es/mityc/javasign/pkstore/CertStoreException
/*      */     //   92: dup
/*      */     //   93: getstatic 64	es/mityc/javasign/pkstore/mitycstore/MITyCStore:I18N	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   96: ldc_w 470
/*      */     //   99: invokeinterface 175 2 0
/*      */     //   104: invokespecial 342	es/mityc/javasign/pkstore/CertStoreException:<init>	(Ljava/lang/String;)V
/*      */     //   107: athrow
/*      */     //   108: getstatic 68	es/mityc/javasign/pkstore/mitycstore/MITyCStore:ksURL	Ljava/lang/String;
/*      */     //   111: invokevirtual 472	java/lang/String:trim	()Ljava/lang/String;
/*      */     //   114: putstatic 68	es/mityc/javasign/pkstore/mitycstore/MITyCStore:ksURL	Ljava/lang/String;
/*      */     //   117: aload_0
/*      */     //   118: getfield 142	es/mityc/javasign/pkstore/mitycstore/MITyCStore:prop	Ljava/util/Properties;
/*      */     //   121: ldc_w 465
/*      */     //   124: invokevirtual 475	java/util/Properties:remove	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   127: pop
/*      */     //   128: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   131: invokeinterface 478 1 0
/*      */     //   136: ifeq +30 -> 166
/*      */     //   139: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   142: new 83	java/lang/StringBuilder
/*      */     //   145: dup
/*      */     //   146: ldc_w 481
/*      */     //   149: invokespecial 87	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   152: getstatic 68	es/mityc/javasign/pkstore/mitycstore/MITyCStore:ksURL	Ljava/lang/String;
/*      */     //   155: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   158: invokevirtual 102	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   161: invokeinterface 483 2 0
/*      */     //   166: getstatic 68	es/mityc/javasign/pkstore/mitycstore/MITyCStore:ksURL	Ljava/lang/String;
/*      */     //   169: ifnull +338 -> 507
/*      */     //   172: new 91	java/io/File
/*      */     //   175: dup
/*      */     //   176: getstatic 68	es/mityc/javasign/pkstore/mitycstore/MITyCStore:ksURL	Ljava/lang/String;
/*      */     //   179: invokespecial 486	java/io/File:<init>	(Ljava/lang/String;)V
/*      */     //   182: invokevirtual 487	java/io/File:exists	()Z
/*      */     //   185: ifeq +322 -> 507
/*      */     //   188: new 91	java/io/File
/*      */     //   191: dup
/*      */     //   192: getstatic 68	es/mityc/javasign/pkstore/mitycstore/MITyCStore:ksURL	Ljava/lang/String;
/*      */     //   195: invokespecial 486	java/io/File:<init>	(Ljava/lang/String;)V
/*      */     //   198: invokevirtual 490	java/io/File:length	()J
/*      */     //   201: lconst_0
/*      */     //   202: lcmp
/*      */     //   203: ifeq +304 -> 507
/*      */     //   206: new 77	java/io/FileInputStream
/*      */     //   209: dup
/*      */     //   210: getstatic 68	es/mityc/javasign/pkstore/mitycstore/MITyCStore:ksURL	Ljava/lang/String;
/*      */     //   213: invokespecial 494	java/io/FileInputStream:<init>	(Ljava/lang/String;)V
/*      */     //   216: astore_1
/*      */     //   217: aload_0
/*      */     //   218: getfield 156	es/mityc/javasign/pkstore/mitycstore/MITyCStore:ks	Ljava/security/KeyStore;
/*      */     //   221: aload_1
/*      */     //   222: iconst_0
/*      */     //   223: newarray <illegal type>
/*      */     //   225: invokevirtual 495	java/security/KeyStore:load	(Ljava/io/InputStream;[C)V
/*      */     //   228: goto +263 -> 491
/*      */     //   231: astore_2
/*      */     //   232: aload_2
/*      */     //   233: invokevirtual 498	java/security/NoSuchAlgorithmException:printStackTrace	()V
/*      */     //   236: aload_1
/*      */     //   237: ifnull +336 -> 573
/*      */     //   240: aload_1
/*      */     //   241: invokevirtual 501	java/io/FileInputStream:close	()V
/*      */     //   244: goto +329 -> 573
/*      */     //   247: astore 6
/*      */     //   249: goto +324 -> 573
/*      */     //   252: astore_2
/*      */     //   253: aload_2
/*      */     //   254: invokevirtual 504	java/security/cert/CertificateException:printStackTrace	()V
/*      */     //   257: aload_1
/*      */     //   258: ifnull +315 -> 573
/*      */     //   261: aload_1
/*      */     //   262: invokevirtual 501	java/io/FileInputStream:close	()V
/*      */     //   265: goto +308 -> 573
/*      */     //   268: astore 6
/*      */     //   270: goto +303 -> 573
/*      */     //   273: astore_2
/*      */     //   274: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   277: invokeinterface 205 1 0
/*      */     //   282: ifeq +14 -> 296
/*      */     //   285: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   288: ldc_w 505
/*      */     //   291: invokeinterface 211 2 0
/*      */     //   296: aconst_null
/*      */     //   297: astore_3
/*      */     //   298: aload_0
/*      */     //   299: getfield 148	es/mityc/javasign/pkstore/mitycstore/MITyCStore:passKsCachedList	Ljava/util/HashMap;
/*      */     //   302: dup
/*      */     //   303: astore 4
/*      */     //   305: monitorenter
/*      */     //   306: aload_0
/*      */     //   307: getfield 148	es/mityc/javasign/pkstore/mitycstore/MITyCStore:passKsCachedList	Ljava/util/HashMap;
/*      */     //   310: ldc 19
/*      */     //   312: invokevirtual 308	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   315: checkcast 312	es/mityc/javasign/pkstore/mitycstore/PKHandlers/CachedPassHandler
/*      */     //   318: astore_3
/*      */     //   319: aload_3
/*      */     //   320: ifnonnull +22 -> 342
/*      */     //   323: new 312	es/mityc/javasign/pkstore/mitycstore/PKHandlers/CachedPassHandler
/*      */     //   326: dup
/*      */     //   327: invokespecial 314	es/mityc/javasign/pkstore/mitycstore/PKHandlers/CachedPassHandler:<init>	()V
/*      */     //   330: astore_3
/*      */     //   331: aload_0
/*      */     //   332: getfield 148	es/mityc/javasign/pkstore/mitycstore/MITyCStore:passKsCachedList	Ljava/util/HashMap;
/*      */     //   335: ldc 19
/*      */     //   337: aload_3
/*      */     //   338: invokevirtual 315	java/util/HashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   341: pop
/*      */     //   342: aload 4
/*      */     //   344: monitorexit
/*      */     //   345: goto +7 -> 352
/*      */     //   348: aload 4
/*      */     //   350: monitorexit
/*      */     //   351: athrow
/*      */     //   352: new 77	java/io/FileInputStream
/*      */     //   355: dup
/*      */     //   356: getstatic 68	es/mityc/javasign/pkstore/mitycstore/MITyCStore:ksURL	Ljava/lang/String;
/*      */     //   359: invokespecial 494	java/io/FileInputStream:<init>	(Ljava/lang/String;)V
/*      */     //   362: astore_1
/*      */     //   363: aload_0
/*      */     //   364: getfield 156	es/mityc/javasign/pkstore/mitycstore/MITyCStore:ks	Ljava/security/KeyStore;
/*      */     //   367: aload_1
/*      */     //   368: aload_3
/*      */     //   369: aconst_null
/*      */     //   370: getstatic 64	es/mityc/javasign/pkstore/mitycstore/MITyCStore:I18N	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   373: ldc_w 507
/*      */     //   376: invokeinterface 175 2 0
/*      */     //   381: invokevirtual 321	es/mityc/javasign/pkstore/mitycstore/PKHandlers/CachedPassHandler:getPassword	(Ljava/security/cert/X509Certificate;Ljava/lang/String;)[C
/*      */     //   384: invokevirtual 495	java/security/KeyStore:load	(Ljava/io/InputStream;[C)V
/*      */     //   387: goto +70 -> 457
/*      */     //   390: astore_3
/*      */     //   391: aload_2
/*      */     //   392: invokevirtual 509	java/io/IOException:printStackTrace	()V
/*      */     //   395: goto +62 -> 457
/*      */     //   398: astore_3
/*      */     //   399: aload_2
/*      */     //   400: invokevirtual 509	java/io/IOException:printStackTrace	()V
/*      */     //   403: goto +54 -> 457
/*      */     //   406: astore_3
/*      */     //   407: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   410: invokeinterface 205 1 0
/*      */     //   415: ifeq +23 -> 438
/*      */     //   418: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   421: getstatic 64	es/mityc/javasign/pkstore/mitycstore/MITyCStore:I18N	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   424: ldc_w 510
/*      */     //   427: invokeinterface 175 2 0
/*      */     //   432: aload_3
/*      */     //   433: invokeinterface 512 3 0
/*      */     //   438: new 75	es/mityc/javasign/pkstore/CertStoreException
/*      */     //   441: dup
/*      */     //   442: getstatic 64	es/mityc/javasign/pkstore/mitycstore/MITyCStore:I18N	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   445: ldc_w 510
/*      */     //   448: invokeinterface 175 2 0
/*      */     //   453: invokespecial 342	es/mityc/javasign/pkstore/CertStoreException:<init>	(Ljava/lang/String;)V
/*      */     //   456: athrow
/*      */     //   457: aload_1
/*      */     //   458: ifnull +115 -> 573
/*      */     //   461: aload_1
/*      */     //   462: invokevirtual 501	java/io/FileInputStream:close	()V
/*      */     //   465: goto +108 -> 573
/*      */     //   468: astore 6
/*      */     //   470: goto +103 -> 573
/*      */     //   473: astore 5
/*      */     //   475: aload_1
/*      */     //   476: ifnull +12 -> 488
/*      */     //   479: aload_1
/*      */     //   480: invokevirtual 501	java/io/FileInputStream:close	()V
/*      */     //   483: goto +5 -> 488
/*      */     //   486: astore 6
/*      */     //   488: aload 5
/*      */     //   490: athrow
/*      */     //   491: aload_1
/*      */     //   492: ifnull +81 -> 573
/*      */     //   495: aload_1
/*      */     //   496: invokevirtual 501	java/io/FileInputStream:close	()V
/*      */     //   499: goto +74 -> 573
/*      */     //   502: astore 6
/*      */     //   504: goto +69 -> 573
/*      */     //   507: aload_0
/*      */     //   508: getfield 144	es/mityc/javasign/pkstore/mitycstore/MITyCStore:autocreate	Z
/*      */     //   511: ifeq +43 -> 554
/*      */     //   514: aload_0
/*      */     //   515: getfield 156	es/mityc/javasign/pkstore/mitycstore/MITyCStore:ks	Ljava/security/KeyStore;
/*      */     //   518: aconst_null
/*      */     //   519: invokevirtual 514	java/security/KeyStore:load	(Ljava/security/KeyStore$LoadStoreParameter;)V
/*      */     //   522: aload_0
/*      */     //   523: invokespecial 517	es/mityc/javasign/pkstore/mitycstore/MITyCStore:saveStore	()Z
/*      */     //   526: pop
/*      */     //   527: goto +46 -> 573
/*      */     //   530: astore_2
/*      */     //   531: aload_2
/*      */     //   532: invokevirtual 498	java/security/NoSuchAlgorithmException:printStackTrace	()V
/*      */     //   535: goto +38 -> 573
/*      */     //   538: astore_2
/*      */     //   539: aload_2
/*      */     //   540: invokevirtual 504	java/security/cert/CertificateException:printStackTrace	()V
/*      */     //   543: goto +30 -> 573
/*      */     //   546: astore_2
/*      */     //   547: aload_2
/*      */     //   548: invokevirtual 509	java/io/IOException:printStackTrace	()V
/*      */     //   551: goto +22 -> 573
/*      */     //   554: new 75	es/mityc/javasign/pkstore/CertStoreException
/*      */     //   557: dup
/*      */     //   558: getstatic 64	es/mityc/javasign/pkstore/mitycstore/MITyCStore:I18N	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   561: ldc_w 520
/*      */     //   564: invokeinterface 175 2 0
/*      */     //   569: invokespecial 342	es/mityc/javasign/pkstore/CertStoreException:<init>	(Ljava/lang/String;)V
/*      */     //   572: athrow
/*      */     //   573: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   576: invokeinterface 205 1 0
/*      */     //   581: ifeq +14 -> 595
/*      */     //   584: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   587: ldc_w 522
/*      */     //   590: invokeinterface 211 2 0
/*      */     //   595: aload_0
/*      */     //   596: getfield 142	es/mityc/javasign/pkstore/mitycstore/MITyCStore:prop	Ljava/util/Properties;
/*      */     //   599: invokevirtual 524	java/util/Properties:keys	()Ljava/util/Enumeration;
/*      */     //   602: astore_2
/*      */     //   603: new 228	java/util/ArrayList
/*      */     //   606: dup
/*      */     //   607: invokespecial 230	java/util/ArrayList:<init>	()V
/*      */     //   610: astore_3
/*      */     //   611: goto +51 -> 662
/*      */     //   614: aload_2
/*      */     //   615: invokeinterface 409 1 0
/*      */     //   620: checkcast 284	java/lang/String
/*      */     //   623: invokevirtual 472	java/lang/String:trim	()Ljava/lang/String;
/*      */     //   626: astore 4
/*      */     //   628: aload 4
/*      */     //   630: iconst_0
/*      */     //   631: aload 4
/*      */     //   633: bipush 46
/*      */     //   635: invokevirtual 527	java/lang/String:indexOf	(I)I
/*      */     //   638: invokevirtual 531	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   641: astore 4
/*      */     //   643: aload_3
/*      */     //   644: aload 4
/*      */     //   646: invokevirtual 535	java/util/ArrayList:contains	(Ljava/lang/Object;)Z
/*      */     //   649: ifeq +6 -> 655
/*      */     //   652: goto +10 -> 662
/*      */     //   655: aload_3
/*      */     //   656: aload 4
/*      */     //   658: invokevirtual 233	java/util/ArrayList:add	(Ljava/lang/Object;)Z
/*      */     //   661: pop
/*      */     //   662: aload_2
/*      */     //   663: invokeinterface 424 1 0
/*      */     //   668: ifne -54 -> 614
/*      */     //   671: new 538	es/mityc/javasign/pkstore/pkcs11/ConfigMultiPKCS11
/*      */     //   674: dup
/*      */     //   675: invokespecial 540	es/mityc/javasign/pkstore/pkcs11/ConfigMultiPKCS11:<init>	()V
/*      */     //   678: astore 4
/*      */     //   680: iconst_0
/*      */     //   681: istore 5
/*      */     //   683: goto +278 -> 961
/*      */     //   686: aload_0
/*      */     //   687: getfield 142	es/mityc/javasign/pkstore/mitycstore/MITyCStore:prop	Ljava/util/Properties;
/*      */     //   690: new 83	java/lang/StringBuilder
/*      */     //   693: dup
/*      */     //   694: aload_3
/*      */     //   695: iload 5
/*      */     //   697: invokevirtual 541	java/util/ArrayList:get	(I)Ljava/lang/Object;
/*      */     //   700: checkcast 284	java/lang/String
/*      */     //   703: invokestatic 544	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   706: invokespecial 87	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   709: ldc_w 548
/*      */     //   712: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   715: invokevirtual 102	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   718: invokevirtual 467	java/util/Properties:getProperty	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   721: astore 6
/*      */     //   723: aload 6
/*      */     //   725: ifnull +181 -> 906
/*      */     //   728: new 91	java/io/File
/*      */     //   731: dup
/*      */     //   732: aload 6
/*      */     //   734: invokevirtual 472	java/lang/String:trim	()Ljava/lang/String;
/*      */     //   737: invokespecial 486	java/io/File:<init>	(Ljava/lang/String;)V
/*      */     //   740: ifnull +166 -> 906
/*      */     //   743: new 91	java/io/File
/*      */     //   746: dup
/*      */     //   747: aload 6
/*      */     //   749: invokevirtual 472	java/lang/String:trim	()Ljava/lang/String;
/*      */     //   752: invokespecial 486	java/io/File:<init>	(Ljava/lang/String;)V
/*      */     //   755: invokevirtual 487	java/io/File:exists	()Z
/*      */     //   758: ifeq +148 -> 906
/*      */     //   761: aload 6
/*      */     //   763: invokevirtual 472	java/lang/String:trim	()Ljava/lang/String;
/*      */     //   766: astore 6
/*      */     //   768: aload 4
/*      */     //   770: aload_0
/*      */     //   771: getfield 142	es/mityc/javasign/pkstore/mitycstore/MITyCStore:prop	Ljava/util/Properties;
/*      */     //   774: new 83	java/lang/StringBuilder
/*      */     //   777: dup
/*      */     //   778: aload_3
/*      */     //   779: iload 5
/*      */     //   781: invokevirtual 541	java/util/ArrayList:get	(I)Ljava/lang/Object;
/*      */     //   784: checkcast 284	java/lang/String
/*      */     //   787: invokestatic 544	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   790: invokespecial 87	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   793: ldc_w 550
/*      */     //   796: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   799: invokevirtual 102	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   802: invokevirtual 467	java/util/Properties:getProperty	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   805: invokevirtual 472	java/lang/String:trim	()Ljava/lang/String;
/*      */     //   808: aload 6
/*      */     //   810: invokevirtual 552	es/mityc/javasign/pkstore/pkcs11/ConfigMultiPKCS11:addSunProvider	(Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   813: goto +42 -> 855
/*      */     //   816: astore 7
/*      */     //   818: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   821: aload 7
/*      */     //   823: invokevirtual 556	java/security/NoSuchProviderException:getMessage	()Ljava/lang/String;
/*      */     //   826: invokeinterface 105 2 0
/*      */     //   831: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   834: invokeinterface 205 1 0
/*      */     //   839: ifeq +16 -> 855
/*      */     //   842: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   845: ldc_w 559
/*      */     //   848: aload 7
/*      */     //   850: invokeinterface 512 3 0
/*      */     //   855: aload_0
/*      */     //   856: getfield 161	es/mityc/javasign/pkstore/mitycstore/MITyCStore:drvrList	Ljava/util/HashMap;
/*      */     //   859: aload_0
/*      */     //   860: getfield 142	es/mityc/javasign/pkstore/mitycstore/MITyCStore:prop	Ljava/util/Properties;
/*      */     //   863: new 83	java/lang/StringBuilder
/*      */     //   866: dup
/*      */     //   867: aload_3
/*      */     //   868: iload 5
/*      */     //   870: invokevirtual 541	java/util/ArrayList:get	(I)Ljava/lang/Object;
/*      */     //   873: checkcast 284	java/lang/String
/*      */     //   876: invokestatic 544	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   879: invokespecial 87	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   882: ldc_w 550
/*      */     //   885: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   888: invokevirtual 102	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   891: invokevirtual 467	java/util/Properties:getProperty	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   894: invokevirtual 472	java/lang/String:trim	()Ljava/lang/String;
/*      */     //   897: aload 6
/*      */     //   899: invokevirtual 315	java/util/HashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   902: pop
/*      */     //   903: goto +55 -> 958
/*      */     //   906: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   909: getstatic 64	es/mityc/javasign/pkstore/mitycstore/MITyCStore:I18N	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   912: ldc_w 561
/*      */     //   915: iconst_1
/*      */     //   916: anewarray 3	java/lang/Object
/*      */     //   919: dup
/*      */     //   920: iconst_0
/*      */     //   921: aload 6
/*      */     //   923: aastore
/*      */     //   924: invokeinterface 563 3 0
/*      */     //   929: invokeinterface 105 2 0
/*      */     //   934: goto +24 -> 958
/*      */     //   937: astore 6
/*      */     //   939: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   942: getstatic 64	es/mityc/javasign/pkstore/mitycstore/MITyCStore:I18N	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   945: ldc_w 566
/*      */     //   948: invokeinterface 175 2 0
/*      */     //   953: invokeinterface 105 2 0
/*      */     //   958: iinc 5 1
/*      */     //   961: iload 5
/*      */     //   963: aload_3
/*      */     //   964: invokevirtual 568	java/util/ArrayList:size	()I
/*      */     //   967: if_icmplt -281 -> 686
/*      */     //   970: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   973: invokeinterface 205 1 0
/*      */     //   978: ifeq +14 -> 992
/*      */     //   981: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   984: ldc_w 569
/*      */     //   987: invokeinterface 211 2 0
/*      */     //   992: aload_0
/*      */     //   993: new 356	es/mityc/javasign/pkstore/pkcs11/MultiPKCS11Store
/*      */     //   996: dup
/*      */     //   997: aload 4
/*      */     //   999: aload_0
/*      */     //   1000: getfield 154	es/mityc/javasign/pkstore/mitycstore/MITyCStore:smartCrdPassKs	Les/mityc/javasign/pkstore/IPassStoreKS;
/*      */     //   1003: invokespecial 571	es/mityc/javasign/pkstore/pkcs11/MultiPKCS11Store:<init>	(Les/mityc/javasign/pkstore/pkcs11/ConfigMultiPKCS11;Les/mityc/javasign/pkstore/IPassStoreKS;)V
/*      */     //   1006: putfield 163	es/mityc/javasign/pkstore/mitycstore/MITyCStore:pkcs11s	Les/mityc/javasign/pkstore/pkcs11/MultiPKCS11Store;
/*      */     //   1009: return
/*      */     // Line number table:
/*      */     //   Java source line #505	-> byte code offset #0
/*      */     //   Java source line #507	-> byte code offset #2
/*      */     //   Java source line #508	-> byte code offset #12
/*      */     //   Java source line #510	-> byte code offset #16
/*      */     //   Java source line #513	-> byte code offset #36
/*      */     //   Java source line #514	-> byte code offset #43
/*      */     //   Java source line #515	-> byte code offset #54
/*      */     //   Java source line #517	-> byte code offset #65
/*      */     //   Java source line #521	-> byte code offset #66
/*      */     //   Java source line #524	-> byte code offset #70
/*      */     //   Java source line #525	-> byte code offset #83
/*      */     //   Java source line #527	-> byte code offset #89
/*      */     //   Java source line #529	-> byte code offset #108
/*      */     //   Java source line #530	-> byte code offset #117
/*      */     //   Java source line #531	-> byte code offset #128
/*      */     //   Java source line #532	-> byte code offset #139
/*      */     //   Java source line #536	-> byte code offset #166
/*      */     //   Java source line #538	-> byte code offset #206
/*      */     //   Java source line #539	-> byte code offset #217
/*      */     //   Java source line #540	-> byte code offset #228
/*      */     //   Java source line #541	-> byte code offset #232
/*      */     //   Java source line #572	-> byte code offset #236
/*      */     //   Java source line #574	-> byte code offset #240
/*      */     //   Java source line #575	-> byte code offset #244
/*      */     //   Java source line #542	-> byte code offset #252
/*      */     //   Java source line #543	-> byte code offset #253
/*      */     //   Java source line #572	-> byte code offset #257
/*      */     //   Java source line #574	-> byte code offset #261
/*      */     //   Java source line #575	-> byte code offset #265
/*      */     //   Java source line #544	-> byte code offset #273
/*      */     //   Java source line #545	-> byte code offset #274
/*      */     //   Java source line #546	-> byte code offset #285
/*      */     //   Java source line #549	-> byte code offset #296
/*      */     //   Java source line #550	-> byte code offset #298
/*      */     //   Java source line #551	-> byte code offset #306
/*      */     //   Java source line #552	-> byte code offset #319
/*      */     //   Java source line #553	-> byte code offset #323
/*      */     //   Java source line #554	-> byte code offset #331
/*      */     //   Java source line #550	-> byte code offset #342
/*      */     //   Java source line #558	-> byte code offset #352
/*      */     //   Java source line #559	-> byte code offset #363
/*      */     //   Java source line #560	-> byte code offset #387
/*      */     //   Java source line #561	-> byte code offset #391
/*      */     //   Java source line #562	-> byte code offset #398
/*      */     //   Java source line #563	-> byte code offset #399
/*      */     //   Java source line #564	-> byte code offset #406
/*      */     //   Java source line #565	-> byte code offset #407
/*      */     //   Java source line #566	-> byte code offset #418
/*      */     //   Java source line #569	-> byte code offset #438
/*      */     //   Java source line #572	-> byte code offset #457
/*      */     //   Java source line #574	-> byte code offset #461
/*      */     //   Java source line #575	-> byte code offset #465
/*      */     //   Java source line #571	-> byte code offset #473
/*      */     //   Java source line #572	-> byte code offset #475
/*      */     //   Java source line #574	-> byte code offset #479
/*      */     //   Java source line #575	-> byte code offset #483
/*      */     //   Java source line #577	-> byte code offset #488
/*      */     //   Java source line #572	-> byte code offset #491
/*      */     //   Java source line #574	-> byte code offset #495
/*      */     //   Java source line #575	-> byte code offset #499
/*      */     //   Java source line #578	-> byte code offset #504
/*      */     //   Java source line #580	-> byte code offset #514
/*      */     //   Java source line #581	-> byte code offset #522
/*      */     //   Java source line #582	-> byte code offset #527
/*      */     //   Java source line #583	-> byte code offset #531
/*      */     //   Java source line #584	-> byte code offset #538
/*      */     //   Java source line #585	-> byte code offset #539
/*      */     //   Java source line #586	-> byte code offset #546
/*      */     //   Java source line #587	-> byte code offset #547
/*      */     //   Java source line #589	-> byte code offset #551
/*      */     //   Java source line #591	-> byte code offset #554
/*      */     //   Java source line #594	-> byte code offset #573
/*      */     //   Java source line #595	-> byte code offset #584
/*      */     //   Java source line #601	-> byte code offset #595
/*      */     //   Java source line #602	-> byte code offset #603
/*      */     //   Java source line #603	-> byte code offset #611
/*      */     //   Java source line #604	-> byte code offset #614
/*      */     //   Java source line #605	-> byte code offset #628
/*      */     //   Java source line #606	-> byte code offset #643
/*      */     //   Java source line #607	-> byte code offset #652
/*      */     //   Java source line #609	-> byte code offset #655
/*      */     //   Java source line #603	-> byte code offset #662
/*      */     //   Java source line #613	-> byte code offset #671
/*      */     //   Java source line #614	-> byte code offset #680
/*      */     //   Java source line #617	-> byte code offset #686
/*      */     //   Java source line #618	-> byte code offset #723
/*      */     //   Java source line #619	-> byte code offset #761
/*      */     //   Java source line #621	-> byte code offset #768
/*      */     //   Java source line #622	-> byte code offset #813
/*      */     //   Java source line #623	-> byte code offset #818
/*      */     //   Java source line #624	-> byte code offset #831
/*      */     //   Java source line #625	-> byte code offset #842
/*      */     //   Java source line #628	-> byte code offset #855
/*      */     //   Java source line #629	-> byte code offset #903
/*      */     //   Java source line #631	-> byte code offset #906
/*      */     //   Java source line #633	-> byte code offset #934
/*      */     //   Java source line #635	-> byte code offset #939
/*      */     //   Java source line #614	-> byte code offset #958
/*      */     //   Java source line #638	-> byte code offset #970
/*      */     //   Java source line #639	-> byte code offset #981
/*      */     //   Java source line #643	-> byte code offset #992
/*      */     //   Java source line #644	-> byte code offset #1009
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	1010	0	this	MITyCStore
/*      */     //   1	495	1	fis	FileInputStream
/*      */     //   15	17	2	e2	KeyStoreException
/*      */     //   231	2	2	e	NoSuchAlgorithmException
/*      */     //   252	2	2	e	CertificateException
/*      */     //   273	127	2	e	IOException
/*      */     //   530	2	2	e1	NoSuchAlgorithmException
/*      */     //   538	2	2	e1	CertificateException
/*      */     //   546	2	2	e1	IOException
/*      */     //   602	61	2	keys	Enumeration<Object>
/*      */     //   297	72	3	handler	CachedPassHandler
/*      */     //   390	2	3	ex	NoSuchAlgorithmException
/*      */     //   398	2	3	ex	CertificateException
/*      */     //   406	27	3	ex	IOException
/*      */     //   610	354	3	prefijos	ArrayList<String>
/*      */     //   303	46	4	Ljava/lang/Object;	Object
/*      */     //   626	31	4	key	String
/*      */     //   678	320	4	config	ConfigMultiPKCS11
/*      */     //   473	16	5	localObject1	Object
/*      */     //   681	287	5	i	int
/*      */     //   247	1	6	localIOException1	IOException
/*      */     //   268	1	6	localIOException2	IOException
/*      */     //   468	1	6	localIOException3	IOException
/*      */     //   486	1	6	localIOException4	IOException
/*      */     //   502	1	6	localIOException5	IOException
/*      */     //   721	201	6	lib	String
/*      */     //   937	3	6	ex	MissingResourceException
/*      */     //   816	33	7	ex	NoSuchProviderException
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   2	12	15	java/security/KeyStoreException
/*      */     //   206	228	231	java/security/NoSuchAlgorithmException
/*      */     //   240	244	247	java/io/IOException
/*      */     //   206	228	252	java/security/cert/CertificateException
/*      */     //   261	265	268	java/io/IOException
/*      */     //   206	228	273	java/io/IOException
/*      */     //   306	345	348	finally
/*      */     //   348	351	348	finally
/*      */     //   296	387	390	java/security/NoSuchAlgorithmException
/*      */     //   296	387	398	java/security/cert/CertificateException
/*      */     //   296	387	406	java/io/IOException
/*      */     //   461	465	468	java/io/IOException
/*      */     //   206	236	473	finally
/*      */     //   252	257	473	finally
/*      */     //   273	457	473	finally
/*      */     //   479	483	486	java/io/IOException
/*      */     //   495	499	502	java/io/IOException
/*      */     //   514	527	530	java/security/NoSuchAlgorithmException
/*      */     //   514	527	538	java/security/cert/CertificateException
/*      */     //   514	527	546	java/io/IOException
/*      */     //   768	813	816	java/security/NoSuchProviderException
/*      */     //   686	934	937	java/util/MissingResourceException
/*      */   }
/*      */   
/*      */   public void addTrustCert(X509Certificate cert)
/*      */     throws CertStoreException
/*      */   {
/*  653 */     if (cert == null)
/*      */     {
/*  655 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mityc.15"));
/*      */     }
/*      */     
/*  658 */     if (this.ks == null) {
/*  659 */       if (LOG.isDebugEnabled()) {
/*  660 */         LOG.debug("El almacén no está inicializado.");
/*      */       }
/*  662 */       return;
/*      */     }
/*      */     
/*  665 */     String newAlias = genNewAlias("SignCert");
/*      */     try {
/*  667 */       KeyStore.TrustedCertificateEntry ksEntry = new KeyStore.TrustedCertificateEntry(cert);
/*  668 */       this.ks.setEntry(newAlias, ksEntry, null);
/*      */     } catch (KeyStoreException e) {
/*  670 */       e.printStackTrace();
/*  671 */       return;
/*      */     }
/*      */     
/*  674 */     saveStore();
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public void importSignCert(PrivateKey pk, X509Certificate cert, char[] password)
/*      */     throws CertStoreException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_1
/*      */     //   1: ifnull +11 -> 12
/*      */     //   4: aload_2
/*      */     //   5: ifnull +7 -> 12
/*      */     //   8: aload_3
/*      */     //   9: ifnonnull +22 -> 31
/*      */     //   12: new 75	es/mityc/javasign/pkstore/CertStoreException
/*      */     //   15: dup
/*      */     //   16: getstatic 64	es/mityc/javasign/pkstore/mitycstore/MITyCStore:I18N	Les/mityc/javasign/i18n/II18nManager;
/*      */     //   19: ldc_w 589
/*      */     //   22: invokeinterface 175 2 0
/*      */     //   27: invokespecial 342	es/mityc/javasign/pkstore/CertStoreException:<init>	(Ljava/lang/String;)V
/*      */     //   30: athrow
/*      */     //   31: aload_0
/*      */     //   32: getfield 156	es/mityc/javasign/pkstore/mitycstore/MITyCStore:ks	Ljava/security/KeyStore;
/*      */     //   35: ifnonnull +25 -> 60
/*      */     //   38: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   41: invokeinterface 205 1 0
/*      */     //   46: ifeq +13 -> 59
/*      */     //   49: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   52: ldc -42
/*      */     //   54: invokeinterface 211 2 0
/*      */     //   59: return
/*      */     //   60: new 609	es/mityc/javasign/pkstore/mitycstore/PKContextDialog
/*      */     //   63: dup
/*      */     //   64: aconst_null
/*      */     //   65: aload_0
/*      */     //   66: invokespecial 611	es/mityc/javasign/pkstore/mitycstore/PKContextDialog:<init>	(Ljava/awt/Frame;Les/mityc/javasign/pkstore/mitycstore/MITyCStore;)V
/*      */     //   69: astore 4
/*      */     //   71: aload 4
/*      */     //   73: iconst_1
/*      */     //   74: invokevirtual 614	es/mityc/javasign/pkstore/mitycstore/PKContextDialog:setVisible	(Z)V
/*      */     //   77: aload_0
/*      */     //   78: new 83	java/lang/StringBuilder
/*      */     //   81: dup
/*      */     //   82: aload 4
/*      */     //   84: invokevirtual 618	es/mityc/javasign/pkstore/mitycstore/PKContextDialog:getContext	()Ljava/lang/String;
/*      */     //   87: invokestatic 544	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   90: invokespecial 87	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   93: ldc_w 591
/*      */     //   96: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   99: invokevirtual 102	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   102: invokespecial 593	es/mityc/javasign/pkstore/mitycstore/MITyCStore:genNewAlias	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   105: astore 5
/*      */     //   107: new 291	java/security/KeyStore$PrivateKeyEntry
/*      */     //   110: dup
/*      */     //   111: aload_1
/*      */     //   112: iconst_1
/*      */     //   113: anewarray 621	java/security/cert/Certificate
/*      */     //   116: dup
/*      */     //   117: iconst_0
/*      */     //   118: aload_2
/*      */     //   119: aastore
/*      */     //   120: invokespecial 623	java/security/KeyStore$PrivateKeyEntry:<init>	(Ljava/security/PrivateKey;[Ljava/security/cert/Certificate;)V
/*      */     //   123: astore 6
/*      */     //   125: new 319	java/security/KeyStore$PasswordProtection
/*      */     //   128: dup
/*      */     //   129: aload 4
/*      */     //   131: invokevirtual 626	es/mityc/javasign/pkstore/mitycstore/PKContextDialog:getPass	()[C
/*      */     //   134: invokespecial 325	java/security/KeyStore$PasswordProtection:<init>	([C)V
/*      */     //   137: astore 7
/*      */     //   139: aload_0
/*      */     //   140: getfield 156	es/mityc/javasign/pkstore/mitycstore/MITyCStore:ks	Ljava/security/KeyStore;
/*      */     //   143: aload 5
/*      */     //   145: aload 6
/*      */     //   147: aload 7
/*      */     //   149: invokevirtual 599	java/security/KeyStore:setEntry	(Ljava/lang/String;Ljava/security/KeyStore$Entry;Ljava/security/KeyStore$ProtectionParameter;)V
/*      */     //   152: goto +28 -> 180
/*      */     //   155: astore 6
/*      */     //   157: aload 6
/*      */     //   159: invokevirtual 603	java/security/KeyStoreException:printStackTrace	()V
/*      */     //   162: aload 4
/*      */     //   164: invokevirtual 629	es/mityc/javasign/pkstore/mitycstore/PKContextDialog:dispose	()V
/*      */     //   167: goto +18 -> 185
/*      */     //   170: astore 8
/*      */     //   172: aload 4
/*      */     //   174: invokevirtual 629	es/mityc/javasign/pkstore/mitycstore/PKContextDialog:dispose	()V
/*      */     //   177: aload 8
/*      */     //   179: athrow
/*      */     //   180: aload 4
/*      */     //   182: invokevirtual 629	es/mityc/javasign/pkstore/mitycstore/PKContextDialog:dispose	()V
/*      */     //   185: aload_0
/*      */     //   186: invokespecial 517	es/mityc/javasign/pkstore/mitycstore/MITyCStore:saveStore	()Z
/*      */     //   189: pop
/*      */     //   190: return
/*      */     // Line number table:
/*      */     //   Java source line #686	-> byte code offset #0
/*      */     //   Java source line #688	-> byte code offset #12
/*      */     //   Java source line #691	-> byte code offset #31
/*      */     //   Java source line #692	-> byte code offset #38
/*      */     //   Java source line #693	-> byte code offset #49
/*      */     //   Java source line #695	-> byte code offset #59
/*      */     //   Java source line #699	-> byte code offset #60
/*      */     //   Java source line #700	-> byte code offset #71
/*      */     //   Java source line #702	-> byte code offset #77
/*      */     //   Java source line #704	-> byte code offset #107
/*      */     //   Java source line #705	-> byte code offset #125
/*      */     //   Java source line #706	-> byte code offset #139
/*      */     //   Java source line #707	-> byte code offset #152
/*      */     //   Java source line #708	-> byte code offset #157
/*      */     //   Java source line #710	-> byte code offset #162
/*      */     //   Java source line #709	-> byte code offset #170
/*      */     //   Java source line #710	-> byte code offset #172
/*      */     //   Java source line #711	-> byte code offset #177
/*      */     //   Java source line #710	-> byte code offset #180
/*      */     //   Java source line #713	-> byte code offset #185
/*      */     //   Java source line #714	-> byte code offset #190
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	191	0	this	MITyCStore
/*      */     //   0	191	1	pk	PrivateKey
/*      */     //   0	191	2	cert	X509Certificate
/*      */     //   0	191	3	password	char[]
/*      */     //   69	112	4	contextDialog	PKContextDialog
/*      */     //   105	39	5	newAlias	String
/*      */     //   123	23	6	ksEntry	KeyStore.PrivateKeyEntry
/*      */     //   155	3	6	e	KeyStoreException
/*      */     //   137	11	7	pp	KeyStore.PasswordProtection
/*      */     //   170	8	8	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   107	152	155	java/security/KeyStoreException
/*      */     //   107	162	170	finally
/*      */   }
/*      */   
/*      */   public void removeSignCert(X509Certificate cert)
/*      */     throws CertStoreException
/*      */   {
/*  723 */     if (cert == null)
/*      */     {
/*  725 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mityc.15"));
/*      */     }
/*      */     
/*  728 */     if (this.ks == null) {
/*  729 */       if (LOG.isDebugEnabled()) {
/*  730 */         LOG.debug("El almacén no está inicializado.");
/*      */       }
/*  732 */       return;
/*      */     }
/*      */     
/*  735 */     String alias = null;
/*      */     try {
/*  737 */       alias = this.ks.getCertificateAlias(cert);
/*  738 */       if (this.ks.entryInstanceOf(alias, KeyStore.PrivateKeyEntry.class))
/*      */       {
/*  740 */         KeyStore.PasswordProtection kpp = null;
/*  741 */         this.aliasFormat = new AliasFormat(alias);
/*  742 */         if (this.aliasFormat.isProtected())
/*      */         {
/*  744 */           kpp = new KeyStore.PasswordProtection(this.passKs.getPassword(cert, null));
/*      */         }
/*      */         else {
/*  747 */           kpp = new KeyStore.PasswordProtection(new DeleteWarnHandler().getPassword(cert, alias));
/*      */         }
/*      */         
/*  750 */         if (kpp.getPassword() == null)
/*      */         {
/*  752 */           LOG.info(I18N.getLocalMessage("i18n.mityc.cert.mityc.81"));
/*  753 */           throw new CertStoreException("Cancelado por el usuario.");
/*      */         }
/*      */         
/*  756 */         this.ks.getEntry(alias, kpp);
/*      */         
/*      */ 
/*  759 */         this.ks.deleteEntry(alias);
/*  760 */         saveStore();
/*  761 */       } else if (LOG.isDebugEnabled()) {
/*  762 */         LOG.debug("No es un certificado de firma asociado a una clave privada.");
/*      */       }
/*      */     } catch (KeyStoreException e) {
/*  765 */       e.printStackTrace();
/*  766 */       return;
/*      */     }
/*      */     catch (UnrecoverableEntryException e) {
/*  769 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mityc.82"));
/*      */     }
/*      */     catch (NoSuchAlgorithmException e) {
/*  772 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mityc.82"));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeTrustCert(X509Certificate cert)
/*      */     throws CertStoreException
/*      */   {
/*  784 */     if (cert == null)
/*      */     {
/*  786 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mityc.15"));
/*      */     }
/*      */     
/*  789 */     if (this.ks == null) {
/*  790 */       if (LOG.isDebugEnabled()) {
/*  791 */         LOG.debug("El almacén no está inicializado.");
/*      */       }
/*  793 */       return;
/*      */     }
/*      */     
/*  796 */     String alias = null;
/*      */     try {
/*  798 */       alias = this.ks.getCertificateAlias(cert);
/*  799 */       if (this.ks.entryInstanceOf(alias, KeyStore.TrustedCertificateEntry.class)) {
/*  800 */         this.ks.deleteEntry(alias);
/*  801 */       } else if (LOG.isDebugEnabled()) {
/*  802 */         LOG.debug("No es un certificado de autenticación.");
/*      */       }
/*      */     } catch (KeyStoreException e) {
/*  805 */       e.printStackTrace();
/*  806 */       return;
/*      */     }
/*      */     
/*  809 */     saveStore();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateSignCert(X509Certificate newCert)
/*      */     throws CertStoreException
/*      */   {
/*  819 */     if (newCert == null)
/*      */     {
/*  821 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mityc.15"));
/*      */     }
/*      */     
/*  824 */     if (this.ks == null) {
/*  825 */       if (LOG.isDebugEnabled()) {
/*  826 */         LOG.debug("El almacén no está inicializado.");
/*      */       }
/*  828 */       return;
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  833 */       PublicKey pubKey = newCert.getPublicKey();
/*  834 */       String foundAlias = null;
/*  835 */       Iterator<X509Certificate> signCerts = getSignCertificates().iterator();
/*  836 */       X509Certificate signCert = null;
/*  837 */       while (signCerts.hasNext()) {
/*  838 */         signCert = (X509Certificate)signCerts.next();
/*  839 */         if (pubKey.equals(signCert.getPublicKey())) {
/*  840 */           foundAlias = this.ks.getCertificateAlias(signCert);
/*  841 */           break;
/*      */         }
/*      */       }
/*      */       
/*  845 */       if (foundAlias != null)
/*      */       {
/*  847 */         if ((isDeletable(newCert)) && (this.ks.entryInstanceOf(foundAlias, KeyStore.PrivateKeyEntry.class))) {
/*  848 */           this.ks.setCertificateEntry(foundAlias, newCert);
/*      */         }
/*      */         else {
/*  851 */           throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mityc.93"));
/*      */         }
/*      */       }
/*      */       else {
/*  855 */         throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mityc.16"));
/*      */       }
/*      */       
/*  858 */       saveStore();
/*      */     } catch (KeyStoreException e) {
/*  860 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isDeletable(X509Certificate cert)
/*      */   {
/*  870 */     boolean borrable = true;
/*      */     try {
/*  872 */       borrable = this.ks.getCertificateAlias(cert) != null;
/*      */     } catch (KeyStoreException ex) {
/*  874 */       borrable = false;
/*      */     }
/*      */     
/*  877 */     return borrable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean saveStore()
/*      */     throws CertStoreException
/*      */   {
/*  887 */     FileOutputStream fos = null;
/*      */     
/*  889 */     if (this.ks == null) {
/*  890 */       if (LOG.isDebugEnabled()) {
/*  891 */         LOG.debug("El almacén no está inicializado.");
/*      */       }
/*  893 */       return false;
/*      */     }
/*      */     
/*  896 */     CachedPassHandler handler = null;
/*  897 */     synchronized (this.passKsCachedList) {
/*  898 */       handler = (CachedPassHandler)this.passKsCachedList.get("MITyCKeyStoreAlias");
/*  899 */       if (handler == null) {
/*  900 */         handler = new CachedPassHandler();
/*  901 */         this.passKsCachedList.put("MITyCKeyStoreAlias", handler);
/*      */       }
/*      */     }
/*      */     try {
/*  905 */       fos = new FileOutputStream(ksURL);
/*  906 */       this.ks.store(fos, handler.getPassword(null, null));
/*      */     } catch (FileNotFoundException e) {
/*  908 */       e.printStackTrace();
/*      */     } catch (NoSuchAlgorithmException e) {
/*  910 */       e.printStackTrace();
/*      */     } catch (CertificateException e) {
/*  912 */       e.printStackTrace();
/*      */     } catch (IOException e) {
/*  914 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mityc.17"), e);
/*      */     } catch (KeyStoreException e) {
/*  916 */       e.printStackTrace();
/*      */     } finally {
/*  918 */       if (fos != null) {
/*      */         try {
/*  920 */           fos.close();
/*      */         } catch (IOException e) {
/*  922 */           throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mityc.17"), e);
/*      */         }
/*      */       }
/*      */     }
/*  918 */     if (fos != null) {
/*      */       try {
/*  920 */         fos.close();
/*      */       } catch (IOException e) {
/*  922 */         throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mityc.17"), e);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  927 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void saveConf()
/*      */     throws CertStoreException
/*      */   {
/*  935 */     if (confFile == null)
/*      */     {
/*  937 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mityc.96"));
/*      */     }
/*  939 */     this.prop = new Properties();
/*      */     
/*      */ 
/*  942 */     if (ksURL == null)
/*      */     {
/*  944 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mityc.11"));
/*      */     }
/*  946 */     this.prop.setProperty("KeyStoreName", ksURL);
/*  947 */     if (LOG.isTraceEnabled()) {
/*  948 */       LOG.trace("El almacén se buscará en: " + ksURL);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  954 */     Iterator<Map.Entry<String, String>> contents = this.drvrList.entrySet().iterator();
/*  955 */     Map.Entry<String, String> content = null;
/*  956 */     while (contents.hasNext()) {
/*  957 */       content = (Map.Entry)contents.next();
/*      */       
/*  959 */       this.prop.put(((String)content.getKey()).toLowerCase() + ".name", 
/*  960 */         content.getKey());
/*      */       
/*  962 */       this.prop.put(((String)content.getKey()).toLowerCase() + ".library", 
/*  963 */         content.getValue());
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  968 */       FileOutputStream fos = new FileOutputStream(confFile);
/*  969 */       this.prop.store(fos, null);
/*      */     }
/*      */     catch (Exception e) {
/*  972 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mityc.96"), e);
/*      */     }
/*      */     FileOutputStream fos;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public void setNewPass(char[] oldPass, char[] newPass)
/*      */     throws CertStoreException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 156	es/mityc/javasign/pkstore/mitycstore/MITyCStore:ks	Ljava/security/KeyStore;
/*      */     //   4: ifnonnull +25 -> 29
/*      */     //   7: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   10: invokeinterface 205 1 0
/*      */     //   15: ifeq +13 -> 28
/*      */     //   18: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   21: ldc -42
/*      */     //   23: invokeinterface 211 2 0
/*      */     //   28: return
/*      */     //   29: aconst_null
/*      */     //   30: astore_3
/*      */     //   31: aconst_null
/*      */     //   32: astore 4
/*      */     //   34: new 77	java/io/FileInputStream
/*      */     //   37: dup
/*      */     //   38: getstatic 68	es/mityc/javasign/pkstore/mitycstore/MITyCStore:ksURL	Ljava/lang/String;
/*      */     //   41: invokespecial 494	java/io/FileInputStream:<init>	(Ljava/lang/String;)V
/*      */     //   44: astore_3
/*      */     //   45: aload_0
/*      */     //   46: getfield 156	es/mityc/javasign/pkstore/mitycstore/MITyCStore:ks	Ljava/security/KeyStore;
/*      */     //   49: aload_3
/*      */     //   50: aload_1
/*      */     //   51: invokevirtual 495	java/security/KeyStore:load	(Ljava/io/InputStream;[C)V
/*      */     //   54: new 701	java/io/FileOutputStream
/*      */     //   57: dup
/*      */     //   58: getstatic 68	es/mityc/javasign/pkstore/mitycstore/MITyCStore:ksURL	Ljava/lang/String;
/*      */     //   61: invokespecial 703	java/io/FileOutputStream:<init>	(Ljava/lang/String;)V
/*      */     //   64: astore 4
/*      */     //   66: aload_0
/*      */     //   67: getfield 156	es/mityc/javasign/pkstore/mitycstore/MITyCStore:ks	Ljava/security/KeyStore;
/*      */     //   70: aload 4
/*      */     //   72: aload_2
/*      */     //   73: invokevirtual 704	java/security/KeyStore:store	(Ljava/io/OutputStream;[C)V
/*      */     //   76: goto +220 -> 296
/*      */     //   79: astore 5
/*      */     //   81: aload 5
/*      */     //   83: invokevirtual 498	java/security/NoSuchAlgorithmException:printStackTrace	()V
/*      */     //   86: aload_3
/*      */     //   87: ifnull +12 -> 99
/*      */     //   90: aload_3
/*      */     //   91: invokevirtual 501	java/io/FileInputStream:close	()V
/*      */     //   94: goto +5 -> 99
/*      */     //   97: astore 7
/*      */     //   99: aload 4
/*      */     //   101: ifnull +223 -> 324
/*      */     //   104: aload 4
/*      */     //   106: invokevirtual 709	java/io/FileOutputStream:close	()V
/*      */     //   109: goto +215 -> 324
/*      */     //   112: astore 7
/*      */     //   114: goto +210 -> 324
/*      */     //   117: astore 5
/*      */     //   119: aload 5
/*      */     //   121: invokevirtual 504	java/security/cert/CertificateException:printStackTrace	()V
/*      */     //   124: aload_3
/*      */     //   125: ifnull +12 -> 137
/*      */     //   128: aload_3
/*      */     //   129: invokevirtual 501	java/io/FileInputStream:close	()V
/*      */     //   132: goto +5 -> 137
/*      */     //   135: astore 7
/*      */     //   137: aload 4
/*      */     //   139: ifnull +185 -> 324
/*      */     //   142: aload 4
/*      */     //   144: invokevirtual 709	java/io/FileOutputStream:close	()V
/*      */     //   147: goto +177 -> 324
/*      */     //   150: astore 7
/*      */     //   152: goto +172 -> 324
/*      */     //   155: astore 5
/*      */     //   157: aload 5
/*      */     //   159: invokevirtual 708	java/io/FileNotFoundException:printStackTrace	()V
/*      */     //   162: aload_3
/*      */     //   163: ifnull +12 -> 175
/*      */     //   166: aload_3
/*      */     //   167: invokevirtual 501	java/io/FileInputStream:close	()V
/*      */     //   170: goto +5 -> 175
/*      */     //   173: astore 7
/*      */     //   175: aload 4
/*      */     //   177: ifnull +147 -> 324
/*      */     //   180: aload 4
/*      */     //   182: invokevirtual 709	java/io/FileOutputStream:close	()V
/*      */     //   185: goto +139 -> 324
/*      */     //   188: astore 7
/*      */     //   190: goto +134 -> 324
/*      */     //   193: astore 5
/*      */     //   195: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   198: invokeinterface 205 1 0
/*      */     //   203: ifeq +14 -> 217
/*      */     //   206: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   209: ldc_w 756
/*      */     //   212: invokeinterface 211 2 0
/*      */     //   217: new 75	es/mityc/javasign/pkstore/CertStoreException
/*      */     //   220: dup
/*      */     //   221: ldc_w 758
/*      */     //   224: invokespecial 342	es/mityc/javasign/pkstore/CertStoreException:<init>	(Ljava/lang/String;)V
/*      */     //   227: athrow
/*      */     //   228: astore 5
/*      */     //   230: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   233: invokeinterface 205 1 0
/*      */     //   238: ifeq +14 -> 252
/*      */     //   241: getstatic 54	es/mityc/javasign/pkstore/mitycstore/MITyCStore:LOG	Lorg/apache/commons/logging/Log;
/*      */     //   244: ldc_w 756
/*      */     //   247: invokeinterface 211 2 0
/*      */     //   252: new 75	es/mityc/javasign/pkstore/CertStoreException
/*      */     //   255: dup
/*      */     //   256: ldc_w 758
/*      */     //   259: invokespecial 342	es/mityc/javasign/pkstore/CertStoreException:<init>	(Ljava/lang/String;)V
/*      */     //   262: athrow
/*      */     //   263: astore 6
/*      */     //   265: aload_3
/*      */     //   266: ifnull +12 -> 278
/*      */     //   269: aload_3
/*      */     //   270: invokevirtual 501	java/io/FileInputStream:close	()V
/*      */     //   273: goto +5 -> 278
/*      */     //   276: astore 7
/*      */     //   278: aload 4
/*      */     //   280: ifnull +13 -> 293
/*      */     //   283: aload 4
/*      */     //   285: invokevirtual 709	java/io/FileOutputStream:close	()V
/*      */     //   288: goto +5 -> 293
/*      */     //   291: astore 7
/*      */     //   293: aload 6
/*      */     //   295: athrow
/*      */     //   296: aload_3
/*      */     //   297: ifnull +12 -> 309
/*      */     //   300: aload_3
/*      */     //   301: invokevirtual 501	java/io/FileInputStream:close	()V
/*      */     //   304: goto +5 -> 309
/*      */     //   307: astore 7
/*      */     //   309: aload 4
/*      */     //   311: ifnull +13 -> 324
/*      */     //   314: aload 4
/*      */     //   316: invokevirtual 709	java/io/FileOutputStream:close	()V
/*      */     //   319: goto +5 -> 324
/*      */     //   322: astore 7
/*      */     //   324: return
/*      */     // Line number table:
/*      */     //   Java source line #983	-> byte code offset #0
/*      */     //   Java source line #984	-> byte code offset #7
/*      */     //   Java source line #985	-> byte code offset #18
/*      */     //   Java source line #987	-> byte code offset #28
/*      */     //   Java source line #991	-> byte code offset #29
/*      */     //   Java source line #992	-> byte code offset #31
/*      */     //   Java source line #994	-> byte code offset #34
/*      */     //   Java source line #995	-> byte code offset #45
/*      */     //   Java source line #999	-> byte code offset #54
/*      */     //   Java source line #1000	-> byte code offset #66
/*      */     //   Java source line #1001	-> byte code offset #76
/*      */     //   Java source line #1002	-> byte code offset #81
/*      */     //   Java source line #1018	-> byte code offset #86
/*      */     //   Java source line #1020	-> byte code offset #90
/*      */     //   Java source line #1021	-> byte code offset #94
/*      */     //   Java source line #1023	-> byte code offset #99
/*      */     //   Java source line #1025	-> byte code offset #104
/*      */     //   Java source line #1026	-> byte code offset #109
/*      */     //   Java source line #1003	-> byte code offset #117
/*      */     //   Java source line #1004	-> byte code offset #119
/*      */     //   Java source line #1018	-> byte code offset #124
/*      */     //   Java source line #1020	-> byte code offset #128
/*      */     //   Java source line #1021	-> byte code offset #132
/*      */     //   Java source line #1023	-> byte code offset #137
/*      */     //   Java source line #1025	-> byte code offset #142
/*      */     //   Java source line #1026	-> byte code offset #147
/*      */     //   Java source line #1005	-> byte code offset #155
/*      */     //   Java source line #1006	-> byte code offset #157
/*      */     //   Java source line #1018	-> byte code offset #162
/*      */     //   Java source line #1020	-> byte code offset #166
/*      */     //   Java source line #1021	-> byte code offset #170
/*      */     //   Java source line #1023	-> byte code offset #175
/*      */     //   Java source line #1025	-> byte code offset #180
/*      */     //   Java source line #1026	-> byte code offset #185
/*      */     //   Java source line #1007	-> byte code offset #193
/*      */     //   Java source line #1008	-> byte code offset #195
/*      */     //   Java source line #1009	-> byte code offset #206
/*      */     //   Java source line #1011	-> byte code offset #217
/*      */     //   Java source line #1012	-> byte code offset #228
/*      */     //   Java source line #1013	-> byte code offset #230
/*      */     //   Java source line #1014	-> byte code offset #241
/*      */     //   Java source line #1016	-> byte code offset #252
/*      */     //   Java source line #1017	-> byte code offset #263
/*      */     //   Java source line #1018	-> byte code offset #265
/*      */     //   Java source line #1020	-> byte code offset #269
/*      */     //   Java source line #1021	-> byte code offset #273
/*      */     //   Java source line #1023	-> byte code offset #278
/*      */     //   Java source line #1025	-> byte code offset #283
/*      */     //   Java source line #1026	-> byte code offset #288
/*      */     //   Java source line #1028	-> byte code offset #293
/*      */     //   Java source line #1018	-> byte code offset #296
/*      */     //   Java source line #1020	-> byte code offset #300
/*      */     //   Java source line #1021	-> byte code offset #304
/*      */     //   Java source line #1023	-> byte code offset #309
/*      */     //   Java source line #1025	-> byte code offset #314
/*      */     //   Java source line #1026	-> byte code offset #319
/*      */     //   Java source line #1029	-> byte code offset #324
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	325	0	this	MITyCStore
/*      */     //   0	325	1	oldPass	char[]
/*      */     //   0	325	2	newPass	char[]
/*      */     //   30	271	3	fis	FileInputStream
/*      */     //   32	283	4	fos	FileOutputStream
/*      */     //   79	3	5	e	NoSuchAlgorithmException
/*      */     //   117	3	5	e	CertificateException
/*      */     //   155	3	5	e	FileNotFoundException
/*      */     //   193	3	5	e	KeyStoreException
/*      */     //   228	3	5	e	IOException
/*      */     //   263	31	6	localObject	Object
/*      */     //   97	1	7	localIOException1	IOException
/*      */     //   112	1	7	localIOException2	IOException
/*      */     //   135	1	7	localIOException3	IOException
/*      */     //   150	1	7	localIOException4	IOException
/*      */     //   173	1	7	localIOException5	IOException
/*      */     //   188	1	7	localIOException6	IOException
/*      */     //   276	1	7	localIOException7	IOException
/*      */     //   291	1	7	localIOException8	IOException
/*      */     //   307	1	7	localIOException9	IOException
/*      */     //   322	1	7	localIOException10	IOException
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   34	76	79	java/security/NoSuchAlgorithmException
/*      */     //   90	94	97	java/io/IOException
/*      */     //   104	109	112	java/io/IOException
/*      */     //   34	76	117	java/security/cert/CertificateException
/*      */     //   128	132	135	java/io/IOException
/*      */     //   142	147	150	java/io/IOException
/*      */     //   34	76	155	java/io/FileNotFoundException
/*      */     //   166	170	173	java/io/IOException
/*      */     //   180	185	188	java/io/IOException
/*      */     //   34	76	193	java/security/KeyStoreException
/*      */     //   34	76	228	java/io/IOException
/*      */     //   34	86	263	finally
/*      */     //   117	124	263	finally
/*      */     //   155	162	263	finally
/*      */     //   193	263	263	finally
/*      */     //   269	273	276	java/io/IOException
/*      */     //   283	288	291	java/io/IOException
/*      */     //   300	304	307	java/io/IOException
/*      */     //   314	319	322	java/io/IOException
/*      */   }
/*      */   
/*      */   private String genNewAlias(String prefix)
/*      */   {
/* 1038 */     Random rnd = new Random();
/* 1039 */     String alias = prefix + rnd.nextInt(10000);
/*      */     try
/*      */     {
/* 1042 */       while (this.ks.containsAlias(alias)) {
/* 1043 */         alias = prefix + rnd.nextInt(10000);
/*      */       }
/*      */     } catch (KeyStoreException e) {
/* 1046 */       e.printStackTrace();
/*      */     }
/*      */     
/* 1049 */     return alias;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public JPanel getPreferencesPanel()
/*      */   {
/* 1057 */     return new PreferencesPanel(this, this.drvrList);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setNewMultiPkcs11(HashMap<String, String> newDrvrList)
/*      */     throws CertStoreException
/*      */   {
/* 1066 */     if (newDrvrList != null) {
/* 1067 */       this.drvrList = newDrvrList;
/*      */     }
/*      */     else {
/* 1070 */       throw new CertStoreException(I18N.getLocalMessage("i18n.mityc.cert.mityc.15"));
/*      */     }
/*      */     
/* 1073 */     ConfigMultiPKCS11 config = new ConfigMultiPKCS11();
/* 1074 */     Iterator<Map.Entry<String, String>> contents = newDrvrList.entrySet().iterator();
/* 1075 */     Map.Entry<String, String> content = null;
/* 1076 */     String lib = null;
/* 1077 */     while (contents.hasNext()) {
/* 1078 */       content = (Map.Entry)contents.next();
/* 1079 */       lib = (String)content.getValue();
/*      */       try
/*      */       {
/* 1082 */         if ((lib != null) && (new File(lib) != null) && (new File(lib).exists())) {
/*      */           try {
/* 1084 */             config.addSunProvider((String)content.getKey(), lib);
/*      */           } catch (NoSuchProviderException ex) {
/* 1086 */             LOG.error(ex.getMessage());
/* 1087 */             if (!LOG.isDebugEnabled()) continue; }
/* 1088 */           LOG.debug("", ex);
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 1093 */           LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mityc.92", new Object[] { lib }));
/*      */         }
/*      */       }
/*      */       catch (MissingResourceException ex) {
/* 1097 */         LOG.error(I18N.getLocalMessage("i18n.mityc.cert.mityc.14"));
/*      */       }
/*      */     }
/* 1100 */     if (LOG.isDebugEnabled()) {
/* 1101 */       LOG.debug("Cargando pasarelas PKCS11");
/*      */     }
/*      */     
/*      */ 
/* 1105 */     this.pkcs11s = new MultiPKCS11Store(config, this.smartCrdPassKs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private class PreferencesPanel
/*      */     extends JPanel
/*      */   {
/*      */     private static final int WIDTH = 350;
/*      */     
/*      */ 
/*      */     private static final int HEIGHT = 265;
/*      */     
/*      */ 
/* 1120 */     private HashMap<String, String> drivrList = null;
/*      */     
/*      */ 
/* 1123 */     private MITyCStore store = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public PreferencesPanel(HashMap<String, String> keyStore)
/*      */     {
/* 1132 */       this.store = keyStore;
/* 1133 */       this.drivrList = drvrList;
/* 1134 */       init();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private void init()
/*      */     {
/* 1142 */       setBorder(BorderFactory.createTitledBorder(MITyCStore.I18N.getLocalMessage("i18n.mityc.cert.mityc.90")));
/*      */       
/* 1144 */       this.tabs = new JTabbedPane();
/*      */       
/*      */ 
/* 1147 */       this.storePass = new JPanel();
/*      */       
/*      */ 
/* 1150 */       this.oldPassLabel = new JLabel(MITyCStore.I18N.getLocalMessage("i18n.mityc.cert.mityc.87"));
/* 1151 */       this.oldPassLabel.setHorizontalAlignment(4);
/* 1152 */       this.oldPassField = new JPasswordField();
/*      */       
/* 1154 */       this.newPassLabel = new JLabel(MITyCStore.I18N.getLocalMessage("i18n.mityc.cert.mityc.88"));
/* 1155 */       this.newPassLabel.setHorizontalAlignment(4);
/* 1156 */       this.newPassField = new JPasswordField();
/*      */       
/* 1158 */       this.noPassCheck = new JCheckBox(MITyCStore.I18N.getLocalMessage("i18n.mityc.cert.mityc.89"));
/* 1159 */       this.noPassCheck.addItemListener(new ItemListener() {
/*      */         public void itemStateChanged(ItemEvent e) {
/* 1161 */           MITyCStore.PreferencesPanel.this.noPassActionPerformed(e);
/*      */         }
/*      */         
/* 1164 */       });
/* 1165 */       this.aceptarButton = new JButton();
/*      */       
/* 1167 */       setLayout(new GridBagLayout());
/* 1168 */       this.storePass.setLayout(new GridBagLayout());
/*      */       
/*      */ 
/* 1171 */       GridBagConstraints oldPassLblConstraints = new GridBagConstraints();
/* 1172 */       oldPassLblConstraints.gridx = 0;
/* 1173 */       oldPassLblConstraints.gridy = 0;
/* 1174 */       oldPassLblConstraints.insets = new Insets(5, 10, 3, 3);
/* 1175 */       oldPassLblConstraints.anchor = 13;
/* 1176 */       this.storePass.add(this.oldPassLabel, oldPassLblConstraints);
/*      */       
/* 1178 */       GridBagConstraints oldPassFldConstraints = new GridBagConstraints();
/* 1179 */       oldPassFldConstraints.gridx = 1;
/* 1180 */       oldPassFldConstraints.gridy = 0;
/* 1181 */       oldPassFldConstraints.fill = 2;
/* 1182 */       oldPassFldConstraints.weightx = 1.0D;
/* 1183 */       oldPassFldConstraints.gridwidth = 2;
/* 1184 */       oldPassFldConstraints.insets = new Insets(5, 3, 3, 20);
/* 1185 */       this.storePass.add(this.oldPassField, oldPassFldConstraints);
/*      */       
/* 1187 */       GridBagConstraints newPassLblConstraints = new GridBagConstraints();
/* 1188 */       newPassLblConstraints.gridx = 0;
/* 1189 */       newPassLblConstraints.gridy = 1;
/* 1190 */       newPassLblConstraints.insets = new Insets(5, 10, 3, 3);
/* 1191 */       newPassLblConstraints.anchor = 13;
/* 1192 */       this.storePass.add(this.newPassLabel, newPassLblConstraints);
/*      */       
/* 1194 */       GridBagConstraints newPassFldConstraints = new GridBagConstraints();
/* 1195 */       newPassFldConstraints.gridx = 1;
/* 1196 */       newPassFldConstraints.gridy = 1;
/* 1197 */       newPassFldConstraints.weightx = 1.0D;
/* 1198 */       newPassFldConstraints.fill = 2;
/* 1199 */       newPassFldConstraints.insets = new Insets(5, 3, 3, 20);
/* 1200 */       this.storePass.add(this.newPassField, newPassFldConstraints);
/*      */       
/* 1202 */       GridBagConstraints noPassCheckConstraints = new GridBagConstraints();
/* 1203 */       noPassCheckConstraints.gridx = 0;
/* 1204 */       noPassCheckConstraints.gridy = 2;
/* 1205 */       noPassCheckConstraints.insets = new Insets(5, 10, 3, 10);
/* 1206 */       noPassCheckConstraints.gridwidth = 3;
/* 1207 */       noPassCheckConstraints.anchor = 10;
/* 1208 */       this.storePass.add(this.noPassCheck, noPassCheckConstraints);
/*      */       
/*      */ 
/* 1211 */       this.pkcs11Admon = new JPanel();
/*      */       
/*      */ 
/* 1214 */       this.driversTbl = new JTable();
/* 1215 */       this.driversTbl.setDefaultRenderer(Object.class, new CertCellRenderer());
/* 1216 */       this.driversTbl.setSelectionMode(0);
/* 1217 */       this.driversTbl.setPreferredScrollableViewportSize(new Dimension(500, 200));
/* 1218 */       this.driversTbl.setModel(new DriverTblModel(this.drivrList));
/* 1219 */       this.driversTbl.setAutoResizeMode(4);
/* 1220 */       this.driversTbl.getColumnModel().getColumn(1).setPreferredWidth(250);
/* 1221 */       this.driversTbl.getColumnModel().getColumn(1).setMaxWidth(250);
/* 1222 */       this.driversTbl.getColumnModel().getColumn(1).setMinWidth(250);
/* 1223 */       this.driversTbl.getColumnModel().getColumn(1).setWidth(250);
/*      */       
/* 1225 */       this.driversScroll = new JScrollPane(this.driversTbl);
/*      */       
/* 1227 */       this.addDrvrButton = new JButton();
/* 1228 */       this.addDrvrButton.setText(MITyCStore.I18N.getLocalMessage("i18n.mityc.cert.mityc.71"));
/* 1229 */       this.addDrvrButton.addActionListener(new ActionListener() {
/*      */         public void actionPerformed(ActionEvent evt) {
/* 1231 */           MITyCStore.PreferencesPanel.this.addDriverBtnActionPerformed();
/*      */         }
/*      */         
/* 1234 */       });
/* 1235 */       this.delDrvrButton = new JButton();
/* 1236 */       this.delDrvrButton.setText(MITyCStore.I18N.getLocalMessage("i18n.mityc.cert.mityc.70"));
/* 1237 */       this.delDrvrButton.addActionListener(new ActionListener() {
/*      */         public void actionPerformed(ActionEvent evt) {
/* 1239 */           MITyCStore.PreferencesPanel.this.delDriverBtnActionPerformed();
/*      */         }
/*      */         
/*      */ 
/* 1243 */       });
/* 1244 */       this.pkcs11Admon.setLayout(new GridBagLayout());
/*      */       
/* 1246 */       GridBagConstraints drvTblConstraints = new GridBagConstraints();
/* 1247 */       drvTblConstraints.gridx = 0;
/* 1248 */       drvTblConstraints.gridy = 0;
/* 1249 */       drvTblConstraints.fill = 2;
/* 1250 */       drvTblConstraints.weightx = 1.0D;
/* 1251 */       drvTblConstraints.gridwidth = 4;
/* 1252 */       drvTblConstraints.ipady = 50;
/* 1253 */       drvTblConstraints.insets = new Insets(5, 5, 10, 5);
/* 1254 */       this.pkcs11Admon.add(this.driversScroll, drvTblConstraints);
/*      */       
/* 1256 */       GridBagConstraints addDrvBtnConstraints = new GridBagConstraints();
/* 1257 */       addDrvBtnConstraints.gridx = 0;
/* 1258 */       addDrvBtnConstraints.gridy = 1;
/* 1259 */       addDrvBtnConstraints.gridwidth = 1;
/* 1260 */       addDrvBtnConstraints.insets = new Insets(5, 55, 5, 5);
/* 1261 */       this.pkcs11Admon.add(this.addDrvrButton, addDrvBtnConstraints);
/*      */       
/* 1263 */       GridBagConstraints delDrvBtnConstraints = new GridBagConstraints();
/* 1264 */       delDrvBtnConstraints.gridx = 3;
/* 1265 */       delDrvBtnConstraints.gridy = 1;
/* 1266 */       delDrvBtnConstraints.gridwidth = 1;
/* 1267 */       delDrvBtnConstraints.insets = new Insets(5, 30, 5, 5);
/* 1268 */       this.pkcs11Admon.add(this.delDrvrButton, delDrvBtnConstraints);
/*      */       
/*      */ 
/* 1271 */       this.tabs.addTab(MITyCStore.I18N.getLocalMessage("i18n.mityc.cert.mityc.20"), this.storePass);
/* 1272 */       if (MITyCStore.confFile != null) {
/* 1273 */         this.tabs.addTab("SmartCards", this.pkcs11Admon);
/*      */       }
/*      */       
/*      */ 
/* 1277 */       GridBagConstraints tabsConstraints = new GridBagConstraints();
/* 1278 */       tabsConstraints.gridx = 0;
/* 1279 */       tabsConstraints.gridy = 0;
/* 1280 */       tabsConstraints.fill = 1;
/* 1281 */       tabsConstraints.weightx = 1.0D;
/* 1282 */       tabsConstraints.weighty = 1.0D;
/* 1283 */       add(this.tabs, tabsConstraints);
/*      */       
/* 1285 */       GridBagConstraints aceptarButtonConstraints = new GridBagConstraints();
/* 1286 */       aceptarButtonConstraints.gridx = 0;
/* 1287 */       aceptarButtonConstraints.gridy = 1;
/* 1288 */       aceptarButtonConstraints.anchor = 10;
/* 1289 */       aceptarButtonConstraints.insets = new Insets(10, 20, 10, 20);
/*      */       
/* 1291 */       this.aceptarButton.setText(MITyCStore.I18N.getLocalMessage("i18n.mityc.cert.smartcards.GUI.accept"));
/* 1292 */       this.aceptarButton.addActionListener(new ActionListener() {
/*      */         public void actionPerformed(ActionEvent evt) {
/* 1294 */           MITyCStore.PreferencesPanel.this.jAceptarButtonActionPerformed();
/*      */         }
/* 1296 */       });
/* 1297 */       add(this.aceptarButton, aceptarButtonConstraints);
/*      */       
/* 1299 */       setSize(350, 265);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private void noPassActionPerformed(ItemEvent e)
/*      */     {
/* 1307 */       boolean passEnabled = 2 == e.getStateChange();
/* 1308 */       this.newPassLabel.setEnabled(passEnabled);
/* 1309 */       this.newPassField.setEnabled(passEnabled);
/*      */       
/* 1311 */       repaint();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     private void addDriverBtnActionPerformed()
/*      */     {
/* 1318 */       String origen = System.getProperty("user.home");
/* 1319 */       String osName = System.getProperty("os.name");
/* 1320 */       if (!osName.toLowerCase().startsWith("win")) {
/* 1321 */         origen = "/usr/Library/OpenSC/bin/opensc-pkcs11.so";
/*      */       }
/*      */       
/*      */ 
/* 1325 */       JFileChooser chooser = new JFileChooser();
/* 1326 */       chooser.setDialogTitle(MITyCStore.I18N.getLocalMessage("i18n.mityc.cert.mityc.97"));
/* 1327 */       chooser.setSelectedFile(new File(origen));
/* 1328 */       int returnVal = chooser.showOpenDialog(getTopLevelAncestor());
/* 1329 */       if (returnVal == 0) {
/* 1330 */         origen = chooser.getSelectedFile().getAbsolutePath();
/*      */       } else {
/* 1332 */         MITyCStore.LOG.debug("Cancelado por el usuario.");
/* 1333 */         return;
/*      */       }
/*      */       
/* 1336 */       if ((origen == null) || (!origen.contains("."))) {
/* 1337 */         return;
/*      */       }
/* 1339 */       int initialPoint = origen.lastIndexOf(File.separator) + 1;
/* 1340 */       if (initialPoint == -1) {
/* 1341 */         initialPoint = 0;
/*      */       }
/* 1343 */       int lastPoint = origen.lastIndexOf(".");
/* 1344 */       if (lastPoint == -1) {
/* 1345 */         lastPoint = origen.length();
/*      */       }
/*      */       
/* 1348 */       if (!MITyCStore.this.drvrList.containsValue(origen)) {
/* 1349 */         MITyCStore.this.drvrList.put(origen.substring(initialPoint, lastPoint), origen);
/* 1350 */         ((DriverTblModel)this.driversTbl.getModel()).addRow(origen.substring(initialPoint, lastPoint), origen);
/* 1351 */         this.driversTbl.addNotify();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private void delDriverBtnActionPerformed()
/*      */     {
/* 1360 */       int selIndex = this.driversTbl.getSelectedRow();
/* 1361 */       if (selIndex >= 0) {
/* 1362 */         String key = (String)this.driversTbl.getModel().getValueAt(selIndex, 0);
/* 1363 */         this.drivrList.remove(key);
/* 1364 */         ((DriverTblModel)this.driversTbl.getModel()).removeRow(selIndex);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private void jAceptarButtonActionPerformed()
/*      */     {
/* 1373 */       if ((this.oldPassField.getPassword() != null) && (this.oldPassField.getPassword() != new char[0])) {
/* 1374 */         char[] newPass = new char[0];
/* 1375 */         if (!this.noPassCheck.isSelected()) {
/* 1376 */           newPass = this.newPassField.getPassword();
/*      */         }
/*      */         try {
/* 1379 */           this.store.setNewPass(this.oldPassField.getPassword(), newPass);
/*      */         } catch (CertStoreException e) {
/* 1381 */           JOptionPane.showMessageDialog(this, 
/*      */           
/* 1383 */             MITyCStore.I18N.getLocalMessage("i18n.mityc.cert.mityc.91"), 
/* 1384 */             MITyCStore.I18N.getLocalMessage("i18n.mityc.cert.mityc.77"), 
/* 1385 */             0);
/* 1386 */           this.oldPassField.setText("");
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1391 */       if ((this.drivrList != null) && 
/* 1392 */         (MITyCStore.confFile != null)) {
/*      */         try {
/* 1394 */           this.store.setNewMultiPkcs11(this.drivrList);
/* 1395 */           this.store.saveConf();
/*      */         } catch (CertStoreException e) {
/* 1397 */           JOptionPane.showMessageDialog(this, 
/* 1398 */             e.getMessage(), 
/* 1399 */             MITyCStore.I18N.getLocalMessage("i18n.mityc.cert.mityc.77"), 
/* 1400 */             0);
/* 1401 */           return;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1406 */       setVisible(false);
/* 1407 */       if ((getTopLevelAncestor() != null) && ((getTopLevelAncestor() instanceof JDialog))) {
/* 1408 */         getTopLevelAncestor().setVisible(false);
/* 1409 */         ((JDialog)getTopLevelAncestor()).dispose();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1415 */     private JTabbedPane tabs = null;
/*      */     
/* 1417 */     private JButton aceptarButton = null;
/*      */     
/*      */ 
/* 1420 */     private JPanel storePass = null;
/*      */     
/* 1422 */     private JLabel oldPassLabel = null;
/*      */     
/* 1424 */     private JPasswordField oldPassField = null;
/*      */     
/* 1426 */     private JLabel newPassLabel = null;
/*      */     
/* 1428 */     private JPasswordField newPassField = null;
/*      */     
/* 1430 */     private JCheckBox noPassCheck = null;
/*      */     
/*      */ 
/* 1433 */     private JPanel pkcs11Admon = null;
/*      */     
/* 1435 */     private JScrollPane driversScroll = null;
/*      */     
/* 1437 */     private JTable driversTbl = null;
/*      */     
/* 1439 */     private JButton addDrvrButton = null;
/*      */     
/* 1441 */     private JButton delDrvrButton = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected class AliasFormat
/*      */   {
/* 1451 */     private final char keyProtected = 'p';
/*      */     
/* 1453 */     private final char keyUnprotected = 'u';
/*      */     
/*      */ 
/* 1456 */     private boolean isProtected = true;
/*      */     
/* 1458 */     private boolean isPassCached = false;
/*      */     
/* 1460 */     private boolean mayWarning = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public AliasFormat(String alias)
/*      */     {
/* 1468 */       if ((alias == null) || (alias.length() <= 0)) {
/* 1469 */         if (MITyCStore.LOG.isDebugEnabled()) {
/* 1470 */           MITyCStore.LOG.debug("El alias no cumple con el formato");
/*      */         }
/* 1472 */         return;
/*      */       }
/* 1474 */       char[] aliasArray = alias.toCharArray();
/* 1475 */       if ('p' == aliasArray[0]) {
/* 1476 */         if ('0' == aliasArray[1]) {
/* 1477 */           this.isProtected = true;
/* 1478 */           this.isPassCached = false;
/* 1479 */           this.mayWarning = false;
/* 1480 */         } else if ('1' == aliasArray[1]) {
/* 1481 */           this.isProtected = true;
/* 1482 */           this.isPassCached = true;
/* 1483 */           this.mayWarning = false;
/*      */         }
/* 1485 */         else if (MITyCStore.LOG.isDebugEnabled()) {
/* 1486 */           MITyCStore.LOG.debug("El alias no cumple con el formato");
/*      */         }
/*      */         
/*      */       }
/* 1490 */       else if ('u' == aliasArray[0]) {
/* 1491 */         if ('0' == aliasArray[1]) {
/* 1492 */           this.isProtected = false;
/* 1493 */           this.isPassCached = false;
/* 1494 */           this.mayWarning = false;
/* 1495 */         } else if ('1' == aliasArray[1]) {
/* 1496 */           this.isProtected = false;
/* 1497 */           this.isPassCached = false;
/* 1498 */           this.mayWarning = true;
/*      */         } else {
/* 1500 */           if (MITyCStore.LOG.isDebugEnabled()) {
/* 1501 */             MITyCStore.LOG.debug("El alias no cumple con el formato");
/*      */           }
/* 1503 */           return;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public String genAliasPrefix(boolean isPro, boolean isCached, boolean mayWarn)
/*      */     {
/* 1517 */       StringBuffer sb = new StringBuffer("");
/*      */       
/* 1519 */       if (isPro) {
/* 1520 */         sb.append('p');
/* 1521 */         if (isCached) {
/* 1522 */           sb.append('1');
/*      */         } else {
/* 1524 */           sb.append('0');
/*      */         }
/*      */       } else {
/* 1527 */         sb.append('u');
/* 1528 */         if (mayWarn) {
/* 1529 */           sb.append('1');
/*      */         } else {
/* 1531 */           sb.append('0');
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1536 */       sb.append("00");
/*      */       
/* 1538 */       return sb.toString();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean isProtected()
/*      */     {
/* 1546 */       return this.isProtected;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean isPassCached()
/*      */     {
/* 1554 */       return this.isPassCached;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean isMayWarning()
/*      */     {
/* 1562 */       return this.mayWarning;
/*      */     }
/*      */   }
/*      */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mitycstore\MITyCStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */