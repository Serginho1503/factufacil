/*    */ package es.mityc.javasign.pkstore.pkcs11;
/*    */ 
/*    */ import java.security.Provider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SunP11SlotData
/*    */   implements IProviderData
/*    */ {
/*    */   private Provider provider;
/*    */   private long slotID;
/*    */   private String keyStoreType;
/*    */   
/*    */   public SunP11SlotData(Provider prov, long slot, String type)
/*    */   {
/* 40 */     this.provider = prov;
/* 41 */     this.slotID = slot;
/* 42 */     this.keyStoreType = new String(type);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public long getSlotID()
/*    */   {
/* 50 */     return this.slotID;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Provider getProvider()
/*    */   {
/* 58 */     return this.provider;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getKeyStoreTypeName()
/*    */   {
/* 66 */     return this.keyStoreType;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 77 */     if ((obj instanceof SunP11SlotData)) {
/* 78 */       if (this.slotID == ((SunP11SlotData)obj).slotID) {
/* 79 */         return true;
/*    */       }
/* 81 */     } else if (((obj instanceof Long)) && 
/* 82 */       (this.slotID == ((Long)obj).longValue())) {
/* 83 */       return true;
/*    */     }
/*    */     
/* 86 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 96 */     return (int)(this.slotID ^ this.slotID >>> 32);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\pkcs11\SunP11SlotData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */