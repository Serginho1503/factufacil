/*     */ package es.mityc.javasign.pkstore.mscapi.mityc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class Key
/*     */   implements java.security.Key
/*     */ {
/*  42 */   protected long hCryptProv = 0L;
/*  43 */   protected long hCryptKey = 0L;
/*     */   
/*     */ 
/*  46 */   protected int keyLength = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Key(long hCryptProv, long hCryptKey, int keyLength)
/*     */   {
/*  53 */     this.hCryptProv = hCryptProv;
/*  54 */     this.hCryptKey = hCryptKey;
/*  55 */     this.keyLength = keyLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void finalize()
/*     */     throws Throwable
/*     */   {
/*     */     try
/*     */     {
/*  65 */       synchronized (this)
/*     */       {
/*  67 */         cleanUp(this.hCryptProv, this.hCryptKey);
/*  68 */         this.hCryptProv = 0L;
/*  69 */         this.hCryptKey = 0L;
/*     */       }
/*     */     }
/*     */     finally {
/*  73 */       super.finalize(); } super.finalize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static native void cleanUp(long paramLong1, long paramLong2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int bitLength()
/*     */   {
/*  87 */     return this.keyLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getHCryptKey()
/*     */   {
/*  96 */     return this.hCryptKey;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getHCryptProvider()
/*     */   {
/* 104 */     return this.hCryptProv;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String getAlgorithm();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFormat()
/*     */   {
/* 138 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getEncoded()
/*     */   {
/* 150 */     return null;
/*     */   }
/*     */   
/*     */   protected static native String getContainerName(long paramLong);
/*     */   
/*     */   protected static native String getKeyType(long paramLong);
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCert-1.1.7.jar!\es\mityc\javasign\pkstore\mscapi\mityc\Key.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */