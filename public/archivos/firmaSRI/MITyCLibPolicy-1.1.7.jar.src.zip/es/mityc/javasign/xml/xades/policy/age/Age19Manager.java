/*     */ package es.mityc.javasign.xml.xades.policy.age;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.utilidades.URIEncoder;
/*     */ import es.mityc.firmaJava.libreria.xades.DatosFirma;
/*     */ import es.mityc.firmaJava.libreria.xades.ResultadoValidacion;
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.PolicyException;
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.trust.TrustAbstract;
/*     */ import es.mityc.javasign.xml.xades.policy.PolicyResult;
/*     */ import es.mityc.javasign.xml.xades.policy.PolicyResult.DownloadPolicy;
/*     */ import es.mityc.javasign.xml.xades.policy.PolicyResult.StatusValidation;
/*     */ import es.mityc.javasign.xml.xades.policy.UnknownPolicyException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Age19Manager
/*     */   extends AgeManager
/*     */ {
/*  47 */   private static final Log LOG = LogFactory.getLog(Age19Manager.class);
/*     */   
/*  49 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibPolicy");
/*     */   
/*     */ 
/*     */   private static final String PREFIX_POLICY_PROP = "age19";
/*     */   
/*     */ 
/*  55 */   private static ConfigAGE config = null;
/*     */   
/*     */   static {
/*     */     try {
/*  59 */       config = AgeManager.loadConfig("age19");
/*     */     } catch (ConfigAgeException ex) {
/*  61 */       LOG.fatal(I18N.getLocalMessage("i18n.mityc.policy.general.7"), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Age19Manager()
/*     */     throws InstantiationException
/*     */   {
/*  71 */     if (config == null) {
/*  72 */       throw new InstantiationException(I18N.getLocalMessage("i18n.mityc.policy.general.8"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ConfigAGE getConfig()
/*     */   {
/*  83 */     return config;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getIdentidadPolicy()
/*     */   {
/*  93 */     return config.getPolicyIdValidador();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PolicyResult validaPolicy(Element nodoFirma, ResultadoValidacion resultadoValidacion)
/*     */   {
/* 102 */     PolicyResult pr = new PolicyResult();
/* 103 */     if (LOG.isDebugEnabled()) {
/* 104 */       LOG.debug("Validando política de AGE");
/*     */     }
/*     */     try {
/* 107 */       URI id = config.getPolicyIdXades();
/*     */       try
/*     */       {
/* 110 */         id = new URI(getFormatedMessage("age19", new Object[] { URIEncoder.encode(config.getPolicyIdValidador(), "UTF-8") }));
/*     */       } catch (URISyntaxException ex) {
/* 112 */         LOG.warn(I18N.getLocalMessage("i18n.mityc.policy.general.9"), ex);
/*     */       } catch (UnsupportedEncodingException ex) {
/* 114 */         LOG.warn(I18N.getLocalMessage("i18n.mityc.policy.general.9"), ex);
/*     */       }
/*     */       
/* 117 */       pr.setPolicyID(id);
/*     */       
/*     */ 
/* 120 */       pr.setDownloable(new PolicyResult.DownloadPolicy[] { pr.newDownloadPolicy(config.getSpUri(), PolicyResult.StatusValidation.unknown) });
/*     */       
/* 122 */       checkSchema(nodoFirma, resultadoValidacion);
/*     */       
/* 124 */       checkPolicyHash(nodoFirma, resultadoValidacion);
/*     */       
/* 126 */       checkNodes(nodoFirma, resultadoValidacion);
/*     */       
/* 128 */       checkCertificateInKeyInfoNode(nodoFirma, resultadoValidacion);
/*     */       
/* 130 */       checkRoles(nodoFirma, resultadoValidacion);
/*     */       
/* 132 */       checkTimestamp(nodoFirma, resultadoValidacion);
/*     */       
/* 134 */       checkStatusCertificate(nodoFirma, resultadoValidacion);
/*     */       
/* 136 */       checkTrustSigningCertificate(nodoFirma, resultadoValidacion);
/*     */       
/* 138 */       checkTrustTsa(nodoFirma, resultadoValidacion);
/*     */       
/* 140 */       pr.setResult(PolicyResult.StatusValidation.valid);
/*     */     } catch (UnknownPolicyException ex) {
/* 142 */       pr.setResult(PolicyResult.StatusValidation.unknown);
/* 143 */       pr.setDescriptionResult(ex.getMessage());
/*     */     } catch (PolicyException ex) {
/* 145 */       pr.setResult(PolicyResult.StatusValidation.invalid);
/* 146 */       pr.setDescriptionResult(ex.getMessage());
/*     */     }
/*     */     
/* 149 */     return pr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkSchema(Element nodoFirma, ResultadoValidacion rs)
/*     */     throws PolicyException
/*     */   {
/* 161 */     DatosFirma df = rs.getDatosFirma();
/* 162 */     if (df != null) {
/* 163 */       XAdESSchemas schema = df.getEsquema();
/* 164 */       if ((XAdESSchemas.XAdES_111.equals(schema)) || (XAdESSchemas.XMLDSIG.equals(schema))) {
/* 165 */         throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.general.24"));
/*     */       }
/*     */     }
/*     */     else {
/* 169 */       throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.general.23"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writePolicyNode(Element signNode, String namespaceDS, String namespaceXAdES, XAdESSchemas schema)
/*     */     throws PolicyException
/*     */   {
/* 183 */     escribePolicy(signNode, namespaceDS, namespaceXAdES, schema);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTruster(TrustAbstract truster)
/*     */   {
/* 190 */     if (truster != null) {
/* 191 */       this.truster = truster;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibPolicy-1.1.7.jar!\es\mityc\javasign\xml\xades\policy\age\Age19Manager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */