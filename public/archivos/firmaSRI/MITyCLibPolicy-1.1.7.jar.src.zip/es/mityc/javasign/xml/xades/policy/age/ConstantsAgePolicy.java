package es.mityc.javasign.xml.xades.policy.age;

public final class ConstantsAgePolicy
{
  public static final String I18N_POLICY_AGE_1 = "i18n.mityc.policy.age.1";
  public static final String I18N_POLICY_AGE_2 = "i18n.mityc.policy.age.2";
  public static final String I18N_POLICY_AGE_3 = "i18n.mityc.policy.age.3";
  public static final String I18N_POLICY_AGE_4 = "i18n.mityc.policy.age.4";
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibPolicy-1.1.7.jar!\es\mityc\javasign\xml\xades\policy\age\ConstantsAgePolicy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */