/*    */ package es.mityc.javasign.xml.xades.policy.facturae;
/*    */ 
/*    */ import es.mityc.javasign.xml.xades.policy.PolicyException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigFacturaeException
/*    */   extends PolicyException
/*    */ {
/*    */   static final long serialVersionUID = 1L;
/*    */   
/*    */   public ConfigFacturaeException() {}
/*    */   
/*    */   public ConfigFacturaeException(String message, Throwable cause)
/*    */   {
/* 43 */     super(message, cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ConfigFacturaeException(String message)
/*    */   {
/* 51 */     super(message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ConfigFacturaeException(Throwable cause)
/*    */   {
/* 59 */     super(cause);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibPolicy-1.1.7.jar!\es\mityc\javasign\xml\xades\policy\facturae\ConfigFacturaeException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */