/*     */ package es.mityc.javasign.xml.xades.policy.facturae;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.utilidades.URIEncoder;
/*     */ import es.mityc.firmaJava.libreria.xades.DatosFirma;
/*     */ import es.mityc.firmaJava.libreria.xades.ResultadoValidacion;
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.PolicyException;
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.trust.TrustAbstract;
/*     */ import es.mityc.javasign.xml.xades.policy.PolicyResult;
/*     */ import es.mityc.javasign.xml.xades.policy.PolicyResult.DownloadPolicy;
/*     */ import es.mityc.javasign.xml.xades.policy.PolicyResult.StatusValidation;
/*     */ import es.mityc.javasign.xml.xades.policy.UnknownPolicyException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Facturae30Manager
/*     */   extends FacturaeManager
/*     */ {
/*  47 */   private static final Log LOG = LogFactory.getLog(Facturae30Manager.class);
/*     */   
/*  49 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibPolicy");
/*     */   
/*     */ 
/*     */   private static final String PREFIX_POLICY_PROP = "facturae30";
/*     */   
/*  54 */   private static ConfigFacturae config = null;
/*     */   
/*     */   static {
/*     */     try {
/*  58 */       config = FacturaeManager.loadConfig("facturae30");
/*     */     } catch (ConfigFacturaeException ex) {
/*  60 */       LOG.fatal(I18N.getLocalMessage("i18n.mityc.policy.general.7"), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Facturae30Manager()
/*     */     throws InstantiationException
/*     */   {
/*  70 */     if (config == null) {
/*  71 */       throw new InstantiationException(I18N.getLocalMessage("i18n.mityc.policy.general.8"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ConfigFacturae getConfig()
/*     */   {
/*  82 */     return config;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getIdentidadPolicy()
/*     */   {
/*  92 */     return config.getPolicyIdValidador();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PolicyResult validaPolicy(Element nodoFirma, ResultadoValidacion resultadoValidacion)
/*     */   {
/* 132 */     PolicyResult pr = new PolicyResult();
/* 133 */     if (LOG.isDebugEnabled()) {
/* 134 */       LOG.debug("Validando política de factura 3.0");
/*     */     }
/*     */     try {
/* 137 */       URI id = config.getPolicyIdXades();
/*     */       try
/*     */       {
/* 140 */         id = new URI(getFormatedMessage("text:{0}", new Object[] { URIEncoder.encode(config.getPolicyIdValidador(), "UTF-8") }));
/*     */       } catch (URISyntaxException ex) {
/* 142 */         LOG.warn(I18N.getLocalMessage("i18n.mityc.policy.general.9"), ex);
/*     */       } catch (UnsupportedEncodingException ex) {
/* 144 */         LOG.warn(I18N.getLocalMessage("i18n.mityc.policy.general.9"), ex);
/*     */       }
/*     */       
/* 147 */       pr.setPolicyID(id);
/*     */       
/*     */ 
/* 150 */       pr.setDownloable(new PolicyResult.DownloadPolicy[] { pr.newDownloadPolicy(config.getPolicyIdXades(), PolicyResult.StatusValidation.unknown) });
/*     */       
/* 152 */       checkSchema(nodoFirma, resultadoValidacion);
/*     */       
/* 154 */       checkPolicyHash(nodoFirma, resultadoValidacion);
/*     */       
/* 156 */       checkEnveloped(nodoFirma, resultadoValidacion);
/*     */       
/* 158 */       checkCertificateInKeyInfoNode(nodoFirma, resultadoValidacion);
/*     */       
/* 160 */       checkRoles(nodoFirma, resultadoValidacion);
/*     */       
/* 162 */       checkTimestamp(nodoFirma, resultadoValidacion);
/*     */       
/* 164 */       checkStatusCertificate(nodoFirma, resultadoValidacion);
/*     */       
/* 166 */       checkTrustSigningCertificate(nodoFirma, resultadoValidacion);
/*     */       
/* 168 */       checkTrustTsa(nodoFirma, resultadoValidacion);
/*     */       
/* 170 */       pr.setResult(PolicyResult.StatusValidation.valid);
/*     */     } catch (UnknownPolicyException ex) {
/* 172 */       pr.setResult(PolicyResult.StatusValidation.unknown);
/* 173 */       pr.setDescriptionResult(ex.getMessage());
/*     */     } catch (PolicyException ex) {
/* 175 */       pr.setResult(PolicyResult.StatusValidation.invalid);
/* 176 */       pr.setDescriptionResult(ex.getMessage());
/*     */     }
/*     */     
/* 179 */     return pr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkSchema(Element nodoFirma, ResultadoValidacion rs)
/*     */     throws PolicyException
/*     */   {
/* 191 */     DatosFirma df = rs.getDatosFirma();
/* 192 */     if (df != null) {
/* 193 */       XAdESSchemas schema = df.getEsquema();
/* 194 */       if (!XAdESSchemas.XAdES_122.equals(schema)) {
/* 195 */         throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.general.24"));
/*     */       }
/*     */     }
/*     */     else {
/* 199 */       throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.general.23"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writePolicyNode(Element signNode, String namespaceDS, String namespaceXAdES, XAdESSchemas schema)
/*     */     throws PolicyException
/*     */   {
/* 213 */     escribePolicy(signNode, namespaceDS, namespaceXAdES, schema);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTruster(TrustAbstract truster)
/*     */   {
/* 220 */     if (truster != null) {
/* 221 */       this.truster = truster;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibPolicy-1.1.7.jar!\es\mityc\javasign\xml\xades\policy\facturae\Facturae30Manager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */