/*     */ package es.mityc.javasign.xml.xades.policy.facturae;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.DigestAlgAndValueType;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SigPolicyHash;
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigFacturae
/*     */ {
/*  40 */   private static final Log LOG = LogFactory.getLog(ConfigFacturae.class);
/*     */   
/*  42 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibPolicy");
/*     */   
/*     */ 
/*     */   private static final String STRING_POINT = ".";
/*     */   
/*     */ 
/*     */   private static final String STRING_EMPTY = "";
/*     */   
/*  50 */   private URI policyIdXades = null;
/*     */   
/*  52 */   private String policyIdValidador = null;
/*     */   
/*  54 */   private String policyDescription = null;
/*     */   
/*  56 */   private ArrayList<DigestAlgAndValueType> huellas = null;
/*     */   
/*  58 */   private int policyWriterId = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConfigFacturae(Properties props, String prefix)
/*     */     throws ConfigFacturaeException
/*     */   {
/*  68 */     if (LOG.isDebugEnabled()) {
/*  69 */       LOG.debug("Se carga la configuración de políticas de factura: " + prefix);
/*     */     }
/*  71 */     String prep = "";
/*  72 */     if ((prefix != null) && (!"".equals(prefix.trim()))) {
/*  73 */       prep = prefix + ".";
/*     */     }
/*     */     try
/*     */     {
/*  77 */       String policyIdXadesStr = props.getProperty(prep + "policy.id");
/*  78 */       this.policyIdValidador = props.getProperty(prep + "policy.idValidator");
/*  79 */       if ((policyIdXadesStr == null) || (this.policyIdValidador == null)) {
/*  80 */         LOG.fatal(I18N.getLocalMessage("i18n.mityc.policy.general.1"));
/*  81 */         throw new ConfigFacturaeException(I18N.getLocalMessage("i18n.mityc.policy.general.2"));
/*     */       }
/*  83 */       this.policyIdXades = new URI(policyIdXadesStr);
/*     */     } catch (URISyntaxException ex) {
/*  85 */       LOG.fatal(I18N.getLocalMessage("i18n.mityc.policy.general.3"));
/*  86 */       throw new ConfigFacturaeException(I18N.getLocalMessage("i18n.mityc.policy.general.2"), ex);
/*     */     }
/*     */     try
/*     */     {
/*  90 */       this.policyDescription = props.getProperty(prep + "policy.idValidator");
/*     */     } catch (MissingResourceException ex) {
/*  92 */       if (LOG.isTraceEnabled()) {
/*  93 */         LOG.trace(I18N.getLocalMessage("i18n.mityc.policy.general.4", new Object[] { prep }));
/*     */       }
/*     */     }
/*     */     
/*  97 */     this.huellas = new ArrayList();
/*  98 */     int i = 0;
/*     */     for (;;) {
/* 100 */       String hashId = props.getProperty(prep + "policy.digest.id." + i);
/* 101 */       String hashValue = props.getProperty(prep + "policy.digest.value." + i);
/* 102 */       if ((hashId == null) || (hashValue == null)) break;
/* 103 */       this.huellas.add(new SigPolicyHash(null, hashId, hashValue));
/* 104 */       i++;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 111 */       String policyWriterIdStr = props.getProperty(prep + "policy.writer.digest");
/* 112 */       if (policyWriterIdStr == null) {
/* 113 */         if (LOG.isTraceEnabled()) {
/* 114 */           LOG.trace(I18N.getLocalMessage("i18n.mityc.policy.general.6", new Object[] { prep }));
/*     */         }
/*     */       } else {
/* 117 */         this.policyWriterId = Integer.parseInt(policyWriterIdStr);
/* 118 */         if (this.policyWriterId >= this.huellas.size()) {
/* 119 */           this.policyWriterId = -1;
/* 120 */           LOG.error(I18N.getLocalMessage("i18n.mityc.policy.general.5"));
/*     */         }
/*     */       }
/*     */     } catch (NumberFormatException ex) {
/* 124 */       LOG.error(I18N.getLocalMessage("i18n.mityc.policy.general.5"), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public URI getPolicyIdXades()
/*     */   {
/* 133 */     return this.policyIdXades;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPolicyIdValidador()
/*     */   {
/* 141 */     return this.policyIdValidador;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPolicyDescription()
/*     */   {
/* 149 */     return this.policyDescription;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPolicyWriterId()
/*     */   {
/* 157 */     return this.policyWriterId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ArrayList<DigestAlgAndValueType> getHuellas()
/*     */   {
/* 165 */     return this.huellas;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibPolicy-1.1.7.jar!\es\mityc\javasign\xml\xades\policy\facturae\ConfigFacturae.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */