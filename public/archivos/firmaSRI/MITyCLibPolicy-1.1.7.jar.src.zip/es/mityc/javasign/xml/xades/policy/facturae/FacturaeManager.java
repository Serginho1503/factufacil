/*     */ package es.mityc.javasign.xml.xades.policy.facturae;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.utilidades.UtilidadTratarNodo;
/*     */ import es.mityc.firmaJava.libreria.xades.DatosFirma;
/*     */ import es.mityc.firmaJava.libreria.xades.DatosNodosFirmados;
/*     */ import es.mityc.firmaJava.libreria.xades.ResultadoValidacion;
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.DigestAlgAndValueType;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SigPolicyHash;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SigPolicyId;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SignaturePolicyId;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SignaturePolicyIdentifier;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xmldsig.DigestMethod;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.PolicyException;
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.trust.TrustAbstract;
/*     */ import es.mityc.javasign.trust.TrustException;
/*     */ import es.mityc.javasign.trust.TrustFactory;
/*     */ import es.mityc.javasign.xml.xades.TransformProxy;
/*     */ import es.mityc.javasign.xml.xades.policy.IFirmaPolicy;
/*     */ import es.mityc.javasign.xml.xades.policy.IValidacionPolicy;
/*     */ import es.mityc.javasign.xml.xades.policy.PoliciesTool;
/*     */ import es.mityc.javasign.xml.xades.policy.UnknownPolicyException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FacturaeManager
/*     */   implements IValidacionPolicy, IFirmaPolicy
/*     */ {
/*  64 */   private static final Log LOG = LogFactory.getLog(FacturaeManager.class);
/*     */   
/*  66 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibPolicy");
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String CONFIG_FILENAME = "facturae.properties";
/*     */   
/*     */ 
/*     */ 
/*     */   protected static final String URI_ID_POLICY = "text:{0}";
/*     */   
/*     */ 
/*     */ 
/*     */   protected static final String UTF_8 = "UTF-8";
/*     */   
/*     */ 
/*     */   private static final String MATCH_ROLES = "[eE][mM][iI][sS][oO][rR]|[sS][uU][pP][pP][lL][iI][eE][rR]|[rR][eE][cC][eE][pP][tT][oO][rR]|[cC][uU][sS][tT][oO][mM][eE][rR]|[tT][eE][rR][cC][eE][rR][oO]|[tT][hH][iI][rR][dD] [pP][aA][rR][tT][yY]";
/*     */   
/*     */ 
/*  84 */   private static Properties rb = null;
/*     */   protected TrustAbstract truster;
/*     */   
/*     */   static
/*     */   {
/*     */     try {
/*  90 */       InputStream is = FacturaeManager.class.getResourceAsStream("facturae.properties");
/*  91 */       if (is != null) {
/*  92 */         rb = new Properties();
/*  93 */         rb.load(is);
/*     */       } else {
/*  95 */         LOG.error("No se encontró configuración sobre políticas");
/*     */       }
/*     */     } catch (IOException ex) {
/*  98 */       LOG.fatal(I18N.getLocalMessage("i18n.mityc.policy.general.12"), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected FacturaeManager()
/*     */     throws InstantiationException
/*     */   {
/* 108 */     this.truster = TrustFactory.getInstance().getTruster("mityc");
/* 109 */     if (this.truster == null) {
/* 110 */       throw new InstantiationException(I18N.getLocalMessage("i18n.mityc.policy.general.29"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static ConfigFacturae loadConfig(String prefix)
/*     */     throws ConfigFacturaeException
/*     */   {
/* 122 */     if (rb == null) {
/* 123 */       throw new ConfigFacturaeException(I18N.getLocalMessage("i18n.mityc.policy.general.13"));
/*     */     }
/* 125 */     return new ConfigFacturae(rb, prefix);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private DigestAlgAndValueType getDigestRelated(String algorithm)
/*     */   {
/* 135 */     DigestAlgAndValueType daavt = null;
/* 136 */     Iterator<DigestAlgAndValueType> it = getConfig().getHuellas().iterator();
/* 137 */     while (it.hasNext()) {
/* 138 */       DigestAlgAndValueType temp = (DigestAlgAndValueType)it.next();
/* 139 */       if (temp.getDigestMethod().getAlgorithm().equals(algorithm)) {
/* 140 */         daavt = temp;
/* 141 */         break;
/*     */       }
/*     */     }
/* 144 */     return daavt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkPolicyHash(Element signatureNode, ResultadoValidacion rs)
/*     */     throws PolicyException
/*     */   {
/* 155 */     XAdESSchemas schema = rs.getDatosFirma().getEsquema();
/* 156 */     if (schema == null) {
/* 157 */       throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.general.25"));
/*     */     }
/* 159 */     String esquema = schema.getSchemaUri();
/*     */     
/*     */ 
/* 162 */     NodeList signaturePolicyList = signatureNode.getElementsByTagNameNS(esquema, "SignaturePolicyIdentifier");
/* 163 */     if (signaturePolicyList.getLength() != 1) {
/* 164 */       throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.general.26"));
/*     */     }
/* 166 */     if (signaturePolicyList.item(0).getNodeType() != 1) {
/* 167 */       throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.general.26"));
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 172 */       SignaturePolicyIdentifier signaturePolicyIdentifier = new SignaturePolicyIdentifier(schema);
/* 173 */       if (!signaturePolicyIdentifier.isThisNode(signaturePolicyList.item(0))) {
/* 174 */         throw new InvalidInfoNodeException(I18N.getLocalMessage("i18n.mityc.policy.general.14"));
/*     */       }
/* 176 */       signaturePolicyIdentifier.load((Element)signaturePolicyList.item(0));
/*     */       
/* 178 */       if (signaturePolicyIdentifier.isImplied()) {
/* 179 */         throw new InvalidInfoNodeException(I18N.getLocalMessage("i18n.mityc.policy.general.15"));
/*     */       }
/*     */       
/* 182 */       DigestAlgAndValueType value = getDigestRelated(signaturePolicyIdentifier.getSignaturePolicyId().getSigPolicyHash().getDigestMethod().getAlgorithm());
/* 183 */       SignaturePolicyIdentifier comp = createPolicy(schema, value);
/*     */       
/* 185 */       if (!signaturePolicyIdentifier.equals(comp)) {
/* 186 */         throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.general.27"));
/*     */       }
/*     */     } catch (InvalidInfoNodeException ex) {
/* 189 */       if (LOG.isDebugEnabled()) {
/* 190 */         LOG.debug(I18N.getLocalMessage("i18n.mityc.policy.general.16"), ex);
/*     */       }
/* 192 */       throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.general.28", new Object[] { ex.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkEnveloped(Element signatureNode, ResultadoValidacion rs)
/*     */     throws UnknownPolicyException, PolicyException
/*     */   {
/* 205 */     List<DatosNodosFirmados> nodos = rs.getDatosFirma().getDatosNodosFirmados();
/* 206 */     for (DatosNodosFirmados nodo : nodos) {
/* 207 */       if ("".equals(nodo.getURI())) {
/* 208 */         boolean isEnveloped = false;
/* 209 */         List<TransformProxy> trans = nodo.getTransforms();
/* 210 */         for (TransformProxy transform : trans) {
/* 211 */           String uri = transform.getURI();
/* 212 */           if (!TransformProxy.isCanonicalization(transform))
/*     */           {
/* 214 */             if (uri.equals("http://www.w3.org/2000/09/xmldsig#enveloped-signature")) {
/* 215 */               isEnveloped = true;
/*     */             }
/*     */             else
/* 218 */               throw new UnknownPolicyException(I18N.getLocalMessage("i18n.mityc.policy.facturae.3"));
/*     */           }
/*     */         }
/* 221 */         if (isEnveloped) {
/* 222 */           return;
/*     */         }
/*     */       }
/*     */     }
/* 226 */     throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.facturae.2"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkCertificateInKeyInfoNode(Element signatureNode, ResultadoValidacion rs)
/*     */     throws UnknownPolicyException, PolicyException
/*     */   {
/* 238 */     List<DatosNodosFirmados> nodos = rs.getDatosFirma().getDatosNodosFirmados();
/* 239 */     for (DatosNodosFirmados nodo : nodos)
/*     */     {
/* 241 */       String id = nodo.getId();
/* 242 */       if (id != null) {
/* 243 */         Element el = UtilidadTratarNodo.getElementById(signatureNode.getOwnerDocument(), id);
/*     */         
/* 245 */         if ((el != null) && 
/* 246 */           ("http://www.w3.org/2000/09/xmldsig#".equals(el.getNamespaceURI())) && 
/* 247 */           ("KeyInfo".equals(el.getLocalName())))
/*     */         {
/* 249 */           if (el.getParentNode().equals(signatureNode))
/*     */           {
/* 251 */             List<TransformProxy> trans = nodo.getTransforms();
/* 252 */             for (TransformProxy transform : trans) {
/* 253 */               if (!TransformProxy.isCanonicalization(transform)) {
/* 254 */                 throw new UnknownPolicyException(I18N.getLocalMessage("i18n.mityc.policy.facturae.4"));
/*     */               }
/*     */             }
/* 257 */             return;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 262 */     throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.general.30"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkRoles(Element signatureNode, ResultadoValidacion rs)
/*     */     throws PolicyException
/*     */   {
/* 273 */     DatosFirma df = rs.getDatosFirma();
/* 274 */     if (df != null) {
/* 275 */       ArrayList<String> roles = df.getRoles();
/* 276 */       if ((roles != null) && (roles.size() > 0)) {
/* 277 */         Iterator<String> it = roles.iterator();
/* 278 */         while (it.hasNext()) {
/* 279 */           String role = (String)it.next();
/* 280 */           if (!role.matches("[eE][mM][iI][sS][oO][rR]|[sS][uU][pP][pP][lL][iI][eE][rR]|[rR][eE][cC][eE][pP][tT][oO][rR]|[cC][uU][sS][tT][oO][mM][eE][rR]|[tT][eE][rR][cC][eE][rR][oO]|[tT][hH][iI][rR][dD] [pP][aA][rR][tT][yY]")) {
/* 281 */             throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.general.22"));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 287 */       throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.general.21"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkTimestamp(Element signatureNode, ResultadoValidacion rs)
/*     */     throws PolicyException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkStatusCertificate(Element signatureNode, ResultadoValidacion rs)
/*     */     throws PolicyException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkTrustSigningCertificate(Element signatureNode, ResultadoValidacion rs)
/*     */     throws PolicyException
/*     */   {
/* 326 */     DatosFirma df = rs.getDatosFirma();
/* 327 */     if (df != null) {
/*     */       try {
/* 329 */         this.truster.isTrusted(df.getCadenaFirma());
/*     */       } catch (TrustException ex) {
/* 331 */         throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.facturae.1"));
/*     */       }
/*     */       
/*     */     } else {
/* 335 */       throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.general.20"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkTrustTsa(Element signatureNode, ResultadoValidacion rs)
/*     */     throws PolicyException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected SignaturePolicyIdentifier createPolicy(XAdESSchemas schema, DigestAlgAndValueType value)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 357 */     if (value == null) {
/* 358 */       throw new InvalidInfoNodeException(I18N.getLocalMessage("i18n.mityc.policy.general.17"));
/*     */     }
/*     */     
/* 361 */     ConfigFacturae config = getConfig();
/* 362 */     SignaturePolicyIdentifier resultado = new SignaturePolicyIdentifier(schema, false);
/* 363 */     resultado.getSignaturePolicyId().setSigPolicyId(new SigPolicyId(schema, config.getPolicyIdXades(), config.getPolicyDescription()));
/* 364 */     resultado.getSignaturePolicyId().setSigPolicyHash(new SigPolicyHash(schema, value));
/* 365 */     return resultado;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void escribePolicy(Element signatureNode, String namespaceDS, String namespaceXAdES, XAdESSchemas schema)
/*     */     throws PolicyException
/*     */   {
/* 378 */     ConfigFacturae config = getConfig();
/*     */     
/*     */     try
/*     */     {
/* 382 */       if ((config.getPolicyWriterId() < 0) || (config.getPolicyWriterId() >= config.getHuellas().size())) {
/* 383 */         throw new InvalidInfoNodeException(I18N.getLocalMessage("i18n.mityc.policy.general.18"));
/*     */       }
/* 385 */       DigestAlgAndValueType hash = (DigestAlgAndValueType)config.getHuellas().get(config.getPolicyWriterId());
/*     */       
/* 387 */       spi = createPolicy(schema, hash);
/*     */     } catch (InvalidInfoNodeException ex) { SignaturePolicyIdentifier spi;
/* 389 */       throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.general.19")); }
/*     */     SignaturePolicyIdentifier spi;
/* 391 */     PoliciesTool.insertPolicyNode(signatureNode, namespaceDS, namespaceXAdES, schema, spi);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static String getFormatedMessage(String message, Object... varargs)
/*     */   {
/* 401 */     MessageFormat mf = new MessageFormat(message);
/* 402 */     return mf.format(varargs, new StringBuffer(), null).toString();
/*     */   }
/*     */   
/*     */   protected abstract ConfigFacturae getConfig();
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibPolicy-1.1.7.jar!\es\mityc\javasign\xml\xades\policy\facturae\FacturaeManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */