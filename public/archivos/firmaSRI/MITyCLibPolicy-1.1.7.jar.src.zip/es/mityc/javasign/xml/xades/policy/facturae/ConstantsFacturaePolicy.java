package es.mityc.javasign.xml.xades.policy.facturae;

public final class ConstantsFacturaePolicy
{
  public static final String PROPNAME_HASH_ID = "policy.digest.id.";
  public static final String PROPNAME_HASH_VALUE = "policy.digest.value.";
  public static final String PROPNAME_SCHEMA_URI = "xades.schema.uri.";
  public static final String PROPNAME_POLICY_ID = "policy.id";
  public static final String PROPNAME_POLICY_ID_VALIDADOR = "policy.idValidator";
  public static final String PROPNAME_POLICY_DESCRIPTION = "policy.description";
  public static final String PROPNAME_WRITER_HASH = "policy.writer.digest";
  public static final String I18N_POLICY_FACTURAE_1 = "i18n.mityc.policy.facturae.1";
  public static final String I18N_POLICY_FACTURAE_2 = "i18n.mityc.policy.facturae.2";
  public static final String I18N_POLICY_FACTURAE_3 = "i18n.mityc.policy.facturae.3";
  public static final String I18N_POLICY_FACTURAE_4 = "i18n.mityc.policy.facturae.4";
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibPolicy-1.1.7.jar!\es\mityc\javasign\xml\xades\policy\facturae\ConstantsFacturaePolicy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */