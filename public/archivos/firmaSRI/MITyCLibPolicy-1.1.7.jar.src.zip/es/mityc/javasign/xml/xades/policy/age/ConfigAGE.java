/*     */ package es.mityc.javasign.xml.xades.policy.age;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.DigestAlgAndValueType;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SigPolicyHash;
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigAGE
/*     */ {
/*  41 */   private static final Log LOG = LogFactory.getLog(ConfigAGE.class);
/*     */   
/*  43 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibPolicy");
/*     */   
/*     */ 
/*     */   private static final String STRING_POINT = ".";
/*     */   
/*     */   private static final String STRING_EMPTY = "";
/*     */   
/*     */   private static final String SP_URI_KEY = "policy.spuri";
/*     */   
/*  52 */   private URI policyIdXades = null;
/*     */   
/*  54 */   private URI spUri = null;
/*     */   
/*  56 */   private String policyIdValidador = null;
/*     */   
/*  58 */   private String policyDescription = null;
/*     */   
/*  60 */   private ArrayList<DigestAlgAndValueType> huellas = null;
/*     */   
/*  62 */   private int policyWriterId = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConfigAGE(Properties props, String prefix)
/*     */     throws ConfigAgeException
/*     */   {
/*  72 */     if (LOG.isDebugEnabled()) {
/*  73 */       LOG.debug("Se carga la configuración de políticas de la AGE: " + prefix);
/*     */     }
/*  75 */     String prep = "";
/*  76 */     if ((prefix != null) && (!"".equals(prefix.trim()))) {
/*  77 */       prep = prefix + ".";
/*     */     }
/*     */     try
/*     */     {
/*  81 */       URI policyIdXadesStr = new URI(props.getProperty(prep + "policy.id"));
/*  82 */       this.policyIdValidador = props.getProperty(prep + "policy.idValidator");
/*  83 */       if ((policyIdXadesStr == null) || (this.policyIdValidador == null)) {
/*  84 */         LOG.fatal(I18N.getLocalMessage("i18n.mityc.policy.general.1"));
/*  85 */         throw new ConfigAgeException(I18N.getLocalMessage("i18n.mityc.policy.general.2"));
/*     */       }
/*  87 */       this.policyIdXades = policyIdXadesStr;
/*     */     } catch (URISyntaxException ex) {
/*  89 */       LOG.fatal(I18N.getLocalMessage("i18n.mityc.policy.general.3"));
/*  90 */       throw new ConfigAgeException(I18N.getLocalMessage("i18n.mityc.policy.general.2"), ex);
/*     */     }
/*     */     try
/*     */     {
/*  94 */       this.policyDescription = props.getProperty(prep + "policy.idValidator");
/*     */     } catch (MissingResourceException ex) {
/*  96 */       if (LOG.isTraceEnabled()) {
/*  97 */         LOG.trace(I18N.getLocalMessage("i18n.mityc.policy.general.4", new Object[] { prep }));
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 103 */       String value = props.getProperty(prep + "policy.spuri");
/* 104 */       this.spUri = new URI(value);
/*     */     } catch (URISyntaxException ex) {
/* 106 */       LOG.fatal(I18N.getLocalMessage("i18n.mityc.policy.general.3"));
/* 107 */       throw new ConfigAgeException(I18N.getLocalMessage("i18n.mityc.policy.general.2"), ex);
/*     */     }
/*     */     
/*     */ 
/* 111 */     this.huellas = new ArrayList();
/* 112 */     int i = 0;
/*     */     for (;;) {
/* 114 */       String hashId = props.getProperty(prep + "policy.digest.id." + i);
/* 115 */       String hashValue = props.getProperty(prep + "policy.digest.value." + i);
/* 116 */       if ((hashId == null) || (hashValue == null)) break;
/* 117 */       this.huellas.add(new SigPolicyHash(null, hashId, hashValue));
/* 118 */       i++;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 125 */       String policyWriterIdStr = props.getProperty(prep + "policy.writer.digest");
/* 126 */       if (policyWriterIdStr == null) {
/* 127 */         if (LOG.isTraceEnabled()) {
/* 128 */           LOG.trace(I18N.getLocalMessage("i18n.mityc.policy.general.6", new Object[] { prep }));
/*     */         }
/*     */       } else {
/* 131 */         this.policyWriterId = Integer.parseInt(policyWriterIdStr);
/* 132 */         if (this.policyWriterId >= this.huellas.size()) {
/* 133 */           this.policyWriterId = -1;
/* 134 */           LOG.error(I18N.getLocalMessage("i18n.mityc.policy.general.5"));
/*     */         }
/*     */       }
/*     */     } catch (NumberFormatException ex) {
/* 138 */       LOG.error(I18N.getLocalMessage("i18n.mityc.policy.general.5"), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public URI getPolicyIdXades()
/*     */   {
/* 147 */     return this.policyIdXades;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public URI getSpUri()
/*     */   {
/* 154 */     return this.spUri;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPolicyIdValidador()
/*     */   {
/* 162 */     return this.policyIdValidador;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPolicyDescription()
/*     */   {
/* 170 */     return this.policyDescription;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPolicyWriterId()
/*     */   {
/* 178 */     return this.policyWriterId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ArrayList<DigestAlgAndValueType> getHuellas()
/*     */   {
/* 186 */     return this.huellas;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibPolicy-1.1.7.jar!\es\mityc\javasign\xml\xades\policy\age\ConfigAGE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */