/*     */ package es.mityc.javasign.xml.xades.policy.age;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.utilidades.UtilidadTratarNodo;
/*     */ import es.mityc.firmaJava.libreria.xades.DatosFirma;
/*     */ import es.mityc.firmaJava.libreria.xades.DatosNodosFirmados;
/*     */ import es.mityc.firmaJava.libreria.xades.ResultadoValidacion;
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.DigestAlgAndValueType;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SPURI;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SigPolicyHash;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SigPolicyId;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SigPolicyQualifier;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SigPolicyQualifiers;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SignaturePolicyId;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xades.SignaturePolicyIdentifier;
/*     */ import es.mityc.firmaJava.libreria.xades.elementos.xmldsig.DigestMethod;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.InvalidInfoNodeException;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.PolicyException;
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.trust.TrustAbstract;
/*     */ import es.mityc.javasign.trust.TrustException;
/*     */ import es.mityc.javasign.trust.TrustFactory;
/*     */ import es.mityc.javasign.xml.xades.TransformProxy;
/*     */ import es.mityc.javasign.xml.xades.policy.IFirmaPolicy;
/*     */ import es.mityc.javasign.xml.xades.policy.IValidacionPolicy;
/*     */ import es.mityc.javasign.xml.xades.policy.PoliciesTool;
/*     */ import es.mityc.javasign.xml.xades.policy.UnknownPolicyException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AgeManager
/*     */   implements IValidacionPolicy, IFirmaPolicy
/*     */ {
/*  70 */   private static final Log LOG = LogFactory.getLog(AgeManager.class);
/*     */   
/*  72 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibPolicy");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String CONFIG_FILENAME = "age.properties";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static final String URI_ID_POLICY = "text:{0}";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static final String UTF_8 = "UTF-8";
/*     */   
/*     */ 
/*     */ 
/*  91 */   private static Properties rb = null;
/*     */   
/*     */ 
/*  94 */   protected TrustAbstract truster = null;
/*     */   
/*     */   static {
/*     */     try {
/*  98 */       InputStream is = AgeManager.class.getResourceAsStream("age.properties");
/*  99 */       if (is != null) {
/* 100 */         rb = new Properties();
/* 101 */         rb.load(is);
/*     */       } else {
/* 103 */         LOG.error("No se encontró configuración sobre políticas");
/*     */       }
/*     */     } catch (IOException ex) {
/* 106 */       LOG.fatal(I18N.getLocalMessage("i18n.mityc.policy.general.12"), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AgeManager()
/*     */     throws InstantiationException
/*     */   {
/* 116 */     this.truster = TrustFactory.getInstance().getTruster("mityc");
/* 117 */     if (this.truster == null) {
/* 118 */       throw new InstantiationException(I18N.getLocalMessage("i18n.mityc.policy.general.29"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static ConfigAGE loadConfig(String prefix)
/*     */     throws ConfigAgeException
/*     */   {
/* 130 */     if (rb == null) {
/* 131 */       throw new ConfigAgeException(I18N.getLocalMessage("i18n.mityc.policy.general.13"));
/*     */     }
/* 133 */     return new ConfigAGE(rb, prefix);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private DigestAlgAndValueType getDigestRelated(String algorithm)
/*     */   {
/* 143 */     DigestAlgAndValueType daavt = null;
/* 144 */     Iterator<DigestAlgAndValueType> it = getConfig().getHuellas().iterator();
/* 145 */     while (it.hasNext()) {
/* 146 */       DigestAlgAndValueType temp = (DigestAlgAndValueType)it.next();
/* 147 */       if (temp.getDigestMethod().getAlgorithm().equals(algorithm)) {
/* 148 */         daavt = temp;
/* 149 */         break;
/*     */       }
/*     */     }
/* 152 */     return daavt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkPolicyHash(Element signatureNode, ResultadoValidacion rs)
/*     */     throws PolicyException
/*     */   {
/* 163 */     XAdESSchemas schema = rs.getDatosFirma().getEsquema();
/* 164 */     if (schema == null) {
/* 165 */       throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.general.25"));
/*     */     }
/* 167 */     String esquema = schema.getSchemaUri();
/*     */     
/*     */ 
/* 170 */     NodeList signaturePolicyList = signatureNode.getElementsByTagNameNS(esquema, "SignaturePolicyIdentifier");
/* 171 */     if (signaturePolicyList.getLength() != 1) {
/* 172 */       throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.general.26"));
/*     */     }
/* 174 */     if (signaturePolicyList.item(0).getNodeType() != 1) {
/* 175 */       throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.general.26"));
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 180 */       SignaturePolicyIdentifier signaturePolicyIdentifier = new SignaturePolicyIdentifier(schema);
/* 181 */       if (!signaturePolicyIdentifier.isThisNode(signaturePolicyList.item(0))) {
/* 182 */         throw new InvalidInfoNodeException(I18N.getLocalMessage("i18n.mityc.policy.general.14"));
/*     */       }
/* 184 */       signaturePolicyIdentifier.load((Element)signaturePolicyList.item(0));
/*     */       
/* 186 */       if (signaturePolicyIdentifier.isImplied()) {
/* 187 */         throw new InvalidInfoNodeException(I18N.getLocalMessage("i18n.mityc.policy.general.15"));
/*     */       }
/*     */       
/* 190 */       DigestAlgAndValueType value = getDigestRelated(signaturePolicyIdentifier.getSignaturePolicyId().getSigPolicyHash().getDigestMethod().getAlgorithm());
/* 191 */       SignaturePolicyIdentifier comp = createPolicy(schema, value);
/*     */       
/* 193 */       if (!signaturePolicyIdentifier.equals(comp)) {
/* 194 */         throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.general.27"));
/*     */       }
/*     */     } catch (InvalidInfoNodeException ex) {
/* 197 */       if (LOG.isDebugEnabled()) {
/* 198 */         LOG.debug(I18N.getLocalMessage("i18n.mityc.policy.general.16"), ex);
/*     */       }
/* 200 */       throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.general.28", new Object[] { ex.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkNodes(Element signatureNode, ResultadoValidacion rs)
/*     */     throws PolicyException
/*     */   {
/* 216 */     NodeList nl = null;
/* 217 */     boolean hasTime = false;
/* 218 */     boolean hasCert = false;
/* 219 */     boolean hasFormat = false;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 232 */     nl = signatureNode.getElementsByTagName("SigningTime");
/* 233 */     if (nl != null) {
/* 234 */       hasTime = true;
/*     */     }
/* 236 */     nl = signatureNode.getElementsByTagName("SigningCertificate");
/* 237 */     if (nl != null) {
/* 238 */       hasCert = true;
/*     */     }
/* 240 */     nl = signatureNode.getElementsByTagName("DataObjectFormat");
/* 241 */     if (nl != null) {
/* 242 */       hasFormat = true;
/*     */     }
/* 244 */     if ((hasTime) && (hasCert) && (hasFormat)) {
/* 245 */       return;
/*     */     }
/* 247 */     throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.age.2"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkCertificateInKeyInfoNode(Element signatureNode, ResultadoValidacion rs)
/*     */     throws UnknownPolicyException, PolicyException
/*     */   {
/* 259 */     List<DatosNodosFirmados> nodos = rs.getDatosFirma().getDatosNodosFirmados();
/* 260 */     for (DatosNodosFirmados nodo : nodos)
/*     */     {
/* 262 */       String id = nodo.getId();
/* 263 */       if (id != null) {
/* 264 */         Element el = UtilidadTratarNodo.getElementById(signatureNode.getOwnerDocument(), id);
/*     */         
/* 266 */         if ((el != null) && 
/* 267 */           ("http://www.w3.org/2000/09/xmldsig#".equals(el.getNamespaceURI())) && 
/* 268 */           ("KeyInfo".equals(el.getLocalName())))
/*     */         {
/* 270 */           if (el.getParentNode().equals(signatureNode))
/*     */           {
/* 272 */             List<TransformProxy> trans = nodo.getTransforms();
/* 273 */             for (TransformProxy transform : trans) {
/* 274 */               if (!TransformProxy.isCanonicalization(transform)) {
/* 275 */                 throw new UnknownPolicyException(I18N.getLocalMessage("i18n.mityc.policy.age.4"));
/*     */               }
/*     */             }
/* 278 */             return;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 283 */     throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.general.30"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkRoles(Element signatureNode, ResultadoValidacion rs)
/*     */     throws PolicyException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkTimestamp(Element signatureNode, ResultadoValidacion rs)
/*     */     throws PolicyException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkStatusCertificate(Element signatureNode, ResultadoValidacion rs)
/*     */     throws PolicyException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkTrustSigningCertificate(Element signatureNode, ResultadoValidacion rs)
/*     */     throws PolicyException
/*     */   {
/* 349 */     DatosFirma df = rs.getDatosFirma();
/* 350 */     if (df != null) {
/*     */       try {
/* 352 */         this.truster.isTrusted(df.getCadenaFirma());
/*     */       } catch (TrustException ex) {
/* 354 */         throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.age.1"));
/*     */       }
/*     */       
/*     */     } else {
/* 358 */       throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.general.20"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkTrustTsa(Element signatureNode, ResultadoValidacion rs)
/*     */     throws PolicyException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected SignaturePolicyIdentifier createPolicy(XAdESSchemas schema, DigestAlgAndValueType value)
/*     */     throws InvalidInfoNodeException
/*     */   {
/* 380 */     if (value == null) {
/* 381 */       throw new InvalidInfoNodeException(I18N.getLocalMessage("i18n.mityc.policy.general.17"));
/*     */     }
/*     */     
/* 384 */     ConfigAGE config = getConfig();
/* 385 */     SignaturePolicyIdentifier resultado = new SignaturePolicyIdentifier(schema, false);
/* 386 */     resultado.getSignaturePolicyId().setSigPolicyId(new SigPolicyId(schema, config.getPolicyIdXades(), config.getPolicyDescription()));
/* 387 */     resultado.getSignaturePolicyId().setSigPolicyHash(new SigPolicyHash(schema, value));
/* 388 */     ArrayList<SigPolicyQualifier> lista = new ArrayList();
/* 389 */     SPURI spUri = new SPURI(schema, config.getSpUri());
/* 390 */     spUri.setNamespaceXAdES(value.getNamespaceXAdES());
/* 391 */     lista.add(new SigPolicyQualifier(schema, spUri));
/* 392 */     SigPolicyQualifiers qualifiers = new SigPolicyQualifiers(schema, lista);
/* 393 */     resultado.getSignaturePolicyId().setSigPolicyQualifiers(qualifiers);
/* 394 */     return resultado;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void escribePolicy(Element signatureNode, String namespaceDS, String namespaceXAdES, XAdESSchemas schema)
/*     */     throws PolicyException
/*     */   {
/* 407 */     ConfigAGE config = getConfig();
/*     */     
/*     */     try
/*     */     {
/* 411 */       if ((config.getPolicyWriterId() < 0) || (config.getPolicyWriterId() >= config.getHuellas().size())) {
/* 412 */         throw new InvalidInfoNodeException(I18N.getLocalMessage("i18n.mityc.policy.general.18"));
/*     */       }
/* 414 */       DigestAlgAndValueType hash = (DigestAlgAndValueType)config.getHuellas().get(config.getPolicyWriterId());
/* 415 */       hash.setNamespaceXAdES(namespaceXAdES);
/*     */       
/* 417 */       spi = createPolicy(schema, hash);
/*     */     } catch (InvalidInfoNodeException ex) { SignaturePolicyIdentifier spi;
/* 419 */       throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.general.19")); }
/*     */     SignaturePolicyIdentifier spi;
/* 421 */     PoliciesTool.insertPolicyNode(signatureNode, namespaceDS, namespaceXAdES, schema, spi);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static String getFormatedMessage(String message, Object... varargs)
/*     */   {
/* 431 */     MessageFormat mf = new MessageFormat(message);
/* 432 */     return mf.format(varargs, new StringBuffer(), null).toString();
/*     */   }
/*     */   
/*     */   protected abstract ConfigAGE getConfig();
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibPolicy-1.1.7.jar!\es\mityc\javasign\xml\xades\policy\age\AgeManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */