/*    */ package es.mityc.javasign.xml.xades.policy.age;
/*    */ 
/*    */ import es.mityc.javasign.xml.xades.policy.PolicyException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigAgeException
/*    */   extends PolicyException
/*    */ {
/*    */   static final long serialVersionUID = 1L;
/*    */   
/*    */   public ConfigAgeException() {}
/*    */   
/*    */   public ConfigAgeException(String message, Throwable cause)
/*    */   {
/* 43 */     super(message, cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ConfigAgeException(String message)
/*    */   {
/* 51 */     super(message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ConfigAgeException(Throwable cause)
/*    */   {
/* 59 */     super(cause);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibPolicy-1.1.7.jar!\es\mityc\javasign\xml\xades\policy\age\ConfigAgeException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */