package es.mityc.javasign.xml.xades.policy;

public final class ConstantsPolicy
{
  public static final String LIB_NAME = "MITyCLibPolicy";
  public static final String I18N_POLICY_NO_TRANSFORMS_1 = "i18n.mityc.policy.notransforms.1";
  public static final String I18N_POLICY_NO_TRANSFORMS_2 = "i18n.mityc.policy.notransforms.2";
  public static final String I18N_POLICY_MITYC_TRUST_1 = "i18n.mityc.policy.mityc.1";
  public static final String I18N_POLICY_MITYC_TRUST_2 = "i18n.mityc.policy.mityc.2";
  public static final String I18N_POLICY_MITYC_TRUST_3 = "i18n.mityc.policy.mityc.3";
  public static final String I18N_POLICY_MITYC_TRUST_4 = "i18n.mityc.policy.mityc.4";
  public static final String I18N_POLICY_GENERAL_1 = "i18n.mityc.policy.general.1";
  public static final String I18N_POLICY_GENERAL_2 = "i18n.mityc.policy.general.2";
  public static final String I18N_POLICY_GENERAL_3 = "i18n.mityc.policy.general.3";
  public static final String I18N_POLICY_GENERAL_4 = "i18n.mityc.policy.general.4";
  public static final String I18N_POLICY_GENERAL_5 = "i18n.mityc.policy.general.5";
  public static final String I18N_POLICY_GENERAL_6 = "i18n.mityc.policy.general.6";
  public static final String I18N_POLICY_GENERAL_7 = "i18n.mityc.policy.general.7";
  public static final String I18N_POLICY_GENERAL_8 = "i18n.mityc.policy.general.8";
  public static final String I18N_POLICY_GENERAL_9 = "i18n.mityc.policy.general.9";
  public static final String I18N_POLICY_GENERAL_10 = "i18n.mityc.policy.general.10";
  public static final String I18N_POLICY_GENERAL_11 = "i18n.mityc.policy.general.11";
  public static final String I18N_POLICY_GENERAL_12 = "i18n.mityc.policy.general.12";
  public static final String I18N_POLICY_GENERAL_13 = "i18n.mityc.policy.general.13";
  public static final String I18N_POLICY_GENERAL_14 = "i18n.mityc.policy.general.14";
  public static final String I18N_POLICY_GENERAL_15 = "i18n.mityc.policy.general.15";
  public static final String I18N_POLICY_GENERAL_16 = "i18n.mityc.policy.general.16";
  public static final String I18N_POLICY_GENERAL_17 = "i18n.mityc.policy.general.17";
  public static final String I18N_POLICY_GENERAL_18 = "i18n.mityc.policy.general.18";
  public static final String I18N_POLICY_GENERAL_19 = "i18n.mityc.policy.general.19";
  public static final String I18N_POLICY_GENERAL_20 = "i18n.mityc.policy.general.20";
  public static final String I18N_POLICY_GENERAL_21 = "i18n.mityc.policy.general.21";
  public static final String I18N_POLICY_GENERAL_22 = "i18n.mityc.policy.general.22";
  public static final String I18N_POLICY_GENERAL_23 = "i18n.mityc.policy.general.23";
  public static final String I18N_POLICY_GENERAL_24 = "i18n.mityc.policy.general.24";
  public static final String I18N_POLICY_GENERAL_25 = "i18n.mityc.policy.general.25";
  public static final String I18N_POLICY_GENERAL_26 = "i18n.mityc.policy.general.26";
  public static final String I18N_POLICY_GENERAL_27 = "i18n.mityc.policy.general.27";
  public static final String I18N_POLICY_GENERAL_28 = "i18n.mityc.policy.general.28";
  public static final String I18N_POLICY_GENERAL_29 = "i18n.mityc.policy.general.29";
  public static final String I18N_POLICY_GENERAL_30 = "i18n.mityc.policy.general.30";
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibPolicy-1.1.7.jar!\es\mityc\javasign\xml\xades\policy\ConstantsPolicy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */