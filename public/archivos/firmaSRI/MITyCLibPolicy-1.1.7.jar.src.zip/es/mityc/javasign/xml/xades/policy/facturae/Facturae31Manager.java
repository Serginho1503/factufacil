/*     */ package es.mityc.javasign.xml.xades.policy.facturae;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.utilidades.URIEncoder;
/*     */ import es.mityc.firmaJava.libreria.xades.DatosFirma;
/*     */ import es.mityc.firmaJava.libreria.xades.ResultadoValidacion;
/*     */ import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.PolicyException;
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.trust.TrustAbstract;
/*     */ import es.mityc.javasign.xml.xades.policy.PolicyResult;
/*     */ import es.mityc.javasign.xml.xades.policy.PolicyResult.DownloadPolicy;
/*     */ import es.mityc.javasign.xml.xades.policy.PolicyResult.StatusValidation;
/*     */ import es.mityc.javasign.xml.xades.policy.UnknownPolicyException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Facturae31Manager
/*     */   extends FacturaeManager
/*     */ {
/*  46 */   private static final Log LOG = LogFactory.getLog(Facturae31Manager.class);
/*     */   
/*  48 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibPolicy");
/*     */   
/*     */ 
/*     */   private static final String PREFIX_POLICY_PROP = "facturae31";
/*     */   
/*  53 */   private static ConfigFacturae config = null;
/*     */   
/*     */   static {
/*     */     try {
/*  57 */       config = FacturaeManager.loadConfig("facturae31");
/*     */     } catch (ConfigFacturaeException ex) {
/*  59 */       LOG.fatal(I18N.getLocalMessage("i18n.mityc.policy.general.7"), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Facturae31Manager()
/*     */     throws InstantiationException
/*     */   {
/*  69 */     if (config == null) {
/*  70 */       throw new InstantiationException(I18N.getLocalMessage("i18n.mityc.policy.general.8"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ConfigFacturae getConfig()
/*     */   {
/*  81 */     return config;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getIdentidadPolicy()
/*     */   {
/*  91 */     return config.getPolicyIdValidador();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PolicyResult validaPolicy(Element nodoFirma, ResultadoValidacion resultadoValidacion)
/*     */   {
/* 131 */     PolicyResult pr = new PolicyResult();
/* 132 */     if (LOG.isDebugEnabled()) {
/* 133 */       LOG.debug("Validando política de factura 3.1");
/*     */     }
/*     */     try {
/* 136 */       URI id = config.getPolicyIdXades();
/*     */       try
/*     */       {
/* 139 */         id = new URI(getFormatedMessage("text:{0}", new Object[] { URIEncoder.encode(config.getPolicyIdValidador(), "UTF-8") }));
/*     */       } catch (URISyntaxException ex) {
/* 141 */         LOG.warn(I18N.getLocalMessage("i18n.mityc.policy.general.9"), ex);
/*     */       } catch (UnsupportedEncodingException ex) {
/* 143 */         LOG.warn(I18N.getLocalMessage("i18n.mityc.policy.general.9"), ex);
/*     */       }
/*     */       
/* 146 */       pr.setPolicyID(id);
/*     */       
/*     */ 
/* 149 */       pr.setDownloable(new PolicyResult.DownloadPolicy[] { pr.newDownloadPolicy(config.getPolicyIdXades(), PolicyResult.StatusValidation.unknown) });
/*     */       
/* 151 */       checkSchema(nodoFirma, resultadoValidacion);
/*     */       
/* 153 */       checkPolicyHash(nodoFirma, resultadoValidacion);
/*     */       
/* 155 */       checkEnveloped(nodoFirma, resultadoValidacion);
/*     */       
/* 157 */       checkCertificateInKeyInfoNode(nodoFirma, resultadoValidacion);
/*     */       
/* 159 */       checkRoles(nodoFirma, resultadoValidacion);
/*     */       
/* 161 */       checkTimestamp(nodoFirma, resultadoValidacion);
/*     */       
/* 163 */       checkStatusCertificate(nodoFirma, resultadoValidacion);
/*     */       
/* 165 */       checkTrustSigningCertificate(nodoFirma, resultadoValidacion);
/*     */       
/* 167 */       checkTrustTsa(nodoFirma, resultadoValidacion);
/*     */       
/* 169 */       pr.setResult(PolicyResult.StatusValidation.valid);
/*     */     } catch (UnknownPolicyException ex) {
/* 171 */       pr.setResult(PolicyResult.StatusValidation.unknown);
/* 172 */       pr.setDescriptionResult(ex.getMessage());
/*     */     } catch (PolicyException ex) {
/* 174 */       pr.setResult(PolicyResult.StatusValidation.invalid);
/* 175 */       pr.setDescriptionResult(ex.getMessage());
/*     */     }
/*     */     
/* 178 */     return pr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkSchema(Element nodoFirma, ResultadoValidacion rs)
/*     */     throws PolicyException
/*     */   {
/* 190 */     DatosFirma df = rs.getDatosFirma();
/* 191 */     if (df != null) {
/* 192 */       XAdESSchemas schema = df.getEsquema();
/* 193 */       if ((!XAdESSchemas.XAdES_122.equals(schema)) && 
/* 194 */         (!XAdESSchemas.XAdES_132.equals(schema))) {
/* 195 */         throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.general.24"));
/*     */       }
/*     */     }
/*     */     else {
/* 199 */       throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.general.23"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writePolicyNode(Element nodoFirma, String namespaceDS, String namespaceXAdES, XAdESSchemas schema)
/*     */     throws PolicyException
/*     */   {
/* 213 */     escribePolicy(nodoFirma, namespaceDS, namespaceXAdES, schema);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTruster(TrustAbstract truster)
/*     */   {
/* 220 */     if (truster != null) {
/* 221 */       this.truster = truster;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibPolicy-1.1.7.jar!\es\mityc\javasign\xml\xades\policy\facturae\Facturae31Manager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */