/*     */ package es.mityc.javasign.xml.xades.policy;
/*     */ 
/*     */ import es.mityc.firmaJava.libreria.xades.DatosFirma;
/*     */ import es.mityc.firmaJava.libreria.xades.ResultadoValidacion;
/*     */ import es.mityc.firmaJava.libreria.xades.errores.PolicyException;
/*     */ import es.mityc.javasign.i18n.I18nFactory;
/*     */ import es.mityc.javasign.i18n.II18nManager;
/*     */ import es.mityc.javasign.trust.TrustAbstract;
/*     */ import es.mityc.javasign.trust.TrustException;
/*     */ import es.mityc.javasign.trust.TrustFactory;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MITyCTrustPolicy
/*     */   implements IValidacionPolicy
/*     */ {
/*  43 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibPolicy");
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String POLICY_URI = "self:policy/mityc/trust";
/*     */   
/*     */ 
/*     */   protected TrustAbstract truster;
/*     */   
/*     */ 
/*     */ 
/*     */   public MITyCTrustPolicy()
/*     */     throws InstantiationException
/*     */   {
/*  57 */     this.truster = TrustFactory.getInstance().getTruster("mityc");
/*  58 */     if (this.truster == null) {
/*  59 */       throw new InstantiationException(I18N.getLocalMessage("i18n.mityc.policy.mityc.1"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getIdentidadPolicy()
/*     */   {
/*  69 */     return I18N.getLocalMessage("i18n.mityc.policy.mityc.2");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PolicyResult validaPolicy(Element nodoFirma, ResultadoValidacion resultadoValidacion)
/*     */   {
/*  80 */     PolicyResult pr = new PolicyResult();
/*     */     try
/*     */     {
/*  83 */       pr.setPolicyID(new URI("self:policy/mityc/trust"));
/*  84 */       checkTrustSigningCertificate(nodoFirma, resultadoValidacion);
/*  85 */       pr.setResult(PolicyResult.StatusValidation.valid);
/*     */     } catch (PolicyException ex) {
/*  87 */       pr.setResult(PolicyResult.StatusValidation.invalid);
/*  88 */       pr.setDescriptionResult(ex.getMessage());
/*     */     } catch (URISyntaxException ex) {
/*  90 */       pr.setResult(PolicyResult.StatusValidation.unknown);
/*  91 */       pr.setDescriptionResult(ex.getMessage());
/*     */     }
/*     */     
/*  94 */     return pr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkTrustSigningCertificate(Element signatureNode, ResultadoValidacion rs)
/*     */     throws PolicyException
/*     */   {
/* 105 */     DatosFirma df = rs.getDatosFirma();
/* 106 */     if (df != null) {
/*     */       try {
/* 108 */         this.truster.isTrusted(df.getCadenaFirma());
/*     */       } catch (TrustException ex) {
/* 110 */         throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.mityc.3"));
/*     */       }
/*     */       
/*     */     } else {
/* 114 */       throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.mityc.4"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTruster(TrustAbstract truster)
/*     */   {
/* 122 */     this.truster = truster;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibPolicy-1.1.7.jar!\es\mityc\javasign\xml\xades\policy\MITyCTrustPolicy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */