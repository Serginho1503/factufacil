/*    */ package es.mityc.javasign.xml.xades.policy;
/*    */ 
/*    */ import es.mityc.firmaJava.libreria.xades.DatosFirma;
/*    */ import es.mityc.firmaJava.libreria.xades.DatosNodosFirmados;
/*    */ import es.mityc.firmaJava.libreria.xades.ResultadoValidacion;
/*    */ import es.mityc.firmaJava.libreria.xades.errores.PolicyException;
/*    */ import es.mityc.javasign.i18n.I18nFactory;
/*    */ import es.mityc.javasign.i18n.II18nManager;
/*    */ import es.mityc.javasign.trust.TrustAbstract;
/*    */ import es.mityc.javasign.xml.xades.TransformProxy;
/*    */ import java.net.URI;
/*    */ import java.net.URISyntaxException;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoTransformsPolicy
/*    */   implements IValidacionPolicy
/*    */ {
/* 42 */   private static final II18nManager I18N = I18nFactory.getI18nManager("MITyCLibPolicy");
/*    */   
/*    */ 
/*    */ 
/*    */   private static final String POLICY_URI = "self:policy/general/notransforms";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getIdentidadPolicy()
/*    */   {
/* 53 */     return I18N.getLocalMessage("i18n.mityc.policy.notransforms.2");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PolicyResult validaPolicy(Element nodoFirma, ResultadoValidacion resultadoValidacion)
/*    */   {
/* 64 */     PolicyResult pr = new PolicyResult();
/*    */     try
/*    */     {
/* 67 */       pr.setPolicyID(new URI("self:policy/general/notransforms"));
/* 68 */       checkNoTransforms(nodoFirma, resultadoValidacion);
/* 69 */       pr.setResult(PolicyResult.StatusValidation.valid);
/*    */     } catch (PolicyException ex) {
/* 71 */       pr.setResult(PolicyResult.StatusValidation.invalid);
/* 72 */       pr.setDescriptionResult(ex.getMessage());
/*    */     } catch (URISyntaxException ex) {
/* 74 */       pr.setResult(PolicyResult.StatusValidation.unknown);
/* 75 */       pr.setDescriptionResult(ex.getMessage());
/*    */     }
/*    */     
/* 78 */     return pr;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void checkNoTransforms(Element signatureNode, ResultadoValidacion rs)
/*    */     throws PolicyException
/*    */   {
/* 88 */     List<DatosNodosFirmados> nodos = rs.getDatosFirma().getDatosNodosFirmados();
/* 89 */     Iterator localIterator2; for (Iterator localIterator1 = nodos.iterator(); localIterator1.hasNext(); 
/*    */         
/* 91 */         localIterator2.hasNext())
/*    */     {
/* 89 */       DatosNodosFirmados nodo = (DatosNodosFirmados)localIterator1.next();
/* 90 */       List<TransformProxy> trans = nodo.getTransforms();
/* 91 */       localIterator2 = trans.iterator(); continue;TransformProxy transform = (TransformProxy)localIterator2.next();
/* 92 */       String uri = transform.getURI();
/* 93 */       if ((!TransformProxy.isCanonicalization(transform)) && 
/* 94 */         (!uri.equals("http://www.w3.org/2000/09/xmldsig#enveloped-signature")) && 
/* 95 */         (!uri.equals("http://www.w3.org/2000/09/xmldsig#base64")))
/*    */       {
/*    */ 
/* 98 */         throw new PolicyException(I18N.getLocalMessage("i18n.mityc.policy.notransforms.1"));
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void setTruster(TrustAbstract truster) {}
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibPolicy-1.1.7.jar!\es\mityc\javasign\xml\xades\policy\NoTransformsPolicy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */