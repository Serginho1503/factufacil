/*    */ package org.apache.commons.httpclient;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.commons.httpclient.util.ExceptionUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoHttpResponseException
/*    */   extends IOException
/*    */ {
/*    */   public NoHttpResponseException() {}
/*    */   
/*    */   public NoHttpResponseException(String message)
/*    */   {
/* 60 */     super(message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public NoHttpResponseException(String message, Throwable cause)
/*    */   {
/* 73 */     super(message);
/*    */     
/* 75 */     ExceptionUtil.initCause(this, cause);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\NoHttpResponseException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */