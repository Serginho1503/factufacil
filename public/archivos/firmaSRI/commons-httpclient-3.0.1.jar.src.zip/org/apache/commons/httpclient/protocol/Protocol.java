/*     */ package org.apache.commons.httpclient.protocol;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.httpclient.util.LangUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Protocol
/*     */ {
/*  59 */   private static final Map PROTOCOLS = Collections.synchronizedMap(new HashMap());
/*     */   
/*     */ 
/*     */   private String scheme;
/*     */   
/*     */   private ProtocolSocketFactory socketFactory;
/*     */   
/*     */   private int defaultPort;
/*     */   
/*     */   private boolean secure;
/*     */   
/*     */ 
/*     */   public static void registerProtocol(String id, Protocol protocol)
/*     */   {
/*  73 */     if (id == null) {
/*  74 */       throw new IllegalArgumentException("id is null");
/*     */     }
/*  76 */     if (protocol == null) {
/*  77 */       throw new IllegalArgumentException("protocol is null");
/*     */     }
/*     */     
/*  80 */     PROTOCOLS.put(id, protocol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void unregisterProtocol(String id)
/*     */   {
/*  90 */     if (id == null) {
/*  91 */       throw new IllegalArgumentException("id is null");
/*     */     }
/*     */     
/*  94 */     PROTOCOLS.remove(id);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Protocol getProtocol(String id)
/*     */     throws IllegalStateException
/*     */   {
/* 109 */     if (id == null) {
/* 110 */       throw new IllegalArgumentException("id is null");
/*     */     }
/*     */     
/* 113 */     Protocol protocol = (Protocol)PROTOCOLS.get(id);
/*     */     
/* 115 */     if (protocol == null) {
/* 116 */       protocol = lazyRegisterProtocol(id);
/*     */     }
/*     */     
/* 119 */     return protocol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Protocol lazyRegisterProtocol(String id)
/*     */     throws IllegalStateException
/*     */   {
/* 134 */     if ("http".equals(id)) {
/* 135 */       Protocol http = new Protocol("http", DefaultProtocolSocketFactory.getSocketFactory(), 80);
/*     */       
/* 137 */       registerProtocol("http", http);
/* 138 */       return http;
/*     */     }
/*     */     
/* 141 */     if ("https".equals(id)) {
/* 142 */       Protocol https = new Protocol("https", SSLProtocolSocketFactory.getSocketFactory(), 443);
/*     */       
/* 144 */       registerProtocol("https", https);
/* 145 */       return https;
/*     */     }
/*     */     
/* 148 */     throw new IllegalStateException("unsupported protocol: '" + id + "'");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Protocol(String scheme, ProtocolSocketFactory factory, int defaultPort)
/*     */   {
/* 175 */     if (scheme == null) {
/* 176 */       throw new IllegalArgumentException("scheme is null");
/*     */     }
/* 178 */     if (factory == null) {
/* 179 */       throw new IllegalArgumentException("socketFactory is null");
/*     */     }
/* 181 */     if (defaultPort <= 0) {
/* 182 */       throw new IllegalArgumentException("port is invalid: " + defaultPort);
/*     */     }
/*     */     
/* 185 */     this.scheme = scheme;
/* 186 */     this.socketFactory = factory;
/* 187 */     this.defaultPort = defaultPort;
/* 188 */     this.secure = (factory instanceof SecureProtocolSocketFactory);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public Protocol(String scheme, SecureProtocolSocketFactory factory, int defaultPort)
/*     */   {
/* 204 */     this(scheme, factory, defaultPort);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDefaultPort()
/*     */   {
/* 212 */     return this.defaultPort;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ProtocolSocketFactory getSocketFactory()
/*     */   {
/* 221 */     return this.socketFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getScheme()
/*     */   {
/* 229 */     return this.scheme;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSecure()
/*     */   {
/* 237 */     return this.secure;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int resolvePort(int port)
/*     */   {
/* 249 */     return port <= 0 ? getDefaultPort() : port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 257 */     return this.scheme + ":" + this.defaultPort;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 267 */     if ((obj instanceof Protocol))
/*     */     {
/* 269 */       Protocol p = (Protocol)obj;
/*     */       
/* 271 */       return (this.defaultPort == p.getDefaultPort()) && (this.scheme.equalsIgnoreCase(p.getScheme())) && (this.secure == p.isSecure()) && (this.socketFactory.equals(p.getSocketFactory()));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 278 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 288 */     int hash = 17;
/* 289 */     hash = LangUtils.hashCode(hash, this.defaultPort);
/* 290 */     hash = LangUtils.hashCode(hash, this.scheme.toLowerCase());
/* 291 */     hash = LangUtils.hashCode(hash, this.secure);
/* 292 */     hash = LangUtils.hashCode(hash, this.socketFactory);
/* 293 */     return hash;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\protocol\Protocol.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */