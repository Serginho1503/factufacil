/*     */ package org.apache.commons.httpclient.params;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
/*     */ import org.apache.commons.httpclient.HttpVersion;
/*     */ import org.apache.commons.httpclient.SimpleHttpConnectionManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultHttpParamsFactory
/*     */   implements HttpParamsFactory
/*     */ {
/*     */   private HttpParams httpParams;
/*     */   
/*     */   public synchronized HttpParams getDefaultParams()
/*     */   {
/*  59 */     if (this.httpParams == null) {
/*  60 */       this.httpParams = createParams();
/*     */     }
/*     */     
/*  63 */     return this.httpParams;
/*     */   }
/*     */   
/*     */   protected HttpParams createParams() {
/*  67 */     HttpClientParams params = new HttpClientParams(null);
/*     */     
/*  69 */     params.setParameter("http.useragent", "Jakarta Commons-HttpClient/3.0.1");
/*  70 */     params.setVersion(HttpVersion.HTTP_1_1);
/*  71 */     params.setConnectionManagerClass(SimpleHttpConnectionManager.class);
/*  72 */     params.setCookiePolicy("rfc2109");
/*  73 */     params.setHttpElementCharset("US-ASCII");
/*  74 */     params.setContentCharset("ISO-8859-1");
/*  75 */     params.setParameter("http.method.retry-handler", new DefaultHttpMethodRetryHandler());
/*     */     
/*  77 */     ArrayList datePatterns = new ArrayList();
/*  78 */     datePatterns.addAll(Arrays.asList(new String[] { "EEE, dd MMM yyyy HH:mm:ss zzz", "EEEE, dd-MMM-yy HH:mm:ss zzz", "EEE MMM d HH:mm:ss yyyy", "EEE, dd-MMM-yyyy HH:mm:ss z", "EEE, dd-MMM-yyyy HH-mm-ss z", "EEE, dd MMM yy HH:mm:ss z", "EEE dd-MMM-yyyy HH:mm:ss z", "EEE dd MMM yyyy HH:mm:ss z", "EEE dd-MMM-yyyy HH-mm-ss z", "EEE dd-MMM-yy HH:mm:ss z", "EEE dd MMM yy HH:mm:ss z", "EEE,dd-MMM-yy HH:mm:ss z", "EEE,dd-MMM-yyyy HH:mm:ss z", "EEE, dd-MM-yyyy HH:mm:ss z" }));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  98 */     params.setParameter("http.dateparser.patterns", datePatterns);
/*     */     
/*     */ 
/* 101 */     String agent = null;
/*     */     try {
/* 103 */       agent = System.getProperty("httpclient.useragent");
/*     */     }
/*     */     catch (SecurityException ignore) {}
/* 106 */     if (agent != null) {
/* 107 */       params.setParameter("http.useragent", agent);
/*     */     }
/*     */     
/*     */ 
/* 111 */     String preemptiveDefault = null;
/*     */     try {
/* 113 */       preemptiveDefault = System.getProperty("httpclient.authentication.preemptive");
/*     */     }
/*     */     catch (SecurityException ignore) {}
/* 116 */     if (preemptiveDefault != null) {
/* 117 */       preemptiveDefault = preemptiveDefault.trim().toLowerCase();
/* 118 */       if (preemptiveDefault.equals("true")) {
/* 119 */         params.setParameter("http.authentication.preemptive", Boolean.TRUE);
/* 120 */       } else if (preemptiveDefault.equals("false")) {
/* 121 */         params.setParameter("http.authentication.preemptive", Boolean.FALSE);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 126 */     String defaultCookiePolicy = null;
/*     */     try {
/* 128 */       defaultCookiePolicy = System.getProperty("apache.commons.httpclient.cookiespec");
/*     */     }
/*     */     catch (SecurityException ignore) {}
/* 131 */     if (defaultCookiePolicy != null) {
/* 132 */       if ("COMPATIBILITY".equalsIgnoreCase(defaultCookiePolicy)) {
/* 133 */         params.setCookiePolicy("compatibility");
/* 134 */       } else if ("NETSCAPE_DRAFT".equalsIgnoreCase(defaultCookiePolicy)) {
/* 135 */         params.setCookiePolicy("netscape");
/* 136 */       } else if ("RFC2109".equalsIgnoreCase(defaultCookiePolicy)) {
/* 137 */         params.setCookiePolicy("rfc2109");
/*     */       }
/*     */     }
/*     */     
/* 141 */     return params;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\params\DefaultHttpParamsFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */