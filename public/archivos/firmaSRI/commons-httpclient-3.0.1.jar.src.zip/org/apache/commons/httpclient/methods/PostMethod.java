/*     */ package org.apache.commons.httpclient.methods;
/*     */ 
/*     */ import java.util.AbstractList;
/*     */ import java.util.Iterator;
/*     */ import java.util.Vector;
/*     */ import org.apache.commons.httpclient.NameValuePair;
/*     */ import org.apache.commons.httpclient.util.EncodingUtil;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PostMethod
/*     */   extends EntityEnclosingMethod
/*     */ {
/*  75 */   private static final Log LOG = LogFactory.getLog(PostMethod.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String FORM_URL_ENCODED_CONTENT_TYPE = "application/x-www-form-urlencoded";
/*     */   
/*     */ 
/*     */ 
/*  84 */   private Vector params = new Vector();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PostMethod() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PostMethod(String uri)
/*     */   {
/* 105 */     super(uri);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 118 */     return "POST";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean hasRequestContent()
/*     */   {
/* 134 */     LOG.trace("enter PostMethod.hasRequestContent()");
/* 135 */     if (!this.params.isEmpty()) {
/* 136 */       return true;
/*     */     }
/* 138 */     return super.hasRequestContent();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void clearRequestBody()
/*     */   {
/* 151 */     LOG.trace("enter PostMethod.clearRequestBody()");
/* 152 */     this.params.clear();
/* 153 */     super.clearRequestBody();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected RequestEntity generateRequestEntity()
/*     */   {
/* 163 */     if (!this.params.isEmpty())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 169 */       String content = EncodingUtil.formUrlEncode(getParameters(), getRequestCharSet());
/* 170 */       ByteArrayRequestEntity entity = new ByteArrayRequestEntity(EncodingUtil.getAsciiBytes(content), "application/x-www-form-urlencoded");
/*     */       
/*     */ 
/*     */ 
/* 174 */       return entity;
/*     */     }
/* 176 */     return super.generateRequestEntity();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParameter(String parameterName, String parameterValue)
/*     */   {
/* 190 */     LOG.trace("enter PostMethod.setParameter(String, String)");
/*     */     
/* 192 */     removeParameter(parameterName);
/* 193 */     addParameter(parameterName, parameterValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NameValuePair getParameter(String paramName)
/*     */   {
/* 209 */     LOG.trace("enter PostMethod.getParameter(String)");
/*     */     
/* 211 */     if (paramName == null) {
/* 212 */       return null;
/*     */     }
/*     */     
/* 215 */     Iterator iter = this.params.iterator();
/*     */     
/* 217 */     while (iter.hasNext()) {
/* 218 */       NameValuePair parameter = (NameValuePair)iter.next();
/*     */       
/* 220 */       if (paramName.equals(parameter.getName())) {
/* 221 */         return parameter;
/*     */       }
/*     */     }
/* 224 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NameValuePair[] getParameters()
/*     */   {
/* 239 */     LOG.trace("enter PostMethod.getParameters()");
/*     */     
/* 241 */     int numPairs = this.params.size();
/* 242 */     Object[] objectArr = this.params.toArray();
/* 243 */     NameValuePair[] nvPairArr = new NameValuePair[numPairs];
/*     */     
/* 245 */     for (int i = 0; i < numPairs; i++) {
/* 246 */       nvPairArr[i] = ((NameValuePair)objectArr[i]);
/*     */     }
/*     */     
/* 249 */     return nvPairArr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addParameter(String paramName, String paramValue)
/*     */     throws IllegalArgumentException
/*     */   {
/* 264 */     LOG.trace("enter PostMethod.addParameter(String, String)");
/*     */     
/* 266 */     if ((paramName == null) || (paramValue == null)) {
/* 267 */       throw new IllegalArgumentException("Arguments to addParameter(String, String) cannot be null");
/*     */     }
/*     */     
/* 270 */     super.clearRequestBody();
/* 271 */     this.params.add(new NameValuePair(paramName, paramValue));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addParameter(NameValuePair param)
/*     */     throws IllegalArgumentException
/*     */   {
/* 286 */     LOG.trace("enter PostMethod.addParameter(NameValuePair)");
/*     */     
/* 288 */     if (param == null) {
/* 289 */       throw new IllegalArgumentException("NameValuePair may not be null");
/*     */     }
/* 291 */     addParameter(param.getName(), param.getValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addParameters(NameValuePair[] parameters)
/*     */   {
/* 303 */     LOG.trace("enter PostMethod.addParameters(NameValuePair[])");
/*     */     
/* 305 */     if (parameters == null) {
/* 306 */       LOG.warn("Attempt to addParameters(null) ignored");
/*     */     } else {
/* 308 */       super.clearRequestBody();
/* 309 */       for (int i = 0; i < parameters.length; i++) {
/* 310 */         this.params.add(parameters[i]);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean removeParameter(String paramName)
/*     */     throws IllegalArgumentException
/*     */   {
/* 331 */     LOG.trace("enter PostMethod.removeParameter(String)");
/*     */     
/* 333 */     if (paramName == null) {
/* 334 */       throw new IllegalArgumentException("Argument passed to removeParameter(String) cannot be null");
/*     */     }
/*     */     
/* 337 */     boolean removed = false;
/* 338 */     Iterator iter = this.params.iterator();
/*     */     
/* 340 */     while (iter.hasNext()) {
/* 341 */       NameValuePair pair = (NameValuePair)iter.next();
/*     */       
/* 343 */       if (paramName.equals(pair.getName())) {
/* 344 */         iter.remove();
/* 345 */         removed = true;
/*     */       }
/*     */     }
/* 348 */     return removed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean removeParameter(String paramName, String paramValue)
/*     */     throws IllegalArgumentException
/*     */   {
/* 367 */     LOG.trace("enter PostMethod.removeParameter(String, String)");
/*     */     
/* 369 */     if (paramName == null) {
/* 370 */       throw new IllegalArgumentException("Parameter name may not be null");
/*     */     }
/* 372 */     if (paramValue == null) {
/* 373 */       throw new IllegalArgumentException("Parameter value may not be null");
/*     */     }
/*     */     
/* 376 */     Iterator iter = this.params.iterator();
/*     */     
/* 378 */     while (iter.hasNext()) {
/* 379 */       NameValuePair pair = (NameValuePair)iter.next();
/*     */       
/* 381 */       if ((paramName.equals(pair.getName())) && (paramValue.equals(pair.getValue())))
/*     */       {
/* 383 */         iter.remove();
/* 384 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 388 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRequestBody(NameValuePair[] parametersBody)
/*     */     throws IllegalArgumentException
/*     */   {
/* 402 */     LOG.trace("enter PostMethod.setRequestBody(NameValuePair[])");
/*     */     
/* 404 */     if (parametersBody == null) {
/* 405 */       throw new IllegalArgumentException("Array of parameters may not be null");
/*     */     }
/* 407 */     clearRequestBody();
/* 408 */     addParameters(parametersBody);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\methods\PostMethod.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */