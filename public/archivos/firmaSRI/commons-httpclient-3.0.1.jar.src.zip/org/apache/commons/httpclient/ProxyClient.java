/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.Socket;
/*     */ import org.apache.commons.httpclient.params.DefaultHttpParams;
/*     */ import org.apache.commons.httpclient.params.HttpClientParams;
/*     */ import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
/*     */ import org.apache.commons.httpclient.params.HttpParams;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProxyClient
/*     */ {
/*  59 */   private HttpState state = new HttpState();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  64 */   private HttpClientParams params = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  70 */   private HostConfiguration hostConfiguration = new HostConfiguration();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ProxyClient()
/*     */   {
/*  78 */     this(new HttpClientParams());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ProxyClient(HttpClientParams params)
/*     */   {
/*  91 */     if (params == null) {
/*  92 */       throw new IllegalArgumentException("Params may not be null");
/*     */     }
/*  94 */     this.params = params;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized HttpState getState()
/*     */   {
/* 106 */     return this.state;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setState(HttpState state)
/*     */   {
/* 116 */     this.state = state;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized HostConfiguration getHostConfiguration()
/*     */   {
/* 126 */     return this.hostConfiguration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setHostConfiguration(HostConfiguration hostConfiguration)
/*     */   {
/* 136 */     this.hostConfiguration = hostConfiguration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized HttpClientParams getParams()
/*     */   {
/* 145 */     return this.params;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setParams(HttpClientParams params)
/*     */   {
/* 154 */     if (params == null) {
/* 155 */       throw new IllegalArgumentException("Parameters may not be null");
/*     */     }
/* 157 */     this.params = params;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConnectResponse connect()
/*     */     throws IOException, HttpException
/*     */   {
/* 182 */     if (getHostConfiguration().getProxyHost() == null) {
/* 183 */       throw new IllegalStateException("proxy host must be configured");
/*     */     }
/* 185 */     if (getHostConfiguration().getHost() == null) {
/* 186 */       throw new IllegalStateException("destination host must be configured");
/*     */     }
/*     */     
/* 189 */     ConnectMethod method = new ConnectMethod();
/* 190 */     method.getParams().setDefaults(getParams());
/*     */     
/* 192 */     DummyConnectionManager connectionManager = new DummyConnectionManager();
/* 193 */     connectionManager.setConnectionParams(getParams());
/*     */     
/* 195 */     HttpMethodDirector director = new HttpMethodDirector(connectionManager, getHostConfiguration(), getParams(), getState());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 202 */     director.executeMethod(method);
/*     */     
/* 204 */     ConnectResponse response = new ConnectResponse(null);
/* 205 */     response.setConnectMethod(method);
/*     */     
/*     */ 
/* 208 */     if (method.getStatusCode() == 200) {
/* 209 */       response.setSocket(connectionManager.getConnection().getSocket());
/*     */     } else {
/* 211 */       connectionManager.getConnection().close();
/*     */     }
/*     */     
/* 214 */     return response;
/*     */   }
/*     */   
/*     */   public static class ConnectResponse { private ConnectMethod connectMethod;
/*     */     private Socket socket;
/*     */     
/* 220 */     ConnectResponse(ProxyClient.1 x0) { this(); }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ConnectMethod getConnectMethod()
/*     */     {
/* 235 */       return this.connectMethod;
/*     */     }
/*     */     
/*     */ 
/*     */     private void setConnectMethod(ConnectMethod connectMethod)
/*     */     {
/* 241 */       this.connectMethod = connectMethod;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Socket getSocket()
/*     */     {
/* 251 */       return this.socket;
/*     */     }
/*     */     
/*     */ 
/*     */     private void setSocket(Socket socket)
/*     */     {
/* 257 */       this.socket = socket;
/*     */     }
/*     */     
/*     */ 
/*     */     private ConnectResponse() {}
/*     */   }
/*     */   
/*     */   static class DummyConnectionManager
/*     */     implements HttpConnectionManager
/*     */   {
/*     */     private HttpConnection httpConnection;
/*     */     private HttpParams connectionParams;
/*     */     
/*     */     public void closeIdleConnections(long idleTimeout) {}
/*     */     
/*     */     public HttpConnection getConnection()
/*     */     {
/* 274 */       return this.httpConnection;
/*     */     }
/*     */     
/*     */     public void setConnectionParams(HttpParams httpParams) {
/* 278 */       this.connectionParams = httpParams;
/*     */     }
/*     */     
/*     */ 
/*     */     public HttpConnection getConnectionWithTimeout(HostConfiguration hostConfiguration, long timeout)
/*     */     {
/* 284 */       this.httpConnection = new HttpConnection(hostConfiguration);
/* 285 */       this.httpConnection.setHttpConnectionManager(this);
/* 286 */       this.httpConnection.getParams().setDefaults(this.connectionParams);
/* 287 */       return this.httpConnection;
/*     */     }
/*     */     
/*     */     /**
/*     */      * @deprecated
/*     */      */
/*     */     public HttpConnection getConnection(HostConfiguration hostConfiguration, long timeout) throws HttpException
/*     */     {
/* 295 */       return getConnectionWithTimeout(hostConfiguration, timeout);
/*     */     }
/*     */     
/*     */     public HttpConnection getConnection(HostConfiguration hostConfiguration) {
/* 299 */       return getConnectionWithTimeout(hostConfiguration, -1L);
/*     */     }
/*     */     
/*     */     public void releaseConnection(HttpConnection conn) {}
/*     */     
/*     */     public HttpConnectionManagerParams getParams()
/*     */     {
/* 306 */       return null;
/*     */     }
/*     */     
/*     */     public void setParams(HttpConnectionManagerParams params) {}
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\ProxyClient.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */