/*     */ package org.apache.commons.httpclient.util;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import org.apache.commons.codec.net.URLCodec;
/*     */ import org.apache.commons.httpclient.HttpClientError;
/*     */ import org.apache.commons.httpclient.NameValuePair;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EncodingUtil
/*     */ {
/*     */   private static final String DEFAULT_CHARSET = "ISO-8859-1";
/*  53 */   private static final Log LOG = LogFactory.getLog(EncodingUtil.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String formUrlEncode(NameValuePair[] pairs, String charset)
/*     */   {
/*     */     try
/*     */     {
/*  80 */       return doFormUrlEncode(pairs, charset);
/*     */     } catch (UnsupportedEncodingException e) {
/*  82 */       LOG.error("Encoding not supported: " + charset);
/*     */       try {
/*  84 */         return doFormUrlEncode(pairs, "ISO-8859-1");
/*     */       }
/*     */       catch (UnsupportedEncodingException fatal) {
/*  87 */         throw new HttpClientError("Encoding not supported: ISO-8859-1");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String doFormUrlEncode(NameValuePair[] pairs, String charset)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 116 */     StringBuffer buf = new StringBuffer();
/* 117 */     for (int i = 0; i < pairs.length; i++) {
/* 118 */       URLCodec codec = new URLCodec();
/* 119 */       NameValuePair pair = pairs[i];
/* 120 */       if (pair.getName() != null) {
/* 121 */         if (i > 0) {
/* 122 */           buf.append("&");
/*     */         }
/* 124 */         buf.append(codec.encode(pair.getName(), charset));
/* 125 */         buf.append("=");
/* 126 */         if (pair.getValue() != null) {
/* 127 */           buf.append(codec.encode(pair.getValue(), charset));
/*     */         }
/*     */       }
/*     */     }
/* 131 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getString(byte[] data, int offset, int length, String charset)
/*     */   {
/* 154 */     if (data == null) {
/* 155 */       throw new IllegalArgumentException("Parameter may not be null");
/*     */     }
/*     */     
/* 158 */     if ((charset == null) || (charset.length() == 0)) {
/* 159 */       throw new IllegalArgumentException("charset may not be null or empty");
/*     */     }
/*     */     try
/*     */     {
/* 163 */       return new String(data, offset, length, charset);
/*     */     }
/*     */     catch (UnsupportedEncodingException e) {
/* 166 */       if (LOG.isWarnEnabled())
/* 167 */         LOG.warn("Unsupported encoding: " + charset + ". System encoding used");
/*     */     }
/* 169 */     return new String(data, offset, length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getString(byte[] data, String charset)
/*     */   {
/* 186 */     return getString(data, 0, data.length, charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] getBytes(String data, String charset)
/*     */   {
/* 201 */     if (data == null) {
/* 202 */       throw new IllegalArgumentException("data may not be null");
/*     */     }
/*     */     
/* 205 */     if ((charset == null) || (charset.length() == 0)) {
/* 206 */       throw new IllegalArgumentException("charset may not be null or empty");
/*     */     }
/*     */     try
/*     */     {
/* 210 */       return data.getBytes(charset);
/*     */     }
/*     */     catch (UnsupportedEncodingException e) {
/* 213 */       if (LOG.isWarnEnabled()) {
/* 214 */         LOG.warn("Unsupported encoding: " + charset + ". System encoding used.");
/*     */       }
/*     */     }
/* 217 */     return data.getBytes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] getAsciiBytes(String data)
/*     */   {
/* 231 */     if (data == null) {
/* 232 */       throw new IllegalArgumentException("Parameter may not be null");
/*     */     }
/*     */     try
/*     */     {
/* 236 */       return data.getBytes("US-ASCII");
/*     */     } catch (UnsupportedEncodingException e) {
/* 238 */       throw new HttpClientError("HttpClient requires ASCII support");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getAsciiString(byte[] data, int offset, int length)
/*     */   {
/* 256 */     if (data == null) {
/* 257 */       throw new IllegalArgumentException("Parameter may not be null");
/*     */     }
/*     */     try
/*     */     {
/* 261 */       return new String(data, offset, length, "US-ASCII");
/*     */     } catch (UnsupportedEncodingException e) {
/* 263 */       throw new HttpClientError("HttpClient requires ASCII support");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getAsciiString(byte[] data)
/*     */   {
/* 278 */     return getAsciiString(data, 0, data.length);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\util\EncodingUtil.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */