/*     */ package org.apache.commons.httpclient.methods;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.commons.httpclient.HttpConnection;
/*     */ import org.apache.commons.httpclient.HttpException;
/*     */ import org.apache.commons.httpclient.HttpMethodBase;
/*     */ import org.apache.commons.httpclient.HttpState;
/*     */ import org.apache.commons.httpclient.HttpVersion;
/*     */ import org.apache.commons.httpclient.params.DefaultHttpParams;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ExpectContinueMethod
/*     */   extends HttpMethodBase
/*     */ {
/*  73 */   private static final Log LOG = LogFactory.getLog(ExpectContinueMethod.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExpectContinueMethod() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExpectContinueMethod(String uri)
/*     */   {
/*  92 */     super(uri);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public boolean getUseExpectHeader()
/*     */   {
/* 117 */     return getParams().getBooleanParameter("http.protocol.expect-continue", false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setUseExpectHeader(boolean value)
/*     */   {
/* 153 */     getParams().setBooleanParameter("http.protocol.expect-continue", value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract boolean hasRequestContent();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addRequestHeaders(HttpState state, HttpConnection conn)
/*     */     throws IOException, HttpException
/*     */   {
/* 182 */     LOG.trace("enter ExpectContinueMethod.addRequestHeaders(HttpState, HttpConnection)");
/*     */     
/* 184 */     super.addRequestHeaders(state, conn);
/*     */     
/* 186 */     boolean headerPresent = getRequestHeader("Expect") != null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 191 */     if ((getParams().isParameterTrue("http.protocol.expect-continue")) && (getEffectiveVersion().greaterEquals(HttpVersion.HTTP_1_1)) && (hasRequestContent()))
/*     */     {
/*     */ 
/*     */ 
/* 195 */       if (!headerPresent) {
/* 196 */         setRequestHeader("Expect", "100-continue");
/*     */       }
/*     */     }
/* 199 */     else if (headerPresent) {
/* 200 */       removeRequestHeader("Expect");
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\methods\ExpectContinueMethod.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */