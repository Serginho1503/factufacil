/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.httpclient.util.ParameterParser;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HeaderElement
/*     */   extends NameValuePair
/*     */ {
/*     */   public HeaderElement()
/*     */   {
/*  94 */     this(null, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HeaderElement(String name, String value)
/*     */   {
/* 103 */     this(name, value, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HeaderElement(String name, String value, NameValuePair[] parameters)
/*     */   {
/* 115 */     super(name, value);
/* 116 */     this.parameters = parameters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HeaderElement(char[] chars, int offset, int length)
/*     */   {
/* 129 */     this();
/* 130 */     if (chars == null) {
/* 131 */       return;
/*     */     }
/* 133 */     ParameterParser parser = new ParameterParser();
/* 134 */     List params = parser.parse(chars, offset, length, ';');
/* 135 */     if (params.size() > 0) {
/* 136 */       NameValuePair element = (NameValuePair)params.remove(0);
/* 137 */       setName(element.getName());
/* 138 */       setValue(element.getValue());
/* 139 */       if (params.size() > 0) {
/* 140 */         this.parameters = ((NameValuePair[])params.toArray(new NameValuePair[params.size()]));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HeaderElement(char[] chars)
/*     */   {
/* 154 */     this(chars, 0, chars.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 160 */   private static final Log LOG = LogFactory.getLog(HeaderElement.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 165 */   private NameValuePair[] parameters = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NameValuePair[] getParameters()
/*     */   {
/* 176 */     return this.parameters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final HeaderElement[] parseElements(char[] headerValue)
/*     */   {
/* 193 */     LOG.trace("enter HeaderElement.parseElements(char[])");
/*     */     
/* 195 */     if (headerValue == null) {
/* 196 */       return new HeaderElement[0];
/*     */     }
/* 198 */     List elements = new ArrayList();
/*     */     
/* 200 */     int i = 0;
/* 201 */     int from = 0;
/* 202 */     int len = headerValue.length;
/* 203 */     boolean qouted = false;
/* 204 */     while (i < len) {
/* 205 */       char ch = headerValue[i];
/* 206 */       if (ch == '"') {
/* 207 */         qouted = !qouted;
/*     */       }
/* 209 */       HeaderElement element = null;
/* 210 */       if ((!qouted) && (ch == ',')) {
/* 211 */         element = new HeaderElement(headerValue, from, i);
/* 212 */         from = i + 1;
/* 213 */       } else if (i == len - 1) {
/* 214 */         element = new HeaderElement(headerValue, from, len);
/*     */       }
/* 216 */       if ((element != null) && (element.getName() != null)) {
/* 217 */         elements.add(element);
/*     */       }
/* 219 */       i++;
/*     */     }
/* 221 */     return (HeaderElement[])elements.toArray(new HeaderElement[elements.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final HeaderElement[] parseElements(String headerValue)
/*     */   {
/* 237 */     LOG.trace("enter HeaderElement.parseElements(String)");
/*     */     
/* 239 */     if (headerValue == null) {
/* 240 */       return new HeaderElement[0];
/*     */     }
/* 242 */     return parseElements(headerValue.toCharArray());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static final HeaderElement[] parse(String headerValue)
/*     */     throws HttpException
/*     */   {
/* 259 */     LOG.trace("enter HeaderElement.parse(String)");
/*     */     
/* 261 */     if (headerValue == null) {
/* 262 */       return new HeaderElement[0];
/*     */     }
/* 264 */     return parseElements(headerValue.toCharArray());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NameValuePair getParameterByName(String name)
/*     */   {
/* 278 */     LOG.trace("enter HeaderElement.getParameterByName(String)");
/*     */     
/* 280 */     if (name == null) {
/* 281 */       throw new IllegalArgumentException("Name may not be null");
/*     */     }
/* 283 */     NameValuePair found = null;
/* 284 */     NameValuePair[] parameters = getParameters();
/* 285 */     if (parameters != null) {
/* 286 */       for (int i = 0; i < parameters.length; i++) {
/* 287 */         NameValuePair current = parameters[i];
/* 288 */         if (current.getName().equalsIgnoreCase(name)) {
/* 289 */           found = current;
/* 290 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 294 */     return found;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\HeaderElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */