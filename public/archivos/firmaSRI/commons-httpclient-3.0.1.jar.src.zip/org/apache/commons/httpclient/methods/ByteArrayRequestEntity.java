/*     */ package org.apache.commons.httpclient.methods;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteArrayRequestEntity
/*     */   implements RequestEntity
/*     */ {
/*     */   private byte[] content;
/*     */   private String contentType;
/*     */   
/*     */   public ByteArrayRequestEntity(byte[] content)
/*     */   {
/*  54 */     this(content, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ByteArrayRequestEntity(byte[] content, String contentType)
/*     */   {
/*  64 */     if (content == null) {
/*  65 */       throw new IllegalArgumentException("The content cannot be null");
/*     */     }
/*  67 */     this.content = content;
/*  68 */     this.contentType = contentType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isRepeatable()
/*     */   {
/*  75 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getContentType()
/*     */   {
/*  82 */     return this.contentType;
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeRequest(OutputStream out)
/*     */     throws IOException
/*     */   {
/*  89 */     out.write(this.content);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public long getContentLength()
/*     */   {
/*  96 */     return this.content.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public byte[] getContent()
/*     */   {
/* 103 */     return this.content;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\methods\ByteArrayRequestEntity.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */