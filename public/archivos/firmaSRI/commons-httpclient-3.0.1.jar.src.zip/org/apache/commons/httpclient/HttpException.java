/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpException
/*     */   extends IOException
/*     */ {
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   private String reason;
/*     */   
/*     */   public HttpException()
/*     */   {
/*  51 */     this.cause = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpException(String message)
/*     */   {
/*  60 */     super(message);
/*  61 */     this.cause = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpException(String message, Throwable cause)
/*     */   {
/*  74 */     super(message);
/*  75 */     this.cause = cause;
/*     */     
/*     */     try
/*     */     {
/*  79 */       Class[] paramsClasses = { Throwable.class };
/*  80 */       Method initCause = Throwable.class.getMethod("initCause", paramsClasses);
/*  81 */       initCause.invoke(this, new Object[] { cause });
/*     */     }
/*     */     catch (Exception e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Throwable getCause()
/*     */   {
/*  97 */     return this.cause;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printStackTrace()
/*     */   {
/* 106 */     printStackTrace(System.err);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printStackTrace(PrintStream s)
/*     */   {
/*     */     try
/*     */     {
/* 122 */       Class[] paramsClasses = new Class[0];
/* 123 */       getClass().getMethod("getStackTrace", paramsClasses);
/* 124 */       super.printStackTrace(s);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 128 */       super.printStackTrace(s);
/* 129 */       if (this.cause != null)
/*     */       {
/*     */ 
/* 132 */         s.print("Caused by: ");
/* 133 */         this.cause.printStackTrace(s);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printStackTrace(PrintWriter s)
/*     */   {
/*     */     try
/*     */     {
/* 151 */       Class[] paramsClasses = new Class[0];
/* 152 */       getClass().getMethod("getStackTrace", paramsClasses);
/* 153 */       super.printStackTrace(s);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 157 */       super.printStackTrace(s);
/* 158 */       if (this.cause != null)
/*     */       {
/*     */ 
/* 161 */         s.print("Caused by: ");
/* 162 */         this.cause.printStackTrace(s);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setReason(String reason)
/*     */   {
/* 177 */     this.reason = reason;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public String getReason()
/*     */   {
/* 188 */     return this.reason;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setReasonCode(int code)
/*     */   {
/* 202 */     this.reasonCode = code;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public int getReasonCode()
/*     */   {
/* 213 */     return this.reasonCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/* 230 */   private int reasonCode = 200;
/*     */   private final Throwable cause;
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\HttpException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */