/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import org.apache.commons.httpclient.util.URIUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpURL
/*     */   extends URI
/*     */ {
/*     */   protected HttpURL() {}
/*     */   
/*     */   public HttpURL(char[] escaped, String charset)
/*     */     throws URIException, NullPointerException
/*     */   {
/*  61 */     this.protocolCharset = charset;
/*  62 */     parseUriReference(new String(escaped), true);
/*  63 */     checkValid();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpURL(char[] escaped)
/*     */     throws URIException, NullPointerException
/*     */   {
/*  76 */     parseUriReference(new String(escaped), true);
/*  77 */     checkValid();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpURL(String original, String charset)
/*     */     throws URIException
/*     */   {
/*  91 */     this.protocolCharset = charset;
/*  92 */     parseUriReference(original, false);
/*  93 */     checkValid();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpURL(String original)
/*     */     throws URIException
/*     */   {
/* 105 */     parseUriReference(original, false);
/* 106 */     checkValid();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpURL(String host, int port, String path)
/*     */     throws URIException
/*     */   {
/* 120 */     this(null, null, host, port, path, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpURL(String host, int port, String path, String query)
/*     */     throws URIException
/*     */   {
/* 137 */     this(null, null, host, port, path, query, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpURL(String user, String password, String host)
/*     */     throws URIException
/*     */   {
/* 153 */     this(user, password, host, -1, null, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpURL(String user, String password, String host, int port)
/*     */     throws URIException
/*     */   {
/* 170 */     this(user, password, host, port, null, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpURL(String user, String password, String host, int port, String path)
/*     */     throws URIException
/*     */   {
/* 188 */     this(user, password, host, port, path, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpURL(String user, String password, String host, int port, String path, String query)
/*     */     throws URIException
/*     */   {
/* 207 */     this(user, password, host, port, path, query, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpURL(String host, String path, String query, String fragment)
/*     */     throws URIException
/*     */   {
/* 224 */     this(null, null, host, -1, path, query, fragment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpURL(String userinfo, String host, String path, String query, String fragment)
/*     */     throws URIException
/*     */   {
/* 246 */     this(userinfo, host, -1, path, query, fragment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpURL(String userinfo, String host, int port, String path)
/*     */     throws URIException
/*     */   {
/* 267 */     this(userinfo, host, port, path, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpURL(String userinfo, String host, int port, String path, String query)
/*     */     throws URIException
/*     */   {
/* 289 */     this(userinfo, host, port, path, query, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpURL(String userinfo, String host, int port, String path, String query, String fragment)
/*     */     throws URIException
/*     */   {
/* 313 */     StringBuffer buff = new StringBuffer();
/* 314 */     if ((userinfo != null) || (host != null) || (port != -1)) {
/* 315 */       this._scheme = DEFAULT_SCHEME;
/* 316 */       buff.append(_default_scheme);
/* 317 */       buff.append("://");
/* 318 */       if (userinfo != null) {
/* 319 */         buff.append(userinfo);
/* 320 */         buff.append('@');
/*     */       }
/* 322 */       if (host != null) {
/* 323 */         buff.append(URIUtil.encode(host, URI.allowed_host));
/* 324 */         if ((port != -1) || (port != 80)) {
/* 325 */           buff.append(':');
/* 326 */           buff.append(port);
/*     */         }
/*     */       }
/*     */     }
/* 330 */     if (path != null) {
/* 331 */       if ((URI.scheme != null) && (!path.startsWith("/"))) {
/* 332 */         throw new URIException(1, "abs_path requested");
/*     */       }
/*     */       
/* 335 */       buff.append(URIUtil.encode(path, URI.allowed_abs_path));
/*     */     }
/* 337 */     if (query != null) {
/* 338 */       buff.append('?');
/* 339 */       buff.append(URIUtil.encode(query, URI.allowed_query));
/*     */     }
/* 341 */     if (fragment != null) {
/* 342 */       buff.append('#');
/* 343 */       buff.append(URIUtil.encode(fragment, URI.allowed_fragment));
/*     */     }
/* 345 */     parseUriReference(buff.toString(), true);
/* 346 */     checkValid();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpURL(String user, String password, String host, int port, String path, String query, String fragment)
/*     */     throws URIException
/*     */   {
/* 365 */     this(toUserinfo(user, password), host, port, path, query, fragment);
/*     */   }
/*     */   
/*     */   protected static String toUserinfo(String user, String password) throws URIException {
/* 369 */     if (user == null) return null;
/* 370 */     StringBuffer usrinfo = new StringBuffer(20);
/* 371 */     usrinfo.append(URIUtil.encode(user, URI.allowed_within_userinfo));
/* 372 */     if (password == null) return usrinfo.toString();
/* 373 */     usrinfo.append(':');
/* 374 */     usrinfo.append(URIUtil.encode(password, URI.allowed_within_userinfo));
/* 375 */     return usrinfo.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpURL(HttpURL base, String relative)
/*     */     throws URIException
/*     */   {
/* 387 */     this(base, new HttpURL(relative));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpURL(HttpURL base, HttpURL relative)
/*     */     throws URIException
/*     */   {
/* 399 */     super(base, relative);
/* 400 */     checkValid();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 408 */   public static final char[] DEFAULT_SCHEME = { 'h', 't', 't', 'p' };
/*     */   
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/* 415 */   public static final char[] _default_scheme = DEFAULT_SCHEME;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int DEFAULT_PORT = 80;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static final int _default_port = 80;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final long serialVersionUID = -7158031098595039459L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] getRawScheme()
/*     */   {
/* 442 */     return this._scheme == null ? null : DEFAULT_SCHEME;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getScheme()
/*     */   {
/* 452 */     return this._scheme == null ? null : new String(DEFAULT_SCHEME);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 462 */     return this._port == -1 ? 80 : this._port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRawUserinfo(char[] escapedUser, char[] escapedPassword)
/*     */     throws URIException
/*     */   {
/* 478 */     if ((escapedUser == null) || (escapedUser.length == 0)) {
/* 479 */       throw new URIException(1, "user required");
/*     */     }
/* 481 */     if ((!validate(escapedUser, URI.within_userinfo)) || ((escapedPassword != null) && (!validate(escapedPassword, URI.within_userinfo))))
/*     */     {
/*     */ 
/* 484 */       throw new URIException(3, "escaped userinfo not valid");
/*     */     }
/*     */     
/* 487 */     String username = new String(escapedUser);
/* 488 */     String password = escapedPassword == null ? null : new String(escapedPassword);
/*     */     
/* 490 */     String userinfo = username + (password == null ? "" : new StringBuffer().append(":").append(password).toString());
/* 491 */     String hostname = new String(getRawHost());
/* 492 */     String hostport = hostname + ":" + this._port;
/* 493 */     String authority = userinfo + "@" + hostport;
/* 494 */     this._userinfo = userinfo.toCharArray();
/* 495 */     this._authority = authority.toCharArray();
/* 496 */     setURI();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEscapedUserinfo(String escapedUser, String escapedPassword)
/*     */     throws URIException, NullPointerException
/*     */   {
/* 512 */     setRawUserinfo(escapedUser.toCharArray(), escapedPassword == null ? null : escapedPassword.toCharArray());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserinfo(String user, String password)
/*     */     throws URIException, NullPointerException
/*     */   {
/* 528 */     String charset = getProtocolCharset();
/* 529 */     setRawUserinfo(URI.encode(user, URI.within_userinfo, charset), password == null ? null : URI.encode(password, URI.within_userinfo, charset));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRawUser(char[] escapedUser)
/*     */     throws URIException
/*     */   {
/* 543 */     if ((escapedUser == null) || (escapedUser.length == 0)) {
/* 544 */       throw new URIException(1, "user required");
/*     */     }
/* 546 */     if (!validate(escapedUser, URI.within_userinfo)) {
/* 547 */       throw new URIException(3, "escaped user not valid");
/*     */     }
/*     */     
/* 550 */     String username = new String(escapedUser);
/* 551 */     String password = new String(getRawPassword());
/* 552 */     String userinfo = username + (password == null ? "" : new StringBuffer().append(":").append(password).toString());
/* 553 */     String hostname = new String(getRawHost());
/* 554 */     String hostport = hostname + ":" + this._port;
/* 555 */     String authority = userinfo + "@" + hostport;
/* 556 */     this._userinfo = userinfo.toCharArray();
/* 557 */     this._authority = authority.toCharArray();
/* 558 */     setURI();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEscapedUser(String escapedUser)
/*     */     throws URIException, NullPointerException
/*     */   {
/* 571 */     setRawUser(escapedUser.toCharArray());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUser(String user)
/*     */     throws URIException, NullPointerException
/*     */   {
/* 583 */     setRawUser(URI.encode(user, URI.allowed_within_userinfo, getProtocolCharset()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] getRawUser()
/*     */   {
/* 593 */     if ((this._userinfo == null) || (this._userinfo.length == 0)) {
/* 594 */       return null;
/*     */     }
/* 596 */     int to = indexFirstOf(this._userinfo, ':');
/*     */     
/* 598 */     if (to == -1) {
/* 599 */       return this._userinfo;
/*     */     }
/* 601 */     char[] result = new char[to];
/* 602 */     System.arraycopy(this._userinfo, 0, result, 0, to);
/* 603 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getEscapedUser()
/*     */   {
/* 613 */     char[] user = getRawUser();
/* 614 */     return user == null ? null : new String(user);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUser()
/*     */     throws URIException
/*     */   {
/* 625 */     char[] user = getRawUser();
/* 626 */     return user == null ? null : URI.decode(user, getProtocolCharset());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRawPassword(char[] escapedPassword)
/*     */     throws URIException
/*     */   {
/* 637 */     if ((escapedPassword != null) && (!validate(escapedPassword, URI.within_userinfo)))
/*     */     {
/* 639 */       throw new URIException(3, "escaped password not valid");
/*     */     }
/*     */     
/* 642 */     if ((getRawUser() == null) || (getRawUser().length == 0)) {
/* 643 */       throw new URIException(1, "username required");
/*     */     }
/* 645 */     String username = new String(getRawUser());
/* 646 */     String password = new String(escapedPassword);
/*     */     
/* 648 */     String userinfo = username + (password == null ? "" : new StringBuffer().append(":").append(password).toString());
/* 649 */     String hostname = new String(getRawHost());
/* 650 */     String hostport = hostname + ":" + this._port;
/* 651 */     String authority = userinfo + "@" + hostport;
/* 652 */     this._userinfo = userinfo.toCharArray();
/* 653 */     this._authority = authority.toCharArray();
/* 654 */     setURI();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEscapedPassword(String escapedPassword)
/*     */     throws URIException
/*     */   {
/* 665 */     setRawPassword(escapedPassword == null ? null : escapedPassword.toCharArray());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPassword(String password)
/*     */     throws URIException
/*     */   {
/* 677 */     setRawPassword(password == null ? null : URI.encode(password, URI.allowed_within_userinfo, getProtocolCharset()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] getRawPassword()
/*     */   {
/* 688 */     int from = indexFirstOf(this._userinfo, ':');
/* 689 */     if (from == -1) {
/* 690 */       return null;
/*     */     }
/* 692 */     int len = this._userinfo.length - from - 1;
/* 693 */     char[] result = new char[len];
/* 694 */     System.arraycopy(this._userinfo, from + 1, result, 0, len);
/* 695 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getEscapedPassword()
/*     */   {
/* 705 */     char[] password = getRawPassword();
/* 706 */     return password == null ? null : new String(password);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPassword()
/*     */     throws URIException
/*     */   {
/* 717 */     char[] password = getRawPassword();
/* 718 */     return password == null ? null : URI.decode(password, getProtocolCharset());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] getRawCurrentHierPath()
/*     */     throws URIException
/*     */   {
/* 731 */     return (this._path == null) || (this._path.length == 0) ? URI.rootPath : super.getRawCurrentHierPath(this._path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] getRawAboveHierPath()
/*     */     throws URIException
/*     */   {
/* 743 */     char[] path = getRawCurrentHierPath();
/* 744 */     return (path == null) || (path.length == 0) ? URI.rootPath : getRawCurrentHierPath(path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] getRawPath()
/*     */   {
/* 754 */     char[] path = super.getRawPath();
/* 755 */     return (path == null) || (path.length == 0) ? URI.rootPath : path;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setQuery(String queryName, String queryValue)
/*     */     throws URIException, NullPointerException
/*     */   {
/* 773 */     StringBuffer buff = new StringBuffer();
/*     */     
/* 775 */     String charset = getProtocolCharset();
/* 776 */     buff.append(URI.encode(queryName, URI.allowed_within_query, charset));
/* 777 */     buff.append('=');
/* 778 */     buff.append(URI.encode(queryValue, URI.allowed_within_query, charset));
/* 779 */     this._query = buff.toString().toCharArray();
/* 780 */     setURI();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setQuery(String[] queryName, String[] queryValue)
/*     */     throws URIException, NullPointerException
/*     */   {
/* 797 */     int length = queryName.length;
/* 798 */     if (length != queryValue.length) {
/* 799 */       throw new URIException("wrong array size of query");
/*     */     }
/*     */     
/* 802 */     StringBuffer buff = new StringBuffer();
/*     */     
/* 804 */     String charset = getProtocolCharset();
/* 805 */     for (int i = 0; i < length; i++) {
/* 806 */       buff.append(URI.encode(queryName[i], URI.allowed_within_query, charset));
/* 807 */       buff.append('=');
/* 808 */       buff.append(URI.encode(queryValue[i], URI.allowed_within_query, charset));
/* 809 */       if (i + 1 < length) {
/* 810 */         buff.append('&');
/*     */       }
/*     */     }
/* 813 */     this._query = buff.toString().toCharArray();
/* 814 */     setURI();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkValid()
/*     */     throws URIException
/*     */   {
/* 826 */     if ((!equals(this._scheme, DEFAULT_SCHEME)) && (this._scheme != null)) {
/* 827 */       throw new URIException(1, "wrong class use");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setURI()
/*     */   {
/* 838 */     StringBuffer buf = new StringBuffer();
/*     */     
/* 840 */     if (this._scheme != null) {
/* 841 */       buf.append(this._scheme);
/* 842 */       buf.append(':');
/*     */     }
/* 844 */     if (this._is_net_path) {
/* 845 */       buf.append("//");
/* 846 */       if (this._authority != null) {
/* 847 */         if (this._userinfo != null) {
/* 848 */           if (this._host != null) {
/* 849 */             buf.append(this._host);
/* 850 */             if (this._port != -1) {
/* 851 */               buf.append(':');
/* 852 */               buf.append(this._port);
/*     */             }
/*     */           }
/*     */         } else {
/* 856 */           buf.append(this._authority);
/*     */         }
/*     */       }
/*     */     }
/* 860 */     if ((this._opaque != null) && (this._is_opaque_part)) {
/* 861 */       buf.append(this._opaque);
/* 862 */     } else if (this._path != null)
/*     */     {
/* 864 */       if (this._path.length != 0) {
/* 865 */         buf.append(this._path);
/*     */       }
/*     */     }
/* 868 */     if (this._query != null) {
/* 869 */       buf.append('?');
/* 870 */       buf.append(this._query);
/*     */     }
/*     */     
/* 873 */     this._uri = buf.toString().toCharArray();
/* 874 */     this.hash = 0;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\HttpURL.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */