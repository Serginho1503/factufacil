/*     */ package org.apache.commons.httpclient.auth;
/*     */ 
/*     */ import org.apache.commons.codec.binary.Base64;
/*     */ import org.apache.commons.httpclient.Credentials;
/*     */ import org.apache.commons.httpclient.HttpMethod;
/*     */ import org.apache.commons.httpclient.UsernamePasswordCredentials;
/*     */ import org.apache.commons.httpclient.params.HttpMethodParams;
/*     */ import org.apache.commons.httpclient.util.EncodingUtil;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicScheme
/*     */   extends RFC2617Scheme
/*     */ {
/*  58 */   private static final Log LOG = LogFactory.getLog(BasicScheme.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean complete;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public BasicScheme()
/*     */   {
/*  70 */     this.complete = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public BasicScheme(String challenge)
/*     */     throws MalformedChallengeException
/*     */   {
/*  85 */     super(challenge);
/*  86 */     this.complete = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSchemeName()
/*     */   {
/*  95 */     return "basic";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void processChallenge(String challenge)
/*     */     throws MalformedChallengeException
/*     */   {
/* 111 */     super.processChallenge(challenge);
/* 112 */     this.complete = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isComplete()
/*     */   {
/* 124 */     return this.complete;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public String authenticate(Credentials credentials, String method, String uri)
/*     */     throws AuthenticationException
/*     */   {
/* 146 */     LOG.trace("enter BasicScheme.authenticate(Credentials, String, String)");
/*     */     
/* 148 */     UsernamePasswordCredentials usernamepassword = null;
/*     */     try {
/* 150 */       usernamepassword = (UsernamePasswordCredentials)credentials;
/*     */     } catch (ClassCastException e) {
/* 152 */       throw new InvalidCredentialsException("Credentials cannot be used for basic authentication: " + credentials.getClass().getName());
/*     */     }
/*     */     
/*     */ 
/* 156 */     return authenticate(usernamepassword);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isConnectionBased()
/*     */   {
/* 167 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String authenticate(Credentials credentials, HttpMethod method)
/*     */     throws AuthenticationException
/*     */   {
/* 186 */     LOG.trace("enter BasicScheme.authenticate(Credentials, HttpMethod)");
/*     */     
/* 188 */     if (method == null) {
/* 189 */       throw new IllegalArgumentException("Method may not be null");
/*     */     }
/* 191 */     UsernamePasswordCredentials usernamepassword = null;
/*     */     try {
/* 193 */       usernamepassword = (UsernamePasswordCredentials)credentials;
/*     */     } catch (ClassCastException e) {
/* 195 */       throw new InvalidCredentialsException("Credentials cannot be used for basic authentication: " + credentials.getClass().getName());
/*     */     }
/*     */     
/*     */ 
/* 199 */     return authenticate(usernamepassword, method.getParams().getCredentialCharset());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static String authenticate(UsernamePasswordCredentials credentials)
/*     */   {
/* 215 */     return authenticate(credentials, "ISO-8859-1");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String authenticate(UsernamePasswordCredentials credentials, String charset)
/*     */   {
/* 231 */     LOG.trace("enter BasicScheme.authenticate(UsernamePasswordCredentials, String)");
/*     */     
/* 233 */     if (credentials == null) {
/* 234 */       throw new IllegalArgumentException("Credentials may not be null");
/*     */     }
/* 236 */     if ((charset == null) || (charset.length() == 0)) {
/* 237 */       throw new IllegalArgumentException("charset may not be null or empty");
/*     */     }
/* 239 */     StringBuffer buffer = new StringBuffer();
/* 240 */     buffer.append(credentials.getUserName());
/* 241 */     buffer.append(":");
/* 242 */     buffer.append(credentials.getPassword());
/*     */     
/* 244 */     return "Basic " + EncodingUtil.getAsciiString(Base64.encodeBase64(EncodingUtil.getBytes(buffer.toString(), charset)));
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\auth\BasicScheme.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */