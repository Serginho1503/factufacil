/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import java.net.InetAddress;
/*     */ import org.apache.commons.httpclient.params.DefaultHttpParams;
/*     */ import org.apache.commons.httpclient.params.HostParams;
/*     */ import org.apache.commons.httpclient.protocol.Protocol;
/*     */ import org.apache.commons.httpclient.util.LangUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HostConfiguration
/*     */   implements Cloneable
/*     */ {
/*  56 */   public static final HostConfiguration ANY_HOST_CONFIGURATION = new HostConfiguration();
/*     */   
/*     */ 
/*  59 */   private HttpHost host = null;
/*     */   
/*     */ 
/*  62 */   private ProxyHost proxyHost = null;
/*     */   
/*     */ 
/*  65 */   private InetAddress localAddress = null;
/*     */   
/*     */ 
/*  68 */   private HostParams params = new HostParams();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HostConfiguration() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HostConfiguration(HostConfiguration hostConfiguration)
/*     */   {
/*  85 */     synchronized (hostConfiguration) {
/*     */       try {
/*  87 */         if (hostConfiguration.host != null) {
/*  88 */           this.host = ((HttpHost)hostConfiguration.host.clone());
/*     */         } else {
/*  90 */           this.host = null;
/*     */         }
/*  92 */         if (hostConfiguration.proxyHost != null) {
/*  93 */           this.proxyHost = ((ProxyHost)hostConfiguration.proxyHost.clone());
/*     */         } else {
/*  95 */           this.proxyHost = null;
/*     */         }
/*  97 */         this.localAddress = hostConfiguration.getLocalAddress();
/*  98 */         this.params = ((HostParams)hostConfiguration.getParams().clone());
/*     */       } catch (CloneNotSupportedException e) {
/* 100 */         throw new IllegalArgumentException("Host configuration could not be cloned");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 109 */     return new HostConfiguration(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized String toString()
/*     */   {
/* 117 */     boolean appendComma = false;
/* 118 */     StringBuffer b = new StringBuffer(50);
/* 119 */     b.append("HostConfiguration[");
/*     */     
/* 121 */     if (this.host != null) {
/* 122 */       appendComma = true;
/* 123 */       b.append("host=").append(this.host);
/*     */     }
/* 125 */     if (this.proxyHost != null) {
/* 126 */       if (appendComma) {
/* 127 */         b.append(", ");
/*     */       } else {
/* 129 */         appendComma = true;
/*     */       }
/* 131 */       b.append("proxyHost=").append(this.proxyHost);
/*     */     }
/* 133 */     if (this.localAddress != null) {
/* 134 */       if (appendComma) {
/* 135 */         b.append(", ");
/*     */       } else {
/* 137 */         appendComma = true;
/*     */       }
/* 139 */       b.append("localAddress=").append(this.localAddress);
/* 140 */       if (appendComma) {
/* 141 */         b.append(", ");
/*     */       } else {
/* 143 */         appendComma = true;
/*     */       }
/* 145 */       b.append("params=").append(this.params);
/*     */     }
/* 147 */     b.append("]");
/* 148 */     return b.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean hostEquals(HttpConnection connection)
/*     */   {
/* 163 */     if (connection == null) {
/* 164 */       throw new IllegalArgumentException("Connection may not be null");
/*     */     }
/* 166 */     if (this.host != null) {
/* 167 */       if (!this.host.getHostName().equalsIgnoreCase(connection.getHost())) {
/* 168 */         return false;
/*     */       }
/* 170 */       if (this.host.getPort() != connection.getPort()) {
/* 171 */         return false;
/*     */       }
/* 173 */       if (!this.host.getProtocol().equals(connection.getProtocol())) {
/* 174 */         return false;
/*     */       }
/* 176 */       if (this.localAddress != null) {
/* 177 */         if (!this.localAddress.equals(connection.getLocalAddress())) {
/* 178 */           return false;
/*     */         }
/*     */       }
/* 181 */       else if (connection.getLocalAddress() != null) {
/* 182 */         return false;
/*     */       }
/*     */       
/* 185 */       return true;
/*     */     }
/* 187 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean proxyEquals(HttpConnection connection)
/*     */   {
/* 202 */     if (connection == null) {
/* 203 */       throw new IllegalArgumentException("Connection may not be null");
/*     */     }
/* 205 */     if (this.proxyHost != null) {
/* 206 */       return (this.proxyHost.getHostName().equalsIgnoreCase(connection.getProxyHost())) && (this.proxyHost.getPort() == connection.getProxyPort());
/*     */     }
/*     */     
/*     */ 
/* 210 */     return connection.getProxyHost() == null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public synchronized boolean isHostSet()
/*     */   {
/* 221 */     return this.host != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setHost(HttpHost host)
/*     */   {
/* 230 */     this.host = host;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setHost(String host, int port, String protocol)
/*     */   {
/* 241 */     this.host = new HttpHost(host, port, Protocol.getProtocol(protocol));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public synchronized void setHost(String host, String virtualHost, int port, Protocol protocol)
/*     */   {
/* 256 */     setHost(host, port, protocol);
/* 257 */     this.params.setVirtualHost(virtualHost);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setHost(String host, int port, Protocol protocol)
/*     */   {
/* 268 */     if (host == null) {
/* 269 */       throw new IllegalArgumentException("host must not be null");
/*     */     }
/* 271 */     if (protocol == null) {
/* 272 */       throw new IllegalArgumentException("protocol must not be null");
/*     */     }
/* 274 */     this.host = new HttpHost(host, port, protocol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setHost(String host, int port)
/*     */   {
/* 284 */     setHost(host, port, Protocol.getProtocol("http"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setHost(String host)
/*     */   {
/* 293 */     Protocol defaultProtocol = Protocol.getProtocol("http");
/* 294 */     setHost(host, defaultProtocol.getDefaultPort(), defaultProtocol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized void setHost(URI uri)
/*     */   {
/*     */     try
/*     */     {
/* 303 */       setHost(uri.getHost(), uri.getPort(), uri.getScheme());
/*     */     } catch (URIException e) {
/* 305 */       throw new IllegalArgumentException(e.toString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized String getHostURL()
/*     */   {
/* 315 */     if (this.host == null) {
/* 316 */       throw new IllegalStateException("Host must be set to create a host URL");
/*     */     }
/* 318 */     return this.host.toURI();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized String getHost()
/*     */   {
/* 330 */     if (this.host != null) {
/* 331 */       return this.host.getHostName();
/*     */     }
/* 333 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public synchronized String getVirtualHost()
/*     */   {
/* 345 */     return this.params.getVirtualHost();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized int getPort()
/*     */   {
/* 356 */     if (this.host != null) {
/* 357 */       return this.host.getPort();
/*     */     }
/* 359 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Protocol getProtocol()
/*     */   {
/* 368 */     if (this.host != null) {
/* 369 */       return this.host.getProtocol();
/*     */     }
/* 371 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public synchronized boolean isProxySet()
/*     */   {
/* 385 */     return this.proxyHost != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setProxyHost(ProxyHost proxyHost)
/*     */   {
/* 394 */     this.proxyHost = proxyHost;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setProxy(String proxyHost, int proxyPort)
/*     */   {
/* 403 */     this.proxyHost = new ProxyHost(proxyHost, proxyPort);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized String getProxyHost()
/*     */   {
/* 414 */     if (this.proxyHost != null) {
/* 415 */       return this.proxyHost.getHostName();
/*     */     }
/* 417 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized int getProxyPort()
/*     */   {
/* 429 */     if (this.proxyHost != null) {
/* 430 */       return this.proxyHost.getPort();
/*     */     }
/* 432 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setLocalAddress(InetAddress localAddress)
/*     */   {
/* 445 */     this.localAddress = localAddress;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized InetAddress getLocalAddress()
/*     */   {
/* 456 */     return this.localAddress;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HostParams getParams()
/*     */   {
/* 467 */     return this.params;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParams(HostParams params)
/*     */   {
/* 478 */     if (params == null) {
/* 479 */       throw new IllegalArgumentException("Parameters may not be null");
/*     */     }
/* 481 */     this.params = params;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized boolean equals(Object o)
/*     */   {
/* 488 */     if ((o instanceof HostConfiguration))
/*     */     {
/* 490 */       if (o == this) {
/* 491 */         return true;
/*     */       }
/* 493 */       HostConfiguration that = (HostConfiguration)o;
/* 494 */       return (LangUtils.equals(this.host, that.host)) && (LangUtils.equals(this.proxyHost, that.proxyHost)) && (LangUtils.equals(this.localAddress, that.localAddress));
/*     */     }
/*     */     
/*     */ 
/* 498 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized int hashCode()
/*     */   {
/* 507 */     int hash = 17;
/* 508 */     hash = LangUtils.hashCode(hash, this.host);
/* 509 */     hash = LangUtils.hashCode(hash, this.proxyHost);
/* 510 */     hash = LangUtils.hashCode(hash, this.localAddress);
/* 511 */     return hash;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\HostConfiguration.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */