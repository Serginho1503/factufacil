/*     */ package org.apache.commons.httpclient.methods.multipart;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import org.apache.commons.httpclient.util.EncodingUtil;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilePart
/*     */   extends PartBase
/*     */ {
/*     */   public static final String DEFAULT_CONTENT_TYPE = "application/octet-stream";
/*     */   public static final String DEFAULT_CHARSET = "ISO-8859-1";
/*     */   public static final String DEFAULT_TRANSFER_ENCODING = "binary";
/*  68 */   private static final Log LOG = LogFactory.getLog(FilePart.class);
/*     */   
/*     */ 
/*     */   protected static final String FILE_NAME = "; filename=";
/*     */   
/*     */ 
/*  74 */   private static final byte[] FILE_NAME_BYTES = EncodingUtil.getAsciiBytes("; filename=");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private PartSource source;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FilePart(String name, PartSource partSource, String contentType, String charset)
/*     */   {
/*  92 */     super(name, contentType == null ? "application/octet-stream" : contentType, charset == null ? "ISO-8859-1" : charset, "binary");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  99 */     if (partSource == null) {
/* 100 */       throw new IllegalArgumentException("Source may not be null");
/*     */     }
/* 102 */     this.source = partSource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FilePart(String name, PartSource partSource)
/*     */   {
/* 112 */     this(name, partSource, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FilePart(String name, File file)
/*     */     throws FileNotFoundException
/*     */   {
/* 126 */     this(name, new FilePartSource(file), null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FilePart(String name, File file, String contentType, String charset)
/*     */     throws FileNotFoundException
/*     */   {
/* 144 */     this(name, new FilePartSource(file), contentType, charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FilePart(String name, String fileName, File file)
/*     */     throws FileNotFoundException
/*     */   {
/* 159 */     this(name, new FilePartSource(fileName, file), null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FilePart(String name, String fileName, File file, String contentType, String charset)
/*     */     throws FileNotFoundException
/*     */   {
/* 178 */     this(name, new FilePartSource(fileName, file), contentType, charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void sendDispositionHeader(OutputStream out)
/*     */     throws IOException
/*     */   {
/* 189 */     LOG.trace("enter sendDispositionHeader(OutputStream out)");
/* 190 */     super.sendDispositionHeader(out);
/* 191 */     String filename = this.source.getFileName();
/* 192 */     if (filename != null) {
/* 193 */       out.write(FILE_NAME_BYTES);
/* 194 */       out.write(Part.QUOTE_BYTES);
/* 195 */       out.write(EncodingUtil.getAsciiBytes(filename));
/* 196 */       out.write(Part.QUOTE_BYTES);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void sendData(OutputStream out)
/*     */     throws IOException
/*     */   {
/* 207 */     LOG.trace("enter sendData(OutputStream out)");
/* 208 */     if (lengthOfData() == 0L)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 213 */       LOG.debug("No data to send.");
/* 214 */       return;
/*     */     }
/*     */     
/* 217 */     byte[] tmp = new byte['က'];
/* 218 */     InputStream instream = this.source.createInputStream();
/*     */     try {
/*     */       int len;
/* 221 */       while ((len = instream.read(tmp)) >= 0) { int i;
/* 222 */         out.write(tmp, 0, i);
/*     */       }
/*     */     }
/*     */     finally {
/* 226 */       instream.close();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PartSource getSource()
/*     */   {
/* 236 */     LOG.trace("enter getSource()");
/* 237 */     return this.source;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected long lengthOfData()
/*     */     throws IOException
/*     */   {
/* 247 */     LOG.trace("enter lengthOfData()");
/* 248 */     return this.source.getLength();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\methods\multipart\FilePart.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */