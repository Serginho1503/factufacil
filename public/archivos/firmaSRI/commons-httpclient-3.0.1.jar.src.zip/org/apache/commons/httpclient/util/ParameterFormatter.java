/*     */ package org.apache.commons.httpclient.util;
/*     */ 
/*     */ import org.apache.commons.httpclient.NameValuePair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParameterFormatter
/*     */ {
/*  91 */   private static final char[] SEPARATORS = { '(', ')', '<', '>', '@', ',', ';', ':', '\\', '"', '/', '[', ']', '?', '=', '{', '}', ' ', '\t' };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */   private static final char[] UNSAFE_CHARS = { '"', '\\' };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 110 */   private boolean alwaysUseQuotes = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isOneOf(char[] chars, char ch)
/*     */   {
/* 118 */     for (int i = 0; i < chars.length; i++) {
/* 119 */       if (ch == chars[i]) {
/* 120 */         return true;
/*     */       }
/*     */     }
/* 123 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean isUnsafeChar(char ch) {
/* 127 */     return isOneOf(UNSAFE_CHARS, ch);
/*     */   }
/*     */   
/*     */   private static boolean isSeparator(char ch) {
/* 131 */     return isOneOf(SEPARATORS, ch);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAlwaysUseQuotes()
/*     */   {
/* 142 */     return this.alwaysUseQuotes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAlwaysUseQuotes(boolean alwaysUseQuotes)
/*     */   {
/* 152 */     this.alwaysUseQuotes = alwaysUseQuotes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void formatValue(StringBuffer buffer, String value, boolean alwaysUseQuotes)
/*     */   {
/* 168 */     if (buffer == null) {
/* 169 */       throw new IllegalArgumentException("String buffer may not be null");
/*     */     }
/* 171 */     if (value == null) {
/* 172 */       throw new IllegalArgumentException("Value buffer may not be null");
/*     */     }
/* 174 */     if (alwaysUseQuotes) {
/* 175 */       buffer.append('"');
/* 176 */       for (int i = 0; i < value.length(); i++) {
/* 177 */         char ch = value.charAt(i);
/* 178 */         if (isUnsafeChar(ch)) {
/* 179 */           buffer.append('\\');
/*     */         }
/* 181 */         buffer.append(ch);
/*     */       }
/* 183 */       buffer.append('"');
/*     */     } else {
/* 185 */       int offset = buffer.length();
/* 186 */       boolean unsafe = false;
/* 187 */       for (int i = 0; i < value.length(); i++) {
/* 188 */         char ch = value.charAt(i);
/* 189 */         if (isSeparator(ch)) {
/* 190 */           unsafe = true;
/*     */         }
/* 192 */         if (isUnsafeChar(ch)) {
/* 193 */           buffer.append('\\');
/*     */         }
/* 195 */         buffer.append(ch);
/*     */       }
/* 197 */       if (unsafe) {
/* 198 */         buffer.insert(offset, '"');
/* 199 */         buffer.append('"');
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void format(StringBuffer buffer, NameValuePair param)
/*     */   {
/* 212 */     if (buffer == null) {
/* 213 */       throw new IllegalArgumentException("String buffer may not be null");
/*     */     }
/* 215 */     if (param == null) {
/* 216 */       throw new IllegalArgumentException("Parameter may not be null");
/*     */     }
/* 218 */     buffer.append(param.getName());
/* 219 */     String value = param.getValue();
/* 220 */     if (value != null) {
/* 221 */       buffer.append("=");
/* 222 */       formatValue(buffer, value, this.alwaysUseQuotes);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String format(NameValuePair param)
/*     */   {
/* 236 */     StringBuffer buffer = new StringBuffer();
/* 237 */     format(buffer, param);
/* 238 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\util\ParameterFormatter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */