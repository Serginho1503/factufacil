/*     */ package org.apache.commons.httpclient.auth;
/*     */ 
/*     */ import java.util.AbstractCollection;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AuthPolicy
/*     */ {
/*  59 */   private static final HashMap SCHEMES = new HashMap();
/*  60 */   private static final ArrayList SCHEME_LIST = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String AUTH_SCHEME_PRIORITY = "http.auth.scheme-priority";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String NTLM = "NTLM";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String DIGEST = "Digest";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String BASIC = "Basic";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*  99 */     registerAuthScheme("NTLM", NTLMScheme.class);
/* 100 */     registerAuthScheme("Digest", DigestScheme.class);
/* 101 */     registerAuthScheme("Basic", BasicScheme.class);
/*     */   }
/*     */   
/*     */ 
/* 105 */   protected static final Log LOG = LogFactory.getLog(AuthPolicy.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized void registerAuthScheme(String id, Class clazz)
/*     */   {
/* 125 */     if (id == null) {
/* 126 */       throw new IllegalArgumentException("Id may not be null");
/*     */     }
/* 128 */     if (clazz == null) {
/* 129 */       throw new IllegalArgumentException("Authentication scheme class may not be null");
/*     */     }
/* 131 */     SCHEMES.put(id.toLowerCase(), clazz);
/* 132 */     SCHEME_LIST.add(id.toLowerCase());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized void unregisterAuthScheme(String id)
/*     */   {
/* 142 */     if (id == null) {
/* 143 */       throw new IllegalArgumentException("Id may not be null");
/*     */     }
/* 145 */     SCHEMES.remove(id.toLowerCase());
/* 146 */     SCHEME_LIST.remove(id.toLowerCase());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized AuthScheme getAuthScheme(String id)
/*     */     throws IllegalStateException
/*     */   {
/* 161 */     if (id == null) {
/* 162 */       throw new IllegalArgumentException("Id may not be null");
/*     */     }
/* 164 */     Class clazz = (Class)SCHEMES.get(id.toLowerCase());
/* 165 */     if (clazz != null) {
/*     */       try {
/* 167 */         return (AuthScheme)clazz.newInstance();
/*     */       } catch (Exception e) {
/* 169 */         LOG.error("Error initializing authentication scheme: " + id, e);
/* 170 */         throw new IllegalStateException(id + " authentication scheme implemented by " + clazz.getName() + " could not be initialized");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 175 */     throw new IllegalStateException("Unsupported authentication scheme " + id);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized List getDefaultAuthPrefs()
/*     */   {
/* 186 */     return (List)SCHEME_LIST.clone();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\auth\AuthPolicy.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */