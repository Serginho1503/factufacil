/*     */ package org.apache.commons.httpclient.cookie;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CookiePolicy
/*     */ {
/*  60 */   private static Map SPECS = Collections.synchronizedMap(new HashMap());
/*     */   
/*     */ 
/*     */   public static final String BROWSER_COMPATIBILITY = "compatibility";
/*     */   
/*     */ 
/*     */   public static final String NETSCAPE = "netscape";
/*     */   
/*     */ 
/*     */   public static final String RFC_2109 = "rfc2109";
/*     */   
/*     */ 
/*     */   public static final String IGNORE_COOKIES = "ignoreCookies";
/*     */   
/*     */ 
/*     */   public static final String DEFAULT = "default";
/*     */   
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static final int COMPATIBILITY = 0;
/*     */   
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static final int NETSCAPE_DRAFT = 1;
/*     */   
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static final int RFC2109 = 2;
/*     */   
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*  99 */     registerCookieSpec("default", RFC2109Spec.class);
/* 100 */     registerCookieSpec("rfc2109", RFC2109Spec.class);
/* 101 */     registerCookieSpec("compatibility", CookieSpecBase.class);
/* 102 */     registerCookieSpec("netscape", NetscapeDraftSpec.class);
/* 103 */     registerCookieSpec("ignoreCookies", IgnoreCookiesSpec.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/* 133 */   private static int defaultPolicy = 2;
/*     */   
/*     */ 
/* 136 */   protected static final Log LOG = LogFactory.getLog(CookiePolicy.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void registerCookieSpec(String id, Class clazz)
/*     */   {
/* 152 */     if (id == null) {
/* 153 */       throw new IllegalArgumentException("Id may not be null");
/*     */     }
/* 155 */     if (clazz == null) {
/* 156 */       throw new IllegalArgumentException("Cookie spec class may not be null");
/*     */     }
/* 158 */     SPECS.put(id.toLowerCase(), clazz);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void unregisterCookieSpec(String id)
/*     */   {
/* 169 */     if (id == null) {
/* 170 */       throw new IllegalArgumentException("Id may not be null");
/*     */     }
/* 172 */     SPECS.remove(id.toLowerCase());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CookieSpec getCookieSpec(String id)
/*     */     throws IllegalStateException
/*     */   {
/* 189 */     if (id == null) {
/* 190 */       throw new IllegalArgumentException("Id may not be null");
/*     */     }
/* 192 */     Class clazz = (Class)SPECS.get(id.toLowerCase());
/*     */     
/* 194 */     if (clazz != null) {
/*     */       try {
/* 196 */         return (CookieSpec)clazz.newInstance();
/*     */       } catch (Exception e) {
/* 198 */         LOG.error("Error initializing cookie spec: " + id, e);
/* 199 */         throw new IllegalStateException(id + " cookie spec implemented by " + clazz.getName() + " could not be initialized");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 204 */     throw new IllegalStateException("Unsupported cookie spec " + id);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static int getDefaultPolicy()
/*     */   {
/* 216 */     return defaultPolicy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static void setDefaultPolicy(int policy)
/*     */   {
/* 227 */     defaultPolicy = policy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static CookieSpec getSpecByPolicy(int policy)
/*     */   {
/* 237 */     switch (policy) {
/*     */     case 0: 
/* 239 */       return new CookieSpecBase();
/*     */     case 1: 
/* 241 */       return new NetscapeDraftSpec();
/*     */     case 2: 
/* 243 */       return new RFC2109Spec();
/*     */     }
/* 245 */     return getDefaultSpec();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CookieSpec getDefaultSpec()
/*     */   {
/*     */     try
/*     */     {
/* 261 */       return getCookieSpec("default");
/*     */     } catch (IllegalStateException e) {
/* 263 */       LOG.warn("Default cookie policy is not registered"); }
/* 264 */     return new RFC2109Spec();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static CookieSpec getSpecByVersion(int ver)
/*     */   {
/* 286 */     switch (ver) {
/*     */     case 0: 
/* 288 */       return new NetscapeDraftSpec();
/*     */     case 1: 
/* 290 */       return new RFC2109Spec();
/*     */     }
/* 292 */     return getDefaultSpec();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static CookieSpec getCompatibilitySpec()
/*     */   {
/* 303 */     return getSpecByPolicy(0);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\cookie\CookiePolicy.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */