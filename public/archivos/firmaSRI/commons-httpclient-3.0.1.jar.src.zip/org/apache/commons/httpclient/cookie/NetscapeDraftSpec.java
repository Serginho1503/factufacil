/*     */ package org.apache.commons.httpclient.cookie;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.commons.httpclient.Cookie;
/*     */ import org.apache.commons.httpclient.HeaderElement;
/*     */ import org.apache.commons.httpclient.NameValuePair;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NetscapeDraftSpec
/*     */   extends CookieSpecBase
/*     */ {
/*     */   public Cookie[] parse(String host, int port, String path, boolean secure, String header)
/*     */     throws MalformedCookieException
/*     */   {
/* 106 */     CookieSpecBase.LOG.trace("enter NetscapeDraftSpec.parse(String, port, path, boolean, Header)");
/*     */     
/* 108 */     if (host == null) {
/* 109 */       throw new IllegalArgumentException("Host of origin may not be null");
/*     */     }
/* 111 */     if (host.trim().equals("")) {
/* 112 */       throw new IllegalArgumentException("Host of origin may not be blank");
/*     */     }
/* 114 */     if (port < 0) {
/* 115 */       throw new IllegalArgumentException("Invalid port: " + port);
/*     */     }
/* 117 */     if (path == null) {
/* 118 */       throw new IllegalArgumentException("Path of origin may not be null.");
/*     */     }
/* 120 */     if (header == null) {
/* 121 */       throw new IllegalArgumentException("Header may not be null.");
/*     */     }
/*     */     
/* 124 */     if (path.trim().equals("")) {
/* 125 */       path = "/";
/*     */     }
/* 127 */     host = host.toLowerCase();
/*     */     
/* 129 */     String defaultPath = path;
/* 130 */     int lastSlashIndex = defaultPath.lastIndexOf("/");
/* 131 */     if (lastSlashIndex >= 0) {
/* 132 */       if (lastSlashIndex == 0)
/*     */       {
/* 134 */         lastSlashIndex = 1;
/*     */       }
/* 136 */       defaultPath = defaultPath.substring(0, lastSlashIndex);
/*     */     }
/* 138 */     HeaderElement headerelement = new HeaderElement(header.toCharArray());
/* 139 */     Cookie cookie = new Cookie(host, headerelement.getName(), headerelement.getValue(), defaultPath, null, false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 146 */     NameValuePair[] parameters = headerelement.getParameters();
/*     */     
/* 148 */     if (parameters != null) {
/* 149 */       for (int j = 0; j < parameters.length; j++) {
/* 150 */         parseAttribute(parameters[j], cookie);
/*     */       }
/*     */     }
/* 153 */     return new Cookie[] { cookie };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parseAttribute(NameValuePair attribute, Cookie cookie)
/*     */     throws MalformedCookieException
/*     */   {
/* 170 */     if (attribute == null) {
/* 171 */       throw new IllegalArgumentException("Attribute may not be null.");
/*     */     }
/* 173 */     if (cookie == null) {
/* 174 */       throw new IllegalArgumentException("Cookie may not be null.");
/*     */     }
/* 176 */     String paramName = attribute.getName().toLowerCase();
/* 177 */     String paramValue = attribute.getValue();
/*     */     
/* 179 */     if (paramName.equals("expires"))
/*     */     {
/* 181 */       if (paramValue == null) {
/* 182 */         throw new MalformedCookieException("Missing value for expires attribute");
/*     */       }
/*     */       try
/*     */       {
/* 186 */         DateFormat expiryFormat = new SimpleDateFormat("EEE, dd-MMM-yyyy HH:mm:ss z", Locale.US);
/*     */         
/* 188 */         Date date = expiryFormat.parse(paramValue);
/* 189 */         cookie.setExpiryDate(date);
/*     */       } catch (ParseException e) {
/* 191 */         throw new MalformedCookieException("Invalid expires attribute: " + e.getMessage());
/*     */       }
/*     */     }
/*     */     else {
/* 195 */       super.parseAttribute(attribute, cookie);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean domainMatch(String host, String domain)
/*     */   {
/* 206 */     return host.endsWith(domain);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validate(String host, int port, String path, boolean secure, Cookie cookie)
/*     */     throws MalformedCookieException
/*     */   {
/* 225 */     CookieSpecBase.LOG.trace("enterNetscapeDraftCookieProcessor RCF2109CookieProcessor.validate(Cookie)");
/*     */     
/*     */ 
/* 228 */     super.validate(host, port, path, secure, cookie);
/*     */     
/* 230 */     if (host.indexOf(".") >= 0) {
/* 231 */       int domainParts = new StringTokenizer(cookie.getDomain(), ".").countTokens();
/*     */       
/*     */ 
/* 234 */       if (isSpecialDomain(cookie.getDomain())) {
/* 235 */         if (domainParts < 2) {
/* 236 */           throw new MalformedCookieException("Domain attribute \"" + cookie.getDomain() + "\" violates the Netscape cookie specification for " + "special domains");
/*     */ 
/*     */         }
/*     */         
/*     */ 
/*     */       }
/* 242 */       else if (domainParts < 3) {
/* 243 */         throw new MalformedCookieException("Domain attribute \"" + cookie.getDomain() + "\" violates the Netscape cookie specification");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isSpecialDomain(String domain)
/*     */   {
/* 258 */     String ucDomain = domain.toUpperCase();
/* 259 */     if ((ucDomain.endsWith(".COM")) || (ucDomain.endsWith(".EDU")) || (ucDomain.endsWith(".NET")) || (ucDomain.endsWith(".GOV")) || (ucDomain.endsWith(".MIL")) || (ucDomain.endsWith(".ORG")) || (ucDomain.endsWith(".INT")))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 266 */       return true;
/*     */     }
/* 268 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\cookie\NetscapeDraftSpec.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */