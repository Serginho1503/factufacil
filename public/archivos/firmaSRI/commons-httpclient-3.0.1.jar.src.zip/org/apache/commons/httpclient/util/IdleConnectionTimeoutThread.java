/*     */ package org.apache.commons.httpclient.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.httpclient.HttpConnectionManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IdleConnectionTimeoutThread
/*     */   extends Thread
/*     */ {
/*  46 */   private List connectionManagers = new ArrayList();
/*     */   
/*  48 */   private boolean shutdown = false;
/*     */   
/*  50 */   private long timeoutInterval = 1000L;
/*     */   
/*  52 */   private long connectionTimeout = 3000L;
/*     */   
/*     */   public IdleConnectionTimeoutThread() {
/*  55 */     setDaemon(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void addConnectionManager(HttpConnectionManager connectionManager)
/*     */   {
/*  66 */     if (this.shutdown) {
/*  67 */       throw new IllegalStateException("IdleConnectionTimeoutThread has been shutdown");
/*     */     }
/*  69 */     this.connectionManagers.add(connectionManager);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void removeConnectionManager(HttpConnectionManager connectionManager)
/*     */   {
/*  79 */     if (this.shutdown) {
/*  80 */       throw new IllegalStateException("IdleConnectionTimeoutThread has been shutdown");
/*     */     }
/*  82 */     this.connectionManagers.remove(connectionManager);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized void run()
/*     */   {
/*  89 */     while (!this.shutdown) {
/*  90 */       Iterator iter = this.connectionManagers.iterator();
/*     */       
/*  92 */       while (iter.hasNext()) {
/*  93 */         HttpConnectionManager connectionManager = (HttpConnectionManager)iter.next();
/*  94 */         connectionManager.closeIdleConnections(this.connectionTimeout);
/*     */       }
/*     */       try
/*     */       {
/*  98 */         wait(this.timeoutInterval);
/*     */       }
/*     */       catch (InterruptedException e) {}
/*     */     }
/*     */     
/* 103 */     this.connectionManagers.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized void shutdown()
/*     */   {
/* 110 */     this.shutdown = true;
/* 111 */     notifyAll();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setConnectionTimeout(long connectionTimeout)
/*     */   {
/* 122 */     if (this.shutdown) {
/* 123 */       throw new IllegalStateException("IdleConnectionTimeoutThread has been shutdown");
/*     */     }
/* 125 */     this.connectionTimeout = connectionTimeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setTimeoutInterval(long timeoutInterval)
/*     */   {
/* 134 */     if (this.shutdown) {
/* 135 */       throw new IllegalStateException("IdleConnectionTimeoutThread has been shutdown");
/*     */     }
/* 137 */     this.timeoutInterval = timeoutInterval;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\util\IdleConnectionTimeoutThread.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */