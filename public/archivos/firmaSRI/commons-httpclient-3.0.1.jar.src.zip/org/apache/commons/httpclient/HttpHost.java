/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import org.apache.commons.httpclient.protocol.Protocol;
/*     */ import org.apache.commons.httpclient.util.LangUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpHost
/*     */   implements Cloneable
/*     */ {
/*  49 */   private String hostname = null;
/*     */   
/*     */ 
/*  52 */   private int port = -1;
/*     */   
/*     */ 
/*  55 */   private Protocol protocol = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpHost(String hostname, int port, Protocol protocol)
/*     */   {
/*  66 */     if (hostname == null) {
/*  67 */       throw new IllegalArgumentException("Host name may not be null");
/*     */     }
/*  69 */     if (protocol == null) {
/*  70 */       throw new IllegalArgumentException("Protocol may not be null");
/*     */     }
/*  72 */     this.hostname = hostname;
/*  73 */     this.protocol = protocol;
/*  74 */     if (port >= 0) {
/*  75 */       this.port = port;
/*     */     } else {
/*  77 */       this.port = this.protocol.getDefaultPort();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpHost(String hostname, int port)
/*     */   {
/*  88 */     this(hostname, port, Protocol.getProtocol("http"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpHost(String hostname)
/*     */   {
/*  97 */     this(hostname, -1, Protocol.getProtocol("http"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpHost(URI uri)
/*     */     throws URIException
/*     */   {
/* 106 */     this(uri.getHost(), uri.getPort(), Protocol.getProtocol(uri.getScheme()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpHost(HttpHost httphost)
/*     */   {
/* 116 */     this.hostname = httphost.hostname;
/* 117 */     this.port = httphost.port;
/* 118 */     this.protocol = httphost.protocol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 125 */     return new HttpHost(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHostName()
/*     */   {
/* 134 */     return this.hostname;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 143 */     return this.port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Protocol getProtocol()
/*     */   {
/* 151 */     return this.protocol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toURI()
/*     */   {
/* 160 */     StringBuffer buffer = new StringBuffer(50);
/* 161 */     if (this.protocol != null) {
/* 162 */       buffer.append(this.protocol.getScheme());
/* 163 */       buffer.append("://");
/*     */     }
/* 165 */     buffer.append(this.hostname);
/* 166 */     if (this.port != this.protocol.getDefaultPort()) {
/* 167 */       buffer.append(':');
/* 168 */       buffer.append(this.port);
/*     */     }
/* 170 */     return buffer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 177 */     StringBuffer buffer = new StringBuffer(50);
/* 178 */     buffer.append(toURI());
/* 179 */     return buffer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 187 */     if ((o instanceof HttpHost))
/*     */     {
/* 189 */       if (o == this) {
/* 190 */         return true;
/*     */       }
/* 192 */       HttpHost that = (HttpHost)o;
/* 193 */       if (!this.hostname.equalsIgnoreCase(that.hostname)) {
/* 194 */         return false;
/*     */       }
/* 196 */       if (this.port != that.port) {
/* 197 */         return false;
/*     */       }
/* 199 */       if (!this.protocol.equals(that.protocol)) {
/* 200 */         return false;
/*     */       }
/*     */       
/* 203 */       return true;
/*     */     }
/* 205 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 213 */     int hash = 17;
/* 214 */     hash = LangUtils.hashCode(hash, this.hostname);
/* 215 */     hash = LangUtils.hashCode(hash, this.port);
/* 216 */     hash = LangUtils.hashCode(hash, this.protocol);
/* 217 */     return hash;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\HttpHost.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */