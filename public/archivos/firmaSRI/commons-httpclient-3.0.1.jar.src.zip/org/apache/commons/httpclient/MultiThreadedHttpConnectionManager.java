/*      */ package org.apache.commons.httpclient;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.lang.ref.Reference;
/*      */ import java.lang.ref.ReferenceQueue;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.net.InetAddress;
/*      */ import java.net.SocketException;
/*      */ import java.util.AbstractList;
/*      */ import java.util.AbstractMap;
/*      */ import java.util.AbstractSequentialList;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.WeakHashMap;
/*      */ import org.apache.commons.httpclient.params.DefaultHttpParams;
/*      */ import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
/*      */ import org.apache.commons.httpclient.params.HttpConnectionParams;
/*      */ import org.apache.commons.httpclient.protocol.Protocol;
/*      */ import org.apache.commons.httpclient.util.IdleConnectionHandler;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MultiThreadedHttpConnectionManager
/*      */   implements HttpConnectionManager
/*      */ {
/*   69 */   private static final Log LOG = LogFactory.getLog(MultiThreadedHttpConnectionManager.class);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int DEFAULT_MAX_HOST_CONNECTIONS = 2;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int DEFAULT_MAX_TOTAL_CONNECTIONS = 20;
/*      */   
/*      */ 
/*      */ 
/*   81 */   private static final Map REFERENCE_TO_CONNECTION_SOURCE = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   87 */   private static final ReferenceQueue REFERENCE_QUEUE = new ReferenceQueue();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static ReferenceQueueThread REFERENCE_QUEUE_THREAD;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   97 */   private static WeakHashMap ALL_CONNECTION_MANAGERS = new WeakHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void shutdownAll()
/*      */   {
/*  112 */     synchronized (REFERENCE_TO_CONNECTION_SOURCE)
/*      */     {
/*  114 */       synchronized (ALL_CONNECTION_MANAGERS) {
/*  115 */         Iterator connIter = ALL_CONNECTION_MANAGERS.keySet().iterator();
/*  116 */         while (connIter.hasNext()) {
/*  117 */           MultiThreadedHttpConnectionManager connManager = (MultiThreadedHttpConnectionManager)connIter.next();
/*      */           
/*  119 */           connIter.remove();
/*  120 */           connManager.shutdown();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  125 */       if (REFERENCE_QUEUE_THREAD != null) {
/*  126 */         REFERENCE_QUEUE_THREAD.shutdown();
/*  127 */         REFERENCE_QUEUE_THREAD = null;
/*      */       }
/*  129 */       REFERENCE_TO_CONNECTION_SOURCE.clear();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void storeReferenceToConnection(HttpConnectionWithReference connection, HostConfiguration hostConfiguration, ConnectionPool connectionPool)
/*      */   {
/*  156 */     ConnectionSource source = new ConnectionSource(null);
/*  157 */     source.connectionPool = connectionPool;
/*  158 */     source.hostConfiguration = hostConfiguration;
/*      */     
/*  160 */     synchronized (REFERENCE_TO_CONNECTION_SOURCE)
/*      */     {
/*      */ 
/*  163 */       if (REFERENCE_QUEUE_THREAD == null) {
/*  164 */         REFERENCE_QUEUE_THREAD = new ReferenceQueueThread();
/*  165 */         REFERENCE_QUEUE_THREAD.start();
/*      */       }
/*      */       
/*  168 */       REFERENCE_TO_CONNECTION_SOURCE.put(connection.reference, source);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void shutdownCheckedOutConnections(ConnectionPool connectionPool)
/*      */   {
/*  182 */     ArrayList connectionsToClose = new ArrayList();
/*      */     
/*  184 */     synchronized (REFERENCE_TO_CONNECTION_SOURCE)
/*      */     {
/*  186 */       Iterator referenceIter = REFERENCE_TO_CONNECTION_SOURCE.keySet().iterator();
/*  187 */       while (referenceIter.hasNext()) {
/*  188 */         Reference ref = (Reference)referenceIter.next();
/*  189 */         ConnectionSource source = (ConnectionSource)REFERENCE_TO_CONNECTION_SOURCE.get(ref);
/*      */         
/*  191 */         if (source.connectionPool == connectionPool) {
/*  192 */           referenceIter.remove();
/*  193 */           HttpConnection connection = (HttpConnection)ref.get();
/*  194 */           if (connection != null) {
/*  195 */             connectionsToClose.add(connection);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  203 */     for (Iterator i = connectionsToClose.iterator(); i.hasNext();) {
/*  204 */       HttpConnection connection = (HttpConnection)i.next();
/*  205 */       connection.close();
/*      */       
/*      */ 
/*  208 */       connection.setHttpConnectionManager(null);
/*  209 */       connection.releaseConnection();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void removeReferenceToConnection(HttpConnectionWithReference connection)
/*      */   {
/*  223 */     synchronized (REFERENCE_TO_CONNECTION_SOURCE) {
/*  224 */       REFERENCE_TO_CONNECTION_SOURCE.remove(connection.reference);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  234 */   private HttpConnectionManagerParams params = new HttpConnectionManagerParams();
/*      */   
/*      */ 
/*      */   private ConnectionPool connectionPool;
/*      */   
/*  239 */   private boolean shutdown = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MultiThreadedHttpConnectionManager()
/*      */   {
/*  248 */     this.connectionPool = new ConnectionPool(null);
/*  249 */     synchronized (ALL_CONNECTION_MANAGERS) {
/*  250 */       ALL_CONNECTION_MANAGERS.put(this, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void shutdown()
/*      */   {
/*  266 */     synchronized (this.connectionPool) {
/*  267 */       if (!this.shutdown) {
/*  268 */         this.shutdown = true;
/*  269 */         this.connectionPool.shutdown();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public boolean isConnectionStaleCheckingEnabled()
/*      */   {
/*  285 */     return this.params.isStaleCheckingEnabled();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setConnectionStaleCheckingEnabled(boolean connectionStaleCheckingEnabled)
/*      */   {
/*  300 */     this.params.setStaleCheckingEnabled(connectionStaleCheckingEnabled);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setMaxConnectionsPerHost(int maxHostConnections)
/*      */   {
/*  314 */     this.params.setDefaultMaxConnectionsPerHost(maxHostConnections);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public int getMaxConnectionsPerHost()
/*      */   {
/*  328 */     return this.params.getDefaultMaxConnectionsPerHost();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setMaxTotalConnections(int maxTotalConnections)
/*      */   {
/*  340 */     this.params.setMaxTotalConnections(maxTotalConnections);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public int getMaxTotalConnections()
/*      */   {
/*  352 */     return this.params.getMaxTotalConnections();
/*      */   }
/*      */   
/*      */ 
/*      */   public HttpConnection getConnection(HostConfiguration hostConfiguration)
/*      */   {
/*      */     for (;;)
/*      */     {
/*      */       try
/*      */       {
/*  362 */         return getConnectionWithTimeout(hostConfiguration, 0L);
/*      */ 
/*      */       }
/*      */       catch (ConnectionPoolTimeoutException e)
/*      */       {
/*  367 */         LOG.debug("Unexpected exception while waiting for connection", e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpConnection getConnectionWithTimeout(HostConfiguration hostConfiguration, long timeout)
/*      */     throws ConnectionPoolTimeoutException
/*      */   {
/*  383 */     LOG.trace("enter HttpConnectionManager.getConnectionWithTimeout(HostConfiguration, long)");
/*      */     
/*  385 */     if (hostConfiguration == null) {
/*  386 */       throw new IllegalArgumentException("hostConfiguration is null");
/*      */     }
/*      */     
/*  389 */     if (LOG.isDebugEnabled()) {
/*  390 */       LOG.debug("HttpConnectionManager.getConnection:  config = " + hostConfiguration + ", timeout = " + timeout);
/*      */     }
/*      */     
/*      */ 
/*  394 */     HttpConnection conn = doGetConnection(hostConfiguration, timeout);
/*      */     
/*      */ 
/*      */ 
/*  398 */     return new HttpConnectionAdapter(conn);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public HttpConnection getConnection(HostConfiguration hostConfiguration, long timeout)
/*      */     throws HttpException
/*      */   {
/*  409 */     LOG.trace("enter HttpConnectionManager.getConnection(HostConfiguration, long)");
/*      */     try {
/*  411 */       return getConnectionWithTimeout(hostConfiguration, timeout);
/*      */     } catch (ConnectionPoolTimeoutException e) {
/*  413 */       throw new HttpException(e.getMessage());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private HttpConnection doGetConnection(HostConfiguration hostConfiguration, long timeout)
/*      */     throws ConnectionPoolTimeoutException
/*      */   {
/*  435 */     HttpConnection connection = null;
/*      */     
/*  437 */     int maxHostConnections = this.params.getMaxConnectionsPerHost(hostConfiguration);
/*  438 */     int maxTotalConnections = this.params.getMaxTotalConnections();
/*      */     
/*  440 */     synchronized (this.connectionPool)
/*      */     {
/*      */ 
/*      */ 
/*  444 */       hostConfiguration = new HostConfiguration(hostConfiguration);
/*  445 */       HostConnectionPool hostPool = this.connectionPool.getHostPool(hostConfiguration);
/*  446 */       WaitingThread waitingThread = null;
/*      */       
/*  448 */       boolean useTimeout = timeout > 0L;
/*  449 */       long timeToWait = timeout;
/*  450 */       long startWait = 0L;
/*  451 */       long endWait = 0L;
/*      */       
/*  453 */       while (connection == null)
/*      */       {
/*  455 */         if (this.shutdown) {
/*  456 */           throw new IllegalStateException("Connection factory has been shutdown.");
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  461 */         if (hostPool.freeConnections.size() > 0) {
/*  462 */           connection = this.connectionPool.getFreeConnection(hostConfiguration);
/*      */ 
/*      */ 
/*      */         }
/*  466 */         else if ((hostPool.numConnections < maxHostConnections) && (this.connectionPool.numConnections < maxTotalConnections))
/*      */         {
/*      */ 
/*  469 */           connection = this.connectionPool.createConnection(hostConfiguration);
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*  474 */         else if ((hostPool.numConnections < maxHostConnections) && (this.connectionPool.freeConnections.size() > 0))
/*      */         {
/*      */ 
/*  477 */           this.connectionPool.deleteLeastUsedConnection();
/*  478 */           connection = this.connectionPool.createConnection(hostConfiguration);
/*      */ 
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/*      */ 
/*      */           try
/*      */           {
/*      */ 
/*  489 */             if ((useTimeout) && (timeToWait <= 0L)) {
/*  490 */               throw new ConnectionPoolTimeoutException("Timeout waiting for connection");
/*      */             }
/*      */             
/*  493 */             if (LOG.isDebugEnabled()) {
/*  494 */               LOG.debug("Unable to get a connection, waiting..., hostConfig=" + hostConfiguration);
/*      */             }
/*      */             
/*  497 */             if (waitingThread == null) {
/*  498 */               waitingThread = new WaitingThread(null);
/*  499 */               waitingThread.hostConnectionPool = hostPool;
/*  500 */               waitingThread.thread = Thread.currentThread();
/*      */             }
/*      */             
/*  503 */             if (useTimeout) {
/*  504 */               startWait = System.currentTimeMillis();
/*      */             }
/*      */             
/*  507 */             hostPool.waitingThreads.addLast(waitingThread);
/*  508 */             this.connectionPool.waitingThreads.addLast(waitingThread);
/*  509 */             this.connectionPool.wait(timeToWait);
/*      */             
/*      */ 
/*      */ 
/*  513 */             hostPool.waitingThreads.remove(waitingThread);
/*  514 */             this.connectionPool.waitingThreads.remove(waitingThread);
/*      */           }
/*      */           catch (InterruptedException e) {}finally
/*      */           {
/*  518 */             if (useTimeout) {
/*  519 */               endWait = System.currentTimeMillis();
/*  520 */               timeToWait -= endWait - startWait;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  526 */     return connection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getConnectionsInPool(HostConfiguration hostConfiguration)
/*      */   {
/*  540 */     synchronized (this.connectionPool) {
/*  541 */       HostConnectionPool hostPool = this.connectionPool.getHostPool(hostConfiguration);
/*  542 */       int i = hostPool.numConnections;return i;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getConnectionsInPool()
/*      */   {
/*  555 */     synchronized (this.connectionPool) {
/*  556 */       int i = this.connectionPool.numConnections;return i;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public int getConnectionsInUse(HostConfiguration hostConfiguration)
/*      */   {
/*  569 */     return getConnectionsInPool(hostConfiguration);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public int getConnectionsInUse()
/*      */   {
/*  580 */     return getConnectionsInPool();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void deleteClosedConnections()
/*      */   {
/*  592 */     this.connectionPool.deleteClosedConnections();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void closeIdleConnections(long idleTimeout)
/*      */   {
/*  599 */     this.connectionPool.closeIdleConnections(idleTimeout);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void releaseConnection(HttpConnection conn)
/*      */   {
/*  610 */     LOG.trace("enter HttpConnectionManager.releaseConnection(HttpConnection)");
/*      */     
/*  612 */     if ((conn instanceof HttpConnectionAdapter))
/*      */     {
/*  614 */       conn = ((HttpConnectionAdapter)conn).getWrappedConnection();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  621 */     SimpleHttpConnectionManager.finishLastResponse(conn);
/*      */     
/*  623 */     this.connectionPool.freeConnection(conn);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private HostConfiguration configurationForConnection(HttpConnection conn)
/*      */   {
/*  633 */     HostConfiguration connectionConfiguration = new HostConfiguration();
/*      */     
/*  635 */     connectionConfiguration.setHost(conn.getHost(), conn.getPort(), conn.getProtocol());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  640 */     if (conn.getLocalAddress() != null) {
/*  641 */       connectionConfiguration.setLocalAddress(conn.getLocalAddress());
/*      */     }
/*  643 */     if (conn.getProxyHost() != null) {
/*  644 */       connectionConfiguration.setProxy(conn.getProxyHost(), conn.getProxyPort());
/*      */     }
/*      */     
/*  647 */     return connectionConfiguration;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpConnectionManagerParams getParams()
/*      */   {
/*  659 */     return this.params;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setParams(HttpConnectionManagerParams params)
/*      */   {
/*  671 */     if (params == null) {
/*  672 */       throw new IllegalArgumentException("Parameters may not be null");
/*      */     }
/*  674 */     this.params = params;
/*      */   }
/*      */   
/*      */   private class ConnectionPool
/*      */   {
/*      */     ConnectionPool(MultiThreadedHttpConnectionManager.1 x1) {
/*  680 */       this();
/*      */     }
/*      */     
/*  683 */     private LinkedList freeConnections = new LinkedList();
/*      */     
/*      */ 
/*  686 */     private LinkedList waitingThreads = new LinkedList();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  692 */     private final Map mapHosts = new HashMap();
/*      */     
/*  694 */     private IdleConnectionHandler idleConnectionHandler = new IdleConnectionHandler();
/*      */     
/*      */ 
/*  697 */     private int numConnections = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public synchronized void shutdown()
/*      */     {
/*  705 */       Iterator iter = this.freeConnections.iterator();
/*  706 */       while (iter.hasNext()) {
/*  707 */         HttpConnection conn = (HttpConnection)iter.next();
/*  708 */         iter.remove();
/*  709 */         conn.close();
/*      */       }
/*      */       
/*      */ 
/*  713 */       MultiThreadedHttpConnectionManager.shutdownCheckedOutConnections(this);
/*      */       
/*      */ 
/*  716 */       iter = this.waitingThreads.iterator();
/*  717 */       while (iter.hasNext()) {
/*  718 */         MultiThreadedHttpConnectionManager.WaitingThread waiter = (MultiThreadedHttpConnectionManager.WaitingThread)iter.next();
/*  719 */         iter.remove();
/*  720 */         waiter.thread.interrupt();
/*      */       }
/*      */       
/*      */ 
/*  724 */       this.mapHosts.clear();
/*      */       
/*      */ 
/*  727 */       this.idleConnectionHandler.removeAll();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public synchronized HttpConnection createConnection(HostConfiguration hostConfiguration)
/*      */     {
/*  737 */       MultiThreadedHttpConnectionManager.HostConnectionPool hostPool = getHostPool(hostConfiguration);
/*  738 */       if (MultiThreadedHttpConnectionManager.LOG.isDebugEnabled()) {
/*  739 */         MultiThreadedHttpConnectionManager.LOG.debug("Allocating new connection, hostConfig=" + hostConfiguration);
/*      */       }
/*  741 */       MultiThreadedHttpConnectionManager.HttpConnectionWithReference connection = new MultiThreadedHttpConnectionManager.HttpConnectionWithReference(hostConfiguration);
/*      */       
/*  743 */       connection.getParams().setDefaults(MultiThreadedHttpConnectionManager.this.params);
/*  744 */       connection.setHttpConnectionManager(MultiThreadedHttpConnectionManager.this);
/*  745 */       this.numConnections += 1;
/*  746 */       hostPool.numConnections += 1;
/*      */       
/*      */ 
/*      */ 
/*  750 */       MultiThreadedHttpConnectionManager.storeReferenceToConnection(connection, hostConfiguration, this);
/*  751 */       return connection;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public synchronized void handleLostConnection(HostConfiguration config)
/*      */     {
/*  761 */       MultiThreadedHttpConnectionManager.HostConnectionPool hostPool = getHostPool(config);
/*  762 */       hostPool.numConnections -= 1;
/*      */       
/*  764 */       this.numConnections -= 1;
/*  765 */       notifyWaitingThread(config);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public synchronized MultiThreadedHttpConnectionManager.HostConnectionPool getHostPool(HostConfiguration hostConfiguration)
/*      */     {
/*  775 */       MultiThreadedHttpConnectionManager.LOG.trace("enter HttpConnectionManager.ConnectionPool.getHostPool(HostConfiguration)");
/*      */       
/*      */ 
/*  778 */       MultiThreadedHttpConnectionManager.HostConnectionPool listConnections = (MultiThreadedHttpConnectionManager.HostConnectionPool)this.mapHosts.get(hostConfiguration);
/*      */       
/*  780 */       if (listConnections == null)
/*      */       {
/*  782 */         listConnections = new MultiThreadedHttpConnectionManager.HostConnectionPool(null);
/*  783 */         listConnections.hostConfiguration = hostConfiguration;
/*  784 */         this.mapHosts.put(hostConfiguration, listConnections);
/*      */       }
/*      */       
/*  787 */       return listConnections;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public synchronized HttpConnection getFreeConnection(HostConfiguration hostConfiguration)
/*      */     {
/*  798 */       MultiThreadedHttpConnectionManager.HttpConnectionWithReference connection = null;
/*      */       
/*  800 */       MultiThreadedHttpConnectionManager.HostConnectionPool hostPool = getHostPool(hostConfiguration);
/*      */       
/*  802 */       if (hostPool.freeConnections.size() > 0) {
/*  803 */         connection = (MultiThreadedHttpConnectionManager.HttpConnectionWithReference)hostPool.freeConnections.removeFirst();
/*  804 */         this.freeConnections.remove(connection);
/*      */         
/*      */ 
/*  807 */         MultiThreadedHttpConnectionManager.storeReferenceToConnection(connection, hostConfiguration, this);
/*  808 */         if (MultiThreadedHttpConnectionManager.LOG.isDebugEnabled()) {
/*  809 */           MultiThreadedHttpConnectionManager.LOG.debug("Getting free connection, hostConfig=" + hostConfiguration);
/*      */         }
/*      */         
/*      */ 
/*  813 */         this.idleConnectionHandler.remove(connection);
/*  814 */       } else if (MultiThreadedHttpConnectionManager.LOG.isDebugEnabled()) {
/*  815 */         MultiThreadedHttpConnectionManager.LOG.debug("There were no free connections to get, hostConfig=" + hostConfiguration);
/*      */       }
/*      */       
/*  818 */       return connection;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public synchronized void deleteClosedConnections()
/*      */     {
/*  826 */       Iterator iter = this.freeConnections.iterator();
/*      */       
/*  828 */       while (iter.hasNext()) {
/*  829 */         HttpConnection conn = (HttpConnection)iter.next();
/*  830 */         if (!conn.isOpen()) {
/*  831 */           iter.remove();
/*  832 */           deleteConnection(conn);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public synchronized void closeIdleConnections(long idleTimeout)
/*      */     {
/*  842 */       this.idleConnectionHandler.closeIdleConnections(idleTimeout);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private synchronized void deleteConnection(HttpConnection connection)
/*      */     {
/*  856 */       HostConfiguration connectionConfiguration = MultiThreadedHttpConnectionManager.this.configurationForConnection(connection);
/*      */       
/*  858 */       if (MultiThreadedHttpConnectionManager.LOG.isDebugEnabled()) {
/*  859 */         MultiThreadedHttpConnectionManager.LOG.debug("Reclaiming connection, hostConfig=" + connectionConfiguration);
/*      */       }
/*      */       
/*  862 */       connection.close();
/*      */       
/*  864 */       MultiThreadedHttpConnectionManager.HostConnectionPool hostPool = getHostPool(connectionConfiguration);
/*      */       
/*  866 */       hostPool.freeConnections.remove(connection);
/*  867 */       hostPool.numConnections -= 1;
/*  868 */       this.numConnections -= 1;
/*      */       
/*      */ 
/*  871 */       this.idleConnectionHandler.remove(connection);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public synchronized void deleteLeastUsedConnection()
/*      */     {
/*  879 */       HttpConnection connection = (HttpConnection)this.freeConnections.removeFirst();
/*      */       
/*  881 */       if (connection != null) {
/*  882 */         deleteConnection(connection);
/*  883 */       } else if (MultiThreadedHttpConnectionManager.LOG.isDebugEnabled()) {
/*  884 */         MultiThreadedHttpConnectionManager.LOG.debug("Attempted to reclaim an unused connection but there were none.");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public synchronized void notifyWaitingThread(HostConfiguration configuration)
/*      */     {
/*  895 */       notifyWaitingThread(getHostPool(configuration));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public synchronized void notifyWaitingThread(MultiThreadedHttpConnectionManager.HostConnectionPool hostPool)
/*      */     {
/*  910 */       MultiThreadedHttpConnectionManager.WaitingThread waitingThread = null;
/*      */       
/*  912 */       if (hostPool.waitingThreads.size() > 0) {
/*  913 */         if (MultiThreadedHttpConnectionManager.LOG.isDebugEnabled()) {
/*  914 */           MultiThreadedHttpConnectionManager.LOG.debug("Notifying thread waiting on host pool, hostConfig=" + hostPool.hostConfiguration);
/*      */         }
/*      */         
/*  917 */         waitingThread = (MultiThreadedHttpConnectionManager.WaitingThread)hostPool.waitingThreads.removeFirst();
/*  918 */         this.waitingThreads.remove(waitingThread);
/*  919 */       } else if (this.waitingThreads.size() > 0) {
/*  920 */         if (MultiThreadedHttpConnectionManager.LOG.isDebugEnabled()) {
/*  921 */           MultiThreadedHttpConnectionManager.LOG.debug("No-one waiting on host pool, notifying next waiting thread.");
/*      */         }
/*  923 */         waitingThread = (MultiThreadedHttpConnectionManager.WaitingThread)this.waitingThreads.removeFirst();
/*  924 */         waitingThread.hostConnectionPool.waitingThreads.remove(waitingThread);
/*  925 */       } else if (MultiThreadedHttpConnectionManager.LOG.isDebugEnabled()) {
/*  926 */         MultiThreadedHttpConnectionManager.LOG.debug("Notifying no-one, there are no waiting threads");
/*      */       }
/*      */       
/*  929 */       if (waitingThread != null) {
/*  930 */         waitingThread.thread.interrupt();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void freeConnection(HttpConnection conn)
/*      */     {
/*  940 */       HostConfiguration connectionConfiguration = MultiThreadedHttpConnectionManager.this.configurationForConnection(conn);
/*      */       
/*  942 */       if (MultiThreadedHttpConnectionManager.LOG.isDebugEnabled()) {
/*  943 */         MultiThreadedHttpConnectionManager.LOG.debug("Freeing connection, hostConfig=" + connectionConfiguration);
/*      */       }
/*      */       
/*  946 */       synchronized (this)
/*      */       {
/*  948 */         if (MultiThreadedHttpConnectionManager.this.shutdown)
/*      */         {
/*      */ 
/*  951 */           conn.close();
/*  952 */           return;
/*      */         }
/*      */         
/*  955 */         MultiThreadedHttpConnectionManager.HostConnectionPool hostPool = getHostPool(connectionConfiguration);
/*      */         
/*      */ 
/*  958 */         hostPool.freeConnections.add(conn);
/*  959 */         if (hostPool.numConnections == 0)
/*      */         {
/*  961 */           MultiThreadedHttpConnectionManager.LOG.error("Host connection pool not found, hostConfig=" + connectionConfiguration);
/*      */           
/*  963 */           hostPool.numConnections = 1;
/*      */         }
/*      */         
/*  966 */         this.freeConnections.add(conn);
/*      */         
/*      */ 
/*  969 */         MultiThreadedHttpConnectionManager.removeReferenceToConnection((MultiThreadedHttpConnectionManager.HttpConnectionWithReference)conn);
/*  970 */         if (this.numConnections == 0)
/*      */         {
/*  972 */           MultiThreadedHttpConnectionManager.LOG.error("Host connection pool not found, hostConfig=" + connectionConfiguration);
/*      */           
/*  974 */           this.numConnections = 1;
/*      */         }
/*      */         
/*      */ 
/*  978 */         this.idleConnectionHandler.add(conn);
/*      */         
/*  980 */         notifyWaitingThread(hostPool); } }
/*      */     
/*      */     private ConnectionPool() {} }
/*      */   
/*      */   private static class ConnectionSource { public MultiThreadedHttpConnectionManager.ConnectionPool connectionPool;
/*      */     public HostConfiguration hostConfiguration;
/*      */     
/*      */     private ConnectionSource() {}
/*      */     
/*  989 */     ConnectionSource(MultiThreadedHttpConnectionManager.1 x0) { this(); }
/*      */   }
/*      */   
/*      */ 
/*      */   private static class HostConnectionPool
/*      */   {
/*      */     public HostConfiguration hostConfiguration;
/*      */     
/*      */ 
/*      */     private HostConnectionPool() {}
/*      */     
/*      */     HostConnectionPool(MultiThreadedHttpConnectionManager.1 x0)
/*      */     {
/* 1002 */       this();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1007 */     public LinkedList freeConnections = new LinkedList();
/*      */     
/*      */ 
/* 1010 */     public LinkedList waitingThreads = new LinkedList();
/*      */     
/*      */ 
/* 1013 */     public int numConnections = 0; }
/*      */   
/*      */   private static class WaitingThread { public Thread thread;
/*      */     public MultiThreadedHttpConnectionManager.HostConnectionPool hostConnectionPool;
/*      */     
/*      */     private WaitingThread() {}
/*      */     
/* 1020 */     WaitingThread(MultiThreadedHttpConnectionManager.1 x0) { this(); }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class ReferenceQueueThread
/*      */     extends Thread
/*      */   {
/* 1034 */     private boolean shutdown = false;
/*      */     
/*      */ 
/*      */ 
/*      */     public ReferenceQueueThread()
/*      */     {
/* 1040 */       setDaemon(true);
/* 1041 */       setName("MultiThreadedHttpConnectionManager cleanup");
/*      */     }
/*      */     
/*      */     public void shutdown() {
/* 1045 */       this.shutdown = true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private void handleReference(Reference ref)
/*      */     {
/* 1055 */       MultiThreadedHttpConnectionManager.ConnectionSource source = null;
/*      */       
/* 1057 */       synchronized (MultiThreadedHttpConnectionManager.REFERENCE_TO_CONNECTION_SOURCE) {
/* 1058 */         source = (MultiThreadedHttpConnectionManager.ConnectionSource)MultiThreadedHttpConnectionManager.REFERENCE_TO_CONNECTION_SOURCE.remove(ref);
/*      */       }
/*      */       
/*      */ 
/* 1062 */       if (source != null) {
/* 1063 */         if (MultiThreadedHttpConnectionManager.LOG.isDebugEnabled()) {
/* 1064 */           MultiThreadedHttpConnectionManager.LOG.debug("Connection reclaimed by garbage collector, hostConfig=" + source.hostConfiguration);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1069 */         source.connectionPool.handleLostConnection(source.hostConfiguration);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void run()
/*      */     {
/* 1077 */       while (!this.shutdown)
/*      */       {
/*      */         try
/*      */         {
/*      */ 
/* 1082 */           Reference ref = MultiThreadedHttpConnectionManager.REFERENCE_QUEUE.remove(1000L);
/* 1083 */           if (ref != null) {
/* 1084 */             handleReference(ref);
/*      */           }
/*      */         } catch (InterruptedException e) {
/* 1087 */           MultiThreadedHttpConnectionManager.LOG.debug("ReferenceQueueThread interrupted", e);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class HttpConnectionWithReference
/*      */     extends HttpConnection
/*      */   {
/* 1099 */     public WeakReference reference = new WeakReference(this, MultiThreadedHttpConnectionManager.REFERENCE_QUEUE);
/*      */     
/*      */ 
/*      */ 
/*      */     public HttpConnectionWithReference(HostConfiguration hostConfiguration)
/*      */     {
/* 1105 */       super();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class HttpConnectionAdapter
/*      */     extends HttpConnection
/*      */   {
/*      */     private HttpConnection wrappedConnection;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public HttpConnectionAdapter(HttpConnection connection)
/*      */     {
/* 1124 */       super(connection.getPort(), connection.getProtocol());
/* 1125 */       this.wrappedConnection = connection;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     protected boolean hasConnection()
/*      */     {
/* 1133 */       return this.wrappedConnection != null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     HttpConnection getWrappedConnection()
/*      */     {
/* 1140 */       return this.wrappedConnection;
/*      */     }
/*      */     
/*      */     public void close() {
/* 1144 */       if (hasConnection()) {
/* 1145 */         this.wrappedConnection.close();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public InetAddress getLocalAddress()
/*      */     {
/* 1152 */       if (hasConnection()) {
/* 1153 */         return this.wrappedConnection.getLocalAddress();
/*      */       }
/* 1155 */       return null;
/*      */     }
/*      */     
/*      */     /**
/*      */      * @deprecated
/*      */      */
/*      */     public boolean isStaleCheckingEnabled()
/*      */     {
/* 1163 */       if (hasConnection()) {
/* 1164 */         return this.wrappedConnection.isStaleCheckingEnabled();
/*      */       }
/* 1166 */       return false;
/*      */     }
/*      */     
/*      */     public void setLocalAddress(InetAddress localAddress)
/*      */     {
/* 1171 */       if (hasConnection()) {
/* 1172 */         this.wrappedConnection.setLocalAddress(localAddress);
/*      */       } else {
/* 1174 */         throw new IllegalStateException("Connection has been released");
/*      */       }
/*      */     }
/*      */     
/*      */     /**
/*      */      * @deprecated
/*      */      */
/*      */     public void setStaleCheckingEnabled(boolean staleCheckEnabled) {
/* 1182 */       if (hasConnection()) {
/* 1183 */         this.wrappedConnection.setStaleCheckingEnabled(staleCheckEnabled);
/*      */       } else {
/* 1185 */         throw new IllegalStateException("Connection has been released");
/*      */       }
/*      */     }
/*      */     
/*      */     public String getHost() {
/* 1190 */       if (hasConnection()) {
/* 1191 */         return this.wrappedConnection.getHost();
/*      */       }
/* 1193 */       return null;
/*      */     }
/*      */     
/*      */     public HttpConnectionManager getHttpConnectionManager()
/*      */     {
/* 1198 */       if (hasConnection()) {
/* 1199 */         return this.wrappedConnection.getHttpConnectionManager();
/*      */       }
/* 1201 */       return null;
/*      */     }
/*      */     
/*      */     public InputStream getLastResponseInputStream()
/*      */     {
/* 1206 */       if (hasConnection()) {
/* 1207 */         return this.wrappedConnection.getLastResponseInputStream();
/*      */       }
/* 1209 */       return null;
/*      */     }
/*      */     
/*      */     public int getPort()
/*      */     {
/* 1214 */       if (hasConnection()) {
/* 1215 */         return this.wrappedConnection.getPort();
/*      */       }
/* 1217 */       return -1;
/*      */     }
/*      */     
/*      */     public Protocol getProtocol()
/*      */     {
/* 1222 */       if (hasConnection()) {
/* 1223 */         return this.wrappedConnection.getProtocol();
/*      */       }
/* 1225 */       return null;
/*      */     }
/*      */     
/*      */     public String getProxyHost()
/*      */     {
/* 1230 */       if (hasConnection()) {
/* 1231 */         return this.wrappedConnection.getProxyHost();
/*      */       }
/* 1233 */       return null;
/*      */     }
/*      */     
/*      */     public int getProxyPort()
/*      */     {
/* 1238 */       if (hasConnection()) {
/* 1239 */         return this.wrappedConnection.getProxyPort();
/*      */       }
/* 1241 */       return -1;
/*      */     }
/*      */     
/*      */     public OutputStream getRequestOutputStream()
/*      */       throws IOException, IllegalStateException
/*      */     {
/* 1247 */       if (hasConnection()) {
/* 1248 */         return this.wrappedConnection.getRequestOutputStream();
/*      */       }
/* 1250 */       return null;
/*      */     }
/*      */     
/*      */     public InputStream getResponseInputStream()
/*      */       throws IOException, IllegalStateException
/*      */     {
/* 1256 */       if (hasConnection()) {
/* 1257 */         return this.wrappedConnection.getResponseInputStream();
/*      */       }
/* 1259 */       return null;
/*      */     }
/*      */     
/*      */     public boolean isOpen()
/*      */     {
/* 1264 */       if (hasConnection()) {
/* 1265 */         return this.wrappedConnection.isOpen();
/*      */       }
/* 1267 */       return false;
/*      */     }
/*      */     
/*      */     public boolean closeIfStale() throws IOException
/*      */     {
/* 1272 */       if (hasConnection()) {
/* 1273 */         return this.wrappedConnection.closeIfStale();
/*      */       }
/* 1275 */       return false;
/*      */     }
/*      */     
/*      */     public boolean isProxied()
/*      */     {
/* 1280 */       if (hasConnection()) {
/* 1281 */         return this.wrappedConnection.isProxied();
/*      */       }
/* 1283 */       return false;
/*      */     }
/*      */     
/*      */     public boolean isResponseAvailable() throws IOException
/*      */     {
/* 1288 */       if (hasConnection()) {
/* 1289 */         return this.wrappedConnection.isResponseAvailable();
/*      */       }
/* 1291 */       return false;
/*      */     }
/*      */     
/*      */     public boolean isResponseAvailable(int timeout) throws IOException
/*      */     {
/* 1296 */       if (hasConnection()) {
/* 1297 */         return this.wrappedConnection.isResponseAvailable(timeout);
/*      */       }
/* 1299 */       return false;
/*      */     }
/*      */     
/*      */     public boolean isSecure()
/*      */     {
/* 1304 */       if (hasConnection()) {
/* 1305 */         return this.wrappedConnection.isSecure();
/*      */       }
/* 1307 */       return false;
/*      */     }
/*      */     
/*      */     public boolean isTransparent()
/*      */     {
/* 1312 */       if (hasConnection()) {
/* 1313 */         return this.wrappedConnection.isTransparent();
/*      */       }
/* 1315 */       return false;
/*      */     }
/*      */     
/*      */     public void open() throws IOException
/*      */     {
/* 1320 */       if (hasConnection()) {
/* 1321 */         this.wrappedConnection.open();
/*      */       } else {
/* 1323 */         throw new IllegalStateException("Connection has been released");
/*      */       }
/*      */     }
/*      */     
/*      */     /**
/*      */      * @deprecated
/*      */      */
/*      */     public void print(String data) throws IOException, IllegalStateException
/*      */     {
/* 1332 */       if (hasConnection()) {
/* 1333 */         this.wrappedConnection.print(data);
/*      */       } else {
/* 1335 */         throw new IllegalStateException("Connection has been released");
/*      */       }
/*      */     }
/*      */     
/*      */     public void printLine() throws IOException, IllegalStateException
/*      */     {
/* 1341 */       if (hasConnection()) {
/* 1342 */         this.wrappedConnection.printLine();
/*      */       } else {
/* 1344 */         throw new IllegalStateException("Connection has been released");
/*      */       }
/*      */     }
/*      */     
/*      */     /**
/*      */      * @deprecated
/*      */      */
/*      */     public void printLine(String data) throws IOException, IllegalStateException
/*      */     {
/* 1353 */       if (hasConnection()) {
/* 1354 */         this.wrappedConnection.printLine(data);
/*      */       } else {
/* 1356 */         throw new IllegalStateException("Connection has been released");
/*      */       }
/*      */     }
/*      */     
/*      */     /**
/*      */      * @deprecated
/*      */      */
/*      */     public String readLine() throws IOException, IllegalStateException {
/* 1364 */       if (hasConnection()) {
/* 1365 */         return this.wrappedConnection.readLine();
/*      */       }
/* 1367 */       throw new IllegalStateException("Connection has been released");
/*      */     }
/*      */     
/*      */     public String readLine(String charset) throws IOException, IllegalStateException
/*      */     {
/* 1372 */       if (hasConnection()) {
/* 1373 */         return this.wrappedConnection.readLine(charset);
/*      */       }
/* 1375 */       throw new IllegalStateException("Connection has been released");
/*      */     }
/*      */     
/*      */     public void releaseConnection()
/*      */     {
/* 1380 */       if ((!isLocked()) && (hasConnection())) {
/* 1381 */         HttpConnection wrappedConnection = this.wrappedConnection;
/* 1382 */         this.wrappedConnection = null;
/* 1383 */         wrappedConnection.releaseConnection();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     /**
/*      */      * @deprecated
/*      */      */
/*      */     public void setConnectionTimeout(int timeout)
/*      */     {
/* 1393 */       if (hasConnection()) {
/* 1394 */         this.wrappedConnection.setConnectionTimeout(timeout);
/*      */       }
/*      */     }
/*      */     
/*      */     public void setHost(String host)
/*      */       throws IllegalStateException
/*      */     {
/* 1401 */       if (hasConnection()) {
/* 1402 */         this.wrappedConnection.setHost(host);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void setHttpConnectionManager(HttpConnectionManager httpConnectionManager)
/*      */     {
/* 1409 */       if (hasConnection()) {
/* 1410 */         this.wrappedConnection.setHttpConnectionManager(httpConnectionManager);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void setLastResponseInputStream(InputStream inStream)
/*      */     {
/* 1417 */       if (hasConnection()) {
/* 1418 */         this.wrappedConnection.setLastResponseInputStream(inStream);
/*      */       }
/*      */     }
/*      */     
/*      */     public void setPort(int port)
/*      */       throws IllegalStateException
/*      */     {
/* 1425 */       if (hasConnection()) {
/* 1426 */         this.wrappedConnection.setPort(port);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void setProtocol(Protocol protocol)
/*      */     {
/* 1433 */       if (hasConnection()) {
/* 1434 */         this.wrappedConnection.setProtocol(protocol);
/*      */       }
/*      */     }
/*      */     
/*      */     public void setProxyHost(String host)
/*      */       throws IllegalStateException
/*      */     {
/* 1441 */       if (hasConnection()) {
/* 1442 */         this.wrappedConnection.setProxyHost(host);
/*      */       }
/*      */     }
/*      */     
/*      */     public void setProxyPort(int port)
/*      */       throws IllegalStateException
/*      */     {
/* 1449 */       if (hasConnection()) {
/* 1450 */         this.wrappedConnection.setProxyPort(port);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     /**
/*      */      * @deprecated
/*      */      */
/*      */     public void setSoTimeout(int timeout)
/*      */       throws SocketException, IllegalStateException
/*      */     {
/* 1461 */       if (hasConnection()) {
/* 1462 */         this.wrappedConnection.setSoTimeout(timeout);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     /**
/*      */      * @deprecated
/*      */      */
/*      */     public void shutdownOutput()
/*      */     {
/* 1472 */       if (hasConnection()) {
/* 1473 */         this.wrappedConnection.shutdownOutput();
/*      */       }
/*      */     }
/*      */     
/*      */     public void tunnelCreated()
/*      */       throws IllegalStateException, IOException
/*      */     {
/* 1480 */       if (hasConnection()) {
/* 1481 */         this.wrappedConnection.tunnelCreated();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void write(byte[] data, int offset, int length)
/*      */       throws IOException, IllegalStateException
/*      */     {
/* 1489 */       if (hasConnection()) {
/* 1490 */         this.wrappedConnection.write(data, offset, length);
/*      */       } else {
/* 1492 */         throw new IllegalStateException("Connection has been released");
/*      */       }
/*      */     }
/*      */     
/*      */     public void write(byte[] data) throws IOException, IllegalStateException
/*      */     {
/* 1498 */       if (hasConnection()) {
/* 1499 */         this.wrappedConnection.write(data);
/*      */       } else {
/* 1501 */         throw new IllegalStateException("Connection has been released");
/*      */       }
/*      */     }
/*      */     
/*      */     public void writeLine() throws IOException, IllegalStateException
/*      */     {
/* 1507 */       if (hasConnection()) {
/* 1508 */         this.wrappedConnection.writeLine();
/*      */       } else {
/* 1510 */         throw new IllegalStateException("Connection has been released");
/*      */       }
/*      */     }
/*      */     
/*      */     public void writeLine(byte[] data) throws IOException, IllegalStateException
/*      */     {
/* 1516 */       if (hasConnection()) {
/* 1517 */         this.wrappedConnection.writeLine(data);
/*      */       } else {
/* 1519 */         throw new IllegalStateException("Connection has been released");
/*      */       }
/*      */     }
/*      */     
/*      */     public void flushRequestOutputStream() throws IOException {
/* 1524 */       if (hasConnection()) {
/* 1525 */         this.wrappedConnection.flushRequestOutputStream();
/*      */       } else {
/* 1527 */         throw new IllegalStateException("Connection has been released");
/*      */       }
/*      */     }
/*      */     
/*      */     /**
/*      */      * @deprecated
/*      */      */
/*      */     public int getSoTimeout() throws SocketException {
/* 1535 */       if (hasConnection()) {
/* 1536 */         return this.wrappedConnection.getSoTimeout();
/*      */       }
/* 1538 */       throw new IllegalStateException("Connection has been released");
/*      */     }
/*      */     
/*      */     /**
/*      */      * @deprecated
/*      */      */
/*      */     public String getVirtualHost()
/*      */     {
/* 1546 */       if (hasConnection()) {
/* 1547 */         return this.wrappedConnection.getVirtualHost();
/*      */       }
/* 1549 */       throw new IllegalStateException("Connection has been released");
/*      */     }
/*      */     
/*      */     /**
/*      */      * @deprecated
/*      */      */
/*      */     public void setVirtualHost(String host) throws IllegalStateException
/*      */     {
/* 1557 */       if (hasConnection()) {
/* 1558 */         this.wrappedConnection.setVirtualHost(host);
/*      */       } else {
/* 1560 */         throw new IllegalStateException("Connection has been released");
/*      */       }
/*      */     }
/*      */     
/*      */     public int getSendBufferSize() throws SocketException {
/* 1565 */       if (hasConnection()) {
/* 1566 */         return this.wrappedConnection.getSendBufferSize();
/*      */       }
/* 1568 */       throw new IllegalStateException("Connection has been released");
/*      */     }
/*      */     
/*      */     /**
/*      */      * @deprecated
/*      */      */
/*      */     public void setSendBufferSize(int sendBufferSize) throws SocketException
/*      */     {
/* 1576 */       if (hasConnection()) {
/* 1577 */         this.wrappedConnection.setSendBufferSize(sendBufferSize);
/*      */       } else {
/* 1579 */         throw new IllegalStateException("Connection has been released");
/*      */       }
/*      */     }
/*      */     
/*      */     public HttpConnectionParams getParams() {
/* 1584 */       if (hasConnection()) {
/* 1585 */         return this.wrappedConnection.getParams();
/*      */       }
/* 1587 */       throw new IllegalStateException("Connection has been released");
/*      */     }
/*      */     
/*      */     public void setParams(HttpConnectionParams params)
/*      */     {
/* 1592 */       if (hasConnection()) {
/* 1593 */         this.wrappedConnection.setParams(params);
/*      */       } else {
/* 1595 */         throw new IllegalStateException("Connection has been released");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void print(String data, String charset)
/*      */       throws IOException, IllegalStateException
/*      */     {
/* 1603 */       if (hasConnection()) {
/* 1604 */         this.wrappedConnection.print(data, charset);
/*      */       } else {
/* 1606 */         throw new IllegalStateException("Connection has been released");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void printLine(String data, String charset)
/*      */       throws IOException, IllegalStateException
/*      */     {
/* 1615 */       if (hasConnection()) {
/* 1616 */         this.wrappedConnection.printLine(data, charset);
/*      */       } else {
/* 1618 */         throw new IllegalStateException("Connection has been released");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void setSocketTimeout(int timeout)
/*      */       throws SocketException, IllegalStateException
/*      */     {
/* 1626 */       if (hasConnection()) {
/* 1627 */         this.wrappedConnection.setSocketTimeout(timeout);
/*      */       } else {
/* 1629 */         throw new IllegalStateException("Connection has been released");
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\MultiThreadedHttpConnectionManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */