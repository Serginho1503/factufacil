package org.apache.commons.httpclient.auth;

import org.apache.commons.httpclient.Credentials;
import org.apache.commons.httpclient.HttpMethod;

public abstract interface AuthScheme
{
  public abstract void processChallenge(String paramString)
    throws MalformedChallengeException;
  
  public abstract String getSchemeName();
  
  public abstract String getParameter(String paramString);
  
  public abstract String getRealm();
  
  /**
   * @deprecated
   */
  public abstract String getID();
  
  public abstract boolean isConnectionBased();
  
  public abstract boolean isComplete();
  
  /**
   * @deprecated
   */
  public abstract String authenticate(Credentials paramCredentials, String paramString1, String paramString2)
    throws AuthenticationException;
  
  public abstract String authenticate(Credentials paramCredentials, HttpMethod paramHttpMethod)
    throws AuthenticationException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\auth\AuthScheme.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */