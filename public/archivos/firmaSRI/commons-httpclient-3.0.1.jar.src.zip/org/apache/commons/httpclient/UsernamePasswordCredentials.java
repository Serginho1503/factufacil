/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import org.apache.commons.httpclient.util.LangUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UsernamePasswordCredentials
/*     */   implements Credentials
/*     */ {
/*     */   private String userName;
/*     */   private String password;
/*     */   
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public UsernamePasswordCredentials() {}
/*     */   
/*     */   public UsernamePasswordCredentials(String usernamePassword)
/*     */   {
/*  67 */     if (usernamePassword == null) {
/*  68 */       throw new IllegalArgumentException("Username:password string may not be null");
/*     */     }
/*  70 */     int atColon = usernamePassword.indexOf(':');
/*  71 */     if (atColon >= 0) {
/*  72 */       this.userName = usernamePassword.substring(0, atColon);
/*  73 */       this.password = usernamePassword.substring(atColon + 1);
/*     */     } else {
/*  75 */       this.userName = usernamePassword;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UsernamePasswordCredentials(String userName, String password)
/*     */   {
/*  88 */     if (userName == null) {
/*  89 */       throw new IllegalArgumentException("Username may not be null");
/*     */     }
/*  91 */     this.userName = userName;
/*  92 */     this.password = password;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setUserName(String userName)
/*     */   {
/* 121 */     if (userName == null) {
/* 122 */       throw new IllegalArgumentException("Username may not be null");
/*     */     }
/* 124 */     this.userName = userName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUserName()
/*     */   {
/* 135 */     return this.userName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setPassword(String password)
/*     */   {
/* 148 */     this.password = password;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPassword()
/*     */   {
/* 159 */     return this.password;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 169 */     StringBuffer result = new StringBuffer();
/* 170 */     result.append(this.userName);
/* 171 */     result.append(":");
/* 172 */     result.append(this.password == null ? "null" : this.password);
/* 173 */     return result.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 182 */     int hash = 17;
/* 183 */     hash = LangUtils.hashCode(hash, this.userName);
/* 184 */     hash = LangUtils.hashCode(hash, this.password);
/* 185 */     return hash;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 197 */     if (o == null) return false;
/* 198 */     if (this == o) { return true;
/*     */     }
/*     */     
/* 201 */     if (getClass().equals(o.getClass())) {
/* 202 */       UsernamePasswordCredentials that = (UsernamePasswordCredentials)o;
/*     */       
/* 204 */       if ((LangUtils.equals(this.userName, that.userName)) && (LangUtils.equals(this.password, that.password)))
/*     */       {
/* 206 */         return true;
/*     */       }
/*     */     }
/* 209 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\UsernamePasswordCredentials.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */