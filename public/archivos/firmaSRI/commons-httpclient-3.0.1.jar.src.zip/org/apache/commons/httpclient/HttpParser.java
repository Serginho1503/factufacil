/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import org.apache.commons.httpclient.util.EncodingUtil;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpParser
/*     */ {
/*  53 */   private static final Log LOG = LogFactory.getLog(HttpParser.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] readRawLine(InputStream inputStream)
/*     */     throws IOException
/*     */   {
/*  73 */     LOG.trace("enter HttpParser.readRawLine()");
/*     */     
/*  75 */     ByteArrayOutputStream buf = new ByteArrayOutputStream();
/*     */     int ch;
/*  77 */     while ((ch = inputStream.read()) >= 0) { int i;
/*  78 */       buf.write(i);
/*  79 */       if (i == 10) {
/*     */         break;
/*     */       }
/*     */     }
/*  83 */     if (buf.size() == 0) {
/*  84 */       return null;
/*     */     }
/*  86 */     return buf.toByteArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String readLine(InputStream inputStream, String charset)
/*     */     throws IOException
/*     */   {
/* 104 */     LOG.trace("enter HttpParser.readLine(InputStream, String)");
/* 105 */     byte[] rawdata = readRawLine(inputStream);
/* 106 */     if (rawdata == null) {
/* 107 */       return null;
/*     */     }
/*     */     
/* 110 */     int len = rawdata.length;
/* 111 */     int offset = 0;
/* 112 */     if ((len > 0) && 
/* 113 */       (rawdata[(len - 1)] == 10)) {
/* 114 */       offset++;
/* 115 */       if ((len > 1) && 
/* 116 */         (rawdata[(len - 2)] == 13)) {
/* 117 */         offset++;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 122 */     return EncodingUtil.getString(rawdata, 0, len - offset, charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static String readLine(InputStream inputStream)
/*     */     throws IOException
/*     */   {
/* 140 */     LOG.trace("enter HttpParser.readLine(InputStream)");
/* 141 */     return readLine(inputStream, "US-ASCII");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Header[] parseHeaders(InputStream is, String charset)
/*     */     throws IOException, HttpException
/*     */   {
/* 159 */     LOG.trace("enter HeaderParser.parseHeaders(InputStream, String)");
/*     */     
/* 161 */     ArrayList headers = new ArrayList();
/* 162 */     String name = null;
/* 163 */     StringBuffer value = null;
/*     */     for (;;) {
/* 165 */       String line = readLine(is, charset);
/* 166 */       if ((line == null) || (line.trim().length() < 1)) {
/*     */         break;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 174 */       if ((line.charAt(0) == ' ') || (line.charAt(0) == '\t'))
/*     */       {
/*     */ 
/* 177 */         if (value != null) {
/* 178 */           value.append(' ');
/* 179 */           value.append(line.trim());
/*     */         }
/*     */       }
/*     */       else {
/* 183 */         if (name != null) {
/* 184 */           headers.add(new Header(name, value.toString()));
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 189 */         int colon = line.indexOf(":");
/* 190 */         if (colon < 0) {
/* 191 */           throw new ProtocolException("Unable to parse header: " + line);
/*     */         }
/* 193 */         name = line.substring(0, colon).trim();
/* 194 */         value = new StringBuffer(line.substring(colon + 1).trim());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 200 */     if (name != null) {
/* 201 */       headers.add(new Header(name, value.toString()));
/*     */     }
/*     */     
/* 204 */     return (Header[])headers.toArray(new Header[headers.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static Header[] parseHeaders(InputStream is)
/*     */     throws IOException, HttpException
/*     */   {
/* 221 */     LOG.trace("enter HeaderParser.parseHeaders(InputStream, String)");
/* 222 */     return parseHeaders(is, "US-ASCII");
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\HttpParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */