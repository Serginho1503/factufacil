/*     */ package org.apache.commons.httpclient.methods.multipart;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import org.apache.commons.httpclient.util.EncodingUtil;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Part
/*     */ {
/*  54 */   private static final Log LOG = LogFactory.getLog(Part.class);
/*     */   
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   protected static final String BOUNDARY = "----------------314159265358979323846";
/*     */   
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*  66 */   protected static final byte[] BOUNDARY_BYTES = EncodingUtil.getAsciiBytes("----------------314159265358979323846");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */   private static final byte[] DEFAULT_BOUNDARY_BYTES = BOUNDARY_BYTES;
/*     */   
/*     */ 
/*     */   protected static final String CRLF = "\r\n";
/*     */   
/*     */ 
/*  78 */   protected static final byte[] CRLF_BYTES = EncodingUtil.getAsciiBytes("\r\n");
/*     */   
/*     */ 
/*     */   protected static final String QUOTE = "\"";
/*     */   
/*     */ 
/*  84 */   protected static final byte[] QUOTE_BYTES = EncodingUtil.getAsciiBytes("\"");
/*     */   
/*     */ 
/*     */ 
/*     */   protected static final String EXTRA = "--";
/*     */   
/*     */ 
/*  91 */   protected static final byte[] EXTRA_BYTES = EncodingUtil.getAsciiBytes("--");
/*     */   
/*     */ 
/*     */ 
/*     */   protected static final String CONTENT_DISPOSITION = "Content-Disposition: form-data; name=";
/*     */   
/*     */ 
/*  98 */   protected static final byte[] CONTENT_DISPOSITION_BYTES = EncodingUtil.getAsciiBytes("Content-Disposition: form-data; name=");
/*     */   
/*     */ 
/*     */ 
/*     */   protected static final String CONTENT_TYPE = "Content-Type: ";
/*     */   
/*     */ 
/* 105 */   protected static final byte[] CONTENT_TYPE_BYTES = EncodingUtil.getAsciiBytes("Content-Type: ");
/*     */   
/*     */ 
/*     */ 
/*     */   protected static final String CHARSET = "; charset=";
/*     */   
/*     */ 
/* 112 */   protected static final byte[] CHARSET_BYTES = EncodingUtil.getAsciiBytes("; charset=");
/*     */   
/*     */ 
/*     */ 
/*     */   protected static final String CONTENT_TRANSFER_ENCODING = "Content-Transfer-Encoding: ";
/*     */   
/*     */ 
/* 119 */   protected static final byte[] CONTENT_TRANSFER_ENCODING_BYTES = EncodingUtil.getAsciiBytes("Content-Transfer-Encoding: ");
/*     */   
/*     */   private byte[] boundaryBytes;
/*     */   
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static String getBoundary()
/*     */   {
/* 128 */     return "----------------314159265358979323846";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String getName();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String getContentType();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String getCharSet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String getTransferEncoding();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected byte[] getPartBoundary()
/*     */   {
/* 168 */     if (this.boundaryBytes == null)
/*     */     {
/* 170 */       return DEFAULT_BOUNDARY_BYTES;
/*     */     }
/* 172 */     return this.boundaryBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setPartBoundary(byte[] boundaryBytes)
/*     */   {
/* 184 */     this.boundaryBytes = boundaryBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRepeatable()
/*     */   {
/* 194 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void sendStart(OutputStream out)
/*     */     throws IOException
/*     */   {
/* 203 */     LOG.trace("enter sendStart(OutputStream out)");
/* 204 */     out.write(EXTRA_BYTES);
/* 205 */     out.write(getPartBoundary());
/* 206 */     out.write(CRLF_BYTES);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void sendDispositionHeader(OutputStream out)
/*     */     throws IOException
/*     */   {
/* 216 */     LOG.trace("enter sendDispositionHeader(OutputStream out)");
/* 217 */     out.write(CONTENT_DISPOSITION_BYTES);
/* 218 */     out.write(QUOTE_BYTES);
/* 219 */     out.write(EncodingUtil.getAsciiBytes(getName()));
/* 220 */     out.write(QUOTE_BYTES);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void sendContentTypeHeader(OutputStream out)
/*     */     throws IOException
/*     */   {
/* 229 */     LOG.trace("enter sendContentTypeHeader(OutputStream out)");
/* 230 */     String contentType = getContentType();
/* 231 */     if (contentType != null) {
/* 232 */       out.write(CRLF_BYTES);
/* 233 */       out.write(CONTENT_TYPE_BYTES);
/* 234 */       out.write(EncodingUtil.getAsciiBytes(contentType));
/* 235 */       String charSet = getCharSet();
/* 236 */       if (charSet != null) {
/* 237 */         out.write(CHARSET_BYTES);
/* 238 */         out.write(EncodingUtil.getAsciiBytes(charSet));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void sendTransferEncodingHeader(OutputStream out)
/*     */     throws IOException
/*     */   {
/* 251 */     LOG.trace("enter sendTransferEncodingHeader(OutputStream out)");
/* 252 */     String transferEncoding = getTransferEncoding();
/* 253 */     if (transferEncoding != null) {
/* 254 */       out.write(CRLF_BYTES);
/* 255 */       out.write(CONTENT_TRANSFER_ENCODING_BYTES);
/* 256 */       out.write(EncodingUtil.getAsciiBytes(transferEncoding));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void sendEndOfHeader(OutputStream out)
/*     */     throws IOException
/*     */   {
/* 266 */     LOG.trace("enter sendEndOfHeader(OutputStream out)");
/* 267 */     out.write(CRLF_BYTES);
/* 268 */     out.write(CRLF_BYTES);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void sendData(OutputStream paramOutputStream)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract long lengthOfData()
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void sendEnd(OutputStream out)
/*     */     throws IOException
/*     */   {
/* 292 */     LOG.trace("enter sendEnd(OutputStream out)");
/* 293 */     out.write(CRLF_BYTES);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void send(OutputStream out)
/*     */     throws IOException
/*     */   {
/* 305 */     LOG.trace("enter send(OutputStream out)");
/* 306 */     sendStart(out);
/* 307 */     sendDispositionHeader(out);
/* 308 */     sendContentTypeHeader(out);
/* 309 */     sendTransferEncodingHeader(out);
/* 310 */     sendEndOfHeader(out);
/* 311 */     sendData(out);
/* 312 */     sendEnd(out);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long length()
/*     */     throws IOException
/*     */   {
/* 325 */     LOG.trace("enter length()");
/* 326 */     if (lengthOfData() < 0L) {
/* 327 */       return -1L;
/*     */     }
/* 329 */     ByteArrayOutputStream overhead = new ByteArrayOutputStream();
/* 330 */     sendStart(overhead);
/* 331 */     sendDispositionHeader(overhead);
/* 332 */     sendContentTypeHeader(overhead);
/* 333 */     sendTransferEncodingHeader(overhead);
/* 334 */     sendEndOfHeader(overhead);
/* 335 */     sendEnd(overhead);
/* 336 */     return overhead.size() + lengthOfData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 345 */     return getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void sendParts(OutputStream out, Part[] parts)
/*     */     throws IOException
/*     */   {
/* 358 */     sendParts(out, parts, DEFAULT_BOUNDARY_BYTES);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void sendParts(OutputStream out, Part[] parts, byte[] partBoundary)
/*     */     throws IOException
/*     */   {
/* 375 */     if (parts == null) {
/* 376 */       throw new IllegalArgumentException("Parts may not be null");
/*     */     }
/* 378 */     if ((partBoundary == null) || (partBoundary.length == 0)) {
/* 379 */       throw new IllegalArgumentException("partBoundary may not be empty");
/*     */     }
/* 381 */     for (int i = 0; i < parts.length; i++)
/*     */     {
/* 383 */       parts[i].setPartBoundary(partBoundary);
/* 384 */       parts[i].send(out);
/*     */     }
/* 386 */     out.write(EXTRA_BYTES);
/* 387 */     out.write(partBoundary);
/* 388 */     out.write(EXTRA_BYTES);
/* 389 */     out.write(CRLF_BYTES);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static long getLengthOfParts(Part[] parts)
/*     */     throws IOException
/*     */   {
/* 402 */     return getLengthOfParts(parts, DEFAULT_BOUNDARY_BYTES);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static long getLengthOfParts(Part[] parts, byte[] partBoundary)
/*     */     throws IOException
/*     */   {
/* 417 */     LOG.trace("getLengthOfParts(Parts[])");
/* 418 */     if (parts == null) {
/* 419 */       throw new IllegalArgumentException("Parts may not be null");
/*     */     }
/* 421 */     long total = 0L;
/* 422 */     for (int i = 0; i < parts.length; i++)
/*     */     {
/* 424 */       parts[i].setPartBoundary(partBoundary);
/* 425 */       long l = parts[i].length();
/* 426 */       if (l < 0L) {
/* 427 */         return -1L;
/*     */       }
/* 429 */       total += l;
/*     */     }
/* 431 */     total += EXTRA_BYTES.length;
/* 432 */     total += partBoundary.length;
/* 433 */     total += EXTRA_BYTES.length;
/* 434 */     total += CRLF_BYTES.length;
/* 435 */     return total;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\methods\multipart\Part.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */