/*     */ package org.apache.commons.httpclient.auth;
/*     */ 
/*     */ import org.apache.commons.httpclient.util.LangUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthScope
/*     */ {
/*  50 */   public static final String ANY_HOST = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int ANY_PORT = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  60 */   public static final String ANY_REALM = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  65 */   public static final String ANY_SCHEME = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */   public static final AuthScope ANY = new AuthScope(ANY_HOST, -1, ANY_REALM, ANY_SCHEME);
/*     */   
/*     */ 
/*  75 */   private String scheme = null;
/*     */   
/*     */ 
/*  78 */   private String realm = null;
/*     */   
/*     */ 
/*  81 */   private String host = null;
/*     */   
/*     */ 
/*  84 */   private int port = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AuthScope(String host, int port, String realm, String scheme)
/*     */   {
/* 108 */     this.host = (host == null ? ANY_HOST : host.toLowerCase());
/* 109 */     this.port = (port < 0 ? -1 : port);
/* 110 */     this.realm = (realm == null ? ANY_REALM : realm);
/* 111 */     this.scheme = (scheme == null ? ANY_SCHEME : scheme.toUpperCase());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AuthScope(String host, int port, String realm)
/*     */   {
/* 131 */     this(host, port, realm, ANY_SCHEME);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AuthScope(String host, int port)
/*     */   {
/* 148 */     this(host, port, ANY_REALM, ANY_SCHEME);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AuthScope(AuthScope authscope)
/*     */   {
/* 158 */     if (authscope == null) {
/* 159 */       throw new IllegalArgumentException("Scope may not be null");
/*     */     }
/* 161 */     this.host = authscope.getHost();
/* 162 */     this.port = authscope.getPort();
/* 163 */     this.realm = authscope.getRealm();
/* 164 */     this.scheme = authscope.getScheme();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHost()
/*     */   {
/* 173 */     return this.host;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 182 */     return this.port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRealm()
/*     */   {
/* 191 */     return this.realm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getScheme()
/*     */   {
/* 200 */     return this.scheme;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean paramsEqual(String p1, String p2)
/*     */   {
/* 210 */     if (p1 == null) {
/* 211 */       return p1 == p2;
/*     */     }
/* 213 */     return p1.equals(p2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean paramsEqual(int p1, int p2)
/*     */   {
/* 224 */     return p1 == p2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int match(AuthScope that)
/*     */   {
/* 237 */     int factor = 0;
/* 238 */     if (paramsEqual(this.scheme, that.scheme)) {
/* 239 */       factor++;
/*     */     }
/* 241 */     else if ((this.scheme != ANY_SCHEME) && (that.scheme != ANY_SCHEME)) {
/* 242 */       return -1;
/*     */     }
/*     */     
/* 245 */     if (paramsEqual(this.realm, that.realm)) {
/* 246 */       factor += 2;
/*     */     }
/* 248 */     else if ((this.realm != ANY_REALM) && (that.realm != ANY_REALM)) {
/* 249 */       return -1;
/*     */     }
/*     */     
/* 252 */     if (paramsEqual(this.port, that.port)) {
/* 253 */       factor += 4;
/*     */     }
/* 255 */     else if ((this.port != -1) && (that.port != -1)) {
/* 256 */       return -1;
/*     */     }
/*     */     
/* 259 */     if (paramsEqual(this.host, that.host)) {
/* 260 */       factor += 8;
/*     */     }
/* 262 */     else if ((this.host != ANY_HOST) && (that.host != ANY_HOST)) {
/* 263 */       return -1;
/*     */     }
/*     */     
/* 266 */     return factor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 273 */     if (o == null) {
/* 274 */       return false;
/*     */     }
/* 276 */     if (o == this) {
/* 277 */       return true;
/*     */     }
/* 279 */     if (!(o instanceof AuthScope)) {
/* 280 */       return super.equals(o);
/*     */     }
/* 282 */     AuthScope that = (AuthScope)o;
/* 283 */     return (paramsEqual(this.host, that.host)) && (paramsEqual(this.port, that.port)) && (paramsEqual(this.realm, that.realm)) && (paramsEqual(this.scheme, that.scheme));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 294 */     StringBuffer buffer = new StringBuffer();
/* 295 */     if (this.scheme != null) {
/* 296 */       buffer.append(this.scheme.toUpperCase());
/* 297 */       buffer.append(' ');
/*     */     }
/* 299 */     if (this.realm != null) {
/* 300 */       buffer.append('\'');
/* 301 */       buffer.append(this.realm);
/* 302 */       buffer.append('\'');
/*     */     } else {
/* 304 */       buffer.append("<any realm>");
/*     */     }
/* 306 */     if (this.host != null) {
/* 307 */       buffer.append('@');
/* 308 */       buffer.append(this.host);
/* 309 */       if (this.port >= 0) {
/* 310 */         buffer.append(':');
/* 311 */         buffer.append(this.port);
/*     */       }
/*     */     }
/* 314 */     return buffer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 321 */     int hash = 17;
/* 322 */     hash = LangUtils.hashCode(hash, this.host);
/* 323 */     hash = LangUtils.hashCode(hash, this.port);
/* 324 */     hash = LangUtils.hashCode(hash, this.realm);
/* 325 */     hash = LangUtils.hashCode(hash, this.scheme);
/* 326 */     return hash;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\auth\AuthScope.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */