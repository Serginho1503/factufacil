/*     */ package org.apache.commons.httpclient.methods;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.httpclient.HttpConnection;
/*     */ import org.apache.commons.httpclient.HttpException;
/*     */ import org.apache.commons.httpclient.HttpMethodBase;
/*     */ import org.apache.commons.httpclient.HttpState;
/*     */ import org.apache.commons.httpclient.methods.multipart.FilePart;
/*     */ import org.apache.commons.httpclient.methods.multipart.Part;
/*     */ import org.apache.commons.httpclient.methods.multipart.StringPart;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ /**
/*     */  * @deprecated
/*     */  */
/*     */ public class MultipartPostMethod
/*     */   extends ExpectContinueMethod
/*     */ {
/*     */   public static final String MULTIPART_FORM_CONTENT_TYPE = "multipart/form-data";
/*  85 */   private static final Log LOG = LogFactory.getLog(MultipartPostMethod.class);
/*     */   
/*     */ 
/*  88 */   private final List parameters = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MultipartPostMethod() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MultipartPostMethod(String uri)
/*     */   {
/* 103 */     super(uri);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean hasRequestContent()
/*     */   {
/* 114 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 122 */     return "POST";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addParameter(String parameterName, String parameterValue)
/*     */   {
/* 132 */     LOG.trace("enter addParameter(String parameterName, String parameterValue)");
/* 133 */     Part param = new StringPart(parameterName, parameterValue);
/* 134 */     this.parameters.add(param);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addParameter(String parameterName, File parameterFile)
/*     */     throws FileNotFoundException
/*     */   {
/* 146 */     LOG.trace("enter MultipartPostMethod.addParameter(String parameterName, File parameterFile)");
/*     */     
/* 148 */     Part param = new FilePart(parameterName, parameterFile);
/* 149 */     this.parameters.add(param);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addParameter(String parameterName, String fileName, File parameterFile)
/*     */     throws FileNotFoundException
/*     */   {
/* 162 */     LOG.trace("enter MultipartPostMethod.addParameter(String parameterName, String fileName, File parameterFile)");
/*     */     
/* 164 */     Part param = new FilePart(parameterName, fileName, parameterFile);
/* 165 */     this.parameters.add(param);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addPart(Part part)
/*     */   {
/* 174 */     LOG.trace("enter addPart(Part part)");
/* 175 */     this.parameters.add(part);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Part[] getParts()
/*     */   {
/* 184 */     return (Part[])this.parameters.toArray(new Part[this.parameters.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addContentLengthRequestHeader(HttpState state, HttpConnection conn)
/*     */     throws IOException, HttpException
/*     */   {
/* 204 */     LOG.trace("enter EntityEnclosingMethod.addContentLengthRequestHeader(HttpState, HttpConnection)");
/*     */     
/*     */ 
/* 207 */     if (getRequestHeader("Content-Length") == null) {
/* 208 */       long len = getRequestContentLength();
/* 209 */       addRequestHeader("Content-Length", String.valueOf(len));
/*     */     }
/* 211 */     removeRequestHeader("Transfer-Encoding");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addContentTypeRequestHeader(HttpState state, HttpConnection conn)
/*     */     throws IOException, HttpException
/*     */   {
/* 230 */     LOG.trace("enter EntityEnclosingMethod.addContentTypeRequestHeader(HttpState, HttpConnection)");
/*     */     
/*     */ 
/* 233 */     if (!this.parameters.isEmpty()) {
/* 234 */       StringBuffer buffer = new StringBuffer("multipart/form-data");
/* 235 */       if (Part.getBoundary() != null) {
/* 236 */         buffer.append("; boundary=");
/* 237 */         buffer.append(Part.getBoundary());
/*     */       }
/* 239 */       setRequestHeader("Content-Type", buffer.toString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addRequestHeaders(HttpState state, HttpConnection conn)
/*     */     throws IOException, HttpException
/*     */   {
/* 272 */     LOG.trace("enter MultipartPostMethod.addRequestHeaders(HttpState state, HttpConnection conn)");
/*     */     
/* 274 */     super.addRequestHeaders(state, conn);
/* 275 */     addContentLengthRequestHeader(state, conn);
/* 276 */     addContentTypeRequestHeader(state, conn);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean writeRequestBody(HttpState state, HttpConnection conn)
/*     */     throws IOException, HttpException
/*     */   {
/* 295 */     LOG.trace("enter MultipartPostMethod.writeRequestBody(HttpState state, HttpConnection conn)");
/*     */     
/* 297 */     OutputStream out = conn.getRequestOutputStream();
/* 298 */     Part.sendParts(out, getParts());
/* 299 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected long getRequestContentLength()
/*     */     throws IOException
/*     */   {
/* 311 */     LOG.trace("enter MultipartPostMethod.getRequestContentLength()");
/* 312 */     return Part.getLengthOfParts(getParts());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void recycle()
/*     */   {
/* 328 */     LOG.trace("enter MultipartPostMethod.recycle()");
/* 329 */     super.recycle();
/* 330 */     this.parameters.clear();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\methods\MultipartPostMethod.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */