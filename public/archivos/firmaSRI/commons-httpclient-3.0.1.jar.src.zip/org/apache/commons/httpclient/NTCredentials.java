/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import org.apache.commons.httpclient.util.LangUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NTCredentials
/*     */   extends UsernamePasswordCredentials
/*     */ {
/*     */   private String domain;
/*     */   private String host;
/*     */   
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public NTCredentials() {}
/*     */   
/*     */   public NTCredentials(String userName, String password, String host, String domain)
/*     */   {
/*  77 */     super(userName, password);
/*  78 */     if (domain == null) {
/*  79 */       throw new IllegalArgumentException("Domain may not be null");
/*     */     }
/*  81 */     this.domain = domain;
/*  82 */     if (host == null) {
/*  83 */       throw new IllegalArgumentException("Host may not be null");
/*     */     }
/*  85 */     this.host = host;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setDomain(String domain)
/*     */   {
/* 100 */     if (domain == null) {
/* 101 */       throw new IllegalArgumentException("Domain may not be null");
/*     */     }
/* 103 */     this.domain = domain;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDomain()
/*     */   {
/* 115 */     return this.domain;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setHost(String host)
/*     */   {
/* 127 */     if (host == null) {
/* 128 */       throw new IllegalArgumentException("Host may not be null");
/*     */     }
/* 130 */     this.host = host;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHost()
/*     */   {
/* 139 */     return this.host;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 147 */     StringBuffer sbResult = new StringBuffer(super.toString());
/*     */     
/* 149 */     sbResult.append("@");
/* 150 */     sbResult.append(this.host);
/* 151 */     sbResult.append(".");
/* 152 */     sbResult.append(this.domain);
/*     */     
/* 154 */     return sbResult.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 163 */     int hash = super.hashCode();
/* 164 */     hash = LangUtils.hashCode(hash, this.host);
/* 165 */     hash = LangUtils.hashCode(hash, this.domain);
/* 166 */     return hash;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 178 */     if (o == null) return false;
/* 179 */     if (this == o) return true;
/* 180 */     if ((super.equals(o)) && 
/* 181 */       ((o instanceof NTCredentials))) {
/* 182 */       NTCredentials that = (NTCredentials)o;
/*     */       
/* 184 */       return (LangUtils.equals(this.domain, that.domain)) && (LangUtils.equals(this.host, that.host));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 189 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\NTCredentials.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */