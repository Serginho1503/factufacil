/*     */ package org.apache.commons.httpclient.auth;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.httpclient.Header;
/*     */ import org.apache.commons.httpclient.NameValuePair;
/*     */ import org.apache.commons.httpclient.util.ParameterParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AuthChallengeParser
/*     */ {
/*     */   public static String extractScheme(String challengeStr)
/*     */     throws MalformedChallengeException
/*     */   {
/*  63 */     if (challengeStr == null) {
/*  64 */       throw new IllegalArgumentException("Challenge may not be null");
/*     */     }
/*  66 */     int idx = challengeStr.indexOf(' ');
/*  67 */     String s = null;
/*  68 */     if (idx == -1) {
/*  69 */       s = challengeStr;
/*     */     } else {
/*  71 */       s = challengeStr.substring(0, idx);
/*     */     }
/*  73 */     if (s.equals("")) {
/*  74 */       throw new MalformedChallengeException("Invalid challenge: " + challengeStr);
/*     */     }
/*  76 */     return s.toLowerCase();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map extractParams(String challengeStr)
/*     */     throws MalformedChallengeException
/*     */   {
/*  92 */     if (challengeStr == null) {
/*  93 */       throw new IllegalArgumentException("Challenge may not be null");
/*     */     }
/*  95 */     int idx = challengeStr.indexOf(' ');
/*  96 */     if (idx == -1) {
/*  97 */       throw new MalformedChallengeException("Invalid challenge: " + challengeStr);
/*     */     }
/*  99 */     Map map = new HashMap();
/* 100 */     ParameterParser parser = new ParameterParser();
/* 101 */     List params = parser.parse(challengeStr.substring(idx + 1, challengeStr.length()), ',');
/*     */     
/* 103 */     for (int i = 0; i < params.size(); i++) {
/* 104 */       NameValuePair param = (NameValuePair)params.get(i);
/* 105 */       map.put(param.getName().toLowerCase(), param.getValue());
/*     */     }
/* 107 */     return map;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map parseChallenges(Header[] headers)
/*     */     throws MalformedChallengeException
/*     */   {
/* 123 */     if (headers == null) {
/* 124 */       throw new IllegalArgumentException("Array of challenges may not be null");
/*     */     }
/* 126 */     String challenge = null;
/* 127 */     Map challengemap = new HashMap(headers.length);
/* 128 */     for (int i = 0; i < headers.length; i++) {
/* 129 */       challenge = headers[i].getValue();
/* 130 */       String s = extractScheme(challenge);
/* 131 */       challengemap.put(s, challenge);
/*     */     }
/* 133 */     return challengemap;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\auth\AuthChallengeParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */