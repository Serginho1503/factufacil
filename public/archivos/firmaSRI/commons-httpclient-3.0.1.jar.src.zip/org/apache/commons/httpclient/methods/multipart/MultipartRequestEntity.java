/*     */ package org.apache.commons.httpclient.methods.multipart;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Random;
/*     */ import org.apache.commons.httpclient.methods.RequestEntity;
/*     */ import org.apache.commons.httpclient.params.DefaultHttpParams;
/*     */ import org.apache.commons.httpclient.params.HttpMethodParams;
/*     */ import org.apache.commons.httpclient.util.EncodingUtil;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultipartRequestEntity
/*     */   implements RequestEntity
/*     */ {
/*  78 */   private static final Log log = LogFactory.getLog(MultipartRequestEntity.class);
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String MULTIPART_FORM_CONTENT_TYPE = "multipart/form-data";
/*     */   
/*     */ 
/*     */ 
/*  86 */   private static byte[] MULTIPART_CHARS = EncodingUtil.getAsciiBytes("-_1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
/*     */   
/*     */   protected Part[] parts;
/*     */   private byte[] multipartBoundary;
/*     */   private HttpMethodParams params;
/*     */   
/*     */   private static byte[] generateMultipartBoundary()
/*     */   {
/*  94 */     Random rand = new Random();
/*  95 */     byte[] bytes = new byte[rand.nextInt(11) + 30];
/*  96 */     for (int i = 0; i < bytes.length; i++) {
/*  97 */       bytes[i] = MULTIPART_CHARS[rand.nextInt(MULTIPART_CHARS.length)];
/*     */     }
/*  99 */     return bytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MultipartRequestEntity(Part[] parts, HttpMethodParams params)
/*     */   {
/* 115 */     if (parts == null) {
/* 116 */       throw new IllegalArgumentException("parts cannot be null");
/*     */     }
/* 118 */     if (params == null) {
/* 119 */       throw new IllegalArgumentException("params cannot be null");
/*     */     }
/* 121 */     this.parts = parts;
/* 122 */     this.params = params;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected byte[] getMultipartBoundary()
/*     */   {
/* 135 */     if (this.multipartBoundary == null) {
/* 136 */       String temp = (String)this.params.getParameter("http.method.multipart.boundary");
/* 137 */       if (temp != null) {
/* 138 */         this.multipartBoundary = EncodingUtil.getAsciiBytes(temp);
/*     */       } else {
/* 140 */         this.multipartBoundary = generateMultipartBoundary();
/*     */       }
/*     */     }
/* 143 */     return this.multipartBoundary;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRepeatable()
/*     */   {
/* 151 */     for (int i = 0; i < this.parts.length; i++) {
/* 152 */       if (!this.parts[i].isRepeatable()) {
/* 153 */         return false;
/*     */       }
/*     */     }
/* 156 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeRequest(OutputStream out)
/*     */     throws IOException
/*     */   {
/* 163 */     Part.sendParts(out, this.parts, getMultipartBoundary());
/*     */   }
/*     */   
/*     */ 
/*     */   public long getContentLength()
/*     */   {
/*     */     try
/*     */     {
/* 171 */       return Part.getLengthOfParts(this.parts, getMultipartBoundary());
/*     */     } catch (Exception e) {
/* 173 */       log.error("An exception occurred while getting the length of the parts", e); }
/* 174 */     return 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContentType()
/*     */   {
/* 182 */     StringBuffer buffer = new StringBuffer("multipart/form-data");
/* 183 */     buffer.append("; boundary=");
/* 184 */     buffer.append(EncodingUtil.getAsciiString(getMultipartBoundary()));
/* 185 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\methods\multipart\MultipartRequestEntity.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */