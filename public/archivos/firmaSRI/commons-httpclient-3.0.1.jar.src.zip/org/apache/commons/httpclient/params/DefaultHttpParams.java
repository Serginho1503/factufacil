/*     */ package org.apache.commons.httpclient.params;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultHttpParams
/*     */   implements HttpParams, Serializable, Cloneable
/*     */ {
/*  53 */   private static final Log LOG = LogFactory.getLog(DefaultHttpParams.class);
/*     */   
/*     */ 
/*  56 */   private static HttpParamsFactory httpParamsFactory = new DefaultHttpParamsFactory();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HttpParams getDefaultParams()
/*     */   {
/*  66 */     return httpParamsFactory.getDefaultParams();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setHttpParamsFactory(HttpParamsFactory httpParamsFactory)
/*     */   {
/*  77 */     if (httpParamsFactory == null) {
/*  78 */       throw new IllegalArgumentException("httpParamsFactory may not be null");
/*     */     }
/*  80 */     httpParamsFactory = httpParamsFactory;
/*     */   }
/*     */   
/*     */ 
/*  84 */   private HttpParams defaults = null;
/*     */   
/*     */ 
/*  87 */   private HashMap parameters = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultHttpParams(HttpParams defaults)
/*     */   {
/* 100 */     this.defaults = defaults;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultHttpParams()
/*     */   {
/* 112 */     this(getDefaultParams());
/*     */   }
/*     */   
/*     */   public synchronized HttpParams getDefaults() {
/* 116 */     return this.defaults;
/*     */   }
/*     */   
/*     */   public synchronized void setDefaults(HttpParams params) {
/* 120 */     this.defaults = params;
/*     */   }
/*     */   
/*     */   public synchronized Object getParameter(String name)
/*     */   {
/* 125 */     Object param = null;
/* 126 */     if (this.parameters != null) {
/* 127 */       param = this.parameters.get(name);
/*     */     }
/* 129 */     if (param != null)
/*     */     {
/* 131 */       return param;
/*     */     }
/*     */     
/* 134 */     if (this.defaults != null)
/*     */     {
/* 136 */       return this.defaults.getParameter(name);
/*     */     }
/*     */     
/* 139 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void setParameter(String name, Object value)
/*     */   {
/* 145 */     if (this.parameters == null) {
/* 146 */       this.parameters = new HashMap();
/*     */     }
/* 148 */     this.parameters.put(name, value);
/* 149 */     if (LOG.isDebugEnabled()) {
/* 150 */       LOG.debug("Set parameter " + name + " = " + value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setParameters(String[] names, Object value)
/*     */   {
/* 161 */     for (int i = 0; i < names.length; i++) {
/* 162 */       setParameter(names[i], value);
/*     */     }
/*     */   }
/*     */   
/*     */   public long getLongParameter(String name, long defaultValue) {
/* 167 */     Object param = getParameter(name);
/* 168 */     if (param == null) {
/* 169 */       return defaultValue;
/*     */     }
/* 171 */     return ((Long)param).longValue();
/*     */   }
/*     */   
/*     */   public void setLongParameter(String name, long value) {
/* 175 */     setParameter(name, new Long(value));
/*     */   }
/*     */   
/*     */   public int getIntParameter(String name, int defaultValue) {
/* 179 */     Object param = getParameter(name);
/* 180 */     if (param == null) {
/* 181 */       return defaultValue;
/*     */     }
/* 183 */     return ((Integer)param).intValue();
/*     */   }
/*     */   
/*     */   public void setIntParameter(String name, int value) {
/* 187 */     setParameter(name, new Integer(value));
/*     */   }
/*     */   
/*     */   public double getDoubleParameter(String name, double defaultValue) {
/* 191 */     Object param = getParameter(name);
/* 192 */     if (param == null) {
/* 193 */       return defaultValue;
/*     */     }
/* 195 */     return ((Double)param).doubleValue();
/*     */   }
/*     */   
/*     */   public void setDoubleParameter(String name, double value) {
/* 199 */     setParameter(name, new Double(value));
/*     */   }
/*     */   
/*     */   public boolean getBooleanParameter(String name, boolean defaultValue) {
/* 203 */     Object param = getParameter(name);
/* 204 */     if (param == null) {
/* 205 */       return defaultValue;
/*     */     }
/* 207 */     return ((Boolean)param).booleanValue();
/*     */   }
/*     */   
/*     */   public void setBooleanParameter(String name, boolean value) {
/* 211 */     setParameter(name, new Boolean(value));
/*     */   }
/*     */   
/*     */   public boolean isParameterSet(String name) {
/* 215 */     return getParameter(name) != null;
/*     */   }
/*     */   
/*     */   public boolean isParameterSetLocally(String name) {
/* 219 */     return (this.parameters != null) && (this.parameters.get(name) != null);
/*     */   }
/*     */   
/*     */   public boolean isParameterTrue(String name) {
/* 223 */     return getBooleanParameter(name, false);
/*     */   }
/*     */   
/*     */   public boolean isParameterFalse(String name) {
/* 227 */     return !getBooleanParameter(name, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/* 234 */     this.parameters = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */     throws CloneNotSupportedException
/*     */   {
/* 246 */     DefaultHttpParams clone = (DefaultHttpParams)super.clone();
/* 247 */     if (this.parameters != null) {
/* 248 */       clone.parameters = ((HashMap)this.parameters.clone());
/*     */     }
/* 250 */     clone.setDefaults(this.defaults);
/* 251 */     return clone;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\params\DefaultHttpParams.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */