/*     */ package org.apache.commons.httpclient.protocol;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.UnknownHostException;
/*     */ import org.apache.commons.httpclient.ConnectTimeoutException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReflectionSocketFactory
/*     */ {
/*  52 */   private static boolean REFLECTION_FAILED = false;
/*     */   
/*  54 */   private static Constructor INETSOCKETADDRESS_CONSTRUCTOR = null;
/*  55 */   private static Method SOCKETCONNECT_METHOD = null;
/*  56 */   private static Method SOCKETBIND_METHOD = null;
/*  57 */   private static Class SOCKETTIMEOUTEXCEPTION_CLASS = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Socket createSocket(String socketfactoryName, String host, int port, InetAddress localAddress, int localPort, int timeout)
/*     */     throws IOException, UnknownHostException, ConnectTimeoutException
/*     */   {
/*  94 */     if (REFLECTION_FAILED)
/*     */     {
/*  96 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 108 */       Class socketfactoryClass = Class.forName(socketfactoryName);
/* 109 */       Method method = socketfactoryClass.getMethod("getDefault", new Class[0]);
/*     */       
/* 111 */       Object socketfactory = method.invoke(null, new Object[0]);
/*     */       
/* 113 */       method = socketfactoryClass.getMethod("createSocket", new Class[0]);
/*     */       
/* 115 */       Socket socket = (Socket)method.invoke(socketfactory, new Object[0]);
/*     */       
/* 117 */       if (INETSOCKETADDRESS_CONSTRUCTOR == null) {
/* 118 */         Class addressClass = Class.forName("java.net.InetSocketAddress");
/* 119 */         INETSOCKETADDRESS_CONSTRUCTOR = addressClass.getConstructor(new Class[] { InetAddress.class, Integer.TYPE });
/*     */       }
/*     */       
/*     */ 
/* 123 */       Object remoteaddr = INETSOCKETADDRESS_CONSTRUCTOR.newInstance(new Object[] { InetAddress.getByName(host), new Integer(port) });
/*     */       
/*     */ 
/* 126 */       Object localaddr = INETSOCKETADDRESS_CONSTRUCTOR.newInstance(new Object[] { localAddress, new Integer(localPort) });
/*     */       
/*     */ 
/* 129 */       if (SOCKETCONNECT_METHOD == null) {
/* 130 */         SOCKETCONNECT_METHOD = class$java$net$Socket.getMethod("connect", new Class[] { Class.forName("java.net.SocketAddress"), Integer.TYPE });
/*     */       }
/*     */       
/*     */ 
/* 134 */       if (SOCKETBIND_METHOD == null) {
/* 135 */         SOCKETBIND_METHOD = class$java$net$Socket.getMethod("bind", new Class[] { Class.forName("java.net.SocketAddress") });
/*     */       }
/*     */       
/* 138 */       SOCKETBIND_METHOD.invoke(socket, new Object[] { localaddr });
/* 139 */       SOCKETCONNECT_METHOD.invoke(socket, new Object[] { remoteaddr, new Integer(timeout) });
/* 140 */       return socket;
/*     */     }
/*     */     catch (InvocationTargetException e) {
/* 143 */       Throwable cause = e.getTargetException();
/* 144 */       if (SOCKETTIMEOUTEXCEPTION_CLASS == null) {
/*     */         try {
/* 146 */           SOCKETTIMEOUTEXCEPTION_CLASS = Class.forName("java.net.SocketTimeoutException");
/*     */         }
/*     */         catch (ClassNotFoundException ex) {
/* 149 */           REFLECTION_FAILED = true;
/* 150 */           return null;
/*     */         }
/*     */       }
/* 153 */       if (SOCKETTIMEOUTEXCEPTION_CLASS.isInstance(cause)) {
/* 154 */         throw new ConnectTimeoutException("The host did not accept the connection within timeout of " + timeout + " ms", cause);
/*     */       }
/*     */       
/*     */ 
/* 158 */       if ((cause instanceof IOException)) {
/* 159 */         throw ((IOException)cause);
/*     */       }
/* 161 */       return null;
/*     */     }
/*     */     catch (Exception e) {
/* 164 */       REFLECTION_FAILED = true; }
/* 165 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\protocol\ReflectionSocketFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */