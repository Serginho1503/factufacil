/*    */ package org.apache.commons.httpclient;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ /**
/*    */  * @deprecated
/*    */  */
/*    */ public class DefaultMethodRetryHandler
/*    */   implements MethodRetryHandler
/*    */ {
/*    */   private int retryCount;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private boolean requestSentRetryEnabled;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public DefaultMethodRetryHandler()
/*    */   {
/* 52 */     this.retryCount = 3;
/* 53 */     this.requestSentRetryEnabled = false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean retryMethod(HttpMethod method, HttpConnection connection, HttpRecoverableException recoverableException, int executionCount, boolean requestSent)
/*    */   {
/* 69 */     return ((!requestSent) || (this.requestSentRetryEnabled)) && (executionCount <= this.retryCount);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean isRequestSentRetryEnabled()
/*    */   {
/* 76 */     return this.requestSentRetryEnabled;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int getRetryCount()
/*    */   {
/* 83 */     return this.retryCount;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setRequestSentRetryEnabled(boolean requestSentRetryEnabled)
/*    */   {
/* 91 */     this.requestSentRetryEnabled = requestSentRetryEnabled;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setRetryCount(int retryCount)
/*    */   {
/* 98 */     this.retryCount = retryCount;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\DefaultMethodRetryHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */