/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import org.apache.commons.httpclient.util.URIUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpsURL
/*     */   extends HttpURL
/*     */ {
/*     */   protected HttpsURL() {}
/*     */   
/*     */   public HttpsURL(char[] escaped, String charset)
/*     */     throws URIException, NullPointerException
/*     */   {
/*  63 */     this.protocolCharset = charset;
/*  64 */     parseUriReference(new String(escaped), true);
/*  65 */     checkValid();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpsURL(char[] escaped)
/*     */     throws URIException, NullPointerException
/*     */   {
/*  78 */     parseUriReference(new String(escaped), true);
/*  79 */     checkValid();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpsURL(String original, String charset)
/*     */     throws URIException
/*     */   {
/*  93 */     this.protocolCharset = charset;
/*  94 */     parseUriReference(original, false);
/*  95 */     checkValid();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpsURL(String original)
/*     */     throws URIException
/*     */   {
/* 107 */     parseUriReference(original, false);
/* 108 */     checkValid();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpsURL(String host, int port, String path)
/*     */     throws URIException
/*     */   {
/* 122 */     this(null, host, port, path, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpsURL(String host, int port, String path, String query)
/*     */     throws URIException
/*     */   {
/* 139 */     this(null, host, port, path, query, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpsURL(String user, String password, String host)
/*     */     throws URIException
/*     */   {
/* 155 */     this(user, password, host, -1, null, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpsURL(String user, String password, String host, int port)
/*     */     throws URIException
/*     */   {
/* 172 */     this(user, password, host, port, null, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpsURL(String user, String password, String host, int port, String path)
/*     */     throws URIException
/*     */   {
/* 190 */     this(user, password, host, port, path, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpsURL(String user, String password, String host, int port, String path, String query)
/*     */     throws URIException
/*     */   {
/* 209 */     this(user, password, host, port, path, query, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpsURL(String host, String path, String query, String fragment)
/*     */     throws URIException
/*     */   {
/* 226 */     this(null, host, -1, path, query, fragment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpsURL(String userinfo, String host, String path, String query, String fragment)
/*     */     throws URIException
/*     */   {
/* 248 */     this(userinfo, host, -1, path, query, fragment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpsURL(String userinfo, String host, int port, String path)
/*     */     throws URIException
/*     */   {
/* 269 */     this(userinfo, host, port, path, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpsURL(String userinfo, String host, int port, String path, String query)
/*     */     throws URIException
/*     */   {
/* 291 */     this(userinfo, host, port, path, query, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpsURL(String userinfo, String host, int port, String path, String query, String fragment)
/*     */     throws URIException
/*     */   {
/* 315 */     StringBuffer buff = new StringBuffer();
/* 316 */     if ((userinfo != null) || (host != null) || (port != -1)) {
/* 317 */       this._scheme = DEFAULT_SCHEME;
/* 318 */       buff.append(_default_scheme);
/* 319 */       buff.append("://");
/* 320 */       if (userinfo != null) {
/* 321 */         buff.append(userinfo);
/* 322 */         buff.append('@');
/*     */       }
/* 324 */       if (host != null) {
/* 325 */         buff.append(URIUtil.encode(host, URI.allowed_host));
/* 326 */         if ((port != -1) || (port != 443)) {
/* 327 */           buff.append(':');
/* 328 */           buff.append(port);
/*     */         }
/*     */       }
/*     */     }
/* 332 */     if (path != null) {
/* 333 */       if ((URI.scheme != null) && (!path.startsWith("/"))) {
/* 334 */         throw new URIException(1, "abs_path requested");
/*     */       }
/*     */       
/* 337 */       buff.append(URIUtil.encode(path, URI.allowed_abs_path));
/*     */     }
/* 339 */     if (query != null) {
/* 340 */       buff.append('?');
/* 341 */       buff.append(URIUtil.encode(query, URI.allowed_query));
/*     */     }
/* 343 */     if (fragment != null) {
/* 344 */       buff.append('#');
/* 345 */       buff.append(URIUtil.encode(fragment, URI.allowed_fragment));
/*     */     }
/* 347 */     parseUriReference(buff.toString(), true);
/* 348 */     checkValid();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpsURL(String user, String password, String host, int port, String path, String query, String fragment)
/*     */     throws URIException
/*     */   {
/* 366 */     this(HttpURL.toUserinfo(user, password), host, port, path, query, fragment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpsURL(HttpsURL base, String relative)
/*     */     throws URIException
/*     */   {
/* 377 */     this(base, new HttpsURL(relative));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpsURL(HttpsURL base, HttpsURL relative)
/*     */     throws URIException
/*     */   {
/* 389 */     super(base, relative);
/* 390 */     checkValid();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 398 */   public static final char[] DEFAULT_SCHEME = { 'h', 't', 't', 'p', 's' };
/*     */   
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/* 405 */   public static final char[] _default_scheme = DEFAULT_SCHEME;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int DEFAULT_PORT = 443;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static final int _default_port = 443;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final long serialVersionUID = 887844277028676648L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] getRawScheme()
/*     */   {
/* 434 */     return this._scheme == null ? null : DEFAULT_SCHEME;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getScheme()
/*     */   {
/* 444 */     return this._scheme == null ? null : new String(DEFAULT_SCHEME);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 454 */     return this._port == -1 ? 443 : this._port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkValid()
/*     */     throws URIException
/*     */   {
/* 466 */     if ((!equals(this._scheme, DEFAULT_SCHEME)) && (this._scheme != null)) {
/* 467 */       throw new URIException(1, "wrong class use");
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\HttpsURL.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */