/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import java.util.AbstractList;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.httpclient.auth.AuthScope;
/*     */ import org.apache.commons.httpclient.cookie.CookiePolicy;
/*     */ import org.apache.commons.httpclient.cookie.CookieSpec;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpState
/*     */ {
/*  71 */   private HashMap credMap = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  77 */   private HashMap proxyCred = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  82 */   private ArrayList cookies = new ArrayList();
/*     */   
/*  84 */   private boolean preemptive = false;
/*     */   
/*  86 */   private int cookiePolicy = -1;
/*     */   
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static final String PREEMPTIVE_PROPERTY = "httpclient.authentication.preemptive";
/*     */   
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static final String PREEMPTIVE_DEFAULT = "false";
/*     */   
/*     */ 
/* 102 */   private static final Log LOG = LogFactory.getLog(HttpState.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void addCookie(Cookie cookie)
/*     */   {
/* 124 */     LOG.trace("enter HttpState.addCookie(Cookie)");
/*     */     
/* 126 */     if (cookie != null)
/*     */     {
/* 128 */       for (Iterator it = this.cookies.iterator(); it.hasNext();) {
/* 129 */         Cookie tmp = (Cookie)it.next();
/* 130 */         if (cookie.equals(tmp)) {
/* 131 */           it.remove();
/* 132 */           break;
/*     */         }
/*     */       }
/* 135 */       if (!cookie.isExpired()) {
/* 136 */         this.cookies.add(cookie);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void addCookies(Cookie[] cookies)
/*     */   {
/* 153 */     LOG.trace("enter HttpState.addCookies(Cookie[])");
/*     */     
/* 155 */     if (cookies != null) {
/* 156 */       for (int i = 0; i < cookies.length; i++) {
/* 157 */         addCookie(cookies[i]);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Cookie[] getCookies()
/*     */   {
/* 172 */     LOG.trace("enter HttpState.getCookies()");
/* 173 */     return (Cookie[])this.cookies.toArray(new Cookie[this.cookies.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public synchronized Cookie[] getCookies(String domain, int port, String path, boolean secure)
/*     */   {
/* 197 */     LOG.trace("enter HttpState.getCookies(String, int, String, boolean)");
/*     */     
/* 199 */     CookieSpec matcher = CookiePolicy.getDefaultSpec();
/* 200 */     ArrayList list = new ArrayList(this.cookies.size());
/* 201 */     int i = 0; for (int m = this.cookies.size(); i < m; i++) {
/* 202 */       Cookie cookie = (Cookie)this.cookies.get(i);
/* 203 */       if (matcher.match(domain, port, path, secure, cookie)) {
/* 204 */         list.add(cookie);
/*     */       }
/*     */     }
/* 207 */     return (Cookie[])list.toArray(new Cookie[list.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean purgeExpiredCookies()
/*     */   {
/* 218 */     LOG.trace("enter HttpState.purgeExpiredCookies()");
/* 219 */     return purgeExpiredCookies(new Date());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean purgeExpiredCookies(Date date)
/*     */   {
/* 235 */     LOG.trace("enter HttpState.purgeExpiredCookies(Date)");
/* 236 */     boolean removed = false;
/* 237 */     Iterator it = this.cookies.iterator();
/* 238 */     while (it.hasNext()) {
/* 239 */       if (((Cookie)it.next()).isExpired(date)) {
/* 240 */         it.remove();
/* 241 */         removed = true;
/*     */       }
/*     */     }
/* 244 */     return removed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public int getCookiePolicy()
/*     */   {
/* 260 */     return this.cookiePolicy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setAuthenticationPreemptive(boolean value)
/*     */   {
/* 277 */     this.preemptive = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public boolean isAuthenticationPreemptive()
/*     */   {
/* 293 */     return this.preemptive;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setCookiePolicy(int policy)
/*     */   {
/* 312 */     this.cookiePolicy = policy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public synchronized void setCredentials(String realm, String host, Credentials credentials)
/*     */   {
/* 337 */     LOG.trace("enter HttpState.setCredentials(String, String, Credentials)");
/* 338 */     this.credMap.put(new AuthScope(host, -1, realm, AuthScope.ANY_SCHEME), credentials);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setCredentials(AuthScope authscope, Credentials credentials)
/*     */   {
/* 355 */     if (authscope == null) {
/* 356 */       throw new IllegalArgumentException("Authentication scope may not be null");
/*     */     }
/* 358 */     LOG.trace("enter HttpState.setCredentials(AuthScope, Credentials)");
/* 359 */     this.credMap.put(authscope, credentials);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Credentials matchCredentials(HashMap map, AuthScope authscope)
/*     */   {
/* 372 */     Credentials creds = (Credentials)map.get(authscope);
/* 373 */     if (creds == null)
/*     */     {
/*     */ 
/* 376 */       int bestMatchFactor = -1;
/* 377 */       AuthScope bestMatch = null;
/* 378 */       Iterator items = map.keySet().iterator();
/* 379 */       while (items.hasNext()) {
/* 380 */         AuthScope current = (AuthScope)items.next();
/* 381 */         int factor = authscope.match(current);
/* 382 */         if (factor > bestMatchFactor) {
/* 383 */           bestMatchFactor = factor;
/* 384 */           bestMatch = current;
/*     */         }
/*     */       }
/* 387 */       if (bestMatch != null) {
/* 388 */         creds = (Credentials)map.get(bestMatch);
/*     */       }
/*     */     }
/* 391 */     return creds;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public synchronized Credentials getCredentials(String realm, String host)
/*     */   {
/* 416 */     LOG.trace("enter HttpState.getCredentials(String, String");
/* 417 */     return matchCredentials(this.credMap, new AuthScope(host, -1, realm, AuthScope.ANY_SCHEME));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Credentials getCredentials(AuthScope authscope)
/*     */   {
/* 432 */     if (authscope == null) {
/* 433 */       throw new IllegalArgumentException("Authentication scope may not be null");
/*     */     }
/* 435 */     LOG.trace("enter HttpState.getCredentials(AuthScope)");
/* 436 */     return matchCredentials(this.credMap, authscope);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public synchronized void setProxyCredentials(String realm, String proxyHost, Credentials credentials)
/*     */   {
/* 464 */     LOG.trace("enter HttpState.setProxyCredentials(String, String, Credentials");
/* 465 */     this.proxyCred.put(new AuthScope(proxyHost, -1, realm, AuthScope.ANY_SCHEME), credentials);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setProxyCredentials(AuthScope authscope, Credentials credentials)
/*     */   {
/* 484 */     if (authscope == null) {
/* 485 */       throw new IllegalArgumentException("Authentication scope may not be null");
/*     */     }
/* 487 */     LOG.trace("enter HttpState.setProxyCredentials(AuthScope, Credentials)");
/* 488 */     this.proxyCred.put(authscope, credentials);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public synchronized Credentials getProxyCredentials(String realm, String proxyHost)
/*     */   {
/* 511 */     LOG.trace("enter HttpState.getCredentials(String, String");
/* 512 */     return matchCredentials(this.proxyCred, new AuthScope(proxyHost, -1, realm, AuthScope.ANY_SCHEME));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Credentials getProxyCredentials(AuthScope authscope)
/*     */   {
/* 527 */     if (authscope == null) {
/* 528 */       throw new IllegalArgumentException("Authentication scope may not be null");
/*     */     }
/* 530 */     LOG.trace("enter HttpState.getProxyCredentials(AuthScope)");
/* 531 */     return matchCredentials(this.proxyCred, authscope);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized String toString()
/*     */   {
/* 542 */     StringBuffer sbResult = new StringBuffer();
/*     */     
/* 544 */     sbResult.append("[");
/* 545 */     sbResult.append(getCredentialsStringRepresentation(this.proxyCred));
/* 546 */     sbResult.append(" | ");
/* 547 */     sbResult.append(getCredentialsStringRepresentation(this.credMap));
/* 548 */     sbResult.append(" | ");
/* 549 */     sbResult.append(getCookiesStringRepresentation(this.cookies));
/* 550 */     sbResult.append("]");
/*     */     
/* 552 */     String strResult = sbResult.toString();
/*     */     
/* 554 */     return strResult;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String getCredentialsStringRepresentation(Map credMap)
/*     */   {
/* 563 */     StringBuffer sbResult = new StringBuffer();
/* 564 */     Iterator iter = credMap.keySet().iterator();
/* 565 */     while (iter.hasNext()) {
/* 566 */       Object key = iter.next();
/* 567 */       Credentials cred = (Credentials)credMap.get(key);
/* 568 */       if (sbResult.length() > 0) {
/* 569 */         sbResult.append(", ");
/*     */       }
/* 571 */       sbResult.append(key);
/* 572 */       sbResult.append("#");
/* 573 */       sbResult.append(cred.toString());
/*     */     }
/* 575 */     return sbResult.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String getCookiesStringRepresentation(List cookies)
/*     */   {
/* 584 */     StringBuffer sbResult = new StringBuffer();
/* 585 */     Iterator iter = cookies.iterator();
/* 586 */     while (iter.hasNext()) {
/* 587 */       Cookie ck = (Cookie)iter.next();
/* 588 */       if (sbResult.length() > 0) {
/* 589 */         sbResult.append("#");
/*     */       }
/* 591 */       sbResult.append(ck.toExternalForm());
/*     */     }
/* 593 */     return sbResult.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void clearCredentials()
/*     */   {
/* 600 */     this.credMap.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void clearProxyCredentials()
/*     */   {
/* 607 */     this.proxyCred.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized void clearCookies()
/*     */   {
/* 614 */     this.cookies.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/* 621 */     clearCookies();
/* 622 */     clearCredentials();
/* 623 */     clearProxyCredentials();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\HttpState.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */