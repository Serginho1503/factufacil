package org.apache.commons.httpclient.params;

public abstract interface HttpParams
{
  public abstract HttpParams getDefaults();
  
  public abstract void setDefaults(HttpParams paramHttpParams);
  
  public abstract Object getParameter(String paramString);
  
  public abstract void setParameter(String paramString, Object paramObject);
  
  public abstract long getLongParameter(String paramString, long paramLong);
  
  public abstract void setLongParameter(String paramString, long paramLong);
  
  public abstract int getIntParameter(String paramString, int paramInt);
  
  public abstract void setIntParameter(String paramString, int paramInt);
  
  public abstract double getDoubleParameter(String paramString, double paramDouble);
  
  public abstract void setDoubleParameter(String paramString, double paramDouble);
  
  public abstract boolean getBooleanParameter(String paramString, boolean paramBoolean);
  
  public abstract void setBooleanParameter(String paramString, boolean paramBoolean);
  
  public abstract boolean isParameterSet(String paramString);
  
  public abstract boolean isParameterSetLocally(String paramString);
  
  public abstract boolean isParameterTrue(String paramString);
  
  public abstract boolean isParameterFalse(String paramString);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\params\HttpParams.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */