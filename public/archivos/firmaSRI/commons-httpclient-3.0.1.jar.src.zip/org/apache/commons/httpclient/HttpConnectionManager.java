package org.apache.commons.httpclient;

import org.apache.commons.httpclient.params.HttpConnectionManagerParams;

public abstract interface HttpConnectionManager
{
  public abstract HttpConnection getConnection(HostConfiguration paramHostConfiguration);
  
  /**
   * @deprecated
   */
  public abstract HttpConnection getConnection(HostConfiguration paramHostConfiguration, long paramLong)
    throws HttpException;
  
  public abstract HttpConnection getConnectionWithTimeout(HostConfiguration paramHostConfiguration, long paramLong)
    throws ConnectionPoolTimeoutException;
  
  public abstract void releaseConnection(HttpConnection paramHttpConnection);
  
  public abstract void closeIdleConnections(long paramLong);
  
  public abstract HttpConnectionManagerParams getParams();
  
  public abstract void setParams(HttpConnectionManagerParams paramHttpConnectionManagerParams);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\HttpConnectionManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */