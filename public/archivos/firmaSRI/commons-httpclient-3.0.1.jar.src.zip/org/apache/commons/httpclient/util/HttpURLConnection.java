/*     */ package org.apache.commons.httpclient.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.ProtocolException;
/*     */ import java.net.URL;
/*     */ import java.security.Permission;
/*     */ import org.apache.commons.httpclient.Header;
/*     */ import org.apache.commons.httpclient.HttpMethod;
/*     */ import org.apache.commons.httpclient.NameValuePair;
/*     */ import org.apache.commons.httpclient.StatusLine;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpURLConnection
/*     */   extends java.net.HttpURLConnection
/*     */ {
/*  71 */   private static final Log LOG = LogFactory.getLog(HttpURLConnection.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private HttpMethod method;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private URL url;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpURLConnection(HttpMethod method, URL url)
/*     */   {
/*  99 */     super(url);
/* 100 */     this.method = method;
/* 101 */     this.url = url;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected HttpURLConnection(URL url)
/*     */   {
/* 110 */     super(url);
/* 111 */     throw new RuntimeException("An HTTP URL connection can only be constructed from a HttpMethod class");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputStream getInputStream()
/*     */     throws IOException
/*     */   {
/* 126 */     LOG.trace("enter HttpURLConnection.getInputStream()");
/* 127 */     return this.method.getResponseBodyAsStream();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputStream getErrorStream()
/*     */   {
/* 136 */     LOG.trace("enter HttpURLConnection.getErrorStream()");
/* 137 */     throw new RuntimeException("Not implemented yet");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void disconnect()
/*     */   {
/* 145 */     LOG.trace("enter HttpURLConnection.disconnect()");
/* 146 */     throw new RuntimeException("Not implemented yet");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void connect()
/*     */     throws IOException
/*     */   {
/* 155 */     LOG.trace("enter HttpURLConnection.connect()");
/* 156 */     throw new RuntimeException("This class can only be used with alreadyretrieved data");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean usingProxy()
/*     */   {
/* 166 */     LOG.trace("enter HttpURLConnection.usingProxy()");
/* 167 */     throw new RuntimeException("Not implemented yet");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRequestMethod()
/*     */   {
/* 177 */     LOG.trace("enter HttpURLConnection.getRequestMethod()");
/* 178 */     return this.method.getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getResponseCode()
/*     */     throws IOException
/*     */   {
/* 189 */     LOG.trace("enter HttpURLConnection.getResponseCode()");
/* 190 */     return this.method.getStatusCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getResponseMessage()
/*     */     throws IOException
/*     */   {
/* 201 */     LOG.trace("enter HttpURLConnection.getResponseMessage()");
/* 202 */     return this.method.getStatusText();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHeaderField(String name)
/*     */   {
/* 213 */     LOG.trace("enter HttpURLConnection.getHeaderField(String)");
/*     */     
/*     */ 
/* 216 */     Header[] headers = this.method.getResponseHeaders();
/* 217 */     for (int i = headers.length - 1; i >= 0; i--) {
/* 218 */       if (headers[i].getName().equalsIgnoreCase(name)) {
/* 219 */         return headers[i].getValue();
/*     */       }
/*     */     }
/*     */     
/* 223 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHeaderFieldKey(int keyPosition)
/*     */   {
/* 234 */     LOG.trace("enter HttpURLConnection.getHeaderFieldKey(int)");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 240 */     if (keyPosition == 0) {
/* 241 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 247 */     Header[] headers = this.method.getResponseHeaders();
/* 248 */     if ((keyPosition < 0) || (keyPosition > headers.length)) {
/* 249 */       return null;
/*     */     }
/*     */     
/* 252 */     return headers[(keyPosition - 1)].getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHeaderField(int position)
/*     */   {
/* 263 */     LOG.trace("enter HttpURLConnection.getHeaderField(int)");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 269 */     if (position == 0) {
/* 270 */       return this.method.getStatusLine().toString();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 276 */     Header[] headers = this.method.getResponseHeaders();
/* 277 */     if ((position < 0) || (position > headers.length)) {
/* 278 */       return null;
/*     */     }
/*     */     
/* 281 */     return headers[(position - 1)].getValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public URL getURL()
/*     */   {
/* 290 */     LOG.trace("enter HttpURLConnection.getURL()");
/* 291 */     return this.url;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInstanceFollowRedirects(boolean isFollowingRedirects)
/*     */   {
/* 311 */     LOG.trace("enter HttpURLConnection.setInstanceFollowRedirects(boolean)");
/* 312 */     throw new RuntimeException("This class can only be used with alreadyretrieved data");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getInstanceFollowRedirects()
/*     */   {
/* 320 */     LOG.trace("enter HttpURLConnection.getInstanceFollowRedirects()");
/* 321 */     throw new RuntimeException("Not implemented yet");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setRequestMethod(String method)
/*     */     throws ProtocolException
/*     */   {
/* 329 */     LOG.trace("enter HttpURLConnection.setRequestMethod(String)");
/* 330 */     throw new RuntimeException("This class can only be used with alreadyretrieved data");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Permission getPermission()
/*     */     throws IOException
/*     */   {
/* 339 */     LOG.trace("enter HttpURLConnection.getPermission()");
/* 340 */     throw new RuntimeException("Not implemented yet");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getContent()
/*     */     throws IOException
/*     */   {
/* 348 */     LOG.trace("enter HttpURLConnection.getContent()");
/* 349 */     throw new RuntimeException("Not implemented yet");
/*     */   }
/*     */   
/*     */ 
/*     */   public Object getContent(Class[] classes)
/*     */     throws IOException
/*     */   {
/* 356 */     LOG.trace("enter HttpURLConnection.getContent(Class[])");
/* 357 */     throw new RuntimeException("Not implemented yet");
/*     */   }
/*     */   
/*     */ 
/*     */   public OutputStream getOutputStream()
/*     */     throws IOException
/*     */   {
/* 364 */     LOG.trace("enter HttpURLConnection.getOutputStream()");
/* 365 */     throw new RuntimeException("This class can only be used with alreadyretrieved data");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDoInput(boolean isInput)
/*     */   {
/* 374 */     LOG.trace("enter HttpURLConnection.setDoInput()");
/* 375 */     throw new RuntimeException("This class can only be used with alreadyretrieved data");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getDoInput()
/*     */   {
/* 384 */     LOG.trace("enter HttpURLConnection.getDoInput()");
/* 385 */     throw new RuntimeException("Not implemented yet");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDoOutput(boolean isOutput)
/*     */   {
/* 393 */     LOG.trace("enter HttpURLConnection.setDoOutput()");
/* 394 */     throw new RuntimeException("This class can only be used with alreadyretrieved data");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getDoOutput()
/*     */   {
/* 403 */     LOG.trace("enter HttpURLConnection.getDoOutput()");
/* 404 */     throw new RuntimeException("Not implemented yet");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAllowUserInteraction(boolean isAllowInteraction)
/*     */   {
/* 412 */     LOG.trace("enter HttpURLConnection.setAllowUserInteraction(boolean)");
/* 413 */     throw new RuntimeException("This class can only be used with alreadyretrieved data");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getAllowUserInteraction()
/*     */   {
/* 422 */     LOG.trace("enter HttpURLConnection.getAllowUserInteraction()");
/* 423 */     throw new RuntimeException("Not implemented yet");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUseCaches(boolean isUsingCaches)
/*     */   {
/* 431 */     LOG.trace("enter HttpURLConnection.setUseCaches(boolean)");
/* 432 */     throw new RuntimeException("This class can only be used with alreadyretrieved data");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getUseCaches()
/*     */   {
/* 441 */     LOG.trace("enter HttpURLConnection.getUseCaches()");
/* 442 */     throw new RuntimeException("Not implemented yet");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIfModifiedSince(long modificationDate)
/*     */   {
/* 450 */     LOG.trace("enter HttpURLConnection.setIfModifiedSince(long)");
/* 451 */     throw new RuntimeException("This class can only be used with alreadyretrieved data");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getIfModifiedSince()
/*     */   {
/* 460 */     LOG.trace("enter HttpURLConnection.getIfmodifiedSince()");
/* 461 */     throw new RuntimeException("Not implemented yet");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getDefaultUseCaches()
/*     */   {
/* 469 */     LOG.trace("enter HttpURLConnection.getDefaultUseCaches()");
/* 470 */     throw new RuntimeException("Not implemented yet");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultUseCaches(boolean isUsingCaches)
/*     */   {
/* 478 */     LOG.trace("enter HttpURLConnection.setDefaultUseCaches(boolean)");
/* 479 */     throw new RuntimeException("This class can only be used with alreadyretrieved data");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRequestProperty(String key, String value)
/*     */   {
/* 488 */     LOG.trace("enter HttpURLConnection.setRequestProperty()");
/* 489 */     throw new RuntimeException("This class can only be used with alreadyretrieved data");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRequestProperty(String key)
/*     */   {
/* 498 */     LOG.trace("enter HttpURLConnection.getRequestProperty()");
/* 499 */     throw new RuntimeException("Not implemented yet");
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\util\HttpURLConnection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */