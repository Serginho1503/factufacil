/*     */ package org.apache.commons.httpclient.auth;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.httpclient.Credentials;
/*     */ import org.apache.commons.httpclient.Header;
/*     */ import org.apache.commons.httpclient.HttpConnection;
/*     */ import org.apache.commons.httpclient.HttpMethod;
/*     */ import org.apache.commons.httpclient.HttpState;
/*     */ import org.apache.commons.httpclient.NameValuePair;
/*     */ import org.apache.commons.httpclient.UsernamePasswordCredentials;
/*     */ import org.apache.commons.httpclient.params.HttpMethodParams;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ /**
/*     */  * @deprecated
/*     */  */
/*     */ public final class HttpAuthenticator
/*     */ {
/*  75 */   private static final Log LOG = LogFactory.getLog(HttpAuthenticator.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String WWW_AUTH = "WWW-Authenticate";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String WWW_AUTH_RESP = "Authorization";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String PROXY_AUTH = "Proxy-Authenticate";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String PROXY_AUTH_RESP = "Proxy-Authorization";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static AuthScheme selectAuthScheme(Header[] challenges)
/*     */     throws MalformedChallengeException
/*     */   {
/* 120 */     LOG.trace("enter HttpAuthenticator.selectAuthScheme(Header[])");
/* 121 */     if (challenges == null) {
/* 122 */       throw new IllegalArgumentException("Array of challenges may not be null");
/*     */     }
/* 124 */     if (challenges.length == 0) {
/* 125 */       throw new IllegalArgumentException("Array of challenges may not be empty");
/*     */     }
/* 127 */     String challenge = null;
/* 128 */     Map challengemap = new HashMap(challenges.length);
/* 129 */     for (int i = 0; i < challenges.length; i++) {
/* 130 */       challenge = challenges[i].getValue();
/* 131 */       String s = AuthChallengeParser.extractScheme(challenge);
/* 132 */       challengemap.put(s, challenge);
/*     */     }
/* 134 */     challenge = (String)challengemap.get("ntlm");
/* 135 */     if (challenge != null) {
/* 136 */       return new NTLMScheme(challenge);
/*     */     }
/* 138 */     challenge = (String)challengemap.get("digest");
/* 139 */     if (challenge != null) {
/* 140 */       return new DigestScheme(challenge);
/*     */     }
/* 142 */     challenge = (String)challengemap.get("basic");
/* 143 */     if (challenge != null) {
/* 144 */       return new BasicScheme(challenge);
/*     */     }
/* 146 */     throw new UnsupportedOperationException("Authentication scheme(s) not supported: " + challengemap.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean doAuthenticateDefault(HttpMethod method, HttpConnection conn, HttpState state, boolean proxy)
/*     */     throws AuthenticationException
/*     */   {
/* 156 */     if (method == null) {
/* 157 */       throw new IllegalArgumentException("HTTP method may not be null");
/*     */     }
/* 159 */     if (state == null) {
/* 160 */       throw new IllegalArgumentException("HTTP state may not be null");
/*     */     }
/* 162 */     String host = null;
/* 163 */     if (conn != null) {
/* 164 */       host = proxy ? conn.getProxyHost() : conn.getHost();
/*     */     }
/* 166 */     Credentials credentials = proxy ? state.getProxyCredentials(null, host) : state.getCredentials(null, host);
/*     */     
/* 168 */     if (credentials == null) {
/* 169 */       return false;
/*     */     }
/* 171 */     if (!(credentials instanceof UsernamePasswordCredentials)) {
/* 172 */       throw new InvalidCredentialsException("Credentials cannot be used for basic authentication: " + credentials.toString());
/*     */     }
/*     */     
/*     */ 
/* 176 */     String auth = BasicScheme.authenticate((UsernamePasswordCredentials)credentials, method.getParams().getCredentialCharset());
/*     */     
/*     */ 
/* 179 */     if (auth != null) {
/* 180 */       String s = proxy ? "Proxy-Authorization" : "Authorization";
/* 181 */       Header header = new Header(s, auth, true);
/* 182 */       method.addRequestHeader(header);
/* 183 */       return true;
/*     */     }
/* 185 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static boolean authenticateDefault(HttpMethod method, HttpConnection conn, HttpState state)
/*     */     throws AuthenticationException
/*     */   {
/* 217 */     LOG.trace("enter HttpAuthenticator.authenticateDefault(HttpMethod, HttpConnection, HttpState)");
/*     */     
/* 219 */     return doAuthenticateDefault(method, conn, state, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static boolean authenticateProxyDefault(HttpMethod method, HttpConnection conn, HttpState state)
/*     */     throws AuthenticationException
/*     */   {
/* 250 */     LOG.trace("enter HttpAuthenticator.authenticateProxyDefault(HttpMethod, HttpState)");
/* 251 */     return doAuthenticateDefault(method, conn, state, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean doAuthenticate(AuthScheme authscheme, HttpMethod method, HttpConnection conn, HttpState state, boolean proxy)
/*     */     throws AuthenticationException
/*     */   {
/* 262 */     if (authscheme == null) {
/* 263 */       throw new IllegalArgumentException("Authentication scheme may not be null");
/*     */     }
/* 265 */     if (method == null) {
/* 266 */       throw new IllegalArgumentException("HTTP method may not be null");
/*     */     }
/* 268 */     if (state == null) {
/* 269 */       throw new IllegalArgumentException("HTTP state may not be null");
/*     */     }
/* 271 */     String host = null;
/* 272 */     if (conn != null) {
/* 273 */       if (proxy) {
/* 274 */         host = conn.getProxyHost();
/*     */       } else {
/* 276 */         host = method.getParams().getVirtualHost();
/* 277 */         if (host == null) {
/* 278 */           host = conn.getHost();
/*     */         }
/*     */       }
/*     */     }
/* 282 */     String realm = authscheme.getRealm();
/* 283 */     if (LOG.isDebugEnabled()) {
/* 284 */       StringBuffer buffer = new StringBuffer();
/* 285 */       buffer.append("Using credentials for ");
/* 286 */       if (realm == null) {
/* 287 */         buffer.append("default");
/*     */       } else {
/* 289 */         buffer.append('\'');
/* 290 */         buffer.append(realm);
/* 291 */         buffer.append('\'');
/*     */       }
/* 293 */       buffer.append(" authentication realm at ");
/* 294 */       buffer.append(host);
/* 295 */       LOG.debug(buffer.toString());
/*     */     }
/* 297 */     Credentials credentials = proxy ? state.getProxyCredentials(realm, host) : state.getCredentials(realm, host);
/*     */     
/*     */ 
/* 300 */     if (credentials == null) {
/* 301 */       StringBuffer buffer = new StringBuffer();
/* 302 */       buffer.append("No credentials available for the ");
/* 303 */       if (realm == null) {
/* 304 */         buffer.append("default");
/*     */       } else {
/* 306 */         buffer.append('\'');
/* 307 */         buffer.append(realm);
/* 308 */         buffer.append('\'');
/*     */       }
/* 310 */       buffer.append(" authentication realm at ");
/* 311 */       buffer.append(host);
/* 312 */       throw new CredentialsNotAvailableException(buffer.toString());
/*     */     }
/* 314 */     String auth = authscheme.authenticate(credentials, method);
/* 315 */     if (auth != null) {
/* 316 */       String s = proxy ? "Proxy-Authorization" : "Authorization";
/* 317 */       Header header = new Header(s, auth, true);
/* 318 */       method.addRequestHeader(header);
/* 319 */       return true;
/*     */     }
/* 321 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static boolean authenticate(AuthScheme authscheme, HttpMethod method, HttpConnection conn, HttpState state)
/*     */     throws AuthenticationException
/*     */   {
/* 353 */     LOG.trace("enter HttpAuthenticator.authenticate(AuthScheme, HttpMethod, HttpConnection, HttpState)");
/*     */     
/*     */ 
/* 356 */     return doAuthenticate(authscheme, method, conn, state, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static boolean authenticateProxy(AuthScheme authscheme, HttpMethod method, HttpConnection conn, HttpState state)
/*     */     throws AuthenticationException
/*     */   {
/* 389 */     LOG.trace("enter HttpAuthenticator.authenticateProxy(AuthScheme, HttpMethod, HttpState)");
/* 390 */     return doAuthenticate(authscheme, method, conn, state, true);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\auth\HttpAuthenticator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */