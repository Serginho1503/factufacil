/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class URIException
/*     */   extends HttpException
/*     */ {
/*     */   public static final int UNKNOWN = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int PARSING = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int UNSUPPORTED_ENCODING = 2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int ESCAPING = 3;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int PUNYCODE = 4;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int reasonCode;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String reason;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public URIException() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public URIException(int reasonCode)
/*     */   {
/*  56 */     this.reasonCode = reasonCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public URIException(int reasonCode, String reason)
/*     */   {
/*  67 */     super(reason);
/*  68 */     this.reason = reason;
/*  69 */     this.reasonCode = reasonCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public URIException(String reason)
/*     */   {
/*  79 */     super(reason);
/*  80 */     this.reason = reason;
/*  81 */     this.reasonCode = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReasonCode()
/*     */   {
/* 136 */     return this.reasonCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setReasonCode(int reasonCode)
/*     */   {
/* 148 */     this.reasonCode = reasonCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public String getReason()
/*     */   {
/* 160 */     return this.reason;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setReason(String reason)
/*     */   {
/* 172 */     this.reason = reason;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\URIException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */