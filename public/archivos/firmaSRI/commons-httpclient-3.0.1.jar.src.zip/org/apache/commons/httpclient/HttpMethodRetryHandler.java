package org.apache.commons.httpclient;

import java.io.IOException;

public abstract interface HttpMethodRetryHandler
{
  public abstract boolean retryMethod(HttpMethod paramHttpMethod, IOException paramIOException, int paramInt);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\HttpMethodRetryHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */