/*    */ package org.apache.commons.httpclient;
/*    */ 
/*    */ import java.io.FilterOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WireLogOutputStream
/*    */   extends FilterOutputStream
/*    */ {
/*    */   private OutputStream out;
/*    */   private Wire wire;
/*    */   
/*    */   public WireLogOutputStream(OutputStream out, Wire wire)
/*    */   {
/* 57 */     super(out);
/* 58 */     this.out = out;
/* 59 */     this.wire = wire;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void write(byte[] b, int off, int len)
/*    */     throws IOException
/*    */   {
/* 67 */     this.out.write(b, off, len);
/* 68 */     this.wire.output(b, off, len);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void write(int b)
/*    */     throws IOException
/*    */   {
/* 76 */     this.out.write(b);
/* 77 */     this.wire.output(b);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void write(byte[] b)
/*    */     throws IOException
/*    */   {
/* 85 */     this.out.write(b);
/* 86 */     this.wire.output(b);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\WireLogOutputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */