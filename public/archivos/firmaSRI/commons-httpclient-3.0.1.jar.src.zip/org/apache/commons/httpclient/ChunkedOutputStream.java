/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import org.apache.commons.httpclient.util.EncodingUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChunkedOutputStream
/*     */   extends OutputStream
/*     */ {
/*  46 */   private static final byte[] CRLF = { 13, 10 };
/*     */   
/*     */ 
/*  49 */   private static final byte[] ENDCHUNK = CRLF;
/*     */   
/*     */ 
/*  52 */   private static final byte[] ZERO = { 48 };
/*     */   
/*     */ 
/*  55 */   private OutputStream stream = null;
/*     */   
/*     */   private byte[] cache;
/*     */   
/*  59 */   private int cachePosition = 0;
/*     */   
/*  61 */   private boolean wroteLastChunk = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ChunkedOutputStream(OutputStream stream, int bufferSize)
/*     */     throws IOException
/*     */   {
/*  73 */     this.cache = new byte[bufferSize];
/*  74 */     this.stream = stream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ChunkedOutputStream(OutputStream stream)
/*     */     throws IOException
/*     */   {
/*  84 */     this(stream, 2048);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void flushCache()
/*     */     throws IOException
/*     */   {
/*  95 */     if (this.cachePosition > 0) {
/*  96 */       byte[] chunkHeader = EncodingUtil.getAsciiBytes(Integer.toHexString(this.cachePosition) + "\r\n");
/*     */       
/*  98 */       this.stream.write(chunkHeader, 0, chunkHeader.length);
/*  99 */       this.stream.write(this.cache, 0, this.cachePosition);
/* 100 */       this.stream.write(ENDCHUNK, 0, ENDCHUNK.length);
/* 101 */       this.cachePosition = 0;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void flushCacheWithAppend(byte[] bufferToAppend, int off, int len)
/*     */     throws IOException
/*     */   {
/* 116 */     byte[] chunkHeader = EncodingUtil.getAsciiBytes(Integer.toHexString(this.cachePosition + len) + "\r\n");
/*     */     
/* 118 */     this.stream.write(chunkHeader, 0, chunkHeader.length);
/* 119 */     this.stream.write(this.cache, 0, this.cachePosition);
/* 120 */     this.stream.write(bufferToAppend, off, len);
/* 121 */     this.stream.write(ENDCHUNK, 0, ENDCHUNK.length);
/* 122 */     this.cachePosition = 0;
/*     */   }
/*     */   
/*     */   protected void writeClosingChunk()
/*     */     throws IOException
/*     */   {
/* 128 */     this.stream.write(ZERO, 0, ZERO.length);
/* 129 */     this.stream.write(CRLF, 0, CRLF.length);
/* 130 */     this.stream.write(ENDCHUNK, 0, ENDCHUNK.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void finish()
/*     */     throws IOException
/*     */   {
/* 141 */     if (!this.wroteLastChunk) {
/* 142 */       flushCache();
/* 143 */       writeClosingChunk();
/* 144 */       this.wroteLastChunk = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(int b)
/*     */     throws IOException
/*     */   {
/* 159 */     this.cache[this.cachePosition] = ((byte)b);
/* 160 */     this.cachePosition += 1;
/* 161 */     if (this.cachePosition == this.cache.length) { flushCache();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(byte[] b)
/*     */     throws IOException
/*     */   {
/* 173 */     write(b, 0, b.length);
/*     */   }
/*     */   
/*     */   public void write(byte[] src, int off, int len) throws IOException {
/* 177 */     if (len >= this.cache.length - this.cachePosition) {
/* 178 */       flushCacheWithAppend(src, off, len);
/*     */     } else {
/* 180 */       System.arraycopy(src, off, this.cache, this.cachePosition, len);
/* 181 */       this.cachePosition += len;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void flush()
/*     */     throws IOException
/*     */   {
/* 190 */     this.stream.flush();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 198 */     finish();
/* 199 */     super.close();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\ChunkedOutputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */