/*     */ package org.apache.commons.httpclient.methods.multipart;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import org.apache.commons.httpclient.util.EncodingUtil;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringPart
/*     */   extends PartBase
/*     */ {
/*  52 */   private static final Log LOG = LogFactory.getLog(StringPart.class);
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String DEFAULT_CONTENT_TYPE = "text/plain";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String DEFAULT_CHARSET = "US-ASCII";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String DEFAULT_TRANSFER_ENCODING = "8bit";
/*     */   
/*     */ 
/*     */ 
/*     */   private byte[] content;
/*     */   
/*     */ 
/*     */ 
/*     */   private String value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringPart(String name, String value, String charset)
/*     */   {
/*  79 */     super(name, "text/plain", charset == null ? "US-ASCII" : charset, "8bit");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */     if (value == null) {
/*  86 */       throw new IllegalArgumentException("Value may not be null");
/*     */     }
/*  88 */     if (value.indexOf(0) != -1)
/*     */     {
/*  90 */       throw new IllegalArgumentException("NULs may not be present in string parts");
/*     */     }
/*  92 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringPart(String name, String value)
/*     */   {
/* 102 */     this(name, value, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] getContent()
/*     */   {
/* 112 */     if (this.content == null) {
/* 113 */       this.content = EncodingUtil.getBytes(this.value, getCharSet());
/*     */     }
/* 115 */     return this.content;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void sendData(OutputStream out)
/*     */     throws IOException
/*     */   {
/* 124 */     LOG.trace("enter sendData(OutputStream)");
/* 125 */     out.write(getContent());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected long lengthOfData()
/*     */     throws IOException
/*     */   {
/* 135 */     LOG.trace("enter lengthOfData()");
/* 136 */     return getContent().length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setCharSet(String charSet)
/*     */   {
/* 143 */     super.setCharSet(charSet);
/* 144 */     this.content = null;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\methods\multipart\StringPart.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */