/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.commons.httpclient.params.HttpMethodParams;
/*     */ import org.apache.commons.httpclient.protocol.Protocol;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectMethod
/*     */   extends HttpMethodBase
/*     */ {
/*     */   public static final String NAME = "CONNECT";
/*     */   
/*     */   public ConnectMethod()
/*     */   {
/*  58 */     LOG.trace("enter ConnectMethod()");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public ConnectMethod(HttpMethod method)
/*     */   {
/*  70 */     LOG.trace("enter ConnectMethod(HttpMethod)");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/*  79 */     return "CONNECT";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addCookieRequestHeader(HttpState state, HttpConnection conn)
/*     */     throws IOException, HttpException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addRequestHeaders(HttpState state, HttpConnection conn)
/*     */     throws IOException, HttpException
/*     */   {
/* 120 */     LOG.trace("enter ConnectMethod.addRequestHeaders(HttpState, HttpConnection)");
/*     */     
/* 122 */     addUserAgentRequestHeader(state, conn);
/* 123 */     addHostRequestHeader(state, conn);
/* 124 */     addProxyConnectionHeader(state, conn);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int execute(HttpState state, HttpConnection conn)
/*     */     throws IOException, HttpException
/*     */   {
/* 143 */     LOG.trace("enter ConnectMethod.execute(HttpState, HttpConnection)");
/* 144 */     int code = super.execute(state, conn);
/* 145 */     if (LOG.isDebugEnabled()) {
/* 146 */       LOG.debug("CONNECT status code " + code);
/*     */     }
/* 148 */     return code;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writeRequestLine(HttpState state, HttpConnection conn)
/*     */     throws IOException, HttpException
/*     */   {
/* 161 */     int port = conn.getPort();
/* 162 */     if (port == -1) {
/* 163 */       port = conn.getProtocol().getDefaultPort();
/*     */     }
/* 165 */     StringBuffer buffer = new StringBuffer();
/* 166 */     buffer.append(getName());
/* 167 */     buffer.append(' ');
/* 168 */     buffer.append(conn.getHost());
/* 169 */     if (port > -1) {
/* 170 */       buffer.append(':');
/* 171 */       buffer.append(port);
/*     */     }
/* 173 */     buffer.append(" ");
/* 174 */     buffer.append(getEffectiveVersion());
/* 175 */     String line = buffer.toString();
/* 176 */     conn.printLine(line, getParams().getHttpElementCharset());
/* 177 */     if (Wire.HEADER_WIRE.enabled()) {
/* 178 */       Wire.HEADER_WIRE.output(line);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean shouldCloseConnection(HttpConnection conn)
/*     */   {
/* 192 */     if (getStatusCode() == 200) {
/* 193 */       Header connectionHeader = null;
/* 194 */       if (!conn.isTransparent()) {
/* 195 */         connectionHeader = getResponseHeader("proxy-connection");
/*     */       }
/* 197 */       if (connectionHeader == null) {
/* 198 */         connectionHeader = getResponseHeader("connection");
/*     */       }
/* 200 */       if ((connectionHeader != null) && 
/* 201 */         (connectionHeader.getValue().equalsIgnoreCase("close")) && 
/* 202 */         (LOG.isWarnEnabled())) {
/* 203 */         LOG.warn("Invalid header encountered '" + connectionHeader.toExternalForm() + "' in response " + getStatusLine().toString());
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 208 */       return false;
/*     */     }
/* 210 */     return super.shouldCloseConnection(conn);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 215 */   private static final Log LOG = LogFactory.getLog(ConnectMethod.class);
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\ConnectMethod.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */