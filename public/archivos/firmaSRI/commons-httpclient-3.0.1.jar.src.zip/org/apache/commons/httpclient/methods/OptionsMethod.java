/*     */ package org.apache.commons.httpclient.methods;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ import org.apache.commons.httpclient.Header;
/*     */ import org.apache.commons.httpclient.HttpConnection;
/*     */ import org.apache.commons.httpclient.HttpMethodBase;
/*     */ import org.apache.commons.httpclient.HttpState;
/*     */ import org.apache.commons.httpclient.NameValuePair;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OptionsMethod
/*     */   extends HttpMethodBase
/*     */ {
/*  73 */   private static final Log LOG = LogFactory.getLog(OptionsMethod.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OptionsMethod() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OptionsMethod(String uri)
/*     */   {
/*  95 */     super(uri);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 105 */   private Vector methodsAllowed = new Vector();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 116 */     return "OPTIONS";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAllowed(String method)
/*     */   {
/* 128 */     checkUsed();
/* 129 */     return this.methodsAllowed.contains(method);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Enumeration getAllowedMethods()
/*     */   {
/* 140 */     checkUsed();
/* 141 */     return this.methodsAllowed.elements();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void processResponseHeaders(HttpState state, HttpConnection conn)
/*     */   {
/* 162 */     LOG.trace("enter OptionsMethod.processResponseHeaders(HttpState, HttpConnection)");
/*     */     
/* 164 */     Header allowHeader = getResponseHeader("allow");
/* 165 */     if (allowHeader != null) {
/* 166 */       String allowHeaderValue = allowHeader.getValue();
/* 167 */       StringTokenizer tokenizer = new StringTokenizer(allowHeaderValue, ",");
/*     */       
/* 169 */       while (tokenizer.hasMoreElements()) {
/* 170 */         String methodAllowed = tokenizer.nextToken().trim().toUpperCase();
/*     */         
/* 172 */         this.methodsAllowed.addElement(methodAllowed);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public boolean needContentLength()
/*     */   {
/* 187 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\methods\OptionsMethod.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */