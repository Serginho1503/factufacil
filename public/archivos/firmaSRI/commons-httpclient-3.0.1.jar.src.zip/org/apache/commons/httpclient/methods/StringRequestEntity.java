/*     */ package org.apache.commons.httpclient.methods;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import org.apache.commons.httpclient.HeaderElement;
/*     */ import org.apache.commons.httpclient.NameValuePair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringRequestEntity
/*     */   implements RequestEntity
/*     */ {
/*     */   private byte[] content;
/*     */   private String charset;
/*     */   private String contentType;
/*     */   
/*     */   public StringRequestEntity(String content)
/*     */   {
/*  74 */     if (content == null) {
/*  75 */       throw new IllegalArgumentException("The content cannot be null");
/*     */     }
/*  77 */     this.contentType = null;
/*  78 */     this.charset = null;
/*  79 */     this.content = content.getBytes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringRequestEntity(String content, String contentType, String charset)
/*     */     throws UnsupportedEncodingException
/*     */   {
/*  96 */     if (content == null) {
/*  97 */       throw new IllegalArgumentException("The content cannot be null");
/*     */     }
/*     */     
/* 100 */     this.contentType = contentType;
/* 101 */     this.charset = charset;
/*     */     
/*     */ 
/* 104 */     if (contentType != null) {
/* 105 */       HeaderElement[] values = HeaderElement.parseElements(contentType);
/* 106 */       NameValuePair charsetPair = null;
/* 107 */       for (int i = 0; i < values.length; i++) {
/* 108 */         if ((charsetPair = values[i].getParameterByName("charset")) != null) {
/*     */           break;
/*     */         }
/*     */       }
/*     */       
/* 113 */       if ((charset == null) && (charsetPair != null))
/*     */       {
/* 115 */         this.charset = charsetPair.getValue();
/* 116 */       } else if ((charset != null) && (charsetPair == null))
/*     */       {
/* 118 */         this.contentType = (contentType + "; charset=" + charset);
/*     */       }
/*     */     }
/* 121 */     if (this.charset != null) {
/* 122 */       this.content = content.getBytes(this.charset);
/*     */     } else {
/* 124 */       this.content = content.getBytes();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getContentType()
/*     */   {
/* 132 */     return this.contentType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isRepeatable()
/*     */   {
/* 139 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeRequest(OutputStream out)
/*     */     throws IOException
/*     */   {
/* 146 */     if (out == null) {
/* 147 */       throw new IllegalArgumentException("Output stream may not be null");
/*     */     }
/* 149 */     out.write(this.content);
/* 150 */     out.flush();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public long getContentLength()
/*     */   {
/* 157 */     return this.content.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getContent()
/*     */   {
/* 164 */     if (this.charset != null) {
/*     */       try {
/* 166 */         return new String(this.content, this.charset);
/*     */       } catch (UnsupportedEncodingException e) {
/* 168 */         return new String(this.content);
/*     */       }
/*     */     }
/* 171 */     return new String(this.content);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCharset()
/*     */   {
/* 180 */     return this.charset;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\methods\StringRequestEntity.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */