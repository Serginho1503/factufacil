/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.apache.commons.httpclient.params.HttpMethodParams;
/*     */ import org.apache.commons.httpclient.util.EncodingUtil;
/*     */ import org.apache.commons.httpclient.util.ExceptionUtil;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChunkedInputStream
/*     */   extends InputStream
/*     */ {
/*     */   private InputStream in;
/*     */   private int chunkSize;
/*     */   private int pos;
/*  74 */   private boolean bof = true;
/*     */   
/*     */ 
/*  77 */   private boolean eof = false;
/*     */   
/*     */ 
/*  80 */   private boolean closed = false;
/*     */   
/*     */ 
/*  83 */   private HttpMethod method = null;
/*     */   
/*     */ 
/*  86 */   private static final Log LOG = LogFactory.getLog(ChunkedInputStream.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ChunkedInputStream(InputStream in, HttpMethod method)
/*     */     throws IOException
/*     */   {
/* 103 */     if (in == null) {
/* 104 */       throw new IllegalArgumentException("InputStream parameter may not be null");
/*     */     }
/* 106 */     this.in = in;
/* 107 */     this.method = method;
/* 108 */     this.pos = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ChunkedInputStream(InputStream in)
/*     */     throws IOException
/*     */   {
/* 119 */     this(in, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/* 138 */     if (this.closed) {
/* 139 */       throw new IOException("Attempted read from closed stream.");
/*     */     }
/* 141 */     if (this.eof) {
/* 142 */       return -1;
/*     */     }
/* 144 */     if (this.pos >= this.chunkSize) {
/* 145 */       nextChunk();
/* 146 */       if (this.eof) {
/* 147 */         return -1;
/*     */       }
/*     */     }
/* 150 */     this.pos += 1;
/* 151 */     return this.in.read();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 167 */     if (this.closed) {
/* 168 */       throw new IOException("Attempted read from closed stream.");
/*     */     }
/*     */     
/* 171 */     if (this.eof) {
/* 172 */       return -1;
/*     */     }
/* 174 */     if (this.pos >= this.chunkSize) {
/* 175 */       nextChunk();
/* 176 */       if (this.eof) {
/* 177 */         return -1;
/*     */       }
/*     */     }
/* 180 */     len = Math.min(len, this.chunkSize - this.pos);
/* 181 */     int count = this.in.read(b, off, len);
/* 182 */     this.pos += count;
/* 183 */     return count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] b)
/*     */     throws IOException
/*     */   {
/* 195 */     return read(b, 0, b.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void readCRLF()
/*     */     throws IOException
/*     */   {
/* 203 */     int cr = this.in.read();
/* 204 */     int lf = this.in.read();
/* 205 */     if ((cr != 13) || (lf != 10)) {
/* 206 */       throw new IOException("CRLF expected at end of chunk: " + cr + "/" + lf);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void nextChunk()
/*     */     throws IOException
/*     */   {
/* 217 */     if (!this.bof) {
/* 218 */       readCRLF();
/*     */     }
/* 220 */     this.chunkSize = getChunkSizeFromInputStream(this.in);
/* 221 */     this.bof = false;
/* 222 */     this.pos = 0;
/* 223 */     if (this.chunkSize == 0) {
/* 224 */       this.eof = true;
/* 225 */       parseTrailerHeaders();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int getChunkSizeFromInputStream(InputStream in)
/*     */     throws IOException
/*     */   {
/* 245 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*     */     
/* 247 */     int state = 0;
/* 248 */     while (state != -1) {
/* 249 */       int b = in.read();
/* 250 */       if (b == -1) {
/* 251 */         throw new IOException("chunked stream ended unexpectedly");
/*     */       }
/* 253 */       switch (state) {
/*     */       case 0: 
/* 255 */         switch (b) {
/*     */         case 13: 
/* 257 */           state = 1;
/* 258 */           break;
/*     */         case 34: 
/* 260 */           state = 2;
/*     */         
/*     */         default: 
/* 263 */           baos.write(b);
/*     */         }
/* 265 */         break;
/*     */       
/*     */       case 1: 
/* 268 */         if (b == 10) {
/* 269 */           state = -1;
/*     */         }
/*     */         else {
/* 272 */           throw new IOException("Protocol violation: Unexpected single newline character in chunk size");
/*     */         }
/*     */         
/*     */ 
/*     */         break;
/*     */       case 2: 
/* 278 */         switch (b) {
/*     */         case 92: 
/* 280 */           b = in.read();
/* 281 */           baos.write(b);
/* 282 */           break;
/*     */         case 34: 
/* 284 */           state = 0;
/*     */         
/*     */         default: 
/* 287 */           baos.write(b);
/*     */         }
/* 289 */         break;
/* 290 */       default:  throw new RuntimeException("assertion failed");
/*     */       }
/*     */       
/*     */     }
/*     */     
/* 295 */     String dataString = EncodingUtil.getAsciiString(baos.toByteArray());
/* 296 */     int separator = dataString.indexOf(';');
/* 297 */     dataString = separator > 0 ? dataString.substring(0, separator).trim() : dataString.trim();
/*     */     
/*     */     int result;
/*     */     
/*     */     try
/*     */     {
/* 303 */       result = Integer.parseInt(dataString.trim(), 16);
/*     */     } catch (NumberFormatException e) {
/* 305 */       throw new IOException("Bad chunk size: " + dataString);
/*     */     }
/* 307 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void parseTrailerHeaders()
/*     */     throws IOException
/*     */   {
/* 315 */     Header[] footers = null;
/*     */     try {
/* 317 */       String charset = "US-ASCII";
/* 318 */       if (this.method != null) {
/* 319 */         charset = this.method.getParams().getHttpElementCharset();
/*     */       }
/* 321 */       footers = HttpParser.parseHeaders(this.in, charset);
/*     */     } catch (HttpException e) {
/* 323 */       LOG.error("Error parsing trailer headers", e);
/* 324 */       IOException ioe = new IOException(e.getMessage());
/* 325 */       ExceptionUtil.initCause(ioe, e);
/* 326 */       throw ioe;
/*     */     }
/* 328 */     if (this.method != null) {
/* 329 */       for (int i = 0; i < footers.length; i++) {
/* 330 */         this.method.addResponseFooter(footers[i]);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 342 */     if (!this.closed) {
/*     */       try {
/* 344 */         if (!this.eof) {
/* 345 */           exhaustInputStream(this);
/*     */         }
/*     */       } finally {
/* 348 */         this.eof = true;
/* 349 */         this.closed = true;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void exhaustInputStream(InputStream inStream)
/*     */     throws IOException
/*     */   {
/* 367 */     byte[] buffer = new byte['Ѐ'];
/* 368 */     while (inStream.read(buffer) >= 0) {}
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\ChunkedInputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */