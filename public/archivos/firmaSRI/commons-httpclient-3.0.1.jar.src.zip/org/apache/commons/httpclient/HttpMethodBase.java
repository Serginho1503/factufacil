/*      */ package org.apache.commons.httpclient;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InterruptedIOException;
/*      */ import java.util.Collection;
/*      */ import org.apache.commons.httpclient.auth.AuthState;
/*      */ import org.apache.commons.httpclient.cookie.CookiePolicy;
/*      */ import org.apache.commons.httpclient.cookie.CookieSpec;
/*      */ import org.apache.commons.httpclient.cookie.MalformedCookieException;
/*      */ import org.apache.commons.httpclient.params.DefaultHttpParams;
/*      */ import org.apache.commons.httpclient.params.HttpConnectionParams;
/*      */ import org.apache.commons.httpclient.params.HttpMethodParams;
/*      */ import org.apache.commons.httpclient.protocol.Protocol;
/*      */ import org.apache.commons.httpclient.util.EncodingUtil;
/*      */ import org.apache.commons.httpclient.util.ExceptionUtil;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class HttpMethodBase
/*      */   implements HttpMethod
/*      */ {
/*  102 */   private static final Log LOG = LogFactory.getLog(HttpMethodBase.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  107 */   private HeaderGroup requestHeaders = new HeaderGroup();
/*      */   
/*      */ 
/*  110 */   private StatusLine statusLine = null;
/*      */   
/*      */ 
/*  113 */   private HeaderGroup responseHeaders = new HeaderGroup();
/*      */   
/*      */ 
/*  116 */   private HeaderGroup responseTrailerHeaders = new HeaderGroup();
/*      */   
/*      */ 
/*  119 */   private String path = null;
/*      */   
/*      */ 
/*  122 */   private String queryString = null;
/*      */   
/*      */ 
/*      */ 
/*  126 */   private InputStream responseStream = null;
/*      */   
/*      */ 
/*  129 */   private HttpConnection responseConnection = null;
/*      */   
/*      */ 
/*  132 */   private byte[] responseBody = null;
/*      */   
/*      */ 
/*  135 */   private boolean followRedirects = false;
/*      */   
/*      */ 
/*      */ 
/*  139 */   private boolean doAuthentication = true;
/*      */   
/*      */ 
/*  142 */   private HttpMethodParams params = new HttpMethodParams();
/*      */   
/*      */ 
/*  145 */   private AuthState hostAuthState = new AuthState();
/*      */   
/*      */ 
/*  148 */   private AuthState proxyAuthState = new AuthState();
/*      */   
/*      */ 
/*  151 */   private boolean used = false;
/*      */   
/*      */ 
/*      */ 
/*  155 */   private int recoverableExceptionCount = 0;
/*      */   
/*      */ 
/*  158 */   private HttpHost httphost = null;
/*      */   
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   private MethodRetryHandler methodRetryHandler;
/*      */   
/*      */ 
/*  168 */   private boolean connectionCloseForced = false;
/*      */   
/*      */ 
/*      */   private static final int RESPONSE_WAIT_TIME_MS = 3000;
/*      */   
/*      */ 
/*  174 */   private HttpVersion effectiveVersion = null;
/*      */   
/*      */ 
/*  177 */   private transient boolean aborted = false;
/*      */   
/*      */ 
/*      */ 
/*  181 */   private boolean requestSent = false;
/*      */   
/*      */ 
/*  184 */   private CookieSpec cookiespec = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int DEFAULT_INITIAL_BUFFER_SIZE = 4096;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpMethodBase() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpMethodBase(String uri)
/*      */     throws IllegalArgumentException, IllegalStateException
/*      */   {
/*      */     try
/*      */     {
/*  214 */       if ((uri == null) || (uri.equals(""))) {
/*  215 */         uri = "/";
/*      */       }
/*  217 */       setURI(new URI(uri, true));
/*      */     } catch (URIException e) {
/*  219 */       throw new IllegalArgumentException("Invalid uri '" + uri + "': " + e.getMessage());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract String getName();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URI getURI()
/*      */     throws URIException
/*      */   {
/*  245 */     StringBuffer buffer = new StringBuffer();
/*  246 */     if (this.httphost != null) {
/*  247 */       buffer.append(this.httphost.getProtocol().getScheme());
/*  248 */       buffer.append("://");
/*  249 */       buffer.append(this.httphost.getHostName());
/*  250 */       int port = this.httphost.getPort();
/*  251 */       if ((port != -1) && (port != this.httphost.getProtocol().getDefaultPort())) {
/*  252 */         buffer.append(":");
/*  253 */         buffer.append(port);
/*      */       }
/*      */     }
/*  256 */     buffer.append(this.path);
/*  257 */     if (this.queryString != null) {
/*  258 */       buffer.append('?');
/*  259 */       buffer.append(this.queryString);
/*      */     }
/*  261 */     return new URI(buffer.toString(), true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setURI(URI uri)
/*      */     throws URIException
/*      */   {
/*  275 */     if (uri.isAbsoluteURI()) {
/*  276 */       this.httphost = new HttpHost(uri);
/*      */     }
/*      */     
/*  279 */     setPath(uri.getPath() == null ? "/" : uri.getEscapedPath());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  284 */     setQueryString(uri.getEscapedQuery());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFollowRedirects(boolean followRedirects)
/*      */   {
/*  295 */     this.followRedirects = followRedirects;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getFollowRedirects()
/*      */   {
/*  306 */     return this.followRedirects;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setHttp11(boolean http11)
/*      */   {
/*  316 */     if (http11) {
/*  317 */       this.params.setVersion(HttpVersion.HTTP_1_1);
/*      */     } else {
/*  319 */       this.params.setVersion(HttpVersion.HTTP_1_0);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getDoAuthentication()
/*      */   {
/*  333 */     return this.doAuthentication;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDoAuthentication(boolean doAuthentication)
/*      */   {
/*  346 */     this.doAuthentication = doAuthentication;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public boolean isHttp11()
/*      */   {
/*  360 */     return this.params.getVersion().equals(HttpVersion.HTTP_1_1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPath(String path)
/*      */   {
/*  372 */     this.path = path;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addRequestHeader(Header header)
/*      */   {
/*  382 */     LOG.trace("HttpMethodBase.addRequestHeader(Header)");
/*      */     
/*  384 */     if (header == null) {
/*  385 */       LOG.debug("null header value ignored");
/*      */     } else {
/*  387 */       getRequestHeaderGroup().addHeader(header);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addResponseFooter(Header footer)
/*      */   {
/*  397 */     getResponseTrailerHeaderGroup().addHeader(footer);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPath()
/*      */   {
/*  409 */     return (this.path == null) || (this.path.equals("")) ? "/" : this.path;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setQueryString(String queryString)
/*      */   {
/*  422 */     this.queryString = queryString;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setQueryString(NameValuePair[] params)
/*      */   {
/*  438 */     LOG.trace("enter HttpMethodBase.setQueryString(NameValuePair[])");
/*  439 */     this.queryString = EncodingUtil.formUrlEncode(params, "UTF-8");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getQueryString()
/*      */   {
/*  448 */     return this.queryString;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRequestHeader(String headerName, String headerValue)
/*      */   {
/*  459 */     Header header = new Header(headerName, headerValue);
/*  460 */     setRequestHeader(header);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRequestHeader(Header header)
/*      */   {
/*  471 */     Header[] headers = getRequestHeaderGroup().getHeaders(header.getName());
/*      */     
/*  473 */     for (int i = 0; i < headers.length; i++) {
/*  474 */       getRequestHeaderGroup().removeHeader(headers[i]);
/*      */     }
/*      */     
/*  477 */     getRequestHeaderGroup().addHeader(header);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Header getRequestHeader(String headerName)
/*      */   {
/*  494 */     if (headerName == null) {
/*  495 */       return null;
/*      */     }
/*  497 */     return getRequestHeaderGroup().getCondensedHeader(headerName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Header[] getRequestHeaders()
/*      */   {
/*  507 */     return getRequestHeaderGroup().getAllHeaders();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Header[] getRequestHeaders(String headerName)
/*      */   {
/*  514 */     return getRequestHeaderGroup().getHeaders(headerName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected HeaderGroup getRequestHeaderGroup()
/*      */   {
/*  525 */     return this.requestHeaders;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected HeaderGroup getResponseTrailerHeaderGroup()
/*      */   {
/*  537 */     return this.responseTrailerHeaders;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected HeaderGroup getResponseHeaderGroup()
/*      */   {
/*  548 */     return this.responseHeaders;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Header[] getResponseHeaders(String headerName)
/*      */   {
/*  557 */     return getResponseHeaderGroup().getHeaders(headerName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getStatusCode()
/*      */   {
/*  566 */     return this.statusLine.getStatusCode();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StatusLine getStatusLine()
/*      */   {
/*  576 */     return this.statusLine;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean responseAvailable()
/*      */   {
/*  584 */     return (this.responseBody != null) || (this.responseStream != null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Header[] getResponseHeaders()
/*      */   {
/*  594 */     return getResponseHeaderGroup().getAllHeaders();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Header getResponseHeader(String headerName)
/*      */   {
/*  608 */     if (headerName == null) {
/*  609 */       return null;
/*      */     }
/*  611 */     return getResponseHeaderGroup().getCondensedHeader(headerName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getResponseContentLength()
/*      */   {
/*  630 */     Header[] headers = getResponseHeaderGroup().getHeaders("Content-Length");
/*  631 */     if (headers.length == 0) {
/*  632 */       return -1L;
/*      */     }
/*  634 */     if (headers.length > 1) {
/*  635 */       LOG.warn("Multiple content-length headers detected");
/*      */     }
/*  637 */     for (int i = headers.length - 1; i >= 0; i--) {
/*  638 */       Header header = headers[i];
/*      */       try {
/*  640 */         return Long.parseLong(header.getValue());
/*      */       } catch (NumberFormatException e) {
/*  642 */         if (LOG.isWarnEnabled()) {
/*  643 */           LOG.warn("Invalid content-length value: " + e.getMessage());
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  648 */     return -1L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getResponseBody()
/*      */     throws IOException
/*      */   {
/*  667 */     if (this.responseBody == null) {
/*  668 */       InputStream instream = getResponseBodyAsStream();
/*  669 */       if (instream != null) {
/*  670 */         long contentLength = getResponseContentLength();
/*  671 */         if (contentLength > 2147483647L) {
/*  672 */           throw new IOException("Content too large to be buffered: " + contentLength + " bytes");
/*      */         }
/*  674 */         int limit = getParams().getIntParameter("http.method.response.buffer.warnlimit", 1048576);
/*  675 */         if ((contentLength == -1L) || (contentLength > limit)) {
/*  676 */           LOG.warn("Going to buffer response body of large or unknown size. Using getResponseBodyAsStream instead is recommended.");
/*      */         }
/*      */         
/*  679 */         LOG.debug("Buffering response body");
/*  680 */         ByteArrayOutputStream outstream = new ByteArrayOutputStream(contentLength > 0L ? (int)contentLength : 4096);
/*      */         
/*  682 */         byte[] buffer = new byte['က'];
/*      */         int len;
/*  684 */         while ((len = instream.read(buffer)) > 0) { int i;
/*  685 */           outstream.write(buffer, 0, i);
/*      */         }
/*  687 */         outstream.close();
/*  688 */         setResponseStream(null);
/*  689 */         this.responseBody = outstream.toByteArray();
/*      */       }
/*      */     }
/*  692 */     return this.responseBody;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getResponseBodyAsStream()
/*      */     throws IOException
/*      */   {
/*  705 */     if (this.responseStream != null) {
/*  706 */       return this.responseStream;
/*      */     }
/*  708 */     if (this.responseBody != null) {
/*  709 */       InputStream byteResponseStream = new ByteArrayInputStream(this.responseBody);
/*  710 */       LOG.debug("re-creating response stream from byte array");
/*  711 */       return byteResponseStream;
/*      */     }
/*  713 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getResponseBodyAsString()
/*      */     throws IOException
/*      */   {
/*  733 */     byte[] rawdata = null;
/*  734 */     if (responseAvailable()) {
/*  735 */       rawdata = getResponseBody();
/*      */     }
/*  737 */     if (rawdata != null) {
/*  738 */       return EncodingUtil.getString(rawdata, getResponseCharSet());
/*      */     }
/*  740 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Header[] getResponseFooters()
/*      */   {
/*  751 */     return getResponseTrailerHeaderGroup().getAllHeaders();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Header getResponseFooter(String footerName)
/*      */   {
/*  767 */     if (footerName == null) {
/*  768 */       return null;
/*      */     }
/*  770 */     return getResponseTrailerHeaderGroup().getCondensedHeader(footerName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setResponseStream(InputStream responseStream)
/*      */   {
/*  779 */     this.responseStream = responseStream;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected InputStream getResponseStream()
/*      */   {
/*  791 */     return this.responseStream;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getStatusText()
/*      */   {
/*  801 */     return this.statusLine.getReasonPhrase();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setStrictMode(boolean strictMode)
/*      */   {
/*  817 */     if (strictMode) {
/*  818 */       this.params.makeStrict();
/*      */     } else {
/*  820 */       this.params.makeLenient();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public boolean isStrictMode()
/*      */   {
/*  831 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addRequestHeader(String headerName, String headerValue)
/*      */   {
/*  842 */     addRequestHeader(new Header(headerName, headerValue));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isConnectionCloseForced()
/*      */   {
/*  851 */     return this.connectionCloseForced;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setConnectionCloseForced(boolean b)
/*      */   {
/*  863 */     if (LOG.isDebugEnabled()) {
/*  864 */       LOG.debug("Force-close connection: " + b);
/*      */     }
/*  866 */     this.connectionCloseForced = b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean shouldCloseConnection(HttpConnection conn)
/*      */   {
/*  880 */     if (isConnectionCloseForced()) {
/*  881 */       LOG.debug("Should force-close connection.");
/*  882 */       return true;
/*      */     }
/*      */     
/*  885 */     Header connectionHeader = null;
/*      */     
/*  887 */     if (!conn.isTransparent())
/*      */     {
/*  889 */       connectionHeader = this.responseHeaders.getFirstHeader("proxy-connection");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  894 */     if (connectionHeader == null) {
/*  895 */       connectionHeader = this.responseHeaders.getFirstHeader("connection");
/*      */     }
/*      */     
/*      */ 
/*  899 */     if (connectionHeader == null) {
/*  900 */       connectionHeader = this.requestHeaders.getFirstHeader("connection");
/*      */     }
/*  902 */     if (connectionHeader != null) {
/*  903 */       if (connectionHeader.getValue().equalsIgnoreCase("close")) {
/*  904 */         if (LOG.isDebugEnabled()) {
/*  905 */           LOG.debug("Should close connection in response to directive: " + connectionHeader.getValue());
/*      */         }
/*      */         
/*  908 */         return true; }
/*  909 */       if (connectionHeader.getValue().equalsIgnoreCase("keep-alive")) {
/*  910 */         if (LOG.isDebugEnabled()) {
/*  911 */           LOG.debug("Should NOT close connection in response to directive: " + connectionHeader.getValue());
/*      */         }
/*      */         
/*  914 */         return false;
/*      */       }
/*  916 */       if (LOG.isDebugEnabled()) {
/*  917 */         LOG.debug("Unknown directive: " + connectionHeader.toExternalForm());
/*      */       }
/*      */     }
/*      */     
/*  921 */     LOG.debug("Resorting to protocol version default close connection policy");
/*      */     
/*  923 */     if (this.effectiveVersion.greaterEquals(HttpVersion.HTTP_1_1)) {
/*  924 */       if (LOG.isDebugEnabled()) {
/*  925 */         LOG.debug("Should NOT close connection, using " + this.effectiveVersion.toString());
/*      */       }
/*      */     }
/*  928 */     else if (LOG.isDebugEnabled()) {
/*  929 */       LOG.debug("Should close connection, using " + this.effectiveVersion.toString());
/*      */     }
/*      */     
/*  932 */     return this.effectiveVersion.lessEquals(HttpVersion.HTTP_1_0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void checkExecuteConditions(HttpState state, HttpConnection conn)
/*      */     throws HttpException
/*      */   {
/*  945 */     if (state == null) {
/*  946 */       throw new IllegalArgumentException("HttpState parameter may not be null");
/*      */     }
/*  948 */     if (conn == null) {
/*  949 */       throw new IllegalArgumentException("HttpConnection parameter may not be null");
/*      */     }
/*  951 */     if (this.aborted) {
/*  952 */       throw new IllegalStateException("Method has been aborted");
/*      */     }
/*  954 */     if (!validate()) {
/*  955 */       throw new ProtocolException("HttpMethodBase object not valid");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int execute(HttpState state, HttpConnection conn)
/*      */     throws HttpException, IOException
/*      */   {
/*  976 */     LOG.trace("enter HttpMethodBase.execute(HttpState, HttpConnection)");
/*      */     
/*      */ 
/*      */ 
/*  980 */     this.responseConnection = conn;
/*      */     
/*  982 */     checkExecuteConditions(state, conn);
/*  983 */     this.statusLine = null;
/*  984 */     this.connectionCloseForced = false;
/*      */     
/*  986 */     conn.setLastResponseInputStream(null);
/*      */     
/*      */ 
/*  989 */     if (this.effectiveVersion == null) {
/*  990 */       this.effectiveVersion = this.params.getVersion();
/*      */     }
/*      */     
/*  993 */     writeRequest(state, conn);
/*  994 */     this.requestSent = true;
/*  995 */     readResponse(state, conn);
/*      */     
/*  997 */     this.used = true;
/*      */     
/*  999 */     return this.statusLine.getStatusCode();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void abort()
/*      */   {
/* 1008 */     if (this.aborted) {
/* 1009 */       return;
/*      */     }
/* 1011 */     this.aborted = true;
/* 1012 */     HttpConnection conn = this.responseConnection;
/* 1013 */     if (conn != null) {
/* 1014 */       conn.close();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasBeenUsed()
/*      */   {
/* 1025 */     return this.used;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void recycle()
/*      */   {
/* 1040 */     LOG.trace("enter HttpMethodBase.recycle()");
/*      */     
/* 1042 */     releaseConnection();
/*      */     
/* 1044 */     this.path = null;
/* 1045 */     this.followRedirects = false;
/* 1046 */     this.doAuthentication = true;
/* 1047 */     this.queryString = null;
/* 1048 */     getRequestHeaderGroup().clear();
/* 1049 */     getResponseHeaderGroup().clear();
/* 1050 */     getResponseTrailerHeaderGroup().clear();
/* 1051 */     this.statusLine = null;
/* 1052 */     this.effectiveVersion = null;
/* 1053 */     this.aborted = false;
/* 1054 */     this.used = false;
/* 1055 */     this.params = new HttpMethodParams();
/* 1056 */     this.responseBody = null;
/* 1057 */     this.recoverableExceptionCount = 0;
/* 1058 */     this.connectionCloseForced = false;
/* 1059 */     this.hostAuthState.invalidate();
/* 1060 */     this.proxyAuthState.invalidate();
/* 1061 */     this.cookiespec = null;
/* 1062 */     this.requestSent = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void releaseConnection()
/*      */   {
/*      */     try
/*      */     {
/* 1075 */       if (this.responseStream != null) {
/*      */         try
/*      */         {
/* 1078 */           this.responseStream.close();
/*      */         }
/*      */         catch (IOException ignore) {}
/*      */       }
/*      */     } finally {
/* 1083 */       ensureConnectionRelease();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeRequestHeader(String headerName)
/*      */   {
/* 1095 */     Header[] headers = getRequestHeaderGroup().getHeaders(headerName);
/* 1096 */     for (int i = 0; i < headers.length; i++) {
/* 1097 */       getRequestHeaderGroup().removeHeader(headers[i]);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeRequestHeader(Header header)
/*      */   {
/* 1108 */     if (header == null) {
/* 1109 */       return;
/*      */     }
/* 1111 */     getRequestHeaderGroup().removeHeader(header);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean validate()
/*      */   {
/* 1122 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private CookieSpec getCookieSpec(HttpState state)
/*      */   {
/* 1134 */     if (this.cookiespec == null) {
/* 1135 */       int i = state.getCookiePolicy();
/* 1136 */       if (i == -1) {
/* 1137 */         this.cookiespec = CookiePolicy.getCookieSpec(this.params.getCookiePolicy());
/*      */       } else {
/* 1139 */         this.cookiespec = CookiePolicy.getSpecByPolicy(i);
/*      */       }
/* 1141 */       this.cookiespec.setValidDateFormats((Collection)this.params.getParameter("http.dateparser.patterns"));
/*      */     }
/*      */     
/* 1144 */     return this.cookiespec;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void addCookieRequestHeader(HttpState state, HttpConnection conn)
/*      */     throws IOException, HttpException
/*      */   {
/* 1163 */     LOG.trace("enter HttpMethodBase.addCookieRequestHeader(HttpState, HttpConnection)");
/*      */     
/*      */ 
/* 1166 */     Header[] cookieheaders = getRequestHeaderGroup().getHeaders("Cookie");
/* 1167 */     for (int i = 0; i < cookieheaders.length; i++) {
/* 1168 */       Header cookieheader = cookieheaders[i];
/* 1169 */       if (cookieheader.isAutogenerated()) {
/* 1170 */         getRequestHeaderGroup().removeHeader(cookieheader);
/*      */       }
/*      */     }
/*      */     
/* 1174 */     CookieSpec matcher = getCookieSpec(state);
/* 1175 */     String host = this.params.getVirtualHost();
/* 1176 */     if (host == null) {
/* 1177 */       host = conn.getHost();
/*      */     }
/* 1179 */     Cookie[] cookies = matcher.match(host, conn.getPort(), getPath(), conn.isSecure(), state.getCookies());
/*      */     
/* 1181 */     if ((cookies != null) && (cookies.length > 0)) {
/* 1182 */       if (getParams().isParameterTrue("http.protocol.single-cookie-header"))
/*      */       {
/* 1184 */         String s = matcher.formatCookies(cookies);
/* 1185 */         getRequestHeaderGroup().addHeader(new Header("Cookie", s, true));
/*      */       }
/*      */       else {
/* 1188 */         for (int i = 0; i < cookies.length; i++) {
/* 1189 */           String s = matcher.formatCookie(cookies[i]);
/* 1190 */           getRequestHeaderGroup().addHeader(new Header("Cookie", s, true));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void addHostRequestHeader(HttpState state, HttpConnection conn)
/*      */     throws IOException, HttpException
/*      */   {
/* 1211 */     LOG.trace("enter HttpMethodBase.addHostRequestHeader(HttpState, HttpConnection)");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1218 */     String host = this.params.getVirtualHost();
/* 1219 */     if (host != null) {
/* 1220 */       LOG.debug("Using virtual host name: " + host);
/*      */     } else {
/* 1222 */       host = conn.getHost();
/*      */     }
/* 1224 */     int port = conn.getPort();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1234 */     if (LOG.isDebugEnabled()) {
/* 1235 */       LOG.debug("Adding Host request header");
/*      */     }
/*      */     
/*      */ 
/* 1239 */     if (conn.getProtocol().getDefaultPort() != port) {
/* 1240 */       host = host + ":" + port;
/*      */     }
/*      */     
/* 1243 */     setRequestHeader("Host", host);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void addProxyConnectionHeader(HttpState state, HttpConnection conn)
/*      */     throws IOException, HttpException
/*      */   {
/* 1262 */     LOG.trace("enter HttpMethodBase.addProxyConnectionHeader(HttpState, HttpConnection)");
/*      */     
/* 1264 */     if ((!conn.isTransparent()) && 
/* 1265 */       (getRequestHeader("Proxy-Connection") == null)) {
/* 1266 */       addRequestHeader("Proxy-Connection", "Keep-Alive");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void addRequestHeaders(HttpState state, HttpConnection conn)
/*      */     throws IOException, HttpException
/*      */   {
/* 1300 */     LOG.trace("enter HttpMethodBase.addRequestHeaders(HttpState, HttpConnection)");
/*      */     
/*      */ 
/* 1303 */     addUserAgentRequestHeader(state, conn);
/* 1304 */     addHostRequestHeader(state, conn);
/* 1305 */     addCookieRequestHeader(state, conn);
/* 1306 */     addProxyConnectionHeader(state, conn);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void addUserAgentRequestHeader(HttpState state, HttpConnection conn)
/*      */     throws IOException, HttpException
/*      */   {
/* 1325 */     LOG.trace("enter HttpMethodBase.addUserAgentRequestHeaders(HttpState, HttpConnection)");
/*      */     
/*      */ 
/* 1328 */     if (getRequestHeader("User-Agent") == null) {
/* 1329 */       String agent = (String)getParams().getParameter("http.useragent");
/* 1330 */       if (agent == null) {
/* 1331 */         agent = "Jakarta Commons-HttpClient";
/*      */       }
/* 1333 */       setRequestHeader("User-Agent", agent);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void checkNotUsed()
/*      */     throws IllegalStateException
/*      */   {
/* 1345 */     if (this.used) {
/* 1346 */       throw new IllegalStateException("Already used.");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void checkUsed()
/*      */     throws IllegalStateException
/*      */   {
/* 1358 */     if (!this.used) {
/* 1359 */       throw new IllegalStateException("Not Used.");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static String generateRequestLine(HttpConnection connection, String name, String requestPath, String query, String version)
/*      */   {
/* 1379 */     LOG.trace("enter HttpMethodBase.generateRequestLine(HttpConnection, String, String, String, String)");
/*      */     
/*      */ 
/* 1382 */     StringBuffer buf = new StringBuffer();
/*      */     
/* 1384 */     buf.append(name);
/* 1385 */     buf.append(" ");
/*      */     
/* 1387 */     if (!connection.isTransparent()) {
/* 1388 */       Protocol protocol = connection.getProtocol();
/* 1389 */       buf.append(protocol.getScheme().toLowerCase());
/* 1390 */       buf.append("://");
/* 1391 */       buf.append(connection.getHost());
/* 1392 */       if ((connection.getPort() != -1) && (connection.getPort() != protocol.getDefaultPort()))
/*      */       {
/*      */ 
/* 1395 */         buf.append(":");
/* 1396 */         buf.append(connection.getPort());
/*      */       }
/*      */     }
/*      */     
/* 1400 */     if (requestPath == null) {
/* 1401 */       buf.append("/");
/*      */     } else {
/* 1403 */       if ((!connection.isTransparent()) && (!requestPath.startsWith("/"))) {
/* 1404 */         buf.append("/");
/*      */       }
/* 1406 */       buf.append(requestPath);
/*      */     }
/*      */     
/* 1409 */     if (query != null) {
/* 1410 */       if (query.indexOf("?") != 0) {
/* 1411 */         buf.append("?");
/*      */       }
/* 1413 */       buf.append(query);
/*      */     }
/*      */     
/* 1416 */     buf.append(" ");
/* 1417 */     buf.append(version);
/* 1418 */     buf.append("\r\n");
/*      */     
/* 1420 */     return buf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void processResponseBody(HttpState state, HttpConnection conn) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void processResponseHeaders(HttpState state, HttpConnection conn)
/*      */   {
/* 1462 */     LOG.trace("enter HttpMethodBase.processResponseHeaders(HttpState, HttpConnection)");
/*      */     
/*      */ 
/* 1465 */     Header[] headers = getResponseHeaderGroup().getHeaders("set-cookie2");
/*      */     
/*      */ 
/* 1468 */     if (headers.length == 0) {
/* 1469 */       headers = getResponseHeaderGroup().getHeaders("set-cookie");
/*      */     }
/*      */     
/* 1472 */     CookieSpec parser = getCookieSpec(state);
/* 1473 */     String host = this.params.getVirtualHost();
/* 1474 */     if (host == null) {
/* 1475 */       host = conn.getHost();
/*      */     }
/* 1477 */     for (int i = 0; i < headers.length; i++) {
/* 1478 */       Header header = headers[i];
/* 1479 */       Cookie[] cookies = null;
/*      */       try {
/* 1481 */         cookies = parser.parse(host, conn.getPort(), getPath(), conn.isSecure(), header);
/*      */ 
/*      */ 
/*      */       }
/*      */       catch (MalformedCookieException e)
/*      */       {
/*      */ 
/* 1488 */         if (LOG.isWarnEnabled()) {
/* 1489 */           LOG.warn("Invalid cookie header: \"" + header.getValue() + "\". " + e.getMessage());
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1494 */       if (cookies != null) {
/* 1495 */         for (int j = 0; j < cookies.length; j++) {
/* 1496 */           Cookie cookie = cookies[j];
/*      */           try {
/* 1498 */             parser.validate(host, conn.getPort(), getPath(), conn.isSecure(), cookie);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1504 */             state.addCookie(cookie);
/* 1505 */             if (LOG.isDebugEnabled()) {
/* 1506 */               LOG.debug("Cookie accepted: \"" + parser.formatCookie(cookie) + "\"");
/*      */             }
/*      */           }
/*      */           catch (MalformedCookieException e) {
/* 1510 */             if (LOG.isWarnEnabled()) {
/* 1511 */               LOG.warn("Cookie rejected: \"" + parser.formatCookie(cookie) + "\". " + e.getMessage());
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void processStatusLine(HttpState state, HttpConnection conn) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void readResponse(HttpState state, HttpConnection conn)
/*      */     throws IOException, HttpException
/*      */   {
/* 1585 */     LOG.trace("enter HttpMethodBase.readResponse(HttpState, HttpConnection)");
/*      */     
/*      */ 
/*      */ 
/* 1589 */     while (this.statusLine == null) {
/* 1590 */       readStatusLine(state, conn);
/* 1591 */       processStatusLine(state, conn);
/* 1592 */       readResponseHeaders(state, conn);
/* 1593 */       processResponseHeaders(state, conn);
/*      */       
/* 1595 */       int status = this.statusLine.getStatusCode();
/* 1596 */       if ((status >= 100) && (status < 200)) {
/* 1597 */         if (LOG.isInfoEnabled()) {
/* 1598 */           LOG.info("Discarding unexpected response: " + this.statusLine.toString());
/*      */         }
/* 1600 */         this.statusLine = null;
/*      */       }
/*      */     }
/* 1603 */     readResponseBody(state, conn);
/* 1604 */     processResponseBody(state, conn);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void readResponseBody(HttpState state, HttpConnection conn)
/*      */     throws IOException, HttpException
/*      */   {
/* 1636 */     LOG.trace("enter HttpMethodBase.readResponseBody(HttpState, HttpConnection)");
/*      */     
/*      */ 
/*      */ 
/* 1640 */     InputStream stream = readResponseBody(conn);
/* 1641 */     if (stream == null)
/*      */     {
/* 1643 */       responseBodyConsumed();
/*      */     } else {
/* 1645 */       conn.setLastResponseInputStream(stream);
/* 1646 */       setResponseStream(stream);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private InputStream readResponseBody(HttpConnection conn)
/*      */     throws HttpException, IOException
/*      */   {
/* 1671 */     LOG.trace("enter HttpMethodBase.readResponseBody(HttpConnection)");
/*      */     
/* 1673 */     this.responseBody = null;
/* 1674 */     InputStream is = conn.getResponseInputStream();
/* 1675 */     if (Wire.CONTENT_WIRE.enabled()) {
/* 1676 */       is = new WireLogInputStream(is, Wire.CONTENT_WIRE);
/*      */     }
/* 1678 */     boolean canHaveBody = canResponseHaveBody(this.statusLine.getStatusCode());
/* 1679 */     InputStream result = null;
/* 1680 */     Header transferEncodingHeader = this.responseHeaders.getFirstHeader("Transfer-Encoding");
/*      */     
/*      */ 
/* 1683 */     if (transferEncodingHeader != null)
/*      */     {
/* 1685 */       String transferEncoding = transferEncodingHeader.getValue();
/* 1686 */       if ((!"chunked".equalsIgnoreCase(transferEncoding)) && (!"identity".equalsIgnoreCase(transferEncoding)))
/*      */       {
/* 1688 */         if (LOG.isWarnEnabled()) {
/* 1689 */           LOG.warn("Unsupported transfer encoding: " + transferEncoding);
/*      */         }
/*      */       }
/* 1692 */       HeaderElement[] encodings = transferEncodingHeader.getElements();
/*      */       
/*      */ 
/* 1695 */       int len = encodings.length;
/* 1696 */       if ((len > 0) && ("chunked".equalsIgnoreCase(encodings[(len - 1)].getName())))
/*      */       {
/* 1698 */         if (conn.isResponseAvailable(conn.getParams().getSoTimeout())) {
/* 1699 */           result = new ChunkedInputStream(is, this);
/*      */         } else {
/* 1701 */           if (getParams().isParameterTrue("http.protocol.strict-transfer-encoding")) {
/* 1702 */             throw new ProtocolException("Chunk-encoded body declared but not sent");
/*      */           }
/* 1704 */           LOG.warn("Chunk-encoded body missing");
/*      */         }
/*      */       }
/*      */       else {
/* 1708 */         LOG.info("Response content is not chunk-encoded");
/*      */         
/*      */ 
/* 1711 */         setConnectionCloseForced(true);
/* 1712 */         result = is;
/*      */       }
/*      */     } else {
/* 1715 */       long expectedLength = getResponseContentLength();
/* 1716 */       if (expectedLength == -1L) {
/* 1717 */         if ((canHaveBody) && (this.effectiveVersion.greaterEquals(HttpVersion.HTTP_1_1))) {
/* 1718 */           Header connectionHeader = this.responseHeaders.getFirstHeader("Connection");
/* 1719 */           String connectionDirective = null;
/* 1720 */           if (connectionHeader != null) {
/* 1721 */             connectionDirective = connectionHeader.getValue();
/*      */           }
/* 1723 */           if (!"close".equalsIgnoreCase(connectionDirective)) {
/* 1724 */             LOG.info("Response content length is not known");
/* 1725 */             setConnectionCloseForced(true);
/*      */           }
/*      */         }
/* 1728 */         result = is;
/*      */       } else {
/* 1730 */         result = new ContentLengthInputStream(is, expectedLength);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1735 */     if (!canHaveBody) {
/* 1736 */       result = null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1741 */     if (result != null)
/*      */     {
/* 1743 */       result = new AutoCloseInputStream(result, new ResponseConsumedWatcher()
/*      */       {
/*      */         public void responseConsumed()
/*      */         {
/* 1747 */           HttpMethodBase.this.responseBodyConsumed();
/*      */         }
/*      */       });
/*      */     }
/*      */     
/*      */ 
/* 1753 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void readResponseHeaders(HttpState state, HttpConnection conn)
/*      */     throws IOException, HttpException
/*      */   {
/* 1785 */     LOG.trace("enter HttpMethodBase.readResponseHeaders(HttpState,HttpConnection)");
/*      */     
/*      */ 
/* 1788 */     getResponseHeaderGroup().clear();
/*      */     
/* 1790 */     Header[] headers = HttpParser.parseHeaders(conn.getResponseInputStream(), getParams().getHttpElementCharset());
/*      */     
/* 1792 */     if (Wire.HEADER_WIRE.enabled()) {
/* 1793 */       for (int i = 0; i < headers.length; i++) {
/* 1794 */         Wire.HEADER_WIRE.input(headers[i].toExternalForm());
/*      */       }
/*      */     }
/* 1797 */     getResponseHeaderGroup().setHeaders(headers);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void readStatusLine(HttpState state, HttpConnection conn)
/*      */     throws IOException, HttpException
/*      */   {
/* 1823 */     LOG.trace("enter HttpMethodBase.readStatusLine(HttpState, HttpConnection)");
/*      */     
/* 1825 */     int maxGarbageLines = getParams().getIntParameter("http.protocol.status-line-garbage-limit", Integer.MAX_VALUE);
/*      */     
/*      */ 
/*      */ 
/* 1829 */     int count = 0;
/*      */     String s;
/*      */     for (;;) {
/* 1832 */       s = conn.readLine(getParams().getHttpElementCharset());
/* 1833 */       if ((s == null) && (count == 0))
/*      */       {
/* 1835 */         throw new NoHttpResponseException("The server " + conn.getHost() + " failed to respond");
/*      */       }
/*      */       
/* 1838 */       if (Wire.HEADER_WIRE.enabled()) {
/* 1839 */         Wire.HEADER_WIRE.input(s + "\r\n");
/*      */       }
/* 1841 */       if ((s != null) && (StatusLine.startsWithHTTP(s))) {
/*      */         break;
/*      */       }
/* 1844 */       if ((s == null) || (count >= maxGarbageLines))
/*      */       {
/* 1846 */         throw new ProtocolException("The server " + conn.getHost() + " failed to respond with a valid HTTP response");
/*      */       }
/*      */       
/* 1849 */       count++;
/*      */     }
/*      */     
/*      */ 
/* 1853 */     this.statusLine = new StatusLine(s);
/*      */     
/*      */ 
/* 1856 */     String versionStr = this.statusLine.getHttpVersion();
/* 1857 */     if ((getParams().isParameterFalse("http.protocol.unambiguous-statusline")) && (versionStr.equals("HTTP")))
/*      */     {
/* 1859 */       getParams().setVersion(HttpVersion.HTTP_1_0);
/* 1860 */       if (LOG.isWarnEnabled()) {
/* 1861 */         LOG.warn("Ambiguous status line (HTTP protocol version missing):" + this.statusLine.toString());
/*      */       }
/*      */     }
/*      */     else {
/* 1865 */       this.effectiveVersion = HttpVersion.parse(versionStr);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void writeRequest(HttpState state, HttpConnection conn)
/*      */     throws IOException, HttpException
/*      */   {
/* 1916 */     LOG.trace("enter HttpMethodBase.writeRequest(HttpState, HttpConnection)");
/*      */     
/* 1918 */     writeRequestLine(state, conn);
/* 1919 */     writeRequestHeaders(state, conn);
/* 1920 */     conn.writeLine();
/* 1921 */     if (Wire.HEADER_WIRE.enabled()) {
/* 1922 */       Wire.HEADER_WIRE.output("\r\n");
/*      */     }
/*      */     
/* 1925 */     HttpVersion ver = getParams().getVersion();
/* 1926 */     Header expectheader = getRequestHeader("Expect");
/* 1927 */     String expectvalue = null;
/* 1928 */     if (expectheader != null) {
/* 1929 */       expectvalue = expectheader.getValue();
/*      */     }
/* 1931 */     if ((expectvalue != null) && (expectvalue.compareToIgnoreCase("100-continue") == 0))
/*      */     {
/* 1933 */       if (ver.greaterEquals(HttpVersion.HTTP_1_1))
/*      */       {
/*      */ 
/* 1936 */         conn.flushRequestOutputStream();
/*      */         
/* 1938 */         int readTimeout = conn.getParams().getSoTimeout();
/*      */         try {
/* 1940 */           conn.setSocketTimeout(3000);
/* 1941 */           readStatusLine(state, conn);
/* 1942 */           processStatusLine(state, conn);
/* 1943 */           readResponseHeaders(state, conn);
/* 1944 */           processResponseHeaders(state, conn);
/*      */           
/* 1946 */           if (this.statusLine.getStatusCode() == 100)
/*      */           {
/* 1948 */             this.statusLine = null;
/* 1949 */             LOG.debug("OK to continue received");
/*      */           } else {
/* 1951 */             return;
/*      */           }
/*      */         } catch (InterruptedIOException e) {
/* 1954 */           if (!ExceptionUtil.isSocketTimeoutException(e)) {
/* 1955 */             throw e;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1960 */           removeRequestHeader("Expect");
/* 1961 */           LOG.info("100 (continue) read timeout. Resume sending the request");
/*      */         } finally {
/* 1963 */           conn.setSocketTimeout(readTimeout);
/*      */         }
/*      */       }
/*      */       else {
/* 1967 */         removeRequestHeader("Expect");
/* 1968 */         LOG.info("'Expect: 100-continue' handshake is only supported by HTTP/1.1 or higher");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1973 */     writeRequestBody(state, conn);
/*      */     
/* 1975 */     conn.flushRequestOutputStream();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean writeRequestBody(HttpState state, HttpConnection conn)
/*      */     throws IOException, HttpException
/*      */   {
/* 2004 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void writeRequestHeaders(HttpState state, HttpConnection conn)
/*      */     throws IOException, HttpException
/*      */   {
/* 2034 */     LOG.trace("enter HttpMethodBase.writeRequestHeaders(HttpState,HttpConnection)");
/*      */     
/* 2036 */     addRequestHeaders(state, conn);
/*      */     
/* 2038 */     String charset = getParams().getHttpElementCharset();
/*      */     
/* 2040 */     Header[] headers = getRequestHeaders();
/* 2041 */     for (int i = 0; i < headers.length; i++) {
/* 2042 */       String s = headers[i].toExternalForm();
/* 2043 */       if (Wire.HEADER_WIRE.enabled()) {
/* 2044 */         Wire.HEADER_WIRE.output(s);
/*      */       }
/* 2046 */       conn.print(s, charset);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void writeRequestLine(HttpState state, HttpConnection conn)
/*      */     throws IOException, HttpException
/*      */   {
/* 2071 */     LOG.trace("enter HttpMethodBase.writeRequestLine(HttpState, HttpConnection)");
/*      */     
/* 2073 */     String requestLine = getRequestLine(conn);
/* 2074 */     if (Wire.HEADER_WIRE.enabled()) {
/* 2075 */       Wire.HEADER_WIRE.output(requestLine);
/*      */     }
/* 2077 */     conn.print(requestLine, getParams().getHttpElementCharset());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getRequestLine(HttpConnection conn)
/*      */   {
/* 2089 */     return generateRequestLine(conn, getName(), getPath(), getQueryString(), this.effectiveVersion.toString());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpMethodParams getParams()
/*      */   {
/* 2101 */     return this.params;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setParams(HttpMethodParams params)
/*      */   {
/* 2112 */     if (params == null) {
/* 2113 */       throw new IllegalArgumentException("Parameters may not be null");
/*      */     }
/* 2115 */     this.params = params;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpVersion getEffectiveVersion()
/*      */   {
/* 2127 */     return this.effectiveVersion;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static boolean canResponseHaveBody(int status)
/*      */   {
/* 2140 */     LOG.trace("enter HttpMethodBase.canResponseHaveBody(int)");
/*      */     
/* 2142 */     boolean result = true;
/*      */     
/* 2144 */     if (((status >= 100) && (status <= 199)) || (status == 204) || (status == 304))
/*      */     {
/* 2146 */       result = false;
/*      */     }
/*      */     
/* 2149 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public String getProxyAuthenticationRealm()
/*      */   {
/* 2161 */     return this.proxyAuthState.getRealm();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public String getAuthenticationRealm()
/*      */   {
/* 2173 */     return this.hostAuthState.getRealm();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getContentCharSet(Header contentheader)
/*      */   {
/* 2183 */     LOG.trace("enter getContentCharSet( Header contentheader )");
/* 2184 */     String charset = null;
/* 2185 */     if (contentheader != null) {
/* 2186 */       HeaderElement[] values = contentheader.getElements();
/*      */       
/*      */ 
/* 2189 */       if (values.length == 1) {
/* 2190 */         NameValuePair param = values[0].getParameterByName("charset");
/* 2191 */         if (param != null)
/*      */         {
/*      */ 
/* 2194 */           charset = param.getValue();
/*      */         }
/*      */       }
/*      */     }
/* 2198 */     if (charset == null) {
/* 2199 */       charset = getParams().getContentCharset();
/* 2200 */       if (LOG.isDebugEnabled()) {
/* 2201 */         LOG.debug("Default charset used: " + charset);
/*      */       }
/*      */     }
/* 2204 */     return charset;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRequestCharSet()
/*      */   {
/* 2214 */     return getContentCharSet(getRequestHeader("Content-Type"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getResponseCharSet()
/*      */   {
/* 2224 */     return getContentCharSet(getResponseHeader("Content-Type"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public int getRecoverableExceptionCount()
/*      */   {
/* 2236 */     return this.recoverableExceptionCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void responseBodyConsumed()
/*      */   {
/* 2252 */     this.responseStream = null;
/* 2253 */     if (this.responseConnection != null) {
/* 2254 */       this.responseConnection.setLastResponseInputStream(null);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2260 */       if (shouldCloseConnection(this.responseConnection)) {
/* 2261 */         this.responseConnection.close();
/*      */       } else {
/*      */         try {
/* 2264 */           if (this.responseConnection.isResponseAvailable()) {
/* 2265 */             boolean logExtraInput = getParams().isParameterTrue("http.protocol.warn-extra-input");
/*      */             
/*      */ 
/* 2268 */             if (logExtraInput) {
/* 2269 */               LOG.warn("Extra response data detected - closing connection");
/*      */             }
/* 2271 */             this.responseConnection.close();
/*      */           }
/*      */         }
/*      */         catch (IOException e) {
/* 2275 */           LOG.warn(e.getMessage());
/* 2276 */           this.responseConnection.close();
/*      */         }
/*      */       }
/*      */     }
/* 2280 */     this.connectionCloseForced = false;
/* 2281 */     ensureConnectionRelease();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void ensureConnectionRelease()
/*      */   {
/* 2288 */     if (this.responseConnection != null) {
/* 2289 */       this.responseConnection.releaseConnection();
/* 2290 */       this.responseConnection = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public HostConfiguration getHostConfiguration()
/*      */   {
/* 2302 */     HostConfiguration hostconfig = new HostConfiguration();
/* 2303 */     hostconfig.setHost(this.httphost);
/* 2304 */     return hostconfig;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setHostConfiguration(HostConfiguration hostconfig)
/*      */   {
/* 2314 */     if (hostconfig != null) {
/* 2315 */       this.httphost = new HttpHost(hostconfig.getHost(), hostconfig.getPort(), hostconfig.getProtocol());
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 2320 */       this.httphost = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public MethodRetryHandler getMethodRetryHandler()
/*      */   {
/* 2332 */     return this.methodRetryHandler;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setMethodRetryHandler(MethodRetryHandler handler)
/*      */   {
/* 2343 */     this.methodRetryHandler = handler;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void fakeResponse(StatusLine statusline, HeaderGroup responseheaders, InputStream responseStream)
/*      */   {
/* 2360 */     this.used = true;
/* 2361 */     this.statusLine = statusline;
/* 2362 */     this.responseHeaders = responseheaders;
/* 2363 */     this.responseBody = null;
/* 2364 */     this.responseStream = responseStream;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AuthState getHostAuthState()
/*      */   {
/* 2375 */     return this.hostAuthState;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AuthState getProxyAuthState()
/*      */   {
/* 2386 */     return this.proxyAuthState;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isAborted()
/*      */   {
/* 2398 */     return this.aborted;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isRequestSent()
/*      */   {
/* 2410 */     return this.requestSent;
/*      */   }
/*      */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\HttpMethodBase.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */