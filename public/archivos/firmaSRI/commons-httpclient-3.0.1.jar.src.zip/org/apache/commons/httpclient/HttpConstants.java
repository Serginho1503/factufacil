/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ /**
/*     */  * @deprecated
/*     */  */
/*     */ public class HttpConstants
/*     */ {
/*     */   public static final String HTTP_ELEMENT_CHARSET = "US-ASCII";
/*     */   public static final String DEFAULT_CONTENT_CHARSET = "ISO-8859-1";
/*  55 */   private static final Log LOG = LogFactory.getLog(HttpConstants.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] getBytes(String data)
/*     */   {
/*  66 */     if (data == null) {
/*  67 */       throw new IllegalArgumentException("Parameter may not be null");
/*     */     }
/*     */     try
/*     */     {
/*  71 */       return data.getBytes("US-ASCII");
/*     */     }
/*     */     catch (UnsupportedEncodingException e) {
/*  74 */       if (LOG.isWarnEnabled()) {
/*  75 */         LOG.warn("Unsupported encoding: US-ASCII. System default encoding used");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  80 */     return data.getBytes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getString(byte[] data, int offset, int length)
/*     */   {
/*  96 */     if (data == null) {
/*  97 */       throw new IllegalArgumentException("Parameter may not be null");
/*     */     }
/*     */     try
/*     */     {
/* 101 */       return new String(data, offset, length, "US-ASCII");
/*     */     }
/*     */     catch (UnsupportedEncodingException e) {
/* 104 */       if (LOG.isWarnEnabled()) {
/* 105 */         LOG.warn("Unsupported encoding: US-ASCII. System default encoding used");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 110 */     return new String(data, offset, length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getString(byte[] data)
/*     */   {
/* 123 */     return getString(data, 0, data.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] getContentBytes(String data, String charset)
/*     */   {
/* 138 */     if (data == null) {
/* 139 */       throw new IllegalArgumentException("Parameter may not be null");
/*     */     }
/*     */     
/* 142 */     if ((charset == null) || (charset.equals(""))) {
/* 143 */       charset = "ISO-8859-1";
/*     */     }
/*     */     try
/*     */     {
/* 147 */       return data.getBytes(charset);
/*     */     }
/*     */     catch (UnsupportedEncodingException e) {
/* 150 */       if (LOG.isWarnEnabled()) {
/* 151 */         LOG.warn("Unsupported encoding: " + charset + ". HTTP default encoding used");
/*     */       }
/*     */       
/*     */ 
/*     */       try
/*     */       {
/* 157 */         return data.getBytes("ISO-8859-1");
/*     */       }
/*     */       catch (UnsupportedEncodingException e2) {
/* 160 */         if (LOG.isWarnEnabled()) {
/* 161 */           LOG.warn("Unsupported encoding: ISO-8859-1. System encoding used");
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 166 */     return data.getBytes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getContentString(byte[] data, int offset, int length, String charset)
/*     */   {
/* 190 */     if (data == null) {
/* 191 */       throw new IllegalArgumentException("Parameter may not be null");
/*     */     }
/*     */     
/* 194 */     if ((charset == null) || (charset.equals(""))) {
/* 195 */       charset = "ISO-8859-1";
/*     */     }
/*     */     try
/*     */     {
/* 199 */       return new String(data, offset, length, charset);
/*     */     }
/*     */     catch (UnsupportedEncodingException e) {
/* 202 */       if (LOG.isWarnEnabled()) {
/* 203 */         LOG.warn("Unsupported encoding: " + charset + ". Default HTTP encoding used");
/*     */       }
/*     */       try
/*     */       {
/* 207 */         return new String(data, offset, length, "ISO-8859-1");
/*     */       }
/*     */       catch (UnsupportedEncodingException e2) {
/* 210 */         if (LOG.isWarnEnabled()) {
/* 211 */           LOG.warn("Unsupported encoding: ISO-8859-1. System encoding used");
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 216 */     return new String(data, offset, length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getContentString(byte[] data, String charset)
/*     */   {
/* 233 */     return getContentString(data, 0, data.length, charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] getContentBytes(String data)
/*     */   {
/* 245 */     return getContentBytes(data, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getContentString(byte[] data, int offset, int length)
/*     */   {
/* 259 */     return getContentString(data, offset, length, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getContentString(byte[] data)
/*     */   {
/* 271 */     return getContentString(data, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] getAsciiBytes(String data)
/*     */   {
/* 282 */     if (data == null) {
/* 283 */       throw new IllegalArgumentException("Parameter may not be null");
/*     */     }
/*     */     try
/*     */     {
/* 287 */       return data.getBytes("US-ASCII");
/*     */     } catch (UnsupportedEncodingException e) {
/* 289 */       throw new RuntimeException("HttpClient requires ASCII support");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getAsciiString(byte[] data, int offset, int length)
/*     */   {
/* 305 */     if (data == null) {
/* 306 */       throw new IllegalArgumentException("Parameter may not be null");
/*     */     }
/*     */     try
/*     */     {
/* 310 */       return new String(data, offset, length, "US-ASCII");
/*     */     } catch (UnsupportedEncodingException e) {
/* 312 */       throw new RuntimeException("HttpClient requires ASCII support");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getAsciiString(byte[] data)
/*     */   {
/* 325 */     return getAsciiString(data, 0, data.length);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\HttpConstants.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */