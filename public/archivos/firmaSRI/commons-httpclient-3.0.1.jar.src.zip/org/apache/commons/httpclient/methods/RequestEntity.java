package org.apache.commons.httpclient.methods;

import java.io.IOException;
import java.io.OutputStream;

public abstract interface RequestEntity
{
  public abstract boolean isRepeatable();
  
  public abstract void writeRequest(OutputStream paramOutputStream)
    throws IOException;
  
  public abstract long getContentLength();
  
  public abstract String getContentType();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\methods\RequestEntity.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */