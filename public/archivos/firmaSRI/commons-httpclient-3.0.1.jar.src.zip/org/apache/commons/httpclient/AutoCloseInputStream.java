/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AutoCloseInputStream
/*     */   extends FilterInputStream
/*     */ {
/*  52 */   private boolean streamOpen = true;
/*     */   
/*     */ 
/*  55 */   private boolean selfClosed = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  61 */   private ResponseConsumedWatcher watcher = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AutoCloseInputStream(InputStream in, ResponseConsumedWatcher watcher)
/*     */   {
/*  72 */     super(in);
/*  73 */     this.watcher = watcher;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/*  83 */     int l = -1;
/*     */     
/*  85 */     if (isReadAllowed())
/*     */     {
/*  87 */       l = super.read();
/*  88 */       checkClose(l);
/*     */     }
/*     */     
/*  91 */     return l;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 104 */     int l = -1;
/*     */     
/* 106 */     if (isReadAllowed()) {
/* 107 */       l = super.read(b, off, len);
/* 108 */       checkClose(l);
/*     */     }
/*     */     
/* 111 */     return l;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] b)
/*     */     throws IOException
/*     */   {
/* 123 */     int l = -1;
/*     */     
/* 125 */     if (isReadAllowed()) {
/* 126 */       l = super.read(b);
/* 127 */       checkClose(l);
/*     */     }
/* 129 */     return l;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 138 */     if (!this.selfClosed) {
/* 139 */       this.selfClosed = true;
/* 140 */       notifyWatcher();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkClose(int readResult)
/*     */     throws IOException
/*     */   {
/* 151 */     if (readResult == -1) {
/* 152 */       notifyWatcher();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isReadAllowed()
/*     */     throws IOException
/*     */   {
/* 164 */     if ((!this.streamOpen) && (this.selfClosed)) {
/* 165 */       throw new IOException("Attempted read on closed stream.");
/*     */     }
/* 167 */     return this.streamOpen;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void notifyWatcher()
/*     */     throws IOException
/*     */   {
/* 175 */     if (this.streamOpen) {
/* 176 */       super.close();
/* 177 */       this.streamOpen = false;
/*     */       
/* 179 */       if (this.watcher != null) {
/* 180 */         this.watcher.responseConsumed();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\AutoCloseInputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */