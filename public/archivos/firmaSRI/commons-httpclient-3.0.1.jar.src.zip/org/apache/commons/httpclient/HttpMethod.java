package org.apache.commons.httpclient;

import java.io.IOException;
import java.io.InputStream;
import org.apache.commons.httpclient.auth.AuthState;
import org.apache.commons.httpclient.params.HttpMethodParams;

public abstract interface HttpMethod
{
  public abstract String getName();
  
  /**
   * @deprecated
   */
  public abstract HostConfiguration getHostConfiguration();
  
  public abstract void setPath(String paramString);
  
  public abstract String getPath();
  
  public abstract URI getURI()
    throws URIException;
  
  public abstract void setURI(URI paramURI)
    throws URIException;
  
  /**
   * @deprecated
   */
  public abstract void setStrictMode(boolean paramBoolean);
  
  /**
   * @deprecated
   */
  public abstract boolean isStrictMode();
  
  public abstract void setRequestHeader(String paramString1, String paramString2);
  
  public abstract void setRequestHeader(Header paramHeader);
  
  public abstract void addRequestHeader(String paramString1, String paramString2);
  
  public abstract void addRequestHeader(Header paramHeader);
  
  public abstract Header getRequestHeader(String paramString);
  
  public abstract void removeRequestHeader(String paramString);
  
  public abstract void removeRequestHeader(Header paramHeader);
  
  public abstract boolean getFollowRedirects();
  
  public abstract void setFollowRedirects(boolean paramBoolean);
  
  public abstract void setQueryString(String paramString);
  
  public abstract void setQueryString(NameValuePair[] paramArrayOfNameValuePair);
  
  public abstract String getQueryString();
  
  public abstract Header[] getRequestHeaders();
  
  public abstract Header[] getRequestHeaders(String paramString);
  
  public abstract boolean validate();
  
  public abstract int getStatusCode();
  
  public abstract String getStatusText();
  
  public abstract Header[] getResponseHeaders();
  
  public abstract Header getResponseHeader(String paramString);
  
  public abstract Header[] getResponseHeaders(String paramString);
  
  public abstract Header[] getResponseFooters();
  
  public abstract Header getResponseFooter(String paramString);
  
  public abstract byte[] getResponseBody()
    throws IOException;
  
  public abstract String getResponseBodyAsString()
    throws IOException;
  
  public abstract InputStream getResponseBodyAsStream()
    throws IOException;
  
  public abstract boolean hasBeenUsed();
  
  public abstract int execute(HttpState paramHttpState, HttpConnection paramHttpConnection)
    throws HttpException, IOException;
  
  public abstract void abort();
  
  /**
   * @deprecated
   */
  public abstract void recycle();
  
  public abstract void releaseConnection();
  
  public abstract void addResponseFooter(Header paramHeader);
  
  public abstract StatusLine getStatusLine();
  
  public abstract boolean getDoAuthentication();
  
  public abstract void setDoAuthentication(boolean paramBoolean);
  
  public abstract HttpMethodParams getParams();
  
  public abstract void setParams(HttpMethodParams paramHttpMethodParams);
  
  public abstract AuthState getHostAuthState();
  
  public abstract AuthState getProxyAuthState();
  
  public abstract boolean isRequestSent();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\HttpMethod.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */