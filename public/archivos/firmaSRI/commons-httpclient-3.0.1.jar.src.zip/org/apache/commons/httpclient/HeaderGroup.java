/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HeaderGroup
/*     */ {
/*     */   private List headers;
/*     */   
/*     */   public HeaderGroup()
/*     */   {
/*  54 */     this.headers = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/*  61 */     this.headers.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addHeader(Header header)
/*     */   {
/*  71 */     this.headers.add(header);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeHeader(Header header)
/*     */   {
/*  80 */     this.headers.remove(header);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeaders(Header[] headers)
/*     */   {
/*  91 */     clear();
/*     */     
/*  93 */     for (int i = 0; i < headers.length; i++) {
/*  94 */       addHeader(headers[i]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Header getCondensedHeader(String name)
/*     */   {
/* 110 */     Header[] headers = getHeaders(name);
/*     */     
/* 112 */     if (headers.length == 0)
/* 113 */       return null;
/* 114 */     if (headers.length == 1) {
/* 115 */       return new Header(headers[0].getName(), headers[0].getValue());
/*     */     }
/* 117 */     StringBuffer valueBuffer = new StringBuffer(headers[0].getValue());
/*     */     
/* 119 */     for (int i = 1; i < headers.length; i++) {
/* 120 */       valueBuffer.append(", ");
/* 121 */       valueBuffer.append(headers[i].getValue());
/*     */     }
/*     */     
/* 124 */     return new Header(name.toLowerCase(), valueBuffer.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Header[] getHeaders(String name)
/*     */   {
/* 139 */     ArrayList headersFound = new ArrayList();
/*     */     
/* 141 */     for (Iterator headerIter = this.headers.iterator(); headerIter.hasNext();) {
/* 142 */       Header header = (Header)headerIter.next();
/* 143 */       if (header.getName().equalsIgnoreCase(name)) {
/* 144 */         headersFound.add(header);
/*     */       }
/*     */     }
/*     */     
/* 148 */     return (Header[])headersFound.toArray(new Header[headersFound.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Header getFirstHeader(String name)
/*     */   {
/* 160 */     for (Iterator headerIter = this.headers.iterator(); headerIter.hasNext();) {
/* 161 */       Header header = (Header)headerIter.next();
/* 162 */       if (header.getName().equalsIgnoreCase(name)) {
/* 163 */         return header;
/*     */       }
/*     */     }
/*     */     
/* 167 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Header getLastHeader(String name)
/*     */   {
/* 180 */     for (int i = this.headers.size() - 1; i >= 0; i--) {
/* 181 */       Header header = (Header)this.headers.get(i);
/* 182 */       if (header.getName().equalsIgnoreCase(name)) {
/* 183 */         return header;
/*     */       }
/*     */     }
/*     */     
/* 187 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Header[] getAllHeaders()
/*     */   {
/* 196 */     return (Header[])this.headers.toArray(new Header[this.headers.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsHeader(String name)
/*     */   {
/* 209 */     for (Iterator headerIter = this.headers.iterator(); headerIter.hasNext();) {
/* 210 */       Header header = (Header)headerIter.next();
/* 211 */       if (header.getName().equalsIgnoreCase(name)) {
/* 212 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 216 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator getIterator()
/*     */   {
/* 227 */     return this.headers.iterator();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\HeaderGroup.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */