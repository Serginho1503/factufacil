/*    */ package org.apache.commons.httpclient.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LangUtils
/*    */ {
/*    */   public static final int HASH_SEED = 17;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static final int HASH_OFFSET = 37;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static int hashCode(int seed, int hashcode)
/*    */   {
/* 50 */     return seed * 37 + hashcode;
/*    */   }
/*    */   
/*    */   public static int hashCode(int seed, Object obj) {
/* 54 */     return hashCode(seed, obj != null ? obj.hashCode() : 0);
/*    */   }
/*    */   
/*    */   public static int hashCode(int seed, boolean b) {
/* 58 */     return hashCode(seed, b ? 1 : 0);
/*    */   }
/*    */   
/*    */   public static boolean equals(Object obj1, Object obj2) {
/* 62 */     return obj1 == null ? false : obj2 == null ? true : obj1.equals(obj2);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\util\LangUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */