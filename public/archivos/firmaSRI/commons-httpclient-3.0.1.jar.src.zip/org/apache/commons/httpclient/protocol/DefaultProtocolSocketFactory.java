/*     */ package org.apache.commons.httpclient.protocol;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.UnknownHostException;
/*     */ import org.apache.commons.httpclient.ConnectTimeoutException;
/*     */ import org.apache.commons.httpclient.params.HttpConnectionParams;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultProtocolSocketFactory
/*     */   implements ProtocolSocketFactory
/*     */ {
/*  53 */   private static final DefaultProtocolSocketFactory factory = new DefaultProtocolSocketFactory();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static DefaultProtocolSocketFactory getSocketFactory()
/*     */   {
/*  60 */     return factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Socket createSocket(String host, int port, InetAddress localAddress, int localPort)
/*     */     throws IOException, UnknownHostException
/*     */   {
/*  79 */     return new Socket(host, port, localAddress, localPort);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Socket createSocket(String host, int port, InetAddress localAddress, int localPort, HttpConnectionParams params)
/*     */     throws IOException, UnknownHostException, ConnectTimeoutException
/*     */   {
/* 116 */     if (params == null) {
/* 117 */       throw new IllegalArgumentException("Parameters may not be null");
/*     */     }
/* 119 */     int timeout = params.getConnectionTimeout();
/* 120 */     if (timeout == 0) {
/* 121 */       return createSocket(host, port, localAddress, localPort);
/*     */     }
/*     */     
/* 124 */     Socket socket = ReflectionSocketFactory.createSocket("javax.net.SocketFactory", host, port, localAddress, localPort, timeout);
/*     */     
/* 126 */     if (socket == null) {
/* 127 */       socket = ControllerThreadSocketFactory.createSocket(this, host, port, localAddress, localPort, timeout);
/*     */     }
/*     */     
/* 130 */     return socket;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Socket createSocket(String host, int port)
/*     */     throws IOException, UnknownHostException
/*     */   {
/* 139 */     return new Socket(host, port);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 146 */     return (obj != null) && (obj.getClass().equals(DefaultProtocolSocketFactory.class));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 153 */     return DefaultProtocolSocketFactory.class.hashCode();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\protocol\DefaultProtocolSocketFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */