/*      */ package org.apache.commons.httpclient;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InterruptedIOException;
/*      */ import java.io.OutputStream;
/*      */ import java.lang.reflect.Method;
/*      */ import java.net.InetAddress;
/*      */ import java.net.Socket;
/*      */ import java.net.SocketException;
/*      */ import org.apache.commons.httpclient.params.HttpConnectionParams;
/*      */ import org.apache.commons.httpclient.protocol.Protocol;
/*      */ import org.apache.commons.httpclient.protocol.ProtocolSocketFactory;
/*      */ import org.apache.commons.httpclient.protocol.SecureProtocolSocketFactory;
/*      */ import org.apache.commons.httpclient.util.EncodingUtil;
/*      */ import org.apache.commons.httpclient.util.ExceptionUtil;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HttpConnection
/*      */ {
/*      */   public HttpConnection(String host, int port)
/*      */   {
/*  103 */     this(null, -1, host, null, port, Protocol.getProtocol("http"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpConnection(String host, int port, Protocol protocol)
/*      */   {
/*  115 */     this(null, -1, host, null, port, protocol);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpConnection(String host, String virtualHost, int port, Protocol protocol)
/*      */   {
/*  128 */     this(null, -1, host, virtualHost, port, protocol);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpConnection(String proxyHost, int proxyPort, String host, int port)
/*      */   {
/*  145 */     this(proxyHost, proxyPort, host, null, port, Protocol.getProtocol("http"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpConnection(HostConfiguration hostConfiguration)
/*      */   {
/*  154 */     this(hostConfiguration.getProxyHost(), hostConfiguration.getProxyPort(), hostConfiguration.getHost(), hostConfiguration.getPort(), hostConfiguration.getProtocol());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  159 */     this.localAddress = hostConfiguration.getLocalAddress();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public HttpConnection(String proxyHost, int proxyPort, String host, String virtualHost, int port, Protocol protocol)
/*      */   {
/*  183 */     this(proxyHost, proxyPort, host, port, protocol);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpConnection(String proxyHost, int proxyPort, String host, int port, Protocol protocol)
/*      */   {
/*  204 */     if (host == null) {
/*  205 */       throw new IllegalArgumentException("host parameter is null");
/*      */     }
/*  207 */     if (protocol == null) {
/*  208 */       throw new IllegalArgumentException("protocol is null");
/*      */     }
/*      */     
/*  211 */     this.proxyHostName = proxyHost;
/*  212 */     this.proxyPortNumber = proxyPort;
/*  213 */     this.hostName = host;
/*  214 */     this.portNumber = protocol.resolvePort(port);
/*  215 */     this.protocolInUse = protocol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Socket getSocket()
/*      */   {
/*  228 */     return this.socket;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getHost()
/*      */   {
/*  237 */     return this.hostName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHost(String host)
/*      */     throws IllegalStateException
/*      */   {
/*  247 */     if (host == null) {
/*  248 */       throw new IllegalArgumentException("host parameter is null");
/*      */     }
/*  250 */     assertNotOpen();
/*  251 */     this.hostName = host;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public String getVirtualHost()
/*      */   {
/*  263 */     return this.hostName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setVirtualHost(String host)
/*      */     throws IllegalStateException
/*      */   {
/*  280 */     assertNotOpen();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getPort()
/*      */   {
/*  292 */     if (this.portNumber < 0) {
/*  293 */       return isSecure() ? 443 : 80;
/*      */     }
/*  295 */     return this.portNumber;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPort(int port)
/*      */     throws IllegalStateException
/*      */   {
/*  307 */     assertNotOpen();
/*  308 */     this.portNumber = port;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProxyHost()
/*      */   {
/*  317 */     return this.proxyHostName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProxyHost(String host)
/*      */     throws IllegalStateException
/*      */   {
/*  328 */     assertNotOpen();
/*  329 */     this.proxyHostName = host;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getProxyPort()
/*      */   {
/*  338 */     return this.proxyPortNumber;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProxyPort(int port)
/*      */     throws IllegalStateException
/*      */   {
/*  349 */     assertNotOpen();
/*  350 */     this.proxyPortNumber = port;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isSecure()
/*      */   {
/*  360 */     return this.protocolInUse.isSecure();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Protocol getProtocol()
/*      */   {
/*  368 */     return this.protocolInUse;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProtocol(Protocol protocol)
/*      */   {
/*  379 */     assertNotOpen();
/*      */     
/*  381 */     if (protocol == null) {
/*  382 */       throw new IllegalArgumentException("protocol is null");
/*      */     }
/*      */     
/*  385 */     this.protocolInUse = protocol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InetAddress getLocalAddress()
/*      */   {
/*  396 */     return this.localAddress;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLocalAddress(InetAddress localAddress)
/*      */   {
/*  406 */     assertNotOpen();
/*  407 */     this.localAddress = localAddress;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isOpen()
/*      */   {
/*  416 */     return this.isOpen;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean closeIfStale()
/*      */     throws IOException
/*      */   {
/*  430 */     if ((this.isOpen) && (isStale())) {
/*  431 */       LOG.debug("Connection is stale, closing...");
/*  432 */       close();
/*  433 */       return true;
/*      */     }
/*  435 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public boolean isStaleCheckingEnabled()
/*      */   {
/*  449 */     return this.params.isStaleCheckingEnabled();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setStaleCheckingEnabled(boolean staleCheckEnabled)
/*      */   {
/*  469 */     this.params.setStaleCheckingEnabled(staleCheckEnabled);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isStale()
/*      */     throws IOException
/*      */   {
/*  495 */     boolean isStale = true;
/*  496 */     if (this.isOpen)
/*      */     {
/*      */ 
/*  499 */       isStale = false;
/*      */       try {
/*  501 */         if (this.inputStream.available() <= 0) {
/*      */           try {
/*  503 */             this.socket.setSoTimeout(1);
/*  504 */             this.inputStream.mark(1);
/*  505 */             int byteRead = this.inputStream.read();
/*  506 */             if (byteRead == -1)
/*      */             {
/*      */ 
/*  509 */               isStale = true;
/*      */             } else {
/*  511 */               this.inputStream.reset();
/*      */             }
/*      */           } finally {
/*  514 */             this.socket.setSoTimeout(this.params.getSoTimeout());
/*      */           }
/*      */         }
/*      */       } catch (InterruptedIOException e) {
/*  518 */         if (!ExceptionUtil.isSocketTimeoutException(e)) {
/*  519 */           throw e;
/*      */         }
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/*  524 */         LOG.debug("An error occurred while reading from the socket, is appears to be stale", e);
/*      */         
/*      */ 
/*      */ 
/*  528 */         isStale = true;
/*      */       }
/*      */     }
/*      */     
/*  532 */     return isStale;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isProxied()
/*      */   {
/*  543 */     return (null != this.proxyHostName) && (0 < this.proxyPortNumber);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLastResponseInputStream(InputStream inStream)
/*      */   {
/*  557 */     this.lastResponseInputStream = inStream;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getLastResponseInputStream()
/*      */   {
/*  574 */     return this.lastResponseInputStream;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpConnectionParams getParams()
/*      */   {
/*  587 */     return this.params;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setParams(HttpConnectionParams params)
/*      */   {
/*  598 */     if (params == null) {
/*  599 */       throw new IllegalArgumentException("Parameters may not be null");
/*      */     }
/*  601 */     this.params = params;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setSoTimeout(int timeout)
/*      */     throws SocketException, IllegalStateException
/*      */   {
/*  620 */     this.params.setSoTimeout(timeout);
/*  621 */     if (this.socket != null) {
/*  622 */       this.socket.setSoTimeout(timeout);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSocketTimeout(int timeout)
/*      */     throws SocketException, IllegalStateException
/*      */   {
/*  640 */     assertOpen();
/*  641 */     if (this.socket != null) {
/*  642 */       this.socket.setSoTimeout(timeout);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public int getSoTimeout()
/*      */     throws SocketException
/*      */   {
/*  659 */     return this.params.getSoTimeout();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setConnectionTimeout(int timeout)
/*      */   {
/*  672 */     this.params.setConnectionTimeout(timeout);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void open()
/*      */     throws IOException
/*      */   {
/*  684 */     LOG.trace("enter HttpConnection.open()");
/*      */     
/*  686 */     String host = this.proxyHostName == null ? this.hostName : this.proxyHostName;
/*  687 */     int port = this.proxyHostName == null ? this.portNumber : this.proxyPortNumber;
/*  688 */     assertNotOpen();
/*      */     
/*  690 */     if (LOG.isDebugEnabled()) {
/*  691 */       LOG.debug("Open connection to " + host + ":" + port);
/*      */     }
/*      */     try
/*      */     {
/*  695 */       if (this.socket == null) {
/*  696 */         this.usingSecureSocket = ((isSecure()) && (!isProxied()));
/*      */         
/*      */ 
/*  699 */         ProtocolSocketFactory socketFactory = null;
/*  700 */         if ((isSecure()) && (isProxied())) {
/*  701 */           Protocol defaultprotocol = Protocol.getProtocol("http");
/*  702 */           socketFactory = defaultprotocol.getSocketFactory();
/*      */         } else {
/*  704 */           socketFactory = this.protocolInUse.getSocketFactory();
/*      */         }
/*  706 */         this.socket = socketFactory.createSocket(host, port, this.localAddress, 0, this.params);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  720 */       this.socket.setTcpNoDelay(this.params.getTcpNoDelay());
/*  721 */       this.socket.setSoTimeout(this.params.getSoTimeout());
/*      */       
/*  723 */       int linger = this.params.getLinger();
/*  724 */       if (linger >= 0) {
/*  725 */         this.socket.setSoLinger(linger > 0, linger);
/*      */       }
/*      */       
/*  728 */       int sndBufSize = this.params.getSendBufferSize();
/*  729 */       if (sndBufSize >= 0) {
/*  730 */         this.socket.setSendBufferSize(sndBufSize);
/*      */       }
/*  732 */       int rcvBufSize = this.params.getReceiveBufferSize();
/*  733 */       if (rcvBufSize >= 0) {
/*  734 */         this.socket.setReceiveBufferSize(rcvBufSize);
/*      */       }
/*  736 */       int outbuffersize = this.socket.getSendBufferSize();
/*  737 */       if ((outbuffersize > 2048) || (outbuffersize <= 0)) {
/*  738 */         outbuffersize = 2048;
/*      */       }
/*  740 */       int inbuffersize = this.socket.getReceiveBufferSize();
/*  741 */       if ((inbuffersize > 2048) || (inbuffersize <= 0)) {
/*  742 */         inbuffersize = 2048;
/*      */       }
/*  744 */       this.inputStream = new BufferedInputStream(this.socket.getInputStream(), inbuffersize);
/*  745 */       this.outputStream = new BufferedOutputStream(this.socket.getOutputStream(), outbuffersize);
/*  746 */       this.isOpen = true;
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/*  750 */       closeSocketAndStreams();
/*  751 */       throw e;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void tunnelCreated()
/*      */     throws IllegalStateException, IOException
/*      */   {
/*  766 */     LOG.trace("enter HttpConnection.tunnelCreated()");
/*      */     
/*  768 */     if ((!isSecure()) || (!isProxied())) {
/*  769 */       throw new IllegalStateException("Connection must be secure and proxied to use this feature");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  774 */     if (this.usingSecureSocket) {
/*  775 */       throw new IllegalStateException("Already using a secure socket");
/*      */     }
/*      */     
/*  778 */     if (LOG.isDebugEnabled()) {
/*  779 */       LOG.debug("Secure tunnel to " + this.hostName + ":" + this.portNumber);
/*      */     }
/*      */     
/*  782 */     SecureProtocolSocketFactory socketFactory = (SecureProtocolSocketFactory)this.protocolInUse.getSocketFactory();
/*      */     
/*      */ 
/*  785 */     this.socket = socketFactory.createSocket(this.socket, this.hostName, this.portNumber, true);
/*  786 */     int sndBufSize = this.params.getSendBufferSize();
/*  787 */     if (sndBufSize >= 0) {
/*  788 */       this.socket.setSendBufferSize(sndBufSize);
/*      */     }
/*  790 */     int rcvBufSize = this.params.getReceiveBufferSize();
/*  791 */     if (rcvBufSize >= 0) {
/*  792 */       this.socket.setReceiveBufferSize(rcvBufSize);
/*      */     }
/*  794 */     int outbuffersize = this.socket.getSendBufferSize();
/*  795 */     if (outbuffersize > 2048) {
/*  796 */       outbuffersize = 2048;
/*      */     }
/*  798 */     int inbuffersize = this.socket.getReceiveBufferSize();
/*  799 */     if (inbuffersize > 2048) {
/*  800 */       inbuffersize = 2048;
/*      */     }
/*  802 */     this.inputStream = new BufferedInputStream(this.socket.getInputStream(), inbuffersize);
/*  803 */     this.outputStream = new BufferedOutputStream(this.socket.getOutputStream(), outbuffersize);
/*  804 */     this.usingSecureSocket = true;
/*  805 */     this.tunnelEstablished = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isTransparent()
/*      */   {
/*  815 */     return (!isProxied()) || (this.tunnelEstablished);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void flushRequestOutputStream()
/*      */     throws IOException
/*      */   {
/*  825 */     LOG.trace("enter HttpConnection.flushRequestOutputStream()");
/*  826 */     assertOpen();
/*  827 */     this.outputStream.flush();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public OutputStream getRequestOutputStream()
/*      */     throws IOException, IllegalStateException
/*      */   {
/*  839 */     LOG.trace("enter HttpConnection.getRequestOutputStream()");
/*  840 */     assertOpen();
/*  841 */     OutputStream out = this.outputStream;
/*  842 */     if (Wire.CONTENT_WIRE.enabled()) {
/*  843 */       out = new WireLogOutputStream(out, Wire.CONTENT_WIRE);
/*      */     }
/*  845 */     return out;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getResponseInputStream()
/*      */     throws IOException, IllegalStateException
/*      */   {
/*  856 */     LOG.trace("enter HttpConnection.getResponseInputStream()");
/*  857 */     assertOpen();
/*  858 */     return this.inputStream;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isResponseAvailable()
/*      */     throws IOException
/*      */   {
/*  873 */     LOG.trace("enter HttpConnection.isResponseAvailable()");
/*  874 */     if (this.isOpen) {
/*  875 */       return this.inputStream.available() > 0;
/*      */     }
/*  877 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isResponseAvailable(int timeout)
/*      */     throws IOException
/*      */   {
/*  893 */     LOG.trace("enter HttpConnection.isResponseAvailable(int)");
/*  894 */     assertOpen();
/*  895 */     boolean result = false;
/*  896 */     if (this.inputStream.available() > 0) {
/*  897 */       result = true;
/*      */     } else {
/*      */       try {
/*  900 */         this.socket.setSoTimeout(timeout);
/*  901 */         this.inputStream.mark(1);
/*  902 */         int byteRead = this.inputStream.read();
/*  903 */         if (byteRead != -1) {
/*  904 */           this.inputStream.reset();
/*  905 */           LOG.debug("Input data available");
/*  906 */           result = true;
/*      */         } else {
/*  908 */           LOG.debug("Input data not available");
/*      */         }
/*      */       } catch (InterruptedIOException e) {
/*  911 */         if (!ExceptionUtil.isSocketTimeoutException(e)) {
/*  912 */           throw e;
/*      */         }
/*  914 */         if (LOG.isDebugEnabled()) {
/*  915 */           LOG.debug("Input data not available after " + timeout + " ms");
/*      */         }
/*      */       } finally {
/*      */         try {
/*  919 */           this.socket.setSoTimeout(this.params.getSoTimeout());
/*      */         } catch (IOException ioe) {
/*  921 */           LOG.debug("An error ocurred while resetting soTimeout, we will assume that no response is available.", ioe);
/*      */           
/*      */ 
/*  924 */           result = false;
/*      */         }
/*      */       }
/*      */     }
/*  928 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void write(byte[] data)
/*      */     throws IOException, IllegalStateException
/*      */   {
/*  941 */     LOG.trace("enter HttpConnection.write(byte[])");
/*  942 */     write(data, 0, data.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void write(byte[] data, int offset, int length)
/*      */     throws IOException, IllegalStateException
/*      */   {
/*  962 */     LOG.trace("enter HttpConnection.write(byte[], int, int)");
/*      */     
/*  964 */     if (offset < 0) {
/*  965 */       throw new IllegalArgumentException("Array offset may not be negative");
/*      */     }
/*  967 */     if (length < 0) {
/*  968 */       throw new IllegalArgumentException("Array length may not be negative");
/*      */     }
/*  970 */     if (offset + length > data.length) {
/*  971 */       throw new IllegalArgumentException("Given offset and length exceed the array length");
/*      */     }
/*  973 */     assertOpen();
/*  974 */     this.outputStream.write(data, offset, length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeLine(byte[] data)
/*      */     throws IOException, IllegalStateException
/*      */   {
/*  987 */     LOG.trace("enter HttpConnection.writeLine(byte[])");
/*  988 */     write(data);
/*  989 */     writeLine();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeLine()
/*      */     throws IOException, IllegalStateException
/*      */   {
/* 1000 */     LOG.trace("enter HttpConnection.writeLine()");
/* 1001 */     write(CRLF);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void print(String data)
/*      */     throws IOException, IllegalStateException
/*      */   {
/* 1015 */     LOG.trace("enter HttpConnection.print(String)");
/* 1016 */     write(EncodingUtil.getBytes(data, "ISO-8859-1"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void print(String data, String charset)
/*      */     throws IOException, IllegalStateException
/*      */   {
/* 1031 */     LOG.trace("enter HttpConnection.print(String)");
/* 1032 */     write(EncodingUtil.getBytes(data, charset));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void printLine(String data)
/*      */     throws IOException, IllegalStateException
/*      */   {
/* 1047 */     LOG.trace("enter HttpConnection.printLine(String)");
/* 1048 */     writeLine(EncodingUtil.getBytes(data, "ISO-8859-1"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void printLine(String data, String charset)
/*      */     throws IOException, IllegalStateException
/*      */   {
/* 1064 */     LOG.trace("enter HttpConnection.printLine(String)");
/* 1065 */     writeLine(EncodingUtil.getBytes(data, charset));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void printLine()
/*      */     throws IOException, IllegalStateException
/*      */   {
/* 1076 */     LOG.trace("enter HttpConnection.printLine()");
/* 1077 */     writeLine();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public String readLine()
/*      */     throws IOException, IllegalStateException
/*      */   {
/* 1092 */     LOG.trace("enter HttpConnection.readLine()");
/*      */     
/* 1094 */     assertOpen();
/* 1095 */     return HttpParser.readLine(this.inputStream);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String readLine(String charset)
/*      */     throws IOException, IllegalStateException
/*      */   {
/* 1112 */     LOG.trace("enter HttpConnection.readLine()");
/*      */     
/* 1114 */     assertOpen();
/* 1115 */     return HttpParser.readLine(this.inputStream, charset);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void shutdownOutput()
/*      */   {
/* 1125 */     LOG.trace("enter HttpConnection.shutdownOutput()");
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 1131 */       Class[] paramsClasses = new Class[0];
/* 1132 */       Method shutdownOutput = this.socket.getClass().getMethod("shutdownOutput", paramsClasses);
/*      */       
/* 1134 */       Object[] params = new Object[0];
/* 1135 */       shutdownOutput.invoke(this.socket, params);
/*      */     } catch (Exception ex) {
/* 1137 */       LOG.debug("Unexpected Exception caught", ex);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */   {
/* 1147 */     LOG.trace("enter HttpConnection.close()");
/* 1148 */     closeSocketAndStreams();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpConnectionManager getHttpConnectionManager()
/*      */   {
/* 1156 */     return this.httpConnectionManager;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHttpConnectionManager(HttpConnectionManager httpConnectionManager)
/*      */   {
/* 1164 */     this.httpConnectionManager = httpConnectionManager;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void releaseConnection()
/*      */   {
/* 1173 */     LOG.trace("enter HttpConnection.releaseConnection()");
/* 1174 */     if (this.locked) {
/* 1175 */       LOG.debug("Connection is locked.  Call to releaseConnection() ignored.");
/* 1176 */     } else if (this.httpConnectionManager != null) {
/* 1177 */       LOG.debug("Releasing connection back to connection manager.");
/* 1178 */       this.httpConnectionManager.releaseConnection(this);
/*      */     } else {
/* 1180 */       LOG.warn("HttpConnectionManager is null.  Connection cannot be released.");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isLocked()
/*      */   {
/* 1193 */     return this.locked;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setLocked(boolean locked)
/*      */   {
/* 1206 */     this.locked = locked;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void closeSocketAndStreams()
/*      */   {
/* 1214 */     LOG.trace("enter HttpConnection.closeSockedAndStreams()");
/*      */     
/* 1216 */     this.isOpen = false;
/*      */     
/*      */ 
/* 1219 */     this.lastResponseInputStream = null;
/*      */     
/* 1221 */     if (null != this.outputStream) {
/* 1222 */       OutputStream temp = this.outputStream;
/* 1223 */       this.outputStream = null;
/*      */       try {
/* 1225 */         temp.close();
/*      */       } catch (Exception ex) {
/* 1227 */         LOG.debug("Exception caught when closing output", ex);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1232 */     if (null != this.inputStream) {
/* 1233 */       InputStream temp = this.inputStream;
/* 1234 */       this.inputStream = null;
/*      */       try {
/* 1236 */         temp.close();
/*      */       } catch (Exception ex) {
/* 1238 */         LOG.debug("Exception caught when closing input", ex);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1243 */     if (null != this.socket) {
/* 1244 */       Socket temp = this.socket;
/* 1245 */       this.socket = null;
/*      */       try {
/* 1247 */         temp.close();
/*      */       } catch (Exception ex) {
/* 1249 */         LOG.debug("Exception caught when closing socket", ex);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1254 */     this.tunnelEstablished = false;
/* 1255 */     this.usingSecureSocket = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void assertNotOpen()
/*      */     throws IllegalStateException
/*      */   {
/* 1264 */     if (this.isOpen) {
/* 1265 */       throw new IllegalStateException("Connection is open");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void assertOpen()
/*      */     throws IllegalStateException
/*      */   {
/* 1275 */     if (!this.isOpen) {
/* 1276 */       throw new IllegalStateException("Connection is not open");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSendBufferSize()
/*      */     throws SocketException
/*      */   {
/* 1291 */     if (this.socket == null) {
/* 1292 */       return -1;
/*      */     }
/* 1294 */     return this.socket.getSendBufferSize();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setSendBufferSize(int sendBufferSize)
/*      */     throws SocketException
/*      */   {
/* 1311 */     this.params.setSendBufferSize(sendBufferSize);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1317 */   private static final byte[] CRLF = { 13, 10 };
/*      */   
/*      */ 
/* 1320 */   private static final Log LOG = LogFactory.getLog(HttpConnection.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1325 */   private String hostName = null;
/*      */   
/*      */ 
/* 1328 */   private int portNumber = -1;
/*      */   
/*      */ 
/* 1331 */   private String proxyHostName = null;
/*      */   
/*      */ 
/* 1334 */   private int proxyPortNumber = -1;
/*      */   
/*      */ 
/* 1337 */   private Socket socket = null;
/*      */   
/*      */ 
/* 1340 */   private InputStream inputStream = null;
/*      */   
/*      */ 
/* 1343 */   private OutputStream outputStream = null;
/*      */   
/*      */ 
/* 1346 */   private InputStream lastResponseInputStream = null;
/*      */   
/*      */ 
/* 1349 */   protected boolean isOpen = false;
/*      */   
/*      */ 
/*      */   private Protocol protocolInUse;
/*      */   
/*      */ 
/* 1355 */   private HttpConnectionParams params = new HttpConnectionParams();
/*      */   
/*      */ 
/*      */ 
/* 1359 */   private boolean locked = false;
/*      */   
/*      */ 
/* 1362 */   private boolean usingSecureSocket = false;
/*      */   
/*      */ 
/* 1365 */   private boolean tunnelEstablished = false;
/*      */   private HttpConnectionManager httpConnectionManager;
/*      */   private InetAddress localAddress;
/*      */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\HttpConnection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */