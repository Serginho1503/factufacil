/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.text.Collator;
/*     */ import java.text.RuleBasedCollator;
/*     */ import java.util.Comparator;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.httpclient.cookie.CookiePolicy;
/*     */ import org.apache.commons.httpclient.cookie.CookieSpec;
/*     */ import org.apache.commons.httpclient.util.LangUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Cookie
/*     */   extends NameValuePair
/*     */   implements Serializable, Comparator
/*     */ {
/*     */   private String cookieComment;
/*     */   private String cookieDomain;
/*     */   private Date cookieExpiryDate;
/*     */   private String cookiePath;
/*     */   private boolean isSecure;
/*     */   
/*     */   public Cookie()
/*     */   {
/*  73 */     this(null, "noname", null, null, null, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cookie(String domain, String name, String value)
/*     */   {
/*  84 */     this(domain, name, value, null, null, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cookie(String domain, String name, String value, String path, Date expires, boolean secure)
/*     */   {
/* 107 */     super(name, value);
/* 108 */     LOG.trace("enter Cookie(String, String, String, String, Date, boolean)");
/* 109 */     if (name == null) {
/* 110 */       throw new IllegalArgumentException("Cookie name may not be null");
/*     */     }
/* 112 */     if (name.trim().equals("")) {
/* 113 */       throw new IllegalArgumentException("Cookie name may not be blank");
/*     */     }
/* 115 */     setPath(path);
/* 116 */     setDomain(domain);
/* 117 */     setExpiryDate(expires);
/* 118 */     setSecure(secure);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cookie(String domain, String name, String value, String path, int maxAge, boolean secure)
/*     */   {
/* 138 */     this(domain, name, value, path, null, secure);
/* 139 */     if (maxAge < -1) {
/* 140 */       throw new IllegalArgumentException("Invalid max age:  " + Integer.toString(maxAge));
/*     */     }
/* 142 */     if (maxAge >= 0) {
/* 143 */       setExpiryDate(new Date(System.currentTimeMillis() + maxAge * 1000L));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getComment()
/*     */   {
/* 156 */     return this.cookieComment;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setComment(String comment)
/*     */   {
/* 168 */     this.cookieComment = comment;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getExpiryDate()
/*     */   {
/* 183 */     return this.cookieExpiryDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExpiryDate(Date expiryDate)
/*     */   {
/* 198 */     this.cookieExpiryDate = expiryDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPersistent()
/*     */   {
/* 210 */     return null != this.cookieExpiryDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDomain()
/*     */   {
/* 222 */     return this.cookieDomain;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDomain(String domain)
/*     */   {
/* 233 */     if (domain != null) {
/* 234 */       int ndx = domain.indexOf(":");
/* 235 */       if (ndx != -1) {
/* 236 */         domain = domain.substring(0, ndx);
/*     */       }
/* 238 */       this.cookieDomain = domain.toLowerCase();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPath()
/*     */   {
/* 251 */     return this.cookiePath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPath(String path)
/*     */   {
/* 263 */     this.cookiePath = path;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getSecure()
/*     */   {
/* 271 */     return this.isSecure;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSecure(boolean secure)
/*     */   {
/* 287 */     this.isSecure = secure;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getVersion()
/*     */   {
/* 300 */     return this.cookieVersion;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVersion(int version)
/*     */   {
/* 312 */     this.cookieVersion = version;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isExpired()
/*     */   {
/* 321 */     return (this.cookieExpiryDate != null) && (this.cookieExpiryDate.getTime() <= System.currentTimeMillis());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isExpired(Date now)
/*     */   {
/* 333 */     return (this.cookieExpiryDate != null) && (this.cookieExpiryDate.getTime() <= now.getTime());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPathAttributeSpecified(boolean value)
/*     */   {
/* 352 */     this.hasPathAttribute = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPathAttributeSpecified()
/*     */   {
/* 365 */     return this.hasPathAttribute;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDomainAttributeSpecified(boolean value)
/*     */   {
/* 382 */     this.hasDomainAttribute = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDomainAttributeSpecified()
/*     */   {
/* 395 */     return this.hasDomainAttribute;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 404 */     int hash = 17;
/* 405 */     hash = LangUtils.hashCode(hash, getName());
/* 406 */     hash = LangUtils.hashCode(hash, this.cookieDomain);
/* 407 */     hash = LangUtils.hashCode(hash, this.cookiePath);
/* 408 */     return hash;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 418 */     if (obj == null) return false;
/* 419 */     if (this == obj) return true;
/* 420 */     if ((obj instanceof Cookie)) {
/* 421 */       Cookie that = (Cookie)obj;
/* 422 */       return (LangUtils.equals(getName(), that.getName())) && (LangUtils.equals(this.cookieDomain, that.cookieDomain)) && (LangUtils.equals(this.cookiePath, that.cookiePath));
/*     */     }
/*     */     
/*     */ 
/* 426 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toExternalForm()
/*     */   {
/* 437 */     CookieSpec spec = null;
/* 438 */     if (getVersion() > 0) {
/* 439 */       spec = CookiePolicy.getDefaultSpec();
/*     */     } else {
/* 441 */       spec = CookiePolicy.getCookieSpec("netscape");
/*     */     }
/* 443 */     return spec.formatCookie(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int compare(Object o1, Object o2)
/*     */   {
/* 457 */     LOG.trace("enter Cookie.compare(Object, Object)");
/*     */     
/* 459 */     if (!(o1 instanceof Cookie)) {
/* 460 */       throw new ClassCastException(o1.getClass().getName());
/*     */     }
/* 462 */     if (!(o2 instanceof Cookie)) {
/* 463 */       throw new ClassCastException(o2.getClass().getName());
/*     */     }
/* 465 */     Cookie c1 = (Cookie)o1;
/* 466 */     Cookie c2 = (Cookie)o2;
/* 467 */     if ((c1.getPath() == null) && (c2.getPath() == null))
/* 468 */       return 0;
/* 469 */     if (c1.getPath() == null)
/*     */     {
/* 471 */       if (c2.getPath().equals("/")) {
/* 472 */         return 0;
/*     */       }
/* 474 */       return -1;
/*     */     }
/* 476 */     if (c2.getPath() == null)
/*     */     {
/* 478 */       if (c1.getPath().equals("/")) {
/* 479 */         return 0;
/*     */       }
/* 481 */       return 1;
/*     */     }
/*     */     
/* 484 */     return STRING_COLLATOR.compare(c1.getPath(), c2.getPath());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 496 */     return toExternalForm();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 520 */   private boolean hasPathAttribute = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 526 */   private boolean hasDomainAttribute = false;
/*     */   
/*     */ 
/* 529 */   private int cookieVersion = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 537 */   private static final RuleBasedCollator STRING_COLLATOR = (RuleBasedCollator)Collator.getInstance(new Locale("en", "US", ""));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 542 */   private static final Log LOG = LogFactory.getLog(Cookie.class);
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\Cookie.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */