/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.httpclient.auth.AuthChallengeException;
/*     */ import org.apache.commons.httpclient.auth.AuthChallengeParser;
/*     */ import org.apache.commons.httpclient.auth.AuthChallengeProcessor;
/*     */ import org.apache.commons.httpclient.auth.AuthScheme;
/*     */ import org.apache.commons.httpclient.auth.AuthScope;
/*     */ import org.apache.commons.httpclient.auth.AuthState;
/*     */ import org.apache.commons.httpclient.auth.AuthenticationException;
/*     */ import org.apache.commons.httpclient.auth.CredentialsNotAvailableException;
/*     */ import org.apache.commons.httpclient.auth.CredentialsProvider;
/*     */ import org.apache.commons.httpclient.auth.MalformedChallengeException;
/*     */ import org.apache.commons.httpclient.params.DefaultHttpParams;
/*     */ import org.apache.commons.httpclient.params.HttpClientParams;
/*     */ import org.apache.commons.httpclient.params.HttpConnectionParams;
/*     */ import org.apache.commons.httpclient.params.HttpMethodParams;
/*     */ import org.apache.commons.httpclient.params.HttpParams;
/*     */ import org.apache.commons.httpclient.protocol.Protocol;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HttpMethodDirector
/*     */ {
/*     */   public static final String WWW_AUTH_CHALLENGE = "WWW-Authenticate";
/*     */   public static final String WWW_AUTH_RESP = "Authorization";
/*     */   public static final String PROXY_AUTH_CHALLENGE = "Proxy-Authenticate";
/*     */   public static final String PROXY_AUTH_RESP = "Proxy-Authorization";
/*  76 */   private static final Log LOG = LogFactory.getLog(HttpMethodDirector.class);
/*     */   
/*     */ 
/*     */   private ConnectMethod connectMethod;
/*     */   
/*     */   private HttpState state;
/*     */   
/*     */   private HostConfiguration hostConfiguration;
/*     */   
/*     */   private HttpConnectionManager connectionManager;
/*     */   
/*     */   private HttpClientParams params;
/*     */   
/*     */   private HttpConnection conn;
/*     */   
/*  91 */   private boolean releaseConnection = false;
/*     */   
/*     */ 
/*  94 */   private AuthChallengeProcessor authProcessor = null;
/*     */   
/*  96 */   private Set redirectLocations = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpMethodDirector(HttpConnectionManager connectionManager, HostConfiguration hostConfiguration, HttpClientParams params, HttpState state)
/*     */   {
/* 105 */     this.connectionManager = connectionManager;
/* 106 */     this.hostConfiguration = hostConfiguration;
/* 107 */     this.params = params;
/* 108 */     this.state = state;
/* 109 */     this.authProcessor = new AuthChallengeProcessor(this.params);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeMethod(HttpMethod method)
/*     */     throws IOException, HttpException
/*     */   {
/* 120 */     if (method == null) {
/* 121 */       throw new IllegalArgumentException("Method may not be null");
/*     */     }
/*     */     
/*     */ 
/* 125 */     this.hostConfiguration.getParams().setDefaults(this.params);
/* 126 */     method.getParams().setDefaults(this.hostConfiguration.getParams());
/*     */     
/*     */ 
/* 129 */     Collection defaults = (Collection)this.hostConfiguration.getParams().getParameter("http.default-headers");
/*     */     
/* 131 */     if (defaults != null) {
/* 132 */       Iterator i = defaults.iterator();
/* 133 */       while (i.hasNext()) {
/* 134 */         method.addRequestHeader((Header)i.next());
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 139 */       int maxRedirects = this.params.getIntParameter("http.protocol.max-redirects", 100);
/*     */       
/* 141 */       int redirectCount = 0;
/*     */       for (;;)
/*     */       {
/* 144 */         if ((this.conn != null) && (!this.hostConfiguration.hostEquals(this.conn))) {
/* 145 */           this.conn.setLocked(false);
/* 146 */           this.conn.releaseConnection();
/* 147 */           this.conn = null;
/*     */         }
/*     */         
/*     */ 
/* 151 */         if (this.conn == null) {
/* 152 */           this.conn = this.connectionManager.getConnectionWithTimeout(this.hostConfiguration, this.params.getConnectionManagerTimeout());
/*     */           
/*     */ 
/*     */ 
/* 156 */           this.conn.setLocked(true);
/* 157 */           if ((this.params.isAuthenticationPreemptive()) || (this.state.isAuthenticationPreemptive()))
/*     */           {
/*     */ 
/* 160 */             LOG.debug("Preemptively sending default basic credentials");
/* 161 */             method.getHostAuthState().setPreemptive();
/* 162 */             method.getHostAuthState().setAuthAttempted(true);
/* 163 */             if ((this.conn.isProxied()) && (!this.conn.isSecure())) {
/* 164 */               method.getProxyAuthState().setPreemptive();
/* 165 */               method.getProxyAuthState().setAuthAttempted(true);
/*     */             }
/*     */           }
/*     */         }
/* 169 */         authenticate(method);
/* 170 */         executeWithRetry(method);
/* 171 */         if (this.connectMethod != null) {
/* 172 */           fakeResponse(method);
/* 173 */           break;
/*     */         }
/*     */         
/* 176 */         boolean retry = false;
/* 177 */         if ((isRedirectNeeded(method)) && 
/* 178 */           (processRedirectResponse(method))) {
/* 179 */           retry = true;
/* 180 */           redirectCount++;
/* 181 */           if (redirectCount >= maxRedirects) {
/* 182 */             LOG.error("Narrowly avoided an infinite loop in execute");
/* 183 */             throw new RedirectException("Maximum redirects (" + maxRedirects + ") exceeded");
/*     */           }
/*     */           
/* 186 */           if (LOG.isDebugEnabled()) {
/* 187 */             LOG.debug("Execute redirect " + redirectCount + " of " + maxRedirects);
/*     */           }
/*     */         }
/*     */         
/* 191 */         if ((isAuthenticationNeeded(method)) && 
/* 192 */           (processAuthenticationResponse(method))) {
/* 193 */           LOG.debug("Retry authentication");
/* 194 */           retry = true;
/*     */         }
/*     */         
/* 197 */         if (!retry) {
/*     */           break;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 203 */         if (method.getResponseBodyAsStream() != null) {
/* 204 */           method.getResponseBodyAsStream().close();
/*     */         }
/*     */       }
/*     */     }
/*     */     finally {
/* 209 */       if (this.conn != null) {
/* 210 */         this.conn.setLocked(false);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 217 */       if (((this.releaseConnection) || (method.getResponseBodyAsStream() == null)) && (this.conn != null))
/*     */       {
/*     */ 
/*     */ 
/* 221 */         this.conn.releaseConnection();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void authenticate(HttpMethod method)
/*     */   {
/*     */     try
/*     */     {
/* 230 */       if ((this.conn.isProxied()) && (!this.conn.isSecure())) {
/* 231 */         authenticateProxy(method);
/*     */       }
/* 233 */       authenticateHost(method);
/*     */     } catch (AuthenticationException e) {
/* 235 */       LOG.error(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean cleanAuthHeaders(HttpMethod method, String name)
/*     */   {
/* 241 */     Header[] authheaders = method.getRequestHeaders(name);
/* 242 */     boolean clean = true;
/* 243 */     for (int i = 0; i < authheaders.length; i++) {
/* 244 */       Header authheader = authheaders[i];
/* 245 */       if (authheader.isAutogenerated()) {
/* 246 */         method.removeRequestHeader(authheader);
/*     */       } else {
/* 248 */         clean = false;
/*     */       }
/*     */     }
/* 251 */     return clean;
/*     */   }
/*     */   
/*     */   private void authenticateHost(HttpMethod method)
/*     */     throws AuthenticationException
/*     */   {
/* 257 */     if (!cleanAuthHeaders(method, "Authorization"))
/*     */     {
/* 259 */       return;
/*     */     }
/* 261 */     AuthState authstate = method.getHostAuthState();
/* 262 */     AuthScheme authscheme = authstate.getAuthScheme();
/* 263 */     if (authscheme == null) {
/* 264 */       return;
/*     */     }
/* 266 */     if ((authstate.isAuthRequested()) || (!authscheme.isConnectionBased())) {
/* 267 */       String host = method.getParams().getVirtualHost();
/* 268 */       if (host == null) {
/* 269 */         host = this.conn.getHost();
/*     */       }
/* 271 */       int port = this.conn.getPort();
/* 272 */       AuthScope authscope = new AuthScope(host, port, authscheme.getRealm(), authscheme.getSchemeName());
/*     */       
/*     */ 
/*     */ 
/* 276 */       if (LOG.isDebugEnabled()) {
/* 277 */         LOG.debug("Authenticating with " + authscope);
/*     */       }
/* 279 */       Credentials credentials = this.state.getCredentials(authscope);
/* 280 */       if (credentials != null) {
/* 281 */         String authstring = authscheme.authenticate(credentials, method);
/* 282 */         if (authstring != null) {
/* 283 */           method.addRequestHeader(new Header("Authorization", authstring, true));
/*     */         }
/*     */       }
/* 286 */       else if (LOG.isWarnEnabled()) {
/* 287 */         LOG.warn("Required credentials not available for " + authscope);
/* 288 */         if (method.getHostAuthState().isPreemptive()) {
/* 289 */           LOG.warn("Preemptive authentication requested but no default credentials available");
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void authenticateProxy(HttpMethod method)
/*     */     throws AuthenticationException
/*     */   {
/* 300 */     if (!cleanAuthHeaders(method, "Proxy-Authorization"))
/*     */     {
/* 302 */       return;
/*     */     }
/* 304 */     AuthState authstate = method.getProxyAuthState();
/* 305 */     AuthScheme authscheme = authstate.getAuthScheme();
/* 306 */     if (authscheme == null) {
/* 307 */       return;
/*     */     }
/* 309 */     if ((authstate.isAuthRequested()) || (!authscheme.isConnectionBased())) {
/* 310 */       AuthScope authscope = new AuthScope(this.conn.getProxyHost(), this.conn.getProxyPort(), authscheme.getRealm(), authscheme.getSchemeName());
/*     */       
/*     */ 
/*     */ 
/* 314 */       if (LOG.isDebugEnabled()) {
/* 315 */         LOG.debug("Authenticating with " + authscope);
/*     */       }
/* 317 */       Credentials credentials = this.state.getProxyCredentials(authscope);
/* 318 */       if (credentials != null) {
/* 319 */         String authstring = authscheme.authenticate(credentials, method);
/* 320 */         if (authstring != null) {
/* 321 */           method.addRequestHeader(new Header("Proxy-Authorization", authstring, true));
/*     */         }
/*     */       }
/* 324 */       else if (LOG.isWarnEnabled()) {
/* 325 */         LOG.warn("Required proxy credentials not available for " + authscope);
/* 326 */         if (method.getProxyAuthState().isPreemptive()) {
/* 327 */           LOG.warn("Preemptive authentication requested but no default proxy credentials available");
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void applyConnectionParams(HttpMethod method)
/*     */     throws IOException
/*     */   {
/* 344 */     int timeout = 0;
/*     */     
/* 346 */     Object param = method.getParams().getParameter("http.socket.timeout");
/* 347 */     if (param == null)
/*     */     {
/* 349 */       param = this.conn.getParams().getParameter("http.socket.timeout");
/*     */     }
/* 351 */     if (param != null) {
/* 352 */       timeout = ((Integer)param).intValue();
/*     */     }
/* 354 */     this.conn.setSocketTimeout(timeout);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void executeWithRetry(HttpMethod method)
/*     */     throws IOException, HttpException
/*     */   {
/* 369 */     int execCount = 0;
/*     */     try
/*     */     {
/*     */       for (;;)
/*     */       {
/* 374 */         execCount++;
/*     */         try
/*     */         {
/* 377 */           if (LOG.isTraceEnabled()) {
/* 378 */             LOG.trace("Attempt number " + execCount + " to process request");
/*     */           }
/* 380 */           if (this.conn.getParams().isStaleCheckingEnabled()) {
/* 381 */             this.conn.closeIfStale();
/*     */           }
/* 383 */           if (!this.conn.isOpen())
/*     */           {
/*     */ 
/* 386 */             this.conn.open();
/* 387 */             if ((this.conn.isProxied()) && (this.conn.isSecure()) && (!(method instanceof ConnectMethod)))
/*     */             {
/*     */ 
/* 390 */               if (!executeConnect())
/*     */               {
/* 392 */                 return;
/*     */               }
/*     */             }
/*     */           }
/* 396 */           applyConnectionParams(method);
/* 397 */           method.execute(this.state, this.conn);
/*     */         }
/*     */         catch (HttpException e)
/*     */         {
/* 401 */           throw e;
/*     */         } catch (IOException e) {
/* 403 */           LOG.debug("Closing the connection.");
/* 404 */           this.conn.close();
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 409 */           if ((method instanceof HttpMethodBase)) {
/* 410 */             MethodRetryHandler handler = ((HttpMethodBase)method).getMethodRetryHandler();
/*     */             
/* 412 */             if ((handler != null) && 
/* 413 */               (!handler.retryMethod(method, this.conn, new HttpRecoverableException(e.getMessage()), execCount, method.isRequestSent())))
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 419 */               LOG.debug("Method retry handler returned false. Automatic recovery will not be attempted");
/*     */               
/* 421 */               throw e;
/*     */             }
/*     */           }
/*     */           
/*     */ 
/* 426 */           HttpMethodRetryHandler handler = (HttpMethodRetryHandler)method.getParams().getParameter("http.method.retry-handler");
/*     */           
/*     */ 
/* 429 */           if (handler == null) {
/* 430 */             handler = new DefaultHttpMethodRetryHandler();
/*     */           }
/* 432 */           if (!handler.retryMethod(method, e, execCount)) {
/* 433 */             LOG.debug("Method retry handler returned false. Automatic recovery will not be attempted");
/*     */             
/* 435 */             throw e;
/*     */           }
/* 437 */           if (LOG.isInfoEnabled()) {
/* 438 */             LOG.info("I/O exception (" + e.getClass().getName() + ") caught when processing request: " + e.getMessage());
/*     */           }
/*     */           
/* 441 */           if (LOG.isDebugEnabled()) {
/* 442 */             LOG.debug(e.getMessage(), e);
/*     */           }
/* 444 */           LOG.info("Retrying request");
/*     */         }
/*     */       }
/*     */     } catch (IOException e) {
/* 448 */       if (this.conn.isOpen()) {
/* 449 */         LOG.debug("Closing the connection.");
/* 450 */         this.conn.close();
/*     */       }
/* 452 */       this.releaseConnection = true;
/* 453 */       throw e;
/*     */     } catch (RuntimeException e) {
/* 455 */       if (this.conn.isOpen) {
/* 456 */         LOG.debug("Closing the connection.");
/* 457 */         this.conn.close();
/*     */       }
/* 459 */       this.releaseConnection = true;
/* 460 */       throw e;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean executeConnect()
/*     */     throws IOException, HttpException
/*     */   {
/* 475 */     this.connectMethod = new ConnectMethod();
/* 476 */     this.connectMethod.getParams().setDefaults(this.hostConfiguration.getParams());
/*     */     int code;
/*     */     for (;;)
/*     */     {
/* 480 */       if (!this.conn.isOpen()) {
/* 481 */         this.conn.open();
/*     */       }
/* 483 */       if ((this.params.isAuthenticationPreemptive()) || (this.state.isAuthenticationPreemptive()))
/*     */       {
/* 485 */         LOG.debug("Preemptively sending default basic credentials");
/* 486 */         this.connectMethod.getProxyAuthState().setPreemptive();
/* 487 */         this.connectMethod.getProxyAuthState().setAuthAttempted(true);
/*     */       }
/*     */       try {
/* 490 */         authenticateProxy(this.connectMethod);
/*     */       } catch (AuthenticationException e) {
/* 492 */         LOG.error(e.getMessage(), e);
/*     */       }
/* 494 */       applyConnectionParams(this.connectMethod);
/* 495 */       this.connectMethod.execute(this.state, this.conn);
/* 496 */       code = this.connectMethod.getStatusCode();
/* 497 */       boolean retry = false;
/* 498 */       AuthState authstate = this.connectMethod.getProxyAuthState();
/* 499 */       authstate.setAuthRequested(code == 407);
/* 500 */       if ((authstate.isAuthRequested()) && 
/* 501 */         (processAuthenticationResponse(this.connectMethod))) {
/* 502 */         retry = true;
/*     */       }
/*     */       
/* 505 */       if (!retry) {
/*     */         break;
/*     */       }
/* 508 */       if (this.connectMethod.getResponseBodyAsStream() != null) {
/* 509 */         this.connectMethod.getResponseBodyAsStream().close();
/*     */       }
/*     */     }
/* 512 */     if ((code >= 200) && (code < 300)) {
/* 513 */       this.conn.tunnelCreated();
/*     */       
/* 515 */       this.connectMethod = null;
/* 516 */       return true;
/*     */     }
/* 518 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void fakeResponse(HttpMethod method)
/*     */     throws IOException, HttpException
/*     */   {
/* 540 */     LOG.debug("CONNECT failed, fake the response for the original method");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 548 */     if ((method instanceof HttpMethodBase)) {
/* 549 */       ((HttpMethodBase)method).fakeResponse(this.connectMethod.getStatusLine(), this.connectMethod.getResponseHeaderGroup(), this.connectMethod.getResponseBodyAsStream());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 554 */       method.getProxyAuthState().setAuthScheme(this.connectMethod.getProxyAuthState().getAuthScheme());
/*     */       
/* 556 */       this.connectMethod = null;
/*     */     } else {
/* 558 */       this.releaseConnection = true;
/* 559 */       LOG.warn("Unable to fake response on method as it is not derived from HttpMethodBase.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean processRedirectResponse(HttpMethod method)
/*     */     throws RedirectException
/*     */   {
/* 572 */     Header locationHeader = method.getResponseHeader("location");
/* 573 */     if (locationHeader == null)
/*     */     {
/* 575 */       LOG.error("Received redirect response " + method.getStatusCode() + " but no location header");
/*     */       
/* 577 */       return false;
/*     */     }
/* 579 */     String location = locationHeader.getValue();
/* 580 */     if (LOG.isDebugEnabled()) {
/* 581 */       LOG.debug("Redirect requested to location '" + location + "'");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 586 */     URI redirectUri = null;
/* 587 */     URI currentUri = null;
/*     */     try
/*     */     {
/* 590 */       currentUri = new URI(this.conn.getProtocol().getScheme(), null, this.conn.getHost(), this.conn.getPort(), method.getPath());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 597 */       redirectUri = new URI(location, true);
/* 598 */       if (redirectUri.isRelativeURI()) {
/* 599 */         if (this.params.isParameterTrue("http.protocol.reject-relative-redirect")) {
/* 600 */           LOG.warn("Relative redirect location '" + location + "' not allowed");
/* 601 */           return false;
/*     */         }
/*     */         
/* 604 */         LOG.debug("Redirect URI is not absolute - parsing as relative");
/* 605 */         redirectUri = new URI(currentUri, redirectUri);
/*     */       }
/*     */       else
/*     */       {
/* 609 */         method.getParams().setDefaults(this.params);
/*     */       }
/* 611 */       method.setURI(redirectUri);
/* 612 */       this.hostConfiguration.setHost(redirectUri);
/*     */     } catch (URIException e) {
/* 614 */       LOG.warn("Redirected location '" + location + "' is malformed");
/* 615 */       return false;
/*     */     }
/*     */     
/* 618 */     if (this.params.isParameterFalse("http.protocol.allow-circular-redirects")) {
/* 619 */       if (this.redirectLocations == null) {
/* 620 */         this.redirectLocations = new HashSet();
/*     */       }
/* 622 */       this.redirectLocations.add(currentUri);
/*     */       try {
/* 624 */         if (redirectUri.hasQuery()) {
/* 625 */           redirectUri.setQuery(null);
/*     */         }
/*     */       }
/*     */       catch (URIException e) {
/* 629 */         return false;
/*     */       }
/*     */       
/* 632 */       if (this.redirectLocations.contains(redirectUri)) {
/* 633 */         throw new CircularRedirectException("Circular redirect to '" + redirectUri + "'");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 638 */     if (LOG.isDebugEnabled()) {
/* 639 */       LOG.debug("Redirecting from '" + currentUri.getEscapedURI() + "' to '" + redirectUri.getEscapedURI());
/*     */     }
/*     */     
/*     */ 
/* 643 */     method.getHostAuthState().invalidate();
/* 644 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean processAuthenticationResponse(HttpMethod method)
/*     */   {
/* 657 */     LOG.trace("enter HttpMethodBase.processAuthenticationResponse(HttpState, HttpConnection)");
/*     */     
/*     */     try
/*     */     {
/* 661 */       switch (method.getStatusCode()) {
/*     */       case 401: 
/* 663 */         return processWWWAuthChallenge(method);
/*     */       case 407: 
/* 665 */         return processProxyAuthChallenge(method);
/*     */       }
/* 667 */       return false;
/*     */     }
/*     */     catch (Exception e) {
/* 670 */       if (LOG.isErrorEnabled())
/* 671 */         LOG.error(e.getMessage(), e);
/*     */     }
/* 673 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean processWWWAuthChallenge(HttpMethod method)
/*     */     throws MalformedChallengeException, AuthenticationException
/*     */   {
/* 680 */     AuthState authstate = method.getHostAuthState();
/* 681 */     Map challenges = AuthChallengeParser.parseChallenges(method.getResponseHeaders("WWW-Authenticate"));
/*     */     
/* 683 */     if (challenges.isEmpty()) {
/* 684 */       LOG.debug("Authentication challenge(s) not found");
/* 685 */       return false;
/*     */     }
/* 687 */     AuthScheme authscheme = null;
/*     */     try {
/* 689 */       authscheme = this.authProcessor.processChallenge(authstate, challenges);
/*     */     } catch (AuthChallengeException e) {
/* 691 */       if (LOG.isWarnEnabled()) {
/* 692 */         LOG.warn(e.getMessage());
/*     */       }
/*     */     }
/* 695 */     if (authscheme == null) {
/* 696 */       return false;
/*     */     }
/* 698 */     String host = method.getParams().getVirtualHost();
/* 699 */     if (host == null) {
/* 700 */       host = this.conn.getHost();
/*     */     }
/* 702 */     int port = this.conn.getPort();
/* 703 */     AuthScope authscope = new AuthScope(host, port, authscheme.getRealm(), authscheme.getSchemeName());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 708 */     if (LOG.isDebugEnabled()) {
/* 709 */       LOG.debug("Authentication scope: " + authscope);
/*     */     }
/* 711 */     if ((authstate.isAuthAttempted()) && (authscheme.isComplete()))
/*     */     {
/* 713 */       Credentials credentials = promptForCredentials(authscheme, method.getParams(), authscope);
/*     */       
/* 715 */       if (credentials == null) {
/* 716 */         if (LOG.isInfoEnabled()) {
/* 717 */           LOG.info("Failure authenticating with " + authscope);
/*     */         }
/* 719 */         return false;
/*     */       }
/* 721 */       return true;
/*     */     }
/*     */     
/* 724 */     authstate.setAuthAttempted(true);
/* 725 */     Credentials credentials = this.state.getCredentials(authscope);
/* 726 */     if (credentials == null) {
/* 727 */       credentials = promptForCredentials(authscheme, method.getParams(), authscope);
/*     */     }
/*     */     
/* 730 */     if (credentials == null) {
/* 731 */       if (LOG.isInfoEnabled()) {
/* 732 */         LOG.info("No credentials available for " + authscope);
/*     */       }
/* 734 */       return false;
/*     */     }
/* 736 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean processProxyAuthChallenge(HttpMethod method)
/*     */     throws MalformedChallengeException, AuthenticationException
/*     */   {
/* 744 */     AuthState authstate = method.getProxyAuthState();
/* 745 */     Map proxyChallenges = AuthChallengeParser.parseChallenges(method.getResponseHeaders("Proxy-Authenticate"));
/*     */     
/* 747 */     if (proxyChallenges.isEmpty()) {
/* 748 */       LOG.debug("Proxy authentication challenge(s) not found");
/* 749 */       return false;
/*     */     }
/* 751 */     AuthScheme authscheme = null;
/*     */     try {
/* 753 */       authscheme = this.authProcessor.processChallenge(authstate, proxyChallenges);
/*     */     } catch (AuthChallengeException e) {
/* 755 */       if (LOG.isWarnEnabled()) {
/* 756 */         LOG.warn(e.getMessage());
/*     */       }
/*     */     }
/* 759 */     if (authscheme == null) {
/* 760 */       return false;
/*     */     }
/* 762 */     AuthScope authscope = new AuthScope(this.conn.getProxyHost(), this.conn.getProxyPort(), authscheme.getRealm(), authscheme.getSchemeName());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 767 */     if (LOG.isDebugEnabled()) {
/* 768 */       LOG.debug("Proxy authentication scope: " + authscope);
/*     */     }
/* 770 */     if ((authstate.isAuthAttempted()) && (authscheme.isComplete()))
/*     */     {
/* 772 */       Credentials credentials = promptForProxyCredentials(authscheme, method.getParams(), authscope);
/*     */       
/* 774 */       if (credentials == null) {
/* 775 */         if (LOG.isInfoEnabled()) {
/* 776 */           LOG.info("Failure authenticating with " + authscope);
/*     */         }
/* 778 */         return false;
/*     */       }
/* 780 */       return true;
/*     */     }
/*     */     
/* 783 */     authstate.setAuthAttempted(true);
/* 784 */     Credentials credentials = this.state.getProxyCredentials(authscope);
/* 785 */     if (credentials == null) {
/* 786 */       credentials = promptForProxyCredentials(authscheme, method.getParams(), authscope);
/*     */     }
/*     */     
/* 789 */     if (credentials == null) {
/* 790 */       if (LOG.isInfoEnabled()) {
/* 791 */         LOG.info("No credentials available for " + authscope);
/*     */       }
/* 793 */       return false;
/*     */     }
/* 795 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isRedirectNeeded(HttpMethod method)
/*     */   {
/* 808 */     switch (method.getStatusCode()) {
/*     */     case 301: 
/*     */     case 302: 
/*     */     case 303: 
/*     */     case 307: 
/* 813 */       LOG.debug("Redirect required");
/* 814 */       if (method.getFollowRedirects()) {
/* 815 */         return true;
/*     */       }
/* 817 */       LOG.info("Redirect requested but followRedirects is disabled");
/*     */       
/* 819 */       return false;
/*     */     }
/*     */     
/* 822 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isAuthenticationNeeded(HttpMethod method)
/*     */   {
/* 834 */     method.getHostAuthState().setAuthRequested(method.getStatusCode() == 401);
/*     */     
/* 836 */     method.getProxyAuthState().setAuthRequested(method.getStatusCode() == 407);
/*     */     
/* 838 */     if ((method.getHostAuthState().isAuthRequested()) || (method.getProxyAuthState().isAuthRequested()))
/*     */     {
/* 840 */       LOG.debug("Authorization required");
/* 841 */       if (method.getDoAuthentication()) {
/* 842 */         return true;
/*     */       }
/* 844 */       LOG.info("Authentication requested but doAuthentication is disabled");
/*     */       
/* 846 */       return false;
/*     */     }
/*     */     
/* 849 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Credentials promptForCredentials(AuthScheme authScheme, HttpParams params, AuthScope authscope)
/*     */   {
/* 858 */     LOG.debug("Credentials required");
/* 859 */     Credentials creds = null;
/* 860 */     CredentialsProvider credProvider = (CredentialsProvider)params.getParameter("http.authentication.credential-provider");
/*     */     
/* 862 */     if (credProvider != null) {
/*     */       try {
/* 864 */         creds = credProvider.getCredentials(authScheme, authscope.getHost(), authscope.getPort(), false);
/*     */       }
/*     */       catch (CredentialsNotAvailableException e) {
/* 867 */         LOG.warn(e.getMessage());
/*     */       }
/* 869 */       if (creds != null) {
/* 870 */         this.state.setCredentials(authscope, creds);
/* 871 */         if (LOG.isDebugEnabled()) {
/* 872 */           LOG.debug(authscope + " new credentials given");
/*     */         }
/*     */       }
/*     */     } else {
/* 876 */       LOG.debug("Credentials provider not available");
/*     */     }
/* 878 */     return creds;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Credentials promptForProxyCredentials(AuthScheme authScheme, HttpParams params, AuthScope authscope)
/*     */   {
/* 886 */     LOG.debug("Proxy credentials required");
/* 887 */     Credentials creds = null;
/* 888 */     CredentialsProvider credProvider = (CredentialsProvider)params.getParameter("http.authentication.credential-provider");
/*     */     
/* 890 */     if (credProvider != null) {
/*     */       try {
/* 892 */         creds = credProvider.getCredentials(authScheme, authscope.getHost(), authscope.getPort(), true);
/*     */       }
/*     */       catch (CredentialsNotAvailableException e) {
/* 895 */         LOG.warn(e.getMessage());
/*     */       }
/* 897 */       if (creds != null) {
/* 898 */         this.state.setProxyCredentials(authscope, creds);
/* 899 */         if (LOG.isDebugEnabled()) {
/* 900 */           LOG.debug(authscope + " new credentials given");
/*     */         }
/*     */       }
/*     */     } else {
/* 904 */       LOG.debug("Proxy credentials provider not available");
/*     */     }
/* 906 */     return creds;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public HostConfiguration getHostConfiguration()
/*     */   {
/* 913 */     return this.hostConfiguration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public HttpState getState()
/*     */   {
/* 920 */     return this.state;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public HttpConnectionManager getConnectionManager()
/*     */   {
/* 927 */     return this.connectionManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public HttpParams getParams()
/*     */   {
/* 934 */     return this.params;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\HttpMethodDirector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */