/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.apache.commons.httpclient.params.DefaultHttpParams;
/*     */ import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
/*     */ import org.apache.commons.httpclient.params.HttpConnectionParams;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleHttpConnectionManager
/*     */   implements HttpConnectionManager
/*     */ {
/*  54 */   private static final Log LOG = LogFactory.getLog(SimpleHttpConnectionManager.class);
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String MISUSE_MESSAGE = "SimpleHttpConnectionManager being used incorrectly.  Be sure that HttpMethod.releaseConnection() is always called and that only one thread and/or method is using this connection manager at a time.";
/*     */   
/*     */ 
/*     */ 
/*     */   protected HttpConnection httpConnection;
/*     */   
/*     */ 
/*     */ 
/*     */   static void finishLastResponse(HttpConnection conn)
/*     */   {
/*  68 */     InputStream lastResponse = conn.getLastResponseInputStream();
/*  69 */     if (lastResponse != null) {
/*  70 */       conn.setLastResponseInputStream(null);
/*     */       try {
/*  72 */         lastResponse.close();
/*     */       }
/*     */       catch (IOException ioe) {
/*  75 */         conn.close();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  86 */   private HttpConnectionManagerParams params = new HttpConnectionManagerParams();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  91 */   private long idleStartTime = Long.MAX_VALUE;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  99 */   private volatile boolean inUse = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpConnection getConnection(HostConfiguration hostConfiguration)
/*     */   {
/* 108 */     return getConnection(hostConfiguration, 0L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public boolean isConnectionStaleCheckingEnabled()
/*     */   {
/* 122 */     return this.params.isStaleCheckingEnabled();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setConnectionStaleCheckingEnabled(boolean connectionStaleCheckingEnabled)
/*     */   {
/* 137 */     this.params.setStaleCheckingEnabled(connectionStaleCheckingEnabled);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpConnection getConnectionWithTimeout(HostConfiguration hostConfiguration, long timeout)
/*     */   {
/* 148 */     if (this.httpConnection == null) {
/* 149 */       this.httpConnection = new HttpConnection(hostConfiguration);
/* 150 */       this.httpConnection.setHttpConnectionManager(this);
/* 151 */       this.httpConnection.getParams().setDefaults(this.params);
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/* 156 */     else if ((!hostConfiguration.hostEquals(this.httpConnection)) || (!hostConfiguration.proxyEquals(this.httpConnection)))
/*     */     {
/*     */ 
/* 159 */       if (this.httpConnection.isOpen()) {
/* 160 */         this.httpConnection.close();
/*     */       }
/*     */       
/* 163 */       this.httpConnection.setHost(hostConfiguration.getHost());
/* 164 */       this.httpConnection.setPort(hostConfiguration.getPort());
/* 165 */       this.httpConnection.setProtocol(hostConfiguration.getProtocol());
/* 166 */       this.httpConnection.setLocalAddress(hostConfiguration.getLocalAddress());
/*     */       
/* 168 */       this.httpConnection.setProxyHost(hostConfiguration.getProxyHost());
/* 169 */       this.httpConnection.setProxyPort(hostConfiguration.getProxyPort());
/*     */     } else {
/* 171 */       finishLastResponse(this.httpConnection);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 176 */     this.idleStartTime = Long.MAX_VALUE;
/*     */     
/* 178 */     if (this.inUse) LOG.warn("SimpleHttpConnectionManager being used incorrectly.  Be sure that HttpMethod.releaseConnection() is always called and that only one thread and/or method is using this connection manager at a time.");
/* 179 */     this.inUse = true;
/*     */     
/* 181 */     return this.httpConnection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public HttpConnection getConnection(HostConfiguration hostConfiguration, long timeout)
/*     */   {
/* 191 */     return getConnectionWithTimeout(hostConfiguration, timeout);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void releaseConnection(HttpConnection conn)
/*     */   {
/* 198 */     if (conn != this.httpConnection) {
/* 199 */       throw new IllegalStateException("Unexpected release of an unknown connection.");
/*     */     }
/*     */     
/* 202 */     finishLastResponse(this.httpConnection);
/*     */     
/* 204 */     this.inUse = false;
/*     */     
/*     */ 
/* 207 */     this.idleStartTime = System.currentTimeMillis();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpConnectionManagerParams getParams()
/*     */   {
/* 219 */     return this.params;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParams(HttpConnectionManagerParams params)
/*     */   {
/* 231 */     if (params == null) {
/* 232 */       throw new IllegalArgumentException("Parameters may not be null");
/*     */     }
/* 234 */     this.params = params;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void closeIdleConnections(long idleTimeout)
/*     */   {
/* 241 */     long maxIdleTime = System.currentTimeMillis() - idleTimeout;
/* 242 */     if (this.idleStartTime <= maxIdleTime) {
/* 243 */       this.httpConnection.close();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\SimpleHttpConnectionManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */