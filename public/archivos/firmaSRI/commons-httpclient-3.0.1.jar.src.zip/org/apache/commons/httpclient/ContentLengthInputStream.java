/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContentLengthInputStream
/*     */   extends InputStream
/*     */ {
/*     */   private long contentLength;
/*  69 */   private long pos = 0L;
/*     */   
/*     */ 
/*  72 */   private boolean closed = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  77 */   private InputStream wrappedStream = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public ContentLengthInputStream(InputStream in, int contentLength)
/*     */   {
/*  89 */     this(in, contentLength);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentLengthInputStream(InputStream in, long contentLength)
/*     */   {
/* 103 */     this.wrappedStream = in;
/* 104 */     this.contentLength = contentLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 115 */     if (!this.closed) {
/*     */       try {
/* 117 */         ChunkedInputStream.exhaustInputStream(this);
/*     */       }
/*     */       finally
/*     */       {
/* 121 */         this.closed = true;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/* 134 */     if (this.closed) {
/* 135 */       throw new IOException("Attempted read from closed stream.");
/*     */     }
/*     */     
/* 138 */     if (this.pos >= this.contentLength) {
/* 139 */       return -1;
/*     */     }
/* 141 */     this.pos += 1L;
/* 142 */     return this.wrappedStream.read();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 158 */     if (this.closed) {
/* 159 */       throw new IOException("Attempted read from closed stream.");
/*     */     }
/*     */     
/* 162 */     if (this.pos >= this.contentLength) {
/* 163 */       return -1;
/*     */     }
/*     */     
/* 166 */     if (this.pos + len > this.contentLength) {
/* 167 */       len = (int)(this.contentLength - this.pos);
/*     */     }
/* 169 */     int count = this.wrappedStream.read(b, off, len);
/* 170 */     this.pos += count;
/* 171 */     return count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] b)
/*     */     throws IOException
/*     */   {
/* 183 */     return read(b, 0, b.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long skip(long n)
/*     */     throws IOException
/*     */   {
/* 197 */     long length = Math.min(n, this.contentLength - this.pos);
/*     */     
/* 199 */     length = this.wrappedStream.skip(length);
/*     */     
/*     */ 
/* 202 */     if (length > 0L) {
/* 203 */       this.pos += length;
/*     */     }
/* 205 */     return length;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\ContentLengthInputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */