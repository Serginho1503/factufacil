/*     */ package org.apache.commons.httpclient.auth;
/*     */ 
/*     */ import org.apache.commons.httpclient.Credentials;
/*     */ import org.apache.commons.httpclient.HttpMethod;
/*     */ import org.apache.commons.httpclient.NTCredentials;
/*     */ import org.apache.commons.httpclient.UsernamePasswordCredentials;
/*     */ import org.apache.commons.httpclient.params.HttpMethodParams;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NTLMScheme
/*     */   implements AuthScheme
/*     */ {
/*  54 */   private static final Log LOG = LogFactory.getLog(NTLMScheme.class);
/*     */   
/*     */ 
/*  57 */   private String ntlmchallenge = null;
/*     */   
/*     */   private static final int UNINITIATED = 0;
/*     */   
/*     */   private static final int INITIATED = 1;
/*     */   
/*     */   private static final int TYPE1_MSG_GENERATED = 2;
/*     */   
/*     */   private static final int TYPE2_MSG_RECEIVED = 3;
/*     */   
/*     */   private static final int TYPE3_MSG_GENERATED = 4;
/*     */   
/*     */   private static final int FAILED = Integer.MAX_VALUE;
/*     */   
/*     */   private int state;
/*     */   
/*     */ 
/*     */   public NTLMScheme()
/*     */   {
/*  76 */     this.state = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NTLMScheme(String challenge)
/*     */     throws MalformedChallengeException
/*     */   {
/*  89 */     processChallenge(challenge);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void processChallenge(String challenge)
/*     */     throws MalformedChallengeException
/*     */   {
/* 103 */     String s = AuthChallengeParser.extractScheme(challenge);
/* 104 */     if (!s.equalsIgnoreCase(getSchemeName())) {
/* 105 */       throw new MalformedChallengeException("Invalid NTLM challenge: " + challenge);
/*     */     }
/* 107 */     int i = challenge.indexOf(' ');
/* 108 */     if (i != -1) {
/* 109 */       s = challenge.substring(i, challenge.length());
/* 110 */       this.ntlmchallenge = s.trim();
/* 111 */       this.state = 3;
/*     */     } else {
/* 113 */       this.ntlmchallenge = "";
/* 114 */       if (this.state == 0) {
/* 115 */         this.state = 1;
/*     */       } else {
/* 117 */         this.state = Integer.MAX_VALUE;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isComplete()
/*     */   {
/* 131 */     return (this.state == 4) || (this.state == Integer.MAX_VALUE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSchemeName()
/*     */   {
/* 140 */     return "ntlm";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRealm()
/*     */   {
/* 150 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public String getID()
/*     */   {
/* 172 */     return this.ntlmchallenge;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getParameter(String name)
/*     */   {
/* 186 */     if (name == null) {
/* 187 */       throw new IllegalArgumentException("Parameter name may not be null");
/*     */     }
/* 189 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isConnectionBased()
/*     */   {
/* 200 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static String authenticate(NTCredentials credentials, String challenge)
/*     */     throws AuthenticationException
/*     */   {
/* 219 */     LOG.trace("enter NTLMScheme.authenticate(NTCredentials, String)");
/*     */     
/* 221 */     if (credentials == null) {
/* 222 */       throw new IllegalArgumentException("Credentials may not be null");
/*     */     }
/*     */     
/* 225 */     NTLM ntlm = new NTLM();
/* 226 */     String s = ntlm.getResponseFor(challenge, credentials.getUserName(), credentials.getPassword(), credentials.getHost(), credentials.getDomain());
/*     */     
/*     */ 
/* 229 */     return "NTLM " + s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static String authenticate(NTCredentials credentials, String challenge, String charset)
/*     */     throws AuthenticationException
/*     */   {
/* 253 */     LOG.trace("enter NTLMScheme.authenticate(NTCredentials, String)");
/*     */     
/* 255 */     if (credentials == null) {
/* 256 */       throw new IllegalArgumentException("Credentials may not be null");
/*     */     }
/*     */     
/* 259 */     NTLM ntlm = new NTLM();
/* 260 */     ntlm.setCredentialCharset(charset);
/* 261 */     String s = ntlm.getResponseFor(challenge, credentials.getUserName(), credentials.getPassword(), credentials.getHost(), credentials.getDomain());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 267 */     return "NTLM " + s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public String authenticate(Credentials credentials, String method, String uri)
/*     */     throws AuthenticationException
/*     */   {
/* 288 */     LOG.trace("enter NTLMScheme.authenticate(Credentials, String, String)");
/*     */     
/* 290 */     NTCredentials ntcredentials = null;
/*     */     try {
/* 292 */       ntcredentials = (NTCredentials)credentials;
/*     */     } catch (ClassCastException e) {
/* 294 */       throw new InvalidCredentialsException("Credentials cannot be used for NTLM authentication: " + credentials.getClass().getName());
/*     */     }
/*     */     
/*     */ 
/* 298 */     return authenticate(ntcredentials, this.ntlmchallenge);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String authenticate(Credentials credentials, HttpMethod method)
/*     */     throws AuthenticationException
/*     */   {
/* 321 */     LOG.trace("enter NTLMScheme.authenticate(Credentials, HttpMethod)");
/*     */     
/* 323 */     if (this.state == 0) {
/* 324 */       throw new IllegalStateException("NTLM authentication process has not been initiated");
/*     */     }
/*     */     
/* 327 */     NTCredentials ntcredentials = null;
/*     */     try {
/* 329 */       ntcredentials = (NTCredentials)credentials;
/*     */     } catch (ClassCastException e) {
/* 331 */       throw new InvalidCredentialsException("Credentials cannot be used for NTLM authentication: " + credentials.getClass().getName());
/*     */     }
/*     */     
/*     */ 
/* 335 */     NTLM ntlm = new NTLM();
/* 336 */     ntlm.setCredentialCharset(method.getParams().getCredentialCharset());
/* 337 */     String response = null;
/* 338 */     if ((this.state == 1) || (this.state == Integer.MAX_VALUE)) {
/* 339 */       response = ntlm.getType1Message(ntcredentials.getHost(), ntcredentials.getDomain());
/*     */       
/*     */ 
/* 342 */       this.state = 2;
/*     */     } else {
/* 344 */       response = ntlm.getType3Message(ntcredentials.getUserName(), ntcredentials.getPassword(), ntcredentials.getHost(), ntcredentials.getDomain(), ntlm.parseType2Message(this.ntlmchallenge));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 350 */       this.state = 4;
/*     */     }
/* 352 */     return "NTLM " + response;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\auth\NTLMScheme.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */