package org.apache.commons.httpclient.auth;

import org.apache.commons.httpclient.Credentials;

public abstract interface CredentialsProvider
{
  public static final String PROVIDER = "http.authentication.credential-provider";
  
  public abstract Credentials getCredentials(AuthScheme paramAuthScheme, String paramString, int paramInt, boolean paramBoolean)
    throws CredentialsNotAvailableException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\auth\CredentialsProvider.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */