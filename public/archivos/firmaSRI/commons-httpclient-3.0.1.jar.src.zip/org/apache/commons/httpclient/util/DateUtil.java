/*     */ package org.apache.commons.httpclient.util;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Arrays;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DateUtil
/*     */ {
/*     */   public static final String PATTERN_RFC1123 = "EEE, dd MMM yyyy HH:mm:ss zzz";
/*     */   public static final String PATTERN_RFC1036 = "EEEE, dd-MMM-yy HH:mm:ss zzz";
/*     */   public static final String PATTERN_ASCTIME = "EEE MMM d HH:mm:ss yyyy";
/*  68 */   private static final Collection DEFAULT_PATTERNS = Arrays.asList(new String[] { "EEE MMM d HH:mm:ss yyyy", "EEEE, dd-MMM-yy HH:mm:ss zzz", "EEE, dd MMM yyyy HH:mm:ss zzz" });
/*     */   
/*     */   private static final Date DEFAULT_TWO_DIGIT_YEAR_START;
/*     */   
/*     */   static
/*     */   {
/*  74 */     Calendar calendar = Calendar.getInstance();
/*  75 */     calendar.set(2000, 0, 1, 0, 0);
/*  76 */     DEFAULT_TWO_DIGIT_YEAR_START = calendar.getTime();
/*     */   }
/*     */   
/*  79 */   private static final TimeZone GMT = TimeZone.getTimeZone("GMT");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Date parseDate(String dateValue)
/*     */     throws DateParseException
/*     */   {
/*  93 */     return parseDate(dateValue, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Date parseDate(String dateValue, Collection dateFormats)
/*     */     throws DateParseException
/*     */   {
/* 108 */     return parseDate(dateValue, dateFormats, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Date parseDate(String dateValue, Collection dateFormats, Date startDate)
/*     */     throws DateParseException
/*     */   {
/* 131 */     if (dateValue == null) {
/* 132 */       throw new IllegalArgumentException("dateValue is null");
/*     */     }
/* 134 */     if (dateFormats == null) {
/* 135 */       dateFormats = DEFAULT_PATTERNS;
/*     */     }
/* 137 */     if (startDate == null) {
/* 138 */       startDate = DEFAULT_TWO_DIGIT_YEAR_START;
/*     */     }
/*     */     
/*     */ 
/* 142 */     if ((dateValue.length() > 1) && (dateValue.startsWith("'")) && (dateValue.endsWith("'")))
/*     */     {
/*     */ 
/*     */ 
/* 146 */       dateValue = dateValue.substring(1, dateValue.length() - 1);
/*     */     }
/*     */     
/* 149 */     SimpleDateFormat dateParser = null;
/* 150 */     Iterator formatIter = dateFormats.iterator();
/*     */     
/* 152 */     while (formatIter.hasNext()) {
/* 153 */       String format = (String)formatIter.next();
/* 154 */       if (dateParser == null) {
/* 155 */         dateParser = new SimpleDateFormat(format, Locale.US);
/* 156 */         dateParser.setTimeZone(TimeZone.getTimeZone("GMT"));
/* 157 */         dateParser.set2DigitYearStart(startDate);
/*     */       } else {
/* 159 */         dateParser.applyPattern(format);
/*     */       }
/*     */       try {
/* 162 */         return dateParser.parse(dateValue);
/*     */       }
/*     */       catch (ParseException pe) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 169 */     throw new DateParseException("Unable to parse the date " + dateValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String formatDate(Date date)
/*     */   {
/* 181 */     return formatDate(date, "EEE, dd MMM yyyy HH:mm:ss zzz");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String formatDate(Date date, String pattern)
/*     */   {
/* 198 */     if (date == null) throw new IllegalArgumentException("date is null");
/* 199 */     if (pattern == null) { throw new IllegalArgumentException("pattern is null");
/*     */     }
/* 201 */     SimpleDateFormat formatter = new SimpleDateFormat(pattern, Locale.US);
/* 202 */     formatter.setTimeZone(GMT);
/* 203 */     return formatter.format(date);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\util\DateUtil.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */