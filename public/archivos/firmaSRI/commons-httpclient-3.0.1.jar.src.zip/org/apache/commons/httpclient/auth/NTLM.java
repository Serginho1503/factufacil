/*     */ package org.apache.commons.httpclient.auth;
/*     */ 
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import javax.crypto.BadPaddingException;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.IllegalBlockSizeException;
/*     */ import javax.crypto.NoSuchPaddingException;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ import org.apache.commons.codec.binary.Base64;
/*     */ import org.apache.commons.httpclient.util.EncodingUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class NTLM
/*     */ {
/*     */   public static final String DEFAULT_CHARSET = "ASCII";
/*     */   private byte[] currentResponse;
/*  75 */   private int currentPosition = 0;
/*     */   
/*     */ 
/*  78 */   private String credentialCharset = "ASCII";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getResponseFor(String message, String username, String password, String host, String domain)
/*     */     throws AuthenticationException
/*     */   {
/*     */     String response;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */     if ((message == null) || (message.trim().equals(""))) {
/*  97 */       response = getType1Message(host, domain);
/*     */     } else {
/*  99 */       response = getType3Message(username, password, host, domain, parseType2Message(message));
/*     */     }
/*     */     
/* 102 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Cipher getCipher(byte[] key)
/*     */     throws AuthenticationException
/*     */   {
/*     */     try
/*     */     {
/* 113 */       Cipher ecipher = Cipher.getInstance("DES/ECB/NoPadding");
/* 114 */       key = setupKey(key);
/* 115 */       ecipher.init(1, new SecretKeySpec(key, "DES"));
/* 116 */       return ecipher;
/*     */     } catch (NoSuchAlgorithmException e) {
/* 118 */       throw new AuthenticationException("DES encryption is not available.", e);
/*     */     } catch (InvalidKeyException e) {
/* 120 */       throw new AuthenticationException("Invalid key for DES encryption.", e);
/*     */     } catch (NoSuchPaddingException e) {
/* 122 */       throw new AuthenticationException("NoPadding option for DES is not available.", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] setupKey(byte[] key56)
/*     */   {
/* 133 */     byte[] key = new byte[8];
/* 134 */     key[0] = ((byte)(key56[0] >> 1 & 0xFF));
/* 135 */     key[1] = ((byte)(((key56[0] & 0x1) << 6 | (key56[1] & 0xFF) >> 2 & 0xFF) & 0xFF));
/*     */     
/* 137 */     key[2] = ((byte)(((key56[1] & 0x3) << 5 | (key56[2] & 0xFF) >> 3 & 0xFF) & 0xFF));
/*     */     
/* 139 */     key[3] = ((byte)(((key56[2] & 0x7) << 4 | (key56[3] & 0xFF) >> 4 & 0xFF) & 0xFF));
/*     */     
/* 141 */     key[4] = ((byte)(((key56[3] & 0xF) << 3 | (key56[4] & 0xFF) >> 5 & 0xFF) & 0xFF));
/*     */     
/* 143 */     key[5] = ((byte)(((key56[4] & 0x1F) << 2 | (key56[5] & 0xFF) >> 6 & 0xFF) & 0xFF));
/*     */     
/* 145 */     key[6] = ((byte)(((key56[5] & 0x3F) << 1 | (key56[6] & 0xFF) >> 7 & 0xFF) & 0xFF));
/*     */     
/* 147 */     key[7] = ((byte)(key56[6] & 0x7F));
/*     */     
/* 149 */     for (int i = 0; i < key.length; i++) {
/* 150 */       key[i] = ((byte)(key[i] << 1));
/*     */     }
/* 152 */     return key;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] encrypt(byte[] key, byte[] bytes)
/*     */     throws AuthenticationException
/*     */   {
/* 164 */     Cipher ecipher = getCipher(key);
/*     */     try {
/* 166 */       return ecipher.doFinal(bytes);
/*     */     }
/*     */     catch (IllegalBlockSizeException e) {
/* 169 */       throw new AuthenticationException("Invalid block size for DES encryption.", e);
/*     */     } catch (BadPaddingException e) {
/* 171 */       throw new AuthenticationException("Data not padded correctly for DES encryption.", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void prepareResponse(int length)
/*     */   {
/* 180 */     this.currentResponse = new byte[length];
/* 181 */     this.currentPosition = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addByte(byte b)
/*     */   {
/* 189 */     this.currentResponse[this.currentPosition] = b;
/* 190 */     this.currentPosition += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addBytes(byte[] bytes)
/*     */   {
/* 198 */     for (int i = 0; i < bytes.length; i++) {
/* 199 */       this.currentResponse[this.currentPosition] = bytes[i];
/* 200 */       this.currentPosition += 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private String getResponse()
/*     */   {
/*     */     byte[] resp;
/*     */     
/*     */ 
/* 211 */     if (this.currentResponse.length > this.currentPosition) {
/* 212 */       byte[] tmp = new byte[this.currentPosition];
/* 213 */       for (int i = 0; i < this.currentPosition; i++) {
/* 214 */         tmp[i] = this.currentResponse[i];
/*     */       }
/* 216 */       resp = tmp;
/*     */     } else {
/* 218 */       resp = this.currentResponse;
/*     */     }
/* 220 */     return EncodingUtil.getAsciiString(Base64.encodeBase64(resp));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getType1Message(String host, String domain)
/*     */   {
/* 232 */     host = host.toUpperCase();
/* 233 */     domain = domain.toUpperCase();
/* 234 */     byte[] hostBytes = EncodingUtil.getBytes(host, "ASCII");
/* 235 */     byte[] domainBytes = EncodingUtil.getBytes(domain, "ASCII");
/*     */     
/* 237 */     int finalLength = 32 + hostBytes.length + domainBytes.length;
/* 238 */     prepareResponse(finalLength);
/*     */     
/*     */ 
/* 241 */     byte[] protocol = EncodingUtil.getBytes("NTLMSSP", "ASCII");
/* 242 */     addBytes(protocol);
/* 243 */     addByte((byte)0);
/*     */     
/*     */ 
/* 246 */     addByte((byte)1);
/* 247 */     addByte((byte)0);
/* 248 */     addByte((byte)0);
/* 249 */     addByte((byte)0);
/*     */     
/*     */ 
/* 252 */     addByte((byte)6);
/* 253 */     addByte((byte)82);
/* 254 */     addByte((byte)0);
/* 255 */     addByte((byte)0);
/*     */     
/*     */ 
/* 258 */     int iDomLen = domainBytes.length;
/* 259 */     byte[] domLen = convertShort(iDomLen);
/* 260 */     addByte(domLen[0]);
/* 261 */     addByte(domLen[1]);
/*     */     
/*     */ 
/* 264 */     addByte(domLen[0]);
/* 265 */     addByte(domLen[1]);
/*     */     
/*     */ 
/* 268 */     byte[] domOff = convertShort(hostBytes.length + 32);
/* 269 */     addByte(domOff[0]);
/* 270 */     addByte(domOff[1]);
/* 271 */     addByte((byte)0);
/* 272 */     addByte((byte)0);
/*     */     
/*     */ 
/* 275 */     byte[] hostLen = convertShort(hostBytes.length);
/* 276 */     addByte(hostLen[0]);
/* 277 */     addByte(hostLen[1]);
/*     */     
/*     */ 
/* 280 */     addByte(hostLen[0]);
/* 281 */     addByte(hostLen[1]);
/*     */     
/*     */ 
/* 284 */     byte[] hostOff = convertShort(32);
/* 285 */     addByte(hostOff[0]);
/* 286 */     addByte(hostOff[1]);
/* 287 */     addByte((byte)0);
/* 288 */     addByte((byte)0);
/*     */     
/*     */ 
/* 291 */     addBytes(hostBytes);
/*     */     
/*     */ 
/* 294 */     addBytes(domainBytes);
/*     */     
/* 296 */     return getResponse();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] parseType2Message(String message)
/*     */   {
/* 308 */     byte[] msg = Base64.decodeBase64(EncodingUtil.getBytes(message, "ASCII"));
/* 309 */     byte[] nonce = new byte[8];
/*     */     
/* 311 */     for (int i = 0; i < 8; i++) {
/* 312 */       nonce[i] = msg[(i + 24)];
/*     */     }
/* 314 */     return nonce;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getType3Message(String user, String password, String host, String domain, byte[] nonce)
/*     */     throws AuthenticationException
/*     */   {
/* 334 */     int ntRespLen = 0;
/* 335 */     int lmRespLen = 24;
/* 336 */     domain = domain.toUpperCase();
/* 337 */     host = host.toUpperCase();
/* 338 */     user = user.toUpperCase();
/* 339 */     byte[] domainBytes = EncodingUtil.getBytes(domain, "ASCII");
/* 340 */     byte[] hostBytes = EncodingUtil.getBytes(host, "ASCII");
/* 341 */     byte[] userBytes = EncodingUtil.getBytes(user, this.credentialCharset);
/* 342 */     int domainLen = domainBytes.length;
/* 343 */     int hostLen = hostBytes.length;
/* 344 */     int userLen = userBytes.length;
/* 345 */     int finalLength = 64 + ntRespLen + lmRespLen + domainLen + userLen + hostLen;
/*     */     
/* 347 */     prepareResponse(finalLength);
/* 348 */     byte[] ntlmssp = EncodingUtil.getBytes("NTLMSSP", "ASCII");
/* 349 */     addBytes(ntlmssp);
/* 350 */     addByte((byte)0);
/* 351 */     addByte((byte)3);
/* 352 */     addByte((byte)0);
/* 353 */     addByte((byte)0);
/* 354 */     addByte((byte)0);
/*     */     
/*     */ 
/* 357 */     addBytes(convertShort(24));
/* 358 */     addBytes(convertShort(24));
/*     */     
/*     */ 
/* 361 */     addBytes(convertShort(finalLength - 24));
/* 362 */     addByte((byte)0);
/* 363 */     addByte((byte)0);
/*     */     
/*     */ 
/* 366 */     addBytes(convertShort(0));
/* 367 */     addBytes(convertShort(0));
/*     */     
/*     */ 
/* 370 */     addBytes(convertShort(finalLength));
/* 371 */     addByte((byte)0);
/* 372 */     addByte((byte)0);
/*     */     
/*     */ 
/* 375 */     addBytes(convertShort(domainLen));
/* 376 */     addBytes(convertShort(domainLen));
/*     */     
/*     */ 
/* 379 */     addBytes(convertShort(64));
/* 380 */     addByte((byte)0);
/* 381 */     addByte((byte)0);
/*     */     
/*     */ 
/* 384 */     addBytes(convertShort(userLen));
/* 385 */     addBytes(convertShort(userLen));
/*     */     
/*     */ 
/* 388 */     addBytes(convertShort(64 + domainLen));
/* 389 */     addByte((byte)0);
/* 390 */     addByte((byte)0);
/*     */     
/*     */ 
/* 393 */     addBytes(convertShort(hostLen));
/* 394 */     addBytes(convertShort(hostLen));
/*     */     
/*     */ 
/* 397 */     addBytes(convertShort(64 + domainLen + userLen));
/*     */     
/* 399 */     for (int i = 0; i < 6; i++) {
/* 400 */       addByte((byte)0);
/*     */     }
/*     */     
/*     */ 
/* 404 */     addBytes(convertShort(finalLength));
/* 405 */     addByte((byte)0);
/* 406 */     addByte((byte)0);
/*     */     
/*     */ 
/* 409 */     addByte((byte)6);
/* 410 */     addByte((byte)82);
/* 411 */     addByte((byte)0);
/* 412 */     addByte((byte)0);
/*     */     
/* 414 */     addBytes(domainBytes);
/* 415 */     addBytes(userBytes);
/* 416 */     addBytes(hostBytes);
/* 417 */     addBytes(hashPassword(password, nonce));
/* 418 */     return getResponse();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] hashPassword(String password, byte[] nonce)
/*     */     throws AuthenticationException
/*     */   {
/* 431 */     byte[] passw = EncodingUtil.getBytes(password.toUpperCase(), this.credentialCharset);
/* 432 */     byte[] lmPw1 = new byte[7];
/* 433 */     byte[] lmPw2 = new byte[7];
/*     */     
/* 435 */     int len = passw.length;
/* 436 */     if (len > 7) {
/* 437 */       len = 7;
/*     */     }
/*     */     
/*     */ 
/* 441 */     for (int idx = 0; idx < len; idx++) {
/* 442 */       lmPw1[idx] = passw[idx];
/*     */     }
/* 444 */     for (; idx < 7; idx++) {
/* 445 */       lmPw1[idx] = 0;
/*     */     }
/*     */     
/* 448 */     len = passw.length;
/* 449 */     if (len > 14) {
/* 450 */       len = 14;
/*     */     }
/* 452 */     for (idx = 7; idx < len; idx++) {
/* 453 */       lmPw2[(idx - 7)] = passw[idx];
/*     */     }
/* 455 */     for (; idx < 14; idx++) {
/* 456 */       lmPw2[(idx - 7)] = 0;
/*     */     }
/*     */     
/*     */ 
/* 460 */     byte[] magic = { 75, 71, 83, 33, 64, 35, 36, 37 };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 466 */     byte[] lmHpw1 = encrypt(lmPw1, magic);
/*     */     
/* 468 */     byte[] lmHpw2 = encrypt(lmPw2, magic);
/*     */     
/* 470 */     byte[] lmHpw = new byte[21];
/* 471 */     for (int i = 0; i < lmHpw1.length; i++) {
/* 472 */       lmHpw[i] = lmHpw1[i];
/*     */     }
/* 474 */     for (int i = 0; i < lmHpw2.length; i++) {
/* 475 */       lmHpw[(i + 8)] = lmHpw2[i];
/*     */     }
/* 477 */     for (int i = 0; i < 5; i++) {
/* 478 */       lmHpw[(i + 16)] = 0;
/*     */     }
/*     */     
/*     */ 
/* 482 */     byte[] lmResp = new byte[24];
/* 483 */     calcResp(lmHpw, nonce, lmResp);
/*     */     
/* 485 */     return lmResp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void calcResp(byte[] keys, byte[] plaintext, byte[] results)
/*     */     throws AuthenticationException
/*     */   {
/* 500 */     byte[] keys1 = new byte[7];
/* 501 */     byte[] keys2 = new byte[7];
/* 502 */     byte[] keys3 = new byte[7];
/* 503 */     for (int i = 0; i < 7; i++) {
/* 504 */       keys1[i] = keys[i];
/*     */     }
/*     */     
/* 507 */     for (int i = 0; i < 7; i++) {
/* 508 */       keys2[i] = keys[(i + 7)];
/*     */     }
/*     */     
/* 511 */     for (int i = 0; i < 7; i++) {
/* 512 */       keys3[i] = keys[(i + 14)];
/*     */     }
/* 514 */     byte[] results1 = encrypt(keys1, plaintext);
/*     */     
/* 516 */     byte[] results2 = encrypt(keys2, plaintext);
/*     */     
/* 518 */     byte[] results3 = encrypt(keys3, plaintext);
/*     */     
/* 520 */     for (int i = 0; i < 8; i++) {
/* 521 */       results[i] = results1[i];
/*     */     }
/* 523 */     for (int i = 0; i < 8; i++) {
/* 524 */       results[(i + 8)] = results2[i];
/*     */     }
/* 526 */     for (int i = 0; i < 8; i++) {
/* 527 */       results[(i + 16)] = results3[i];
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] convertShort(int num)
/*     */   {
/* 537 */     byte[] val = new byte[2];
/* 538 */     String hex = Integer.toString(num, 16);
/* 539 */     while (hex.length() < 4) {
/* 540 */       hex = "0" + hex;
/*     */     }
/* 542 */     String low = hex.substring(2, 4);
/* 543 */     String high = hex.substring(0, 2);
/*     */     
/* 545 */     val[0] = ((byte)Integer.parseInt(low, 16));
/* 546 */     val[1] = ((byte)Integer.parseInt(high, 16));
/* 547 */     return val;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getCredentialCharset()
/*     */   {
/* 554 */     return this.credentialCharset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setCredentialCharset(String credentialCharset)
/*     */   {
/* 561 */     this.credentialCharset = credentialCharset;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\auth\NTLM.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */