/*     */ package org.apache.commons.httpclient.methods;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InputStreamRequestEntity
/*     */   implements RequestEntity
/*     */ {
/*     */   public static final int CONTENT_LENGTH_AUTO = -2;
/*  54 */   private static final Log LOG = LogFactory.getLog(InputStreamRequestEntity.class);
/*     */   
/*     */ 
/*     */   private long contentLength;
/*     */   
/*     */   private InputStream content;
/*     */   
/*  61 */   private byte[] buffer = null;
/*     */   
/*     */ 
/*     */ 
/*     */   private String contentType;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputStreamRequestEntity(InputStream content)
/*     */   {
/*  72 */     this(content, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputStreamRequestEntity(InputStream content, String contentType)
/*     */   {
/*  82 */     this(content, -2L, contentType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputStreamRequestEntity(InputStream content, long contentLength)
/*     */   {
/*  93 */     this(content, contentLength, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputStreamRequestEntity(InputStream content, long contentLength, String contentType)
/*     */   {
/* 106 */     if (content == null) {
/* 107 */       throw new IllegalArgumentException("The content cannot be null");
/*     */     }
/* 109 */     this.content = content;
/* 110 */     this.contentLength = contentLength;
/* 111 */     this.contentType = contentType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getContentType()
/*     */   {
/* 118 */     return this.contentType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void bufferContent()
/*     */   {
/* 126 */     if (this.buffer != null)
/*     */     {
/* 128 */       return;
/*     */     }
/* 130 */     if (this.content != null) {
/*     */       try {
/* 132 */         ByteArrayOutputStream tmp = new ByteArrayOutputStream();
/* 133 */         byte[] data = new byte['က'];
/* 134 */         int l = 0;
/* 135 */         while ((l = this.content.read(data)) >= 0) {
/* 136 */           tmp.write(data, 0, l);
/*     */         }
/* 138 */         this.buffer = tmp.toByteArray();
/* 139 */         this.content = null;
/* 140 */         this.contentLength = this.buffer.length;
/*     */       } catch (IOException e) {
/* 142 */         LOG.error(e.getMessage(), e);
/* 143 */         this.buffer = null;
/* 144 */         this.content = null;
/* 145 */         this.contentLength = 0L;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRepeatable()
/*     */   {
/* 157 */     return this.buffer != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void writeRequest(OutputStream out)
/*     */     throws IOException
/*     */   {
/* 165 */     if (this.content != null) {
/* 166 */       byte[] tmp = new byte['က'];
/* 167 */       int total = 0;
/* 168 */       int i = 0;
/* 169 */       while ((i = this.content.read(tmp)) >= 0) {
/* 170 */         out.write(tmp, 0, i);
/* 171 */         total += i;
/*     */       }
/* 173 */     } else if (this.buffer != null) {
/* 174 */       out.write(this.buffer);
/*     */     } else {
/* 176 */       throw new IllegalStateException("Content must be set before entity is written");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getContentLength()
/*     */   {
/* 185 */     if ((this.contentLength == -2L) && (this.buffer == null)) {
/* 186 */       bufferContent();
/*     */     }
/* 188 */     return this.contentLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public InputStream getContent()
/*     */   {
/* 195 */     return this.content;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\methods\InputStreamRequestEntity.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */