/*     */ package org.apache.commons.httpclient.auth;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthState
/*     */ {
/*     */   public static final String PREEMPTIVE_AUTH_SCHEME = "basic";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  44 */   private AuthScheme authScheme = null;
/*     */   
/*     */ 
/*  47 */   private boolean authRequested = false;
/*     */   
/*     */ 
/*  50 */   private boolean authAttempted = false;
/*     */   
/*     */ 
/*  53 */   private boolean preemptive = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void invalidate()
/*     */   {
/*  67 */     this.authScheme = null;
/*  68 */     this.authRequested = false;
/*  69 */     this.authAttempted = false;
/*  70 */     this.preemptive = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAuthRequested()
/*     */   {
/*  80 */     return this.authRequested;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAuthRequested(boolean challengeReceived)
/*     */   {
/*  90 */     this.authRequested = challengeReceived;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAuthAttempted()
/*     */   {
/* 100 */     return this.authAttempted;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAuthAttempted(boolean challengeResponded)
/*     */   {
/* 110 */     this.authAttempted = challengeResponded;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPreemptive()
/*     */   {
/* 117 */     if (!this.preemptive) {
/* 118 */       if (this.authScheme != null) {
/* 119 */         throw new IllegalStateException("Authentication state already initialized");
/*     */       }
/* 121 */       this.authScheme = AuthPolicy.getAuthScheme("basic");
/* 122 */       this.preemptive = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPreemptive()
/*     */   {
/* 133 */     return this.preemptive;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAuthScheme(AuthScheme authScheme)
/*     */   {
/* 142 */     if (authScheme == null) {
/* 143 */       invalidate();
/* 144 */       return;
/*     */     }
/* 146 */     if ((this.preemptive) && (!this.authScheme.getClass().isInstance(authScheme))) {
/* 147 */       this.preemptive = false;
/* 148 */       this.authAttempted = false;
/*     */     }
/* 150 */     this.authScheme = authScheme;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AuthScheme getAuthScheme()
/*     */   {
/* 159 */     return this.authScheme;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRealm()
/*     */   {
/* 168 */     if (this.authScheme != null) {
/* 169 */       return this.authScheme.getRealm();
/*     */     }
/* 171 */     return null;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 176 */     StringBuffer buffer = new StringBuffer();
/* 177 */     buffer.append("Auth state: auth requested [");
/* 178 */     buffer.append(this.authRequested);
/* 179 */     buffer.append("]; auth attempted [");
/* 180 */     buffer.append(this.authAttempted);
/* 181 */     if (this.authScheme != null) {
/* 182 */       buffer.append("]; auth scheme [");
/* 183 */       buffer.append(this.authScheme.getSchemeName());
/* 184 */       buffer.append("]; realm [");
/* 185 */       buffer.append(this.authScheme.getRealm());
/*     */     }
/* 187 */     buffer.append("] preemptive [");
/* 188 */     buffer.append(this.preemptive);
/* 189 */     buffer.append("]");
/* 190 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\auth\AuthState.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */