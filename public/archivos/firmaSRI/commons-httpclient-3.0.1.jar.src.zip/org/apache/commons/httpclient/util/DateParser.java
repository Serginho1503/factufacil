/*     */ package org.apache.commons.httpclient.util;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ /**
/*     */  * @deprecated
/*     */  */
/*     */ public class DateParser
/*     */ {
/*     */   public static final String PATTERN_RFC1123 = "EEE, dd MMM yyyy HH:mm:ss zzz";
/*     */   public static final String PATTERN_RFC1036 = "EEEE, dd-MMM-yy HH:mm:ss zzz";
/*     */   public static final String PATTERN_ASCTIME = "EEE MMM d HH:mm:ss yyyy";
/*  69 */   private static final Collection DEFAULT_PATTERNS = Arrays.asList(new String[] { "EEE MMM d HH:mm:ss yyyy", "EEEE, dd-MMM-yy HH:mm:ss zzz", "EEE, dd MMM yyyy HH:mm:ss zzz" });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Date parseDate(String dateValue)
/*     */     throws DateParseException
/*     */   {
/*  83 */     return parseDate(dateValue, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Date parseDate(String dateValue, Collection dateFormats)
/*     */     throws DateParseException
/*     */   {
/* 101 */     if (dateValue == null) {
/* 102 */       throw new IllegalArgumentException("dateValue is null");
/*     */     }
/* 104 */     if (dateFormats == null) {
/* 105 */       dateFormats = DEFAULT_PATTERNS;
/*     */     }
/*     */     
/*     */ 
/* 109 */     if ((dateValue.length() > 1) && (dateValue.startsWith("'")) && (dateValue.endsWith("'")))
/*     */     {
/*     */ 
/*     */ 
/* 113 */       dateValue = dateValue.substring(1, dateValue.length() - 1);
/*     */     }
/*     */     
/* 116 */     SimpleDateFormat dateParser = null;
/* 117 */     Iterator formatIter = dateFormats.iterator();
/*     */     
/* 119 */     while (formatIter.hasNext()) {
/* 120 */       String format = (String)formatIter.next();
/* 121 */       if (dateParser == null) {
/* 122 */         dateParser = new SimpleDateFormat(format, Locale.US);
/* 123 */         dateParser.setTimeZone(TimeZone.getTimeZone("GMT"));
/*     */       } else {
/* 125 */         dateParser.applyPattern(format);
/*     */       }
/*     */       try {
/* 128 */         return dateParser.parse(dateValue);
/*     */       }
/*     */       catch (ParseException pe) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 135 */     throw new DateParseException("Unable to parse the date " + dateValue);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\util\DateParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */