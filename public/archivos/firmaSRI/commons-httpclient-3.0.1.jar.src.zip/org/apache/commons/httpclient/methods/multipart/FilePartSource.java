/*     */ package org.apache.commons.httpclient.methods.multipart;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilePartSource
/*     */   implements PartSource
/*     */ {
/*  51 */   private File file = null;
/*     */   
/*     */ 
/*  54 */   private String fileName = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FilePartSource(File file)
/*     */     throws FileNotFoundException
/*     */   {
/*  65 */     this.file = file;
/*  66 */     if (file != null) {
/*  67 */       if (!file.isFile()) {
/*  68 */         throw new FileNotFoundException("File is not a normal file.");
/*     */       }
/*  70 */       if (!file.canRead()) {
/*  71 */         throw new FileNotFoundException("File is not readable.");
/*     */       }
/*  73 */       this.fileName = file.getName();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FilePartSource(String fileName, File file)
/*     */     throws FileNotFoundException
/*     */   {
/*  88 */     this(file);
/*  89 */     if (fileName != null) {
/*  90 */       this.fileName = fileName;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getLength()
/*     */   {
/* 100 */     if (this.file != null) {
/* 101 */       return this.file.length();
/*     */     }
/* 103 */     return 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFileName()
/*     */   {
/* 113 */     return this.fileName == null ? "noname" : this.fileName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputStream createInputStream()
/*     */     throws IOException
/*     */   {
/* 123 */     if (this.file != null) {
/* 124 */       return new FileInputStream(this.file);
/*     */     }
/* 126 */     return new ByteArrayInputStream(new byte[0]);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\methods\multipart\FilePartSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */