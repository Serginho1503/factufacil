/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.security.Provider;
/*     */ import java.security.Security;
/*     */ import org.apache.commons.httpclient.params.DefaultHttpParams;
/*     */ import org.apache.commons.httpclient.params.HttpClientParams;
/*     */ import org.apache.commons.httpclient.params.HttpConnectionParams;
/*     */ import org.apache.commons.httpclient.params.HttpMethodParams;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpClient
/*     */ {
/*  65 */   private static final Log LOG = LogFactory.getLog(HttpClient.class);
/*     */   private HttpConnectionManager httpConnectionManager;
/*     */   
/*     */   static {
/*  69 */     if (LOG.isDebugEnabled()) {
/*     */       try {
/*  71 */         LOG.debug("Java version: " + System.getProperty("java.version"));
/*  72 */         LOG.debug("Java vendor: " + System.getProperty("java.vendor"));
/*  73 */         LOG.debug("Java class path: " + System.getProperty("java.class.path"));
/*  74 */         LOG.debug("Operating system name: " + System.getProperty("os.name"));
/*  75 */         LOG.debug("Operating system architecture: " + System.getProperty("os.arch"));
/*  76 */         LOG.debug("Operating system version: " + System.getProperty("os.version"));
/*     */         
/*  78 */         Provider[] providers = Security.getProviders();
/*  79 */         for (int i = 0; i < providers.length; i++) {
/*  80 */           Provider provider = providers[i];
/*  81 */           LOG.debug(provider.getName() + " " + provider.getVersion() + ": " + provider.getInfo());
/*     */         }
/*     */       }
/*     */       catch (SecurityException ignore) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpClient()
/*     */   {
/*  96 */     this(new HttpClientParams());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpClient(HttpClientParams params)
/*     */   {
/* 111 */     if (params == null) {
/* 112 */       throw new IllegalArgumentException("Params may not be null");
/*     */     }
/* 114 */     this.params = params;
/* 115 */     this.httpConnectionManager = null;
/* 116 */     Class clazz = params.getConnectionManagerClass();
/* 117 */     if (clazz != null) {
/*     */       try {
/* 119 */         this.httpConnectionManager = ((HttpConnectionManager)clazz.newInstance());
/*     */       } catch (Exception e) {
/* 121 */         LOG.warn("Error instantiating connection manager class, defaulting to SimpleHttpConnectionManager", e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 126 */     if (this.httpConnectionManager == null) {
/* 127 */       this.httpConnectionManager = new SimpleHttpConnectionManager();
/*     */     }
/* 129 */     if (this.httpConnectionManager != null) {
/* 130 */       this.httpConnectionManager.getParams().setDefaults(this.params);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpClient(HttpClientParams params, HttpConnectionManager httpConnectionManager)
/*     */   {
/* 147 */     if (httpConnectionManager == null) {
/* 148 */       throw new IllegalArgumentException("httpConnectionManager cannot be null");
/*     */     }
/* 150 */     if (params == null) {
/* 151 */       throw new IllegalArgumentException("Params may not be null");
/*     */     }
/* 153 */     this.params = params;
/* 154 */     this.httpConnectionManager = httpConnectionManager;
/* 155 */     if (this.httpConnectionManager != null) {
/* 156 */       this.httpConnectionManager.getParams().setDefaults(this.params);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpClient(HttpConnectionManager httpConnectionManager)
/*     */   {
/* 170 */     this(new HttpClientParams(), httpConnectionManager);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 184 */   private HttpState state = new HttpState();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 189 */   private HttpClientParams params = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 195 */   private HostConfiguration hostConfiguration = new HostConfiguration();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized HttpState getState()
/*     */   {
/* 206 */     return this.state;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setState(HttpState state)
/*     */   {
/* 216 */     this.state = state;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public synchronized void setStrictMode(boolean strictMode)
/*     */   {
/* 236 */     if (strictMode) {
/* 237 */       this.params.makeStrict();
/*     */     } else {
/* 239 */       this.params.makeLenient();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public synchronized boolean isStrictMode()
/*     */   {
/* 255 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public synchronized void setTimeout(int newTimeoutInMilliseconds)
/*     */   {
/* 271 */     this.params.setSoTimeout(newTimeoutInMilliseconds);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public synchronized void setHttpConnectionFactoryTimeout(long timeout)
/*     */   {
/* 288 */     this.params.setConnectionManagerTimeout(timeout);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public synchronized void setConnectionTimeout(int newTimeoutInMilliseconds)
/*     */   {
/* 303 */     this.httpConnectionManager.getParams().setConnectionTimeout(newTimeoutInMilliseconds);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int executeMethod(HttpMethod method)
/*     */     throws IOException, HttpException
/*     */   {
/* 322 */     LOG.trace("enter HttpClient.executeMethod(HttpMethod)");
/*     */     
/* 324 */     return executeMethod(null, method, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int executeMethod(HostConfiguration hostConfiguration, HttpMethod method)
/*     */     throws IOException, HttpException
/*     */   {
/* 344 */     LOG.trace("enter HttpClient.executeMethod(HostConfiguration,HttpMethod)");
/*     */     
/* 346 */     return executeMethod(hostConfiguration, method, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int executeMethod(HostConfiguration hostconfig, HttpMethod method, HttpState state)
/*     */     throws IOException, HttpException
/*     */   {
/* 373 */     LOG.trace("enter HttpClient.executeMethod(HostConfiguration,HttpMethod,HttpState)");
/*     */     
/* 375 */     if (method == null) {
/* 376 */       throw new IllegalArgumentException("HttpMethod parameter may not be null");
/*     */     }
/* 378 */     HostConfiguration defaulthostconfig = getHostConfiguration();
/* 379 */     if (hostconfig == null) {
/* 380 */       hostconfig = defaulthostconfig;
/*     */     }
/* 382 */     URI uri = method.getURI();
/* 383 */     if ((hostconfig == defaulthostconfig) || (uri.isAbsoluteURI()))
/*     */     {
/* 385 */       hostconfig = new HostConfiguration(hostconfig);
/* 386 */       if (uri.isAbsoluteURI()) {
/* 387 */         hostconfig.setHost(uri);
/*     */       }
/*     */     }
/*     */     
/* 391 */     HttpMethodDirector methodDirector = new HttpMethodDirector(getHttpConnectionManager(), hostconfig, this.params, state == null ? getState() : state);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 396 */     methodDirector.executeMethod(method);
/* 397 */     return method.getStatusCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public String getHost()
/*     */   {
/* 408 */     return this.hostConfiguration.getHost();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public int getPort()
/*     */   {
/* 419 */     return this.hostConfiguration.getPort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized HostConfiguration getHostConfiguration()
/*     */   {
/* 431 */     return this.hostConfiguration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setHostConfiguration(HostConfiguration hostConfiguration)
/*     */   {
/* 443 */     this.hostConfiguration = hostConfiguration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized HttpConnectionManager getHttpConnectionManager()
/*     */   {
/* 455 */     return this.httpConnectionManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setHttpConnectionManager(HttpConnectionManager httpConnectionManager)
/*     */   {
/* 470 */     this.httpConnectionManager = httpConnectionManager;
/* 471 */     if (this.httpConnectionManager != null) {
/* 472 */       this.httpConnectionManager.getParams().setDefaults(this.params);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpClientParams getParams()
/*     */   {
/* 484 */     return this.params;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParams(HttpClientParams params)
/*     */   {
/* 495 */     if (params == null) {
/* 496 */       throw new IllegalArgumentException("Parameters may not be null");
/*     */     }
/* 498 */     this.params = params;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\HttpClient.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */