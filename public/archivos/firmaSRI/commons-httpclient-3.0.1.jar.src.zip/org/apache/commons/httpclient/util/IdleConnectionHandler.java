/*     */ package org.apache.commons.httpclient.util;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.httpclient.HttpConnection;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IdleConnectionHandler
/*     */ {
/*  50 */   private static final Log LOG = LogFactory.getLog(IdleConnectionHandler.class);
/*     */   
/*     */ 
/*  53 */   private Map connectionToAdded = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(HttpConnection connection)
/*     */   {
/*  72 */     Long timeAdded = new Long(System.currentTimeMillis());
/*     */     
/*  74 */     if (LOG.isDebugEnabled()) {
/*  75 */       LOG.debug("Adding connection at: " + timeAdded);
/*     */     }
/*     */     
/*  78 */     this.connectionToAdded.put(connection, timeAdded);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void remove(HttpConnection connection)
/*     */   {
/*  86 */     this.connectionToAdded.remove(connection);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void removeAll()
/*     */   {
/*  93 */     this.connectionToAdded.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void closeIdleConnections(long idleTime)
/*     */   {
/* 104 */     long idleTimeout = System.currentTimeMillis() - idleTime;
/*     */     
/* 106 */     if (LOG.isDebugEnabled()) {
/* 107 */       LOG.debug("Checking for connections, idleTimeout: " + idleTimeout);
/*     */     }
/*     */     
/* 110 */     Iterator connectionIter = this.connectionToAdded.keySet().iterator();
/*     */     
/* 112 */     while (connectionIter.hasNext()) {
/* 113 */       HttpConnection conn = (HttpConnection)connectionIter.next();
/* 114 */       Long connectionTime = (Long)this.connectionToAdded.get(conn);
/* 115 */       if (connectionTime.longValue() <= idleTimeout) {
/* 116 */         if (LOG.isDebugEnabled()) {
/* 117 */           LOG.debug("Closing connection, connection time: " + connectionTime);
/*     */         }
/* 119 */         connectionIter.remove();
/* 120 */         conn.close();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\util\IdleConnectionHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */