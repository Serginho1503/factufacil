/*     */ package org.apache.commons.httpclient.util;
/*     */ 
/*     */ import java.io.InterruptedIOException;
/*     */ import java.lang.reflect.Method;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExceptionUtil
/*     */ {
/*  48 */   private static final Log LOG = LogFactory.getLog(ExceptionUtil.class);
/*     */   
/*     */ 
/*  51 */   private static final Method INIT_CAUSE_METHOD = getInitCauseMethod();
/*     */   
/*     */ 
/*  54 */   private static final Class SOCKET_TIMEOUT_CLASS = SocketTimeoutExceptionClass();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Method getInitCauseMethod()
/*     */   {
/*     */     try
/*     */     {
/*  67 */       Class[] paramsClasses = { Throwable.class };
/*  68 */       return Throwable.class.getMethod("initCause", paramsClasses);
/*     */     } catch (NoSuchMethodException e) {}
/*  70 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Class SocketTimeoutExceptionClass()
/*     */   {
/*     */     try
/*     */     {
/*  82 */       return Class.forName("java.net.SocketTimeoutException");
/*     */     } catch (ClassNotFoundException e) {}
/*  84 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void initCause(Throwable throwable, Throwable cause)
/*     */   {
/*  95 */     if (INIT_CAUSE_METHOD != null) {
/*     */       try {
/*  97 */         INIT_CAUSE_METHOD.invoke(throwable, new Object[] { cause });
/*     */       } catch (Exception e) {
/*  99 */         LOG.warn("Exception invoking Throwable.initCause", e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isSocketTimeoutException(InterruptedIOException e)
/*     */   {
/* 115 */     if (SOCKET_TIMEOUT_CLASS != null) {
/* 116 */       return SOCKET_TIMEOUT_CLASS.isInstance(e);
/*     */     }
/* 118 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\util\ExceptionUtil.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */