/*    */ package org.apache.commons.httpclient;
/*    */ 
/*    */ import java.io.InterruptedIOException;
/*    */ import org.apache.commons.httpclient.util.ExceptionUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConnectTimeoutException
/*    */   extends InterruptedIOException
/*    */ {
/*    */   public ConnectTimeoutException() {}
/*    */   
/*    */   public ConnectTimeoutException(String message)
/*    */   {
/* 59 */     super(message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ConnectTimeoutException(String message, Throwable cause)
/*    */   {
/* 70 */     super(message);
/*    */     
/* 72 */     ExceptionUtil.initCause(this, cause);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\ConnectTimeoutException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */