/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InterruptedIOException;
/*     */ import java.net.NoRouteToHostException;
/*     */ import java.net.UnknownHostException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultHttpMethodRetryHandler
/*     */   implements HttpMethodRetryHandler
/*     */ {
/*  46 */   private static Class SSL_HANDSHAKE_EXCEPTION = null;
/*     */   private int retryCount;
/*     */   private boolean requestSentRetryEnabled;
/*     */   
/*  50 */   static { try { SSL_HANDSHAKE_EXCEPTION = Class.forName("javax.net.ssl.SSLHandshakeException");
/*     */     }
/*     */     catch (ClassNotFoundException ignore) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultHttpMethodRetryHandler(int retryCount, boolean requestSentRetryEnabled)
/*     */   {
/*  67 */     this.retryCount = retryCount;
/*  68 */     this.requestSentRetryEnabled = requestSentRetryEnabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultHttpMethodRetryHandler()
/*     */   {
/*  76 */     this(3, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean retryMethod(HttpMethod method, IOException exception, int executionCount)
/*     */   {
/*  88 */     if (method == null) {
/*  89 */       throw new IllegalArgumentException("HTTP method may not be null");
/*     */     }
/*  91 */     if (exception == null) {
/*  92 */       throw new IllegalArgumentException("Exception parameter may not be null");
/*     */     }
/*     */     
/*  95 */     if (((method instanceof HttpMethodBase)) && 
/*  96 */       (((HttpMethodBase)method).isAborted())) {
/*  97 */       return false;
/*     */     }
/*     */     
/* 100 */     if (executionCount > this.retryCount)
/*     */     {
/* 102 */       return false;
/*     */     }
/* 104 */     if ((exception instanceof NoHttpResponseException))
/*     */     {
/* 106 */       return true;
/*     */     }
/* 108 */     if ((exception instanceof InterruptedIOException))
/*     */     {
/* 110 */       return false;
/*     */     }
/* 112 */     if ((exception instanceof UnknownHostException))
/*     */     {
/* 114 */       return false;
/*     */     }
/* 116 */     if ((exception instanceof NoRouteToHostException))
/*     */     {
/* 118 */       return false;
/*     */     }
/* 120 */     if ((SSL_HANDSHAKE_EXCEPTION != null) && (SSL_HANDSHAKE_EXCEPTION.isInstance(exception)))
/*     */     {
/* 122 */       return false;
/*     */     }
/* 124 */     if ((!method.isRequestSent()) || (this.requestSentRetryEnabled))
/*     */     {
/*     */ 
/* 127 */       return true;
/*     */     }
/*     */     
/* 130 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRequestSentRetryEnabled()
/*     */   {
/* 138 */     return this.requestSentRetryEnabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getRetryCount()
/*     */   {
/* 145 */     return this.retryCount;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\DefaultHttpMethodRetryHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */