/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpVersion
/*     */   implements Comparable
/*     */ {
/*  73 */   private int major = 0;
/*     */   
/*     */ 
/*  76 */   private int minor = 0;
/*     */   
/*     */ 
/*  79 */   public static final HttpVersion HTTP_0_9 = new HttpVersion(0, 9);
/*     */   
/*     */ 
/*  82 */   public static final HttpVersion HTTP_1_0 = new HttpVersion(1, 0);
/*     */   
/*     */ 
/*  85 */   public static final HttpVersion HTTP_1_1 = new HttpVersion(1, 1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpVersion(int major, int minor)
/*     */   {
/*  96 */     if (major < 0) {
/*  97 */       throw new IllegalArgumentException("HTTP major version number may not be negative");
/*     */     }
/*  99 */     this.major = major;
/* 100 */     if (minor < 0) {
/* 101 */       throw new IllegalArgumentException("HTTP minor version number may not be negative");
/*     */     }
/* 103 */     this.minor = minor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMajor()
/*     */   {
/* 112 */     return this.major;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMinor()
/*     */   {
/* 121 */     return this.minor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 128 */     return this.major * 100000 + this.minor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 135 */     if (this == obj) {
/* 136 */       return true;
/*     */     }
/* 138 */     if (!(obj instanceof HttpVersion)) {
/* 139 */       return false;
/*     */     }
/* 141 */     return equals((HttpVersion)obj);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int compareTo(HttpVersion anotherVer)
/*     */   {
/* 153 */     if (anotherVer == null) {
/* 154 */       throw new IllegalArgumentException("Version parameter may not be null");
/*     */     }
/* 156 */     int delta = getMajor() - anotherVer.getMajor();
/* 157 */     if (delta == 0) {
/* 158 */       delta = getMinor() - anotherVer.getMinor();
/*     */     }
/* 160 */     return delta;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int compareTo(Object o)
/*     */   {
/* 167 */     return compareTo((HttpVersion)o);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(HttpVersion version)
/*     */   {
/* 177 */     return compareTo(version) == 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean greaterEquals(HttpVersion version)
/*     */   {
/* 187 */     return compareTo(version) >= 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean lessEquals(HttpVersion version)
/*     */   {
/* 197 */     return compareTo(version) <= 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 204 */     StringBuffer buffer = new StringBuffer();
/* 205 */     buffer.append("HTTP/");
/* 206 */     buffer.append(this.major);
/* 207 */     buffer.append('.');
/* 208 */     buffer.append(this.minor);
/* 209 */     return buffer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HttpVersion parse(String s)
/*     */     throws ProtocolException
/*     */   {
/* 220 */     if (s == null) {
/* 221 */       throw new IllegalArgumentException("String may not be null");
/*     */     }
/* 223 */     if (!s.startsWith("HTTP/")) {
/* 224 */       throw new ProtocolException("Invalid HTTP version string: " + s);
/*     */     }
/*     */     
/*     */ 
/* 228 */     int i1 = "HTTP/".length();
/* 229 */     int i2 = s.indexOf(".", i1);
/* 230 */     if (i2 == -1)
/* 231 */       throw new ProtocolException("Invalid HTTP version number: " + s);
/*     */     int major;
/*     */     try {
/* 234 */       major = Integer.parseInt(s.substring(i1, i2));
/*     */     } catch (NumberFormatException e) {
/* 236 */       throw new ProtocolException("Invalid HTTP major version number: " + s);
/*     */     }
/* 238 */     i1 = i2 + 1;
/* 239 */     i2 = s.length();
/*     */     int minor;
/* 241 */     try { minor = Integer.parseInt(s.substring(i1, i2));
/*     */     } catch (NumberFormatException e) {
/* 243 */       throw new ProtocolException("Invalid HTTP minor version number: " + s);
/*     */     }
/* 245 */     return new HttpVersion(major, minor);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\HttpVersion.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */