/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Wire
/*     */ {
/*  47 */   public static Wire HEADER_WIRE = new Wire(LogFactory.getLog("httpclient.wire.header"));
/*     */   
/*  49 */   public static Wire CONTENT_WIRE = new Wire(LogFactory.getLog("httpclient.wire.content"));
/*     */   
/*     */   private Log log;
/*     */   
/*     */   private Wire(Log log)
/*     */   {
/*  55 */     this.log = log;
/*     */   }
/*     */   
/*     */   private void wire(String header, InputStream instream) throws IOException
/*     */   {
/*  60 */     StringBuffer buffer = new StringBuffer();
/*     */     int ch;
/*  62 */     while ((ch = instream.read()) != -1) { int i;
/*  63 */       if (i == 13) {
/*  64 */         buffer.append("[\\r]");
/*  65 */       } else if (i == 10) {
/*  66 */         buffer.append("[\\n]\"");
/*  67 */         buffer.insert(0, "\"");
/*  68 */         buffer.insert(0, header);
/*  69 */         this.log.debug(buffer.toString());
/*  70 */         buffer.setLength(0);
/*  71 */       } else if ((i < 32) || (i > 127)) {
/*  72 */         buffer.append("[0x");
/*  73 */         buffer.append(Integer.toHexString(i));
/*  74 */         buffer.append("]");
/*     */       } else {
/*  76 */         buffer.append((char)i);
/*     */       }
/*     */     }
/*  79 */     if (buffer.length() > 0) {
/*  80 */       buffer.append("\"");
/*  81 */       buffer.insert(0, "\"");
/*  82 */       buffer.insert(0, header);
/*  83 */       this.log.debug(buffer.toString());
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean enabled()
/*     */   {
/*  89 */     return this.log.isDebugEnabled();
/*     */   }
/*     */   
/*     */   public void output(InputStream outstream) throws IOException
/*     */   {
/*  94 */     if (outstream == null) {
/*  95 */       throw new IllegalArgumentException("Output may not be null");
/*     */     }
/*  97 */     wire(">> ", outstream);
/*     */   }
/*     */   
/*     */   public void input(InputStream instream) throws IOException
/*     */   {
/* 102 */     if (instream == null) {
/* 103 */       throw new IllegalArgumentException("Input may not be null");
/*     */     }
/* 105 */     wire("<< ", instream);
/*     */   }
/*     */   
/*     */   public void output(byte[] b, int off, int len) throws IOException
/*     */   {
/* 110 */     if (b == null) {
/* 111 */       throw new IllegalArgumentException("Output may not be null");
/*     */     }
/* 113 */     wire(">> ", new ByteArrayInputStream(b, off, len));
/*     */   }
/*     */   
/*     */   public void input(byte[] b, int off, int len) throws IOException
/*     */   {
/* 118 */     if (b == null) {
/* 119 */       throw new IllegalArgumentException("Input may not be null");
/*     */     }
/* 121 */     wire("<< ", new ByteArrayInputStream(b, off, len));
/*     */   }
/*     */   
/*     */   public void output(byte[] b) throws IOException
/*     */   {
/* 126 */     if (b == null) {
/* 127 */       throw new IllegalArgumentException("Output may not be null");
/*     */     }
/* 129 */     wire(">> ", new ByteArrayInputStream(b));
/*     */   }
/*     */   
/*     */   public void input(byte[] b) throws IOException
/*     */   {
/* 134 */     if (b == null) {
/* 135 */       throw new IllegalArgumentException("Input may not be null");
/*     */     }
/* 137 */     wire("<< ", new ByteArrayInputStream(b));
/*     */   }
/*     */   
/*     */   public void output(int b) throws IOException
/*     */   {
/* 142 */     output(new byte[] { (byte)b });
/*     */   }
/*     */   
/*     */   public void input(int b) throws IOException
/*     */   {
/* 147 */     input(new byte[] { (byte)b });
/*     */   }
/*     */   
/*     */   public void output(String s) throws IOException
/*     */   {
/* 152 */     if (s == null) {
/* 153 */       throw new IllegalArgumentException("Output may not be null");
/*     */     }
/* 155 */     output(s.getBytes());
/*     */   }
/*     */   
/*     */   public void input(String s) throws IOException
/*     */   {
/* 160 */     if (s == null) {
/* 161 */       throw new IllegalArgumentException("Input may not be null");
/*     */     }
/* 163 */     input(s.getBytes());
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\Wire.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */