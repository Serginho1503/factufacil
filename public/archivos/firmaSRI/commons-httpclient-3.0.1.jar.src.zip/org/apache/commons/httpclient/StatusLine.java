/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StatusLine
/*     */ {
/*     */   private final String statusLine;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String httpVersion;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int statusCode;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String reasonPhrase;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StatusLine(String statusLine)
/*     */     throws HttpException
/*     */   {
/*  83 */     int length = statusLine.length();
/*  84 */     int at = 0;
/*  85 */     int start = 0;
/*     */     try {
/*  87 */       while (Character.isWhitespace(statusLine.charAt(at))) {
/*  88 */         at++;
/*  89 */         start++;
/*     */       }
/*  91 */       if (!"HTTP".equals(statusLine.substring(, at))) {
/*  92 */         throw new HttpException("Status-Line '" + statusLine + "' does not start with HTTP");
/*     */       }
/*     */       
/*     */ 
/*  96 */       at = statusLine.indexOf(" ", at);
/*  97 */       if (at <= 0) {
/*  98 */         throw new ProtocolException("Unable to parse HTTP-Version from the status line: '" + statusLine + "'");
/*     */       }
/*     */       
/*     */ 
/* 102 */       this.httpVersion = statusLine.substring(start, at).toUpperCase();
/*     */       
/*     */ 
/* 105 */       while (statusLine.charAt(at) == ' ') {
/* 106 */         at++;
/*     */       }
/*     */       
/*     */ 
/* 110 */       int to = statusLine.indexOf(" ", at);
/* 111 */       if (to < 0) {
/* 112 */         to = length;
/*     */       }
/*     */       try {
/* 115 */         this.statusCode = Integer.parseInt(statusLine.substring(at, to));
/*     */       } catch (NumberFormatException e) {
/* 117 */         throw new ProtocolException("Unable to parse status code from status line: '" + statusLine + "'");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 122 */       at = to + 1;
/* 123 */       if (at < length) {
/* 124 */         this.reasonPhrase = statusLine.substring(at).trim();
/*     */       } else {
/* 126 */         this.reasonPhrase = "";
/*     */       }
/*     */     } catch (StringIndexOutOfBoundsException e) {
/* 129 */       throw new HttpException("Status-Line '" + statusLine + "' is not valid");
/*     */     }
/*     */     
/* 132 */     this.statusLine = statusLine;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getStatusCode()
/*     */   {
/* 142 */     return this.statusCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final String getHttpVersion()
/*     */   {
/* 149 */     return this.httpVersion;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final String getReasonPhrase()
/*     */   {
/* 156 */     return this.reasonPhrase;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String toString()
/*     */   {
/* 164 */     return this.statusLine;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean startsWithHTTP(String s)
/*     */   {
/*     */     try
/*     */     {
/* 175 */       int at = 0;
/* 176 */       while (Character.isWhitespace(s.charAt(at))) {
/* 177 */         at++;
/*     */       }
/* 179 */       return "HTTP".equals(s.substring(at, at + 4));
/*     */     } catch (StringIndexOutOfBoundsException e) {}
/* 181 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\StatusLine.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */