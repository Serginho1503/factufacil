package org.apache.commons.httpclient.protocol;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

public abstract interface SecureProtocolSocketFactory
  extends ProtocolSocketFactory
{
  public abstract Socket createSocket(Socket paramSocket, String paramString, int paramInt, boolean paramBoolean)
    throws IOException, UnknownHostException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\protocol\SecureProtocolSocketFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */