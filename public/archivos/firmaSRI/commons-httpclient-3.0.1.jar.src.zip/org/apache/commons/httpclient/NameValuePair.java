/*     */ package org.apache.commons.httpclient;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.apache.commons.httpclient.util.LangUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NameValuePair
/*     */   implements Serializable
/*     */ {
/*     */   public NameValuePair()
/*     */   {
/*  55 */     this(null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NameValuePair(String name, String value)
/*     */   {
/*  64 */     this.name = name;
/*  65 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  73 */   private String name = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  78 */   private String value = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/*  89 */     this.name = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 100 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValue(String value)
/*     */   {
/* 110 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getValue()
/*     */   {
/* 120 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 130 */     return "name=" + this.name + ", " + "value=" + this.value;
/*     */   }
/*     */   
/*     */   public boolean equals(Object object) {
/* 134 */     if (object == null) return false;
/* 135 */     if (this == object) return true;
/* 136 */     if ((object instanceof NameValuePair)) {
/* 137 */       NameValuePair that = (NameValuePair)object;
/* 138 */       return (LangUtils.equals(this.name, that.name)) && (LangUtils.equals(this.value, that.value));
/*     */     }
/*     */     
/* 141 */     return false;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 146 */     int hash = 17;
/* 147 */     hash = LangUtils.hashCode(hash, this.name);
/* 148 */     hash = LangUtils.hashCode(hash, this.value);
/* 149 */     return hash;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\NameValuePair.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */