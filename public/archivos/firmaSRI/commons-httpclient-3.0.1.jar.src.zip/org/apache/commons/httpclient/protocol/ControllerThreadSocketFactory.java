/*     */ package org.apache.commons.httpclient.protocol;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.UnknownHostException;
/*     */ import org.apache.commons.httpclient.ConnectTimeoutException;
/*     */ import org.apache.commons.httpclient.util.TimeoutController;
/*     */ import org.apache.commons.httpclient.util.TimeoutController.TimeoutException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ControllerThreadSocketFactory
/*     */ {
/*     */   public static Socket createSocket(ProtocolSocketFactory socketfactory, String host, int port, InetAddress localAddress, int localPort, int timeout)
/*     */     throws IOException, UnknownHostException, ConnectTimeoutException
/*     */   {
/*  88 */     SocketTask task = new SocketTask() { private final ProtocolSocketFactory val$socketfactory;
/*     */       
/*  90 */       public void doit() throws IOException { setSocket(this.val$socketfactory.createSocket(this.val$host, this.val$port, this.val$localAddress, this.val$localPort)); }
/*     */     };
/*     */     try
/*     */     {
/*  94 */       TimeoutController.execute(task, timeout);
/*     */     } catch (TimeoutController.TimeoutException e) {
/*  96 */       throw new ConnectTimeoutException("The host did not accept the connection within timeout of " + timeout + " ms");
/*     */     }
/*     */     
/*     */ 
/* 100 */     Socket socket = task.getSocket();
/* 101 */     if (task.exception != null) {
/* 102 */       throw task.exception;
/*     */     }
/* 104 */     return socket;
/*     */   }
/*     */   
/*     */   public static Socket createSocket(SocketTask task, int timeout) throws IOException, UnknownHostException, ConnectTimeoutException
/*     */   {
/*     */     try
/*     */     {
/* 111 */       TimeoutController.execute(task, timeout);
/*     */     } catch (TimeoutController.TimeoutException e) {
/* 113 */       throw new ConnectTimeoutException("The host did not accept the connection within timeout of " + timeout + " ms");
/*     */     }
/*     */     
/*     */ 
/* 117 */     Socket socket = task.getSocket();
/* 118 */     if (task.exception != null) {
/* 119 */       throw task.exception;
/*     */     }
/* 121 */     return socket;
/*     */   }
/*     */   
/*     */ 
/*     */   private final String val$host;
/*     */   
/*     */   private final int val$port;
/*     */   private final InetAddress val$localAddress;
/*     */   private final int val$localPort;
/*     */   public static abstract class SocketTask
/*     */     implements Runnable
/*     */   {
/*     */     private Socket socket;
/*     */     private IOException exception;
/*     */     
/*     */     protected void setSocket(Socket newSocket)
/*     */     {
/* 138 */       this.socket = newSocket;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected Socket getSocket()
/*     */     {
/* 146 */       return this.socket;
/*     */     }
/*     */     
/*     */ 
/*     */     public abstract void doit()
/*     */       throws IOException;
/*     */     
/*     */     public void run()
/*     */     {
/*     */       try
/*     */       {
/* 157 */         doit();
/*     */       } catch (IOException e) {
/* 159 */         this.exception = e;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\protocol\ControllerThreadSocketFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */