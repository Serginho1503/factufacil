package org.apache.commons.httpclient;

abstract interface ResponseConsumedWatcher
{
  public abstract void responseConsumed();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\ResponseConsumedWatcher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */