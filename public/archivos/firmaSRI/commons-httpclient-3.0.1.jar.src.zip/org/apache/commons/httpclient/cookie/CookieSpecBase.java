/*     */ package org.apache.commons.httpclient.cookie;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.httpclient.Cookie;
/*     */ import org.apache.commons.httpclient.Header;
/*     */ import org.apache.commons.httpclient.HeaderElement;
/*     */ import org.apache.commons.httpclient.NameValuePair;
/*     */ import org.apache.commons.httpclient.util.DateParseException;
/*     */ import org.apache.commons.httpclient.util.DateUtil;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CookieSpecBase
/*     */   implements CookieSpec
/*     */ {
/*  66 */   protected static final Log LOG = LogFactory.getLog(CookieSpec.class);
/*     */   
/*     */ 
/*  69 */   private Collection datepatterns = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cookie[] parse(String host, int port, String path, boolean secure, String header)
/*     */     throws MalformedCookieException
/*     */   {
/* 112 */     LOG.trace("enter CookieSpecBase.parse(String, port, path, boolean, Header)");
/*     */     
/*     */ 
/* 115 */     if (host == null) {
/* 116 */       throw new IllegalArgumentException("Host of origin may not be null");
/*     */     }
/*     */     
/* 119 */     if (host.trim().equals("")) {
/* 120 */       throw new IllegalArgumentException("Host of origin may not be blank");
/*     */     }
/*     */     
/* 123 */     if (port < 0) {
/* 124 */       throw new IllegalArgumentException("Invalid port: " + port);
/*     */     }
/* 126 */     if (path == null) {
/* 127 */       throw new IllegalArgumentException("Path of origin may not be null.");
/*     */     }
/*     */     
/* 130 */     if (header == null) {
/* 131 */       throw new IllegalArgumentException("Header may not be null.");
/*     */     }
/*     */     
/* 134 */     if (path.trim().equals("")) {
/* 135 */       path = "/";
/*     */     }
/* 137 */     host = host.toLowerCase();
/*     */     
/* 139 */     String defaultPath = path;
/* 140 */     int lastSlashIndex = defaultPath.lastIndexOf("/");
/* 141 */     if (lastSlashIndex >= 0) {
/* 142 */       if (lastSlashIndex == 0)
/*     */       {
/* 144 */         lastSlashIndex = 1;
/*     */       }
/* 146 */       defaultPath = defaultPath.substring(0, lastSlashIndex);
/*     */     }
/*     */     
/* 149 */     HeaderElement[] headerElements = null;
/*     */     
/* 151 */     boolean isNetscapeCookie = false;
/* 152 */     int i1 = header.toLowerCase().indexOf("expires=");
/* 153 */     if (i1 != -1) {
/* 154 */       i1 += "expires=".length();
/* 155 */       int i2 = header.indexOf(";", i1);
/* 156 */       if (i2 == -1) {
/* 157 */         i2 = header.length();
/*     */       }
/*     */       try {
/* 160 */         DateUtil.parseDate(header.substring(i1, i2), this.datepatterns);
/* 161 */         isNetscapeCookie = true;
/*     */       }
/*     */       catch (DateParseException e) {}
/*     */     }
/*     */     
/* 166 */     if (isNetscapeCookie) {
/* 167 */       headerElements = new HeaderElement[] { new HeaderElement(header.toCharArray()) };
/*     */     }
/*     */     else
/*     */     {
/* 171 */       headerElements = HeaderElement.parseElements(header.toCharArray());
/*     */     }
/*     */     
/* 174 */     Cookie[] cookies = new Cookie[headerElements.length];
/*     */     
/* 176 */     for (int i = 0; i < headerElements.length; i++)
/*     */     {
/* 178 */       HeaderElement headerelement = headerElements[i];
/* 179 */       Cookie cookie = null;
/*     */       try {
/* 181 */         cookie = new Cookie(host, headerelement.getName(), headerelement.getValue(), defaultPath, null, false);
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (IllegalArgumentException e)
/*     */       {
/*     */ 
/* 188 */         throw new MalformedCookieException(e.getMessage());
/*     */       }
/*     */       
/* 191 */       NameValuePair[] parameters = headerelement.getParameters();
/*     */       
/* 193 */       if (parameters != null)
/*     */       {
/* 195 */         for (int j = 0; j < parameters.length; j++) {
/* 196 */           parseAttribute(parameters[j], cookie);
/*     */         }
/*     */       }
/* 199 */       cookies[i] = cookie;
/*     */     }
/* 201 */     return cookies;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cookie[] parse(String host, int port, String path, boolean secure, Header header)
/*     */     throws MalformedCookieException
/*     */   {
/* 242 */     LOG.trace("enter CookieSpecBase.parse(String, port, path, boolean, String)");
/*     */     
/* 244 */     if (header == null) {
/* 245 */       throw new IllegalArgumentException("Header may not be null.");
/*     */     }
/* 247 */     return parse(host, port, path, secure, header.getValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parseAttribute(NameValuePair attribute, Cookie cookie)
/*     */     throws MalformedCookieException
/*     */   {
/* 265 */     if (attribute == null) {
/* 266 */       throw new IllegalArgumentException("Attribute may not be null.");
/*     */     }
/* 268 */     if (cookie == null) {
/* 269 */       throw new IllegalArgumentException("Cookie may not be null.");
/*     */     }
/* 271 */     String paramName = attribute.getName().toLowerCase();
/* 272 */     String paramValue = attribute.getValue();
/*     */     
/* 274 */     if (paramName.equals("path"))
/*     */     {
/* 276 */       if ((paramValue == null) || (paramValue.trim().equals(""))) {
/* 277 */         paramValue = "/";
/*     */       }
/* 279 */       cookie.setPath(paramValue);
/* 280 */       cookie.setPathAttributeSpecified(true);
/*     */     }
/* 282 */     else if (paramName.equals("domain"))
/*     */     {
/* 284 */       if (paramValue == null) {
/* 285 */         throw new MalformedCookieException("Missing value for domain attribute");
/*     */       }
/*     */       
/* 288 */       if (paramValue.trim().equals("")) {
/* 289 */         throw new MalformedCookieException("Blank value for domain attribute");
/*     */       }
/*     */       
/* 292 */       cookie.setDomain(paramValue);
/* 293 */       cookie.setDomainAttributeSpecified(true);
/*     */     }
/* 295 */     else if (paramName.equals("max-age"))
/*     */     {
/* 297 */       if (paramValue == null) {
/* 298 */         throw new MalformedCookieException("Missing value for max-age attribute");
/*     */       }
/*     */       int age;
/*     */       try
/*     */       {
/* 303 */         age = Integer.parseInt(paramValue);
/*     */       } catch (NumberFormatException e) {
/* 305 */         throw new MalformedCookieException("Invalid max-age attribute: " + e.getMessage());
/*     */       }
/*     */       
/* 308 */       cookie.setExpiryDate(new Date(System.currentTimeMillis() + age * 1000L));
/*     */ 
/*     */     }
/* 311 */     else if (paramName.equals("secure"))
/*     */     {
/* 313 */       cookie.setSecure(true);
/*     */     }
/* 315 */     else if (paramName.equals("comment"))
/*     */     {
/* 317 */       cookie.setComment(paramValue);
/*     */     }
/* 319 */     else if (paramName.equals("expires"))
/*     */     {
/* 321 */       if (paramValue == null) {
/* 322 */         throw new MalformedCookieException("Missing value for expires attribute");
/*     */       }
/*     */       
/*     */       try
/*     */       {
/* 327 */         cookie.setExpiryDate(DateUtil.parseDate(paramValue, this.datepatterns));
/*     */       } catch (DateParseException dpe) {
/* 329 */         LOG.debug("Error parsing cookie date", dpe);
/* 330 */         throw new MalformedCookieException("Unable to parse expiration date parameter: " + paramValue);
/*     */       }
/*     */       
/*     */ 
/*     */     }
/* 335 */     else if (LOG.isDebugEnabled()) {
/* 336 */       LOG.debug("Unrecognized cookie attribute: " + attribute.toString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Collection getValidDateFormats()
/*     */   {
/* 344 */     return this.datepatterns;
/*     */   }
/*     */   
/*     */   public void setValidDateFormats(Collection datepatterns) {
/* 348 */     this.datepatterns = datepatterns;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validate(String host, int port, String path, boolean secure, Cookie cookie)
/*     */     throws MalformedCookieException
/*     */   {
/* 368 */     LOG.trace("enter CookieSpecBase.validate(String, port, path, boolean, Cookie)");
/*     */     
/* 370 */     if (host == null) {
/* 371 */       throw new IllegalArgumentException("Host of origin may not be null");
/*     */     }
/*     */     
/* 374 */     if (host.trim().equals("")) {
/* 375 */       throw new IllegalArgumentException("Host of origin may not be blank");
/*     */     }
/*     */     
/* 378 */     if (port < 0) {
/* 379 */       throw new IllegalArgumentException("Invalid port: " + port);
/*     */     }
/* 381 */     if (path == null) {
/* 382 */       throw new IllegalArgumentException("Path of origin may not be null.");
/*     */     }
/*     */     
/* 385 */     if (path.trim().equals("")) {
/* 386 */       path = "/";
/*     */     }
/* 388 */     host = host.toLowerCase();
/*     */     
/* 390 */     if (cookie.getVersion() < 0) {
/* 391 */       throw new MalformedCookieException("Illegal version number " + cookie.getValue());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 403 */     if (host.indexOf(".") >= 0)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 408 */       if (!host.endsWith(cookie.getDomain())) {
/* 409 */         String s = cookie.getDomain();
/* 410 */         if (s.startsWith(".")) {
/* 411 */           s = s.substring(1, s.length());
/*     */         }
/* 413 */         if (!host.equals(s)) {
/* 414 */           throw new MalformedCookieException("Illegal domain attribute \"" + cookie.getDomain() + "\". Domain of origin: \"" + host + "\"");
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */     }
/* 420 */     else if (!host.equals(cookie.getDomain())) {
/* 421 */       throw new MalformedCookieException("Illegal domain attribute \"" + cookie.getDomain() + "\". Domain of origin: \"" + host + "\"");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 430 */     if (!path.startsWith(cookie.getPath())) {
/* 431 */       throw new MalformedCookieException("Illegal path attribute \"" + cookie.getPath() + "\". Path of origin: \"" + path + "\"");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean match(String host, int port, String path, boolean secure, Cookie cookie)
/*     */   {
/* 452 */     LOG.trace("enter CookieSpecBase.match(String, int, String, boolean, Cookie");
/*     */     
/*     */ 
/* 455 */     if (host == null) {
/* 456 */       throw new IllegalArgumentException("Host of origin may not be null");
/*     */     }
/*     */     
/* 459 */     if (host.trim().equals("")) {
/* 460 */       throw new IllegalArgumentException("Host of origin may not be blank");
/*     */     }
/*     */     
/* 463 */     if (port < 0) {
/* 464 */       throw new IllegalArgumentException("Invalid port: " + port);
/*     */     }
/* 466 */     if (path == null) {
/* 467 */       throw new IllegalArgumentException("Path of origin may not be null.");
/*     */     }
/*     */     
/* 470 */     if (cookie == null) {
/* 471 */       throw new IllegalArgumentException("Cookie may not be null");
/*     */     }
/* 473 */     if (path.trim().equals("")) {
/* 474 */       path = "/";
/*     */     }
/* 476 */     host = host.toLowerCase();
/* 477 */     if (cookie.getDomain() == null) {
/* 478 */       LOG.warn("Invalid cookie state: domain not specified");
/* 479 */       return false;
/*     */     }
/* 481 */     if (cookie.getPath() == null) {
/* 482 */       LOG.warn("Invalid cookie state: path not specified");
/* 483 */       return false;
/*     */     }
/*     */     
/* 486 */     if (((cookie.getExpiryDate() == null) || (cookie.getExpiryDate().after(new Date()))) && (domainMatch(host, cookie.getDomain())) && (pathMatch(path, cookie.getPath()))) {} return (cookie.getSecure() ? secure : 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean domainMatch(String host, String domain)
/*     */   {
/* 506 */     if (host.equals(domain)) {
/* 507 */       return true;
/*     */     }
/* 509 */     if (!domain.startsWith(".")) {
/* 510 */       domain = "." + domain;
/*     */     }
/* 512 */     return (host.endsWith(domain)) || (host.equals(domain.substring(1)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean pathMatch(String path, String topmostPath)
/*     */   {
/* 522 */     boolean match = path.startsWith(topmostPath);
/*     */     
/*     */ 
/* 525 */     if ((match) && (path.length() != topmostPath.length()) && 
/* 526 */       (!topmostPath.endsWith("/"))) {
/* 527 */       match = path.charAt(topmostPath.length()) == CookieSpec.PATH_DELIM_CHAR;
/*     */     }
/*     */     
/* 530 */     return match;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cookie[] match(String host, int port, String path, boolean secure, Cookie[] cookies)
/*     */   {
/* 548 */     LOG.trace("enter CookieSpecBase.match(String, int, String, boolean, Cookie[])");
/*     */     
/*     */ 
/* 551 */     if (cookies == null) {
/* 552 */       return null;
/*     */     }
/* 554 */     List matching = new LinkedList();
/* 555 */     for (int i = 0; i < cookies.length; i++) {
/* 556 */       if (match(host, port, path, secure, cookies[i])) {
/* 557 */         addInPathOrder(matching, cookies[i]);
/*     */       }
/*     */     }
/* 560 */     return (Cookie[])matching.toArray(new Cookie[matching.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void addInPathOrder(List list, Cookie addCookie)
/*     */   {
/* 574 */     int i = 0;
/*     */     
/* 576 */     for (i = 0; i < list.size(); i++) {
/* 577 */       Cookie c = (Cookie)list.get(i);
/* 578 */       if (addCookie.compare(addCookie, c) > 0) {
/*     */         break;
/*     */       }
/*     */     }
/* 582 */     list.add(i, addCookie);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String formatCookie(Cookie cookie)
/*     */   {
/* 591 */     LOG.trace("enter CookieSpecBase.formatCookie(Cookie)");
/* 592 */     if (cookie == null) {
/* 593 */       throw new IllegalArgumentException("Cookie may not be null");
/*     */     }
/* 595 */     StringBuffer buf = new StringBuffer();
/* 596 */     buf.append(cookie.getName());
/* 597 */     buf.append("=");
/* 598 */     String s = cookie.getValue();
/* 599 */     if (s != null) {
/* 600 */       buf.append(s);
/*     */     }
/* 602 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String formatCookies(Cookie[] cookies)
/*     */     throws IllegalArgumentException
/*     */   {
/* 615 */     LOG.trace("enter CookieSpecBase.formatCookies(Cookie[])");
/* 616 */     if (cookies == null) {
/* 617 */       throw new IllegalArgumentException("Cookie array may not be null");
/*     */     }
/* 619 */     if (cookies.length == 0) {
/* 620 */       throw new IllegalArgumentException("Cookie array may not be empty");
/*     */     }
/*     */     
/* 623 */     StringBuffer buffer = new StringBuffer();
/* 624 */     for (int i = 0; i < cookies.length; i++) {
/* 625 */       if (i > 0) {
/* 626 */         buffer.append("; ");
/*     */       }
/* 628 */       buffer.append(formatCookie(cookies[i]));
/*     */     }
/* 630 */     return buffer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Header formatCookieHeader(Cookie[] cookies)
/*     */   {
/* 642 */     LOG.trace("enter CookieSpecBase.formatCookieHeader(Cookie[])");
/* 643 */     return new Header("Cookie", formatCookies(cookies));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Header formatCookieHeader(Cookie cookie)
/*     */   {
/* 654 */     LOG.trace("enter CookieSpecBase.formatCookieHeader(Cookie)");
/* 655 */     return new Header("Cookie", formatCookie(cookie));
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\cookie\CookieSpecBase.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */