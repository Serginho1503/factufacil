/*     */ package org.apache.commons.httpclient.methods;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import org.apache.commons.httpclient.ChunkedOutputStream;
/*     */ import org.apache.commons.httpclient.Header;
/*     */ import org.apache.commons.httpclient.HttpConnection;
/*     */ import org.apache.commons.httpclient.HttpException;
/*     */ import org.apache.commons.httpclient.HttpMethodBase;
/*     */ import org.apache.commons.httpclient.HttpState;
/*     */ import org.apache.commons.httpclient.HttpVersion;
/*     */ import org.apache.commons.httpclient.ProtocolException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class EntityEnclosingMethod
/*     */   extends ExpectContinueMethod
/*     */ {
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static final long CONTENT_LENGTH_AUTO = -2L;
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static final long CONTENT_LENGTH_CHUNKED = -1L;
/*  76 */   private static final Log LOG = LogFactory.getLog(EntityEnclosingMethod.class);
/*     */   
/*     */ 
/*  79 */   private InputStream requestStream = null;
/*     */   
/*     */ 
/*  82 */   private String requestString = null;
/*     */   
/*     */ 
/*     */   private RequestEntity requestEntity;
/*     */   
/*  87 */   private int repeatCount = 0;
/*     */   
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*  94 */   private long requestContentLength = -2L;
/*     */   
/*  96 */   private boolean chunked = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EntityEnclosingMethod()
/*     */   {
/* 107 */     setFollowRedirects(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EntityEnclosingMethod(String uri)
/*     */   {
/* 118 */     super(uri);
/* 119 */     setFollowRedirects(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean hasRequestContent()
/*     */   {
/* 134 */     LOG.trace("enter EntityEnclosingMethod.hasRequestContent()");
/* 135 */     return (this.requestEntity != null) || (this.requestStream != null) || (this.requestString != null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void clearRequestBody()
/*     */   {
/* 149 */     LOG.trace("enter EntityEnclosingMethod.clearRequestBody()");
/* 150 */     this.requestStream = null;
/* 151 */     this.requestString = null;
/* 152 */     this.requestEntity = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected byte[] generateRequestBody()
/*     */   {
/* 167 */     LOG.trace("enter EntityEnclosingMethod.renerateRequestBody()");
/* 168 */     return null;
/*     */   }
/*     */   
/*     */   protected RequestEntity generateRequestEntity()
/*     */   {
/* 173 */     byte[] requestBody = generateRequestBody();
/* 174 */     if (requestBody != null)
/*     */     {
/*     */ 
/* 177 */       this.requestEntity = new ByteArrayRequestEntity(requestBody);
/* 178 */     } else if (this.requestStream != null) {
/* 179 */       this.requestEntity = new InputStreamRequestEntity(this.requestStream, this.requestContentLength);
/*     */       
/*     */ 
/* 182 */       this.requestStream = null;
/* 183 */     } else if (this.requestString != null) {
/* 184 */       String charset = getRequestCharSet();
/*     */       try {
/* 186 */         this.requestEntity = new StringRequestEntity(this.requestString, null, charset);
/*     */       }
/*     */       catch (UnsupportedEncodingException e) {
/* 189 */         if (LOG.isWarnEnabled()) {
/* 190 */           LOG.warn(charset + " not supported");
/*     */         }
/* 192 */         this.requestEntity = new StringRequestEntity(this.requestString);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 197 */     return this.requestEntity;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getFollowRedirects()
/*     */   {
/* 209 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFollowRedirects(boolean followRedirects)
/*     */   {
/* 220 */     if (followRedirects == true) {
/* 221 */       throw new IllegalArgumentException("Entity enclosing requests cannot be redirected without user intervention");
/*     */     }
/* 223 */     super.setFollowRedirects(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setRequestContentLength(int length)
/*     */   {
/* 249 */     LOG.trace("enter EntityEnclosingMethod.setRequestContentLength(int)");
/* 250 */     this.requestContentLength = length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRequestCharSet()
/*     */   {
/* 262 */     if (getRequestHeader("Content-Type") == null)
/*     */     {
/*     */ 
/*     */ 
/* 266 */       if (this.requestEntity != null) {
/* 267 */         return getContentCharSet(new Header("Content-Type", this.requestEntity.getContentType()));
/*     */       }
/*     */       
/* 270 */       return super.getRequestCharSet();
/*     */     }
/*     */     
/* 273 */     return super.getRequestCharSet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setRequestContentLength(long length)
/*     */   {
/* 300 */     LOG.trace("enter EntityEnclosingMethod.setRequestContentLength(int)");
/* 301 */     this.requestContentLength = length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContentChunked(boolean chunked)
/*     */   {
/* 312 */     this.chunked = chunked;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected long getRequestContentLength()
/*     */   {
/* 321 */     LOG.trace("enter EntityEnclosingMethod.getRequestContentLength()");
/*     */     
/* 323 */     if (!hasRequestContent()) {
/* 324 */       return 0L;
/*     */     }
/* 326 */     if (this.chunked) {
/* 327 */       return -1L;
/*     */     }
/* 329 */     if (this.requestEntity == null) {
/* 330 */       this.requestEntity = generateRequestEntity();
/*     */     }
/* 332 */     return this.requestEntity == null ? 0L : this.requestEntity.getContentLength();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addRequestHeaders(HttpState state, HttpConnection conn)
/*     */     throws IOException, HttpException
/*     */   {
/* 366 */     LOG.trace("enter EntityEnclosingMethod.addRequestHeaders(HttpState, HttpConnection)");
/*     */     
/*     */ 
/* 369 */     super.addRequestHeaders(state, conn);
/* 370 */     addContentLengthRequestHeader(state, conn);
/*     */     
/*     */ 
/*     */ 
/* 374 */     if (getRequestHeader("Content-Type") == null) {
/* 375 */       RequestEntity requestEntity = getRequestEntity();
/* 376 */       if ((requestEntity != null) && (requestEntity.getContentType() != null)) {
/* 377 */         setRequestHeader("Content-Type", requestEntity.getContentType());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addContentLengthRequestHeader(HttpState state, HttpConnection conn)
/*     */     throws IOException, HttpException
/*     */   {
/* 397 */     LOG.trace("enter EntityEnclosingMethod.addContentLengthRequestHeader(HttpState, HttpConnection)");
/*     */     
/*     */ 
/* 400 */     if ((getRequestHeader("content-length") == null) && (getRequestHeader("Transfer-Encoding") == null))
/*     */     {
/* 402 */       long len = getRequestContentLength();
/* 403 */       if (len < 0L) {
/* 404 */         if (getEffectiveVersion().greaterEquals(HttpVersion.HTTP_1_1)) {
/* 405 */           addRequestHeader("Transfer-Encoding", "chunked");
/*     */         } else {
/* 407 */           throw new ProtocolException(getEffectiveVersion() + " does not support chunk encoding");
/*     */         }
/*     */       }
/*     */       else {
/* 411 */         addRequestHeader("Content-Length", String.valueOf(len));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setRequestBody(InputStream body)
/*     */   {
/* 424 */     LOG.trace("enter EntityEnclosingMethod.setRequestBody(InputStream)");
/* 425 */     clearRequestBody();
/* 426 */     this.requestStream = body;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setRequestBody(String body)
/*     */   {
/* 444 */     LOG.trace("enter EntityEnclosingMethod.setRequestBody(String)");
/* 445 */     clearRequestBody();
/* 446 */     this.requestString = body;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean writeRequestBody(HttpState state, HttpConnection conn)
/*     */     throws IOException, HttpException
/*     */   {
/* 465 */     LOG.trace("enter EntityEnclosingMethod.writeRequestBody(HttpState, HttpConnection)");
/*     */     
/*     */ 
/* 468 */     if (!hasRequestContent()) {
/* 469 */       LOG.debug("Request body has not been specified");
/* 470 */       return true;
/*     */     }
/* 472 */     if (this.requestEntity == null) {
/* 473 */       this.requestEntity = generateRequestEntity();
/*     */     }
/* 475 */     if (this.requestEntity == null) {
/* 476 */       LOG.debug("Request body is empty");
/* 477 */       return true;
/*     */     }
/*     */     
/* 480 */     long contentLength = getRequestContentLength();
/*     */     
/* 482 */     if ((this.repeatCount > 0) && (!this.requestEntity.isRepeatable())) {
/* 483 */       throw new ProtocolException("Unbuffered entity enclosing request can not be repeated.");
/*     */     }
/*     */     
/*     */ 
/* 487 */     this.repeatCount += 1;
/*     */     
/* 489 */     OutputStream outstream = conn.getRequestOutputStream();
/*     */     
/* 491 */     if (contentLength < 0L) {
/* 492 */       outstream = new ChunkedOutputStream(outstream);
/*     */     }
/*     */     
/* 495 */     this.requestEntity.writeRequest(outstream);
/*     */     
/*     */ 
/* 498 */     if ((outstream instanceof ChunkedOutputStream)) {
/* 499 */       ((ChunkedOutputStream)outstream).finish();
/*     */     }
/*     */     
/* 502 */     outstream.flush();
/*     */     
/* 504 */     LOG.debug("Request body sent");
/* 505 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void recycle()
/*     */   {
/* 520 */     LOG.trace("enter EntityEnclosingMethod.recycle()");
/* 521 */     clearRequestBody();
/* 522 */     this.requestContentLength = -2L;
/* 523 */     this.repeatCount = 0;
/* 524 */     this.chunked = false;
/* 525 */     super.recycle();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RequestEntity getRequestEntity()
/*     */   {
/* 534 */     return generateRequestEntity();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRequestEntity(RequestEntity requestEntity)
/*     */   {
/* 543 */     clearRequestBody();
/* 544 */     this.requestEntity = requestEntity;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\methods\EntityEnclosingMethod.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */