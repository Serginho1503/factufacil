/*     */ package org.apache.commons.httpclient.params;
/*     */ 
/*     */ import org.apache.commons.httpclient.HttpVersion;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpMethodParams
/*     */   extends DefaultHttpParams
/*     */ {
/*  54 */   private static final Log LOG = LogFactory.getLog(HttpMethodParams.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String USER_AGENT = "http.useragent";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String PROTOCOL_VERSION = "http.protocol.version";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String UNAMBIGUOUS_STATUS_LINE = "http.protocol.unambiguous-statusline";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String SINGLE_COOKIE_HEADER = "http.protocol.single-cookie-header";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String STRICT_TRANSFER_ENCODING = "http.protocol.strict-transfer-encoding";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String REJECT_HEAD_BODY = "http.protocol.reject-head-body";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String HEAD_BODY_CHECK_TIMEOUT = "http.protocol.head-body-timeout";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String USE_EXPECT_CONTINUE = "http.protocol.expect-continue";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String CREDENTIAL_CHARSET = "http.protocol.credential-charset";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String HTTP_ELEMENT_CHARSET = "http.protocol.element-charset";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String HTTP_CONTENT_CHARSET = "http.protocol.content-charset";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String COOKIE_POLICY = "http.protocol.cookie-policy";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String WARN_EXTRA_INPUT = "http.protocol.warn-extra-input";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String STATUS_LINE_GARBAGE_LIMIT = "http.protocol.status-line-garbage-limit";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String SO_TIMEOUT = "http.socket.timeout";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String DATE_PATTERNS = "http.dateparser.patterns";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String RETRY_HANDLER = "http.method.retry-handler";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String BUFFER_WARN_TRIGGER_LIMIT = "http.method.response.buffer.warnlimit";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String VIRTUAL_HOST = "http.virtual-host";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String MULTIPART_BOUNDARY = "http.method.multipart.boundary";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpMethodParams()
/*     */   {
/* 285 */     super(DefaultHttpParams.getDefaultParams());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpMethodParams(HttpParams defaults)
/*     */   {
/* 300 */     super(defaults);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHttpElementCharset()
/*     */   {
/* 308 */     String charset = (String)getParameter("http.protocol.element-charset");
/* 309 */     if (charset == null) {
/* 310 */       LOG.warn("HTTP element charset not configured, using US-ASCII");
/* 311 */       charset = "US-ASCII";
/*     */     }
/* 313 */     return charset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHttpElementCharset(String charset)
/*     */   {
/* 321 */     setParameter("http.protocol.element-charset", charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContentCharset()
/*     */   {
/* 330 */     String charset = (String)getParameter("http.protocol.content-charset");
/* 331 */     if (charset == null) {
/* 332 */       LOG.warn("Default content charset not configured, using ISO-8859-1");
/* 333 */       charset = "ISO-8859-1";
/*     */     }
/* 335 */     return charset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContentCharset(String charset)
/*     */   {
/* 344 */     setParameter("http.protocol.content-charset", charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCredentialCharset()
/*     */   {
/* 353 */     String charset = (String)getParameter("http.protocol.credential-charset");
/* 354 */     if (charset == null) {
/* 355 */       LOG.debug("Credential charset not configured, using HTTP element charset");
/* 356 */       charset = getHttpElementCharset();
/*     */     }
/* 358 */     return charset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCredentialCharset(String charset)
/*     */   {
/* 366 */     setParameter("http.protocol.credential-charset", charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpVersion getVersion()
/*     */   {
/* 377 */     Object param = getParameter("http.protocol.version");
/* 378 */     if (param == null) {
/* 379 */       return HttpVersion.HTTP_1_1;
/*     */     }
/* 381 */     return (HttpVersion)param;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVersion(HttpVersion version)
/*     */   {
/* 392 */     setParameter("http.protocol.version", version);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCookiePolicy()
/*     */   {
/* 404 */     Object param = getParameter("http.protocol.cookie-policy");
/* 405 */     if (param == null) {
/* 406 */       return "default";
/*     */     }
/* 408 */     return (String)param;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCookiePolicy(String policy)
/*     */   {
/* 419 */     setParameter("http.protocol.cookie-policy", policy);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSoTimeout()
/*     */   {
/* 430 */     return getIntParameter("http.socket.timeout", 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSoTimeout(int timeout)
/*     */   {
/* 441 */     setIntParameter("http.socket.timeout", timeout);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVirtualHost(String hostname)
/*     */   {
/* 450 */     setParameter("http.virtual-host", hostname);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getVirtualHost()
/*     */   {
/* 459 */     return (String)getParameter("http.virtual-host");
/*     */   }
/*     */   
/* 462 */   private static final String[] PROTOCOL_STRICTNESS_PARAMETERS = { "http.protocol.unambiguous-statusline", "http.protocol.single-cookie-header", "http.protocol.strict-transfer-encoding", "http.protocol.reject-head-body", "http.protocol.warn-extra-input" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void makeStrict()
/*     */   {
/* 478 */     setParameters(PROTOCOL_STRICTNESS_PARAMETERS, Boolean.TRUE);
/* 479 */     setIntParameter("http.protocol.status-line-garbage-limit", 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void makeLenient()
/*     */   {
/* 489 */     setParameters(PROTOCOL_STRICTNESS_PARAMETERS, Boolean.FALSE);
/* 490 */     setIntParameter("http.protocol.status-line-garbage-limit", Integer.MAX_VALUE);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\params\HttpMethodParams.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */