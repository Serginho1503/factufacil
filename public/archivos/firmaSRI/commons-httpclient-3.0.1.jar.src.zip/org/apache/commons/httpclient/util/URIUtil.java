/*     */ package org.apache.commons.httpclient.util;
/*     */ 
/*     */ import java.util.BitSet;
/*     */ import org.apache.commons.codec.DecoderException;
/*     */ import org.apache.commons.codec.net.URLCodec;
/*     */ import org.apache.commons.httpclient.URI;
/*     */ import org.apache.commons.httpclient.URIException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class URIUtil
/*     */ {
/*  51 */   protected static final BitSet empty = new BitSet(1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getName(String uri)
/*     */   {
/*  62 */     if ((uri == null) || (uri.length() == 0)) return uri;
/*  63 */     String path = getPath(uri);
/*  64 */     int at = path.lastIndexOf("/");
/*  65 */     int to = path.length();
/*  66 */     return at >= 0 ? path.substring(at + 1, to) : path;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getQuery(String uri)
/*     */   {
/*  77 */     if ((uri == null) || (uri.length() == 0)) { return null;
/*     */     }
/*  79 */     int at = uri.indexOf("//");
/*  80 */     int from = uri.indexOf("/", at >= 0 ? at + 2 : uri.lastIndexOf("/", at - 1) >= 0 ? 0 : 0);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  85 */     int to = uri.length();
/*     */     
/*  87 */     at = uri.indexOf("?", from);
/*  88 */     if (at >= 0) {
/*  89 */       from = at + 1;
/*     */     } else {
/*  91 */       return null;
/*     */     }
/*     */     
/*  94 */     if (uri.lastIndexOf("#") > from) {
/*  95 */       to = uri.lastIndexOf("#");
/*     */     }
/*     */     
/*  98 */     return (from < 0) || (from == to) ? null : uri.substring(from, to);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getPath(String uri)
/*     */   {
/* 109 */     if (uri == null) {
/* 110 */       return null;
/*     */     }
/*     */     
/* 113 */     int at = uri.indexOf("//");
/* 114 */     int from = uri.indexOf("/", at >= 0 ? at + 2 : uri.lastIndexOf("/", at - 1) >= 0 ? 0 : 0);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 119 */     int to = uri.length();
/*     */     
/* 121 */     if (uri.indexOf('?', from) != -1) {
/* 122 */       to = uri.indexOf('?', from);
/*     */     }
/*     */     
/* 125 */     if ((uri.lastIndexOf("#") > from) && (uri.lastIndexOf("#") < to)) {
/* 126 */       to = uri.lastIndexOf("#");
/*     */     }
/*     */     
/* 129 */     return from < 0 ? uri : at >= 0 ? "/" : uri.substring(from, to);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getPathQuery(String uri)
/*     */   {
/* 140 */     if (uri == null) {
/* 141 */       return null;
/*     */     }
/*     */     
/* 144 */     int at = uri.indexOf("//");
/* 145 */     int from = uri.indexOf("/", at >= 0 ? at + 2 : uri.lastIndexOf("/", at - 1) >= 0 ? 0 : 0);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 150 */     int to = uri.length();
/*     */     
/*     */ 
/* 153 */     if (uri.lastIndexOf("#") > from) {
/* 154 */       to = uri.lastIndexOf("#");
/*     */     }
/*     */     
/* 157 */     return from < 0 ? uri : at >= 0 ? "/" : uri.substring(from, to);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getFromPath(String uri)
/*     */   {
/* 168 */     if (uri == null) {
/* 169 */       return null;
/*     */     }
/*     */     
/* 172 */     int at = uri.indexOf("//");
/* 173 */     int from = uri.indexOf("/", at >= 0 ? at + 2 : uri.lastIndexOf("/", at - 1) >= 0 ? 0 : 0);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 178 */     return from < 0 ? uri : at >= 0 ? "/" : uri.substring(from);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encodeAll(String unescaped)
/*     */     throws URIException
/*     */   {
/* 197 */     return encodeAll(unescaped, URI.getDefaultProtocolCharset());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encodeAll(String unescaped, String charset)
/*     */     throws URIException
/*     */   {
/* 217 */     return encode(unescaped, empty, charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encodeWithinAuthority(String unescaped)
/*     */     throws URIException
/*     */   {
/* 238 */     return encodeWithinAuthority(unescaped, URI.getDefaultProtocolCharset());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encodeWithinAuthority(String unescaped, String charset)
/*     */     throws URIException
/*     */   {
/* 259 */     return encode(unescaped, URI.allowed_within_authority, charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encodePathQuery(String unescaped)
/*     */     throws URIException
/*     */   {
/* 276 */     return encodePathQuery(unescaped, URI.getDefaultProtocolCharset());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encodePathQuery(String unescaped, String charset)
/*     */     throws URIException
/*     */   {
/* 295 */     int at = unescaped.indexOf('?');
/* 296 */     if (at < 0) {
/* 297 */       return encode(unescaped, URI.allowed_abs_path, charset);
/*     */     }
/*     */     
/* 300 */     return encode(unescaped.substring(0, at), URI.allowed_abs_path, charset) + '?' + encode(unescaped.substring(at + 1), URI.allowed_query, charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encodeWithinPath(String unescaped)
/*     */     throws URIException
/*     */   {
/* 323 */     return encodeWithinPath(unescaped, URI.getDefaultProtocolCharset());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encodeWithinPath(String unescaped, String charset)
/*     */     throws URIException
/*     */   {
/* 345 */     return encode(unescaped, URI.allowed_within_path, charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encodePath(String unescaped)
/*     */     throws URIException
/*     */   {
/* 362 */     return encodePath(unescaped, URI.getDefaultProtocolCharset());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encodePath(String unescaped, String charset)
/*     */     throws URIException
/*     */   {
/* 381 */     return encode(unescaped, URI.allowed_abs_path, charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encodeWithinQuery(String unescaped)
/*     */     throws URIException
/*     */   {
/* 403 */     return encodeWithinQuery(unescaped, URI.getDefaultProtocolCharset());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encodeWithinQuery(String unescaped, String charset)
/*     */     throws URIException
/*     */   {
/* 425 */     return encode(unescaped, URI.allowed_within_query, charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encodeQuery(String unescaped)
/*     */     throws URIException
/*     */   {
/* 445 */     return encodeQuery(unescaped, URI.getDefaultProtocolCharset());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encodeQuery(String unescaped, String charset)
/*     */     throws URIException
/*     */   {
/* 467 */     return encode(unescaped, URI.allowed_query, charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encode(String unescaped, BitSet allowed)
/*     */     throws URIException
/*     */   {
/* 486 */     return encode(unescaped, allowed, URI.getDefaultProtocolCharset());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encode(String unescaped, BitSet allowed, String charset)
/*     */     throws URIException
/*     */   {
/* 501 */     byte[] rawdata = URLCodec.encodeUrl(allowed, EncodingUtil.getBytes(unescaped, charset));
/*     */     
/* 503 */     return EncodingUtil.getAsciiString(rawdata);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String decode(String escaped)
/*     */     throws URIException
/*     */   {
/*     */     try
/*     */     {
/* 520 */       byte[] rawdata = URLCodec.decodeUrl(EncodingUtil.getAsciiBytes(escaped));
/* 521 */       return EncodingUtil.getString(rawdata, URI.getDefaultProtocolCharset());
/*     */     } catch (DecoderException e) {
/* 523 */       throw new URIException(e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String decode(String escaped, String charset)
/*     */     throws URIException
/*     */   {
/* 541 */     return Coder.decode(escaped.toCharArray(), charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   protected static class Coder
/*     */     extends URI
/*     */   {
/*     */     /**
/*     */      * @deprecated
/*     */      */
/*     */     public static char[] encode(String unescapedComponent, BitSet allowed, String charset)
/*     */       throws URIException
/*     */     {
/* 570 */       return URI.encode(unescapedComponent, allowed, charset);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     /**
/*     */      * @deprecated
/*     */      */
/*     */     public static String decode(char[] escapedComponent, String charset)
/*     */       throws URIException
/*     */     {
/* 588 */       return URI.decode(escapedComponent, charset);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public static boolean verifyEscaped(char[] original)
/*     */     {
/* 599 */       for (int i = 0; i < original.length; i++) {
/* 600 */         int c = original[i];
/* 601 */         if (c > 128)
/* 602 */           return false;
/* 603 */         if ((c == 37) && (
/* 604 */           (Character.digit(original[(++i)], 16) == -1) || (Character.digit(original[(++i)], 16) == -1)))
/*     */         {
/* 606 */           return false;
/*     */         }
/*     */       }
/*     */       
/* 610 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public static String replace(String original, char[] from, char[] to)
/*     */     {
/* 624 */       for (int i = from.length; i > 0; i--) {
/* 625 */         original = replace(original, from[i], to[i]);
/*     */       }
/* 627 */       return original.toString();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public static String replace(String original, char from, char to)
/*     */     {
/* 640 */       StringBuffer result = new StringBuffer(original.length());
/* 641 */       int saved = 0;
/*     */       int at;
/* 643 */       do { at = original.indexOf(from);
/* 644 */         if (at >= 0) {
/* 645 */           result.append(original.substring(0, at));
/* 646 */           result.append(to);
/*     */         } else {
/* 648 */           result.append(original.substring(saved));
/*     */         }
/* 650 */         saved = at;
/* 651 */       } while (at >= 0);
/* 652 */       return result.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\util\URIUtil.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */