package org.apache.commons.httpclient;

public abstract interface Credentials {}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\Credentials.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */