/*    */ package org.apache.commons.httpclient.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TimeoutController
/*    */ {
/*    */   public static void execute(Thread task, long timeout)
/*    */     throws TimeoutController.TimeoutException
/*    */   {
/* 60 */     task.start();
/*    */     try {
/* 62 */       task.join(timeout);
/*    */     }
/*    */     catch (InterruptedException e) {}
/*    */     
/* 66 */     if (task.isAlive()) {
/* 67 */       task.interrupt();
/* 68 */       throw new TimeoutException();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void execute(Runnable task, long timeout)
/*    */     throws TimeoutController.TimeoutException
/*    */   {
/* 79 */     Thread t = new Thread(task, "Timeout guard");
/* 80 */     t.setDaemon(true);
/* 81 */     execute(t, timeout);
/*    */   }
/*    */   
/*    */   public static class TimeoutException
/*    */     extends Exception
/*    */   {}
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\util\TimeoutController.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */