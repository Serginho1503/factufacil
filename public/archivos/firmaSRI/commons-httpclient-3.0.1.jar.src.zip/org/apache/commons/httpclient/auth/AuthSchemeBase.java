/*    */ package org.apache.commons.httpclient.auth;
/*    */ 
/*    */ import org.apache.commons.httpclient.Credentials;
/*    */ import org.apache.commons.httpclient.HttpMethod;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ /**
/*    */  * @deprecated
/*    */  */
/*    */ public abstract class AuthSchemeBase
/*    */   implements AuthScheme
/*    */ {
/* 46 */   private String challenge = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   /**
/*    */    * @deprecated
/*    */    */
/*    */   public AuthSchemeBase(String challenge)
/*    */     throws MalformedChallengeException
/*    */   {
/* 62 */     if (challenge == null) {
/* 63 */       throw new IllegalArgumentException("Challenge may not be null");
/*    */     }
/* 65 */     this.challenge = challenge;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 72 */     if ((obj instanceof AuthSchemeBase)) {
/* 73 */       return this.challenge.equals(((AuthSchemeBase)obj).challenge);
/*    */     }
/* 75 */     return super.equals(obj);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 83 */     return this.challenge.hashCode();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 90 */     return this.challenge;
/*    */   }
/*    */   
/*    */   public abstract String authenticate(Credentials paramCredentials, HttpMethod paramHttpMethod)
/*    */     throws AuthenticationException;
/*    */   
/*    */   /**
/*    */    * @deprecated
/*    */    */
/*    */   public abstract String authenticate(Credentials paramCredentials, String paramString1, String paramString2)
/*    */     throws AuthenticationException;
/*    */   
/*    */   public abstract boolean isComplete();
/*    */   
/*    */   public abstract boolean isConnectionBased();
/*    */   
/*    */   /**
/*    */    * @deprecated
/*    */    */
/*    */   public abstract String getID();
/*    */   
/*    */   public abstract String getRealm();
/*    */   
/*    */   public abstract String getParameter(String paramString);
/*    */   
/*    */   public abstract String getSchemeName();
/*    */   
/*    */   public abstract void processChallenge(String paramString)
/*    */     throws MalformedChallengeException;
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\auth\AuthSchemeBase.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */