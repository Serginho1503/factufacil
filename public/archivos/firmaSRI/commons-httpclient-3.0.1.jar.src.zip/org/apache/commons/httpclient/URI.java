/*      */ package org.apache.commons.httpclient;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.util.BitSet;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Locale;
/*      */ import org.apache.commons.codec.DecoderException;
/*      */ import org.apache.commons.codec.net.URLCodec;
/*      */ import org.apache.commons.httpclient.util.EncodingUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class URI
/*      */   implements Cloneable, Comparable, Serializable
/*      */ {
/*      */   static final long serialVersionUID = 604752400577948726L;
/*      */   
/*      */   public URI(String s, boolean escaped, String charset)
/*      */     throws URIException, NullPointerException
/*      */   {
/*  144 */     this.protocolCharset = charset;
/*  145 */     parseUriReference(s, escaped);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URI(String s, boolean escaped)
/*      */     throws URIException, NullPointerException
/*      */   {
/*  165 */     parseUriReference(s, escaped);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public URI(char[] escaped, String charset)
/*      */     throws URIException, NullPointerException
/*      */   {
/*  182 */     this.protocolCharset = charset;
/*  183 */     parseUriReference(new String(escaped), true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public URI(char[] escaped)
/*      */     throws URIException, NullPointerException
/*      */   {
/*  201 */     parseUriReference(new String(escaped), true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public URI(String original, String charset)
/*      */     throws URIException
/*      */   {
/*  217 */     this.protocolCharset = charset;
/*  218 */     parseUriReference(original, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public URI(String original)
/*      */     throws URIException
/*      */   {
/*  238 */     parseUriReference(original, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URI(String scheme, String schemeSpecificPart, String fragment)
/*      */     throws URIException
/*      */   {
/*  262 */     if (scheme == null) {
/*  263 */       throw new URIException(1, "scheme required");
/*      */     }
/*  265 */     char[] s = scheme.toLowerCase().toCharArray();
/*  266 */     if (validate(s, scheme)) {
/*  267 */       this._scheme = s;
/*      */     } else {
/*  269 */       throw new URIException(1, "incorrect scheme");
/*      */     }
/*  271 */     this._opaque = encode(schemeSpecificPart, allowed_opaque_part, getProtocolCharset());
/*      */     
/*      */ 
/*  274 */     this._is_opaque_part = true;
/*  275 */     this._fragment = (fragment == null ? null : fragment.toCharArray());
/*  276 */     setURI();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URI(String scheme, String authority, String path, String query, String fragment)
/*      */     throws URIException
/*      */   {
/*  304 */     StringBuffer buff = new StringBuffer();
/*  305 */     if (scheme != null) {
/*  306 */       buff.append(scheme);
/*  307 */       buff.append(':');
/*      */     }
/*  309 */     if (authority != null) {
/*  310 */       buff.append("//");
/*  311 */       buff.append(authority);
/*      */     }
/*  313 */     if (path != null) {
/*  314 */       if (((scheme != null) || (authority != null)) && (!path.startsWith("/")))
/*      */       {
/*  316 */         throw new URIException(1, "abs_path requested");
/*      */       }
/*      */       
/*  319 */       buff.append(path);
/*      */     }
/*  321 */     if (query != null) {
/*  322 */       buff.append('?');
/*  323 */       buff.append(query);
/*      */     }
/*  325 */     if (fragment != null) {
/*  326 */       buff.append('#');
/*  327 */       buff.append(fragment);
/*      */     }
/*  329 */     parseUriReference(buff.toString(), false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URI(String scheme, String userinfo, String host, int port)
/*      */     throws URIException
/*      */   {
/*  346 */     this(scheme, userinfo, host, port, null, null, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URI(String scheme, String userinfo, String host, int port, String path)
/*      */     throws URIException
/*      */   {
/*  364 */     this(scheme, userinfo, host, port, path, null, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URI(String scheme, String userinfo, String host, int port, String path, String query)
/*      */     throws URIException
/*      */   {
/*  383 */     this(scheme, userinfo, host, port, path, query, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URI(String scheme, String userinfo, String host, int port, String path, String query, String fragment)
/*      */     throws URIException
/*      */   {
/*  403 */     this(scheme, (userinfo != null ? userinfo + '@' : "") + host + (port != -1 ? ":" + port : ""), path, query, fragment);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URI(String scheme, String host, String path, String fragment)
/*      */     throws URIException
/*      */   {
/*  422 */     this(scheme, host, path, null, fragment);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public URI(URI base, String relative)
/*      */     throws URIException
/*      */   {
/*  436 */     this(base, new URI(relative));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URI(URI base, String relative, boolean escaped)
/*      */     throws URIException
/*      */   {
/*  453 */     this(base, new URI(relative, escaped));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URI(URI base, URI relative)
/*      */     throws URIException
/*      */   {
/*  509 */     if (base._scheme == null) {
/*  510 */       throw new URIException(1, "base URI required");
/*      */     }
/*  512 */     if (base._scheme != null) {
/*  513 */       this._scheme = base._scheme;
/*  514 */       this._authority = base._authority;
/*      */     }
/*  516 */     if ((base._is_opaque_part) || (relative._is_opaque_part)) {
/*  517 */       this._scheme = base._scheme;
/*  518 */       this._is_opaque_part = ((base._is_opaque_part) || (relative._is_opaque_part));
/*      */       
/*  520 */       this._opaque = relative._opaque;
/*  521 */       this._fragment = relative._fragment;
/*  522 */       setURI();
/*  523 */       return;
/*      */     }
/*  525 */     if (relative._scheme != null) {
/*  526 */       this._scheme = relative._scheme;
/*  527 */       this._is_net_path = relative._is_net_path;
/*  528 */       this._authority = relative._authority;
/*  529 */       if (relative._is_server) {
/*  530 */         this._is_server = relative._is_server;
/*  531 */         this._userinfo = relative._userinfo;
/*  532 */         this._host = relative._host;
/*  533 */         this._port = relative._port;
/*  534 */       } else if (relative._is_reg_name) {
/*  535 */         this._is_reg_name = relative._is_reg_name;
/*      */       }
/*  537 */       this._is_abs_path = relative._is_abs_path;
/*  538 */       this._is_rel_path = relative._is_rel_path;
/*  539 */       this._path = relative._path;
/*  540 */     } else if ((base._authority != null) && (relative._scheme == null)) {
/*  541 */       this._is_net_path = base._is_net_path;
/*  542 */       this._authority = base._authority;
/*  543 */       if (base._is_server) {
/*  544 */         this._is_server = base._is_server;
/*  545 */         this._userinfo = base._userinfo;
/*  546 */         this._host = base._host;
/*  547 */         this._port = base._port;
/*  548 */       } else if (base._is_reg_name) {
/*  549 */         this._is_reg_name = base._is_reg_name;
/*      */       }
/*      */     }
/*  552 */     if (relative._authority != null) {
/*  553 */       this._is_net_path = relative._is_net_path;
/*  554 */       this._authority = relative._authority;
/*  555 */       if (relative._is_server) {
/*  556 */         this._is_server = relative._is_server;
/*  557 */         this._userinfo = relative._userinfo;
/*  558 */         this._host = relative._host;
/*  559 */         this._port = relative._port;
/*  560 */       } else if (relative._is_reg_name) {
/*  561 */         this._is_reg_name = relative._is_reg_name;
/*      */       }
/*  563 */       this._is_abs_path = relative._is_abs_path;
/*  564 */       this._is_rel_path = relative._is_rel_path;
/*  565 */       this._path = relative._path;
/*      */     }
/*      */     
/*  568 */     if ((relative._scheme == null) && (relative._authority == null)) {
/*  569 */       if (((relative._path == null) || (relative._path.length == 0)) && (relative._query == null))
/*      */       {
/*      */ 
/*      */ 
/*  573 */         this._path = base._path;
/*  574 */         this._query = base._query;
/*      */       } else {
/*  576 */         this._path = resolvePath(base._path, relative._path);
/*      */       }
/*      */     }
/*      */     
/*  580 */     if (relative._query != null) {
/*  581 */       this._query = relative._query;
/*      */     }
/*      */     
/*  584 */     if (relative._fragment != null) {
/*  585 */       this._fragment = relative._fragment;
/*      */     }
/*  587 */     setURI();
/*      */     
/*      */ 
/*  590 */     parseUriReference(new String(this._uri), true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  602 */   protected int hash = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  610 */   protected char[] _uri = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  616 */   protected String protocolCharset = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  622 */   protected static String defaultProtocolCharset = "UTF-8";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  629 */   protected static String defaultDocumentCharset = null;
/*  630 */   protected static String defaultDocumentCharsetByLocale = null;
/*  631 */   protected static String defaultDocumentCharsetByPlatform = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  657 */   protected char[] _scheme = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  663 */   protected char[] _opaque = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  669 */   protected char[] _authority = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  675 */   protected char[] _userinfo = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  681 */   protected char[] _host = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  687 */   protected int _port = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  693 */   protected char[] _path = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  699 */   protected char[] _query = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  705 */   protected char[] _fragment = null;
/*      */   protected static char[] rootPath;
/*      */   protected static final BitSet percent;
/*      */   protected static final BitSet digit;
/*      */   protected static final BitSet alpha;
/*      */   protected static final BitSet alphanum;
/*      */   protected static final BitSet hex;
/*      */   protected static final BitSet escaped;
/*      */   protected static final BitSet mark;
/*      */   protected static final BitSet unreserved;
/*      */   protected static final BitSet reserved;
/*      */   protected static final BitSet uric;
/*      */   protected static final BitSet fragment;
/*      */   protected static final BitSet query;
/*      */   protected static final BitSet pchar;
/*      */   protected static final BitSet param;
/*      */   protected static final BitSet segment;
/*      */   protected static final BitSet path_segments;
/*      */   protected static final BitSet abs_path;
/*      */   protected static final BitSet uric_no_slash;
/*      */   protected static final BitSet opaque_part;
/*      */   protected static final BitSet path;
/*      */   protected static final BitSet port;
/*      */   protected static final BitSet IPv4address;
/*      */   protected static final BitSet IPv6address;
/*      */   protected static final BitSet IPv6reference;
/*      */   protected static final BitSet toplabel;
/*      */   protected static final BitSet domainlabel;
/*      */   protected static final BitSet hostname;
/*      */   protected static final BitSet host;
/*      */   protected static final BitSet hostport;
/*      */   protected static final BitSet userinfo;
/*      */   public static final BitSet within_userinfo;
/*      */   protected static final BitSet server;
/*      */   protected static final BitSet reg_name;
/*      */   protected static final BitSet authority;
/*      */   protected static final BitSet scheme;
/*      */   protected static final BitSet rel_segment;
/*      */   protected static final BitSet rel_path;
/*      */   protected static final BitSet net_path;
/*      */   protected static final BitSet hier_part;
/*      */   protected static final BitSet relativeURI;
/*      */   protected static final BitSet absoluteURI;
/*      */   protected static final BitSet URI_reference;
/*      */   public static final BitSet control;
/*      */   public static final BitSet space;
/*      */   public static final BitSet delims;
/*      */   public static final BitSet unwise;
/*      */   public static final BitSet disallowed_rel_path;
/*      */   public static final BitSet disallowed_opaque_part;
/*      */   public static final BitSet allowed_authority;
/*      */   public static final BitSet allowed_opaque_part;
/*      */   public static final BitSet allowed_reg_name;
/*      */   public static final BitSet allowed_userinfo;
/*      */   public static final BitSet allowed_within_userinfo;
/*      */   public static final BitSet allowed_IPv6reference;
/*      */   public static final BitSet allowed_host;
/*      */   public static final BitSet allowed_within_authority;
/*      */   public static final BitSet allowed_abs_path;
/*      */   public static final BitSet allowed_rel_path;
/*      */   public static final BitSet allowed_within_path;
/*      */   public static final BitSet allowed_query;
/*      */   public static final BitSet allowed_within_query;
/*      */   public static final BitSet allowed_fragment;
/*      */   protected boolean _is_hier_part;
/*      */   protected boolean _is_opaque_part;
/*      */   protected boolean _is_net_path;
/*      */   protected boolean _is_abs_path;
/*      */   protected boolean _is_rel_path;
/*      */   protected boolean _is_reg_name;
/*      */   protected boolean _is_server;
/*      */   protected boolean _is_hostname;
/*      */   protected boolean _is_IPv4address;
/*      */   protected boolean _is_IPv6reference;
/*      */   
/*      */   static
/*      */   {
/*  634 */     Locale locale = Locale.getDefault();
/*      */     
/*  636 */     if (locale != null) {
/*  637 */       defaultDocumentCharsetByLocale = LocaleToCharsetMap.getCharset(locale);
/*      */       
/*      */ 
/*  640 */       defaultDocumentCharset = defaultDocumentCharsetByLocale;
/*      */     }
/*      */     try
/*      */     {
/*  644 */       defaultDocumentCharsetByPlatform = System.getProperty("file.encoding");
/*      */     }
/*      */     catch (SecurityException ignore) {}
/*  647 */     if (defaultDocumentCharset == null)
/*      */     {
/*  649 */       defaultDocumentCharset = defaultDocumentCharsetByPlatform;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  711 */     rootPath = new char[] { '/' };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  720 */     percent = new BitSet(256);
/*      */     
/*      */ 
/*  723 */     percent.set(37);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  734 */     digit = new BitSet(256);
/*      */     
/*      */ 
/*  737 */     for (int i = 48; i <= 57; i++) {
/*  738 */       digit.set(i);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  749 */     alpha = new BitSet(256);
/*      */     
/*      */ 
/*  752 */     for (int i = 97; i <= 122; i++) {
/*  753 */       alpha.set(i);
/*      */     }
/*  755 */     for (int i = 65; i <= 90; i++) {
/*  756 */       alpha.set(i);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  767 */     alphanum = new BitSet(256);
/*      */     
/*      */ 
/*  770 */     alphanum.or(alpha);
/*  771 */     alphanum.or(digit);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  782 */     hex = new BitSet(256);
/*      */     
/*      */ 
/*  785 */     hex.or(digit);
/*  786 */     for (int i = 97; i <= 102; i++) {
/*  787 */       hex.set(i);
/*      */     }
/*  789 */     for (int i = 65; i <= 70; i++) {
/*  790 */       hex.set(i);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  801 */     escaped = new BitSet(256);
/*      */     
/*      */ 
/*  804 */     escaped.or(percent);
/*  805 */     escaped.or(hex);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  816 */     mark = new BitSet(256);
/*      */     
/*      */ 
/*  819 */     mark.set(45);
/*  820 */     mark.set(95);
/*  821 */     mark.set(46);
/*  822 */     mark.set(33);
/*  823 */     mark.set(126);
/*  824 */     mark.set(42);
/*  825 */     mark.set(39);
/*  826 */     mark.set(40);
/*  827 */     mark.set(41);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  838 */     unreserved = new BitSet(256);
/*      */     
/*      */ 
/*  841 */     unreserved.or(alphanum);
/*  842 */     unreserved.or(mark);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  853 */     reserved = new BitSet(256);
/*      */     
/*      */ 
/*  856 */     reserved.set(59);
/*  857 */     reserved.set(47);
/*  858 */     reserved.set(63);
/*  859 */     reserved.set(58);
/*  860 */     reserved.set(64);
/*  861 */     reserved.set(38);
/*  862 */     reserved.set(61);
/*  863 */     reserved.set(43);
/*  864 */     reserved.set(36);
/*  865 */     reserved.set(44);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  875 */     uric = new BitSet(256);
/*      */     
/*      */ 
/*  878 */     uric.or(reserved);
/*  879 */     uric.or(unreserved);
/*  880 */     uric.or(escaped);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  890 */     fragment = uric;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  899 */     query = uric;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  909 */     pchar = new BitSet(256);
/*      */     
/*      */ 
/*  912 */     pchar.or(unreserved);
/*  913 */     pchar.or(escaped);
/*  914 */     pchar.set(58);
/*  915 */     pchar.set(64);
/*  916 */     pchar.set(38);
/*  917 */     pchar.set(61);
/*  918 */     pchar.set(43);
/*  919 */     pchar.set(36);
/*  920 */     pchar.set(44);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  930 */     param = pchar;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  939 */     segment = new BitSet(256);
/*      */     
/*      */ 
/*  942 */     segment.or(pchar);
/*  943 */     segment.set(59);
/*  944 */     segment.or(param);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  954 */     path_segments = new BitSet(256);
/*      */     
/*      */ 
/*  957 */     path_segments.set(47);
/*  958 */     path_segments.or(segment);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  968 */     abs_path = new BitSet(256);
/*      */     
/*      */ 
/*  971 */     abs_path.set(47);
/*  972 */     abs_path.or(path_segments);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  983 */     uric_no_slash = new BitSet(256);
/*      */     
/*      */ 
/*  986 */     uric_no_slash.or(unreserved);
/*  987 */     uric_no_slash.or(escaped);
/*  988 */     uric_no_slash.set(59);
/*  989 */     uric_no_slash.set(63);
/*  990 */     uric_no_slash.set(59);
/*  991 */     uric_no_slash.set(64);
/*  992 */     uric_no_slash.set(38);
/*  993 */     uric_no_slash.set(61);
/*  994 */     uric_no_slash.set(43);
/*  995 */     uric_no_slash.set(36);
/*  996 */     uric_no_slash.set(44);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1006 */     opaque_part = new BitSet(256);
/*      */     
/*      */ 
/*      */ 
/* 1010 */     opaque_part.or(uric_no_slash);
/* 1011 */     opaque_part.or(uric);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1021 */     path = new BitSet(256);
/*      */     
/*      */ 
/* 1024 */     path.or(abs_path);
/* 1025 */     path.or(opaque_part);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1032 */     port = digit;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1041 */     IPv4address = new BitSet(256);
/*      */     
/*      */ 
/* 1044 */     IPv4address.or(digit);
/* 1045 */     IPv4address.set(46);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1055 */     IPv6address = new BitSet(256);
/*      */     
/*      */ 
/* 1058 */     IPv6address.or(hex);
/* 1059 */     IPv6address.set(58);
/* 1060 */     IPv6address.or(IPv4address);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1070 */     IPv6reference = new BitSet(256);
/*      */     
/*      */ 
/* 1073 */     IPv6reference.set(91);
/* 1074 */     IPv6reference.or(IPv6address);
/* 1075 */     IPv6reference.set(93);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1085 */     toplabel = new BitSet(256);
/*      */     
/*      */ 
/* 1088 */     toplabel.or(alphanum);
/* 1089 */     toplabel.set(45);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1099 */     domainlabel = toplabel;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1108 */     hostname = new BitSet(256);
/*      */     
/*      */ 
/* 1111 */     hostname.or(toplabel);
/*      */     
/* 1113 */     hostname.set(46);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1123 */     host = new BitSet(256);
/*      */     
/*      */ 
/* 1126 */     host.or(hostname);
/*      */     
/* 1128 */     host.or(IPv6reference);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1138 */     hostport = new BitSet(256);
/*      */     
/*      */ 
/* 1141 */     hostport.or(host);
/* 1142 */     hostport.set(58);
/* 1143 */     hostport.or(port);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1154 */     userinfo = new BitSet(256);
/*      */     
/*      */ 
/* 1157 */     userinfo.or(unreserved);
/* 1158 */     userinfo.or(escaped);
/* 1159 */     userinfo.set(59);
/* 1160 */     userinfo.set(58);
/* 1161 */     userinfo.set(38);
/* 1162 */     userinfo.set(61);
/* 1163 */     userinfo.set(43);
/* 1164 */     userinfo.set(36);
/* 1165 */     userinfo.set(44);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1172 */     within_userinfo = new BitSet(256);
/*      */     
/*      */ 
/* 1175 */     within_userinfo.or(userinfo);
/* 1176 */     within_userinfo.clear(59);
/* 1177 */     within_userinfo.clear(58);
/* 1178 */     within_userinfo.clear(64);
/* 1179 */     within_userinfo.clear(63);
/* 1180 */     within_userinfo.clear(47);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1190 */     server = new BitSet(256);
/*      */     
/*      */ 
/* 1193 */     server.or(userinfo);
/* 1194 */     server.set(64);
/* 1195 */     server.or(hostport);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1206 */     reg_name = new BitSet(256);
/*      */     
/*      */ 
/* 1209 */     reg_name.or(unreserved);
/* 1210 */     reg_name.or(escaped);
/* 1211 */     reg_name.set(36);
/* 1212 */     reg_name.set(44);
/* 1213 */     reg_name.set(59);
/* 1214 */     reg_name.set(58);
/* 1215 */     reg_name.set(64);
/* 1216 */     reg_name.set(38);
/* 1217 */     reg_name.set(61);
/* 1218 */     reg_name.set(43);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1228 */     authority = new BitSet(256);
/*      */     
/*      */ 
/* 1231 */     authority.or(server);
/* 1232 */     authority.or(reg_name);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1242 */     scheme = new BitSet(256);
/*      */     
/*      */ 
/* 1245 */     scheme.or(alpha);
/* 1246 */     scheme.or(digit);
/* 1247 */     scheme.set(43);
/* 1248 */     scheme.set(45);
/* 1249 */     scheme.set(46);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1260 */     rel_segment = new BitSet(256);
/*      */     
/*      */ 
/* 1263 */     rel_segment.or(unreserved);
/* 1264 */     rel_segment.or(escaped);
/* 1265 */     rel_segment.set(59);
/* 1266 */     rel_segment.set(64);
/* 1267 */     rel_segment.set(38);
/* 1268 */     rel_segment.set(61);
/* 1269 */     rel_segment.set(43);
/* 1270 */     rel_segment.set(36);
/* 1271 */     rel_segment.set(44);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1281 */     rel_path = new BitSet(256);
/*      */     
/*      */ 
/* 1284 */     rel_path.or(rel_segment);
/* 1285 */     rel_path.or(abs_path);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1295 */     net_path = new BitSet(256);
/*      */     
/*      */ 
/* 1298 */     net_path.set(47);
/* 1299 */     net_path.or(authority);
/* 1300 */     net_path.or(abs_path);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1310 */     hier_part = new BitSet(256);
/*      */     
/*      */ 
/* 1313 */     hier_part.or(net_path);
/* 1314 */     hier_part.or(abs_path);
/*      */     
/* 1316 */     hier_part.or(query);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1326 */     relativeURI = new BitSet(256);
/*      */     
/*      */ 
/* 1329 */     relativeURI.or(net_path);
/* 1330 */     relativeURI.or(abs_path);
/* 1331 */     relativeURI.or(rel_path);
/*      */     
/* 1333 */     relativeURI.or(query);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1343 */     absoluteURI = new BitSet(256);
/*      */     
/*      */ 
/* 1346 */     absoluteURI.or(scheme);
/* 1347 */     absoluteURI.set(58);
/* 1348 */     absoluteURI.or(hier_part);
/* 1349 */     absoluteURI.or(opaque_part);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1359 */     URI_reference = new BitSet(256);
/*      */     
/*      */ 
/* 1362 */     URI_reference.or(absoluteURI);
/* 1363 */     URI_reference.or(relativeURI);
/* 1364 */     URI_reference.set(35);
/* 1365 */     URI_reference.or(fragment);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1374 */     control = new BitSet(256);
/*      */     
/*      */ 
/* 1377 */     for (int i = 0; i <= 31; i++) {
/* 1378 */       control.set(i);
/*      */     }
/* 1380 */     control.set(127);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1386 */     space = new BitSet(256);
/*      */     
/*      */ 
/* 1389 */     space.set(32);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1396 */     delims = new BitSet(256);
/*      */     
/*      */ 
/* 1399 */     delims.set(60);
/* 1400 */     delims.set(62);
/* 1401 */     delims.set(35);
/* 1402 */     delims.set(37);
/* 1403 */     delims.set(34);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1410 */     unwise = new BitSet(256);
/*      */     
/*      */ 
/* 1413 */     unwise.set(123);
/* 1414 */     unwise.set(125);
/* 1415 */     unwise.set(124);
/* 1416 */     unwise.set(92);
/* 1417 */     unwise.set(94);
/* 1418 */     unwise.set(91);
/* 1419 */     unwise.set(93);
/* 1420 */     unwise.set(96);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1427 */     disallowed_rel_path = new BitSet(256);
/*      */     
/*      */ 
/* 1430 */     disallowed_rel_path.or(uric);
/* 1431 */     disallowed_rel_path.andNot(rel_path);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1438 */     disallowed_opaque_part = new BitSet(256);
/*      */     
/*      */ 
/* 1441 */     disallowed_opaque_part.or(uric);
/* 1442 */     disallowed_opaque_part.andNot(opaque_part);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1450 */     allowed_authority = new BitSet(256);
/*      */     
/*      */ 
/* 1453 */     allowed_authority.or(authority);
/* 1454 */     allowed_authority.clear(37);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1461 */     allowed_opaque_part = new BitSet(256);
/*      */     
/*      */ 
/* 1464 */     allowed_opaque_part.or(opaque_part);
/* 1465 */     allowed_opaque_part.clear(37);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1472 */     allowed_reg_name = new BitSet(256);
/*      */     
/*      */ 
/* 1475 */     allowed_reg_name.or(reg_name);
/*      */     
/* 1477 */     allowed_reg_name.clear(37);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1484 */     allowed_userinfo = new BitSet(256);
/*      */     
/*      */ 
/* 1487 */     allowed_userinfo.or(userinfo);
/*      */     
/* 1489 */     allowed_userinfo.clear(37);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1496 */     allowed_within_userinfo = new BitSet(256);
/*      */     
/*      */ 
/* 1499 */     allowed_within_userinfo.or(within_userinfo);
/* 1500 */     allowed_within_userinfo.clear(37);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1508 */     allowed_IPv6reference = new BitSet(256);
/*      */     
/*      */ 
/* 1511 */     allowed_IPv6reference.or(IPv6reference);
/*      */     
/* 1513 */     allowed_IPv6reference.clear(91);
/* 1514 */     allowed_IPv6reference.clear(93);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1522 */     allowed_host = new BitSet(256);
/*      */     
/*      */ 
/* 1525 */     allowed_host.or(hostname);
/* 1526 */     allowed_host.or(allowed_IPv6reference);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1533 */     allowed_within_authority = new BitSet(256);
/*      */     
/*      */ 
/* 1536 */     allowed_within_authority.or(server);
/* 1537 */     allowed_within_authority.or(reg_name);
/* 1538 */     allowed_within_authority.clear(59);
/* 1539 */     allowed_within_authority.clear(58);
/* 1540 */     allowed_within_authority.clear(64);
/* 1541 */     allowed_within_authority.clear(63);
/* 1542 */     allowed_within_authority.clear(47);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1549 */     allowed_abs_path = new BitSet(256);
/*      */     
/*      */ 
/* 1552 */     allowed_abs_path.or(abs_path);
/*      */     
/* 1554 */     allowed_abs_path.andNot(percent);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1561 */     allowed_rel_path = new BitSet(256);
/*      */     
/*      */ 
/* 1564 */     allowed_rel_path.or(rel_path);
/* 1565 */     allowed_rel_path.clear(37);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1572 */     allowed_within_path = new BitSet(256);
/*      */     
/*      */ 
/* 1575 */     allowed_within_path.or(abs_path);
/* 1576 */     allowed_within_path.clear(47);
/* 1577 */     allowed_within_path.clear(59);
/* 1578 */     allowed_within_path.clear(61);
/* 1579 */     allowed_within_path.clear(63);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1586 */     allowed_query = new BitSet(256);
/*      */     
/*      */ 
/* 1589 */     allowed_query.or(uric);
/* 1590 */     allowed_query.clear(37);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1597 */     allowed_within_query = new BitSet(256);
/*      */     
/*      */ 
/* 1600 */     allowed_within_query.or(allowed_query);
/* 1601 */     allowed_within_query.andNot(reserved);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1608 */     allowed_fragment = new BitSet(256);
/*      */     
/*      */ 
/* 1611 */     allowed_fragment.or(uric);
/* 1612 */     allowed_fragment.clear(37);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static char[] encode(String original, BitSet allowed, String charset)
/*      */     throws URIException
/*      */   {
/* 1678 */     if (original == null) {
/* 1679 */       throw new IllegalArgumentException("Original string may not be null");
/*      */     }
/* 1681 */     if (allowed == null) {
/* 1682 */       throw new IllegalArgumentException("Allowed bitset may not be null");
/*      */     }
/* 1684 */     byte[] rawdata = URLCodec.encodeUrl(allowed, EncodingUtil.getBytes(original, charset));
/* 1685 */     return EncodingUtil.getAsciiString(rawdata).toCharArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static String decode(char[] component, String charset)
/*      */     throws URIException
/*      */   {
/* 1720 */     if (component == null) {
/* 1721 */       throw new IllegalArgumentException("Component array of chars may not be null");
/*      */     }
/* 1723 */     return decode(new String(component), charset);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static String decode(String component, String charset)
/*      */     throws URIException
/*      */   {
/* 1760 */     if (component == null) {
/* 1761 */       throw new IllegalArgumentException("Component array of chars may not be null");
/*      */     }
/* 1763 */     byte[] rawdata = null;
/*      */     try {
/* 1765 */       rawdata = URLCodec.decodeUrl(EncodingUtil.getAsciiBytes(component));
/*      */     } catch (DecoderException e) {
/* 1767 */       throw new URIException(e.getMessage());
/*      */     }
/* 1769 */     return EncodingUtil.getString(rawdata, charset);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean prevalidate(String component, BitSet disallowed)
/*      */   {
/* 1781 */     if (component == null) {
/* 1782 */       return false;
/*      */     }
/* 1784 */     char[] target = component.toCharArray();
/* 1785 */     for (int i = 0; i < target.length; i++) {
/* 1786 */       if (disallowed.get(target[i])) {
/* 1787 */         return false;
/*      */       }
/*      */     }
/* 1790 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean validate(char[] component, BitSet generous)
/*      */   {
/* 1805 */     return validate(component, 0, -1, generous);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean validate(char[] component, int soffset, int eoffset, BitSet generous)
/*      */   {
/* 1827 */     if (eoffset == -1) {
/* 1828 */       eoffset = component.length - 1;
/*      */     }
/* 1830 */     for (int i = soffset; i <= eoffset; i++) {
/* 1831 */       if (!generous.get(component[i])) {
/* 1832 */         return false;
/*      */       }
/*      */     }
/* 1835 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void parseUriReference(String original, boolean escaped)
/*      */     throws URIException
/*      */   {
/* 1873 */     if (original == null) {
/* 1874 */       throw new URIException("URI-Reference required");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1880 */     String tmp = original.trim();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1886 */     int length = tmp.length();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1891 */     if (length > 0) {
/* 1892 */       char[] firstDelimiter = { tmp.charAt(0) };
/* 1893 */       if ((validate(firstDelimiter, delims)) && 
/* 1894 */         (length >= 2)) {
/* 1895 */         char[] lastDelimiter = { tmp.charAt(length - 1) };
/* 1896 */         if (validate(lastDelimiter, delims)) {
/* 1897 */           tmp = tmp.substring(1, length - 1);
/* 1898 */           length -= 2;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1907 */     int from = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1912 */     boolean isStartedFromPath = false;
/* 1913 */     int atColon = tmp.indexOf(':');
/* 1914 */     int atSlash = tmp.indexOf('/');
/* 1915 */     if ((atColon <= 0) || ((atSlash >= 0) && (atSlash < atColon))) {
/* 1916 */       isStartedFromPath = true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1925 */     int at = indexFirstOf(tmp, isStartedFromPath ? "/?#" : ":/?#", from);
/* 1926 */     if (at == -1) {
/* 1927 */       at = 0;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1938 */     if ((at > 0) && (at < length) && (tmp.charAt(at) == ':')) {
/* 1939 */       char[] target = tmp.substring(0, at).toLowerCase().toCharArray();
/* 1940 */       if (validate(target, scheme)) {
/* 1941 */         this._scheme = target;
/*      */       } else {
/* 1943 */         throw new URIException("incorrect scheme");
/*      */       }
/* 1945 */       at++;from = at;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1957 */     this._is_net_path = (this._is_abs_path = this._is_rel_path = this._is_hier_part = 0);
/* 1958 */     if ((0 <= at) && (at < length) && (tmp.charAt(at) == '/'))
/*      */     {
/* 1960 */       this._is_hier_part = true;
/* 1961 */       if ((at + 2 < length) && (tmp.charAt(at + 1) == '/'))
/*      */       {
/* 1963 */         int next = indexFirstOf(tmp, "/?#", at + 2);
/* 1964 */         if (next == -1) {
/* 1965 */           next = tmp.substring(at + 2).length() == 0 ? at + 2 : tmp.length();
/*      */         }
/*      */         
/* 1968 */         parseAuthority(tmp.substring(at + 2, next), escaped);
/* 1969 */         from = at = next;
/*      */         
/* 1971 */         this._is_net_path = true;
/*      */       }
/* 1973 */       if (from == at)
/*      */       {
/* 1975 */         this._is_abs_path = true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1987 */     if (from < length)
/*      */     {
/* 1989 */       int next = indexFirstOf(tmp, "?#", from);
/* 1990 */       if (next == -1) {
/* 1991 */         next = tmp.length();
/*      */       }
/* 1993 */       if (!this._is_abs_path) {
/* 1994 */         if (((!escaped) && (prevalidate(tmp.substring(from, next), disallowed_rel_path))) || ((escaped) && (validate(tmp.substring(from, next).toCharArray(), rel_path))))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 1999 */           this._is_rel_path = true;
/* 2000 */         } else if (((!escaped) && (prevalidate(tmp.substring(from, next), disallowed_opaque_part))) || ((escaped) && (validate(tmp.substring(from, next).toCharArray(), opaque_part))))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 2005 */           this._is_opaque_part = true;
/*      */         }
/*      */         else {
/* 2008 */           this._path = null;
/*      */         }
/*      */       }
/* 2011 */       if (escaped) {
/* 2012 */         setRawPath(tmp.substring(from, next).toCharArray());
/*      */       } else {
/* 2014 */         setPath(tmp.substring(from, next));
/*      */       }
/* 2016 */       at = next;
/*      */     }
/*      */     
/*      */ 
/* 2020 */     String charset = getProtocolCharset();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2030 */     if ((0 <= at) && (at + 1 < length) && (tmp.charAt(at) == '?')) {
/* 2031 */       int next = tmp.indexOf('#', at + 1);
/* 2032 */       if (next == -1) {
/* 2033 */         next = tmp.length();
/*      */       }
/* 2035 */       this._query = (escaped ? tmp.substring(at + 1, next).toCharArray() : encode(tmp.substring(at + 1, next), allowed_query, charset));
/*      */       
/* 2037 */       at = next;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2048 */     if ((0 <= at) && (at + 1 <= length) && (tmp.charAt(at) == '#')) {
/* 2049 */       if (at + 1 == length) {
/* 2050 */         this._fragment = "".toCharArray();
/*      */       } else {
/* 2052 */         this._fragment = (escaped ? tmp.substring(at + 1).toCharArray() : encode(tmp.substring(at + 1), allowed_fragment, charset));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2058 */     setURI();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int indexFirstOf(String s, String delims)
/*      */   {
/* 2071 */     return indexFirstOf(s, delims, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int indexFirstOf(String s, String delims, int offset)
/*      */   {
/* 2085 */     if ((s == null) || (s.length() == 0)) {
/* 2086 */       return -1;
/*      */     }
/* 2088 */     if ((delims == null) || (delims.length() == 0)) {
/* 2089 */       return -1;
/*      */     }
/*      */     
/* 2092 */     if (offset < 0) {
/* 2093 */       offset = 0;
/* 2094 */     } else if (offset > s.length()) {
/* 2095 */       return -1;
/*      */     }
/*      */     
/* 2098 */     int min = s.length();
/* 2099 */     char[] delim = delims.toCharArray();
/* 2100 */     for (int i = 0; i < delim.length; i++) {
/* 2101 */       int at = s.indexOf(delim[i], offset);
/* 2102 */       if ((at >= 0) && (at < min)) {
/* 2103 */         min = at;
/*      */       }
/*      */     }
/* 2106 */     return min == s.length() ? -1 : min;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int indexFirstOf(char[] s, char delim)
/*      */   {
/* 2119 */     return indexFirstOf(s, delim, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int indexFirstOf(char[] s, char delim, int offset)
/*      */   {
/* 2133 */     if ((s == null) || (s.length == 0)) {
/* 2134 */       return -1;
/*      */     }
/*      */     
/* 2137 */     if (offset < 0) {
/* 2138 */       offset = 0;
/* 2139 */     } else if (offset > s.length) {
/* 2140 */       return -1;
/*      */     }
/* 2142 */     for (int i = offset; i < s.length; i++) {
/* 2143 */       if (s[i] == delim) {
/* 2144 */         return i;
/*      */       }
/*      */     }
/* 2147 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void parseAuthority(String original, boolean escaped)
/*      */     throws URIException
/*      */   {
/* 2162 */     this._is_reg_name = (this._is_server = this._is_hostname = this._is_IPv4address = this._is_IPv6reference = 0);
/*      */     
/*      */ 
/*      */ 
/* 2166 */     String charset = getProtocolCharset();
/*      */     
/* 2168 */     boolean hasPort = true;
/* 2169 */     int from = 0;
/* 2170 */     int next = original.indexOf('@');
/* 2171 */     if (next != -1)
/*      */     {
/* 2173 */       this._userinfo = (escaped ? original.substring(0, next).toCharArray() : encode(original.substring(0, next), allowed_userinfo, charset));
/*      */       
/*      */ 
/* 2176 */       from = next + 1;
/*      */     }
/* 2178 */     next = original.indexOf('[', from);
/* 2179 */     if (next >= from) {
/* 2180 */       next = original.indexOf(']', from);
/* 2181 */       if (next == -1) {
/* 2182 */         throw new URIException(1, "IPv6reference");
/*      */       }
/* 2184 */       next++;
/*      */       
/*      */ 
/* 2187 */       this._host = (escaped ? original.substring(from, next).toCharArray() : encode(original.substring(from, next), allowed_IPv6reference, charset));
/*      */       
/*      */ 
/*      */ 
/* 2191 */       this._is_IPv6reference = true;
/*      */     } else {
/* 2193 */       next = original.indexOf(':', from);
/* 2194 */       if (next == -1) {
/* 2195 */         next = original.length();
/* 2196 */         hasPort = false;
/*      */       }
/*      */       
/* 2199 */       this._host = original.substring(from, next).toCharArray();
/* 2200 */       if (validate(this._host, IPv4address))
/*      */       {
/* 2202 */         this._is_IPv4address = true;
/* 2203 */       } else if (validate(this._host, hostname))
/*      */       {
/* 2205 */         this._is_hostname = true;
/*      */       }
/*      */       else {
/* 2208 */         this._is_reg_name = true;
/*      */       }
/*      */     }
/* 2211 */     if (this._is_reg_name)
/*      */     {
/* 2213 */       this._is_server = (this._is_hostname = this._is_IPv4address = this._is_IPv6reference = 0);
/*      */       
/*      */ 
/* 2216 */       this._authority = (escaped ? original.toString().toCharArray() : encode(original.toString(), allowed_reg_name, charset));
/*      */     }
/*      */     else {
/* 2219 */       if ((original.length() - 1 > next) && (hasPort) && (original.charAt(next) == ':'))
/*      */       {
/* 2221 */         from = next + 1;
/*      */         try {
/* 2223 */           this._port = Integer.parseInt(original.substring(from));
/*      */         } catch (NumberFormatException error) {
/* 2225 */           throw new URIException(1, "invalid port number");
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 2230 */       StringBuffer buf = new StringBuffer();
/* 2231 */       if (this._userinfo != null) {
/* 2232 */         buf.append(this._userinfo);
/* 2233 */         buf.append('@');
/*      */       }
/* 2235 */       if (this._host != null) {
/* 2236 */         buf.append(this._host);
/* 2237 */         if (this._port != -1) {
/* 2238 */           buf.append(':');
/* 2239 */           buf.append(this._port);
/*      */         }
/*      */       }
/* 2242 */       this._authority = buf.toString().toCharArray();
/*      */       
/* 2244 */       this._is_server = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setURI()
/*      */   {
/* 2256 */     StringBuffer buf = new StringBuffer();
/*      */     
/* 2258 */     if (this._scheme != null) {
/* 2259 */       buf.append(this._scheme);
/* 2260 */       buf.append(':');
/*      */     }
/* 2262 */     if (this._is_net_path) {
/* 2263 */       buf.append("//");
/* 2264 */       if (this._authority != null) {
/* 2265 */         buf.append(this._authority);
/*      */       }
/*      */     }
/* 2268 */     if ((this._opaque != null) && (this._is_opaque_part)) {
/* 2269 */       buf.append(this._opaque);
/* 2270 */     } else if (this._path != null)
/*      */     {
/* 2272 */       if (this._path.length != 0) {
/* 2273 */         buf.append(this._path);
/*      */       }
/*      */     }
/* 2276 */     if (this._query != null) {
/* 2277 */       buf.append('?');
/* 2278 */       buf.append(this._query);
/*      */     }
/*      */     
/* 2281 */     this._uri = buf.toString().toCharArray();
/* 2282 */     this.hash = 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isAbsoluteURI()
/*      */   {
/* 2294 */     return this._scheme != null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isRelativeURI()
/*      */   {
/* 2304 */     return this._scheme == null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isHierPart()
/*      */   {
/* 2314 */     return this._is_hier_part;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isOpaquePart()
/*      */   {
/* 2324 */     return this._is_opaque_part;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isNetPath()
/*      */   {
/* 2336 */     return (this._is_net_path) || (this._authority != null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isAbsPath()
/*      */   {
/* 2346 */     return this._is_abs_path;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isRelPath()
/*      */   {
/* 2356 */     return this._is_rel_path;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasAuthority()
/*      */   {
/* 2368 */     return (this._authority != null) || (this._is_net_path);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isRegName()
/*      */   {
/* 2377 */     return this._is_reg_name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isServer()
/*      */   {
/* 2387 */     return this._is_server;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasUserinfo()
/*      */   {
/* 2397 */     return this._userinfo != null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isHostname()
/*      */   {
/* 2407 */     return this._is_hostname;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isIPv4address()
/*      */   {
/* 2417 */     return this._is_IPv4address;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isIPv6reference()
/*      */   {
/* 2427 */     return this._is_IPv6reference;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasQuery()
/*      */   {
/* 2437 */     return this._query != null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasFragment()
/*      */   {
/* 2447 */     return this._fragment != null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void setDefaultProtocolCharset(String charset)
/*      */     throws URI.DefaultCharsetChanged
/*      */   {
/* 2499 */     defaultProtocolCharset = charset;
/* 2500 */     throw new DefaultCharsetChanged(1, "the default protocol charset changed");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getDefaultProtocolCharset()
/*      */   {
/* 2520 */     return defaultProtocolCharset;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProtocolCharset()
/*      */   {
/* 2533 */     return this.protocolCharset != null ? this.protocolCharset : defaultProtocolCharset;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void setDefaultDocumentCharset(String charset)
/*      */     throws URI.DefaultCharsetChanged
/*      */   {
/* 2579 */     defaultDocumentCharset = charset;
/* 2580 */     throw new DefaultCharsetChanged(2, "the default document charset changed");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getDefaultDocumentCharset()
/*      */   {
/* 2591 */     return defaultDocumentCharset;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getDefaultDocumentCharsetByLocale()
/*      */   {
/* 2601 */     return defaultDocumentCharsetByLocale;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getDefaultDocumentCharsetByPlatform()
/*      */   {
/* 2611 */     return defaultDocumentCharsetByPlatform;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public char[] getRawScheme()
/*      */   {
/* 2622 */     return this._scheme;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getScheme()
/*      */   {
/* 2633 */     return this._scheme == null ? null : new String(this._scheme);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRawAuthority(char[] escapedAuthority)
/*      */     throws URIException, NullPointerException
/*      */   {
/* 2653 */     parseAuthority(new String(escapedAuthority), true);
/* 2654 */     setURI();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEscapedAuthority(String escapedAuthority)
/*      */     throws URIException
/*      */   {
/* 2670 */     parseAuthority(escapedAuthority, true);
/* 2671 */     setURI();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public char[] getRawAuthority()
/*      */   {
/* 2681 */     return this._authority;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getEscapedAuthority()
/*      */   {
/* 2691 */     return this._authority == null ? null : new String(this._authority);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getAuthority()
/*      */     throws URIException
/*      */   {
/* 2702 */     return this._authority == null ? null : decode(this._authority, getProtocolCharset());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public char[] getRawUserinfo()
/*      */   {
/* 2715 */     return this._userinfo;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getEscapedUserinfo()
/*      */   {
/* 2726 */     return this._userinfo == null ? null : new String(this._userinfo);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getUserinfo()
/*      */     throws URIException
/*      */   {
/* 2738 */     return this._userinfo == null ? null : decode(this._userinfo, getProtocolCharset());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public char[] getRawHost()
/*      */   {
/* 2754 */     return this._host;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getHost()
/*      */     throws URIException
/*      */   {
/* 2769 */     if (this._host != null) {
/* 2770 */       return decode(this._host, getProtocolCharset());
/*      */     }
/* 2772 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getPort()
/*      */   {
/* 2788 */     return this._port;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRawPath(char[] escapedPath)
/*      */     throws URIException
/*      */   {
/* 2801 */     if ((escapedPath == null) || (escapedPath.length == 0)) {
/* 2802 */       this._path = (this._opaque = escapedPath);
/* 2803 */       setURI();
/* 2804 */       return;
/*      */     }
/*      */     
/* 2807 */     escapedPath = removeFragmentIdentifier(escapedPath);
/* 2808 */     if ((this._is_net_path) || (this._is_abs_path)) {
/* 2809 */       if (escapedPath[0] != '/') {
/* 2810 */         throw new URIException(1, "not absolute path");
/*      */       }
/*      */       
/* 2813 */       if (!validate(escapedPath, abs_path)) {
/* 2814 */         throw new URIException(3, "escaped absolute path not valid");
/*      */       }
/*      */       
/* 2817 */       this._path = escapedPath;
/* 2818 */     } else if (this._is_rel_path) {
/* 2819 */       int at = indexFirstOf(escapedPath, '/');
/* 2820 */       if (at == 0) {
/* 2821 */         throw new URIException(1, "incorrect path");
/*      */       }
/* 2823 */       if (((at > 0) && (!validate(escapedPath, 0, at - 1, rel_segment)) && (!validate(escapedPath, at, -1, abs_path))) || ((at < 0) && (!validate(escapedPath, 0, -1, rel_segment))))
/*      */       {
/*      */ 
/*      */ 
/* 2827 */         throw new URIException(3, "escaped relative path not valid");
/*      */       }
/*      */       
/* 2830 */       this._path = escapedPath;
/* 2831 */     } else if (this._is_opaque_part) {
/* 2832 */       if ((!uric_no_slash.get(escapedPath[0])) && (!validate(escapedPath, 1, -1, uric)))
/*      */       {
/* 2834 */         throw new URIException(3, "escaped opaque part not valid");
/*      */       }
/*      */       
/* 2837 */       this._opaque = escapedPath;
/*      */     } else {
/* 2839 */       throw new URIException(1, "incorrect path");
/*      */     }
/* 2841 */     setURI();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEscapedPath(String escapedPath)
/*      */     throws URIException
/*      */   {
/* 2853 */     if (escapedPath == null) {
/* 2854 */       this._path = (this._opaque = null);
/* 2855 */       setURI();
/* 2856 */       return;
/*      */     }
/* 2858 */     setRawPath(escapedPath.toCharArray());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPath(String path)
/*      */     throws URIException
/*      */   {
/* 2871 */     if ((path == null) || (path.length() == 0)) {
/* 2872 */       this._path = (this._opaque = path == null ? null : path.toCharArray());
/* 2873 */       setURI();
/* 2874 */       return;
/*      */     }
/*      */     
/* 2877 */     String charset = getProtocolCharset();
/*      */     
/* 2879 */     if ((this._is_net_path) || (this._is_abs_path)) {
/* 2880 */       this._path = encode(path, allowed_abs_path, charset);
/* 2881 */     } else if (this._is_rel_path) {
/* 2882 */       StringBuffer buff = new StringBuffer(path.length());
/* 2883 */       int at = path.indexOf('/');
/* 2884 */       if (at == 0) {
/* 2885 */         throw new URIException(1, "incorrect relative path");
/*      */       }
/*      */       
/* 2888 */       if (at > 0) {
/* 2889 */         buff.append(encode(path.substring(0, at), allowed_rel_path, charset));
/*      */         
/* 2891 */         buff.append(encode(path.substring(at), allowed_abs_path, charset));
/*      */       }
/*      */       else {
/* 2894 */         buff.append(encode(path, allowed_rel_path, charset));
/*      */       }
/* 2896 */       this._path = buff.toString().toCharArray();
/* 2897 */     } else if (this._is_opaque_part) {
/* 2898 */       StringBuffer buf = new StringBuffer();
/* 2899 */       buf.insert(0, encode(path.substring(0, 1), uric_no_slash, charset));
/* 2900 */       buf.insert(1, encode(path.substring(1), uric, charset));
/* 2901 */       this._opaque = buf.toString().toCharArray();
/*      */     } else {
/* 2903 */       throw new URIException(1, "incorrect path");
/*      */     }
/* 2905 */     setURI();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected char[] resolvePath(char[] basePath, char[] relPath)
/*      */     throws URIException
/*      */   {
/* 2921 */     String base = basePath == null ? "" : new String(basePath);
/* 2922 */     int at = base.lastIndexOf('/');
/* 2923 */     if (at != -1) {
/* 2924 */       basePath = base.substring(0, at + 1).toCharArray();
/*      */     }
/*      */     
/* 2927 */     if ((relPath == null) || (relPath.length == 0))
/* 2928 */       return normalize(basePath);
/* 2929 */     if (relPath[0] == '/') {
/* 2930 */       return normalize(relPath);
/*      */     }
/* 2932 */     StringBuffer buff = new StringBuffer(base.length() + relPath.length);
/*      */     
/* 2934 */     buff.append(at != -1 ? base.substring(0, at + 1) : "/");
/* 2935 */     buff.append(relPath);
/* 2936 */     return normalize(buff.toString().toCharArray());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected char[] getRawCurrentHierPath(char[] path)
/*      */     throws URIException
/*      */   {
/* 2952 */     if (this._is_opaque_part) {
/* 2953 */       throw new URIException(1, "no hierarchy level");
/*      */     }
/* 2955 */     if (path == null) {
/* 2956 */       throw new URIException(1, "empty path");
/*      */     }
/* 2958 */     String buff = new String(path);
/* 2959 */     int first = buff.indexOf('/');
/* 2960 */     int last = buff.lastIndexOf('/');
/* 2961 */     if (last == 0)
/* 2962 */       return rootPath;
/* 2963 */     if ((first != last) && (last != -1)) {
/* 2964 */       return buff.substring(0, last).toCharArray();
/*      */     }
/*      */     
/* 2967 */     return path;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public char[] getRawCurrentHierPath()
/*      */     throws URIException
/*      */   {
/* 2978 */     return this._path == null ? null : getRawCurrentHierPath(this._path);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getEscapedCurrentHierPath()
/*      */     throws URIException
/*      */   {
/* 2989 */     char[] path = getRawCurrentHierPath();
/* 2990 */     return path == null ? null : new String(path);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCurrentHierPath()
/*      */     throws URIException
/*      */   {
/* 3002 */     char[] path = getRawCurrentHierPath();
/* 3003 */     return path == null ? null : decode(path, getProtocolCharset());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public char[] getRawAboveHierPath()
/*      */     throws URIException
/*      */   {
/* 3014 */     char[] path = getRawCurrentHierPath();
/* 3015 */     return path == null ? null : getRawCurrentHierPath(path);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getEscapedAboveHierPath()
/*      */     throws URIException
/*      */   {
/* 3026 */     char[] path = getRawAboveHierPath();
/* 3027 */     return path == null ? null : new String(path);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getAboveHierPath()
/*      */     throws URIException
/*      */   {
/* 3039 */     char[] path = getRawAboveHierPath();
/* 3040 */     return path == null ? null : decode(path, getProtocolCharset());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public char[] getRawPath()
/*      */   {
/* 3053 */     return this._is_opaque_part ? this._opaque : this._path;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getEscapedPath()
/*      */   {
/* 3068 */     char[] path = getRawPath();
/* 3069 */     return path == null ? null : new String(path);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPath()
/*      */     throws URIException
/*      */   {
/* 3083 */     char[] path = getRawPath();
/* 3084 */     return path == null ? null : decode(path, getProtocolCharset());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public char[] getRawName()
/*      */   {
/* 3094 */     if (this._path == null) {
/* 3095 */       return null;
/*      */     }
/*      */     
/* 3098 */     int at = 0;
/* 3099 */     for (int i = this._path.length - 1; i >= 0; i--) {
/* 3100 */       if (this._path[i] == '/') {
/* 3101 */         at = i + 1;
/* 3102 */         break;
/*      */       }
/*      */     }
/* 3105 */     int len = this._path.length - at;
/* 3106 */     char[] basename = new char[len];
/* 3107 */     System.arraycopy(this._path, at, basename, 0, len);
/* 3108 */     return basename;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getEscapedName()
/*      */   {
/* 3118 */     char[] basename = getRawName();
/* 3119 */     return basename == null ? null : new String(basename);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getName()
/*      */     throws URIException
/*      */   {
/* 3132 */     char[] basename = getRawName();
/* 3133 */     return basename == null ? null : decode(getRawName(), getProtocolCharset());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public char[] getRawPathQuery()
/*      */   {
/* 3146 */     if ((this._path == null) && (this._query == null)) {
/* 3147 */       return null;
/*      */     }
/* 3149 */     StringBuffer buff = new StringBuffer();
/* 3150 */     if (this._path != null) {
/* 3151 */       buff.append(this._path);
/*      */     }
/* 3153 */     if (this._query != null) {
/* 3154 */       buff.append('?');
/* 3155 */       buff.append(this._query);
/*      */     }
/* 3157 */     return buff.toString().toCharArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getEscapedPathQuery()
/*      */   {
/* 3167 */     char[] rawPathQuery = getRawPathQuery();
/* 3168 */     return rawPathQuery == null ? null : new String(rawPathQuery);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPathQuery()
/*      */     throws URIException
/*      */   {
/* 3181 */     char[] rawPathQuery = getRawPathQuery();
/* 3182 */     return rawPathQuery == null ? null : decode(rawPathQuery, getProtocolCharset());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRawQuery(char[] escapedQuery)
/*      */     throws URIException
/*      */   {
/* 3195 */     if ((escapedQuery == null) || (escapedQuery.length == 0)) {
/* 3196 */       this._query = escapedQuery;
/* 3197 */       setURI();
/* 3198 */       return;
/*      */     }
/*      */     
/* 3201 */     escapedQuery = removeFragmentIdentifier(escapedQuery);
/* 3202 */     if (!validate(escapedQuery, query)) {
/* 3203 */       throw new URIException(3, "escaped query not valid");
/*      */     }
/*      */     
/* 3206 */     this._query = escapedQuery;
/* 3207 */     setURI();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEscapedQuery(String escapedQuery)
/*      */     throws URIException
/*      */   {
/* 3218 */     if (escapedQuery == null) {
/* 3219 */       this._query = null;
/* 3220 */       setURI();
/* 3221 */       return;
/*      */     }
/* 3223 */     setRawQuery(escapedQuery.toCharArray());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setQuery(String query)
/*      */     throws URIException
/*      */   {
/* 3245 */     if ((query == null) || (query.length() == 0)) {
/* 3246 */       this._query = (query == null ? null : query.toCharArray());
/* 3247 */       setURI();
/* 3248 */       return;
/*      */     }
/* 3250 */     setRawQuery(encode(query, allowed_query, getProtocolCharset()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public char[] getRawQuery()
/*      */   {
/* 3260 */     return this._query;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getEscapedQuery()
/*      */   {
/* 3270 */     return this._query == null ? null : new String(this._query);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getQuery()
/*      */     throws URIException
/*      */   {
/* 3283 */     return this._query == null ? null : decode(this._query, getProtocolCharset());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRawFragment(char[] escapedFragment)
/*      */     throws URIException
/*      */   {
/* 3295 */     if ((escapedFragment == null) || (escapedFragment.length == 0)) {
/* 3296 */       this._fragment = escapedFragment;
/* 3297 */       this.hash = 0;
/* 3298 */       return;
/*      */     }
/* 3300 */     if (!validate(escapedFragment, fragment)) {
/* 3301 */       throw new URIException(3, "escaped fragment not valid");
/*      */     }
/*      */     
/* 3304 */     this._fragment = escapedFragment;
/* 3305 */     this.hash = 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEscapedFragment(String escapedFragment)
/*      */     throws URIException
/*      */   {
/* 3316 */     if (escapedFragment == null) {
/* 3317 */       this._fragment = null;
/* 3318 */       this.hash = 0;
/* 3319 */       return;
/*      */     }
/* 3321 */     setRawFragment(escapedFragment.toCharArray());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFragment(String fragment)
/*      */     throws URIException
/*      */   {
/* 3332 */     if ((fragment == null) || (fragment.length() == 0)) {
/* 3333 */       this._fragment = (fragment == null ? null : fragment.toCharArray());
/* 3334 */       this.hash = 0;
/* 3335 */       return;
/*      */     }
/* 3337 */     this._fragment = encode(fragment, allowed_fragment, getProtocolCharset());
/* 3338 */     this.hash = 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public char[] getRawFragment()
/*      */   {
/* 3358 */     return this._fragment;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getEscapedFragment()
/*      */   {
/* 3368 */     return this._fragment == null ? null : new String(this._fragment);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getFragment()
/*      */     throws URIException
/*      */   {
/* 3381 */     return this._fragment == null ? null : decode(this._fragment, getProtocolCharset());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected char[] removeFragmentIdentifier(char[] component)
/*      */   {
/* 3394 */     if (component == null) {
/* 3395 */       return null;
/*      */     }
/* 3397 */     int lastIndex = new String(component).indexOf('#');
/* 3398 */     if (lastIndex != -1) {
/* 3399 */       component = new String(component).substring(0, lastIndex).toCharArray();
/*      */     }
/*      */     
/* 3402 */     return component;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected char[] normalize(char[] path)
/*      */     throws URIException
/*      */   {
/* 3418 */     if (path == null) {
/* 3419 */       return null;
/*      */     }
/*      */     
/* 3422 */     String normalized = new String(path);
/*      */     
/*      */ 
/* 3425 */     if (normalized.startsWith("./")) {
/* 3426 */       normalized = normalized.substring(1);
/* 3427 */     } else if (normalized.startsWith("../")) {
/* 3428 */       normalized = normalized.substring(2);
/* 3429 */     } else if (normalized.startsWith("..")) {
/* 3430 */       normalized = normalized.substring(2);
/*      */     }
/*      */     
/*      */ 
/* 3434 */     int index = -1;
/* 3435 */     while ((index = normalized.indexOf("/./")) != -1) {
/* 3436 */       normalized = normalized.substring(0, index) + normalized.substring(index + 2);
/*      */     }
/*      */     
/*      */ 
/* 3440 */     if (normalized.endsWith("/.")) {
/* 3441 */       normalized = normalized.substring(0, normalized.length() - 1);
/*      */     }
/*      */     
/* 3444 */     int startIndex = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3451 */     while ((index = normalized.indexOf("/../", startIndex)) != -1) {
/* 3452 */       int slashIndex = normalized.lastIndexOf('/', index - 1);
/* 3453 */       if (slashIndex >= 0) {
/* 3454 */         normalized = normalized.substring(0, slashIndex) + normalized.substring(index + 3);
/*      */       } else {
/* 3456 */         startIndex = index + 3;
/*      */       }
/*      */     }
/* 3459 */     if (normalized.endsWith("/..")) {
/* 3460 */       int slashIndex = normalized.lastIndexOf('/', normalized.length() - 4);
/* 3461 */       if (slashIndex >= 0) {
/* 3462 */         normalized = normalized.substring(0, slashIndex + 1);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3471 */     while ((index = normalized.indexOf("/../")) != -1) {
/* 3472 */       int slashIndex = normalized.lastIndexOf('/', index - 1);
/* 3473 */       if (slashIndex >= 0) {
/*      */         break;
/*      */       }
/* 3476 */       normalized = normalized.substring(index + 3);
/*      */     }
/*      */     
/* 3479 */     if (normalized.endsWith("/..")) {
/* 3480 */       int slashIndex = normalized.lastIndexOf('/', normalized.length() - 4);
/* 3481 */       if (slashIndex < 0) {
/* 3482 */         normalized = "/";
/*      */       }
/*      */     }
/*      */     
/* 3486 */     return normalized.toCharArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void normalize()
/*      */     throws URIException
/*      */   {
/* 3500 */     if (isAbsPath()) {
/* 3501 */       this._path = normalize(this._path);
/* 3502 */       setURI();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean equals(char[] first, char[] second)
/*      */   {
/* 3516 */     if ((first == null) && (second == null)) {
/* 3517 */       return true;
/*      */     }
/* 3519 */     if ((first == null) || (second == null)) {
/* 3520 */       return false;
/*      */     }
/* 3522 */     if (first.length != second.length) {
/* 3523 */       return false;
/*      */     }
/* 3525 */     for (int i = 0; i < first.length; i++) {
/* 3526 */       if (first[i] != second[i]) {
/* 3527 */         return false;
/*      */       }
/*      */     }
/* 3530 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean equals(Object obj)
/*      */   {
/* 3543 */     if (obj == this) {
/* 3544 */       return true;
/*      */     }
/* 3546 */     if (!(obj instanceof URI)) {
/* 3547 */       return false;
/*      */     }
/* 3549 */     URI another = (URI)obj;
/*      */     
/* 3551 */     if (!equals(this._scheme, another._scheme)) {
/* 3552 */       return false;
/*      */     }
/*      */     
/* 3555 */     if (!equals(this._opaque, another._opaque)) {
/* 3556 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 3560 */     if (!equals(this._authority, another._authority)) {
/* 3561 */       return false;
/*      */     }
/*      */     
/* 3564 */     if (!equals(this._path, another._path)) {
/* 3565 */       return false;
/*      */     }
/*      */     
/* 3568 */     if (!equals(this._query, another._query)) {
/* 3569 */       return false;
/*      */     }
/*      */     
/* 3572 */     if (!equals(this._fragment, another._fragment)) {
/* 3573 */       return false;
/*      */     }
/* 3575 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void writeObject(ObjectOutputStream oos)
/*      */     throws IOException
/*      */   {
/* 3589 */     oos.defaultWriteObject();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void readObject(ObjectInputStream ois)
/*      */     throws ClassNotFoundException, IOException
/*      */   {
/* 3604 */     ois.defaultReadObject();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int hashCode()
/*      */   {
/* 3615 */     if (this.hash == 0) {
/* 3616 */       char[] c = this._uri;
/* 3617 */       if (c != null) {
/* 3618 */         int i = 0; for (int len = c.length; i < len; i++) {
/* 3619 */           this.hash = (31 * this.hash + c[i]);
/*      */         }
/*      */       }
/* 3622 */       c = this._fragment;
/* 3623 */       if (c != null) {
/* 3624 */         int i = 0; for (int len = c.length; i < len; i++) {
/* 3625 */           this.hash = (31 * this.hash + c[i]);
/*      */         }
/*      */       }
/*      */     }
/* 3629 */     return this.hash;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int compareTo(Object obj)
/*      */     throws ClassCastException
/*      */   {
/* 3644 */     URI another = (URI)obj;
/* 3645 */     if (!equals(this._authority, another.getRawAuthority())) {
/* 3646 */       return -1;
/*      */     }
/* 3648 */     return toString().compareTo(another.toString());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized Object clone()
/*      */   {
/* 3665 */     URI instance = new URI();
/*      */     
/* 3667 */     instance._uri = this._uri;
/* 3668 */     instance._scheme = this._scheme;
/* 3669 */     instance._opaque = this._opaque;
/* 3670 */     instance._authority = this._authority;
/* 3671 */     instance._userinfo = this._userinfo;
/* 3672 */     instance._host = this._host;
/* 3673 */     instance._port = this._port;
/* 3674 */     instance._path = this._path;
/* 3675 */     instance._query = this._query;
/* 3676 */     instance._fragment = this._fragment;
/*      */     
/* 3678 */     instance.protocolCharset = this.protocolCharset;
/*      */     
/* 3680 */     instance._is_hier_part = this._is_hier_part;
/* 3681 */     instance._is_opaque_part = this._is_opaque_part;
/* 3682 */     instance._is_net_path = this._is_net_path;
/* 3683 */     instance._is_abs_path = this._is_abs_path;
/* 3684 */     instance._is_rel_path = this._is_rel_path;
/* 3685 */     instance._is_reg_name = this._is_reg_name;
/* 3686 */     instance._is_server = this._is_server;
/* 3687 */     instance._is_hostname = this._is_hostname;
/* 3688 */     instance._is_IPv4address = this._is_IPv4address;
/* 3689 */     instance._is_IPv6reference = this._is_IPv6reference;
/*      */     
/* 3691 */     return instance;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public char[] getRawURI()
/*      */   {
/* 3712 */     return this._uri;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getEscapedURI()
/*      */   {
/* 3723 */     return this._uri == null ? null : new String(this._uri);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getURI()
/*      */     throws URIException
/*      */   {
/* 3736 */     return this._uri == null ? null : decode(this._uri, getProtocolCharset());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public char[] getRawURIReference()
/*      */   {
/* 3746 */     if (this._fragment == null) {
/* 3747 */       return this._uri;
/*      */     }
/* 3749 */     if (this._uri == null) {
/* 3750 */       return this._fragment;
/*      */     }
/*      */     
/* 3753 */     String uriReference = new String(this._uri) + "#" + new String(this._fragment);
/* 3754 */     return uriReference.toCharArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getEscapedURIReference()
/*      */   {
/* 3764 */     char[] uriReference = getRawURIReference();
/* 3765 */     return uriReference == null ? null : new String(uriReference);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getURIReference()
/*      */     throws URIException
/*      */   {
/* 3776 */     char[] uriReference = getRawURIReference();
/* 3777 */     return uriReference == null ? null : decode(uriReference, getProtocolCharset());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 3800 */     return getEscapedURI();
/*      */   }
/*      */   
/*      */ 
/*      */   protected URI() {}
/*      */   
/*      */ 
/*      */   public static class DefaultCharsetChanged
/*      */     extends RuntimeException
/*      */   {
/*      */     public static final int UNKNOWN = 0;
/*      */     
/*      */     public static final int PROTOCOL_CHARSET = 1;
/*      */     
/*      */     public static final int DOCUMENT_CHARSET = 2;
/*      */     
/*      */     private int reasonCode;
/*      */     private String reason;
/*      */     
/*      */     public DefaultCharsetChanged(int reasonCode, String reason)
/*      */     {
/* 3821 */       super();
/* 3822 */       this.reason = reason;
/* 3823 */       this.reasonCode = reasonCode;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public int getReasonCode()
/*      */     {
/* 3853 */       return this.reasonCode;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public String getReason()
/*      */     {
/* 3862 */       return this.reason;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class LocaleToCharsetMap
/*      */   {
/* 3880 */     private static final Hashtable LOCALE_TO_CHARSET_MAP = new Hashtable();
/* 3881 */     static { LOCALE_TO_CHARSET_MAP.put("ar", "ISO-8859-6");
/* 3882 */       LOCALE_TO_CHARSET_MAP.put("be", "ISO-8859-5");
/* 3883 */       LOCALE_TO_CHARSET_MAP.put("bg", "ISO-8859-5");
/* 3884 */       LOCALE_TO_CHARSET_MAP.put("ca", "ISO-8859-1");
/* 3885 */       LOCALE_TO_CHARSET_MAP.put("cs", "ISO-8859-2");
/* 3886 */       LOCALE_TO_CHARSET_MAP.put("da", "ISO-8859-1");
/* 3887 */       LOCALE_TO_CHARSET_MAP.put("de", "ISO-8859-1");
/* 3888 */       LOCALE_TO_CHARSET_MAP.put("el", "ISO-8859-7");
/* 3889 */       LOCALE_TO_CHARSET_MAP.put("en", "ISO-8859-1");
/* 3890 */       LOCALE_TO_CHARSET_MAP.put("es", "ISO-8859-1");
/* 3891 */       LOCALE_TO_CHARSET_MAP.put("et", "ISO-8859-1");
/* 3892 */       LOCALE_TO_CHARSET_MAP.put("fi", "ISO-8859-1");
/* 3893 */       LOCALE_TO_CHARSET_MAP.put("fr", "ISO-8859-1");
/* 3894 */       LOCALE_TO_CHARSET_MAP.put("hr", "ISO-8859-2");
/* 3895 */       LOCALE_TO_CHARSET_MAP.put("hu", "ISO-8859-2");
/* 3896 */       LOCALE_TO_CHARSET_MAP.put("is", "ISO-8859-1");
/* 3897 */       LOCALE_TO_CHARSET_MAP.put("it", "ISO-8859-1");
/* 3898 */       LOCALE_TO_CHARSET_MAP.put("iw", "ISO-8859-8");
/* 3899 */       LOCALE_TO_CHARSET_MAP.put("ja", "Shift_JIS");
/* 3900 */       LOCALE_TO_CHARSET_MAP.put("ko", "EUC-KR");
/* 3901 */       LOCALE_TO_CHARSET_MAP.put("lt", "ISO-8859-2");
/* 3902 */       LOCALE_TO_CHARSET_MAP.put("lv", "ISO-8859-2");
/* 3903 */       LOCALE_TO_CHARSET_MAP.put("mk", "ISO-8859-5");
/* 3904 */       LOCALE_TO_CHARSET_MAP.put("nl", "ISO-8859-1");
/* 3905 */       LOCALE_TO_CHARSET_MAP.put("no", "ISO-8859-1");
/* 3906 */       LOCALE_TO_CHARSET_MAP.put("pl", "ISO-8859-2");
/* 3907 */       LOCALE_TO_CHARSET_MAP.put("pt", "ISO-8859-1");
/* 3908 */       LOCALE_TO_CHARSET_MAP.put("ro", "ISO-8859-2");
/* 3909 */       LOCALE_TO_CHARSET_MAP.put("ru", "ISO-8859-5");
/* 3910 */       LOCALE_TO_CHARSET_MAP.put("sh", "ISO-8859-5");
/* 3911 */       LOCALE_TO_CHARSET_MAP.put("sk", "ISO-8859-2");
/* 3912 */       LOCALE_TO_CHARSET_MAP.put("sl", "ISO-8859-2");
/* 3913 */       LOCALE_TO_CHARSET_MAP.put("sq", "ISO-8859-2");
/* 3914 */       LOCALE_TO_CHARSET_MAP.put("sr", "ISO-8859-5");
/* 3915 */       LOCALE_TO_CHARSET_MAP.put("sv", "ISO-8859-1");
/* 3916 */       LOCALE_TO_CHARSET_MAP.put("tr", "ISO-8859-9");
/* 3917 */       LOCALE_TO_CHARSET_MAP.put("uk", "ISO-8859-5");
/* 3918 */       LOCALE_TO_CHARSET_MAP.put("zh", "GB2312");
/* 3919 */       LOCALE_TO_CHARSET_MAP.put("zh_TW", "Big5");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public static String getCharset(Locale locale)
/*      */     {
/* 3931 */       String charset = (String)LOCALE_TO_CHARSET_MAP.get(locale.toString());
/*      */       
/* 3933 */       if (charset != null) {
/* 3934 */         return charset;
/*      */       }
/*      */       
/*      */ 
/* 3938 */       charset = (String)LOCALE_TO_CHARSET_MAP.get(locale.getLanguage());
/* 3939 */       return charset;
/*      */     }
/*      */   }
/*      */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\URI.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */