package org.apache.commons.httpclient.params;

public abstract interface HttpParamsFactory
{
  public abstract HttpParams getDefaultParams();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\params\HttpParamsFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */