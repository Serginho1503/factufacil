/*     */ package org.apache.commons.httpclient.methods;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.commons.httpclient.HttpConnection;
/*     */ import org.apache.commons.httpclient.HttpException;
/*     */ import org.apache.commons.httpclient.HttpMethodBase;
/*     */ import org.apache.commons.httpclient.HttpState;
/*     */ import org.apache.commons.httpclient.ProtocolException;
/*     */ import org.apache.commons.httpclient.params.DefaultHttpParams;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HeadMethod
/*     */   extends HttpMethodBase
/*     */ {
/*  72 */   private static final Log LOG = LogFactory.getLog(HeadMethod.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HeadMethod()
/*     */   {
/*  82 */     setFollowRedirects(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HeadMethod(String uri)
/*     */   {
/*  93 */     super(uri);
/*  94 */     setFollowRedirects(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 107 */     return "HEAD";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void recycle()
/*     */   {
/* 124 */     super.recycle();
/* 125 */     setFollowRedirects(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void readResponseBody(HttpState state, HttpConnection conn)
/*     */     throws HttpException, IOException
/*     */   {
/* 149 */     LOG.trace("enter HeadMethod.readResponseBody(HttpState, HttpConnection)");
/*     */     
/*     */ 
/* 152 */     int bodyCheckTimeout = getParams().getIntParameter("http.protocol.head-body-timeout", -1);
/*     */     
/*     */ 
/* 155 */     if (bodyCheckTimeout < 0) {
/* 156 */       responseBodyConsumed();
/*     */     } else {
/* 158 */       if (LOG.isDebugEnabled()) {
/* 159 */         LOG.debug("Check for non-compliant response body. Timeout in " + bodyCheckTimeout + " ms");
/*     */       }
/*     */       
/* 162 */       boolean responseAvailable = false;
/*     */       try {
/* 164 */         responseAvailable = conn.isResponseAvailable(bodyCheckTimeout);
/*     */       } catch (IOException e) {
/* 166 */         LOG.debug("An IOException occurred while testing if a response was available, we will assume one is not.", e);
/*     */         
/*     */ 
/* 169 */         responseAvailable = false;
/*     */       }
/* 171 */       if (responseAvailable) {
/* 172 */         if (getParams().isParameterTrue("http.protocol.reject-head-body")) {
/* 173 */           throw new ProtocolException("Body content may not be sent in response to HTTP HEAD request");
/*     */         }
/*     */         
/* 176 */         LOG.warn("Body content returned in response to HTTP HEAD");
/*     */         
/* 178 */         super.readResponseBody(state, conn);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public int getBodyCheckTimeout()
/*     */   {
/* 198 */     return getParams().getIntParameter("http.protocol.head-body-timeout", -1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setBodyCheckTimeout(int timeout)
/*     */   {
/* 215 */     getParams().setIntParameter("http.protocol.head-body-timeout", timeout);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\methods\HeadMethod.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */