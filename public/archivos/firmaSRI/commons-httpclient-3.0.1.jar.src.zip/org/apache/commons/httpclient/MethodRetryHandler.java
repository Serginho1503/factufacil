package org.apache.commons.httpclient;

/**
 * @deprecated
 */
public abstract interface MethodRetryHandler
{
  public abstract boolean retryMethod(HttpMethod paramHttpMethod, HttpConnection paramHttpConnection, HttpRecoverableException paramHttpRecoverableException, int paramInt, boolean paramBoolean);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\MethodRetryHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */