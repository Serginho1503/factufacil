/*     */ package org.apache.commons.httpclient.params;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpClientParams
/*     */   extends HttpMethodParams
/*     */ {
/*     */   public static final String CONNECTION_MANAGER_TIMEOUT = "http.connection-manager.timeout";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String CONNECTION_MANAGER_CLASS = "http.connection-manager.class";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String PREEMPTIVE_AUTHENTICATION = "http.authentication.preemptive";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String REJECT_RELATIVE_REDIRECT = "http.protocol.reject-relative-redirect";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String MAX_REDIRECTS = "http.protocol.max-redirects";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String ALLOW_CIRCULAR_REDIRECTS = "http.protocol.allow-circular-redirects";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpClientParams() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpClientParams(HttpParams defaults)
/*     */   {
/* 126 */     super(defaults);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getConnectionManagerTimeout()
/*     */   {
/* 137 */     return getLongParameter("http.connection-manager.timeout", 0L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConnectionManagerTimeout(long timeout)
/*     */   {
/* 148 */     setLongParameter("http.connection-manager.timeout", timeout);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class getConnectionManagerClass()
/*     */   {
/* 159 */     return (Class)getParameter("http.connection-manager.class");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConnectionManagerClass(Class clazz)
/*     */   {
/* 170 */     setParameter("http.connection-manager.class", clazz);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAuthenticationPreemptive()
/*     */   {
/* 181 */     return getBooleanParameter("http.authentication.preemptive", false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAuthenticationPreemptive(boolean value)
/*     */   {
/* 191 */     setBooleanParameter("http.authentication.preemptive", value);
/*     */   }
/*     */   
/* 194 */   private static final String[] PROTOCOL_STRICTNESS_PARAMETERS = { "http.protocol.reject-relative-redirect", "http.protocol.allow-circular-redirects" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void makeStrict()
/*     */   {
/* 201 */     super.makeStrict();
/* 202 */     setParameters(PROTOCOL_STRICTNESS_PARAMETERS, Boolean.TRUE);
/*     */   }
/*     */   
/*     */   public void makeLenient()
/*     */   {
/* 207 */     super.makeLenient();
/* 208 */     setParameters(PROTOCOL_STRICTNESS_PARAMETERS, Boolean.FALSE);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\params\HttpClientParams.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */