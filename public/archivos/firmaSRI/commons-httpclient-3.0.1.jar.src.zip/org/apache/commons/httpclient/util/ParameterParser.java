/*     */ package org.apache.commons.httpclient.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.httpclient.NameValuePair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParameterParser
/*     */ {
/*  53 */   private char[] chars = null;
/*     */   
/*     */ 
/*  56 */   private int pos = 0;
/*     */   
/*     */ 
/*  59 */   private int len = 0;
/*     */   
/*     */ 
/*  62 */   private int i1 = 0;
/*     */   
/*     */ 
/*  65 */   private int i2 = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean hasChar()
/*     */   {
/*  75 */     return this.pos < this.len;
/*     */   }
/*     */   
/*     */ 
/*     */   private String getToken(boolean quoted)
/*     */   {
/*     */     do
/*     */     {
/*  83 */       this.i1 += 1;
/*  82 */       if (this.i1 >= this.i2) break; } while (Character.isWhitespace(this.chars[this.i1]));
/*     */     
/*     */ 
/*     */ 
/*  86 */     while ((this.i2 > this.i1) && (Character.isWhitespace(this.chars[(this.i2 - 1)]))) {
/*  87 */       this.i2 -= 1;
/*     */     }
/*     */     
/*  90 */     if ((quoted) && 
/*  91 */       (this.i2 - this.i1 >= 2) && (this.chars[this.i1] == '"') && (this.chars[(this.i2 - 1)] == '"'))
/*     */     {
/*     */ 
/*  94 */       this.i1 += 1;
/*  95 */       this.i2 -= 1;
/*     */     }
/*     */     
/*  98 */     String result = null;
/*  99 */     if (this.i2 >= this.i1) {
/* 100 */       result = new String(this.chars, this.i1, this.i2 - this.i1);
/*     */     }
/* 102 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean isOneOf(char ch, char[] charray)
/*     */   {
/* 108 */     boolean result = false;
/* 109 */     for (int i = 0; i < charray.length; i++) {
/* 110 */       if (ch == charray[i]) {
/* 111 */         result = true;
/* 112 */         break;
/*     */       }
/*     */     }
/* 115 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String parseToken(char[] terminators)
/*     */   {
/* 123 */     this.i1 = this.pos;
/* 124 */     this.i2 = this.pos;
/* 125 */     while (hasChar()) {
/* 126 */       char ch = this.chars[this.pos];
/* 127 */       if (isOneOf(ch, terminators)) {
/*     */         break;
/*     */       }
/* 130 */       this.i2 += 1;
/* 131 */       this.pos += 1;
/*     */     }
/* 133 */     return getToken(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String parseQuotedToken(char[] terminators)
/*     */   {
/* 142 */     this.i1 = this.pos;
/* 143 */     this.i2 = this.pos;
/* 144 */     boolean quoted = false;
/* 145 */     boolean charEscaped = false;
/* 146 */     while (hasChar()) {
/* 147 */       char ch = this.chars[this.pos];
/* 148 */       if ((!quoted) && (isOneOf(ch, terminators))) {
/*     */         break;
/*     */       }
/* 151 */       if ((!charEscaped) && (ch == '"')) {
/* 152 */         quoted = !quoted;
/*     */       }
/* 154 */       charEscaped = (!charEscaped) && (ch == '\\');
/* 155 */       this.i2 += 1;
/* 156 */       this.pos += 1;
/*     */     }
/*     */     
/* 159 */     return getToken(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List parse(String str, char separator)
/*     */   {
/* 171 */     if (str == null) {
/* 172 */       return new ArrayList();
/*     */     }
/* 174 */     return parse(str.toCharArray(), separator);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List parse(char[] chars, char separator)
/*     */   {
/* 188 */     if (chars == null) {
/* 189 */       return new ArrayList();
/*     */     }
/* 191 */     return parse(chars, 0, chars.length, separator);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List parse(char[] chars, int offset, int length, char separator)
/*     */   {
/* 208 */     if (chars == null) {
/* 209 */       return new ArrayList();
/*     */     }
/* 211 */     List params = new ArrayList();
/* 212 */     this.chars = chars;
/* 213 */     this.pos = offset;
/* 214 */     this.len = length;
/*     */     
/* 216 */     String paramName = null;
/* 217 */     String paramValue = null;
/* 218 */     while (hasChar()) {
/* 219 */       paramName = parseToken(new char[] { '=', separator });
/* 220 */       paramValue = null;
/* 221 */       if ((hasChar()) && (chars[this.pos] == '=')) {
/* 222 */         this.pos += 1;
/* 223 */         paramValue = parseQuotedToken(new char[] { separator });
/*     */       }
/* 225 */       if ((hasChar()) && (chars[this.pos] == separator)) {
/* 226 */         this.pos += 1;
/*     */       }
/* 228 */       if ((paramName != null) && ((!paramName.equals("")) || (paramValue != null))) {
/* 229 */         params.add(new NameValuePair(paramName, paramValue));
/*     */       }
/*     */     }
/* 232 */     return params;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\util\ParameterParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */