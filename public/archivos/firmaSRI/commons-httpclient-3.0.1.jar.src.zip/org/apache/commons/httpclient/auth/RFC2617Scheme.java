/*     */ package org.apache.commons.httpclient.auth;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.apache.commons.httpclient.Credentials;
/*     */ import org.apache.commons.httpclient.HttpMethod;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RFC2617Scheme
/*     */   implements AuthScheme
/*     */ {
/*  48 */   private Map params = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RFC2617Scheme() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public RFC2617Scheme(String challenge)
/*     */     throws MalformedChallengeException
/*     */   {
/*  72 */     processChallenge(challenge);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void processChallenge(String challenge)
/*     */     throws MalformedChallengeException
/*     */   {
/*  88 */     String s = AuthChallengeParser.extractScheme(challenge);
/*  89 */     if (!s.equalsIgnoreCase(getSchemeName())) {
/*  90 */       throw new MalformedChallengeException("Invalid " + getSchemeName() + " challenge: " + challenge);
/*     */     }
/*     */     
/*  93 */     this.params = AuthChallengeParser.extractParams(challenge);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Map getParameters()
/*     */   {
/* 102 */     return this.params;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getParameter(String name)
/*     */   {
/* 113 */     if (name == null) {
/* 114 */       throw new IllegalArgumentException("Parameter name may not be null");
/*     */     }
/* 116 */     if (this.params == null) {
/* 117 */       return null;
/*     */     }
/* 119 */     return (String)this.params.get(name.toLowerCase());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRealm()
/*     */   {
/* 128 */     return getParameter("realm");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public String getID()
/*     */   {
/* 152 */     return getRealm();
/*     */   }
/*     */   
/*     */   public abstract String authenticate(Credentials paramCredentials, HttpMethod paramHttpMethod)
/*     */     throws AuthenticationException;
/*     */   
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public abstract String authenticate(Credentials paramCredentials, String paramString1, String paramString2)
/*     */     throws AuthenticationException;
/*     */   
/*     */   public abstract boolean isComplete();
/*     */   
/*     */   public abstract boolean isConnectionBased();
/*     */   
/*     */   public abstract String getSchemeName();
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\auth\RFC2617Scheme.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */