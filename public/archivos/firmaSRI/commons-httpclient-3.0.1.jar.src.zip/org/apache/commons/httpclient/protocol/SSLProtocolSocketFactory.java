/*     */ package org.apache.commons.httpclient.protocol;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.UnknownHostException;
/*     */ import javax.net.SocketFactory;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import org.apache.commons.httpclient.ConnectTimeoutException;
/*     */ import org.apache.commons.httpclient.params.HttpConnectionParams;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SSLProtocolSocketFactory
/*     */   implements SecureProtocolSocketFactory
/*     */ {
/*  55 */   private static final SSLProtocolSocketFactory factory = new SSLProtocolSocketFactory();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static SSLProtocolSocketFactory getSocketFactory()
/*     */   {
/*  62 */     return factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Socket createSocket(String host, int port, InetAddress clientHost, int clientPort)
/*     */     throws IOException, UnknownHostException
/*     */   {
/*  81 */     return SSLSocketFactory.getDefault().createSocket(host, port, clientHost, clientPort);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Socket createSocket(String host, int port, InetAddress localAddress, int localPort, HttpConnectionParams params)
/*     */     throws IOException, UnknownHostException, ConnectTimeoutException
/*     */   {
/* 121 */     if (params == null) {
/* 122 */       throw new IllegalArgumentException("Parameters may not be null");
/*     */     }
/* 124 */     int timeout = params.getConnectionTimeout();
/* 125 */     if (timeout == 0) {
/* 126 */       return createSocket(host, port, localAddress, localPort);
/*     */     }
/*     */     
/* 129 */     Socket socket = ReflectionSocketFactory.createSocket("javax.net.ssl.SSLSocketFactory", host, port, localAddress, localPort, timeout);
/*     */     
/* 131 */     if (socket == null) {
/* 132 */       socket = ControllerThreadSocketFactory.createSocket(this, host, port, localAddress, localPort, timeout);
/*     */     }
/*     */     
/* 135 */     return socket;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Socket createSocket(String host, int port)
/*     */     throws IOException, UnknownHostException
/*     */   {
/* 144 */     return SSLSocketFactory.getDefault().createSocket(host, port);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Socket createSocket(Socket socket, String host, int port, boolean autoClose)
/*     */     throws IOException, UnknownHostException
/*     */   {
/* 159 */     return ((SSLSocketFactory)SSLSocketFactory.getDefault()).createSocket(socket, host, port, autoClose);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 171 */     return (obj != null) && (obj.getClass().equals(SSLProtocolSocketFactory.class));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 178 */     return SSLProtocolSocketFactory.class.hashCode();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\protocol\SSLProtocolSocketFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */