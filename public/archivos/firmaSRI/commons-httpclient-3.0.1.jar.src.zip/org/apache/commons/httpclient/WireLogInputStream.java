/*    */ package org.apache.commons.httpclient;
/*    */ 
/*    */ import java.io.FilterInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WireLogInputStream
/*    */   extends FilterInputStream
/*    */ {
/*    */   private InputStream in;
/*    */   private Wire wire;
/*    */   
/*    */   public WireLogInputStream(InputStream in, Wire wire)
/*    */   {
/* 59 */     super(in);
/* 60 */     this.in = in;
/* 61 */     this.wire = wire;
/*    */   }
/*    */   
/*    */ 
/*    */   public int read(byte[] b, int off, int len)
/*    */     throws IOException
/*    */   {
/* 68 */     int l = this.in.read(b, off, len);
/* 69 */     if (l > 0) {
/* 70 */       this.wire.input(b, off, l);
/*    */     }
/* 72 */     return l;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int read()
/*    */     throws IOException
/*    */   {
/* 80 */     int l = this.in.read();
/* 81 */     if (l > 0) {
/* 82 */       this.wire.input(l);
/*    */     }
/* 84 */     return l;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int read(byte[] b)
/*    */     throws IOException
/*    */   {
/* 92 */     int l = this.in.read(b);
/* 93 */     if (l > 0) {
/* 94 */       this.wire.input(b, 0, l);
/*    */     }
/* 96 */     return l;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\WireLogInputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */