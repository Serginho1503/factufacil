/*    */ package org.apache.commons.httpclient;
/*    */ 
/*    */ import org.apache.commons.httpclient.protocol.Protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProxyHost
/*    */   extends HttpHost
/*    */ {
/*    */   public ProxyHost(ProxyHost httpproxy)
/*    */   {
/* 53 */     super(httpproxy);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ProxyHost(String hostname, int port)
/*    */   {
/* 63 */     super(hostname, port, Protocol.getProtocol("http"));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ProxyHost(String hostname)
/*    */   {
/* 72 */     this(hostname, -1);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Object clone()
/*    */   {
/* 79 */     return new ProxyHost(this);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\ProxyHost.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */