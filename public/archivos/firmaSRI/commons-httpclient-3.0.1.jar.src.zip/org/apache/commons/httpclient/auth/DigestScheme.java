/*     */ package org.apache.commons.httpclient.auth;
/*     */ 
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.commons.httpclient.Credentials;
/*     */ import org.apache.commons.httpclient.HttpClientError;
/*     */ import org.apache.commons.httpclient.HttpMethod;
/*     */ import org.apache.commons.httpclient.NameValuePair;
/*     */ import org.apache.commons.httpclient.UsernamePasswordCredentials;
/*     */ import org.apache.commons.httpclient.params.HttpMethodParams;
/*     */ import org.apache.commons.httpclient.util.EncodingUtil;
/*     */ import org.apache.commons.httpclient.util.ParameterFormatter;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DigestScheme
/*     */   extends RFC2617Scheme
/*     */ {
/*  79 */   private static final Log LOG = LogFactory.getLog(DigestScheme.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  87 */   private static final char[] HEXADECIMAL = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
/*     */   
/*     */ 
/*     */   private boolean complete;
/*     */   
/*     */ 
/*     */   private static final String NC = "00000001";
/*     */   
/*     */   private static final int QOP_MISSING = 0;
/*     */   
/*     */   private static final int QOP_AUTH_INT = 1;
/*     */   
/*     */   private static final int QOP_AUTH = 2;
/*     */   
/* 101 */   private int qopVariant = 0;
/*     */   
/*     */ 
/*     */   private String cnonce;
/*     */   
/*     */ 
/*     */   private final ParameterFormatter formatter;
/*     */   
/*     */ 
/*     */   public DigestScheme()
/*     */   {
/* 112 */     this.complete = false;
/* 113 */     this.formatter = new ParameterFormatter();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public String getID()
/*     */   {
/* 125 */     String id = getRealm();
/* 126 */     String nonce = getParameter("nonce");
/* 127 */     if (nonce != null) {
/* 128 */       id = id + "-" + nonce;
/*     */     }
/*     */     
/* 131 */     return id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public DigestScheme(String challenge)
/*     */     throws MalformedChallengeException
/*     */   {
/* 147 */     this();
/* 148 */     processChallenge(challenge);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void processChallenge(String challenge)
/*     */     throws MalformedChallengeException
/*     */   {
/* 163 */     super.processChallenge(challenge);
/*     */     
/* 165 */     if (getParameter("realm") == null) {
/* 166 */       throw new MalformedChallengeException("missing realm in challange");
/*     */     }
/* 168 */     if (getParameter("nonce") == null) {
/* 169 */       throw new MalformedChallengeException("missing nonce in challange");
/*     */     }
/*     */     
/* 172 */     boolean unsupportedQop = false;
/*     */     
/* 174 */     String qop = getParameter("qop");
/* 175 */     if (qop != null) {
/* 176 */       StringTokenizer tok = new StringTokenizer(qop, ",");
/* 177 */       while (tok.hasMoreTokens()) {
/* 178 */         String variant = tok.nextToken().trim();
/* 179 */         if (variant.equals("auth")) {
/* 180 */           this.qopVariant = 2;
/* 181 */           break; }
/* 182 */         if (variant.equals("auth-int")) {
/* 183 */           this.qopVariant = 1;
/*     */         } else {
/* 185 */           unsupportedQop = true;
/* 186 */           LOG.warn("Unsupported qop detected: " + variant);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 191 */     if ((unsupportedQop) && (this.qopVariant == 0)) {
/* 192 */       throw new MalformedChallengeException("None of the qop methods is supported");
/*     */     }
/*     */     
/* 195 */     this.cnonce = createCnonce();
/* 196 */     this.complete = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isComplete()
/*     */   {
/* 208 */     String s = getParameter("stale");
/* 209 */     if ("true".equalsIgnoreCase(s)) {
/* 210 */       return false;
/*     */     }
/* 212 */     return this.complete;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSchemeName()
/*     */   {
/* 222 */     return "digest";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isConnectionBased()
/*     */   {
/* 233 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public String authenticate(Credentials credentials, String method, String uri)
/*     */     throws AuthenticationException
/*     */   {
/* 259 */     LOG.trace("enter DigestScheme.authenticate(Credentials, String, String)");
/*     */     
/* 261 */     UsernamePasswordCredentials usernamepassword = null;
/*     */     try {
/* 263 */       usernamepassword = (UsernamePasswordCredentials)credentials;
/*     */     } catch (ClassCastException e) {
/* 265 */       throw new InvalidCredentialsException("Credentials cannot be used for digest authentication: " + credentials.getClass().getName());
/*     */     }
/*     */     
/*     */ 
/* 269 */     getParameters().put("methodname", method);
/* 270 */     getParameters().put("uri", uri);
/* 271 */     String digest = createDigest(usernamepassword.getUserName(), usernamepassword.getPassword());
/*     */     
/*     */ 
/* 274 */     return "Digest " + createDigestHeader(usernamepassword.getUserName(), digest);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String authenticate(Credentials credentials, HttpMethod method)
/*     */     throws AuthenticationException
/*     */   {
/* 296 */     LOG.trace("enter DigestScheme.authenticate(Credentials, HttpMethod)");
/*     */     
/* 298 */     UsernamePasswordCredentials usernamepassword = null;
/*     */     try {
/* 300 */       usernamepassword = (UsernamePasswordCredentials)credentials;
/*     */     } catch (ClassCastException e) {
/* 302 */       throw new InvalidCredentialsException("Credentials cannot be used for digest authentication: " + credentials.getClass().getName());
/*     */     }
/*     */     
/*     */ 
/* 306 */     getParameters().put("methodname", method.getName());
/* 307 */     StringBuffer buffer = new StringBuffer(method.getPath());
/* 308 */     String query = method.getQueryString();
/* 309 */     if (query != null) {
/* 310 */       if (query.indexOf("?") != 0) {
/* 311 */         buffer.append("?");
/*     */       }
/* 313 */       buffer.append(method.getQueryString());
/*     */     }
/* 315 */     getParameters().put("uri", buffer.toString());
/* 316 */     String charset = getParameter("charset");
/* 317 */     if (charset == null) {
/* 318 */       getParameters().put("charset", method.getParams().getCredentialCharset());
/*     */     }
/* 320 */     String digest = createDigest(usernamepassword.getUserName(), usernamepassword.getPassword());
/*     */     
/*     */ 
/* 323 */     return "Digest " + createDigestHeader(usernamepassword.getUserName(), digest);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String createDigest(String uname, String pwd)
/*     */     throws AuthenticationException
/*     */   {
/* 340 */     LOG.trace("enter DigestScheme.createDigest(String, String, Map)");
/*     */     
/* 342 */     String digAlg = "MD5";
/*     */     
/*     */ 
/* 345 */     String uri = getParameter("uri");
/* 346 */     String realm = getParameter("realm");
/* 347 */     String nonce = getParameter("nonce");
/* 348 */     String qop = getParameter("qop");
/* 349 */     String method = getParameter("methodname");
/* 350 */     String algorithm = getParameter("algorithm");
/*     */     
/* 352 */     if (algorithm == null) {
/* 353 */       algorithm = "MD5";
/*     */     }
/*     */     
/* 356 */     String charset = getParameter("charset");
/* 357 */     if (charset == null) {
/* 358 */       charset = "ISO-8859-1";
/*     */     }
/*     */     
/* 361 */     if (this.qopVariant == 1) {
/* 362 */       LOG.warn("qop=auth-int is not supported");
/* 363 */       throw new AuthenticationException("Unsupported qop in HTTP Digest authentication");
/*     */     }
/*     */     
/*     */     MessageDigest md5Helper;
/*     */     
/*     */     try
/*     */     {
/* 370 */       md5Helper = MessageDigest.getInstance("MD5");
/*     */     } catch (Exception e) {
/* 372 */       throw new AuthenticationException("Unsupported algorithm in HTTP Digest authentication: MD5");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 378 */     StringBuffer tmp = new StringBuffer(uname.length() + realm.length() + pwd.length() + 2);
/* 379 */     tmp.append(uname);
/* 380 */     tmp.append(':');
/* 381 */     tmp.append(realm);
/* 382 */     tmp.append(':');
/* 383 */     tmp.append(pwd);
/*     */     
/* 385 */     String a1 = tmp.toString();
/*     */     
/* 387 */     if (algorithm.equals("MD5-sess"))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 392 */       String tmp2 = encode(md5Helper.digest(EncodingUtil.getBytes(a1, charset)));
/* 393 */       StringBuffer tmp3 = new StringBuffer(tmp2.length() + nonce.length() + this.cnonce.length() + 2);
/* 394 */       tmp3.append(tmp2);
/* 395 */       tmp3.append(':');
/* 396 */       tmp3.append(nonce);
/* 397 */       tmp3.append(':');
/* 398 */       tmp3.append(this.cnonce);
/* 399 */       a1 = tmp3.toString();
/* 400 */     } else if (!algorithm.equals("MD5")) {
/* 401 */       LOG.warn("Unhandled algorithm " + algorithm + " requested");
/*     */     }
/* 403 */     String md5a1 = encode(md5Helper.digest(EncodingUtil.getBytes(a1, charset)));
/*     */     
/* 405 */     String a2 = null;
/* 406 */     if (this.qopVariant == 1) {
/* 407 */       LOG.error("Unhandled qop auth-int");
/*     */     }
/*     */     else
/*     */     {
/* 411 */       a2 = method + ":" + uri;
/*     */     }
/* 413 */     String md5a2 = encode(md5Helper.digest(EncodingUtil.getAsciiBytes(a2)));
/*     */     
/*     */     String serverDigestValue;
/*     */     
/* 417 */     if (this.qopVariant == 0) {
/* 418 */       LOG.debug("Using null qop method");
/* 419 */       StringBuffer tmp2 = new StringBuffer(md5a1.length() + nonce.length() + md5a2.length());
/* 420 */       tmp2.append(md5a1);
/* 421 */       tmp2.append(':');
/* 422 */       tmp2.append(nonce);
/* 423 */       tmp2.append(':');
/* 424 */       tmp2.append(md5a2);
/* 425 */       serverDigestValue = tmp2.toString();
/*     */     } else {
/* 427 */       if (LOG.isDebugEnabled()) {
/* 428 */         LOG.debug("Using qop method " + qop);
/*     */       }
/* 430 */       String qopOption = getQopVariantString();
/* 431 */       StringBuffer tmp2 = new StringBuffer(md5a1.length() + nonce.length() + "00000001".length() + this.cnonce.length() + qopOption.length() + md5a2.length() + 5);
/*     */       
/* 433 */       tmp2.append(md5a1);
/* 434 */       tmp2.append(':');
/* 435 */       tmp2.append(nonce);
/* 436 */       tmp2.append(':');
/* 437 */       tmp2.append("00000001");
/* 438 */       tmp2.append(':');
/* 439 */       tmp2.append(this.cnonce);
/* 440 */       tmp2.append(':');
/* 441 */       tmp2.append(qopOption);
/* 442 */       tmp2.append(':');
/* 443 */       tmp2.append(md5a2);
/* 444 */       serverDigestValue = tmp2.toString();
/*     */     }
/*     */     
/* 447 */     String serverDigest = encode(md5Helper.digest(EncodingUtil.getAsciiBytes(serverDigestValue)));
/*     */     
/*     */ 
/* 450 */     return serverDigest;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String createDigestHeader(String uname, String digest)
/*     */     throws AuthenticationException
/*     */   {
/* 464 */     LOG.trace("enter DigestScheme.createDigestHeader(String, Map, String)");
/*     */     
/*     */ 
/* 467 */     String uri = getParameter("uri");
/* 468 */     String realm = getParameter("realm");
/* 469 */     String nonce = getParameter("nonce");
/* 470 */     String opaque = getParameter("opaque");
/* 471 */     String response = digest;
/* 472 */     String algorithm = getParameter("algorithm");
/*     */     
/* 474 */     List params = new ArrayList(20);
/* 475 */     params.add(new NameValuePair("username", uname));
/* 476 */     params.add(new NameValuePair("realm", realm));
/* 477 */     params.add(new NameValuePair("nonce", nonce));
/* 478 */     params.add(new NameValuePair("uri", uri));
/* 479 */     params.add(new NameValuePair("response", response));
/*     */     
/* 481 */     if (this.qopVariant != 0) {
/* 482 */       params.add(new NameValuePair("qop", getQopVariantString()));
/* 483 */       params.add(new NameValuePair("nc", "00000001"));
/* 484 */       params.add(new NameValuePair("cnonce", this.cnonce));
/*     */     }
/* 486 */     if (algorithm != null) {
/* 487 */       params.add(new NameValuePair("algorithm", algorithm));
/*     */     }
/* 489 */     if (opaque != null) {
/* 490 */       params.add(new NameValuePair("opaque", opaque));
/*     */     }
/*     */     
/* 493 */     StringBuffer buffer = new StringBuffer();
/* 494 */     for (int i = 0; i < params.size(); i++) {
/* 495 */       NameValuePair param = (NameValuePair)params.get(i);
/* 496 */       if (i > 0) {
/* 497 */         buffer.append(", ");
/*     */       }
/* 499 */       boolean noQuotes = ("nc".equals(param.getName())) || ("qop".equals(param.getName()));
/*     */       
/* 501 */       this.formatter.setAlwaysUseQuotes(!noQuotes);
/* 502 */       this.formatter.format(buffer, param);
/*     */     }
/* 504 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   private String getQopVariantString() {
/*     */     String qopOption;
/* 509 */     if (this.qopVariant == 1) {
/* 510 */       qopOption = "auth-int";
/*     */     } else {
/* 512 */       qopOption = "auth";
/*     */     }
/* 514 */     return qopOption;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String encode(byte[] binaryData)
/*     */   {
/* 525 */     LOG.trace("enter DigestScheme.encode(byte[])");
/*     */     
/* 527 */     if (binaryData.length != 16) {
/* 528 */       return null;
/*     */     }
/*     */     
/* 531 */     char[] buffer = new char[32];
/* 532 */     for (int i = 0; i < 16; i++) {
/* 533 */       int low = binaryData[i] & 0xF;
/* 534 */       int high = (binaryData[i] & 0xF0) >> 4;
/* 535 */       buffer[(i * 2)] = HEXADECIMAL[high];
/* 536 */       buffer[(i * 2 + 1)] = HEXADECIMAL[low];
/*     */     }
/*     */     
/* 539 */     return new String(buffer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String createCnonce()
/*     */   {
/* 550 */     LOG.trace("enter DigestScheme.createCnonce()");
/*     */     
/*     */ 
/* 553 */     String digAlg = "MD5";
/*     */     MessageDigest md5Helper;
/*     */     try
/*     */     {
/* 557 */       md5Helper = MessageDigest.getInstance("MD5");
/*     */     } catch (NoSuchAlgorithmException e) {
/* 559 */       throw new HttpClientError("Unsupported algorithm in HTTP Digest authentication: MD5");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 564 */     String cnonce = Long.toString(System.currentTimeMillis());
/* 565 */     cnonce = encode(md5Helper.digest(EncodingUtil.getAsciiBytes(cnonce)));
/*     */     
/* 567 */     return cnonce;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\auth\DigestScheme.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */