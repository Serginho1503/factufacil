/*     */ package org.apache.commons.httpclient.auth;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.httpclient.params.HttpParams;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AuthChallengeProcessor
/*     */ {
/*  50 */   private static final Log LOG = LogFactory.getLog(AuthChallengeProcessor.class);
/*     */   
/*  52 */   private HttpParams params = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AuthChallengeProcessor(HttpParams params)
/*     */   {
/*  62 */     if (params == null) {
/*  63 */       throw new IllegalArgumentException("Parameter collection may not be null");
/*     */     }
/*  65 */     this.params = params;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AuthScheme selectAuthScheme(Map challenges)
/*     */     throws AuthChallengeException
/*     */   {
/*  80 */     if (challenges == null) {
/*  81 */       throw new IllegalArgumentException("Challenge map may not be null");
/*     */     }
/*  83 */     Collection authPrefs = (Collection)this.params.getParameter("http.auth.scheme-priority");
/*     */     
/*  85 */     if ((authPrefs == null) || (authPrefs.isEmpty())) {
/*  86 */       authPrefs = AuthPolicy.getDefaultAuthPrefs();
/*     */     }
/*  88 */     if (LOG.isDebugEnabled()) {
/*  89 */       LOG.debug("Supported authentication schemes in the order of preference: " + authPrefs);
/*     */     }
/*     */     
/*  92 */     AuthScheme authscheme = null;
/*  93 */     String challenge = null;
/*  94 */     Iterator item = authPrefs.iterator();
/*  95 */     while (item.hasNext()) {
/*  96 */       String id = (String)item.next();
/*  97 */       challenge = (String)challenges.get(id.toLowerCase());
/*  98 */       if (challenge != null) {
/*  99 */         if (LOG.isInfoEnabled()) {
/* 100 */           LOG.info(id + " authentication scheme selected");
/*     */         }
/*     */         try {
/* 103 */           authscheme = AuthPolicy.getAuthScheme(id);
/*     */         } catch (IllegalStateException e) {
/* 105 */           throw new AuthChallengeException(e.getMessage());
/*     */         }
/* 107 */         break;
/*     */       }
/* 109 */       if (LOG.isDebugEnabled()) {
/* 110 */         LOG.debug("Challenge for " + id + " authentication scheme not available");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 115 */     if (authscheme == null)
/*     */     {
/* 117 */       throw new AuthChallengeException("Unable to respond to any of these challenges: " + challenges);
/*     */     }
/*     */     
/*     */ 
/* 121 */     return authscheme;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AuthScheme processChallenge(AuthState state, Map challenges)
/*     */     throws MalformedChallengeException, AuthenticationException
/*     */   {
/* 140 */     if (state == null) {
/* 141 */       throw new IllegalArgumentException("Authentication state may not be null");
/*     */     }
/* 143 */     if (challenges == null) {
/* 144 */       throw new IllegalArgumentException("Challenge map may not be null");
/*     */     }
/*     */     
/* 147 */     if ((state.isPreemptive()) || (state.getAuthScheme() == null))
/*     */     {
/* 149 */       state.setAuthScheme(selectAuthScheme(challenges));
/*     */     }
/* 151 */     AuthScheme authscheme = state.getAuthScheme();
/* 152 */     String id = authscheme.getSchemeName();
/* 153 */     if (LOG.isDebugEnabled()) {
/* 154 */       LOG.debug("Using authentication scheme: " + id);
/*     */     }
/* 156 */     String challenge = (String)challenges.get(id.toLowerCase());
/* 157 */     if (challenge == null) {
/* 158 */       throw new AuthenticationException(id + " authorization challenge expected, but not found");
/*     */     }
/*     */     
/* 161 */     authscheme.processChallenge(challenge);
/* 162 */     LOG.debug("Authorization challenge processed");
/* 163 */     return authscheme;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\auth\AuthChallengeProcessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */