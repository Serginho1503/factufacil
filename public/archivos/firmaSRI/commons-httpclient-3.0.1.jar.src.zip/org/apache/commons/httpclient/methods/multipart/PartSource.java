package org.apache.commons.httpclient.methods.multipart;

import java.io.IOException;
import java.io.InputStream;

public abstract interface PartSource
{
  public abstract long getLength();
  
  public abstract String getFileName();
  
  public abstract InputStream createInputStream()
    throws IOException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\methods\multipart\PartSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */