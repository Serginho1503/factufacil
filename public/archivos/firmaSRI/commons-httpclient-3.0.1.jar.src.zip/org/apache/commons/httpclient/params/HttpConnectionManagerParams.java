/*     */ package org.apache.commons.httpclient.params;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.httpclient.HostConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpConnectionManagerParams
/*     */   extends HttpConnectionParams
/*     */ {
/*     */   public static final String MAX_HOST_CONNECTIONS = "http.connection-manager.max-per-host";
/*     */   public static final String MAX_TOTAL_CONNECTIONS = "http.connection-manager.max-total";
/*     */   
/*     */   public void setDefaultMaxConnectionsPerHost(int maxHostConnections)
/*     */   {
/*  85 */     setMaxConnectionsPerHost(HostConfiguration.ANY_HOST_CONFIGURATION, maxHostConnections);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaxConnectionsPerHost(HostConfiguration hostConfiguration, int maxHostConnections)
/*     */   {
/* 102 */     if (maxHostConnections <= 0) {
/* 103 */       throw new IllegalArgumentException("maxHostConnections must be greater than 0");
/*     */     }
/*     */     
/* 106 */     Map currentValues = (Map)getParameter("http.connection-manager.max-per-host");
/*     */     
/*     */ 
/* 109 */     Map newValues = null;
/* 110 */     if (currentValues == null) {
/* 111 */       newValues = new HashMap();
/*     */     } else {
/* 113 */       newValues = new HashMap(currentValues);
/*     */     }
/* 115 */     newValues.put(hostConfiguration, new Integer(maxHostConnections));
/* 116 */     setParameter("http.connection-manager.max-per-host", newValues);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDefaultMaxConnectionsPerHost()
/*     */   {
/* 128 */     return getMaxConnectionsPerHost(HostConfiguration.ANY_HOST_CONFIGURATION);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaxConnectionsPerHost(HostConfiguration hostConfiguration)
/*     */   {
/* 143 */     Map m = (Map)getParameter("http.connection-manager.max-per-host");
/* 144 */     if (m == null)
/*     */     {
/* 146 */       return 2;
/*     */     }
/* 148 */     Integer max = (Integer)m.get(hostConfiguration);
/* 149 */     if ((max == null) && (hostConfiguration != HostConfiguration.ANY_HOST_CONFIGURATION))
/*     */     {
/*     */ 
/* 152 */       return getMaxConnectionsPerHost(HostConfiguration.ANY_HOST_CONFIGURATION);
/*     */     }
/* 154 */     return max == null ? 2 : max.intValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaxTotalConnections(int maxTotalConnections)
/*     */   {
/* 171 */     setIntParameter("http.connection-manager.max-total", maxTotalConnections);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaxTotalConnections()
/*     */   {
/* 184 */     return getIntParameter("http.connection-manager.max-total", 20);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\params\HttpConnectionManagerParams.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */