/*    */ package org.apache.commons.httpclient.methods.multipart;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteArrayPartSource
/*    */   implements PartSource
/*    */ {
/*    */   private String fileName;
/*    */   private byte[] bytes;
/*    */   
/*    */   public ByteArrayPartSource(String fileName, byte[] bytes)
/*    */   {
/* 60 */     this.fileName = fileName;
/* 61 */     this.bytes = bytes;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public long getLength()
/*    */   {
/* 69 */     return this.bytes.length;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getFileName()
/*    */   {
/* 76 */     return this.fileName;
/*    */   }
/*    */   
/*    */ 
/*    */   public InputStream createInputStream()
/*    */     throws IOException
/*    */   {
/* 83 */     return new ByteArrayInputStream(this.bytes);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\methods\multipart\ByteArrayPartSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */