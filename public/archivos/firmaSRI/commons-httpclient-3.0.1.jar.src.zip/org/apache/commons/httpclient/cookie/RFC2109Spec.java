/*     */ package org.apache.commons.httpclient.cookie;
/*     */ 
/*     */ import org.apache.commons.httpclient.Cookie;
/*     */ import org.apache.commons.httpclient.NameValuePair;
/*     */ import org.apache.commons.httpclient.util.ParameterFormatter;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RFC2109Spec
/*     */   extends CookieSpecBase
/*     */ {
/*     */   private final ParameterFormatter formatter;
/*     */   
/*     */   public RFC2109Spec()
/*     */   {
/*  60 */     this.formatter = new ParameterFormatter();
/*  61 */     this.formatter.setAlwaysUseQuotes(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parseAttribute(NameValuePair attribute, Cookie cookie)
/*     */     throws MalformedCookieException
/*     */   {
/*  77 */     if (attribute == null) {
/*  78 */       throw new IllegalArgumentException("Attribute may not be null.");
/*     */     }
/*  80 */     if (cookie == null) {
/*  81 */       throw new IllegalArgumentException("Cookie may not be null.");
/*     */     }
/*  83 */     String paramName = attribute.getName().toLowerCase();
/*  84 */     String paramValue = attribute.getValue();
/*     */     
/*  86 */     if (paramName.equals("path")) {
/*  87 */       if (paramValue == null) {
/*  88 */         throw new MalformedCookieException("Missing value for path attribute");
/*     */       }
/*     */       
/*  91 */       if (paramValue.trim().equals("")) {
/*  92 */         throw new MalformedCookieException("Blank value for path attribute");
/*     */       }
/*     */       
/*  95 */       cookie.setPath(paramValue);
/*  96 */       cookie.setPathAttributeSpecified(true);
/*  97 */     } else if (paramName.equals("version"))
/*     */     {
/*  99 */       if (paramValue == null) {
/* 100 */         throw new MalformedCookieException("Missing value for version attribute");
/*     */       }
/*     */       try
/*     */       {
/* 104 */         cookie.setVersion(Integer.parseInt(paramValue));
/*     */       } catch (NumberFormatException e) {
/* 106 */         throw new MalformedCookieException("Invalid version: " + e.getMessage());
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 111 */       super.parseAttribute(attribute, cookie);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validate(String host, int port, String path, boolean secure, Cookie cookie)
/*     */     throws MalformedCookieException
/*     */   {
/* 130 */     CookieSpecBase.LOG.trace("enter RFC2109Spec.validate(String, int, String, boolean, Cookie)");
/*     */     
/*     */ 
/*     */ 
/* 134 */     super.validate(host, port, path, secure, cookie);
/*     */     
/*     */ 
/* 137 */     if (cookie.getName().indexOf(' ') != -1) {
/* 138 */       throw new MalformedCookieException("Cookie name may not contain blanks");
/*     */     }
/* 140 */     if (cookie.getName().startsWith("$")) {
/* 141 */       throw new MalformedCookieException("Cookie name may not start with $");
/*     */     }
/*     */     
/* 144 */     if ((cookie.isDomainAttributeSpecified()) && (!cookie.getDomain().equals(host)))
/*     */     {
/*     */ 
/*     */ 
/* 148 */       if (!cookie.getDomain().startsWith(".")) {
/* 149 */         throw new MalformedCookieException("Domain attribute \"" + cookie.getDomain() + "\" violates RFC 2109: domain must start with a dot");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 154 */       int dotIndex = cookie.getDomain().indexOf('.', 1);
/* 155 */       if ((dotIndex < 0) || (dotIndex == cookie.getDomain().length() - 1)) {
/* 156 */         throw new MalformedCookieException("Domain attribute \"" + cookie.getDomain() + "\" violates RFC 2109: domain must contain an embedded dot");
/*     */       }
/*     */       
/*     */ 
/* 160 */       host = host.toLowerCase();
/* 161 */       if (!host.endsWith(cookie.getDomain())) {
/* 162 */         throw new MalformedCookieException("Illegal domain attribute \"" + cookie.getDomain() + "\". Domain of origin: \"" + host + "\"");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 167 */       String hostWithoutDomain = host.substring(0, host.length() - cookie.getDomain().length());
/*     */       
/* 169 */       if (hostWithoutDomain.indexOf('.') != -1) {
/* 170 */         throw new MalformedCookieException("Domain attribute \"" + cookie.getDomain() + "\" violates RFC 2109: host minus domain may not contain any dots");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean domainMatch(String host, String domain)
/*     */   {
/* 186 */     boolean match = (host.equals(domain)) || ((domain.startsWith(".")) && (host.endsWith(domain)));
/*     */     
/*     */ 
/* 189 */     return match;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void formatParam(StringBuffer buffer, NameValuePair param, int version)
/*     */   {
/* 201 */     if (version < 1) {
/* 202 */       buffer.append(param.getName());
/* 203 */       buffer.append("=");
/* 204 */       if (param.getValue() != null) {
/* 205 */         buffer.append(param.getValue());
/*     */       }
/*     */     } else {
/* 208 */       this.formatter.format(buffer, param);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void formatCookieAsVer(StringBuffer buffer, Cookie cookie, int version)
/*     */   {
/* 220 */     String value = cookie.getValue();
/* 221 */     if (value == null) {
/* 222 */       value = "";
/*     */     }
/* 224 */     formatParam(buffer, new NameValuePair(cookie.getName(), value), version);
/* 225 */     if ((cookie.getPath() != null) && (cookie.isPathAttributeSpecified())) {
/* 226 */       buffer.append("; ");
/* 227 */       formatParam(buffer, new NameValuePair("$Path", cookie.getPath()), version);
/*     */     }
/* 229 */     if ((cookie.getDomain() != null) && (cookie.isDomainAttributeSpecified()))
/*     */     {
/* 231 */       buffer.append("; ");
/* 232 */       formatParam(buffer, new NameValuePair("$Domain", cookie.getDomain()), version);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String formatCookie(Cookie cookie)
/*     */   {
/* 243 */     CookieSpecBase.LOG.trace("enter RFC2109Spec.formatCookie(Cookie)");
/* 244 */     if (cookie == null) {
/* 245 */       throw new IllegalArgumentException("Cookie may not be null");
/*     */     }
/* 247 */     int version = cookie.getVersion();
/* 248 */     StringBuffer buffer = new StringBuffer();
/* 249 */     formatParam(buffer, new NameValuePair("$Version", Integer.toString(version)), version);
/*     */     
/*     */ 
/* 252 */     buffer.append("; ");
/* 253 */     formatCookieAsVer(buffer, cookie, version);
/* 254 */     return buffer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String formatCookies(Cookie[] cookies)
/*     */   {
/* 265 */     CookieSpecBase.LOG.trace("enter RFC2109Spec.formatCookieHeader(Cookie[])");
/* 266 */     int version = Integer.MAX_VALUE;
/*     */     
/* 268 */     for (int i = 0; i < cookies.length; i++) {
/* 269 */       Cookie cookie = cookies[i];
/* 270 */       if (cookie.getVersion() < version) {
/* 271 */         version = cookie.getVersion();
/*     */       }
/*     */     }
/* 274 */     StringBuffer buffer = new StringBuffer();
/* 275 */     formatParam(buffer, new NameValuePair("$Version", Integer.toString(version)), version);
/*     */     
/*     */ 
/* 278 */     for (int i = 0; i < cookies.length; i++) {
/* 279 */       buffer.append("; ");
/* 280 */       formatCookieAsVer(buffer, cookies[i], version);
/*     */     }
/* 282 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-httpclient-3.0.1.jar!\org\apache\commons\httpclient\cookie\RFC2109Spec.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */