package javax.xml.xpath;

import java.util.List;

public abstract interface XPathFunction
{
  public abstract Object evaluate(List paramList)
    throws XPathFunctionException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\javax\xml\xpath\XPathFunction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */