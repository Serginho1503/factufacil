package javax.xml.xpath;

public class XPathFactoryConfigurationException
  extends XPathException
{
  private static final long serialVersionUID = -1837080260374986980L;
  
  public XPathFactoryConfigurationException(String paramString)
  {
    super(paramString);
  }
  
  public XPathFactoryConfigurationException(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\javax\xml\xpath\XPathFactoryConfigurationException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */