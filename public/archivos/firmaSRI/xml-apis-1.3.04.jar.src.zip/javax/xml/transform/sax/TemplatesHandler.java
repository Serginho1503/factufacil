package javax.xml.transform.sax;

import javax.xml.transform.Templates;
import org.xml.sax.ContentHandler;

public abstract interface TemplatesHandler
  extends ContentHandler
{
  public abstract Templates getTemplates();
  
  public abstract void setSystemId(String paramString);
  
  public abstract String getSystemId();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\javax\xml\transform\sax\TemplatesHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */