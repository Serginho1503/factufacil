package javax.xml.transform;

import java.util.Properties;

public abstract interface Templates
{
  public abstract Transformer newTransformer()
    throws TransformerConfigurationException;
  
  public abstract Properties getOutputProperties();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\javax\xml\transform\Templates.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */