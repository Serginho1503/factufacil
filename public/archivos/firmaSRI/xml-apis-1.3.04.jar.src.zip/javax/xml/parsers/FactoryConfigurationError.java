package javax.xml.parsers;

public class FactoryConfigurationError
  extends Error
{
  private Exception exception;
  
  public FactoryConfigurationError()
  {
    this.exception = null;
  }
  
  public FactoryConfigurationError(String paramString)
  {
    super(paramString);
    this.exception = null;
  }
  
  public FactoryConfigurationError(Exception paramException)
  {
    super(paramException.toString());
    this.exception = paramException;
  }
  
  public FactoryConfigurationError(Exception paramException, String paramString)
  {
    super(paramString);
    this.exception = paramException;
  }
  
  public String getMessage()
  {
    String str = super.getMessage();
    if ((str == null) && (this.exception != null)) {
      return this.exception.getMessage();
    }
    return str;
  }
  
  public Exception getException()
  {
    return this.exception;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\javax\xml\parsers\FactoryConfigurationError.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */