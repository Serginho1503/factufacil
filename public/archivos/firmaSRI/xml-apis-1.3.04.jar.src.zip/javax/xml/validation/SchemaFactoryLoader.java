package javax.xml.validation;

public abstract class SchemaFactoryLoader
{
  public abstract SchemaFactory newFactory(String paramString);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\javax\xml\validation\SchemaFactoryLoader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */