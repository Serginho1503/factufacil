package org.apache.xmlcommons;

import java.io.PrintStream;

public class Version
{
  public static String getVersion()
  {
    return getProduct() + " " + getVersionNum();
  }
  
  public static String getProduct()
  {
    return "XmlCommonsExternal";
  }
  
  public static String getVersionNum()
  {
    return "1.3.04";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    System.out.println(getVersion());
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\apache\xmlcommons\Version.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */