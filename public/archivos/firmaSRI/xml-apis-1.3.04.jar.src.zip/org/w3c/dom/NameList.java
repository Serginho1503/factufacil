package org.w3c.dom;

public abstract interface NameList
{
  public abstract String getName(int paramInt);
  
  public abstract String getNamespaceURI(int paramInt);
  
  public abstract int getLength();
  
  public abstract boolean contains(String paramString);
  
  public abstract boolean containsNS(String paramString1, String paramString2);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\NameList.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */