package org.w3c.dom;

public abstract interface EntityReference
  extends Node
{}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\EntityReference.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */