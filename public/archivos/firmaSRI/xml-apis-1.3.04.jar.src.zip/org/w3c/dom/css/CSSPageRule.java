package org.w3c.dom.css;

import org.w3c.dom.DOMException;

public abstract interface CSSPageRule
  extends CSSRule
{
  public abstract String getSelectorText();
  
  public abstract void setSelectorText(String paramString)
    throws DOMException;
  
  public abstract CSSStyleDeclaration getStyle();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\css\CSSPageRule.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */