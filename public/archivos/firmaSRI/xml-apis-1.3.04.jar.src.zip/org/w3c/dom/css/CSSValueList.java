package org.w3c.dom.css;

public abstract interface CSSValueList
  extends CSSValue
{
  public abstract int getLength();
  
  public abstract CSSValue item(int paramInt);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\css\CSSValueList.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */