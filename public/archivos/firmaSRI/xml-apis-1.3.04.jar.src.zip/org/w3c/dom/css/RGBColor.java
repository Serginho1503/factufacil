package org.w3c.dom.css;

public abstract interface RGBColor
{
  public abstract CSSPrimitiveValue getRed();
  
  public abstract CSSPrimitiveValue getGreen();
  
  public abstract CSSPrimitiveValue getBlue();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\css\RGBColor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */