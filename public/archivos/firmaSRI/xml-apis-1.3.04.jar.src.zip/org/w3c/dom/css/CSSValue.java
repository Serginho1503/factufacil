package org.w3c.dom.css;

import org.w3c.dom.DOMException;

public abstract interface CSSValue
{
  public static final short CSS_INHERIT = 0;
  public static final short CSS_PRIMITIVE_VALUE = 1;
  public static final short CSS_VALUE_LIST = 2;
  public static final short CSS_CUSTOM = 3;
  
  public abstract String getCssText();
  
  public abstract void setCssText(String paramString)
    throws DOMException;
  
  public abstract short getCssValueType();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\css\CSSValue.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */