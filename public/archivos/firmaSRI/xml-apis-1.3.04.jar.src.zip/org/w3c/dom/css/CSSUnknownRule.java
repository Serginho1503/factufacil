package org.w3c.dom.css;

public abstract interface CSSUnknownRule
  extends CSSRule
{}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\css\CSSUnknownRule.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */