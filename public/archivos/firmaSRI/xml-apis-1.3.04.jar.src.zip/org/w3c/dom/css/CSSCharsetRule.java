package org.w3c.dom.css;

import org.w3c.dom.DOMException;

public abstract interface CSSCharsetRule
  extends CSSRule
{
  public abstract String getEncoding();
  
  public abstract void setEncoding(String paramString)
    throws DOMException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\css\CSSCharsetRule.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */