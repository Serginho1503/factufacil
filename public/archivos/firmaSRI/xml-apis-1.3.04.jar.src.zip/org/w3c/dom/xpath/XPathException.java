package org.w3c.dom.xpath;

public class XPathException
  extends RuntimeException
{
  public short code;
  public static final short INVALID_EXPRESSION_ERR = 51;
  public static final short TYPE_ERR = 52;
  
  public XPathException(short paramShort, String paramString)
  {
    super(paramString);
    this.code = paramShort;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\xpath\XPathException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */