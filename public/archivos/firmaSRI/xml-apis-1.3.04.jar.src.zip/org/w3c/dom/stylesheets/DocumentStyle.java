package org.w3c.dom.stylesheets;

public abstract interface DocumentStyle
{
  public abstract StyleSheetList getStyleSheets();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\stylesheets\DocumentStyle.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */