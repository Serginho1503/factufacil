package org.w3c.dom;

public abstract interface Comment
  extends CharacterData
{}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\Comment.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */