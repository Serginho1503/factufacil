package org.w3c.dom;

public abstract interface DOMImplementationSource
{
  public abstract DOMImplementation getDOMImplementation(String paramString);
  
  public abstract DOMImplementationList getDOMImplementationList(String paramString);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\DOMImplementationSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */