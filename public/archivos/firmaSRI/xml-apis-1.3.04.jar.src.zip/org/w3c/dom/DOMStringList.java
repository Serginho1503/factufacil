package org.w3c.dom;

public abstract interface DOMStringList
{
  public abstract String item(int paramInt);
  
  public abstract int getLength();
  
  public abstract boolean contains(String paramString);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\DOMStringList.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */