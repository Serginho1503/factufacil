package org.w3c.dom.events;

public abstract interface EventTarget
{
  public abstract void addEventListener(String paramString, EventListener paramEventListener, boolean paramBoolean);
  
  public abstract void removeEventListener(String paramString, EventListener paramEventListener, boolean paramBoolean);
  
  public abstract boolean dispatchEvent(Event paramEvent)
    throws EventException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\events\EventTarget.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */