package org.w3c.dom.events;

public abstract interface EventListener
{
  public abstract void handleEvent(Event paramEvent);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\events\EventListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */