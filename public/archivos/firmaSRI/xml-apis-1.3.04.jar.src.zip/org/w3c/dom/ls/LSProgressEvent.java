package org.w3c.dom.ls;

import org.w3c.dom.events.Event;

public abstract interface LSProgressEvent
  extends Event
{
  public abstract LSInput getInput();
  
  public abstract int getPosition();
  
  public abstract int getTotalSize();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\ls\LSProgressEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */