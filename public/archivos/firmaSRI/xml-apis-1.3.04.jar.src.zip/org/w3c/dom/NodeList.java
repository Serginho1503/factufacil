package org.w3c.dom;

public abstract interface NodeList
{
  public abstract Node item(int paramInt);
  
  public abstract int getLength();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\NodeList.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */