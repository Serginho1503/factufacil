package org.w3c.dom.html;

public abstract interface HTMLLIElement
  extends HTMLElement
{
  public abstract String getType();
  
  public abstract void setType(String paramString);
  
  public abstract int getValue();
  
  public abstract void setValue(int paramInt);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\html\HTMLLIElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */