package org.w3c.dom.html;

public abstract interface HTMLMapElement
  extends HTMLElement
{
  public abstract HTMLCollection getAreas();
  
  public abstract String getName();
  
  public abstract void setName(String paramString);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\html\HTMLMapElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */