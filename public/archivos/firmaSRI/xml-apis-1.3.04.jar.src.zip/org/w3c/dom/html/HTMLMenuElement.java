package org.w3c.dom.html;

public abstract interface HTMLMenuElement
  extends HTMLElement
{
  public abstract boolean getCompact();
  
  public abstract void setCompact(boolean paramBoolean);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\html\HTMLMenuElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */