package org.w3c.dom.html;

public abstract interface HTMLLabelElement
  extends HTMLElement
{
  public abstract HTMLFormElement getForm();
  
  public abstract String getAccessKey();
  
  public abstract void setAccessKey(String paramString);
  
  public abstract String getHtmlFor();
  
  public abstract void setHtmlFor(String paramString);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\html\HTMLLabelElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */