package org.w3c.dom.html;

public abstract interface HTMLModElement
  extends HTMLElement
{
  public abstract String getCite();
  
  public abstract void setCite(String paramString);
  
  public abstract String getDateTime();
  
  public abstract void setDateTime(String paramString);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\html\HTMLModElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */