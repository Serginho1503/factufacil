package org.w3c.dom.html;

public abstract interface HTMLStyleElement
  extends HTMLElement
{
  public abstract boolean getDisabled();
  
  public abstract void setDisabled(boolean paramBoolean);
  
  public abstract String getMedia();
  
  public abstract void setMedia(String paramString);
  
  public abstract String getType();
  
  public abstract void setType(String paramString);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\html\HTMLStyleElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */