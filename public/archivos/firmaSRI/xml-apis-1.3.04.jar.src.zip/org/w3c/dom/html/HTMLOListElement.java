package org.w3c.dom.html;

public abstract interface HTMLOListElement
  extends HTMLElement
{
  public abstract boolean getCompact();
  
  public abstract void setCompact(boolean paramBoolean);
  
  public abstract int getStart();
  
  public abstract void setStart(int paramInt);
  
  public abstract String getType();
  
  public abstract void setType(String paramString);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\html\HTMLOListElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */