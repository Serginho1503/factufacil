package org.w3c.dom.html;

public abstract interface HTMLIsIndexElement
  extends HTMLElement
{
  public abstract HTMLFormElement getForm();
  
  public abstract String getPrompt();
  
  public abstract void setPrompt(String paramString);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\html\HTMLIsIndexElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */