package org.w3c.dom.html;

public abstract interface HTMLBaseElement
  extends HTMLElement
{
  public abstract String getHref();
  
  public abstract void setHref(String paramString);
  
  public abstract String getTarget();
  
  public abstract void setTarget(String paramString);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\html\HTMLBaseElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */