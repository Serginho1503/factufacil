package org.w3c.dom.html;

public abstract interface HTMLTitleElement
  extends HTMLElement
{
  public abstract String getText();
  
  public abstract void setText(String paramString);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\html\HTMLTitleElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */