package org.w3c.dom.html;

public abstract interface HTMLTableCaptionElement
  extends HTMLElement
{
  public abstract String getAlign();
  
  public abstract void setAlign(String paramString);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\html\HTMLTableCaptionElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */