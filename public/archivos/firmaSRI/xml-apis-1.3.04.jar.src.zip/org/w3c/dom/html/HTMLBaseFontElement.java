package org.w3c.dom.html;

public abstract interface HTMLBaseFontElement
  extends HTMLElement
{
  public abstract String getColor();
  
  public abstract void setColor(String paramString);
  
  public abstract String getFace();
  
  public abstract void setFace(String paramString);
  
  public abstract String getSize();
  
  public abstract void setSize(String paramString);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\html\HTMLBaseFontElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */