package org.w3c.dom.html;

public abstract interface HTMLHeadElement
  extends HTMLElement
{
  public abstract String getProfile();
  
  public abstract void setProfile(String paramString);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\w3c\dom\html\HTMLHeadElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */