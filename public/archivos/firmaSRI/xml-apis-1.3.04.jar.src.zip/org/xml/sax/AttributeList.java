package org.xml.sax;

/**
 * @deprecated
 */
public abstract interface AttributeList
{
  public abstract int getLength();
  
  public abstract String getName(int paramInt);
  
  public abstract String getType(int paramInt);
  
  public abstract String getValue(int paramInt);
  
  public abstract String getType(String paramString);
  
  public abstract String getValue(String paramString);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\xml\sax\AttributeList.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */