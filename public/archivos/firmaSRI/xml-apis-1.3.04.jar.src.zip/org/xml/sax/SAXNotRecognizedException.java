package org.xml.sax;

public class SAXNotRecognizedException
  extends SAXException
{
  static final long serialVersionUID = 5440506620509557213L;
  
  public SAXNotRecognizedException() {}
  
  public SAXNotRecognizedException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\xml\sax\SAXNotRecognizedException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */