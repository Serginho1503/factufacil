package org.xml.sax;

public class SAXNotSupportedException
  extends SAXException
{
  static final long serialVersionUID = -1422818934641823846L;
  
  public SAXNotSupportedException() {}
  
  public SAXNotSupportedException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\xml\sax\SAXNotSupportedException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */