package org.xml.sax.ext;

import org.xml.sax.Locator;

public abstract interface Locator2
  extends Locator
{
  public abstract String getXMLVersion();
  
  public abstract String getEncoding();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\xml\sax\ext\Locator2.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */