package org.xml.sax.ext;

import org.xml.sax.SAXException;

public abstract interface LexicalHandler
{
  public abstract void startDTD(String paramString1, String paramString2, String paramString3)
    throws SAXException;
  
  public abstract void endDTD()
    throws SAXException;
  
  public abstract void startEntity(String paramString)
    throws SAXException;
  
  public abstract void endEntity(String paramString)
    throws SAXException;
  
  public abstract void startCDATA()
    throws SAXException;
  
  public abstract void endCDATA()
    throws SAXException;
  
  public abstract void comment(char[] paramArrayOfChar, int paramInt1, int paramInt2)
    throws SAXException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\xml-apis-1.3.04.jar!\org\xml\sax\ext\LexicalHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */