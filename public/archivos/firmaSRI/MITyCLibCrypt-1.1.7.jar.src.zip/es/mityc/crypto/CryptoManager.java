package es.mityc.crypto;

public abstract interface CryptoManager
{
  public abstract void feedSeed(byte[] paramArrayOfByte);
  
  public abstract String getUsedAlgorithmURI();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCrypt-1.1.7.jar!\es\mityc\crypto\CryptoManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */