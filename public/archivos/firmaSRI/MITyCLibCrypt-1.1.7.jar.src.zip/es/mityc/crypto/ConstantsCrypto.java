/*    */ package es.mityc.crypto;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstantsCrypto
/*    */ {
/*    */   public static final String LIB_NAME = "MITyCLibCrypt";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 23 */   public static final String[] SYMMETRIC_CIPHERS = {
/* 24 */     "AES", "Camellia", "CAST5", "Grainv1", "Grain128", "IDEA", "Noekeon", "SEED" };
/*    */   public static final String RSA_ALGORITHM = "RSA";
/*    */   public static final String TripleDES_ALGORITHM = "DESede";
/*    */   public static final String PBE_DES_ALGORITHM = "PBEWithMD5AndDES";
/*    */   public static final String AES_ALGORITHM = "AES";
/*    */   public static final String AES_CBC_PKCS5Padding_ALGORITHM = "AES/CBC/PKCS5Padding";
/*    */   public static final String PBEWithSHA256And256BitAES_CBC_BC_ALGORITHM = "PBEWithSHA256And256BitAES-CBC-BC";
/*    */   public static final String BLOWFISH_ALGORITHM = "Blowfish";
/*    */   public static final String BLOWFISH_CFB64_NO_PADDING = "Blowfish/CFB64/NoPadding";
/*    */   public static final String DIGEST_ALG_SHA1 = "SHA1";
/*    */   public static final String DIGEST_ALG_SHA256 = "SHA256";
/*    */   public static final String DIGEST_ALG_MD5 = "MD5";
/*    */   public static final String EL_GAMAL_ALGORITHM = "ElGamal";
/*    */   public static final String EL_GAMAL_NO_PADDING = "ElGamal/None/NoPadding";
/*    */   public static final String DIFFIE_HELLMAN_ALGORITHM = "DH";
/*    */   public static final String ELIPTIC_CURVE_DH = "ECDH";
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCrypt-1.1.7.jar!\es\mityc\crypto\ConstantsCrypto.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */