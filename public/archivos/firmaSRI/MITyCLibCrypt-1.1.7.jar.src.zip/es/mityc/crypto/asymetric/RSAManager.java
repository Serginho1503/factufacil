/*     */ package es.mityc.crypto.asymetric;
/*     */ 
/*     */ import es.mityc.crypto.CryptoManager;
/*     */ import es.mityc.crypto.symetric.TripleDESManager;
/*     */ import es.mityc.javasign.pkstore.IPKStoreManager;
/*     */ import es.mityc.javasign.utils.Base64Coder;
/*     */ import java.io.PrintStream;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.Key;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.KeyPair;
/*     */ import java.security.KeyPairGenerator;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.Provider;
/*     */ import java.security.Provider.Service;
/*     */ import java.security.PublicKey;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.Security;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.security.spec.EncodedKeySpec;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import java.security.spec.PKCS8EncodedKeySpec;
/*     */ import java.security.spec.X509EncodedKeySpec;
/*     */ import java.util.Set;
/*     */ import javax.crypto.BadPaddingException;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.IllegalBlockSizeException;
/*     */ import javax.crypto.NoSuchPaddingException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RSAManager
/*     */   implements CryptoManager
/*     */ {
/*  56 */   static Log logger = LogFactory.getLog(RSAManager.class);
/*     */   
/*     */   private static final int keySize = 1024;
/*     */   
/*  60 */   private static final byte[] salt = SecureRandom.getSeed(8);
/*     */   
/*  62 */   private Cipher rsaCipher = null;
/*  63 */   private SecureRandom random = null;
/*     */   
/*  65 */   private TripleDESManager simetricCipher = null;
/*     */   
/*     */   public static final String RSA_OAEP_KEY = "RSA/None/OAEPWithSHA1AndMGF1Padding";
/*     */   
/*     */   public static final String RSA_NONE = "RSA/None/NoPadding";
/*     */   public static final String RSA_ECB_PKCS1 = "RSA/ECB/PKCS1Padding";
/*     */   public static final String RSA = "RSA";
/*  72 */   private String usedAlgorithm = "RSA/None/OAEPWithSHA1AndMGF1Padding";
/*     */   
/*     */   public RSAManager() {
/*  75 */     init();
/*     */   }
/*     */   
/*     */   public void feedSeed(byte[] seed) {
/*  79 */     this.random.nextBytes(salt);
/*  80 */     if (seed != null) {
/*  81 */       for (int i = 0; (i < salt.length) && (i < seed.length); i++) {
/*  82 */         salt[i] = ((byte)(salt[i] & seed[i]));
/*     */       }
/*     */     }
/*  85 */     this.random.setSeed(salt);
/*     */   }
/*     */   
/*     */   private void init() throws SecurityException {
/*  89 */     if (Security.getProvider("BC") == null) {
/*  90 */       es.mityc.javasign.utils.Utils.addBCProvider();
/*     */     }
/*     */     try {
/*  93 */       this.rsaCipher = Cipher.getInstance("RSA/None/OAEPWithSHA1AndMGF1Padding", "BC");
/*     */     } catch (NoSuchAlgorithmException e) {
/*  95 */       throw new SecurityException("No se pudo instanciar el algoritmo RSA", e);
/*     */     } catch (NoSuchProviderException e) {
/*  97 */       throw new SecurityException("No se encontró el proveedor de BouncyCastle", e);
/*     */     } catch (NoSuchPaddingException e) {
/*  99 */       throw new SecurityException("No se pudo inicializar el relleno", e);
/*     */     }
/* 101 */     this.random = new SecureRandom(salt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] protectRSA(String plain, Key key)
/*     */     throws SecurityException
/*     */   {
/* 112 */     return protectRSA(plain.getBytes(), key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] protectRSA(String plain, Key key, Provider provider)
/*     */     throws SecurityException
/*     */   {
/* 124 */     return protectRSA(plain.getBytes(), key, provider);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] protectRSA(byte[] plain, Key key)
/*     */     throws SecurityException
/*     */   {
/* 135 */     if ((key == null) || (plain == null)) {
/* 136 */       throw new SecurityException("Faltan parámetros de entrada");
/*     */     }
/*     */     try
/*     */     {
/* 140 */       this.rsaCipher.init(1, key, this.random);
/* 141 */       byte[] cipherText = this.rsaCipher.doFinal(plain);
/*     */       
/* 143 */       return Base64Coder.encode(cipherText);
/*     */     } catch (InvalidKeyException ex) {
/* 145 */       throw new SecurityException(ex);
/*     */     } catch (IllegalBlockSizeException ex) {
/* 147 */       throw new SecurityException(ex);
/*     */     } catch (BadPaddingException ex) {
/* 149 */       throw new SecurityException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] protectRSA(byte[] plain, Key key, String alg)
/*     */     throws SecurityException
/*     */   {
/* 162 */     return protectRSA(plain, key, alg, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] protectRSA(byte[] plain, Key key, String alg, Provider provider)
/*     */     throws SecurityException
/*     */   {
/* 173 */     if ((key == null) || (plain == null)) {
/* 174 */       throw new SecurityException("Faltan parámetros de entrada");
/*     */     }
/*     */     
/* 177 */     if (provider == null) {
/* 178 */       provider = Security.getProvider("BC");
/*     */     }
/* 180 */     Cipher cipher = null;
/*     */     try {
/* 182 */       this.usedAlgorithm = alg;
/* 183 */       cipher = Cipher.getInstance(this.usedAlgorithm, provider.getName());
/* 184 */       if (logger.isDebugEnabled()) {
/* 185 */         logger.debug("Empleando el algoritmo " + this.usedAlgorithm + " con el proveedor " + cipher.getProvider().getName());
/*     */       }
/* 187 */       cipher.init(1, key, this.random);
/* 188 */       byte[] cipherText = cipher.doFinal(plain);
/*     */       
/* 190 */       return Base64Coder.encode(cipherText);
/*     */     } catch (Exception ex) {
/* 192 */       throw new SecurityException(ex);
/*     */     } finally {
/* 194 */       if (Security.getProvider("BC") != null) {
/* 195 */         if (logger.isDebugEnabled()) {
/* 196 */           logger.debug("Eliminando el proveedor BC");
/*     */         }
/* 198 */         Security.removeProvider("BC");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] protectRSA(byte[] plain, Key key, Provider provider)
/*     */     throws SecurityException
/*     */   {
/* 213 */     if ((key == null) || (plain == null)) {
/* 214 */       throw new SecurityException("Faltan parámetros de entrada");
/*     */     }
/*     */     
/*     */ 
/* 218 */     Cipher cipher = null;
/* 219 */     this.usedAlgorithm = "RSA/None/OAEPWithSHA1AndMGF1Padding";
/*     */     try {
/* 221 */       if (provider != null) {
/* 222 */         Provider.Service s = provider.getService("Cipher", this.usedAlgorithm);
/* 223 */         if (s == null) {
/* 224 */           logger.error("No se pudo encontrar el servicio Cipher.RSA en " + provider.getName());
/* 225 */           this.usedAlgorithm = "RSA";
/* 226 */           if ((logger.isTraceEnabled()) && (provider.getServices() != null)) {
/* 227 */             logger.trace("Servicios disponibles --> ");
/* 228 */             Object[] ser = provider.getServices().toArray();
/* 229 */             for (int i = 0; i < ser.length; i++) {
/* 230 */               logger.trace("Algoritmo disponible: " + ((Provider.Service)ser[i]).getAlgorithm());
/*     */             }
/*     */           }
/*     */         }
/* 234 */         if (logger.isDebugEnabled()) {
/* 235 */           logger.debug("Proveedor: " + provider.getInfo());
/* 236 */           logger.debug("Algoritmo a emplear: " + this.usedAlgorithm);
/*     */         }
/* 238 */         cipher = Cipher.getInstance(this.usedAlgorithm, provider);
/*     */       } else {
/* 240 */         cipher = Cipher.getInstance(this.usedAlgorithm);
/*     */       }
/*     */       
/* 243 */       cipher.init(1, key, this.random);
/* 244 */       byte[] cipherText = cipher.doFinal(plain);
/*     */       
/* 246 */       return Base64Coder.encode(cipherText);
/*     */     } catch (InvalidKeyException ex) {
/*     */       try {
/* 249 */         if (logger.isDebugEnabled()) {
/* 250 */           logger.error(ex);
/* 251 */           logger.debug("Reintento con configuración por defecto: ");
/*     */         }
/*     */         
/* 254 */         this.usedAlgorithm = "RSA/ECB/PKCS1Padding";
/* 255 */         cipher = Cipher.getInstance(this.usedAlgorithm, "BC");
/* 256 */         if (logger.isDebugEnabled()) {
/* 257 */           logger.debug("Empleando el algoritmo " + this.usedAlgorithm + " con el proveedor " + cipher.getProvider().getName());
/*     */         }
/* 259 */         cipher.init(1, key, this.random);
/* 260 */         byte[] cipherText = cipher.doFinal(plain);
/*     */         
/* 262 */         arrayOfChar = Base64Coder.encode(cipherText);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 294 */         if ((provider != null) && (Security.getProvider(provider.getName()) != null)) {
/* 295 */           Security.removeProvider(provider.getName());
/*     */         }
/* 262 */         return arrayOfChar;
/*     */       } catch (Exception e) {
/* 264 */         if (logger.isDebugEnabled()) {
/* 265 */           logger.debug("Error al encriptar", e);
/*     */         }
/* 267 */         throw new SecurityException(ex);
/*     */       }
/*     */     } catch (IllegalBlockSizeException ex) {
/* 270 */       throw new SecurityException(ex);
/*     */     } catch (BadPaddingException ex) {
/* 272 */       throw new SecurityException(ex);
/*     */     } catch (NoSuchAlgorithmException e) {
/*     */       try {
/* 275 */         if (logger.isDebugEnabled()) {
/* 276 */           logger.error(e);
/* 277 */           logger.debug("NoSuchAlgorithmException. Reintento con configuración por defecto: ");
/*     */         }
/* 279 */         this.usedAlgorithm = "RSA/ECB/PKCS1Padding";
/* 280 */         cipher = Cipher.getInstance(this.usedAlgorithm, "BC");
/* 281 */         cipher.init(1, key, this.random);
/* 282 */         byte[] cipherText = cipher.doFinal(plain);
/*     */         
/* 284 */         char[] arrayOfChar = Base64Coder.encode(cipherText);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 294 */         if ((provider != null) && (Security.getProvider(provider.getName()) != null)) {
/* 295 */           Security.removeProvider(provider.getName());
/*     */         }
/* 284 */         return arrayOfChar;
/*     */       } catch (Exception e2) {
/* 286 */         if (logger.isDebugEnabled()) {
/* 287 */           logger.debug("No se encontró el algoritmo", e2);
/*     */         }
/* 289 */         throw new SecurityException("No se detectó el algoritmo RSA", e);
/*     */       }
/*     */     } catch (NoSuchPaddingException e) {
/* 292 */       throw new SecurityException(e);
/*     */     } finally {
/* 294 */       if ((provider != null) && (Security.getProvider(provider.getName()) != null)) {
/* 295 */         Security.removeProvider(provider.getName());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] recoverRSA(char[] cryptedText, Key key)
/*     */     throws SecurityException
/*     */   {
/* 308 */     if ((key == null) || (cryptedText == null)) {
/* 309 */       throw new SecurityException("Faltan parámetros de entrada");
/*     */     }
/*     */     try
/*     */     {
/* 313 */       this.rsaCipher.init(2, key);
/*     */       
/*     */ 
/* 316 */       return this.rsaCipher.doFinal(Base64Coder.decode(cryptedText));
/*     */     }
/*     */     catch (InvalidKeyException ex)
/*     */     {
/* 320 */       throw new SecurityException(ex);
/*     */     } catch (IllegalBlockSizeException ex) {
/* 322 */       throw new SecurityException(ex);
/*     */     } catch (BadPaddingException ex) {
/* 324 */       throw new SecurityException("Clave incorrecta", ex);
/*     */     } catch (IllegalArgumentException ex) {
/* 326 */       throw new SecurityException("Clave incorrecta", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] recoverRSA(char[] cryptedText, IPKStoreManager storeManager, X509Certificate cert, String algoritmURI)
/*     */     throws SecurityException
/*     */   {
/* 339 */     return recoverRSA(cryptedText, storeManager, cert, algoritmURI, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] recoverRSA(char[] cryptedText, IPKStoreManager storeManager, X509Certificate cert, String algoritmURI, Provider provider)
/*     */     throws SecurityException
/*     */   {
/* 350 */     if ((storeManager == null) || (cryptedText == null) || (cert == null)) {
/* 351 */       throw new SecurityException("Faltan parámetros de entrada");
/*     */     }
/* 353 */     if (provider == null)
/* 354 */       provider = Security.getProvider("BC");
/* 355 */     PrivateKey privateKey = null;
/*     */     try {
/* 357 */       if ((provider != null) && (Security.getProvider(provider.getName()) == null)) {
/* 358 */         Security.addProvider(provider);
/* 359 */         if (logger.isDebugEnabled()) {
/* 360 */           if (Security.getProvider(provider.getName()) == null) {
/* 361 */             logger.debug("No se ha insertado el proveedor");
/*     */           } else {
/* 363 */             logger.debug("Proveedor insertado correctamente");
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 368 */       privateKey = storeManager.getPrivateKey(cert);
/*     */       
/* 370 */       if (logger.isTraceEnabled()) {
/* 371 */         Provider[] provs = Security.getProviders();
/*     */         
/* 373 */         if (provs != null) {
/* 374 */           logger.trace("\n*** Proveedores disponibles --> ");
/* 375 */           for (int i = 0; i < provs.length; i++) {
/* 376 */             logger.trace(provs[i].getName());
/*     */           }
/*     */         }
/* 379 */         if ((provider != null) && (provider.getServices() != null)) {
/* 380 */           logger.trace("\n*** Servicios disponibles en " + provider.getName() + " --> ");
/* 381 */           Object[] ser = provider.getServices().toArray();
/* 382 */           for (int i = 0; i < ser.length; i++) {
/* 383 */             logger.trace(((Provider.Service)ser[i]).getAlgorithm());
/*     */           }
/*     */         }
/* 386 */         if (privateKey != null) {
/* 387 */           logger.trace("Algoritmo de la clave privada --> " + privateKey.getAlgorithm());
/* 388 */           logger.trace("Formato de la clave privada --> " + privateKey.getFormat());
/*     */         }
/*     */       }
/* 391 */       if (algoritmURI != null) {
/* 392 */         this.usedAlgorithm = algoritmURI;
/*     */       } else {
/* 394 */         this.usedAlgorithm = "RSA/None/OAEPWithSHA1AndMGF1Padding";
/*     */       }
/*     */       
/* 397 */       Cipher cipher = null;
/* 398 */       if (provider != null) {
/* 399 */         cipher = Cipher.getInstance(this.usedAlgorithm, provider);
/* 400 */         if (logger.isDebugEnabled()) {
/* 401 */           logger.debug("Empleando el algoritmo " + this.usedAlgorithm + " con el proveedor " + provider);
/*     */         }
/*     */       } else {
/* 404 */         if (logger.isDebugEnabled()) {
/* 405 */           logger.debug("Empleando el algoritmo " + this.usedAlgorithm + " con la lista de proveedores");
/*     */         }
/* 407 */         cipher = Cipher.getInstance(this.usedAlgorithm);
/*     */       }
/*     */       
/* 410 */       byte[] ciphertext = null;
/* 411 */       return decryptText(cryptedText, provider, privateKey, cipher);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 415 */       if (logger.isDebugEnabled())
/* 416 */         logger.debug("Se produjo un error al desencriptar: " + ex.getMessage(), ex);
/*     */       try {
/* 418 */         this.usedAlgorithm = "RSA/None/OAEPWithSHA1AndMGF1Padding";
/* 419 */         Cipher cipher = Cipher.getInstance(this.usedAlgorithm);
/* 420 */         if (logger.isDebugEnabled()) {
/* 421 */           logger.debug("Empleando el algoritmo " + this.usedAlgorithm + " con el proveedor " + cipher.getProvider().getName());
/*     */         }
/*     */         
/*     */ 
/* 425 */         byte[] ciphertext = decryptText(cryptedText, provider, privateKey, cipher);
/*     */         
/*     */ 
/* 428 */         return ciphertext;
/*     */       } catch (Exception e2) { byte[] arrayOfByte1;
/* 430 */         logger.debug("Error RSA para el descifrado según: " + this.usedAlgorithm, e2);
/*     */         try {
/* 432 */           this.usedAlgorithm = "RSA/ECB/PKCS1Padding";
/* 433 */           Cipher cipher = Cipher.getInstance(this.usedAlgorithm, provider);
/* 434 */           if (logger.isDebugEnabled()) {
/* 435 */             logger.debug("Empleando el algoritmo " + this.usedAlgorithm + " con el proveedor " + cipher.getProvider().getName());
/*     */           }
/*     */           
/* 438 */           byte[] ciphertext = decryptText(cryptedText, provider, privateKey, cipher);
/*     */           
/* 440 */           arrayOfByte1 = ciphertext;
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 473 */           if ((provider != null) && (Security.getProvider(provider.getName()) != null)) {
/* 474 */             Security.removeProvider(provider.getName());
/*     */           }
/* 440 */           return arrayOfByte1;
/*     */         } catch (Exception e3) {
/* 442 */           logger.debug("Error RSA para el descifrado según: " + this.usedAlgorithm + " con el proveedor " + provider, e3);
/*     */           try {
/* 444 */             this.usedAlgorithm = "RSA";
/* 445 */             Cipher cipher = Cipher.getInstance(this.usedAlgorithm, provider);
/* 446 */             if (logger.isDebugEnabled()) {
/* 447 */               logger.debug("Empleando el algoritmo " + this.usedAlgorithm + " con el proveedor " + cipher.getProvider().getName());
/*     */             }
/*     */             
/* 450 */             byte[] ciphertext = decryptText(cryptedText, provider, privateKey, cipher);
/*     */             
/* 452 */             arrayOfByte1 = ciphertext;
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 473 */             if ((provider != null) && (Security.getProvider(provider.getName()) != null)) {
/* 474 */               Security.removeProvider(provider.getName());
/*     */             }
/* 452 */             return arrayOfByte1;
/*     */           } catch (Exception e4) {
/* 454 */             logger.debug("Error RSA para el descifrado según: " + this.usedAlgorithm + " con el proveedor " + provider, e4);
/*     */             try {
/* 456 */               this.usedAlgorithm = "RSA/ECB/PKCS1Padding";
/* 457 */               Cipher cipher = Cipher.getInstance(this.usedAlgorithm);
/* 458 */               if (logger.isDebugEnabled()) {
/* 459 */                 logger.debug("Empleando el algoritmo " + this.usedAlgorithm + " con el proveedor " + cipher.getProvider().getName());
/*     */               }
/*     */               
/* 462 */               byte[] ciphertext = decryptText(cryptedText, provider, privateKey, cipher);
/*     */               
/* 464 */               arrayOfByte1 = ciphertext;
/*     */               
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 473 */               if ((provider != null) && (Security.getProvider(provider.getName()) != null)) {
/* 474 */                 Security.removeProvider(provider.getName());
/*     */               }
/* 464 */               return arrayOfByte1;
/*     */             } catch (Exception e5) {
/* 466 */               logger.debug("No se pudo desencriptar", e5);
/*     */               
/*     */ 
/*     */ 
/*     */ 
/* 471 */               throw new SecurityException("Error RSA - No se pudo desencriptar", e2);
/*     */             }
/* 473 */           } } } finally { if ((provider != null) && (Security.getProvider(provider.getName()) != null)) {
/* 474 */           Security.removeProvider(provider.getName());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private byte[] decryptText(char[] cryptedText, Provider provider, PrivateKey privateKey, Cipher cipher)
/*     */     throws InvalidKeyException, NoSuchAlgorithmException, IllegalBlockSizeException, BadPaddingException
/*     */   {
/*     */     byte[] ciphertext;
/*     */     byte[] ciphertext;
/* 486 */     if ((provider != null) && (provider.getName() != null) && (provider.getName().contains("Mozilla-JSS"))) {
/* 487 */       if (logger.isDebugEnabled()) {
/* 488 */         logger.debug("Recuperando clave a través de Mozilla-JSS");
/*     */       }
/* 490 */       cipher.init(4, privateKey);
/* 491 */       ciphertext = cipher.unwrap(Base64Coder.decode(cryptedText), "DESede", 3).getEncoded();
/*     */     } else {
/* 493 */       cipher.init(2, privateKey);
/* 494 */       ciphertext = cipher.doFinal(Base64Coder.decode(cryptedText));
/*     */     }
/* 496 */     return ciphertext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String genNewRSAKeys(String password)
/*     */   {
/*     */     try
/*     */     {
/* 507 */       KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA", "BC");
/* 508 */       generator.initialize(1024, this.random);
/* 509 */       KeyPair newKeys = generator.generateKeyPair();
/*     */       
/*     */ 
/* 512 */       byte[] pbcBuffer = newKeys.getPublic().getEncoded();
/* 513 */       byte[] pvtBuffer = newKeys.getPrivate().getEncoded();
/*     */       
/*     */ 
/* 516 */       int totalSize = pbcBuffer.length + pvtBuffer.length + 4;
/* 517 */       byte[] pairData = new byte[totalSize];
/*     */       
/* 519 */       char[] pubSize = String.valueOf(pbcBuffer.length).toCharArray();
/*     */       
/*     */ 
/* 522 */       for (int i = 0; i < pubSize.length; i++) {
/* 523 */         pairData[i] = ((byte)pubSize[i]);
/*     */       }
/*     */       
/* 526 */       for (int i = 0; i < pbcBuffer.length; i++) {
/* 527 */         pairData[(i + 4)] = pbcBuffer[i];
/*     */       }
/* 529 */       for (int i = pbcBuffer.length + 4; i < totalSize; i++) {
/* 530 */         pairData[i] = pvtBuffer[(i - (pbcBuffer.length + 4))];
/*     */       }
/*     */       
/* 533 */       if (this.simetricCipher == null) {
/* 534 */         this.simetricCipher = new TripleDESManager();
/*     */       }
/*     */       
/* 537 */       char[] encPairChar = this.simetricCipher.protectTripleDES(pairData, password);
/*     */       
/* 539 */       return new String(encPairChar);
/*     */     } catch (NoSuchAlgorithmException e) {
/* 541 */       throw new SecurityException(e);
/*     */     } catch (NoSuchProviderException e) {
/* 543 */       throw new SecurityException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyPair unprotectKeyPair(String encPair, String password)
/*     */     throws SecurityException
/*     */   {
/* 554 */     return unprotectKeyPair(encPair.toCharArray(), password);
/*     */   }
/*     */   
/*     */   public KeyPair unprotectKeyPair(char[] encPairChar, String password) throws SecurityException {
/* 558 */     if (this.simetricCipher == null) {
/* 559 */       this.simetricCipher = new TripleDESManager();
/*     */     }
/*     */     
/* 562 */     byte[] pair = this.simetricCipher.recoverTripleDES(encPairChar, password);
/*     */     
/*     */ 
/* 565 */     int pubKeySize = 0;
/* 566 */     int cifra = 0;
/* 567 */     for (int i = 0; i < 4; i++) {
/*     */       try {
/* 569 */         cifra = Integer.valueOf(String.valueOf((char)pair[i])).intValue();
/* 570 */         if ((cifra >= 0) && (cifra <= 9)) {
/* 571 */           pubKeySize = pubKeySize * 10 + cifra;
/*     */         }
/*     */       }
/*     */       catch (NumberFormatException e) {
/*     */         break;
/*     */       }
/*     */     }
/* 578 */     byte[] publicKeyData = new byte[pubKeySize];
/* 579 */     byte[] privateKeyData = new byte[pair.length - pubKeySize - 4];
/*     */     
/* 581 */     for (int i = 4; i < pubKeySize + 4; i++) {
/* 582 */       publicKeyData[(i - 4)] = pair[i];
/*     */     }
/* 584 */     for (int i = pubKeySize + 4; i < pair.length; i++) {
/* 585 */       privateKeyData[(i - (pubKeySize + 4))] = pair[i];
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 590 */       KeyFactory keyFactory = KeyFactory.getInstance("RSA", "BC");
/* 591 */       EncodedKeySpec privateKeySpec = new PKCS8EncodedKeySpec(privateKeyData);
/* 592 */       EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(publicKeyData);
/*     */       
/* 594 */       return new KeyPair(keyFactory.generatePublic(publicKeySpec), keyFactory.generatePrivate(privateKeySpec));
/*     */     } catch (NoSuchAlgorithmException e) {
/* 596 */       throw new SecurityException(e);
/*     */     } catch (InvalidKeySpecException e) {
/* 598 */       throw new SecurityException(e);
/*     */     } catch (NoSuchProviderException e) {
/* 600 */       throw new SecurityException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getUsedAlgorithmURI() {
/* 605 */     if (this.usedAlgorithm == "RSA/None/OAEPWithSHA1AndMGF1Padding") {
/* 606 */       return "http://www.w3.org/2001/04/xmlenc#rsa-oaep-mgf1p";
/*     */     }
/* 608 */     return "http://www.w3.org/2001/04/xmlenc#rsa-1_5";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 616 */     RSAManager p = new RSAManager();
/*     */     
/* 618 */     System.out.println("Se solicita el cálculo de un nuevo par de claves asimétricas de 1024 bits");
/* 619 */     Long start = Long.valueOf(System.currentTimeMillis());
/* 620 */     String protectedPair = p.genNewRSAKeys("ecoestadisticassrepals");
/* 621 */     KeyPair pair = p.unprotectKeyPair(protectedPair, "ecoestadisticassrepals");
/* 622 */     Long time = Long.valueOf(System.currentTimeMillis() - start.longValue());
/* 623 */     System.out.println("Claves obtenidas. Tiempo consumido (ms): " + time + ". Comienzan las pruebas de encriptación...");
/*     */     
/* 625 */     System.out.println("Texto en claro: " + args[0]);
/* 626 */     String buffer = args[0];
/* 627 */     char[] bufferChar = p.protectRSA(buffer, pair.getPrivate());
/* 628 */     buffer = new String(bufferChar);
/* 629 */     System.out.println("Texto encriptado RSA con privada: " + buffer);
/* 630 */     buffer = new String(p.recoverRSA(bufferChar, pair.getPublic()));
/* 631 */     System.out.println("Texto desencriptado RSA con pública: " + buffer);
/*     */     
/* 633 */     start = Long.valueOf(System.currentTimeMillis());
/* 634 */     buffer = es.mityc.crypto.Utils.obfuscate(new String(p.protectRSA(buffer, pair.getPublic())));
/* 635 */     System.out.println("Encriptado RSA con pública y ofuscado: " + buffer);
/* 636 */     buffer = new String(p.recoverRSA(es.mityc.crypto.Utils.undoObfuscate(buffer.getBytes()).toCharArray(), pair.getPrivate()));
/* 637 */     time = Long.valueOf(System.currentTimeMillis() - start.longValue());
/* 638 */     System.out.println("Texto recuperado con privada: " + buffer + "\nTiempo consumido (ms): " + time);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCrypt-1.1.7.jar!\es\mityc\crypto\asymetric\RSAManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */