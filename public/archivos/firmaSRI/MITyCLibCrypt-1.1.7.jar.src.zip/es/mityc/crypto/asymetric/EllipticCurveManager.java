/*     */ package es.mityc.crypto.asymetric;
/*     */ 
/*     */ import es.mityc.crypto.CryptoManager;
/*     */ import es.mityc.crypto.symetric.TripleDESManager;
/*     */ import es.mityc.javasign.utils.Base64Coder;
/*     */ import java.io.PrintStream;
/*     */ import java.math.BigInteger;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.Key;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.KeyPair;
/*     */ import java.security.KeyPairGenerator;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.PublicKey;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.Security;
/*     */ import java.security.spec.EncodedKeySpec;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import java.security.spec.PKCS8EncodedKeySpec;
/*     */ import java.security.spec.X509EncodedKeySpec;
/*     */ import javax.crypto.BadPaddingException;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.IllegalBlockSizeException;
/*     */ import javax.crypto.NoSuchPaddingException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.bouncycastle.jce.spec.ECParameterSpec;
/*     */ import org.bouncycastle.jce.spec.IEKeySpec;
/*     */ import org.bouncycastle.jce.spec.IESParameterSpec;
/*     */ import org.bouncycastle.math.ec.ECCurve;
/*     */ import org.bouncycastle.math.ec.ECCurve.Fp;
/*     */ import org.bouncycastle.util.encoders.Hex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EllipticCurveManager
/*     */   implements CryptoManager
/*     */ {
/*  59 */   static Log logger = LogFactory.getLog(EllipticCurveManager.class);
/*     */   
/*     */   private static final int keySize = 4096;
/*     */   
/*  63 */   private static byte[] salt = SecureRandom.getSeed(8);
/*     */   
/*  65 */   private Cipher ecCipher = null;
/*  66 */   private SecureRandom random = null;
/*     */   
/*  68 */   private TripleDESManager simetricCipher = null;
/*     */   
/*     */   public EllipticCurveManager() {
/*  71 */     init();
/*     */   }
/*     */   
/*     */   public void feedSeed(byte[] seed) {
/*  75 */     this.random.nextBytes(salt);
/*  76 */     if (seed != null) {
/*  77 */       for (int i = 0; (i < salt.length) && (i < seed.length); i++) {
/*  78 */         salt[i] = ((byte)(salt[i] & seed[i]));
/*     */       }
/*     */     }
/*  81 */     this.random.setSeed(salt);
/*     */   }
/*     */   
/*     */   private void init() throws SecurityException {
/*  85 */     if (Security.getProvider("BC") == null) {
/*  86 */       es.mityc.javasign.utils.Utils.addBCProvider();
/*     */     }
/*     */     try {
/*  89 */       this.ecCipher = Cipher.getInstance("ECIES", "BC");
/*     */     } catch (NoSuchAlgorithmException e) {
/*  91 */       throw new SecurityException("No se pudo instanciar el algoritmo EC", e);
/*     */     } catch (NoSuchProviderException e) {
/*  93 */       throw new SecurityException("No se encontró el proveedor de BouncyCastle", e);
/*     */     } catch (NoSuchPaddingException e) {
/*  95 */       throw new SecurityException("No se pudo inicializar el relleno", e);
/*     */     }
/*  97 */     this.random = new SecureRandom(salt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] protectEC(String plain, Key key)
/*     */     throws SecurityException
/*     */   {
/* 108 */     if ((key == null) || (plain == null)) {
/* 109 */       throw new SecurityException("Faltan parámetros de entrada");
/*     */     }
/*     */     try
/*     */     {
/* 113 */       this.ecCipher.init(1, key, this.random);
/* 114 */       byte[] cipherText = this.ecCipher.doFinal(plain.getBytes());
/*     */       
/* 116 */       return Base64Coder.encode(cipherText);
/*     */     } catch (InvalidKeyException ex) {
/* 118 */       throw new SecurityException(ex);
/*     */     } catch (IllegalBlockSizeException ex) {
/* 120 */       throw new SecurityException(ex);
/*     */     } catch (BadPaddingException ex) {
/* 122 */       throw new SecurityException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] recoverEC(char[] cryptedText, Key key)
/*     */     throws SecurityException
/*     */   {
/* 134 */     if ((key == null) || (cryptedText == null)) {
/* 135 */       throw new SecurityException("Faltan parámetros de entrada");
/*     */     }
/*     */     try
/*     */     {
/* 139 */       this.ecCipher.init(2, key);
/*     */       
/*     */ 
/* 142 */       return this.ecCipher.doFinal(Base64Coder.decode(cryptedText));
/*     */     }
/*     */     catch (InvalidKeyException ex)
/*     */     {
/* 146 */       throw new SecurityException(ex);
/*     */     } catch (IllegalBlockSizeException ex) {
/* 148 */       throw new SecurityException(ex);
/*     */     } catch (BadPaddingException ex) {
/* 150 */       throw new SecurityException("Clave incorrecta", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String genNewECKeys(String password)
/*     */   {
/*     */     try
/*     */     {
/* 164 */       ECCurve curva = new ECCurve.Fp(
/* 165 */         new BigInteger("883423532389192164791648750360308885314476597252960362792450860609699839"), 
/* 166 */         new BigInteger("7fffffffffffffffffffffff7fffffffffff8000000000007ffffffffffc", 16), 
/* 167 */         new BigInteger("6b016c3bdcf18941d0d654921475ca71a9db2fb27d1d37796185c2942c0a", 16));
/*     */       
/* 169 */       ECParameterSpec ecSpec = new ECParameterSpec(
/* 170 */         curva, 
/* 171 */         curva.decodePoint(Hex.decode("020ffa963cdca8816ccc33b8642bedf905c3d358573d3f27fbbd3b3cb9aaaf")), 
/* 172 */         new BigInteger("883423532389192164791648750360308884807550341691627752275345424702807307"));
/*     */       
/* 174 */       KeyPairGenerator generator = KeyPairGenerator.getInstance("ECIES", "BC");
/*     */       
/* 176 */       generator.initialize(192, this.random);
/* 177 */       KeyPair newKeys = generator.generateKeyPair();
/*     */       
/*     */       try
/*     */       {
/* 181 */         PrivateKey privateKey = newKeys.getPrivate();
/* 182 */         PublicKey publicaKey = newKeys.getPublic();
/*     */         
/* 184 */         System.out.println("Clave privada " + privateKey.toString());
/* 185 */         System.out.println("Clave publica " + publicaKey.toString());
/*     */         
/* 187 */         newKeys = generator.generateKeyPair();
/*     */         
/* 189 */         PrivateKey priKey = newKeys.getPrivate();
/* 190 */         PublicKey pubKey = newKeys.getPublic();
/*     */         
/* 192 */         Cipher cifrador = Cipher.getInstance("ECIES", "BC");
/*     */         
/* 194 */         IEKeySpec c1Key = new IEKeySpec(privateKey, pubKey);
/* 195 */         IEKeySpec c2Key = new IEKeySpec(priKey, publicaKey);
/*     */         
/* 197 */         byte[] d = { 1, 2, 3, 4, 5, 6, 7, 8 };
/* 198 */         byte[] e = { 8, 7, 6, 5, 4, 3, 2, 1 };
/*     */         
/* 200 */         IESParameterSpec param = new IESParameterSpec(d, e, 128);
/*     */         
/* 202 */         cifrador.init(1, c1Key, param);
/* 203 */         byte[] mensajeCifrado = cifrador.doFinal("123456".getBytes());
/* 204 */         System.out.println("Mensaje Cifrado: " + mensajeCifrado);
/*     */         
/* 206 */         cifrador.init(2, c2Key, param);
/* 207 */         byte[] mensajeRecuperado = cifrador.doFinal(mensajeCifrado);
/* 208 */         System.out.println("Mensaje Recuperado: " + new String(mensajeRecuperado));
/*     */       } catch (Exception e) {
/* 210 */         e.printStackTrace();
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 216 */       byte[] pbcBuffer = newKeys.getPublic().getEncoded();
/* 217 */       byte[] pvtBuffer = newKeys.getPrivate().getEncoded();
/*     */       
/*     */ 
/* 220 */       int totalSize = pbcBuffer.length + pvtBuffer.length + 4;
/* 221 */       byte[] pairData = new byte[totalSize];
/*     */       
/* 223 */       char[] pubSize = String.valueOf(pbcBuffer.length).toCharArray();
/*     */       
/*     */ 
/* 226 */       for (int i = 0; i < pubSize.length; i++) {
/* 227 */         pairData[i] = ((byte)pubSize[i]);
/*     */       }
/*     */       
/* 230 */       for (int i = 0; i < pbcBuffer.length; i++) {
/* 231 */         pairData[(i + 4)] = pbcBuffer[i];
/*     */       }
/* 233 */       for (int i = pbcBuffer.length + 4; i < totalSize; i++) {
/* 234 */         pairData[i] = pvtBuffer[(i - (pbcBuffer.length + 4))];
/*     */       }
/*     */       
/* 237 */       if (this.simetricCipher == null) {
/* 238 */         this.simetricCipher = new TripleDESManager();
/*     */       }
/*     */       
/* 241 */       char[] encPairChar = this.simetricCipher.protectTripleDES(pairData, password);
/*     */       
/* 243 */       return new String(encPairChar);
/*     */     } catch (NoSuchAlgorithmException e) {
/* 245 */       throw new SecurityException(e);
/*     */     } catch (NoSuchProviderException e) {
/* 247 */       throw new SecurityException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyPair unprotectKeyPair(String encPair, String password)
/*     */     throws SecurityException
/*     */   {
/* 258 */     return unprotectKeyPair(encPair.toCharArray(), password);
/*     */   }
/*     */   
/*     */   public KeyPair unprotectKeyPair(char[] encPairChar, String password) throws SecurityException {
/* 262 */     if (this.simetricCipher == null) {
/* 263 */       this.simetricCipher = new TripleDESManager();
/*     */     }
/*     */     
/* 266 */     byte[] pair = this.simetricCipher.recoverTripleDES(encPairChar, password);
/*     */     
/*     */ 
/* 269 */     int pubKeySize = 0;
/* 270 */     int cifra = 0;
/* 271 */     for (int i = 0; i < 4; i++) {
/*     */       try {
/* 273 */         cifra = Integer.valueOf(String.valueOf((char)pair[i])).intValue();
/* 274 */         if ((cifra >= 0) && (cifra <= 9)) {
/* 275 */           pubKeySize = pubKeySize * 10 + cifra;
/*     */         }
/*     */       }
/*     */       catch (NumberFormatException e) {
/*     */         break;
/*     */       }
/*     */     }
/* 282 */     byte[] publicKeyData = new byte[pubKeySize];
/* 283 */     byte[] privateKeyData = new byte[pair.length - pubKeySize - 4];
/*     */     
/* 285 */     for (int i = 4; i < pubKeySize + 4; i++) {
/* 286 */       publicKeyData[(i - 4)] = pair[i];
/*     */     }
/* 288 */     for (int i = pubKeySize + 4; i < pair.length; i++) {
/* 289 */       privateKeyData[(i - (pubKeySize + 4))] = pair[i];
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 294 */       KeyFactory keyFactory = KeyFactory.getInstance("RSA", "BC");
/* 295 */       EncodedKeySpec privateKeySpec = new PKCS8EncodedKeySpec(privateKeyData);
/* 296 */       EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(publicKeyData);
/*     */       
/* 298 */       return new KeyPair(keyFactory.generatePublic(publicKeySpec), keyFactory.generatePrivate(privateKeySpec));
/*     */     } catch (NoSuchAlgorithmException e) {
/* 300 */       throw new SecurityException(e);
/*     */     } catch (InvalidKeySpecException e) {
/* 302 */       throw new SecurityException(e);
/*     */     } catch (NoSuchProviderException e) {
/* 304 */       throw new SecurityException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getUsedAlgorithmURI() {
/* 309 */     return this.ecCipher.getAlgorithm();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 316 */     String plain = "TextoEnClaro0123456789";
/* 317 */     EllipticCurveManager p = new EllipticCurveManager();
/*     */     
/* 319 */     System.out.println("Se solicita el cálculo de un nuevo par de claves asimétricas de 4096 bits");
/* 320 */     Long start = Long.valueOf(System.currentTimeMillis());
/* 321 */     String protectedPair = p.genNewECKeys("123456789012345678901234");
/* 322 */     KeyPair pair = p.unprotectKeyPair(protectedPair, "123456789012345678901234");
/* 323 */     Long time = Long.valueOf(System.currentTimeMillis() - start.longValue());
/* 324 */     System.out.println("Claves obtenidas. Tiempo consumido (ms): " + time + ". Comienzan las pruebas de encriptación...");
/*     */     
/* 326 */     System.out.println("Texto en claro: " + plain);
/* 327 */     String buffer = plain;
/* 328 */     char[] bufferChar = p.protectEC(buffer, pair.getPrivate());
/* 329 */     buffer = new String(bufferChar);
/* 330 */     System.out.println("Texto encriptado RSA con privada: " + buffer);
/* 331 */     buffer = new String(p.recoverEC(bufferChar, pair.getPublic()));
/* 332 */     System.out.println("Texto desencriptado RSA con pública: " + buffer);
/*     */     
/* 334 */     start = Long.valueOf(System.currentTimeMillis());
/* 335 */     buffer = es.mityc.crypto.Utils.obfuscate(new String(p.protectEC(buffer, pair.getPublic())));
/* 336 */     System.out.println("Encriptado RSA con pública y ofuscado: " + buffer);
/* 337 */     buffer = new String(p.recoverEC(es.mityc.crypto.Utils.undoObfuscate(buffer.getBytes()).toCharArray(), pair.getPrivate()));
/* 338 */     time = Long.valueOf(System.currentTimeMillis() - start.longValue());
/* 339 */     System.out.println("Texto recuperado con privada: " + buffer + "\nTiempo consumido (ms): " + time);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCrypt-1.1.7.jar!\es\mityc\crypto\asymetric\EllipticCurveManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */