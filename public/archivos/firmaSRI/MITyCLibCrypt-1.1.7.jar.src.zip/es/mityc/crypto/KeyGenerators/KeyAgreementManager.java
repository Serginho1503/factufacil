/*     */ package es.mityc.crypto.KeyGenerators;
/*     */ 
/*     */ import es.mityc.javasign.utils.Utils;
/*     */ import java.io.PrintStream;
/*     */ import java.math.BigInteger;
/*     */ import java.security.Key;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.KeyPair;
/*     */ import java.security.KeyPairGenerator;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.Security;
/*     */ import java.security.spec.ECFieldFp;
/*     */ import java.security.spec.ECParameterSpec;
/*     */ import java.security.spec.ECPoint;
/*     */ import java.security.spec.EllipticCurve;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.KeyAgreement;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.spec.DHParameterSpec;
/*     */ import javax.crypto.spec.DHPublicKeySpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyAgreementManager
/*     */ {
/*     */   public static final int pValue = 47;
/*     */   public static final int gValue = 71;
/*     */   
/*     */   public static void basicDiffieHellmanExample()
/*     */     throws Exception
/*     */   {
/*  51 */     int bitLength = 512;
/*  52 */     SecureRandom rnd = new SecureRandom();
/*  53 */     BigInteger p = BigInteger.probablePrime(bitLength, rnd);
/*  54 */     BigInteger g = BigInteger.probablePrime(bitLength, rnd);
/*  55 */     DHParameterSpec dhParams = new DHParameterSpec(p, g);
/*  56 */     KeyPairGenerator keyGen = KeyPairGenerator.getInstance("DH", "BC");
/*  57 */     keyGen.initialize(dhParams, new SecureRandom(rnd.generateSeed(8)));
/*     */     
/*     */ 
/*  60 */     KeyPair aPair = keyGen.generateKeyPair();
/*  61 */     KeyPair bPair = keyGen.generateKeyPair();
/*     */     
/*  63 */     KeyAgreement aKeyAgree = KeyAgreement.getInstance("DH", "BC");
/*  64 */     aKeyAgree.init(aPair.getPrivate());
/*  65 */     KeyAgreement bKeyAgree = KeyAgreement.getInstance("DH", "BC");
/*  66 */     bKeyAgree.init(bPair.getPrivate());
/*     */     
/*  68 */     aKeyAgree.doPhase(bPair.getPublic(), true);
/*  69 */     bKeyAgree.doPhase(aPair.getPublic(), true);
/*     */     
/*  71 */     BigInteger k1 = new BigInteger(aKeyAgree.generateSecret());
/*  72 */     BigInteger k2 = new BigInteger(bKeyAgree.generateSecret());
/*     */     
/*  74 */     if (!k1.equals(k2)) {
/*  75 */       System.out.println("Las claves generadas no coinciden!");
/*     */     } else {
/*  77 */       System.out.println("El secreto compartido coincide");
/*     */     }
/*     */     
/*  80 */     MessageDigest hash = MessageDigest.getInstance("SHA1", "BC");
/*  81 */     System.out.println(new String(hash.digest(aKeyAgree.generateSecret())));
/*  82 */     System.out.println(new String(hash.digest(bKeyAgree.generateSecret())));
/*     */   }
/*     */   
/*     */   public static void ellipticCurveKeyExchangeExample() throws Exception {
/*  86 */     int bitLength = 512;
/*  87 */     SecureRandom rnd = new SecureRandom();
/*  88 */     BigInteger p = BigInteger.probablePrime(bitLength, rnd);
/*  89 */     BigInteger g = BigInteger.probablePrime(bitLength, rnd);
/*     */     
/*  91 */     createSpecificKey(p, g);
/*     */     
/*     */ 
/*  94 */     KeyPairGenerator keyGen = KeyPairGenerator.getInstance("ECDH", "BC");
/*  95 */     EllipticCurve curve = new EllipticCurve(new ECFieldFp(new BigInteger(
/*  96 */       "fffffffffffffffffffffffffffffffeffffffffffffffff", 16)), new BigInteger(
/*  97 */       "fffffffffffffffffffffffffffffffefffffffffffffffc", 16), new BigInteger(
/*  98 */       "fffffffffffffffffffffffffffffffefffffffffffffffc", 16));
/*     */     
/* 100 */     ECParameterSpec ecSpec = new ECParameterSpec(curve, new ECPoint(new BigInteger(
/* 101 */       "fffffffffffffffffffffffffffffffefffffffffffffffc", 16), new BigInteger(
/* 102 */       "fffffffffffffffffffffffffffffffefffffffffffffffc", 16)), new BigInteger(
/* 103 */       "fffffffffffffffffffffffffffffffefffffffffffffffc", 16), 1);
/*     */     
/* 105 */     keyGen.initialize(ecSpec, new SecureRandom());
/*     */     
/* 107 */     KeyPair aPair = keyGen.generateKeyPair();
/* 108 */     KeyPair bPair = keyGen.generateKeyPair();
/*     */     
/* 110 */     KeyAgreement aKeyAgree = KeyAgreement.getInstance("ECDH", "BC");
/* 111 */     aKeyAgree.init(aPair.getPrivate());
/* 112 */     KeyAgreement bKeyAgree = KeyAgreement.getInstance("ECDH", "BC");
/* 113 */     bKeyAgree.init(bPair.getPrivate());
/*     */     
/* 115 */     aKeyAgree.doPhase(bPair.getPublic(), true);
/* 116 */     bKeyAgree.doPhase(aPair.getPublic(), true);
/*     */     
/* 118 */     MessageDigest hash = MessageDigest.getInstance("SHA1", "BC");
/*     */     
/* 120 */     BigInteger k1 = new BigInteger(aKeyAgree.generateSecret());
/* 121 */     BigInteger k2 = new BigInteger(bKeyAgree.generateSecret());
/*     */     
/* 123 */     if (!k1.equals(k2)) {
/* 124 */       System.out.println("Las claves generadas no coinciden!");
/*     */     } else {
/* 126 */       System.out.println("El secreto compartido coincide");
/*     */     }
/*     */     
/* 129 */     System.out.println(new String(hash.digest(aKeyAgree.generateSecret())));
/* 130 */     System.out.println(new String(hash.digest(bKeyAgree.generateSecret())));
/*     */   }
/*     */   
/*     */   public static void threeActorsKeyExchange()
/*     */     throws Exception
/*     */   {
/* 136 */     KeyPairGenerator keyGen = KeyPairGenerator.getInstance("DH", "BC");
/* 137 */     int bitLength = 512;
/* 138 */     SecureRandom rnd = new SecureRandom();
/* 139 */     BigInteger p = BigInteger.probablePrime(bitLength, rnd);
/* 140 */     BigInteger g = BigInteger.probablePrime(bitLength, rnd);
/* 141 */     DHParameterSpec spec = new DHParameterSpec(p, g);
/* 142 */     keyGen.initialize(spec);
/*     */     
/* 144 */     KeyPair aPair = keyGen.generateKeyPair();
/* 145 */     KeyPair bPair = keyGen.generateKeyPair();
/* 146 */     KeyPair cPair = keyGen.generateKeyPair();
/*     */     
/* 148 */     KeyAgreement aKeyAgree = KeyAgreement.getInstance("DH", "BC");
/* 149 */     aKeyAgree.init(aPair.getPrivate());
/* 150 */     KeyAgreement bKeyAgree = KeyAgreement.getInstance("DH", "BC");
/* 151 */     bKeyAgree.init(bPair.getPrivate());
/* 152 */     KeyAgreement cKeyAgree = KeyAgreement.getInstance("DH", "BC");
/* 153 */     cKeyAgree.init(cPair.getPrivate());
/*     */     
/* 155 */     Key ac = aKeyAgree.doPhase(cPair.getPublic(), false);
/* 156 */     Key ba = bKeyAgree.doPhase(aPair.getPublic(), false);
/* 157 */     Key cb = cKeyAgree.doPhase(bPair.getPublic(), false);
/*     */     
/* 159 */     aKeyAgree.doPhase(cb, true);
/* 160 */     bKeyAgree.doPhase(ac, true);
/* 161 */     cKeyAgree.doPhase(ba, true);
/*     */     
/* 163 */     BigInteger k1 = new BigInteger(aKeyAgree.generateSecret());
/* 164 */     BigInteger k2 = new BigInteger(bKeyAgree.generateSecret());
/* 165 */     BigInteger k3 = new BigInteger(cKeyAgree.generateSecret());
/*     */     
/* 167 */     if (!k1.equals(k2)) {
/* 168 */       System.out.println("Las claves a y b generadas no coinciden!");
/*     */     } else {
/* 170 */       System.out.println("El secreto compartido entre a y b coincide");
/*     */     }
/*     */     
/* 173 */     if (!k2.equals(k3)) {
/* 174 */       System.out.println("Las claves b y c generadas no coinciden!");
/*     */     } else {
/* 176 */       System.out.println("El secreto compartido entre b y c coincide");
/*     */     }
/*     */     
/* 179 */     MessageDigest hash = MessageDigest.getInstance("SHA1", "BC");
/*     */     
/*     */ 
/* 182 */     System.out.println(new String(hash.digest(aKeyAgree.generateSecret())));
/* 183 */     System.out.println(new String(hash.digest(bKeyAgree.generateSecret())));
/* 184 */     System.out.println(new String(hash.digest(cKeyAgree.generateSecret())));
/*     */     
/* 186 */     String plain = "TextoEnClaro123456789";
/* 187 */     SecretKey key = aKeyAgree.generateSecret("DESede");
/* 188 */     Cipher tripleDesCipher = Cipher.getInstance("DESede");
/*     */     
/* 190 */     tripleDesCipher.init(1, key);
/*     */     
/*     */ 
/* 193 */     byte[] ciphertext = tripleDesCipher.doFinal(plain.getBytes());
/*     */     
/*     */ 
/* 196 */     key = cKeyAgree.generateSecret("DESede");
/* 197 */     tripleDesCipher.init(2, key);
/*     */     
/*     */ 
/* 200 */     byte[] restored = tripleDesCipher.doFinal(ciphertext);
/*     */     
/* 202 */     System.out.println(new String(restored));
/*     */   }
/*     */   
/*     */   public static void main(String[] args) throws Exception {
/* 206 */     if (Security.getProvider("BC") == null) {
/* 207 */       Utils.addBCProvider();
/*     */     }
/*     */     
/* 210 */     basicDiffieHellmanExample();
/*     */     
/* 212 */     ellipticCurveKeyExchangeExample();
/*     */     
/* 214 */     threeActorsKeyExchange();
/*     */   }
/*     */   
/*     */   public static void createSpecificKey(BigInteger p, BigInteger g) throws Exception {
/* 218 */     KeyPairGenerator kpg = KeyPairGenerator.getInstance("DiffieHellman");
/*     */     
/* 220 */     if ((p != null) && (g != null)) {
/* 221 */       DHParameterSpec param = new DHParameterSpec(p, g);
/* 222 */       kpg.initialize(param);
/*     */     } else {
/* 224 */       kpg.initialize(512);
/*     */     }
/*     */     
/* 227 */     KeyPair kp = kpg.generateKeyPair();
/* 228 */     KeyFactory kfactory = KeyFactory.getInstance("DiffieHellman");
/*     */     
/* 230 */     DHPublicKeySpec kspec = (DHPublicKeySpec)kfactory.getKeySpec(kp.getPublic(), DHPublicKeySpec.class);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCrypt-1.1.7.jar!\es\mityc\crypto\KeyGenerators\KeyAgreementManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */