/*    */ package es.mityc.crypto.KeyGenerators;
/*    */ 
/*    */ import es.mityc.javasign.utils.Utils;
/*    */ import java.io.PrintStream;
/*    */ import java.security.Key;
/*    */ import java.security.KeyPair;
/*    */ import java.security.KeyPairGenerator;
/*    */ import java.security.SecureRandom;
/*    */ import java.security.Security;
/*    */ import javax.crypto.Cipher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ElGamalManager
/*    */ {
/*    */   public static void main(String[] args)
/*    */     throws Exception
/*    */   {
/* 36 */     if (Security.getProvider("BC") == null) {
/* 37 */       Utils.addBCProvider();
/*    */     }
/*    */     
/* 40 */     byte[] input = "textoEnClaroElGammal".getBytes();
/* 41 */     Cipher cipher = Cipher.getInstance("ElGamal/None/NoPadding", "BC");
/* 42 */     KeyPairGenerator generator = KeyPairGenerator.getInstance("ElGamal", "BC");
/* 43 */     SecureRandom random = new SecureRandom();
/*    */     
/* 45 */     generator.initialize(1024, random);
/*    */     
/* 47 */     KeyPair pair = generator.generateKeyPair();
/* 48 */     Key pubKey = pair.getPublic();
/* 49 */     Key privKey = pair.getPrivate();
/*    */     
/* 51 */     cipher.init(1, pubKey);
/* 52 */     byte[] cipherText = cipher.doFinal(input);
/* 53 */     System.out.println("cipher: " + new String(cipherText));
/*    */     
/* 55 */     cipher.init(2, privKey);
/* 56 */     byte[] plainText = cipher.doFinal(cipherText);
/* 57 */     System.out.println("plain : " + new String(plainText));
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCrypt-1.1.7.jar!\es\mityc\crypto\KeyGenerators\ElGamalManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */