/*     */ package es.mityc.crypto.steganography;
/*     */ 
/*     */ import es.mityc.crypto.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CabeceraLSB
/*     */ {
/*  33 */   protected static final byte[] SELLO = "STEGANOGRAFIADA".getBytes();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int ESPACIO_RESERVADO = 8;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  43 */   private int datosLength = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  48 */   private int bitsCanalUtilizados = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  53 */   private byte[] fileName = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  58 */   private StegoConfig config = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CabeceraLSB(int datosLength, int bitsUtilizados, String fileName, StegoConfig config)
/*     */   {
/*  68 */     this.datosLength = datosLength;
/*  69 */     this.bitsCanalUtilizados = bitsUtilizados;
/*  70 */     this.config = config;
/*     */     
/*  72 */     if (fileName == null) {
/*  73 */       this.fileName = "datos.bin".getBytes();
/*     */     } else {
/*     */       try {
/*  76 */         this.fileName = fileName.getBytes("UTF-8");
/*     */       } catch (Exception unEx) {
/*  78 */         this.fileName = fileName.getBytes();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CabeceraLSB() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getDatosCabecera(byte[] pass)
/*     */   {
/*  93 */     byte[] out = null;
/*  94 */     int stampLen = 0;
/*  95 */     int currIndex = 0;
/*     */     
/*  97 */     byte[] dataStamp = SELLO;
/*  98 */     byte[] finalFileName = this.fileName;
/*  99 */     if ((pass != null) && (pass.length > 0)) {
/* 100 */       dataStamp = Utils.obfuscate(new String(dataStamp), StegoUtils.hashPassLong(new String(pass))).getBytes();
/* 101 */       finalFileName = Utils.obfuscate(new String(this.fileName), StegoUtils.hashPassLong(new String(pass))).getBytes();
/*     */     }
/* 103 */     stampLen = SELLO.length;
/* 104 */     out = new byte[stampLen + 8 + finalFileName.length];
/*     */     
/* 106 */     System.arraycopy(dataStamp, 0, out, currIndex, stampLen);
/* 107 */     currIndex += stampLen;
/*     */     
/* 109 */     out[(currIndex++)] = ((byte)(this.datosLength & 0xFF));
/* 110 */     out[(currIndex++)] = ((byte)((this.datosLength & 0xFF00) >> 8));
/* 111 */     out[(currIndex++)] = ((byte)((this.datosLength & 0xFF0000) >> 16));
/* 112 */     out[(currIndex++)] = ((byte)((this.datosLength & 0xFF000000) >> 32));
/* 113 */     out[(currIndex++)] = ((byte)this.bitsCanalUtilizados);
/* 114 */     out[(currIndex++)] = ((byte)finalFileName.length);
/* 115 */     out[(currIndex++)] = ((byte)(this.config.isComprimir() ? 1 : 0));
/* 116 */     out[(currIndex++)] = ((byte)(this.config.isEncriptar() ? 1 : 0));
/*     */     
/* 118 */     if (finalFileName.length > 0) {
/* 119 */       System.arraycopy(finalFileName, 0, out, currIndex, finalFileName.length);
/* 120 */       currIndex += finalFileName.length;
/*     */     }
/*     */     
/* 123 */     return out;
/*     */   }
/*     */   
/*     */   public int getBitsUtilizados() {
/* 127 */     return this.bitsCanalUtilizados;
/*     */   }
/*     */   
/*     */   public void setBitsUtilizados(int bitsUtilizados) {
/* 131 */     this.bitsCanalUtilizados = bitsUtilizados;
/*     */   }
/*     */   
/*     */   public int getLongitudDatos() {
/* 135 */     return this.datosLength;
/*     */   }
/*     */   
/*     */   public String getFileName() {
/* 139 */     String name = null;
/*     */     try
/*     */     {
/* 142 */       name = new String(this.fileName, "UTF-8");
/*     */     } catch (Exception e) {
/* 144 */       name = new String(this.fileName);
/*     */     }
/*     */     
/* 147 */     return name;
/*     */   }
/*     */   
/*     */   public void setFileName(byte[] fileName) {
/* 151 */     this.fileName = fileName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLongitudCabecera()
/*     */   {
/* 159 */     return SELLO.length + 8 + this.fileName.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getLongMaxCabecera()
/*     */   {
/* 168 */     return SELLO.length + 8 + 256;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCrypt-1.1.7.jar!\es\mityc\crypto\steganography\CabeceraLSB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */