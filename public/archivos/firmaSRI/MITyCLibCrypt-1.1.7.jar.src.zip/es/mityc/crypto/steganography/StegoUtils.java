/*     */ package es.mityc.crypto.steganography;
/*     */ 
/*     */ import es.mityc.javasign.utils.Utils;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.GraphicsConfiguration;
/*     */ import java.awt.GraphicsDevice;
/*     */ import java.awt.GraphicsEnvironment;
/*     */ import java.awt.HeadlessException;
/*     */ import java.awt.Image;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.MemoryImageSource;
/*     */ import java.awt.image.PixelGrabber;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.security.MessageDigest;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Random;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import java.util.zip.GZIPOutputStream;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.InputSource;
/*     */ import sun.awt.image.ImageFormatException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StegoUtils
/*     */ {
/*  83 */   private static Log logger = LogFactory.getLog(StegoUtils.class);
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String RESTAURATION_NODE_NAME = "RestaurationData";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String REST_DIGEST_NODE_NAME = "RestDigestData";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] imageToByteArray(BufferedImage image, String formato)
/*     */     throws Exception
/*     */   {
/*  99 */     if (logger.isDebugEnabled()) {
/* 100 */       logger.debug("Convirtiendo imagen");
/* 101 */       logger.debug("Formato: " + formato);
/*     */     }
/* 103 */     ByteArrayOutputStream barrOS = new ByteArrayOutputStream();
/* 104 */     if (formato != null) {
/* 105 */       String imageType = formato.toLowerCase();
/* 106 */       if (imageType.equals("jp2"))
/* 107 */         imageType = "jpeg 2000";
/* 108 */       ImageIO.write(image, imageType, barrOS);
/*     */     } else {
/* 110 */       ImageIO.write(image, "png", barrOS);
/*     */     }
/*     */     
/* 113 */     barrOS.close();
/* 114 */     return barrOS.toByteArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BufferedImage byteArrayToImage(byte[] imageData)
/*     */     throws Exception
/*     */   {
/* 125 */     BufferedImage image = null;
/* 126 */     if (imageData == null) {
/* 127 */       return null;
/*     */     }
/* 129 */     image = ImageIO.read(new ByteArrayInputStream(imageData));
/* 130 */     if (image == null) {
/* 131 */       throw new Exception("La imagen no se puede leer");
/*     */     }
/* 133 */     return image;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int byteToInt(int b)
/*     */   {
/* 142 */     int i = b;
/* 143 */     if (i < 0)
/* 144 */       i += 256;
/* 145 */     return i;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public static void appendRestaurationDataToXML(char[] data, File xml)
/*     */     throws Exception
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_2
/*     */     //   2: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   5: invokeinterface 38 1 0
/*     */     //   10: ifeq +67 -> 77
/*     */     //   13: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   16: new 50	java/lang/StringBuilder
/*     */     //   19: dup
/*     */     //   20: ldc -128
/*     */     //   22: invokespecial 54	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   25: aload_1
/*     */     //   26: invokevirtual 130	java/io/File:getAbsolutePath	()Ljava/lang/String;
/*     */     //   29: invokevirtual 57	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   32: invokevirtual 61	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   35: invokeinterface 46 2 0
/*     */     //   40: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   43: new 50	java/lang/StringBuilder
/*     */     //   46: dup
/*     */     //   47: ldc -121
/*     */     //   49: invokespecial 54	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   52: aload_0
/*     */     //   53: ifnull +11 -> 64
/*     */     //   56: aload_0
/*     */     //   57: arraylength
/*     */     //   58: invokestatic 137	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
/*     */     //   61: goto +5 -> 66
/*     */     //   64: ldc -113
/*     */     //   66: invokevirtual 145	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   69: invokevirtual 61	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   72: invokeinterface 46 2 0
/*     */     //   77: new 148	java/io/FileInputStream
/*     */     //   80: dup
/*     */     //   81: aload_1
/*     */     //   82: invokespecial 150	java/io/FileInputStream:<init>	(Ljava/io/File;)V
/*     */     //   85: astore_2
/*     */     //   86: aload_2
/*     */     //   87: invokestatic 153	es/mityc/crypto/steganography/StegoUtils:getDocument	(Ljava/io/FileInputStream;)Lorg/w3c/dom/Document;
/*     */     //   90: astore_3
/*     */     //   91: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   94: invokeinterface 38 1 0
/*     */     //   99: ifeq +13 -> 112
/*     */     //   102: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   105: ldc -99
/*     */     //   107: invokeinterface 46 2 0
/*     */     //   112: aload_3
/*     */     //   113: ldc 10
/*     */     //   115: invokeinterface 159 2 0
/*     */     //   120: astore 4
/*     */     //   122: aconst_null
/*     */     //   123: astore 5
/*     */     //   125: aload_0
/*     */     //   126: ifnonnull +10 -> 136
/*     */     //   129: ldc -91
/*     */     //   131: astore 5
/*     */     //   133: goto +42 -> 175
/*     */     //   136: aload_0
/*     */     //   137: arraylength
/*     */     //   138: invokestatic 167	java/lang/String:valueOf	(I)Ljava/lang/String;
/*     */     //   141: astore 5
/*     */     //   143: goto +22 -> 165
/*     */     //   146: new 50	java/lang/StringBuilder
/*     */     //   149: dup
/*     */     //   150: ldc -86
/*     */     //   152: invokespecial 54	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   155: aload 5
/*     */     //   157: invokevirtual 57	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   160: invokevirtual 61	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   163: astore 5
/*     */     //   165: aload 5
/*     */     //   167: invokevirtual 172	java/lang/String:length	()I
/*     */     //   170: bipush 6
/*     */     //   172: if_icmplt -26 -> 146
/*     */     //   175: aload 4
/*     */     //   177: aload_3
/*     */     //   178: aload 5
/*     */     //   180: invokeinterface 176 2 0
/*     */     //   185: invokeinterface 180 2 0
/*     */     //   190: pop
/*     */     //   191: aload_3
/*     */     //   192: invokeinterface 186 1 0
/*     */     //   197: ldc 10
/*     */     //   199: invokeinterface 190 2 0
/*     */     //   204: astore 6
/*     */     //   206: aload 6
/*     */     //   208: ifnull +33 -> 241
/*     */     //   211: aload 6
/*     */     //   213: invokeinterface 194 1 0
/*     */     //   218: ifle +23 -> 241
/*     */     //   221: aload_3
/*     */     //   222: invokeinterface 186 1 0
/*     */     //   227: aload 6
/*     */     //   229: iconst_0
/*     */     //   230: invokeinterface 199 2 0
/*     */     //   235: invokeinterface 203 2 0
/*     */     //   240: pop
/*     */     //   241: aload_3
/*     */     //   242: invokeinterface 186 1 0
/*     */     //   247: aload 4
/*     */     //   249: invokeinterface 180 2 0
/*     */     //   254: pop
/*     */     //   255: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   258: invokeinterface 38 1 0
/*     */     //   263: ifeq +13 -> 276
/*     */     //   266: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   269: ldc -50
/*     */     //   271: invokeinterface 46 2 0
/*     */     //   276: aload_3
/*     */     //   277: ldc 13
/*     */     //   279: invokeinterface 159 2 0
/*     */     //   284: astore 7
/*     */     //   286: aload_0
/*     */     //   287: ifnonnull +10 -> 297
/*     */     //   290: ldc -48
/*     */     //   292: astore 5
/*     */     //   294: goto +74 -> 368
/*     */     //   297: aload_0
/*     */     //   298: arraylength
/*     */     //   299: newarray <illegal type>
/*     */     //   301: astore 8
/*     */     //   303: iconst_0
/*     */     //   304: istore 9
/*     */     //   306: goto +16 -> 322
/*     */     //   309: aload 8
/*     */     //   311: iload 9
/*     */     //   313: aload_0
/*     */     //   314: iload 9
/*     */     //   316: caload
/*     */     //   317: i2b
/*     */     //   318: bastore
/*     */     //   319: iinc 9 1
/*     */     //   322: iload 9
/*     */     //   324: aload_0
/*     */     //   325: arraylength
/*     */     //   326: if_icmplt -17 -> 309
/*     */     //   329: ldc -46
/*     */     //   331: invokestatic 212	java/security/MessageDigest:getInstance	(Ljava/lang/String;)Ljava/security/MessageDigest;
/*     */     //   334: astore 9
/*     */     //   336: aload 9
/*     */     //   338: aload 8
/*     */     //   340: invokevirtual 218	java/security/MessageDigest:update	([B)V
/*     */     //   343: aload 9
/*     */     //   345: invokevirtual 221	java/security/MessageDigest:digest	()[B
/*     */     //   348: astore 10
/*     */     //   350: aload 10
/*     */     //   352: invokestatic 224	es/mityc/javasign/utils/Base64Coder:encode	([B)[C
/*     */     //   355: astore 11
/*     */     //   357: new 69	java/lang/String
/*     */     //   360: dup
/*     */     //   361: aload 11
/*     */     //   363: invokespecial 230	java/lang/String:<init>	([C)V
/*     */     //   366: astore 5
/*     */     //   368: aload 7
/*     */     //   370: aload_3
/*     */     //   371: aload 5
/*     */     //   373: invokeinterface 176 2 0
/*     */     //   378: invokeinterface 180 2 0
/*     */     //   383: pop
/*     */     //   384: aload_3
/*     */     //   385: invokeinterface 186 1 0
/*     */     //   390: ldc 13
/*     */     //   392: invokeinterface 190 2 0
/*     */     //   397: astore 6
/*     */     //   399: aload 6
/*     */     //   401: ifnull +33 -> 434
/*     */     //   404: aload 6
/*     */     //   406: invokeinterface 194 1 0
/*     */     //   411: ifle +23 -> 434
/*     */     //   414: aload_3
/*     */     //   415: invokeinterface 186 1 0
/*     */     //   420: aload 6
/*     */     //   422: iconst_0
/*     */     //   423: invokeinterface 199 2 0
/*     */     //   428: invokeinterface 203 2 0
/*     */     //   433: pop
/*     */     //   434: aload_3
/*     */     //   435: invokeinterface 186 1 0
/*     */     //   440: aload 7
/*     */     //   442: invokeinterface 180 2 0
/*     */     //   447: pop
/*     */     //   448: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   451: invokeinterface 38 1 0
/*     */     //   456: ifeq +13 -> 469
/*     */     //   459: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   462: ldc -23
/*     */     //   464: invokeinterface 46 2 0
/*     */     //   469: new 235	java/io/FileOutputStream
/*     */     //   472: dup
/*     */     //   473: aload_1
/*     */     //   474: invokespecial 237	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
/*     */     //   477: astore 8
/*     */     //   479: new 238	java/io/OutputStreamWriter
/*     */     //   482: dup
/*     */     //   483: aload 8
/*     */     //   485: ldc -16
/*     */     //   487: invokespecial 242	java/io/OutputStreamWriter:<init>	(Ljava/io/OutputStream;Ljava/lang/String;)V
/*     */     //   490: astore 9
/*     */     //   492: invokestatic 245	javax/xml/transform/TransformerFactory:newInstance	()Ljavax/xml/transform/TransformerFactory;
/*     */     //   495: invokevirtual 251	javax/xml/transform/TransformerFactory:newTransformer	()Ljavax/xml/transform/Transformer;
/*     */     //   498: astore 10
/*     */     //   500: new 255	java/util/Properties
/*     */     //   503: dup
/*     */     //   504: invokespecial 257	java/util/Properties:<init>	()V
/*     */     //   507: astore 11
/*     */     //   509: aload 11
/*     */     //   511: ldc_w 258
/*     */     //   514: ldc_w 260
/*     */     //   517: invokevirtual 262	java/util/Properties:setProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;
/*     */     //   520: pop
/*     */     //   521: aload 11
/*     */     //   523: ldc_w 266
/*     */     //   526: ldc -16
/*     */     //   528: invokevirtual 262	java/util/Properties:setProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;
/*     */     //   531: pop
/*     */     //   532: aload 11
/*     */     //   534: ldc_w 268
/*     */     //   537: ldc_w 270
/*     */     //   540: invokevirtual 262	java/util/Properties:setProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;
/*     */     //   543: pop
/*     */     //   544: aload 10
/*     */     //   546: aload 11
/*     */     //   548: invokevirtual 272	javax/xml/transform/Transformer:setOutputProperties	(Ljava/util/Properties;)V
/*     */     //   551: new 278	java/io/StringWriter
/*     */     //   554: dup
/*     */     //   555: invokespecial 280	java/io/StringWriter:<init>	()V
/*     */     //   558: astore 12
/*     */     //   560: aload 10
/*     */     //   562: new 281	javax/xml/transform/dom/DOMSource
/*     */     //   565: dup
/*     */     //   566: aload_3
/*     */     //   567: invokespecial 283	javax/xml/transform/dom/DOMSource:<init>	(Lorg/w3c/dom/Node;)V
/*     */     //   570: new 286	javax/xml/transform/stream/StreamResult
/*     */     //   573: dup
/*     */     //   574: aload 12
/*     */     //   576: invokespecial 288	javax/xml/transform/stream/StreamResult:<init>	(Ljava/io/Writer;)V
/*     */     //   579: invokevirtual 291	javax/xml/transform/Transformer:transform	(Ljavax/xml/transform/Source;Ljavax/xml/transform/Result;)V
/*     */     //   582: aload 9
/*     */     //   584: aload 12
/*     */     //   586: invokevirtual 295	java/io/StringWriter:toString	()Ljava/lang/String;
/*     */     //   589: invokevirtual 296	java/io/Writer:write	(Ljava/lang/String;)V
/*     */     //   592: aload 9
/*     */     //   594: invokevirtual 300	java/io/Writer:flush	()V
/*     */     //   597: aload 9
/*     */     //   599: invokevirtual 303	java/io/Writer:close	()V
/*     */     //   602: goto +21 -> 623
/*     */     //   605: astore 13
/*     */     //   607: aload_2
/*     */     //   608: ifnull +12 -> 620
/*     */     //   611: aload_2
/*     */     //   612: invokevirtual 304	java/io/FileInputStream:close	()V
/*     */     //   615: goto +5 -> 620
/*     */     //   618: astore 14
/*     */     //   620: aload 13
/*     */     //   622: athrow
/*     */     //   623: aload_2
/*     */     //   624: ifnull +12 -> 636
/*     */     //   627: aload_2
/*     */     //   628: invokevirtual 304	java/io/FileInputStream:close	()V
/*     */     //   631: goto +5 -> 636
/*     */     //   634: astore 14
/*     */     //   636: return
/*     */     // Line number table:
/*     */     //   Java source line #155	-> byte code offset #0
/*     */     //   Java source line #157	-> byte code offset #2
/*     */     //   Java source line #158	-> byte code offset #13
/*     */     //   Java source line #159	-> byte code offset #40
/*     */     //   Java source line #161	-> byte code offset #77
/*     */     //   Java source line #162	-> byte code offset #86
/*     */     //   Java source line #164	-> byte code offset #91
/*     */     //   Java source line #165	-> byte code offset #102
/*     */     //   Java source line #167	-> byte code offset #112
/*     */     //   Java source line #168	-> byte code offset #122
/*     */     //   Java source line #169	-> byte code offset #125
/*     */     //   Java source line #170	-> byte code offset #129
/*     */     //   Java source line #171	-> byte code offset #133
/*     */     //   Java source line #172	-> byte code offset #136
/*     */     //   Java source line #173	-> byte code offset #143
/*     */     //   Java source line #174	-> byte code offset #146
/*     */     //   Java source line #173	-> byte code offset #165
/*     */     //   Java source line #177	-> byte code offset #175
/*     */     //   Java source line #178	-> byte code offset #191
/*     */     //   Java source line #179	-> byte code offset #206
/*     */     //   Java source line #180	-> byte code offset #221
/*     */     //   Java source line #182	-> byte code offset #241
/*     */     //   Java source line #184	-> byte code offset #255
/*     */     //   Java source line #185	-> byte code offset #266
/*     */     //   Java source line #187	-> byte code offset #276
/*     */     //   Java source line #188	-> byte code offset #286
/*     */     //   Java source line #189	-> byte code offset #290
/*     */     //   Java source line #190	-> byte code offset #294
/*     */     //   Java source line #191	-> byte code offset #297
/*     */     //   Java source line #192	-> byte code offset #303
/*     */     //   Java source line #193	-> byte code offset #309
/*     */     //   Java source line #192	-> byte code offset #319
/*     */     //   Java source line #195	-> byte code offset #329
/*     */     //   Java source line #196	-> byte code offset #336
/*     */     //   Java source line #197	-> byte code offset #343
/*     */     //   Java source line #198	-> byte code offset #350
/*     */     //   Java source line #199	-> byte code offset #357
/*     */     //   Java source line #202	-> byte code offset #368
/*     */     //   Java source line #203	-> byte code offset #384
/*     */     //   Java source line #204	-> byte code offset #399
/*     */     //   Java source line #205	-> byte code offset #414
/*     */     //   Java source line #207	-> byte code offset #434
/*     */     //   Java source line #209	-> byte code offset #448
/*     */     //   Java source line #210	-> byte code offset #459
/*     */     //   Java source line #212	-> byte code offset #469
/*     */     //   Java source line #214	-> byte code offset #479
/*     */     //   Java source line #216	-> byte code offset #492
/*     */     //   Java source line #217	-> byte code offset #500
/*     */     //   Java source line #218	-> byte code offset #509
/*     */     //   Java source line #219	-> byte code offset #521
/*     */     //   Java source line #220	-> byte code offset #532
/*     */     //   Java source line #221	-> byte code offset #544
/*     */     //   Java source line #223	-> byte code offset #551
/*     */     //   Java source line #224	-> byte code offset #560
/*     */     //   Java source line #225	-> byte code offset #582
/*     */     //   Java source line #226	-> byte code offset #592
/*     */     //   Java source line #227	-> byte code offset #597
/*     */     //   Java source line #228	-> byte code offset #602
/*     */     //   Java source line #229	-> byte code offset #607
/*     */     //   Java source line #230	-> byte code offset #611
/*     */     //   Java source line #232	-> byte code offset #620
/*     */     //   Java source line #229	-> byte code offset #623
/*     */     //   Java source line #230	-> byte code offset #627
/*     */     //   Java source line #233	-> byte code offset #636
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	637	0	data	char[]
/*     */     //   0	637	1	xml	File
/*     */     //   1	627	2	fis	FileInputStream
/*     */     //   90	477	3	doc	Document
/*     */     //   120	128	4	restaurationDataElement	Element
/*     */     //   123	249	5	text	String
/*     */     //   204	217	6	prevData	NodeList
/*     */     //   284	157	7	restDigestDataElement	Element
/*     */     //   301	38	8	buffer	byte[]
/*     */     //   477	7	8	f	FileOutputStream
/*     */     //   304	19	9	i	int
/*     */     //   334	10	9	md	MessageDigest
/*     */     //   490	108	9	out	java.io.Writer
/*     */     //   348	3	10	a	byte[]
/*     */     //   498	63	10	xformer	javax.xml.transform.Transformer
/*     */     //   355	7	11	r	char[]
/*     */     //   507	40	11	props	java.util.Properties
/*     */     //   558	27	12	salida	java.io.StringWriter
/*     */     //   605	16	13	localObject	Object
/*     */     //   618	1	14	localIOException	IOException
/*     */     //   634	1	14	localIOException1	IOException
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   2	605	605	finally
/*     */     //   611	615	618	java/io/IOException
/*     */     //   627	631	634	java/io/IOException
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public static void appendRestaurationDataToImage(char[] data, File image)
/*     */     throws Exception
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_2
/*     */     //   2: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   5: invokeinterface 38 1 0
/*     */     //   10: ifeq +57 -> 67
/*     */     //   13: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   16: new 50	java/lang/StringBuilder
/*     */     //   19: dup
/*     */     //   20: ldc_w 343
/*     */     //   23: invokespecial 54	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   26: aload_1
/*     */     //   27: invokevirtual 130	java/io/File:getAbsolutePath	()Ljava/lang/String;
/*     */     //   30: invokevirtual 57	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   33: invokevirtual 61	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   36: invokeinterface 46 2 0
/*     */     //   41: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   44: new 50	java/lang/StringBuilder
/*     */     //   47: dup
/*     */     //   48: ldc_w 345
/*     */     //   51: invokespecial 54	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   54: aload_0
/*     */     //   55: arraylength
/*     */     //   56: invokevirtual 347	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*     */     //   59: invokevirtual 61	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   62: invokeinterface 46 2 0
/*     */     //   67: new 350	java/io/FileWriter
/*     */     //   70: dup
/*     */     //   71: aload_1
/*     */     //   72: iconst_1
/*     */     //   73: invokespecial 352	java/io/FileWriter:<init>	(Ljava/io/File;Z)V
/*     */     //   76: astore_2
/*     */     //   77: aload_2
/*     */     //   78: new 69	java/lang/String
/*     */     //   81: dup
/*     */     //   82: aload_0
/*     */     //   83: invokespecial 230	java/lang/String:<init>	([C)V
/*     */     //   86: invokevirtual 355	java/io/FileWriter:append	(Ljava/lang/CharSequence;)Ljava/io/Writer;
/*     */     //   89: pop
/*     */     //   90: aload_2
/*     */     //   91: invokevirtual 358	java/io/FileWriter:flush	()V
/*     */     //   94: goto +19 -> 113
/*     */     //   97: astore_3
/*     */     //   98: aload_2
/*     */     //   99: ifnull +12 -> 111
/*     */     //   102: aload_2
/*     */     //   103: invokevirtual 359	java/io/FileWriter:close	()V
/*     */     //   106: goto +5 -> 111
/*     */     //   109: astore 4
/*     */     //   111: aload_3
/*     */     //   112: athrow
/*     */     //   113: aload_2
/*     */     //   114: ifnull +12 -> 126
/*     */     //   117: aload_2
/*     */     //   118: invokevirtual 359	java/io/FileWriter:close	()V
/*     */     //   121: goto +5 -> 126
/*     */     //   124: astore 4
/*     */     //   126: return
/*     */     // Line number table:
/*     */     //   Java source line #242	-> byte code offset #0
/*     */     //   Java source line #244	-> byte code offset #2
/*     */     //   Java source line #245	-> byte code offset #13
/*     */     //   Java source line #246	-> byte code offset #41
/*     */     //   Java source line #248	-> byte code offset #67
/*     */     //   Java source line #249	-> byte code offset #77
/*     */     //   Java source line #250	-> byte code offset #90
/*     */     //   Java source line #251	-> byte code offset #94
/*     */     //   Java source line #252	-> byte code offset #98
/*     */     //   Java source line #253	-> byte code offset #102
/*     */     //   Java source line #255	-> byte code offset #111
/*     */     //   Java source line #252	-> byte code offset #113
/*     */     //   Java source line #253	-> byte code offset #117
/*     */     //   Java source line #256	-> byte code offset #126
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	127	0	data	char[]
/*     */     //   0	127	1	image	File
/*     */     //   1	117	2	fw	java.io.FileWriter
/*     */     //   97	15	3	localObject	Object
/*     */     //   109	1	4	localIOException	IOException
/*     */     //   124	1	4	localIOException1	IOException
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   2	97	97	finally
/*     */     //   102	106	109	java/io/IOException
/*     */     //   117	121	124	java/io/IOException
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public static void deleteRestaurationDataInImage(File image, int pos)
/*     */     throws Exception
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_2
/*     */     //   2: aconst_null
/*     */     //   3: astore_3
/*     */     //   4: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   7: invokeinterface 38 1 0
/*     */     //   12: ifeq +56 -> 68
/*     */     //   15: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   18: new 50	java/lang/StringBuilder
/*     */     //   21: dup
/*     */     //   22: ldc_w 364
/*     */     //   25: invokespecial 54	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   28: aload_0
/*     */     //   29: invokevirtual 130	java/io/File:getAbsolutePath	()Ljava/lang/String;
/*     */     //   32: invokevirtual 57	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   35: invokevirtual 61	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   38: invokeinterface 46 2 0
/*     */     //   43: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   46: new 50	java/lang/StringBuilder
/*     */     //   49: dup
/*     */     //   50: ldc_w 366
/*     */     //   53: invokespecial 54	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   56: iload_1
/*     */     //   57: invokevirtual 347	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*     */     //   60: invokevirtual 61	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   63: invokeinterface 46 2 0
/*     */     //   68: new 148	java/io/FileInputStream
/*     */     //   71: dup
/*     */     //   72: aload_0
/*     */     //   73: invokespecial 150	java/io/FileInputStream:<init>	(Ljava/io/File;)V
/*     */     //   76: astore_2
/*     */     //   77: aload_2
/*     */     //   78: invokevirtual 368	java/io/FileInputStream:available	()I
/*     */     //   81: istore 4
/*     */     //   83: new 65	java/io/ByteArrayOutputStream
/*     */     //   86: dup
/*     */     //   87: invokespecial 67	java/io/ByteArrayOutputStream:<init>	()V
/*     */     //   90: astore_3
/*     */     //   91: iconst_0
/*     */     //   92: istore 5
/*     */     //   94: sipush 1024
/*     */     //   97: newarray <illegal type>
/*     */     //   99: astore 6
/*     */     //   101: goto +12 -> 113
/*     */     //   104: aload_3
/*     */     //   105: aload 6
/*     */     //   107: iconst_0
/*     */     //   108: iload 5
/*     */     //   110: invokevirtual 371	java/io/ByteArrayOutputStream:write	([BII)V
/*     */     //   113: aload_2
/*     */     //   114: aload 6
/*     */     //   116: iconst_0
/*     */     //   117: sipush 1024
/*     */     //   120: invokevirtual 374	java/io/FileInputStream:read	([BII)I
/*     */     //   123: dup
/*     */     //   124: istore 5
/*     */     //   126: ifge -22 -> 104
/*     */     //   129: aload_2
/*     */     //   130: invokevirtual 304	java/io/FileInputStream:close	()V
/*     */     //   133: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   136: invokeinterface 38 1 0
/*     */     //   141: ifeq +14 -> 155
/*     */     //   144: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   147: ldc_w 377
/*     */     //   150: invokeinterface 46 2 0
/*     */     //   155: new 235	java/io/FileOutputStream
/*     */     //   158: dup
/*     */     //   159: aload_0
/*     */     //   160: invokespecial 237	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
/*     */     //   163: astore 7
/*     */     //   165: new 379	java/io/BufferedOutputStream
/*     */     //   168: dup
/*     */     //   169: aload 7
/*     */     //   171: invokespecial 381	java/io/BufferedOutputStream:<init>	(Ljava/io/OutputStream;)V
/*     */     //   174: astore 8
/*     */     //   176: aload 8
/*     */     //   178: aload_3
/*     */     //   179: invokevirtual 92	java/io/ByteArrayOutputStream:toByteArray	()[B
/*     */     //   182: iconst_0
/*     */     //   183: iload 4
/*     */     //   185: iload_1
/*     */     //   186: isub
/*     */     //   187: invokevirtual 384	java/io/BufferedOutputStream:write	([BII)V
/*     */     //   190: aload 8
/*     */     //   192: invokevirtual 385	java/io/BufferedOutputStream:close	()V
/*     */     //   195: goto +34 -> 229
/*     */     //   198: astore 9
/*     */     //   200: aload_2
/*     */     //   201: ifnull +12 -> 213
/*     */     //   204: aload_2
/*     */     //   205: invokevirtual 304	java/io/FileInputStream:close	()V
/*     */     //   208: goto +5 -> 213
/*     */     //   211: astore 10
/*     */     //   213: aload_3
/*     */     //   214: ifnull +12 -> 226
/*     */     //   217: aload_3
/*     */     //   218: invokevirtual 89	java/io/ByteArrayOutputStream:close	()V
/*     */     //   221: goto +5 -> 226
/*     */     //   224: astore 10
/*     */     //   226: aload 9
/*     */     //   228: athrow
/*     */     //   229: aload_2
/*     */     //   230: ifnull +12 -> 242
/*     */     //   233: aload_2
/*     */     //   234: invokevirtual 304	java/io/FileInputStream:close	()V
/*     */     //   237: goto +5 -> 242
/*     */     //   240: astore 10
/*     */     //   242: aload_3
/*     */     //   243: ifnull +12 -> 255
/*     */     //   246: aload_3
/*     */     //   247: invokevirtual 89	java/io/ByteArrayOutputStream:close	()V
/*     */     //   250: goto +5 -> 255
/*     */     //   253: astore 10
/*     */     //   255: return
/*     */     // Line number table:
/*     */     //   Java source line #265	-> byte code offset #0
/*     */     //   Java source line #266	-> byte code offset #2
/*     */     //   Java source line #268	-> byte code offset #4
/*     */     //   Java source line #269	-> byte code offset #15
/*     */     //   Java source line #270	-> byte code offset #43
/*     */     //   Java source line #272	-> byte code offset #68
/*     */     //   Java source line #273	-> byte code offset #77
/*     */     //   Java source line #274	-> byte code offset #83
/*     */     //   Java source line #275	-> byte code offset #91
/*     */     //   Java source line #276	-> byte code offset #94
/*     */     //   Java source line #277	-> byte code offset #101
/*     */     //   Java source line #278	-> byte code offset #104
/*     */     //   Java source line #277	-> byte code offset #113
/*     */     //   Java source line #280	-> byte code offset #129
/*     */     //   Java source line #281	-> byte code offset #133
/*     */     //   Java source line #282	-> byte code offset #144
/*     */     //   Java source line #284	-> byte code offset #155
/*     */     //   Java source line #285	-> byte code offset #165
/*     */     //   Java source line #286	-> byte code offset #176
/*     */     //   Java source line #287	-> byte code offset #190
/*     */     //   Java source line #288	-> byte code offset #195
/*     */     //   Java source line #289	-> byte code offset #200
/*     */     //   Java source line #290	-> byte code offset #204
/*     */     //   Java source line #292	-> byte code offset #213
/*     */     //   Java source line #293	-> byte code offset #217
/*     */     //   Java source line #295	-> byte code offset #226
/*     */     //   Java source line #289	-> byte code offset #229
/*     */     //   Java source line #290	-> byte code offset #233
/*     */     //   Java source line #292	-> byte code offset #242
/*     */     //   Java source line #293	-> byte code offset #246
/*     */     //   Java source line #296	-> byte code offset #255
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	256	0	image	File
/*     */     //   0	256	1	pos	int
/*     */     //   1	233	2	fis	FileInputStream
/*     */     //   3	244	3	baosLeido	ByteArrayOutputStream
/*     */     //   81	103	4	imgLenght	int
/*     */     //   92	33	5	bytesRead	int
/*     */     //   99	16	6	buffer	byte[]
/*     */     //   163	7	7	fileOutput	FileOutputStream
/*     */     //   174	17	8	bufferedOutput	BufferedOutputStream
/*     */     //   198	29	9	localObject	Object
/*     */     //   211	1	10	localIOException	IOException
/*     */     //   224	1	10	localIOException1	IOException
/*     */     //   240	1	10	localIOException2	IOException
/*     */     //   253	1	10	localIOException3	IOException
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   4	198	198	finally
/*     */     //   204	208	211	java/io/IOException
/*     */     //   217	221	224	java/io/IOException
/*     */     //   233	237	240	java/io/IOException
/*     */     //   246	250	253	java/io/IOException
/*     */   }
/*     */   
/*     */   public static byte[] readRestaurationDataFromImage(File img, int pos, byte[] digest)
/*     */     throws Exception
/*     */   {
/* 306 */     ByteArrayOutputStream baosLeido = null;
/*     */     try {
/* 308 */       if (logger.isDebugEnabled()) {
/* 309 */         logger.debug("Extrayendo datos de la imagen: " + img.getAbsolutePath());
/* 310 */         logger.debug("Posición: " + pos);
/*     */       }
/* 312 */       baosLeido = new ByteArrayOutputStream();
/*     */       
/* 314 */       if (pos > 0) {
/* 315 */         if (logger.isDebugEnabled()) {
/* 316 */           logger.debug("Leyendo imagen");
/*     */         }
/* 318 */         FileInputStream fisImg = new FileInputStream(img);
/* 319 */         int imgLenght = fisImg.available();
/* 320 */         int bytesRead = 0;
/* 321 */         byte[] buffer = new byte['Ѐ'];
/* 322 */         while ((bytesRead = fisImg.read(buffer, 0, 1024)) >= 0) {
/* 323 */           baosLeido.write(buffer, 0, bytesRead);
/*     */         }
/*     */         
/* 326 */         int from = imgLenght - pos;
/*     */         
/* 328 */         byte[] data = Arrays.copyOfRange(baosLeido.toByteArray(), from, imgLenght);
/* 329 */         if (logger.isDebugEnabled()) {
/* 330 */           logger.debug("Datos extraídos. Comprobando la integridad...");
/*     */         }
/* 332 */         if (digest != null) {
/* 333 */           MessageDigest md = MessageDigest.getInstance("SHA-256");
/* 334 */           md.update(data);
/* 335 */           byte[] a = md.digest();
/*     */           
/* 337 */           if (Arrays.equals(digest, a)) {
/* 338 */             if (logger.isDebugEnabled()) {
/* 339 */               logger.debug("Dátos validos");
/*     */             }
/* 341 */             return data;
/*     */           }
/* 343 */           logger.debug("Los datos no superaron la validación de Digest");
/* 344 */           return null;
/*     */         }
/* 346 */         logger.error("Digest indicado nulo");
/* 347 */         return null;
/*     */       }
/* 349 */       logger.error("Posición indicada nula");
/* 350 */       return null;
/*     */     }
/*     */     finally {
/* 353 */       if (baosLeido != null) {
/* 354 */         try { baosLeido.close();
/*     */         }
/*     */         catch (IOException localIOException4) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public static ArrayList<Object> getRestaurationDataFromXML(File xml)
/*     */     throws Exception
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 428	java/util/ArrayList
/*     */     //   3: dup
/*     */     //   4: iconst_3
/*     */     //   5: invokespecial 430	java/util/ArrayList:<init>	(I)V
/*     */     //   8: astore_1
/*     */     //   9: aconst_null
/*     */     //   10: astore_2
/*     */     //   11: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   14: invokeinterface 38 1 0
/*     */     //   19: ifeq +31 -> 50
/*     */     //   22: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   25: new 50	java/lang/StringBuilder
/*     */     //   28: dup
/*     */     //   29: ldc_w 433
/*     */     //   32: invokespecial 54	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   35: aload_0
/*     */     //   36: invokevirtual 130	java/io/File:getAbsolutePath	()Ljava/lang/String;
/*     */     //   39: invokevirtual 57	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   42: invokevirtual 61	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   45: invokeinterface 46 2 0
/*     */     //   50: new 148	java/io/FileInputStream
/*     */     //   53: dup
/*     */     //   54: aload_0
/*     */     //   55: invokespecial 150	java/io/FileInputStream:<init>	(Ljava/io/File;)V
/*     */     //   58: astore_2
/*     */     //   59: aload_2
/*     */     //   60: invokestatic 153	es/mityc/crypto/steganography/StegoUtils:getDocument	(Ljava/io/FileInputStream;)Lorg/w3c/dom/Document;
/*     */     //   63: astore_3
/*     */     //   64: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   67: invokeinterface 38 1 0
/*     */     //   72: ifeq +14 -> 86
/*     */     //   75: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   78: ldc_w 435
/*     */     //   81: invokeinterface 46 2 0
/*     */     //   86: aload_3
/*     */     //   87: ldc 10
/*     */     //   89: invokeinterface 437 2 0
/*     */     //   94: astore 4
/*     */     //   96: aload 4
/*     */     //   98: ifnull +40 -> 138
/*     */     //   101: aload 4
/*     */     //   103: invokeinterface 194 1 0
/*     */     //   108: ifle +30 -> 138
/*     */     //   111: aload_1
/*     */     //   112: aload 4
/*     */     //   114: iconst_0
/*     */     //   115: invokeinterface 199 2 0
/*     */     //   120: invokeinterface 438 1 0
/*     */     //   125: invokestatic 443	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*     */     //   128: invokestatic 137	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
/*     */     //   131: invokevirtual 447	java/util/ArrayList:add	(Ljava/lang/Object;)Z
/*     */     //   134: pop
/*     */     //   135: goto +12 -> 147
/*     */     //   138: aload_1
/*     */     //   139: iconst_m1
/*     */     //   140: invokestatic 137	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
/*     */     //   143: invokevirtual 447	java/util/ArrayList:add	(Ljava/lang/Object;)Z
/*     */     //   146: pop
/*     */     //   147: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   150: invokeinterface 38 1 0
/*     */     //   155: ifeq +14 -> 169
/*     */     //   158: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   161: ldc_w 450
/*     */     //   164: invokeinterface 46 2 0
/*     */     //   169: aload_3
/*     */     //   170: invokeinterface 186 1 0
/*     */     //   175: ldc_w 452
/*     */     //   178: invokestatic 454	es/mityc/crypto/steganography/StegoUtils:getChildElementByTagName	(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/util/ArrayList;
/*     */     //   181: astore 5
/*     */     //   183: aload 5
/*     */     //   185: ifnull +140 -> 325
/*     */     //   188: aload 5
/*     */     //   190: invokevirtual 458	java/util/ArrayList:size	()I
/*     */     //   193: ifle +132 -> 325
/*     */     //   196: aconst_null
/*     */     //   197: astore 6
/*     */     //   199: iconst_0
/*     */     //   200: istore 7
/*     */     //   202: goto +103 -> 305
/*     */     //   205: aload 5
/*     */     //   207: iload 7
/*     */     //   209: invokevirtual 461	java/util/ArrayList:get	(I)Ljava/lang/Object;
/*     */     //   212: checkcast 181	org/w3c/dom/Element
/*     */     //   215: invokeinterface 465 1 0
/*     */     //   220: astore 8
/*     */     //   222: iconst_0
/*     */     //   223: istore 9
/*     */     //   225: goto +65 -> 290
/*     */     //   228: aload 8
/*     */     //   230: iload 9
/*     */     //   232: invokeinterface 469 2 0
/*     */     //   237: astore 10
/*     */     //   239: aload 10
/*     */     //   241: invokeinterface 438 1 0
/*     */     //   246: astore 11
/*     */     //   248: aload 11
/*     */     //   250: ifnull +37 -> 287
/*     */     //   253: aload 11
/*     */     //   255: new 50	java/lang/StringBuilder
/*     */     //   258: dup
/*     */     //   259: ldc_w 472
/*     */     //   262: invokespecial 54	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   265: getstatic 474	java/io/File:separator	Ljava/lang/String;
/*     */     //   268: invokevirtual 57	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   271: invokevirtual 61	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   274: invokevirtual 477	java/lang/String:startsWith	(Ljava/lang/String;)Z
/*     */     //   277: ifeq +10 -> 287
/*     */     //   280: aload 11
/*     */     //   282: astore 6
/*     */     //   284: goto +18 -> 302
/*     */     //   287: iinc 9 1
/*     */     //   290: iload 9
/*     */     //   292: aload 8
/*     */     //   294: invokeinterface 481 1 0
/*     */     //   299: if_icmplt -71 -> 228
/*     */     //   302: iinc 7 1
/*     */     //   305: iload 7
/*     */     //   307: aload 5
/*     */     //   309: invokevirtual 458	java/util/ArrayList:size	()I
/*     */     //   312: if_icmplt -107 -> 205
/*     */     //   315: aload_1
/*     */     //   316: aload 6
/*     */     //   318: invokevirtual 447	java/util/ArrayList:add	(Ljava/lang/Object;)Z
/*     */     //   321: pop
/*     */     //   322: goto +9 -> 331
/*     */     //   325: aload_1
/*     */     //   326: aconst_null
/*     */     //   327: invokevirtual 447	java/util/ArrayList:add	(Ljava/lang/Object;)Z
/*     */     //   330: pop
/*     */     //   331: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   334: invokeinterface 38 1 0
/*     */     //   339: ifeq +14 -> 353
/*     */     //   342: getstatic 24	es/mityc/crypto/steganography/StegoUtils:logger	Lorg/apache/commons/logging/Log;
/*     */     //   345: ldc_w 482
/*     */     //   348: invokeinterface 46 2 0
/*     */     //   353: aload_3
/*     */     //   354: invokeinterface 186 1 0
/*     */     //   359: ldc 13
/*     */     //   361: invokestatic 454	es/mityc/crypto/steganography/StegoUtils:getChildElementByTagName	(Lorg/w3c/dom/Element;Ljava/lang/String;)Ljava/util/ArrayList;
/*     */     //   364: astore 6
/*     */     //   366: aload 6
/*     */     //   368: ifnull +45 -> 413
/*     */     //   371: aload 6
/*     */     //   373: invokevirtual 458	java/util/ArrayList:size	()I
/*     */     //   376: iconst_1
/*     */     //   377: if_icmpne +36 -> 413
/*     */     //   380: aload 6
/*     */     //   382: iconst_0
/*     */     //   383: invokevirtual 461	java/util/ArrayList:get	(I)Ljava/lang/Object;
/*     */     //   386: checkcast 181	org/w3c/dom/Element
/*     */     //   389: invokeinterface 484 1 0
/*     */     //   394: astore 7
/*     */     //   396: aload 7
/*     */     //   398: invokestatic 485	es/mityc/javasign/utils/Base64Coder:decode	(Ljava/lang/String;)[B
/*     */     //   401: astore 8
/*     */     //   403: aload_1
/*     */     //   404: aload 8
/*     */     //   406: invokevirtual 447	java/util/ArrayList:add	(Ljava/lang/Object;)Z
/*     */     //   409: pop
/*     */     //   410: goto +30 -> 440
/*     */     //   413: aload_1
/*     */     //   414: aconst_null
/*     */     //   415: invokevirtual 447	java/util/ArrayList:add	(Ljava/lang/Object;)Z
/*     */     //   418: pop
/*     */     //   419: goto +21 -> 440
/*     */     //   422: astore 12
/*     */     //   424: aload_2
/*     */     //   425: ifnull +12 -> 437
/*     */     //   428: aload_2
/*     */     //   429: invokevirtual 304	java/io/FileInputStream:close	()V
/*     */     //   432: goto +5 -> 437
/*     */     //   435: astore 13
/*     */     //   437: aload 12
/*     */     //   439: athrow
/*     */     //   440: aload_2
/*     */     //   441: ifnull +12 -> 453
/*     */     //   444: aload_2
/*     */     //   445: invokevirtual 304	java/io/FileInputStream:close	()V
/*     */     //   448: goto +5 -> 453
/*     */     //   451: astore 13
/*     */     //   453: aload_1
/*     */     //   454: areturn
/*     */     // Line number table:
/*     */     //   Java source line #367	-> byte code offset #0
/*     */     //   Java source line #368	-> byte code offset #9
/*     */     //   Java source line #370	-> byte code offset #11
/*     */     //   Java source line #371	-> byte code offset #22
/*     */     //   Java source line #373	-> byte code offset #50
/*     */     //   Java source line #374	-> byte code offset #59
/*     */     //   Java source line #376	-> byte code offset #64
/*     */     //   Java source line #377	-> byte code offset #75
/*     */     //   Java source line #379	-> byte code offset #86
/*     */     //   Java source line #380	-> byte code offset #96
/*     */     //   Java source line #381	-> byte code offset #111
/*     */     //   Java source line #382	-> byte code offset #135
/*     */     //   Java source line #383	-> byte code offset #138
/*     */     //   Java source line #386	-> byte code offset #147
/*     */     //   Java source line #387	-> byte code offset #158
/*     */     //   Java source line #389	-> byte code offset #169
/*     */     //   Java source line #390	-> byte code offset #183
/*     */     //   Java source line #391	-> byte code offset #196
/*     */     //   Java source line #392	-> byte code offset #199
/*     */     //   Java source line #393	-> byte code offset #205
/*     */     //   Java source line #394	-> byte code offset #222
/*     */     //   Java source line #395	-> byte code offset #228
/*     */     //   Java source line #396	-> byte code offset #239
/*     */     //   Java source line #397	-> byte code offset #248
/*     */     //   Java source line #398	-> byte code offset #280
/*     */     //   Java source line #399	-> byte code offset #284
/*     */     //   Java source line #394	-> byte code offset #287
/*     */     //   Java source line #392	-> byte code offset #302
/*     */     //   Java source line #403	-> byte code offset #315
/*     */     //   Java source line #404	-> byte code offset #322
/*     */     //   Java source line #405	-> byte code offset #325
/*     */     //   Java source line #408	-> byte code offset #331
/*     */     //   Java source line #409	-> byte code offset #342
/*     */     //   Java source line #411	-> byte code offset #353
/*     */     //   Java source line #412	-> byte code offset #366
/*     */     //   Java source line #413	-> byte code offset #380
/*     */     //   Java source line #414	-> byte code offset #396
/*     */     //   Java source line #415	-> byte code offset #403
/*     */     //   Java source line #416	-> byte code offset #410
/*     */     //   Java source line #417	-> byte code offset #413
/*     */     //   Java source line #419	-> byte code offset #419
/*     */     //   Java source line #420	-> byte code offset #424
/*     */     //   Java source line #421	-> byte code offset #428
/*     */     //   Java source line #423	-> byte code offset #437
/*     */     //   Java source line #420	-> byte code offset #440
/*     */     //   Java source line #421	-> byte code offset #444
/*     */     //   Java source line #425	-> byte code offset #453
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	455	0	xml	File
/*     */     //   8	446	1	res	ArrayList<Object>
/*     */     //   10	435	2	fis	FileInputStream
/*     */     //   63	291	3	doc	Document
/*     */     //   94	19	4	prevData	NodeList
/*     */     //   181	127	5	nodosReference	ArrayList<Element>
/*     */     //   197	120	6	name	String
/*     */     //   364	17	6	nodosDigest	ArrayList<Element>
/*     */     //   200	106	7	i	int
/*     */     //   394	3	7	b64Val	String
/*     */     //   220	73	8	att	org.w3c.dom.NamedNodeMap
/*     */     //   401	4	8	digest	byte[]
/*     */     //   223	68	9	j	int
/*     */     //   237	3	10	at	Node
/*     */     //   246	35	11	attVal	String
/*     */     //   422	16	12	localObject	Object
/*     */     //   435	1	13	localIOException	IOException
/*     */     //   451	1	13	localIOException1	IOException
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   11	422	422	finally
/*     */     //   428	432	435	java/io/IOException
/*     */     //   444	448	451	java/io/IOException
/*     */   }
/*     */   
/*     */   public static byte[] zipData(byte[] msg)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 436 */       if (logger.isDebugEnabled()) {
/* 437 */         logger.debug("Comprimiendo datos en ZIP: " + msg.length);
/*     */       }
/* 439 */       ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*     */       
/* 441 */       GZIPOutputStream zos = new GZIPOutputStream(bos);
/* 442 */       zos.write(msg);
/* 443 */       zos.finish();
/* 444 */       zos.close();
/* 445 */       bos.close();
/*     */       
/* 447 */       byte[] data = bos.toByteArray();
/* 448 */       if (logger.isDebugEnabled()) {
/* 449 */         logger.debug("Datos comprimidos: " + data.length);
/*     */       }
/* 451 */       return data;
/*     */     } catch (IOException ioEx) {
/* 453 */       logger.error("Error al inflar los datos");
/* 454 */       if (logger.isDebugEnabled()) {
/* 455 */         logger.debug(ioEx);
/*     */       }
/* 457 */       throw ioEx;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] unzipData(byte[] msg)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 469 */       if (logger.isDebugEnabled()) {
/* 470 */         logger.debug("Descomprimiendo datos en ZIP: " + msg.length);
/*     */       }
/* 472 */       ByteArrayInputStream bis = new ByteArrayInputStream(msg);
/* 473 */       GZIPInputStream zis = new GZIPInputStream(bis);
/* 474 */       msg = Utils.getStreamBytes(zis);
/* 475 */       zis.close();
/* 476 */       bis.close();
/* 477 */       if (logger.isDebugEnabled()) {
/* 478 */         logger.debug("Datos inflados: " + msg.length);
/*     */       }
/* 480 */       return msg;
/*     */     } catch (IOException ioEx) {
/* 482 */       logger.error("Error al inflar los datos");
/* 483 */       if (logger.isDebugEnabled()) {
/* 484 */         logger.debug(ioEx);
/*     */       }
/* 486 */       throw ioEx;
/*     */     }
/*     */   }
/*     */   
/*     */   public static byte[] hashPass(String pass) {
/* 491 */     logger.debug("Se emplea el valor SHA256 como contraseña.");
/* 492 */     if ((pass == null) || (pass.trim().equals(""))) {
/* 493 */       logger.error("Contraseña nula o vacía. Se utiliza por defecto");
/* 494 */       return "3141592654Pi".getBytes();
/*     */     }
/* 496 */     Utils.addBCProvider();
/*     */     try {
/* 498 */       MessageDigest hash = MessageDigest.getInstance("SHA256", 
/* 499 */         "BC");
/* 500 */       return hash.digest(pass.getBytes());
/*     */     } catch (Exception e) {
/* 502 */       logger.error("Error al calcular el Digest de la contraseña", e); }
/* 503 */     return "3141592654Pi".getBytes();
/*     */   }
/*     */   
/*     */   public static long hashPassLong(String pass)
/*     */   {
/* 508 */     byte[] byteHash = hashPass(pass);
/*     */     
/* 510 */     byte[] hex = new byte[2 * byteHash.length];
/* 511 */     int index = 0;
/*     */     
/*     */ 
/* 514 */     byte[] HEX_CHAR_TABLE = {
/* 515 */       48, 49, 50, 51, 
/* 516 */       52, 53, 54, 55, 
/* 517 */       56, 57, 97, 98, 
/* 518 */       99, 100, 101, 102 };
/*     */     
/*     */ 
/* 521 */     for (int i = 0; i < byteHash.length; i++) {
/* 522 */       int byteVal = byteHash[i] & 0xFF;
/* 523 */       hex[(index++)] = HEX_CHAR_TABLE[(byteVal >>> 4)];
/* 524 */       hex[(index++)] = HEX_CHAR_TABLE[(byteVal & 0xF)];
/*     */     }
/* 526 */     String hexString = new String(hex);
/*     */     
/*     */ 
/* 529 */     hexString = hexString.substring(0, 15);
/* 530 */     return Long.parseLong(hexString, 16);
/*     */   }
/*     */   
/*     */   private static Document getDocument(FileInputStream fis) throws Exception {
/* 534 */     ByteArrayOutputStream baosLeido = null;
/*     */     try {
/* 536 */       baosLeido = new ByteArrayOutputStream();
/* 537 */       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 538 */       dbf.setNamespaceAware(true);
/* 539 */       DocumentBuilder db = null;
/* 540 */       db = dbf.newDocumentBuilder();
/*     */       
/* 542 */       int bytesRead = 0;
/* 543 */       byte[] data = new byte['Ѐ'];
/* 544 */       while ((bytesRead = fis.read(data, 0, 1024)) >= 0) {
/* 545 */         baosLeido.write(data, 0, bytesRead);
/*     */       }
/*     */       
/* 548 */       InputSource isour = new InputSource(new ByteArrayInputStream(baosLeido.toByteArray()));
/* 549 */       return db.parse(isour);
/*     */     } finally {
/* 551 */       if (baosLeido != null)
/* 552 */         try { baosLeido.close();
/*     */         } catch (IOException localIOException1) {}
/*     */     }
/*     */   }
/*     */   
/*     */   private static ArrayList<Element> getChildElementByTagName(Element padre, String name) {
/* 558 */     ArrayList<Element> resultado = new ArrayList();
/* 559 */     NodeList nodesHijos = padre.getChildNodes();
/*     */     
/* 561 */     for (int i = 0; i < nodesHijos.getLength(); i++) {
/* 562 */       Node nodo = nodesHijos.item(i);
/*     */       
/*     */ 
/* 565 */       if (nodo.getNodeType() == 1)
/*     */       {
/*     */ 
/*     */ 
/* 569 */         if (name.equals(nodo.getLocalName())) {
/* 570 */           resultado.add((Element)nodo);
/*     */         }
/* 572 */         if (nodo.hasChildNodes())
/* 573 */           resultado.addAll(getChildElementByTagName((Element)nodo, name));
/*     */       }
/*     */     }
/* 576 */     return resultado;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static File prepareImage(File imagen, File destino)
/*     */     throws Exception
/*     */   {
/* 587 */     int BUF_SIZE = 512;
/* 588 */     byte[] res = null;
/* 589 */     BufferedOutputStream fos = null;
/*     */     
/* 591 */     InputStream is = null;
/* 592 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 593 */     int bytesRead = 0;
/* 594 */     byte[] data = new byte[BUF_SIZE];
/*     */     try {
/* 596 */       if (logger.isDebugEnabled()) {
/* 597 */         logger.debug("Leyendo imagen.");
/*     */       }
/* 599 */       is = new FileInputStream(imagen);
/* 600 */       while ((bytesRead = is.read(data, 0, BUF_SIZE)) >= 0) {
/* 601 */         bos.write(data, 0, bytesRead);
/*     */       }
/* 603 */       bos.flush();
/* 604 */       bos.close();
/* 605 */       is.close();
/*     */       
/* 607 */       if (logger.isDebugEnabled()) {
/* 608 */         logger.debug("Realizando la conversión");
/*     */       }
/*     */       
/* 611 */       BufferedImage image = null;
/* 612 */       if (imagen.getName().endsWith("bmp")) {
/* 613 */         image = convertBitmap(imagen);
/*     */         
/* 615 */         destino = new File(destino.getAbsolutePath() + ".png");
/* 616 */         if (destino.exists()) {
/* 617 */           destino = new File(destino.getAbsolutePath() + new Random().nextInt(100) + ".png");
/*     */         }
/* 619 */       } else if (imagen.getName().endsWith("jpg")) {
/* 620 */         image = byteArrayToImage(bos.toByteArray());
/*     */         
/* 622 */         destino = new File(destino.getAbsolutePath() + ".png");
/* 623 */         if (destino.exists()) {
/* 624 */           destino = new File(destino.getAbsolutePath() + new Random().nextInt(100) + ".png");
/*     */         }
/*     */       } else {
/* 627 */         image = byteArrayToImage(bos.toByteArray());
/*     */       }
/*     */       
/* 630 */       if (image == null) {
/* 631 */         throw new ImageFormatException("Imagen no compatible");
/*     */       }
/*     */       
/* 634 */       if (image.getType() != 1) {
/* 635 */         int width = image.getWidth();
/* 636 */         int height = image.getHeight();
/* 637 */         BufferedImage imageConv = new BufferedImage(width, height, 1);
/* 638 */         for (int x = 0; x < width; x++) {
/* 639 */           for (int y = 0; y < height; y++) {
/* 640 */             imageConv.setRGB(x, y, image.getRGB(x, y));
/*     */           }
/*     */         }
/*     */         
/* 644 */         String formatoDestino = destino.getAbsolutePath();
/* 645 */         formatoDestino = formatoDestino.substring(formatoDestino.lastIndexOf('.') + 1);
/* 646 */         res = imageToByteArray(imageConv, formatoDestino);
/*     */       } else {
/* 648 */         String formatoDestino = destino.getAbsolutePath();
/* 649 */         formatoDestino = formatoDestino.substring(formatoDestino.lastIndexOf('.') + 1);
/* 650 */         res = imageToByteArray(image, formatoDestino);
/*     */       }
/*     */       
/* 653 */       if (logger.isDebugEnabled()) {
/* 654 */         logger.debug("Escribiendo el resultado");
/*     */       }
/*     */       
/* 657 */       fos = new BufferedOutputStream(new FileOutputStream(destino));
/* 658 */       fos.write(res);
/*     */       
/* 660 */       return destino;
/*     */     } catch (Exception e) {
/* 662 */       logger.error(e);
/* 663 */       throw e;
/*     */     } finally {
/* 665 */       if (fos != null) {
/*     */         try {
/* 667 */           fos.flush();
/* 668 */           fos.close();
/*     */         } catch (Throwable e) {
/* 670 */           if (logger.isDebugEnabled()) {
/* 671 */             logger.debug(e);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BufferedImage convertBitmap(File imagen)
/*     */   {
/* 684 */     if (logger.isDebugEnabled()) {
/* 685 */       logger.debug("Convirtiendo el mapa de bits: " + imagen.getAbsolutePath());
/*     */     }
/* 687 */     Image image = null;
/* 688 */     FileInputStream fs = null;
/*     */     try {
/* 690 */       fs = new FileInputStream(imagen);
/*     */       
/* 692 */       int bflen = 14;
/* 693 */       byte[] bf = new byte[bflen];
/* 694 */       fs.read(bf, 0, bflen);
/*     */       
/* 696 */       int bilen = 40;
/* 697 */       byte[] bi = new byte[bilen];
/* 698 */       fs.read(bi, 0, bilen);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 705 */       if (logger.isDebugEnabled()) {
/* 706 */         logger.debug("Tipo de mapa de bits: " + (char)bf[0] + (char)bf[1]);
/*     */       }
/*     */       
/* 709 */       int nbisize = (bi[3] & 0xFF) << 24 | 
/* 710 */         (bi[2] & 0xFF) << 16 | 
/* 711 */         (bi[1] & 0xFF) << 8 | 
/* 712 */         bi[0] & 0xFF;
/* 713 */       if (logger.isDebugEnabled()) {
/* 714 */         logger.debug("Tamaño de la cabecera: " + nbisize);
/*     */       }
/*     */       
/* 717 */       int nwidth = (bi[7] & 0xFF) << 24 | 
/* 718 */         (bi[6] & 0xFF) << 16 | 
/* 719 */         (bi[5] & 0xFF) << 8 | 
/* 720 */         bi[4] & 0xFF;
/*     */       
/* 722 */       int nheight = (bi[11] & 0xFF) << 24 | 
/* 723 */         (bi[10] & 0xFF) << 16 | 
/* 724 */         (bi[9] & 0xFF) << 8 | 
/* 725 */         bi[8] & 0xFF;
/* 726 */       if (logger.isDebugEnabled()) {
/* 727 */         logger.debug("Tamaño de la imagen: " + nwidth + ", " + nheight);
/*     */       }
/*     */       
/*     */ 
/* 731 */       int nbitcount = (bi[15] & 0xFF) << 8 | bi[14] & 0xFF;
/*     */       
/*     */ 
/* 734 */       int ncompression = bi[19] << 24 | 
/* 735 */         bi[18] << 16 | 
/* 736 */         bi[17] << 8 | 
/* 737 */         bi[16];
/* 738 */       if (logger.isDebugEnabled()) {
/* 739 */         logger.debug("Compresión de imagen: " + ncompression);
/*     */       }
/*     */       
/* 742 */       int nsizeimage = (bi[23] & 0xFF) << 24 | 
/* 743 */         (bi[22] & 0xFF) << 16 | 
/* 744 */         (bi[21] & 0xFF) << 8 | 
/* 745 */         bi[20] & 0xFF;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 758 */       int nclrused = (bi[35] & 0xFF) << 24 | 
/* 759 */         (bi[34] & 0xFF) << 16 | 
/* 760 */         (bi[33] & 0xFF) << 8 | 
/* 761 */         bi[32] & 0xFF;
/* 762 */       if (logger.isDebugEnabled()) {
/* 763 */         logger.debug("Colores: " + nclrused);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 772 */       if (nbitcount == 24)
/*     */       {
/*     */ 
/* 775 */         int npad = nsizeimage / nheight - nwidth * 3;
/*     */         
/* 777 */         if (npad == 4) {
/* 778 */           npad = 0;
/*     */         }
/* 780 */         int[] ndata = new int[nheight * nwidth];
/* 781 */         byte[] brgb = new byte[(nwidth + npad) * 3 * nheight];
/*     */         
/* 783 */         fs.read(brgb, 0, (nwidth + npad) * 3 * nheight);
/* 784 */         int nindex = 0;
/* 785 */         for (int j = 0; j < nheight; j++) {
/* 786 */           for (int i = 0; i < nwidth; i++) {
/* 787 */             ndata[(nwidth * (nheight - j - 1) + i)] = 
/* 788 */               (0xFF000000 | 
/* 789 */               (brgb[(nindex + 2)] & 0xFF) << 16 | 
/* 790 */               (brgb[(nindex + 1)] & 0xFF) << 8 | 
/* 791 */               brgb[nindex] & 0xFF);
/* 792 */             nindex += 3;
/*     */           }
/* 794 */           nindex += npad;
/*     */         }
/*     */         
/* 797 */         image = Toolkit.getDefaultToolkit().createImage(new MemoryImageSource(nwidth, nheight, ndata, 0, nwidth));
/* 798 */       } else if (nbitcount == 8)
/*     */       {
/*     */ 
/*     */ 
/* 802 */         int nNumColors = 0;
/* 803 */         if (nclrused > 0) {
/* 804 */           nNumColors = nclrused;
/*     */         } else {
/* 806 */           nNumColors = 1 << nbitcount;
/*     */         }
/* 808 */         if (logger.isDebugEnabled()) {
/* 809 */           logger.debug("Colores: " + nNumColors);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 814 */         if (nsizeimage == 0) {
/* 815 */           nsizeimage = (nwidth * nbitcount + 31 & 0xFFFFFFE0) >> 3;
/* 816 */           nsizeimage *= nheight;
/*     */         }
/*     */         
/*     */ 
/* 820 */         int[] npalette = new int[nNumColors];
/* 821 */         byte[] bpalette = new byte[nNumColors * 4];
/* 822 */         fs.read(bpalette, 0, nNumColors * 4);
/* 823 */         int nindex8 = 0;
/* 824 */         for (int n = 0; n < nNumColors; n++) {
/* 825 */           npalette[n] = 
/*     */           
/*     */ 
/* 828 */             (0xFF000000 | (bpalette[(nindex8 + 2)] & 0xFF) << 16 | (bpalette[(nindex8 + 1)] & 0xFF) << 8 | bpalette[nindex8] & 0xFF);
/* 829 */           nindex8 += 4;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 834 */         int npad8 = nsizeimage / nheight - nwidth;
/*     */         
/* 836 */         int[] ndata8 = new int[nwidth * nheight];
/* 837 */         byte[] bdata = new byte[(nwidth + npad8) * nheight];
/* 838 */         fs.read(bdata, 0, (nwidth + npad8) * nheight);
/* 839 */         nindex8 = 0;
/* 840 */         for (int j8 = 0; j8 < nheight; j8++) {
/* 841 */           for (int i8 = 0; i8 < nwidth; i8++) {
/* 842 */             ndata8[(nwidth * (nheight - j8 - 1) + i8)] = 
/* 843 */               npalette[(bdata[nindex8] & 0xFF)];
/* 844 */             nindex8++;
/*     */           }
/* 846 */           nindex8 += npad8;
/*     */         }
/*     */         
/* 849 */         image = Toolkit.getDefaultToolkit().createImage(new MemoryImageSource(nwidth, nheight, ndata8, 0, nwidth));
/*     */       }
/* 851 */       else if (nbitcount == 1) {
/* 852 */         int npad1 = nsizeimage / nheight - nwidth / 8;
/* 853 */         byte[] bdata = new byte[(nwidth + npad1) * nheight];
/* 854 */         fs.read(bdata, 0, 8);
/* 855 */         fs.read(bdata, 0, (nwidth + npad1) * nheight);
/* 856 */         int[] ndata1 = new int[nwidth * nheight];
/* 857 */         int nindex1 = 0;
/*     */         
/* 859 */         for (int j1 = 0; j1 < nheight; j1++)
/*     */         {
/* 861 */           int iindex = nindex1;
/* 862 */           for (int i1 = 0; i1 <= nwidth / 8; i1++) {
/* 863 */             int ib1 = 0;
/* 864 */             if (i1 * 8 < nwidth) {
/* 865 */               for (int b1 = 128; b1 > 0; b1 /= 2) {
/* 866 */                 ndata1[(nwidth * (nheight - j1 - 1) + i1 * 8 + ib1)] = 
/* 867 */                   ((b1 & bdata[iindex]) > 0 ? 16777215 : 0);
/* 868 */                 ib1++;
/* 869 */                 if (i1 * 8 + ib1 >= nwidth) {
/* 870 */                   b1 = 0;
/*     */                 }
/*     */               }
/*     */             }
/* 874 */             iindex++;
/*     */           }
/* 876 */           nindex1 += nsizeimage / nheight;
/*     */         }
/*     */         
/* 879 */         image = Toolkit.getDefaultToolkit().createImage(
/* 880 */           new MemoryImageSource(nwidth, nheight, ndata1, 0, nwidth));
/*     */       } else {
/* 882 */         logger.error("Formato incompatible. No pertenece a un formato válido de 24, 8 o 1 bit.");
/* 883 */         image = null;
/*     */       }
/*     */       
/* 886 */       BufferedImage img = toBufferedImage(image);
/*     */       
/* 888 */       return img;
/*     */     } catch (Exception e) {
/* 890 */       logger.error("No se pudo convertir la imagen", e);
/*     */     } finally {
/*     */       try {
/* 893 */         fs.close();
/*     */       } catch (Exception e) {
/* 895 */         logger.debug(e);
/*     */       }
/*     */     }
/*     */     
/* 899 */     return null;
/*     */   }
/*     */   
/*     */   private static BufferedImage toBufferedImage(Image image) {
/* 903 */     if ((image instanceof BufferedImage)) {
/* 904 */       return (BufferedImage)image;
/*     */     }
/*     */     
/*     */ 
/* 908 */     image = new ImageIcon(image).getImage();
/*     */     
/*     */ 
/*     */ 
/* 912 */     boolean hasAlpha = hasAlpha(image);
/*     */     
/*     */ 
/* 915 */     BufferedImage bimage = null;
/* 916 */     GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
/*     */     try
/*     */     {
/* 919 */       int transparency = 1;
/* 920 */       if (hasAlpha) {
/* 921 */         transparency = 2;
/*     */       }
/*     */       
/*     */ 
/* 925 */       GraphicsDevice gs = ge.getDefaultScreenDevice();
/* 926 */       GraphicsConfiguration gc = gs.getDefaultConfiguration();
/* 927 */       bimage = gc.createCompatibleImage(image.getWidth(null), image.getHeight(null), transparency);
/*     */     } catch (HeadlessException e) {
/* 929 */       logger.error("No se pudo recuperar los datos de cabacera de la imagen", e);
/*     */     }
/*     */     
/* 932 */     if (bimage == null)
/*     */     {
/* 934 */       int type = 1;
/* 935 */       if (hasAlpha) {
/* 936 */         type = 2;
/*     */       }
/* 938 */       bimage = new BufferedImage(image.getWidth(null), image.getHeight(null), type);
/*     */     }
/*     */     
/*     */ 
/* 942 */     Graphics g = bimage.getGraphics();
/*     */     
/*     */ 
/* 945 */     g.drawImage(image, 0, 0, null);
/* 946 */     g.dispose();
/*     */     
/* 948 */     return bimage;
/*     */   }
/*     */   
/*     */ 
/*     */   private static boolean hasAlpha(Image image)
/*     */   {
/* 954 */     if ((image instanceof BufferedImage)) {
/* 955 */       BufferedImage bimage = (BufferedImage)image;
/* 956 */       return bimage.getColorModel().hasAlpha();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 961 */     PixelGrabber pg = new PixelGrabber(image, 0, 0, 1, 1, false);
/*     */     try {
/* 963 */       pg.grabPixels();
/*     */     } catch (InterruptedException e) {
/* 965 */       logger.error("No se pudo leer los pixels de la imagen", e);
/* 966 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 970 */     ColorModel cm = pg.getColorModel();
/* 971 */     return cm.hasAlpha();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCrypt-1.1.7.jar!\es\mityc\crypto\steganography\StegoUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */