/*    */ package es.mityc.crypto.steganography;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StegoConfig
/*    */ {
/* 28 */   private boolean comprimir = true;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 33 */   private boolean encriptar = false;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 38 */   private String password = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 44 */   private int maxBitsCanal = 3;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isComprimir()
/*    */   {
/* 56 */     return this.comprimir;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setComprimir(boolean comprimir)
/*    */   {
/* 63 */     this.comprimir = comprimir;
/*    */   }
/*    */   
/*    */   public boolean isEncriptar() {
/* 67 */     return this.encriptar;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setEncriptar(boolean encriptar)
/*    */   {
/* 74 */     this.encriptar = encriptar;
/*    */   }
/*    */   
/*    */   public String getPassword() {
/* 78 */     return this.password;
/*    */   }
/*    */   
/*    */   public void setPassword(String password) {
/* 82 */     this.password = password;
/*    */   }
/*    */   
/*    */   public int getMaxBitsPorCanal() {
/* 86 */     return this.maxBitsCanal;
/*    */   }
/*    */   
/*    */   public void setMaxBitsPorCanal(int maxBitsUsedPerChannel) {
/* 90 */     this.maxBitsCanal = maxBitsUsedPerChannel;
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCrypt-1.1.7.jar!\es\mityc\crypto\steganography\StegoConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */