/*    */ package es.mityc.crypto.steganography;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StegoException
/*    */   extends Exception
/*    */ {
/*    */   public StegoException(Throwable causa)
/*    */   {
/* 25 */     super(causa);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public StegoException(String causa)
/*    */   {
/* 32 */     super(causa);
/*    */   }
/*    */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCrypt-1.1.7.jar!\es\mityc\crypto\steganography\StegoException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */