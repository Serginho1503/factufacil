/*     */ package es.mityc.crypto.steganography;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Random;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StegoSign
/*     */ {
/*  38 */   static Log logger = LogFactory.getLog(StegoSign.class);
/*     */   
/*  40 */   private BufferedImage image = null;
/*     */   
/*  42 */   private Random rand = null;
/*     */   
/*     */   private static final int BUF_SIZE = 512;
/*  45 */   private int imgWidth = 0;
/*  46 */   private int imgHeight = 0;
/*  47 */   private int channelBitsUsed = 1;
/*  48 */   private CabeceraLSB cabecera = null;
/*  49 */   private String fileName = null;
/*     */   
/*     */ 
/*     */   private boolean[][][][] matrizMaestra;
/*     */   
/*     */ 
/*  55 */   private static StegoConfig config = new StegoConfig();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getRestaurationData(File imagenOriginal, File datos, String password)
/*     */     throws Exception
/*     */   {
/*  67 */     this.rand = new Random(StegoUtils.hashPassLong(password));
/*     */     
/*  69 */     InputStream is = null;
/*  70 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*  71 */     ByteArrayOutputStream bosFirma = new ByteArrayOutputStream();
/*  72 */     int bytesRead = 0;
/*  73 */     byte[] data = new byte['Ȁ'];
/*     */     try {
/*  75 */       if (logger.isDebugEnabled()) {
/*  76 */         logger.debug("Leyendo imagen original");
/*     */       }
/*  78 */       is = new FileInputStream(imagenOriginal);
/*  79 */       while ((bytesRead = is.read(data, 0, 512)) >= 0) {
/*  80 */         bos.write(data, 0, bytesRead);
/*     */       }
/*  82 */       if (logger.isDebugEnabled()) {
/*  83 */         logger.debug("Leyendo datos a ocultar");
/*     */       }
/*  85 */       is = new FileInputStream(datos);
/*  86 */       while ((bytesRead = is.read(data, 0, 512)) >= 0) {
/*  87 */         bosFirma.write(data, 0, bytesRead);
/*     */       }
/*     */       
/*  90 */       if (logger.isDebugEnabled()) {
/*  91 */         logger.debug("Calculando datos de recuperación");
/*     */       }
/*     */       
/*  94 */       byte[] datosZip = null;
/*     */       try
/*     */       {
/*  97 */         datosZip = StegoUtils.zipData(bosFirma.toByteArray());
/*  98 */         datosZip = new byte[datosZip.length + 50];
/*     */       } catch (Exception e) {
/* 100 */         if (logger.isDebugEnabled()) {
/* 101 */           logger.debug("Se continúa sin comprimir");
/*     */         }
/*     */       }
/*     */       
/* 105 */       return getRestoreData(datosZip, datos.getName(), bos.toByteArray(), password != null ? password.getBytes() : null);
/*     */     } catch (Exception e) {
/* 107 */       logger.error(e);
/* 108 */       throw e;
/*     */     } finally {
/*     */       try {
/* 111 */         is.close();
/* 112 */         bos.close();
/*     */       } catch (IOException e) {
/* 114 */         if (logger.isDebugEnabled()) {
/* 115 */           logger.debug(e);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void restoreOriginal(File imagen, byte[] restaurationData, File destino, String password)
/*     */     throws Exception
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore 5
/*     */     //   3: new 79	java/io/ByteArrayOutputStream
/*     */     //   6: dup
/*     */     //   7: invokespecial 81	java/io/ByteArrayOutputStream:<init>	()V
/*     */     //   10: astore 6
/*     */     //   12: iconst_0
/*     */     //   13: istore 7
/*     */     //   15: sipush 512
/*     */     //   18: newarray <illegal type>
/*     */     //   20: astore 8
/*     */     //   22: getstatic 35	es/mityc/crypto/steganography/StegoSign:logger	Lorg/apache/commons/logging/Log;
/*     */     //   25: invokeinterface 82 1 0
/*     */     //   30: ifeq +13 -> 43
/*     */     //   33: getstatic 35	es/mityc/crypto/steganography/StegoSign:logger	Lorg/apache/commons/logging/Log;
/*     */     //   36: ldc 88
/*     */     //   38: invokeinterface 90 2 0
/*     */     //   43: new 94	java/io/FileInputStream
/*     */     //   46: dup
/*     */     //   47: aload_1
/*     */     //   48: invokespecial 96	java/io/FileInputStream:<init>	(Ljava/io/File;)V
/*     */     //   51: astore 5
/*     */     //   53: goto +13 -> 66
/*     */     //   56: aload 6
/*     */     //   58: aload 8
/*     */     //   60: iconst_0
/*     */     //   61: iload 7
/*     */     //   63: invokevirtual 99	java/io/ByteArrayOutputStream:write	([BII)V
/*     */     //   66: aload 5
/*     */     //   68: aload 8
/*     */     //   70: iconst_0
/*     */     //   71: sipush 512
/*     */     //   74: invokevirtual 103	java/io/InputStream:read	([BII)I
/*     */     //   77: dup
/*     */     //   78: istore 7
/*     */     //   80: ifge -24 -> 56
/*     */     //   83: getstatic 35	es/mityc/crypto/steganography/StegoSign:logger	Lorg/apache/commons/logging/Log;
/*     */     //   86: invokeinterface 82 1 0
/*     */     //   91: ifeq +13 -> 104
/*     */     //   94: getstatic 35	es/mityc/crypto/steganography/StegoSign:logger	Lorg/apache/commons/logging/Log;
/*     */     //   97: ldc -87
/*     */     //   99: invokeinterface 90 2 0
/*     */     //   104: new 171	es/mityc/crypto/steganography/StegoData
/*     */     //   107: dup
/*     */     //   108: invokespecial 173	es/mityc/crypto/steganography/StegoData:<init>	()V
/*     */     //   111: aload_2
/*     */     //   112: aconst_null
/*     */     //   113: aload 6
/*     */     //   115: invokevirtual 113	java/io/ByteArrayOutputStream:toByteArray	()[B
/*     */     //   118: aload_1
/*     */     //   119: invokevirtual 123	java/io/File:getName	()Ljava/lang/String;
/*     */     //   122: aload 4
/*     */     //   124: invokevirtual 174	es/mityc/crypto/steganography/StegoData:embeberDatos	([BLjava/lang/String;[BLjava/lang/String;Ljava/lang/String;)[B
/*     */     //   127: astore 9
/*     */     //   129: getstatic 35	es/mityc/crypto/steganography/StegoSign:logger	Lorg/apache/commons/logging/Log;
/*     */     //   132: invokeinterface 82 1 0
/*     */     //   137: ifeq +13 -> 150
/*     */     //   140: getstatic 35	es/mityc/crypto/steganography/StegoSign:logger	Lorg/apache/commons/logging/Log;
/*     */     //   143: ldc -78
/*     */     //   145: invokeinterface 90 2 0
/*     */     //   150: new 180	java/io/BufferedOutputStream
/*     */     //   153: dup
/*     */     //   154: new 182	java/io/FileOutputStream
/*     */     //   157: dup
/*     */     //   158: aload_3
/*     */     //   159: invokespecial 184	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
/*     */     //   162: invokespecial 185	java/io/BufferedOutputStream:<init>	(Ljava/io/OutputStream;)V
/*     */     //   165: astore 10
/*     */     //   167: aload 10
/*     */     //   169: aload 9
/*     */     //   171: invokevirtual 188	java/io/BufferedOutputStream:write	([B)V
/*     */     //   174: aload 10
/*     */     //   176: invokevirtual 191	java/io/BufferedOutputStream:flush	()V
/*     */     //   179: aload 10
/*     */     //   181: invokevirtual 194	java/io/BufferedOutputStream:close	()V
/*     */     //   184: goto +59 -> 243
/*     */     //   187: astore 9
/*     */     //   189: getstatic 35	es/mityc/crypto/steganography/StegoSign:logger	Lorg/apache/commons/logging/Log;
/*     */     //   192: aload 9
/*     */     //   194: invokeinterface 142 2 0
/*     */     //   199: aload 9
/*     */     //   201: athrow
/*     */     //   202: astore 11
/*     */     //   204: aload 5
/*     */     //   206: invokevirtual 138	java/io/InputStream:close	()V
/*     */     //   209: aload 6
/*     */     //   211: invokevirtual 141	java/io/ByteArrayOutputStream:close	()V
/*     */     //   214: goto +26 -> 240
/*     */     //   217: astore 12
/*     */     //   219: getstatic 35	es/mityc/crypto/steganography/StegoSign:logger	Lorg/apache/commons/logging/Log;
/*     */     //   222: invokeinterface 82 1 0
/*     */     //   227: ifeq +13 -> 240
/*     */     //   230: getstatic 35	es/mityc/crypto/steganography/StegoSign:logger	Lorg/apache/commons/logging/Log;
/*     */     //   233: aload 12
/*     */     //   235: invokeinterface 90 2 0
/*     */     //   240: aload 11
/*     */     //   242: athrow
/*     */     //   243: aload 5
/*     */     //   245: invokevirtual 138	java/io/InputStream:close	()V
/*     */     //   248: aload 6
/*     */     //   250: invokevirtual 141	java/io/ByteArrayOutputStream:close	()V
/*     */     //   253: goto +26 -> 279
/*     */     //   256: astore 12
/*     */     //   258: getstatic 35	es/mityc/crypto/steganography/StegoSign:logger	Lorg/apache/commons/logging/Log;
/*     */     //   261: invokeinterface 82 1 0
/*     */     //   266: ifeq +13 -> 279
/*     */     //   269: getstatic 35	es/mityc/crypto/steganography/StegoSign:logger	Lorg/apache/commons/logging/Log;
/*     */     //   272: aload 12
/*     */     //   274: invokeinterface 90 2 0
/*     */     //   279: return
/*     */     // Line number table:
/*     */     //   Java source line #130	-> byte code offset #0
/*     */     //   Java source line #131	-> byte code offset #3
/*     */     //   Java source line #132	-> byte code offset #12
/*     */     //   Java source line #133	-> byte code offset #15
/*     */     //   Java source line #135	-> byte code offset #22
/*     */     //   Java source line #136	-> byte code offset #33
/*     */     //   Java source line #138	-> byte code offset #43
/*     */     //   Java source line #139	-> byte code offset #53
/*     */     //   Java source line #140	-> byte code offset #56
/*     */     //   Java source line #139	-> byte code offset #66
/*     */     //   Java source line #143	-> byte code offset #83
/*     */     //   Java source line #144	-> byte code offset #94
/*     */     //   Java source line #146	-> byte code offset #104
/*     */     //   Java source line #147	-> byte code offset #118
/*     */     //   Java source line #146	-> byte code offset #124
/*     */     //   Java source line #149	-> byte code offset #129
/*     */     //   Java source line #150	-> byte code offset #140
/*     */     //   Java source line #152	-> byte code offset #150
/*     */     //   Java source line #153	-> byte code offset #167
/*     */     //   Java source line #154	-> byte code offset #174
/*     */     //   Java source line #155	-> byte code offset #179
/*     */     //   Java source line #156	-> byte code offset #184
/*     */     //   Java source line #157	-> byte code offset #189
/*     */     //   Java source line #158	-> byte code offset #199
/*     */     //   Java source line #159	-> byte code offset #202
/*     */     //   Java source line #161	-> byte code offset #204
/*     */     //   Java source line #162	-> byte code offset #209
/*     */     //   Java source line #163	-> byte code offset #214
/*     */     //   Java source line #164	-> byte code offset #219
/*     */     //   Java source line #165	-> byte code offset #230
/*     */     //   Java source line #168	-> byte code offset #240
/*     */     //   Java source line #161	-> byte code offset #243
/*     */     //   Java source line #162	-> byte code offset #248
/*     */     //   Java source line #163	-> byte code offset #253
/*     */     //   Java source line #164	-> byte code offset #258
/*     */     //   Java source line #165	-> byte code offset #269
/*     */     //   Java source line #169	-> byte code offset #279
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	280	0	this	StegoSign
/*     */     //   0	280	1	imagen	File
/*     */     //   0	280	2	restaurationData	byte[]
/*     */     //   0	280	3	destino	File
/*     */     //   0	280	4	password	String
/*     */     //   1	243	5	is	InputStream
/*     */     //   10	239	6	bos	ByteArrayOutputStream
/*     */     //   13	66	7	bytesRead	int
/*     */     //   20	49	8	data	byte[]
/*     */     //   127	43	9	res	byte[]
/*     */     //   187	13	9	e	Exception
/*     */     //   165	15	10	fos	java.io.BufferedOutputStream
/*     */     //   202	39	11	localObject	Object
/*     */     //   217	17	12	e	IOException
/*     */     //   256	17	12	e	IOException
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   22	184	187	java/lang/Exception
/*     */     //   22	202	202	finally
/*     */     //   204	214	217	java/io/IOException
/*     */     //   243	253	256	java/io/IOException
/*     */   }
/*     */   
/*     */   private byte[] getRestoreData(byte[] msg, String msgFileName, byte[] cover, byte[] pass)
/*     */     throws Exception
/*     */   {
/* 172 */     this.image = StegoUtils.byteArrayToImage(cover);
/* 173 */     if (this.image == null) {
/* 174 */       throw new Exception("No se pudo leer la imagen.");
/*     */     }
/* 176 */     this.imgWidth = this.image.getWidth();
/* 177 */     this.imgHeight = this.image.getHeight();
/* 178 */     this.fileName = msgFileName;
/*     */     
/* 180 */     this.matrizMaestra = new boolean[this.imgWidth][this.imgHeight][3][config.getMaxBitsPorCanal()];
/* 181 */     for (int i = 0; i < this.imgWidth; i++) {
/* 182 */       for (int j = 0; j < this.imgHeight; j++) {
/* 183 */         for (int k = 0; k < config.getMaxBitsPorCanal(); k++) {
/* 184 */           this.matrizMaestra[i][j][0][k] = 0;
/* 185 */           this.matrizMaestra[i][j][1][k] = 0;
/* 186 */           this.matrizMaestra[i][j][2][k] = 0;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 191 */     byte[] r = calculateHeader(msg.length, pass);
/* 192 */     byte[] data = getRestaurationBytes(msg.length);
/* 193 */     byte[] res = new byte[r.length + data.length];
/* 194 */     System.arraycopy(r, 0, res, 0, r.length);
/* 195 */     System.arraycopy(data, 0, res, r.length, data.length);
/*     */     
/* 197 */     return res;
/*     */   }
/*     */   
/*     */   private byte[] calculateHeader(int dataLength, byte[] pass) throws StegoException {
/* 201 */     int noOfPixels = this.imgWidth * this.imgHeight;
/* 202 */     int headerSize = 0;
/*     */     try {
/* 204 */       this.cabecera = new CabeceraLSB(dataLength, this.channelBitsUsed, this.fileName, config);
/* 205 */       for (headerSize = this.cabecera.getLongitudCabecera(); noOfPixels * 3 * this.channelBitsUsed / 8.0D < headerSize + dataLength;) {
/* 206 */         if (++this.channelBitsUsed > config.getMaxBitsPorCanal())
/* 207 */           throw new StegoException("Los datos no caben. Se han utilizado más bits por canal que el máximo permitido.");
/*     */       }
/* 209 */       this.cabecera.setBitsUtilizados(this.channelBitsUsed);
/*     */       
/*     */ 
/* 212 */       return getRestaurationBytes(this.cabecera.getDatosCabecera(pass).length);
/*     */     } catch (Exception ex) {
/* 214 */       throw new StegoException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private byte[] getRestaurationBytes(int b) throws IOException {
/* 219 */     return getRestaurationBytes(0, b);
/*     */   }
/*     */   
/*     */   private byte[] getRestaurationBytes(int off, int len) throws IOException {
/* 223 */     if ((off < 0) || (len <= 0) || 
/* 224 */       (off + len < 0)) {
/* 225 */       if (logger.isDebugEnabled()) {
/* 226 */         logger.debug("Posición fuera de rango");
/*     */       }
/* 228 */       throw new IndexOutOfBoundsException(); }
/* 229 */     if (len == 0) {
/* 230 */       if (logger.isDebugEnabled()) {
/* 231 */         logger.debug("Longitud de entrada nula");
/*     */       }
/* 233 */       return null; }
/* 234 */     if (this.image == null) {
/* 235 */       if (logger.isDebugEnabled()) {
/* 236 */         logger.debug("No se pudo leer la imagen de entrada");
/*     */       }
/* 238 */       return null;
/*     */     }
/* 240 */     byte[] res = new byte[len];
/* 241 */     for (int i = 0; i < len; i++) {
/* 242 */       res[i] = ((byte)getRestoreByte());
/*     */     }
/*     */     
/* 245 */     return res;
/*     */   }
/*     */   
/*     */   private int getRestoreByte() throws IOException {
/* 249 */     int x = 0;
/* 250 */     int y = 0;
/* 251 */     int channel = 0;
/* 252 */     int bit = 0;
/* 253 */     byte[] bitSet = new byte[8];
/* 254 */     for (int i = 0; i < 8; i++) {
/*     */       do {
/* 256 */         x = this.rand.nextInt(this.imgWidth);
/* 257 */         y = this.rand.nextInt(this.imgHeight);
/* 258 */         channel = this.rand.nextInt(3);
/* 259 */         bit = this.rand.nextInt(this.channelBitsUsed);
/* 260 */       } while (this.matrizMaestra[x][y][channel][bit] != 0);
/* 261 */       this.matrizMaestra[x][y][channel][bit] = 1;
/* 262 */       bitSet[i] = ((byte)getPixelBit(x, y, channel, bit));
/*     */     }
/*     */     
/* 265 */     return (bitSet[0] << 7) + (bitSet[1] << 6) + (bitSet[2] << 5) + (bitSet[3] << 4) + (bitSet[4] << 3) + (bitSet[5] << 2) + (bitSet[6] << 1) + (bitSet[7] << 0);
/*     */   }
/*     */   
/*     */   private int getPixelBit(int x, int y, int channel, int bit) {
/* 269 */     return this.image.getRGB(x, y) >> channel * 8 + bit & 0x1;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCrypt-1.1.7.jar!\es\mityc\crypto\steganography\StegoSign.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */