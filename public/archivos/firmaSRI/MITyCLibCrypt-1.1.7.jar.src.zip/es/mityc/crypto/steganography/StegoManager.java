/*     */ package es.mityc.crypto.steganography;
/*     */ 
/*     */ import es.mityc.crypto.symetric.TripleDESManager;
/*     */ import es.mityc.javasign.utils.Utils;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StegoManager
/*     */ {
/*  35 */   static Log logger = LogFactory.getLog(StegoManager.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  40 */   private StegoData sd = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public StegoManager()
/*     */   {
/*  46 */     this.sd = new StegoData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] ocultarInfo(File msgFile, File coverFile)
/*     */     throws StegoException
/*     */   {
/*  57 */     if (logger.isDebugEnabled()) {
/*  58 */       logger.debug("Insertando datos en " + coverFile);
/*     */     }
/*  60 */     InputStream is = null;
/*     */     
/*  62 */     if ((msgFile == null) || (!msgFile.exists())) {
/*  63 */       throw new StegoException(new Exception("La imagen indicada: " + msgFile.getAbsolutePath() + " no existe."));
/*     */     }
/*     */     
/*  66 */     if ((coverFile == null) || (!coverFile.exists())) {
/*  67 */       throw new StegoException(new Exception("El fichero indicado: " + coverFile.getAbsolutePath() + " no existe."));
/*     */     }
/*     */     try
/*     */     {
/*  71 */       if (msgFile != null) {
/*  72 */         is = new FileInputStream(msgFile);
/*     */       }
/*     */       
/*  75 */       return ocultarInfo(Utils.getStreamBytes(is), msgFile.getName(), 
/*  76 */         coverFile == null ? null : Utils.getFileBytes(coverFile), 
/*  77 */         coverFile == null ? null : coverFile.getAbsolutePath());
/*     */     } catch (StegoException soEx) {
/*  79 */       throw soEx;
/*     */     } catch (Exception ioEx) {
/*  81 */       logger.error(ioEx); }
/*  82 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] ocultarInfo(byte[] datos, String msgFileName, byte[] imagen, String imagenFileFormat)
/*     */     throws StegoException
/*     */   {
/*     */     try
/*     */     {
/*  98 */       if (this.sd.config.isComprimir()) {
/*     */         try {
/* 100 */           datos = StegoUtils.zipData(datos);
/*     */         } catch (Exception e) {
/* 102 */           if (logger.isDebugEnabled()) {
/* 103 */             logger.debug("Se continúa sin comprimir");
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 109 */       if (this.sd.config.isEncriptar()) {
/* 110 */         if (logger.isDebugEnabled()) {
/* 111 */           logger.debug("Encriptando " + datos.length + " bytes");
/*     */         }
/* 113 */         TripleDESManager crypto = new TripleDESManager();
/* 114 */         datos = new String(crypto.protectTripleDES(datos, this.sd.config.getPassword())).getBytes();
/*     */       }
/*     */       
/* 117 */       return this.sd.embeberDatos(datos, msgFileName, imagen, imagenFileFormat, this.sd.config.getPassword());
/*     */     } catch (StegoException osEx) {
/* 119 */       logger.error(osEx);
/* 120 */       throw osEx;
/*     */     } catch (Exception ex) {
/* 122 */       logger.error(ex); }
/* 123 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Object> extraerDatos(byte[] stegoData)
/*     */   {
/* 133 */     byte[] msg = null;
/* 134 */     List<Object> output = new ArrayList();
/*     */     try
/*     */     {
/* 137 */       if (logger.isDebugEnabled()) {
/* 138 */         logger.debug("Extrayendo datos: ");
/*     */       }
/*     */       
/*     */ 
/* 142 */       msg = this.sd.extraerDatos(stegoData, this.sd.config.getPassword());
/*     */       
/*     */ 
/* 145 */       output.add(this.sd.getStegoFileName());
/*     */       
/*     */ 
/* 148 */       if (this.sd.config.isEncriptar()) {
/* 149 */         if (logger.isDebugEnabled()) {
/* 150 */           logger.debug("Desencriptando " + msg.length + " bytes");
/*     */         }
/* 152 */         TripleDESManager crypto = new TripleDESManager();
/* 153 */         msg = crypto.recoverTripleDES(new String(msg).toCharArray(), this.sd.config.getPassword());
/*     */       }
/*     */       
/*     */ 
/* 157 */       if (this.sd.config.isComprimir()) {
/*     */         try {
/* 159 */           msg = StegoUtils.unzipData(msg);
/*     */         } catch (IOException ioEx) {
/* 161 */           logger.error("No se inflaron los datos");
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 166 */       output.add(msg);
/*     */     } catch (StegoException osEx) {
/* 168 */       logger.debug(osEx);
/*     */     } catch (IndexOutOfBoundsException ex) {
/* 170 */       if (msg.length == 0) {
/* 171 */         logger.warn("La imagen no contiene datos");
/*     */       } else {
/* 173 */         logger.error(ex);
/*     */       }
/*     */     } catch (Exception ex) {
/* 176 */       logger.debug(ex);
/*     */     }
/*     */     
/* 179 */     return output;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Object> extraerDatos(File stegoFile)
/*     */     throws IOException
/*     */   {
/* 188 */     return extraerDatos(Utils.getFileBytes(stegoFile));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPassword(String password)
/*     */   {
/* 195 */     this.sd.config.setEncriptar(true);
/* 196 */     this.sd.config.setPassword(password);
/* 197 */     if (logger.isDebugEnabled()) {
/* 198 */       logger.debug("Contraseña establecida");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setComprimir(boolean f)
/*     */   {
/* 206 */     this.sd.config.setComprimir(f);
/* 207 */     if (logger.isDebugEnabled()) {
/* 208 */       logger.debug("Uso de compresión: " + f);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/* 213 */     StegoManager ssg = new StegoManager();
/* 214 */     ssg.setPassword("Caracola");
/* 215 */     ssg.setComprimir(true);
/*     */     try {
/* 217 */       byte[] stego = ssg.ocultarInfo(new File("resources/DocumentoA.pdf"), new File("resources/imagen.png"));
/*     */       
/* 219 */       Utils.writeFile(stego, "./Steganografriado.png");
/* 220 */       List<Object> lista = ssg.extraerDatos(new File("./Steganografriado.png"));
/* 221 */       Utils.writeFile((byte[])lista.get(1), new String((byte[])lista.get(0)));
/*     */     } catch (IOException e) {
/* 223 */       e.printStackTrace();
/*     */     } catch (StegoException e) {
/* 225 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCrypt-1.1.7.jar!\es\mityc\crypto\steganography\StegoManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */