/*     */ package es.mityc.crypto.steganography;
/*     */ 
/*     */ import es.mityc.crypto.Utils;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.IndexColorModel;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Random;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StegoData
/*     */ {
/*  40 */   static Log logger = LogFactory.getLog(StegoData.class);
/*     */   
/*  42 */   private BufferedImage image = null;
/*     */   
/*  44 */   private Random rand = null;
/*     */   
/*     */   private static final int BUF_SIZE = 512;
/*  47 */   private int imgWidth = 0;
/*  48 */   private int imgHeight = 0;
/*  49 */   private int channelBitsUsed = 1;
/*  50 */   private CabeceraLSB header = null;
/*     */   
/*     */   private boolean[][][][] matrizMaestra;
/*     */   
/*     */   private int[][] matrizDebug;
/*     */   
/*  56 */   private BufferedImage imageDebug = null;
/*     */   
/*  58 */   protected StegoConfig config = null;
/*     */   
/*     */   public StegoData() {
/*  61 */     this.config = new StegoConfig();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] extraerDatos(File imagen, String password)
/*     */     throws Exception
/*     */   {
/*  74 */     InputStream is = null;
/*  75 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*  76 */     int bytesRead = 0;
/*  77 */     byte[] data = new byte['Ȁ'];
/*     */     try {
/*  79 */       if (logger.isDebugEnabled()) {
/*  80 */         logger.debug("Leyendo imagen estaganografiada");
/*     */       }
/*  82 */       is = new FileInputStream(imagen);
/*  83 */       while ((bytesRead = is.read(data, 0, 512)) >= 0) {
/*  84 */         bos.write(data, 0, bytesRead);
/*     */       }
/*     */       
/*  87 */       return bos.toByteArray();
/*     */     } catch (Exception e) {
/*  89 */       logger.error(e);
/*  90 */       throw e;
/*     */     } finally {
/*     */       try {
/*  93 */         is.close();
/*  94 */         bos.close();
/*     */       } catch (IOException e) {
/*  96 */         if (logger.isDebugEnabled()) {
/*  97 */           logger.debug(e);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public byte[] extraerDatos(byte[] img, String password) throws Exception {
/* 104 */     this.rand = new Random(StegoUtils.hashPassLong(password));
/* 105 */     if (logger.isDebugEnabled()) {
/* 106 */       logger.debug("Extrayendo datos");
/*     */     }
/* 108 */     this.header = new CabeceraLSB();
/* 109 */     return getEmbeddedData(img, password != null ? password.getBytes() : null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getStegoFileName()
/*     */   {
/* 120 */     return this.header.getFileName().getBytes();
/*     */   }
/*     */   
/*     */   private byte[] getEmbeddedData(byte[] cover, byte[] password) throws Exception {
/* 124 */     this.image = StegoUtils.byteArrayToImage(cover);
/* 125 */     if (this.image == null) {
/* 126 */       throw new Exception("No se pudo leer la imagen.");
/*     */     }
/*     */     
/* 129 */     this.imgWidth = this.image.getWidth();
/* 130 */     this.imgHeight = this.image.getHeight();
/*     */     
/* 132 */     this.matrizMaestra = new boolean[this.imgWidth][this.imgHeight][3][this.config.getMaxBitsPorCanal()];
/* 133 */     for (int i = 0; i < this.imgWidth; i++) {
/* 134 */       for (int j = 0; j < this.imgHeight; j++) {
/* 135 */         for (int k = 0; k < this.config.getMaxBitsPorCanal(); k++) {
/* 136 */           this.matrizMaestra[i][j][0][k] = 0;
/* 137 */           this.matrizMaestra[i][j][1][k] = 0;
/* 138 */           this.matrizMaestra[i][j][2][k] = 0;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 143 */     return getBytes(cover, password);
/*     */   }
/*     */   
/*     */   private byte[] getBytes(byte[] b, byte[] pass) throws IOException {
/* 147 */     return getBytes(b, 0, pass);
/*     */   }
/*     */   
/*     */   private byte[] getBytes(byte[] b, int off, byte[] password) throws IOException {
/* 151 */     if (b == null) {
/* 152 */       if (logger.isDebugEnabled()) {
/* 153 */         logger.debug("Byte de entrada nulo");
/*     */       }
/* 155 */       throw new NullPointerException(); }
/* 156 */     if ((off < 0) || (off > b.length)) {
/* 157 */       if (logger.isDebugEnabled()) {
/* 158 */         logger.debug("Posición fuera de rango");
/*     */       }
/* 160 */       throw new IndexOutOfBoundsException(); }
/* 161 */     if (this.image == null) {
/* 162 */       if (logger.isDebugEnabled()) {
/* 163 */         logger.debug("No se pudo leer la imagen de entrada");
/*     */       }
/* 165 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 169 */     ByteArrayInputStream bais = null;
/*     */     try {
/* 171 */       boolean founded = false;
/* 172 */       int i = 0;
/*     */       
/*     */ 
/* 175 */       int cabeceraLength = CabeceraLSB.SELLO.length + 8;
/*     */       
/* 177 */       byte[] res = null;
/* 178 */       byte[] stamp = new byte[CabeceraLSB.SELLO.length];
/*     */       
/*     */ 
/* 181 */       for (int j = 1; j < this.config.getMaxBitsPorCanal(); j++)
/*     */       {
/* 183 */         this.rand = new Random(StegoUtils.hashPassLong(password != null ? new String(password) : null));
/* 184 */         this.matrizMaestra = new boolean[this.imgWidth][this.imgHeight][3][this.config.getMaxBitsPorCanal()];
/* 185 */         for (int k = 0; k < this.imgWidth; k++) {
/* 186 */           for (int h = 0; h < this.imgHeight; h++) {
/* 187 */             for (int l = 0; l < this.config.getMaxBitsPorCanal(); l++) {
/* 188 */               this.matrizMaestra[k][h][0][l] = 0;
/* 189 */               this.matrizMaestra[k][h][1][l] = 0;
/* 190 */               this.matrizMaestra[k][h][2][l] = 0;
/*     */             }
/*     */           }
/*     */         }
/* 194 */         i = 0;
/*     */         
/* 196 */         this.channelBitsUsed = j;
/*     */         
/* 198 */         res = new byte[cabeceraLength];
/* 199 */         for (; i < cabeceraLength; i++) {
/* 200 */           res[i] = ((byte)getPixelByte(b[(off + i)]));
/*     */         }
/* 202 */         bais = new ByteArrayInputStream(res);
/*     */         
/*     */ 
/* 205 */         bais.read(stamp, 0, CabeceraLSB.SELLO.length);
/* 206 */         if (!new String(stamp).equals(new String(CabeceraLSB.SELLO)))
/*     */         {
/* 208 */           if ((password != null) && (password.length > 0)) {
/* 209 */             String msg = Utils.undoObfuscate(stamp, StegoUtils.hashPassLong(new String(password)));
/* 210 */             if (new String(msg).equals(new String(CabeceraLSB.SELLO))) {
/* 211 */               founded = true;
/* 212 */               break;
/*     */             }
/*     */           }
/*     */         } else {
/* 216 */           founded = true;
/* 217 */           break;
/*     */         }
/*     */       }
/*     */       
/* 221 */       if (!founded) {
/* 222 */         throw new StegoException("No se encuentra la cabecera");
/*     */       }
/*     */       
/*     */ 
/* 226 */       byte[] headerBytes = new byte[8];
/* 227 */       bais.read(headerBytes, 0, 8);
/* 228 */       int dataLength = StegoUtils.byteToInt(headerBytes[0]) + (StegoUtils.byteToInt(headerBytes[1]) << 8) + (
/* 229 */         StegoUtils.byteToInt(headerBytes[2]) << 16) + (StegoUtils.byteToInt(headerBytes[3]) << 32);
/* 230 */       int fileNameLen = headerBytes[5];
/* 231 */       this.config.setComprimir(headerBytes[6] == 1);
/* 232 */       this.config.setEncriptar(headerBytes[7] == 1);
/*     */       
/*     */ 
/* 235 */       res = new byte[fileNameLen];
/* 236 */       cabeceraLength = fileNameLen + cabeceraLength;
/* 237 */       for (int j = 0; i < cabeceraLength; i++) {
/* 238 */         res[j] = ((byte)getPixelByte(b[(off + i)]));
/* 239 */         j++;
/*     */       }
/*     */       
/* 242 */       if ((password != null) && (password.length > 0)) {
/* 243 */         if (logger.isDebugEnabled()) {
/* 244 */           logger.debug("Desencriptando " + stamp.length + " bytes");
/*     */         }
/*     */         try {
/* 247 */           res = Utils.undoObfuscate(res, StegoUtils.hashPassLong(new String(password))).getBytes();
/*     */         } catch (Exception e) {
/* 249 */           logger.error(e);
/*     */         }
/*     */       }
/* 252 */       this.header.setFileName(res);
/*     */       
/*     */ 
/* 255 */       if ((dataLength == 0) || (dataLength > b.length)) {
/* 256 */         if (logger.isDebugEnabled()) {
/* 257 */           logger.debug("Longitud de entrada nula o fuera de rango");
/*     */         }
/* 259 */         return null;
/*     */       }
/* 261 */       res = new byte[dataLength];
/* 262 */       dataLength += cabeceraLength;
/* 263 */       for (int j = 0; i < dataLength; i++) {
/* 264 */         res[j] = ((byte)getPixelByte(b[(off + i)]));
/* 265 */         j++;
/*     */       }
/*     */       
/* 268 */       return res;
/*     */     } catch (Exception e) {
/* 270 */       logger.error(e);
/* 271 */       throw new IOException(e);
/*     */     } finally {
/*     */       try {
/* 274 */         bais.close();
/*     */       } catch (IOException e) {
/* 276 */         if (logger.isDebugEnabled()) {
/* 277 */           logger.debug(e);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private int getPixelByte(int data) throws IOException {
/* 284 */     int x = 0;
/* 285 */     int y = 0;
/* 286 */     int channel = 0;
/* 287 */     int bit = 0;
/* 288 */     byte[] bitSet = new byte[8];
/* 289 */     for (int i = 0; i < 8; i++) {
/*     */       do {
/* 291 */         x = this.rand.nextInt(this.imgWidth);
/* 292 */         y = this.rand.nextInt(this.imgHeight);
/* 293 */         channel = this.rand.nextInt(3);
/* 294 */         bit = this.rand.nextInt(this.channelBitsUsed);
/* 295 */       } while (this.matrizMaestra[x][y][channel][bit] != 0);
/* 296 */       this.matrizMaestra[x][y][channel][bit] = 1;
/* 297 */       bitSet[i] = ((byte)getPixelBit(x, y, channel, bit));
/*     */     }
/*     */     
/* 300 */     return (bitSet[0] << 7) + (bitSet[1] << 6) + (bitSet[2] << 5) + (bitSet[3] << 4) + (bitSet[4] << 3) + (bitSet[5] << 2) + (bitSet[6] << 1) + (bitSet[7] << 0);
/*     */   }
/*     */   
/*     */   private int getPixelBit(int x, int y, int channel, int bit) {
/* 304 */     return this.image.getRGB(x, y) >> channel * 8 + bit & 0x1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] embeberDatos(byte[] datos, String nombreDatos, byte[] img, String pathImg, String password)
/*     */     throws StegoException
/*     */   {
/* 319 */     this.rand = new Random(StegoUtils.hashPassLong(password));
/*     */     try {
/* 321 */       this.image = StegoUtils.byteArrayToImage(img);
/*     */       
/* 323 */       this.imgWidth = this.image.getWidth();
/* 324 */       this.imgHeight = this.image.getHeight();
/*     */       
/* 326 */       if (logger.isDebugEnabled()) {
/* 327 */         this.imageDebug = StegoUtils.byteArrayToImage(img);
/*     */       }
/*     */     } catch (Exception e) {
/* 330 */       logger.error("No se pudo leer la imagen indicada", e);
/* 331 */       throw new StegoException(e);
/*     */     }
/*     */     
/* 334 */     if ((this.image.getColorModel() instanceof IndexColorModel)) {
/* 335 */       logger.error("No se pueden utilizar imagenes con colores indexados");
/* 336 */       throw new StegoException("No se pueden utilizar imagenes con colores indexados");
/*     */     }
/* 338 */     inicializar();
/*     */     try
/*     */     {
/* 341 */       if (nombreDatos != null) {
/* 342 */         write(crearCabecera(datos.length, nombreDatos, password != null ? password.getBytes() : null));
/*     */       } else {
/* 344 */         int noOfPixels = this.imgWidth * this.imgHeight;
/* 345 */         int dataLength = datos.length;
/* 346 */         while (noOfPixels * 3 * this.channelBitsUsed / 8.0D < dataLength) {
/* 347 */           if (++this.channelBitsUsed > this.config.getMaxBitsPorCanal())
/* 348 */             throw new StegoException("Datos demasiado grandes para embeber");
/*     */         }
/*     */       }
/* 351 */       write(datos);
/*     */       
/*     */ 
/*     */ 
/* 355 */       String formatoDestino = pathImg.substring(pathImg.lastIndexOf('.') + 1);
/* 356 */       return StegoUtils.imageToByteArray(this.image, formatoDestino);
/*     */     } catch (StegoException soEx) {
/* 358 */       throw soEx;
/*     */     } catch (Exception e) {
/* 360 */       logger.error("No se pudo embeber los datos en la imagen indicada", e);
/* 361 */       throw new StegoException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   private byte[] crearCabecera(int dataLength, String fileName, byte[] pass) throws StegoException {
/* 366 */     int noOfPixels = this.imgWidth * this.imgHeight;
/* 367 */     int headerSize = 0;
/*     */     try {
/* 369 */       this.header = new CabeceraLSB(dataLength, this.channelBitsUsed, fileName, this.config);
/* 370 */       for (headerSize = this.header.getLongitudCabecera(); noOfPixels * 3 * this.channelBitsUsed / 8.0D < headerSize + dataLength;) {
/* 371 */         if (++this.channelBitsUsed > this.config.getMaxBitsPorCanal())
/* 372 */           throw new StegoException("Datos demasiado grandes para embeber");
/*     */       }
/* 374 */       this.header.setBitsUtilizados(this.channelBitsUsed);
/*     */       
/*     */ 
/* 377 */       return this.header.getDatosCabecera(pass);
/*     */     } catch (StegoException soEx) {
/* 379 */       throw soEx;
/*     */     } catch (Exception ex) {
/* 381 */       throw new StegoException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private void inicializar() throws StegoException {
/* 386 */     this.matrizMaestra = new boolean[this.imgWidth][this.imgHeight][3][this.config.getMaxBitsPorCanal()];
/* 387 */     for (int i = 0; i < this.imgWidth; i++) {
/* 388 */       for (int j = 0; j < this.imgHeight; j++) {
/* 389 */         for (int k = 0; k < this.channelBitsUsed; k++) {
/* 390 */           this.matrizMaestra[i][j][0][k] = 0;
/* 391 */           this.matrizMaestra[i][j][1][k] = 0;
/* 392 */           this.matrizMaestra[i][j][2][k] = 0;
/*     */         }
/*     */       }
/*     */     }
/* 396 */     if (logger.isDebugEnabled()) {
/* 397 */       this.matrizDebug = new int[this.imgWidth][this.imgHeight];
/* 398 */       for (int i = 0; i < this.imgWidth; i++) {
/* 399 */         for (int j = 0; j < this.imgHeight; j++) {
/* 400 */           this.matrizDebug[i][j] = 0;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void write(byte[] b) throws IOException {
/* 407 */     write(b, 0, b.length);
/*     */   }
/*     */   
/*     */   private void write(byte[] b, int off, int len) throws IOException {
/* 411 */     if (b == null) {
/* 412 */       if (logger.isDebugEnabled()) {
/* 413 */         logger.debug("Byte de entrada nulo");
/*     */       }
/* 415 */       throw new NullPointerException(); }
/* 416 */     if ((off < 0) || (off > b.length) || (len < 0) || 
/* 417 */       (off + len > b.length) || (off + len < 0)) {
/* 418 */       if (logger.isDebugEnabled()) {
/* 419 */         logger.debug("Posición fuera de rango");
/*     */       }
/* 421 */       throw new IndexOutOfBoundsException(); }
/* 422 */     if (len == 0) {
/* 423 */       if (logger.isDebugEnabled()) {
/* 424 */         logger.debug("Longitud de entrada nula");
/*     */       }
/* 426 */       return; }
/* 427 */     if (this.image == null) {
/* 428 */       if (logger.isDebugEnabled()) {
/* 429 */         logger.debug("No se pudo leer la imagen de entrada");
/*     */       }
/* 431 */       return;
/*     */     }
/*     */     
/* 434 */     for (int i = 0; i < len; i++) {
/* 435 */       write(b[(off + i)]);
/*     */     }
/*     */   }
/*     */   
/*     */   private void write(int data) throws IOException {
/* 440 */     boolean bitValue = false;
/* 441 */     int x = 0;
/* 442 */     int y = 0;
/* 443 */     int channel = 0;
/* 444 */     int bit = 0;
/* 445 */     for (int i = 0; i < 8; i++) {
/* 446 */       bitValue = (data >> 7 - i & 0x1) == 1;
/*     */       do {
/* 448 */         x = this.rand.nextInt(this.imgWidth);
/* 449 */         y = this.rand.nextInt(this.imgHeight);
/* 450 */         channel = this.rand.nextInt(3);
/* 451 */         bit = this.rand.nextInt(this.channelBitsUsed);
/* 452 */       } while (this.matrizMaestra[x][y][channel][bit] != 0);
/* 453 */       this.matrizMaestra[x][y][channel][bit] = 1;
/* 454 */       setPixelBit(x, y, channel, bit, bitValue);
/*     */     }
/*     */   }
/*     */   
/*     */   private void setPixelBit(int x, int y, int channel, int bit, boolean bitValue) {
/* 459 */     int pixel = 0;
/* 460 */     int newPixel = 0;
/* 461 */     pixel = this.image.getRGB(x, y);
/* 462 */     if (bitValue) {
/* 463 */       newPixel = pixel | 1 << bit + channel * 8;
/*     */     } else {
/* 465 */       int newColor = -2;
/* 466 */       for (int i = 0; i < bit + channel * 8; i++) {
/* 467 */         newColor = newColor << 1 | 0x1;
/*     */       }
/* 469 */       newPixel = pixel & newColor;
/*     */     }
/*     */     
/* 472 */     this.image.setRGB(x, y, newPixel);
/* 473 */     if ((logger.isDebugEnabled()) && 
/* 474 */       (this.imageDebug != null)) {
/* 475 */       if (this.imageDebug.getRGB(x, y) != newPixel) {
/* 476 */         this.matrizDebug[x][y] = newPixel;
/* 477 */       } else if (this.matrizDebug[x][y] != 0) {
/* 478 */         this.matrizDebug[x][y] = 0;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCrypt-1.1.7.jar!\es\mityc\crypto\steganography\StegoData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */