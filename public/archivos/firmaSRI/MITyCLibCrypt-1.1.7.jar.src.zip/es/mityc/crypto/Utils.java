/*     */ package es.mityc.crypto;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Utils
/*     */ {
/*  27 */   private static Log logger = LogFactory.getLog(Utils.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String obfuscate(String enClaro)
/*     */     throws SecurityException
/*     */   {
/*  35 */     return obfuscate(enClaro, 0L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String obfuscate(String enClaro, long pass)
/*     */     throws SecurityException
/*     */   {
/*  45 */     StringBuffer bufer = new StringBuffer(enClaro).reverse();
/*     */     byte[] arr;
/*     */     try {
/*  48 */       arr = bufer.toString().getBytes("ASCII");
/*     */     } catch (Exception e) { byte[] arr;
/*  50 */       arr = bufer.toString().getBytes();
/*     */     }
/*  52 */     StringBuffer resultado = new StringBuffer();
/*     */     
/*  54 */     pass = pass / 101L % 997L;
/*     */     
/*  56 */     long aumento = bufer.length() * (13L + pass);
/*     */     
/*  58 */     for (int x = 0; x < bufer.length(); x++) {
/*  59 */       int ascii = arr[x];
/*  60 */       if (ascii < 0) {
/*  61 */         throw new SecurityException("El caracter leído no es de tipo ASCII --> " + arr[x]);
/*     */       }
/*  63 */       ascii = (int)((ascii + aumento) % 92L) + 34;
/*  64 */       if ((32 >= ascii) && (ascii >= 130)) {
/*  65 */         throw new SecurityException("Error al encriptar la posición: " + (bufer.length() - x) + " Letra en claro: " + (char)arr[x]);
/*     */       }
/*  67 */       if (61 == ascii)
/*  68 */         ascii = 33;
/*  69 */       aumento += (x + 2) * (13L + pass);
/*  70 */       char ascitotext = (char)ascii;
/*  71 */       resultado.append(ascitotext);
/*     */     }
/*     */     
/*  74 */     return resultado.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String undoObfuscate(byte[] codigo)
/*     */     throws SecurityException
/*     */   {
/*  84 */     return undoObfuscate(codigo, 0L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String undoObfuscate(byte[] codigo, long pass)
/*     */     throws SecurityException
/*     */   {
/*  94 */     StringBuffer resultado = new StringBuffer();
/*     */     
/*  96 */     pass = pass / 101L % 997L;
/*     */     
/*  98 */     long decremento = codigo.length * (13L + pass);
/*     */     
/* 100 */     for (int x = 0; x < codigo.length; x++) {
/* 101 */       int ascii = codigo[x];
/* 102 */       if (33 == ascii)
/* 103 */         ascii = 61;
/* 104 */       int ret = 0;
/* 105 */       ascii -= 34;
/*     */       
/* 107 */       for (int y = 31; (y < 200) && (ascii != (y + decremento) % 92L); y++) {
/* 108 */         ret = y + 1;
/*     */       }
/* 110 */       decremento += (x + 2) * (13L + pass);
/* 111 */       if (ret >= 128) {
/* 112 */         throw new SecurityException("El caracter leído no es de tipo ASCII --> " + ret);
/*     */       }
/* 114 */       char ascitotext = (char)ret;
/* 115 */       resultado.append(ascitotext);
/*     */     }
/* 117 */     resultado.reverse();
/* 118 */     return resultado.toString();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCrypt-1.1.7.jar!\es\mityc\crypto\Utils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */