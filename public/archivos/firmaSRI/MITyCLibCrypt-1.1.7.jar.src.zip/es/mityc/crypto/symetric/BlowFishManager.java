/*     */ package es.mityc.crypto.symetric;
/*     */ 
/*     */ import es.mityc.crypto.CryptoManager;
/*     */ import es.mityc.javasign.utils.Base64Coder;
/*     */ import java.io.PrintStream;
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.Security;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import javax.crypto.BadPaddingException;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.IllegalBlockSizeException;
/*     */ import javax.crypto.NoSuchPaddingException;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.SecretKeyFactory;
/*     */ import javax.crypto.spec.PBEKeySpec;
/*     */ import javax.crypto.spec.PBEParameterSpec;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlowFishManager
/*     */   implements CryptoManager
/*     */ {
/*  49 */   static Log logger = LogFactory.getLog(DESCipherManager.class);
/*     */   
/*     */ 
/*  52 */   private byte[] salt = null;
/*     */   
/*     */ 
/*  55 */   private int iter = 64;
/*     */   
/*     */ 
/*  58 */   private Cipher desCipher = null;
/*     */   
/*     */ 
/*  61 */   private SecretKeyFactory skfDes = null;
/*     */   
/*     */   public BlowFishManager() {
/*  64 */     init(null, 0);
/*     */   }
/*     */   
/*     */   public BlowFishManager(byte[] salt, int iter) {
/*  68 */     init(salt, iter);
/*     */   }
/*     */   
/*     */   public void feedSeed(byte[] seed) {
/*  72 */     if (seed == null) {
/*  73 */       seed = SecureRandom.getSeed(8);
/*     */     }
/*  75 */     for (int i = 0; (i < this.salt.length) && (i < seed.length); i++) {
/*  76 */       this.salt[i] = ((byte)(this.salt[i] & seed[i]));
/*     */     }
/*     */   }
/*     */   
/*     */   private void init(byte[] salt, int iter)
/*     */   {
/*  82 */     if (salt != null) {
/*  83 */       this.salt = salt;
/*     */     } else {
/*  85 */       this.salt = SecureRandom.getSeed(8);
/*     */     }
/*     */     
/*  88 */     if (iter != 0) {
/*  89 */       this.iter = iter;
/*     */     }
/*     */     
/*     */ 
/*  93 */     if (Security.getProvider("BC") == null) {
/*  94 */       es.mityc.javasign.utils.Utils.addBCProvider();
/*     */     }
/*     */     try
/*     */     {
/*  98 */       this.desCipher = Cipher.getInstance("Blowfish");
/*     */       
/* 100 */       this.skfDes = SecretKeyFactory.getInstance("Blowfish/CFB64/NoPadding");
/*     */     } catch (NoSuchPaddingException ex) {
/* 102 */       throw new SecurityException(ex);
/*     */     } catch (NoSuchAlgorithmException ex) {
/* 104 */       throw new SecurityException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] protectPBEandDES(String plain, String password)
/*     */     throws SecurityException
/*     */   {
/* 116 */     if ((password == null) || ("".equals(new String(password).trim())) || (plain == null))
/* 117 */       throw new SecurityException("Faltan parámetros de entrada");
/* 118 */     if (password.length() < 8) {
/* 119 */       logger.warn("La clave debe tener al menos 8 bytes. Se emplea su valor SHA1 como contraseña.");
/*     */       try {
/* 121 */         MessageDigest hash = MessageDigest.getInstance("SHA1", "BC");
/* 122 */         password = new String(hash.digest(password.getBytes()));
/*     */       } catch (NoSuchAlgorithmException e) {
/* 124 */         throw new SecurityException("Error al calcular el Digest de la contraseña", e);
/*     */       } catch (NoSuchProviderException e) {
/* 126 */         throw new SecurityException("Error al calcular el Digest de la contraseña", e);
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 132 */       PBEParameterSpec pbeParamSpec = new PBEParameterSpec(this.salt, this.iter);
/*     */       
/*     */ 
/* 135 */       SecretKey pbeKey = this.skfDes.generateSecret(new PBEKeySpec(password.toCharArray()));
/*     */       
/*     */ 
/* 138 */       this.desCipher.init(1, pbeKey, pbeParamSpec);
/*     */       
/*     */ 
/* 141 */       byte[] plainProps = plain.getBytes();
/*     */       
/*     */ 
/* 144 */       byte[] ciphertext = this.desCipher.doFinal(plainProps);
/*     */       
/* 146 */       return Base64Coder.encode(ciphertext);
/*     */     } catch (InvalidKeySpecException ex) {
/* 148 */       throw new SecurityException(ex);
/*     */     } catch (InvalidKeyException ex) {
/* 150 */       throw new SecurityException(ex);
/*     */     } catch (InvalidAlgorithmParameterException ex) {
/* 152 */       throw new SecurityException(ex);
/*     */     } catch (IllegalBlockSizeException ex) {
/* 154 */       throw new SecurityException(ex);
/*     */     } catch (BadPaddingException ex) {
/* 156 */       throw new SecurityException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] recoverPBEandDES(char[] cryptedText, String password)
/*     */     throws SecurityException
/*     */   {
/* 168 */     if ((password == null) || ("".equals(new String(password).trim())) || (cryptedText == null))
/* 169 */       throw new SecurityException("Faltan parámetros de entrada");
/* 170 */     if (password.length() < 8) {
/* 171 */       logger.warn("La clave debe tener al menos 8 bytes. Se emplea su valor SHA1 como contraseña.");
/*     */       try {
/* 173 */         MessageDigest hash = MessageDigest.getInstance("SHA1", "BC");
/* 174 */         password = new String(hash.digest(password.getBytes()));
/*     */       } catch (NoSuchAlgorithmException e) {
/* 176 */         throw new SecurityException("Error al calcular el Digest de la contraseña", e);
/*     */       } catch (NoSuchProviderException e) {
/* 178 */         throw new SecurityException("Error al calcular el Digest de la contraseña", e);
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 184 */       PBEParameterSpec pbeParamSpec = new PBEParameterSpec(this.salt, this.iter);
/*     */       
/*     */ 
/* 187 */       SecretKey pbeKey = this.skfDes.generateSecret(new PBEKeySpec(password.toCharArray()));
/*     */       
/*     */ 
/* 190 */       this.desCipher.init(2, pbeKey, pbeParamSpec);
/*     */       
/*     */ 
/* 193 */       return this.desCipher.doFinal(Base64Coder.decode(cryptedText));
/*     */     }
/*     */     catch (InvalidKeySpecException ex)
/*     */     {
/* 197 */       throw new SecurityException(ex);
/*     */     } catch (InvalidKeyException ex) {
/* 199 */       throw new SecurityException(ex);
/*     */     } catch (InvalidAlgorithmParameterException ex) {
/* 201 */       throw new SecurityException(ex);
/*     */     } catch (IllegalBlockSizeException ex) {
/* 203 */       throw new SecurityException(ex);
/*     */     } catch (BadPaddingException ex) {
/* 205 */       throw new SecurityException("Contraseña incorrecta", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getUsedAlgorithmURI() {
/* 210 */     return this.desCipher.getAlgorithm();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 217 */     String plain = "TextoEnClaro012456789";
/* 218 */     String pass = "1234567890123456789012345678901234567890";
/* 219 */     DESCipherManager p = new DESCipherManager();
/* 220 */     System.out.println("Texto en claro: " + plain);
/* 221 */     String buffer = es.mityc.crypto.Utils.obfuscate(plain);
/* 222 */     System.out.println("Texto ofuscado: " + buffer);
/* 223 */     buffer = es.mityc.crypto.Utils.undoObfuscate(buffer.getBytes());
/* 224 */     System.out.println("Texto recuperado: " + buffer);
/* 225 */     char[] bufferChar = p.protectPBEandDES(buffer, pass);
/* 226 */     buffer = new String(bufferChar);
/* 227 */     System.out.println("Texto encriptado PBEandDES: " + buffer);
/* 228 */     buffer = new String(p.recoverPBEandDES(bufferChar, pass));
/* 229 */     System.out.println("Texto desencriptado PBEandDES: " + buffer);
/*     */     
/* 231 */     Long start = Long.valueOf(System.currentTimeMillis());
/* 232 */     buffer = es.mityc.crypto.Utils.obfuscate(new String(p.protectPBEandDES(buffer, pass)));
/* 233 */     System.out.println("Encriptado PBEandDES y ofuscado: " + buffer);
/* 234 */     buffer = new String(p.recoverPBEandDES(es.mityc.crypto.Utils.undoObfuscate(buffer.getBytes()).toCharArray(), pass));
/* 235 */     Long time = Long.valueOf(System.currentTimeMillis() - start.longValue());
/* 236 */     System.out.println("Texto recuperado: " + buffer + "\nTiempo consumido (ms): " + time);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCrypt-1.1.7.jar!\es\mityc\crypto\symetric\BlowFishManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */