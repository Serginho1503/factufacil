/*     */ package es.mityc.crypto.symetric;
/*     */ 
/*     */ import es.mityc.crypto.CryptoManager;
/*     */ import es.mityc.javasign.utils.Base64Coder;
/*     */ import java.io.PrintStream;
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.Security;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import javax.crypto.BadPaddingException;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.IllegalBlockSizeException;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.SecretKeyFactory;
/*     */ import javax.crypto.spec.PBEKeySpec;
/*     */ import javax.crypto.spec.PBEParameterSpec;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AESCipherManager
/*     */   implements CryptoManager
/*     */ {
/*  49 */   static Log logger = LogFactory.getLog(AESCipherManager.class);
/*     */   
/*     */ 
/*  52 */   private byte[] salt = null;
/*     */   
/*     */ 
/*  55 */   private int iter = 0;
/*     */   
/*     */ 
/*  58 */   private Cipher aesCipher = null;
/*     */   
/*     */ 
/*  61 */   private SecretKeyFactory skfAes = null;
/*     */   
/*     */   public AESCipherManager() {
/*  64 */     init(null, 0);
/*     */   }
/*     */   
/*     */   public AESCipherManager(byte[] salt, int iter) {
/*  68 */     init(salt, iter);
/*     */   }
/*     */   
/*     */   public void feedSeed(byte[] seed) {
/*  72 */     if (seed == null) {
/*  73 */       seed = SecureRandom.getSeed(8);
/*     */     }
/*  75 */     for (int i = 0; (i < this.salt.length) && (i < seed.length); i++) {
/*  76 */       this.salt[i] = ((byte)(this.salt[i] & seed[i]));
/*     */     }
/*     */   }
/*     */   
/*     */   private void init(byte[] salt, int iter)
/*     */   {
/*  82 */     if (salt != null) {
/*  83 */       feedSeed(salt);
/*     */     } else {
/*  85 */       this.salt = SecureRandom.getSeed(8);
/*     */     }
/*     */     
/*  88 */     if (iter != 0) {
/*  89 */       this.iter = iter;
/*     */     } else {
/*  91 */       this.iter = 256;
/*     */     }
/*     */     
/*     */ 
/*  95 */     if (Security.getProvider("BC") == null) {
/*  96 */       es.mityc.javasign.utils.Utils.addBCProvider();
/*     */     }
/*     */     try
/*     */     {
/* 100 */       this.aesCipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
/*     */       
/* 102 */       this.skfAes = SecretKeyFactory.getInstance("PBEWithSHA256And256BitAES-CBC-BC", "BC");
/*     */     } catch (Exception ex) {
/* 104 */       throw new SecurityException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public char[] protectAES(String plain, String password) throws SecurityException {
/* 109 */     if ((password == null) || ("".equals(new String(password).trim())) || (plain == null)) {
/* 110 */       throw new SecurityException("Faltan parámetros de entrada");
/*     */     }
/*     */     
/* 113 */     return protectAES(plain.getBytes(), password);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] protectAES(byte[] plain, String password)
/*     */     throws SecurityException
/*     */   {
/* 124 */     if ((password == null) || ("".equals(new String(password).trim())) || (plain == null))
/* 125 */       throw new SecurityException("Faltan parámetros de entrada");
/* 126 */     if (password.length() < 8) {
/* 127 */       logger.warn("La clave debe tener al menos 8 bytes. Se emplea su valor SHA1 como contraseña.");
/*     */       try {
/* 129 */         MessageDigest hash = MessageDigest.getInstance("SHA1", "BC");
/* 130 */         password = new String(hash.digest(password.getBytes()));
/*     */       } catch (NoSuchAlgorithmException e) {
/* 132 */         throw new SecurityException("Error al calcular el Digest de la contraseña", e);
/*     */       } catch (NoSuchProviderException e) {
/* 134 */         throw new SecurityException("Error al calcular el Digest de la contraseña", e);
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 140 */       SecretKey pbeKey = this.skfAes.generateSecret(new PBEKeySpec(password.toCharArray(), this.salt, this.iter));
/* 141 */       SecretKey secret = new SecretKeySpec(pbeKey.getEncoded(), "AES");
/*     */       
/*     */ 
/* 144 */       this.aesCipher.init(1, secret);
/*     */       
/*     */ 
/* 147 */       byte[] ciphertext = this.aesCipher.doFinal(plain);
/*     */       
/* 149 */       return Base64Coder.encode(ciphertext);
/*     */     } catch (InvalidKeySpecException ex) {
/* 151 */       throw new SecurityException(ex);
/*     */     } catch (InvalidKeyException ex) {
/* 153 */       throw new SecurityException(ex);
/*     */     } catch (IllegalBlockSizeException ex) {
/* 155 */       throw new SecurityException(ex);
/*     */     } catch (BadPaddingException ex) {
/* 157 */       throw new SecurityException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] recoverAES(char[] cryptedText, String password)
/*     */     throws SecurityException
/*     */   {
/* 169 */     if ((password == null) || ("".equals(new String(password).trim())) || (cryptedText == null))
/* 170 */       throw new SecurityException("Faltan parámetros de entrada");
/* 171 */     if (password.length() < 8) {
/* 172 */       logger.warn("La clave debe tener al menos 8 bytes. Se emplea su valor SHA1 como contraseña.");
/*     */       try {
/* 174 */         MessageDigest hash = MessageDigest.getInstance("SHA1", "BC");
/* 175 */         password = new String(hash.digest(password.getBytes()));
/*     */       } catch (NoSuchAlgorithmException e) {
/* 177 */         throw new SecurityException("Error al calcular el Digest de la contraseña", e);
/*     */       } catch (NoSuchProviderException e) {
/* 179 */         throw new SecurityException("Error al calcular el Digest de la contraseña", e);
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 185 */       PBEParameterSpec pbeParamSpec = new PBEParameterSpec(this.salt, this.iter);
/*     */       
/*     */ 
/* 188 */       SecretKey pbeKey = this.skfAes.generateSecret(new PBEKeySpec(password.toCharArray()));
/*     */       
/*     */ 
/* 191 */       this.aesCipher.init(2, pbeKey, pbeParamSpec);
/*     */       
/*     */ 
/* 194 */       return this.aesCipher.doFinal(Base64Coder.decode(cryptedText));
/*     */     }
/*     */     catch (InvalidKeySpecException ex)
/*     */     {
/* 198 */       throw new SecurityException(ex);
/*     */     } catch (InvalidKeyException ex) {
/* 200 */       throw new SecurityException(ex);
/*     */     } catch (InvalidAlgorithmParameterException ex) {
/* 202 */       throw new SecurityException(ex);
/*     */     } catch (IllegalBlockSizeException ex) {
/* 204 */       throw new SecurityException(ex);
/*     */     } catch (BadPaddingException ex) {
/* 206 */       throw new SecurityException("Contraseña incorrecta", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getUsedAlgorithmURI() {
/* 211 */     return "http://www.w3.org/2001/04/xmlenc#aes256-cbc";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 218 */     String plain = "TextoEnClaro0123456789";
/* 219 */     String pass = "1234567890123456789012345678901234567890";
/* 220 */     DESCipherManager p = new DESCipherManager();
/* 221 */     System.out.println("Texto en claro: " + plain);
/* 222 */     String buffer = es.mityc.crypto.Utils.obfuscate(plain);
/* 223 */     System.out.println("Texto ofuscado: " + buffer);
/* 224 */     buffer = es.mityc.crypto.Utils.undoObfuscate(buffer.getBytes());
/* 225 */     System.out.println("Texto recuperado: " + buffer);
/* 226 */     char[] bufferChar = p.protectPBEandDES(buffer, pass);
/* 227 */     buffer = new String(bufferChar);
/* 228 */     System.out.println("Texto encriptado AES: " + buffer);
/* 229 */     buffer = new String(p.recoverPBEandDES(bufferChar, pass));
/* 230 */     System.out.println("Texto desencriptado AES: " + buffer);
/*     */     
/* 232 */     Long start = Long.valueOf(System.currentTimeMillis());
/* 233 */     buffer = es.mityc.crypto.Utils.obfuscate(new String(p.protectPBEandDES(buffer, pass)));
/* 234 */     System.out.println("Encriptado AES y ofuscado: " + buffer);
/* 235 */     buffer = new String(p.recoverPBEandDES(es.mityc.crypto.Utils.undoObfuscate(buffer.getBytes()).toCharArray(), pass));
/* 236 */     Long time = Long.valueOf(System.currentTimeMillis() - start.longValue());
/* 237 */     System.out.println("Texto recuperado: " + buffer + "\nTiempo consumido (ms): " + time);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCrypt-1.1.7.jar!\es\mityc\crypto\symetric\AESCipherManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */