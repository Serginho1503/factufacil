/*     */ package es.mityc.crypto.symetric;
/*     */ 
/*     */ import es.mityc.crypto.CryptoManager;
/*     */ import es.mityc.javasign.utils.Base64Coder;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.Security;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import javax.crypto.BadPaddingException;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.IllegalBlockSizeException;
/*     */ import javax.crypto.NoSuchPaddingException;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.SecretKeyFactory;
/*     */ import javax.crypto.spec.DESKeySpec;
/*     */ import javax.crypto.spec.PBEKeySpec;
/*     */ import javax.crypto.spec.PBEParameterSpec;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DESCipherManager
/*     */   implements CryptoManager
/*     */ {
/*  52 */   static Log logger = LogFactory.getLog(DESCipherManager.class);
/*     */   
/*     */ 
/*  55 */   private SecureRandom random = null;
/*     */   
/*     */ 
/*  58 */   private byte[] salt = null;
/*     */   
/*     */ 
/*  61 */   private int iter = 64;
/*     */   
/*     */ 
/*  64 */   private Cipher desCipher = null;
/*     */   
/*     */ 
/*  67 */   private SecretKeyFactory skfDes = null;
/*     */   
/*     */   public DESCipherManager() {
/*  70 */     init(null, 0);
/*     */   }
/*     */   
/*     */   public DESCipherManager(byte[] salt, int iter) {
/*  74 */     init(salt, iter);
/*     */   }
/*     */   
/*     */   public void feedSeed(byte[] seed) {
/*  78 */     if (seed == null) {
/*  79 */       seed = SecureRandom.getSeed(8);
/*     */     }
/*  81 */     for (int i = 0; (i < this.salt.length) && (i < seed.length); i++) {
/*  82 */       this.salt[i] = ((byte)(this.salt[i] & seed[i]));
/*     */     }
/*  84 */     this.random.setSeed(this.salt);
/*     */   }
/*     */   
/*     */   private void init(byte[] salt, int iter)
/*     */   {
/*  89 */     if (salt != null) {
/*  90 */       this.salt = salt;
/*     */     } else {
/*  92 */       this.salt = SecureRandom.getSeed(8);
/*     */     }
/*     */     
/*  95 */     if (iter != 0) {
/*  96 */       this.iter = iter;
/*     */     }
/*     */     
/*     */ 
/* 100 */     if (Security.getProvider("BC") == null) {
/* 101 */       es.mityc.javasign.utils.Utils.addBCProvider();
/*     */     }
/*     */     try
/*     */     {
/* 105 */       this.desCipher = Cipher.getInstance("PBEWithMD5AndDES");
/*     */       
/* 107 */       this.skfDes = SecretKeyFactory.getInstance("PBEWithMD5AndDES");
/*     */     } catch (NoSuchPaddingException ex) {
/* 109 */       throw new SecurityException(ex);
/*     */     } catch (NoSuchAlgorithmException ex) {
/* 111 */       throw new SecurityException(ex);
/*     */     }
/* 113 */     this.random = new SecureRandom(salt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] protectPBEandDES(String plain, String password)
/*     */     throws SecurityException
/*     */   {
/* 124 */     if ((password == null) || ("".equals(new String(password).trim())) || (plain == null))
/* 125 */       throw new SecurityException("Faltan parámetros de entrada");
/* 126 */     if (password.length() < 8) {
/* 127 */       logger.warn("La clave debe tener al menos 8 bytes. Se emplea su valor SHA1 como contraseña.");
/*     */       try {
/* 129 */         MessageDigest hash = MessageDigest.getInstance("SHA1", "BC");
/* 130 */         password = new String(hash.digest(password.getBytes()));
/*     */       } catch (NoSuchAlgorithmException e) {
/* 132 */         throw new SecurityException("Error al calcular el Digest de la contraseña", e);
/*     */       } catch (NoSuchProviderException e) {
/* 134 */         throw new SecurityException("Error al calcular el Digest de la contraseña", e);
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 140 */       SecretKey pbeKey = this.skfDes.generateSecret(new PBEKeySpec(password.toCharArray()));
/*     */       
/*     */ 
/* 143 */       byte[] plainProps = plain.getBytes();
/*     */       
/* 145 */       return protectDES(plainProps, pbeKey);
/*     */     } catch (InvalidKeySpecException ex) {
/* 147 */       throw new SecurityException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] recoverPBEandDES(char[] cryptedText, String password)
/*     */     throws SecurityException
/*     */   {
/* 159 */     if ((password == null) || ("".equals(new String(password).trim())) || (cryptedText == null))
/* 160 */       throw new SecurityException("Faltan parámetros de entrada");
/* 161 */     if (password.length() < 8) {
/* 162 */       logger.warn("La clave debe tener al menos 8 bytes. Se emplea su valor SHA1 como contraseña.");
/*     */       try {
/* 164 */         MessageDigest hash = MessageDigest.getInstance("SHA1", "BC");
/* 165 */         password = new String(hash.digest(password.getBytes()));
/*     */       } catch (NoSuchAlgorithmException e) {
/* 167 */         throw new SecurityException("Error al calcular el Digest de la contraseña", e);
/*     */       } catch (NoSuchProviderException e) {
/* 169 */         throw new SecurityException("Error al calcular el Digest de la contraseña", e);
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 175 */       SecretKey pbeKey = this.skfDes.generateSecret(new PBEKeySpec(password.toCharArray()));
/*     */       
/* 177 */       return recoverDES(cryptedText, pbeKey);
/*     */     } catch (InvalidKeySpecException ex) {
/* 179 */       throw new SecurityException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] protectDES(byte[] plain, SecretKey sk)
/*     */     throws SecurityException
/*     */   {
/*     */     try
/*     */     {
/* 193 */       PBEParameterSpec pbeParamSpec = new PBEParameterSpec(this.salt, this.iter);
/*     */       
/*     */ 
/* 196 */       this.desCipher.init(1, sk, pbeParamSpec);
/*     */       
/*     */ 
/* 199 */       byte[] ciphertext = this.desCipher.doFinal(plain);
/*     */       
/* 201 */       return Base64Coder.encode(ciphertext);
/*     */     } catch (InvalidKeyException ex) {
/* 203 */       throw new SecurityException(ex);
/*     */     } catch (InvalidAlgorithmParameterException ex) {
/* 205 */       throw new SecurityException(ex);
/*     */     } catch (IllegalBlockSizeException ex) {
/* 207 */       throw new SecurityException(ex);
/*     */     } catch (BadPaddingException ex) {
/* 209 */       throw new SecurityException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] recoverDES(char[] cryptedText, SecretKey sk)
/*     */     throws SecurityException
/*     */   {
/*     */     try
/*     */     {
/* 223 */       PBEParameterSpec pbeParamSpec = new PBEParameterSpec(this.salt, this.iter);
/*     */       
/*     */ 
/* 226 */       this.desCipher.init(2, sk, pbeParamSpec);
/*     */       
/* 228 */       return this.desCipher.doFinal(Base64Coder.decode(cryptedText));
/*     */     } catch (InvalidKeyException ex) {
/* 230 */       throw new SecurityException(ex);
/*     */     } catch (InvalidAlgorithmParameterException ex) {
/* 232 */       throw new SecurityException(ex);
/*     */     } catch (IllegalBlockSizeException ex) {
/* 234 */       throw new SecurityException(ex);
/*     */     } catch (BadPaddingException ex) {
/* 236 */       throw new SecurityException("Contraseña incorrecta", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SecretKey genKey()
/*     */   {
/* 245 */     byte[] randomKey = new byte[30];
/* 246 */     this.random.nextBytes(randomKey);
/*     */     try {
/* 248 */       return this.skfDes.generateSecret(new DESKeySpec(randomKey));
/*     */     } catch (Exception e) {
/* 250 */       logger.error("No se pudo construir la clave aleatoria", e); }
/* 251 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SecretKey rebuildKey(byte[] key)
/*     */   {
/*     */     try
/*     */     {
/* 261 */       return this.skfDes.generateSecret(new DESKeySpec(key));
/*     */     } catch (Exception e) {
/* 263 */       logger.error("No se pudo reconstruir la clave indicada", e); }
/* 264 */     return null;
/*     */   }
/*     */   
/*     */   public String getUsedAlgorithmURI()
/*     */   {
/* 269 */     return "http://www.w3.org/2001/04/xmlenc#des-cbc";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 276 */     String pass = "1234567890123456789012345678901234567890";
/* 277 */     DESCipherManager p = new DESCipherManager();
/* 278 */     System.out.println("Texto en claro: " + args[0]);
/* 279 */     String buffer = es.mityc.crypto.Utils.obfuscate(args[0]);
/* 280 */     System.out.println("Texto ofuscado: " + buffer);
/* 281 */     buffer = es.mityc.crypto.Utils.undoObfuscate(buffer.getBytes());
/* 282 */     System.out.println("Texto recuperado: " + buffer);
/* 283 */     char[] bufferChar = p.protectPBEandDES(buffer, pass);
/* 284 */     buffer = new String(bufferChar);
/* 285 */     System.out.println("Texto encriptado PBEandDES: " + buffer);
/* 286 */     buffer = new String(p.recoverPBEandDES(bufferChar, pass));
/* 287 */     System.out.println("Texto desencriptado PBEandDES: " + buffer);
/*     */     
/* 289 */     Long start = Long.valueOf(System.currentTimeMillis());
/* 290 */     buffer = es.mityc.crypto.Utils.obfuscate(new String(p.protectPBEandDES(buffer, pass)));
/* 291 */     System.out.println("Encriptado PBEandDES y ofuscado: " + buffer);
/* 292 */     buffer = new String(p.recoverPBEandDES(es.mityc.crypto.Utils.undoObfuscate(buffer.getBytes()).toCharArray(), pass));
/* 293 */     Long time = Long.valueOf(System.currentTimeMillis() - start.longValue());
/* 294 */     System.out.println("Texto recuperado: " + buffer + "\nTiempo consumido (ms): " + time);
/*     */     
/*     */     try
/*     */     {
/* 298 */       SecretKeyFactory skfDes = SecretKeyFactory.getInstance("PBEWithMD5AndDES");
/* 299 */       SecretKey pbeKey = skfDes.generateSecret(new PBEKeySpec(pass.toCharArray()));
/*     */       
/* 301 */       BufferedReader br = new BufferedReader(new InputStreamReader(p.getClass().getResourceAsStream("/prueba.pdf")));
/* 302 */       StringBuffer sb = new StringBuffer();
/* 303 */       String line = br.readLine();
/* 304 */       while (line != null) {
/* 305 */         sb.append(line);
/* 306 */         line = br.readLine();
/*     */       }
/* 308 */       byte[] aEnc = sb.toString().getBytes();
/* 309 */       bufferChar = p.protectDES(aEnc, pbeKey);
/* 310 */       start = Long.valueOf(System.currentTimeMillis());
/* 311 */       buffer = new String(p.recoverDES(bufferChar, pbeKey));
/* 312 */       time = Long.valueOf(System.currentTimeMillis() - start.longValue());
/* 313 */       System.out.println("Tiempo consumido (ms): " + time);
/*     */     } catch (Exception e) {
/* 315 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCrypt-1.1.7.jar!\es\mityc\crypto\symetric\DESCipherManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */