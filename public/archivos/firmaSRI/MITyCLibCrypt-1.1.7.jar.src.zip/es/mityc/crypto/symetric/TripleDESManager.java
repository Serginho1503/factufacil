/*     */ package es.mityc.crypto.symetric;
/*     */ 
/*     */ import es.mityc.crypto.CryptoManager;
/*     */ import es.mityc.javasign.utils.Base64Coder;
/*     */ import java.io.PrintStream;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.Security;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import javax.crypto.BadPaddingException;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.IllegalBlockSizeException;
/*     */ import javax.crypto.NoSuchPaddingException;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.SecretKeyFactory;
/*     */ import javax.crypto.spec.DESedeKeySpec;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TripleDESManager
/*     */   implements CryptoManager
/*     */ {
/*  47 */   static Log logger = LogFactory.getLog(TripleDESManager.class);
/*     */   
/*     */ 
/*  50 */   private Cipher tripleDesCipher = null;
/*     */   
/*     */ 
/*  53 */   private SecretKeyFactory skf3Des = null;
/*     */   
/*  55 */   private SecureRandom random = null;
/*  56 */   private static byte[] salt = null;
/*     */   
/*     */   public TripleDESManager() {
/*  59 */     init();
/*     */   }
/*     */   
/*     */   public void feedSeed(byte[] seed) {
/*  63 */     this.random.nextBytes(salt);
/*  64 */     if (seed != null) {
/*  65 */       for (int i = 0; (i < salt.length) && (i < seed.length); i++) {
/*  66 */         salt[i] = ((byte)(salt[i] & seed[i]));
/*     */       }
/*     */     }
/*  69 */     this.random.setSeed(salt);
/*     */   }
/*     */   
/*     */   private void init() {
/*     */     
/*     */     try {
/*  75 */       this.tripleDesCipher = Cipher.getInstance("DESede", "BC");
/*  76 */       this.skf3Des = SecretKeyFactory.getInstance("DESede", "BC");
/*     */     } catch (NoSuchPaddingException ex) {
/*  78 */       throw new SecurityException(ex);
/*     */     } catch (NoSuchAlgorithmException ex) {
/*  80 */       throw new SecurityException(ex);
/*     */     } catch (NoSuchProviderException ex) {
/*  82 */       throw new SecurityException(ex);
/*     */     }
/*     */     
/*  85 */     salt = SecureRandom.getSeed(8);
/*     */     
/*  87 */     this.random = new SecureRandom(salt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] protectTripleDES(String plain, String password)
/*     */     throws SecurityException
/*     */   {
/*  98 */     if ((password == null) || ("".equals(new String(password).trim())) || (plain == null)) {
/*  99 */       throw new SecurityException("Faltan parámetros de entrada");
/*     */     }
/* 101 */     return protectTripleDES(plain.getBytes(), password);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] protectTripleDES(byte[] plainBytes, String password)
/*     */     throws SecurityException
/*     */   {
/* 112 */     if ((password == null) || ("".equals(new String(password).trim())) || (plainBytes == null))
/* 113 */       throw new SecurityException("Faltan parámetros de entrada");
/* 114 */     if (password.length() < 24) {
/* 115 */       logger.warn("La clave debe tener al menos 24 bytes. Se emplea su valor SHA256 como contraseña.");
/* 116 */       es.mityc.javasign.utils.Utils.addBCProvider();
/*     */       try {
/* 118 */         MessageDigest hash = MessageDigest.getInstance("SHA256", "BC");
/* 119 */         password = new String(hash.digest(password.getBytes()));
/*     */       } catch (NoSuchAlgorithmException e) {
/* 121 */         throw new SecurityException("Error al calcular el Digest de la contraseña", e);
/*     */       } catch (NoSuchProviderException e) {
/* 123 */         throw new SecurityException("Error al calcular el Digest de la contraseña", e);
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 129 */       SecretKey desKey = this.skf3Des.generateSecret(new DESedeKeySpec(password.getBytes()));
/* 130 */       return protectTripleDES(plainBytes, desKey);
/*     */     } catch (InvalidKeySpecException ex) {
/* 132 */       throw new SecurityException(ex);
/*     */     } catch (InvalidKeyException ex) {
/* 134 */       throw new SecurityException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] protectTripleDES(byte[] plainBytes, SecretKey key)
/*     */     throws SecurityException
/*     */   {
/*     */     try
/*     */     {
/* 147 */       if (logger.isDebugEnabled()) {
/* 148 */         logger.debug("Encriptando " + plainBytes.length + " bytes");
/*     */       }
/* 150 */       init();
/*     */       
/* 152 */       this.tripleDesCipher.init(1, key, this.random);
/*     */       
/* 154 */       byte[] ciphertext = this.tripleDesCipher.doFinal(plainBytes);
/*     */       
/* 156 */       return Base64Coder.encode(ciphertext);
/*     */     } catch (InvalidKeyException ex) {
/* 158 */       throw new SecurityException(ex);
/*     */     } catch (IllegalBlockSizeException ex) {
/* 160 */       throw new SecurityException(ex);
/*     */     } catch (BadPaddingException ex) {
/* 162 */       throw new SecurityException(ex);
/*     */     } finally {
/* 164 */       if (Security.getProvider("BC") != null) {
/* 165 */         if (logger.isDebugEnabled()) {
/* 166 */           logger.debug("Eliminando el proveedor BC");
/*     */         }
/* 168 */         Security.removeProvider("BC");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] recoverTripleDES(char[] cryptedText, String password)
/*     */     throws SecurityException
/*     */   {
/* 181 */     if ((password == null) || ("".equals(new String(password).trim())) || (cryptedText == null))
/* 182 */       throw new SecurityException("Faltan parámetros de entrada");
/* 183 */     if (password.length() < 24) {
/* 184 */       logger.warn("La clave debe tener al menos 24 bytes. Se emplea su valor SHA256 como contraseña.");
/*     */       try {
/* 186 */         es.mityc.javasign.utils.Utils.addBCProvider();
/* 187 */         MessageDigest hash = MessageDigest.getInstance("SHA256", "BC");
/* 188 */         password = new String(hash.digest(password.getBytes()));
/*     */       } catch (NoSuchAlgorithmException e) {
/* 190 */         throw new SecurityException("Error al calcular el Digest de la contraseña", e);
/*     */       } catch (NoSuchProviderException e) {
/* 192 */         throw new SecurityException("Error al calcular el Digest de la contraseña", e);
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 197 */       SecretKey desKey = this.skf3Des.generateSecret(new DESedeKeySpec(password.getBytes()));
/* 198 */       return recoverTripleDES(cryptedText, desKey);
/*     */     } catch (InvalidKeySpecException ex) {
/* 200 */       throw new SecurityException(ex);
/*     */     } catch (InvalidKeyException ex) {
/* 202 */       throw new SecurityException(ex);
/*     */     } finally {
/* 204 */       if (Security.getProvider("BC") != null) {
/* 205 */         if (logger.isDebugEnabled()) {
/* 206 */           logger.debug("Eliminando el proveedor BC");
/*     */         }
/* 208 */         Security.removeProvider("BC");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] recoverTripleDES(char[] cryptedText, SecretKey key)
/*     */     throws SecurityException
/*     */   {
/*     */     try
/*     */     {
/* 222 */       if (logger.isDebugEnabled()) {
/* 223 */         logger.debug("Recuperando " + cryptedText.length + " bytes");
/*     */       }
/* 225 */       init();
/*     */       
/* 227 */       this.tripleDesCipher.init(2, key);
/*     */       
/* 229 */       return this.tripleDesCipher.doFinal(Base64Coder.decode(cryptedText));
/*     */     } catch (InvalidKeyException ex) {
/* 231 */       throw new SecurityException(ex);
/*     */     } catch (IllegalBlockSizeException ex) {
/* 233 */       throw new SecurityException(ex);
/*     */     } catch (BadPaddingException ex) {
/* 235 */       throw new SecurityException("Contraseña incorrecta", ex);
/*     */     } finally {
/* 237 */       if (Security.getProvider("BC") != null) {
/* 238 */         if (logger.isDebugEnabled()) {
/* 239 */           logger.debug("Eliminando el proveedor BC");
/*     */         }
/* 241 */         Security.removeProvider("BC");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SecretKey genKey()
/*     */   {
/* 251 */     byte[] randomKey = new byte[30];
/* 252 */     this.random.nextBytes(randomKey);
/*     */     try {
/* 254 */       return this.skf3Des.generateSecret(new DESedeKeySpec(randomKey));
/*     */     } catch (Exception e) {
/* 256 */       logger.error("No se pudo construir la clave aleatoria", e); }
/* 257 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SecretKey rebuildKey(byte[] key)
/*     */   {
/*     */     try
/*     */     {
/* 267 */       return this.skf3Des.generateSecret(new DESedeKeySpec(key));
/*     */     } catch (Exception e) {
/* 269 */       logger.error("No se pudo reconstruir la clave indicada", e); }
/* 270 */     return null;
/*     */   }
/*     */   
/*     */   public String getUsedAlgorithmURI()
/*     */   {
/* 275 */     return "http://www.w3.org/2001/04/xmlenc#tripledes-cbc";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 282 */     String pass = "1234567890123456789012345678901234567890";
/* 283 */     TripleDESManager p = new TripleDESManager();
/* 284 */     System.out.println("Texto en claro: " + args[0]);
/* 285 */     String buffer = es.mityc.crypto.Utils.obfuscate(args[0]);
/* 286 */     System.out.println("Texto ofuscado: " + buffer);
/* 287 */     buffer = es.mityc.crypto.Utils.undoObfuscate(buffer.getBytes());
/* 288 */     System.out.println("Texto recuperado: " + buffer);
/*     */     
/* 290 */     char[] bufferChar = p.protectTripleDES(buffer, pass);
/* 291 */     buffer = new String(bufferChar);
/* 292 */     System.out.println("Texto encriptado triple DES: " + buffer);
/* 293 */     buffer = new String(p.recoverTripleDES(bufferChar, pass));
/* 294 */     System.out.println("Texto desencriptado triple DES: " + buffer);
/*     */     
/* 296 */     long start = System.currentTimeMillis();
/* 297 */     buffer = es.mityc.crypto.Utils.obfuscate(new String(p.protectTripleDES(buffer, pass)));
/* 298 */     System.out.println("Encriptado y ofuscado triple DES: " + buffer);
/* 299 */     buffer = new String(p.recoverTripleDES(es.mityc.crypto.Utils.undoObfuscate(buffer.getBytes()).toCharArray(), pass));
/* 300 */     long time = System.currentTimeMillis() - start;
/* 301 */     System.out.println("Texto recuperado: " + buffer + "\nTiempo consumido (ms): " + time);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\MITyCLibCrypt-1.1.7.jar!\es\mityc\crypto\symetric\TripleDESManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */