package org.bouncycastle.asn1.cms;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.BERSequence;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERTaggedObject;

public class AuthEnvelopedData
  extends ASN1Encodable
{
  private DERInteger version;
  private OriginatorInfo originatorInfo;
  private ASN1Set recipientInfos;
  private EncryptedContentInfo authEncryptedContentInfo;
  private ASN1Set authAttrs;
  private ASN1OctetString mac;
  private ASN1Set unauthAttrs;
  
  public AuthEnvelopedData(OriginatorInfo paramOriginatorInfo, ASN1Set paramASN1Set1, EncryptedContentInfo paramEncryptedContentInfo, ASN1Set paramASN1Set2, ASN1OctetString paramASN1OctetString, ASN1Set paramASN1Set3)
  {
    this.version = new DERInteger(0);
    this.originatorInfo = paramOriginatorInfo;
    this.recipientInfos = paramASN1Set1;
    this.authEncryptedContentInfo = paramEncryptedContentInfo;
    this.authAttrs = paramASN1Set2;
    this.mac = paramASN1OctetString;
    this.unauthAttrs = paramASN1Set3;
  }
  
  public AuthEnvelopedData(ASN1Sequence paramASN1Sequence)
  {
    int i = 0;
    DERObject localDERObject = paramASN1Sequence.getObjectAt(i++).getDERObject();
    this.version = ((DERInteger)localDERObject);
    localDERObject = paramASN1Sequence.getObjectAt(i++).getDERObject();
    if ((localDERObject instanceof ASN1TaggedObject))
    {
      this.originatorInfo = OriginatorInfo.getInstance((ASN1TaggedObject)localDERObject, false);
      localDERObject = paramASN1Sequence.getObjectAt(i++).getDERObject();
    }
    this.recipientInfos = ASN1Set.getInstance(localDERObject);
    localDERObject = paramASN1Sequence.getObjectAt(i++).getDERObject();
    this.authEncryptedContentInfo = EncryptedContentInfo.getInstance(localDERObject);
    localDERObject = paramASN1Sequence.getObjectAt(i++).getDERObject();
    if ((localDERObject instanceof ASN1TaggedObject))
    {
      this.authAttrs = ASN1Set.getInstance((ASN1TaggedObject)localDERObject, false);
      localDERObject = paramASN1Sequence.getObjectAt(i++).getDERObject();
    }
    this.mac = ASN1OctetString.getInstance(localDERObject);
    if (paramASN1Sequence.size() > i)
    {
      localDERObject = paramASN1Sequence.getObjectAt(i++).getDERObject();
      this.unauthAttrs = ASN1Set.getInstance((ASN1TaggedObject)localDERObject, false);
    }
  }
  
  public static AuthEnvelopedData getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1Sequence.getInstance(paramASN1TaggedObject, paramBoolean));
  }
  
  public static AuthEnvelopedData getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof AuthEnvelopedData))) {
      return (AuthEnvelopedData)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new AuthEnvelopedData((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("Invalid AuthEnvelopedData: " + paramObject.getClass().getName());
  }
  
  public DERInteger getVersion()
  {
    return this.version;
  }
  
  public OriginatorInfo getOriginatorInfo()
  {
    return this.originatorInfo;
  }
  
  public ASN1Set getRecipientInfos()
  {
    return this.recipientInfos;
  }
  
  public EncryptedContentInfo getAuthEncryptedContentInfo()
  {
    return this.authEncryptedContentInfo;
  }
  
  public ASN1Set getAuthAttrs()
  {
    return this.authAttrs;
  }
  
  public ASN1OctetString getMac()
  {
    return this.mac;
  }
  
  public ASN1Set getUnauthAttrs()
  {
    return this.unauthAttrs;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.version);
    if (this.originatorInfo != null) {
      localASN1EncodableVector.add(new DERTaggedObject(false, 0, this.originatorInfo));
    }
    localASN1EncodableVector.add(this.recipientInfos);
    localASN1EncodableVector.add(this.authEncryptedContentInfo);
    if (this.authAttrs != null) {
      localASN1EncodableVector.add(new DERTaggedObject(false, 1, this.authAttrs));
    }
    localASN1EncodableVector.add(this.mac);
    if (this.unauthAttrs != null) {
      localASN1EncodableVector.add(new DERTaggedObject(false, 2, this.unauthAttrs));
    }
    return new BERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\cms\AuthEnvelopedData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */