package org.bouncycastle.asn1.cms;

import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;

public abstract interface CMSAttributes
{
  public static final DERObjectIdentifier contentType = PKCSObjectIdentifiers.pkcs_9_at_contentType;
  public static final DERObjectIdentifier messageDigest = PKCSObjectIdentifiers.pkcs_9_at_messageDigest;
  public static final DERObjectIdentifier signingTime = PKCSObjectIdentifiers.pkcs_9_at_signingTime;
  public static final DERObjectIdentifier counterSignature = PKCSObjectIdentifiers.pkcs_9_at_counterSignature;
  public static final DERObjectIdentifier contentHint = PKCSObjectIdentifiers.id_aa_contentHint;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\cms\CMSAttributes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */