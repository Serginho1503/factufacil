package org.bouncycastle.asn1.cms;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1SequenceParser;
import org.bouncycastle.asn1.ASN1TaggedObjectParser;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObjectIdentifier;

public class ContentInfoParser
{
  private DERObjectIdentifier contentType;
  private ASN1TaggedObjectParser content;
  
  public ContentInfoParser(ASN1SequenceParser paramASN1SequenceParser)
    throws IOException
  {
    this.contentType = ((DERObjectIdentifier)paramASN1SequenceParser.readObject());
    this.content = ((ASN1TaggedObjectParser)paramASN1SequenceParser.readObject());
  }
  
  public DERObjectIdentifier getContentType()
  {
    return this.contentType;
  }
  
  public DEREncodable getContent(int paramInt)
    throws IOException
  {
    if (this.content != null) {
      return this.content.getObjectParser(paramInt, true);
    }
    return null;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\cms\ContentInfoParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */