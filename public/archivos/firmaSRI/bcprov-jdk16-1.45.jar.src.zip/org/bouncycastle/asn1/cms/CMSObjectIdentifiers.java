package org.bouncycastle.asn1.cms;

import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;

public abstract interface CMSObjectIdentifiers
{
  public static final DERObjectIdentifier data = PKCSObjectIdentifiers.data;
  public static final DERObjectIdentifier signedData = PKCSObjectIdentifiers.signedData;
  public static final DERObjectIdentifier envelopedData = PKCSObjectIdentifiers.envelopedData;
  public static final DERObjectIdentifier signedAndEnvelopedData = PKCSObjectIdentifiers.signedAndEnvelopedData;
  public static final DERObjectIdentifier digestedData = PKCSObjectIdentifiers.digestedData;
  public static final DERObjectIdentifier encryptedData = PKCSObjectIdentifiers.encryptedData;
  public static final DERObjectIdentifier authenticatedData = PKCSObjectIdentifiers.id_ct_authData;
  public static final DERObjectIdentifier compressedData = PKCSObjectIdentifiers.id_ct_compressedData;
  public static final DERObjectIdentifier authEnvelopedData = PKCSObjectIdentifiers.id_ct_authEnvelopedData;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\cms\CMSObjectIdentifiers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */