package org.bouncycastle.asn1.cms;

import org.bouncycastle.asn1.ASN1Choice;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERTaggedObject;

public class SignerIdentifier
  extends ASN1Encodable
  implements ASN1Choice
{
  private DEREncodable id;
  
  public SignerIdentifier(IssuerAndSerialNumber paramIssuerAndSerialNumber)
  {
    this.id = paramIssuerAndSerialNumber;
  }
  
  public SignerIdentifier(ASN1OctetString paramASN1OctetString)
  {
    this.id = new DERTaggedObject(false, 0, paramASN1OctetString);
  }
  
  public SignerIdentifier(DERObject paramDERObject)
  {
    this.id = paramDERObject;
  }
  
  public static SignerIdentifier getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof SignerIdentifier))) {
      return (SignerIdentifier)paramObject;
    }
    if ((paramObject instanceof IssuerAndSerialNumber)) {
      return new SignerIdentifier((IssuerAndSerialNumber)paramObject);
    }
    if ((paramObject instanceof ASN1OctetString)) {
      return new SignerIdentifier((ASN1OctetString)paramObject);
    }
    if ((paramObject instanceof DERObject)) {
      return new SignerIdentifier((DERObject)paramObject);
    }
    throw new IllegalArgumentException("Illegal object in SignerIdentifier: " + paramObject.getClass().getName());
  }
  
  public boolean isTagged()
  {
    return this.id instanceof ASN1TaggedObject;
  }
  
  public DEREncodable getId()
  {
    if ((this.id instanceof ASN1TaggedObject)) {
      return ASN1OctetString.getInstance((ASN1TaggedObject)this.id, false);
    }
    return this.id;
  }
  
  public DERObject toASN1Object()
  {
    return this.id.getDERObject();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\cms\SignerIdentifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */