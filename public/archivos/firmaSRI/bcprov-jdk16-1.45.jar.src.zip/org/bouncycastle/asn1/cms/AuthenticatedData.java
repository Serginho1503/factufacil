package org.bouncycastle.asn1.cms;

import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.BERSequence;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class AuthenticatedData
  extends ASN1Encodable
{
  private DERInteger version;
  private OriginatorInfo originatorInfo;
  private ASN1Set recipientInfos;
  private AlgorithmIdentifier macAlgorithm;
  private AlgorithmIdentifier digestAlgorithm;
  private ContentInfo encapsulatedContentInfo;
  private ASN1Set authAttrs;
  private ASN1OctetString mac;
  private ASN1Set unauthAttrs;
  
  public AuthenticatedData(OriginatorInfo paramOriginatorInfo, ASN1Set paramASN1Set1, AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, ContentInfo paramContentInfo, ASN1Set paramASN1Set2, ASN1OctetString paramASN1OctetString, ASN1Set paramASN1Set3)
  {
    if (((paramAlgorithmIdentifier2 != null) || (paramASN1Set2 != null)) && ((paramAlgorithmIdentifier2 == null) || (paramASN1Set2 == null))) {
      throw new IllegalArgumentException("digestAlgorithm and authAttrs must be set together");
    }
    this.version = new DERInteger(calculateVersion(paramOriginatorInfo));
    this.originatorInfo = paramOriginatorInfo;
    this.macAlgorithm = paramAlgorithmIdentifier1;
    this.digestAlgorithm = paramAlgorithmIdentifier2;
    this.recipientInfos = paramASN1Set1;
    this.encapsulatedContentInfo = paramContentInfo;
    this.authAttrs = paramASN1Set2;
    this.mac = paramASN1OctetString;
    this.unauthAttrs = paramASN1Set3;
  }
  
  public AuthenticatedData(ASN1Sequence paramASN1Sequence)
  {
    int i = 0;
    this.version = ((DERInteger)paramASN1Sequence.getObjectAt(i++));
    DEREncodable localDEREncodable = paramASN1Sequence.getObjectAt(i++);
    if ((localDEREncodable instanceof ASN1TaggedObject))
    {
      this.originatorInfo = OriginatorInfo.getInstance((ASN1TaggedObject)localDEREncodable, false);
      localDEREncodable = paramASN1Sequence.getObjectAt(i++);
    }
    this.recipientInfos = ASN1Set.getInstance(localDEREncodable);
    this.macAlgorithm = AlgorithmIdentifier.getInstance(paramASN1Sequence.getObjectAt(i++));
    localDEREncodable = paramASN1Sequence.getObjectAt(i++);
    if ((localDEREncodable instanceof ASN1TaggedObject))
    {
      this.digestAlgorithm = AlgorithmIdentifier.getInstance((ASN1TaggedObject)localDEREncodable, false);
      localDEREncodable = paramASN1Sequence.getObjectAt(i++);
    }
    this.encapsulatedContentInfo = ContentInfo.getInstance(localDEREncodable);
    localDEREncodable = paramASN1Sequence.getObjectAt(i++);
    if ((localDEREncodable instanceof ASN1TaggedObject))
    {
      this.authAttrs = ASN1Set.getInstance((ASN1TaggedObject)localDEREncodable, false);
      localDEREncodable = paramASN1Sequence.getObjectAt(i++);
    }
    this.mac = ASN1OctetString.getInstance(localDEREncodable);
    if (paramASN1Sequence.size() > i) {
      this.unauthAttrs = ASN1Set.getInstance((ASN1TaggedObject)paramASN1Sequence.getObjectAt(i), false);
    }
  }
  
  public static AuthenticatedData getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1Sequence.getInstance(paramASN1TaggedObject, paramBoolean));
  }
  
  public static AuthenticatedData getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof AuthenticatedData))) {
      return (AuthenticatedData)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new AuthenticatedData((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("Invalid AuthenticatedData: " + paramObject.getClass().getName());
  }
  
  public DERInteger getVersion()
  {
    return this.version;
  }
  
  public OriginatorInfo getOriginatorInfo()
  {
    return this.originatorInfo;
  }
  
  public ASN1Set getRecipientInfos()
  {
    return this.recipientInfos;
  }
  
  public AlgorithmIdentifier getMacAlgorithm()
  {
    return this.macAlgorithm;
  }
  
  public ContentInfo getEncapsulatedContentInfo()
  {
    return this.encapsulatedContentInfo;
  }
  
  public ASN1Set getAuthAttrs()
  {
    return this.authAttrs;
  }
  
  public ASN1OctetString getMac()
  {
    return this.mac;
  }
  
  public ASN1Set getUnauthAttrs()
  {
    return this.unauthAttrs;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.version);
    if (this.originatorInfo != null) {
      localASN1EncodableVector.add(new DERTaggedObject(false, 0, this.originatorInfo));
    }
    localASN1EncodableVector.add(this.recipientInfos);
    localASN1EncodableVector.add(this.macAlgorithm);
    if (this.digestAlgorithm != null) {
      localASN1EncodableVector.add(new DERTaggedObject(false, 1, this.digestAlgorithm));
    }
    localASN1EncodableVector.add(this.encapsulatedContentInfo);
    if (this.authAttrs != null) {
      localASN1EncodableVector.add(new DERTaggedObject(false, 2, this.authAttrs));
    }
    localASN1EncodableVector.add(this.mac);
    if (this.unauthAttrs != null) {
      localASN1EncodableVector.add(new DERTaggedObject(false, 3, this.unauthAttrs));
    }
    return new BERSequence(localASN1EncodableVector);
  }
  
  public static int calculateVersion(OriginatorInfo paramOriginatorInfo)
  {
    if (paramOriginatorInfo == null) {
      return 0;
    }
    int i = 0;
    Enumeration localEnumeration = paramOriginatorInfo.getCertificates().getObjects();
    Object localObject;
    ASN1TaggedObject localASN1TaggedObject;
    while (localEnumeration.hasMoreElements())
    {
      localObject = localEnumeration.nextElement();
      if ((localObject instanceof ASN1TaggedObject))
      {
        localASN1TaggedObject = (ASN1TaggedObject)localObject;
        if (localASN1TaggedObject.getTagNo() == 2)
        {
          i = 1;
        }
        else if (localASN1TaggedObject.getTagNo() == 3)
        {
          i = 3;
          break;
        }
      }
    }
    localEnumeration = paramOriginatorInfo.getCRLs().getObjects();
    while (localEnumeration.hasMoreElements())
    {
      localObject = localEnumeration.nextElement();
      if ((localObject instanceof ASN1TaggedObject))
      {
        localASN1TaggedObject = (ASN1TaggedObject)localObject;
        if (localASN1TaggedObject.getTagNo() == 1)
        {
          i = 3;
          break;
        }
      }
    }
    return i;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\cms\AuthenticatedData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */