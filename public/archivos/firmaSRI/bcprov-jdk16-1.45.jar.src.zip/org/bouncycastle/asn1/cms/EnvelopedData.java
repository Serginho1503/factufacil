package org.bouncycastle.asn1.cms;

import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.BERSequence;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERTaggedObject;

public class EnvelopedData
  extends ASN1Encodable
{
  private DERInteger version;
  private OriginatorInfo originatorInfo;
  private ASN1Set recipientInfos;
  private EncryptedContentInfo encryptedContentInfo;
  private ASN1Set unprotectedAttrs;
  
  public EnvelopedData(OriginatorInfo paramOriginatorInfo, ASN1Set paramASN1Set1, EncryptedContentInfo paramEncryptedContentInfo, ASN1Set paramASN1Set2)
  {
    if ((paramOriginatorInfo != null) || (paramASN1Set2 != null))
    {
      this.version = new DERInteger(2);
    }
    else
    {
      this.version = new DERInteger(0);
      Enumeration localEnumeration = paramASN1Set1.getObjects();
      while (localEnumeration.hasMoreElements())
      {
        RecipientInfo localRecipientInfo = RecipientInfo.getInstance(localEnumeration.nextElement());
        if (!localRecipientInfo.getVersion().equals(this.version))
        {
          this.version = new DERInteger(2);
          break;
        }
      }
    }
    this.originatorInfo = paramOriginatorInfo;
    this.recipientInfos = paramASN1Set1;
    this.encryptedContentInfo = paramEncryptedContentInfo;
    this.unprotectedAttrs = paramASN1Set2;
  }
  
  public EnvelopedData(ASN1Sequence paramASN1Sequence)
  {
    int i = 0;
    this.version = ((DERInteger)paramASN1Sequence.getObjectAt(i++));
    DEREncodable localDEREncodable = paramASN1Sequence.getObjectAt(i++);
    if ((localDEREncodable instanceof ASN1TaggedObject))
    {
      this.originatorInfo = OriginatorInfo.getInstance((ASN1TaggedObject)localDEREncodable, false);
      localDEREncodable = paramASN1Sequence.getObjectAt(i++);
    }
    this.recipientInfos = ASN1Set.getInstance(localDEREncodable);
    this.encryptedContentInfo = EncryptedContentInfo.getInstance(paramASN1Sequence.getObjectAt(i++));
    if (paramASN1Sequence.size() > i) {
      this.unprotectedAttrs = ASN1Set.getInstance((ASN1TaggedObject)paramASN1Sequence.getObjectAt(i), false);
    }
  }
  
  public static EnvelopedData getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1Sequence.getInstance(paramASN1TaggedObject, paramBoolean));
  }
  
  public static EnvelopedData getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof EnvelopedData))) {
      return (EnvelopedData)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new EnvelopedData((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("Invalid EnvelopedData: " + paramObject.getClass().getName());
  }
  
  public DERInteger getVersion()
  {
    return this.version;
  }
  
  public OriginatorInfo getOriginatorInfo()
  {
    return this.originatorInfo;
  }
  
  public ASN1Set getRecipientInfos()
  {
    return this.recipientInfos;
  }
  
  public EncryptedContentInfo getEncryptedContentInfo()
  {
    return this.encryptedContentInfo;
  }
  
  public ASN1Set getUnprotectedAttrs()
  {
    return this.unprotectedAttrs;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.version);
    if (this.originatorInfo != null) {
      localASN1EncodableVector.add(new DERTaggedObject(false, 0, this.originatorInfo));
    }
    localASN1EncodableVector.add(this.recipientInfos);
    localASN1EncodableVector.add(this.encryptedContentInfo);
    if (this.unprotectedAttrs != null) {
      localASN1EncodableVector.add(new DERTaggedObject(false, 1, this.unprotectedAttrs));
    }
    return new BERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\cms\EnvelopedData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */