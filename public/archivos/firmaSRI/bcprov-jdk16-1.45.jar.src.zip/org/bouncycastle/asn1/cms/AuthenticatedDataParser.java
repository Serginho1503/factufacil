package org.bouncycastle.asn1.cms;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1SequenceParser;
import org.bouncycastle.asn1.ASN1SetParser;
import org.bouncycastle.asn1.ASN1TaggedObjectParser;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class AuthenticatedDataParser
{
  private ASN1SequenceParser seq;
  private DERInteger version;
  private DEREncodable nextObject;
  private boolean originatorInfoCalled;
  
  public AuthenticatedDataParser(ASN1SequenceParser paramASN1SequenceParser)
    throws IOException
  {
    this.seq = paramASN1SequenceParser;
    this.version = ((DERInteger)paramASN1SequenceParser.readObject());
  }
  
  public DERInteger getVersion()
  {
    return this.version;
  }
  
  public OriginatorInfo getOriginatorInfo()
    throws IOException
  {
    this.originatorInfoCalled = true;
    if (this.nextObject == null) {
      this.nextObject = this.seq.readObject();
    }
    if (((this.nextObject instanceof ASN1TaggedObjectParser)) && (((ASN1TaggedObjectParser)this.nextObject).getTagNo() == 0))
    {
      ASN1SequenceParser localASN1SequenceParser = (ASN1SequenceParser)((ASN1TaggedObjectParser)this.nextObject).getObjectParser(16, false);
      this.nextObject = null;
      return OriginatorInfo.getInstance(localASN1SequenceParser.getDERObject());
    }
    return null;
  }
  
  public ASN1SetParser getRecipientInfos()
    throws IOException
  {
    if (!this.originatorInfoCalled) {
      getOriginatorInfo();
    }
    if (this.nextObject == null) {
      this.nextObject = this.seq.readObject();
    }
    ASN1SetParser localASN1SetParser = (ASN1SetParser)this.nextObject;
    this.nextObject = null;
    return localASN1SetParser;
  }
  
  public AlgorithmIdentifier getMacAlgorithm()
    throws IOException
  {
    if (this.nextObject == null) {
      this.nextObject = this.seq.readObject();
    }
    if (this.nextObject != null)
    {
      ASN1SequenceParser localASN1SequenceParser = (ASN1SequenceParser)this.nextObject;
      this.nextObject = null;
      return AlgorithmIdentifier.getInstance(localASN1SequenceParser.getDERObject());
    }
    return null;
  }
  
  public ContentInfoParser getEnapsulatedContentInfo()
    throws IOException
  {
    if (this.nextObject == null) {
      this.nextObject = this.seq.readObject();
    }
    if (this.nextObject != null)
    {
      ASN1SequenceParser localASN1SequenceParser = (ASN1SequenceParser)this.nextObject;
      this.nextObject = null;
      return new ContentInfoParser(localASN1SequenceParser);
    }
    return null;
  }
  
  public ASN1SetParser getAuthAttrs()
    throws IOException
  {
    if (this.nextObject == null) {
      this.nextObject = this.seq.readObject();
    }
    if ((this.nextObject instanceof ASN1TaggedObjectParser))
    {
      DEREncodable localDEREncodable = this.nextObject;
      this.nextObject = null;
      return (ASN1SetParser)((ASN1TaggedObjectParser)localDEREncodable).getObjectParser(17, false);
    }
    return null;
  }
  
  public ASN1OctetString getMac()
    throws IOException
  {
    if (this.nextObject == null) {
      this.nextObject = this.seq.readObject();
    }
    DEREncodable localDEREncodable = this.nextObject;
    this.nextObject = null;
    return ASN1OctetString.getInstance(localDEREncodable.getDERObject());
  }
  
  public ASN1SetParser getUnauthAttrs()
    throws IOException
  {
    if (this.nextObject == null) {
      this.nextObject = this.seq.readObject();
    }
    if (this.nextObject != null)
    {
      DEREncodable localDEREncodable = this.nextObject;
      this.nextObject = null;
      return (ASN1SetParser)((ASN1TaggedObjectParser)localDEREncodable).getObjectParser(17, false);
    }
    return null;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\cms\AuthenticatedDataParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */