package org.bouncycastle.asn1.cms;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.BERSequence;
import org.bouncycastle.asn1.BERTaggedObject;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;

public class EncryptedData
  extends ASN1Encodable
{
  private DERInteger version;
  private EncryptedContentInfo encryptedContentInfo;
  private ASN1Set unprotectedAttrs;
  
  public static EncryptedData getInstance(Object paramObject)
  {
    if ((paramObject instanceof EncryptedData)) {
      return (EncryptedData)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new EncryptedData((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("Invalid EncryptedData: " + paramObject.getClass().getName());
  }
  
  public EncryptedData(EncryptedContentInfo paramEncryptedContentInfo)
  {
    this(paramEncryptedContentInfo, null);
  }
  
  public EncryptedData(EncryptedContentInfo paramEncryptedContentInfo, ASN1Set paramASN1Set)
  {
    this.version = new DERInteger(paramASN1Set == null ? 0 : 2);
    this.encryptedContentInfo = paramEncryptedContentInfo;
    this.unprotectedAttrs = paramASN1Set;
  }
  
  private EncryptedData(ASN1Sequence paramASN1Sequence)
  {
    this.version = DERInteger.getInstance(paramASN1Sequence.getObjectAt(0));
    this.encryptedContentInfo = EncryptedContentInfo.getInstance(paramASN1Sequence.getObjectAt(1));
    if (paramASN1Sequence.size() == 3) {
      this.unprotectedAttrs = ASN1Set.getInstance(paramASN1Sequence.getObjectAt(2));
    }
  }
  
  public DERInteger getVersion()
  {
    return this.version;
  }
  
  public EncryptedContentInfo getEncryptedContentInfo()
  {
    return this.encryptedContentInfo;
  }
  
  public ASN1Set getUnprotectedAttrs()
  {
    return this.unprotectedAttrs;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.version);
    localASN1EncodableVector.add(this.encryptedContentInfo);
    if (this.unprotectedAttrs != null) {
      localASN1EncodableVector.add(new BERTaggedObject(false, 1, this.unprotectedAttrs));
    }
    return new BERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\cms\EncryptedData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */