package org.bouncycastle.asn1.cms;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1SequenceParser;
import org.bouncycastle.asn1.ASN1TaggedObjectParser;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class EncryptedContentInfoParser
{
  private DERObjectIdentifier _contentType;
  private AlgorithmIdentifier _contentEncryptionAlgorithm;
  private ASN1TaggedObjectParser _encryptedContent;
  
  public EncryptedContentInfoParser(ASN1SequenceParser paramASN1SequenceParser)
    throws IOException
  {
    this._contentType = ((DERObjectIdentifier)paramASN1SequenceParser.readObject());
    this._contentEncryptionAlgorithm = AlgorithmIdentifier.getInstance(paramASN1SequenceParser.readObject().getDERObject());
    this._encryptedContent = ((ASN1TaggedObjectParser)paramASN1SequenceParser.readObject());
  }
  
  public DERObjectIdentifier getContentType()
  {
    return this._contentType;
  }
  
  public AlgorithmIdentifier getContentEncryptionAlgorithm()
  {
    return this._contentEncryptionAlgorithm;
  }
  
  public DEREncodable getEncryptedContent(int paramInt)
    throws IOException
  {
    return this._encryptedContent.getObjectParser(paramInt, false);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\cms\EncryptedContentInfoParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */