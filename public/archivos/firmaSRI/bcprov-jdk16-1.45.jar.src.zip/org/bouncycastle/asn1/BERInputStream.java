package org.bouncycastle.asn1;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Vector;

/**
 * @deprecated
 */
public class BERInputStream
  extends DERInputStream
{
  private static final DERObject END_OF_STREAM = new DERObject()
  {
    void encode(DEROutputStream paramAnonymousDEROutputStream)
      throws IOException
    {
      throw new IOException("Eeek!");
    }
    
    public int hashCode()
    {
      return 0;
    }
    
    public boolean equals(Object paramAnonymousObject)
    {
      return paramAnonymousObject == this;
    }
  };
  
  public BERInputStream(InputStream paramInputStream)
  {
    super(paramInputStream);
  }
  
  private byte[] readIndefiniteLengthFully()
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    int i;
    for (int j = read(); ((i = read()) >= 0) && ((j != 0) || (i != 0)); j = i) {
      localByteArrayOutputStream.write(j);
    }
    return localByteArrayOutputStream.toByteArray();
  }
  
  private BERConstructedOctetString buildConstructedOctetString()
    throws IOException
  {
    Vector localVector = new Vector();
    for (;;)
    {
      DERObject localDERObject = readObject();
      if (localDERObject == END_OF_STREAM) {
        break;
      }
      localVector.addElement(localDERObject);
    }
    return new BERConstructedOctetString(localVector);
  }
  
  public DERObject readObject()
    throws IOException
  {
    int i = read();
    if (i == -1) {
      throw new EOFException();
    }
    int j = readLength();
    if (j < 0)
    {
      Object localObject2;
      Object localObject3;
      switch (i)
      {
      case 5: 
        return null;
      case 48: 
        localObject1 = new BERConstructedSequence();
        for (;;)
        {
          localObject2 = readObject();
          if (localObject2 == END_OF_STREAM) {
            break;
          }
          ((BERConstructedSequence)localObject1).addObject((DEREncodable)localObject2);
        }
        return (DERObject)localObject1;
      case 36: 
        return buildConstructedOctetString();
      case 49: 
        localObject2 = new ASN1EncodableVector();
        for (;;)
        {
          localObject3 = readObject();
          if (localObject3 == END_OF_STREAM) {
            break;
          }
          ((ASN1EncodableVector)localObject2).add((DEREncodable)localObject3);
        }
        return new BERSet((DEREncodableVector)localObject2);
      }
      if ((i & 0x80) != 0)
      {
        if ((i & 0x1F) == 31) {
          throw new IOException("unsupported high tag encountered");
        }
        if ((i & 0x20) == 0)
        {
          localObject3 = readIndefiniteLengthFully();
          return new BERTaggedObject(false, i & 0x1F, new DEROctetString((byte[])localObject3));
        }
        localObject3 = readObject();
        if (localObject3 == END_OF_STREAM) {
          return new DERTaggedObject(i & 0x1F);
        }
        DERObject localDERObject = readObject();
        if (localDERObject == END_OF_STREAM) {
          return new BERTaggedObject(i & 0x1F, (DEREncodable)localObject3);
        }
        localObject1 = new BERConstructedSequence();
        ((BERConstructedSequence)localObject1).addObject((DEREncodable)localObject3);
        do
        {
          ((BERConstructedSequence)localObject1).addObject(localDERObject);
          localDERObject = readObject();
        } while (localDERObject != END_OF_STREAM);
        return new BERTaggedObject(false, i & 0x1F, (DEREncodable)localObject1);
      }
      throw new IOException("unknown BER object encountered");
    }
    if ((i == 0) && (j == 0)) {
      return END_OF_STREAM;
    }
    Object localObject1 = new byte[j];
    readFully((byte[])localObject1);
    return buildObject(i, (byte[])localObject1);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\BERInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */