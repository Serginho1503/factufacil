package org.bouncycastle.asn1;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Enumeration;

/**
 * @deprecated
 */
public class DERConstructedSequence
  extends ASN1Sequence
{
  public void addObject(DEREncodable paramDEREncodable)
  {
    super.addObject(paramDEREncodable);
  }
  
  public int getSize()
  {
    return size();
  }
  
  void encode(DEROutputStream paramDEROutputStream)
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    DEROutputStream localDEROutputStream = new DEROutputStream(localByteArrayOutputStream);
    Enumeration localEnumeration = getObjects();
    while (localEnumeration.hasMoreElements())
    {
      localObject = localEnumeration.nextElement();
      localDEROutputStream.writeObject(localObject);
    }
    localDEROutputStream.close();
    Object localObject = localByteArrayOutputStream.toByteArray();
    paramDEROutputStream.writeEncoded(48, (byte[])localObject);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\DERConstructedSequence.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */