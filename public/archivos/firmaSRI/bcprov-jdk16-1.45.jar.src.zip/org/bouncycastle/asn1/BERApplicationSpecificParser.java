package org.bouncycastle.asn1;

import java.io.IOException;

public class BERApplicationSpecificParser
  implements ASN1ApplicationSpecificParser
{
  private final int tag;
  private final ASN1StreamParser parser;
  
  BERApplicationSpecificParser(int paramInt, ASN1StreamParser paramASN1StreamParser)
  {
    this.tag = paramInt;
    this.parser = paramASN1StreamParser;
  }
  
  public DEREncodable readObject()
    throws IOException
  {
    return this.parser.readObject();
  }
  
  public DERObject getDERObject()
  {
    try
    {
      return new BERApplicationSpecific(this.tag, this.parser.readVector());
    }
    catch (IOException localIOException)
    {
      throw new ASN1ParsingException(localIOException.getMessage(), localIOException);
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\BERApplicationSpecificParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */