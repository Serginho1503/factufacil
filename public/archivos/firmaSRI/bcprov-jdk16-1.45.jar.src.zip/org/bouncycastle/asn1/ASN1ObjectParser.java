package org.bouncycastle.asn1;

import java.io.InputStream;

/**
 * @deprecated
 */
public class ASN1ObjectParser
{
  ASN1StreamParser _aIn;
  
  protected ASN1ObjectParser(int paramInt1, int paramInt2, InputStream paramInputStream)
  {
    this._aIn = new ASN1StreamParser(paramInputStream);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\ASN1ObjectParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */