package org.bouncycastle.asn1.sec;

import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.x9.X9ObjectIdentifiers;

public abstract interface SECObjectIdentifiers
{
  public static final DERObjectIdentifier ellipticCurve = new DERObjectIdentifier("1.3.132.0");
  public static final DERObjectIdentifier sect163k1 = new DERObjectIdentifier(ellipticCurve + ".1");
  public static final DERObjectIdentifier sect163r1 = new DERObjectIdentifier(ellipticCurve + ".2");
  public static final DERObjectIdentifier sect239k1 = new DERObjectIdentifier(ellipticCurve + ".3");
  public static final DERObjectIdentifier sect113r1 = new DERObjectIdentifier(ellipticCurve + ".4");
  public static final DERObjectIdentifier sect113r2 = new DERObjectIdentifier(ellipticCurve + ".5");
  public static final DERObjectIdentifier secp112r1 = new DERObjectIdentifier(ellipticCurve + ".6");
  public static final DERObjectIdentifier secp112r2 = new DERObjectIdentifier(ellipticCurve + ".7");
  public static final DERObjectIdentifier secp160r1 = new DERObjectIdentifier(ellipticCurve + ".8");
  public static final DERObjectIdentifier secp160k1 = new DERObjectIdentifier(ellipticCurve + ".9");
  public static final DERObjectIdentifier secp256k1 = new DERObjectIdentifier(ellipticCurve + ".10");
  public static final DERObjectIdentifier sect163r2 = new DERObjectIdentifier(ellipticCurve + ".15");
  public static final DERObjectIdentifier sect283k1 = new DERObjectIdentifier(ellipticCurve + ".16");
  public static final DERObjectIdentifier sect283r1 = new DERObjectIdentifier(ellipticCurve + ".17");
  public static final DERObjectIdentifier sect131r1 = new DERObjectIdentifier(ellipticCurve + ".22");
  public static final DERObjectIdentifier sect131r2 = new DERObjectIdentifier(ellipticCurve + ".23");
  public static final DERObjectIdentifier sect193r1 = new DERObjectIdentifier(ellipticCurve + ".24");
  public static final DERObjectIdentifier sect193r2 = new DERObjectIdentifier(ellipticCurve + ".25");
  public static final DERObjectIdentifier sect233k1 = new DERObjectIdentifier(ellipticCurve + ".26");
  public static final DERObjectIdentifier sect233r1 = new DERObjectIdentifier(ellipticCurve + ".27");
  public static final DERObjectIdentifier secp128r1 = new DERObjectIdentifier(ellipticCurve + ".28");
  public static final DERObjectIdentifier secp128r2 = new DERObjectIdentifier(ellipticCurve + ".29");
  public static final DERObjectIdentifier secp160r2 = new DERObjectIdentifier(ellipticCurve + ".30");
  public static final DERObjectIdentifier secp192k1 = new DERObjectIdentifier(ellipticCurve + ".31");
  public static final DERObjectIdentifier secp224k1 = new DERObjectIdentifier(ellipticCurve + ".32");
  public static final DERObjectIdentifier secp224r1 = new DERObjectIdentifier(ellipticCurve + ".33");
  public static final DERObjectIdentifier secp384r1 = new DERObjectIdentifier(ellipticCurve + ".34");
  public static final DERObjectIdentifier secp521r1 = new DERObjectIdentifier(ellipticCurve + ".35");
  public static final DERObjectIdentifier sect409k1 = new DERObjectIdentifier(ellipticCurve + ".36");
  public static final DERObjectIdentifier sect409r1 = new DERObjectIdentifier(ellipticCurve + ".37");
  public static final DERObjectIdentifier sect571k1 = new DERObjectIdentifier(ellipticCurve + ".38");
  public static final DERObjectIdentifier sect571r1 = new DERObjectIdentifier(ellipticCurve + ".39");
  public static final DERObjectIdentifier secp192r1 = X9ObjectIdentifiers.prime192v1;
  public static final DERObjectIdentifier secp256r1 = X9ObjectIdentifiers.prime256v1;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\sec\SECObjectIdentifiers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */