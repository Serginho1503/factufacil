package org.bouncycastle.asn1.sec;

import java.math.BigInteger;
import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.util.BigIntegers;

public class ECPrivateKeyStructure
  extends ASN1Encodable
{
  private ASN1Sequence seq;
  
  public ECPrivateKeyStructure(ASN1Sequence paramASN1Sequence)
  {
    this.seq = paramASN1Sequence;
  }
  
  public ECPrivateKeyStructure(BigInteger paramBigInteger)
  {
    byte[] arrayOfByte = BigIntegers.asUnsignedByteArray(paramBigInteger);
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(new DERInteger(1));
    localASN1EncodableVector.add(new DEROctetString(arrayOfByte));
    this.seq = new DERSequence(localASN1EncodableVector);
  }
  
  public ECPrivateKeyStructure(BigInteger paramBigInteger, ASN1Encodable paramASN1Encodable)
  {
    this(paramBigInteger, null, paramASN1Encodable);
  }
  
  public ECPrivateKeyStructure(BigInteger paramBigInteger, DERBitString paramDERBitString, ASN1Encodable paramASN1Encodable)
  {
    byte[] arrayOfByte = BigIntegers.asUnsignedByteArray(paramBigInteger);
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(new DERInteger(1));
    localASN1EncodableVector.add(new DEROctetString(arrayOfByte));
    if (paramASN1Encodable != null) {
      localASN1EncodableVector.add(new DERTaggedObject(true, 0, paramASN1Encodable));
    }
    if (paramDERBitString != null) {
      localASN1EncodableVector.add(new DERTaggedObject(true, 1, paramDERBitString));
    }
    this.seq = new DERSequence(localASN1EncodableVector);
  }
  
  public BigInteger getKey()
  {
    ASN1OctetString localASN1OctetString = (ASN1OctetString)this.seq.getObjectAt(1);
    return new BigInteger(1, localASN1OctetString.getOctets());
  }
  
  public DERBitString getPublicKey()
  {
    return (DERBitString)getObjectInTag(1);
  }
  
  public ASN1Object getParameters()
  {
    return getObjectInTag(0);
  }
  
  private ASN1Object getObjectInTag(int paramInt)
  {
    Enumeration localEnumeration = this.seq.getObjects();
    while (localEnumeration.hasMoreElements())
    {
      DEREncodable localDEREncodable = (DEREncodable)localEnumeration.nextElement();
      if ((localDEREncodable instanceof ASN1TaggedObject))
      {
        ASN1TaggedObject localASN1TaggedObject = (ASN1TaggedObject)localDEREncodable;
        if (localASN1TaggedObject.getTagNo() == paramInt) {
          return (ASN1Object)localASN1TaggedObject.getObject().getDERObject();
        }
      }
    }
    return null;
  }
  
  public DERObject toASN1Object()
  {
    return this.seq;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\sec\ECPrivateKeyStructure.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */