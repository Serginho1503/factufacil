package org.bouncycastle.asn1;

import java.io.IOException;

public class DERGeneralString
  extends ASN1Object
  implements DERString
{
  private String string;
  
  public static DERGeneralString getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof DERGeneralString))) {
      return (DERGeneralString)paramObject;
    }
    if ((paramObject instanceof ASN1OctetString)) {
      return new DERGeneralString(((ASN1OctetString)paramObject).getOctets());
    }
    if ((paramObject instanceof ASN1TaggedObject)) {
      return getInstance(((ASN1TaggedObject)paramObject).getObject());
    }
    throw new IllegalArgumentException("illegal object in getInstance: " + paramObject.getClass().getName());
  }
  
  public static DERGeneralString getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(paramASN1TaggedObject.getObject());
  }
  
  public DERGeneralString(byte[] paramArrayOfByte)
  {
    char[] arrayOfChar = new char[paramArrayOfByte.length];
    for (int i = 0; i != arrayOfChar.length; i++) {
      arrayOfChar[i] = ((char)(paramArrayOfByte[i] & 0xFF));
    }
    this.string = new String(arrayOfChar);
  }
  
  public DERGeneralString(String paramString)
  {
    this.string = paramString;
  }
  
  public String getString()
  {
    return this.string;
  }
  
  public String toString()
  {
    return this.string;
  }
  
  public byte[] getOctets()
  {
    char[] arrayOfChar = this.string.toCharArray();
    byte[] arrayOfByte = new byte[arrayOfChar.length];
    for (int i = 0; i != arrayOfChar.length; i++) {
      arrayOfByte[i] = ((byte)arrayOfChar[i]);
    }
    return arrayOfByte;
  }
  
  void encode(DEROutputStream paramDEROutputStream)
    throws IOException
  {
    paramDEROutputStream.writeEncoded(27, getOctets());
  }
  
  public int hashCode()
  {
    return getString().hashCode();
  }
  
  boolean asn1Equals(DERObject paramDERObject)
  {
    if (!(paramDERObject instanceof DERGeneralString)) {
      return false;
    }
    DERGeneralString localDERGeneralString = (DERGeneralString)paramDERObject;
    return getString().equals(localDERGeneralString.getString());
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\DERGeneralString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */