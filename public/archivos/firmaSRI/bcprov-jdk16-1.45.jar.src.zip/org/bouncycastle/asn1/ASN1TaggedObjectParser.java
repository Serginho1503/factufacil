package org.bouncycastle.asn1;

import java.io.IOException;

public abstract interface ASN1TaggedObjectParser
  extends DEREncodable
{
  public abstract int getTagNo();
  
  public abstract DEREncodable getObjectParser(int paramInt, boolean paramBoolean)
    throws IOException;
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\ASN1TaggedObjectParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */