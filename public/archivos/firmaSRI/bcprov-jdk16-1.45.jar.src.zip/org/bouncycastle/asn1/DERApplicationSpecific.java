package org.bouncycastle.asn1;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import org.bouncycastle.util.Arrays;

public class DERApplicationSpecific
  extends ASN1Object
{
  private final boolean isConstructed;
  private final int tag;
  private final byte[] octets;
  
  DERApplicationSpecific(boolean paramBoolean, int paramInt, byte[] paramArrayOfByte)
  {
    this.isConstructed = paramBoolean;
    this.tag = paramInt;
    this.octets = paramArrayOfByte;
  }
  
  public DERApplicationSpecific(int paramInt, byte[] paramArrayOfByte)
  {
    this(false, paramInt, paramArrayOfByte);
  }
  
  public DERApplicationSpecific(int paramInt, DEREncodable paramDEREncodable)
    throws IOException
  {
    this(true, paramInt, paramDEREncodable);
  }
  
  public DERApplicationSpecific(boolean paramBoolean, int paramInt, DEREncodable paramDEREncodable)
    throws IOException
  {
    byte[] arrayOfByte1 = paramDEREncodable.getDERObject().getDEREncoded();
    this.isConstructed = paramBoolean;
    this.tag = paramInt;
    if (paramBoolean)
    {
      this.octets = arrayOfByte1;
    }
    else
    {
      int i = getLengthOfLength(arrayOfByte1);
      byte[] arrayOfByte2 = new byte[arrayOfByte1.length - i];
      System.arraycopy(arrayOfByte1, i, arrayOfByte2, 0, arrayOfByte2.length);
      this.octets = arrayOfByte2;
    }
  }
  
  public DERApplicationSpecific(int paramInt, ASN1EncodableVector paramASN1EncodableVector)
  {
    this.tag = paramInt;
    this.isConstructed = true;
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    for (int i = 0; i != paramASN1EncodableVector.size(); i++) {
      try
      {
        localByteArrayOutputStream.write(((ASN1Encodable)paramASN1EncodableVector.get(i)).getEncoded());
      }
      catch (IOException localIOException)
      {
        throw new ASN1ParsingException("malformed object: " + localIOException, localIOException);
      }
    }
    this.octets = localByteArrayOutputStream.toByteArray();
  }
  
  private int getLengthOfLength(byte[] paramArrayOfByte)
  {
    for (int i = 2; (paramArrayOfByte[(i - 1)] & 0x80) != 0; i++) {}
    return i;
  }
  
  public boolean isConstructed()
  {
    return this.isConstructed;
  }
  
  public byte[] getContents()
  {
    return this.octets;
  }
  
  public int getApplicationTag()
  {
    return this.tag;
  }
  
  public DERObject getObject()
    throws IOException
  {
    return new ASN1InputStream(getContents()).readObject();
  }
  
  public DERObject getObject(int paramInt)
    throws IOException
  {
    if (paramInt >= 31) {
      throw new IOException("unsupported tag number");
    }
    byte[] arrayOfByte1 = getEncoded();
    byte[] arrayOfByte2 = replaceTagNumber(paramInt, arrayOfByte1);
    if ((arrayOfByte1[0] & 0x20) != 0)
    {
      int tmp39_38 = 0;
      byte[] tmp39_37 = arrayOfByte2;
      tmp39_37[tmp39_38] = ((byte)(tmp39_37[tmp39_38] | 0x20));
    }
    return new ASN1InputStream(arrayOfByte2).readObject();
  }
  
  void encode(DEROutputStream paramDEROutputStream)
    throws IOException
  {
    int i = 64;
    if (this.isConstructed) {
      i |= 0x20;
    }
    paramDEROutputStream.writeEncoded(i, this.tag, this.octets);
  }
  
  boolean asn1Equals(DERObject paramDERObject)
  {
    if (!(paramDERObject instanceof DERApplicationSpecific)) {
      return false;
    }
    DERApplicationSpecific localDERApplicationSpecific = (DERApplicationSpecific)paramDERObject;
    return (this.isConstructed == localDERApplicationSpecific.isConstructed) && (this.tag == localDERApplicationSpecific.tag) && (Arrays.areEqual(this.octets, localDERApplicationSpecific.octets));
  }
  
  public int hashCode()
  {
    return (this.isConstructed ? 1 : 0) ^ this.tag ^ Arrays.hashCode(this.octets);
  }
  
  private byte[] replaceTagNumber(int paramInt, byte[] paramArrayOfByte)
    throws IOException
  {
    int i = paramArrayOfByte[0] & 0x1F;
    int j = 1;
    if (i == 31)
    {
      i = 0;
      int k = paramArrayOfByte[(j++)] & 0xFF;
      if ((k & 0x7F) == 0) {
        throw new ASN1ParsingException("corrupted stream - invalid high tag number found");
      }
      while ((k >= 0) && ((k & 0x80) != 0))
      {
        i |= k & 0x7F;
        i <<= 7;
        k = paramArrayOfByte[(j++)] & 0xFF;
      }
      i |= k & 0x7F;
    }
    byte[] arrayOfByte = new byte[paramArrayOfByte.length - j + 1];
    System.arraycopy(paramArrayOfByte, j, arrayOfByte, 1, arrayOfByte.length - 1);
    arrayOfByte[0] = ((byte)paramInt);
    return arrayOfByte;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\DERApplicationSpecific.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */