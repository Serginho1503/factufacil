package org.bouncycastle.asn1;

import java.io.IOException;
import org.bouncycastle.util.Arrays;

public class DERUnknownTag
  extends DERObject
{
  private boolean isConstructed;
  private int tag;
  private byte[] data;
  
  public DERUnknownTag(int paramInt, byte[] paramArrayOfByte)
  {
    this(false, paramInt, paramArrayOfByte);
  }
  
  public DERUnknownTag(boolean paramBoolean, int paramInt, byte[] paramArrayOfByte)
  {
    this.isConstructed = paramBoolean;
    this.tag = paramInt;
    this.data = paramArrayOfByte;
  }
  
  public boolean isConstructed()
  {
    return this.isConstructed;
  }
  
  public int getTag()
  {
    return this.tag;
  }
  
  public byte[] getData()
  {
    return this.data;
  }
  
  void encode(DEROutputStream paramDEROutputStream)
    throws IOException
  {
    paramDEROutputStream.writeEncoded(this.isConstructed ? 32 : 0, this.tag, this.data);
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof DERUnknownTag)) {
      return false;
    }
    DERUnknownTag localDERUnknownTag = (DERUnknownTag)paramObject;
    return (this.isConstructed == localDERUnknownTag.isConstructed) && (this.tag == localDERUnknownTag.tag) && (Arrays.areEqual(this.data, localDERUnknownTag.data));
  }
  
  public int hashCode()
  {
    return (this.isConstructed ? -1 : 0) ^ this.tag ^ Arrays.hashCode(this.data);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\DERUnknownTag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */