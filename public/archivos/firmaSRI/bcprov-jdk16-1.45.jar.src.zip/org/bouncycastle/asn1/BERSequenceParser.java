package org.bouncycastle.asn1;

import java.io.IOException;

public class BERSequenceParser
  implements ASN1SequenceParser
{
  private ASN1StreamParser _parser;
  
  BERSequenceParser(ASN1StreamParser paramASN1StreamParser)
  {
    this._parser = paramASN1StreamParser;
  }
  
  public DEREncodable readObject()
    throws IOException
  {
    return this._parser.readObject();
  }
  
  public DERObject getDERObject()
  {
    try
    {
      return new BERSequence(this._parser.readVector());
    }
    catch (IOException localIOException)
    {
      throw new IllegalStateException(localIOException.getMessage());
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\BERSequenceParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */