package org.bouncycastle.asn1.icao;

import java.math.BigInteger;
import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;

public class DataGroupHash
  extends ASN1Encodable
{
  DERInteger dataGroupNumber;
  ASN1OctetString dataGroupHashValue;
  
  public static DataGroupHash getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof DataGroupHash))) {
      return (DataGroupHash)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new DataGroupHash(ASN1Sequence.getInstance(paramObject));
    }
    throw new IllegalArgumentException("unknown object in getInstance: " + paramObject.getClass().getName());
  }
  
  public DataGroupHash(ASN1Sequence paramASN1Sequence)
  {
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    this.dataGroupNumber = DERInteger.getInstance(localEnumeration.nextElement());
    this.dataGroupHashValue = ASN1OctetString.getInstance(localEnumeration.nextElement());
  }
  
  public DataGroupHash(int paramInt, ASN1OctetString paramASN1OctetString)
  {
    this.dataGroupNumber = new DERInteger(paramInt);
    this.dataGroupHashValue = paramASN1OctetString;
  }
  
  public int getDataGroupNumber()
  {
    return this.dataGroupNumber.getValue().intValue();
  }
  
  public ASN1OctetString getDataGroupHashValue()
  {
    return this.dataGroupHashValue;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.dataGroupNumber);
    localASN1EncodableVector.add(this.dataGroupHashValue);
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\icao\DataGroupHash.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */