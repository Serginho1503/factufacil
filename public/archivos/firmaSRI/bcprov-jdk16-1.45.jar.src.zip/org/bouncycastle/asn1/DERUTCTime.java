package org.bouncycastle.asn1;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.SimpleTimeZone;

public class DERUTCTime
  extends ASN1Object
{
  String time;
  
  public static DERUTCTime getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof DERUTCTime))) {
      return (DERUTCTime)paramObject;
    }
    if ((paramObject instanceof ASN1OctetString)) {
      return new DERUTCTime(((ASN1OctetString)paramObject).getOctets());
    }
    throw new IllegalArgumentException("illegal object in getInstance: " + paramObject.getClass().getName());
  }
  
  public static DERUTCTime getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(paramASN1TaggedObject.getObject());
  }
  
  public DERUTCTime(String paramString)
  {
    this.time = paramString;
    try
    {
      getDate();
    }
    catch (ParseException localParseException)
    {
      throw new IllegalArgumentException("invalid date string: " + localParseException.getMessage());
    }
  }
  
  public DERUTCTime(Date paramDate)
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyMMddHHmmss'Z'");
    localSimpleDateFormat.setTimeZone(new SimpleTimeZone(0, "Z"));
    this.time = localSimpleDateFormat.format(paramDate);
  }
  
  DERUTCTime(byte[] paramArrayOfByte)
  {
    char[] arrayOfChar = new char[paramArrayOfByte.length];
    for (int i = 0; i != arrayOfChar.length; i++) {
      arrayOfChar[i] = ((char)(paramArrayOfByte[i] & 0xFF));
    }
    this.time = new String(arrayOfChar);
  }
  
  public Date getDate()
    throws ParseException
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyMMddHHmmssz");
    return localSimpleDateFormat.parse(getTime());
  }
  
  public Date getAdjustedDate()
    throws ParseException
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmssz");
    localSimpleDateFormat.setTimeZone(new SimpleTimeZone(0, "Z"));
    return localSimpleDateFormat.parse(getAdjustedTime());
  }
  
  public String getTime()
  {
    if ((this.time.indexOf('-') < 0) && (this.time.indexOf('+') < 0))
    {
      if (this.time.length() == 11) {
        return this.time.substring(0, 10) + "00GMT+00:00";
      }
      return this.time.substring(0, 12) + "GMT+00:00";
    }
    int i = this.time.indexOf('-');
    if (i < 0) {
      i = this.time.indexOf('+');
    }
    String str = this.time;
    if (i == this.time.length() - 3) {
      str = str + "00";
    }
    if (i == 10) {
      return str.substring(0, 10) + "00GMT" + str.substring(10, 13) + ":" + str.substring(13, 15);
    }
    return str.substring(0, 12) + "GMT" + str.substring(12, 15) + ":" + str.substring(15, 17);
  }
  
  public String getAdjustedTime()
  {
    String str = getTime();
    if (str.charAt(0) < '5') {
      return "20" + str;
    }
    return "19" + str;
  }
  
  private byte[] getOctets()
  {
    char[] arrayOfChar = this.time.toCharArray();
    byte[] arrayOfByte = new byte[arrayOfChar.length];
    for (int i = 0; i != arrayOfChar.length; i++) {
      arrayOfByte[i] = ((byte)arrayOfChar[i]);
    }
    return arrayOfByte;
  }
  
  void encode(DEROutputStream paramDEROutputStream)
    throws IOException
  {
    paramDEROutputStream.writeEncoded(23, getOctets());
  }
  
  boolean asn1Equals(DERObject paramDERObject)
  {
    if (!(paramDERObject instanceof DERUTCTime)) {
      return false;
    }
    return this.time.equals(((DERUTCTime)paramDERObject).time);
  }
  
  public int hashCode()
  {
    return this.time.hashCode();
  }
  
  public String toString()
  {
    return this.time;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\DERUTCTime.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */