package org.bouncycastle.asn1;

public class BERApplicationSpecific
  extends DERApplicationSpecific
{
  public BERApplicationSpecific(int paramInt, ASN1EncodableVector paramASN1EncodableVector)
  {
    super(paramInt, paramASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\BERApplicationSpecific.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */