package org.bouncycastle.asn1;

import java.io.IOException;
import java.util.Enumeration;

public class LazyDERSequence
  extends DERSequence
{
  private byte[] encoded;
  private boolean parsed = false;
  private int size = -1;
  
  LazyDERSequence(byte[] paramArrayOfByte)
    throws IOException
  {
    this.encoded = paramArrayOfByte;
  }
  
  private void parse()
  {
    LazyDERConstructionEnumeration localLazyDERConstructionEnumeration = new LazyDERConstructionEnumeration(this.encoded);
    while (localLazyDERConstructionEnumeration.hasMoreElements()) {
      addObject((DEREncodable)localLazyDERConstructionEnumeration.nextElement());
    }
    this.parsed = true;
  }
  
  public DEREncodable getObjectAt(int paramInt)
  {
    if (!this.parsed) {
      parse();
    }
    return super.getObjectAt(paramInt);
  }
  
  public Enumeration getObjects()
  {
    if (this.parsed) {
      return super.getObjects();
    }
    return new LazyDERConstructionEnumeration(this.encoded);
  }
  
  public int size()
  {
    if (this.size < 0)
    {
      LazyDERConstructionEnumeration localLazyDERConstructionEnumeration = new LazyDERConstructionEnumeration(this.encoded);
      for (this.size = 0; localLazyDERConstructionEnumeration.hasMoreElements(); this.size += 1) {
        localLazyDERConstructionEnumeration.nextElement();
      }
    }
    return this.size;
  }
  
  void encode(DEROutputStream paramDEROutputStream)
    throws IOException
  {
    paramDEROutputStream.writeEncoded(48, this.encoded);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\LazyDERSequence.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */