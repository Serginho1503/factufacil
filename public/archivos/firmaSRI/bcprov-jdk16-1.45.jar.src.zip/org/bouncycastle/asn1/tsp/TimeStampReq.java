package org.bouncycastle.asn1.tsp;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERBoolean;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.x509.X509Extensions;

public class TimeStampReq
  extends ASN1Encodable
{
  DERInteger version;
  MessageImprint messageImprint;
  DERObjectIdentifier tsaPolicy;
  DERInteger nonce;
  DERBoolean certReq;
  X509Extensions extensions;
  
  public static TimeStampReq getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof TimeStampReq))) {
      return (TimeStampReq)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new TimeStampReq((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("Unknown object in 'TimeStampReq' factory : " + paramObject.getClass().getName() + ".");
  }
  
  public TimeStampReq(ASN1Sequence paramASN1Sequence)
  {
    int i = paramASN1Sequence.size();
    int j = 0;
    this.version = DERInteger.getInstance(paramASN1Sequence.getObjectAt(j));
    j++;
    this.messageImprint = MessageImprint.getInstance(paramASN1Sequence.getObjectAt(j));
    j++;
    for (int k = j; k < i; k++) {
      if ((paramASN1Sequence.getObjectAt(k) instanceof DERObjectIdentifier))
      {
        this.tsaPolicy = DERObjectIdentifier.getInstance(paramASN1Sequence.getObjectAt(k));
      }
      else if ((paramASN1Sequence.getObjectAt(k) instanceof DERInteger))
      {
        this.nonce = DERInteger.getInstance(paramASN1Sequence.getObjectAt(k));
      }
      else if ((paramASN1Sequence.getObjectAt(k) instanceof DERBoolean))
      {
        this.certReq = DERBoolean.getInstance(paramASN1Sequence.getObjectAt(k));
      }
      else if ((paramASN1Sequence.getObjectAt(k) instanceof ASN1TaggedObject))
      {
        ASN1TaggedObject localASN1TaggedObject = (ASN1TaggedObject)paramASN1Sequence.getObjectAt(k);
        if (localASN1TaggedObject.getTagNo() == 0) {
          this.extensions = X509Extensions.getInstance(localASN1TaggedObject, false);
        }
      }
    }
  }
  
  public TimeStampReq(MessageImprint paramMessageImprint, DERObjectIdentifier paramDERObjectIdentifier, DERInteger paramDERInteger, DERBoolean paramDERBoolean, X509Extensions paramX509Extensions)
  {
    this.version = new DERInteger(1);
    this.messageImprint = paramMessageImprint;
    this.tsaPolicy = paramDERObjectIdentifier;
    this.nonce = paramDERInteger;
    this.certReq = paramDERBoolean;
    this.extensions = paramX509Extensions;
  }
  
  public DERInteger getVersion()
  {
    return this.version;
  }
  
  public MessageImprint getMessageImprint()
  {
    return this.messageImprint;
  }
  
  public DERObjectIdentifier getReqPolicy()
  {
    return this.tsaPolicy;
  }
  
  public DERInteger getNonce()
  {
    return this.nonce;
  }
  
  public DERBoolean getCertReq()
  {
    return this.certReq;
  }
  
  public X509Extensions getExtensions()
  {
    return this.extensions;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.version);
    localASN1EncodableVector.add(this.messageImprint);
    if (this.tsaPolicy != null) {
      localASN1EncodableVector.add(this.tsaPolicy);
    }
    if (this.nonce != null) {
      localASN1EncodableVector.add(this.nonce);
    }
    if ((this.certReq != null) && (this.certReq.isTrue())) {
      localASN1EncodableVector.add(this.certReq);
    }
    if (this.extensions != null) {
      localASN1EncodableVector.add(new DERTaggedObject(false, 0, this.extensions));
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\tsp\TimeStampReq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */