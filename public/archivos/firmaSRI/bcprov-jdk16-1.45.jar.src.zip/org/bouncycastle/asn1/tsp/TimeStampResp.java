package org.bouncycastle.asn1.tsp;

import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.cmp.PKIStatusInfo;
import org.bouncycastle.asn1.cms.ContentInfo;

public class TimeStampResp
  extends ASN1Encodable
{
  PKIStatusInfo pkiStatusInfo;
  ContentInfo timeStampToken;
  
  public static TimeStampResp getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof TimeStampResp))) {
      return (TimeStampResp)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new TimeStampResp((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in 'TimeStampResp' factory : " + paramObject.getClass().getName() + ".");
  }
  
  public TimeStampResp(ASN1Sequence paramASN1Sequence)
  {
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    this.pkiStatusInfo = PKIStatusInfo.getInstance(localEnumeration.nextElement());
    if (localEnumeration.hasMoreElements()) {
      this.timeStampToken = ContentInfo.getInstance(localEnumeration.nextElement());
    }
  }
  
  public TimeStampResp(PKIStatusInfo paramPKIStatusInfo, ContentInfo paramContentInfo)
  {
    this.pkiStatusInfo = paramPKIStatusInfo;
    this.timeStampToken = paramContentInfo;
  }
  
  public PKIStatusInfo getStatus()
  {
    return this.pkiStatusInfo;
  }
  
  public ContentInfo getTimeStampToken()
  {
    return this.timeStampToken;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.pkiStatusInfo);
    if (this.timeStampToken != null) {
      localASN1EncodableVector.add(this.timeStampToken);
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\tsp\TimeStampResp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */