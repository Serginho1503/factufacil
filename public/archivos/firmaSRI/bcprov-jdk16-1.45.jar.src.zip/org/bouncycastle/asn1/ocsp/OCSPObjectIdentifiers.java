package org.bouncycastle.asn1.ocsp;

import org.bouncycastle.asn1.DERObjectIdentifier;

public abstract interface OCSPObjectIdentifiers
{
  public static final String pkix_ocsp = "1.3.6.1.5.5.7.48.1";
  public static final DERObjectIdentifier id_pkix_ocsp = new DERObjectIdentifier("1.3.6.1.5.5.7.48.1");
  public static final DERObjectIdentifier id_pkix_ocsp_basic = new DERObjectIdentifier("1.3.6.1.5.5.7.48.1.1");
  public static final DERObjectIdentifier id_pkix_ocsp_nonce = new DERObjectIdentifier("1.3.6.1.5.5.7.48.1.2");
  public static final DERObjectIdentifier id_pkix_ocsp_crl = new DERObjectIdentifier("1.3.6.1.5.5.7.48.1.3");
  public static final DERObjectIdentifier id_pkix_ocsp_response = new DERObjectIdentifier("1.3.6.1.5.5.7.48.1.4");
  public static final DERObjectIdentifier id_pkix_ocsp_nocheck = new DERObjectIdentifier("1.3.6.1.5.5.7.48.1.5");
  public static final DERObjectIdentifier id_pkix_ocsp_archive_cutoff = new DERObjectIdentifier("1.3.6.1.5.5.7.48.1.6");
  public static final DERObjectIdentifier id_pkix_ocsp_service_locator = new DERObjectIdentifier("1.3.6.1.5.5.7.48.1.7");
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\ocsp\OCSPObjectIdentifiers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */