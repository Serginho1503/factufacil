package org.bouncycastle.asn1.ocsp;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class BasicOCSPResponse
  extends ASN1Encodable
{
  private ResponseData tbsResponseData;
  private AlgorithmIdentifier signatureAlgorithm;
  private DERBitString signature;
  private ASN1Sequence certs;
  
  public BasicOCSPResponse(ResponseData paramResponseData, AlgorithmIdentifier paramAlgorithmIdentifier, DERBitString paramDERBitString, ASN1Sequence paramASN1Sequence)
  {
    this.tbsResponseData = paramResponseData;
    this.signatureAlgorithm = paramAlgorithmIdentifier;
    this.signature = paramDERBitString;
    this.certs = paramASN1Sequence;
  }
  
  public BasicOCSPResponse(ASN1Sequence paramASN1Sequence)
  {
    this.tbsResponseData = ResponseData.getInstance(paramASN1Sequence.getObjectAt(0));
    this.signatureAlgorithm = AlgorithmIdentifier.getInstance(paramASN1Sequence.getObjectAt(1));
    this.signature = ((DERBitString)paramASN1Sequence.getObjectAt(2));
    if (paramASN1Sequence.size() > 3) {
      this.certs = ASN1Sequence.getInstance((ASN1TaggedObject)paramASN1Sequence.getObjectAt(3), true);
    }
  }
  
  public static BasicOCSPResponse getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1Sequence.getInstance(paramASN1TaggedObject, paramBoolean));
  }
  
  public static BasicOCSPResponse getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof BasicOCSPResponse))) {
      return (BasicOCSPResponse)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new BasicOCSPResponse((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in factory: " + paramObject.getClass().getName());
  }
  
  public ResponseData getTbsResponseData()
  {
    return this.tbsResponseData;
  }
  
  public AlgorithmIdentifier getSignatureAlgorithm()
  {
    return this.signatureAlgorithm;
  }
  
  public DERBitString getSignature()
  {
    return this.signature;
  }
  
  public ASN1Sequence getCerts()
  {
    return this.certs;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.tbsResponseData);
    localASN1EncodableVector.add(this.signatureAlgorithm);
    localASN1EncodableVector.add(this.signature);
    if (this.certs != null) {
      localASN1EncodableVector.add(new DERTaggedObject(true, 0, this.certs));
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\ocsp\BasicOCSPResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */