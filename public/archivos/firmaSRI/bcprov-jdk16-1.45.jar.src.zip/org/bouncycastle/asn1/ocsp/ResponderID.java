package org.bouncycastle.asn1.ocsp;

import org.bouncycastle.asn1.ASN1Choice;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.x509.X509Name;

public class ResponderID
  extends ASN1Encodable
  implements ASN1Choice
{
  private DEREncodable value;
  
  public ResponderID(ASN1OctetString paramASN1OctetString)
  {
    this.value = paramASN1OctetString;
  }
  
  public ResponderID(X509Name paramX509Name)
  {
    this.value = paramX509Name;
  }
  
  public static ResponderID getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof ResponderID))) {
      return (ResponderID)paramObject;
    }
    if ((paramObject instanceof DEROctetString)) {
      return new ResponderID((DEROctetString)paramObject);
    }
    if ((paramObject instanceof ASN1TaggedObject))
    {
      ASN1TaggedObject localASN1TaggedObject = (ASN1TaggedObject)paramObject;
      if (localASN1TaggedObject.getTagNo() == 1) {
        return new ResponderID(X509Name.getInstance(localASN1TaggedObject, true));
      }
      return new ResponderID(ASN1OctetString.getInstance(localASN1TaggedObject, true));
    }
    return new ResponderID(X509Name.getInstance(paramObject));
  }
  
  public static ResponderID getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(paramASN1TaggedObject.getObject());
  }
  
  public DERObject toASN1Object()
  {
    if ((this.value instanceof ASN1OctetString)) {
      return new DERTaggedObject(true, 2, this.value);
    }
    return new DERTaggedObject(true, 1, this.value);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\ocsp\ResponderID.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */