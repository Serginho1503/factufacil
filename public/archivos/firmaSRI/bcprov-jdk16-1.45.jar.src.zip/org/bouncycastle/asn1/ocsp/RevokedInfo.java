package org.bouncycastle.asn1.ocsp;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DEREnumerated;
import org.bouncycastle.asn1.DERGeneralizedTime;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.x509.CRLReason;

public class RevokedInfo
  extends ASN1Encodable
{
  private DERGeneralizedTime revocationTime;
  private CRLReason revocationReason;
  
  public RevokedInfo(DERGeneralizedTime paramDERGeneralizedTime, CRLReason paramCRLReason)
  {
    this.revocationTime = paramDERGeneralizedTime;
    this.revocationReason = paramCRLReason;
  }
  
  public RevokedInfo(ASN1Sequence paramASN1Sequence)
  {
    this.revocationTime = ((DERGeneralizedTime)paramASN1Sequence.getObjectAt(0));
    if (paramASN1Sequence.size() > 1) {
      this.revocationReason = new CRLReason(DEREnumerated.getInstance((ASN1TaggedObject)paramASN1Sequence.getObjectAt(1), true));
    }
  }
  
  public static RevokedInfo getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1Sequence.getInstance(paramASN1TaggedObject, paramBoolean));
  }
  
  public static RevokedInfo getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof RevokedInfo))) {
      return (RevokedInfo)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new RevokedInfo((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in factory: " + paramObject.getClass().getName());
  }
  
  public DERGeneralizedTime getRevocationTime()
  {
    return this.revocationTime;
  }
  
  public CRLReason getRevocationReason()
  {
    return this.revocationReason;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.revocationTime);
    if (this.revocationReason != null) {
      localASN1EncodableVector.add(new DERTaggedObject(true, 0, this.revocationReason));
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\ocsp\RevokedInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */