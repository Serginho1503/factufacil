package org.bouncycastle.asn1.ocsp;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERGeneralizedTime;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.x509.X509Extensions;

public class ResponseData
  extends ASN1Encodable
{
  private static final DERInteger V1 = new DERInteger(0);
  private boolean versionPresent;
  private DERInteger version;
  private ResponderID responderID;
  private DERGeneralizedTime producedAt;
  private ASN1Sequence responses;
  private X509Extensions responseExtensions;
  
  public ResponseData(DERInteger paramDERInteger, ResponderID paramResponderID, DERGeneralizedTime paramDERGeneralizedTime, ASN1Sequence paramASN1Sequence, X509Extensions paramX509Extensions)
  {
    this.version = paramDERInteger;
    this.responderID = paramResponderID;
    this.producedAt = paramDERGeneralizedTime;
    this.responses = paramASN1Sequence;
    this.responseExtensions = paramX509Extensions;
  }
  
  public ResponseData(ResponderID paramResponderID, DERGeneralizedTime paramDERGeneralizedTime, ASN1Sequence paramASN1Sequence, X509Extensions paramX509Extensions)
  {
    this(V1, paramResponderID, paramDERGeneralizedTime, paramASN1Sequence, paramX509Extensions);
  }
  
  public ResponseData(ASN1Sequence paramASN1Sequence)
  {
    int i = 0;
    if ((paramASN1Sequence.getObjectAt(0) instanceof ASN1TaggedObject))
    {
      ASN1TaggedObject localASN1TaggedObject = (ASN1TaggedObject)paramASN1Sequence.getObjectAt(0);
      if (localASN1TaggedObject.getTagNo() == 0)
      {
        this.versionPresent = true;
        this.version = DERInteger.getInstance((ASN1TaggedObject)paramASN1Sequence.getObjectAt(0), true);
        i++;
      }
      else
      {
        this.version = V1;
      }
    }
    else
    {
      this.version = V1;
    }
    this.responderID = ResponderID.getInstance(paramASN1Sequence.getObjectAt(i++));
    this.producedAt = ((DERGeneralizedTime)paramASN1Sequence.getObjectAt(i++));
    this.responses = ((ASN1Sequence)paramASN1Sequence.getObjectAt(i++));
    if (paramASN1Sequence.size() > i) {
      this.responseExtensions = X509Extensions.getInstance((ASN1TaggedObject)paramASN1Sequence.getObjectAt(i), true);
    }
  }
  
  public static ResponseData getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1Sequence.getInstance(paramASN1TaggedObject, paramBoolean));
  }
  
  public static ResponseData getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof ResponseData))) {
      return (ResponseData)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new ResponseData((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in factory: " + paramObject.getClass().getName());
  }
  
  public DERInteger getVersion()
  {
    return this.version;
  }
  
  public ResponderID getResponderID()
  {
    return this.responderID;
  }
  
  public DERGeneralizedTime getProducedAt()
  {
    return this.producedAt;
  }
  
  public ASN1Sequence getResponses()
  {
    return this.responses;
  }
  
  public X509Extensions getResponseExtensions()
  {
    return this.responseExtensions;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    if ((this.versionPresent) || (!this.version.equals(V1))) {
      localASN1EncodableVector.add(new DERTaggedObject(true, 0, this.version));
    }
    localASN1EncodableVector.add(this.responderID);
    localASN1EncodableVector.add(this.producedAt);
    localASN1EncodableVector.add(this.responses);
    if (this.responseExtensions != null) {
      localASN1EncodableVector.add(new DERTaggedObject(true, 1, this.responseExtensions));
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\ocsp\ResponseData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */