package org.bouncycastle.asn1.x9;

import java.math.BigInteger;
import org.bouncycastle.math.ec.ECCurve;
import org.bouncycastle.math.ec.ECFieldElement;

public class X9IntegerConverter
{
  public int getByteLength(ECCurve paramECCurve)
  {
    return (paramECCurve.getFieldSize() + 7) / 8;
  }
  
  public int getByteLength(ECFieldElement paramECFieldElement)
  {
    return (paramECFieldElement.getFieldSize() + 7) / 8;
  }
  
  public byte[] integerToBytes(BigInteger paramBigInteger, int paramInt)
  {
    byte[] arrayOfByte1 = paramBigInteger.toByteArray();
    byte[] arrayOfByte2;
    if (paramInt < arrayOfByte1.length)
    {
      arrayOfByte2 = new byte[paramInt];
      System.arraycopy(arrayOfByte1, arrayOfByte1.length - arrayOfByte2.length, arrayOfByte2, 0, arrayOfByte2.length);
      return arrayOfByte2;
    }
    if (paramInt > arrayOfByte1.length)
    {
      arrayOfByte2 = new byte[paramInt];
      System.arraycopy(arrayOfByte1, 0, arrayOfByte2, arrayOfByte2.length - arrayOfByte1.length, arrayOfByte1.length);
      return arrayOfByte2;
    }
    return arrayOfByte1;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x9\X9IntegerConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */