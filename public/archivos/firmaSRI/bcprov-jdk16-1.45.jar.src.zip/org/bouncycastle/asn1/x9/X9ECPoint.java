package org.bouncycastle.asn1.x9;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.math.ec.ECCurve;
import org.bouncycastle.math.ec.ECPoint;

public class X9ECPoint
  extends ASN1Encodable
{
  ECPoint p;
  
  public X9ECPoint(ECPoint paramECPoint)
  {
    this.p = paramECPoint;
  }
  
  public X9ECPoint(ECCurve paramECCurve, ASN1OctetString paramASN1OctetString)
  {
    this.p = paramECCurve.decodePoint(paramASN1OctetString.getOctets());
  }
  
  public ECPoint getPoint()
  {
    return this.p;
  }
  
  public DERObject toASN1Object()
  {
    return new DEROctetString(this.p.getEncoded());
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x9\X9ECPoint.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */