package org.bouncycastle.asn1.x9;

public abstract class X9ECParametersHolder
{
  private X9ECParameters params;
  
  public X9ECParameters getParameters()
  {
    if (this.params == null) {
      this.params = createParameters();
    }
    return this.params;
  }
  
  protected abstract X9ECParameters createParameters();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x9\X9ECParametersHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */