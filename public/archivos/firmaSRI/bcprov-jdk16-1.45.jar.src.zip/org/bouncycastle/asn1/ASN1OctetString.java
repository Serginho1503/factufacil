package org.bouncycastle.asn1;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Vector;
import org.bouncycastle.util.Arrays;
import org.bouncycastle.util.encoders.Hex;

public abstract class ASN1OctetString
  extends ASN1Object
  implements ASN1OctetStringParser
{
  byte[] string;
  
  public static ASN1OctetString getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(paramASN1TaggedObject.getObject());
  }
  
  public static ASN1OctetString getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof ASN1OctetString))) {
      return (ASN1OctetString)paramObject;
    }
    if ((paramObject instanceof ASN1TaggedObject)) {
      return getInstance(((ASN1TaggedObject)paramObject).getObject());
    }
    if ((paramObject instanceof ASN1Sequence))
    {
      Vector localVector = new Vector();
      Enumeration localEnumeration = ((ASN1Sequence)paramObject).getObjects();
      while (localEnumeration.hasMoreElements()) {
        localVector.addElement(localEnumeration.nextElement());
      }
      return new BERConstructedOctetString(localVector);
    }
    throw new IllegalArgumentException("illegal object in getInstance: " + paramObject.getClass().getName());
  }
  
  public ASN1OctetString(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte == null) {
      throw new NullPointerException("string cannot be null");
    }
    this.string = paramArrayOfByte;
  }
  
  public ASN1OctetString(DEREncodable paramDEREncodable)
  {
    try
    {
      this.string = paramDEREncodable.getDERObject().getEncoded("DER");
    }
    catch (IOException localIOException)
    {
      throw new IllegalArgumentException("Error processing object : " + localIOException.toString());
    }
  }
  
  public InputStream getOctetStream()
  {
    return new ByteArrayInputStream(this.string);
  }
  
  public ASN1OctetStringParser parser()
  {
    return this;
  }
  
  public byte[] getOctets()
  {
    return this.string;
  }
  
  public int hashCode()
  {
    return Arrays.hashCode(getOctets());
  }
  
  boolean asn1Equals(DERObject paramDERObject)
  {
    if (!(paramDERObject instanceof ASN1OctetString)) {
      return false;
    }
    ASN1OctetString localASN1OctetString = (ASN1OctetString)paramDERObject;
    return Arrays.areEqual(this.string, localASN1OctetString.string);
  }
  
  abstract void encode(DEROutputStream paramDEROutputStream)
    throws IOException;
  
  public String toString()
  {
    return "#" + new String(Hex.encode(this.string));
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\ASN1OctetString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */