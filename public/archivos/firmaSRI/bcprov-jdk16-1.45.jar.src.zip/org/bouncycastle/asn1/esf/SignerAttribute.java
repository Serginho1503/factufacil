package org.bouncycastle.asn1.esf;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.x509.AttributeCertificate;

public class SignerAttribute
  extends ASN1Encodable
{
  private ASN1Sequence claimedAttributes;
  private AttributeCertificate certifiedAttributes;
  
  public static SignerAttribute getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof SignerAttribute))) {
      return (SignerAttribute)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new SignerAttribute(paramObject);
    }
    throw new IllegalArgumentException("unknown object in 'SignerAttribute' factory: " + paramObject.getClass().getName() + ".");
  }
  
  private SignerAttribute(Object paramObject)
  {
    ASN1Sequence localASN1Sequence = (ASN1Sequence)paramObject;
    DERTaggedObject localDERTaggedObject = (DERTaggedObject)localASN1Sequence.getObjectAt(0);
    if (localDERTaggedObject.getTagNo() == 0) {
      this.claimedAttributes = ASN1Sequence.getInstance(localDERTaggedObject, true);
    } else if (localDERTaggedObject.getTagNo() == 1) {
      this.certifiedAttributes = AttributeCertificate.getInstance(localDERTaggedObject);
    } else {
      throw new IllegalArgumentException("illegal tag.");
    }
  }
  
  public SignerAttribute(ASN1Sequence paramASN1Sequence)
  {
    this.claimedAttributes = paramASN1Sequence;
  }
  
  public SignerAttribute(AttributeCertificate paramAttributeCertificate)
  {
    this.certifiedAttributes = paramAttributeCertificate;
  }
  
  public ASN1Sequence getClaimedAttributes()
  {
    return this.claimedAttributes;
  }
  
  public AttributeCertificate getCertifiedAttributes()
  {
    return this.certifiedAttributes;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    if (this.claimedAttributes != null) {
      localASN1EncodableVector.add(new DERTaggedObject(0, this.claimedAttributes));
    } else {
      localASN1EncodableVector.add(new DERTaggedObject(1, this.certifiedAttributes));
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\esf\SignerAttribute.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */