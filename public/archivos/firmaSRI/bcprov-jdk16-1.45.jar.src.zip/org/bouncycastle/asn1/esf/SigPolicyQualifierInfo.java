package org.bouncycastle.asn1.esf;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSequence;

public class SigPolicyQualifierInfo
  extends ASN1Encodable
{
  private DERObjectIdentifier sigPolicyQualifierId;
  private DEREncodable sigQualifier;
  
  public SigPolicyQualifierInfo(DERObjectIdentifier paramDERObjectIdentifier, DEREncodable paramDEREncodable)
  {
    this.sigPolicyQualifierId = paramDERObjectIdentifier;
    this.sigQualifier = paramDEREncodable;
  }
  
  public SigPolicyQualifierInfo(ASN1Sequence paramASN1Sequence)
  {
    this.sigPolicyQualifierId = DERObjectIdentifier.getInstance(paramASN1Sequence.getObjectAt(0));
    this.sigQualifier = paramASN1Sequence.getObjectAt(1);
  }
  
  public static SigPolicyQualifierInfo getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof SigPolicyQualifierInfo))) {
      return (SigPolicyQualifierInfo)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new SigPolicyQualifierInfo((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in 'SigPolicyQualifierInfo' factory: " + paramObject.getClass().getName() + ".");
  }
  
  public DERObjectIdentifier getSigPolicyQualifierId()
  {
    return this.sigPolicyQualifierId;
  }
  
  public DEREncodable getSigQualifier()
  {
    return this.sigQualifier;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.sigPolicyQualifierId);
    localASN1EncodableVector.add(this.sigQualifier);
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\esf\SigPolicyQualifierInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */