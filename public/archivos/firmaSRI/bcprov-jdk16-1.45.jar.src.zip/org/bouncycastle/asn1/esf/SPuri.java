package org.bouncycastle.asn1.esf;

import org.bouncycastle.asn1.DERIA5String;
import org.bouncycastle.asn1.DERObject;

public class SPuri
{
  private DERIA5String uri;
  
  public static SPuri getInstance(Object paramObject)
  {
    if ((paramObject instanceof SPuri)) {
      return (SPuri)paramObject;
    }
    if ((paramObject instanceof DERIA5String)) {
      return new SPuri((DERIA5String)paramObject);
    }
    throw new IllegalArgumentException("unknown object in 'SPuri' factory: " + paramObject.getClass().getName() + ".");
  }
  
  public SPuri(DERIA5String paramDERIA5String)
  {
    this.uri = paramDERIA5String;
  }
  
  public DERIA5String getUri()
  {
    return this.uri;
  }
  
  public DERObject toASN1Object()
  {
    return this.uri.getDERObject();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\esf\SPuri.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */