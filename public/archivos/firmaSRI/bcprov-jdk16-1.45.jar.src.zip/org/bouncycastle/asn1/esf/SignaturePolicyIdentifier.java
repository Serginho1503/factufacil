package org.bouncycastle.asn1.esf;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1Null;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DERObject;

public class SignaturePolicyIdentifier
  extends ASN1Encodable
{
  private SignaturePolicyId signaturePolicyId;
  private boolean isSignaturePolicyImplied;
  
  public static SignaturePolicyIdentifier getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof SignaturePolicyIdentifier))) {
      return (SignaturePolicyIdentifier)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new SignaturePolicyIdentifier(SignaturePolicyId.getInstance(paramObject));
    }
    if ((paramObject instanceof ASN1Null)) {
      return new SignaturePolicyIdentifier();
    }
    throw new IllegalArgumentException("unknown object in 'SignaturePolicyIdentifier' factory: " + paramObject.getClass().getName() + ".");
  }
  
  public SignaturePolicyIdentifier()
  {
    this.isSignaturePolicyImplied = true;
  }
  
  public SignaturePolicyIdentifier(SignaturePolicyId paramSignaturePolicyId)
  {
    this.signaturePolicyId = paramSignaturePolicyId;
    this.isSignaturePolicyImplied = false;
  }
  
  public SignaturePolicyId getSignaturePolicyId()
  {
    return this.signaturePolicyId;
  }
  
  public boolean isSignaturePolicyImplied()
  {
    return this.isSignaturePolicyImplied;
  }
  
  public DERObject toASN1Object()
  {
    if (this.isSignaturePolicyImplied) {
      return new DERNull();
    }
    return this.signaturePolicyId.getDERObject();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\esf\SignaturePolicyIdentifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */