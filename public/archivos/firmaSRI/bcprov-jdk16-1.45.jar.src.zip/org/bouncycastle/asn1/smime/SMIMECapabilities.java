package org.bouncycastle.asn1.smime;

import java.util.Enumeration;
import java.util.Vector;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cms.Attribute;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;

public class SMIMECapabilities
  extends ASN1Encodable
{
  public static final DERObjectIdentifier preferSignedData = PKCSObjectIdentifiers.preferSignedData;
  public static final DERObjectIdentifier canNotDecryptAny = PKCSObjectIdentifiers.canNotDecryptAny;
  public static final DERObjectIdentifier sMIMECapabilitesVersions = PKCSObjectIdentifiers.sMIMECapabilitiesVersions;
  public static final DERObjectIdentifier dES_CBC = new DERObjectIdentifier("1.3.14.3.2.7");
  public static final DERObjectIdentifier dES_EDE3_CBC = PKCSObjectIdentifiers.des_EDE3_CBC;
  public static final DERObjectIdentifier rC2_CBC = PKCSObjectIdentifiers.RC2_CBC;
  private ASN1Sequence capabilities;
  
  public static SMIMECapabilities getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof SMIMECapabilities))) {
      return (SMIMECapabilities)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new SMIMECapabilities((ASN1Sequence)paramObject);
    }
    if ((paramObject instanceof Attribute)) {
      return new SMIMECapabilities((ASN1Sequence)((Attribute)paramObject).getAttrValues().getObjectAt(0));
    }
    throw new IllegalArgumentException("unknown object in factory: " + paramObject.getClass().getName());
  }
  
  public SMIMECapabilities(ASN1Sequence paramASN1Sequence)
  {
    this.capabilities = paramASN1Sequence;
  }
  
  public Vector getCapabilities(DERObjectIdentifier paramDERObjectIdentifier)
  {
    Enumeration localEnumeration = this.capabilities.getObjects();
    Vector localVector = new Vector();
    SMIMECapability localSMIMECapability;
    if (paramDERObjectIdentifier == null) {
      while (localEnumeration.hasMoreElements())
      {
        localSMIMECapability = SMIMECapability.getInstance(localEnumeration.nextElement());
        localVector.addElement(localSMIMECapability);
      }
    }
    while (localEnumeration.hasMoreElements())
    {
      localSMIMECapability = SMIMECapability.getInstance(localEnumeration.nextElement());
      if (paramDERObjectIdentifier.equals(localSMIMECapability.getCapabilityID())) {
        localVector.addElement(localSMIMECapability);
      }
    }
    return localVector;
  }
  
  public DERObject toASN1Object()
  {
    return this.capabilities;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\smime\SMIMECapabilities.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */