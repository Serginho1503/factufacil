package org.bouncycastle.asn1;

class BERFactory
{
  static final BERSequence EMPTY_SEQUENCE = new BERSequence();
  static final BERSet EMPTY_SET = new BERSet();
  
  static BERSequence createSequence(ASN1EncodableVector paramASN1EncodableVector)
  {
    return paramASN1EncodableVector.size() < 1 ? EMPTY_SEQUENCE : new BERSequence(paramASN1EncodableVector);
  }
  
  static BERSet createSet(ASN1EncodableVector paramASN1EncodableVector)
  {
    return paramASN1EncodableVector.size() < 1 ? EMPTY_SET : new BERSet(paramASN1EncodableVector);
  }
  
  static BERSet createSet(ASN1EncodableVector paramASN1EncodableVector, boolean paramBoolean)
  {
    return paramASN1EncodableVector.size() < 1 ? EMPTY_SET : new BERSet(paramASN1EncodableVector, paramBoolean);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\BERFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */