package org.bouncycastle.asn1.x509;

import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERGeneralizedTime;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;

public class PrivateKeyUsagePeriod
  extends ASN1Encodable
{
  private DERGeneralizedTime _notBefore;
  private DERGeneralizedTime _notAfter;
  
  public static PrivateKeyUsagePeriod getInstance(Object paramObject)
  {
    if ((paramObject instanceof PrivateKeyUsagePeriod)) {
      return (PrivateKeyUsagePeriod)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new PrivateKeyUsagePeriod((ASN1Sequence)paramObject);
    }
    if ((paramObject instanceof X509Extension)) {
      return getInstance(X509Extension.convertValueToObject((X509Extension)paramObject));
    }
    throw new IllegalArgumentException("unknown object in getInstance: " + paramObject.getClass().getName());
  }
  
  private PrivateKeyUsagePeriod(ASN1Sequence paramASN1Sequence)
  {
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    while (localEnumeration.hasMoreElements())
    {
      ASN1TaggedObject localASN1TaggedObject = (ASN1TaggedObject)localEnumeration.nextElement();
      if (localASN1TaggedObject.getTagNo() == 0) {
        this._notBefore = DERGeneralizedTime.getInstance(localASN1TaggedObject, false);
      } else if (localASN1TaggedObject.getTagNo() == 1) {
        this._notAfter = DERGeneralizedTime.getInstance(localASN1TaggedObject, false);
      }
    }
  }
  
  public DERGeneralizedTime getNotBefore()
  {
    return this._notBefore;
  }
  
  public DERGeneralizedTime getNotAfter()
  {
    return this._notAfter;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    if (this._notBefore != null) {
      localASN1EncodableVector.add(new DERTaggedObject(false, 0, this._notBefore));
    }
    if (this._notAfter != null) {
      localASN1EncodableVector.add(new DERTaggedObject(false, 1, this._notAfter));
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x509\PrivateKeyUsagePeriod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */