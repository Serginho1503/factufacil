package org.bouncycastle.asn1.x509;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Vector;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERGeneralizedTime;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.DERUTCTime;

public class V2TBSCertListGenerator
{
  DERInteger version = new DERInteger(1);
  AlgorithmIdentifier signature;
  X509Name issuer;
  Time thisUpdate;
  Time nextUpdate = null;
  X509Extensions extensions = null;
  private Vector crlentries = null;
  
  public void setSignature(AlgorithmIdentifier paramAlgorithmIdentifier)
  {
    this.signature = paramAlgorithmIdentifier;
  }
  
  public void setIssuer(X509Name paramX509Name)
  {
    this.issuer = paramX509Name;
  }
  
  public void setThisUpdate(DERUTCTime paramDERUTCTime)
  {
    this.thisUpdate = new Time(paramDERUTCTime);
  }
  
  public void setNextUpdate(DERUTCTime paramDERUTCTime)
  {
    this.nextUpdate = new Time(paramDERUTCTime);
  }
  
  public void setThisUpdate(Time paramTime)
  {
    this.thisUpdate = paramTime;
  }
  
  public void setNextUpdate(Time paramTime)
  {
    this.nextUpdate = paramTime;
  }
  
  public void addCRLEntry(ASN1Sequence paramASN1Sequence)
  {
    if (this.crlentries == null) {
      this.crlentries = new Vector();
    }
    this.crlentries.addElement(paramASN1Sequence);
  }
  
  public void addCRLEntry(DERInteger paramDERInteger, DERUTCTime paramDERUTCTime, int paramInt)
  {
    addCRLEntry(paramDERInteger, new Time(paramDERUTCTime), paramInt);
  }
  
  public void addCRLEntry(DERInteger paramDERInteger, Time paramTime, int paramInt)
  {
    addCRLEntry(paramDERInteger, paramTime, paramInt, null);
  }
  
  public void addCRLEntry(DERInteger paramDERInteger, Time paramTime, int paramInt, DERGeneralizedTime paramDERGeneralizedTime)
  {
    Vector localVector1 = new Vector();
    Vector localVector2 = new Vector();
    if (paramInt != 0)
    {
      CRLReason localCRLReason = new CRLReason(paramInt);
      try
      {
        localVector1.addElement(X509Extensions.ReasonCode);
        localVector2.addElement(new X509Extension(false, new DEROctetString(localCRLReason.getEncoded())));
      }
      catch (IOException localIOException2)
      {
        throw new IllegalArgumentException("error encoding reason: " + localIOException2);
      }
    }
    if (paramDERGeneralizedTime != null) {
      try
      {
        localVector1.addElement(X509Extensions.InvalidityDate);
        localVector2.addElement(new X509Extension(false, new DEROctetString(paramDERGeneralizedTime.getEncoded())));
      }
      catch (IOException localIOException1)
      {
        throw new IllegalArgumentException("error encoding invalidityDate: " + localIOException1);
      }
    }
    if (localVector1.size() != 0) {
      addCRLEntry(paramDERInteger, paramTime, new X509Extensions(localVector1, localVector2));
    } else {
      addCRLEntry(paramDERInteger, paramTime, null);
    }
  }
  
  public void addCRLEntry(DERInteger paramDERInteger, Time paramTime, X509Extensions paramX509Extensions)
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(paramDERInteger);
    localASN1EncodableVector.add(paramTime);
    if (paramX509Extensions != null) {
      localASN1EncodableVector.add(paramX509Extensions);
    }
    addCRLEntry(new DERSequence(localASN1EncodableVector));
  }
  
  public void setExtensions(X509Extensions paramX509Extensions)
  {
    this.extensions = paramX509Extensions;
  }
  
  public TBSCertList generateTBSCertList()
  {
    if ((this.signature == null) || (this.issuer == null) || (this.thisUpdate == null)) {
      throw new IllegalStateException("Not all mandatory fields set in V2 TBSCertList generator.");
    }
    ASN1EncodableVector localASN1EncodableVector1 = new ASN1EncodableVector();
    localASN1EncodableVector1.add(this.version);
    localASN1EncodableVector1.add(this.signature);
    localASN1EncodableVector1.add(this.issuer);
    localASN1EncodableVector1.add(this.thisUpdate);
    if (this.nextUpdate != null) {
      localASN1EncodableVector1.add(this.nextUpdate);
    }
    if (this.crlentries != null)
    {
      ASN1EncodableVector localASN1EncodableVector2 = new ASN1EncodableVector();
      Enumeration localEnumeration = this.crlentries.elements();
      while (localEnumeration.hasMoreElements()) {
        localASN1EncodableVector2.add((ASN1Sequence)localEnumeration.nextElement());
      }
      localASN1EncodableVector1.add(new DERSequence(localASN1EncodableVector2));
    }
    if (this.extensions != null) {
      localASN1EncodableVector1.add(new DERTaggedObject(0, this.extensions));
    }
    return new TBSCertList(new DERSequence(localASN1EncodableVector1));
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x509\V2TBSCertListGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */