package org.bouncycastle.asn1.x509;

import java.math.BigInteger;
import org.bouncycastle.asn1.DERInteger;

public class CRLNumber
  extends DERInteger
{
  public CRLNumber(BigInteger paramBigInteger)
  {
    super(paramBigInteger);
  }
  
  public BigInteger getCRLNumber()
  {
    return getPositiveValue();
  }
  
  public String toString()
  {
    return "CRLNumber: " + getCRLNumber();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x509\CRLNumber.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */