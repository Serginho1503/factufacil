package org.bouncycastle.asn1.x509;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSequence;

public class AlgorithmIdentifier
  extends ASN1Encodable
{
  private DERObjectIdentifier objectId;
  private DEREncodable parameters;
  private boolean parametersDefined = false;
  
  public static AlgorithmIdentifier getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1Sequence.getInstance(paramASN1TaggedObject, paramBoolean));
  }
  
  public static AlgorithmIdentifier getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof AlgorithmIdentifier))) {
      return (AlgorithmIdentifier)paramObject;
    }
    if ((paramObject instanceof DERObjectIdentifier)) {
      return new AlgorithmIdentifier((DERObjectIdentifier)paramObject);
    }
    if ((paramObject instanceof String)) {
      return new AlgorithmIdentifier((String)paramObject);
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new AlgorithmIdentifier((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in factory: " + paramObject.getClass().getName());
  }
  
  public AlgorithmIdentifier(DERObjectIdentifier paramDERObjectIdentifier)
  {
    this.objectId = paramDERObjectIdentifier;
  }
  
  public AlgorithmIdentifier(String paramString)
  {
    this.objectId = new DERObjectIdentifier(paramString);
  }
  
  public AlgorithmIdentifier(DERObjectIdentifier paramDERObjectIdentifier, DEREncodable paramDEREncodable)
  {
    this.parametersDefined = true;
    this.objectId = paramDERObjectIdentifier;
    this.parameters = paramDEREncodable;
  }
  
  public AlgorithmIdentifier(ASN1Sequence paramASN1Sequence)
  {
    if ((paramASN1Sequence.size() < 1) || (paramASN1Sequence.size() > 2)) {
      throw new IllegalArgumentException("Bad sequence size: " + paramASN1Sequence.size());
    }
    this.objectId = DERObjectIdentifier.getInstance(paramASN1Sequence.getObjectAt(0));
    if (paramASN1Sequence.size() == 2)
    {
      this.parametersDefined = true;
      this.parameters = paramASN1Sequence.getObjectAt(1);
    }
    else
    {
      this.parameters = null;
    }
  }
  
  public DERObjectIdentifier getObjectId()
  {
    return this.objectId;
  }
  
  public DEREncodable getParameters()
  {
    return this.parameters;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.objectId);
    if (this.parametersDefined) {
      localASN1EncodableVector.add(this.parameters);
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x509\AlgorithmIdentifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */