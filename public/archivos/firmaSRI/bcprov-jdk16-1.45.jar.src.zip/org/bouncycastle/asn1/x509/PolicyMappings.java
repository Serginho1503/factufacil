package org.bouncycastle.asn1.x509;

import java.util.Enumeration;
import java.util.Hashtable;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSequence;

public class PolicyMappings
  extends ASN1Encodable
{
  ASN1Sequence seq = null;
  
  public PolicyMappings(ASN1Sequence paramASN1Sequence)
  {
    this.seq = paramASN1Sequence;
  }
  
  public PolicyMappings(Hashtable paramHashtable)
  {
    ASN1EncodableVector localASN1EncodableVector1 = new ASN1EncodableVector();
    Enumeration localEnumeration = paramHashtable.keys();
    while (localEnumeration.hasMoreElements())
    {
      String str1 = (String)localEnumeration.nextElement();
      String str2 = (String)paramHashtable.get(str1);
      ASN1EncodableVector localASN1EncodableVector2 = new ASN1EncodableVector();
      localASN1EncodableVector2.add(new DERObjectIdentifier(str1));
      localASN1EncodableVector2.add(new DERObjectIdentifier(str2));
      localASN1EncodableVector1.add(new DERSequence(localASN1EncodableVector2));
    }
    this.seq = new DERSequence(localASN1EncodableVector1);
  }
  
  public DERObject toASN1Object()
  {
    return this.seq;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x509\PolicyMappings.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */