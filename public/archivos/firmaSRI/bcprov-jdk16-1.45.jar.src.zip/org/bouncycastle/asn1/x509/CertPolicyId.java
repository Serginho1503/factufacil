package org.bouncycastle.asn1.x509;

import org.bouncycastle.asn1.DERObjectIdentifier;

public class CertPolicyId
  extends DERObjectIdentifier
{
  public CertPolicyId(String paramString)
  {
    super(paramString);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x509\CertPolicyId.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */