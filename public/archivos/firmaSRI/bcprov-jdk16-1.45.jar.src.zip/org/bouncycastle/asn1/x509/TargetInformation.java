package org.bouncycastle.asn1.x509;

import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;

public class TargetInformation
  extends ASN1Encodable
{
  private ASN1Sequence targets;
  
  public static TargetInformation getInstance(Object paramObject)
  {
    if ((paramObject instanceof TargetInformation)) {
      return (TargetInformation)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new TargetInformation((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in factory: " + paramObject.getClass());
  }
  
  private TargetInformation(ASN1Sequence paramASN1Sequence)
  {
    this.targets = paramASN1Sequence;
  }
  
  public Targets[] getTargetsObjects()
  {
    Targets[] arrayOfTargets = new Targets[this.targets.size()];
    int i = 0;
    Enumeration localEnumeration = this.targets.getObjects();
    while (localEnumeration.hasMoreElements()) {
      arrayOfTargets[(i++)] = Targets.getInstance(localEnumeration.nextElement());
    }
    return arrayOfTargets;
  }
  
  public TargetInformation(Targets paramTargets)
  {
    this.targets = new DERSequence(paramTargets);
  }
  
  public TargetInformation(Target[] paramArrayOfTarget)
  {
    this(new Targets(paramArrayOfTarget));
  }
  
  public DERObject toASN1Object()
  {
    return this.targets;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x509\TargetInformation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */