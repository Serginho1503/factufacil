package org.bouncycastle.asn1.x509;

import java.math.BigInteger;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;

public class TBSCertificateStructure
  extends ASN1Encodable
  implements X509ObjectIdentifiers, PKCSObjectIdentifiers
{
  ASN1Sequence seq;
  DERInteger version;
  DERInteger serialNumber;
  AlgorithmIdentifier signature;
  X509Name issuer;
  Time startDate;
  Time endDate;
  X509Name subject;
  SubjectPublicKeyInfo subjectPublicKeyInfo;
  DERBitString issuerUniqueId;
  DERBitString subjectUniqueId;
  X509Extensions extensions;
  
  public static TBSCertificateStructure getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1Sequence.getInstance(paramASN1TaggedObject, paramBoolean));
  }
  
  public static TBSCertificateStructure getInstance(Object paramObject)
  {
    if ((paramObject instanceof TBSCertificateStructure)) {
      return (TBSCertificateStructure)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new TBSCertificateStructure((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in factory: " + paramObject.getClass().getName());
  }
  
  public TBSCertificateStructure(ASN1Sequence paramASN1Sequence)
  {
    int i = 0;
    this.seq = paramASN1Sequence;
    if ((paramASN1Sequence.getObjectAt(0) instanceof DERTaggedObject))
    {
      this.version = DERInteger.getInstance(paramASN1Sequence.getObjectAt(0));
    }
    else
    {
      i = -1;
      this.version = new DERInteger(0);
    }
    this.serialNumber = DERInteger.getInstance(paramASN1Sequence.getObjectAt(i + 1));
    this.signature = AlgorithmIdentifier.getInstance(paramASN1Sequence.getObjectAt(i + 2));
    this.issuer = X509Name.getInstance(paramASN1Sequence.getObjectAt(i + 3));
    ASN1Sequence localASN1Sequence = (ASN1Sequence)paramASN1Sequence.getObjectAt(i + 4);
    this.startDate = Time.getInstance(localASN1Sequence.getObjectAt(0));
    this.endDate = Time.getInstance(localASN1Sequence.getObjectAt(1));
    this.subject = X509Name.getInstance(paramASN1Sequence.getObjectAt(i + 5));
    this.subjectPublicKeyInfo = SubjectPublicKeyInfo.getInstance(paramASN1Sequence.getObjectAt(i + 6));
    for (int j = paramASN1Sequence.size() - (i + 6) - 1; j > 0; j--)
    {
      DERTaggedObject localDERTaggedObject = (DERTaggedObject)paramASN1Sequence.getObjectAt(i + 6 + j);
      switch (localDERTaggedObject.getTagNo())
      {
      case 1: 
        this.issuerUniqueId = DERBitString.getInstance(localDERTaggedObject, false);
        break;
      case 2: 
        this.subjectUniqueId = DERBitString.getInstance(localDERTaggedObject, false);
        break;
      case 3: 
        this.extensions = X509Extensions.getInstance(localDERTaggedObject);
      }
    }
  }
  
  public int getVersion()
  {
    return this.version.getValue().intValue() + 1;
  }
  
  public DERInteger getVersionNumber()
  {
    return this.version;
  }
  
  public DERInteger getSerialNumber()
  {
    return this.serialNumber;
  }
  
  public AlgorithmIdentifier getSignature()
  {
    return this.signature;
  }
  
  public X509Name getIssuer()
  {
    return this.issuer;
  }
  
  public Time getStartDate()
  {
    return this.startDate;
  }
  
  public Time getEndDate()
  {
    return this.endDate;
  }
  
  public X509Name getSubject()
  {
    return this.subject;
  }
  
  public SubjectPublicKeyInfo getSubjectPublicKeyInfo()
  {
    return this.subjectPublicKeyInfo;
  }
  
  public DERBitString getIssuerUniqueId()
  {
    return this.issuerUniqueId;
  }
  
  public DERBitString getSubjectUniqueId()
  {
    return this.subjectUniqueId;
  }
  
  public X509Extensions getExtensions()
  {
    return this.extensions;
  }
  
  public DERObject toASN1Object()
  {
    return this.seq;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x509\TBSCertificateStructure.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */