package org.bouncycastle.asn1.x509;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSequence;

public class ExtendedKeyUsage
  extends ASN1Encodable
{
  Hashtable usageTable = new Hashtable();
  ASN1Sequence seq;
  
  public static ExtendedKeyUsage getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1Sequence.getInstance(paramASN1TaggedObject, paramBoolean));
  }
  
  public static ExtendedKeyUsage getInstance(Object paramObject)
  {
    if ((paramObject instanceof ExtendedKeyUsage)) {
      return (ExtendedKeyUsage)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new ExtendedKeyUsage((ASN1Sequence)paramObject);
    }
    if ((paramObject instanceof X509Extension)) {
      return getInstance(X509Extension.convertValueToObject((X509Extension)paramObject));
    }
    throw new IllegalArgumentException("Invalid ExtendedKeyUsage: " + paramObject.getClass().getName());
  }
  
  public ExtendedKeyUsage(KeyPurposeId paramKeyPurposeId)
  {
    this.seq = new DERSequence(paramKeyPurposeId);
    this.usageTable.put(paramKeyPurposeId, paramKeyPurposeId);
  }
  
  public ExtendedKeyUsage(ASN1Sequence paramASN1Sequence)
  {
    this.seq = paramASN1Sequence;
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    while (localEnumeration.hasMoreElements())
    {
      Object localObject = localEnumeration.nextElement();
      if (!(localObject instanceof DERObjectIdentifier)) {
        throw new IllegalArgumentException("Only DERObjectIdentifiers allowed in ExtendedKeyUsage.");
      }
      this.usageTable.put(localObject, localObject);
    }
  }
  
  public ExtendedKeyUsage(Vector paramVector)
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    Enumeration localEnumeration = paramVector.elements();
    while (localEnumeration.hasMoreElements())
    {
      DERObject localDERObject = (DERObject)localEnumeration.nextElement();
      localASN1EncodableVector.add(localDERObject);
      this.usageTable.put(localDERObject, localDERObject);
    }
    this.seq = new DERSequence(localASN1EncodableVector);
  }
  
  public boolean hasKeyPurposeId(KeyPurposeId paramKeyPurposeId)
  {
    return this.usageTable.get(paramKeyPurposeId) != null;
  }
  
  public Vector getUsages()
  {
    Vector localVector = new Vector();
    Enumeration localEnumeration = this.usageTable.elements();
    while (localEnumeration.hasMoreElements()) {
      localVector.addElement(localEnumeration.nextElement());
    }
    return localVector;
  }
  
  public int size()
  {
    return this.usageTable.size();
  }
  
  public DERObject toASN1Object()
  {
    return this.seq;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x509\ExtendedKeyUsage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */