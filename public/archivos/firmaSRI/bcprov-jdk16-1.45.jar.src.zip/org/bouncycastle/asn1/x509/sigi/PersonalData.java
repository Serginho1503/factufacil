package org.bouncycastle.asn1.x509.sigi;

import java.math.BigInteger;
import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERGeneralizedTime;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERPrintableString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.x500.DirectoryString;

public class PersonalData
  extends ASN1Encodable
{
  private NameOrPseudonym nameOrPseudonym;
  private BigInteger nameDistinguisher;
  private DERGeneralizedTime dateOfBirth;
  private DirectoryString placeOfBirth;
  private String gender;
  private DirectoryString postalAddress;
  
  public static PersonalData getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof PersonalData))) {
      return (PersonalData)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new PersonalData((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("illegal object in getInstance: " + paramObject.getClass().getName());
  }
  
  private PersonalData(ASN1Sequence paramASN1Sequence)
  {
    if (paramASN1Sequence.size() < 1) {
      throw new IllegalArgumentException("Bad sequence size: " + paramASN1Sequence.size());
    }
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    this.nameOrPseudonym = NameOrPseudonym.getInstance(localEnumeration.nextElement());
    while (localEnumeration.hasMoreElements())
    {
      ASN1TaggedObject localASN1TaggedObject = ASN1TaggedObject.getInstance(localEnumeration.nextElement());
      int i = localASN1TaggedObject.getTagNo();
      switch (i)
      {
      case 0: 
        this.nameDistinguisher = DERInteger.getInstance(localASN1TaggedObject, false).getValue();
        break;
      case 1: 
        this.dateOfBirth = DERGeneralizedTime.getInstance(localASN1TaggedObject, false);
        break;
      case 2: 
        this.placeOfBirth = DirectoryString.getInstance(localASN1TaggedObject, true);
        break;
      case 3: 
        this.gender = DERPrintableString.getInstance(localASN1TaggedObject, false).getString();
        break;
      case 4: 
        this.postalAddress = DirectoryString.getInstance(localASN1TaggedObject, true);
        break;
      default: 
        throw new IllegalArgumentException("Bad tag number: " + localASN1TaggedObject.getTagNo());
      }
    }
  }
  
  public PersonalData(NameOrPseudonym paramNameOrPseudonym, BigInteger paramBigInteger, DERGeneralizedTime paramDERGeneralizedTime, DirectoryString paramDirectoryString1, String paramString, DirectoryString paramDirectoryString2)
  {
    this.nameOrPseudonym = paramNameOrPseudonym;
    this.dateOfBirth = paramDERGeneralizedTime;
    this.gender = paramString;
    this.nameDistinguisher = paramBigInteger;
    this.postalAddress = paramDirectoryString2;
    this.placeOfBirth = paramDirectoryString1;
  }
  
  public NameOrPseudonym getNameOrPseudonym()
  {
    return this.nameOrPseudonym;
  }
  
  public BigInteger getNameDistinguisher()
  {
    return this.nameDistinguisher;
  }
  
  public DERGeneralizedTime getDateOfBirth()
  {
    return this.dateOfBirth;
  }
  
  public DirectoryString getPlaceOfBirth()
  {
    return this.placeOfBirth;
  }
  
  public String getGender()
  {
    return this.gender;
  }
  
  public DirectoryString getPostalAddress()
  {
    return this.postalAddress;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.nameOrPseudonym);
    if (this.nameDistinguisher != null) {
      localASN1EncodableVector.add(new DERTaggedObject(false, 0, new DERInteger(this.nameDistinguisher)));
    }
    if (this.dateOfBirth != null) {
      localASN1EncodableVector.add(new DERTaggedObject(false, 1, this.dateOfBirth));
    }
    if (this.placeOfBirth != null) {
      localASN1EncodableVector.add(new DERTaggedObject(true, 2, this.placeOfBirth));
    }
    if (this.gender != null) {
      localASN1EncodableVector.add(new DERTaggedObject(false, 3, new DERPrintableString(this.gender, true)));
    }
    if (this.postalAddress != null) {
      localASN1EncodableVector.add(new DERTaggedObject(true, 4, this.postalAddress));
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x509\sigi\PersonalData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */