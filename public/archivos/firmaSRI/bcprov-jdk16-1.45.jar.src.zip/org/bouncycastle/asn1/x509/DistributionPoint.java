package org.bouncycastle.asn1.x509;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;

public class DistributionPoint
  extends ASN1Encodable
{
  DistributionPointName distributionPoint;
  ReasonFlags reasons;
  GeneralNames cRLIssuer;
  
  public static DistributionPoint getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1Sequence.getInstance(paramASN1TaggedObject, paramBoolean));
  }
  
  public static DistributionPoint getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof DistributionPoint))) {
      return (DistributionPoint)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new DistributionPoint((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("Invalid DistributionPoint: " + paramObject.getClass().getName());
  }
  
  public DistributionPoint(ASN1Sequence paramASN1Sequence)
  {
    for (int i = 0; i != paramASN1Sequence.size(); i++)
    {
      ASN1TaggedObject localASN1TaggedObject = ASN1TaggedObject.getInstance(paramASN1Sequence.getObjectAt(i));
      switch (localASN1TaggedObject.getTagNo())
      {
      case 0: 
        this.distributionPoint = DistributionPointName.getInstance(localASN1TaggedObject, true);
        break;
      case 1: 
        this.reasons = new ReasonFlags(DERBitString.getInstance(localASN1TaggedObject, false));
        break;
      case 2: 
        this.cRLIssuer = GeneralNames.getInstance(localASN1TaggedObject, false);
      }
    }
  }
  
  public DistributionPoint(DistributionPointName paramDistributionPointName, ReasonFlags paramReasonFlags, GeneralNames paramGeneralNames)
  {
    this.distributionPoint = paramDistributionPointName;
    this.reasons = paramReasonFlags;
    this.cRLIssuer = paramGeneralNames;
  }
  
  public DistributionPointName getDistributionPoint()
  {
    return this.distributionPoint;
  }
  
  public ReasonFlags getReasons()
  {
    return this.reasons;
  }
  
  public GeneralNames getCRLIssuer()
  {
    return this.cRLIssuer;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    if (this.distributionPoint != null) {
      localASN1EncodableVector.add(new DERTaggedObject(0, this.distributionPoint));
    }
    if (this.reasons != null) {
      localASN1EncodableVector.add(new DERTaggedObject(false, 1, this.reasons));
    }
    if (this.cRLIssuer != null) {
      localASN1EncodableVector.add(new DERTaggedObject(false, 2, this.cRLIssuer));
    }
    return new DERSequence(localASN1EncodableVector);
  }
  
  public String toString()
  {
    String str = System.getProperty("line.separator");
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("DistributionPoint: [");
    localStringBuffer.append(str);
    if (this.distributionPoint != null) {
      appendObject(localStringBuffer, str, "distributionPoint", this.distributionPoint.toString());
    }
    if (this.reasons != null) {
      appendObject(localStringBuffer, str, "reasons", this.reasons.toString());
    }
    if (this.cRLIssuer != null) {
      appendObject(localStringBuffer, str, "cRLIssuer", this.cRLIssuer.toString());
    }
    localStringBuffer.append("]");
    localStringBuffer.append(str);
    return localStringBuffer.toString();
  }
  
  private void appendObject(StringBuffer paramStringBuffer, String paramString1, String paramString2, String paramString3)
  {
    String str = "    ";
    paramStringBuffer.append(str);
    paramStringBuffer.append(paramString2);
    paramStringBuffer.append(":");
    paramStringBuffer.append(paramString1);
    paramStringBuffer.append(str);
    paramStringBuffer.append(str);
    paramStringBuffer.append(paramString3);
    paramStringBuffer.append(paramString1);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x509\DistributionPoint.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */