package org.bouncycastle.asn1.x509;

import org.bouncycastle.asn1.DERObjectIdentifier;

public class X509Attributes
{
  public static final DERObjectIdentifier RoleSyntax = new DERObjectIdentifier("2.5.4.72");
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x509\X509Attributes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */