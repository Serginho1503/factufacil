package org.bouncycastle.asn1.x509;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;

public class UserNotice
  extends ASN1Encodable
{
  private NoticeReference noticeRef;
  private DisplayText explicitText;
  
  public UserNotice(NoticeReference paramNoticeReference, DisplayText paramDisplayText)
  {
    this.noticeRef = paramNoticeReference;
    this.explicitText = paramDisplayText;
  }
  
  public UserNotice(NoticeReference paramNoticeReference, String paramString)
  {
    this.noticeRef = paramNoticeReference;
    this.explicitText = new DisplayText(paramString);
  }
  
  public UserNotice(ASN1Sequence paramASN1Sequence)
  {
    if (paramASN1Sequence.size() == 2)
    {
      this.noticeRef = NoticeReference.getInstance(paramASN1Sequence.getObjectAt(0));
      this.explicitText = DisplayText.getInstance(paramASN1Sequence.getObjectAt(1));
    }
    else if (paramASN1Sequence.size() == 1)
    {
      if ((paramASN1Sequence.getObjectAt(0).getDERObject() instanceof ASN1Sequence)) {
        this.noticeRef = NoticeReference.getInstance(paramASN1Sequence.getObjectAt(0));
      } else {
        this.explicitText = DisplayText.getInstance(paramASN1Sequence.getObjectAt(0));
      }
    }
    else
    {
      throw new IllegalArgumentException("Bad sequence size: " + paramASN1Sequence.size());
    }
  }
  
  public NoticeReference getNoticeRef()
  {
    return this.noticeRef;
  }
  
  public DisplayText getExplicitText()
  {
    return this.explicitText;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    if (this.noticeRef != null) {
      localASN1EncodableVector.add(this.noticeRef);
    }
    if (this.explicitText != null) {
      localASN1EncodableVector.add(this.explicitText);
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x509\UserNotice.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */