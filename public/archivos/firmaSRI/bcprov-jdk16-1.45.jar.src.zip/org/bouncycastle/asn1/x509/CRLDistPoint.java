package org.bouncycastle.asn1.x509;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;

public class CRLDistPoint
  extends ASN1Encodable
{
  ASN1Sequence seq = null;
  
  public static CRLDistPoint getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1Sequence.getInstance(paramASN1TaggedObject, paramBoolean));
  }
  
  public static CRLDistPoint getInstance(Object paramObject)
  {
    if (((paramObject instanceof CRLDistPoint)) || (paramObject == null)) {
      return (CRLDistPoint)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new CRLDistPoint((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in factory: " + paramObject.getClass().getName());
  }
  
  public CRLDistPoint(ASN1Sequence paramASN1Sequence)
  {
    this.seq = paramASN1Sequence;
  }
  
  public CRLDistPoint(DistributionPoint[] paramArrayOfDistributionPoint)
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    for (int i = 0; i != paramArrayOfDistributionPoint.length; i++) {
      localASN1EncodableVector.add(paramArrayOfDistributionPoint[i]);
    }
    this.seq = new DERSequence(localASN1EncodableVector);
  }
  
  public DistributionPoint[] getDistributionPoints()
  {
    DistributionPoint[] arrayOfDistributionPoint = new DistributionPoint[this.seq.size()];
    for (int i = 0; i != this.seq.size(); i++) {
      arrayOfDistributionPoint[i] = DistributionPoint.getInstance(this.seq.getObjectAt(i));
    }
    return arrayOfDistributionPoint;
  }
  
  public DERObject toASN1Object()
  {
    return this.seq;
  }
  
  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    String str = System.getProperty("line.separator");
    localStringBuffer.append("CRLDistPoint:");
    localStringBuffer.append(str);
    DistributionPoint[] arrayOfDistributionPoint = getDistributionPoints();
    for (int i = 0; i != arrayOfDistributionPoint.length; i++)
    {
      localStringBuffer.append("    ");
      localStringBuffer.append(arrayOfDistributionPoint[i]);
      localStringBuffer.append(str);
    }
    return localStringBuffer.toString();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x509\CRLDistPoint.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */