package org.bouncycastle.asn1.x509;

public class X509NameTokenizer
{
  private String value;
  private int index;
  private char seperator;
  private StringBuffer buf = new StringBuffer();
  
  public X509NameTokenizer(String paramString)
  {
    this(paramString, ',');
  }
  
  public X509NameTokenizer(String paramString, char paramChar)
  {
    this.value = paramString;
    this.index = -1;
    this.seperator = paramChar;
  }
  
  public boolean hasMoreTokens()
  {
    return this.index != this.value.length();
  }
  
  public String nextToken()
  {
    if (this.index == this.value.length()) {
      return null;
    }
    int i = this.index + 1;
    int j = 0;
    int k = 0;
    this.buf.setLength(0);
    while (i != this.value.length())
    {
      char c = this.value.charAt(i);
      if (c == '"')
      {
        if (k == 0) {
          j = j == 0 ? 1 : 0;
        } else {
          this.buf.append(c);
        }
        k = 0;
      }
      else if ((k != 0) || (j != 0))
      {
        if ((c == '#') && (this.buf.charAt(this.buf.length() - 1) == '=')) {
          this.buf.append('\\');
        } else if ((c == '+') && (this.seperator != '+')) {
          this.buf.append('\\');
        }
        this.buf.append(c);
        k = 0;
      }
      else if (c == '\\')
      {
        k = 1;
      }
      else
      {
        if (c == this.seperator) {
          break;
        }
        this.buf.append(c);
      }
      i++;
    }
    this.index = i;
    return this.buf.toString().trim();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x509\X509NameTokenizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */