package org.bouncycastle.asn1.x509;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;

public class GeneralNames
  extends ASN1Encodable
{
  private final GeneralName[] names;
  
  public static GeneralNames getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof GeneralNames))) {
      return (GeneralNames)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new GeneralNames((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("illegal object in getInstance: " + paramObject.getClass().getName());
  }
  
  public static GeneralNames getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1Sequence.getInstance(paramASN1TaggedObject, paramBoolean));
  }
  
  public GeneralNames(GeneralName paramGeneralName)
  {
    this.names = new GeneralName[] { paramGeneralName };
  }
  
  public GeneralNames(ASN1Sequence paramASN1Sequence)
  {
    this.names = new GeneralName[paramASN1Sequence.size()];
    for (int i = 0; i != paramASN1Sequence.size(); i++) {
      this.names[i] = GeneralName.getInstance(paramASN1Sequence.getObjectAt(i));
    }
  }
  
  public GeneralName[] getNames()
  {
    GeneralName[] arrayOfGeneralName = new GeneralName[this.names.length];
    System.arraycopy(this.names, 0, arrayOfGeneralName, 0, this.names.length);
    return arrayOfGeneralName;
  }
  
  public DERObject toASN1Object()
  {
    return new DERSequence(this.names);
  }
  
  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    String str = System.getProperty("line.separator");
    localStringBuffer.append("GeneralNames:");
    localStringBuffer.append(str);
    for (int i = 0; i != this.names.length; i++)
    {
      localStringBuffer.append("    ");
      localStringBuffer.append(this.names[i]);
      localStringBuffer.append(str);
    }
    return localStringBuffer.toString();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x509\GeneralNames.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */