package org.bouncycastle.asn1.x509;

import org.bouncycastle.asn1.DERBitString;

public class KeyUsage
  extends DERBitString
{
  public static final int digitalSignature = 128;
  public static final int nonRepudiation = 64;
  public static final int keyEncipherment = 32;
  public static final int dataEncipherment = 16;
  public static final int keyAgreement = 8;
  public static final int keyCertSign = 4;
  public static final int cRLSign = 2;
  public static final int encipherOnly = 1;
  public static final int decipherOnly = 32768;
  
  public static DERBitString getInstance(Object paramObject)
  {
    if ((paramObject instanceof KeyUsage)) {
      return (KeyUsage)paramObject;
    }
    if ((paramObject instanceof X509Extension)) {
      return new KeyUsage(DERBitString.getInstance(X509Extension.convertValueToObject((X509Extension)paramObject)));
    }
    return new KeyUsage(DERBitString.getInstance(paramObject));
  }
  
  public KeyUsage(int paramInt)
  {
    super(getBytes(paramInt), getPadBits(paramInt));
  }
  
  public KeyUsage(DERBitString paramDERBitString)
  {
    super(paramDERBitString.getBytes(), paramDERBitString.getPadBits());
  }
  
  public String toString()
  {
    if (this.data.length == 1) {
      return "KeyUsage: 0x" + Integer.toHexString(this.data[0] & 0xFF);
    }
    return "KeyUsage: 0x" + Integer.toHexString((this.data[1] & 0xFF) << 8 | this.data[0] & 0xFF);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x509\KeyUsage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */