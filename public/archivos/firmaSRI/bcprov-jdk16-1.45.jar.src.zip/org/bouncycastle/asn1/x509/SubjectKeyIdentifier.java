package org.bouncycastle.asn1.x509;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.crypto.Digest;
import org.bouncycastle.crypto.digests.SHA1Digest;

public class SubjectKeyIdentifier
  extends ASN1Encodable
{
  private byte[] keyidentifier;
  
  public static SubjectKeyIdentifier getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1OctetString.getInstance(paramASN1TaggedObject, paramBoolean));
  }
  
  public static SubjectKeyIdentifier getInstance(Object paramObject)
  {
    if ((paramObject instanceof SubjectKeyIdentifier)) {
      return (SubjectKeyIdentifier)paramObject;
    }
    if ((paramObject instanceof SubjectPublicKeyInfo)) {
      return new SubjectKeyIdentifier((SubjectPublicKeyInfo)paramObject);
    }
    if ((paramObject instanceof ASN1OctetString)) {
      return new SubjectKeyIdentifier((ASN1OctetString)paramObject);
    }
    if ((paramObject instanceof X509Extension)) {
      return getInstance(X509Extension.convertValueToObject((X509Extension)paramObject));
    }
    throw new IllegalArgumentException("Invalid SubjectKeyIdentifier: " + paramObject.getClass().getName());
  }
  
  public SubjectKeyIdentifier(byte[] paramArrayOfByte)
  {
    this.keyidentifier = paramArrayOfByte;
  }
  
  public SubjectKeyIdentifier(ASN1OctetString paramASN1OctetString)
  {
    this.keyidentifier = paramASN1OctetString.getOctets();
  }
  
  public SubjectKeyIdentifier(SubjectPublicKeyInfo paramSubjectPublicKeyInfo)
  {
    this.keyidentifier = getDigest(paramSubjectPublicKeyInfo);
  }
  
  public byte[] getKeyIdentifier()
  {
    return this.keyidentifier;
  }
  
  public DERObject toASN1Object()
  {
    return new DEROctetString(this.keyidentifier);
  }
  
  public static SubjectKeyIdentifier createSHA1KeyIdentifier(SubjectPublicKeyInfo paramSubjectPublicKeyInfo)
  {
    return new SubjectKeyIdentifier(paramSubjectPublicKeyInfo);
  }
  
  public static SubjectKeyIdentifier createTruncatedSHA1KeyIdentifier(SubjectPublicKeyInfo paramSubjectPublicKeyInfo)
  {
    byte[] arrayOfByte1 = getDigest(paramSubjectPublicKeyInfo);
    byte[] arrayOfByte2 = new byte[8];
    System.arraycopy(arrayOfByte1, arrayOfByte1.length - 8, arrayOfByte2, 0, arrayOfByte2.length);
    int tmp25_24 = 0;
    byte[] tmp25_23 = arrayOfByte2;
    tmp25_23[tmp25_24] = ((byte)(tmp25_23[tmp25_24] & 0xF));
    int tmp34_33 = 0;
    byte[] tmp34_32 = arrayOfByte2;
    tmp34_32[tmp34_33] = ((byte)(tmp34_32[tmp34_33] | 0x40));
    return new SubjectKeyIdentifier(arrayOfByte2);
  }
  
  private static byte[] getDigest(SubjectPublicKeyInfo paramSubjectPublicKeyInfo)
  {
    SHA1Digest localSHA1Digest = new SHA1Digest();
    byte[] arrayOfByte1 = new byte[localSHA1Digest.getDigestSize()];
    byte[] arrayOfByte2 = paramSubjectPublicKeyInfo.getPublicKeyData().getBytes();
    localSHA1Digest.update(arrayOfByte2, 0, arrayOfByte2.length);
    localSHA1Digest.doFinal(arrayOfByte1, 0);
    return arrayOfByte1;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x509\SubjectKeyIdentifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */