package org.bouncycastle.asn1.x509;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;

public class V2Form
  extends ASN1Encodable
{
  GeneralNames issuerName;
  IssuerSerial baseCertificateID;
  ObjectDigestInfo objectDigestInfo;
  
  public static V2Form getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1Sequence.getInstance(paramASN1TaggedObject, paramBoolean));
  }
  
  public static V2Form getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof V2Form))) {
      return (V2Form)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new V2Form((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in factory: " + paramObject.getClass().getName());
  }
  
  public V2Form(GeneralNames paramGeneralNames)
  {
    this.issuerName = paramGeneralNames;
  }
  
  public V2Form(ASN1Sequence paramASN1Sequence)
  {
    if (paramASN1Sequence.size() > 3) {
      throw new IllegalArgumentException("Bad sequence size: " + paramASN1Sequence.size());
    }
    int i = 0;
    if (!(paramASN1Sequence.getObjectAt(0) instanceof ASN1TaggedObject))
    {
      i++;
      this.issuerName = GeneralNames.getInstance(paramASN1Sequence.getObjectAt(0));
    }
    for (int j = i; j != paramASN1Sequence.size(); j++)
    {
      ASN1TaggedObject localASN1TaggedObject = ASN1TaggedObject.getInstance(paramASN1Sequence.getObjectAt(j));
      if (localASN1TaggedObject.getTagNo() == 0) {
        this.baseCertificateID = IssuerSerial.getInstance(localASN1TaggedObject, false);
      } else if (localASN1TaggedObject.getTagNo() == 1) {
        this.objectDigestInfo = ObjectDigestInfo.getInstance(localASN1TaggedObject, false);
      } else {
        throw new IllegalArgumentException("Bad tag number: " + localASN1TaggedObject.getTagNo());
      }
    }
  }
  
  public GeneralNames getIssuerName()
  {
    return this.issuerName;
  }
  
  public IssuerSerial getBaseCertificateID()
  {
    return this.baseCertificateID;
  }
  
  public ObjectDigestInfo getObjectDigestInfo()
  {
    return this.objectDigestInfo;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    if (this.issuerName != null) {
      localASN1EncodableVector.add(this.issuerName);
    }
    if (this.baseCertificateID != null) {
      localASN1EncodableVector.add(new DERTaggedObject(false, 0, this.baseCertificateID));
    }
    if (this.objectDigestInfo != null) {
      localASN1EncodableVector.add(new DERTaggedObject(false, 1, this.objectDigestInfo));
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x509\V2Form.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */