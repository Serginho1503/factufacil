package org.bouncycastle.asn1.x509;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERBoolean;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSequence;

public class X509Extensions
  extends ASN1Encodable
{
  public static final DERObjectIdentifier SubjectDirectoryAttributes = new DERObjectIdentifier("2.5.29.9");
  public static final DERObjectIdentifier SubjectKeyIdentifier = new DERObjectIdentifier("2.5.29.14");
  public static final DERObjectIdentifier KeyUsage = new DERObjectIdentifier("2.5.29.15");
  public static final DERObjectIdentifier PrivateKeyUsagePeriod = new DERObjectIdentifier("2.5.29.16");
  public static final DERObjectIdentifier SubjectAlternativeName = new DERObjectIdentifier("2.5.29.17");
  public static final DERObjectIdentifier IssuerAlternativeName = new DERObjectIdentifier("2.5.29.18");
  public static final DERObjectIdentifier BasicConstraints = new DERObjectIdentifier("2.5.29.19");
  public static final DERObjectIdentifier CRLNumber = new DERObjectIdentifier("2.5.29.20");
  public static final DERObjectIdentifier ReasonCode = new DERObjectIdentifier("2.5.29.21");
  public static final DERObjectIdentifier InstructionCode = new DERObjectIdentifier("2.5.29.23");
  public static final DERObjectIdentifier InvalidityDate = new DERObjectIdentifier("2.5.29.24");
  public static final DERObjectIdentifier DeltaCRLIndicator = new DERObjectIdentifier("2.5.29.27");
  public static final DERObjectIdentifier IssuingDistributionPoint = new DERObjectIdentifier("2.5.29.28");
  public static final DERObjectIdentifier CertificateIssuer = new DERObjectIdentifier("2.5.29.29");
  public static final DERObjectIdentifier NameConstraints = new DERObjectIdentifier("2.5.29.30");
  public static final DERObjectIdentifier CRLDistributionPoints = new DERObjectIdentifier("2.5.29.31");
  public static final DERObjectIdentifier CertificatePolicies = new DERObjectIdentifier("2.5.29.32");
  public static final DERObjectIdentifier PolicyMappings = new DERObjectIdentifier("2.5.29.33");
  public static final DERObjectIdentifier AuthorityKeyIdentifier = new DERObjectIdentifier("2.5.29.35");
  public static final DERObjectIdentifier PolicyConstraints = new DERObjectIdentifier("2.5.29.36");
  public static final DERObjectIdentifier ExtendedKeyUsage = new DERObjectIdentifier("2.5.29.37");
  public static final DERObjectIdentifier FreshestCRL = new DERObjectIdentifier("2.5.29.46");
  public static final DERObjectIdentifier InhibitAnyPolicy = new DERObjectIdentifier("2.5.29.54");
  public static final DERObjectIdentifier AuthorityInfoAccess = new DERObjectIdentifier("1.3.6.1.5.5.7.1.1");
  public static final DERObjectIdentifier SubjectInfoAccess = new DERObjectIdentifier("1.3.6.1.5.5.7.1.11");
  public static final DERObjectIdentifier LogoType = new DERObjectIdentifier("1.3.6.1.5.5.7.1.12");
  public static final DERObjectIdentifier BiometricInfo = new DERObjectIdentifier("1.3.6.1.5.5.7.1.2");
  public static final DERObjectIdentifier QCStatements = new DERObjectIdentifier("1.3.6.1.5.5.7.1.3");
  public static final DERObjectIdentifier AuditIdentity = new DERObjectIdentifier("1.3.6.1.5.5.7.1.4");
  public static final DERObjectIdentifier NoRevAvail = new DERObjectIdentifier("2.5.29.56");
  public static final DERObjectIdentifier TargetInformation = new DERObjectIdentifier("2.5.29.55");
  private Hashtable extensions = new Hashtable();
  private Vector ordering = new Vector();
  
  public static X509Extensions getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1Sequence.getInstance(paramASN1TaggedObject, paramBoolean));
  }
  
  public static X509Extensions getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof X509Extensions))) {
      return (X509Extensions)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new X509Extensions((ASN1Sequence)paramObject);
    }
    if ((paramObject instanceof ASN1TaggedObject)) {
      return getInstance(((ASN1TaggedObject)paramObject).getObject());
    }
    throw new IllegalArgumentException("illegal object in getInstance: " + paramObject.getClass().getName());
  }
  
  public X509Extensions(ASN1Sequence paramASN1Sequence)
  {
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    while (localEnumeration.hasMoreElements())
    {
      ASN1Sequence localASN1Sequence = ASN1Sequence.getInstance(localEnumeration.nextElement());
      if (localASN1Sequence.size() == 3) {
        this.extensions.put(localASN1Sequence.getObjectAt(0), new X509Extension(DERBoolean.getInstance(localASN1Sequence.getObjectAt(1)), ASN1OctetString.getInstance(localASN1Sequence.getObjectAt(2))));
      } else if (localASN1Sequence.size() == 2) {
        this.extensions.put(localASN1Sequence.getObjectAt(0), new X509Extension(false, ASN1OctetString.getInstance(localASN1Sequence.getObjectAt(1))));
      } else {
        throw new IllegalArgumentException("Bad sequence size: " + localASN1Sequence.size());
      }
      this.ordering.addElement(localASN1Sequence.getObjectAt(0));
    }
  }
  
  public X509Extensions(Hashtable paramHashtable)
  {
    this(null, paramHashtable);
  }
  
  public X509Extensions(Vector paramVector, Hashtable paramHashtable)
  {
    if (paramVector == null) {
      localEnumeration = paramHashtable.keys();
    } else {
      localEnumeration = paramVector.elements();
    }
    while (localEnumeration.hasMoreElements()) {
      this.ordering.addElement(localEnumeration.nextElement());
    }
    Enumeration localEnumeration = this.ordering.elements();
    while (localEnumeration.hasMoreElements())
    {
      DERObjectIdentifier localDERObjectIdentifier = (DERObjectIdentifier)localEnumeration.nextElement();
      X509Extension localX509Extension = (X509Extension)paramHashtable.get(localDERObjectIdentifier);
      this.extensions.put(localDERObjectIdentifier, localX509Extension);
    }
  }
  
  public X509Extensions(Vector paramVector1, Vector paramVector2)
  {
    Enumeration localEnumeration = paramVector1.elements();
    while (localEnumeration.hasMoreElements()) {
      this.ordering.addElement(localEnumeration.nextElement());
    }
    int i = 0;
    localEnumeration = this.ordering.elements();
    while (localEnumeration.hasMoreElements())
    {
      DERObjectIdentifier localDERObjectIdentifier = (DERObjectIdentifier)localEnumeration.nextElement();
      X509Extension localX509Extension = (X509Extension)paramVector2.elementAt(i);
      this.extensions.put(localDERObjectIdentifier, localX509Extension);
      i++;
    }
  }
  
  public Enumeration oids()
  {
    return this.ordering.elements();
  }
  
  public X509Extension getExtension(DERObjectIdentifier paramDERObjectIdentifier)
  {
    return (X509Extension)this.extensions.get(paramDERObjectIdentifier);
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector1 = new ASN1EncodableVector();
    Enumeration localEnumeration = this.ordering.elements();
    while (localEnumeration.hasMoreElements())
    {
      DERObjectIdentifier localDERObjectIdentifier = (DERObjectIdentifier)localEnumeration.nextElement();
      X509Extension localX509Extension = (X509Extension)this.extensions.get(localDERObjectIdentifier);
      ASN1EncodableVector localASN1EncodableVector2 = new ASN1EncodableVector();
      localASN1EncodableVector2.add(localDERObjectIdentifier);
      if (localX509Extension.isCritical()) {
        localASN1EncodableVector2.add(new DERBoolean(true));
      }
      localASN1EncodableVector2.add(localX509Extension.getValue());
      localASN1EncodableVector1.add(new DERSequence(localASN1EncodableVector2));
    }
    return new DERSequence(localASN1EncodableVector1);
  }
  
  public boolean equivalent(X509Extensions paramX509Extensions)
  {
    if (this.extensions.size() != paramX509Extensions.extensions.size()) {
      return false;
    }
    Enumeration localEnumeration = this.extensions.keys();
    while (localEnumeration.hasMoreElements())
    {
      Object localObject = localEnumeration.nextElement();
      if (!this.extensions.get(localObject).equals(paramX509Extensions.extensions.get(localObject))) {
        return false;
      }
    }
    return true;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x509\X509Extensions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */