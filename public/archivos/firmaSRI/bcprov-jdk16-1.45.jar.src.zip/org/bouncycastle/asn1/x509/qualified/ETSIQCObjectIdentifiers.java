package org.bouncycastle.asn1.x509.qualified;

import org.bouncycastle.asn1.DERObjectIdentifier;

public abstract interface ETSIQCObjectIdentifiers
{
  public static final String id_etsi_qcs = "0.4.0.1862.1";
  public static final DERObjectIdentifier id_etsi_qcs_QcCompliance = new DERObjectIdentifier("0.4.0.1862.1.1");
  public static final DERObjectIdentifier id_etsi_qcs_LimiteValue = new DERObjectIdentifier("0.4.0.1862.1.2");
  public static final DERObjectIdentifier id_etsi_qcs_RetentionPeriod = new DERObjectIdentifier("0.4.0.1862.1.3");
  public static final DERObjectIdentifier id_etsi_qcs_QcSSCD = new DERObjectIdentifier("0.4.0.1862.1.4");
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x509\qualified\ETSIQCObjectIdentifiers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */