package org.bouncycastle.asn1.x509;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DEREnumerated;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSequence;

public class ObjectDigestInfo
  extends ASN1Encodable
{
  public static final int publicKey = 0;
  public static final int publicKeyCert = 1;
  public static final int otherObjectDigest = 2;
  DEREnumerated digestedObjectType;
  DERObjectIdentifier otherObjectTypeID;
  AlgorithmIdentifier digestAlgorithm;
  DERBitString objectDigest;
  
  public static ObjectDigestInfo getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof ObjectDigestInfo))) {
      return (ObjectDigestInfo)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new ObjectDigestInfo((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("illegal object in getInstance: " + paramObject.getClass().getName());
  }
  
  public static ObjectDigestInfo getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1Sequence.getInstance(paramASN1TaggedObject, paramBoolean));
  }
  
  public ObjectDigestInfo(int paramInt, String paramString, AlgorithmIdentifier paramAlgorithmIdentifier, byte[] paramArrayOfByte)
  {
    this.digestedObjectType = new DEREnumerated(paramInt);
    if (paramInt == 2) {
      this.otherObjectTypeID = new DERObjectIdentifier(paramString);
    }
    this.digestAlgorithm = paramAlgorithmIdentifier;
    this.objectDigest = new DERBitString(paramArrayOfByte);
  }
  
  private ObjectDigestInfo(ASN1Sequence paramASN1Sequence)
  {
    if ((paramASN1Sequence.size() > 4) || (paramASN1Sequence.size() < 3)) {
      throw new IllegalArgumentException("Bad sequence size: " + paramASN1Sequence.size());
    }
    this.digestedObjectType = DEREnumerated.getInstance(paramASN1Sequence.getObjectAt(0));
    int i = 0;
    if (paramASN1Sequence.size() == 4)
    {
      this.otherObjectTypeID = DERObjectIdentifier.getInstance(paramASN1Sequence.getObjectAt(1));
      i++;
    }
    this.digestAlgorithm = AlgorithmIdentifier.getInstance(paramASN1Sequence.getObjectAt(1 + i));
    this.objectDigest = DERBitString.getInstance(paramASN1Sequence.getObjectAt(2 + i));
  }
  
  public DEREnumerated getDigestedObjectType()
  {
    return this.digestedObjectType;
  }
  
  public DERObjectIdentifier getOtherObjectTypeID()
  {
    return this.otherObjectTypeID;
  }
  
  public AlgorithmIdentifier getDigestAlgorithm()
  {
    return this.digestAlgorithm;
  }
  
  public DERBitString getObjectDigest()
  {
    return this.objectDigest;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.digestedObjectType);
    if (this.otherObjectTypeID != null) {
      localASN1EncodableVector.add(this.otherObjectTypeID);
    }
    localASN1EncodableVector.add(this.digestAlgorithm);
    localASN1EncodableVector.add(this.objectDigest);
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x509\ObjectDigestInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */