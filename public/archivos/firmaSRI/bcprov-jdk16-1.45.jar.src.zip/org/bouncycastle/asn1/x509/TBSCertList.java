package org.bouncycastle.asn1.x509;

import java.math.BigInteger;
import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERGeneralizedTime;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.DERUTCTime;

public class TBSCertList
  extends ASN1Encodable
{
  ASN1Sequence seq;
  DERInteger version;
  AlgorithmIdentifier signature;
  X509Name issuer;
  Time thisUpdate;
  Time nextUpdate;
  ASN1Sequence revokedCertificates;
  X509Extensions crlExtensions;
  
  public static TBSCertList getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1Sequence.getInstance(paramASN1TaggedObject, paramBoolean));
  }
  
  public static TBSCertList getInstance(Object paramObject)
  {
    if ((paramObject instanceof TBSCertList)) {
      return (TBSCertList)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new TBSCertList((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in factory: " + paramObject.getClass().getName());
  }
  
  public TBSCertList(ASN1Sequence paramASN1Sequence)
  {
    if ((paramASN1Sequence.size() < 3) || (paramASN1Sequence.size() > 7)) {
      throw new IllegalArgumentException("Bad sequence size: " + paramASN1Sequence.size());
    }
    int i = 0;
    this.seq = paramASN1Sequence;
    if ((paramASN1Sequence.getObjectAt(i) instanceof DERInteger)) {
      this.version = DERInteger.getInstance(paramASN1Sequence.getObjectAt(i++));
    } else {
      this.version = new DERInteger(0);
    }
    this.signature = AlgorithmIdentifier.getInstance(paramASN1Sequence.getObjectAt(i++));
    this.issuer = X509Name.getInstance(paramASN1Sequence.getObjectAt(i++));
    this.thisUpdate = Time.getInstance(paramASN1Sequence.getObjectAt(i++));
    if ((i < paramASN1Sequence.size()) && (((paramASN1Sequence.getObjectAt(i) instanceof DERUTCTime)) || ((paramASN1Sequence.getObjectAt(i) instanceof DERGeneralizedTime)) || ((paramASN1Sequence.getObjectAt(i) instanceof Time)))) {
      this.nextUpdate = Time.getInstance(paramASN1Sequence.getObjectAt(i++));
    }
    if ((i < paramASN1Sequence.size()) && (!(paramASN1Sequence.getObjectAt(i) instanceof DERTaggedObject))) {
      this.revokedCertificates = ASN1Sequence.getInstance(paramASN1Sequence.getObjectAt(i++));
    }
    if ((i < paramASN1Sequence.size()) && ((paramASN1Sequence.getObjectAt(i) instanceof DERTaggedObject))) {
      this.crlExtensions = X509Extensions.getInstance(paramASN1Sequence.getObjectAt(i));
    }
  }
  
  public int getVersion()
  {
    return this.version.getValue().intValue() + 1;
  }
  
  public DERInteger getVersionNumber()
  {
    return this.version;
  }
  
  public AlgorithmIdentifier getSignature()
  {
    return this.signature;
  }
  
  public X509Name getIssuer()
  {
    return this.issuer;
  }
  
  public Time getThisUpdate()
  {
    return this.thisUpdate;
  }
  
  public Time getNextUpdate()
  {
    return this.nextUpdate;
  }
  
  public CRLEntry[] getRevokedCertificates()
  {
    if (this.revokedCertificates == null) {
      return new CRLEntry[0];
    }
    CRLEntry[] arrayOfCRLEntry = new CRLEntry[this.revokedCertificates.size()];
    for (int i = 0; i < arrayOfCRLEntry.length; i++) {
      arrayOfCRLEntry[i] = new CRLEntry(ASN1Sequence.getInstance(this.revokedCertificates.getObjectAt(i)));
    }
    return arrayOfCRLEntry;
  }
  
  public Enumeration getRevokedCertificateEnumeration()
  {
    if (this.revokedCertificates == null) {
      return new EmptyEnumeration(null);
    }
    return new RevokedCertificatesEnumeration(this.revokedCertificates.getObjects());
  }
  
  public X509Extensions getExtensions()
  {
    return this.crlExtensions;
  }
  
  public DERObject toASN1Object()
  {
    return this.seq;
  }
  
  public class CRLEntry
    extends ASN1Encodable
  {
    ASN1Sequence seq;
    DERInteger userCertificate;
    Time revocationDate;
    X509Extensions crlEntryExtensions;
    
    public CRLEntry(ASN1Sequence paramASN1Sequence)
    {
      if ((paramASN1Sequence.size() < 2) || (paramASN1Sequence.size() > 3)) {
        throw new IllegalArgumentException("Bad sequence size: " + paramASN1Sequence.size());
      }
      this.seq = paramASN1Sequence;
      this.userCertificate = DERInteger.getInstance(paramASN1Sequence.getObjectAt(0));
      this.revocationDate = Time.getInstance(paramASN1Sequence.getObjectAt(1));
    }
    
    public DERInteger getUserCertificate()
    {
      return this.userCertificate;
    }
    
    public Time getRevocationDate()
    {
      return this.revocationDate;
    }
    
    public X509Extensions getExtensions()
    {
      if ((this.crlEntryExtensions == null) && (this.seq.size() == 3)) {
        this.crlEntryExtensions = X509Extensions.getInstance(this.seq.getObjectAt(2));
      }
      return this.crlEntryExtensions;
    }
    
    public DERObject toASN1Object()
    {
      return this.seq;
    }
  }
  
  private class EmptyEnumeration
    implements Enumeration
  {
    private EmptyEnumeration() {}
    
    public boolean hasMoreElements()
    {
      return false;
    }
    
    public Object nextElement()
    {
      return null;
    }
  }
  
  private class RevokedCertificatesEnumeration
    implements Enumeration
  {
    private final Enumeration en;
    
    RevokedCertificatesEnumeration(Enumeration paramEnumeration)
    {
      this.en = paramEnumeration;
    }
    
    public boolean hasMoreElements()
    {
      return this.en.hasMoreElements();
    }
    
    public Object nextElement()
    {
      return new TBSCertList.CRLEntry(TBSCertList.this, ASN1Sequence.getInstance(this.en.nextElement()));
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\x509\TBSCertList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */