package org.bouncycastle.asn1;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigInteger;

public class DERObjectIdentifier
  extends ASN1Object
{
  String identifier;
  
  public static DERObjectIdentifier getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof DERObjectIdentifier))) {
      return (DERObjectIdentifier)paramObject;
    }
    if ((paramObject instanceof ASN1OctetString)) {
      return new DERObjectIdentifier(((ASN1OctetString)paramObject).getOctets());
    }
    if ((paramObject instanceof ASN1TaggedObject)) {
      return getInstance(((ASN1TaggedObject)paramObject).getObject());
    }
    throw new IllegalArgumentException("illegal object in getInstance: " + paramObject.getClass().getName());
  }
  
  public static DERObjectIdentifier getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(paramASN1TaggedObject.getObject());
  }
  
  DERObjectIdentifier(byte[] paramArrayOfByte)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    long l = 0L;
    BigInteger localBigInteger = null;
    int i = 1;
    for (int j = 0; j != paramArrayOfByte.length; j++)
    {
      int k = paramArrayOfByte[j] & 0xFF;
      if (l < 36028797018963968L)
      {
        l = l * 128L + (k & 0x7F);
        if ((k & 0x80) == 0)
        {
          if (i != 0)
          {
            switch ((int)l / 40)
            {
            case 0: 
              localStringBuffer.append('0');
              break;
            case 1: 
              localStringBuffer.append('1');
              l -= 40L;
              break;
            default: 
              localStringBuffer.append('2');
              l -= 80L;
            }
            i = 0;
          }
          localStringBuffer.append('.');
          localStringBuffer.append(l);
          l = 0L;
        }
      }
      else
      {
        if (localBigInteger == null) {
          localBigInteger = BigInteger.valueOf(l);
        }
        localBigInteger = localBigInteger.shiftLeft(7);
        localBigInteger = localBigInteger.or(BigInteger.valueOf(k & 0x7F));
        if ((k & 0x80) == 0)
        {
          localStringBuffer.append('.');
          localStringBuffer.append(localBigInteger);
          localBigInteger = null;
          l = 0L;
        }
      }
    }
    this.identifier = localStringBuffer.toString();
  }
  
  public DERObjectIdentifier(String paramString)
  {
    if (!isValidIdentifier(paramString)) {
      throw new IllegalArgumentException("string " + paramString + " not an OID");
    }
    this.identifier = paramString;
  }
  
  public String getId()
  {
    return this.identifier;
  }
  
  private void writeField(OutputStream paramOutputStream, long paramLong)
    throws IOException
  {
    if (paramLong >= 128L)
    {
      if (paramLong >= 16384L)
      {
        if (paramLong >= 2097152L)
        {
          if (paramLong >= 268435456L)
          {
            if (paramLong >= 34359738368L)
            {
              if (paramLong >= 4398046511104L)
              {
                if (paramLong >= 562949953421312L)
                {
                  if (paramLong >= 72057594037927936L) {
                    paramOutputStream.write((int)(paramLong >> 56) | 0x80);
                  }
                  paramOutputStream.write((int)(paramLong >> 49) | 0x80);
                }
                paramOutputStream.write((int)(paramLong >> 42) | 0x80);
              }
              paramOutputStream.write((int)(paramLong >> 35) | 0x80);
            }
            paramOutputStream.write((int)(paramLong >> 28) | 0x80);
          }
          paramOutputStream.write((int)(paramLong >> 21) | 0x80);
        }
        paramOutputStream.write((int)(paramLong >> 14) | 0x80);
      }
      paramOutputStream.write((int)(paramLong >> 7) | 0x80);
    }
    paramOutputStream.write((int)paramLong & 0x7F);
  }
  
  private void writeField(OutputStream paramOutputStream, BigInteger paramBigInteger)
    throws IOException
  {
    int i = (paramBigInteger.bitLength() + 6) / 7;
    if (i == 0)
    {
      paramOutputStream.write(0);
    }
    else
    {
      BigInteger localBigInteger = paramBigInteger;
      byte[] arrayOfByte = new byte[i];
      for (int j = i - 1; j >= 0; j--)
      {
        arrayOfByte[j] = ((byte)(localBigInteger.intValue() & 0x7F | 0x80));
        localBigInteger = localBigInteger.shiftRight(7);
      }
      int tmp79_78 = (i - 1);
      byte[] tmp79_74 = arrayOfByte;
      tmp79_74[tmp79_78] = ((byte)(tmp79_74[tmp79_78] & 0x7F));
      paramOutputStream.write(arrayOfByte);
    }
  }
  
  void encode(DEROutputStream paramDEROutputStream)
    throws IOException
  {
    OIDTokenizer localOIDTokenizer = new OIDTokenizer(this.identifier);
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    DEROutputStream localDEROutputStream = new DEROutputStream(localByteArrayOutputStream);
    writeField(localByteArrayOutputStream, Integer.parseInt(localOIDTokenizer.nextToken()) * 40 + Integer.parseInt(localOIDTokenizer.nextToken()));
    while (localOIDTokenizer.hasMoreTokens())
    {
      localObject = localOIDTokenizer.nextToken();
      if (((String)localObject).length() < 18) {
        writeField(localByteArrayOutputStream, Long.parseLong((String)localObject));
      } else {
        writeField(localByteArrayOutputStream, new BigInteger((String)localObject));
      }
    }
    localDEROutputStream.close();
    Object localObject = localByteArrayOutputStream.toByteArray();
    paramDEROutputStream.writeEncoded(6, (byte[])localObject);
  }
  
  public int hashCode()
  {
    return this.identifier.hashCode();
  }
  
  boolean asn1Equals(DERObject paramDERObject)
  {
    if (!(paramDERObject instanceof DERObjectIdentifier)) {
      return false;
    }
    return this.identifier.equals(((DERObjectIdentifier)paramDERObject).identifier);
  }
  
  public String toString()
  {
    return getId();
  }
  
  private static boolean isValidIdentifier(String paramString)
  {
    if ((paramString.length() < 3) || (paramString.charAt(1) != '.')) {
      return false;
    }
    int i = paramString.charAt(0);
    if ((i < 48) || (i > 50)) {
      return false;
    }
    boolean bool = false;
    for (int j = paramString.length() - 1; j >= 2; j--)
    {
      int k = paramString.charAt(j);
      if ((48 <= k) && (k <= 57))
      {
        bool = true;
      }
      else if (k == 46)
      {
        if (!bool) {
          return false;
        }
        bool = false;
      }
      else
      {
        return false;
      }
    }
    return bool;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\DERObjectIdentifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */