package org.bouncycastle.asn1.cmp;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERGeneralizedTime;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.crmf.CertId;
import org.bouncycastle.asn1.x509.X509Extensions;

public class RevAnnContent
  extends ASN1Encodable
{
  private PKIStatus status;
  private CertId certId;
  private DERGeneralizedTime willBeRevokedAt;
  private DERGeneralizedTime badSinceDate;
  private X509Extensions crlDetails;
  
  private RevAnnContent(ASN1Sequence paramASN1Sequence)
  {
    this.status = PKIStatus.getInstance(paramASN1Sequence.getObjectAt(0));
    this.certId = CertId.getInstance(paramASN1Sequence.getObjectAt(1));
    this.willBeRevokedAt = DERGeneralizedTime.getInstance(paramASN1Sequence.getObjectAt(2));
    this.badSinceDate = DERGeneralizedTime.getInstance(paramASN1Sequence.getObjectAt(3));
    if (paramASN1Sequence.size() > 4) {
      this.crlDetails = X509Extensions.getInstance(paramASN1Sequence.getObjectAt(4));
    }
  }
  
  public static RevAnnContent getInstance(Object paramObject)
  {
    if ((paramObject instanceof RevAnnContent)) {
      return (RevAnnContent)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new RevAnnContent((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }
  
  public PKIStatus getStatus()
  {
    return this.status;
  }
  
  public CertId getCertId()
  {
    return this.certId;
  }
  
  public DERGeneralizedTime getWillBeRevokedAt()
  {
    return this.willBeRevokedAt;
  }
  
  public DERGeneralizedTime getBadSinceDate()
  {
    return this.badSinceDate;
  }
  
  public X509Extensions getCrlDetails()
  {
    return this.crlDetails;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.status);
    localASN1EncodableVector.add(this.certId);
    localASN1EncodableVector.add(this.willBeRevokedAt);
    localASN1EncodableVector.add(this.badSinceDate);
    if (this.crlDetails != null) {
      localASN1EncodableVector.add(this.crlDetails);
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\cmp\RevAnnContent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */