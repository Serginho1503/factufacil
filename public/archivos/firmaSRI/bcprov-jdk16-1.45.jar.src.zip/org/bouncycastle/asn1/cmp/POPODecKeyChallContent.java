package org.bouncycastle.asn1.cmp;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;

public class POPODecKeyChallContent
  extends ASN1Encodable
{
  private ASN1Sequence content;
  
  private POPODecKeyChallContent(ASN1Sequence paramASN1Sequence)
  {
    this.content = paramASN1Sequence;
  }
  
  public static POPODecKeyChallContent getInstance(Object paramObject)
  {
    if ((paramObject instanceof POPODecKeyChallContent)) {
      return (POPODecKeyChallContent)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new POPODecKeyChallContent((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }
  
  public Challenge[] toChallengeArray()
  {
    Challenge[] arrayOfChallenge = new Challenge[this.content.size()];
    for (int i = 0; i != arrayOfChallenge.length; i++) {
      arrayOfChallenge[i] = Challenge.getInstance(this.content.getObjectAt(i));
    }
    return arrayOfChallenge;
  }
  
  public DERObject toASN1Object()
  {
    return this.content;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\cmp\POPODecKeyChallContent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */