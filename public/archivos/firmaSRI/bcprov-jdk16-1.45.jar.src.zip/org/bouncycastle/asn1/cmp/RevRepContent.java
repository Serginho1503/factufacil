package org.bouncycastle.asn1.cmp;

import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.crmf.CertId;
import org.bouncycastle.asn1.x509.CertificateList;

public class RevRepContent
  extends ASN1Encodable
{
  private ASN1Sequence status;
  private ASN1Sequence revCerts;
  private ASN1Sequence crls;
  
  private RevRepContent(ASN1Sequence paramASN1Sequence)
  {
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    this.status = ASN1Sequence.getInstance(localEnumeration.nextElement());
    while (localEnumeration.hasMoreElements())
    {
      ASN1TaggedObject localASN1TaggedObject = ASN1TaggedObject.getInstance(localEnumeration.nextElement());
      if (localASN1TaggedObject.getTagNo() == 0) {
        this.revCerts = ASN1Sequence.getInstance(localASN1TaggedObject, true);
      } else {
        this.crls = ASN1Sequence.getInstance(localASN1TaggedObject, true);
      }
    }
  }
  
  public static RevRepContent getInstance(Object paramObject)
  {
    if ((paramObject instanceof RevRepContent)) {
      return (RevRepContent)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new RevRepContent((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }
  
  public PKIStatusInfo[] getStatus()
  {
    PKIStatusInfo[] arrayOfPKIStatusInfo = new PKIStatusInfo[this.status.size()];
    for (int i = 0; i != arrayOfPKIStatusInfo.length; i++) {
      arrayOfPKIStatusInfo[i] = PKIStatusInfo.getInstance(this.status.getObjectAt(i));
    }
    return arrayOfPKIStatusInfo;
  }
  
  public CertId[] getRevCerts()
  {
    if (this.revCerts == null) {
      return null;
    }
    CertId[] arrayOfCertId = new CertId[this.revCerts.size()];
    for (int i = 0; i != arrayOfCertId.length; i++) {
      arrayOfCertId[i] = CertId.getInstance(this.revCerts.getObjectAt(i));
    }
    return arrayOfCertId;
  }
  
  public CertificateList[] getCrls()
  {
    if (this.crls == null) {
      return null;
    }
    CertificateList[] arrayOfCertificateList = new CertificateList[this.crls.size()];
    for (int i = 0; i != arrayOfCertificateList.length; i++) {
      arrayOfCertificateList[i] = CertificateList.getInstance(this.crls.getObjectAt(i));
    }
    return arrayOfCertificateList;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.status);
    addOptional(localASN1EncodableVector, 0, this.revCerts);
    addOptional(localASN1EncodableVector, 1, this.crls);
    return new DERSequence(localASN1EncodableVector);
  }
  
  private void addOptional(ASN1EncodableVector paramASN1EncodableVector, int paramInt, ASN1Encodable paramASN1Encodable)
  {
    if (paramASN1Encodable != null) {
      paramASN1EncodableVector.add(new DERTaggedObject(true, paramInt, paramASN1Encodable));
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\cmp\RevRepContent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */