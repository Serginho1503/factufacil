package org.bouncycastle.asn1.cmp;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;

public class CertConfirmContent
  extends ASN1Encodable
{
  private ASN1Sequence content;
  
  private CertConfirmContent(ASN1Sequence paramASN1Sequence)
  {
    this.content = paramASN1Sequence;
  }
  
  public static CertConfirmContent getInstance(Object paramObject)
  {
    if ((paramObject instanceof CertConfirmContent)) {
      return (CertConfirmContent)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new CertConfirmContent((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }
  
  public CertStatus[] toCertStatusArray()
  {
    CertStatus[] arrayOfCertStatus = new CertStatus[this.content.size()];
    for (int i = 0; i != arrayOfCertStatus.length; i++) {
      arrayOfCertStatus[i] = CertStatus.getInstance(this.content.getObjectAt(i));
    }
    return arrayOfCertStatus;
  }
  
  public DERObject toASN1Object()
  {
    return this.content;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\cmp\CertConfirmContent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */