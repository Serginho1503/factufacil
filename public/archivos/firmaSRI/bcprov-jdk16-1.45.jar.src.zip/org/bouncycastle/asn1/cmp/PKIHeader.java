package org.bouncycastle.asn1.cmp;

import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERGeneralizedTime;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.GeneralName;

public class PKIHeader
  extends ASN1Encodable
{
  private DERInteger pvno;
  private GeneralName sender;
  private GeneralName recipient;
  private DERGeneralizedTime messageTime;
  private AlgorithmIdentifier protectionAlg;
  private ASN1OctetString senderKID;
  private ASN1OctetString recipKID;
  private ASN1OctetString transactionID;
  private ASN1OctetString senderNonce;
  private ASN1OctetString recipNonce;
  private PKIFreeText freeText;
  private ASN1Sequence generalInfo;
  
  private PKIHeader(ASN1Sequence paramASN1Sequence)
  {
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    this.pvno = DERInteger.getInstance(localEnumeration.nextElement());
    this.sender = GeneralName.getInstance(localEnumeration.nextElement());
    this.recipient = GeneralName.getInstance(localEnumeration.nextElement());
    while (localEnumeration.hasMoreElements())
    {
      ASN1TaggedObject localASN1TaggedObject = (ASN1TaggedObject)localEnumeration.nextElement();
      switch (localASN1TaggedObject.getTagNo())
      {
      case 0: 
        this.messageTime = DERGeneralizedTime.getInstance(localASN1TaggedObject, true);
        break;
      case 1: 
        this.protectionAlg = AlgorithmIdentifier.getInstance(localASN1TaggedObject, true);
        break;
      case 2: 
        this.senderKID = ASN1OctetString.getInstance(localASN1TaggedObject, true);
        break;
      case 3: 
        this.recipKID = ASN1OctetString.getInstance(localASN1TaggedObject, true);
        break;
      case 4: 
        this.transactionID = ASN1OctetString.getInstance(localASN1TaggedObject, true);
        break;
      case 5: 
        this.senderNonce = ASN1OctetString.getInstance(localASN1TaggedObject, true);
        break;
      case 6: 
        this.recipNonce = ASN1OctetString.getInstance(localASN1TaggedObject, true);
        break;
      case 7: 
        this.freeText = PKIFreeText.getInstance(localASN1TaggedObject, true);
        break;
      case 8: 
        this.generalInfo = ASN1Sequence.getInstance(localASN1TaggedObject, true);
        break;
      default: 
        throw new IllegalArgumentException("unknown tag number: " + localASN1TaggedObject.getTagNo());
      }
    }
  }
  
  public static PKIHeader getInstance(Object paramObject)
  {
    if ((paramObject instanceof PKIHeader)) {
      return (PKIHeader)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new PKIHeader((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }
  
  public DERInteger getPvno()
  {
    return this.pvno;
  }
  
  public GeneralName getSender()
  {
    return this.sender;
  }
  
  public GeneralName getRecipient()
  {
    return this.recipient;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.pvno);
    localASN1EncodableVector.add(this.sender);
    localASN1EncodableVector.add(this.recipient);
    addOptional(localASN1EncodableVector, 0, this.messageTime);
    addOptional(localASN1EncodableVector, 1, this.protectionAlg);
    addOptional(localASN1EncodableVector, 2, this.senderKID);
    addOptional(localASN1EncodableVector, 3, this.recipKID);
    addOptional(localASN1EncodableVector, 4, this.transactionID);
    addOptional(localASN1EncodableVector, 5, this.senderNonce);
    addOptional(localASN1EncodableVector, 6, this.recipNonce);
    addOptional(localASN1EncodableVector, 7, this.freeText);
    addOptional(localASN1EncodableVector, 8, this.generalInfo);
    return new DERSequence(localASN1EncodableVector);
  }
  
  private void addOptional(ASN1EncodableVector paramASN1EncodableVector, int paramInt, ASN1Encodable paramASN1Encodable)
  {
    if (paramASN1Encodable != null) {
      paramASN1EncodableVector.add(new DERTaggedObject(true, paramInt, paramASN1Encodable));
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\cmp\PKIHeader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */