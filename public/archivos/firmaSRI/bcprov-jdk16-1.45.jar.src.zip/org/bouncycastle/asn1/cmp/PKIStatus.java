package org.bouncycastle.asn1.cmp;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;

public class PKIStatus
  extends ASN1Encodable
{
  public static final int GRANTED = 0;
  public static final int GRANTED_WITH_MODS = 1;
  public static final int REJECTION = 2;
  public static final int WAITING = 3;
  public static final int REVOCATION_WARNING = 4;
  public static final int REVOCATION_NOTIFICATION = 5;
  public static final int KEY_UPDATE_WARNING = 6;
  public static final PKIStatus granted = new PKIStatus(0);
  public static final PKIStatus grantedWithMods = new PKIStatus(1);
  public static final PKIStatus rejection = new PKIStatus(2);
  public static final PKIStatus waiting = new PKIStatus(3);
  public static final PKIStatus revocationWarning = new PKIStatus(4);
  public static final PKIStatus revocationNotification = new PKIStatus(5);
  public static final PKIStatus keyUpdateWaiting = new PKIStatus(6);
  private DERInteger value;
  
  private PKIStatus(int paramInt)
  {
    this(new DERInteger(paramInt));
  }
  
  private PKIStatus(DERInteger paramDERInteger)
  {
    this.value = paramDERInteger;
  }
  
  public static PKIStatus getInstance(Object paramObject)
  {
    if ((paramObject instanceof PKIStatus)) {
      return (PKIStatus)paramObject;
    }
    if ((paramObject instanceof DERInteger)) {
      return new PKIStatus((DERInteger)paramObject);
    }
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }
  
  public DERObject toASN1Object()
  {
    return this.value;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\cmp\PKIStatus.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */