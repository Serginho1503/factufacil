package org.bouncycastle.asn1.cmp;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;

public class CertResponse
  extends ASN1Encodable
{
  private DERInteger certReqId;
  private PKIStatusInfo status;
  private CertifiedKeyPair certifiedKeyPair;
  private ASN1OctetString rspInfo;
  
  private CertResponse(ASN1Sequence paramASN1Sequence)
  {
    this.certReqId = DERInteger.getInstance(paramASN1Sequence.getObjectAt(0));
    this.status = PKIStatusInfo.getInstance(paramASN1Sequence.getObjectAt(1));
    if (paramASN1Sequence.size() >= 3) {
      if (paramASN1Sequence.size() == 3)
      {
        DEREncodable localDEREncodable = paramASN1Sequence.getObjectAt(2);
        if ((localDEREncodable instanceof ASN1OctetString)) {
          this.rspInfo = ASN1OctetString.getInstance(localDEREncodable);
        } else {
          this.certifiedKeyPair = CertifiedKeyPair.getInstance(localDEREncodable);
        }
      }
      else
      {
        this.certifiedKeyPair = CertifiedKeyPair.getInstance(paramASN1Sequence.getObjectAt(2));
        this.rspInfo = ASN1OctetString.getInstance(paramASN1Sequence.getObjectAt(3));
      }
    }
  }
  
  public static CertResponse getInstance(Object paramObject)
  {
    if ((paramObject instanceof CertResponse)) {
      return (CertResponse)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new CertResponse((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }
  
  public DERInteger getCertReqId()
  {
    return this.certReqId;
  }
  
  public PKIStatusInfo getStatus()
  {
    return this.status;
  }
  
  public CertifiedKeyPair getCertifiedKeyPair()
  {
    return this.certifiedKeyPair;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.certReqId);
    localASN1EncodableVector.add(this.status);
    if (this.certifiedKeyPair != null) {
      localASN1EncodableVector.add(this.certifiedKeyPair);
    }
    if (this.rspInfo != null) {
      localASN1EncodableVector.add(this.rspInfo);
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\cmp\CertResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */