package org.bouncycastle.asn1.cmp;

import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERUTF8String;

public class PKIFreeText
  extends ASN1Encodable
{
  ASN1Sequence strings;
  
  public static PKIFreeText getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1Sequence.getInstance(paramASN1TaggedObject, paramBoolean));
  }
  
  public static PKIFreeText getInstance(Object paramObject)
  {
    if ((paramObject instanceof PKIFreeText)) {
      return (PKIFreeText)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new PKIFreeText((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("Unknown object in factory: " + paramObject.getClass().getName());
  }
  
  public PKIFreeText(ASN1Sequence paramASN1Sequence)
  {
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    while (localEnumeration.hasMoreElements()) {
      if (!(localEnumeration.nextElement() instanceof DERUTF8String)) {
        throw new IllegalArgumentException("attempt to insert non UTF8 STRING into PKIFreeText");
      }
    }
    this.strings = paramASN1Sequence;
  }
  
  public PKIFreeText(DERUTF8String paramDERUTF8String)
  {
    this.strings = new DERSequence(paramDERUTF8String);
  }
  
  public int size()
  {
    return this.strings.size();
  }
  
  public DERUTF8String getStringAt(int paramInt)
  {
    return (DERUTF8String)this.strings.getObjectAt(paramInt);
  }
  
  public DERObject toASN1Object()
  {
    return this.strings;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\cmp\PKIFreeText.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */