package org.bouncycastle.asn1.cmp;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;

public class GenMsgContent
  extends ASN1Encodable
{
  private ASN1Sequence content;
  
  private GenMsgContent(ASN1Sequence paramASN1Sequence)
  {
    this.content = paramASN1Sequence;
  }
  
  public static GenMsgContent getInstance(Object paramObject)
  {
    if ((paramObject instanceof GenMsgContent)) {
      return (GenMsgContent)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new GenMsgContent((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }
  
  public InfoTypeAndValue[] toInfoTypeAndValueArray()
  {
    InfoTypeAndValue[] arrayOfInfoTypeAndValue = new InfoTypeAndValue[this.content.size()];
    for (int i = 0; i != arrayOfInfoTypeAndValue.length; i++) {
      arrayOfInfoTypeAndValue[i] = InfoTypeAndValue.getInstance(this.content.getObjectAt(i));
    }
    return arrayOfInfoTypeAndValue;
  }
  
  public DERObject toASN1Object()
  {
    return this.content;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\cmp\GenMsgContent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */