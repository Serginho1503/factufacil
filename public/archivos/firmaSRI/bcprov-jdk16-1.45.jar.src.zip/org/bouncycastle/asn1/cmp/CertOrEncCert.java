package org.bouncycastle.asn1.cmp;

import org.bouncycastle.asn1.ASN1Choice;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.crmf.EncryptedValue;

public class CertOrEncCert
  extends ASN1Encodable
  implements ASN1Choice
{
  private CMPCertificate certificate;
  private EncryptedValue encryptedCert;
  
  private CertOrEncCert(ASN1TaggedObject paramASN1TaggedObject)
  {
    if (paramASN1TaggedObject.getTagNo() == 0) {
      this.certificate = CMPCertificate.getInstance(paramASN1TaggedObject.getObject());
    } else if (paramASN1TaggedObject.getTagNo() == 1) {
      this.encryptedCert = EncryptedValue.getInstance(paramASN1TaggedObject.getObject());
    } else {
      throw new IllegalArgumentException("unknown tag: " + paramASN1TaggedObject.getTagNo());
    }
  }
  
  public static CertOrEncCert getInstance(Object paramObject)
  {
    if ((paramObject instanceof CertOrEncCert)) {
      return (CertOrEncCert)paramObject;
    }
    if ((paramObject instanceof ASN1TaggedObject)) {
      return new CertOrEncCert((ASN1TaggedObject)paramObject);
    }
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }
  
  public CMPCertificate getCertificate()
  {
    return this.certificate;
  }
  
  public EncryptedValue getEncryptedCert()
  {
    return this.encryptedCert;
  }
  
  public DERObject toASN1Object()
  {
    if (this.certificate != null) {
      return new DERTaggedObject(true, 0, this.certificate);
    }
    return new DERTaggedObject(true, 1, this.encryptedCert);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\cmp\CertOrEncCert.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */