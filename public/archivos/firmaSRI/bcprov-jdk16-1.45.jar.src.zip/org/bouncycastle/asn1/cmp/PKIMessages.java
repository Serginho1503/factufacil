package org.bouncycastle.asn1.cmp;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;

public class PKIMessages
  extends ASN1Encodable
{
  private ASN1Sequence content;
  
  private PKIMessages(ASN1Sequence paramASN1Sequence)
  {
    this.content = paramASN1Sequence;
  }
  
  public static PKIMessages getInstance(Object paramObject)
  {
    if ((paramObject instanceof PKIMessages)) {
      return (PKIMessages)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new PKIMessages((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }
  
  public PKIMessage[] toPKIMessageArray()
  {
    PKIMessage[] arrayOfPKIMessage = new PKIMessage[this.content.size()];
    for (int i = 0; i != arrayOfPKIMessage.length; i++) {
      arrayOfPKIMessage[i] = PKIMessage.getInstance(this.content.getObjectAt(i));
    }
    return arrayOfPKIMessage;
  }
  
  public DERObject toASN1Object()
  {
    return this.content;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\cmp\PKIMessages.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */