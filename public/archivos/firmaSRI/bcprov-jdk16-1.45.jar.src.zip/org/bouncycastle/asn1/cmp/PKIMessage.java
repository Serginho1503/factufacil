package org.bouncycastle.asn1.cmp;

import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;

public class PKIMessage
  extends ASN1Encodable
{
  private PKIHeader header;
  private PKIBody body;
  private DERBitString protection;
  private ASN1Sequence extraCerts;
  
  private PKIMessage(ASN1Sequence paramASN1Sequence)
  {
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    this.header = PKIHeader.getInstance(localEnumeration.nextElement());
    this.body = PKIBody.getInstance(localEnumeration.nextElement());
    while (localEnumeration.hasMoreElements())
    {
      ASN1TaggedObject localASN1TaggedObject = (ASN1TaggedObject)localEnumeration.nextElement();
      if (localASN1TaggedObject.getTagNo() == 0) {
        this.protection = DERBitString.getInstance(localASN1TaggedObject, true);
      } else {
        this.extraCerts = ASN1Sequence.getInstance(localASN1TaggedObject, true);
      }
    }
  }
  
  public static PKIMessage getInstance(Object paramObject)
  {
    if ((paramObject instanceof PKIMessage)) {
      return (PKIMessage)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new PKIMessage((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }
  
  public PKIHeader getHeader()
  {
    return this.header;
  }
  
  public PKIBody getBody()
  {
    return this.body;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.header);
    localASN1EncodableVector.add(this.body);
    addOptional(localASN1EncodableVector, 0, this.protection);
    addOptional(localASN1EncodableVector, 1, this.extraCerts);
    return new DERSequence(localASN1EncodableVector);
  }
  
  private void addOptional(ASN1EncodableVector paramASN1EncodableVector, int paramInt, ASN1Encodable paramASN1Encodable)
  {
    if (paramASN1Encodable != null) {
      paramASN1EncodableVector.add(new DERTaggedObject(true, paramInt, paramASN1Encodable));
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\cmp\PKIMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */