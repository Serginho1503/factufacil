package org.bouncycastle.asn1.ess;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.x509.PolicyInformation;

public class SigningCertificateV2
  extends ASN1Encodable
{
  ASN1Sequence certs;
  ASN1Sequence policies;
  
  public static SigningCertificateV2 getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof SigningCertificateV2))) {
      return (SigningCertificateV2)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new SigningCertificateV2((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in 'SigningCertificateV2' factory : " + paramObject.getClass().getName() + ".");
  }
  
  public SigningCertificateV2(ASN1Sequence paramASN1Sequence)
  {
    if ((paramASN1Sequence.size() < 1) || (paramASN1Sequence.size() > 2)) {
      throw new IllegalArgumentException("Bad sequence size: " + paramASN1Sequence.size());
    }
    this.certs = ASN1Sequence.getInstance(paramASN1Sequence.getObjectAt(0));
    if (paramASN1Sequence.size() > 1) {
      this.policies = ASN1Sequence.getInstance(paramASN1Sequence.getObjectAt(1));
    }
  }
  
  public SigningCertificateV2(ESSCertIDv2[] paramArrayOfESSCertIDv2)
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    for (int i = 0; i < paramArrayOfESSCertIDv2.length; i++) {
      localASN1EncodableVector.add(paramArrayOfESSCertIDv2[i]);
    }
    this.certs = new DERSequence(localASN1EncodableVector);
  }
  
  public SigningCertificateV2(ESSCertIDv2[] paramArrayOfESSCertIDv2, PolicyInformation[] paramArrayOfPolicyInformation)
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    for (int i = 0; i < paramArrayOfESSCertIDv2.length; i++) {
      localASN1EncodableVector.add(paramArrayOfESSCertIDv2[i]);
    }
    this.certs = new DERSequence(localASN1EncodableVector);
    if (paramArrayOfPolicyInformation != null)
    {
      localASN1EncodableVector = new ASN1EncodableVector();
      for (i = 0; i < paramArrayOfPolicyInformation.length; i++) {
        localASN1EncodableVector.add(paramArrayOfPolicyInformation[i]);
      }
      this.policies = new DERSequence(localASN1EncodableVector);
    }
  }
  
  public ESSCertIDv2[] getCerts()
  {
    ESSCertIDv2[] arrayOfESSCertIDv2 = new ESSCertIDv2[this.certs.size()];
    for (int i = 0; i != this.certs.size(); i++) {
      arrayOfESSCertIDv2[i] = ESSCertIDv2.getInstance(this.certs.getObjectAt(i));
    }
    return arrayOfESSCertIDv2;
  }
  
  public PolicyInformation[] getPolicies()
  {
    if (this.policies == null) {
      return null;
    }
    PolicyInformation[] arrayOfPolicyInformation = new PolicyInformation[this.policies.size()];
    for (int i = 0; i != this.policies.size(); i++) {
      arrayOfPolicyInformation[i] = PolicyInformation.getInstance(this.policies.getObjectAt(i));
    }
    return arrayOfPolicyInformation;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.certs);
    if (this.policies != null) {
      localASN1EncodableVector.add(this.policies);
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\ess\SigningCertificateV2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */