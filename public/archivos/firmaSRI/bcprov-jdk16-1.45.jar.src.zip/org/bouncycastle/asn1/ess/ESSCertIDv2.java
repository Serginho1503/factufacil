package org.bouncycastle.asn1.ess;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.nist.NISTObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.IssuerSerial;

public class ESSCertIDv2
  extends ASN1Encodable
{
  private AlgorithmIdentifier hashAlgorithm;
  private byte[] certHash;
  private IssuerSerial issuerSerial;
  private static final AlgorithmIdentifier DEFAULT_ALG_ID = new AlgorithmIdentifier(NISTObjectIdentifiers.id_sha256);
  
  public static ESSCertIDv2 getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof ESSCertIDv2))) {
      return (ESSCertIDv2)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new ESSCertIDv2((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in 'ESSCertIDv2' factory : " + paramObject.getClass().getName() + ".");
  }
  
  public ESSCertIDv2(ASN1Sequence paramASN1Sequence)
  {
    if ((paramASN1Sequence.size() != 2) && (paramASN1Sequence.size() != 3)) {
      throw new IllegalArgumentException("Bad sequence size: " + paramASN1Sequence.size());
    }
    int i = 0;
    if ((paramASN1Sequence.getObjectAt(0) instanceof ASN1OctetString)) {
      this.hashAlgorithm = DEFAULT_ALG_ID;
    } else {
      this.hashAlgorithm = AlgorithmIdentifier.getInstance(paramASN1Sequence.getObjectAt(i++).getDERObject());
    }
    this.certHash = ASN1OctetString.getInstance(paramASN1Sequence.getObjectAt(i++).getDERObject()).getOctets();
    if (paramASN1Sequence.size() > i) {
      this.issuerSerial = new IssuerSerial(ASN1Sequence.getInstance(paramASN1Sequence.getObjectAt(i).getDERObject()));
    }
  }
  
  public ESSCertIDv2(AlgorithmIdentifier paramAlgorithmIdentifier, byte[] paramArrayOfByte)
  {
    this(paramAlgorithmIdentifier, paramArrayOfByte, null);
  }
  
  public ESSCertIDv2(AlgorithmIdentifier paramAlgorithmIdentifier, byte[] paramArrayOfByte, IssuerSerial paramIssuerSerial)
  {
    if (paramAlgorithmIdentifier == null) {
      this.hashAlgorithm = DEFAULT_ALG_ID;
    } else {
      this.hashAlgorithm = paramAlgorithmIdentifier;
    }
    this.certHash = paramArrayOfByte;
    this.issuerSerial = paramIssuerSerial;
  }
  
  public AlgorithmIdentifier getHashAlgorithm()
  {
    return this.hashAlgorithm;
  }
  
  public byte[] getCertHash()
  {
    return this.certHash;
  }
  
  public IssuerSerial getIssuerSerial()
  {
    return this.issuerSerial;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    if (!this.hashAlgorithm.equals(DEFAULT_ALG_ID)) {
      localASN1EncodableVector.add(this.hashAlgorithm);
    }
    localASN1EncodableVector.add(new DEROctetString(this.certHash).toASN1Object());
    if (this.issuerSerial != null) {
      localASN1EncodableVector.add(this.issuerSerial);
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\ess\ESSCertIDv2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */