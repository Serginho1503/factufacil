package org.bouncycastle.asn1.ess;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.x509.IssuerSerial;

public class ESSCertID
  extends ASN1Encodable
{
  private ASN1OctetString certHash;
  private IssuerSerial issuerSerial;
  
  public static ESSCertID getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof ESSCertID))) {
      return (ESSCertID)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new ESSCertID((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in 'ESSCertID' factory : " + paramObject.getClass().getName() + ".");
  }
  
  public ESSCertID(ASN1Sequence paramASN1Sequence)
  {
    if ((paramASN1Sequence.size() < 1) || (paramASN1Sequence.size() > 2)) {
      throw new IllegalArgumentException("Bad sequence size: " + paramASN1Sequence.size());
    }
    this.certHash = ASN1OctetString.getInstance(paramASN1Sequence.getObjectAt(0));
    if (paramASN1Sequence.size() > 1) {
      this.issuerSerial = IssuerSerial.getInstance(paramASN1Sequence.getObjectAt(1));
    }
  }
  
  public ESSCertID(byte[] paramArrayOfByte)
  {
    this.certHash = new DEROctetString(paramArrayOfByte);
  }
  
  public ESSCertID(byte[] paramArrayOfByte, IssuerSerial paramIssuerSerial)
  {
    this.certHash = new DEROctetString(paramArrayOfByte);
    this.issuerSerial = paramIssuerSerial;
  }
  
  public byte[] getCertHash()
  {
    return this.certHash.getOctets();
  }
  
  public IssuerSerial getIssuerSerial()
  {
    return this.issuerSerial;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.certHash);
    if (this.issuerSerial != null) {
      localASN1EncodableVector.add(this.issuerSerial);
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\ess\ESSCertID.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */