package org.bouncycastle.asn1.isismtt.x509;

import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERPrintableString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.x500.DirectoryString;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.IssuerSerial;

public class ProcurationSyntax
  extends ASN1Encodable
{
  private String country;
  private DirectoryString typeOfSubstitution;
  private GeneralName thirdPerson;
  private IssuerSerial certRef;
  
  public static ProcurationSyntax getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof ProcurationSyntax))) {
      return (ProcurationSyntax)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new ProcurationSyntax((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("illegal object in getInstance: " + paramObject.getClass().getName());
  }
  
  private ProcurationSyntax(ASN1Sequence paramASN1Sequence)
  {
    if ((paramASN1Sequence.size() < 1) || (paramASN1Sequence.size() > 3)) {
      throw new IllegalArgumentException("Bad sequence size: " + paramASN1Sequence.size());
    }
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    while (localEnumeration.hasMoreElements())
    {
      ASN1TaggedObject localASN1TaggedObject = ASN1TaggedObject.getInstance(localEnumeration.nextElement());
      switch (localASN1TaggedObject.getTagNo())
      {
      case 1: 
        this.country = DERPrintableString.getInstance(localASN1TaggedObject, true).getString();
        break;
      case 2: 
        this.typeOfSubstitution = DirectoryString.getInstance(localASN1TaggedObject, true);
        break;
      case 3: 
        DERObject localDERObject = localASN1TaggedObject.getObject();
        if ((localDERObject instanceof ASN1TaggedObject)) {
          this.thirdPerson = GeneralName.getInstance(localDERObject);
        } else {
          this.certRef = IssuerSerial.getInstance(localDERObject);
        }
        break;
      default: 
        throw new IllegalArgumentException("Bad tag number: " + localASN1TaggedObject.getTagNo());
      }
    }
  }
  
  public ProcurationSyntax(String paramString, DirectoryString paramDirectoryString, IssuerSerial paramIssuerSerial)
  {
    this.country = paramString;
    this.typeOfSubstitution = paramDirectoryString;
    this.thirdPerson = null;
    this.certRef = paramIssuerSerial;
  }
  
  public ProcurationSyntax(String paramString, DirectoryString paramDirectoryString, GeneralName paramGeneralName)
  {
    this.country = paramString;
    this.typeOfSubstitution = paramDirectoryString;
    this.thirdPerson = paramGeneralName;
    this.certRef = null;
  }
  
  public String getCountry()
  {
    return this.country;
  }
  
  public DirectoryString getTypeOfSubstitution()
  {
    return this.typeOfSubstitution;
  }
  
  public GeneralName getThirdPerson()
  {
    return this.thirdPerson;
  }
  
  public IssuerSerial getCertRef()
  {
    return this.certRef;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    if (this.country != null) {
      localASN1EncodableVector.add(new DERTaggedObject(true, 1, new DERPrintableString(this.country, true)));
    }
    if (this.typeOfSubstitution != null) {
      localASN1EncodableVector.add(new DERTaggedObject(true, 2, this.typeOfSubstitution));
    }
    if (this.thirdPerson != null) {
      localASN1EncodableVector.add(new DERTaggedObject(true, 3, this.thirdPerson));
    } else {
      localASN1EncodableVector.add(new DERTaggedObject(true, 3, this.certRef));
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\isismtt\x509\ProcurationSyntax.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */