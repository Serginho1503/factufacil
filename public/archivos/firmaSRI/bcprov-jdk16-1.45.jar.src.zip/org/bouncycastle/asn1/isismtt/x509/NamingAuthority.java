package org.bouncycastle.asn1.isismtt.x509;

import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERIA5String;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERString;
import org.bouncycastle.asn1.isismtt.ISISMTTObjectIdentifiers;
import org.bouncycastle.asn1.x500.DirectoryString;

public class NamingAuthority
  extends ASN1Encodable
{
  public static final DERObjectIdentifier id_isismtt_at_namingAuthorities_RechtWirtschaftSteuern = new DERObjectIdentifier(ISISMTTObjectIdentifiers.id_isismtt_at_namingAuthorities + ".1");
  private DERObjectIdentifier namingAuthorityId;
  private String namingAuthorityUrl;
  private DirectoryString namingAuthorityText;
  
  public static NamingAuthority getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof NamingAuthority))) {
      return (NamingAuthority)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new NamingAuthority((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("illegal object in getInstance: " + paramObject.getClass().getName());
  }
  
  public static NamingAuthority getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1Sequence.getInstance(paramASN1TaggedObject, paramBoolean));
  }
  
  private NamingAuthority(ASN1Sequence paramASN1Sequence)
  {
    if (paramASN1Sequence.size() > 3) {
      throw new IllegalArgumentException("Bad sequence size: " + paramASN1Sequence.size());
    }
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    DEREncodable localDEREncodable;
    if (localEnumeration.hasMoreElements())
    {
      localDEREncodable = (DEREncodable)localEnumeration.nextElement();
      if ((localDEREncodable instanceof DERObjectIdentifier)) {
        this.namingAuthorityId = ((DERObjectIdentifier)localDEREncodable);
      } else if ((localDEREncodable instanceof DERIA5String)) {
        this.namingAuthorityUrl = DERIA5String.getInstance(localDEREncodable).getString();
      } else if ((localDEREncodable instanceof DERString)) {
        this.namingAuthorityText = DirectoryString.getInstance(localDEREncodable);
      } else {
        throw new IllegalArgumentException("Bad object encountered: " + localDEREncodable.getClass());
      }
    }
    if (localEnumeration.hasMoreElements())
    {
      localDEREncodable = (DEREncodable)localEnumeration.nextElement();
      if ((localDEREncodable instanceof DERIA5String)) {
        this.namingAuthorityUrl = DERIA5String.getInstance(localDEREncodable).getString();
      } else if ((localDEREncodable instanceof DERString)) {
        this.namingAuthorityText = DirectoryString.getInstance(localDEREncodable);
      } else {
        throw new IllegalArgumentException("Bad object encountered: " + localDEREncodable.getClass());
      }
    }
    if (localEnumeration.hasMoreElements())
    {
      localDEREncodable = (DEREncodable)localEnumeration.nextElement();
      if ((localDEREncodable instanceof DERString)) {
        this.namingAuthorityText = DirectoryString.getInstance(localDEREncodable);
      } else {
        throw new IllegalArgumentException("Bad object encountered: " + localDEREncodable.getClass());
      }
    }
  }
  
  public DERObjectIdentifier getNamingAuthorityId()
  {
    return this.namingAuthorityId;
  }
  
  public DirectoryString getNamingAuthorityText()
  {
    return this.namingAuthorityText;
  }
  
  public String getNamingAuthorityUrl()
  {
    return this.namingAuthorityUrl;
  }
  
  public NamingAuthority(DERObjectIdentifier paramDERObjectIdentifier, String paramString, DirectoryString paramDirectoryString)
  {
    this.namingAuthorityId = paramDERObjectIdentifier;
    this.namingAuthorityUrl = paramString;
    this.namingAuthorityText = paramDirectoryString;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    if (this.namingAuthorityId != null) {
      localASN1EncodableVector.add(this.namingAuthorityId);
    }
    if (this.namingAuthorityUrl != null) {
      localASN1EncodableVector.add(new DERIA5String(this.namingAuthorityUrl, true));
    }
    if (this.namingAuthorityText != null) {
      localASN1EncodableVector.add(this.namingAuthorityText);
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\isismtt\x509\NamingAuthority.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */