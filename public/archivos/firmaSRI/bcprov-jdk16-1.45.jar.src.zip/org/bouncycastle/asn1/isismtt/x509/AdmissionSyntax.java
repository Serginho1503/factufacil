package org.bouncycastle.asn1.isismtt.x509;

import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.x509.GeneralName;

public class AdmissionSyntax
  extends ASN1Encodable
{
  private GeneralName admissionAuthority;
  private ASN1Sequence contentsOfAdmissions;
  
  public static AdmissionSyntax getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof AdmissionSyntax))) {
      return (AdmissionSyntax)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new AdmissionSyntax((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("illegal object in getInstance: " + paramObject.getClass().getName());
  }
  
  private AdmissionSyntax(ASN1Sequence paramASN1Sequence)
  {
    switch (paramASN1Sequence.size())
    {
    case 1: 
      this.contentsOfAdmissions = DERSequence.getInstance(paramASN1Sequence.getObjectAt(0));
      break;
    case 2: 
      this.admissionAuthority = GeneralName.getInstance(paramASN1Sequence.getObjectAt(0));
      this.contentsOfAdmissions = DERSequence.getInstance(paramASN1Sequence.getObjectAt(1));
      break;
    default: 
      throw new IllegalArgumentException("Bad sequence size: " + paramASN1Sequence.size());
    }
  }
  
  public AdmissionSyntax(GeneralName paramGeneralName, ASN1Sequence paramASN1Sequence)
  {
    this.admissionAuthority = paramGeneralName;
    this.contentsOfAdmissions = paramASN1Sequence;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    if (this.admissionAuthority != null) {
      localASN1EncodableVector.add(this.admissionAuthority);
    }
    localASN1EncodableVector.add(this.contentsOfAdmissions);
    return new DERSequence(localASN1EncodableVector);
  }
  
  public GeneralName getAdmissionAuthority()
  {
    return this.admissionAuthority;
  }
  
  public Admissions[] getContentsOfAdmissions()
  {
    Admissions[] arrayOfAdmissions = new Admissions[this.contentsOfAdmissions.size()];
    int i = 0;
    Enumeration localEnumeration = this.contentsOfAdmissions.getObjects();
    while (localEnumeration.hasMoreElements()) {
      arrayOfAdmissions[(i++)] = Admissions.getInstance(localEnumeration.nextElement());
    }
    return arrayOfAdmissions;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\isismtt\x509\AdmissionSyntax.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */