package org.bouncycastle.asn1.isismtt.ocsp;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1Choice;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.x509.X509CertificateStructure;

public class RequestedCertificate
  extends ASN1Encodable
  implements ASN1Choice
{
  public static final int certificate = -1;
  public static final int publicKeyCertificate = 0;
  public static final int attributeCertificate = 1;
  private X509CertificateStructure cert;
  private byte[] publicKeyCert;
  private byte[] attributeCert;
  
  public static RequestedCertificate getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof RequestedCertificate))) {
      return (RequestedCertificate)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new RequestedCertificate(X509CertificateStructure.getInstance(paramObject));
    }
    if ((paramObject instanceof ASN1TaggedObject)) {
      return new RequestedCertificate((ASN1TaggedObject)paramObject);
    }
    throw new IllegalArgumentException("illegal object in getInstance: " + paramObject.getClass().getName());
  }
  
  public static RequestedCertificate getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    if (!paramBoolean) {
      throw new IllegalArgumentException("choice item must be explicitly tagged");
    }
    return getInstance(paramASN1TaggedObject.getObject());
  }
  
  private RequestedCertificate(ASN1TaggedObject paramASN1TaggedObject)
  {
    if (paramASN1TaggedObject.getTagNo() == 0) {
      this.publicKeyCert = ASN1OctetString.getInstance(paramASN1TaggedObject, true).getOctets();
    } else if (paramASN1TaggedObject.getTagNo() == 1) {
      this.attributeCert = ASN1OctetString.getInstance(paramASN1TaggedObject, true).getOctets();
    } else {
      throw new IllegalArgumentException("unknown tag number: " + paramASN1TaggedObject.getTagNo());
    }
  }
  
  public RequestedCertificate(X509CertificateStructure paramX509CertificateStructure)
  {
    this.cert = paramX509CertificateStructure;
  }
  
  public RequestedCertificate(int paramInt, byte[] paramArrayOfByte)
  {
    this(new DERTaggedObject(paramInt, new DEROctetString(paramArrayOfByte)));
  }
  
  public int getType()
  {
    if (this.cert != null) {
      return -1;
    }
    if (this.publicKeyCert != null) {
      return 0;
    }
    return 1;
  }
  
  public byte[] getCertificateBytes()
  {
    if (this.cert != null) {
      try
      {
        return this.cert.getEncoded();
      }
      catch (IOException localIOException)
      {
        throw new IllegalStateException("can't decode certificate: " + localIOException);
      }
    }
    if (this.publicKeyCert != null) {
      return this.publicKeyCert;
    }
    return this.attributeCert;
  }
  
  public DERObject toASN1Object()
  {
    if (this.publicKeyCert != null) {
      return new DERTaggedObject(0, new DEROctetString(this.publicKeyCert));
    }
    if (this.attributeCert != null) {
      return new DERTaggedObject(1, new DEROctetString(this.attributeCert));
    }
    return this.cert.getDERObject();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\isismtt\ocsp\RequestedCertificate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */