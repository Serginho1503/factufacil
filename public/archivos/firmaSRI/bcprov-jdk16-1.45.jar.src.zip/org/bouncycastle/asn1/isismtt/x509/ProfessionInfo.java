package org.bouncycastle.asn1.isismtt.x509;

import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERPrintableString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.x500.DirectoryString;

public class ProfessionInfo
  extends ASN1Encodable
{
  public static final DERObjectIdentifier Rechtsanwltin = new DERObjectIdentifier(NamingAuthority.id_isismtt_at_namingAuthorities_RechtWirtschaftSteuern + ".1");
  public static final DERObjectIdentifier Rechtsanwalt = new DERObjectIdentifier(NamingAuthority.id_isismtt_at_namingAuthorities_RechtWirtschaftSteuern + ".2");
  public static final DERObjectIdentifier Rechtsbeistand = new DERObjectIdentifier(NamingAuthority.id_isismtt_at_namingAuthorities_RechtWirtschaftSteuern + ".3");
  public static final DERObjectIdentifier Steuerberaterin = new DERObjectIdentifier(NamingAuthority.id_isismtt_at_namingAuthorities_RechtWirtschaftSteuern + ".4");
  public static final DERObjectIdentifier Steuerberater = new DERObjectIdentifier(NamingAuthority.id_isismtt_at_namingAuthorities_RechtWirtschaftSteuern + ".5");
  public static final DERObjectIdentifier Steuerbevollmchtigte = new DERObjectIdentifier(NamingAuthority.id_isismtt_at_namingAuthorities_RechtWirtschaftSteuern + ".6");
  public static final DERObjectIdentifier Steuerbevollmchtigter = new DERObjectIdentifier(NamingAuthority.id_isismtt_at_namingAuthorities_RechtWirtschaftSteuern + ".7");
  public static final DERObjectIdentifier Notarin = new DERObjectIdentifier(NamingAuthority.id_isismtt_at_namingAuthorities_RechtWirtschaftSteuern + ".8");
  public static final DERObjectIdentifier Notar = new DERObjectIdentifier(NamingAuthority.id_isismtt_at_namingAuthorities_RechtWirtschaftSteuern + ".9");
  public static final DERObjectIdentifier Notarvertreterin = new DERObjectIdentifier(NamingAuthority.id_isismtt_at_namingAuthorities_RechtWirtschaftSteuern + ".10");
  public static final DERObjectIdentifier Notarvertreter = new DERObjectIdentifier(NamingAuthority.id_isismtt_at_namingAuthorities_RechtWirtschaftSteuern + ".11");
  public static final DERObjectIdentifier Notariatsverwalterin = new DERObjectIdentifier(NamingAuthority.id_isismtt_at_namingAuthorities_RechtWirtschaftSteuern + ".12");
  public static final DERObjectIdentifier Notariatsverwalter = new DERObjectIdentifier(NamingAuthority.id_isismtt_at_namingAuthorities_RechtWirtschaftSteuern + ".13");
  public static final DERObjectIdentifier Wirtschaftsprferin = new DERObjectIdentifier(NamingAuthority.id_isismtt_at_namingAuthorities_RechtWirtschaftSteuern + ".14");
  public static final DERObjectIdentifier Wirtschaftsprfer = new DERObjectIdentifier(NamingAuthority.id_isismtt_at_namingAuthorities_RechtWirtschaftSteuern + ".15");
  public static final DERObjectIdentifier VereidigteBuchprferin = new DERObjectIdentifier(NamingAuthority.id_isismtt_at_namingAuthorities_RechtWirtschaftSteuern + ".16");
  public static final DERObjectIdentifier VereidigterBuchprfer = new DERObjectIdentifier(NamingAuthority.id_isismtt_at_namingAuthorities_RechtWirtschaftSteuern + ".17");
  public static final DERObjectIdentifier Patentanwltin = new DERObjectIdentifier(NamingAuthority.id_isismtt_at_namingAuthorities_RechtWirtschaftSteuern + ".18");
  public static final DERObjectIdentifier Patentanwalt = new DERObjectIdentifier(NamingAuthority.id_isismtt_at_namingAuthorities_RechtWirtschaftSteuern + ".19");
  private NamingAuthority namingAuthority;
  private ASN1Sequence professionItems;
  private ASN1Sequence professionOIDs;
  private String registrationNumber;
  private ASN1OctetString addProfessionInfo;
  
  public static ProfessionInfo getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof ProfessionInfo))) {
      return (ProfessionInfo)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new ProfessionInfo((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("illegal object in getInstance: " + paramObject.getClass().getName());
  }
  
  private ProfessionInfo(ASN1Sequence paramASN1Sequence)
  {
    if (paramASN1Sequence.size() > 5) {
      throw new IllegalArgumentException("Bad sequence size: " + paramASN1Sequence.size());
    }
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    DEREncodable localDEREncodable = (DEREncodable)localEnumeration.nextElement();
    if ((localDEREncodable instanceof ASN1TaggedObject))
    {
      if (((ASN1TaggedObject)localDEREncodable).getTagNo() != 0) {
        throw new IllegalArgumentException("Bad tag number: " + ((ASN1TaggedObject)localDEREncodable).getTagNo());
      }
      this.namingAuthority = NamingAuthority.getInstance((ASN1TaggedObject)localDEREncodable, true);
      localDEREncodable = (DEREncodable)localEnumeration.nextElement();
    }
    this.professionItems = ASN1Sequence.getInstance(localDEREncodable);
    if (localEnumeration.hasMoreElements())
    {
      localDEREncodable = (DEREncodable)localEnumeration.nextElement();
      if ((localDEREncodable instanceof ASN1Sequence)) {
        this.professionOIDs = ASN1Sequence.getInstance(localDEREncodable);
      } else if ((localDEREncodable instanceof DERPrintableString)) {
        this.registrationNumber = DERPrintableString.getInstance(localDEREncodable).getString();
      } else if ((localDEREncodable instanceof ASN1OctetString)) {
        this.addProfessionInfo = ASN1OctetString.getInstance(localDEREncodable);
      } else {
        throw new IllegalArgumentException("Bad object encountered: " + localDEREncodable.getClass());
      }
    }
    if (localEnumeration.hasMoreElements())
    {
      localDEREncodable = (DEREncodable)localEnumeration.nextElement();
      if ((localDEREncodable instanceof DERPrintableString)) {
        this.registrationNumber = DERPrintableString.getInstance(localDEREncodable).getString();
      } else if ((localDEREncodable instanceof DEROctetString)) {
        this.addProfessionInfo = ((DEROctetString)localDEREncodable);
      } else {
        throw new IllegalArgumentException("Bad object encountered: " + localDEREncodable.getClass());
      }
    }
    if (localEnumeration.hasMoreElements())
    {
      localDEREncodable = (DEREncodable)localEnumeration.nextElement();
      if ((localDEREncodable instanceof DEROctetString)) {
        this.addProfessionInfo = ((DEROctetString)localDEREncodable);
      } else {
        throw new IllegalArgumentException("Bad object encountered: " + localDEREncodable.getClass());
      }
    }
  }
  
  public ProfessionInfo(NamingAuthority paramNamingAuthority, DirectoryString[] paramArrayOfDirectoryString, DERObjectIdentifier[] paramArrayOfDERObjectIdentifier, String paramString, ASN1OctetString paramASN1OctetString)
  {
    this.namingAuthority = paramNamingAuthority;
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    for (int i = 0; i != paramArrayOfDirectoryString.length; i++) {
      localASN1EncodableVector.add(paramArrayOfDirectoryString[i]);
    }
    this.professionItems = new DERSequence(localASN1EncodableVector);
    if (paramArrayOfDERObjectIdentifier != null)
    {
      localASN1EncodableVector = new ASN1EncodableVector();
      for (i = 0; i != paramArrayOfDERObjectIdentifier.length; i++) {
        localASN1EncodableVector.add(paramArrayOfDERObjectIdentifier[i]);
      }
      this.professionOIDs = new DERSequence(localASN1EncodableVector);
    }
    this.registrationNumber = paramString;
    this.addProfessionInfo = paramASN1OctetString;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    if (this.namingAuthority != null) {
      localASN1EncodableVector.add(new DERTaggedObject(true, 0, this.namingAuthority));
    }
    localASN1EncodableVector.add(this.professionItems);
    if (this.professionOIDs != null) {
      localASN1EncodableVector.add(this.professionOIDs);
    }
    if (this.registrationNumber != null) {
      localASN1EncodableVector.add(new DERPrintableString(this.registrationNumber, true));
    }
    if (this.addProfessionInfo != null) {
      localASN1EncodableVector.add(this.addProfessionInfo);
    }
    return new DERSequence(localASN1EncodableVector);
  }
  
  public ASN1OctetString getAddProfessionInfo()
  {
    return this.addProfessionInfo;
  }
  
  public NamingAuthority getNamingAuthority()
  {
    return this.namingAuthority;
  }
  
  public DirectoryString[] getProfessionItems()
  {
    DirectoryString[] arrayOfDirectoryString = new DirectoryString[this.professionItems.size()];
    int i = 0;
    Enumeration localEnumeration = this.professionItems.getObjects();
    while (localEnumeration.hasMoreElements()) {
      arrayOfDirectoryString[(i++)] = DirectoryString.getInstance(localEnumeration.nextElement());
    }
    return arrayOfDirectoryString;
  }
  
  public DERObjectIdentifier[] getProfessionOIDs()
  {
    if (this.professionOIDs == null) {
      return new DERObjectIdentifier[0];
    }
    DERObjectIdentifier[] arrayOfDERObjectIdentifier = new DERObjectIdentifier[this.professionOIDs.size()];
    int i = 0;
    Enumeration localEnumeration = this.professionOIDs.getObjects();
    while (localEnumeration.hasMoreElements()) {
      arrayOfDERObjectIdentifier[(i++)] = DERObjectIdentifier.getInstance(localEnumeration.nextElement());
    }
    return arrayOfDERObjectIdentifier;
  }
  
  public String getRegistrationNumber()
  {
    return this.registrationNumber;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\isismtt\x509\ProfessionInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */