package org.bouncycastle.asn1.crmf;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.x509.GeneralName;

public class SinglePubInfo
  extends ASN1Encodable
{
  private DERInteger pubMethod;
  private GeneralName pubLocation;
  
  private SinglePubInfo(ASN1Sequence paramASN1Sequence)
  {
    this.pubMethod = DERInteger.getInstance(paramASN1Sequence.getObjectAt(0));
    if (paramASN1Sequence.size() == 2) {
      this.pubLocation = GeneralName.getInstance(paramASN1Sequence.getObjectAt(1));
    }
  }
  
  public static SinglePubInfo getInstance(Object paramObject)
  {
    if ((paramObject instanceof SinglePubInfo)) {
      return (SinglePubInfo)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new SinglePubInfo((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }
  
  public GeneralName getPubLocation()
  {
    return this.pubLocation;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.pubMethod);
    if (this.pubLocation != null) {
      localASN1EncodableVector.add(this.pubLocation);
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\crmf\SinglePubInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */