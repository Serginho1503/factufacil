package org.bouncycastle.asn1.crmf;

import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;

public class CertReqMsg
  extends ASN1Encodable
{
  private CertRequest certReq;
  private ProofOfPossession pop;
  private ASN1Sequence regInfo;
  
  private CertReqMsg(ASN1Sequence paramASN1Sequence)
  {
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    this.certReq = CertRequest.getInstance(localEnumeration.nextElement());
    while (localEnumeration.hasMoreElements())
    {
      Object localObject = localEnumeration.nextElement();
      if ((localObject instanceof ASN1TaggedObject)) {
        this.pop = ProofOfPossession.getInstance(localObject);
      } else {
        this.regInfo = ASN1Sequence.getInstance(localObject);
      }
    }
  }
  
  public static CertReqMsg getInstance(Object paramObject)
  {
    if ((paramObject instanceof CertReqMsg)) {
      return (CertReqMsg)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new CertReqMsg((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }
  
  public CertRequest getCertReq()
  {
    return this.certReq;
  }
  
  public ProofOfPossession getPop()
  {
    return this.pop;
  }
  
  public AttributeTypeAndValue[] getRegInfo()
  {
    if (this.regInfo == null) {
      return null;
    }
    AttributeTypeAndValue[] arrayOfAttributeTypeAndValue = new AttributeTypeAndValue[this.regInfo.size()];
    for (int i = 0; i != arrayOfAttributeTypeAndValue.length; i++) {
      arrayOfAttributeTypeAndValue[i] = AttributeTypeAndValue.getInstance(this.regInfo.getObjectAt(i));
    }
    return arrayOfAttributeTypeAndValue;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.certReq);
    addOptional(localASN1EncodableVector, this.pop);
    addOptional(localASN1EncodableVector, this.regInfo);
    return new DERSequence(localASN1EncodableVector);
  }
  
  private void addOptional(ASN1EncodableVector paramASN1EncodableVector, ASN1Encodable paramASN1Encodable)
  {
    if (paramASN1Encodable != null) {
      paramASN1EncodableVector.add(paramASN1Encodable);
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\crmf\CertReqMsg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */