package org.bouncycastle.asn1.crmf;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class EncryptedValue
  extends ASN1Encodable
{
  private AlgorithmIdentifier intendedAlg;
  private AlgorithmIdentifier symmAlg;
  private DERBitString encSymmKey;
  private AlgorithmIdentifier keyAlg;
  private ASN1OctetString valueHint;
  private DERBitString encValue;
  
  private EncryptedValue(ASN1Sequence paramASN1Sequence)
  {
    for (int i = 0; (paramASN1Sequence.getObjectAt(i) instanceof ASN1TaggedObject); i++)
    {
      ASN1TaggedObject localASN1TaggedObject = (ASN1TaggedObject)paramASN1Sequence.getObjectAt(i);
      switch (localASN1TaggedObject.getTagNo())
      {
      case 0: 
        this.intendedAlg = AlgorithmIdentifier.getInstance(localASN1TaggedObject, false);
        break;
      case 1: 
        this.symmAlg = AlgorithmIdentifier.getInstance(localASN1TaggedObject, false);
        break;
      case 2: 
        this.encSymmKey = DERBitString.getInstance(localASN1TaggedObject, false);
        break;
      case 3: 
        this.keyAlg = AlgorithmIdentifier.getInstance(localASN1TaggedObject, false);
        break;
      case 4: 
        this.valueHint = ASN1OctetString.getInstance(localASN1TaggedObject, false);
      }
    }
    this.encValue = DERBitString.getInstance(paramASN1Sequence.getObjectAt(i));
  }
  
  public static EncryptedValue getInstance(Object paramObject)
  {
    if ((paramObject instanceof EncryptedValue)) {
      return (EncryptedValue)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new EncryptedValue((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    addOptional(localASN1EncodableVector, 0, this.intendedAlg);
    addOptional(localASN1EncodableVector, 1, this.symmAlg);
    addOptional(localASN1EncodableVector, 2, this.encSymmKey);
    addOptional(localASN1EncodableVector, 3, this.keyAlg);
    addOptional(localASN1EncodableVector, 4, this.valueHint);
    localASN1EncodableVector.add(this.encValue);
    return new DERSequence(localASN1EncodableVector);
  }
  
  private void addOptional(ASN1EncodableVector paramASN1EncodableVector, int paramInt, ASN1Encodable paramASN1Encodable)
  {
    if (paramASN1Encodable != null) {
      paramASN1EncodableVector.add(new DERTaggedObject(false, paramInt, paramASN1Encodable));
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\crmf\EncryptedValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */