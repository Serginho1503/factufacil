package org.bouncycastle.asn1.crmf;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;

public class CertRequest
  extends ASN1Encodable
{
  private DERInteger certReqId;
  private CertTemplate certTemplate;
  private Controls controls;
  
  private CertRequest(ASN1Sequence paramASN1Sequence)
  {
    this.certReqId = DERInteger.getInstance(paramASN1Sequence.getObjectAt(0));
    this.certTemplate = CertTemplate.getInstance(paramASN1Sequence.getObjectAt(1));
    if (paramASN1Sequence.size() > 2) {
      this.controls = Controls.getInstance(paramASN1Sequence.getObjectAt(2));
    }
  }
  
  public static CertRequest getInstance(Object paramObject)
  {
    if ((paramObject instanceof CertRequest)) {
      return (CertRequest)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new CertRequest((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }
  
  public DERInteger getCertReqId()
  {
    return this.certReqId;
  }
  
  public CertTemplate getCertTemplate()
  {
    return this.certTemplate;
  }
  
  public Controls getControls()
  {
    return this.controls;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.certReqId);
    localASN1EncodableVector.add(this.certTemplate);
    if (this.controls != null) {
      localASN1EncodableVector.add(this.controls);
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\crmf\CertRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */