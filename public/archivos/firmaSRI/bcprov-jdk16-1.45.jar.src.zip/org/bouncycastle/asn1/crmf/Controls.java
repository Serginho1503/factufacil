package org.bouncycastle.asn1.crmf;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;

public class Controls
  extends ASN1Encodable
{
  private ASN1Sequence content;
  
  private Controls(ASN1Sequence paramASN1Sequence)
  {
    this.content = paramASN1Sequence;
  }
  
  public static Controls getInstance(Object paramObject)
  {
    if ((paramObject instanceof Controls)) {
      return (Controls)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new Controls((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("Invalid object: " + paramObject.getClass().getName());
  }
  
  public AttributeTypeAndValue[] toAttributeTypeAndValueArray()
  {
    AttributeTypeAndValue[] arrayOfAttributeTypeAndValue = new AttributeTypeAndValue[this.content.size()];
    for (int i = 0; i != arrayOfAttributeTypeAndValue.length; i++) {
      arrayOfAttributeTypeAndValue[i] = AttributeTypeAndValue.getInstance(this.content.getObjectAt(i));
    }
    return arrayOfAttributeTypeAndValue;
  }
  
  public DERObject toASN1Object()
  {
    return this.content;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\crmf\Controls.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */