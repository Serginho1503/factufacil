package org.bouncycastle.asn1.crmf;

import org.bouncycastle.asn1.ASN1Choice;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERObject;

public class POPOPrivKey
  extends ASN1Encodable
  implements ASN1Choice
{
  private DERObject obj;
  
  private POPOPrivKey(DERObject paramDERObject)
  {
    this.obj = paramDERObject;
  }
  
  public static ASN1Encodable getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return new POPOPrivKey(paramASN1TaggedObject.getObject());
  }
  
  public DERObject toASN1Object()
  {
    return this.obj;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\crmf\POPOPrivKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */