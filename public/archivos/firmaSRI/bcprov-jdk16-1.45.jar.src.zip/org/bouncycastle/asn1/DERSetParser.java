package org.bouncycastle.asn1;

import java.io.IOException;

public class DERSetParser
  implements ASN1SetParser
{
  private ASN1StreamParser _parser;
  
  DERSetParser(ASN1StreamParser paramASN1StreamParser)
  {
    this._parser = paramASN1StreamParser;
  }
  
  public DEREncodable readObject()
    throws IOException
  {
    return this._parser.readObject();
  }
  
  public DERObject getDERObject()
  {
    try
    {
      return new DERSet(this._parser.readVector(), false);
    }
    catch (IOException localIOException)
    {
      throw new ASN1ParsingException(localIOException.getMessage(), localIOException);
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\DERSetParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */