package org.bouncycastle.asn1;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Vector;

public abstract class ASN1Sequence
  extends ASN1Object
{
  private Vector seq = new Vector();
  
  public static ASN1Sequence getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof ASN1Sequence))) {
      return (ASN1Sequence)paramObject;
    }
    throw new IllegalArgumentException("unknown object in getInstance: " + paramObject.getClass().getName());
  }
  
  public static ASN1Sequence getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    if (paramBoolean)
    {
      if (!paramASN1TaggedObject.isExplicit()) {
        throw new IllegalArgumentException("object implicit - explicit expected.");
      }
      return (ASN1Sequence)paramASN1TaggedObject.getObject();
    }
    if (paramASN1TaggedObject.isExplicit())
    {
      if ((paramASN1TaggedObject instanceof BERTaggedObject)) {
        return new BERSequence(paramASN1TaggedObject.getObject());
      }
      return new DERSequence(paramASN1TaggedObject.getObject());
    }
    if ((paramASN1TaggedObject.getObject() instanceof ASN1Sequence)) {
      return (ASN1Sequence)paramASN1TaggedObject.getObject();
    }
    throw new IllegalArgumentException("unknown object in getInstance: " + paramASN1TaggedObject.getClass().getName());
  }
  
  public Enumeration getObjects()
  {
    return this.seq.elements();
  }
  
  public ASN1SequenceParser parser()
  {
    final ASN1Sequence localASN1Sequence = this;
    new ASN1SequenceParser()
    {
      private final int max = ASN1Sequence.this.size();
      private int index;
      
      public DEREncodable readObject()
        throws IOException
      {
        if (this.index == this.max) {
          return null;
        }
        DEREncodable localDEREncodable = ASN1Sequence.this.getObjectAt(this.index++);
        if ((localDEREncodable instanceof ASN1Sequence)) {
          return ((ASN1Sequence)localDEREncodable).parser();
        }
        if ((localDEREncodable instanceof ASN1Set)) {
          return ((ASN1Set)localDEREncodable).parser();
        }
        return localDEREncodable;
      }
      
      public DERObject getDERObject()
      {
        return localASN1Sequence;
      }
    };
  }
  
  public DEREncodable getObjectAt(int paramInt)
  {
    return (DEREncodable)this.seq.elementAt(paramInt);
  }
  
  public int size()
  {
    return this.seq.size();
  }
  
  public int hashCode()
  {
    Enumeration localEnumeration = getObjects();
    int i = size();
    while (localEnumeration.hasMoreElements())
    {
      Object localObject = localEnumeration.nextElement();
      i *= 17;
      if (localObject != null) {
        i ^= localObject.hashCode();
      }
    }
    return i;
  }
  
  boolean asn1Equals(DERObject paramDERObject)
  {
    if (!(paramDERObject instanceof ASN1Sequence)) {
      return false;
    }
    ASN1Sequence localASN1Sequence = (ASN1Sequence)paramDERObject;
    if (size() != localASN1Sequence.size()) {
      return false;
    }
    Enumeration localEnumeration1 = getObjects();
    Enumeration localEnumeration2 = localASN1Sequence.getObjects();
    while (localEnumeration1.hasMoreElements())
    {
      DERObject localDERObject1 = ((DEREncodable)localEnumeration1.nextElement()).getDERObject();
      DERObject localDERObject2 = ((DEREncodable)localEnumeration2.nextElement()).getDERObject();
      if ((localDERObject1 != localDERObject2) && ((localDERObject1 == null) || (!localDERObject1.equals(localDERObject2)))) {
        return false;
      }
    }
    return true;
  }
  
  protected void addObject(DEREncodable paramDEREncodable)
  {
    this.seq.addElement(paramDEREncodable);
  }
  
  abstract void encode(DEROutputStream paramDEROutputStream)
    throws IOException;
  
  public String toString()
  {
    return this.seq.toString();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\ASN1Sequence.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */