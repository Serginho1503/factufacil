package org.bouncycastle.asn1;

import java.io.IOException;

public class DERVisibleString
  extends ASN1Object
  implements DERString
{
  String string;
  
  public static DERVisibleString getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof DERVisibleString))) {
      return (DERVisibleString)paramObject;
    }
    if ((paramObject instanceof ASN1OctetString)) {
      return new DERVisibleString(((ASN1OctetString)paramObject).getOctets());
    }
    if ((paramObject instanceof ASN1TaggedObject)) {
      return getInstance(((ASN1TaggedObject)paramObject).getObject());
    }
    throw new IllegalArgumentException("illegal object in getInstance: " + paramObject.getClass().getName());
  }
  
  public static DERVisibleString getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(paramASN1TaggedObject.getObject());
  }
  
  public DERVisibleString(byte[] paramArrayOfByte)
  {
    char[] arrayOfChar = new char[paramArrayOfByte.length];
    for (int i = 0; i != arrayOfChar.length; i++) {
      arrayOfChar[i] = ((char)(paramArrayOfByte[i] & 0xFF));
    }
    this.string = new String(arrayOfChar);
  }
  
  public DERVisibleString(String paramString)
  {
    this.string = paramString;
  }
  
  public String getString()
  {
    return this.string;
  }
  
  public String toString()
  {
    return this.string;
  }
  
  public byte[] getOctets()
  {
    char[] arrayOfChar = this.string.toCharArray();
    byte[] arrayOfByte = new byte[arrayOfChar.length];
    for (int i = 0; i != arrayOfChar.length; i++) {
      arrayOfByte[i] = ((byte)arrayOfChar[i]);
    }
    return arrayOfByte;
  }
  
  void encode(DEROutputStream paramDEROutputStream)
    throws IOException
  {
    paramDEROutputStream.writeEncoded(26, getOctets());
  }
  
  boolean asn1Equals(DERObject paramDERObject)
  {
    if (!(paramDERObject instanceof DERVisibleString)) {
      return false;
    }
    return getString().equals(((DERVisibleString)paramDERObject).getString());
  }
  
  public int hashCode()
  {
    return getString().hashCode();
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\DERVisibleString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */