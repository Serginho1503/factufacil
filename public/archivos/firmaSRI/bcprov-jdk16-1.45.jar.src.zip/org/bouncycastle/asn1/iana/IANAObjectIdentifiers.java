package org.bouncycastle.asn1.iana;

import org.bouncycastle.asn1.DERObjectIdentifier;

public abstract interface IANAObjectIdentifiers
{
  public static final DERObjectIdentifier isakmpOakley = new DERObjectIdentifier("1.3.6.1.5.5.8.1");
  public static final DERObjectIdentifier hmacMD5 = new DERObjectIdentifier(isakmpOakley + ".1");
  public static final DERObjectIdentifier hmacSHA1 = new DERObjectIdentifier(isakmpOakley + ".2");
  public static final DERObjectIdentifier hmacTIGER = new DERObjectIdentifier(isakmpOakley + ".3");
  public static final DERObjectIdentifier hmacRIPEMD160 = new DERObjectIdentifier(isakmpOakley + ".4");
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\iana\IANAObjectIdentifiers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */