package org.bouncycastle.asn1;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public abstract class ASN1Encodable
  implements DEREncodable
{
  public static final String DER = "DER";
  public static final String BER = "BER";
  
  public byte[] getEncoded()
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    ASN1OutputStream localASN1OutputStream = new ASN1OutputStream(localByteArrayOutputStream);
    localASN1OutputStream.writeObject(this);
    return localByteArrayOutputStream.toByteArray();
  }
  
  public byte[] getEncoded(String paramString)
    throws IOException
  {
    if (paramString.equals("DER"))
    {
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      DEROutputStream localDEROutputStream = new DEROutputStream(localByteArrayOutputStream);
      localDEROutputStream.writeObject(this);
      return localByteArrayOutputStream.toByteArray();
    }
    return getEncoded();
  }
  
  public byte[] getDEREncoded()
  {
    try
    {
      return getEncoded("DER");
    }
    catch (IOException localIOException) {}
    return null;
  }
  
  public int hashCode()
  {
    return toASN1Object().hashCode();
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {
      return true;
    }
    if (!(paramObject instanceof DEREncodable)) {
      return false;
    }
    DEREncodable localDEREncodable = (DEREncodable)paramObject;
    return toASN1Object().equals(localDEREncodable.getDERObject());
  }
  
  public DERObject getDERObject()
  {
    return toASN1Object();
  }
  
  public abstract DERObject toASN1Object();
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\ASN1Encodable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */