package org.bouncycastle.asn1;

import java.io.IOException;
import java.math.BigInteger;
import org.bouncycastle.util.Arrays;

public class DEREnumerated
  extends ASN1Object
{
  byte[] bytes;
  
  public static DEREnumerated getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof DEREnumerated))) {
      return (DEREnumerated)paramObject;
    }
    if ((paramObject instanceof ASN1OctetString)) {
      return new DEREnumerated(((ASN1OctetString)paramObject).getOctets());
    }
    if ((paramObject instanceof ASN1TaggedObject)) {
      return getInstance(((ASN1TaggedObject)paramObject).getObject());
    }
    throw new IllegalArgumentException("illegal object in getInstance: " + paramObject.getClass().getName());
  }
  
  public static DEREnumerated getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(paramASN1TaggedObject.getObject());
  }
  
  public DEREnumerated(int paramInt)
  {
    this.bytes = BigInteger.valueOf(paramInt).toByteArray();
  }
  
  public DEREnumerated(BigInteger paramBigInteger)
  {
    this.bytes = paramBigInteger.toByteArray();
  }
  
  public DEREnumerated(byte[] paramArrayOfByte)
  {
    this.bytes = paramArrayOfByte;
  }
  
  public BigInteger getValue()
  {
    return new BigInteger(this.bytes);
  }
  
  void encode(DEROutputStream paramDEROutputStream)
    throws IOException
  {
    paramDEROutputStream.writeEncoded(10, this.bytes);
  }
  
  boolean asn1Equals(DERObject paramDERObject)
  {
    if (!(paramDERObject instanceof DEREnumerated)) {
      return false;
    }
    DEREnumerated localDEREnumerated = (DEREnumerated)paramDERObject;
    return Arrays.areEqual(this.bytes, localDEREnumerated.bytes);
  }
  
  public int hashCode()
  {
    return Arrays.hashCode(this.bytes);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\DEREnumerated.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */