package org.bouncycastle.asn1;

public class OIDTokenizer
{
  private String oid;
  private int index;
  
  public OIDTokenizer(String paramString)
  {
    this.oid = paramString;
    this.index = 0;
  }
  
  public boolean hasMoreTokens()
  {
    return this.index != -1;
  }
  
  public String nextToken()
  {
    if (this.index == -1) {
      return null;
    }
    int i = this.oid.indexOf('.', this.index);
    if (i == -1)
    {
      str = this.oid.substring(this.index);
      this.index = -1;
      return str;
    }
    String str = this.oid.substring(this.index, i);
    this.index = (i + 1);
    return str;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\OIDTokenizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */