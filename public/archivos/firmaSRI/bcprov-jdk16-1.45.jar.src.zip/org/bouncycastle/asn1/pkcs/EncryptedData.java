package org.bouncycastle.asn1.pkcs;

import java.math.BigInteger;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.BERSequence;
import org.bouncycastle.asn1.BERTaggedObject;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class EncryptedData
  extends ASN1Encodable
{
  ASN1Sequence data;
  DERObjectIdentifier bagId;
  DERObject bagValue;
  
  public static EncryptedData getInstance(Object paramObject)
  {
    if ((paramObject instanceof EncryptedData)) {
      return (EncryptedData)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new EncryptedData((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in factory: " + paramObject.getClass().getName());
  }
  
  public EncryptedData(ASN1Sequence paramASN1Sequence)
  {
    int i = ((DERInteger)paramASN1Sequence.getObjectAt(0)).getValue().intValue();
    if (i != 0) {
      throw new IllegalArgumentException("sequence not version 0");
    }
    this.data = ((ASN1Sequence)paramASN1Sequence.getObjectAt(1));
  }
  
  public EncryptedData(DERObjectIdentifier paramDERObjectIdentifier, AlgorithmIdentifier paramAlgorithmIdentifier, DEREncodable paramDEREncodable)
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(paramDERObjectIdentifier);
    localASN1EncodableVector.add(paramAlgorithmIdentifier.getDERObject());
    localASN1EncodableVector.add(new BERTaggedObject(false, 0, paramDEREncodable));
    this.data = new BERSequence(localASN1EncodableVector);
  }
  
  public DERObjectIdentifier getContentType()
  {
    return (DERObjectIdentifier)this.data.getObjectAt(0);
  }
  
  public AlgorithmIdentifier getEncryptionAlgorithm()
  {
    return AlgorithmIdentifier.getInstance(this.data.getObjectAt(1));
  }
  
  public ASN1OctetString getContent()
  {
    if (this.data.size() == 3)
    {
      DERTaggedObject localDERTaggedObject = (DERTaggedObject)this.data.getObjectAt(2);
      return ASN1OctetString.getInstance(localDERTaggedObject.getObject());
    }
    return null;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(new DERInteger(0));
    localASN1EncodableVector.add(this.data);
    return new BERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\pkcs\EncryptedData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */