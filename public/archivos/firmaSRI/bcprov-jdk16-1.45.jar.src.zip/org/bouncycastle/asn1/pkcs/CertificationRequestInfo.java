package org.bouncycastle.asn1.pkcs;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.asn1.x509.X509Name;

public class CertificationRequestInfo
  extends ASN1Encodable
{
  DERInteger version = new DERInteger(0);
  X509Name subject;
  SubjectPublicKeyInfo subjectPKInfo;
  ASN1Set attributes = null;
  
  public static CertificationRequestInfo getInstance(Object paramObject)
  {
    if ((paramObject instanceof CertificationRequestInfo)) {
      return (CertificationRequestInfo)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new CertificationRequestInfo((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in factory: " + paramObject.getClass().getName());
  }
  
  public CertificationRequestInfo(X509Name paramX509Name, SubjectPublicKeyInfo paramSubjectPublicKeyInfo, ASN1Set paramASN1Set)
  {
    this.subject = paramX509Name;
    this.subjectPKInfo = paramSubjectPublicKeyInfo;
    this.attributes = paramASN1Set;
    if ((paramX509Name == null) || (this.version == null) || (this.subjectPKInfo == null)) {
      throw new IllegalArgumentException("Not all mandatory fields set in CertificationRequestInfo generator.");
    }
  }
  
  public CertificationRequestInfo(ASN1Sequence paramASN1Sequence)
  {
    this.version = ((DERInteger)paramASN1Sequence.getObjectAt(0));
    this.subject = X509Name.getInstance(paramASN1Sequence.getObjectAt(1));
    this.subjectPKInfo = SubjectPublicKeyInfo.getInstance(paramASN1Sequence.getObjectAt(2));
    if (paramASN1Sequence.size() > 3)
    {
      DERTaggedObject localDERTaggedObject = (DERTaggedObject)paramASN1Sequence.getObjectAt(3);
      this.attributes = ASN1Set.getInstance(localDERTaggedObject, false);
    }
    if ((this.subject == null) || (this.version == null) || (this.subjectPKInfo == null)) {
      throw new IllegalArgumentException("Not all mandatory fields set in CertificationRequestInfo generator.");
    }
  }
  
  public DERInteger getVersion()
  {
    return this.version;
  }
  
  public X509Name getSubject()
  {
    return this.subject;
  }
  
  public SubjectPublicKeyInfo getSubjectPublicKeyInfo()
  {
    return this.subjectPKInfo;
  }
  
  public ASN1Set getAttributes()
  {
    return this.attributes;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.version);
    localASN1EncodableVector.add(this.subject);
    localASN1EncodableVector.add(this.subjectPKInfo);
    if (this.attributes != null) {
      localASN1EncodableVector.add(new DERTaggedObject(false, 0, this.attributes));
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\pkcs\CertificationRequestInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */