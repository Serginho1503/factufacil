package org.bouncycastle.asn1.pkcs;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.oiw.OIWObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class RSAESOAEPparams
  extends ASN1Encodable
{
  private AlgorithmIdentifier hashAlgorithm;
  private AlgorithmIdentifier maskGenAlgorithm;
  private AlgorithmIdentifier pSourceAlgorithm;
  public static final AlgorithmIdentifier DEFAULT_HASH_ALGORITHM = new AlgorithmIdentifier(OIWObjectIdentifiers.idSHA1, new DERNull());
  public static final AlgorithmIdentifier DEFAULT_MASK_GEN_FUNCTION = new AlgorithmIdentifier(PKCSObjectIdentifiers.id_mgf1, DEFAULT_HASH_ALGORITHM);
  public static final AlgorithmIdentifier DEFAULT_P_SOURCE_ALGORITHM = new AlgorithmIdentifier(PKCSObjectIdentifiers.id_pSpecified, new DEROctetString(new byte[0]));
  
  public static RSAESOAEPparams getInstance(Object paramObject)
  {
    if ((paramObject instanceof RSAESOAEPparams)) {
      return (RSAESOAEPparams)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new RSAESOAEPparams((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in factory: " + paramObject.getClass().getName());
  }
  
  public RSAESOAEPparams()
  {
    this.hashAlgorithm = DEFAULT_HASH_ALGORITHM;
    this.maskGenAlgorithm = DEFAULT_MASK_GEN_FUNCTION;
    this.pSourceAlgorithm = DEFAULT_P_SOURCE_ALGORITHM;
  }
  
  public RSAESOAEPparams(AlgorithmIdentifier paramAlgorithmIdentifier1, AlgorithmIdentifier paramAlgorithmIdentifier2, AlgorithmIdentifier paramAlgorithmIdentifier3)
  {
    this.hashAlgorithm = paramAlgorithmIdentifier1;
    this.maskGenAlgorithm = paramAlgorithmIdentifier2;
    this.pSourceAlgorithm = paramAlgorithmIdentifier3;
  }
  
  public RSAESOAEPparams(ASN1Sequence paramASN1Sequence)
  {
    this.hashAlgorithm = DEFAULT_HASH_ALGORITHM;
    this.maskGenAlgorithm = DEFAULT_MASK_GEN_FUNCTION;
    this.pSourceAlgorithm = DEFAULT_P_SOURCE_ALGORITHM;
    for (int i = 0; i != paramASN1Sequence.size(); i++)
    {
      ASN1TaggedObject localASN1TaggedObject = (ASN1TaggedObject)paramASN1Sequence.getObjectAt(i);
      switch (localASN1TaggedObject.getTagNo())
      {
      case 0: 
        this.hashAlgorithm = AlgorithmIdentifier.getInstance(localASN1TaggedObject, true);
        break;
      case 1: 
        this.maskGenAlgorithm = AlgorithmIdentifier.getInstance(localASN1TaggedObject, true);
        break;
      case 2: 
        this.pSourceAlgorithm = AlgorithmIdentifier.getInstance(localASN1TaggedObject, true);
        break;
      default: 
        throw new IllegalArgumentException("unknown tag");
      }
    }
  }
  
  public AlgorithmIdentifier getHashAlgorithm()
  {
    return this.hashAlgorithm;
  }
  
  public AlgorithmIdentifier getMaskGenAlgorithm()
  {
    return this.maskGenAlgorithm;
  }
  
  public AlgorithmIdentifier getPSourceAlgorithm()
  {
    return this.pSourceAlgorithm;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    if (!this.hashAlgorithm.equals(DEFAULT_HASH_ALGORITHM)) {
      localASN1EncodableVector.add(new DERTaggedObject(true, 0, this.hashAlgorithm));
    }
    if (!this.maskGenAlgorithm.equals(DEFAULT_MASK_GEN_FUNCTION)) {
      localASN1EncodableVector.add(new DERTaggedObject(true, 1, this.maskGenAlgorithm));
    }
    if (!this.pSourceAlgorithm.equals(DEFAULT_P_SOURCE_ALGORITHM)) {
      localASN1EncodableVector.add(new DERTaggedObject(true, 2, this.pSourceAlgorithm));
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\pkcs\RSAESOAEPparams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */