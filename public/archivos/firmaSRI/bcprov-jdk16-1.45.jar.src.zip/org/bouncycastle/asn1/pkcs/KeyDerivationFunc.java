package org.bouncycastle.asn1.pkcs;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class KeyDerivationFunc
  extends AlgorithmIdentifier
{
  KeyDerivationFunc(ASN1Sequence paramASN1Sequence)
  {
    super(paramASN1Sequence);
  }
  
  KeyDerivationFunc(DERObjectIdentifier paramDERObjectIdentifier, ASN1Encodable paramASN1Encodable)
  {
    super(paramDERObjectIdentifier, paramASN1Encodable);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\pkcs\KeyDerivationFunc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */