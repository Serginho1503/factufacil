package org.bouncycastle.asn1.pkcs;

import java.math.BigInteger;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSequence;

public class RC2CBCParameter
  extends ASN1Encodable
{
  DERInteger version;
  ASN1OctetString iv;
  
  public static RC2CBCParameter getInstance(Object paramObject)
  {
    if ((paramObject instanceof ASN1Sequence)) {
      return new RC2CBCParameter((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in RC2CBCParameter factory");
  }
  
  public RC2CBCParameter(byte[] paramArrayOfByte)
  {
    this.version = null;
    this.iv = new DEROctetString(paramArrayOfByte);
  }
  
  public RC2CBCParameter(int paramInt, byte[] paramArrayOfByte)
  {
    this.version = new DERInteger(paramInt);
    this.iv = new DEROctetString(paramArrayOfByte);
  }
  
  public RC2CBCParameter(ASN1Sequence paramASN1Sequence)
  {
    if (paramASN1Sequence.size() == 1)
    {
      this.version = null;
      this.iv = ((ASN1OctetString)paramASN1Sequence.getObjectAt(0));
    }
    else
    {
      this.version = ((DERInteger)paramASN1Sequence.getObjectAt(0));
      this.iv = ((ASN1OctetString)paramASN1Sequence.getObjectAt(1));
    }
  }
  
  public BigInteger getRC2ParameterVersion()
  {
    if (this.version == null) {
      return null;
    }
    return this.version.getValue();
  }
  
  public byte[] getIV()
  {
    return this.iv.getOctets();
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    if (this.version != null) {
      localASN1EncodableVector.add(this.version);
    }
    localASN1EncodableVector.add(this.iv);
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\asn1\pkcs\RC2CBCParameter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */