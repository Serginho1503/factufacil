package org.bouncycastle.crypto.agreement;

import java.math.BigInteger;
import org.bouncycastle.crypto.BasicAgreement;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.params.AsymmetricKeyParameter;
import org.bouncycastle.crypto.params.DHParameters;
import org.bouncycastle.crypto.params.DHPrivateKeyParameters;
import org.bouncycastle.crypto.params.DHPublicKeyParameters;
import org.bouncycastle.crypto.params.ParametersWithRandom;

public class DHBasicAgreement
  implements BasicAgreement
{
  private DHPrivateKeyParameters key;
  private DHParameters dhParams;
  
  public void init(CipherParameters paramCipherParameters)
  {
    AsymmetricKeyParameter localAsymmetricKeyParameter;
    if ((paramCipherParameters instanceof ParametersWithRandom))
    {
      ParametersWithRandom localParametersWithRandom = (ParametersWithRandom)paramCipherParameters;
      localAsymmetricKeyParameter = (AsymmetricKeyParameter)localParametersWithRandom.getParameters();
    }
    else
    {
      localAsymmetricKeyParameter = (AsymmetricKeyParameter)paramCipherParameters;
    }
    if (!(localAsymmetricKeyParameter instanceof DHPrivateKeyParameters)) {
      throw new IllegalArgumentException("DHEngine expects DHPrivateKeyParameters");
    }
    this.key = ((DHPrivateKeyParameters)localAsymmetricKeyParameter);
    this.dhParams = this.key.getParameters();
  }
  
  public BigInteger calculateAgreement(CipherParameters paramCipherParameters)
  {
    DHPublicKeyParameters localDHPublicKeyParameters = (DHPublicKeyParameters)paramCipherParameters;
    if (!localDHPublicKeyParameters.getParameters().equals(this.dhParams)) {
      throw new IllegalArgumentException("Diffie-Hellman public key has wrong parameters.");
    }
    return localDHPublicKeyParameters.getY().modPow(this.key.getX(), this.dhParams.getP());
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\agreement\DHBasicAgreement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */