package org.bouncycastle.crypto.agreement.kdf;

import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.DerivationFunction;
import org.bouncycastle.crypto.DerivationParameters;
import org.bouncycastle.crypto.Digest;

public class DHKEKGenerator
  implements DerivationFunction
{
  private final Digest digest;
  private DERObjectIdentifier algorithm;
  private int keySize;
  private byte[] z;
  private byte[] partyAInfo;
  
  public DHKEKGenerator(Digest paramDigest)
  {
    this.digest = paramDigest;
  }
  
  public void init(DerivationParameters paramDerivationParameters)
  {
    DHKDFParameters localDHKDFParameters = (DHKDFParameters)paramDerivationParameters;
    this.algorithm = localDHKDFParameters.getAlgorithm();
    this.keySize = localDHKDFParameters.getKeySize();
    this.z = localDHKDFParameters.getZ();
    this.partyAInfo = localDHKDFParameters.getExtraInfo();
  }
  
  public Digest getDigest()
  {
    return this.digest;
  }
  
  public int generateBytes(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws DataLengthException, IllegalArgumentException
  {
    if (paramArrayOfByte.length - paramInt2 < paramInt1) {
      throw new DataLengthException("output buffer too small");
    }
    long l = paramInt2;
    int i = this.digest.getDigestSize();
    if (l > 8589934591L) {
      throw new IllegalArgumentException("Output length too large");
    }
    int j = (int)((l + i - 1L) / i);
    byte[] arrayOfByte1 = new byte[this.digest.getDigestSize()];
    int k = 1;
    for (int m = 0; m < j; m++)
    {
      this.digest.update(this.z, 0, this.z.length);
      ASN1EncodableVector localASN1EncodableVector1 = new ASN1EncodableVector();
      ASN1EncodableVector localASN1EncodableVector2 = new ASN1EncodableVector();
      localASN1EncodableVector2.add(this.algorithm);
      localASN1EncodableVector2.add(new DEROctetString(integerToBytes(k)));
      localASN1EncodableVector1.add(new DERSequence(localASN1EncodableVector2));
      if (this.partyAInfo != null) {
        localASN1EncodableVector1.add(new DERTaggedObject(true, 0, new DEROctetString(this.partyAInfo)));
      }
      localASN1EncodableVector1.add(new DERTaggedObject(true, 2, new DEROctetString(integerToBytes(this.keySize))));
      byte[] arrayOfByte2 = new DERSequence(localASN1EncodableVector1).getDEREncoded();
      this.digest.update(arrayOfByte2, 0, arrayOfByte2.length);
      this.digest.doFinal(arrayOfByte1, 0);
      if (paramInt2 > i)
      {
        System.arraycopy(arrayOfByte1, 0, paramArrayOfByte, paramInt1, i);
        paramInt1 += i;
        paramInt2 -= i;
      }
      else
      {
        System.arraycopy(arrayOfByte1, 0, paramArrayOfByte, paramInt1, paramInt2);
      }
      k++;
    }
    this.digest.reset();
    return paramInt2;
  }
  
  private byte[] integerToBytes(int paramInt)
  {
    byte[] arrayOfByte = new byte[4];
    arrayOfByte[0] = ((byte)(paramInt >> 24));
    arrayOfByte[1] = ((byte)(paramInt >> 16));
    arrayOfByte[2] = ((byte)(paramInt >> 8));
    arrayOfByte[3] = ((byte)paramInt);
    return arrayOfByte;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\agreement\kdf\DHKEKGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */