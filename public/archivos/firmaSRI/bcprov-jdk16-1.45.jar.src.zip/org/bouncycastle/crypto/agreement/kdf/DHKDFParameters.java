package org.bouncycastle.crypto.agreement.kdf;

import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.crypto.DerivationParameters;

public class DHKDFParameters
  implements DerivationParameters
{
  private final DERObjectIdentifier algorithm;
  private final int keySize;
  private final byte[] z;
  private final byte[] extraInfo;
  
  public DHKDFParameters(DERObjectIdentifier paramDERObjectIdentifier, int paramInt, byte[] paramArrayOfByte)
  {
    this.algorithm = paramDERObjectIdentifier;
    this.keySize = paramInt;
    this.z = paramArrayOfByte;
    this.extraInfo = null;
  }
  
  public DHKDFParameters(DERObjectIdentifier paramDERObjectIdentifier, int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.algorithm = paramDERObjectIdentifier;
    this.keySize = paramInt;
    this.z = paramArrayOfByte1;
    this.extraInfo = paramArrayOfByte2;
  }
  
  public DERObjectIdentifier getAlgorithm()
  {
    return this.algorithm;
  }
  
  public int getKeySize()
  {
    return this.keySize;
  }
  
  public byte[] getZ()
  {
    return this.z;
  }
  
  public byte[] getExtraInfo()
  {
    return this.extraInfo;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\agreement\kdf\DHKDFParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */