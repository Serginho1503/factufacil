package org.bouncycastle.crypto.agreement.srp;

import java.math.BigInteger;
import org.bouncycastle.crypto.Digest;

public class SRP6VerifierGenerator
{
  protected BigInteger N;
  protected BigInteger g;
  protected Digest digest;
  
  public void init(BigInteger paramBigInteger1, BigInteger paramBigInteger2, Digest paramDigest)
  {
    this.N = paramBigInteger1;
    this.g = paramBigInteger2;
    this.digest = paramDigest;
  }
  
  public BigInteger generateVerifier(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    BigInteger localBigInteger = SRP6Util.calculateX(this.digest, this.N, paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    return this.g.modPow(localBigInteger, this.N);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\agreement\srp\SRP6VerifierGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */