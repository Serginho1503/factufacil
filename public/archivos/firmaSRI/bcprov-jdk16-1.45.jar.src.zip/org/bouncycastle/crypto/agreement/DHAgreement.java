package org.bouncycastle.crypto.agreement;

import java.math.BigInteger;
import java.security.SecureRandom;
import org.bouncycastle.crypto.AsymmetricCipherKeyPair;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.generators.DHKeyPairGenerator;
import org.bouncycastle.crypto.params.AsymmetricKeyParameter;
import org.bouncycastle.crypto.params.DHKeyGenerationParameters;
import org.bouncycastle.crypto.params.DHParameters;
import org.bouncycastle.crypto.params.DHPrivateKeyParameters;
import org.bouncycastle.crypto.params.DHPublicKeyParameters;
import org.bouncycastle.crypto.params.ParametersWithRandom;

public class DHAgreement
{
  private DHPrivateKeyParameters key;
  private DHParameters dhParams;
  private BigInteger privateValue;
  private SecureRandom random;
  
  public void init(CipherParameters paramCipherParameters)
  {
    AsymmetricKeyParameter localAsymmetricKeyParameter;
    if ((paramCipherParameters instanceof ParametersWithRandom))
    {
      ParametersWithRandom localParametersWithRandom = (ParametersWithRandom)paramCipherParameters;
      this.random = localParametersWithRandom.getRandom();
      localAsymmetricKeyParameter = (AsymmetricKeyParameter)localParametersWithRandom.getParameters();
    }
    else
    {
      this.random = new SecureRandom();
      localAsymmetricKeyParameter = (AsymmetricKeyParameter)paramCipherParameters;
    }
    if (!(localAsymmetricKeyParameter instanceof DHPrivateKeyParameters)) {
      throw new IllegalArgumentException("DHEngine expects DHPrivateKeyParameters");
    }
    this.key = ((DHPrivateKeyParameters)localAsymmetricKeyParameter);
    this.dhParams = this.key.getParameters();
  }
  
  public BigInteger calculateMessage()
  {
    DHKeyPairGenerator localDHKeyPairGenerator = new DHKeyPairGenerator();
    localDHKeyPairGenerator.init(new DHKeyGenerationParameters(this.random, this.dhParams));
    AsymmetricCipherKeyPair localAsymmetricCipherKeyPair = localDHKeyPairGenerator.generateKeyPair();
    this.privateValue = ((DHPrivateKeyParameters)localAsymmetricCipherKeyPair.getPrivate()).getX();
    return ((DHPublicKeyParameters)localAsymmetricCipherKeyPair.getPublic()).getY();
  }
  
  public BigInteger calculateAgreement(DHPublicKeyParameters paramDHPublicKeyParameters, BigInteger paramBigInteger)
  {
    if (!paramDHPublicKeyParameters.getParameters().equals(this.dhParams)) {
      throw new IllegalArgumentException("Diffie-Hellman public key has wrong parameters.");
    }
    BigInteger localBigInteger = this.dhParams.getP();
    return paramBigInteger.modPow(this.key.getX(), localBigInteger).multiply(paramDHPublicKeyParameters.getY().modPow(this.privateValue, localBigInteger)).mod(localBigInteger);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\agreement\DHAgreement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */