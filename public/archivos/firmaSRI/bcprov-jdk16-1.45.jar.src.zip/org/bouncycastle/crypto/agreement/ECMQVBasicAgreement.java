package org.bouncycastle.crypto.agreement;

import java.math.BigInteger;
import org.bouncycastle.crypto.BasicAgreement;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.params.ECDomainParameters;
import org.bouncycastle.crypto.params.ECPrivateKeyParameters;
import org.bouncycastle.crypto.params.ECPublicKeyParameters;
import org.bouncycastle.crypto.params.MQVPrivateParameters;
import org.bouncycastle.crypto.params.MQVPublicParameters;
import org.bouncycastle.math.ec.ECAlgorithms;
import org.bouncycastle.math.ec.ECConstants;
import org.bouncycastle.math.ec.ECFieldElement;
import org.bouncycastle.math.ec.ECPoint;

public class ECMQVBasicAgreement
  implements BasicAgreement
{
  MQVPrivateParameters privParams;
  
  public void init(CipherParameters paramCipherParameters)
  {
    this.privParams = ((MQVPrivateParameters)paramCipherParameters);
  }
  
  public BigInteger calculateAgreement(CipherParameters paramCipherParameters)
  {
    MQVPublicParameters localMQVPublicParameters = (MQVPublicParameters)paramCipherParameters;
    ECPrivateKeyParameters localECPrivateKeyParameters = this.privParams.getStaticPrivateKey();
    ECPoint localECPoint = calculateMqvAgreement(localECPrivateKeyParameters.getParameters(), localECPrivateKeyParameters, this.privParams.getEphemeralPrivateKey(), this.privParams.getEphemeralPublicKey(), localMQVPublicParameters.getStaticPublicKey(), localMQVPublicParameters.getEphemeralPublicKey());
    return localECPoint.getX().toBigInteger();
  }
  
  private ECPoint calculateMqvAgreement(ECDomainParameters paramECDomainParameters, ECPrivateKeyParameters paramECPrivateKeyParameters1, ECPrivateKeyParameters paramECPrivateKeyParameters2, ECPublicKeyParameters paramECPublicKeyParameters1, ECPublicKeyParameters paramECPublicKeyParameters2, ECPublicKeyParameters paramECPublicKeyParameters3)
  {
    BigInteger localBigInteger1 = paramECDomainParameters.getN();
    int i = (localBigInteger1.bitLength() + 1) / 2;
    BigInteger localBigInteger2 = ECConstants.ONE.shiftLeft(i);
    ECPoint localECPoint1;
    if (paramECPublicKeyParameters1 == null) {
      localECPoint1 = paramECDomainParameters.getG().multiply(paramECPrivateKeyParameters2.getD());
    } else {
      localECPoint1 = paramECPublicKeyParameters1.getQ();
    }
    BigInteger localBigInteger3 = localECPoint1.getX().toBigInteger();
    BigInteger localBigInteger4 = localBigInteger3.mod(localBigInteger2);
    BigInteger localBigInteger5 = localBigInteger4.setBit(i);
    BigInteger localBigInteger6 = paramECPrivateKeyParameters1.getD().multiply(localBigInteger5).mod(localBigInteger1).add(paramECPrivateKeyParameters2.getD()).mod(localBigInteger1);
    BigInteger localBigInteger7 = paramECPublicKeyParameters3.getQ().getX().toBigInteger();
    BigInteger localBigInteger8 = localBigInteger7.mod(localBigInteger2);
    BigInteger localBigInteger9 = localBigInteger8.setBit(i);
    BigInteger localBigInteger10 = paramECDomainParameters.getH().multiply(localBigInteger6).mod(localBigInteger1);
    ECPoint localECPoint2 = ECAlgorithms.sumOfTwoMultiplies(paramECPublicKeyParameters2.getQ(), localBigInteger9.multiply(localBigInteger10).mod(localBigInteger1), paramECPublicKeyParameters3.getQ(), localBigInteger10);
    if (localECPoint2.isInfinity()) {
      throw new IllegalStateException("Infinity is not a valid agreement value for MQV");
    }
    return localECPoint2;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\agreement\ECMQVBasicAgreement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */