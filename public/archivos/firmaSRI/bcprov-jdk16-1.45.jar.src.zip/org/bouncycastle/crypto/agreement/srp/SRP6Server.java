package org.bouncycastle.crypto.agreement.srp;

import java.math.BigInteger;
import java.security.SecureRandom;
import org.bouncycastle.crypto.CryptoException;
import org.bouncycastle.crypto.Digest;

public class SRP6Server
{
  protected BigInteger N;
  protected BigInteger g;
  protected BigInteger v;
  protected SecureRandom random;
  protected Digest digest;
  protected BigInteger A;
  protected BigInteger b;
  protected BigInteger B;
  protected BigInteger u;
  protected BigInteger S;
  
  public void init(BigInteger paramBigInteger1, BigInteger paramBigInteger2, BigInteger paramBigInteger3, Digest paramDigest, SecureRandom paramSecureRandom)
  {
    this.N = paramBigInteger1;
    this.g = paramBigInteger2;
    this.v = paramBigInteger3;
    this.random = paramSecureRandom;
    this.digest = paramDigest;
  }
  
  public BigInteger generateServerCredentials()
  {
    BigInteger localBigInteger = SRP6Util.calculateK(this.digest, this.N, this.g);
    this.b = selectPrivateValue();
    this.B = localBigInteger.multiply(this.v).mod(this.N).add(this.g.modPow(this.b, this.N)).mod(this.N);
    return this.B;
  }
  
  public BigInteger calculateSecret(BigInteger paramBigInteger)
    throws CryptoException
  {
    this.A = SRP6Util.validatePublicValue(this.N, paramBigInteger);
    this.u = SRP6Util.calculateU(this.digest, this.N, this.A, this.B);
    this.S = calculateS();
    return this.S;
  }
  
  protected BigInteger selectPrivateValue()
  {
    return SRP6Util.generatePrivateValue(this.digest, this.N, this.g, this.random);
  }
  
  private BigInteger calculateS()
  {
    return this.v.modPow(this.u, this.N).multiply(this.A).mod(this.N).modPow(this.b, this.N);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\agreement\srp\SRP6Server.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */