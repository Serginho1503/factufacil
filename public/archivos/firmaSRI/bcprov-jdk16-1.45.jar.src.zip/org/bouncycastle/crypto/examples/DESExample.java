package org.bouncycastle.crypto.examples;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.security.SecureRandom;
import org.bouncycastle.crypto.CryptoException;
import org.bouncycastle.crypto.KeyGenerationParameters;
import org.bouncycastle.crypto.engines.DESedeEngine;
import org.bouncycastle.crypto.generators.DESedeKeyGenerator;
import org.bouncycastle.crypto.modes.CBCBlockCipher;
import org.bouncycastle.crypto.paddings.PaddedBufferedBlockCipher;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.util.encoders.Hex;

public class DESExample
{
  private boolean encrypt = true;
  private PaddedBufferedBlockCipher cipher = null;
  private BufferedInputStream in = null;
  private BufferedOutputStream out = null;
  private byte[] key = null;
  
  public static void main(String[] paramArrayOfString)
  {
    boolean bool = true;
    String str1 = null;
    String str2 = null;
    String str3 = null;
    if (paramArrayOfString.length < 2)
    {
      localDESExample = new DESExample();
      System.err.println("Usage: java " + localDESExample.getClass().getName() + " infile outfile [keyfile]");
      System.exit(1);
    }
    str3 = "deskey.dat";
    str1 = paramArrayOfString[0];
    str2 = paramArrayOfString[1];
    if (paramArrayOfString.length > 2)
    {
      bool = false;
      str3 = paramArrayOfString[2];
    }
    DESExample localDESExample = new DESExample(str1, str2, str3, bool);
    localDESExample.process();
  }
  
  public DESExample() {}
  
  public DESExample(String paramString1, String paramString2, String paramString3, boolean paramBoolean)
  {
    this.encrypt = paramBoolean;
    try
    {
      this.in = new BufferedInputStream(new FileInputStream(paramString1));
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      System.err.println("Input file not found [" + paramString1 + "]");
      System.exit(1);
    }
    try
    {
      this.out = new BufferedOutputStream(new FileOutputStream(paramString2));
    }
    catch (IOException localIOException1)
    {
      System.err.println("Output file not created [" + paramString2 + "]");
      System.exit(1);
    }
    Object localObject;
    if (paramBoolean) {
      try
      {
        SecureRandom localSecureRandom = null;
        try
        {
          localSecureRandom = new SecureRandom();
          localSecureRandom.setSeed("www.bouncycastle.org".getBytes());
        }
        catch (Exception localException)
        {
          System.err.println("Hmmm, no SHA1PRNG, you need the Sun implementation");
          System.exit(1);
        }
        KeyGenerationParameters localKeyGenerationParameters = new KeyGenerationParameters(localSecureRandom, 192);
        localObject = new DESedeKeyGenerator();
        ((DESedeKeyGenerator)localObject).init(localKeyGenerationParameters);
        this.key = ((DESedeKeyGenerator)localObject).generateKey();
        BufferedOutputStream localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString3));
        byte[] arrayOfByte = Hex.encode(this.key);
        localBufferedOutputStream.write(arrayOfByte, 0, arrayOfByte.length);
        localBufferedOutputStream.flush();
        localBufferedOutputStream.close();
      }
      catch (IOException localIOException2)
      {
        System.err.println("Could not decryption create key file [" + paramString3 + "]");
        System.exit(1);
      }
    } else {
      try
      {
        BufferedInputStream localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString3));
        int i = localBufferedInputStream.available();
        localObject = new byte[i];
        localBufferedInputStream.read((byte[])localObject, 0, i);
        this.key = Hex.decode((byte[])localObject);
      }
      catch (IOException localIOException3)
      {
        System.err.println("Decryption key file not found, or not valid [" + paramString3 + "]");
        System.exit(1);
      }
    }
  }
  
  private void process()
  {
    this.cipher = new PaddedBufferedBlockCipher(new CBCBlockCipher(new DESedeEngine()));
    if (this.encrypt) {
      performEncrypt(this.key);
    } else {
      performDecrypt(this.key);
    }
    try
    {
      this.in.close();
      this.out.flush();
      this.out.close();
    }
    catch (IOException localIOException) {}
  }
  
  private void performEncrypt(byte[] paramArrayOfByte)
  {
    this.cipher.init(true, new KeyParameter(paramArrayOfByte));
    int i = 47;
    int j = this.cipher.getOutputSize(i);
    byte[] arrayOfByte1 = new byte[i];
    byte[] arrayOfByte2 = new byte[j];
    try
    {
      byte[] arrayOfByte3 = null;
      int k;
      int m;
      while ((k = this.in.read(arrayOfByte1, 0, i)) > 0)
      {
        m = this.cipher.processBytes(arrayOfByte1, 0, k, arrayOfByte2, 0);
        if (m > 0)
        {
          arrayOfByte3 = Hex.encode(arrayOfByte2, 0, m);
          this.out.write(arrayOfByte3, 0, arrayOfByte3.length);
          this.out.write(10);
        }
      }
      try
      {
        m = this.cipher.doFinal(arrayOfByte2, 0);
        if (m > 0)
        {
          arrayOfByte3 = Hex.encode(arrayOfByte2, 0, m);
          this.out.write(arrayOfByte3, 0, arrayOfByte3.length);
          this.out.write(10);
        }
      }
      catch (CryptoException localCryptoException) {}
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
  }
  
  private void performDecrypt(byte[] paramArrayOfByte)
  {
    this.cipher.init(false, new KeyParameter(paramArrayOfByte));
    BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(this.in));
    try
    {
      byte[] arrayOfByte1 = null;
      byte[] arrayOfByte2 = null;
      String str = null;
      int i;
      while ((str = localBufferedReader.readLine()) != null)
      {
        arrayOfByte1 = Hex.decode(str);
        arrayOfByte2 = new byte[this.cipher.getOutputSize(arrayOfByte1.length)];
        i = this.cipher.processBytes(arrayOfByte1, 0, arrayOfByte1.length, arrayOfByte2, 0);
        if (i > 0) {
          this.out.write(arrayOfByte2, 0, i);
        }
      }
      try
      {
        i = this.cipher.doFinal(arrayOfByte2, 0);
        if (i > 0) {
          this.out.write(arrayOfByte2, 0, i);
        }
      }
      catch (CryptoException localCryptoException) {}
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\examples\DESExample.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */