package org.bouncycastle.crypto.io;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import org.bouncycastle.crypto.Signer;

public class SignerInputStream
  extends FilterInputStream
{
  protected Signer signer;
  
  public SignerInputStream(InputStream paramInputStream, Signer paramSigner)
  {
    super(paramInputStream);
    this.signer = paramSigner;
  }
  
  public int read()
    throws IOException
  {
    int i = this.in.read();
    if (i >= 0) {
      this.signer.update((byte)i);
    }
    return i;
  }
  
  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int i = this.in.read(paramArrayOfByte, paramInt1, paramInt2);
    if (i > 0) {
      this.signer.update(paramArrayOfByte, paramInt1, i);
    }
    return i;
  }
  
  public Signer getSigner()
  {
    return this.signer;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\io\SignerInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */