package org.bouncycastle.crypto.io;

import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import org.bouncycastle.crypto.Digest;

public class DigestOutputStream
  extends FilterOutputStream
{
  protected Digest digest;
  
  public DigestOutputStream(OutputStream paramOutputStream, Digest paramDigest)
  {
    super(paramOutputStream);
    this.digest = paramDigest;
  }
  
  public void write(int paramInt)
    throws IOException
  {
    this.digest.update((byte)paramInt);
    this.out.write(paramInt);
  }
  
  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    this.digest.update(paramArrayOfByte, paramInt1, paramInt2);
    this.out.write(paramArrayOfByte, paramInt1, paramInt2);
  }
  
  public Digest getDigest()
  {
    return this.digest;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\io\DigestOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */