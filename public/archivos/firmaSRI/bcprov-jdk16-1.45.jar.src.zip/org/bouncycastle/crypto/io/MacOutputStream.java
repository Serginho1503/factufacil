package org.bouncycastle.crypto.io;

import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import org.bouncycastle.crypto.Mac;

public class MacOutputStream
  extends FilterOutputStream
{
  protected Mac mac;
  
  public MacOutputStream(OutputStream paramOutputStream, Mac paramMac)
  {
    super(paramOutputStream);
    this.mac = paramMac;
  }
  
  public void write(int paramInt)
    throws IOException
  {
    this.mac.update((byte)paramInt);
    this.out.write(paramInt);
  }
  
  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    this.mac.update(paramArrayOfByte, paramInt1, paramInt2);
    this.out.write(paramArrayOfByte, paramInt1, paramInt2);
  }
  
  public Mac getMac()
  {
    return this.mac;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\io\MacOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */