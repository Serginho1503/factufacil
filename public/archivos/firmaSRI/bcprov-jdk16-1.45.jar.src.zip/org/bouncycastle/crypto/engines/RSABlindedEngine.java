package org.bouncycastle.crypto.engines;

import java.math.BigInteger;
import java.security.SecureRandom;
import org.bouncycastle.crypto.AsymmetricBlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.params.ParametersWithRandom;
import org.bouncycastle.crypto.params.RSAKeyParameters;
import org.bouncycastle.crypto.params.RSAPrivateCrtKeyParameters;
import org.bouncycastle.util.BigIntegers;

public class RSABlindedEngine
  implements AsymmetricBlockCipher
{
  private static BigInteger ONE = BigInteger.valueOf(1L);
  private RSACoreEngine core = new RSACoreEngine();
  private RSAKeyParameters key;
  private SecureRandom random;
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
  {
    this.core.init(paramBoolean, paramCipherParameters);
    if ((paramCipherParameters instanceof ParametersWithRandom))
    {
      ParametersWithRandom localParametersWithRandom = (ParametersWithRandom)paramCipherParameters;
      this.key = ((RSAKeyParameters)localParametersWithRandom.getParameters());
      this.random = localParametersWithRandom.getRandom();
    }
    else
    {
      this.key = ((RSAKeyParameters)paramCipherParameters);
      this.random = new SecureRandom();
    }
  }
  
  public int getInputBlockSize()
  {
    return this.core.getInputBlockSize();
  }
  
  public int getOutputBlockSize()
  {
    return this.core.getOutputBlockSize();
  }
  
  public byte[] processBlock(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    if (this.key == null) {
      throw new IllegalStateException("RSA engine not initialised");
    }
    BigInteger localBigInteger1 = this.core.convertInput(paramArrayOfByte, paramInt1, paramInt2);
    BigInteger localBigInteger2;
    if ((this.key instanceof RSAPrivateCrtKeyParameters))
    {
      RSAPrivateCrtKeyParameters localRSAPrivateCrtKeyParameters = (RSAPrivateCrtKeyParameters)this.key;
      BigInteger localBigInteger3 = localRSAPrivateCrtKeyParameters.getPublicExponent();
      if (localBigInteger3 != null)
      {
        BigInteger localBigInteger4 = localRSAPrivateCrtKeyParameters.getModulus();
        BigInteger localBigInteger5 = BigIntegers.createRandomInRange(ONE, localBigInteger4.subtract(ONE), this.random);
        BigInteger localBigInteger6 = localBigInteger5.modPow(localBigInteger3, localBigInteger4).multiply(localBigInteger1).mod(localBigInteger4);
        BigInteger localBigInteger7 = this.core.processBlock(localBigInteger6);
        BigInteger localBigInteger8 = localBigInteger5.modInverse(localBigInteger4);
        localBigInteger2 = localBigInteger7.multiply(localBigInteger8).mod(localBigInteger4);
      }
      else
      {
        localBigInteger2 = this.core.processBlock(localBigInteger1);
      }
    }
    else
    {
      localBigInteger2 = this.core.processBlock(localBigInteger1);
    }
    return this.core.convertOutput(localBigInteger2);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\engines\RSABlindedEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */