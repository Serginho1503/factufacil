package org.bouncycastle.crypto.engines;

import java.io.PrintStream;
import java.math.BigInteger;
import java.util.Vector;
import org.bouncycastle.crypto.AsymmetricBlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.InvalidCipherTextException;
import org.bouncycastle.crypto.params.NaccacheSternKeyParameters;
import org.bouncycastle.crypto.params.NaccacheSternPrivateKeyParameters;
import org.bouncycastle.crypto.params.ParametersWithRandom;
import org.bouncycastle.util.Arrays;

public class NaccacheSternEngine
  implements AsymmetricBlockCipher
{
  private boolean forEncryption;
  private NaccacheSternKeyParameters key;
  private Vector[] lookup = null;
  private boolean debug = false;
  private static BigInteger ZERO = BigInteger.valueOf(0L);
  private static BigInteger ONE = BigInteger.valueOf(1L);
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
  {
    this.forEncryption = paramBoolean;
    if ((paramCipherParameters instanceof ParametersWithRandom)) {
      paramCipherParameters = ((ParametersWithRandom)paramCipherParameters).getParameters();
    }
    this.key = ((NaccacheSternKeyParameters)paramCipherParameters);
    if (!this.forEncryption)
    {
      if (this.debug) {
        System.out.println("Constructing lookup Array");
      }
      NaccacheSternPrivateKeyParameters localNaccacheSternPrivateKeyParameters = (NaccacheSternPrivateKeyParameters)this.key;
      Vector localVector = localNaccacheSternPrivateKeyParameters.getSmallPrimes();
      this.lookup = new Vector[localVector.size()];
      for (int i = 0; i < localVector.size(); i++)
      {
        BigInteger localBigInteger1 = (BigInteger)localVector.elementAt(i);
        int j = localBigInteger1.intValue();
        this.lookup[i] = new Vector();
        this.lookup[i].addElement(ONE);
        if (this.debug) {
          System.out.println("Constructing lookup ArrayList for " + j);
        }
        BigInteger localBigInteger2 = ZERO;
        for (int k = 1; k < j; k++)
        {
          localBigInteger2 = localBigInteger2.add(localNaccacheSternPrivateKeyParameters.getPhi_n());
          BigInteger localBigInteger3 = localBigInteger2.divide(localBigInteger1);
          this.lookup[i].addElement(localNaccacheSternPrivateKeyParameters.getG().modPow(localBigInteger3, localNaccacheSternPrivateKeyParameters.getModulus()));
        }
      }
    }
  }
  
  public void setDebug(boolean paramBoolean)
  {
    this.debug = paramBoolean;
  }
  
  public int getInputBlockSize()
  {
    if (this.forEncryption) {
      return (this.key.getLowerSigmaBound() + 7) / 8 - 1;
    }
    return this.key.getModulus().toByteArray().length;
  }
  
  public int getOutputBlockSize()
  {
    if (this.forEncryption) {
      return this.key.getModulus().toByteArray().length;
    }
    return (this.key.getLowerSigmaBound() + 7) / 8 - 1;
  }
  
  public byte[] processBlock(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws InvalidCipherTextException
  {
    if (this.key == null) {
      throw new IllegalStateException("NaccacheStern engine not initialised");
    }
    if (paramInt2 > getInputBlockSize() + 1) {
      throw new DataLengthException("input too large for Naccache-Stern cipher.\n");
    }
    if ((!this.forEncryption) && (paramInt2 < getInputBlockSize())) {
      throw new InvalidCipherTextException("BlockLength does not match modulus for Naccache-Stern cipher.\n");
    }
    byte[] arrayOfByte1;
    if ((paramInt1 != 0) || (paramInt2 != paramArrayOfByte.length))
    {
      arrayOfByte1 = new byte[paramInt2];
      System.arraycopy(paramArrayOfByte, paramInt1, arrayOfByte1, 0, paramInt2);
    }
    else
    {
      arrayOfByte1 = paramArrayOfByte;
    }
    BigInteger localBigInteger1 = new BigInteger(1, arrayOfByte1);
    if (this.debug) {
      System.out.println("input as BigInteger: " + localBigInteger1);
    }
    byte[] arrayOfByte2;
    if (this.forEncryption)
    {
      arrayOfByte2 = encrypt(localBigInteger1);
    }
    else
    {
      Vector localVector1 = new Vector();
      NaccacheSternPrivateKeyParameters localNaccacheSternPrivateKeyParameters = (NaccacheSternPrivateKeyParameters)this.key;
      Vector localVector2 = localNaccacheSternPrivateKeyParameters.getSmallPrimes();
      for (int i = 0; i < localVector2.size(); i++)
      {
        BigInteger localBigInteger3 = localBigInteger1.modPow(localNaccacheSternPrivateKeyParameters.getPhi_n().divide((BigInteger)localVector2.elementAt(i)), localNaccacheSternPrivateKeyParameters.getModulus());
        Vector localVector3 = this.lookup[i];
        if (this.lookup[i].size() != ((BigInteger)localVector2.elementAt(i)).intValue())
        {
          if (this.debug) {
            System.out.println("Prime is " + localVector2.elementAt(i) + ", lookup table has size " + localVector3.size());
          }
          throw new InvalidCipherTextException("Error in lookup Array for " + ((BigInteger)localVector2.elementAt(i)).intValue() + ": Size mismatch. Expected ArrayList with length " + ((BigInteger)localVector2.elementAt(i)).intValue() + " but found ArrayList of length " + this.lookup[i].size());
        }
        int j = localVector3.indexOf(localBigInteger3);
        if (j == -1)
        {
          if (this.debug)
          {
            System.out.println("Actual prime is " + localVector2.elementAt(i));
            System.out.println("Decrypted value is " + localBigInteger3);
            System.out.println("LookupList for " + localVector2.elementAt(i) + " with size " + this.lookup[i].size() + " is: ");
            for (int k = 0; k < this.lookup[i].size(); k++) {
              System.out.println(this.lookup[i].elementAt(k));
            }
          }
          throw new InvalidCipherTextException("Lookup failed");
        }
        localVector1.addElement(BigInteger.valueOf(j));
      }
      BigInteger localBigInteger2 = chineseRemainder(localVector1, localVector2);
      arrayOfByte2 = localBigInteger2.toByteArray();
    }
    return arrayOfByte2;
  }
  
  public byte[] encrypt(BigInteger paramBigInteger)
  {
    byte[] arrayOfByte1 = this.key.getModulus().toByteArray();
    Arrays.fill(arrayOfByte1, (byte)0);
    byte[] arrayOfByte2 = this.key.getG().modPow(paramBigInteger, this.key.getModulus()).toByteArray();
    System.arraycopy(arrayOfByte2, 0, arrayOfByte1, arrayOfByte1.length - arrayOfByte2.length, arrayOfByte2.length);
    if (this.debug) {
      System.out.println("Encrypted value is:  " + new BigInteger(arrayOfByte1));
    }
    return arrayOfByte1;
  }
  
  public byte[] addCryptedBlocks(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws InvalidCipherTextException
  {
    if (this.forEncryption)
    {
      if ((paramArrayOfByte1.length > getOutputBlockSize()) || (paramArrayOfByte2.length > getOutputBlockSize())) {
        throw new InvalidCipherTextException("BlockLength too large for simple addition.\n");
      }
    }
    else if ((paramArrayOfByte1.length > getInputBlockSize()) || (paramArrayOfByte2.length > getInputBlockSize())) {
      throw new InvalidCipherTextException("BlockLength too large for simple addition.\n");
    }
    BigInteger localBigInteger1 = new BigInteger(1, paramArrayOfByte1);
    BigInteger localBigInteger2 = new BigInteger(1, paramArrayOfByte2);
    BigInteger localBigInteger3 = localBigInteger1.multiply(localBigInteger2);
    localBigInteger3 = localBigInteger3.mod(this.key.getModulus());
    if (this.debug)
    {
      System.out.println("c(m1) as BigInteger:....... " + localBigInteger1);
      System.out.println("c(m2) as BigInteger:....... " + localBigInteger2);
      System.out.println("c(m1)*c(m2)%n = c(m1+m2)%n: " + localBigInteger3);
    }
    byte[] arrayOfByte = this.key.getModulus().toByteArray();
    Arrays.fill(arrayOfByte, (byte)0);
    System.arraycopy(localBigInteger3.toByteArray(), 0, arrayOfByte, arrayOfByte.length - localBigInteger3.toByteArray().length, localBigInteger3.toByteArray().length);
    return arrayOfByte;
  }
  
  public byte[] processData(byte[] paramArrayOfByte)
    throws InvalidCipherTextException
  {
    if (this.debug) {
      System.out.println();
    }
    if (paramArrayOfByte.length > getInputBlockSize())
    {
      int i = getInputBlockSize();
      int j = getOutputBlockSize();
      if (this.debug)
      {
        System.out.println("Input blocksize is:  " + i + " bytes");
        System.out.println("Output blocksize is: " + j + " bytes");
        System.out.println("Data has length:.... " + paramArrayOfByte.length + " bytes");
      }
      int k = 0;
      int m = 0;
      byte[] arrayOfByte1 = new byte[(paramArrayOfByte.length / i + 1) * j];
      while (k < paramArrayOfByte.length)
      {
        if (k + i < paramArrayOfByte.length)
        {
          arrayOfByte2 = processBlock(paramArrayOfByte, k, i);
          k += i;
        }
        else
        {
          arrayOfByte2 = processBlock(paramArrayOfByte, k, paramArrayOfByte.length - k);
          k += paramArrayOfByte.length - k;
        }
        if (this.debug) {
          System.out.println("new datapos is " + k);
        }
        if (arrayOfByte2 != null)
        {
          System.arraycopy(arrayOfByte2, 0, arrayOfByte1, m, arrayOfByte2.length);
          m += arrayOfByte2.length;
        }
        else
        {
          if (this.debug) {
            System.out.println("cipher returned null");
          }
          throw new InvalidCipherTextException("cipher returned null");
        }
      }
      byte[] arrayOfByte2 = new byte[m];
      System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, m);
      if (this.debug) {
        System.out.println("returning " + arrayOfByte2.length + " bytes");
      }
      return arrayOfByte2;
    }
    if (this.debug) {
      System.out.println("data size is less then input block size, processing directly");
    }
    return processBlock(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  private static BigInteger chineseRemainder(Vector paramVector1, Vector paramVector2)
  {
    BigInteger localBigInteger1 = ZERO;
    BigInteger localBigInteger2 = ONE;
    for (int i = 0; i < paramVector2.size(); i++) {
      localBigInteger2 = localBigInteger2.multiply((BigInteger)paramVector2.elementAt(i));
    }
    for (i = 0; i < paramVector2.size(); i++)
    {
      BigInteger localBigInteger3 = (BigInteger)paramVector2.elementAt(i);
      BigInteger localBigInteger4 = localBigInteger2.divide(localBigInteger3);
      BigInteger localBigInteger5 = localBigInteger4.modInverse(localBigInteger3);
      BigInteger localBigInteger6 = localBigInteger4.multiply(localBigInteger5);
      localBigInteger6 = localBigInteger6.multiply((BigInteger)paramVector1.elementAt(i));
      localBigInteger1 = localBigInteger1.add(localBigInteger6);
    }
    return localBigInteger1.mod(localBigInteger2);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\engines\NaccacheSternEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */