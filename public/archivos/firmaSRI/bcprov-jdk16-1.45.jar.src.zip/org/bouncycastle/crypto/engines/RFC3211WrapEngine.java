package org.bouncycastle.crypto.engines;

import java.security.SecureRandom;
import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.InvalidCipherTextException;
import org.bouncycastle.crypto.Wrapper;
import org.bouncycastle.crypto.modes.CBCBlockCipher;
import org.bouncycastle.crypto.params.ParametersWithIV;
import org.bouncycastle.crypto.params.ParametersWithRandom;

public class RFC3211WrapEngine
  implements Wrapper
{
  private CBCBlockCipher engine;
  private ParametersWithIV param;
  private boolean forWrapping;
  private SecureRandom rand;
  
  public RFC3211WrapEngine(BlockCipher paramBlockCipher)
  {
    this.engine = new CBCBlockCipher(paramBlockCipher);
  }
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
  {
    this.forWrapping = paramBoolean;
    if ((paramCipherParameters instanceof ParametersWithRandom))
    {
      ParametersWithRandom localParametersWithRandom = (ParametersWithRandom)paramCipherParameters;
      this.rand = localParametersWithRandom.getRandom();
      this.param = ((ParametersWithIV)localParametersWithRandom.getParameters());
    }
    else
    {
      if (paramBoolean) {
        this.rand = new SecureRandom();
      }
      this.param = ((ParametersWithIV)paramCipherParameters);
    }
  }
  
  public String getAlgorithmName()
  {
    return this.engine.getUnderlyingCipher().getAlgorithmName() + "/RFC3211Wrap";
  }
  
  public byte[] wrap(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    if (!this.forWrapping) {
      throw new IllegalStateException("not set for wrapping");
    }
    this.engine.init(true, this.param);
    int i = this.engine.getBlockSize();
    byte[] arrayOfByte;
    if (paramInt2 + 4 < i * 2) {
      arrayOfByte = new byte[i * 2];
    } else {
      arrayOfByte = new byte[(paramInt2 + 4) % i == 0 ? paramInt2 + 4 : ((paramInt2 + 4) / i + 1) * i];
    }
    arrayOfByte[0] = ((byte)paramInt2);
    arrayOfByte[1] = ((byte)(paramArrayOfByte[paramInt1] ^ 0xFFFFFFFF));
    arrayOfByte[2] = ((byte)(paramArrayOfByte[(paramInt1 + 1)] ^ 0xFFFFFFFF));
    arrayOfByte[3] = ((byte)(paramArrayOfByte[(paramInt1 + 2)] ^ 0xFFFFFFFF));
    System.arraycopy(paramArrayOfByte, paramInt1, arrayOfByte, 4, paramInt2);
    for (int j = paramInt2 + 4; j < arrayOfByte.length; j++) {
      arrayOfByte[j] = ((byte)this.rand.nextInt());
    }
    j = 0;
    while (j < arrayOfByte.length)
    {
      this.engine.processBlock(arrayOfByte, j, arrayOfByte, j);
      j += i;
    }
    j = 0;
    while (j < arrayOfByte.length)
    {
      this.engine.processBlock(arrayOfByte, j, arrayOfByte, j);
      j += i;
    }
    return arrayOfByte;
  }
  
  public byte[] unwrap(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws InvalidCipherTextException
  {
    if (this.forWrapping) {
      throw new IllegalStateException("not set for unwrapping");
    }
    int i = this.engine.getBlockSize();
    if (paramInt2 < 2 * i) {
      throw new InvalidCipherTextException("input too short");
    }
    byte[] arrayOfByte1 = new byte[paramInt2];
    byte[] arrayOfByte2 = new byte[i];
    System.arraycopy(paramArrayOfByte, paramInt1, arrayOfByte1, 0, paramInt2);
    System.arraycopy(paramArrayOfByte, paramInt1, arrayOfByte2, 0, arrayOfByte2.length);
    this.engine.init(false, new ParametersWithIV(this.param.getParameters(), arrayOfByte2));
    int j = i;
    while (j < arrayOfByte1.length)
    {
      this.engine.processBlock(arrayOfByte1, j, arrayOfByte1, j);
      j += i;
    }
    System.arraycopy(arrayOfByte1, arrayOfByte1.length - arrayOfByte2.length, arrayOfByte2, 0, arrayOfByte2.length);
    this.engine.init(false, new ParametersWithIV(this.param.getParameters(), arrayOfByte2));
    this.engine.processBlock(arrayOfByte1, 0, arrayOfByte1, 0);
    this.engine.init(false, this.param);
    j = 0;
    while (j < arrayOfByte1.length)
    {
      this.engine.processBlock(arrayOfByte1, j, arrayOfByte1, j);
      j += i;
    }
    if ((arrayOfByte1[0] & 0xFF) > arrayOfByte1.length - 4) {
      throw new InvalidCipherTextException("wrapped key corrupted");
    }
    byte[] arrayOfByte3 = new byte[arrayOfByte1[0] & 0xFF];
    System.arraycopy(arrayOfByte1, 4, arrayOfByte3, 0, arrayOfByte1[0]);
    int k = 0;
    for (int m = 0; m != 3; m++)
    {
      int n = (byte)(arrayOfByte1[(1 + m)] ^ 0xFFFFFFFF);
      k |= n ^ arrayOfByte3[m];
    }
    if (k != 0) {
      throw new InvalidCipherTextException("wrapped key fails checksum");
    }
    return arrayOfByte3;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\engines\RFC3211WrapEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */