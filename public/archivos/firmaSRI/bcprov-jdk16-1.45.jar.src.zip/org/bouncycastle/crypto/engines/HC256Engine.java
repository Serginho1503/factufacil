package org.bouncycastle.crypto.engines;

import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.StreamCipher;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.crypto.params.ParametersWithIV;

public class HC256Engine
  implements StreamCipher
{
  private int[] p = new int['Ѐ'];
  private int[] q = new int['Ѐ'];
  private int cnt = 0;
  private byte[] key;
  private byte[] iv;
  private boolean initialised;
  private byte[] buf = new byte[4];
  private int idx = 0;
  
  private int step()
  {
    int i = this.cnt & 0x3FF;
    int k;
    int m;
    int j;
    if (this.cnt < 1024)
    {
      k = this.p[(i - 3 & 0x3FF)];
      m = this.p[(i - 1023 & 0x3FF)];
      this.p[i] += this.p[(i - 10 & 0x3FF)] + (rotateRight(k, 10) ^ rotateRight(m, 23)) + this.q[((k ^ m) & 0x3FF)];
      k = this.p[(i - 12 & 0x3FF)];
      j = this.q[(k & 0xFF)] + this.q[((k >> 8 & 0xFF) + 256)] + this.q[((k >> 16 & 0xFF) + 512)] + this.q[((k >> 24 & 0xFF) + 768)] ^ this.p[i];
    }
    else
    {
      k = this.q[(i - 3 & 0x3FF)];
      m = this.q[(i - 1023 & 0x3FF)];
      this.q[i] += this.q[(i - 10 & 0x3FF)] + (rotateRight(k, 10) ^ rotateRight(m, 23)) + this.p[((k ^ m) & 0x3FF)];
      k = this.q[(i - 12 & 0x3FF)];
      j = this.p[(k & 0xFF)] + this.p[((k >> 8 & 0xFF) + 256)] + this.p[((k >> 16 & 0xFF) + 512)] + this.p[((k >> 24 & 0xFF) + 768)] ^ this.q[i];
    }
    this.cnt = (this.cnt + 1 & 0x7FF);
    return j;
  }
  
  private void init()
  {
    if ((this.key.length != 32) && (this.key.length != 16)) {
      throw new IllegalArgumentException("The key must be 128/256 bits long");
    }
    if (this.iv.length < 16) {
      throw new IllegalArgumentException("The IV must be at least 128 bits long");
    }
    if (this.key.length != 32)
    {
      localObject = new byte[32];
      System.arraycopy(this.key, 0, localObject, 0, this.key.length);
      System.arraycopy(this.key, 0, localObject, 16, this.key.length);
      this.key = ((byte[])localObject);
    }
    if (this.iv.length < 32)
    {
      localObject = new byte[32];
      System.arraycopy(this.iv, 0, localObject, 0, this.iv.length);
      System.arraycopy(this.iv, 0, localObject, this.iv.length, localObject.length - this.iv.length);
      this.iv = ((byte[])localObject);
    }
    this.cnt = 0;
    Object localObject = new int['਀'];
    for (int i = 0; i < 32; i++) {
      localObject[(i >> 2)] |= (this.key[i] & 0xFF) << 8 * (i & 0x3);
    }
    for (i = 0; i < 32; i++) {
      localObject[((i >> 2) + 8)] |= (this.iv[i] & 0xFF) << 8 * (i & 0x3);
    }
    for (i = 16; i < 2560; i++)
    {
      int j = localObject[(i - 2)];
      int k = localObject[(i - 15)];
      localObject[i] = ((rotateRight(j, 17) ^ rotateRight(j, 19) ^ j >>> 10) + localObject[(i - 7)] + (rotateRight(k, 7) ^ rotateRight(k, 18) ^ k >>> 3) + localObject[(i - 16)] + i);
    }
    System.arraycopy(localObject, 512, this.p, 0, 1024);
    System.arraycopy(localObject, 1536, this.q, 0, 1024);
    for (i = 0; i < 4096; i++) {
      step();
    }
    this.cnt = 0;
  }
  
  public String getAlgorithmName()
  {
    return "HC-256";
  }
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
    throws IllegalArgumentException
  {
    CipherParameters localCipherParameters = paramCipherParameters;
    if ((paramCipherParameters instanceof ParametersWithIV))
    {
      this.iv = ((ParametersWithIV)paramCipherParameters).getIV();
      localCipherParameters = ((ParametersWithIV)paramCipherParameters).getParameters();
    }
    else
    {
      this.iv = new byte[0];
    }
    if ((localCipherParameters instanceof KeyParameter))
    {
      this.key = ((KeyParameter)localCipherParameters).getKey();
      init();
    }
    else
    {
      throw new IllegalArgumentException("Invalid parameter passed to HC256 init - " + paramCipherParameters.getClass().getName());
    }
    this.initialised = true;
  }
  
  private byte getByte()
  {
    if (this.idx == 0)
    {
      i = step();
      this.buf[0] = ((byte)(i & 0xFF));
      i >>= 8;
      this.buf[1] = ((byte)(i & 0xFF));
      i >>= 8;
      this.buf[2] = ((byte)(i & 0xFF));
      i >>= 8;
      this.buf[3] = ((byte)(i & 0xFF));
    }
    int i = this.buf[this.idx];
    this.idx = (this.idx + 1 & 0x3);
    return i;
  }
  
  public void processBytes(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
    throws DataLengthException
  {
    if (!this.initialised) {
      throw new IllegalStateException(getAlgorithmName() + " not initialised");
    }
    if (paramInt1 + paramInt2 > paramArrayOfByte1.length) {
      throw new DataLengthException("input buffer too short");
    }
    if (paramInt3 + paramInt2 > paramArrayOfByte2.length) {
      throw new DataLengthException("output buffer too short");
    }
    for (int i = 0; i < paramInt2; i++) {
      paramArrayOfByte2[(paramInt3 + i)] = ((byte)(paramArrayOfByte1[(paramInt1 + i)] ^ getByte()));
    }
  }
  
  public void reset()
  {
    this.idx = 0;
    init();
  }
  
  public byte returnByte(byte paramByte)
  {
    return (byte)(paramByte ^ getByte());
  }
  
  private static int rotateRight(int paramInt1, int paramInt2)
  {
    return paramInt1 >>> paramInt2 | paramInt1 << -paramInt2;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\engines\HC256Engine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */