package org.bouncycastle.crypto.engines;

import java.math.BigInteger;
import org.bouncycastle.crypto.AsymmetricBlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.params.ParametersWithRandom;
import org.bouncycastle.crypto.params.RSABlindingParameters;
import org.bouncycastle.crypto.params.RSAKeyParameters;

public class RSABlindingEngine
  implements AsymmetricBlockCipher
{
  private RSACoreEngine core = new RSACoreEngine();
  private RSAKeyParameters key;
  private BigInteger blindingFactor;
  private boolean forEncryption;
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
  {
    RSABlindingParameters localRSABlindingParameters;
    if ((paramCipherParameters instanceof ParametersWithRandom))
    {
      ParametersWithRandom localParametersWithRandom = (ParametersWithRandom)paramCipherParameters;
      localRSABlindingParameters = (RSABlindingParameters)localParametersWithRandom.getParameters();
    }
    else
    {
      localRSABlindingParameters = (RSABlindingParameters)paramCipherParameters;
    }
    this.core.init(paramBoolean, localRSABlindingParameters.getPublicKey());
    this.forEncryption = paramBoolean;
    this.key = localRSABlindingParameters.getPublicKey();
    this.blindingFactor = localRSABlindingParameters.getBlindingFactor();
  }
  
  public int getInputBlockSize()
  {
    return this.core.getInputBlockSize();
  }
  
  public int getOutputBlockSize()
  {
    return this.core.getOutputBlockSize();
  }
  
  public byte[] processBlock(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    BigInteger localBigInteger = this.core.convertInput(paramArrayOfByte, paramInt1, paramInt2);
    if (this.forEncryption) {
      localBigInteger = blindMessage(localBigInteger);
    } else {
      localBigInteger = unblindMessage(localBigInteger);
    }
    return this.core.convertOutput(localBigInteger);
  }
  
  private BigInteger blindMessage(BigInteger paramBigInteger)
  {
    BigInteger localBigInteger = this.blindingFactor;
    localBigInteger = paramBigInteger.multiply(localBigInteger.modPow(this.key.getExponent(), this.key.getModulus()));
    localBigInteger = localBigInteger.mod(this.key.getModulus());
    return localBigInteger;
  }
  
  private BigInteger unblindMessage(BigInteger paramBigInteger)
  {
    BigInteger localBigInteger1 = this.key.getModulus();
    BigInteger localBigInteger2 = paramBigInteger;
    BigInteger localBigInteger3 = this.blindingFactor.modInverse(localBigInteger1);
    localBigInteger2 = localBigInteger2.multiply(localBigInteger3);
    localBigInteger2 = localBigInteger2.mod(localBigInteger1);
    return localBigInteger2;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\engines\RSABlindingEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */