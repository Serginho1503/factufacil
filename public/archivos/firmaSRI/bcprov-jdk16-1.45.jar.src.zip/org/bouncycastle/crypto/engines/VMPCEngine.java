package org.bouncycastle.crypto.engines;

import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.StreamCipher;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.crypto.params.ParametersWithIV;

public class VMPCEngine
  implements StreamCipher
{
  protected byte n = 0;
  protected byte[] P = null;
  protected byte s = 0;
  protected byte[] workingIV;
  protected byte[] workingKey;
  
  public String getAlgorithmName()
  {
    return "VMPC";
  }
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
  {
    if (!(paramCipherParameters instanceof ParametersWithIV)) {
      throw new IllegalArgumentException("VMPC init parameters must include an IV");
    }
    ParametersWithIV localParametersWithIV = (ParametersWithIV)paramCipherParameters;
    KeyParameter localKeyParameter = (KeyParameter)localParametersWithIV.getParameters();
    if (!(localParametersWithIV.getParameters() instanceof KeyParameter)) {
      throw new IllegalArgumentException("VMPC init parameters must include a key");
    }
    this.workingIV = localParametersWithIV.getIV();
    if ((this.workingIV == null) || (this.workingIV.length < 1) || (this.workingIV.length > 768)) {
      throw new IllegalArgumentException("VMPC requires 1 to 768 bytes of IV");
    }
    this.workingKey = localKeyParameter.getKey();
    initKey(this.workingKey, this.workingIV);
  }
  
  protected void initKey(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.s = 0;
    this.P = new byte['Ā'];
    for (int i = 0; i < 256; i++) {
      this.P[i] = ((byte)i);
    }
    int j;
    for (i = 0; i < 768; i++)
    {
      this.s = this.P[(this.s + this.P[(i & 0xFF)] + paramArrayOfByte1[(i % paramArrayOfByte1.length)] & 0xFF)];
      j = this.P[(i & 0xFF)];
      this.P[(i & 0xFF)] = this.P[(this.s & 0xFF)];
      this.P[(this.s & 0xFF)] = j;
    }
    for (i = 0; i < 768; i++)
    {
      this.s = this.P[(this.s + this.P[(i & 0xFF)] + paramArrayOfByte2[(i % paramArrayOfByte2.length)] & 0xFF)];
      j = this.P[(i & 0xFF)];
      this.P[(i & 0xFF)] = this.P[(this.s & 0xFF)];
      this.P[(this.s & 0xFF)] = j;
    }
    this.n = 0;
  }
  
  public void processBytes(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    if (paramInt1 + paramInt2 > paramArrayOfByte1.length) {
      throw new DataLengthException("input buffer too short");
    }
    if (paramInt3 + paramInt2 > paramArrayOfByte2.length) {
      throw new DataLengthException("output buffer too short");
    }
    for (int i = 0; i < paramInt2; i++)
    {
      this.s = this.P[(this.s + this.P[(this.n & 0xFF)] & 0xFF)];
      int j = this.P[(this.P[(this.P[(this.s & 0xFF)] & 0xFF)] + 1 & 0xFF)];
      int k = this.P[(this.n & 0xFF)];
      this.P[(this.n & 0xFF)] = this.P[(this.s & 0xFF)];
      this.P[(this.s & 0xFF)] = k;
      this.n = ((byte)(this.n + 1 & 0xFF));
      paramArrayOfByte2[(i + paramInt3)] = ((byte)(paramArrayOfByte1[(i + paramInt1)] ^ j));
    }
  }
  
  public void reset()
  {
    initKey(this.workingKey, this.workingIV);
  }
  
  public byte returnByte(byte paramByte)
  {
    this.s = this.P[(this.s + this.P[(this.n & 0xFF)] & 0xFF)];
    byte b = this.P[(this.P[(this.P[(this.s & 0xFF)] & 0xFF)] + 1 & 0xFF)];
    int i = this.P[(this.n & 0xFF)];
    this.P[(this.n & 0xFF)] = this.P[(this.s & 0xFF)];
    this.P[(this.s & 0xFF)] = i;
    this.n = ((byte)(this.n + 1 & 0xFF));
    return (byte)(paramByte ^ b);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\engines\VMPCEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */