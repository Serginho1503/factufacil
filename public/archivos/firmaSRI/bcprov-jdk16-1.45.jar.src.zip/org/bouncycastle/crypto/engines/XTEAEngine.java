package org.bouncycastle.crypto.engines;

import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.params.KeyParameter;

public class XTEAEngine
  implements BlockCipher
{
  private static final int rounds = 32;
  private static final int block_size = 8;
  private static final int delta = -1640531527;
  private int[] _S = new int[4];
  private int[] _sum0 = new int[32];
  private int[] _sum1 = new int[32];
  private boolean _initialised = false;
  private boolean _forEncryption;
  
  public String getAlgorithmName()
  {
    return "XTEA";
  }
  
  public int getBlockSize()
  {
    return 8;
  }
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
  {
    if (!(paramCipherParameters instanceof KeyParameter)) {
      throw new IllegalArgumentException("invalid parameter passed to TEA init - " + paramCipherParameters.getClass().getName());
    }
    this._forEncryption = paramBoolean;
    this._initialised = true;
    KeyParameter localKeyParameter = (KeyParameter)paramCipherParameters;
    setKey(localKeyParameter.getKey());
  }
  
  public int processBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
  {
    if (!this._initialised) {
      throw new IllegalStateException(getAlgorithmName() + " not initialised");
    }
    if (paramInt1 + 8 > paramArrayOfByte1.length) {
      throw new DataLengthException("input buffer too short");
    }
    if (paramInt2 + 8 > paramArrayOfByte2.length) {
      throw new DataLengthException("output buffer too short");
    }
    return this._forEncryption ? encryptBlock(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2) : decryptBlock(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2);
  }
  
  public void reset() {}
  
  private void setKey(byte[] paramArrayOfByte)
  {
    int j;
    int i = j = 0;
    while (i < 4)
    {
      this._S[i] = bytesToInt(paramArrayOfByte, j);
      i++;
      j += 4;
    }
    for (i = j = 0; i < 32; i++)
    {
      this._sum0[i] = (j + this._S[(j & 0x3)]);
      j -= 1640531527;
      this._sum1[i] = (j + this._S[(j >>> 11 & 0x3)]);
    }
  }
  
  private int encryptBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
  {
    int i = bytesToInt(paramArrayOfByte1, paramInt1);
    int j = bytesToInt(paramArrayOfByte1, paramInt1 + 4);
    for (int k = 0; k < 32; k++)
    {
      i += ((j << 4 ^ j >>> 5) + j ^ this._sum0[k]);
      j += ((i << 4 ^ i >>> 5) + i ^ this._sum1[k]);
    }
    unpackInt(i, paramArrayOfByte2, paramInt2);
    unpackInt(j, paramArrayOfByte2, paramInt2 + 4);
    return 8;
  }
  
  private int decryptBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
  {
    int i = bytesToInt(paramArrayOfByte1, paramInt1);
    int j = bytesToInt(paramArrayOfByte1, paramInt1 + 4);
    for (int k = 31; k >= 0; k--)
    {
      j -= ((i << 4 ^ i >>> 5) + i ^ this._sum1[k]);
      i -= ((j << 4 ^ j >>> 5) + j ^ this._sum0[k]);
    }
    unpackInt(i, paramArrayOfByte2, paramInt2);
    unpackInt(j, paramArrayOfByte2, paramInt2 + 4);
    return 8;
  }
  
  private int bytesToInt(byte[] paramArrayOfByte, int paramInt)
  {
    return paramArrayOfByte[(paramInt++)] << 24 | (paramArrayOfByte[(paramInt++)] & 0xFF) << 16 | (paramArrayOfByte[(paramInt++)] & 0xFF) << 8 | paramArrayOfByte[paramInt] & 0xFF;
  }
  
  private void unpackInt(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
  {
    paramArrayOfByte[(paramInt2++)] = ((byte)(paramInt1 >>> 24));
    paramArrayOfByte[(paramInt2++)] = ((byte)(paramInt1 >>> 16));
    paramArrayOfByte[(paramInt2++)] = ((byte)(paramInt1 >>> 8));
    paramArrayOfByte[paramInt2] = ((byte)paramInt1);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\engines\XTEAEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */