package org.bouncycastle.crypto.engines;

public class SEEDWrapEngine
  extends RFC3394WrapEngine
{
  public SEEDWrapEngine()
  {
    super(new SEEDEngine());
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\engines\SEEDWrapEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */