package org.bouncycastle.crypto.engines;

import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.StreamCipher;
import org.bouncycastle.crypto.params.KeyParameter;

public class RC4Engine
  implements StreamCipher
{
  private static final int STATE_LENGTH = 256;
  private byte[] engineState = null;
  private int x = 0;
  private int y = 0;
  private byte[] workingKey = null;
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
  {
    if ((paramCipherParameters instanceof KeyParameter))
    {
      this.workingKey = ((KeyParameter)paramCipherParameters).getKey();
      setKey(this.workingKey);
      return;
    }
    throw new IllegalArgumentException("invalid parameter passed to RC4 init - " + paramCipherParameters.getClass().getName());
  }
  
  public String getAlgorithmName()
  {
    return "RC4";
  }
  
  public byte returnByte(byte paramByte)
  {
    this.x = (this.x + 1 & 0xFF);
    this.y = (this.engineState[this.x] + this.y & 0xFF);
    int i = this.engineState[this.x];
    this.engineState[this.x] = this.engineState[this.y];
    this.engineState[this.y] = i;
    return (byte)(paramByte ^ this.engineState[(this.engineState[this.x] + this.engineState[this.y] & 0xFF)]);
  }
  
  public void processBytes(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    if (paramInt1 + paramInt2 > paramArrayOfByte1.length) {
      throw new DataLengthException("input buffer too short");
    }
    if (paramInt3 + paramInt2 > paramArrayOfByte2.length) {
      throw new DataLengthException("output buffer too short");
    }
    for (int i = 0; i < paramInt2; i++)
    {
      this.x = (this.x + 1 & 0xFF);
      this.y = (this.engineState[this.x] + this.y & 0xFF);
      int j = this.engineState[this.x];
      this.engineState[this.x] = this.engineState[this.y];
      this.engineState[this.y] = j;
      paramArrayOfByte2[(i + paramInt3)] = ((byte)(paramArrayOfByte1[(i + paramInt1)] ^ this.engineState[(this.engineState[this.x] + this.engineState[this.y] & 0xFF)]));
    }
  }
  
  public void reset()
  {
    setKey(this.workingKey);
  }
  
  private void setKey(byte[] paramArrayOfByte)
  {
    this.workingKey = paramArrayOfByte;
    this.x = 0;
    this.y = 0;
    if (this.engineState == null) {
      this.engineState = new byte['Ā'];
    }
    for (int i = 0; i < 256; i++) {
      this.engineState[i] = ((byte)i);
    }
    i = 0;
    int j = 0;
    for (int k = 0; k < 256; k++)
    {
      j = (paramArrayOfByte[i] & 0xFF) + this.engineState[k] + j & 0xFF;
      int m = this.engineState[k];
      this.engineState[k] = this.engineState[j];
      this.engineState[j] = m;
      i = (i + 1) % paramArrayOfByte.length;
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\engines\RC4Engine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */