package org.bouncycastle.crypto.engines;

public class CamelliaWrapEngine
  extends RFC3394WrapEngine
{
  public CamelliaWrapEngine()
  {
    super(new CamelliaEngine());
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\engines\CamelliaWrapEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */