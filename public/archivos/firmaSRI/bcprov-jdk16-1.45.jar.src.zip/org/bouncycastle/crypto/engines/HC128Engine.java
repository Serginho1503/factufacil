package org.bouncycastle.crypto.engines;

import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.StreamCipher;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.crypto.params.ParametersWithIV;

public class HC128Engine
  implements StreamCipher
{
  private int[] p = new int['Ȁ'];
  private int[] q = new int['Ȁ'];
  private int cnt = 0;
  private byte[] key;
  private byte[] iv;
  private boolean initialised;
  private byte[] buf = new byte[4];
  private int idx = 0;
  
  private static int f1(int paramInt)
  {
    return rotateRight(paramInt, 7) ^ rotateRight(paramInt, 18) ^ paramInt >>> 3;
  }
  
  private static int f2(int paramInt)
  {
    return rotateRight(paramInt, 17) ^ rotateRight(paramInt, 19) ^ paramInt >>> 10;
  }
  
  private int g1(int paramInt1, int paramInt2, int paramInt3)
  {
    return (rotateRight(paramInt1, 10) ^ rotateRight(paramInt3, 23)) + rotateRight(paramInt2, 8);
  }
  
  private int g2(int paramInt1, int paramInt2, int paramInt3)
  {
    return (rotateLeft(paramInt1, 10) ^ rotateLeft(paramInt3, 23)) + rotateLeft(paramInt2, 8);
  }
  
  private static int rotateLeft(int paramInt1, int paramInt2)
  {
    return paramInt1 << paramInt2 | paramInt1 >>> -paramInt2;
  }
  
  private static int rotateRight(int paramInt1, int paramInt2)
  {
    return paramInt1 >>> paramInt2 | paramInt1 << -paramInt2;
  }
  
  private int h1(int paramInt)
  {
    return this.q[(paramInt & 0xFF)] + this.q[((paramInt >> 16 & 0xFF) + 256)];
  }
  
  private int h2(int paramInt)
  {
    return this.p[(paramInt & 0xFF)] + this.p[((paramInt >> 16 & 0xFF) + 256)];
  }
  
  private static int mod1024(int paramInt)
  {
    return paramInt & 0x3FF;
  }
  
  private static int mod512(int paramInt)
  {
    return paramInt & 0x1FF;
  }
  
  private static int dim(int paramInt1, int paramInt2)
  {
    return mod512(paramInt1 - paramInt2);
  }
  
  private int step()
  {
    int i = mod512(this.cnt);
    int j;
    if (this.cnt < 512)
    {
      this.p[i] += g1(this.p[dim(i, 3)], this.p[dim(i, 10)], this.p[dim(i, 511)]);
      j = h1(this.p[dim(i, 12)]) ^ this.p[i];
    }
    else
    {
      this.q[i] += g2(this.q[dim(i, 3)], this.q[dim(i, 10)], this.q[dim(i, 511)]);
      j = h2(this.q[dim(i, 12)]) ^ this.q[i];
    }
    this.cnt = mod1024(this.cnt + 1);
    return j;
  }
  
  private void init()
  {
    if (this.key.length != 16) {
      throw new IllegalArgumentException("The key must be 128 bits long");
    }
    this.cnt = 0;
    int[] arrayOfInt = new int['Ԁ'];
    for (int i = 0; i < 16; i++) {
      arrayOfInt[(i >> 2)] |= (this.key[i] & 0xFF) << 8 * (i & 0x3);
    }
    System.arraycopy(arrayOfInt, 0, arrayOfInt, 4, 4);
    for (i = 0; (i < this.iv.length) && (i < 16); i++) {
      arrayOfInt[((i >> 2) + 8)] |= (this.iv[i] & 0xFF) << 8 * (i & 0x3);
    }
    System.arraycopy(arrayOfInt, 8, arrayOfInt, 12, 4);
    for (i = 16; i < 1280; i++) {
      arrayOfInt[i] = (f2(arrayOfInt[(i - 2)]) + arrayOfInt[(i - 7)] + f1(arrayOfInt[(i - 15)]) + arrayOfInt[(i - 16)] + i);
    }
    System.arraycopy(arrayOfInt, 256, this.p, 0, 512);
    System.arraycopy(arrayOfInt, 768, this.q, 0, 512);
    for (i = 0; i < 512; i++) {
      this.p[i] = step();
    }
    for (i = 0; i < 512; i++) {
      this.q[i] = step();
    }
    this.cnt = 0;
  }
  
  public String getAlgorithmName()
  {
    return "HC-128";
  }
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
    throws IllegalArgumentException
  {
    CipherParameters localCipherParameters = paramCipherParameters;
    if ((paramCipherParameters instanceof ParametersWithIV))
    {
      this.iv = ((ParametersWithIV)paramCipherParameters).getIV();
      localCipherParameters = ((ParametersWithIV)paramCipherParameters).getParameters();
    }
    else
    {
      this.iv = new byte[0];
    }
    if ((localCipherParameters instanceof KeyParameter))
    {
      this.key = ((KeyParameter)localCipherParameters).getKey();
      init();
    }
    else
    {
      throw new IllegalArgumentException("Invalid parameter passed to HC128 init - " + paramCipherParameters.getClass().getName());
    }
    this.initialised = true;
  }
  
  private byte getByte()
  {
    if (this.idx == 0)
    {
      i = step();
      this.buf[0] = ((byte)(i & 0xFF));
      i >>= 8;
      this.buf[1] = ((byte)(i & 0xFF));
      i >>= 8;
      this.buf[2] = ((byte)(i & 0xFF));
      i >>= 8;
      this.buf[3] = ((byte)(i & 0xFF));
    }
    int i = this.buf[this.idx];
    this.idx = (this.idx + 1 & 0x3);
    return i;
  }
  
  public void processBytes(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
    throws DataLengthException
  {
    if (!this.initialised) {
      throw new IllegalStateException(getAlgorithmName() + " not initialised");
    }
    if (paramInt1 + paramInt2 > paramArrayOfByte1.length) {
      throw new DataLengthException("input buffer too short");
    }
    if (paramInt3 + paramInt2 > paramArrayOfByte2.length) {
      throw new DataLengthException("output buffer too short");
    }
    for (int i = 0; i < paramInt2; i++) {
      paramArrayOfByte2[(paramInt3 + i)] = ((byte)(paramArrayOfByte1[(paramInt1 + i)] ^ getByte()));
    }
  }
  
  public void reset()
  {
    this.idx = 0;
    init();
  }
  
  public byte returnByte(byte paramByte)
  {
    return (byte)(paramByte ^ getByte());
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\engines\HC128Engine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */