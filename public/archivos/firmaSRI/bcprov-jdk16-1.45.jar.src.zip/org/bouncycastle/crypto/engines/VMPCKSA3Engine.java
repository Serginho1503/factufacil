package org.bouncycastle.crypto.engines;

public class VMPCKSA3Engine
  extends VMPCEngine
{
  public String getAlgorithmName()
  {
    return "VMPC-KSA3";
  }
  
  protected void initKey(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.s = 0;
    this.P = new byte['Ā'];
    for (int i = 0; i < 256; i++) {
      this.P[i] = ((byte)i);
    }
    int j;
    for (i = 0; i < 768; i++)
    {
      this.s = this.P[(this.s + this.P[(i & 0xFF)] + paramArrayOfByte1[(i % paramArrayOfByte1.length)] & 0xFF)];
      j = this.P[(i & 0xFF)];
      this.P[(i & 0xFF)] = this.P[(this.s & 0xFF)];
      this.P[(this.s & 0xFF)] = j;
    }
    for (i = 0; i < 768; i++)
    {
      this.s = this.P[(this.s + this.P[(i & 0xFF)] + paramArrayOfByte2[(i % paramArrayOfByte2.length)] & 0xFF)];
      j = this.P[(i & 0xFF)];
      this.P[(i & 0xFF)] = this.P[(this.s & 0xFF)];
      this.P[(this.s & 0xFF)] = j;
    }
    for (i = 0; i < 768; i++)
    {
      this.s = this.P[(this.s + this.P[(i & 0xFF)] + paramArrayOfByte1[(i % paramArrayOfByte1.length)] & 0xFF)];
      j = this.P[(i & 0xFF)];
      this.P[(i & 0xFF)] = this.P[(this.s & 0xFF)];
      this.P[(this.s & 0xFF)] = j;
    }
    this.n = 0;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\engines\VMPCKSA3Engine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */