package org.bouncycastle.crypto.encodings;

import java.security.SecureRandom;
import org.bouncycastle.crypto.AsymmetricBlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.Digest;
import org.bouncycastle.crypto.InvalidCipherTextException;
import org.bouncycastle.crypto.digests.SHA1Digest;
import org.bouncycastle.crypto.params.ParametersWithRandom;

public class OAEPEncoding
  implements AsymmetricBlockCipher
{
  private byte[] defHash;
  private Digest hash;
  private Digest mgf1Hash;
  private AsymmetricBlockCipher engine;
  private SecureRandom random;
  private boolean forEncryption;
  
  public OAEPEncoding(AsymmetricBlockCipher paramAsymmetricBlockCipher)
  {
    this(paramAsymmetricBlockCipher, new SHA1Digest(), null);
  }
  
  public OAEPEncoding(AsymmetricBlockCipher paramAsymmetricBlockCipher, Digest paramDigest)
  {
    this(paramAsymmetricBlockCipher, paramDigest, null);
  }
  
  public OAEPEncoding(AsymmetricBlockCipher paramAsymmetricBlockCipher, Digest paramDigest, byte[] paramArrayOfByte)
  {
    this(paramAsymmetricBlockCipher, paramDigest, paramDigest, paramArrayOfByte);
  }
  
  public OAEPEncoding(AsymmetricBlockCipher paramAsymmetricBlockCipher, Digest paramDigest1, Digest paramDigest2, byte[] paramArrayOfByte)
  {
    this.engine = paramAsymmetricBlockCipher;
    this.hash = paramDigest1;
    this.mgf1Hash = paramDigest2;
    this.defHash = new byte[paramDigest1.getDigestSize()];
    if (paramArrayOfByte != null) {
      paramDigest1.update(paramArrayOfByte, 0, paramArrayOfByte.length);
    }
    paramDigest1.doFinal(this.defHash, 0);
  }
  
  public AsymmetricBlockCipher getUnderlyingCipher()
  {
    return this.engine;
  }
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
  {
    if ((paramCipherParameters instanceof ParametersWithRandom))
    {
      ParametersWithRandom localParametersWithRandom = (ParametersWithRandom)paramCipherParameters;
      this.random = localParametersWithRandom.getRandom();
    }
    else
    {
      this.random = new SecureRandom();
    }
    this.engine.init(paramBoolean, paramCipherParameters);
    this.forEncryption = paramBoolean;
  }
  
  public int getInputBlockSize()
  {
    int i = this.engine.getInputBlockSize();
    if (this.forEncryption) {
      return i - 1 - 2 * this.defHash.length;
    }
    return i;
  }
  
  public int getOutputBlockSize()
  {
    int i = this.engine.getOutputBlockSize();
    if (this.forEncryption) {
      return i;
    }
    return i - 1 - 2 * this.defHash.length;
  }
  
  public byte[] processBlock(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws InvalidCipherTextException
  {
    if (this.forEncryption) {
      return encodeBlock(paramArrayOfByte, paramInt1, paramInt2);
    }
    return decodeBlock(paramArrayOfByte, paramInt1, paramInt2);
  }
  
  public byte[] encodeBlock(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws InvalidCipherTextException
  {
    byte[] arrayOfByte1 = new byte[getInputBlockSize() + 1 + 2 * this.defHash.length];
    System.arraycopy(paramArrayOfByte, paramInt1, arrayOfByte1, arrayOfByte1.length - paramInt2, paramInt2);
    arrayOfByte1[(arrayOfByte1.length - paramInt2 - 1)] = 1;
    System.arraycopy(this.defHash, 0, arrayOfByte1, this.defHash.length, this.defHash.length);
    byte[] arrayOfByte2 = new byte[this.defHash.length];
    this.random.nextBytes(arrayOfByte2);
    byte[] arrayOfByte3 = maskGeneratorFunction1(arrayOfByte2, 0, arrayOfByte2.length, arrayOfByte1.length - this.defHash.length);
    for (int i = this.defHash.length; i != arrayOfByte1.length; i++)
    {
      int tmp120_118 = i;
      byte[] tmp120_116 = arrayOfByte1;
      tmp120_116[tmp120_118] = ((byte)(tmp120_116[tmp120_118] ^ arrayOfByte3[(i - this.defHash.length)]));
    }
    System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 0, this.defHash.length);
    arrayOfByte3 = maskGeneratorFunction1(arrayOfByte1, this.defHash.length, arrayOfByte1.length - this.defHash.length, this.defHash.length);
    for (i = 0; i != this.defHash.length; i++)
    {
      int tmp200_198 = i;
      byte[] tmp200_196 = arrayOfByte1;
      tmp200_196[tmp200_198] = ((byte)(tmp200_196[tmp200_198] ^ arrayOfByte3[i]));
    }
    return this.engine.processBlock(arrayOfByte1, 0, arrayOfByte1.length);
  }
  
  public byte[] decodeBlock(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws InvalidCipherTextException
  {
    byte[] arrayOfByte1 = this.engine.processBlock(paramArrayOfByte, paramInt1, paramInt2);
    byte[] arrayOfByte2;
    if (arrayOfByte1.length < this.engine.getOutputBlockSize())
    {
      arrayOfByte2 = new byte[this.engine.getOutputBlockSize()];
      System.arraycopy(arrayOfByte1, 0, arrayOfByte2, arrayOfByte2.length - arrayOfByte1.length, arrayOfByte1.length);
    }
    else
    {
      arrayOfByte2 = arrayOfByte1;
    }
    if (arrayOfByte2.length < 2 * this.defHash.length + 1) {
      throw new InvalidCipherTextException("data too short");
    }
    byte[] arrayOfByte3 = maskGeneratorFunction1(arrayOfByte2, this.defHash.length, arrayOfByte2.length - this.defHash.length, this.defHash.length);
    for (int i = 0; i != this.defHash.length; i++)
    {
      int tmp136_134 = i;
      byte[] tmp136_132 = arrayOfByte2;
      tmp136_132[tmp136_134] = ((byte)(tmp136_132[tmp136_134] ^ arrayOfByte3[i]));
    }
    arrayOfByte3 = maskGeneratorFunction1(arrayOfByte2, 0, this.defHash.length, arrayOfByte2.length - this.defHash.length);
    for (i = this.defHash.length; i != arrayOfByte2.length; i++)
    {
      int tmp194_192 = i;
      byte[] tmp194_190 = arrayOfByte2;
      tmp194_190[tmp194_192] = ((byte)(tmp194_190[tmp194_192] ^ arrayOfByte3[(i - this.defHash.length)]));
    }
    for (i = 0; i != this.defHash.length; i++) {
      if (this.defHash[i] != arrayOfByte2[(this.defHash.length + i)]) {
        throw new InvalidCipherTextException("data hash wrong");
      }
    }
    for (i = 2 * this.defHash.length; (i != arrayOfByte2.length) && (arrayOfByte2[i] == 0); i++) {}
    if ((i >= arrayOfByte2.length - 1) || (arrayOfByte2[i] != 1)) {
      throw new InvalidCipherTextException("data start wrong " + i);
    }
    i++;
    byte[] arrayOfByte4 = new byte[arrayOfByte2.length - i];
    System.arraycopy(arrayOfByte2, i, arrayOfByte4, 0, arrayOfByte4.length);
    return arrayOfByte4;
  }
  
  private void ItoOSP(int paramInt, byte[] paramArrayOfByte)
  {
    paramArrayOfByte[0] = ((byte)(paramInt >>> 24));
    paramArrayOfByte[1] = ((byte)(paramInt >>> 16));
    paramArrayOfByte[2] = ((byte)(paramInt >>> 8));
    paramArrayOfByte[3] = ((byte)(paramInt >>> 0));
  }
  
  private byte[] maskGeneratorFunction1(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3)
  {
    byte[] arrayOfByte1 = new byte[paramInt3];
    byte[] arrayOfByte2 = new byte[this.mgf1Hash.getDigestSize()];
    byte[] arrayOfByte3 = new byte[4];
    int i = 0;
    this.hash.reset();
    do
    {
      ItoOSP(i, arrayOfByte3);
      this.mgf1Hash.update(paramArrayOfByte, paramInt1, paramInt2);
      this.mgf1Hash.update(arrayOfByte3, 0, arrayOfByte3.length);
      this.mgf1Hash.doFinal(arrayOfByte2, 0);
      System.arraycopy(arrayOfByte2, 0, arrayOfByte1, i * arrayOfByte2.length, arrayOfByte2.length);
      i++;
    } while (i < paramInt3 / arrayOfByte2.length);
    if (i * arrayOfByte2.length < paramInt3)
    {
      ItoOSP(i, arrayOfByte3);
      this.mgf1Hash.update(paramArrayOfByte, paramInt1, paramInt2);
      this.mgf1Hash.update(arrayOfByte3, 0, arrayOfByte3.length);
      this.mgf1Hash.doFinal(arrayOfByte2, 0);
      System.arraycopy(arrayOfByte2, 0, arrayOfByte1, i * arrayOfByte2.length, arrayOfByte1.length - i * arrayOfByte2.length);
    }
    return arrayOfByte1;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\encodings\OAEPEncoding.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */