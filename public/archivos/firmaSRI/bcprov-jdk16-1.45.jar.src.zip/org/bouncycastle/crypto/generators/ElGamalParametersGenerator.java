package org.bouncycastle.crypto.generators;

import java.math.BigInteger;
import java.security.SecureRandom;
import org.bouncycastle.crypto.params.ElGamalParameters;

public class ElGamalParametersGenerator
{
  private int size;
  private int certainty;
  private SecureRandom random;
  
  public void init(int paramInt1, int paramInt2, SecureRandom paramSecureRandom)
  {
    this.size = paramInt1;
    this.certainty = paramInt2;
    this.random = paramSecureRandom;
  }
  
  public ElGamalParameters generateParameters()
  {
    BigInteger[] arrayOfBigInteger = DHParametersHelper.generateSafePrimes(this.size, this.certainty, this.random);
    BigInteger localBigInteger1 = arrayOfBigInteger[0];
    BigInteger localBigInteger2 = arrayOfBigInteger[1];
    BigInteger localBigInteger3 = DHParametersHelper.selectGenerator(localBigInteger1, localBigInteger2, this.random);
    return new ElGamalParameters(localBigInteger1, localBigInteger3);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\generators\ElGamalParametersGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */