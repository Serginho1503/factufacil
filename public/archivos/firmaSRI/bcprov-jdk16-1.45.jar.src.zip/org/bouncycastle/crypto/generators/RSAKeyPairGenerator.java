package org.bouncycastle.crypto.generators;

import java.math.BigInteger;
import org.bouncycastle.crypto.AsymmetricCipherKeyPair;
import org.bouncycastle.crypto.AsymmetricCipherKeyPairGenerator;
import org.bouncycastle.crypto.KeyGenerationParameters;
import org.bouncycastle.crypto.params.RSAKeyGenerationParameters;
import org.bouncycastle.crypto.params.RSAKeyParameters;
import org.bouncycastle.crypto.params.RSAPrivateCrtKeyParameters;

public class RSAKeyPairGenerator
  implements AsymmetricCipherKeyPairGenerator
{
  private static final BigInteger ONE = BigInteger.valueOf(1L);
  private RSAKeyGenerationParameters param;
  
  public void init(KeyGenerationParameters paramKeyGenerationParameters)
  {
    this.param = ((RSAKeyGenerationParameters)paramKeyGenerationParameters);
  }
  
  public AsymmetricCipherKeyPair generateKeyPair()
  {
    int i = this.param.getStrength();
    int j = (i + 1) / 2;
    int k = i - j;
    int m = i / 3;
    BigInteger localBigInteger3 = this.param.getPublicExponent();
    Object localObject1;
    for (;;)
    {
      localObject1 = new BigInteger(j, 1, this.param.getRandom());
      if ((!((BigInteger)localObject1).mod(localBigInteger3).equals(ONE)) && (((BigInteger)localObject1).isProbablePrime(this.param.getCertainty())) && (localBigInteger3.gcd(((BigInteger)localObject1).subtract(ONE)).equals(ONE))) {
        break;
      }
    }
    Object localObject2;
    BigInteger localBigInteger1;
    for (;;)
    {
      localObject2 = new BigInteger(k, 1, this.param.getRandom());
      if ((((BigInteger)localObject2).subtract((BigInteger)localObject1).abs().bitLength() >= m) && (!((BigInteger)localObject2).mod(localBigInteger3).equals(ONE)) && (((BigInteger)localObject2).isProbablePrime(this.param.getCertainty())) && (localBigInteger3.gcd(((BigInteger)localObject2).subtract(ONE)).equals(ONE)))
      {
        localBigInteger1 = ((BigInteger)localObject1).multiply((BigInteger)localObject2);
        if (localBigInteger1.bitLength() == this.param.getStrength()) {
          break;
        }
        localObject1 = ((BigInteger)localObject1).max((BigInteger)localObject2);
      }
    }
    if (((BigInteger)localObject1).compareTo((BigInteger)localObject2) < 0)
    {
      localObject3 = localObject1;
      localObject1 = localObject2;
      localObject2 = localObject3;
    }
    BigInteger localBigInteger4 = ((BigInteger)localObject1).subtract(ONE);
    BigInteger localBigInteger5 = ((BigInteger)localObject2).subtract(ONE);
    Object localObject3 = localBigInteger4.multiply(localBigInteger5);
    BigInteger localBigInteger2 = localBigInteger3.modInverse((BigInteger)localObject3);
    BigInteger localBigInteger6 = localBigInteger2.remainder(localBigInteger4);
    BigInteger localBigInteger7 = localBigInteger2.remainder(localBigInteger5);
    BigInteger localBigInteger8 = ((BigInteger)localObject2).modInverse((BigInteger)localObject1);
    return new AsymmetricCipherKeyPair(new RSAKeyParameters(false, localBigInteger1, localBigInteger3), new RSAPrivateCrtKeyParameters(localBigInteger1, localBigInteger3, localBigInteger2, (BigInteger)localObject1, (BigInteger)localObject2, localBigInteger6, localBigInteger7, localBigInteger8));
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\generators\RSAKeyPairGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */