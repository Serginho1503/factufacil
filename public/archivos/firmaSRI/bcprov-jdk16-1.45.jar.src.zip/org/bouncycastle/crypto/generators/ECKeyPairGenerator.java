package org.bouncycastle.crypto.generators;

import java.math.BigInteger;
import java.security.SecureRandom;
import org.bouncycastle.crypto.AsymmetricCipherKeyPair;
import org.bouncycastle.crypto.AsymmetricCipherKeyPairGenerator;
import org.bouncycastle.crypto.KeyGenerationParameters;
import org.bouncycastle.crypto.params.ECDomainParameters;
import org.bouncycastle.crypto.params.ECKeyGenerationParameters;
import org.bouncycastle.crypto.params.ECPrivateKeyParameters;
import org.bouncycastle.crypto.params.ECPublicKeyParameters;
import org.bouncycastle.math.ec.ECConstants;
import org.bouncycastle.math.ec.ECPoint;

public class ECKeyPairGenerator
  implements AsymmetricCipherKeyPairGenerator, ECConstants
{
  ECDomainParameters params;
  SecureRandom random;
  
  public void init(KeyGenerationParameters paramKeyGenerationParameters)
  {
    ECKeyGenerationParameters localECKeyGenerationParameters = (ECKeyGenerationParameters)paramKeyGenerationParameters;
    this.random = localECKeyGenerationParameters.getRandom();
    this.params = localECKeyGenerationParameters.getDomainParameters();
  }
  
  public AsymmetricCipherKeyPair generateKeyPair()
  {
    BigInteger localBigInteger1 = this.params.getN();
    int i = localBigInteger1.bitLength();
    BigInteger localBigInteger2;
    do
    {
      localBigInteger2 = new BigInteger(i, this.random);
    } while ((localBigInteger2.equals(ZERO)) || (localBigInteger2.compareTo(localBigInteger1) >= 0));
    ECPoint localECPoint = this.params.getG().multiply(localBigInteger2);
    return new AsymmetricCipherKeyPair(new ECPublicKeyParameters(localECPoint, this.params), new ECPrivateKeyParameters(localBigInteger2, this.params));
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\generators\ECKeyPairGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */