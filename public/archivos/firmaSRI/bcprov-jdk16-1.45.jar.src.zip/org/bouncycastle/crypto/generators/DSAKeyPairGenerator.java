package org.bouncycastle.crypto.generators;

import java.math.BigInteger;
import java.security.SecureRandom;
import org.bouncycastle.crypto.AsymmetricCipherKeyPair;
import org.bouncycastle.crypto.AsymmetricCipherKeyPairGenerator;
import org.bouncycastle.crypto.KeyGenerationParameters;
import org.bouncycastle.crypto.params.DSAKeyGenerationParameters;
import org.bouncycastle.crypto.params.DSAParameters;
import org.bouncycastle.crypto.params.DSAPrivateKeyParameters;
import org.bouncycastle.crypto.params.DSAPublicKeyParameters;
import org.bouncycastle.util.BigIntegers;

public class DSAKeyPairGenerator
  implements AsymmetricCipherKeyPairGenerator
{
  private static final BigInteger ONE = BigInteger.valueOf(1L);
  private DSAKeyGenerationParameters param;
  
  public void init(KeyGenerationParameters paramKeyGenerationParameters)
  {
    this.param = ((DSAKeyGenerationParameters)paramKeyGenerationParameters);
  }
  
  public AsymmetricCipherKeyPair generateKeyPair()
  {
    DSAParameters localDSAParameters = this.param.getParameters();
    BigInteger localBigInteger1 = generatePrivateKey(localDSAParameters.getQ(), this.param.getRandom());
    BigInteger localBigInteger2 = calculatePublicKey(localDSAParameters.getP(), localDSAParameters.getG(), localBigInteger1);
    return new AsymmetricCipherKeyPair(new DSAPublicKeyParameters(localBigInteger2, localDSAParameters), new DSAPrivateKeyParameters(localBigInteger1, localDSAParameters));
  }
  
  private static BigInteger generatePrivateKey(BigInteger paramBigInteger, SecureRandom paramSecureRandom)
  {
    return BigIntegers.createRandomInRange(ONE, paramBigInteger.subtract(ONE), paramSecureRandom);
  }
  
  private static BigInteger calculatePublicKey(BigInteger paramBigInteger1, BigInteger paramBigInteger2, BigInteger paramBigInteger3)
  {
    return paramBigInteger2.modPow(paramBigInteger3, paramBigInteger1);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\generators\DSAKeyPairGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */