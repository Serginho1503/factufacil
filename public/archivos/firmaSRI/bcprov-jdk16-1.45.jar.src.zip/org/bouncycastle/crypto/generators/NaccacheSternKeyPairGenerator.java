package org.bouncycastle.crypto.generators;

import java.io.PrintStream;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Vector;
import org.bouncycastle.crypto.AsymmetricCipherKeyPair;
import org.bouncycastle.crypto.AsymmetricCipherKeyPairGenerator;
import org.bouncycastle.crypto.KeyGenerationParameters;
import org.bouncycastle.crypto.params.NaccacheSternKeyGenerationParameters;
import org.bouncycastle.crypto.params.NaccacheSternKeyParameters;
import org.bouncycastle.crypto.params.NaccacheSternPrivateKeyParameters;

public class NaccacheSternKeyPairGenerator
  implements AsymmetricCipherKeyPairGenerator
{
  private static int[] smallPrimes = { 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199, 211, 223, 227, 229, 233, 239, 241, 251, 257, 263, 269, 271, 277, 281, 283, 293, 307, 311, 313, 317, 331, 337, 347, 349, 353, 359, 367, 373, 379, 383, 389, 397, 401, 409, 419, 421, 431, 433, 439, 443, 449, 457, 461, 463, 467, 479, 487, 491, 499, 503, 509, 521, 523, 541, 547, 557 };
  private NaccacheSternKeyGenerationParameters param;
  private static final BigInteger ONE = BigInteger.valueOf(1L);
  
  public void init(KeyGenerationParameters paramKeyGenerationParameters)
  {
    this.param = ((NaccacheSternKeyGenerationParameters)paramKeyGenerationParameters);
  }
  
  public AsymmetricCipherKeyPair generateKeyPair()
  {
    int i = this.param.getStrength();
    SecureRandom localSecureRandom = this.param.getRandom();
    int j = this.param.getCertainty();
    boolean bool = this.param.isDebug();
    if (bool) {
      System.out.println("Fetching first " + this.param.getCntSmallPrimes() + " primes.");
    }
    Vector localVector1 = findFirstPrimes(this.param.getCntSmallPrimes());
    localVector1 = permuteList(localVector1, localSecureRandom);
    BigInteger localBigInteger1 = ONE;
    BigInteger localBigInteger2 = ONE;
    for (int k = 0; k < localVector1.size() / 2; k++) {
      localBigInteger1 = localBigInteger1.multiply((BigInteger)localVector1.elementAt(k));
    }
    for (k = localVector1.size() / 2; k < localVector1.size(); k++) {
      localBigInteger2 = localBigInteger2.multiply((BigInteger)localVector1.elementAt(k));
    }
    BigInteger localBigInteger3 = localBigInteger1.multiply(localBigInteger2);
    int m = i - localBigInteger3.bitLength() - 48;
    BigInteger localBigInteger4 = generatePrime(m / 2 + 1, j, localSecureRandom);
    BigInteger localBigInteger5 = generatePrime(m / 2 + 1, j, localSecureRandom);
    long l = 0L;
    if (bool) {
      System.out.println("generating p and q");
    }
    BigInteger localBigInteger10 = localBigInteger4.multiply(localBigInteger1).shiftLeft(1);
    BigInteger localBigInteger11 = localBigInteger5.multiply(localBigInteger2).shiftLeft(1);
    BigInteger localBigInteger6;
    BigInteger localBigInteger8;
    BigInteger localBigInteger7;
    BigInteger localBigInteger9;
    for (;;)
    {
      l += 1L;
      localBigInteger6 = generatePrime(24, j, localSecureRandom);
      localBigInteger8 = localBigInteger6.multiply(localBigInteger10).add(ONE);
      if (localBigInteger8.isProbablePrime(j))
      {
        for (;;)
        {
          localBigInteger7 = generatePrime(24, j, localSecureRandom);
          if (!localBigInteger6.equals(localBigInteger7))
          {
            localBigInteger9 = localBigInteger7.multiply(localBigInteger11).add(ONE);
            if (localBigInteger9.isProbablePrime(j)) {
              break;
            }
          }
        }
        if (localBigInteger3.gcd(localBigInteger6.multiply(localBigInteger7)).equals(ONE))
        {
          if (localBigInteger8.multiply(localBigInteger9).bitLength() >= i) {
            break;
          }
          if (bool) {
            System.out.println("key size too small. Should be " + i + " but is actually " + localBigInteger8.multiply(localBigInteger9).bitLength());
          }
        }
      }
    }
    if (bool) {
      System.out.println("needed " + l + " tries to generate p and q.");
    }
    BigInteger localBigInteger12 = localBigInteger8.multiply(localBigInteger9);
    BigInteger localBigInteger13 = localBigInteger8.subtract(ONE).multiply(localBigInteger9.subtract(ONE));
    l = 0L;
    if (bool) {
      System.out.println("generating g");
    }
    BigInteger localBigInteger14;
    for (;;)
    {
      Vector localVector2 = new Vector();
      for (int n = 0; n != localVector1.size(); n++)
      {
        BigInteger localBigInteger15 = (BigInteger)localVector1.elementAt(n);
        BigInteger localBigInteger16 = localBigInteger13.divide(localBigInteger15);
        do
        {
          l += 1L;
          localBigInteger14 = new BigInteger(i, j, localSecureRandom);
        } while (localBigInteger14.modPow(localBigInteger16, localBigInteger12).equals(ONE));
        localVector2.addElement(localBigInteger14);
      }
      localBigInteger14 = ONE;
      for (n = 0; n < localVector1.size(); n++) {
        localBigInteger14 = localBigInteger14.multiply(((BigInteger)localVector2.elementAt(n)).modPow(localBigInteger3.divide((BigInteger)localVector1.elementAt(n)), localBigInteger12)).mod(localBigInteger12);
      }
      n = 0;
      for (int i1 = 0; i1 < localVector1.size(); i1++) {
        if (localBigInteger14.modPow(localBigInteger13.divide((BigInteger)localVector1.elementAt(i1)), localBigInteger12).equals(ONE))
        {
          if (bool) {
            System.out.println("g has order phi(n)/" + localVector1.elementAt(i1) + "\n g: " + localBigInteger14);
          }
          n = 1;
          break;
        }
      }
      if (n == 0) {
        if (localBigInteger14.modPow(localBigInteger13.divide(BigInteger.valueOf(4L)), localBigInteger12).equals(ONE))
        {
          if (bool) {
            System.out.println("g has order phi(n)/4\n g:" + localBigInteger14);
          }
        }
        else if (localBigInteger14.modPow(localBigInteger13.divide(localBigInteger6), localBigInteger12).equals(ONE))
        {
          if (bool) {
            System.out.println("g has order phi(n)/p'\n g: " + localBigInteger14);
          }
        }
        else if (localBigInteger14.modPow(localBigInteger13.divide(localBigInteger7), localBigInteger12).equals(ONE))
        {
          if (bool) {
            System.out.println("g has order phi(n)/q'\n g: " + localBigInteger14);
          }
        }
        else if (localBigInteger14.modPow(localBigInteger13.divide(localBigInteger4), localBigInteger12).equals(ONE))
        {
          if (bool) {
            System.out.println("g has order phi(n)/a\n g: " + localBigInteger14);
          }
        }
        else
        {
          if (!localBigInteger14.modPow(localBigInteger13.divide(localBigInteger5), localBigInteger12).equals(ONE)) {
            break;
          }
          if (bool) {
            System.out.println("g has order phi(n)/b\n g: " + localBigInteger14);
          }
        }
      }
    }
    if (bool)
    {
      System.out.println("needed " + l + " tries to generate g");
      System.out.println();
      System.out.println("found new NaccacheStern cipher variables:");
      System.out.println("smallPrimes: " + localVector1);
      System.out.println("sigma:...... " + localBigInteger3 + " (" + localBigInteger3.bitLength() + " bits)");
      System.out.println("a:.......... " + localBigInteger4);
      System.out.println("b:.......... " + localBigInteger5);
      System.out.println("p':......... " + localBigInteger6);
      System.out.println("q':......... " + localBigInteger7);
      System.out.println("p:.......... " + localBigInteger8);
      System.out.println("q:.......... " + localBigInteger9);
      System.out.println("n:.......... " + localBigInteger12);
      System.out.println("phi(n):..... " + localBigInteger13);
      System.out.println("g:.......... " + localBigInteger14);
      System.out.println();
    }
    return new AsymmetricCipherKeyPair(new NaccacheSternKeyParameters(false, localBigInteger14, localBigInteger12, localBigInteger3.bitLength()), new NaccacheSternPrivateKeyParameters(localBigInteger14, localBigInteger12, localBigInteger3.bitLength(), localVector1, localBigInteger13));
  }
  
  private static BigInteger generatePrime(int paramInt1, int paramInt2, SecureRandom paramSecureRandom)
  {
    for (BigInteger localBigInteger = new BigInteger(paramInt1, paramInt2, paramSecureRandom); localBigInteger.bitLength() != paramInt1; localBigInteger = new BigInteger(paramInt1, paramInt2, paramSecureRandom)) {}
    return localBigInteger;
  }
  
  private static Vector permuteList(Vector paramVector, SecureRandom paramSecureRandom)
  {
    Vector localVector1 = new Vector();
    Vector localVector2 = new Vector();
    for (int i = 0; i < paramVector.size(); i++) {
      localVector2.addElement(paramVector.elementAt(i));
    }
    localVector1.addElement(localVector2.elementAt(0));
    localVector2.removeElementAt(0);
    while (localVector2.size() != 0)
    {
      localVector1.insertElementAt(localVector2.elementAt(0), getInt(paramSecureRandom, localVector1.size() + 1));
      localVector2.removeElementAt(0);
    }
    return localVector1;
  }
  
  private static int getInt(SecureRandom paramSecureRandom, int paramInt)
  {
    if ((paramInt & -paramInt) == paramInt) {
      return (int)(paramInt * (paramSecureRandom.nextInt() & 0x7FFFFFFF) >> 31);
    }
    int i;
    int j;
    do
    {
      i = paramSecureRandom.nextInt() & 0x7FFFFFFF;
      j = i % paramInt;
    } while (i - j + (paramInt - 1) < 0);
    return j;
  }
  
  private static Vector findFirstPrimes(int paramInt)
  {
    Vector localVector = new Vector(paramInt);
    for (int i = 0; i != paramInt; i++) {
      localVector.addElement(BigInteger.valueOf(smallPrimes[i]));
    }
    return localVector;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\generators\NaccacheSternKeyPairGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */