package org.bouncycastle.crypto.generators;

import java.math.BigInteger;
import java.security.SecureRandom;
import org.bouncycastle.crypto.Digest;
import org.bouncycastle.crypto.digests.SHA1Digest;
import org.bouncycastle.crypto.digests.SHA256Digest;
import org.bouncycastle.crypto.params.DSAParameters;
import org.bouncycastle.crypto.params.DSAValidationParameters;
import org.bouncycastle.util.Arrays;
import org.bouncycastle.util.BigIntegers;

public class DSAParametersGenerator
{
  private int L;
  private int N;
  private int certainty;
  private SecureRandom random;
  private static final BigInteger ZERO = BigInteger.valueOf(0L);
  private static final BigInteger ONE = BigInteger.valueOf(1L);
  private static final BigInteger TWO = BigInteger.valueOf(2L);
  
  public void init(int paramInt1, int paramInt2, SecureRandom paramSecureRandom)
  {
    init(paramInt1, getDefaultN(paramInt1), paramInt2, paramSecureRandom);
  }
  
  private void init(int paramInt1, int paramInt2, int paramInt3, SecureRandom paramSecureRandom)
  {
    this.L = paramInt1;
    this.N = paramInt2;
    this.certainty = paramInt3;
    this.random = paramSecureRandom;
  }
  
  public DSAParameters generateParameters()
  {
    return this.L > 1024 ? generateParameters_FIPS186_3() : generateParameters_FIPS186_2();
  }
  
  private DSAParameters generateParameters_FIPS186_2()
  {
    byte[] arrayOfByte1 = new byte[20];
    byte[] arrayOfByte2 = new byte[20];
    byte[] arrayOfByte3 = new byte[20];
    byte[] arrayOfByte4 = new byte[20];
    SHA1Digest localSHA1Digest = new SHA1Digest();
    int i = (this.L - 1) / 160;
    byte[] arrayOfByte5 = new byte[this.L / 8];
    for (;;)
    {
      this.random.nextBytes(arrayOfByte1);
      hash(localSHA1Digest, arrayOfByte1, arrayOfByte2);
      System.arraycopy(arrayOfByte1, 0, arrayOfByte3, 0, arrayOfByte1.length);
      inc(arrayOfByte3);
      hash(localSHA1Digest, arrayOfByte3, arrayOfByte3);
      for (int j = 0; j != arrayOfByte4.length; j++) {
        arrayOfByte4[j] = ((byte)(arrayOfByte2[j] ^ arrayOfByte3[j]));
      }
      int tmp123_122 = 0;
      byte[] tmp123_120 = arrayOfByte4;
      tmp123_120[tmp123_122] = ((byte)(tmp123_120[tmp123_122] | 0xFFFFFF80));
      byte[] tmp134_130 = arrayOfByte4;
      tmp134_130[19] = ((byte)(tmp134_130[19] | 0x1));
      BigInteger localBigInteger1 = new BigInteger(1, arrayOfByte4);
      if (localBigInteger1.isProbablePrime(this.certainty))
      {
        byte[] arrayOfByte6 = Arrays.clone(arrayOfByte1);
        inc(arrayOfByte6);
        for (int k = 0; k < 4096; k++)
        {
          for (int m = 0; m < i; m++)
          {
            inc(arrayOfByte6);
            hash(localSHA1Digest, arrayOfByte6, arrayOfByte2);
            System.arraycopy(arrayOfByte2, 0, arrayOfByte5, arrayOfByte5.length - (m + 1) * arrayOfByte2.length, arrayOfByte2.length);
          }
          inc(arrayOfByte6);
          hash(localSHA1Digest, arrayOfByte6, arrayOfByte2);
          System.arraycopy(arrayOfByte2, arrayOfByte2.length - (arrayOfByte5.length - i * arrayOfByte2.length), arrayOfByte5, 0, arrayOfByte5.length - i * arrayOfByte2.length);
          int tmp282_281 = 0;
          byte[] tmp282_279 = arrayOfByte5;
          tmp282_279[tmp282_281] = ((byte)(tmp282_279[tmp282_281] | 0xFFFFFF80));
          BigInteger localBigInteger2 = new BigInteger(1, arrayOfByte5);
          BigInteger localBigInteger3 = localBigInteger2.mod(localBigInteger1.shiftLeft(1));
          BigInteger localBigInteger4 = localBigInteger2.subtract(localBigInteger3.subtract(ONE));
          if ((localBigInteger4.bitLength() == this.L) && (localBigInteger4.isProbablePrime(this.certainty)))
          {
            BigInteger localBigInteger5 = calculateGenerator_FIPS186_2(localBigInteger4, localBigInteger1, this.random);
            return new DSAParameters(localBigInteger4, localBigInteger1, localBigInteger5, new DSAValidationParameters(arrayOfByte1, k));
          }
        }
      }
    }
  }
  
  private static BigInteger calculateGenerator_FIPS186_2(BigInteger paramBigInteger1, BigInteger paramBigInteger2, SecureRandom paramSecureRandom)
  {
    BigInteger localBigInteger1 = paramBigInteger1.subtract(ONE).divide(paramBigInteger2);
    BigInteger localBigInteger2 = paramBigInteger1.subtract(TWO);
    for (;;)
    {
      BigInteger localBigInteger3 = BigIntegers.createRandomInRange(TWO, localBigInteger2, paramSecureRandom);
      BigInteger localBigInteger4 = localBigInteger3.modPow(localBigInteger1, paramBigInteger1);
      if (localBigInteger4.bitLength() > 1) {
        return localBigInteger4;
      }
    }
  }
  
  private DSAParameters generateParameters_FIPS186_3()
  {
    SHA256Digest localSHA256Digest = new SHA256Digest();
    int i = localSHA256Digest.getDigestSize() * 8;
    int j = this.N;
    byte[] arrayOfByte1 = new byte[j / 8];
    int k = (this.L - 1) / i;
    int m = (this.L - 1) % i;
    byte[] arrayOfByte2 = new byte[localSHA256Digest.getDigestSize()];
    for (;;)
    {
      this.random.nextBytes(arrayOfByte1);
      hash(localSHA256Digest, arrayOfByte1, arrayOfByte2);
      BigInteger localBigInteger1 = new BigInteger(1, arrayOfByte2).mod(ONE.shiftLeft(this.N - 1));
      BigInteger localBigInteger2 = ONE.shiftLeft(this.N - 1).add(localBigInteger1).add(ONE).subtract(localBigInteger1.mod(TWO));
      if (localBigInteger2.isProbablePrime(this.certainty))
      {
        byte[] arrayOfByte3 = Arrays.clone(arrayOfByte1);
        int n = 4 * this.L;
        for (int i1 = 0; i1 < n; i1++)
        {
          BigInteger localBigInteger3 = ZERO;
          int i2 = 0;
          int i3 = 0;
          while (i2 <= k)
          {
            inc(arrayOfByte3);
            hash(localSHA256Digest, arrayOfByte3, arrayOfByte2);
            localBigInteger6 = new BigInteger(1, arrayOfByte2);
            if (i2 == k) {
              localBigInteger6 = localBigInteger6.mod(ONE.shiftLeft(m));
            }
            localBigInteger3 = localBigInteger3.add(localBigInteger6.shiftLeft(i3));
            i2++;
            i3 += i;
          }
          BigInteger localBigInteger4 = localBigInteger3.add(ONE.shiftLeft(this.L - 1));
          BigInteger localBigInteger5 = localBigInteger4.mod(localBigInteger2.shiftLeft(1));
          BigInteger localBigInteger6 = localBigInteger4.subtract(localBigInteger5.subtract(ONE));
          if ((localBigInteger6.bitLength() == this.L) && (localBigInteger6.isProbablePrime(this.certainty)))
          {
            BigInteger localBigInteger7 = calculateGenerator_FIPS186_3_Unverifiable(localBigInteger6, localBigInteger2, this.random);
            return new DSAParameters(localBigInteger6, localBigInteger2, localBigInteger7, new DSAValidationParameters(arrayOfByte1, i1));
          }
        }
      }
    }
  }
  
  private static BigInteger calculateGenerator_FIPS186_3_Unverifiable(BigInteger paramBigInteger1, BigInteger paramBigInteger2, SecureRandom paramSecureRandom)
  {
    return calculateGenerator_FIPS186_2(paramBigInteger1, paramBigInteger2, paramSecureRandom);
  }
  
  private static void hash(Digest paramDigest, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    paramDigest.update(paramArrayOfByte1, 0, paramArrayOfByte1.length);
    paramDigest.doFinal(paramArrayOfByte2, 0);
  }
  
  private static int getDefaultN(int paramInt)
  {
    return paramInt > 1024 ? 256 : 160;
  }
  
  private static void inc(byte[] paramArrayOfByte)
  {
    for (int i = paramArrayOfByte.length - 1; i >= 0; i--)
    {
      int j = (byte)(paramArrayOfByte[i] + 1 & 0xFF);
      paramArrayOfByte[i] = j;
      if (j != 0) {
        break;
      }
    }
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\generators\DSAParametersGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */