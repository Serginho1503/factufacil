package org.bouncycastle.crypto.generators;

import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.Digest;
import org.bouncycastle.crypto.PBEParametersGenerator;
import org.bouncycastle.crypto.digests.MD5Digest;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.crypto.params.ParametersWithIV;

public class OpenSSLPBEParametersGenerator
  extends PBEParametersGenerator
{
  private Digest digest = new MD5Digest();
  
  public void init(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    super.init(paramArrayOfByte1, paramArrayOfByte2, 1);
  }
  
  private byte[] generateDerivedKey(int paramInt)
  {
    byte[] arrayOfByte1 = new byte[this.digest.getDigestSize()];
    byte[] arrayOfByte2 = new byte[paramInt];
    int i = 0;
    for (;;)
    {
      this.digest.update(this.password, 0, this.password.length);
      this.digest.update(this.salt, 0, this.salt.length);
      this.digest.doFinal(arrayOfByte1, 0);
      int j = paramInt > arrayOfByte1.length ? arrayOfByte1.length : paramInt;
      System.arraycopy(arrayOfByte1, 0, arrayOfByte2, i, j);
      i += j;
      paramInt -= j;
      if (paramInt == 0) {
        break;
      }
      this.digest.reset();
      this.digest.update(arrayOfByte1, 0, arrayOfByte1.length);
    }
    return arrayOfByte2;
  }
  
  public CipherParameters generateDerivedParameters(int paramInt)
  {
    paramInt /= 8;
    byte[] arrayOfByte = generateDerivedKey(paramInt);
    return new KeyParameter(arrayOfByte, 0, paramInt);
  }
  
  public CipherParameters generateDerivedParameters(int paramInt1, int paramInt2)
  {
    paramInt1 /= 8;
    paramInt2 /= 8;
    byte[] arrayOfByte = generateDerivedKey(paramInt1 + paramInt2);
    return new ParametersWithIV(new KeyParameter(arrayOfByte, 0, paramInt1), arrayOfByte, paramInt1, paramInt2);
  }
  
  public CipherParameters generateDerivedMacParameters(int paramInt)
  {
    return generateDerivedParameters(paramInt);
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\generators\OpenSSLPBEParametersGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */