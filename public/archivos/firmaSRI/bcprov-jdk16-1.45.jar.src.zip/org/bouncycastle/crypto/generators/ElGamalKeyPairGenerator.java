package org.bouncycastle.crypto.generators;

import java.math.BigInteger;
import org.bouncycastle.crypto.AsymmetricCipherKeyPair;
import org.bouncycastle.crypto.AsymmetricCipherKeyPairGenerator;
import org.bouncycastle.crypto.KeyGenerationParameters;
import org.bouncycastle.crypto.params.DHParameters;
import org.bouncycastle.crypto.params.ElGamalKeyGenerationParameters;
import org.bouncycastle.crypto.params.ElGamalParameters;
import org.bouncycastle.crypto.params.ElGamalPrivateKeyParameters;
import org.bouncycastle.crypto.params.ElGamalPublicKeyParameters;

public class ElGamalKeyPairGenerator
  implements AsymmetricCipherKeyPairGenerator
{
  private ElGamalKeyGenerationParameters param;
  
  public void init(KeyGenerationParameters paramKeyGenerationParameters)
  {
    this.param = ((ElGamalKeyGenerationParameters)paramKeyGenerationParameters);
  }
  
  public AsymmetricCipherKeyPair generateKeyPair()
  {
    DHKeyGeneratorHelper localDHKeyGeneratorHelper = DHKeyGeneratorHelper.INSTANCE;
    ElGamalParameters localElGamalParameters = this.param.getParameters();
    DHParameters localDHParameters = new DHParameters(localElGamalParameters.getP(), localElGamalParameters.getG(), null, localElGamalParameters.getL());
    BigInteger localBigInteger1 = localDHKeyGeneratorHelper.calculatePrivate(localDHParameters, this.param.getRandom());
    BigInteger localBigInteger2 = localDHKeyGeneratorHelper.calculatePublic(localDHParameters, localBigInteger1);
    return new AsymmetricCipherKeyPair(new ElGamalPublicKeyParameters(localBigInteger2, localElGamalParameters), new ElGamalPrivateKeyParameters(localBigInteger1, localElGamalParameters));
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\generators\ElGamalKeyPairGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */