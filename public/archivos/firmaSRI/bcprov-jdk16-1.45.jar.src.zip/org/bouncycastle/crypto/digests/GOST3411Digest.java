package org.bouncycastle.crypto.digests;

import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.ExtendedDigest;
import org.bouncycastle.crypto.engines.GOST28147Engine;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.crypto.params.ParametersWithSBox;

public class GOST3411Digest
  implements ExtendedDigest
{
  private static final int DIGEST_LENGTH = 32;
  private byte[] H = new byte[32];
  private byte[] L = new byte[32];
  private byte[] M = new byte[32];
  private byte[] Sum = new byte[32];
  private byte[][] C = new byte[4][32];
  private byte[] xBuf = new byte[32];
  private int xBufOff;
  private long byteCount;
  private BlockCipher cipher = new GOST28147Engine();
  private byte[] K = new byte[32];
  byte[] a = new byte[8];
  short[] wS = new short[16];
  short[] w_S = new short[16];
  byte[] S = new byte[32];
  byte[] U = new byte[32];
  byte[] V = new byte[32];
  byte[] W = new byte[32];
  private static final byte[] C2 = { 0, -1, 0, -1, 0, -1, 0, -1, -1, 0, -1, 0, -1, 0, -1, 0, 0, -1, -1, 0, -1, 0, 0, -1, -1, 0, 0, 0, -1, -1, 0, -1 };
  
  public GOST3411Digest()
  {
    this.cipher.init(true, new ParametersWithSBox(null, GOST28147Engine.getSBox("D-A")));
    reset();
  }
  
  public GOST3411Digest(GOST3411Digest paramGOST3411Digest)
  {
    this.cipher.init(true, new ParametersWithSBox(null, GOST28147Engine.getSBox("D-A")));
    reset();
    System.arraycopy(paramGOST3411Digest.H, 0, this.H, 0, paramGOST3411Digest.H.length);
    System.arraycopy(paramGOST3411Digest.L, 0, this.L, 0, paramGOST3411Digest.L.length);
    System.arraycopy(paramGOST3411Digest.M, 0, this.M, 0, paramGOST3411Digest.M.length);
    System.arraycopy(paramGOST3411Digest.Sum, 0, this.Sum, 0, paramGOST3411Digest.Sum.length);
    System.arraycopy(paramGOST3411Digest.C[1], 0, this.C[1], 0, paramGOST3411Digest.C[1].length);
    System.arraycopy(paramGOST3411Digest.C[2], 0, this.C[2], 0, paramGOST3411Digest.C[2].length);
    System.arraycopy(paramGOST3411Digest.C[3], 0, this.C[3], 0, paramGOST3411Digest.C[3].length);
    System.arraycopy(paramGOST3411Digest.xBuf, 0, this.xBuf, 0, paramGOST3411Digest.xBuf.length);
    this.xBufOff = paramGOST3411Digest.xBufOff;
    this.byteCount = paramGOST3411Digest.byteCount;
  }
  
  public String getAlgorithmName()
  {
    return "GOST3411";
  }
  
  public int getDigestSize()
  {
    return 32;
  }
  
  public void update(byte paramByte)
  {
    this.xBuf[(this.xBufOff++)] = paramByte;
    if (this.xBufOff == this.xBuf.length)
    {
      sumByteArray(this.xBuf);
      processBlock(this.xBuf, 0);
      this.xBufOff = 0;
    }
    this.byteCount += 1L;
  }
  
  public void update(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    while ((this.xBufOff != 0) && (paramInt2 > 0))
    {
      update(paramArrayOfByte[paramInt1]);
      paramInt1++;
      paramInt2--;
    }
    while (paramInt2 > this.xBuf.length)
    {
      System.arraycopy(paramArrayOfByte, paramInt1, this.xBuf, 0, this.xBuf.length);
      sumByteArray(this.xBuf);
      processBlock(this.xBuf, 0);
      paramInt1 += this.xBuf.length;
      paramInt2 -= this.xBuf.length;
      this.byteCount += this.xBuf.length;
    }
    while (paramInt2 > 0)
    {
      update(paramArrayOfByte[paramInt1]);
      paramInt1++;
      paramInt2--;
    }
  }
  
  private byte[] P(byte[] paramArrayOfByte)
  {
    for (int i = 0; i < 8; i++)
    {
      this.K[(4 * i)] = paramArrayOfByte[i];
      this.K[(1 + 4 * i)] = paramArrayOfByte[(8 + i)];
      this.K[(2 + 4 * i)] = paramArrayOfByte[(16 + i)];
      this.K[(3 + 4 * i)] = paramArrayOfByte[(24 + i)];
    }
    return this.K;
  }
  
  private byte[] A(byte[] paramArrayOfByte)
  {
    for (int i = 0; i < 8; i++) {
      this.a[i] = ((byte)(paramArrayOfByte[i] ^ paramArrayOfByte[(i + 8)]));
    }
    System.arraycopy(paramArrayOfByte, 8, paramArrayOfByte, 0, 24);
    System.arraycopy(this.a, 0, paramArrayOfByte, 24, 8);
    return paramArrayOfByte;
  }
  
  private void E(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt1, byte[] paramArrayOfByte3, int paramInt2)
  {
    this.cipher.init(true, new KeyParameter(paramArrayOfByte1));
    this.cipher.processBlock(paramArrayOfByte3, paramInt2, paramArrayOfByte2, paramInt1);
  }
  
  private void fw(byte[] paramArrayOfByte)
  {
    cpyBytesToShort(paramArrayOfByte, this.wS);
    this.w_S[15] = ((short)(this.wS[0] ^ this.wS[1] ^ this.wS[2] ^ this.wS[3] ^ this.wS[12] ^ this.wS[15]));
    System.arraycopy(this.wS, 1, this.w_S, 0, 15);
    cpyShortToBytes(this.w_S, paramArrayOfByte);
  }
  
  protected void processBlock(byte[] paramArrayOfByte, int paramInt)
  {
    System.arraycopy(paramArrayOfByte, paramInt, this.M, 0, 32);
    System.arraycopy(this.H, 0, this.U, 0, 32);
    System.arraycopy(this.M, 0, this.V, 0, 32);
    for (int i = 0; i < 32; i++) {
      this.W[i] = ((byte)(this.U[i] ^ this.V[i]));
    }
    E(P(this.W), this.S, 0, this.H, 0);
    for (i = 1; i < 4; i++)
    {
      byte[] arrayOfByte = A(this.U);
      for (int j = 0; j < 32; j++) {
        this.U[j] = ((byte)(arrayOfByte[j] ^ this.C[i][j]));
      }
      this.V = A(A(this.V));
      for (j = 0; j < 32; j++) {
        this.W[j] = ((byte)(this.U[j] ^ this.V[j]));
      }
      E(P(this.W), this.S, i * 8, this.H, i * 8);
    }
    for (i = 0; i < 12; i++) {
      fw(this.S);
    }
    for (i = 0; i < 32; i++) {
      this.S[i] = ((byte)(this.S[i] ^ this.M[i]));
    }
    fw(this.S);
    for (i = 0; i < 32; i++) {
      this.S[i] = ((byte)(this.H[i] ^ this.S[i]));
    }
    for (i = 0; i < 61; i++) {
      fw(this.S);
    }
    System.arraycopy(this.S, 0, this.H, 0, this.H.length);
  }
  
  private void finish()
  {
    LongToBytes(this.byteCount * 8L, this.L, 0);
    while (this.xBufOff != 0) {
      update((byte)0);
    }
    processBlock(this.L, 0);
    processBlock(this.Sum, 0);
  }
  
  public int doFinal(byte[] paramArrayOfByte, int paramInt)
  {
    finish();
    System.arraycopy(this.H, 0, paramArrayOfByte, paramInt, this.H.length);
    reset();
    return 32;
  }
  
  public void reset()
  {
    this.byteCount = 0L;
    this.xBufOff = 0;
    for (int i = 0; i < this.H.length; i++) {
      this.H[i] = 0;
    }
    for (i = 0; i < this.L.length; i++) {
      this.L[i] = 0;
    }
    for (i = 0; i < this.M.length; i++) {
      this.M[i] = 0;
    }
    for (i = 0; i < this.C[1].length; i++) {
      this.C[1][i] = 0;
    }
    for (i = 0; i < this.C[3].length; i++) {
      this.C[3][i] = 0;
    }
    for (i = 0; i < this.Sum.length; i++) {
      this.Sum[i] = 0;
    }
    for (i = 0; i < this.xBuf.length; i++) {
      this.xBuf[i] = 0;
    }
    System.arraycopy(C2, 0, this.C[2], 0, C2.length);
  }
  
  private void sumByteArray(byte[] paramArrayOfByte)
  {
    int i = 0;
    for (int j = 0; j != this.Sum.length; j++)
    {
      int k = (this.Sum[j] & 0xFF) + (paramArrayOfByte[j] & 0xFF) + i;
      this.Sum[j] = ((byte)k);
      i = k >>> 8;
    }
  }
  
  private void LongToBytes(long paramLong, byte[] paramArrayOfByte, int paramInt)
  {
    paramArrayOfByte[(paramInt + 7)] = ((byte)(int)(paramLong >> 56));
    paramArrayOfByte[(paramInt + 6)] = ((byte)(int)(paramLong >> 48));
    paramArrayOfByte[(paramInt + 5)] = ((byte)(int)(paramLong >> 40));
    paramArrayOfByte[(paramInt + 4)] = ((byte)(int)(paramLong >> 32));
    paramArrayOfByte[(paramInt + 3)] = ((byte)(int)(paramLong >> 24));
    paramArrayOfByte[(paramInt + 2)] = ((byte)(int)(paramLong >> 16));
    paramArrayOfByte[(paramInt + 1)] = ((byte)(int)(paramLong >> 8));
    paramArrayOfByte[paramInt] = ((byte)(int)paramLong);
  }
  
  private void cpyBytesToShort(byte[] paramArrayOfByte, short[] paramArrayOfShort)
  {
    for (int i = 0; i < paramArrayOfByte.length / 2; i++) {
      paramArrayOfShort[i] = ((short)(paramArrayOfByte[(i * 2 + 1)] << 8 & 0xFF00 | paramArrayOfByte[(i * 2)] & 0xFF));
    }
  }
  
  private void cpyShortToBytes(short[] paramArrayOfShort, byte[] paramArrayOfByte)
  {
    for (int i = 0; i < paramArrayOfByte.length / 2; i++)
    {
      paramArrayOfByte[(i * 2 + 1)] = ((byte)(paramArrayOfShort[i] >> 8));
      paramArrayOfByte[(i * 2)] = ((byte)paramArrayOfShort[i]);
    }
  }
  
  public int getByteLength()
  {
    return 32;
  }
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\bcprov-jdk16-1.45.jar!\org\bouncycastle\crypto\digests\GOST3411Digest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */