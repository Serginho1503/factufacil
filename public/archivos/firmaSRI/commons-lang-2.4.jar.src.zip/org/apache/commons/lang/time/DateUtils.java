/*      */ package org.apache.commons.lang.time;
/*      */ 
/*      */ import java.text.ParseException;
/*      */ import java.text.ParsePosition;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import java.util.Iterator;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.TimeZone;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DateUtils
/*      */ {
/*   59 */   public static final TimeZone UTC_TIME_ZONE = TimeZone.getTimeZone("GMT");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long MILLIS_PER_SECOND = 1000L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long MILLIS_PER_MINUTE = 60000L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long MILLIS_PER_HOUR = 3600000L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long MILLIS_PER_DAY = 86400000L;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int SEMI_MONTH = 1001;
/*      */   
/*      */ 
/*      */ 
/*   87 */   private static final int[][] fields = { { 14 }, { 13 }, { 12 }, { 11, 10 }, { 5, 5, 9 }, { 2, 1001 }, { 1 }, { 0 } };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int RANGE_WEEK_SUNDAY = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int RANGE_WEEK_MONDAY = 2;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int RANGE_WEEK_RELATIVE = 3;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int RANGE_WEEK_CENTER = 4;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int RANGE_MONTH_SUNDAY = 5;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int RANGE_MONTH_MONDAY = 6;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public static final int MILLIS_IN_SECOND = 1000;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public static final int MILLIS_IN_MINUTE = 60000;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public static final int MILLIS_IN_HOUR = 3600000;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public static final int MILLIS_IN_DAY = 86400000;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isSameDay(Date date1, Date date2)
/*      */   {
/*  156 */     if ((date1 == null) || (date2 == null)) {
/*  157 */       throw new IllegalArgumentException("The date must not be null");
/*      */     }
/*  159 */     Calendar cal1 = Calendar.getInstance();
/*  160 */     cal1.setTime(date1);
/*  161 */     Calendar cal2 = Calendar.getInstance();
/*  162 */     cal2.setTime(date2);
/*  163 */     return isSameDay(cal1, cal2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isSameDay(Calendar cal1, Calendar cal2)
/*      */   {
/*  180 */     if ((cal1 == null) || (cal2 == null)) {
/*  181 */       throw new IllegalArgumentException("The date must not be null");
/*      */     }
/*  183 */     return (cal1.get(0) == cal2.get(0)) && (cal1.get(1) == cal2.get(1)) && (cal1.get(6) == cal2.get(6));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isSameInstant(Date date1, Date date2)
/*      */   {
/*  201 */     if ((date1 == null) || (date2 == null)) {
/*  202 */       throw new IllegalArgumentException("The date must not be null");
/*      */     }
/*  204 */     return date1.getTime() == date2.getTime();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isSameInstant(Calendar cal1, Calendar cal2)
/*      */   {
/*  219 */     if ((cal1 == null) || (cal2 == null)) {
/*  220 */       throw new IllegalArgumentException("The date must not be null");
/*      */     }
/*  222 */     return cal1.getTime().getTime() == cal2.getTime().getTime();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isSameLocalTime(Calendar cal1, Calendar cal2)
/*      */   {
/*  239 */     if ((cal1 == null) || (cal2 == null)) {
/*  240 */       throw new IllegalArgumentException("The date must not be null");
/*      */     }
/*  242 */     return (cal1.get(14) == cal2.get(14)) && (cal1.get(13) == cal2.get(13)) && (cal1.get(12) == cal2.get(12)) && (cal1.get(10) == cal2.get(10)) && (cal1.get(6) == cal2.get(6)) && (cal1.get(1) == cal2.get(1)) && (cal1.get(0) == cal2.get(0)) && (cal1.getClass() == cal2.getClass());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Date parseDate(String str, String[] parsePatterns)
/*      */     throws ParseException
/*      */   {
/*  267 */     if ((str == null) || (parsePatterns == null)) {
/*  268 */       throw new IllegalArgumentException("Date and Patterns must not be null");
/*      */     }
/*      */     
/*  271 */     SimpleDateFormat parser = null;
/*  272 */     ParsePosition pos = new ParsePosition(0);
/*  273 */     for (int i = 0; i < parsePatterns.length; i++) {
/*  274 */       if (i == 0) {
/*  275 */         parser = new SimpleDateFormat(parsePatterns[0]);
/*      */       } else {
/*  277 */         parser.applyPattern(parsePatterns[i]);
/*      */       }
/*  279 */       pos.setIndex(0);
/*  280 */       Date date = parser.parse(str, pos);
/*  281 */       if ((date != null) && (pos.getIndex() == str.length())) {
/*  282 */         return date;
/*      */       }
/*      */     }
/*  285 */     throw new ParseException("Unable to parse the date: " + str, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Date addYears(Date date, int amount)
/*      */   {
/*  299 */     return add(date, 1, amount);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Date addMonths(Date date, int amount)
/*      */   {
/*  313 */     return add(date, 2, amount);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Date addWeeks(Date date, int amount)
/*      */   {
/*  327 */     return add(date, 3, amount);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Date addDays(Date date, int amount)
/*      */   {
/*  341 */     return add(date, 5, amount);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Date addHours(Date date, int amount)
/*      */   {
/*  355 */     return add(date, 11, amount);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Date addMinutes(Date date, int amount)
/*      */   {
/*  369 */     return add(date, 12, amount);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Date addSeconds(Date date, int amount)
/*      */   {
/*  383 */     return add(date, 13, amount);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Date addMilliseconds(Date date, int amount)
/*      */   {
/*  397 */     return add(date, 14, amount);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public static Date add(Date date, int calendarField, int amount)
/*      */   {
/*  413 */     if (date == null) {
/*  414 */       throw new IllegalArgumentException("The date must not be null");
/*      */     }
/*  416 */     Calendar c = Calendar.getInstance();
/*  417 */     c.setTime(date);
/*  418 */     c.add(calendarField, amount);
/*  419 */     return c.getTime();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Date setYears(Date date, int amount)
/*      */   {
/*  434 */     return set(date, 1, amount);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Date setMonths(Date date, int amount)
/*      */   {
/*  449 */     return set(date, 2, amount);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Date setDays(Date date, int amount)
/*      */   {
/*  464 */     return set(date, 5, amount);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Date setHours(Date date, int amount)
/*      */   {
/*  480 */     return set(date, 11, amount);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Date setMinutes(Date date, int amount)
/*      */   {
/*  495 */     return set(date, 12, amount);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Date setSeconds(Date date, int amount)
/*      */   {
/*  510 */     return set(date, 13, amount);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Date setMilliseconds(Date date, int amount)
/*      */   {
/*  525 */     return set(date, 14, amount);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static Date set(Date date, int calendarField, int amount)
/*      */   {
/*  542 */     if (date == null) {
/*  543 */       throw new IllegalArgumentException("The date must not be null");
/*      */     }
/*      */     
/*  546 */     Calendar c = Calendar.getInstance();
/*  547 */     c.setLenient(false);
/*  548 */     c.setTime(date);
/*  549 */     c.set(calendarField, amount);
/*  550 */     return c.getTime();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Date round(Date date, int field)
/*      */   {
/*  583 */     if (date == null) {
/*  584 */       throw new IllegalArgumentException("The date must not be null");
/*      */     }
/*  586 */     Calendar gval = Calendar.getInstance();
/*  587 */     gval.setTime(date);
/*  588 */     modify(gval, field, true);
/*  589 */     return gval.getTime();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Calendar round(Calendar date, int field)
/*      */   {
/*  621 */     if (date == null) {
/*  622 */       throw new IllegalArgumentException("The date must not be null");
/*      */     }
/*  624 */     Calendar rounded = (Calendar)date.clone();
/*  625 */     modify(rounded, field, true);
/*  626 */     return rounded;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Date round(Object date, int field)
/*      */   {
/*  660 */     if (date == null) {
/*  661 */       throw new IllegalArgumentException("The date must not be null");
/*      */     }
/*  663 */     if ((date instanceof Date))
/*  664 */       return round((Date)date, field);
/*  665 */     if ((date instanceof Calendar)) {
/*  666 */       return round((Calendar)date, field).getTime();
/*      */     }
/*  668 */     throw new ClassCastException("Could not round " + date);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Date truncate(Date date, int field)
/*      */   {
/*  690 */     if (date == null) {
/*  691 */       throw new IllegalArgumentException("The date must not be null");
/*      */     }
/*  693 */     Calendar gval = Calendar.getInstance();
/*  694 */     gval.setTime(date);
/*  695 */     modify(gval, field, false);
/*  696 */     return gval.getTime();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Calendar truncate(Calendar date, int field)
/*      */   {
/*  716 */     if (date == null) {
/*  717 */       throw new IllegalArgumentException("The date must not be null");
/*      */     }
/*  719 */     Calendar truncated = (Calendar)date.clone();
/*  720 */     modify(truncated, field, false);
/*  721 */     return truncated;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Date truncate(Object date, int field)
/*      */   {
/*  745 */     if (date == null) {
/*  746 */       throw new IllegalArgumentException("The date must not be null");
/*      */     }
/*  748 */     if ((date instanceof Date))
/*  749 */       return truncate((Date)date, field);
/*  750 */     if ((date instanceof Calendar)) {
/*  751 */       return truncate((Calendar)date, field).getTime();
/*      */     }
/*  753 */     throw new ClassCastException("Could not truncate " + date);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void modify(Calendar val, int field, boolean round)
/*      */   {
/*  767 */     if (val.get(1) > 280000000) {
/*  768 */       throw new ArithmeticException("Calendar value too large for accurate calculations");
/*      */     }
/*      */     
/*  771 */     if (field == 14) {
/*  772 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  781 */     Date date = val.getTime();
/*  782 */     long time = date.getTime();
/*  783 */     boolean done = false;
/*      */     
/*      */ 
/*  786 */     int millisecs = val.get(14);
/*  787 */     if ((!round) || (millisecs < 500)) {
/*  788 */       time -= millisecs;
/*      */     }
/*  790 */     if (field == 13) {
/*  791 */       done = true;
/*      */     }
/*      */     
/*      */ 
/*  795 */     int seconds = val.get(13);
/*  796 */     if ((!done) && ((!round) || (seconds < 30))) {
/*  797 */       time -= seconds * 1000L;
/*      */     }
/*  799 */     if (field == 12) {
/*  800 */       done = true;
/*      */     }
/*      */     
/*      */ 
/*  804 */     int minutes = val.get(12);
/*  805 */     if ((!done) && ((!round) || (minutes < 30))) {
/*  806 */       time -= minutes * 60000L;
/*      */     }
/*      */     
/*      */ 
/*  810 */     if (date.getTime() != time) {
/*  811 */       date.setTime(time);
/*  812 */       val.setTime(date);
/*      */     }
/*      */     
/*      */ 
/*  816 */     boolean roundUp = false;
/*  817 */     for (int i = 0; i < fields.length; i++) {
/*  818 */       for (int j = 0; j < fields[i].length; j++) {
/*  819 */         if (fields[i][j] == field)
/*      */         {
/*  821 */           if ((round) && (roundUp)) {
/*  822 */             if (field == 1001)
/*      */             {
/*      */ 
/*      */ 
/*  826 */               if (val.get(5) == 1) {
/*  827 */                 val.add(5, 15);
/*      */               } else {
/*  829 */                 val.add(5, -15);
/*  830 */                 val.add(2, 1);
/*      */               }
/*      */               
/*      */             }
/*      */             else {
/*  835 */               val.add(fields[i][0], 1);
/*      */             }
/*      */           }
/*  838 */           return;
/*      */         }
/*      */       }
/*      */       
/*  842 */       int offset = 0;
/*  843 */       boolean offsetSet = false;
/*      */       
/*  845 */       switch (field) {
/*      */       case 1001: 
/*  847 */         if (fields[i][0] == 5)
/*      */         {
/*      */ 
/*      */ 
/*  851 */           offset = val.get(5) - 1;
/*      */           
/*      */ 
/*  854 */           if (offset >= 15) {
/*  855 */             offset -= 15;
/*      */           }
/*      */           
/*  858 */           roundUp = offset > 7;
/*  859 */           offsetSet = true;
/*      */         }
/*      */         break;
/*      */       case 9: 
/*  863 */         if (fields[i][0] == 11)
/*      */         {
/*      */ 
/*  866 */           offset = val.get(11);
/*  867 */           if (offset >= 12) {
/*  868 */             offset -= 12;
/*      */           }
/*  870 */           roundUp = offset > 6;
/*  871 */           offsetSet = true;
/*      */         }
/*      */         break;
/*      */       }
/*  875 */       if (!offsetSet) {
/*  876 */         int min = val.getActualMinimum(fields[i][0]);
/*  877 */         int max = val.getActualMaximum(fields[i][0]);
/*      */         
/*  879 */         offset = val.get(fields[i][0]) - min;
/*      */         
/*  881 */         roundUp = offset > (max - min) / 2;
/*      */       }
/*      */       
/*  884 */       if (offset != 0) {
/*  885 */         val.set(fields[i][0], val.get(fields[i][0]) - offset);
/*      */       }
/*      */     }
/*  888 */     throw new IllegalArgumentException("The field " + field + " is not supported");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Iterator iterator(Date focus, int rangeStyle)
/*      */   {
/*  918 */     if (focus == null) {
/*  919 */       throw new IllegalArgumentException("The date must not be null");
/*      */     }
/*  921 */     Calendar gval = Calendar.getInstance();
/*  922 */     gval.setTime(focus);
/*  923 */     return iterator(gval, rangeStyle);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Iterator iterator(Calendar focus, int rangeStyle)
/*      */   {
/*  951 */     if (focus == null) {
/*  952 */       throw new IllegalArgumentException("The date must not be null");
/*      */     }
/*  954 */     Calendar start = null;
/*  955 */     Calendar end = null;
/*  956 */     int startCutoff = 1;
/*  957 */     int endCutoff = 7;
/*  958 */     switch (rangeStyle)
/*      */     {
/*      */     case 5: 
/*      */     case 6: 
/*  962 */       start = truncate(focus, 2);
/*      */       
/*  964 */       end = (Calendar)start.clone();
/*  965 */       end.add(2, 1);
/*  966 */       end.add(5, -1);
/*      */       
/*  968 */       if (rangeStyle == 6) {
/*  969 */         startCutoff = 2;
/*  970 */         endCutoff = 1;
/*      */       }
/*      */       
/*      */       break;
/*      */     case 1: 
/*      */     case 2: 
/*      */     case 3: 
/*      */     case 4: 
/*  978 */       start = truncate(focus, 5);
/*  979 */       end = truncate(focus, 5);
/*  980 */       switch (rangeStyle)
/*      */       {
/*      */       case 1: 
/*      */         break;
/*      */       case 2: 
/*  985 */         startCutoff = 2;
/*  986 */         endCutoff = 1;
/*  987 */         break;
/*      */       case 3: 
/*  989 */         startCutoff = focus.get(7);
/*  990 */         endCutoff = startCutoff - 1;
/*  991 */         break;
/*      */       case 4: 
/*  993 */         startCutoff = focus.get(7) - 3;
/*  994 */         endCutoff = focus.get(7) + 3;
/*      */       }
/*      */       
/*  997 */       break;
/*      */     default: 
/*  999 */       throw new IllegalArgumentException("The range style " + rangeStyle + " is not valid.");
/*      */     }
/* 1001 */     if (startCutoff < 1) {
/* 1002 */       startCutoff += 7;
/*      */     }
/* 1004 */     if (startCutoff > 7) {
/* 1005 */       startCutoff -= 7;
/*      */     }
/* 1007 */     if (endCutoff < 1) {
/* 1008 */       endCutoff += 7;
/*      */     }
/* 1010 */     if (endCutoff > 7) {
/* 1011 */       endCutoff -= 7;
/*      */     }
/* 1013 */     while (start.get(7) != startCutoff) {
/* 1014 */       start.add(5, -1);
/*      */     }
/* 1016 */     while (end.get(7) != endCutoff) {
/* 1017 */       end.add(5, 1);
/*      */     }
/* 1019 */     return new DateIterator(start, end);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Iterator iterator(Object focus, int rangeStyle)
/*      */   {
/* 1042 */     if (focus == null) {
/* 1043 */       throw new IllegalArgumentException("The date must not be null");
/*      */     }
/* 1045 */     if ((focus instanceof Date))
/* 1046 */       return iterator((Date)focus, rangeStyle);
/* 1047 */     if ((focus instanceof Calendar)) {
/* 1048 */       return iterator((Calendar)focus, rangeStyle);
/*      */     }
/* 1050 */     throw new ClassCastException("Could not iterate based on " + focus);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static long getFragmentInMilliseconds(Date date, int fragment)
/*      */   {
/* 1088 */     return getFragment(date, fragment, 14);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static long getFragmentInSeconds(Date date, int fragment)
/*      */   {
/* 1128 */     return getFragment(date, fragment, 13);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static long getFragmentInMinutes(Date date, int fragment)
/*      */   {
/* 1168 */     return getFragment(date, fragment, 12);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static long getFragmentInHours(Date date, int fragment)
/*      */   {
/* 1208 */     return getFragment(date, fragment, 11);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static long getFragmentInDays(Date date, int fragment)
/*      */   {
/* 1248 */     return getFragment(date, fragment, 6);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static long getFragmentInMilliseconds(Calendar calendar, int fragment)
/*      */   {
/* 1288 */     return getFragment(calendar, fragment, 14);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static long getFragmentInSeconds(Calendar calendar, int fragment)
/*      */   {
/* 1327 */     return getFragment(calendar, fragment, 13);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static long getFragmentInMinutes(Calendar calendar, int fragment)
/*      */   {
/* 1367 */     return getFragment(calendar, fragment, 12);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static long getFragmentInHours(Calendar calendar, int fragment)
/*      */   {
/* 1407 */     return getFragment(calendar, fragment, 11);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static long getFragmentInDays(Calendar calendar, int fragment)
/*      */   {
/* 1449 */     return getFragment(calendar, fragment, 6);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static long getFragment(Date date, int fragment, int unit)
/*      */   {
/* 1464 */     if (date == null) {
/* 1465 */       throw new IllegalArgumentException("The date must not be null");
/*      */     }
/* 1467 */     Calendar calendar = Calendar.getInstance();
/* 1468 */     calendar.setTime(date);
/* 1469 */     return getFragment(calendar, fragment, unit);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static long getFragment(Calendar calendar, int fragment, int unit)
/*      */   {
/* 1484 */     if (calendar == null) {
/* 1485 */       throw new IllegalArgumentException("The date must not be null");
/*      */     }
/* 1487 */     long millisPerUnit = getMillisPerUnit(unit);
/* 1488 */     long result = 0L;
/*      */     
/*      */ 
/* 1491 */     switch (fragment) {
/*      */     case 1: 
/* 1493 */       result += calendar.get(6) * 86400000L / millisPerUnit;
/* 1494 */       break;
/*      */     case 2: 
/* 1496 */       result += calendar.get(5) * 86400000L / millisPerUnit;
/*      */     }
/*      */     
/*      */     
/* 1500 */     switch (fragment)
/*      */     {
/*      */ 
/*      */ 
/*      */     case 1: 
/*      */     case 2: 
/*      */     case 5: 
/*      */     case 6: 
/* 1508 */       result += calendar.get(11) * 3600000L / millisPerUnit;
/*      */     case 11: 
/* 1510 */       result += calendar.get(12) * 60000L / millisPerUnit;
/*      */     case 12: 
/* 1512 */       result += calendar.get(13) * 1000L / millisPerUnit;
/*      */     case 13: 
/* 1514 */       result += calendar.get(14) * 1 / millisPerUnit;
/* 1515 */       break;
/*      */     case 14: 
/*      */       break; case 3: case 4: case 7: case 8: case 9: case 10: default:  throw new IllegalArgumentException("The fragment " + fragment + " is not supported"); }
/*      */     
/* 1519 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static long getMillisPerUnit(int unit)
/*      */   {
/* 1531 */     long result = Long.MAX_VALUE;
/* 1532 */     switch (unit) {
/*      */     case 5: 
/*      */     case 6: 
/* 1535 */       result = 86400000L;
/* 1536 */       break;
/*      */     case 11: 
/* 1538 */       result = 3600000L;
/* 1539 */       break;
/*      */     case 12: 
/* 1541 */       result = 60000L;
/* 1542 */       break;
/*      */     case 13: 
/* 1544 */       result = 1000L;
/* 1545 */       break;
/*      */     case 14: 
/* 1547 */       result = 1L;
/* 1548 */       break;
/* 1549 */     case 7: case 8: case 9: case 10: default:  throw new IllegalArgumentException("The unit " + unit + " cannot be represented is milleseconds");
/*      */     }
/* 1551 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static class DateIterator
/*      */     implements Iterator
/*      */   {
/*      */     private final Calendar endFinal;
/*      */     
/*      */ 
/*      */     private final Calendar spot;
/*      */     
/*      */ 
/*      */ 
/*      */     DateIterator(Calendar startFinal, Calendar endFinal)
/*      */     {
/* 1569 */       this.endFinal = endFinal;
/* 1570 */       this.spot = startFinal;
/* 1571 */       this.spot.add(5, -1);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean hasNext()
/*      */     {
/* 1580 */       return this.spot.before(this.endFinal);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public Object next()
/*      */     {
/* 1589 */       if (this.spot.equals(this.endFinal)) {
/* 1590 */         throw new NoSuchElementException();
/*      */       }
/* 1592 */       this.spot.add(5, 1);
/* 1593 */       return this.spot.clone();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void remove()
/*      */     {
/* 1603 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-lang-2.4.jar!\org\apache\commons\lang\time\DateUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */