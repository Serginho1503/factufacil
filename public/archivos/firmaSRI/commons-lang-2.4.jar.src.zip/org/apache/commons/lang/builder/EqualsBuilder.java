/*     */ package org.apache.commons.lang.builder;
/*     */ 
/*     */ import java.lang.reflect.AccessibleObject;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EqualsBuilder
/*     */ {
/*  92 */   private boolean isEquals = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean reflectionEquals(Object lhs, Object rhs)
/*     */   {
/* 125 */     return reflectionEquals(lhs, rhs, false, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean reflectionEquals(Object lhs, Object rhs, Collection excludeFields)
/*     */   {
/* 148 */     return reflectionEquals(lhs, rhs, ReflectionToStringBuilder.toNoNullStringArray(excludeFields));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean reflectionEquals(Object lhs, Object rhs, String[] excludeFields)
/*     */   {
/* 171 */     return reflectionEquals(lhs, rhs, false, null, excludeFields);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean reflectionEquals(Object lhs, Object rhs, boolean testTransients)
/*     */   {
/* 195 */     return reflectionEquals(lhs, rhs, testTransients, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean reflectionEquals(Object lhs, Object rhs, boolean testTransients, Class reflectUpToClass)
/*     */   {
/* 224 */     return reflectionEquals(lhs, rhs, testTransients, reflectUpToClass, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean reflectionEquals(Object lhs, Object rhs, boolean testTransients, Class reflectUpToClass, String[] excludeFields)
/*     */   {
/* 255 */     if (lhs == rhs) {
/* 256 */       return true;
/*     */     }
/* 258 */     if ((lhs == null) || (rhs == null)) {
/* 259 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 265 */     Class lhsClass = lhs.getClass();
/* 266 */     Class rhsClass = rhs.getClass();
/*     */     Class testClass;
/* 268 */     if (lhsClass.isInstance(rhs)) {
/* 269 */       Class testClass = lhsClass;
/* 270 */       if (!rhsClass.isInstance(lhs))
/*     */       {
/* 272 */         testClass = rhsClass;
/*     */       }
/* 274 */     } else if (rhsClass.isInstance(lhs)) {
/* 275 */       testClass = rhsClass;
/* 276 */       if (!lhsClass.isInstance(rhs))
/*     */       {
/* 278 */         testClass = lhsClass;
/*     */       }
/*     */     }
/*     */     else {
/* 282 */       return false;
/*     */     }
/* 284 */     EqualsBuilder equalsBuilder = new EqualsBuilder();
/*     */     try {
/* 286 */       reflectionAppend(lhs, rhs, testClass, equalsBuilder, testTransients, excludeFields);
/* 287 */       while ((testClass.getSuperclass() != null) && (testClass != reflectUpToClass)) {
/* 288 */         Class testClass = testClass.getSuperclass();
/* 289 */         reflectionAppend(lhs, rhs, testClass, equalsBuilder, testTransients, excludeFields);
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     catch (IllegalArgumentException e)
/*     */     {
/*     */ 
/* 297 */       return false;
/*     */     }
/* 299 */     return equalsBuilder.isEquals();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void reflectionAppend(Object lhs, Object rhs, Class clazz, EqualsBuilder builder, boolean useTransients, String[] excludeFields)
/*     */   {
/* 320 */     Field[] fields = clazz.getDeclaredFields();
/* 321 */     List excludedFieldList = excludeFields != null ? Arrays.asList(excludeFields) : Collections.EMPTY_LIST;
/* 322 */     AccessibleObject.setAccessible(fields, true);
/* 323 */     for (int i = 0; (i < fields.length) && (builder.isEquals); i++) {
/* 324 */       Field f = fields[i];
/* 325 */       if ((!excludedFieldList.contains(f.getName())) && (f.getName().indexOf('$') == -1) && ((useTransients) || (!Modifier.isTransient(f.getModifiers()))) && (!Modifier.isStatic(f.getModifiers())))
/*     */       {
/*     */         try
/*     */         {
/*     */ 
/* 330 */           builder.append(f.get(lhs), f.get(rhs));
/*     */         }
/*     */         catch (IllegalAccessException e)
/*     */         {
/* 334 */           throw new InternalError("Unexpected IllegalAccessException");
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EqualsBuilder appendSuper(boolean superEquals)
/*     */   {
/* 350 */     if (!this.isEquals) {
/* 351 */       return this;
/*     */     }
/* 353 */     this.isEquals = superEquals;
/* 354 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EqualsBuilder append(Object lhs, Object rhs)
/*     */   {
/* 368 */     if (!this.isEquals) {
/* 369 */       return this;
/*     */     }
/* 371 */     if (lhs == rhs) {
/* 372 */       return this;
/*     */     }
/* 374 */     if ((lhs == null) || (rhs == null)) {
/* 375 */       setEquals(false);
/* 376 */       return this;
/*     */     }
/* 378 */     Class lhsClass = lhs.getClass();
/* 379 */     if (!lhsClass.isArray()) {
/* 380 */       if ((lhs instanceof BigDecimal)) {
/* 381 */         this.isEquals = (((BigDecimal)lhs).compareTo(rhs) == 0);
/*     */       }
/*     */       else {
/* 384 */         this.isEquals = lhs.equals(rhs);
/*     */       }
/* 386 */     } else if (lhs.getClass() != rhs.getClass())
/*     */     {
/* 388 */       setEquals(false);
/*     */ 
/*     */ 
/*     */     }
/* 392 */     else if ((lhs instanceof long[])) {
/* 393 */       append((long[])lhs, (long[])rhs);
/* 394 */     } else if ((lhs instanceof int[])) {
/* 395 */       append((int[])lhs, (int[])rhs);
/* 396 */     } else if ((lhs instanceof short[])) {
/* 397 */       append((short[])lhs, (short[])rhs);
/* 398 */     } else if ((lhs instanceof char[])) {
/* 399 */       append((char[])lhs, (char[])rhs);
/* 400 */     } else if ((lhs instanceof byte[])) {
/* 401 */       append((byte[])lhs, (byte[])rhs);
/* 402 */     } else if ((lhs instanceof double[])) {
/* 403 */       append((double[])lhs, (double[])rhs);
/* 404 */     } else if ((lhs instanceof float[])) {
/* 405 */       append((float[])lhs, (float[])rhs);
/* 406 */     } else if ((lhs instanceof boolean[])) {
/* 407 */       append((boolean[])lhs, (boolean[])rhs);
/*     */     }
/*     */     else {
/* 410 */       append((Object[])lhs, (Object[])rhs);
/*     */     }
/* 412 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EqualsBuilder append(long lhs, long rhs)
/*     */   {
/* 427 */     if (!this.isEquals) {
/* 428 */       return this;
/*     */     }
/* 430 */     this.isEquals = (lhs == rhs);
/* 431 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EqualsBuilder append(int lhs, int rhs)
/*     */   {
/* 442 */     if (!this.isEquals) {
/* 443 */       return this;
/*     */     }
/* 445 */     this.isEquals = (lhs == rhs);
/* 446 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EqualsBuilder append(short lhs, short rhs)
/*     */   {
/* 457 */     if (!this.isEquals) {
/* 458 */       return this;
/*     */     }
/* 460 */     this.isEquals = (lhs == rhs);
/* 461 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EqualsBuilder append(char lhs, char rhs)
/*     */   {
/* 472 */     if (!this.isEquals) {
/* 473 */       return this;
/*     */     }
/* 475 */     this.isEquals = (lhs == rhs);
/* 476 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EqualsBuilder append(byte lhs, byte rhs)
/*     */   {
/* 487 */     if (!this.isEquals) {
/* 488 */       return this;
/*     */     }
/* 490 */     this.isEquals = (lhs == rhs);
/* 491 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EqualsBuilder append(double lhs, double rhs)
/*     */   {
/* 508 */     if (!this.isEquals) {
/* 509 */       return this;
/*     */     }
/* 511 */     return append(Double.doubleToLongBits(lhs), Double.doubleToLongBits(rhs));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EqualsBuilder append(float lhs, float rhs)
/*     */   {
/* 528 */     if (!this.isEquals) {
/* 529 */       return this;
/*     */     }
/* 531 */     return append(Float.floatToIntBits(lhs), Float.floatToIntBits(rhs));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EqualsBuilder append(boolean lhs, boolean rhs)
/*     */   {
/* 542 */     if (!this.isEquals) {
/* 543 */       return this;
/*     */     }
/* 545 */     this.isEquals = (lhs == rhs);
/* 546 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EqualsBuilder append(Object[] lhs, Object[] rhs)
/*     */   {
/* 560 */     if (!this.isEquals) {
/* 561 */       return this;
/*     */     }
/* 563 */     if (lhs == rhs) {
/* 564 */       return this;
/*     */     }
/* 566 */     if ((lhs == null) || (rhs == null)) {
/* 567 */       setEquals(false);
/* 568 */       return this;
/*     */     }
/* 570 */     if (lhs.length != rhs.length) {
/* 571 */       setEquals(false);
/* 572 */       return this;
/*     */     }
/* 574 */     for (int i = 0; (i < lhs.length) && (this.isEquals); i++) {
/* 575 */       append(lhs[i], rhs[i]);
/*     */     }
/* 577 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EqualsBuilder append(long[] lhs, long[] rhs)
/*     */   {
/* 591 */     if (!this.isEquals) {
/* 592 */       return this;
/*     */     }
/* 594 */     if (lhs == rhs) {
/* 595 */       return this;
/*     */     }
/* 597 */     if ((lhs == null) || (rhs == null)) {
/* 598 */       setEquals(false);
/* 599 */       return this;
/*     */     }
/* 601 */     if (lhs.length != rhs.length) {
/* 602 */       setEquals(false);
/* 603 */       return this;
/*     */     }
/* 605 */     for (int i = 0; (i < lhs.length) && (this.isEquals); i++) {
/* 606 */       append(lhs[i], rhs[i]);
/*     */     }
/* 608 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EqualsBuilder append(int[] lhs, int[] rhs)
/*     */   {
/* 622 */     if (!this.isEquals) {
/* 623 */       return this;
/*     */     }
/* 625 */     if (lhs == rhs) {
/* 626 */       return this;
/*     */     }
/* 628 */     if ((lhs == null) || (rhs == null)) {
/* 629 */       setEquals(false);
/* 630 */       return this;
/*     */     }
/* 632 */     if (lhs.length != rhs.length) {
/* 633 */       setEquals(false);
/* 634 */       return this;
/*     */     }
/* 636 */     for (int i = 0; (i < lhs.length) && (this.isEquals); i++) {
/* 637 */       append(lhs[i], rhs[i]);
/*     */     }
/* 639 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EqualsBuilder append(short[] lhs, short[] rhs)
/*     */   {
/* 653 */     if (!this.isEquals) {
/* 654 */       return this;
/*     */     }
/* 656 */     if (lhs == rhs) {
/* 657 */       return this;
/*     */     }
/* 659 */     if ((lhs == null) || (rhs == null)) {
/* 660 */       setEquals(false);
/* 661 */       return this;
/*     */     }
/* 663 */     if (lhs.length != rhs.length) {
/* 664 */       setEquals(false);
/* 665 */       return this;
/*     */     }
/* 667 */     for (int i = 0; (i < lhs.length) && (this.isEquals); i++) {
/* 668 */       append(lhs[i], rhs[i]);
/*     */     }
/* 670 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EqualsBuilder append(char[] lhs, char[] rhs)
/*     */   {
/* 684 */     if (!this.isEquals) {
/* 685 */       return this;
/*     */     }
/* 687 */     if (lhs == rhs) {
/* 688 */       return this;
/*     */     }
/* 690 */     if ((lhs == null) || (rhs == null)) {
/* 691 */       setEquals(false);
/* 692 */       return this;
/*     */     }
/* 694 */     if (lhs.length != rhs.length) {
/* 695 */       setEquals(false);
/* 696 */       return this;
/*     */     }
/* 698 */     for (int i = 0; (i < lhs.length) && (this.isEquals); i++) {
/* 699 */       append(lhs[i], rhs[i]);
/*     */     }
/* 701 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EqualsBuilder append(byte[] lhs, byte[] rhs)
/*     */   {
/* 715 */     if (!this.isEquals) {
/* 716 */       return this;
/*     */     }
/* 718 */     if (lhs == rhs) {
/* 719 */       return this;
/*     */     }
/* 721 */     if ((lhs == null) || (rhs == null)) {
/* 722 */       setEquals(false);
/* 723 */       return this;
/*     */     }
/* 725 */     if (lhs.length != rhs.length) {
/* 726 */       setEquals(false);
/* 727 */       return this;
/*     */     }
/* 729 */     for (int i = 0; (i < lhs.length) && (this.isEquals); i++) {
/* 730 */       append(lhs[i], rhs[i]);
/*     */     }
/* 732 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EqualsBuilder append(double[] lhs, double[] rhs)
/*     */   {
/* 746 */     if (!this.isEquals) {
/* 747 */       return this;
/*     */     }
/* 749 */     if (lhs == rhs) {
/* 750 */       return this;
/*     */     }
/* 752 */     if ((lhs == null) || (rhs == null)) {
/* 753 */       setEquals(false);
/* 754 */       return this;
/*     */     }
/* 756 */     if (lhs.length != rhs.length) {
/* 757 */       setEquals(false);
/* 758 */       return this;
/*     */     }
/* 760 */     for (int i = 0; (i < lhs.length) && (this.isEquals); i++) {
/* 761 */       append(lhs[i], rhs[i]);
/*     */     }
/* 763 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EqualsBuilder append(float[] lhs, float[] rhs)
/*     */   {
/* 777 */     if (!this.isEquals) {
/* 778 */       return this;
/*     */     }
/* 780 */     if (lhs == rhs) {
/* 781 */       return this;
/*     */     }
/* 783 */     if ((lhs == null) || (rhs == null)) {
/* 784 */       setEquals(false);
/* 785 */       return this;
/*     */     }
/* 787 */     if (lhs.length != rhs.length) {
/* 788 */       setEquals(false);
/* 789 */       return this;
/*     */     }
/* 791 */     for (int i = 0; (i < lhs.length) && (this.isEquals); i++) {
/* 792 */       append(lhs[i], rhs[i]);
/*     */     }
/* 794 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EqualsBuilder append(boolean[] lhs, boolean[] rhs)
/*     */   {
/* 808 */     if (!this.isEquals) {
/* 809 */       return this;
/*     */     }
/* 811 */     if (lhs == rhs) {
/* 812 */       return this;
/*     */     }
/* 814 */     if ((lhs == null) || (rhs == null)) {
/* 815 */       setEquals(false);
/* 816 */       return this;
/*     */     }
/* 818 */     if (lhs.length != rhs.length) {
/* 819 */       setEquals(false);
/* 820 */       return this;
/*     */     }
/* 822 */     for (int i = 0; (i < lhs.length) && (this.isEquals); i++) {
/* 823 */       append(lhs[i], rhs[i]);
/*     */     }
/* 825 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEquals()
/*     */   {
/* 835 */     return this.isEquals;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setEquals(boolean isEquals)
/*     */   {
/* 845 */     this.isEquals = isEquals;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-lang-2.4.jar!\org\apache\commons\lang\builder\EqualsBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */