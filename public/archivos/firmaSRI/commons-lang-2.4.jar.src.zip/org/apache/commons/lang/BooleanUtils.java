/*     */ package org.apache.commons.lang;
/*     */ 
/*     */ import org.apache.commons.lang.math.NumberUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BooleanUtils
/*     */ {
/*     */   public static Boolean negate(Boolean bool)
/*     */   {
/*  64 */     if (bool == null) {
/*  65 */       return null;
/*     */     }
/*  67 */     return bool.booleanValue() ? Boolean.FALSE : Boolean.TRUE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isTrue(Boolean bool)
/*     */   {
/*  87 */     if (bool == null) {
/*  88 */       return false;
/*     */     }
/*  90 */     return bool.booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isNotTrue(Boolean bool)
/*     */   {
/* 108 */     return !isTrue(bool);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isFalse(Boolean bool)
/*     */   {
/* 126 */     if (bool == null) {
/* 127 */       return false;
/*     */     }
/* 129 */     return !bool.booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isNotFalse(Boolean bool)
/*     */   {
/* 147 */     return !isFalse(bool);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Boolean toBooleanObject(boolean bool)
/*     */   {
/* 165 */     return bool ? Boolean.TRUE : Boolean.FALSE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean toBoolean(Boolean bool)
/*     */   {
/* 183 */     if (bool == null) {
/* 184 */       return false;
/*     */     }
/* 186 */     return bool.booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean toBooleanDefaultIfNull(Boolean bool, boolean valueIfNull)
/*     */   {
/* 203 */     if (bool == null) {
/* 204 */       return valueIfNull;
/*     */     }
/* 206 */     return bool.booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean toBoolean(int value)
/*     */   {
/* 226 */     return value != 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Boolean toBooleanObject(int value)
/*     */   {
/* 244 */     return value == 0 ? Boolean.FALSE : Boolean.TRUE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Boolean toBooleanObject(Integer value)
/*     */   {
/* 264 */     if (value == null) {
/* 265 */       return null;
/*     */     }
/* 267 */     return value.intValue() == 0 ? Boolean.FALSE : Boolean.TRUE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean toBoolean(int value, int trueValue, int falseValue)
/*     */   {
/* 287 */     if (value == trueValue)
/* 288 */       return true;
/* 289 */     if (value == falseValue) {
/* 290 */       return false;
/*     */     }
/*     */     
/* 293 */     throw new IllegalArgumentException("The Integer did not match either specified value");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean toBoolean(Integer value, Integer trueValue, Integer falseValue)
/*     */   {
/* 316 */     if (value == null) {
/* 317 */       if (trueValue == null)
/* 318 */         return true;
/* 319 */       if (falseValue == null)
/* 320 */         return false;
/*     */     } else {
/* 322 */       if (value.equals(trueValue))
/* 323 */         return true;
/* 324 */       if (value.equals(falseValue)) {
/* 325 */         return false;
/*     */       }
/*     */     }
/* 328 */     throw new IllegalArgumentException("The Integer did not match either specified value");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Boolean toBooleanObject(int value, int trueValue, int falseValue, int nullValue)
/*     */   {
/* 348 */     if (value == trueValue)
/* 349 */       return Boolean.TRUE;
/* 350 */     if (value == falseValue)
/* 351 */       return Boolean.FALSE;
/* 352 */     if (value == nullValue) {
/* 353 */       return null;
/*     */     }
/*     */     
/* 356 */     throw new IllegalArgumentException("The Integer did not match any specified value");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Boolean toBooleanObject(Integer value, Integer trueValue, Integer falseValue, Integer nullValue)
/*     */   {
/* 379 */     if (value == null) {
/* 380 */       if (trueValue == null)
/* 381 */         return Boolean.TRUE;
/* 382 */       if (falseValue == null)
/* 383 */         return Boolean.FALSE;
/* 384 */       if (nullValue == null)
/* 385 */         return null;
/*     */     } else {
/* 387 */       if (value.equals(trueValue))
/* 388 */         return Boolean.TRUE;
/* 389 */       if (value.equals(falseValue))
/* 390 */         return Boolean.FALSE;
/* 391 */       if (value.equals(nullValue)) {
/* 392 */         return null;
/*     */       }
/*     */     }
/* 395 */     throw new IllegalArgumentException("The Integer did not match any specified value");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int toInteger(boolean bool)
/*     */   {
/* 413 */     return bool ? 1 : 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Integer toIntegerObject(boolean bool)
/*     */   {
/* 429 */     return bool ? NumberUtils.INTEGER_ONE : NumberUtils.INTEGER_ZERO;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Integer toIntegerObject(Boolean bool)
/*     */   {
/* 447 */     if (bool == null) {
/* 448 */       return null;
/*     */     }
/* 450 */     return bool.booleanValue() ? NumberUtils.INTEGER_ONE : NumberUtils.INTEGER_ZERO;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int toInteger(boolean bool, int trueValue, int falseValue)
/*     */   {
/* 467 */     return bool ? trueValue : falseValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int toInteger(Boolean bool, int trueValue, int falseValue, int nullValue)
/*     */   {
/* 486 */     if (bool == null) {
/* 487 */       return nullValue;
/*     */     }
/* 489 */     return bool.booleanValue() ? trueValue : falseValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Integer toIntegerObject(boolean bool, Integer trueValue, Integer falseValue)
/*     */   {
/* 508 */     return bool ? trueValue : falseValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Integer toIntegerObject(Boolean bool, Integer trueValue, Integer falseValue, Integer nullValue)
/*     */   {
/* 530 */     if (bool == null) {
/* 531 */       return nullValue;
/*     */     }
/* 533 */     return bool.booleanValue() ? trueValue : falseValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Boolean toBooleanObject(String str)
/*     */   {
/* 563 */     if ("true".equalsIgnoreCase(str))
/* 564 */       return Boolean.TRUE;
/* 565 */     if ("false".equalsIgnoreCase(str))
/* 566 */       return Boolean.FALSE;
/* 567 */     if ("on".equalsIgnoreCase(str))
/* 568 */       return Boolean.TRUE;
/* 569 */     if ("off".equalsIgnoreCase(str))
/* 570 */       return Boolean.FALSE;
/* 571 */     if ("yes".equalsIgnoreCase(str))
/* 572 */       return Boolean.TRUE;
/* 573 */     if ("no".equalsIgnoreCase(str)) {
/* 574 */       return Boolean.FALSE;
/*     */     }
/*     */     
/* 577 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Boolean toBooleanObject(String str, String trueString, String falseString, String nullString)
/*     */   {
/* 603 */     if (str == null) {
/* 604 */       if (trueString == null)
/* 605 */         return Boolean.TRUE;
/* 606 */       if (falseString == null)
/* 607 */         return Boolean.FALSE;
/* 608 */       if (nullString == null)
/* 609 */         return null;
/*     */     } else {
/* 611 */       if (str.equals(trueString))
/* 612 */         return Boolean.TRUE;
/* 613 */       if (str.equals(falseString))
/* 614 */         return Boolean.FALSE;
/* 615 */       if (str.equals(nullString)) {
/* 616 */         return null;
/*     */       }
/*     */     }
/* 619 */     throw new IllegalArgumentException("The String did not match any specified value");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean toBoolean(String str)
/*     */   {
/* 656 */     if (str == "true") {
/* 657 */       return true;
/*     */     }
/* 659 */     if (str == null) {
/* 660 */       return false;
/*     */     }
/* 662 */     switch (str.length()) {
/*     */     case 2: 
/* 664 */       char ch0 = str.charAt(0);
/* 665 */       char ch1 = str.charAt(1);
/* 666 */       return ((ch0 == 'o') || (ch0 == 'O')) && ((ch1 == 'n') || (ch1 == 'N'));
/*     */     
/*     */ 
/*     */ 
/*     */     case 3: 
/* 671 */       char ch = str.charAt(0);
/* 672 */       if (ch == 'y') {
/* 673 */         return ((str.charAt(1) == 'e') || (str.charAt(1) == 'E')) && ((str.charAt(2) == 's') || (str.charAt(2) == 'S'));
/*     */       }
/*     */       
/*     */ 
/* 677 */       if (ch == 'Y') {
/* 678 */         return ((str.charAt(1) == 'E') || (str.charAt(1) == 'e')) && ((str.charAt(2) == 'S') || (str.charAt(2) == 's'));
/*     */       }
/*     */       
/*     */ 
/* 682 */       return false;
/*     */     
/*     */     case 4: 
/* 685 */       char ch = str.charAt(0);
/* 686 */       if (ch == 't') {
/* 687 */         return ((str.charAt(1) == 'r') || (str.charAt(1) == 'R')) && ((str.charAt(2) == 'u') || (str.charAt(2) == 'U')) && ((str.charAt(3) == 'e') || (str.charAt(3) == 'E'));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 692 */       if (ch == 'T') {
/* 693 */         return ((str.charAt(1) == 'R') || (str.charAt(1) == 'r')) && ((str.charAt(2) == 'U') || (str.charAt(2) == 'u')) && ((str.charAt(3) == 'E') || (str.charAt(3) == 'e'));
/*     */       }
/*     */       
/*     */       break;
/*     */     }
/*     */     
/*     */     
/* 700 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean toBoolean(String str, String trueString, String falseString)
/*     */   {
/* 733 */     if (str == null) {
/* 734 */       if (trueString == null)
/* 735 */         return true;
/* 736 */       if (falseString == null)
/* 737 */         return false;
/*     */     } else {
/* 739 */       if (str.equals(trueString))
/* 740 */         return true;
/* 741 */       if (str.equals(falseString)) {
/* 742 */         return false;
/*     */       }
/*     */     }
/* 745 */     throw new IllegalArgumentException("The String did not match either specified value");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toStringTrueFalse(Boolean bool)
/*     */   {
/* 765 */     return toString(bool, "true", "false", null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toStringOnOff(Boolean bool)
/*     */   {
/* 783 */     return toString(bool, "on", "off", null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toStringYesNo(Boolean bool)
/*     */   {
/* 801 */     return toString(bool, "yes", "no", null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toString(Boolean bool, String trueString, String falseString, String nullString)
/*     */   {
/* 823 */     if (bool == null) {
/* 824 */       return nullString;
/*     */     }
/* 826 */     return bool.booleanValue() ? trueString : falseString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toStringTrueFalse(boolean bool)
/*     */   {
/* 845 */     return toString(bool, "true", "false");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toStringOnOff(boolean bool)
/*     */   {
/* 862 */     return toString(bool, "on", "off");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toStringYesNo(boolean bool)
/*     */   {
/* 879 */     return toString(bool, "yes", "no");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toString(boolean bool, String trueString, String falseString)
/*     */   {
/* 898 */     return bool ? trueString : falseString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean xor(boolean[] array)
/*     */   {
/* 919 */     if (array == null)
/* 920 */       throw new IllegalArgumentException("The Array must not be null");
/* 921 */     if (array.length == 0) {
/* 922 */       throw new IllegalArgumentException("Array is empty");
/*     */     }
/*     */     
/*     */ 
/* 926 */     int trueCount = 0;
/* 927 */     for (int i = 0; i < array.length; i++)
/*     */     {
/*     */ 
/* 930 */       if (array[i] != 0) {
/* 931 */         if (trueCount < 1) {
/* 932 */           trueCount++;
/*     */         } else {
/* 934 */           return false;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 940 */     return trueCount == 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Boolean xor(Boolean[] array)
/*     */   {
/* 959 */     if (array == null)
/* 960 */       throw new IllegalArgumentException("The Array must not be null");
/* 961 */     if (array.length == 0) {
/* 962 */       throw new IllegalArgumentException("Array is empty");
/*     */     }
/* 964 */     boolean[] primitive = null;
/*     */     try {
/* 966 */       primitive = ArrayUtils.toPrimitive(array);
/*     */     } catch (NullPointerException ex) {
/* 968 */       throw new IllegalArgumentException("The array must not contain any null elements");
/*     */     }
/* 970 */     return xor(primitive) ? Boolean.TRUE : Boolean.FALSE;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-lang-2.4.jar!\org\apache\commons\lang\BooleanUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */