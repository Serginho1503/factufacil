package org.apache.commons.lang.text;

import java.text.Format;
import java.util.Locale;

public abstract interface FormatFactory
{
  public abstract Format getFormat(String paramString1, String paramString2, Locale paramLocale);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-lang-2.4.jar!\org\apache\commons\lang\text\FormatFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */