/*     */ package org.apache.commons.lang;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassUtils
/*     */ {
/*     */   public static final char PACKAGE_SEPARATOR_CHAR = '.';
/*  52 */   public static final String PACKAGE_SEPARATOR = String.valueOf('.');
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final char INNER_CLASS_SEPARATOR_CHAR = '$';
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  62 */   public static final String INNER_CLASS_SEPARATOR = String.valueOf('$');
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  67 */   private static Map primitiveWrapperMap = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Map wrapperPrimitiveMap;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Map abbreviationMap;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Map reverseAbbreviationMap;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void addAbbreviation(String primitive, String abbreviation)
/*     */   {
/* 111 */     abbreviationMap.put(primitive, abbreviation);
/* 112 */     reverseAbbreviationMap.put(abbreviation, primitive);
/*     */   }
/*     */   
/*     */   static
/*     */   {
/*  69 */     primitiveWrapperMap.put(Boolean.TYPE, Boolean.class);
/*  70 */     primitiveWrapperMap.put(Byte.TYPE, Byte.class);
/*  71 */     primitiveWrapperMap.put(Character.TYPE, Character.class);
/*  72 */     primitiveWrapperMap.put(Short.TYPE, Short.class);
/*  73 */     primitiveWrapperMap.put(Integer.TYPE, Integer.class);
/*  74 */     primitiveWrapperMap.put(Long.TYPE, Long.class);
/*  75 */     primitiveWrapperMap.put(Double.TYPE, Double.class);
/*  76 */     primitiveWrapperMap.put(Float.TYPE, Float.class);
/*  77 */     primitiveWrapperMap.put(Void.TYPE, Void.TYPE);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */     wrapperPrimitiveMap = new HashMap();
/*     */     
/*  85 */     for (Iterator it = primitiveWrapperMap.keySet().iterator(); it.hasNext();) {
/*  86 */       Class primitiveClass = (Class)it.next();
/*  87 */       Class wrapperClass = (Class)primitiveWrapperMap.get(primitiveClass);
/*  88 */       if (!primitiveClass.equals(wrapperClass)) {
/*  89 */         wrapperPrimitiveMap.put(wrapperClass, primitiveClass);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  97 */     abbreviationMap = new HashMap();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 102 */     reverseAbbreviationMap = new HashMap();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 119 */     addAbbreviation("int", "I");
/* 120 */     addAbbreviation("boolean", "Z");
/* 121 */     addAbbreviation("float", "F");
/* 122 */     addAbbreviation("long", "J");
/* 123 */     addAbbreviation("short", "S");
/* 124 */     addAbbreviation("byte", "B");
/* 125 */     addAbbreviation("double", "D");
/* 126 */     addAbbreviation("char", "C");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getShortClassName(Object object, String valueIfNull)
/*     */   {
/* 151 */     if (object == null) {
/* 152 */       return valueIfNull;
/*     */     }
/* 154 */     return getShortClassName(object.getClass().getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getShortClassName(Class cls)
/*     */   {
/* 164 */     if (cls == null) {
/* 165 */       return "";
/*     */     }
/* 167 */     return getShortClassName(cls.getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getShortClassName(String className)
/*     */   {
/* 179 */     if (className == null) {
/* 180 */       return "";
/*     */     }
/* 182 */     if (className.length() == 0) {
/* 183 */       return "";
/*     */     }
/*     */     
/* 186 */     int lastDotIdx = className.lastIndexOf('.');
/* 187 */     int innerIdx = className.indexOf('$', lastDotIdx == -1 ? 0 : lastDotIdx + 1);
/*     */     
/* 189 */     String out = className.substring(lastDotIdx + 1);
/* 190 */     if (innerIdx != -1) {
/* 191 */       out = out.replace('$', '.');
/*     */     }
/* 193 */     return out;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getPackageName(Object object, String valueIfNull)
/*     */   {
/* 206 */     if (object == null) {
/* 207 */       return valueIfNull;
/*     */     }
/* 209 */     return getPackageName(object.getClass().getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getPackageName(Class cls)
/*     */   {
/* 219 */     if (cls == null) {
/* 220 */       return "";
/*     */     }
/* 222 */     return getPackageName(cls.getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getPackageName(String className)
/*     */   {
/* 235 */     if (className == null) {
/* 236 */       return "";
/*     */     }
/* 238 */     int i = className.lastIndexOf('.');
/* 239 */     if (i == -1) {
/* 240 */       return "";
/*     */     }
/* 242 */     return className.substring(0, i);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List getAllSuperclasses(Class cls)
/*     */   {
/* 255 */     if (cls == null) {
/* 256 */       return null;
/*     */     }
/* 258 */     List classes = new ArrayList();
/* 259 */     Class superclass = cls.getSuperclass();
/* 260 */     while (superclass != null) {
/* 261 */       classes.add(superclass);
/* 262 */       superclass = superclass.getSuperclass();
/*     */     }
/* 264 */     return classes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List getAllInterfaces(Class cls)
/*     */   {
/* 281 */     if (cls == null) {
/* 282 */       return null;
/*     */     }
/* 284 */     List list = new ArrayList();
/* 285 */     while (cls != null) {
/* 286 */       Class[] interfaces = cls.getInterfaces();
/* 287 */       Iterator it; for (int i = 0; i < interfaces.length; i++) {
/* 288 */         if (!list.contains(interfaces[i])) {
/* 289 */           list.add(interfaces[i]);
/*     */         }
/* 291 */         List superInterfaces = getAllInterfaces(interfaces[i]);
/* 292 */         for (it = superInterfaces.iterator(); it.hasNext();) {
/* 293 */           Class intface = (Class)it.next();
/* 294 */           if (!list.contains(intface)) {
/* 295 */             list.add(intface);
/*     */           }
/*     */         }
/*     */       }
/* 299 */       cls = cls.getSuperclass();
/*     */     }
/* 301 */     return list;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List convertClassNamesToClasses(List classNames)
/*     */   {
/* 319 */     if (classNames == null) {
/* 320 */       return null;
/*     */     }
/* 322 */     List classes = new ArrayList(classNames.size());
/* 323 */     for (Iterator it = classNames.iterator(); it.hasNext();) {
/* 324 */       String className = (String)it.next();
/*     */       try {
/* 326 */         classes.add(Class.forName(className));
/*     */       } catch (Exception ex) {
/* 328 */         classes.add(null);
/*     */       }
/*     */     }
/* 331 */     return classes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List convertClassesToClassNames(List classes)
/*     */   {
/* 347 */     if (classes == null) {
/* 348 */       return null;
/*     */     }
/* 350 */     List classNames = new ArrayList(classes.size());
/* 351 */     for (Iterator it = classes.iterator(); it.hasNext();) {
/* 352 */       Class cls = (Class)it.next();
/* 353 */       if (cls == null) {
/* 354 */         classNames.add(null);
/*     */       } else {
/* 356 */         classNames.add(cls.getName());
/*     */       }
/*     */     }
/* 359 */     return classNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isAssignable(Class[] classArray, Class[] toClassArray)
/*     */   {
/* 396 */     if (!ArrayUtils.isSameLength(classArray, toClassArray)) {
/* 397 */       return false;
/*     */     }
/* 399 */     if (classArray == null) {
/* 400 */       classArray = ArrayUtils.EMPTY_CLASS_ARRAY;
/*     */     }
/* 402 */     if (toClassArray == null) {
/* 403 */       toClassArray = ArrayUtils.EMPTY_CLASS_ARRAY;
/*     */     }
/* 405 */     for (int i = 0; i < classArray.length; i++) {
/* 406 */       if (!isAssignable(classArray[i], toClassArray[i])) {
/* 407 */         return false;
/*     */       }
/*     */     }
/* 410 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isAssignable(Class cls, Class toClass)
/*     */   {
/* 440 */     if (toClass == null) {
/* 441 */       return false;
/*     */     }
/*     */     
/* 444 */     if (cls == null) {
/* 445 */       return !toClass.isPrimitive();
/*     */     }
/* 447 */     if (cls.equals(toClass)) {
/* 448 */       return true;
/*     */     }
/* 450 */     if (cls.isPrimitive()) {
/* 451 */       if (!toClass.isPrimitive()) {
/* 452 */         return false;
/*     */       }
/* 454 */       if (Integer.TYPE.equals(cls)) {
/* 455 */         return (Long.TYPE.equals(toClass)) || (Float.TYPE.equals(toClass)) || (Double.TYPE.equals(toClass));
/*     */       }
/*     */       
/*     */ 
/* 459 */       if (Long.TYPE.equals(cls)) {
/* 460 */         return (Float.TYPE.equals(toClass)) || (Double.TYPE.equals(toClass));
/*     */       }
/*     */       
/* 463 */       if (Boolean.TYPE.equals(cls)) {
/* 464 */         return false;
/*     */       }
/* 466 */       if (Double.TYPE.equals(cls)) {
/* 467 */         return false;
/*     */       }
/* 469 */       if (Float.TYPE.equals(cls)) {
/* 470 */         return Double.TYPE.equals(toClass);
/*     */       }
/* 472 */       if (Character.TYPE.equals(cls)) {
/* 473 */         return (Integer.TYPE.equals(toClass)) || (Long.TYPE.equals(toClass)) || (Float.TYPE.equals(toClass)) || (Double.TYPE.equals(toClass));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 478 */       if (Short.TYPE.equals(cls)) {
/* 479 */         return (Integer.TYPE.equals(toClass)) || (Long.TYPE.equals(toClass)) || (Float.TYPE.equals(toClass)) || (Double.TYPE.equals(toClass));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 484 */       if (Byte.TYPE.equals(cls)) {
/* 485 */         return (Short.TYPE.equals(toClass)) || (Integer.TYPE.equals(toClass)) || (Long.TYPE.equals(toClass)) || (Float.TYPE.equals(toClass)) || (Double.TYPE.equals(toClass));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 492 */       return false;
/*     */     }
/* 494 */     return toClass.isAssignableFrom(cls);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class primitiveToWrapper(Class cls)
/*     */   {
/* 510 */     Class convertedClass = cls;
/* 511 */     if ((cls != null) && (cls.isPrimitive())) {
/* 512 */       convertedClass = (Class)primitiveWrapperMap.get(cls);
/*     */     }
/* 514 */     return convertedClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class[] primitivesToWrappers(Class[] classes)
/*     */   {
/* 528 */     if (classes == null) {
/* 529 */       return null;
/*     */     }
/*     */     
/* 532 */     if (classes.length == 0) {
/* 533 */       return classes;
/*     */     }
/*     */     
/* 536 */     Class[] convertedClasses = new Class[classes.length];
/* 537 */     for (int i = 0; i < classes.length; i++) {
/* 538 */       convertedClasses[i] = primitiveToWrapper(classes[i]);
/*     */     }
/* 540 */     return convertedClasses;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class wrapperToPrimitive(Class cls)
/*     */   {
/* 560 */     return (Class)wrapperPrimitiveMap.get(cls);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class[] wrappersToPrimitives(Class[] classes)
/*     */   {
/* 578 */     if (classes == null) {
/* 579 */       return null;
/*     */     }
/*     */     
/* 582 */     if (classes.length == 0) {
/* 583 */       return classes;
/*     */     }
/*     */     
/* 586 */     Class[] convertedClasses = new Class[classes.length];
/* 587 */     for (int i = 0; i < classes.length; i++) {
/* 588 */       convertedClasses[i] = wrapperToPrimitive(classes[i]);
/*     */     }
/* 590 */     return convertedClasses;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isInnerClass(Class cls)
/*     */   {
/* 603 */     if (cls == null) {
/* 604 */       return false;
/*     */     }
/* 606 */     return cls.getName().indexOf('$') >= 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class getClass(ClassLoader classLoader, String className, boolean initialize)
/*     */     throws ClassNotFoundException
/*     */   {
/*     */     Class clazz;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     Class clazz;
/*     */     
/*     */ 
/*     */ 
/* 625 */     if (abbreviationMap.containsKey(className)) {
/* 626 */       String clsName = "[" + abbreviationMap.get(className);
/* 627 */       clazz = Class.forName(clsName, initialize, classLoader).getComponentType();
/*     */     } else {
/* 629 */       clazz = Class.forName(toCanonicalName(className), initialize, classLoader);
/*     */     }
/* 631 */     return clazz;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class getClass(ClassLoader classLoader, String className)
/*     */     throws ClassNotFoundException
/*     */   {
/* 646 */     return getClass(classLoader, className, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class getClass(String className)
/*     */     throws ClassNotFoundException
/*     */   {
/* 660 */     return getClass(className, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class getClass(String className, boolean initialize)
/*     */     throws ClassNotFoundException
/*     */   {
/* 675 */     ClassLoader contextCL = Thread.currentThread().getContextClassLoader();
/* 676 */     ClassLoader loader = contextCL == null ? ClassUtils.class.getClassLoader() : contextCL;
/* 677 */     return getClass(loader, className, initialize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Method getPublicMethod(Class cls, String methodName, Class[] parameterTypes)
/*     */     throws SecurityException, NoSuchMethodException
/*     */   {
/* 706 */     Method declaredMethod = cls.getMethod(methodName, parameterTypes);
/* 707 */     if (Modifier.isPublic(declaredMethod.getDeclaringClass().getModifiers())) {
/* 708 */       return declaredMethod;
/*     */     }
/*     */     
/* 711 */     List candidateClasses = new ArrayList();
/* 712 */     candidateClasses.addAll(getAllInterfaces(cls));
/* 713 */     candidateClasses.addAll(getAllSuperclasses(cls));
/*     */     
/* 715 */     for (Iterator it = candidateClasses.iterator(); it.hasNext();) {
/* 716 */       Class candidateClass = (Class)it.next();
/* 717 */       if (Modifier.isPublic(candidateClass.getModifiers()))
/*     */       {
/*     */         Method candidateMethod;
/*     */         try
/*     */         {
/* 722 */           candidateMethod = candidateClass.getMethod(methodName, parameterTypes);
/*     */         } catch (NoSuchMethodException ex) {}
/* 724 */         continue;
/*     */         Method candidateMethod;
/* 726 */         if (Modifier.isPublic(candidateMethod.getDeclaringClass().getModifiers())) {
/* 727 */           return candidateMethod;
/*     */         }
/*     */       }
/*     */     }
/* 731 */     throw new NoSuchMethodException("Can't find a public method for " + methodName + " " + ArrayUtils.toString(parameterTypes));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String toCanonicalName(String className)
/*     */   {
/* 743 */     className = StringUtils.deleteWhitespace(className);
/* 744 */     if (className == null)
/* 745 */       throw new NullArgumentException("className");
/* 746 */     if (className.endsWith("[]")) {
/* 747 */       StringBuffer classNameBuffer = new StringBuffer();
/* 748 */       while (className.endsWith("[]")) {
/* 749 */         className = className.substring(0, className.length() - 2);
/* 750 */         classNameBuffer.append("[");
/*     */       }
/* 752 */       String abbreviation = (String)abbreviationMap.get(className);
/* 753 */       if (abbreviation != null) {
/* 754 */         classNameBuffer.append(abbreviation);
/*     */       } else {
/* 756 */         classNameBuffer.append("L").append(className).append(";");
/*     */       }
/* 758 */       className = classNameBuffer.toString();
/*     */     }
/* 760 */     return className;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class[] toClass(Object[] array)
/*     */   {
/* 774 */     if (array == null)
/* 775 */       return null;
/* 776 */     if (array.length == 0) {
/* 777 */       return ArrayUtils.EMPTY_CLASS_ARRAY;
/*     */     }
/* 779 */     Class[] classes = new Class[array.length];
/* 780 */     for (int i = 0; i < array.length; i++) {
/* 781 */       classes[i] = array[i].getClass();
/*     */     }
/* 783 */     return classes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getShortCanonicalName(Object object, String valueIfNull)
/*     */   {
/* 797 */     if (object == null) {
/* 798 */       return valueIfNull;
/*     */     }
/* 800 */     return getShortCanonicalName(object.getClass().getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getShortCanonicalName(Class cls)
/*     */   {
/* 811 */     if (cls == null) {
/* 812 */       return "";
/*     */     }
/* 814 */     return getShortCanonicalName(cls.getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getShortCanonicalName(String canonicalName)
/*     */   {
/* 827 */     return getShortClassName(getCanonicalName(canonicalName));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getPackageCanonicalName(Object object, String valueIfNull)
/*     */   {
/* 841 */     if (object == null) {
/* 842 */       return valueIfNull;
/*     */     }
/* 844 */     return getPackageCanonicalName(object.getClass().getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getPackageCanonicalName(Class cls)
/*     */   {
/* 855 */     if (cls == null) {
/* 856 */       return "";
/*     */     }
/* 858 */     return getPackageCanonicalName(cls.getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getPackageCanonicalName(String canonicalName)
/*     */   {
/* 872 */     return getPackageName(getCanonicalName(canonicalName));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String getCanonicalName(String className)
/*     */   {
/* 892 */     className = StringUtils.deleteWhitespace(className);
/* 893 */     if (className == null) {
/* 894 */       return null;
/*     */     }
/* 896 */     int dim = 0;
/* 897 */     while (className.startsWith("[")) {
/* 898 */       dim++;
/* 899 */       className = className.substring(1);
/*     */     }
/* 901 */     if (dim < 1) {
/* 902 */       return className;
/*     */     }
/* 904 */     if (className.startsWith("L")) {
/* 905 */       className = className.substring(1, className.endsWith(";") ? className.length() - 1 : className.length());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/* 911 */     else if (className.length() > 0) {
/* 912 */       className = (String)reverseAbbreviationMap.get(className.substring(0, 1));
/*     */     }
/*     */     
/*     */ 
/* 916 */     StringBuffer canonicalClassNameBuffer = new StringBuffer(className);
/* 917 */     for (int i = 0; i < dim; i++) {
/* 918 */       canonicalClassNameBuffer.append("[]");
/*     */     }
/* 920 */     return canonicalClassNameBuffer.toString();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-lang-2.4.jar!\org\apache\commons\lang\ClassUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */