/*     */ package org.apache.commons.lang.text;
/*     */ 
/*     */ import java.text.Format;
/*     */ import java.text.MessageFormat;
/*     */ import java.text.ParsePosition;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExtendedMessageFormat
/*     */   extends MessageFormat
/*     */ {
/*     */   private static final long serialVersionUID = -2362048321261811743L;
/*     */   private static final String DUMMY_PATTERN = "";
/*     */   private static final String ESCAPED_QUOTE = "''";
/*     */   private static final char START_FMT = ',';
/*     */   private static final char END_FE = '}';
/*     */   private static final char START_FE = '{';
/*     */   private static final char QUOTE = '\'';
/*     */   private String toPattern;
/*     */   private Map registry;
/*     */   
/*     */   public ExtendedMessageFormat(String pattern)
/*     */   {
/*  90 */     this(pattern, Locale.getDefault());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExtendedMessageFormat(String pattern, Locale locale)
/*     */   {
/* 101 */     this(pattern, locale, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExtendedMessageFormat(String pattern, Map registry)
/*     */   {
/* 112 */     this(pattern, Locale.getDefault(), registry);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExtendedMessageFormat(String pattern, Locale locale, Map registry)
/*     */   {
/* 124 */     super("");
/* 125 */     setLocale(locale);
/* 126 */     this.registry = registry;
/* 127 */     applyPattern(pattern);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toPattern()
/*     */   {
/* 134 */     return this.toPattern;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void applyPattern(String pattern)
/*     */   {
/* 143 */     if (this.registry == null) {
/* 144 */       super.applyPattern(pattern);
/* 145 */       this.toPattern = super.toPattern();
/* 146 */       return;
/*     */     }
/* 148 */     ArrayList foundFormats = new ArrayList();
/* 149 */     ArrayList foundDescriptions = new ArrayList();
/* 150 */     StringBuffer stripCustom = new StringBuffer(pattern.length());
/*     */     
/* 152 */     ParsePosition pos = new ParsePosition(0);
/* 153 */     char[] c = pattern.toCharArray();
/* 154 */     int fmtCount = 0;
/* 155 */     while (pos.getIndex() < pattern.length()) {
/* 156 */       switch (c[pos.getIndex()]) {
/*     */       case '\'': 
/* 158 */         appendQuotedString(pattern, pos, stripCustom, true);
/* 159 */         break;
/*     */       case '{': 
/* 161 */         fmtCount++;
/* 162 */         seekNonWs(pattern, pos);
/* 163 */         int start = pos.getIndex();
/* 164 */         int index = readArgumentIndex(pattern, next(pos));
/* 165 */         stripCustom.append('{').append(index);
/* 166 */         seekNonWs(pattern, pos);
/* 167 */         Format format = null;
/* 168 */         String formatDescription = null;
/* 169 */         if (c[pos.getIndex()] == ',') {
/* 170 */           formatDescription = parseFormatDescription(pattern, next(pos));
/*     */           
/* 172 */           format = getFormat(formatDescription);
/* 173 */           if (format == null) {
/* 174 */             stripCustom.append(',').append(formatDescription);
/*     */           }
/*     */         }
/* 177 */         foundFormats.add(format);
/* 178 */         foundDescriptions.add(format == null ? null : formatDescription);
/* 179 */         Validate.isTrue(foundFormats.size() == fmtCount);
/* 180 */         Validate.isTrue(foundDescriptions.size() == fmtCount);
/* 181 */         if (c[pos.getIndex()] != '}') {
/* 182 */           throw new IllegalArgumentException("Unreadable format element at position " + start);
/*     */         }
/*     */       
/*     */ 
/*     */       default: 
/* 187 */         stripCustom.append(c[pos.getIndex()]);
/* 188 */         next(pos);
/*     */       }
/*     */     }
/* 191 */     super.applyPattern(stripCustom.toString());
/* 192 */     this.toPattern = insertFormats(super.toPattern(), foundDescriptions);
/* 193 */     if (containsElements(foundFormats)) {
/* 194 */       Format[] origFormats = getFormats();
/*     */       
/*     */ 
/* 197 */       int i = 0;
/* 198 */       for (Iterator it = foundFormats.iterator(); it.hasNext(); i++) {
/* 199 */         Format f = (Format)it.next();
/* 200 */         if (f != null) {
/* 201 */           origFormats[i] = f;
/*     */         }
/*     */       }
/* 204 */       super.setFormats(origFormats);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFormat(int formatElementIndex, Format newFormat)
/*     */   {
/* 213 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFormatByArgumentIndex(int argumentIndex, Format newFormat)
/*     */   {
/* 221 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFormats(Format[] newFormats)
/*     */   {
/* 229 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFormatsByArgumentIndex(Format[] newFormats)
/*     */   {
/* 237 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Format getFormat(String desc)
/*     */   {
/* 247 */     if (this.registry != null) {
/* 248 */       String name = desc;
/* 249 */       String args = null;
/* 250 */       int i = desc.indexOf(',');
/* 251 */       if (i > 0) {
/* 252 */         name = desc.substring(0, i).trim();
/* 253 */         args = desc.substring(i + 1).trim();
/*     */       }
/* 255 */       FormatFactory factory = (FormatFactory)this.registry.get(name);
/* 256 */       if (factory != null) {
/* 257 */         return factory.getFormat(name, args, getLocale());
/*     */       }
/*     */     }
/* 260 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int readArgumentIndex(String pattern, ParsePosition pos)
/*     */   {
/* 271 */     int start = pos.getIndex();
/* 272 */     seekNonWs(pattern, pos);
/* 273 */     StringBuffer result = new StringBuffer();
/* 274 */     boolean error = false;
/* 275 */     for (; (!error) && (pos.getIndex() < pattern.length()); next(pos)) {
/* 276 */       char c = pattern.charAt(pos.getIndex());
/* 277 */       if (Character.isWhitespace(c)) {
/* 278 */         seekNonWs(pattern, pos);
/* 279 */         c = pattern.charAt(pos.getIndex());
/* 280 */         if ((c != ',') && (c != '}')) {
/* 281 */           error = true;
/* 282 */           continue;
/*     */         }
/*     */       }
/* 285 */       if (((c == ',') || (c == '}')) && (result.length() > 0)) {
/*     */         try {
/* 287 */           return Integer.parseInt(result.toString());
/*     */         }
/*     */         catch (NumberFormatException e) {}
/*     */       }
/*     */       
/*     */ 
/* 293 */       error = !Character.isDigit(c);
/* 294 */       result.append(c);
/*     */     }
/* 296 */     if (error) {
/* 297 */       throw new IllegalArgumentException("Invalid format argument index at position " + start + ": " + pattern.substring(start, pos.getIndex()));
/*     */     }
/*     */     
/*     */ 
/* 301 */     throw new IllegalArgumentException("Unterminated format element at position " + start);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String parseFormatDescription(String pattern, ParsePosition pos)
/*     */   {
/* 313 */     int start = pos.getIndex();
/* 314 */     seekNonWs(pattern, pos);
/* 315 */     int text = pos.getIndex();
/* 316 */     int depth = 1;
/* 317 */     for (; pos.getIndex() < pattern.length(); next(pos)) {
/* 318 */       switch (pattern.charAt(pos.getIndex())) {
/*     */       case '{': 
/* 320 */         depth++;
/* 321 */         break;
/*     */       case '}': 
/* 323 */         depth--;
/* 324 */         if (depth == 0) {
/* 325 */           return pattern.substring(text, pos.getIndex());
/*     */         }
/*     */         break;
/*     */       case '\'': 
/* 329 */         getQuotedString(pattern, pos, false);
/*     */       }
/*     */       
/*     */     }
/* 333 */     throw new IllegalArgumentException("Unterminated format element at position " + start);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String insertFormats(String pattern, ArrayList customPatterns)
/*     */   {
/* 345 */     if (!containsElements(customPatterns)) {
/* 346 */       return pattern;
/*     */     }
/* 348 */     StringBuffer sb = new StringBuffer(pattern.length() * 2);
/* 349 */     ParsePosition pos = new ParsePosition(0);
/* 350 */     int fe = -1;
/* 351 */     int depth = 0;
/* 352 */     while (pos.getIndex() < pattern.length()) {
/* 353 */       char c = pattern.charAt(pos.getIndex());
/* 354 */       switch (c) {
/*     */       case '\'': 
/* 356 */         appendQuotedString(pattern, pos, sb, false);
/* 357 */         break;
/*     */       case '{': 
/* 359 */         depth++;
/* 360 */         if (depth == 1) {
/* 361 */           fe++;
/* 362 */           sb.append('{').append(readArgumentIndex(pattern, next(pos)));
/*     */           
/* 364 */           String customPattern = (String)customPatterns.get(fe);
/* 365 */           if (customPattern != null) {
/* 366 */             sb.append(',').append(customPattern);
/*     */           }
/*     */         }
/*     */         break;
/*     */       case '}': 
/* 371 */         depth--;
/*     */       
/*     */       default: 
/* 374 */         sb.append(c);
/* 375 */         next(pos);
/*     */       }
/*     */     }
/* 378 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void seekNonWs(String pattern, ParsePosition pos)
/*     */   {
/* 388 */     int len = 0;
/* 389 */     char[] buffer = pattern.toCharArray();
/*     */     do {
/* 391 */       len = StrMatcher.splitMatcher().isMatch(buffer, pos.getIndex());
/* 392 */       pos.setIndex(pos.getIndex() + len);
/* 393 */     } while ((len > 0) && (pos.getIndex() < pattern.length()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ParsePosition next(ParsePosition pos)
/*     */   {
/* 403 */     pos.setIndex(pos.getIndex() + 1);
/* 404 */     return pos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private StringBuffer appendQuotedString(String pattern, ParsePosition pos, StringBuffer appendTo, boolean escapingOn)
/*     */   {
/* 419 */     int start = pos.getIndex();
/* 420 */     char[] c = pattern.toCharArray();
/* 421 */     if ((escapingOn) && (c[start] == '\'')) {
/* 422 */       return appendTo == null ? null : appendTo.append('\'');
/*     */     }
/* 424 */     int lastHold = start;
/* 425 */     for (int i = pos.getIndex(); i < pattern.length(); i++) {
/* 426 */       if ((escapingOn) && (pattern.substring(i).startsWith("''"))) {
/* 427 */         appendTo.append(c, lastHold, pos.getIndex() - lastHold).append('\'');
/*     */         
/* 429 */         pos.setIndex(i + "''".length());
/* 430 */         lastHold = pos.getIndex();
/*     */       }
/*     */       else {
/* 433 */         switch (c[pos.getIndex()]) {
/*     */         case '\'': 
/* 435 */           next(pos);
/* 436 */           return appendTo == null ? null : appendTo.append(c, lastHold, pos.getIndex() - lastHold);
/*     */         }
/*     */         
/* 439 */         next(pos);
/*     */       }
/*     */     }
/* 442 */     throw new IllegalArgumentException("Unterminated quoted string at position " + start);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void getQuotedString(String pattern, ParsePosition pos, boolean escapingOn)
/*     */   {
/* 455 */     appendQuotedString(pattern, pos, null, escapingOn);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean containsElements(Collection coll)
/*     */   {
/* 464 */     if ((coll == null) || (coll.size() == 0)) {
/* 465 */       return false;
/*     */     }
/* 467 */     for (Iterator iter = coll.iterator(); iter.hasNext();) {
/* 468 */       if (iter.next() != null) {
/* 469 */         return true;
/*     */       }
/*     */     }
/* 472 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-lang-2.4.jar!\org\apache\commons\lang\text\ExtendedMessageFormat.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */