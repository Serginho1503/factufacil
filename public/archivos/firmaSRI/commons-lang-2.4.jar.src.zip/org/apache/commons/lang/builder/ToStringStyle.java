/*      */ package org.apache.commons.lang.builder;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.Array;
/*      */ import java.util.Collection;
/*      */ import java.util.HashSet;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.apache.commons.lang.ClassUtils;
/*      */ import org.apache.commons.lang.ObjectUtils;
/*      */ import org.apache.commons.lang.SystemUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class ToStringStyle
/*      */   implements Serializable
/*      */ {
/*   81 */   public static final ToStringStyle DEFAULT_STYLE = new DefaultToStringStyle();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   95 */   public static final ToStringStyle MULTI_LINE_STYLE = new MultiLineToStringStyle();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  106 */   public static final ToStringStyle NO_FIELD_NAMES_STYLE = new NoFieldNameToStringStyle();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  118 */   public static final ToStringStyle SHORT_PREFIX_STYLE = new ShortPrefixToStringStyle();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  128 */   public static final ToStringStyle SIMPLE_STYLE = new SimpleToStringStyle();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  136 */   private static ThreadLocal registry = new ThreadLocal()
/*      */   {
/*      */     protected Object initialValue()
/*      */     {
/*  140 */       return new HashSet();
/*      */     }
/*      */   };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static Set getRegistry()
/*      */   {
/*  153 */     return (Set)registry.get();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static boolean isRegistered(Object value)
/*      */   {
/*  168 */     return getRegistry().contains(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void register(Object value)
/*      */   {
/*  181 */     if (value != null) {
/*  182 */       getRegistry().add(value);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void unregister(Object value)
/*      */   {
/*  199 */     getRegistry().remove(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  205 */   private boolean useFieldNames = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  210 */   private boolean useClassName = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  215 */   private boolean useShortClassName = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  220 */   private boolean useIdentityHashCode = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  225 */   private String contentStart = "[";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  230 */   private String contentEnd = "]";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  235 */   private String fieldNameValueSeparator = "=";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  240 */   private boolean fieldSeparatorAtStart = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  245 */   private boolean fieldSeparatorAtEnd = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  250 */   private String fieldSeparator = ",";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  255 */   private String arrayStart = "{";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  260 */   private String arraySeparator = ",";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  265 */   private boolean arrayContentDetail = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  270 */   private String arrayEnd = "}";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  276 */   private boolean defaultFullDetail = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  281 */   private String nullText = "<null>";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  286 */   private String sizeStartText = "<size=";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  291 */   private String sizeEndText = ">";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  296 */   private String summaryObjectStartText = "<";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  301 */   private String summaryObjectEndText = ">";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void appendSuper(StringBuffer buffer, String superToString)
/*      */   {
/*  325 */     appendToString(buffer, superToString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void appendToString(StringBuffer buffer, String toString)
/*      */   {
/*  339 */     if (toString != null) {
/*  340 */       int pos1 = toString.indexOf(this.contentStart) + this.contentStart.length();
/*  341 */       int pos2 = toString.lastIndexOf(this.contentEnd);
/*  342 */       if ((pos1 != pos2) && (pos1 >= 0) && (pos2 >= 0)) {
/*  343 */         String data = toString.substring(pos1, pos2);
/*  344 */         if (this.fieldSeparatorAtStart) {
/*  345 */           removeLastFieldSeparator(buffer);
/*      */         }
/*  347 */         buffer.append(data);
/*  348 */         appendFieldSeparator(buffer);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void appendStart(StringBuffer buffer, Object object)
/*      */   {
/*  360 */     if (object != null) {
/*  361 */       appendClassName(buffer, object);
/*  362 */       appendIdentityHashCode(buffer, object);
/*  363 */       appendContentStart(buffer);
/*  364 */       if (this.fieldSeparatorAtStart) {
/*  365 */         appendFieldSeparator(buffer);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void appendEnd(StringBuffer buffer, Object object)
/*      */   {
/*  378 */     if (!this.fieldSeparatorAtEnd) {
/*  379 */       removeLastFieldSeparator(buffer);
/*      */     }
/*  381 */     appendContentEnd(buffer);
/*  382 */     unregister(object);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void removeLastFieldSeparator(StringBuffer buffer)
/*      */   {
/*  392 */     int len = buffer.length();
/*  393 */     int sepLen = this.fieldSeparator.length();
/*  394 */     if ((len > 0) && (sepLen > 0) && (len >= sepLen)) {
/*  395 */       boolean match = true;
/*  396 */       for (int i = 0; i < sepLen; i++) {
/*  397 */         if (buffer.charAt(len - 1 - i) != this.fieldSeparator.charAt(sepLen - 1 - i)) {
/*  398 */           match = false;
/*  399 */           break;
/*      */         }
/*      */       }
/*  402 */       if (match) {
/*  403 */         buffer.setLength(len - sepLen);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void append(StringBuffer buffer, String fieldName, Object value, Boolean fullDetail)
/*      */   {
/*  422 */     appendFieldStart(buffer, fieldName);
/*      */     
/*  424 */     if (value == null) {
/*  425 */       appendNullText(buffer, fieldName);
/*      */     }
/*      */     else {
/*  428 */       appendInternal(buffer, fieldName, value, isFullDetail(fullDetail));
/*      */     }
/*      */     
/*  431 */     appendFieldEnd(buffer, fieldName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendInternal(StringBuffer buffer, String fieldName, Object value, boolean detail)
/*      */   {
/*  454 */     if ((isRegistered(value)) && (!(value instanceof Number)) && (!(value instanceof Boolean)) && (!(value instanceof Character)))
/*      */     {
/*  456 */       appendCyclicObject(buffer, fieldName, value);
/*  457 */       return;
/*      */     }
/*      */     
/*  460 */     register(value);
/*      */     try
/*      */     {
/*  463 */       if ((value instanceof Collection)) {
/*  464 */         if (detail) {
/*  465 */           appendDetail(buffer, fieldName, (Collection)value);
/*      */         } else {
/*  467 */           appendSummarySize(buffer, fieldName, ((Collection)value).size());
/*      */         }
/*      */       }
/*  470 */       else if ((value instanceof Map)) {
/*  471 */         if (detail) {
/*  472 */           appendDetail(buffer, fieldName, (Map)value);
/*      */         } else {
/*  474 */           appendSummarySize(buffer, fieldName, ((Map)value).size());
/*      */         }
/*      */       }
/*  477 */       else if ((value instanceof long[])) {
/*  478 */         if (detail) {
/*  479 */           appendDetail(buffer, fieldName, (long[])value);
/*      */         } else {
/*  481 */           appendSummary(buffer, fieldName, (long[])value);
/*      */         }
/*      */       }
/*  484 */       else if ((value instanceof int[])) {
/*  485 */         if (detail) {
/*  486 */           appendDetail(buffer, fieldName, (int[])value);
/*      */         } else {
/*  488 */           appendSummary(buffer, fieldName, (int[])value);
/*      */         }
/*      */       }
/*  491 */       else if ((value instanceof short[])) {
/*  492 */         if (detail) {
/*  493 */           appendDetail(buffer, fieldName, (short[])value);
/*      */         } else {
/*  495 */           appendSummary(buffer, fieldName, (short[])value);
/*      */         }
/*      */       }
/*  498 */       else if ((value instanceof byte[])) {
/*  499 */         if (detail) {
/*  500 */           appendDetail(buffer, fieldName, (byte[])value);
/*      */         } else {
/*  502 */           appendSummary(buffer, fieldName, (byte[])value);
/*      */         }
/*      */       }
/*  505 */       else if ((value instanceof char[])) {
/*  506 */         if (detail) {
/*  507 */           appendDetail(buffer, fieldName, (char[])value);
/*      */         } else {
/*  509 */           appendSummary(buffer, fieldName, (char[])value);
/*      */         }
/*      */       }
/*  512 */       else if ((value instanceof double[])) {
/*  513 */         if (detail) {
/*  514 */           appendDetail(buffer, fieldName, (double[])value);
/*      */         } else {
/*  516 */           appendSummary(buffer, fieldName, (double[])value);
/*      */         }
/*      */       }
/*  519 */       else if ((value instanceof float[])) {
/*  520 */         if (detail) {
/*  521 */           appendDetail(buffer, fieldName, (float[])value);
/*      */         } else {
/*  523 */           appendSummary(buffer, fieldName, (float[])value);
/*      */         }
/*      */       }
/*  526 */       else if ((value instanceof boolean[])) {
/*  527 */         if (detail) {
/*  528 */           appendDetail(buffer, fieldName, (boolean[])value);
/*      */         } else {
/*  530 */           appendSummary(buffer, fieldName, (boolean[])value);
/*      */         }
/*      */       }
/*  533 */       else if (value.getClass().isArray()) {
/*  534 */         if (detail) {
/*  535 */           appendDetail(buffer, fieldName, (Object[])value);
/*      */         } else {
/*  537 */           appendSummary(buffer, fieldName, (Object[])value);
/*      */         }
/*      */         
/*      */       }
/*  541 */       else if (detail) {
/*  542 */         appendDetail(buffer, fieldName, value);
/*      */       } else {
/*  544 */         appendSummary(buffer, fieldName, value);
/*      */       }
/*      */     }
/*      */     finally {
/*  548 */       unregister(value);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendCyclicObject(StringBuffer buffer, String fieldName, Object value)
/*      */   {
/*  565 */     ObjectUtils.appendIdentityToString(buffer, value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendDetail(StringBuffer buffer, String fieldName, Object value)
/*      */   {
/*  578 */     buffer.append(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendDetail(StringBuffer buffer, String fieldName, Collection coll)
/*      */   {
/*  590 */     buffer.append(coll);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendDetail(StringBuffer buffer, String fieldName, Map map)
/*      */   {
/*  602 */     buffer.append(map);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendSummary(StringBuffer buffer, String fieldName, Object value)
/*      */   {
/*  615 */     buffer.append(this.summaryObjectStartText);
/*  616 */     buffer.append(getShortClassName(value.getClass()));
/*  617 */     buffer.append(this.summaryObjectEndText);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void append(StringBuffer buffer, String fieldName, long value)
/*      */   {
/*  631 */     appendFieldStart(buffer, fieldName);
/*  632 */     appendDetail(buffer, fieldName, value);
/*  633 */     appendFieldEnd(buffer, fieldName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendDetail(StringBuffer buffer, String fieldName, long value)
/*      */   {
/*  645 */     buffer.append(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void append(StringBuffer buffer, String fieldName, int value)
/*      */   {
/*  659 */     appendFieldStart(buffer, fieldName);
/*  660 */     appendDetail(buffer, fieldName, value);
/*  661 */     appendFieldEnd(buffer, fieldName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendDetail(StringBuffer buffer, String fieldName, int value)
/*      */   {
/*  673 */     buffer.append(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void append(StringBuffer buffer, String fieldName, short value)
/*      */   {
/*  687 */     appendFieldStart(buffer, fieldName);
/*  688 */     appendDetail(buffer, fieldName, value);
/*  689 */     appendFieldEnd(buffer, fieldName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendDetail(StringBuffer buffer, String fieldName, short value)
/*      */   {
/*  701 */     buffer.append(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void append(StringBuffer buffer, String fieldName, byte value)
/*      */   {
/*  715 */     appendFieldStart(buffer, fieldName);
/*  716 */     appendDetail(buffer, fieldName, value);
/*  717 */     appendFieldEnd(buffer, fieldName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendDetail(StringBuffer buffer, String fieldName, byte value)
/*      */   {
/*  729 */     buffer.append(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void append(StringBuffer buffer, String fieldName, char value)
/*      */   {
/*  743 */     appendFieldStart(buffer, fieldName);
/*  744 */     appendDetail(buffer, fieldName, value);
/*  745 */     appendFieldEnd(buffer, fieldName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendDetail(StringBuffer buffer, String fieldName, char value)
/*      */   {
/*  757 */     buffer.append(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void append(StringBuffer buffer, String fieldName, double value)
/*      */   {
/*  771 */     appendFieldStart(buffer, fieldName);
/*  772 */     appendDetail(buffer, fieldName, value);
/*  773 */     appendFieldEnd(buffer, fieldName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendDetail(StringBuffer buffer, String fieldName, double value)
/*      */   {
/*  785 */     buffer.append(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void append(StringBuffer buffer, String fieldName, float value)
/*      */   {
/*  799 */     appendFieldStart(buffer, fieldName);
/*  800 */     appendDetail(buffer, fieldName, value);
/*  801 */     appendFieldEnd(buffer, fieldName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendDetail(StringBuffer buffer, String fieldName, float value)
/*      */   {
/*  813 */     buffer.append(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void append(StringBuffer buffer, String fieldName, boolean value)
/*      */   {
/*  827 */     appendFieldStart(buffer, fieldName);
/*  828 */     appendDetail(buffer, fieldName, value);
/*  829 */     appendFieldEnd(buffer, fieldName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendDetail(StringBuffer buffer, String fieldName, boolean value)
/*      */   {
/*  841 */     buffer.append(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void append(StringBuffer buffer, String fieldName, Object[] array, Boolean fullDetail)
/*      */   {
/*  855 */     appendFieldStart(buffer, fieldName);
/*      */     
/*  857 */     if (array == null) {
/*  858 */       appendNullText(buffer, fieldName);
/*      */     }
/*  860 */     else if (isFullDetail(fullDetail)) {
/*  861 */       appendDetail(buffer, fieldName, array);
/*      */     }
/*      */     else {
/*  864 */       appendSummary(buffer, fieldName, array);
/*      */     }
/*      */     
/*  867 */     appendFieldEnd(buffer, fieldName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendDetail(StringBuffer buffer, String fieldName, Object[] array)
/*      */   {
/*  882 */     buffer.append(this.arrayStart);
/*  883 */     for (int i = 0; i < array.length; i++) {
/*  884 */       Object item = array[i];
/*  885 */       if (i > 0) {
/*  886 */         buffer.append(this.arraySeparator);
/*      */       }
/*  888 */       if (item == null) {
/*  889 */         appendNullText(buffer, fieldName);
/*      */       }
/*      */       else {
/*  892 */         appendInternal(buffer, fieldName, item, this.arrayContentDetail);
/*      */       }
/*      */     }
/*  895 */     buffer.append(this.arrayEnd);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void reflectionAppendArrayDetail(StringBuffer buffer, String fieldName, Object array)
/*      */   {
/*  908 */     buffer.append(this.arrayStart);
/*  909 */     int length = Array.getLength(array);
/*  910 */     for (int i = 0; i < length; i++) {
/*  911 */       Object item = Array.get(array, i);
/*  912 */       if (i > 0) {
/*  913 */         buffer.append(this.arraySeparator);
/*      */       }
/*  915 */       if (item == null) {
/*  916 */         appendNullText(buffer, fieldName);
/*      */       }
/*      */       else {
/*  919 */         appendInternal(buffer, fieldName, item, this.arrayContentDetail);
/*      */       }
/*      */     }
/*  922 */     buffer.append(this.arrayEnd);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendSummary(StringBuffer buffer, String fieldName, Object[] array)
/*      */   {
/*  935 */     appendSummarySize(buffer, fieldName, array.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void append(StringBuffer buffer, String fieldName, long[] array, Boolean fullDetail)
/*      */   {
/*  951 */     appendFieldStart(buffer, fieldName);
/*      */     
/*  953 */     if (array == null) {
/*  954 */       appendNullText(buffer, fieldName);
/*      */     }
/*  956 */     else if (isFullDetail(fullDetail)) {
/*  957 */       appendDetail(buffer, fieldName, array);
/*      */     }
/*      */     else {
/*  960 */       appendSummary(buffer, fieldName, array);
/*      */     }
/*      */     
/*  963 */     appendFieldEnd(buffer, fieldName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendDetail(StringBuffer buffer, String fieldName, long[] array)
/*      */   {
/*  976 */     buffer.append(this.arrayStart);
/*  977 */     for (int i = 0; i < array.length; i++) {
/*  978 */       if (i > 0) {
/*  979 */         buffer.append(this.arraySeparator);
/*      */       }
/*  981 */       appendDetail(buffer, fieldName, array[i]);
/*      */     }
/*  983 */     buffer.append(this.arrayEnd);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendSummary(StringBuffer buffer, String fieldName, long[] array)
/*      */   {
/*  996 */     appendSummarySize(buffer, fieldName, array.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void append(StringBuffer buffer, String fieldName, int[] array, Boolean fullDetail)
/*      */   {
/* 1012 */     appendFieldStart(buffer, fieldName);
/*      */     
/* 1014 */     if (array == null) {
/* 1015 */       appendNullText(buffer, fieldName);
/*      */     }
/* 1017 */     else if (isFullDetail(fullDetail)) {
/* 1018 */       appendDetail(buffer, fieldName, array);
/*      */     }
/*      */     else {
/* 1021 */       appendSummary(buffer, fieldName, array);
/*      */     }
/*      */     
/* 1024 */     appendFieldEnd(buffer, fieldName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendDetail(StringBuffer buffer, String fieldName, int[] array)
/*      */   {
/* 1037 */     buffer.append(this.arrayStart);
/* 1038 */     for (int i = 0; i < array.length; i++) {
/* 1039 */       if (i > 0) {
/* 1040 */         buffer.append(this.arraySeparator);
/*      */       }
/* 1042 */       appendDetail(buffer, fieldName, array[i]);
/*      */     }
/* 1044 */     buffer.append(this.arrayEnd);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendSummary(StringBuffer buffer, String fieldName, int[] array)
/*      */   {
/* 1057 */     appendSummarySize(buffer, fieldName, array.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void append(StringBuffer buffer, String fieldName, short[] array, Boolean fullDetail)
/*      */   {
/* 1073 */     appendFieldStart(buffer, fieldName);
/*      */     
/* 1075 */     if (array == null) {
/* 1076 */       appendNullText(buffer, fieldName);
/*      */     }
/* 1078 */     else if (isFullDetail(fullDetail)) {
/* 1079 */       appendDetail(buffer, fieldName, array);
/*      */     }
/*      */     else {
/* 1082 */       appendSummary(buffer, fieldName, array);
/*      */     }
/*      */     
/* 1085 */     appendFieldEnd(buffer, fieldName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendDetail(StringBuffer buffer, String fieldName, short[] array)
/*      */   {
/* 1098 */     buffer.append(this.arrayStart);
/* 1099 */     for (int i = 0; i < array.length; i++) {
/* 1100 */       if (i > 0) {
/* 1101 */         buffer.append(this.arraySeparator);
/*      */       }
/* 1103 */       appendDetail(buffer, fieldName, array[i]);
/*      */     }
/* 1105 */     buffer.append(this.arrayEnd);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendSummary(StringBuffer buffer, String fieldName, short[] array)
/*      */   {
/* 1118 */     appendSummarySize(buffer, fieldName, array.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void append(StringBuffer buffer, String fieldName, byte[] array, Boolean fullDetail)
/*      */   {
/* 1134 */     appendFieldStart(buffer, fieldName);
/*      */     
/* 1136 */     if (array == null) {
/* 1137 */       appendNullText(buffer, fieldName);
/*      */     }
/* 1139 */     else if (isFullDetail(fullDetail)) {
/* 1140 */       appendDetail(buffer, fieldName, array);
/*      */     }
/*      */     else {
/* 1143 */       appendSummary(buffer, fieldName, array);
/*      */     }
/*      */     
/* 1146 */     appendFieldEnd(buffer, fieldName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendDetail(StringBuffer buffer, String fieldName, byte[] array)
/*      */   {
/* 1159 */     buffer.append(this.arrayStart);
/* 1160 */     for (int i = 0; i < array.length; i++) {
/* 1161 */       if (i > 0) {
/* 1162 */         buffer.append(this.arraySeparator);
/*      */       }
/* 1164 */       appendDetail(buffer, fieldName, array[i]);
/*      */     }
/* 1166 */     buffer.append(this.arrayEnd);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendSummary(StringBuffer buffer, String fieldName, byte[] array)
/*      */   {
/* 1179 */     appendSummarySize(buffer, fieldName, array.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void append(StringBuffer buffer, String fieldName, char[] array, Boolean fullDetail)
/*      */   {
/* 1195 */     appendFieldStart(buffer, fieldName);
/*      */     
/* 1197 */     if (array == null) {
/* 1198 */       appendNullText(buffer, fieldName);
/*      */     }
/* 1200 */     else if (isFullDetail(fullDetail)) {
/* 1201 */       appendDetail(buffer, fieldName, array);
/*      */     }
/*      */     else {
/* 1204 */       appendSummary(buffer, fieldName, array);
/*      */     }
/*      */     
/* 1207 */     appendFieldEnd(buffer, fieldName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendDetail(StringBuffer buffer, String fieldName, char[] array)
/*      */   {
/* 1220 */     buffer.append(this.arrayStart);
/* 1221 */     for (int i = 0; i < array.length; i++) {
/* 1222 */       if (i > 0) {
/* 1223 */         buffer.append(this.arraySeparator);
/*      */       }
/* 1225 */       appendDetail(buffer, fieldName, array[i]);
/*      */     }
/* 1227 */     buffer.append(this.arrayEnd);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendSummary(StringBuffer buffer, String fieldName, char[] array)
/*      */   {
/* 1240 */     appendSummarySize(buffer, fieldName, array.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void append(StringBuffer buffer, String fieldName, double[] array, Boolean fullDetail)
/*      */   {
/* 1256 */     appendFieldStart(buffer, fieldName);
/*      */     
/* 1258 */     if (array == null) {
/* 1259 */       appendNullText(buffer, fieldName);
/*      */     }
/* 1261 */     else if (isFullDetail(fullDetail)) {
/* 1262 */       appendDetail(buffer, fieldName, array);
/*      */     }
/*      */     else {
/* 1265 */       appendSummary(buffer, fieldName, array);
/*      */     }
/*      */     
/* 1268 */     appendFieldEnd(buffer, fieldName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendDetail(StringBuffer buffer, String fieldName, double[] array)
/*      */   {
/* 1281 */     buffer.append(this.arrayStart);
/* 1282 */     for (int i = 0; i < array.length; i++) {
/* 1283 */       if (i > 0) {
/* 1284 */         buffer.append(this.arraySeparator);
/*      */       }
/* 1286 */       appendDetail(buffer, fieldName, array[i]);
/*      */     }
/* 1288 */     buffer.append(this.arrayEnd);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendSummary(StringBuffer buffer, String fieldName, double[] array)
/*      */   {
/* 1301 */     appendSummarySize(buffer, fieldName, array.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void append(StringBuffer buffer, String fieldName, float[] array, Boolean fullDetail)
/*      */   {
/* 1317 */     appendFieldStart(buffer, fieldName);
/*      */     
/* 1319 */     if (array == null) {
/* 1320 */       appendNullText(buffer, fieldName);
/*      */     }
/* 1322 */     else if (isFullDetail(fullDetail)) {
/* 1323 */       appendDetail(buffer, fieldName, array);
/*      */     }
/*      */     else {
/* 1326 */       appendSummary(buffer, fieldName, array);
/*      */     }
/*      */     
/* 1329 */     appendFieldEnd(buffer, fieldName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendDetail(StringBuffer buffer, String fieldName, float[] array)
/*      */   {
/* 1342 */     buffer.append(this.arrayStart);
/* 1343 */     for (int i = 0; i < array.length; i++) {
/* 1344 */       if (i > 0) {
/* 1345 */         buffer.append(this.arraySeparator);
/*      */       }
/* 1347 */       appendDetail(buffer, fieldName, array[i]);
/*      */     }
/* 1349 */     buffer.append(this.arrayEnd);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendSummary(StringBuffer buffer, String fieldName, float[] array)
/*      */   {
/* 1362 */     appendSummarySize(buffer, fieldName, array.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void append(StringBuffer buffer, String fieldName, boolean[] array, Boolean fullDetail)
/*      */   {
/* 1378 */     appendFieldStart(buffer, fieldName);
/*      */     
/* 1380 */     if (array == null) {
/* 1381 */       appendNullText(buffer, fieldName);
/*      */     }
/* 1383 */     else if (isFullDetail(fullDetail)) {
/* 1384 */       appendDetail(buffer, fieldName, array);
/*      */     }
/*      */     else {
/* 1387 */       appendSummary(buffer, fieldName, array);
/*      */     }
/*      */     
/* 1390 */     appendFieldEnd(buffer, fieldName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendDetail(StringBuffer buffer, String fieldName, boolean[] array)
/*      */   {
/* 1403 */     buffer.append(this.arrayStart);
/* 1404 */     for (int i = 0; i < array.length; i++) {
/* 1405 */       if (i > 0) {
/* 1406 */         buffer.append(this.arraySeparator);
/*      */       }
/* 1408 */       appendDetail(buffer, fieldName, array[i]);
/*      */     }
/* 1410 */     buffer.append(this.arrayEnd);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendSummary(StringBuffer buffer, String fieldName, boolean[] array)
/*      */   {
/* 1423 */     appendSummarySize(buffer, fieldName, array.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendClassName(StringBuffer buffer, Object object)
/*      */   {
/* 1435 */     if ((this.useClassName) && (object != null)) {
/* 1436 */       register(object);
/* 1437 */       if (this.useShortClassName) {
/* 1438 */         buffer.append(getShortClassName(object.getClass()));
/*      */       } else {
/* 1440 */         buffer.append(object.getClass().getName());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendIdentityHashCode(StringBuffer buffer, Object object)
/*      */   {
/* 1452 */     if ((isUseIdentityHashCode()) && (object != null)) {
/* 1453 */       register(object);
/* 1454 */       buffer.append('@');
/* 1455 */       buffer.append(Integer.toHexString(System.identityHashCode(object)));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendContentStart(StringBuffer buffer)
/*      */   {
/* 1465 */     buffer.append(this.contentStart);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendContentEnd(StringBuffer buffer)
/*      */   {
/* 1474 */     buffer.append(this.contentEnd);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendNullText(StringBuffer buffer, String fieldName)
/*      */   {
/* 1486 */     buffer.append(this.nullText);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendFieldSeparator(StringBuffer buffer)
/*      */   {
/* 1495 */     buffer.append(this.fieldSeparator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendFieldStart(StringBuffer buffer, String fieldName)
/*      */   {
/* 1505 */     if ((this.useFieldNames) && (fieldName != null)) {
/* 1506 */       buffer.append(fieldName);
/* 1507 */       buffer.append(this.fieldNameValueSeparator);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendFieldEnd(StringBuffer buffer, String fieldName)
/*      */   {
/* 1518 */     appendFieldSeparator(buffer);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void appendSummarySize(StringBuffer buffer, String fieldName, int size)
/*      */   {
/* 1537 */     buffer.append(this.sizeStartText);
/* 1538 */     buffer.append(size);
/* 1539 */     buffer.append(this.sizeEndText);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isFullDetail(Boolean fullDetailRequest)
/*      */   {
/* 1557 */     if (fullDetailRequest == null) {
/* 1558 */       return this.defaultFullDetail;
/*      */     }
/* 1560 */     return fullDetailRequest.booleanValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getShortClassName(Class cls)
/*      */   {
/* 1573 */     return ClassUtils.getShortClassName(cls);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isUseClassName()
/*      */   {
/* 1587 */     return this.useClassName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setUseClassName(boolean useClassName)
/*      */   {
/* 1596 */     this.useClassName = useClassName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isUseShortClassName()
/*      */   {
/* 1608 */     return this.useShortClassName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   protected boolean isShortClassName()
/*      */   {
/* 1619 */     return this.useShortClassName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setUseShortClassName(boolean useShortClassName)
/*      */   {
/* 1629 */     this.useShortClassName = useShortClassName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   protected void setShortClassName(boolean shortClassName)
/*      */   {
/* 1640 */     this.useShortClassName = shortClassName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isUseIdentityHashCode()
/*      */   {
/* 1651 */     return this.useIdentityHashCode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setUseIdentityHashCode(boolean useIdentityHashCode)
/*      */   {
/* 1660 */     this.useIdentityHashCode = useIdentityHashCode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isUseFieldNames()
/*      */   {
/* 1671 */     return this.useFieldNames;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setUseFieldNames(boolean useFieldNames)
/*      */   {
/* 1680 */     this.useFieldNames = useFieldNames;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isDefaultFullDetail()
/*      */   {
/* 1692 */     return this.defaultFullDetail;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setDefaultFullDetail(boolean defaultFullDetail)
/*      */   {
/* 1702 */     this.defaultFullDetail = defaultFullDetail;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isArrayContentDetail()
/*      */   {
/* 1713 */     return this.arrayContentDetail;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setArrayContentDetail(boolean arrayContentDetail)
/*      */   {
/* 1722 */     this.arrayContentDetail = arrayContentDetail;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getArrayStart()
/*      */   {
/* 1733 */     return this.arrayStart;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setArrayStart(String arrayStart)
/*      */   {
/* 1745 */     if (arrayStart == null) {
/* 1746 */       arrayStart = "";
/*      */     }
/* 1748 */     this.arrayStart = arrayStart;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getArrayEnd()
/*      */   {
/* 1759 */     return this.arrayEnd;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setArrayEnd(String arrayEnd)
/*      */   {
/* 1771 */     if (arrayEnd == null) {
/* 1772 */       arrayEnd = "";
/*      */     }
/* 1774 */     this.arrayEnd = arrayEnd;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getArraySeparator()
/*      */   {
/* 1785 */     return this.arraySeparator;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setArraySeparator(String arraySeparator)
/*      */   {
/* 1797 */     if (arraySeparator == null) {
/* 1798 */       arraySeparator = "";
/*      */     }
/* 1800 */     this.arraySeparator = arraySeparator;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getContentStart()
/*      */   {
/* 1811 */     return this.contentStart;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setContentStart(String contentStart)
/*      */   {
/* 1823 */     if (contentStart == null) {
/* 1824 */       contentStart = "";
/*      */     }
/* 1826 */     this.contentStart = contentStart;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getContentEnd()
/*      */   {
/* 1837 */     return this.contentEnd;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setContentEnd(String contentEnd)
/*      */   {
/* 1849 */     if (contentEnd == null) {
/* 1850 */       contentEnd = "";
/*      */     }
/* 1852 */     this.contentEnd = contentEnd;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getFieldNameValueSeparator()
/*      */   {
/* 1863 */     return this.fieldNameValueSeparator;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setFieldNameValueSeparator(String fieldNameValueSeparator)
/*      */   {
/* 1875 */     if (fieldNameValueSeparator == null) {
/* 1876 */       fieldNameValueSeparator = "";
/*      */     }
/* 1878 */     this.fieldNameValueSeparator = fieldNameValueSeparator;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getFieldSeparator()
/*      */   {
/* 1889 */     return this.fieldSeparator;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setFieldSeparator(String fieldSeparator)
/*      */   {
/* 1901 */     if (fieldSeparator == null) {
/* 1902 */       fieldSeparator = "";
/*      */     }
/* 1904 */     this.fieldSeparator = fieldSeparator;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isFieldSeparatorAtStart()
/*      */   {
/* 1917 */     return this.fieldSeparatorAtStart;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setFieldSeparatorAtStart(boolean fieldSeparatorAtStart)
/*      */   {
/* 1928 */     this.fieldSeparatorAtStart = fieldSeparatorAtStart;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isFieldSeparatorAtEnd()
/*      */   {
/* 1941 */     return this.fieldSeparatorAtEnd;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setFieldSeparatorAtEnd(boolean fieldSeparatorAtEnd)
/*      */   {
/* 1952 */     this.fieldSeparatorAtEnd = fieldSeparatorAtEnd;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getNullText()
/*      */   {
/* 1963 */     return this.nullText;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setNullText(String nullText)
/*      */   {
/* 1975 */     if (nullText == null) {
/* 1976 */       nullText = "";
/*      */     }
/* 1978 */     this.nullText = nullText;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getSizeStartText()
/*      */   {
/* 1992 */     return this.sizeStartText;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setSizeStartText(String sizeStartText)
/*      */   {
/* 2007 */     if (sizeStartText == null) {
/* 2008 */       sizeStartText = "";
/*      */     }
/* 2010 */     this.sizeStartText = sizeStartText;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getSizeEndText()
/*      */   {
/* 2024 */     return this.sizeEndText;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setSizeEndText(String sizeEndText)
/*      */   {
/* 2039 */     if (sizeEndText == null) {
/* 2040 */       sizeEndText = "";
/*      */     }
/* 2042 */     this.sizeEndText = sizeEndText;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getSummaryObjectStartText()
/*      */   {
/* 2056 */     return this.summaryObjectStartText;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setSummaryObjectStartText(String summaryObjectStartText)
/*      */   {
/* 2071 */     if (summaryObjectStartText == null) {
/* 2072 */       summaryObjectStartText = "";
/*      */     }
/* 2074 */     this.summaryObjectStartText = summaryObjectStartText;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getSummaryObjectEndText()
/*      */   {
/* 2088 */     return this.summaryObjectEndText;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setSummaryObjectEndText(String summaryObjectEndText)
/*      */   {
/* 2103 */     if (summaryObjectEndText == null) {
/* 2104 */       summaryObjectEndText = "";
/*      */     }
/* 2106 */     this.summaryObjectEndText = summaryObjectEndText;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final class DefaultToStringStyle
/*      */     extends ToStringStyle
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private Object readResolve()
/*      */     {
/* 2141 */       return ToStringStyle.DEFAULT_STYLE;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final class NoFieldNameToStringStyle
/*      */     extends ToStringStyle
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     NoFieldNameToStringStyle()
/*      */     {
/* 2166 */       setUseFieldNames(false);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private Object readResolve()
/*      */     {
/* 2175 */       return ToStringStyle.NO_FIELD_NAMES_STYLE;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final class ShortPrefixToStringStyle
/*      */     extends ToStringStyle
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     ShortPrefixToStringStyle()
/*      */     {
/* 2200 */       setUseShortClassName(true);
/* 2201 */       setUseIdentityHashCode(false);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private Object readResolve()
/*      */     {
/* 2209 */       return ToStringStyle.SHORT_PREFIX_STYLE;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final class SimpleToStringStyle
/*      */     extends ToStringStyle
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     SimpleToStringStyle()
/*      */     {
/* 2232 */       setUseClassName(false);
/* 2233 */       setUseIdentityHashCode(false);
/* 2234 */       setUseFieldNames(false);
/* 2235 */       setContentStart("");
/* 2236 */       setContentEnd("");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private Object readResolve()
/*      */     {
/* 2244 */       return ToStringStyle.SIMPLE_STYLE;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final class MultiLineToStringStyle
/*      */     extends ToStringStyle
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     MultiLineToStringStyle()
/*      */     {
/* 2268 */       setContentStart("[");
/* 2269 */       setFieldSeparator(SystemUtils.LINE_SEPARATOR + "  ");
/* 2270 */       setFieldSeparatorAtStart(true);
/* 2271 */       setContentEnd(SystemUtils.LINE_SEPARATOR + "]");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private Object readResolve()
/*      */     {
/* 2280 */       return ToStringStyle.MULTI_LINE_STYLE;
/*      */     }
/*      */   }
/*      */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-lang-2.4.jar!\org\apache\commons\lang\builder\ToStringStyle.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */