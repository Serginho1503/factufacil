/*     */ package org.apache.commons.lang;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import org.apache.commons.lang.exception.NestableRuntimeException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringEscapeUtils
/*     */ {
/*     */   private static final char CSV_DELIMITER = ',';
/*     */   private static final char CSV_QUOTE = '"';
/*  45 */   private static final String CSV_QUOTE_STR = String.valueOf('"');
/*  46 */   private static final char[] CSV_SEARCH_CHARS = { ',', '"', '\r', '\n' };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String escapeJava(String str)
/*     */   {
/*  86 */     return escapeJavaStyleString(str, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void escapeJava(Writer out, String str)
/*     */     throws IOException
/*     */   {
/* 102 */     escapeJavaStyleString(out, str, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String escapeJavaScript(String str)
/*     */   {
/* 127 */     return escapeJavaStyleString(str, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void escapeJavaScript(Writer out, String str)
/*     */     throws IOException
/*     */   {
/* 143 */     escapeJavaStyleString(out, str, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String escapeJavaStyleString(String str, boolean escapeSingleQuotes)
/*     */   {
/* 154 */     if (str == null) {
/* 155 */       return null;
/*     */     }
/*     */     try {
/* 158 */       StringWriter writer = new StringWriter(str.length() * 2);
/* 159 */       escapeJavaStyleString(writer, str, escapeSingleQuotes);
/* 160 */       return writer.toString();
/*     */     }
/*     */     catch (IOException ioe) {
/* 163 */       ioe.printStackTrace(); }
/* 164 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void escapeJavaStyleString(Writer out, String str, boolean escapeSingleQuote)
/*     */     throws IOException
/*     */   {
/* 177 */     if (out == null) {
/* 178 */       throw new IllegalArgumentException("The Writer must not be null");
/*     */     }
/* 180 */     if (str == null) {
/* 181 */       return;
/*     */     }
/*     */     
/* 184 */     int sz = str.length();
/* 185 */     for (int i = 0; i < sz; i++) {
/* 186 */       char ch = str.charAt(i);
/*     */       
/*     */ 
/* 189 */       if (ch > '࿿') {
/* 190 */         out.write("\\u" + hex(ch));
/* 191 */       } else if (ch > 'ÿ') {
/* 192 */         out.write("\\u0" + hex(ch));
/* 193 */       } else if (ch > '') {
/* 194 */         out.write("\\u00" + hex(ch));
/* 195 */       } else if (ch < ' ') {
/* 196 */         switch (ch) {
/*     */         case '\b': 
/* 198 */           out.write(92);
/* 199 */           out.write(98);
/* 200 */           break;
/*     */         case '\n': 
/* 202 */           out.write(92);
/* 203 */           out.write(110);
/* 204 */           break;
/*     */         case '\t': 
/* 206 */           out.write(92);
/* 207 */           out.write(116);
/* 208 */           break;
/*     */         case '\f': 
/* 210 */           out.write(92);
/* 211 */           out.write(102);
/* 212 */           break;
/*     */         case '\r': 
/* 214 */           out.write(92);
/* 215 */           out.write(114);
/* 216 */           break;
/*     */         case '\013': default: 
/* 218 */           if (ch > '\017') {
/* 219 */             out.write("\\u00" + hex(ch));
/*     */           } else {
/* 221 */             out.write("\\u000" + hex(ch));
/*     */           }
/* 223 */           break;
/*     */         }
/*     */       } else {
/* 226 */         switch (ch) {
/*     */         case '\'': 
/* 228 */           if (escapeSingleQuote) {
/* 229 */             out.write(92);
/*     */           }
/* 231 */           out.write(39);
/* 232 */           break;
/*     */         case '"': 
/* 234 */           out.write(92);
/* 235 */           out.write(34);
/* 236 */           break;
/*     */         case '\\': 
/* 238 */           out.write(92);
/* 239 */           out.write(92);
/* 240 */           break;
/*     */         case '/': 
/* 242 */           out.write(92);
/* 243 */           out.write(47);
/* 244 */           break;
/*     */         default: 
/* 246 */           out.write(ch);
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String hex(char ch)
/*     */   {
/* 261 */     return Integer.toHexString(ch).toUpperCase();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String unescapeJava(String str)
/*     */   {
/* 274 */     if (str == null) {
/* 275 */       return null;
/*     */     }
/*     */     try {
/* 278 */       StringWriter writer = new StringWriter(str.length());
/* 279 */       unescapeJava(writer, str);
/* 280 */       return writer.toString();
/*     */     }
/*     */     catch (IOException ioe) {
/* 283 */       ioe.printStackTrace(); }
/* 284 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void unescapeJava(Writer out, String str)
/*     */     throws IOException
/*     */   {
/* 304 */     if (out == null) {
/* 305 */       throw new IllegalArgumentException("The Writer must not be null");
/*     */     }
/* 307 */     if (str == null) {
/* 308 */       return;
/*     */     }
/* 310 */     int sz = str.length();
/* 311 */     StringBuffer unicode = new StringBuffer(4);
/* 312 */     boolean hadSlash = false;
/* 313 */     boolean inUnicode = false;
/* 314 */     for (int i = 0; i < sz; i++) {
/* 315 */       char ch = str.charAt(i);
/* 316 */       if (inUnicode)
/*     */       {
/*     */ 
/* 319 */         unicode.append(ch);
/* 320 */         if (unicode.length() == 4)
/*     */         {
/*     */           try
/*     */           {
/* 324 */             int value = Integer.parseInt(unicode.toString(), 16);
/* 325 */             out.write((char)value);
/* 326 */             unicode.setLength(0);
/* 327 */             inUnicode = false;
/* 328 */             hadSlash = false;
/*     */           } catch (NumberFormatException nfe) {
/* 330 */             throw new NestableRuntimeException("Unable to parse unicode value: " + unicode, nfe);
/*     */           }
/*     */           
/*     */         }
/*     */       }
/* 335 */       else if (hadSlash)
/*     */       {
/* 337 */         hadSlash = false;
/* 338 */         switch (ch) {
/*     */         case '\\': 
/* 340 */           out.write(92);
/* 341 */           break;
/*     */         case '\'': 
/* 343 */           out.write(39);
/* 344 */           break;
/*     */         case '"': 
/* 346 */           out.write(34);
/* 347 */           break;
/*     */         case 'r': 
/* 349 */           out.write(13);
/* 350 */           break;
/*     */         case 'f': 
/* 352 */           out.write(12);
/* 353 */           break;
/*     */         case 't': 
/* 355 */           out.write(9);
/* 356 */           break;
/*     */         case 'n': 
/* 358 */           out.write(10);
/* 359 */           break;
/*     */         case 'b': 
/* 361 */           out.write(8);
/* 362 */           break;
/*     */         
/*     */ 
/*     */         case 'u': 
/* 366 */           inUnicode = true;
/* 367 */           break;
/*     */         
/*     */         default: 
/* 370 */           out.write(ch);
/* 371 */           break;
/*     */         }
/*     */       }
/* 374 */       else if (ch == '\\') {
/* 375 */         hadSlash = true;
/*     */       }
/*     */       else {
/* 378 */         out.write(ch);
/*     */       } }
/* 380 */     if (hadSlash)
/*     */     {
/*     */ 
/* 383 */       out.write(92);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String unescapeJavaScript(String str)
/*     */   {
/* 399 */     return unescapeJava(str);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void unescapeJavaScript(Writer out, String str)
/*     */     throws IOException
/*     */   {
/* 419 */     unescapeJava(out, str);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String escapeHtml(String str)
/*     */   {
/* 451 */     if (str == null) {
/* 452 */       return null;
/*     */     }
/*     */     try {
/* 455 */       StringWriter writer = new StringWriter((int)(str.length() * 1.5D));
/* 456 */       escapeHtml(writer, str);
/* 457 */       return writer.toString();
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 461 */       e.printStackTrace(); }
/* 462 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void escapeHtml(Writer writer, String string)
/*     */     throws IOException
/*     */   {
/* 496 */     if (writer == null) {
/* 497 */       throw new IllegalArgumentException("The Writer must not be null.");
/*     */     }
/* 499 */     if (string == null) {
/* 500 */       return;
/*     */     }
/* 502 */     Entities.HTML40.escape(writer, string);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String unescapeHtml(String str)
/*     */   {
/* 523 */     if (str == null) {
/* 524 */       return null;
/*     */     }
/*     */     try {
/* 527 */       StringWriter writer = new StringWriter((int)(str.length() * 1.5D));
/* 528 */       unescapeHtml(writer, str);
/* 529 */       return writer.toString();
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 533 */       e.printStackTrace(); }
/* 534 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void unescapeHtml(Writer writer, String string)
/*     */     throws IOException
/*     */   {
/* 557 */     if (writer == null) {
/* 558 */       throw new IllegalArgumentException("The Writer must not be null.");
/*     */     }
/* 560 */     if (string == null) {
/* 561 */       return;
/*     */     }
/* 563 */     Entities.HTML40.unescape(writer, string);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void escapeXml(Writer writer, String str)
/*     */     throws IOException
/*     */   {
/* 587 */     if (writer == null) {
/* 588 */       throw new IllegalArgumentException("The Writer must not be null.");
/*     */     }
/* 590 */     if (str == null) {
/* 591 */       return;
/*     */     }
/* 593 */     Entities.XML.escape(writer, str);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String escapeXml(String str)
/*     */   {
/* 614 */     if (str == null) {
/* 615 */       return null;
/*     */     }
/* 617 */     return Entities.XML.escape(str);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void unescapeXml(Writer writer, String str)
/*     */     throws IOException
/*     */   {
/* 639 */     if (writer == null) {
/* 640 */       throw new IllegalArgumentException("The Writer must not be null.");
/*     */     }
/* 642 */     if (str == null) {
/* 643 */       return;
/*     */     }
/* 645 */     Entities.XML.unescape(writer, str);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String unescapeXml(String str)
/*     */   {
/* 664 */     if (str == null) {
/* 665 */       return null;
/*     */     }
/* 667 */     return Entities.XML.unescape(str);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String escapeSql(String str)
/*     */   {
/* 690 */     if (str == null) {
/* 691 */       return null;
/*     */     }
/* 693 */     return StringUtils.replace(str, "'", "''");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String escapeCsv(String str)
/*     */   {
/* 721 */     if (StringUtils.containsNone(str, CSV_SEARCH_CHARS)) {
/* 722 */       return str;
/*     */     }
/*     */     try {
/* 725 */       StringWriter writer = new StringWriter();
/* 726 */       escapeCsv(writer, str);
/* 727 */       return writer.toString();
/*     */     }
/*     */     catch (IOException ioe) {
/* 730 */       ioe.printStackTrace(); }
/* 731 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void escapeCsv(Writer out, String str)
/*     */     throws IOException
/*     */   {
/* 759 */     if (StringUtils.containsNone(str, CSV_SEARCH_CHARS)) {
/* 760 */       if (str != null) {
/* 761 */         out.write(str);
/*     */       }
/* 763 */       return;
/*     */     }
/* 765 */     out.write(34);
/* 766 */     for (int i = 0; i < str.length(); i++) {
/* 767 */       char c = str.charAt(i);
/* 768 */       if (c == '"') {
/* 769 */         out.write(34);
/*     */       }
/* 771 */       out.write(c);
/*     */     }
/* 773 */     out.write(34);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String unescapeCsv(String str)
/*     */   {
/* 799 */     if (str == null) {
/* 800 */       return null;
/*     */     }
/*     */     try {
/* 803 */       StringWriter writer = new StringWriter();
/* 804 */       unescapeCsv(writer, str);
/* 805 */       return writer.toString();
/*     */     }
/*     */     catch (IOException ioe) {
/* 808 */       ioe.printStackTrace(); }
/* 809 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void unescapeCsv(Writer out, String str)
/*     */     throws IOException
/*     */   {
/* 837 */     if (str == null) {
/* 838 */       return;
/*     */     }
/* 840 */     if (str.length() < 2) {
/* 841 */       out.write(str);
/* 842 */       return;
/*     */     }
/* 844 */     if ((str.charAt(0) != '"') || (str.charAt(str.length() - 1) != '"')) {
/* 845 */       out.write(str);
/* 846 */       return;
/*     */     }
/*     */     
/*     */ 
/* 850 */     String quoteless = str.substring(1, str.length() - 1);
/*     */     
/* 852 */     if (StringUtils.containsAny(quoteless, CSV_SEARCH_CHARS))
/*     */     {
/* 854 */       str = StringUtils.replace(quoteless, CSV_QUOTE_STR + CSV_QUOTE_STR, CSV_QUOTE_STR);
/*     */     }
/*     */     
/* 857 */     out.write(str);
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-lang-2.4.jar!\org\apache\commons\lang\StringEscapeUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */