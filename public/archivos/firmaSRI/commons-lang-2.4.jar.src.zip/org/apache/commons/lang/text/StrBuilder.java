/*      */ package org.apache.commons.lang.text;
/*      */ 
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import java.util.Collection;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import org.apache.commons.lang.ArrayUtils;
/*      */ import org.apache.commons.lang.SystemUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StrBuilder
/*      */   implements Cloneable
/*      */ {
/*      */   static final int CAPACITY = 32;
/*      */   private static final long serialVersionUID = 7628716375283629643L;
/*      */   protected char[] buffer;
/*      */   protected int size;
/*      */   private String newLine;
/*      */   private String nullText;
/*      */   
/*      */   public StrBuilder()
/*      */   {
/*   98 */     this(32);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder(int initialCapacity)
/*      */   {
/*  108 */     if (initialCapacity <= 0) {
/*  109 */       initialCapacity = 32;
/*      */     }
/*  111 */     this.buffer = new char[initialCapacity];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder(String str)
/*      */   {
/*  122 */     if (str == null) {
/*  123 */       this.buffer = new char[32];
/*      */     } else {
/*  125 */       this.buffer = new char[str.length() + 32];
/*  126 */       append(str);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getNewLineText()
/*      */   {
/*  137 */     return this.newLine;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder setNewLineText(String newLine)
/*      */   {
/*  147 */     this.newLine = newLine;
/*  148 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getNullText()
/*      */   {
/*  158 */     return this.nullText;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder setNullText(String nullText)
/*      */   {
/*  168 */     if ((nullText != null) && (nullText.length() == 0)) {
/*  169 */       nullText = null;
/*      */     }
/*  171 */     this.nullText = nullText;
/*  172 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int length()
/*      */   {
/*  182 */     return this.size;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder setLength(int length)
/*      */   {
/*  194 */     if (length < 0) {
/*  195 */       throw new StringIndexOutOfBoundsException(length);
/*      */     }
/*  197 */     if (length < this.size) {
/*  198 */       this.size = length;
/*  199 */     } else if (length > this.size) {
/*  200 */       ensureCapacity(length);
/*  201 */       int oldEnd = this.size;
/*  202 */       int newEnd = length;
/*  203 */       this.size = length;
/*  204 */       for (int i = oldEnd; i < newEnd; i++) {
/*  205 */         this.buffer[i] = '\000';
/*      */       }
/*      */     }
/*  208 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int capacity()
/*      */   {
/*  218 */     return this.buffer.length;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder ensureCapacity(int capacity)
/*      */   {
/*  228 */     if (capacity > this.buffer.length) {
/*  229 */       char[] old = this.buffer;
/*  230 */       this.buffer = new char[capacity];
/*  231 */       System.arraycopy(old, 0, this.buffer, 0, this.size);
/*      */     }
/*  233 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder minimizeCapacity()
/*      */   {
/*  242 */     if (this.buffer.length > length()) {
/*  243 */       char[] old = this.buffer;
/*  244 */       this.buffer = new char[length()];
/*  245 */       System.arraycopy(old, 0, this.buffer, 0, this.size);
/*      */     }
/*  247 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int size()
/*      */   {
/*  260 */     return this.size;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isEmpty()
/*      */   {
/*  272 */     return this.size == 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder clear()
/*      */   {
/*  287 */     this.size = 0;
/*  288 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public char charAt(int index)
/*      */   {
/*  302 */     if ((index < 0) || (index >= length())) {
/*  303 */       throw new StringIndexOutOfBoundsException(index);
/*      */     }
/*  305 */     return this.buffer[index];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder setCharAt(int index, char ch)
/*      */   {
/*  319 */     if ((index < 0) || (index >= length())) {
/*  320 */       throw new StringIndexOutOfBoundsException(index);
/*      */     }
/*  322 */     this.buffer[index] = ch;
/*  323 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder deleteCharAt(int index)
/*      */   {
/*  336 */     if ((index < 0) || (index >= this.size)) {
/*  337 */       throw new StringIndexOutOfBoundsException(index);
/*      */     }
/*  339 */     deleteImpl(index, index + 1, 1);
/*  340 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public char[] toCharArray()
/*      */   {
/*  350 */     if (this.size == 0) {
/*  351 */       return ArrayUtils.EMPTY_CHAR_ARRAY;
/*      */     }
/*  353 */     char[] chars = new char[this.size];
/*  354 */     System.arraycopy(this.buffer, 0, chars, 0, this.size);
/*  355 */     return chars;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public char[] toCharArray(int startIndex, int endIndex)
/*      */   {
/*  369 */     endIndex = validateRange(startIndex, endIndex);
/*  370 */     int len = endIndex - startIndex;
/*  371 */     if (len == 0) {
/*  372 */       return ArrayUtils.EMPTY_CHAR_ARRAY;
/*      */     }
/*  374 */     char[] chars = new char[len];
/*  375 */     System.arraycopy(this.buffer, startIndex, chars, 0, len);
/*  376 */     return chars;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public char[] getChars(char[] destination)
/*      */   {
/*  386 */     int len = length();
/*  387 */     if ((destination == null) || (destination.length < len)) {
/*  388 */       destination = new char[len];
/*      */     }
/*  390 */     System.arraycopy(this.buffer, 0, destination, 0, len);
/*  391 */     return destination;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void getChars(int startIndex, int endIndex, char[] destination, int destinationIndex)
/*      */   {
/*  405 */     if (startIndex < 0) {
/*  406 */       throw new StringIndexOutOfBoundsException(startIndex);
/*      */     }
/*  408 */     if ((endIndex < 0) || (endIndex > length())) {
/*  409 */       throw new StringIndexOutOfBoundsException(endIndex);
/*      */     }
/*  411 */     if (startIndex > endIndex) {
/*  412 */       throw new StringIndexOutOfBoundsException("end < start");
/*      */     }
/*  414 */     System.arraycopy(this.buffer, startIndex, destination, destinationIndex, endIndex - startIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendNewLine()
/*      */   {
/*  428 */     if (this.newLine == null) {
/*  429 */       append(SystemUtils.LINE_SEPARATOR);
/*  430 */       return this;
/*      */     }
/*  432 */     return append(this.newLine);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendNull()
/*      */   {
/*  441 */     if (this.nullText == null) {
/*  442 */       return this;
/*      */     }
/*  444 */     return append(this.nullText);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder append(Object obj)
/*      */   {
/*  455 */     if (obj == null) {
/*  456 */       return appendNull();
/*      */     }
/*  458 */     return append(obj.toString());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder append(String str)
/*      */   {
/*  469 */     if (str == null) {
/*  470 */       return appendNull();
/*      */     }
/*  472 */     int strLen = str.length();
/*  473 */     if (strLen > 0) {
/*  474 */       int len = length();
/*  475 */       ensureCapacity(len + strLen);
/*  476 */       str.getChars(0, strLen, this.buffer, len);
/*  477 */       this.size += strLen;
/*      */     }
/*  479 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder append(String str, int startIndex, int length)
/*      */   {
/*  492 */     if (str == null) {
/*  493 */       return appendNull();
/*      */     }
/*  495 */     if ((startIndex < 0) || (startIndex > str.length())) {
/*  496 */       throw new StringIndexOutOfBoundsException("startIndex must be valid");
/*      */     }
/*  498 */     if ((length < 0) || (startIndex + length > str.length())) {
/*  499 */       throw new StringIndexOutOfBoundsException("length must be valid");
/*      */     }
/*  501 */     if (length > 0) {
/*  502 */       int len = length();
/*  503 */       ensureCapacity(len + length);
/*  504 */       str.getChars(startIndex, startIndex + length, this.buffer, len);
/*  505 */       this.size += length;
/*      */     }
/*  507 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder append(StringBuffer str)
/*      */   {
/*  518 */     if (str == null) {
/*  519 */       return appendNull();
/*      */     }
/*  521 */     int strLen = str.length();
/*  522 */     if (strLen > 0) {
/*  523 */       int len = length();
/*  524 */       ensureCapacity(len + strLen);
/*  525 */       str.getChars(0, strLen, this.buffer, len);
/*  526 */       this.size += strLen;
/*      */     }
/*  528 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder append(StringBuffer str, int startIndex, int length)
/*      */   {
/*  541 */     if (str == null) {
/*  542 */       return appendNull();
/*      */     }
/*  544 */     if ((startIndex < 0) || (startIndex > str.length())) {
/*  545 */       throw new StringIndexOutOfBoundsException("startIndex must be valid");
/*      */     }
/*  547 */     if ((length < 0) || (startIndex + length > str.length())) {
/*  548 */       throw new StringIndexOutOfBoundsException("length must be valid");
/*      */     }
/*  550 */     if (length > 0) {
/*  551 */       int len = length();
/*  552 */       ensureCapacity(len + length);
/*  553 */       str.getChars(startIndex, startIndex + length, this.buffer, len);
/*  554 */       this.size += length;
/*      */     }
/*  556 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder append(StrBuilder str)
/*      */   {
/*  567 */     if (str == null) {
/*  568 */       return appendNull();
/*      */     }
/*  570 */     int strLen = str.length();
/*  571 */     if (strLen > 0) {
/*  572 */       int len = length();
/*  573 */       ensureCapacity(len + strLen);
/*  574 */       System.arraycopy(str.buffer, 0, this.buffer, len, strLen);
/*  575 */       this.size += strLen;
/*      */     }
/*  577 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder append(StrBuilder str, int startIndex, int length)
/*      */   {
/*  590 */     if (str == null) {
/*  591 */       return appendNull();
/*      */     }
/*  593 */     if ((startIndex < 0) || (startIndex > str.length())) {
/*  594 */       throw new StringIndexOutOfBoundsException("startIndex must be valid");
/*      */     }
/*  596 */     if ((length < 0) || (startIndex + length > str.length())) {
/*  597 */       throw new StringIndexOutOfBoundsException("length must be valid");
/*      */     }
/*  599 */     if (length > 0) {
/*  600 */       int len = length();
/*  601 */       ensureCapacity(len + length);
/*  602 */       str.getChars(startIndex, startIndex + length, this.buffer, len);
/*  603 */       this.size += length;
/*      */     }
/*  605 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder append(char[] chars)
/*      */   {
/*  616 */     if (chars == null) {
/*  617 */       return appendNull();
/*      */     }
/*  619 */     int strLen = chars.length;
/*  620 */     if (strLen > 0) {
/*  621 */       int len = length();
/*  622 */       ensureCapacity(len + strLen);
/*  623 */       System.arraycopy(chars, 0, this.buffer, len, strLen);
/*  624 */       this.size += strLen;
/*      */     }
/*  626 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder append(char[] chars, int startIndex, int length)
/*      */   {
/*  639 */     if (chars == null) {
/*  640 */       return appendNull();
/*      */     }
/*  642 */     if ((startIndex < 0) || (startIndex > chars.length)) {
/*  643 */       throw new StringIndexOutOfBoundsException("Invalid startIndex: " + length);
/*      */     }
/*  645 */     if ((length < 0) || (startIndex + length > chars.length)) {
/*  646 */       throw new StringIndexOutOfBoundsException("Invalid length: " + length);
/*      */     }
/*  648 */     if (length > 0) {
/*  649 */       int len = length();
/*  650 */       ensureCapacity(len + length);
/*  651 */       System.arraycopy(chars, startIndex, this.buffer, len, length);
/*  652 */       this.size += length;
/*      */     }
/*  654 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder append(boolean value)
/*      */   {
/*  664 */     if (value) {
/*  665 */       ensureCapacity(this.size + 4);
/*  666 */       this.buffer[(this.size++)] = 't';
/*  667 */       this.buffer[(this.size++)] = 'r';
/*  668 */       this.buffer[(this.size++)] = 'u';
/*  669 */       this.buffer[(this.size++)] = 'e';
/*      */     } else {
/*  671 */       ensureCapacity(this.size + 5);
/*  672 */       this.buffer[(this.size++)] = 'f';
/*  673 */       this.buffer[(this.size++)] = 'a';
/*  674 */       this.buffer[(this.size++)] = 'l';
/*  675 */       this.buffer[(this.size++)] = 's';
/*  676 */       this.buffer[(this.size++)] = 'e';
/*      */     }
/*  678 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder append(char ch)
/*      */   {
/*  688 */     int len = length();
/*  689 */     ensureCapacity(len + 1);
/*  690 */     this.buffer[(this.size++)] = ch;
/*  691 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder append(int value)
/*      */   {
/*  701 */     return append(String.valueOf(value));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder append(long value)
/*      */   {
/*  711 */     return append(String.valueOf(value));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder append(float value)
/*      */   {
/*  721 */     return append(String.valueOf(value));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder append(double value)
/*      */   {
/*  731 */     return append(String.valueOf(value));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendln(Object obj)
/*      */   {
/*  744 */     return append(obj).appendNewLine();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendln(String str)
/*      */   {
/*  756 */     return append(str).appendNewLine();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendln(String str, int startIndex, int length)
/*      */   {
/*  770 */     return append(str, startIndex, length).appendNewLine();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendln(StringBuffer str)
/*      */   {
/*  782 */     return append(str).appendNewLine();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendln(StringBuffer str, int startIndex, int length)
/*      */   {
/*  796 */     return append(str, startIndex, length).appendNewLine();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendln(StrBuilder str)
/*      */   {
/*  808 */     return append(str).appendNewLine();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendln(StrBuilder str, int startIndex, int length)
/*      */   {
/*  822 */     return append(str, startIndex, length).appendNewLine();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendln(char[] chars)
/*      */   {
/*  834 */     return append(chars).appendNewLine();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendln(char[] chars, int startIndex, int length)
/*      */   {
/*  848 */     return append(chars, startIndex, length).appendNewLine();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendln(boolean value)
/*      */   {
/*  859 */     return append(value).appendNewLine();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendln(char ch)
/*      */   {
/*  870 */     return append(ch).appendNewLine();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendln(int value)
/*      */   {
/*  881 */     return append(value).appendNewLine();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendln(long value)
/*      */   {
/*  892 */     return append(value).appendNewLine();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendln(float value)
/*      */   {
/*  903 */     return append(value).appendNewLine();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendln(double value)
/*      */   {
/*  914 */     return append(value).appendNewLine();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendAll(Object[] array)
/*      */   {
/*  928 */     if ((array != null) && (array.length > 0)) {
/*  929 */       for (int i = 0; i < array.length; i++) {
/*  930 */         append(array[i]);
/*      */       }
/*      */     }
/*  933 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendAll(Collection coll)
/*      */   {
/*  946 */     if ((coll != null) && (coll.size() > 0)) {
/*  947 */       Iterator it = coll.iterator();
/*  948 */       while (it.hasNext()) {
/*  949 */         append(it.next());
/*      */       }
/*      */     }
/*  952 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendAll(Iterator it)
/*      */   {
/*  965 */     if (it != null) {
/*  966 */       while (it.hasNext()) {
/*  967 */         append(it.next());
/*      */       }
/*      */     }
/*  970 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendWithSeparators(Object[] array, String separator)
/*      */   {
/*  985 */     if ((array != null) && (array.length > 0)) {
/*  986 */       separator = separator == null ? "" : separator;
/*  987 */       append(array[0]);
/*  988 */       for (int i = 1; i < array.length; i++) {
/*  989 */         append(separator);
/*  990 */         append(array[i]);
/*      */       }
/*      */     }
/*  993 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendWithSeparators(Collection coll, String separator)
/*      */   {
/* 1007 */     if ((coll != null) && (coll.size() > 0)) {
/* 1008 */       separator = separator == null ? "" : separator;
/* 1009 */       Iterator it = coll.iterator();
/* 1010 */       while (it.hasNext()) {
/* 1011 */         append(it.next());
/* 1012 */         if (it.hasNext()) {
/* 1013 */           append(separator);
/*      */         }
/*      */       }
/*      */     }
/* 1017 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendWithSeparators(Iterator it, String separator)
/*      */   {
/* 1031 */     if (it != null) {
/* 1032 */       separator = separator == null ? "" : separator;
/* 1033 */       while (it.hasNext()) {
/* 1034 */         append(it.next());
/* 1035 */         if (it.hasNext()) {
/* 1036 */           append(separator);
/*      */         }
/*      */       }
/*      */     }
/* 1040 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendSeparator(String separator)
/*      */   {
/* 1065 */     if ((separator != null) && (size() > 0)) {
/* 1066 */       append(separator);
/*      */     }
/* 1068 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendSeparator(char separator)
/*      */   {
/* 1091 */     if (size() > 0) {
/* 1092 */       append(separator);
/*      */     }
/* 1094 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendSeparator(String separator, int loopIndex)
/*      */   {
/* 1119 */     if ((separator != null) && (loopIndex > 0)) {
/* 1120 */       append(separator);
/*      */     }
/* 1122 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendSeparator(char separator, int loopIndex)
/*      */   {
/* 1146 */     if (loopIndex > 0) {
/* 1147 */       append(separator);
/*      */     }
/* 1149 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendPadding(int length, char padChar)
/*      */   {
/* 1161 */     if (length >= 0) {
/* 1162 */       ensureCapacity(this.size + length);
/* 1163 */       for (int i = 0; i < length; i++) {
/* 1164 */         this.buffer[(this.size++)] = padChar;
/*      */       }
/*      */     }
/* 1167 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendFixedWidthPadLeft(Object obj, int width, char padChar)
/*      */   {
/* 1183 */     if (width > 0) {
/* 1184 */       ensureCapacity(this.size + width);
/* 1185 */       String str = obj == null ? getNullText() : obj.toString();
/* 1186 */       if (str == null) {
/* 1187 */         str = "";
/*      */       }
/* 1189 */       int strLen = str.length();
/* 1190 */       if (strLen >= width) {
/* 1191 */         str.getChars(strLen - width, strLen, this.buffer, this.size);
/*      */       } else {
/* 1193 */         int padLen = width - strLen;
/* 1194 */         for (int i = 0; i < padLen; i++) {
/* 1195 */           this.buffer[(this.size + i)] = padChar;
/*      */         }
/* 1197 */         str.getChars(0, strLen, this.buffer, this.size + padLen);
/*      */       }
/* 1199 */       this.size += width;
/*      */     }
/* 1201 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendFixedWidthPadLeft(int value, int width, char padChar)
/*      */   {
/* 1215 */     return appendFixedWidthPadLeft(String.valueOf(value), width, padChar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendFixedWidthPadRight(Object obj, int width, char padChar)
/*      */   {
/* 1230 */     if (width > 0) {
/* 1231 */       ensureCapacity(this.size + width);
/* 1232 */       String str = obj == null ? getNullText() : obj.toString();
/* 1233 */       if (str == null) {
/* 1234 */         str = "";
/*      */       }
/* 1236 */       int strLen = str.length();
/* 1237 */       if (strLen >= width) {
/* 1238 */         str.getChars(0, width, this.buffer, this.size);
/*      */       } else {
/* 1240 */         int padLen = width - strLen;
/* 1241 */         str.getChars(0, strLen, this.buffer, this.size);
/* 1242 */         for (int i = 0; i < padLen; i++) {
/* 1243 */           this.buffer[(this.size + strLen + i)] = padChar;
/*      */         }
/*      */       }
/* 1246 */       this.size += width;
/*      */     }
/* 1248 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder appendFixedWidthPadRight(int value, int width, char padChar)
/*      */   {
/* 1262 */     return appendFixedWidthPadRight(String.valueOf(value), width, padChar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder insert(int index, Object obj)
/*      */   {
/* 1276 */     if (obj == null) {
/* 1277 */       return insert(index, this.nullText);
/*      */     }
/* 1279 */     return insert(index, obj.toString());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder insert(int index, String str)
/*      */   {
/* 1292 */     validateIndex(index);
/* 1293 */     if (str == null) {
/* 1294 */       str = this.nullText;
/*      */     }
/* 1296 */     int strLen = str == null ? 0 : str.length();
/* 1297 */     if (strLen > 0) {
/* 1298 */       int newSize = this.size + strLen;
/* 1299 */       ensureCapacity(newSize);
/* 1300 */       System.arraycopy(this.buffer, index, this.buffer, index + strLen, this.size - index);
/* 1301 */       this.size = newSize;
/* 1302 */       str.getChars(0, strLen, this.buffer, index);
/*      */     }
/* 1304 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder insert(int index, char[] chars)
/*      */   {
/* 1317 */     validateIndex(index);
/* 1318 */     if (chars == null) {
/* 1319 */       return insert(index, this.nullText);
/*      */     }
/* 1321 */     int len = chars.length;
/* 1322 */     if (len > 0) {
/* 1323 */       ensureCapacity(this.size + len);
/* 1324 */       System.arraycopy(this.buffer, index, this.buffer, index + len, this.size - index);
/* 1325 */       System.arraycopy(chars, 0, this.buffer, index, len);
/* 1326 */       this.size += len;
/*      */     }
/* 1328 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder insert(int index, char[] chars, int offset, int length)
/*      */   {
/* 1343 */     validateIndex(index);
/* 1344 */     if (chars == null) {
/* 1345 */       return insert(index, this.nullText);
/*      */     }
/* 1347 */     if ((offset < 0) || (offset > chars.length)) {
/* 1348 */       throw new StringIndexOutOfBoundsException("Invalid offset: " + offset);
/*      */     }
/* 1350 */     if ((length < 0) || (offset + length > chars.length)) {
/* 1351 */       throw new StringIndexOutOfBoundsException("Invalid length: " + length);
/*      */     }
/* 1353 */     if (length > 0) {
/* 1354 */       ensureCapacity(this.size + length);
/* 1355 */       System.arraycopy(this.buffer, index, this.buffer, index + length, this.size - index);
/* 1356 */       System.arraycopy(chars, offset, this.buffer, index, length);
/* 1357 */       this.size += length;
/*      */     }
/* 1359 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder insert(int index, boolean value)
/*      */   {
/* 1371 */     validateIndex(index);
/* 1372 */     if (value) {
/* 1373 */       ensureCapacity(this.size + 4);
/* 1374 */       System.arraycopy(this.buffer, index, this.buffer, index + 4, this.size - index);
/* 1375 */       this.buffer[(index++)] = 't';
/* 1376 */       this.buffer[(index++)] = 'r';
/* 1377 */       this.buffer[(index++)] = 'u';
/* 1378 */       this.buffer[index] = 'e';
/* 1379 */       this.size += 4;
/*      */     } else {
/* 1381 */       ensureCapacity(this.size + 5);
/* 1382 */       System.arraycopy(this.buffer, index, this.buffer, index + 5, this.size - index);
/* 1383 */       this.buffer[(index++)] = 'f';
/* 1384 */       this.buffer[(index++)] = 'a';
/* 1385 */       this.buffer[(index++)] = 'l';
/* 1386 */       this.buffer[(index++)] = 's';
/* 1387 */       this.buffer[index] = 'e';
/* 1388 */       this.size += 5;
/*      */     }
/* 1390 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder insert(int index, char value)
/*      */   {
/* 1402 */     validateIndex(index);
/* 1403 */     ensureCapacity(this.size + 1);
/* 1404 */     System.arraycopy(this.buffer, index, this.buffer, index + 1, this.size - index);
/* 1405 */     this.buffer[index] = value;
/* 1406 */     this.size += 1;
/* 1407 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder insert(int index, int value)
/*      */   {
/* 1419 */     return insert(index, String.valueOf(value));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder insert(int index, long value)
/*      */   {
/* 1431 */     return insert(index, String.valueOf(value));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder insert(int index, float value)
/*      */   {
/* 1443 */     return insert(index, String.valueOf(value));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder insert(int index, double value)
/*      */   {
/* 1455 */     return insert(index, String.valueOf(value));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void deleteImpl(int startIndex, int endIndex, int len)
/*      */   {
/* 1468 */     System.arraycopy(this.buffer, endIndex, this.buffer, startIndex, this.size - endIndex);
/* 1469 */     this.size -= len;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder delete(int startIndex, int endIndex)
/*      */   {
/* 1482 */     endIndex = validateRange(startIndex, endIndex);
/* 1483 */     int len = endIndex - startIndex;
/* 1484 */     if (len > 0) {
/* 1485 */       deleteImpl(startIndex, endIndex, len);
/*      */     }
/* 1487 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder deleteAll(char ch)
/*      */   {
/* 1498 */     for (int i = 0; i < this.size; i++) {
/* 1499 */       if (this.buffer[i] == ch) {
/* 1500 */         int start = i;
/* 1501 */         for (;;) { i++; if (i < this.size) {
/* 1502 */             if (this.buffer[i] != ch)
/*      */               break;
/*      */           }
/*      */         }
/* 1506 */         int len = i - start;
/* 1507 */         deleteImpl(start, i, len);
/* 1508 */         i -= len;
/*      */       }
/*      */     }
/* 1511 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder deleteFirst(char ch)
/*      */   {
/* 1521 */     for (int i = 0; i < this.size; i++) {
/* 1522 */       if (this.buffer[i] == ch) {
/* 1523 */         deleteImpl(i, i + 1, 1);
/* 1524 */         break;
/*      */       }
/*      */     }
/* 1527 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder deleteAll(String str)
/*      */   {
/* 1538 */     int len = str == null ? 0 : str.length();
/* 1539 */     if (len > 0) {
/* 1540 */       int index = indexOf(str, 0);
/* 1541 */       while (index >= 0) {
/* 1542 */         deleteImpl(index, index + len, len);
/* 1543 */         index = indexOf(str, index);
/*      */       }
/*      */     }
/* 1546 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder deleteFirst(String str)
/*      */   {
/* 1556 */     int len = str == null ? 0 : str.length();
/* 1557 */     if (len > 0) {
/* 1558 */       int index = indexOf(str, 0);
/* 1559 */       if (index >= 0) {
/* 1560 */         deleteImpl(index, index + len, len);
/*      */       }
/*      */     }
/* 1563 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder deleteAll(StrMatcher matcher)
/*      */   {
/* 1578 */     return replace(matcher, null, 0, this.size, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder deleteFirst(StrMatcher matcher)
/*      */   {
/* 1592 */     return replace(matcher, null, 0, this.size, 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void replaceImpl(int startIndex, int endIndex, int removeLen, String insertStr, int insertLen)
/*      */   {
/* 1607 */     int newSize = this.size - removeLen + insertLen;
/* 1608 */     if (insertLen != removeLen) {
/* 1609 */       ensureCapacity(newSize);
/* 1610 */       System.arraycopy(this.buffer, endIndex, this.buffer, startIndex + insertLen, this.size - endIndex);
/* 1611 */       this.size = newSize;
/*      */     }
/* 1613 */     if (insertLen > 0) {
/* 1614 */       insertStr.getChars(0, insertLen, this.buffer, startIndex);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder replace(int startIndex, int endIndex, String replaceStr)
/*      */   {
/* 1630 */     endIndex = validateRange(startIndex, endIndex);
/* 1631 */     int insertLen = replaceStr == null ? 0 : replaceStr.length();
/* 1632 */     replaceImpl(startIndex, endIndex, endIndex - startIndex, replaceStr, insertLen);
/* 1633 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder replaceAll(char search, char replace)
/*      */   {
/* 1646 */     if (search != replace) {
/* 1647 */       for (int i = 0; i < this.size; i++) {
/* 1648 */         if (this.buffer[i] == search) {
/* 1649 */           this.buffer[i] = replace;
/*      */         }
/*      */       }
/*      */     }
/* 1653 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder replaceFirst(char search, char replace)
/*      */   {
/* 1665 */     if (search != replace) {
/* 1666 */       for (int i = 0; i < this.size; i++) {
/* 1667 */         if (this.buffer[i] == search) {
/* 1668 */           this.buffer[i] = replace;
/* 1669 */           break;
/*      */         }
/*      */       }
/*      */     }
/* 1673 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder replaceAll(String searchStr, String replaceStr)
/*      */   {
/* 1685 */     int searchLen = searchStr == null ? 0 : searchStr.length();
/* 1686 */     if (searchLen > 0) {
/* 1687 */       int replaceLen = replaceStr == null ? 0 : replaceStr.length();
/* 1688 */       int index = indexOf(searchStr, 0);
/* 1689 */       while (index >= 0) {
/* 1690 */         replaceImpl(index, index + searchLen, searchLen, replaceStr, replaceLen);
/* 1691 */         index = indexOf(searchStr, index + replaceLen);
/*      */       }
/*      */     }
/* 1694 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder replaceFirst(String searchStr, String replaceStr)
/*      */   {
/* 1705 */     int searchLen = searchStr == null ? 0 : searchStr.length();
/* 1706 */     if (searchLen > 0) {
/* 1707 */       int index = indexOf(searchStr, 0);
/* 1708 */       if (index >= 0) {
/* 1709 */         int replaceLen = replaceStr == null ? 0 : replaceStr.length();
/* 1710 */         replaceImpl(index, index + searchLen, searchLen, replaceStr, replaceLen);
/*      */       }
/*      */     }
/* 1713 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder replaceAll(StrMatcher matcher, String replaceStr)
/*      */   {
/* 1729 */     return replace(matcher, replaceStr, 0, this.size, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder replaceFirst(StrMatcher matcher, String replaceStr)
/*      */   {
/* 1744 */     return replace(matcher, replaceStr, 0, this.size, 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder replace(StrMatcher matcher, String replaceStr, int startIndex, int endIndex, int replaceCount)
/*      */   {
/* 1767 */     endIndex = validateRange(startIndex, endIndex);
/* 1768 */     return replaceImpl(matcher, replaceStr, startIndex, endIndex, replaceCount);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private StrBuilder replaceImpl(StrMatcher matcher, String replaceStr, int from, int to, int replaceCount)
/*      */   {
/* 1789 */     if ((matcher == null) || (this.size == 0)) {
/* 1790 */       return this;
/*      */     }
/* 1792 */     int replaceLen = replaceStr == null ? 0 : replaceStr.length();
/* 1793 */     char[] buf = this.buffer;
/* 1794 */     for (int i = from; (i < to) && (replaceCount != 0); i++) {
/* 1795 */       int removeLen = matcher.isMatch(buf, i, from, to);
/* 1796 */       if (removeLen > 0) {
/* 1797 */         replaceImpl(i, i + removeLen, removeLen, replaceStr, replaceLen);
/* 1798 */         to = to - removeLen + replaceLen;
/* 1799 */         i = i + replaceLen - 1;
/* 1800 */         if (replaceCount > 0) {
/* 1801 */           replaceCount--;
/*      */         }
/*      */       }
/*      */     }
/* 1805 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder reverse()
/*      */   {
/* 1815 */     if (this.size == 0) {
/* 1816 */       return this;
/*      */     }
/*      */     
/* 1819 */     int half = this.size / 2;
/* 1820 */     char[] buf = this.buffer;
/* 1821 */     int leftIdx = 0; for (int rightIdx = this.size - 1; leftIdx < half; rightIdx--) {
/* 1822 */       char swap = buf[leftIdx];
/* 1823 */       buf[leftIdx] = buf[rightIdx];
/* 1824 */       buf[rightIdx] = swap;leftIdx++;
/*      */     }
/*      */     
/*      */ 
/* 1826 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrBuilder trim()
/*      */   {
/* 1837 */     if (this.size == 0) {
/* 1838 */       return this;
/*      */     }
/* 1840 */     int len = this.size;
/* 1841 */     char[] buf = this.buffer;
/* 1842 */     int pos = 0;
/* 1843 */     while ((pos < len) && (buf[pos] <= ' ')) {
/* 1844 */       pos++;
/*      */     }
/* 1846 */     while ((pos < len) && (buf[(len - 1)] <= ' ')) {
/* 1847 */       len--;
/*      */     }
/* 1849 */     if (len < this.size) {
/* 1850 */       delete(len, this.size);
/*      */     }
/* 1852 */     if (pos > 0) {
/* 1853 */       delete(0, pos);
/*      */     }
/* 1855 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean startsWith(String str)
/*      */   {
/* 1868 */     if (str == null) {
/* 1869 */       return false;
/*      */     }
/* 1871 */     int len = str.length();
/* 1872 */     if (len == 0) {
/* 1873 */       return true;
/*      */     }
/* 1875 */     if (len > this.size) {
/* 1876 */       return false;
/*      */     }
/* 1878 */     for (int i = 0; i < len; i++) {
/* 1879 */       if (this.buffer[i] != str.charAt(i)) {
/* 1880 */         return false;
/*      */       }
/*      */     }
/* 1883 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean endsWith(String str)
/*      */   {
/* 1895 */     if (str == null) {
/* 1896 */       return false;
/*      */     }
/* 1898 */     int len = str.length();
/* 1899 */     if (len == 0) {
/* 1900 */       return true;
/*      */     }
/* 1902 */     if (len > this.size) {
/* 1903 */       return false;
/*      */     }
/* 1905 */     int pos = this.size - len;
/* 1906 */     for (int i = 0; i < len; pos++) {
/* 1907 */       if (this.buffer[pos] != str.charAt(i)) {
/* 1908 */         return false;
/*      */       }
/* 1906 */       i++;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1911 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String substring(int start)
/*      */   {
/* 1923 */     return substring(start, this.size);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String substring(int startIndex, int endIndex)
/*      */   {
/* 1940 */     endIndex = validateRange(startIndex, endIndex);
/* 1941 */     return new String(this.buffer, startIndex, endIndex - startIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String leftString(int length)
/*      */   {
/* 1957 */     if (length <= 0)
/* 1958 */       return "";
/* 1959 */     if (length >= this.size) {
/* 1960 */       return new String(this.buffer, 0, this.size);
/*      */     }
/* 1962 */     return new String(this.buffer, 0, length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String rightString(int length)
/*      */   {
/* 1979 */     if (length <= 0)
/* 1980 */       return "";
/* 1981 */     if (length >= this.size) {
/* 1982 */       return new String(this.buffer, 0, this.size);
/*      */     }
/* 1984 */     return new String(this.buffer, this.size - length, length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String midString(int index, int length)
/*      */   {
/* 2005 */     if (index < 0) {
/* 2006 */       index = 0;
/*      */     }
/* 2008 */     if ((length <= 0) || (index >= this.size)) {
/* 2009 */       return "";
/*      */     }
/* 2011 */     if (this.size <= index + length) {
/* 2012 */       return new String(this.buffer, index, this.size - index);
/*      */     }
/* 2014 */     return new String(this.buffer, index, length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean contains(char ch)
/*      */   {
/* 2026 */     char[] thisBuf = this.buffer;
/* 2027 */     for (int i = 0; i < this.size; i++) {
/* 2028 */       if (thisBuf[i] == ch) {
/* 2029 */         return true;
/*      */       }
/*      */     }
/* 2032 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean contains(String str)
/*      */   {
/* 2042 */     return indexOf(str, 0) >= 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean contains(StrMatcher matcher)
/*      */   {
/* 2057 */     return indexOf(matcher, 0) >= 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int indexOf(char ch)
/*      */   {
/* 2068 */     return indexOf(ch, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int indexOf(char ch, int startIndex)
/*      */   {
/* 2079 */     startIndex = startIndex < 0 ? 0 : startIndex;
/* 2080 */     if (startIndex >= this.size) {
/* 2081 */       return -1;
/*      */     }
/* 2083 */     char[] thisBuf = this.buffer;
/* 2084 */     for (int i = startIndex; i < this.size; i++) {
/* 2085 */       if (thisBuf[i] == ch) {
/* 2086 */         return i;
/*      */       }
/*      */     }
/* 2089 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int indexOf(String str)
/*      */   {
/* 2101 */     return indexOf(str, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int indexOf(String str, int startIndex)
/*      */   {
/* 2115 */     startIndex = startIndex < 0 ? 0 : startIndex;
/* 2116 */     if ((str == null) || (startIndex >= this.size)) {
/* 2117 */       return -1;
/*      */     }
/* 2119 */     int strLen = str.length();
/* 2120 */     if (strLen == 1) {
/* 2121 */       return indexOf(str.charAt(0), startIndex);
/*      */     }
/* 2123 */     if (strLen == 0) {
/* 2124 */       return startIndex;
/*      */     }
/* 2126 */     if (strLen > this.size) {
/* 2127 */       return -1;
/*      */     }
/* 2129 */     char[] thisBuf = this.buffer;
/* 2130 */     int len = this.size - strLen + 1;
/*      */     label125:
/* 2132 */     for (int i = startIndex; i < len; i++) {
/* 2133 */       for (int j = 0; j < strLen; j++) {
/* 2134 */         if (str.charAt(j) != thisBuf[(i + j)]) {
/*      */           break label125;
/*      */         }
/*      */       }
/* 2138 */       return i;
/*      */     }
/* 2140 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int indexOf(StrMatcher matcher)
/*      */   {
/* 2154 */     return indexOf(matcher, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int indexOf(StrMatcher matcher, int startIndex)
/*      */   {
/* 2170 */     startIndex = startIndex < 0 ? 0 : startIndex;
/* 2171 */     if ((matcher == null) || (startIndex >= this.size)) {
/* 2172 */       return -1;
/*      */     }
/* 2174 */     int len = this.size;
/* 2175 */     char[] buf = this.buffer;
/* 2176 */     for (int i = startIndex; i < len; i++) {
/* 2177 */       if (matcher.isMatch(buf, i, startIndex, len) > 0) {
/* 2178 */         return i;
/*      */       }
/*      */     }
/* 2181 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int lastIndexOf(char ch)
/*      */   {
/* 2192 */     return lastIndexOf(ch, this.size - 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int lastIndexOf(char ch, int startIndex)
/*      */   {
/* 2203 */     startIndex = startIndex >= this.size ? this.size - 1 : startIndex;
/* 2204 */     if (startIndex < 0) {
/* 2205 */       return -1;
/*      */     }
/* 2207 */     for (int i = startIndex; i >= 0; i--) {
/* 2208 */       if (this.buffer[i] == ch) {
/* 2209 */         return i;
/*      */       }
/*      */     }
/* 2212 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int lastIndexOf(String str)
/*      */   {
/* 2224 */     return lastIndexOf(str, this.size - 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int lastIndexOf(String str, int startIndex)
/*      */   {
/* 2238 */     startIndex = startIndex >= this.size ? this.size - 1 : startIndex;
/* 2239 */     if ((str == null) || (startIndex < 0)) {
/* 2240 */       return -1;
/*      */     }
/* 2242 */     int strLen = str.length();
/* 2243 */     if ((strLen > 0) && (strLen <= this.size)) {
/* 2244 */       if (strLen == 1) {
/* 2245 */         return lastIndexOf(str.charAt(0), startIndex);
/*      */       }
/*      */       
/*      */       label114:
/* 2249 */       for (int i = startIndex - strLen + 1; i >= 0; i--) {
/* 2250 */         for (int j = 0; j < strLen; j++) {
/* 2251 */           if (str.charAt(j) != this.buffer[(i + j)]) {
/*      */             break label114;
/*      */           }
/*      */         }
/* 2255 */         return i;
/*      */       }
/*      */     }
/* 2258 */     else if (strLen == 0) {
/* 2259 */       return startIndex;
/*      */     }
/* 2261 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int lastIndexOf(StrMatcher matcher)
/*      */   {
/* 2275 */     return lastIndexOf(matcher, this.size);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int lastIndexOf(StrMatcher matcher, int startIndex)
/*      */   {
/* 2291 */     startIndex = startIndex >= this.size ? this.size - 1 : startIndex;
/* 2292 */     if ((matcher == null) || (startIndex < 0)) {
/* 2293 */       return -1;
/*      */     }
/* 2295 */     char[] buf = this.buffer;
/* 2296 */     int endIndex = startIndex + 1;
/* 2297 */     for (int i = startIndex; i >= 0; i--) {
/* 2298 */       if (matcher.isMatch(buf, i, 0, endIndex) > 0) {
/* 2299 */         return i;
/*      */       }
/*      */     }
/* 2302 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StrTokenizer asTokenizer()
/*      */   {
/* 2339 */     return new StrBuilderTokenizer();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Reader asReader()
/*      */   {
/* 2363 */     return new StrBuilderReader();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Writer asWriter()
/*      */   {
/* 2388 */     return new StrBuilderWriter();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean equalsIgnoreCase(StrBuilder other)
/*      */   {
/* 2430 */     if (this == other) {
/* 2431 */       return true;
/*      */     }
/* 2433 */     if (this.size != other.size) {
/* 2434 */       return false;
/*      */     }
/* 2436 */     char[] thisBuf = this.buffer;
/* 2437 */     char[] otherBuf = other.buffer;
/* 2438 */     for (int i = this.size - 1; i >= 0; i--) {
/* 2439 */       char c1 = thisBuf[i];
/* 2440 */       char c2 = otherBuf[i];
/* 2441 */       if ((c1 != c2) && (Character.toUpperCase(c1) != Character.toUpperCase(c2))) {
/* 2442 */         return false;
/*      */       }
/*      */     }
/* 2445 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean equals(StrBuilder other)
/*      */   {
/* 2456 */     if (this == other) {
/* 2457 */       return true;
/*      */     }
/* 2459 */     if (this.size != other.size) {
/* 2460 */       return false;
/*      */     }
/* 2462 */     char[] thisBuf = this.buffer;
/* 2463 */     char[] otherBuf = other.buffer;
/* 2464 */     for (int i = this.size - 1; i >= 0; i--) {
/* 2465 */       if (thisBuf[i] != otherBuf[i]) {
/* 2466 */         return false;
/*      */       }
/*      */     }
/* 2469 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean equals(Object obj)
/*      */   {
/* 2480 */     if ((obj instanceof StrBuilder)) {
/* 2481 */       return equals((StrBuilder)obj);
/*      */     }
/* 2483 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int hashCode()
/*      */   {
/* 2492 */     char[] buf = this.buffer;
/* 2493 */     int hash = 0;
/* 2494 */     for (int i = this.size - 1; i >= 0; i--) {
/* 2495 */       hash = 31 * hash + buf[i];
/*      */     }
/* 2497 */     return hash;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 2511 */     return new String(this.buffer, 0, this.size);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StringBuffer toStringBuffer()
/*      */   {
/* 2521 */     return new StringBuffer(this.size).append(this.buffer, 0, this.size);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int validateRange(int startIndex, int endIndex)
/*      */   {
/* 2535 */     if (startIndex < 0) {
/* 2536 */       throw new StringIndexOutOfBoundsException(startIndex);
/*      */     }
/* 2538 */     if (endIndex > this.size) {
/* 2539 */       endIndex = this.size;
/*      */     }
/* 2541 */     if (startIndex > endIndex) {
/* 2542 */       throw new StringIndexOutOfBoundsException("end < start");
/*      */     }
/* 2544 */     return endIndex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void validateIndex(int index)
/*      */   {
/* 2554 */     if ((index < 0) || (index > this.size)) {
/* 2555 */       throw new StringIndexOutOfBoundsException(index);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   class StrBuilderTokenizer
/*      */     extends StrTokenizer
/*      */   {
/*      */     StrBuilderTokenizer() {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     protected List tokenize(char[] chars, int offset, int count)
/*      */     {
/* 2572 */       if (chars == null) {
/* 2573 */         return super.tokenize(StrBuilder.this.buffer, 0, StrBuilder.this.size());
/*      */       }
/* 2575 */       return super.tokenize(chars, offset, count);
/*      */     }
/*      */     
/*      */ 
/*      */     public String getContent()
/*      */     {
/* 2581 */       String str = super.getContent();
/* 2582 */       if (str == null) {
/* 2583 */         return StrBuilder.this.toString();
/*      */       }
/* 2585 */       return str;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   class StrBuilderReader
/*      */     extends Reader
/*      */   {
/*      */     private int pos;
/*      */     
/*      */ 
/*      */     private int mark;
/*      */     
/*      */ 
/*      */ 
/*      */     StrBuilderReader() {}
/*      */     
/*      */ 
/*      */ 
/*      */     public void close() {}
/*      */     
/*      */ 
/*      */ 
/*      */     public int read()
/*      */     {
/* 2612 */       if (!ready()) {
/* 2613 */         return -1;
/*      */       }
/* 2615 */       return StrBuilder.this.charAt(this.pos++);
/*      */     }
/*      */     
/*      */     public int read(char[] b, int off, int len)
/*      */     {
/* 2620 */       if ((off < 0) || (len < 0) || (off > b.length) || (off + len > b.length) || (off + len < 0))
/*      */       {
/* 2622 */         throw new IndexOutOfBoundsException();
/*      */       }
/* 2624 */       if (len == 0) {
/* 2625 */         return 0;
/*      */       }
/* 2627 */       if (this.pos >= StrBuilder.this.size()) {
/* 2628 */         return -1;
/*      */       }
/* 2630 */       if (this.pos + len > StrBuilder.this.size()) {
/* 2631 */         len = StrBuilder.this.size() - this.pos;
/*      */       }
/* 2633 */       StrBuilder.this.getChars(this.pos, this.pos + len, b, off);
/* 2634 */       this.pos += len;
/* 2635 */       return len;
/*      */     }
/*      */     
/*      */     public long skip(long n)
/*      */     {
/* 2640 */       if (this.pos + n > StrBuilder.this.size()) {
/* 2641 */         n = StrBuilder.this.size() - this.pos;
/*      */       }
/* 2643 */       if (n < 0L) {
/* 2644 */         return 0L;
/*      */       }
/* 2646 */       this.pos = ((int)(this.pos + n));
/* 2647 */       return n;
/*      */     }
/*      */     
/*      */     public boolean ready()
/*      */     {
/* 2652 */       return this.pos < StrBuilder.this.size();
/*      */     }
/*      */     
/*      */     public boolean markSupported()
/*      */     {
/* 2657 */       return true;
/*      */     }
/*      */     
/*      */     public void mark(int readAheadLimit)
/*      */     {
/* 2662 */       this.mark = this.pos;
/*      */     }
/*      */     
/*      */     public void reset()
/*      */     {
/* 2667 */       this.pos = this.mark;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   class StrBuilderWriter
/*      */     extends Writer
/*      */   {
/*      */     StrBuilderWriter() {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void close() {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void flush() {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void write(int c)
/*      */     {
/* 2694 */       StrBuilder.this.append((char)c);
/*      */     }
/*      */     
/*      */     public void write(char[] cbuf)
/*      */     {
/* 2699 */       StrBuilder.this.append(cbuf);
/*      */     }
/*      */     
/*      */     public void write(char[] cbuf, int off, int len)
/*      */     {
/* 2704 */       StrBuilder.this.append(cbuf, off, len);
/*      */     }
/*      */     
/*      */     public void write(String str)
/*      */     {
/* 2709 */       StrBuilder.this.append(str);
/*      */     }
/*      */     
/*      */     public void write(String str, int off, int len)
/*      */     {
/* 2714 */       StrBuilder.this.append(str, off, len);
/*      */     }
/*      */   }
/*      */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-lang-2.4.jar!\org\apache\commons\lang\text\StrBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */