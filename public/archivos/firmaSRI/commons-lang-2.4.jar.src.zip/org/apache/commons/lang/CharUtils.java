/*     */ package org.apache.commons.lang;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharUtils
/*     */ {
/*     */   private static final String CHAR_STRING = "\000\001\002\003\004\005\006\007\b\t\n\013\f\r\016\017\020\021\022\023\024\025\026\027\030\031\032\033\034\035\036\037 !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  50 */   private static final String[] CHAR_STRING_ARRAY = new String[''];
/*  51 */   private static final Character[] CHAR_ARRAY = new Character[''];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final char LF = '\n';
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final char CR = '\r';
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*  73 */     for (int i = 127; i >= 0; i--) {
/*  74 */       CHAR_STRING_ARRAY[i] = "\000\001\002\003\004\005\006\007\b\t\n\013\f\r\016\017\020\021\022\023\024\025\026\027\030\031\032\033\034\035\036\037 !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~".substring(i, i + 1);
/*  75 */       CHAR_ARRAY[i] = new Character((char)i);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Character toCharacterObject(char ch)
/*     */   {
/* 106 */     if (ch < CHAR_ARRAY.length) {
/* 107 */       return CHAR_ARRAY[ch];
/*     */     }
/* 109 */     return new Character(ch);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Character toCharacterObject(String str)
/*     */   {
/* 130 */     if (StringUtils.isEmpty(str)) {
/* 131 */       return null;
/*     */     }
/* 133 */     return toCharacterObject(str.charAt(0));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static char toChar(Character ch)
/*     */   {
/* 151 */     if (ch == null) {
/* 152 */       throw new IllegalArgumentException("The Character must not be null");
/*     */     }
/* 154 */     return ch.charValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static char toChar(Character ch, char defaultValue)
/*     */   {
/* 171 */     if (ch == null) {
/* 172 */       return defaultValue;
/*     */     }
/* 174 */     return ch.charValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static char toChar(String str)
/*     */   {
/* 194 */     if (StringUtils.isEmpty(str)) {
/* 195 */       throw new IllegalArgumentException("The String must not be empty");
/*     */     }
/* 197 */     return str.charAt(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static char toChar(String str, char defaultValue)
/*     */   {
/* 216 */     if (StringUtils.isEmpty(str)) {
/* 217 */       return defaultValue;
/*     */     }
/* 219 */     return str.charAt(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int toIntValue(char ch)
/*     */   {
/* 239 */     if (!isAsciiNumeric(ch)) {
/* 240 */       throw new IllegalArgumentException("The character " + ch + " is not in the range '0' - '9'");
/*     */     }
/* 242 */     return ch - '0';
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int toIntValue(char ch, int defaultValue)
/*     */   {
/* 261 */     if (!isAsciiNumeric(ch)) {
/* 262 */       return defaultValue;
/*     */     }
/* 264 */     return ch - '0';
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int toIntValue(Character ch)
/*     */   {
/* 284 */     if (ch == null) {
/* 285 */       throw new IllegalArgumentException("The character must not be null");
/*     */     }
/* 287 */     return toIntValue(ch.charValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int toIntValue(Character ch, int defaultValue)
/*     */   {
/* 307 */     if (ch == null) {
/* 308 */       return defaultValue;
/*     */     }
/* 310 */     return toIntValue(ch.charValue(), defaultValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toString(char ch)
/*     */   {
/* 329 */     if (ch < '') {
/* 330 */       return CHAR_STRING_ARRAY[ch];
/*     */     }
/* 332 */     return new String(new char[] { ch });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toString(Character ch)
/*     */   {
/* 353 */     if (ch == null) {
/* 354 */       return null;
/*     */     }
/* 356 */     return toString(ch.charValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String unicodeEscaped(char ch)
/*     */   {
/* 374 */     if (ch < '\020')
/* 375 */       return "\\u000" + Integer.toHexString(ch);
/* 376 */     if (ch < 'Ā')
/* 377 */       return "\\u00" + Integer.toHexString(ch);
/* 378 */     if (ch < 'က') {
/* 379 */       return "\\u0" + Integer.toHexString(ch);
/*     */     }
/* 381 */     return "\\u" + Integer.toHexString(ch);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String unicodeEscaped(Character ch)
/*     */   {
/* 401 */     if (ch == null) {
/* 402 */       return null;
/*     */     }
/* 404 */     return unicodeEscaped(ch.charValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isAscii(char ch)
/*     */   {
/* 424 */     return ch < '';
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isAsciiPrintable(char ch)
/*     */   {
/* 443 */     return (ch >= ' ') && (ch < '');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isAsciiControl(char ch)
/*     */   {
/* 462 */     return (ch < ' ') || (ch == '');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isAsciiAlpha(char ch)
/*     */   {
/* 481 */     return ((ch >= 'A') && (ch <= 'Z')) || ((ch >= 'a') && (ch <= 'z'));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isAsciiAlphaUpper(char ch)
/*     */   {
/* 500 */     return (ch >= 'A') && (ch <= 'Z');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isAsciiAlphaLower(char ch)
/*     */   {
/* 519 */     return (ch >= 'a') && (ch <= 'z');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isAsciiNumeric(char ch)
/*     */   {
/* 538 */     return (ch >= '0') && (ch <= '9');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isAsciiAlphanumeric(char ch)
/*     */   {
/* 557 */     return ((ch >= 'A') && (ch <= 'Z')) || ((ch >= 'a') && (ch <= 'z')) || ((ch >= '0') && (ch <= '9'));
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-lang-2.4.jar!\org\apache\commons\lang\CharUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */