/*     */ package org.apache.commons.lang;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocaleUtils
/*     */ {
/*     */   private static final List cAvailableLocaleList;
/*     */   private static Set cAvailableLocaleSet;
/*  47 */   private static final Map cLanguagesByCountry = Collections.synchronizedMap(new HashMap());
/*     */   
/*  49 */   private static final Map cCountriesByLanguage = Collections.synchronizedMap(new HashMap());
/*     */   
/*  51 */   static { List list = Arrays.asList(Locale.getAvailableLocales());
/*  52 */     cAvailableLocaleList = Collections.unmodifiableList(list);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Locale toLocale(String str)
/*     */   {
/*  95 */     if (str == null) {
/*  96 */       return null;
/*     */     }
/*  98 */     int len = str.length();
/*  99 */     if ((len != 2) && (len != 5) && (len < 7)) {
/* 100 */       throw new IllegalArgumentException("Invalid locale format: " + str);
/*     */     }
/* 102 */     char ch0 = str.charAt(0);
/* 103 */     char ch1 = str.charAt(1);
/* 104 */     if ((ch0 < 'a') || (ch0 > 'z') || (ch1 < 'a') || (ch1 > 'z')) {
/* 105 */       throw new IllegalArgumentException("Invalid locale format: " + str);
/*     */     }
/* 107 */     if (len == 2) {
/* 108 */       return new Locale(str, "");
/*     */     }
/* 110 */     if (str.charAt(2) != '_') {
/* 111 */       throw new IllegalArgumentException("Invalid locale format: " + str);
/*     */     }
/* 113 */     char ch3 = str.charAt(3);
/* 114 */     if (ch3 == '_') {
/* 115 */       return new Locale(str.substring(0, 2), "", str.substring(4));
/*     */     }
/* 117 */     char ch4 = str.charAt(4);
/* 118 */     if ((ch3 < 'A') || (ch3 > 'Z') || (ch4 < 'A') || (ch4 > 'Z')) {
/* 119 */       throw new IllegalArgumentException("Invalid locale format: " + str);
/*     */     }
/* 121 */     if (len == 5) {
/* 122 */       return new Locale(str.substring(0, 2), str.substring(3, 5));
/*     */     }
/* 124 */     if (str.charAt(5) != '_') {
/* 125 */       throw new IllegalArgumentException("Invalid locale format: " + str);
/*     */     }
/* 127 */     return new Locale(str.substring(0, 2), str.substring(3, 5), str.substring(6));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List localeLookupList(Locale locale)
/*     */   {
/* 146 */     return localeLookupList(locale, locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List localeLookupList(Locale locale, Locale defaultLocale)
/*     */   {
/* 168 */     List list = new ArrayList(4);
/* 169 */     if (locale != null) {
/* 170 */       list.add(locale);
/* 171 */       if (locale.getVariant().length() > 0) {
/* 172 */         list.add(new Locale(locale.getLanguage(), locale.getCountry()));
/*     */       }
/* 174 */       if (locale.getCountry().length() > 0) {
/* 175 */         list.add(new Locale(locale.getLanguage(), ""));
/*     */       }
/* 177 */       if (!list.contains(defaultLocale)) {
/* 178 */         list.add(defaultLocale);
/*     */       }
/*     */     }
/* 181 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List availableLocaleList()
/*     */   {
/* 195 */     return cAvailableLocaleList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Set availableLocaleSet()
/*     */   {
/* 209 */     Set set = cAvailableLocaleSet;
/* 210 */     if (set == null) {
/* 211 */       set = new HashSet(availableLocaleList());
/* 212 */       set = Collections.unmodifiableSet(set);
/* 213 */       cAvailableLocaleSet = set;
/*     */     }
/* 215 */     return set;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isAvailableLocale(Locale locale)
/*     */   {
/* 226 */     return availableLocaleList().contains(locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List languagesByCountry(String countryCode)
/*     */   {
/* 240 */     List langs = (List)cLanguagesByCountry.get(countryCode);
/* 241 */     if (langs == null) {
/* 242 */       if (countryCode != null) {
/* 243 */         langs = new ArrayList();
/* 244 */         List locales = availableLocaleList();
/* 245 */         for (int i = 0; i < locales.size(); i++) {
/* 246 */           Locale locale = (Locale)locales.get(i);
/* 247 */           if ((countryCode.equals(locale.getCountry())) && (locale.getVariant().length() == 0))
/*     */           {
/* 249 */             langs.add(locale);
/*     */           }
/*     */         }
/* 252 */         langs = Collections.unmodifiableList(langs);
/*     */       } else {
/* 254 */         langs = Collections.EMPTY_LIST;
/*     */       }
/* 256 */       cLanguagesByCountry.put(countryCode, langs);
/*     */     }
/* 258 */     return langs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List countriesByLanguage(String languageCode)
/*     */   {
/* 272 */     List countries = (List)cCountriesByLanguage.get(languageCode);
/* 273 */     if (countries == null) {
/* 274 */       if (languageCode != null) {
/* 275 */         countries = new ArrayList();
/* 276 */         List locales = availableLocaleList();
/* 277 */         for (int i = 0; i < locales.size(); i++) {
/* 278 */           Locale locale = (Locale)locales.get(i);
/* 279 */           if ((languageCode.equals(locale.getLanguage())) && (locale.getCountry().length() != 0) && (locale.getVariant().length() == 0))
/*     */           {
/*     */ 
/* 282 */             countries.add(locale);
/*     */           }
/*     */         }
/* 285 */         countries = Collections.unmodifiableList(countries);
/*     */       } else {
/* 287 */         countries = Collections.EMPTY_LIST;
/*     */       }
/* 289 */       cCountriesByLanguage.put(languageCode, countries);
/*     */     }
/* 291 */     return countries;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-lang-2.4.jar!\org\apache\commons\lang\LocaleUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */