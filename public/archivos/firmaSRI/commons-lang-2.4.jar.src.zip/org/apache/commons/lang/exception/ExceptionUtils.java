/*      */ package org.apache.commons.lang.exception;
/*      */ 
/*      */ import java.io.PrintStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.StringWriter;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.StringTokenizer;
/*      */ import org.apache.commons.lang.ArrayUtils;
/*      */ import org.apache.commons.lang.ClassUtils;
/*      */ import org.apache.commons.lang.NullArgumentException;
/*      */ import org.apache.commons.lang.StringUtils;
/*      */ import org.apache.commons.lang.SystemUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ExceptionUtils
/*      */ {
/*      */   static final String WRAPPED_MARKER = " [wrapped] ";
/*   62 */   private static String[] CAUSE_METHOD_NAMES = { "getCause", "getNextException", "getTargetException", "getException", "getSourceException", "getRootCause", "getCausedByException", "getNested", "getLinkedException", "getNestedException", "getLinkedCause", "getThrowable" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final Method THROWABLE_CAUSE_METHOD;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final Method THROWABLE_INITCAUSE_METHOD;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static
/*      */   {
/*      */     Method causeMethod;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*   90 */       causeMethod = Throwable.class.getMethod("getCause", null);
/*      */     } catch (Exception e) { Method causeMethod;
/*   92 */       causeMethod = null;
/*      */     }
/*   94 */     THROWABLE_CAUSE_METHOD = causeMethod;
/*      */     try {
/*   96 */       causeMethod = class$java$lang$Throwable.getMethod("initCause", new Class[] { Throwable.class });
/*      */     } catch (Exception e) {
/*   98 */       causeMethod = null;
/*      */     }
/*  100 */     THROWABLE_INITCAUSE_METHOD = causeMethod;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addCauseMethodName(String methodName)
/*      */   {
/*  123 */     if ((StringUtils.isNotEmpty(methodName)) && (!isCauseMethodName(methodName))) {
/*  124 */       List list = getCauseMethodNameList();
/*  125 */       if (list.add(methodName)) {
/*  126 */         synchronized (CAUSE_METHOD_NAMES) {
/*  127 */           CAUSE_METHOD_NAMES = toArray(list);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeCauseMethodName(String methodName)
/*      */   {
/*  142 */     if (StringUtils.isNotEmpty(methodName)) {
/*  143 */       List list = getCauseMethodNameList();
/*  144 */       if (list.remove(methodName)) {
/*  145 */         synchronized (CAUSE_METHOD_NAMES) {
/*  146 */           CAUSE_METHOD_NAMES = toArray(list);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean setCause(Throwable target, Throwable cause)
/*      */   {
/*  181 */     if (target == null) {
/*  182 */       throw new NullArgumentException("target");
/*      */     }
/*  184 */     Object[] causeArgs = { cause };
/*  185 */     boolean modifiedTarget = false;
/*  186 */     if (THROWABLE_INITCAUSE_METHOD != null) {
/*      */       try {
/*  188 */         THROWABLE_INITCAUSE_METHOD.invoke(target, causeArgs);
/*  189 */         modifiedTarget = true;
/*      */       }
/*      */       catch (IllegalAccessException ignored) {}catch (InvocationTargetException ignored) {}
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  197 */       Method setCauseMethod = target.getClass().getMethod("setCause", new Class[] { Throwable.class });
/*  198 */       setCauseMethod.invoke(target, causeArgs);
/*  199 */       modifiedTarget = true;
/*      */     }
/*      */     catch (NoSuchMethodException ignored) {}catch (IllegalAccessException ignored) {}catch (InvocationTargetException ignored) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  207 */     return modifiedTarget;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static String[] toArray(List list)
/*      */   {
/*  216 */     return (String[])list.toArray(new String[list.size()]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isCauseMethodName(String methodName)
/*      */   {
/*  240 */     synchronized (CAUSE_METHOD_NAMES) {
/*  241 */       return ArrayUtils.indexOf(CAUSE_METHOD_NAMES, methodName) >= 0;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Throwable getCause(Throwable throwable, String[] methodNames)
/*      */   {
/*  302 */     if (throwable == null) {
/*  303 */       return null;
/*      */     }
/*  305 */     Throwable cause = getCauseUsingWellKnownTypes(throwable);
/*  306 */     if (cause == null) {
/*  307 */       if (methodNames == null) {
/*  308 */         synchronized (CAUSE_METHOD_NAMES) {
/*  309 */           methodNames = CAUSE_METHOD_NAMES;
/*      */         }
/*      */       }
/*  312 */       for (int i = 0; i < methodNames.length; i++) {
/*  313 */         String methodName = methodNames[i];
/*  314 */         if (methodName != null) {
/*  315 */           cause = getCauseUsingMethodName(throwable, methodName);
/*  316 */           if (cause != null) {
/*      */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*  322 */       if (cause == null) {
/*  323 */         cause = getCauseUsingFieldName(throwable, "detail");
/*      */       }
/*      */     }
/*  326 */     return cause;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Throwable getRootCause(Throwable throwable)
/*      */   {
/*  347 */     List list = getThrowableList(throwable);
/*  348 */     return list.size() < 2 ? null : (Throwable)list.get(list.size() - 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static Throwable getCauseUsingWellKnownTypes(Throwable throwable)
/*      */   {
/*  362 */     if ((throwable instanceof Nestable))
/*  363 */       return ((Nestable)throwable).getCause();
/*  364 */     if ((throwable instanceof SQLException))
/*  365 */       return ((SQLException)throwable).getNextException();
/*  366 */     if ((throwable instanceof InvocationTargetException)) {
/*  367 */       return ((InvocationTargetException)throwable).getTargetException();
/*      */     }
/*  369 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static Throwable getCauseUsingMethodName(Throwable throwable, String methodName)
/*      */   {
/*  381 */     Method method = null;
/*      */     try {
/*  383 */       method = throwable.getClass().getMethod(methodName, null);
/*      */     }
/*      */     catch (NoSuchMethodException ignored) {}catch (SecurityException ignored) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  390 */     if ((method != null) && (Throwable.class.isAssignableFrom(method.getReturnType()))) {
/*      */       try {
/*  392 */         return (Throwable)method.invoke(throwable, ArrayUtils.EMPTY_OBJECT_ARRAY);
/*      */       }
/*      */       catch (IllegalAccessException ignored) {}catch (IllegalArgumentException ignored) {}catch (InvocationTargetException ignored) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  401 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static Throwable getCauseUsingFieldName(Throwable throwable, String fieldName)
/*      */   {
/*  412 */     Field field = null;
/*      */     try {
/*  414 */       field = throwable.getClass().getField(fieldName);
/*      */     }
/*      */     catch (NoSuchFieldException ignored) {}catch (SecurityException ignored) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  421 */     if ((field != null) && (Throwable.class.isAssignableFrom(field.getType()))) {
/*      */       try {
/*  423 */         return (Throwable)field.get(throwable);
/*      */       }
/*      */       catch (IllegalAccessException ignored) {}catch (IllegalArgumentException ignored) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  430 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isThrowableNested()
/*      */   {
/*  443 */     return THROWABLE_CAUSE_METHOD != null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isNestedThrowable(Throwable throwable)
/*      */   {
/*  456 */     if (throwable == null) {
/*  457 */       return false;
/*      */     }
/*      */     
/*  460 */     if ((throwable instanceof Nestable))
/*  461 */       return true;
/*  462 */     if ((throwable instanceof SQLException))
/*  463 */       return true;
/*  464 */     if ((throwable instanceof InvocationTargetException))
/*  465 */       return true;
/*  466 */     if (isThrowableNested()) {
/*  467 */       return true;
/*      */     }
/*      */     
/*  470 */     Class cls = throwable.getClass();
/*  471 */     synchronized (CAUSE_METHOD_NAMES) {
/*  472 */       int i = 0; for (int isize = CAUSE_METHOD_NAMES.length; i < isize; i++) {
/*      */         try {
/*  474 */           Method method = cls.getMethod(CAUSE_METHOD_NAMES[i], null);
/*  475 */           if ((method != null) && (Throwable.class.isAssignableFrom(method.getReturnType()))) {
/*  476 */             return true;
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException ignored) {}catch (SecurityException ignored) {}
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  487 */       Field field = cls.getField("detail");
/*  488 */       if (field != null) {
/*  489 */         return true;
/*      */       }
/*      */     }
/*      */     catch (NoSuchFieldException ignored) {}catch (SecurityException ignored) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  497 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int getThrowableCount(Throwable throwable)
/*      */   {
/*  518 */     return getThrowableList(throwable).size();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Throwable[] getThrowables(Throwable throwable)
/*      */   {
/*  541 */     List list = getThrowableList(throwable);
/*  542 */     return (Throwable[])list.toArray(new Throwable[list.size()]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static List getThrowableList(Throwable throwable)
/*      */   {
/*  565 */     List list = new ArrayList();
/*  566 */     while ((throwable != null) && (!list.contains(throwable))) {
/*  567 */       list.add(throwable);
/*  568 */       throwable = getCause(throwable);
/*      */     }
/*  570 */     return list;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOfThrowable(Throwable throwable, Class clazz)
/*      */   {
/*  589 */     return indexOf(throwable, clazz, 0, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOfThrowable(Throwable throwable, Class clazz, int fromIndex)
/*      */   {
/*  612 */     return indexOf(throwable, clazz, fromIndex, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOfType(Throwable throwable, Class type)
/*      */   {
/*  632 */     return indexOf(throwable, type, 0, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOfType(Throwable throwable, Class type, int fromIndex)
/*      */   {
/*  656 */     return indexOf(throwable, type, fromIndex, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static int indexOf(Throwable throwable, Class type, int fromIndex, boolean subclass)
/*      */   {
/*  671 */     if ((throwable == null) || (type == null)) {
/*  672 */       return -1;
/*      */     }
/*  674 */     if (fromIndex < 0) {
/*  675 */       fromIndex = 0;
/*      */     }
/*  677 */     Throwable[] throwables = getThrowables(throwable);
/*  678 */     if (fromIndex >= throwables.length) {
/*  679 */       return -1;
/*      */     }
/*  681 */     if (subclass) {
/*  682 */       for (int i = fromIndex; i < throwables.length; i++) {
/*  683 */         if (type.isAssignableFrom(throwables[i].getClass())) {
/*  684 */           return i;
/*      */         }
/*      */       }
/*      */     } else {
/*  688 */       for (int i = fromIndex; i < throwables.length; i++) {
/*  689 */         if (type.equals(throwables[i].getClass())) {
/*  690 */           return i;
/*      */         }
/*      */       }
/*      */     }
/*  694 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void printRootCauseStackTrace(Throwable throwable)
/*      */   {
/*  717 */     printRootCauseStackTrace(throwable, System.err);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void printRootCauseStackTrace(Throwable throwable, PrintStream stream)
/*      */   {
/*  740 */     if (throwable == null) {
/*  741 */       return;
/*      */     }
/*  743 */     if (stream == null) {
/*  744 */       throw new IllegalArgumentException("The PrintStream must not be null");
/*      */     }
/*  746 */     String[] trace = getRootCauseStackTrace(throwable);
/*  747 */     for (int i = 0; i < trace.length; i++) {
/*  748 */       stream.println(trace[i]);
/*      */     }
/*  750 */     stream.flush();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void printRootCauseStackTrace(Throwable throwable, PrintWriter writer)
/*      */   {
/*  773 */     if (throwable == null) {
/*  774 */       return;
/*      */     }
/*  776 */     if (writer == null) {
/*  777 */       throw new IllegalArgumentException("The PrintWriter must not be null");
/*      */     }
/*  779 */     String[] trace = getRootCauseStackTrace(throwable);
/*  780 */     for (int i = 0; i < trace.length; i++) {
/*  781 */       writer.println(trace[i]);
/*      */     }
/*  783 */     writer.flush();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] getRootCauseStackTrace(Throwable throwable)
/*      */   {
/*  801 */     if (throwable == null) {
/*  802 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/*  804 */     Throwable[] throwables = getThrowables(throwable);
/*  805 */     int count = throwables.length;
/*  806 */     ArrayList frames = new ArrayList();
/*  807 */     List nextTrace = getStackFrameList(throwables[(count - 1)]);
/*  808 */     int i = count; for (;;) { i--; if (i < 0) break;
/*  809 */       List trace = nextTrace;
/*  810 */       if (i != 0) {
/*  811 */         nextTrace = getStackFrameList(throwables[(i - 1)]);
/*  812 */         removeCommonFrames(trace, nextTrace);
/*      */       }
/*  814 */       if (i == count - 1) {
/*  815 */         frames.add(throwables[i].toString());
/*      */       } else {
/*  817 */         frames.add(" [wrapped] " + throwables[i].toString());
/*      */       }
/*  819 */       for (int j = 0; j < trace.size(); j++) {
/*  820 */         frames.add(trace.get(j));
/*      */       }
/*      */     }
/*  823 */     return (String[])frames.toArray(new String[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeCommonFrames(List causeFrames, List wrapperFrames)
/*      */   {
/*  835 */     if ((causeFrames == null) || (wrapperFrames == null)) {
/*  836 */       throw new IllegalArgumentException("The List must not be null");
/*      */     }
/*  838 */     int causeFrameIndex = causeFrames.size() - 1;
/*  839 */     int wrapperFrameIndex = wrapperFrames.size() - 1;
/*  840 */     while ((causeFrameIndex >= 0) && (wrapperFrameIndex >= 0))
/*      */     {
/*      */ 
/*  843 */       String causeFrame = (String)causeFrames.get(causeFrameIndex);
/*  844 */       String wrapperFrame = (String)wrapperFrames.get(wrapperFrameIndex);
/*  845 */       if (causeFrame.equals(wrapperFrame)) {
/*  846 */         causeFrames.remove(causeFrameIndex);
/*      */       }
/*  848 */       causeFrameIndex--;
/*  849 */       wrapperFrameIndex--;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getFullStackTrace(Throwable throwable)
/*      */   {
/*  865 */     StringWriter sw = new StringWriter();
/*  866 */     PrintWriter pw = new PrintWriter(sw, true);
/*  867 */     Throwable[] ts = getThrowables(throwable);
/*  868 */     for (int i = 0; i < ts.length; i++) {
/*  869 */       ts[i].printStackTrace(pw);
/*  870 */       if (isNestedThrowable(ts[i])) {
/*      */         break;
/*      */       }
/*      */     }
/*  874 */     return sw.getBuffer().toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getStackTrace(Throwable throwable)
/*      */   {
/*  891 */     StringWriter sw = new StringWriter();
/*  892 */     PrintWriter pw = new PrintWriter(sw, true);
/*  893 */     throwable.printStackTrace(pw);
/*  894 */     return sw.getBuffer().toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] getStackFrames(Throwable throwable)
/*      */   {
/*  911 */     if (throwable == null) {
/*  912 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/*  914 */     return getStackFrames(getStackTrace(throwable));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static String[] getStackFrames(String stackTrace)
/*      */   {
/*  931 */     String linebreak = SystemUtils.LINE_SEPARATOR;
/*  932 */     StringTokenizer frames = new StringTokenizer(stackTrace, linebreak);
/*  933 */     List list = new ArrayList();
/*  934 */     while (frames.hasMoreTokens()) {
/*  935 */       list.add(frames.nextToken());
/*      */     }
/*  937 */     return toArray(list);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static List getStackFrameList(Throwable t)
/*      */   {
/*  953 */     String stackTrace = getStackTrace(t);
/*  954 */     String linebreak = SystemUtils.LINE_SEPARATOR;
/*  955 */     StringTokenizer frames = new StringTokenizer(stackTrace, linebreak);
/*  956 */     List list = new ArrayList();
/*  957 */     boolean traceStarted = false;
/*  958 */     while (frames.hasMoreTokens()) {
/*  959 */       String token = frames.nextToken();
/*      */       
/*  961 */       int at = token.indexOf("at");
/*  962 */       if ((at != -1) && (token.substring(0, at).trim().length() == 0)) {
/*  963 */         traceStarted = true;
/*  964 */         list.add(token);
/*  965 */       } else { if (traceStarted)
/*      */           break;
/*      */       }
/*      */     }
/*  969 */     return list;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getMessage(Throwable th)
/*      */   {
/*  984 */     if (th == null) {
/*  985 */       return "";
/*      */     }
/*  987 */     String clsName = ClassUtils.getShortClassName(th, null);
/*  988 */     String msg = th.getMessage();
/*  989 */     return clsName + ": " + StringUtils.defaultString(msg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getRootCauseMessage(Throwable th)
/*      */   {
/* 1004 */     Throwable root = getRootCause(th);
/* 1005 */     root = root == null ? th : root;
/* 1006 */     return getMessage(root);
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   private static ArrayList getCauseMethodNameList()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 11	org/apache/commons/lang/exception/ExceptionUtils:CAUSE_METHOD_NAMES	[Ljava/lang/String;
/*      */     //   3: dup
/*      */     //   4: astore_0
/*      */     //   5: monitorenter
/*      */     //   6: new 34	java/util/ArrayList
/*      */     //   9: dup
/*      */     //   10: getstatic 11	org/apache/commons/lang/exception/ExceptionUtils:CAUSE_METHOD_NAMES	[Ljava/lang/String;
/*      */     //   13: invokestatic 35	java/util/Arrays:asList	([Ljava/lang/Object;)Ljava/util/List;
/*      */     //   16: invokespecial 36	java/util/ArrayList:<init>	(Ljava/util/Collection;)V
/*      */     //   19: aload_0
/*      */     //   20: monitorexit
/*      */     //   21: areturn
/*      */     //   22: astore_1
/*      */     //   23: aload_0
/*      */     //   24: monitorexit
/*      */     //   25: aload_1
/*      */     //   26: athrow
/*      */     // Line number table:
/*      */     //   Java source line #225	-> byte code offset #0
/*      */     //   Java source line #226	-> byte code offset #6
/*      */     //   Java source line #227	-> byte code offset #22
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   4	20	0	Ljava/lang/Object;	Object
/*      */     //   22	4	1	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   6	21	22	finally
/*      */     //   22	25	22	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public static Throwable getCause(Throwable throwable)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 11	org/apache/commons/lang/exception/ExceptionUtils:CAUSE_METHOD_NAMES	[Ljava/lang/String;
/*      */     //   3: dup
/*      */     //   4: astore_1
/*      */     //   5: monitorenter
/*      */     //   6: aload_0
/*      */     //   7: getstatic 11	org/apache/commons/lang/exception/ExceptionUtils:CAUSE_METHOD_NAMES	[Ljava/lang/String;
/*      */     //   10: invokestatic 38	org/apache/commons/lang/exception/ExceptionUtils:getCause	(Ljava/lang/Throwable;[Ljava/lang/String;)Ljava/lang/Throwable;
/*      */     //   13: aload_1
/*      */     //   14: monitorexit
/*      */     //   15: areturn
/*      */     //   16: astore_2
/*      */     //   17: aload_1
/*      */     //   18: monitorexit
/*      */     //   19: aload_2
/*      */     //   20: athrow
/*      */     // Line number table:
/*      */     //   Java source line #278	-> byte code offset #0
/*      */     //   Java source line #279	-> byte code offset #6
/*      */     //   Java source line #280	-> byte code offset #16
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	21	0	throwable	Throwable
/*      */     //   4	14	1	Ljava/lang/Object;	Object
/*      */     //   16	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   6	15	16	finally
/*      */     //   16	19	16	finally
/*      */   }
/*      */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-lang-2.4.jar!\org\apache\commons\lang\exception\ExceptionUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */