/*     */ package org.apache.commons.lang.math;
/*     */ 
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JVMRandom
/*     */   extends Random
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  43 */   private boolean constructed = false;
/*     */   
/*     */ 
/*     */ 
/*     */   public JVMRandom()
/*     */   {
/*  49 */     this.constructed = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setSeed(long seed)
/*     */   {
/*  59 */     if (this.constructed) {
/*  60 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized double nextGaussian()
/*     */   {
/*  71 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void nextBytes(byte[] byteArray)
/*     */   {
/*  81 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int nextInt()
/*     */   {
/*  91 */     return nextInt(Integer.MAX_VALUE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int nextInt(int n)
/*     */   {
/* 103 */     if (n <= 0) {
/* 104 */       throw new IllegalArgumentException("Upper bound for nextInt must be positive");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 109 */     return (int)(Math.random() * n);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long nextLong()
/*     */   {
/* 118 */     return nextLong(Long.MAX_VALUE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static long nextLong(long n)
/*     */   {
/* 132 */     if (n <= 0L) {
/* 133 */       throw new IllegalArgumentException("Upper bound for nextInt must be positive");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 138 */     return (Math.random() * n);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean nextBoolean()
/*     */   {
/* 148 */     return Math.random() > 0.5D;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float nextFloat()
/*     */   {
/* 158 */     return (float)Math.random();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double nextDouble()
/*     */   {
/* 166 */     return Math.random();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-lang-2.4.jar!\org\apache\commons\lang\math\JVMRandom.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */