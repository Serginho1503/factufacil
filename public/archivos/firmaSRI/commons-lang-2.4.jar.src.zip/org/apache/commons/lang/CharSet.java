/*     */ package org.apache.commons.lang;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharSet
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 5947847346149275958L;
/*  51 */   public static final CharSet EMPTY = new CharSet((String)null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  57 */   public static final CharSet ASCII_ALPHA = new CharSet("a-zA-Z");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  63 */   public static final CharSet ASCII_ALPHA_LOWER = new CharSet("a-z");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  69 */   public static final CharSet ASCII_ALPHA_UPPER = new CharSet("A-Z");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  75 */   public static final CharSet ASCII_NUMERIC = new CharSet("0-9");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  82 */   protected static final Map COMMON = new HashMap();
/*     */   
/*     */   static {
/*  85 */     COMMON.put(null, EMPTY);
/*  86 */     COMMON.put("", EMPTY);
/*  87 */     COMMON.put("a-zA-Z", ASCII_ALPHA);
/*  88 */     COMMON.put("A-Za-z", ASCII_ALPHA);
/*  89 */     COMMON.put("a-z", ASCII_ALPHA_LOWER);
/*  90 */     COMMON.put("A-Z", ASCII_ALPHA_UPPER);
/*  91 */     COMMON.put("0-9", ASCII_NUMERIC);
/*     */   }
/*     */   
/*     */ 
/*  95 */   private Set set = new HashSet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CharSet getInstance(String setStr)
/*     */   {
/* 142 */     Object set = COMMON.get(setStr);
/* 143 */     if (set != null) {
/* 144 */       return (CharSet)set;
/*     */     }
/* 146 */     return new CharSet(setStr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CharSet getInstance(String[] setStrs)
/*     */   {
/* 158 */     if (setStrs == null) {
/* 159 */       return null;
/*     */     }
/* 161 */     return new CharSet(setStrs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected CharSet(String setStr)
/*     */   {
/* 173 */     add(setStr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected CharSet(String[] set)
/*     */   {
/* 185 */     int sz = set.length;
/* 186 */     for (int i = 0; i < sz; i++) {
/* 187 */       add(set[i]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void add(String str)
/*     */   {
/* 198 */     if (str == null) {
/* 199 */       return;
/*     */     }
/*     */     
/* 202 */     int len = str.length();
/* 203 */     int pos = 0;
/* 204 */     while (pos < len) {
/* 205 */       int remainder = len - pos;
/* 206 */       if ((remainder >= 4) && (str.charAt(pos) == '^') && (str.charAt(pos + 2) == '-'))
/*     */       {
/* 208 */         this.set.add(new CharRange(str.charAt(pos + 1), str.charAt(pos + 3), true));
/* 209 */         pos += 4;
/* 210 */       } else if ((remainder >= 3) && (str.charAt(pos + 1) == '-'))
/*     */       {
/* 212 */         this.set.add(new CharRange(str.charAt(pos), str.charAt(pos + 2)));
/* 213 */         pos += 3;
/* 214 */       } else if ((remainder >= 2) && (str.charAt(pos) == '^'))
/*     */       {
/* 216 */         this.set.add(new CharRange(str.charAt(pos + 1), true));
/* 217 */         pos += 2;
/*     */       }
/*     */       else {
/* 220 */         this.set.add(new CharRange(str.charAt(pos)));
/* 221 */         pos++;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CharRange[] getCharRanges()
/*     */   {
/* 234 */     return (CharRange[])this.set.toArray(new CharRange[this.set.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean contains(char ch)
/*     */   {
/* 246 */     for (Iterator it = this.set.iterator(); it.hasNext();) {
/* 247 */       CharRange range = (CharRange)it.next();
/* 248 */       if (range.contains(ch)) {
/* 249 */         return true;
/*     */       }
/*     */     }
/* 252 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 269 */     if (obj == this) {
/* 270 */       return true;
/*     */     }
/* 272 */     if (!(obj instanceof CharSet)) {
/* 273 */       return false;
/*     */     }
/* 275 */     CharSet other = (CharSet)obj;
/* 276 */     return this.set.equals(other.set);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 286 */     return 89 + this.set.hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 295 */     return this.set.toString();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-lang-2.4.jar!\org\apache\commons\lang\CharSet.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */