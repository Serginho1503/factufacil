package org.apache.commons.lang.mutable;

public abstract interface Mutable
{
  public abstract Object getValue();
  
  public abstract void setValue(Object paramObject);
}


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-lang-2.4.jar!\org\apache\commons\lang\mutable\Mutable.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */