/*     */ package org.apache.commons.lang.math;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Range
/*     */ {
/*     */   public abstract Number getMinimumNumber();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getMinimumLong()
/*     */   {
/*  58 */     return getMinimumNumber().longValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMinimumInteger()
/*     */   {
/*  70 */     return getMinimumNumber().intValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getMinimumDouble()
/*     */   {
/*  82 */     return getMinimumNumber().doubleValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getMinimumFloat()
/*     */   {
/*  94 */     return getMinimumNumber().floatValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Number getMaximumNumber();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getMaximumLong()
/*     */   {
/* 113 */     return getMaximumNumber().longValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaximumInteger()
/*     */   {
/* 125 */     return getMaximumNumber().intValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getMaximumDouble()
/*     */   {
/* 137 */     return getMaximumNumber().doubleValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getMaximumFloat()
/*     */   {
/* 149 */     return getMaximumNumber().floatValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean containsNumber(Number paramNumber);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsLong(Number value)
/*     */   {
/* 184 */     if (value == null) {
/* 185 */       return false;
/*     */     }
/* 187 */     return containsLong(value.longValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsLong(long value)
/*     */   {
/* 202 */     return (value >= getMinimumLong()) && (value <= getMaximumLong());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsInteger(Number value)
/*     */   {
/* 218 */     if (value == null) {
/* 219 */       return false;
/*     */     }
/* 221 */     return containsInteger(value.intValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsInteger(int value)
/*     */   {
/* 236 */     return (value >= getMinimumInteger()) && (value <= getMaximumInteger());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsDouble(Number value)
/*     */   {
/* 252 */     if (value == null) {
/* 253 */       return false;
/*     */     }
/* 255 */     return containsDouble(value.doubleValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsDouble(double value)
/*     */   {
/* 270 */     int compareMin = NumberUtils.compare(getMinimumDouble(), value);
/* 271 */     int compareMax = NumberUtils.compare(getMaximumDouble(), value);
/* 272 */     return (compareMin <= 0) && (compareMax >= 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsFloat(Number value)
/*     */   {
/* 288 */     if (value == null) {
/* 289 */       return false;
/*     */     }
/* 291 */     return containsFloat(value.floatValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsFloat(float value)
/*     */   {
/* 306 */     int compareMin = NumberUtils.compare(getMinimumFloat(), value);
/* 307 */     int compareMax = NumberUtils.compare(getMaximumFloat(), value);
/* 308 */     return (compareMin <= 0) && (compareMax >= 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsRange(Range range)
/*     */   {
/* 332 */     if (range == null) {
/* 333 */       return false;
/*     */     }
/* 335 */     return (containsNumber(range.getMinimumNumber())) && (containsNumber(range.getMaximumNumber()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean overlapsRange(Range range)
/*     */   {
/* 358 */     if (range == null) {
/* 359 */       return false;
/*     */     }
/* 361 */     return (range.containsNumber(getMinimumNumber())) || (range.containsNumber(getMaximumNumber())) || (containsNumber(range.getMinimumNumber()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 382 */     if (obj == this)
/* 383 */       return true;
/* 384 */     if ((obj == null) || (obj.getClass() != getClass())) {
/* 385 */       return false;
/*     */     }
/* 387 */     Range range = (Range)obj;
/* 388 */     return (getMinimumNumber().equals(range.getMinimumNumber())) && (getMaximumNumber().equals(range.getMaximumNumber()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 403 */     int result = 17;
/* 404 */     result = 37 * result + getClass().hashCode();
/* 405 */     result = 37 * result + getMinimumNumber().hashCode();
/* 406 */     result = 37 * result + getMaximumNumber().hashCode();
/* 407 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 422 */     StringBuffer buf = new StringBuffer(32);
/* 423 */     buf.append("Range[");
/* 424 */     buf.append(getMinimumNumber());
/* 425 */     buf.append(',');
/* 426 */     buf.append(getMaximumNumber());
/* 427 */     buf.append(']');
/* 428 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-lang-2.4.jar!\org\apache\commons\lang\math\Range.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */