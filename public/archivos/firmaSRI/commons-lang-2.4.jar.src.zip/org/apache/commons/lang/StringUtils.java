/*      */ package org.apache.commons.lang;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StringUtils
/*      */ {
/*      */   public static final String EMPTY = "";
/*      */   public static final int INDEX_NOT_FOUND = -1;
/*      */   private static final int PAD_LIMIT = 8192;
/*      */   
/*      */   public static boolean isEmpty(String str)
/*      */   {
/*  190 */     return (str == null) || (str.length() == 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isNotEmpty(String str)
/*      */   {
/*  208 */     return !isEmpty(str);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isBlank(String str)
/*      */   {
/*      */     int strLen;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  228 */     if ((str == null) || ((strLen = str.length()) == 0))
/*  229 */       return true;
/*      */     int strLen;
/*  231 */     for (int i = 0; i < strLen; i++) {
/*  232 */       if (!Character.isWhitespace(str.charAt(i))) {
/*  233 */         return false;
/*      */       }
/*      */     }
/*  236 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isNotBlank(String str)
/*      */   {
/*  256 */     return !isBlank(str);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public static String clean(String str)
/*      */   {
/*  281 */     return str == null ? "" : str.trim();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String trim(String str)
/*      */   {
/*  308 */     return str == null ? null : str.trim();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String trimToNull(String str)
/*      */   {
/*  334 */     String ts = trim(str);
/*  335 */     return isEmpty(ts) ? null : ts;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String trimToEmpty(String str)
/*      */   {
/*  360 */     return str == null ? "" : str.trim();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String strip(String str)
/*      */   {
/*  388 */     return strip(str, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String stripToNull(String str)
/*      */   {
/*  415 */     if (str == null) {
/*  416 */       return null;
/*      */     }
/*  418 */     str = strip(str, null);
/*  419 */     return str.length() == 0 ? null : str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String stripToEmpty(String str)
/*      */   {
/*  445 */     return str == null ? "" : strip(str, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String strip(String str, String stripChars)
/*      */   {
/*  475 */     if (isEmpty(str)) {
/*  476 */       return str;
/*      */     }
/*  478 */     str = stripStart(str, stripChars);
/*  479 */     return stripEnd(str, stripChars);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String stripStart(String str, String stripChars)
/*      */   {
/*      */     int strLen;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  508 */     if ((str == null) || ((strLen = str.length()) == 0))
/*  509 */       return str;
/*      */     int strLen;
/*  511 */     int start = 0;
/*  512 */     if (stripChars == null) {
/*  513 */       while ((start != strLen) && (Character.isWhitespace(str.charAt(start))))
/*  514 */         start++;
/*      */     }
/*  516 */     if (stripChars.length() == 0) {
/*  517 */       return str;
/*      */     }
/*  519 */     while ((start != strLen) && (stripChars.indexOf(str.charAt(start)) != -1)) {
/*  520 */       start++;
/*      */     }
/*      */     
/*  523 */     return str.substring(start);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String stripEnd(String str, String stripChars)
/*      */   {
/*      */     int end;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  552 */     if ((str == null) || ((end = str.length()) == 0)) {
/*  553 */       return str;
/*      */     }
/*      */     int end;
/*  556 */     if (stripChars == null) {
/*  557 */       while ((end != 0) && (Character.isWhitespace(str.charAt(end - 1))))
/*  558 */         end--;
/*      */     }
/*  560 */     if (stripChars.length() == 0) {
/*  561 */       return str;
/*      */     }
/*  563 */     while ((end != 0) && (stripChars.indexOf(str.charAt(end - 1)) != -1)) {
/*  564 */       end--;
/*      */     }
/*      */     
/*  567 */     return str.substring(0, end);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] stripAll(String[] strs)
/*      */   {
/*  592 */     return stripAll(strs, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] stripAll(String[] strs, String stripChars)
/*      */   {
/*      */     int strsLen;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  622 */     if ((strs == null) || ((strsLen = strs.length) == 0))
/*  623 */       return strs;
/*      */     int strsLen;
/*  625 */     String[] newArr = new String[strsLen];
/*  626 */     for (int i = 0; i < strsLen; i++) {
/*  627 */       newArr[i] = strip(strs[i], stripChars);
/*      */     }
/*  629 */     return newArr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean equals(String str1, String str2)
/*      */   {
/*  655 */     return str1 == null ? false : str2 == null ? true : str1.equals(str2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean equalsIgnoreCase(String str1, String str2)
/*      */   {
/*  680 */     return str1 == null ? false : str2 == null ? true : str1.equalsIgnoreCase(str2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOf(String str, char searchChar)
/*      */   {
/*  705 */     if (isEmpty(str)) {
/*  706 */       return -1;
/*      */     }
/*  708 */     return str.indexOf(searchChar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOf(String str, char searchChar, int startPos)
/*      */   {
/*  737 */     if (isEmpty(str)) {
/*  738 */       return -1;
/*      */     }
/*  740 */     return str.indexOf(searchChar, startPos);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOf(String str, String searchStr)
/*      */   {
/*  766 */     if ((str == null) || (searchStr == null)) {
/*  767 */       return -1;
/*      */     }
/*  769 */     return str.indexOf(searchStr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int ordinalIndexOf(String str, String searchStr, int ordinal)
/*      */   {
/*  800 */     if ((str == null) || (searchStr == null) || (ordinal <= 0)) {
/*  801 */       return -1;
/*      */     }
/*  803 */     if (searchStr.length() == 0) {
/*  804 */       return 0;
/*      */     }
/*  806 */     int found = 0;
/*  807 */     int index = -1;
/*      */     do {
/*  809 */       index = str.indexOf(searchStr, index + 1);
/*  810 */       if (index < 0) {
/*  811 */         return index;
/*      */       }
/*  813 */       found++;
/*  814 */     } while (found < ordinal);
/*  815 */     return index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOf(String str, String searchStr, int startPos)
/*      */   {
/*  850 */     if ((str == null) || (searchStr == null)) {
/*  851 */       return -1;
/*      */     }
/*      */     
/*  854 */     if ((searchStr.length() == 0) && (startPos >= str.length())) {
/*  855 */       return str.length();
/*      */     }
/*  857 */     return str.indexOf(searchStr, startPos);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int lastIndexOf(String str, char searchChar)
/*      */   {
/*  882 */     if (isEmpty(str)) {
/*  883 */       return -1;
/*      */     }
/*  885 */     return str.lastIndexOf(searchChar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int lastIndexOf(String str, char searchChar, int startPos)
/*      */   {
/*  916 */     if (isEmpty(str)) {
/*  917 */       return -1;
/*      */     }
/*  919 */     return str.lastIndexOf(searchChar, startPos);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int lastIndexOf(String str, String searchStr)
/*      */   {
/*  945 */     if ((str == null) || (searchStr == null)) {
/*  946 */       return -1;
/*      */     }
/*  948 */     return str.lastIndexOf(searchStr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int lastIndexOf(String str, String searchStr, int startPos)
/*      */   {
/*  980 */     if ((str == null) || (searchStr == null)) {
/*  981 */       return -1;
/*      */     }
/*  983 */     return str.lastIndexOf(searchStr, startPos);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean contains(String str, char searchChar)
/*      */   {
/* 1008 */     if (isEmpty(str)) {
/* 1009 */       return false;
/*      */     }
/* 1011 */     return str.indexOf(searchChar) >= 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean contains(String str, String searchStr)
/*      */   {
/* 1036 */     if ((str == null) || (searchStr == null)) {
/* 1037 */       return false;
/*      */     }
/* 1039 */     return str.indexOf(searchStr) >= 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean containsIgnoreCase(String str, String searchStr)
/*      */   {
/* 1066 */     if ((str == null) || (searchStr == null)) {
/* 1067 */       return false;
/*      */     }
/* 1069 */     return contains(str.toUpperCase(), searchStr.toUpperCase());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOfAny(String str, char[] searchChars)
/*      */   {
/* 1097 */     if ((isEmpty(str)) || (ArrayUtils.isEmpty(searchChars))) {
/* 1098 */       return -1;
/*      */     }
/* 1100 */     for (int i = 0; i < str.length(); i++) {
/* 1101 */       char ch = str.charAt(i);
/* 1102 */       for (int j = 0; j < searchChars.length; j++) {
/* 1103 */         if (searchChars[j] == ch) {
/* 1104 */           return i;
/*      */         }
/*      */       }
/*      */     }
/* 1108 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOfAny(String str, String searchChars)
/*      */   {
/* 1134 */     if ((isEmpty(str)) || (isEmpty(searchChars))) {
/* 1135 */       return -1;
/*      */     }
/* 1137 */     return indexOfAny(str, searchChars.toCharArray());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean containsAny(String str, char[] searchChars)
/*      */   {
/* 1166 */     if ((str == null) || (str.length() == 0) || (searchChars == null) || (searchChars.length == 0)) {
/* 1167 */       return false;
/*      */     }
/* 1169 */     for (int i = 0; i < str.length(); i++) {
/* 1170 */       char ch = str.charAt(i);
/* 1171 */       for (int j = 0; j < searchChars.length; j++) {
/* 1172 */         if (searchChars[j] == ch) {
/* 1173 */           return true;
/*      */         }
/*      */       }
/*      */     }
/* 1177 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean containsAny(String str, String searchChars)
/*      */   {
/* 1208 */     if (searchChars == null) {
/* 1209 */       return false;
/*      */     }
/* 1211 */     return containsAny(str, searchChars.toCharArray());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOfAnyBut(String str, char[] searchChars)
/*      */   {
/* 1239 */     if ((isEmpty(str)) || (ArrayUtils.isEmpty(searchChars)))
/* 1240 */       return -1;
/*      */     label61:
/* 1242 */     for (int i = 0; i < str.length(); i++) {
/* 1243 */       char ch = str.charAt(i);
/* 1244 */       for (int j = 0; j < searchChars.length; j++) {
/* 1245 */         if (searchChars[j] == ch) {
/*      */           break label61;
/*      */         }
/*      */       }
/* 1249 */       return i;
/*      */     }
/* 1251 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOfAnyBut(String str, String searchChars)
/*      */   {
/* 1277 */     if ((isEmpty(str)) || (isEmpty(searchChars))) {
/* 1278 */       return -1;
/*      */     }
/* 1280 */     for (int i = 0; i < str.length(); i++) {
/* 1281 */       if (searchChars.indexOf(str.charAt(i)) < 0) {
/* 1282 */         return i;
/*      */       }
/*      */     }
/* 1285 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean containsOnly(String str, char[] valid)
/*      */   {
/* 1313 */     if ((valid == null) || (str == null)) {
/* 1314 */       return false;
/*      */     }
/* 1316 */     if (str.length() == 0) {
/* 1317 */       return true;
/*      */     }
/* 1319 */     if (valid.length == 0) {
/* 1320 */       return false;
/*      */     }
/* 1322 */     return indexOfAnyBut(str, valid) == -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean containsOnly(String str, String validChars)
/*      */   {
/* 1348 */     if ((str == null) || (validChars == null)) {
/* 1349 */       return false;
/*      */     }
/* 1351 */     return containsOnly(str, validChars.toCharArray());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean containsNone(String str, char[] invalidChars)
/*      */   {
/* 1379 */     if ((str == null) || (invalidChars == null)) {
/* 1380 */       return true;
/*      */     }
/* 1382 */     int strSize = str.length();
/* 1383 */     int validSize = invalidChars.length;
/* 1384 */     for (int i = 0; i < strSize; i++) {
/* 1385 */       char ch = str.charAt(i);
/* 1386 */       for (int j = 0; j < validSize; j++) {
/* 1387 */         if (invalidChars[j] == ch) {
/* 1388 */           return false;
/*      */         }
/*      */       }
/*      */     }
/* 1392 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean containsNone(String str, String invalidChars)
/*      */   {
/* 1418 */     if ((str == null) || (invalidChars == null)) {
/* 1419 */       return true;
/*      */     }
/* 1421 */     return containsNone(str, invalidChars.toCharArray());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOfAny(String str, String[] searchStrs)
/*      */   {
/* 1453 */     if ((str == null) || (searchStrs == null)) {
/* 1454 */       return -1;
/*      */     }
/* 1456 */     int sz = searchStrs.length;
/*      */     
/*      */ 
/* 1459 */     int ret = Integer.MAX_VALUE;
/*      */     
/* 1461 */     int tmp = 0;
/* 1462 */     for (int i = 0; i < sz; i++) {
/* 1463 */       String search = searchStrs[i];
/* 1464 */       if (search != null)
/*      */       {
/*      */ 
/* 1467 */         tmp = str.indexOf(search);
/* 1468 */         if (tmp != -1)
/*      */         {
/*      */ 
/*      */ 
/* 1472 */           if (tmp < ret)
/* 1473 */             ret = tmp;
/*      */         }
/*      */       }
/*      */     }
/* 1477 */     return ret == Integer.MAX_VALUE ? -1 : ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int lastIndexOfAny(String str, String[] searchStrs)
/*      */   {
/* 1506 */     if ((str == null) || (searchStrs == null)) {
/* 1507 */       return -1;
/*      */     }
/* 1509 */     int sz = searchStrs.length;
/* 1510 */     int ret = -1;
/* 1511 */     int tmp = 0;
/* 1512 */     for (int i = 0; i < sz; i++) {
/* 1513 */       String search = searchStrs[i];
/* 1514 */       if (search != null)
/*      */       {
/*      */ 
/* 1517 */         tmp = str.lastIndexOf(search);
/* 1518 */         if (tmp > ret)
/* 1519 */           ret = tmp;
/*      */       }
/*      */     }
/* 1522 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String substring(String str, int start)
/*      */   {
/* 1552 */     if (str == null) {
/* 1553 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 1557 */     if (start < 0) {
/* 1558 */       start = str.length() + start;
/*      */     }
/*      */     
/* 1561 */     if (start < 0) {
/* 1562 */       start = 0;
/*      */     }
/* 1564 */     if (start > str.length()) {
/* 1565 */       return "";
/*      */     }
/*      */     
/* 1568 */     return str.substring(start);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String substring(String str, int start, int end)
/*      */   {
/* 1607 */     if (str == null) {
/* 1608 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 1612 */     if (end < 0) {
/* 1613 */       end = str.length() + end;
/*      */     }
/* 1615 */     if (start < 0) {
/* 1616 */       start = str.length() + start;
/*      */     }
/*      */     
/*      */ 
/* 1620 */     if (end > str.length()) {
/* 1621 */       end = str.length();
/*      */     }
/*      */     
/*      */ 
/* 1625 */     if (start > end) {
/* 1626 */       return "";
/*      */     }
/*      */     
/* 1629 */     if (start < 0) {
/* 1630 */       start = 0;
/*      */     }
/* 1632 */     if (end < 0) {
/* 1633 */       end = 0;
/*      */     }
/*      */     
/* 1636 */     return str.substring(start, end);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String left(String str, int len)
/*      */   {
/* 1662 */     if (str == null) {
/* 1663 */       return null;
/*      */     }
/* 1665 */     if (len < 0) {
/* 1666 */       return "";
/*      */     }
/* 1668 */     if (str.length() <= len) {
/* 1669 */       return str;
/*      */     }
/* 1671 */     return str.substring(0, len);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String right(String str, int len)
/*      */   {
/* 1695 */     if (str == null) {
/* 1696 */       return null;
/*      */     }
/* 1698 */     if (len < 0) {
/* 1699 */       return "";
/*      */     }
/* 1701 */     if (str.length() <= len) {
/* 1702 */       return str;
/*      */     }
/* 1704 */     return str.substring(str.length() - len);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String mid(String str, int pos, int len)
/*      */   {
/* 1732 */     if (str == null) {
/* 1733 */       return null;
/*      */     }
/* 1735 */     if ((len < 0) || (pos > str.length())) {
/* 1736 */       return "";
/*      */     }
/* 1738 */     if (pos < 0) {
/* 1739 */       pos = 0;
/*      */     }
/* 1741 */     if (str.length() <= pos + len) {
/* 1742 */       return str.substring(pos);
/*      */     }
/* 1744 */     return str.substring(pos, pos + len);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String substringBefore(String str, String separator)
/*      */   {
/* 1775 */     if ((isEmpty(str)) || (separator == null)) {
/* 1776 */       return str;
/*      */     }
/* 1778 */     if (separator.length() == 0) {
/* 1779 */       return "";
/*      */     }
/* 1781 */     int pos = str.indexOf(separator);
/* 1782 */     if (pos == -1) {
/* 1783 */       return str;
/*      */     }
/* 1785 */     return str.substring(0, pos);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String substringAfter(String str, String separator)
/*      */   {
/* 1815 */     if (isEmpty(str)) {
/* 1816 */       return str;
/*      */     }
/* 1818 */     if (separator == null) {
/* 1819 */       return "";
/*      */     }
/* 1821 */     int pos = str.indexOf(separator);
/* 1822 */     if (pos == -1) {
/* 1823 */       return "";
/*      */     }
/* 1825 */     return str.substring(pos + separator.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String substringBeforeLast(String str, String separator)
/*      */   {
/* 1854 */     if ((isEmpty(str)) || (isEmpty(separator))) {
/* 1855 */       return str;
/*      */     }
/* 1857 */     int pos = str.lastIndexOf(separator);
/* 1858 */     if (pos == -1) {
/* 1859 */       return str;
/*      */     }
/* 1861 */     return str.substring(0, pos);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String substringAfterLast(String str, String separator)
/*      */   {
/* 1892 */     if (isEmpty(str)) {
/* 1893 */       return str;
/*      */     }
/* 1895 */     if (isEmpty(separator)) {
/* 1896 */       return "";
/*      */     }
/* 1898 */     int pos = str.lastIndexOf(separator);
/* 1899 */     if ((pos == -1) || (pos == str.length() - separator.length())) {
/* 1900 */       return "";
/*      */     }
/* 1902 */     return str.substring(pos + separator.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String substringBetween(String str, String tag)
/*      */   {
/* 1929 */     return substringBetween(str, tag, tag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String substringBetween(String str, String open, String close)
/*      */   {
/* 1960 */     if ((str == null) || (open == null) || (close == null)) {
/* 1961 */       return null;
/*      */     }
/* 1963 */     int start = str.indexOf(open);
/* 1964 */     if (start != -1) {
/* 1965 */       int end = str.indexOf(close, start + open.length());
/* 1966 */       if (end != -1) {
/* 1967 */         return str.substring(start + open.length(), end);
/*      */       }
/*      */     }
/* 1970 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] substringsBetween(String str, String open, String close)
/*      */   {
/* 1996 */     if ((str == null) || (isEmpty(open)) || (isEmpty(close))) {
/* 1997 */       return null;
/*      */     }
/* 1999 */     int strLen = str.length();
/* 2000 */     if (strLen == 0) {
/* 2001 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/* 2003 */     int closeLen = close.length();
/* 2004 */     int openLen = open.length();
/* 2005 */     List list = new ArrayList();
/* 2006 */     int pos = 0;
/* 2007 */     while (pos < strLen - closeLen) {
/* 2008 */       int start = str.indexOf(open, pos);
/* 2009 */       if (start < 0) {
/*      */         break;
/*      */       }
/* 2012 */       start += openLen;
/* 2013 */       int end = str.indexOf(close, start);
/* 2014 */       if (end < 0) {
/*      */         break;
/*      */       }
/* 2017 */       list.add(str.substring(start, end));
/* 2018 */       pos = end + closeLen;
/*      */     }
/* 2020 */     if (list.isEmpty()) {
/* 2021 */       return null;
/*      */     }
/* 2023 */     return (String[])list.toArray(new String[list.size()]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public static String getNestedString(String str, String tag)
/*      */   {
/* 2051 */     return substringBetween(str, tag, tag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public static String getNestedString(String str, String open, String close)
/*      */   {
/* 2081 */     return substringBetween(str, open, close);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] split(String str)
/*      */   {
/* 2109 */     return split(str, null, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] split(String str, char separatorChar)
/*      */   {
/* 2137 */     return splitWorker(str, separatorChar, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] split(String str, String separatorChars)
/*      */   {
/* 2166 */     return splitWorker(str, separatorChars, -1, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] split(String str, String separatorChars, int max)
/*      */   {
/* 2200 */     return splitWorker(str, separatorChars, max, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] splitByWholeSeparator(String str, String separator)
/*      */   {
/* 2227 */     return splitByWholeSeparatorWorker(str, separator, -1, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] splitByWholeSeparator(String str, String separator, int max)
/*      */   {
/* 2258 */     return splitByWholeSeparatorWorker(str, separator, max, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] splitByWholeSeparatorPreserveAllTokens(String str, String separator)
/*      */   {
/* 2287 */     return splitByWholeSeparatorWorker(str, separator, -1, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] splitByWholeSeparatorPreserveAllTokens(String str, String separator, int max)
/*      */   {
/* 2320 */     return splitByWholeSeparatorWorker(str, separator, max, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static String[] splitByWholeSeparatorWorker(String str, String separator, int max, boolean preserveAllTokens)
/*      */   {
/* 2340 */     if (str == null) {
/* 2341 */       return null;
/*      */     }
/*      */     
/* 2344 */     int len = str.length();
/*      */     
/* 2346 */     if (len == 0) {
/* 2347 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/*      */     
/* 2350 */     if ((separator == null) || ("".equals(separator)))
/*      */     {
/* 2352 */       return splitWorker(str, null, max, preserveAllTokens);
/*      */     }
/*      */     
/* 2355 */     int separatorLength = separator.length();
/*      */     
/* 2357 */     ArrayList substrings = new ArrayList();
/* 2358 */     int numberOfSubstrings = 0;
/* 2359 */     int beg = 0;
/* 2360 */     int end = 0;
/* 2361 */     while (end < len) {
/* 2362 */       end = str.indexOf(separator, beg);
/*      */       
/* 2364 */       if (end > -1) {
/* 2365 */         if (end > beg) {
/* 2366 */           numberOfSubstrings++;
/*      */           
/* 2368 */           if (numberOfSubstrings == max) {
/* 2369 */             end = len;
/* 2370 */             substrings.add(str.substring(beg));
/*      */           }
/*      */           else
/*      */           {
/* 2374 */             substrings.add(str.substring(beg, end));
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 2379 */             beg = end + separatorLength;
/*      */           }
/*      */         }
/*      */         else {
/* 2383 */           if (preserveAllTokens) {
/* 2384 */             numberOfSubstrings++;
/* 2385 */             if (numberOfSubstrings == max) {
/* 2386 */               end = len;
/* 2387 */               substrings.add(str.substring(beg));
/*      */             } else {
/* 2389 */               substrings.add("");
/*      */             }
/*      */           }
/* 2392 */           beg = end + separatorLength;
/*      */         }
/*      */       }
/*      */       else {
/* 2396 */         substrings.add(str.substring(beg));
/* 2397 */         end = len;
/*      */       }
/*      */     }
/*      */     
/* 2401 */     return (String[])substrings.toArray(new String[substrings.size()]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] splitPreserveAllTokens(String str)
/*      */   {
/* 2430 */     return splitWorker(str, null, -1, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] splitPreserveAllTokens(String str, char separatorChar)
/*      */   {
/* 2466 */     return splitWorker(str, separatorChar, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static String[] splitWorker(String str, char separatorChar, boolean preserveAllTokens)
/*      */   {
/* 2484 */     if (str == null) {
/* 2485 */       return null;
/*      */     }
/* 2487 */     int len = str.length();
/* 2488 */     if (len == 0) {
/* 2489 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/* 2491 */     List list = new ArrayList();
/* 2492 */     int i = 0;int start = 0;
/* 2493 */     boolean match = false;
/* 2494 */     boolean lastMatch = false;
/* 2495 */     while (i < len)
/* 2496 */       if (str.charAt(i) == separatorChar) {
/* 2497 */         if ((match) || (preserveAllTokens)) {
/* 2498 */           list.add(str.substring(start, i));
/* 2499 */           match = false;
/* 2500 */           lastMatch = true;
/*      */         }
/* 2502 */         i++;start = i;
/*      */       }
/*      */       else {
/* 2505 */         lastMatch = false;
/* 2506 */         match = true;
/* 2507 */         i++;
/*      */       }
/* 2509 */     if ((match) || ((preserveAllTokens) && (lastMatch))) {
/* 2510 */       list.add(str.substring(start, i));
/*      */     }
/* 2512 */     return (String[])list.toArray(new String[list.size()]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] splitPreserveAllTokens(String str, String separatorChars)
/*      */   {
/* 2549 */     return splitWorker(str, separatorChars, -1, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] splitPreserveAllTokens(String str, String separatorChars, int max)
/*      */   {
/* 2589 */     return splitWorker(str, separatorChars, max, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static String[] splitWorker(String str, String separatorChars, int max, boolean preserveAllTokens)
/*      */   {
/* 2611 */     if (str == null) {
/* 2612 */       return null;
/*      */     }
/* 2614 */     int len = str.length();
/* 2615 */     if (len == 0) {
/* 2616 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/* 2618 */     List list = new ArrayList();
/* 2619 */     int sizePlus1 = 1;
/* 2620 */     int i = 0;int start = 0;
/* 2621 */     boolean match = false;
/* 2622 */     boolean lastMatch = false;
/* 2623 */     if (separatorChars == null)
/*      */     {
/* 2625 */       while (i < len)
/* 2626 */         if (Character.isWhitespace(str.charAt(i))) {
/* 2627 */           if ((match) || (preserveAllTokens)) {
/* 2628 */             lastMatch = true;
/* 2629 */             if (sizePlus1++ == max) {
/* 2630 */               i = len;
/* 2631 */               lastMatch = false;
/*      */             }
/* 2633 */             list.add(str.substring(start, i));
/* 2634 */             match = false;
/*      */           }
/* 2636 */           i++;start = i;
/*      */         }
/*      */         else {
/* 2639 */           lastMatch = false;
/* 2640 */           match = true;
/* 2641 */           i++;
/*      */         } }
/* 2643 */     if (separatorChars.length() == 1)
/*      */     {
/* 2645 */       char sep = separatorChars.charAt(0);
/* 2646 */       while (i < len) {
/* 2647 */         if (str.charAt(i) == sep) {
/* 2648 */           if ((match) || (preserveAllTokens)) {
/* 2649 */             lastMatch = true;
/* 2650 */             if (sizePlus1++ == max) {
/* 2651 */               i = len;
/* 2652 */               lastMatch = false;
/*      */             }
/* 2654 */             list.add(str.substring(start, i));
/* 2655 */             match = false;
/*      */           }
/* 2657 */           i++;start = i;
/*      */         }
/*      */         else {
/* 2660 */           lastMatch = false;
/* 2661 */           match = true;
/* 2662 */           i++;
/*      */         }
/*      */       }
/*      */     } else {
/* 2666 */       while (i < len)
/* 2667 */         if (separatorChars.indexOf(str.charAt(i)) >= 0) {
/* 2668 */           if ((match) || (preserveAllTokens)) {
/* 2669 */             lastMatch = true;
/* 2670 */             if (sizePlus1++ == max) {
/* 2671 */               i = len;
/* 2672 */               lastMatch = false;
/*      */             }
/* 2674 */             list.add(str.substring(start, i));
/* 2675 */             match = false;
/*      */           }
/* 2677 */           i++;start = i;
/*      */         }
/*      */         else {
/* 2680 */           lastMatch = false;
/* 2681 */           match = true;
/* 2682 */           i++;
/*      */         }
/*      */     }
/* 2685 */     if ((match) || ((preserveAllTokens) && (lastMatch))) {
/* 2686 */       list.add(str.substring(start, i));
/*      */     }
/* 2688 */     return (String[])list.toArray(new String[list.size()]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] splitByCharacterType(String str)
/*      */   {
/* 2711 */     return splitByCharacterType(str, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] splitByCharacterTypeCamelCase(String str)
/*      */   {
/* 2739 */     return splitByCharacterType(str, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static String[] splitByCharacterType(String str, boolean camelCase)
/*      */   {
/* 2757 */     if (str == null) {
/* 2758 */       return null;
/*      */     }
/* 2760 */     if (str.length() == 0) {
/* 2761 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/* 2763 */     char[] c = str.toCharArray();
/* 2764 */     List list = new ArrayList();
/* 2765 */     int tokenStart = 0;
/* 2766 */     int currentType = Character.getType(c[tokenStart]);
/* 2767 */     for (int pos = tokenStart + 1; pos < c.length; pos++) {
/* 2768 */       int type = Character.getType(c[pos]);
/* 2769 */       if (type != currentType)
/*      */       {
/*      */ 
/* 2772 */         if ((camelCase) && (type == 2) && (currentType == 1)) {
/* 2773 */           int newTokenStart = pos - 1;
/* 2774 */           if (newTokenStart != tokenStart) {
/* 2775 */             list.add(new String(c, tokenStart, newTokenStart - tokenStart));
/* 2776 */             tokenStart = newTokenStart;
/*      */           }
/*      */         } else {
/* 2779 */           list.add(new String(c, tokenStart, pos - tokenStart));
/* 2780 */           tokenStart = pos;
/*      */         }
/* 2782 */         currentType = type;
/*      */       } }
/* 2784 */     list.add(new String(c, tokenStart, c.length - tokenStart));
/* 2785 */     return (String[])list.toArray(new String[list.size()]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public static String concatenate(Object[] array)
/*      */   {
/* 2809 */     return join(array, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String join(Object[] array)
/*      */   {
/* 2833 */     return join(array, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String join(Object[] array, char separator)
/*      */   {
/* 2859 */     if (array == null) {
/* 2860 */       return null;
/*      */     }
/*      */     
/* 2863 */     return join(array, separator, 0, array.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String join(Object[] array, char separator, int startIndex, int endIndex)
/*      */   {
/* 2893 */     if (array == null) {
/* 2894 */       return null;
/*      */     }
/* 2896 */     int bufSize = endIndex - startIndex;
/* 2897 */     if (bufSize <= 0) {
/* 2898 */       return "";
/*      */     }
/*      */     
/* 2901 */     bufSize *= ((array[startIndex] == null ? 16 : array[startIndex].toString().length()) + 1);
/* 2902 */     StringBuffer buf = new StringBuffer(bufSize);
/*      */     
/* 2904 */     for (int i = startIndex; i < endIndex; i++) {
/* 2905 */       if (i > startIndex) {
/* 2906 */         buf.append(separator);
/*      */       }
/* 2908 */       if (array[i] != null) {
/* 2909 */         buf.append(array[i]);
/*      */       }
/*      */     }
/* 2912 */     return buf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String join(Object[] array, String separator)
/*      */   {
/* 2940 */     if (array == null) {
/* 2941 */       return null;
/*      */     }
/* 2943 */     return join(array, separator, 0, array.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String join(Object[] array, String separator, int startIndex, int endIndex)
/*      */   {
/* 2974 */     if (array == null) {
/* 2975 */       return null;
/*      */     }
/* 2977 */     if (separator == null) {
/* 2978 */       separator = "";
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2983 */     int bufSize = endIndex - startIndex;
/* 2984 */     if (bufSize <= 0) {
/* 2985 */       return "";
/*      */     }
/*      */     
/* 2988 */     bufSize *= ((array[startIndex] == null ? 16 : array[startIndex].toString().length()) + separator.length());
/*      */     
/*      */ 
/* 2991 */     StringBuffer buf = new StringBuffer(bufSize);
/*      */     
/* 2993 */     for (int i = startIndex; i < endIndex; i++) {
/* 2994 */       if (i > startIndex) {
/* 2995 */         buf.append(separator);
/*      */       }
/* 2997 */       if (array[i] != null) {
/* 2998 */         buf.append(array[i]);
/*      */       }
/*      */     }
/* 3001 */     return buf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String join(Iterator iterator, char separator)
/*      */   {
/* 3021 */     if (iterator == null) {
/* 3022 */       return null;
/*      */     }
/* 3024 */     if (!iterator.hasNext()) {
/* 3025 */       return "";
/*      */     }
/* 3027 */     Object first = iterator.next();
/* 3028 */     if (!iterator.hasNext()) {
/* 3029 */       return ObjectUtils.toString(first);
/*      */     }
/*      */     
/*      */ 
/* 3033 */     StringBuffer buf = new StringBuffer(256);
/* 3034 */     if (first != null) {
/* 3035 */       buf.append(first);
/*      */     }
/*      */     
/* 3038 */     while (iterator.hasNext()) {
/* 3039 */       buf.append(separator);
/* 3040 */       Object obj = iterator.next();
/* 3041 */       if (obj != null) {
/* 3042 */         buf.append(obj);
/*      */       }
/*      */     }
/*      */     
/* 3046 */     return buf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String join(Iterator iterator, String separator)
/*      */   {
/* 3065 */     if (iterator == null) {
/* 3066 */       return null;
/*      */     }
/* 3068 */     if (!iterator.hasNext()) {
/* 3069 */       return "";
/*      */     }
/* 3071 */     Object first = iterator.next();
/* 3072 */     if (!iterator.hasNext()) {
/* 3073 */       return ObjectUtils.toString(first);
/*      */     }
/*      */     
/*      */ 
/* 3077 */     StringBuffer buf = new StringBuffer(256);
/* 3078 */     if (first != null) {
/* 3079 */       buf.append(first);
/*      */     }
/*      */     
/* 3082 */     while (iterator.hasNext()) {
/* 3083 */       if (separator != null) {
/* 3084 */         buf.append(separator);
/*      */       }
/* 3086 */       Object obj = iterator.next();
/* 3087 */       if (obj != null) {
/* 3088 */         buf.append(obj);
/*      */       }
/*      */     }
/* 3091 */     return buf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String join(Collection collection, char separator)
/*      */   {
/* 3109 */     if (collection == null) {
/* 3110 */       return null;
/*      */     }
/* 3112 */     return join(collection.iterator(), separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String join(Collection collection, String separator)
/*      */   {
/* 3130 */     if (collection == null) {
/* 3131 */       return null;
/*      */     }
/* 3133 */     return join(collection.iterator(), separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public static String deleteSpaces(String str)
/*      */   {
/* 3165 */     if (str == null) {
/* 3166 */       return null;
/*      */     }
/* 3168 */     return CharSetUtils.delete(str, " \t\r\n\b");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String deleteWhitespace(String str)
/*      */   {
/* 3186 */     if (isEmpty(str)) {
/* 3187 */       return str;
/*      */     }
/* 3189 */     int sz = str.length();
/* 3190 */     char[] chs = new char[sz];
/* 3191 */     int count = 0;
/* 3192 */     for (int i = 0; i < sz; i++) {
/* 3193 */       if (!Character.isWhitespace(str.charAt(i))) {
/* 3194 */         chs[(count++)] = str.charAt(i);
/*      */       }
/*      */     }
/* 3197 */     if (count == sz) {
/* 3198 */       return str;
/*      */     }
/* 3200 */     return new String(chs, 0, count);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String removeStart(String str, String remove)
/*      */   {
/* 3230 */     if ((isEmpty(str)) || (isEmpty(remove))) {
/* 3231 */       return str;
/*      */     }
/* 3233 */     if (str.startsWith(remove)) {
/* 3234 */       return str.substring(remove.length());
/*      */     }
/* 3236 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String removeStartIgnoreCase(String str, String remove)
/*      */   {
/* 3265 */     if ((isEmpty(str)) || (isEmpty(remove))) {
/* 3266 */       return str;
/*      */     }
/* 3268 */     if (startsWithIgnoreCase(str, remove)) {
/* 3269 */       return str.substring(remove.length());
/*      */     }
/* 3271 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String removeEnd(String str, String remove)
/*      */   {
/* 3299 */     if ((isEmpty(str)) || (isEmpty(remove))) {
/* 3300 */       return str;
/*      */     }
/* 3302 */     if (str.endsWith(remove)) {
/* 3303 */       return str.substring(0, str.length() - remove.length());
/*      */     }
/* 3305 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String removeEndIgnoreCase(String str, String remove)
/*      */   {
/* 3333 */     if ((isEmpty(str)) || (isEmpty(remove))) {
/* 3334 */       return str;
/*      */     }
/* 3336 */     if (endsWithIgnoreCase(str, remove)) {
/* 3337 */       return str.substring(0, str.length() - remove.length());
/*      */     }
/* 3339 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String remove(String str, String remove)
/*      */   {
/* 3366 */     if ((isEmpty(str)) || (isEmpty(remove))) {
/* 3367 */       return str;
/*      */     }
/* 3369 */     return replace(str, remove, "", -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String remove(String str, char remove)
/*      */   {
/* 3392 */     if ((isEmpty(str)) || (str.indexOf(remove) == -1)) {
/* 3393 */       return str;
/*      */     }
/* 3395 */     char[] chars = str.toCharArray();
/* 3396 */     int pos = 0;
/* 3397 */     for (int i = 0; i < chars.length; i++) {
/* 3398 */       if (chars[i] != remove) {
/* 3399 */         chars[(pos++)] = chars[i];
/*      */       }
/*      */     }
/* 3402 */     return new String(chars, 0, pos);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String replaceOnce(String text, String searchString, String replacement)
/*      */   {
/* 3431 */     return replace(text, searchString, replacement, 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String replace(String text, String searchString, String replacement)
/*      */   {
/* 3458 */     return replace(text, searchString, replacement, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String replace(String text, String searchString, String replacement, int max)
/*      */   {
/* 3490 */     if ((isEmpty(text)) || (isEmpty(searchString)) || (replacement == null) || (max == 0)) {
/* 3491 */       return text;
/*      */     }
/* 3493 */     int start = 0;
/* 3494 */     int end = text.indexOf(searchString, start);
/* 3495 */     if (end == -1) {
/* 3496 */       return text;
/*      */     }
/* 3498 */     int replLength = searchString.length();
/* 3499 */     int increase = replacement.length() - replLength;
/* 3500 */     increase = increase < 0 ? 0 : increase;
/* 3501 */     increase *= (max > 64 ? 64 : max < 0 ? 16 : max);
/* 3502 */     StringBuffer buf = new StringBuffer(text.length() + increase);
/* 3503 */     while (end != -1) {
/* 3504 */       buf.append(text.substring(start, end)).append(replacement);
/* 3505 */       start = end + replLength;
/* 3506 */       max--; if (max == 0) {
/*      */         break;
/*      */       }
/* 3509 */       end = text.indexOf(searchString, start);
/*      */     }
/* 3511 */     buf.append(text.substring(start));
/* 3512 */     return buf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String replaceEach(String text, String[] searchList, String[] replacementList)
/*      */   {
/* 3555 */     return replaceEach(text, searchList, replacementList, false, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String replaceEachRepeatedly(String text, String[] searchList, String[] replacementList)
/*      */   {
/* 3606 */     int timeToLive = searchList == null ? 0 : searchList.length;
/* 3607 */     return replaceEach(text, searchList, replacementList, true, timeToLive);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static String replaceEach(String text, String[] searchList, String[] replacementList, boolean repeat, int timeToLive)
/*      */   {
/* 3665 */     if ((text == null) || (text.length() == 0) || (searchList == null) || (searchList.length == 0) || (replacementList == null) || (replacementList.length == 0))
/*      */     {
/*      */ 
/* 3668 */       return text;
/*      */     }
/*      */     
/*      */ 
/* 3672 */     if (timeToLive < 0) {
/* 3673 */       throw new IllegalStateException("TimeToLive of " + timeToLive + " is less than 0: " + text);
/*      */     }
/*      */     
/* 3676 */     int searchLength = searchList.length;
/* 3677 */     int replacementLength = replacementList.length;
/*      */     
/*      */ 
/* 3680 */     if (searchLength != replacementLength) {
/* 3681 */       throw new IllegalArgumentException("Search and Replace array lengths don't match: " + searchLength + " vs " + replacementLength);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3688 */     boolean[] noMoreMatchesForReplIndex = new boolean[searchLength];
/*      */     
/*      */ 
/* 3691 */     int textIndex = -1;
/* 3692 */     int replaceIndex = -1;
/* 3693 */     int tempIndex = -1;
/*      */     
/*      */ 
/*      */ 
/* 3697 */     for (int i = 0; i < searchLength; i++) {
/* 3698 */       if ((noMoreMatchesForReplIndex[i] == 0) && (searchList[i] != null) && (searchList[i].length() != 0) && (replacementList[i] != null))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 3703 */         tempIndex = text.indexOf(searchList[i]);
/*      */         
/*      */ 
/* 3706 */         if (tempIndex == -1) {
/* 3707 */           noMoreMatchesForReplIndex[i] = true;
/*      */         }
/* 3709 */         else if ((textIndex == -1) || (tempIndex < textIndex)) {
/* 3710 */           textIndex = tempIndex;
/* 3711 */           replaceIndex = i;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3718 */     if (textIndex == -1) {
/* 3719 */       return text;
/*      */     }
/*      */     
/* 3722 */     int start = 0;
/*      */     
/*      */ 
/* 3725 */     int increase = 0;
/*      */     
/*      */ 
/* 3728 */     for (int i = 0; i < searchList.length; i++) {
/* 3729 */       int greater = replacementList[i].length() - searchList[i].length();
/* 3730 */       if (greater > 0) {
/* 3731 */         increase += 3 * greater;
/*      */       }
/*      */     }
/*      */     
/* 3735 */     increase = Math.min(increase, text.length() / 5);
/*      */     
/* 3737 */     StringBuffer buf = new StringBuffer(text.length() + increase);
/*      */     
/* 3739 */     while (textIndex != -1)
/*      */     {
/* 3741 */       for (int i = start; i < textIndex; i++) {
/* 3742 */         buf.append(text.charAt(i));
/*      */       }
/* 3744 */       buf.append(replacementList[replaceIndex]);
/*      */       
/* 3746 */       start = textIndex + searchList[replaceIndex].length();
/*      */       
/* 3748 */       textIndex = -1;
/* 3749 */       replaceIndex = -1;
/* 3750 */       tempIndex = -1;
/*      */       
/*      */ 
/* 3753 */       for (int i = 0; i < searchLength; i++) {
/* 3754 */         if ((noMoreMatchesForReplIndex[i] == 0) && (searchList[i] != null) && (searchList[i].length() != 0) && (replacementList[i] != null))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 3759 */           tempIndex = text.indexOf(searchList[i], start);
/*      */           
/*      */ 
/* 3762 */           if (tempIndex == -1) {
/* 3763 */             noMoreMatchesForReplIndex[i] = true;
/*      */           }
/* 3765 */           else if ((textIndex == -1) || (tempIndex < textIndex)) {
/* 3766 */             textIndex = tempIndex;
/* 3767 */             replaceIndex = i;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 3774 */     int textLength = text.length();
/* 3775 */     for (int i = start; i < textLength; i++) {
/* 3776 */       buf.append(text.charAt(i));
/*      */     }
/* 3778 */     String result = buf.toString();
/* 3779 */     if (!repeat) {
/* 3780 */       return result;
/*      */     }
/*      */     
/* 3783 */     return replaceEach(result, searchList, replacementList, repeat, timeToLive - 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String replaceChars(String str, char searchChar, char replaceChar)
/*      */   {
/* 3809 */     if (str == null) {
/* 3810 */       return null;
/*      */     }
/* 3812 */     return str.replace(searchChar, replaceChar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String replaceChars(String str, String searchChars, String replaceChars)
/*      */   {
/* 3852 */     if ((isEmpty(str)) || (isEmpty(searchChars))) {
/* 3853 */       return str;
/*      */     }
/* 3855 */     if (replaceChars == null) {
/* 3856 */       replaceChars = "";
/*      */     }
/* 3858 */     boolean modified = false;
/* 3859 */     int replaceCharsLength = replaceChars.length();
/* 3860 */     int strLength = str.length();
/* 3861 */     StringBuffer buf = new StringBuffer(strLength);
/* 3862 */     for (int i = 0; i < strLength; i++) {
/* 3863 */       char ch = str.charAt(i);
/* 3864 */       int index = searchChars.indexOf(ch);
/* 3865 */       if (index >= 0) {
/* 3866 */         modified = true;
/* 3867 */         if (index < replaceCharsLength) {
/* 3868 */           buf.append(replaceChars.charAt(index));
/*      */         }
/*      */       } else {
/* 3871 */         buf.append(ch);
/*      */       }
/*      */     }
/* 3874 */     if (modified) {
/* 3875 */       return buf.toString();
/*      */     }
/* 3877 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public static String overlayString(String text, String overlay, int start, int end)
/*      */   {
/* 3908 */     return start + overlay.length() + text.length() - end + 1 + text.substring(0, start) + overlay + text.substring(end);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String overlay(String str, String overlay, int start, int end)
/*      */   {
/* 3945 */     if (str == null) {
/* 3946 */       return null;
/*      */     }
/* 3948 */     if (overlay == null) {
/* 3949 */       overlay = "";
/*      */     }
/* 3951 */     int len = str.length();
/* 3952 */     if (start < 0) {
/* 3953 */       start = 0;
/*      */     }
/* 3955 */     if (start > len) {
/* 3956 */       start = len;
/*      */     }
/* 3958 */     if (end < 0) {
/* 3959 */       end = 0;
/*      */     }
/* 3961 */     if (end > len) {
/* 3962 */       end = len;
/*      */     }
/* 3964 */     if (start > end) {
/* 3965 */       int temp = start;
/* 3966 */       start = end;
/* 3967 */       end = temp;
/*      */     }
/* 3969 */     return len + start - end + overlay.length() + 1 + str.substring(0, start) + overlay + str.substring(end);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String chomp(String str)
/*      */   {
/* 4004 */     if (isEmpty(str)) {
/* 4005 */       return str;
/*      */     }
/*      */     
/* 4008 */     if (str.length() == 1) {
/* 4009 */       char ch = str.charAt(0);
/* 4010 */       if ((ch == '\r') || (ch == '\n')) {
/* 4011 */         return "";
/*      */       }
/* 4013 */       return str;
/*      */     }
/*      */     
/* 4016 */     int lastIdx = str.length() - 1;
/* 4017 */     char last = str.charAt(lastIdx);
/*      */     
/* 4019 */     if (last == '\n') {
/* 4020 */       if (str.charAt(lastIdx - 1) == '\r') {
/* 4021 */         lastIdx--;
/*      */       }
/* 4023 */     } else if (last != '\r') {
/* 4024 */       lastIdx++;
/*      */     }
/* 4026 */     return str.substring(0, lastIdx);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String chomp(String str, String separator)
/*      */   {
/* 4056 */     if ((isEmpty(str)) || (separator == null)) {
/* 4057 */       return str;
/*      */     }
/* 4059 */     if (str.endsWith(separator)) {
/* 4060 */       return str.substring(0, str.length() - separator.length());
/*      */     }
/* 4062 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public static String chompLast(String str)
/*      */   {
/* 4076 */     return chompLast(str, "\n");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public static String chompLast(String str, String sep)
/*      */   {
/* 4090 */     if (str.length() == 0) {
/* 4091 */       return str;
/*      */     }
/* 4093 */     String sub = str.substring(str.length() - sep.length());
/* 4094 */     if (sep.equals(sub)) {
/* 4095 */       return str.substring(0, str.length() - sep.length());
/*      */     }
/* 4097 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public static String getChomp(String str, String sep)
/*      */   {
/* 4113 */     int idx = str.lastIndexOf(sep);
/* 4114 */     if (idx == str.length() - sep.length())
/* 4115 */       return sep;
/* 4116 */     if (idx != -1) {
/* 4117 */       return str.substring(idx);
/*      */     }
/* 4119 */     return "";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public static String prechomp(String str, String sep)
/*      */   {
/* 4135 */     int idx = str.indexOf(sep);
/* 4136 */     if (idx == -1) {
/* 4137 */       return str;
/*      */     }
/* 4139 */     return str.substring(idx + sep.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public static String getPrechomp(String str, String sep)
/*      */   {
/* 4155 */     int idx = str.indexOf(sep);
/* 4156 */     if (idx == -1) {
/* 4157 */       return "";
/*      */     }
/* 4159 */     return str.substring(0, idx + sep.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String chop(String str)
/*      */   {
/* 4188 */     if (str == null) {
/* 4189 */       return null;
/*      */     }
/* 4191 */     int strLen = str.length();
/* 4192 */     if (strLen < 2) {
/* 4193 */       return "";
/*      */     }
/* 4195 */     int lastIdx = strLen - 1;
/* 4196 */     String ret = str.substring(0, lastIdx);
/* 4197 */     char last = str.charAt(lastIdx);
/* 4198 */     if ((last == '\n') && 
/* 4199 */       (ret.charAt(lastIdx - 1) == '\r')) {
/* 4200 */       return ret.substring(0, lastIdx - 1);
/*      */     }
/*      */     
/* 4203 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public static String chopNewline(String str)
/*      */   {
/* 4217 */     int lastIdx = str.length() - 1;
/* 4218 */     if (lastIdx <= 0) {
/* 4219 */       return "";
/*      */     }
/* 4221 */     char last = str.charAt(lastIdx);
/* 4222 */     if (last == '\n') {
/* 4223 */       if (str.charAt(lastIdx - 1) == '\r') {
/* 4224 */         lastIdx--;
/*      */       }
/*      */     } else {
/* 4227 */       lastIdx++;
/*      */     }
/* 4229 */     return str.substring(0, lastIdx);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public static String escape(String str)
/*      */   {
/* 4251 */     return StringEscapeUtils.escapeJava(str);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String repeat(String str, int repeat)
/*      */   {
/* 4277 */     if (str == null) {
/* 4278 */       return null;
/*      */     }
/* 4280 */     if (repeat <= 0) {
/* 4281 */       return "";
/*      */     }
/* 4283 */     int inputLength = str.length();
/* 4284 */     if ((repeat == 1) || (inputLength == 0)) {
/* 4285 */       return str;
/*      */     }
/* 4287 */     if ((inputLength == 1) && (repeat <= 8192)) {
/* 4288 */       return padding(repeat, str.charAt(0));
/*      */     }
/*      */     
/* 4291 */     int outputLength = inputLength * repeat;
/* 4292 */     switch (inputLength) {
/*      */     case 1: 
/* 4294 */       char ch = str.charAt(0);
/* 4295 */       char[] output1 = new char[outputLength];
/* 4296 */       for (int i = repeat - 1; i >= 0; i--) {
/* 4297 */         output1[i] = ch;
/*      */       }
/* 4299 */       return new String(output1);
/*      */     case 2: 
/* 4301 */       char ch0 = str.charAt(0);
/* 4302 */       char ch1 = str.charAt(1);
/* 4303 */       char[] output2 = new char[outputLength];
/* 4304 */       for (int i = repeat * 2 - 2; i >= 0; i--) {
/* 4305 */         output2[i] = ch0;
/* 4306 */         output2[(i + 1)] = ch1;i--;
/*      */       }
/*      */       
/* 4308 */       return new String(output2);
/*      */     }
/* 4310 */     StringBuffer buf = new StringBuffer(outputLength);
/* 4311 */     for (int i = 0; i < repeat; i++) {
/* 4312 */       buf.append(str);
/*      */     }
/* 4314 */     return buf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static String padding(int repeat, char padChar)
/*      */     throws IndexOutOfBoundsException
/*      */   {
/* 4342 */     if (repeat < 0) {
/* 4343 */       throw new IndexOutOfBoundsException("Cannot pad a negative amount: " + repeat);
/*      */     }
/* 4345 */     char[] buf = new char[repeat];
/* 4346 */     for (int i = 0; i < buf.length; i++) {
/* 4347 */       buf[i] = padChar;
/*      */     }
/* 4349 */     return new String(buf);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String rightPad(String str, int size)
/*      */   {
/* 4372 */     return rightPad(str, size, ' ');
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String rightPad(String str, int size, char padChar)
/*      */   {
/* 4397 */     if (str == null) {
/* 4398 */       return null;
/*      */     }
/* 4400 */     int pads = size - str.length();
/* 4401 */     if (pads <= 0) {
/* 4402 */       return str;
/*      */     }
/* 4404 */     if (pads > 8192) {
/* 4405 */       return rightPad(str, size, String.valueOf(padChar));
/*      */     }
/* 4407 */     return str.concat(padding(pads, padChar));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String rightPad(String str, int size, String padStr)
/*      */   {
/* 4434 */     if (str == null) {
/* 4435 */       return null;
/*      */     }
/* 4437 */     if (isEmpty(padStr)) {
/* 4438 */       padStr = " ";
/*      */     }
/* 4440 */     int padLen = padStr.length();
/* 4441 */     int strLen = str.length();
/* 4442 */     int pads = size - strLen;
/* 4443 */     if (pads <= 0) {
/* 4444 */       return str;
/*      */     }
/* 4446 */     if ((padLen == 1) && (pads <= 8192)) {
/* 4447 */       return rightPad(str, size, padStr.charAt(0));
/*      */     }
/*      */     
/* 4450 */     if (pads == padLen)
/* 4451 */       return str.concat(padStr);
/* 4452 */     if (pads < padLen) {
/* 4453 */       return str.concat(padStr.substring(0, pads));
/*      */     }
/* 4455 */     char[] padding = new char[pads];
/* 4456 */     char[] padChars = padStr.toCharArray();
/* 4457 */     for (int i = 0; i < pads; i++) {
/* 4458 */       padding[i] = padChars[(i % padLen)];
/*      */     }
/* 4460 */     return str.concat(new String(padding));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String leftPad(String str, int size)
/*      */   {
/* 4484 */     return leftPad(str, size, ' ');
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String leftPad(String str, int size, char padChar)
/*      */   {
/* 4509 */     if (str == null) {
/* 4510 */       return null;
/*      */     }
/* 4512 */     int pads = size - str.length();
/* 4513 */     if (pads <= 0) {
/* 4514 */       return str;
/*      */     }
/* 4516 */     if (pads > 8192) {
/* 4517 */       return leftPad(str, size, String.valueOf(padChar));
/*      */     }
/* 4519 */     return padding(pads, padChar).concat(str);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String leftPad(String str, int size, String padStr)
/*      */   {
/* 4546 */     if (str == null) {
/* 4547 */       return null;
/*      */     }
/* 4549 */     if (isEmpty(padStr)) {
/* 4550 */       padStr = " ";
/*      */     }
/* 4552 */     int padLen = padStr.length();
/* 4553 */     int strLen = str.length();
/* 4554 */     int pads = size - strLen;
/* 4555 */     if (pads <= 0) {
/* 4556 */       return str;
/*      */     }
/* 4558 */     if ((padLen == 1) && (pads <= 8192)) {
/* 4559 */       return leftPad(str, size, padStr.charAt(0));
/*      */     }
/*      */     
/* 4562 */     if (pads == padLen)
/* 4563 */       return padStr.concat(str);
/* 4564 */     if (pads < padLen) {
/* 4565 */       return padStr.substring(0, pads).concat(str);
/*      */     }
/* 4567 */     char[] padding = new char[pads];
/* 4568 */     char[] padChars = padStr.toCharArray();
/* 4569 */     for (int i = 0; i < pads; i++) {
/* 4570 */       padding[i] = padChars[(i % padLen)];
/*      */     }
/* 4572 */     return new String(padding).concat(str);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int length(String str)
/*      */   {
/* 4585 */     return str == null ? 0 : str.length();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String center(String str, int size)
/*      */   {
/* 4614 */     return center(str, size, ' ');
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String center(String str, int size, char padChar)
/*      */   {
/* 4642 */     if ((str == null) || (size <= 0)) {
/* 4643 */       return str;
/*      */     }
/* 4645 */     int strLen = str.length();
/* 4646 */     int pads = size - strLen;
/* 4647 */     if (pads <= 0) {
/* 4648 */       return str;
/*      */     }
/* 4650 */     str = leftPad(str, strLen + pads / 2, padChar);
/* 4651 */     str = rightPad(str, size, padChar);
/* 4652 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String center(String str, int size, String padStr)
/*      */   {
/* 4682 */     if ((str == null) || (size <= 0)) {
/* 4683 */       return str;
/*      */     }
/* 4685 */     if (isEmpty(padStr)) {
/* 4686 */       padStr = " ";
/*      */     }
/* 4688 */     int strLen = str.length();
/* 4689 */     int pads = size - strLen;
/* 4690 */     if (pads <= 0) {
/* 4691 */       return str;
/*      */     }
/* 4693 */     str = leftPad(str, strLen + pads / 2, padStr);
/* 4694 */     str = rightPad(str, size, padStr);
/* 4695 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String upperCase(String str)
/*      */   {
/* 4715 */     if (str == null) {
/* 4716 */       return null;
/*      */     }
/* 4718 */     return str.toUpperCase();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String lowerCase(String str)
/*      */   {
/* 4736 */     if (str == null) {
/* 4737 */       return null;
/*      */     }
/* 4739 */     return str.toLowerCase();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String capitalize(String str)
/*      */   {
/*      */     int strLen;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4764 */     if ((str == null) || ((strLen = str.length()) == 0))
/* 4765 */       return str;
/*      */     int strLen;
/* 4767 */     return strLen + Character.toTitleCase(str.charAt(0)) + str.substring(1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public static String capitalise(String str)
/*      */   {
/* 4783 */     return capitalize(str);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String uncapitalize(String str)
/*      */   {
/*      */     int strLen;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4808 */     if ((str == null) || ((strLen = str.length()) == 0))
/* 4809 */       return str;
/*      */     int strLen;
/* 4811 */     return strLen + Character.toLowerCase(str.charAt(0)) + str.substring(1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public static String uncapitalise(String str)
/*      */   {
/* 4827 */     return uncapitalize(str);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String swapCase(String str)
/*      */   {
/*      */     int strLen;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4859 */     if ((str == null) || ((strLen = str.length()) == 0))
/* 4860 */       return str;
/*      */     int strLen;
/* 4862 */     StringBuffer buffer = new StringBuffer(strLen);
/*      */     
/* 4864 */     char ch = '\000';
/* 4865 */     for (int i = 0; i < strLen; i++) {
/* 4866 */       ch = str.charAt(i);
/* 4867 */       if (Character.isUpperCase(ch)) {
/* 4868 */         ch = Character.toLowerCase(ch);
/* 4869 */       } else if (Character.isTitleCase(ch)) {
/* 4870 */         ch = Character.toLowerCase(ch);
/* 4871 */       } else if (Character.isLowerCase(ch)) {
/* 4872 */         ch = Character.toUpperCase(ch);
/*      */       }
/* 4874 */       buffer.append(ch);
/*      */     }
/* 4876 */     return buffer.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public static String capitaliseAllWords(String str)
/*      */   {
/* 4892 */     return WordUtils.capitalize(str);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int countMatches(String str, String sub)
/*      */   {
/* 4917 */     if ((isEmpty(str)) || (isEmpty(sub))) {
/* 4918 */       return 0;
/*      */     }
/* 4920 */     int count = 0;
/* 4921 */     int idx = 0;
/* 4922 */     while ((idx = str.indexOf(sub, idx)) != -1) {
/* 4923 */       count++;
/* 4924 */       idx += sub.length();
/*      */     }
/* 4926 */     return count;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isAlpha(String str)
/*      */   {
/* 4950 */     if (str == null) {
/* 4951 */       return false;
/*      */     }
/* 4953 */     int sz = str.length();
/* 4954 */     for (int i = 0; i < sz; i++) {
/* 4955 */       if (!Character.isLetter(str.charAt(i))) {
/* 4956 */         return false;
/*      */       }
/*      */     }
/* 4959 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isAlphaSpace(String str)
/*      */   {
/* 4984 */     if (str == null) {
/* 4985 */       return false;
/*      */     }
/* 4987 */     int sz = str.length();
/* 4988 */     for (int i = 0; i < sz; i++) {
/* 4989 */       if ((!Character.isLetter(str.charAt(i))) && (str.charAt(i) != ' ')) {
/* 4990 */         return false;
/*      */       }
/*      */     }
/* 4993 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isAlphanumeric(String str)
/*      */   {
/* 5017 */     if (str == null) {
/* 5018 */       return false;
/*      */     }
/* 5020 */     int sz = str.length();
/* 5021 */     for (int i = 0; i < sz; i++) {
/* 5022 */       if (!Character.isLetterOrDigit(str.charAt(i))) {
/* 5023 */         return false;
/*      */       }
/*      */     }
/* 5026 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isAlphanumericSpace(String str)
/*      */   {
/* 5051 */     if (str == null) {
/* 5052 */       return false;
/*      */     }
/* 5054 */     int sz = str.length();
/* 5055 */     for (int i = 0; i < sz; i++) {
/* 5056 */       if ((!Character.isLetterOrDigit(str.charAt(i))) && (str.charAt(i) != ' ')) {
/* 5057 */         return false;
/*      */       }
/*      */     }
/* 5060 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isAsciiPrintable(String str)
/*      */   {
/* 5089 */     if (str == null) {
/* 5090 */       return false;
/*      */     }
/* 5092 */     int sz = str.length();
/* 5093 */     for (int i = 0; i < sz; i++) {
/* 5094 */       if (!CharUtils.isAsciiPrintable(str.charAt(i))) {
/* 5095 */         return false;
/*      */       }
/*      */     }
/* 5098 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isNumeric(String str)
/*      */   {
/* 5123 */     if (str == null) {
/* 5124 */       return false;
/*      */     }
/* 5126 */     int sz = str.length();
/* 5127 */     for (int i = 0; i < sz; i++) {
/* 5128 */       if (!Character.isDigit(str.charAt(i))) {
/* 5129 */         return false;
/*      */       }
/*      */     }
/* 5132 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isNumericSpace(String str)
/*      */   {
/* 5159 */     if (str == null) {
/* 5160 */       return false;
/*      */     }
/* 5162 */     int sz = str.length();
/* 5163 */     for (int i = 0; i < sz; i++) {
/* 5164 */       if ((!Character.isDigit(str.charAt(i))) && (str.charAt(i) != ' ')) {
/* 5165 */         return false;
/*      */       }
/*      */     }
/* 5168 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isWhitespace(String str)
/*      */   {
/* 5191 */     if (str == null) {
/* 5192 */       return false;
/*      */     }
/* 5194 */     int sz = str.length();
/* 5195 */     for (int i = 0; i < sz; i++) {
/* 5196 */       if (!Character.isWhitespace(str.charAt(i))) {
/* 5197 */         return false;
/*      */       }
/*      */     }
/* 5200 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String defaultString(String str)
/*      */   {
/* 5222 */     return str == null ? "" : str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String defaultString(String str, String defaultStr)
/*      */   {
/* 5243 */     return str == null ? defaultStr : str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String defaultIfEmpty(String str, String defaultStr)
/*      */   {
/* 5263 */     return isEmpty(str) ? defaultStr : str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String reverse(String str)
/*      */   {
/* 5283 */     if (str == null) {
/* 5284 */       return null;
/*      */     }
/* 5286 */     return new StringBuffer(str).reverse().toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String reverseDelimited(String str, char separatorChar)
/*      */   {
/* 5309 */     if (str == null) {
/* 5310 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 5314 */     String[] strs = split(str, separatorChar);
/* 5315 */     ArrayUtils.reverse(strs);
/* 5316 */     return join(strs, separatorChar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public static String reverseDelimitedString(String str, String separatorChars)
/*      */   {
/* 5342 */     if (str == null) {
/* 5343 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 5347 */     String[] strs = split(str, separatorChars);
/* 5348 */     ArrayUtils.reverse(strs);
/* 5349 */     if (separatorChars == null) {
/* 5350 */       return join(strs, ' ');
/*      */     }
/* 5352 */     return join(strs, separatorChars);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String abbreviate(String str, int maxWidth)
/*      */   {
/* 5390 */     return abbreviate(str, 0, maxWidth);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String abbreviate(String str, int offset, int maxWidth)
/*      */   {
/* 5429 */     if (str == null) {
/* 5430 */       return null;
/*      */     }
/* 5432 */     if (maxWidth < 4) {
/* 5433 */       throw new IllegalArgumentException("Minimum abbreviation width is 4");
/*      */     }
/* 5435 */     if (str.length() <= maxWidth) {
/* 5436 */       return str;
/*      */     }
/* 5438 */     if (offset > str.length()) {
/* 5439 */       offset = str.length();
/*      */     }
/* 5441 */     if (str.length() - offset < maxWidth - 3) {
/* 5442 */       offset = str.length() - (maxWidth - 3);
/*      */     }
/* 5444 */     if (offset <= 4) {
/* 5445 */       return str.substring(0, maxWidth - 3) + "...";
/*      */     }
/* 5447 */     if (maxWidth < 7) {
/* 5448 */       throw new IllegalArgumentException("Minimum abbreviation width with offset is 7");
/*      */     }
/* 5450 */     if (offset + (maxWidth - 3) < str.length()) {
/* 5451 */       return "..." + abbreviate(str.substring(offset), maxWidth - 3);
/*      */     }
/* 5453 */     return "..." + str.substring(str.length() - (maxWidth - 3));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String difference(String str1, String str2)
/*      */   {
/* 5484 */     if (str1 == null) {
/* 5485 */       return str2;
/*      */     }
/* 5487 */     if (str2 == null) {
/* 5488 */       return str1;
/*      */     }
/* 5490 */     int at = indexOfDifference(str1, str2);
/* 5491 */     if (at == -1) {
/* 5492 */       return "";
/*      */     }
/* 5494 */     return str2.substring(at);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOfDifference(String str1, String str2)
/*      */   {
/* 5521 */     if (str1 == str2) {
/* 5522 */       return -1;
/*      */     }
/* 5524 */     if ((str1 == null) || (str2 == null)) {
/* 5525 */       return 0;
/*      */     }
/*      */     
/* 5528 */     for (int i = 0; (i < str1.length()) && (i < str2.length()); i++) {
/* 5529 */       if (str1.charAt(i) != str2.charAt(i)) {
/*      */         break;
/*      */       }
/*      */     }
/* 5533 */     if ((i < str2.length()) || (i < str1.length())) {
/* 5534 */       return i;
/*      */     }
/* 5536 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOfDifference(String[] strs)
/*      */   {
/* 5571 */     if ((strs == null) || (strs.length <= 1)) {
/* 5572 */       return -1;
/*      */     }
/* 5574 */     boolean anyStringNull = false;
/* 5575 */     boolean allStringsNull = true;
/* 5576 */     int arrayLen = strs.length;
/* 5577 */     int shortestStrLen = Integer.MAX_VALUE;
/* 5578 */     int longestStrLen = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5583 */     for (int i = 0; i < arrayLen; i++) {
/* 5584 */       if (strs[i] == null) {
/* 5585 */         anyStringNull = true;
/* 5586 */         shortestStrLen = 0;
/*      */       } else {
/* 5588 */         allStringsNull = false;
/* 5589 */         shortestStrLen = Math.min(strs[i].length(), shortestStrLen);
/* 5590 */         longestStrLen = Math.max(strs[i].length(), longestStrLen);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 5595 */     if ((allStringsNull) || ((longestStrLen == 0) && (!anyStringNull))) {
/* 5596 */       return -1;
/*      */     }
/*      */     
/*      */ 
/* 5600 */     if (shortestStrLen == 0) {
/* 5601 */       return 0;
/*      */     }
/*      */     
/*      */ 
/* 5605 */     int firstDiff = -1;
/* 5606 */     for (int stringPos = 0; stringPos < shortestStrLen; stringPos++) {
/* 5607 */       char comparisonChar = strs[0].charAt(stringPos);
/* 5608 */       for (int arrayPos = 1; arrayPos < arrayLen; arrayPos++) {
/* 5609 */         if (strs[arrayPos].charAt(stringPos) != comparisonChar) {
/* 5610 */           firstDiff = stringPos;
/* 5611 */           break;
/*      */         }
/*      */       }
/* 5614 */       if (firstDiff != -1) {
/*      */         break;
/*      */       }
/*      */     }
/*      */     
/* 5619 */     if ((firstDiff == -1) && (shortestStrLen != longestStrLen))
/*      */     {
/*      */ 
/*      */ 
/* 5623 */       return shortestStrLen;
/*      */     }
/* 5625 */     return firstDiff;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getCommonPrefix(String[] strs)
/*      */   {
/* 5662 */     if ((strs == null) || (strs.length == 0)) {
/* 5663 */       return "";
/*      */     }
/* 5665 */     int smallestIndexOfDiff = indexOfDifference(strs);
/* 5666 */     if (smallestIndexOfDiff == -1)
/*      */     {
/* 5668 */       if (strs[0] == null) {
/* 5669 */         return "";
/*      */       }
/* 5671 */       return strs[0]; }
/* 5672 */     if (smallestIndexOfDiff == 0)
/*      */     {
/* 5674 */       return "";
/*      */     }
/*      */     
/* 5677 */     return strs[0].substring(0, smallestIndexOfDiff);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int getLevenshteinDistance(String s, String t)
/*      */   {
/* 5718 */     if ((s == null) || (t == null)) {
/* 5719 */       throw new IllegalArgumentException("Strings must not be null");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5739 */     int n = s.length();
/* 5740 */     int m = t.length();
/*      */     
/* 5742 */     if (n == 0)
/* 5743 */       return m;
/* 5744 */     if (m == 0) {
/* 5745 */       return n;
/*      */     }
/*      */     
/* 5748 */     if (n > m)
/*      */     {
/* 5750 */       String tmp = s;
/* 5751 */       s = t;
/* 5752 */       t = tmp;
/* 5753 */       n = m;
/* 5754 */       m = t.length();
/*      */     }
/*      */     
/* 5757 */     int[] p = new int[n + 1];
/* 5758 */     int[] d = new int[n + 1];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5769 */     for (int i = 0; i <= n; i++) {
/* 5770 */       p[i] = i;
/*      */     }
/*      */     
/* 5773 */     for (int j = 1; j <= m; j++) {
/* 5774 */       char t_j = t.charAt(j - 1);
/* 5775 */       d[0] = j;
/*      */       
/* 5777 */       for (i = 1; i <= n; i++) {
/* 5778 */         int cost = s.charAt(i - 1) == t_j ? 0 : 1;
/*      */         
/* 5780 */         d[i] = Math.min(Math.min(d[(i - 1)] + 1, p[i] + 1), p[(i - 1)] + cost);
/*      */       }
/*      */       
/*      */ 
/* 5784 */       int[] _d = p;
/* 5785 */       p = d;
/* 5786 */       d = _d;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 5791 */     return p[n];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWith(String str, String prefix)
/*      */   {
/* 5840 */     return startsWith(str, prefix, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWithIgnoreCase(String str, String prefix)
/*      */   {
/* 5865 */     return startsWith(str, prefix, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static boolean startsWith(String str, String prefix, boolean ignoreCase)
/*      */   {
/* 5880 */     if ((str == null) || (prefix == null)) {
/* 5881 */       return (str == null) && (prefix == null);
/*      */     }
/* 5883 */     if (prefix.length() > str.length()) {
/* 5884 */       return false;
/*      */     }
/* 5886 */     return str.regionMatches(ignoreCase, 0, prefix, 0, prefix.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean endsWith(String str, String suffix)
/*      */   {
/* 5914 */     return endsWith(str, suffix, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean endsWithIgnoreCase(String str, String suffix)
/*      */   {
/* 5939 */     return endsWith(str, suffix, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static boolean endsWith(String str, String suffix, boolean ignoreCase)
/*      */   {
/* 5954 */     if ((str == null) || (suffix == null)) {
/* 5955 */       return (str == null) && (suffix == null);
/*      */     }
/* 5957 */     if (suffix.length() > str.length()) {
/* 5958 */       return false;
/*      */     }
/* 5960 */     int strOffset = str.length() - suffix.length();
/* 5961 */     return str.regionMatches(ignoreCase, strOffset, suffix, 0, suffix.length());
/*      */   }
/*      */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-lang-2.4.jar!\org\apache\commons\lang\StringUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */