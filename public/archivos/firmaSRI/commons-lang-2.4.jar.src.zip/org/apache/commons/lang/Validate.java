/*     */ package org.apache.commons.lang;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Validate
/*     */ {
/*     */   public static void isTrue(boolean expression, String message, Object value)
/*     */   {
/*  76 */     if (!expression) {
/*  77 */       throw new IllegalArgumentException(message + value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void isTrue(boolean expression, String message, long value)
/*     */   {
/* 102 */     if (!expression) {
/* 103 */       throw new IllegalArgumentException(message + value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void isTrue(boolean expression, String message, double value)
/*     */   {
/* 129 */     if (!expression) {
/* 130 */       throw new IllegalArgumentException(message + value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void isTrue(boolean expression, String message)
/*     */   {
/* 156 */     if (!expression) {
/* 157 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void isTrue(boolean expression)
/*     */   {
/* 180 */     if (!expression) {
/* 181 */       throw new IllegalArgumentException("The validated expression is false");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void notNull(Object object, String message)
/*     */   {
/* 202 */     if (object == null) {
/* 203 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void notNull(Object object)
/*     */   {
/* 221 */     if (object == null) {
/* 222 */       throw new IllegalArgumentException("The validated object is null");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void notEmpty(Object[] array, String message)
/*     */   {
/* 242 */     if ((array == null) || (array.length == 0)) {
/* 243 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void notEmpty(Object[] array)
/*     */   {
/* 261 */     if ((array == null) || (array.length == 0)) {
/* 262 */       throw new IllegalArgumentException("The validated array is empty");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void notEmpty(Collection collection, String message)
/*     */   {
/* 282 */     if ((collection == null) || (collection.size() == 0)) {
/* 283 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void notEmpty(Collection collection)
/*     */   {
/* 301 */     if ((collection == null) || (collection.size() == 0)) {
/* 302 */       throw new IllegalArgumentException("The validated collection is empty");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void notEmpty(Map map, String message)
/*     */   {
/* 322 */     if ((map == null) || (map.size() == 0)) {
/* 323 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void notEmpty(Map map)
/*     */   {
/* 341 */     if ((map == null) || (map.size() == 0)) {
/* 342 */       throw new IllegalArgumentException("The validated map is empty");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void notEmpty(String string, String message)
/*     */   {
/* 362 */     if ((string == null) || (string.length() == 0)) {
/* 363 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void notEmpty(String string)
/*     */   {
/* 381 */     if ((string == null) || (string.length() == 0)) {
/* 382 */       throw new IllegalArgumentException("The validated string is empty");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void noNullElements(Object[] array, String message)
/*     */   {
/* 407 */     notNull(array);
/* 408 */     for (int i = 0; i < array.length; i++) {
/* 409 */       if (array[i] == null) {
/* 410 */         throw new IllegalArgumentException(message);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void noNullElements(Object[] array)
/*     */   {
/* 434 */     notNull(array);
/* 435 */     for (int i = 0; i < array.length; i++) {
/* 436 */       if (array[i] == null) {
/* 437 */         throw new IllegalArgumentException("The validated array contains null element at index: " + i);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void noNullElements(Collection collection, String message)
/*     */   {
/* 463 */     notNull(collection);
/* 464 */     for (Iterator it = collection.iterator(); it.hasNext();) {
/* 465 */       if (it.next() == null) {
/* 466 */         throw new IllegalArgumentException(message);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void noNullElements(Collection collection)
/*     */   {
/* 489 */     notNull(collection);
/* 490 */     int i = 0;
/* 491 */     for (Iterator it = collection.iterator(); it.hasNext(); i++) {
/* 492 */       if (it.next() == null) {
/* 493 */         throw new IllegalArgumentException("The validated collection contains null element at index: " + i);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void allElementsOfType(Collection collection, Class clazz, String message)
/*     */   {
/* 513 */     notNull(collection);
/* 514 */     notNull(clazz);
/* 515 */     for (Iterator it = collection.iterator(); it.hasNext();) {
/* 516 */       if (!clazz.isInstance(it.next())) {
/* 517 */         throw new IllegalArgumentException(message);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void allElementsOfType(Collection collection, Class clazz)
/*     */   {
/* 543 */     notNull(collection);
/* 544 */     notNull(clazz);
/* 545 */     int i = 0;
/* 546 */     for (Iterator it = collection.iterator(); it.hasNext(); i++) {
/* 547 */       if (!clazz.isInstance(it.next())) {
/* 548 */         throw new IllegalArgumentException("The validated collection contains an element not of type " + clazz.getName() + " at index: " + i);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-lang-2.4.jar!\org\apache\commons\lang\Validate.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */