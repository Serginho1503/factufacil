/*     */ package org.apache.commons.lang.time;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StopWatch
/*     */ {
/*     */   private static final int STATE_UNSTARTED = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int STATE_RUNNING = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int STATE_STOPPED = 2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int STATE_SUSPENDED = 3;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int STATE_UNSPLIT = 10;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int STATE_SPLIT = 11;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  76 */   private int runningState = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  81 */   private int splitState = 10;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  86 */   private long startTime = -1L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  91 */   private long stopTime = -1L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void start()
/*     */   {
/* 115 */     if (this.runningState == 2) {
/* 116 */       throw new IllegalStateException("Stopwatch must be reset before being restarted. ");
/*     */     }
/* 118 */     if (this.runningState != 0) {
/* 119 */       throw new IllegalStateException("Stopwatch already started. ");
/*     */     }
/* 121 */     this.stopTime = -1L;
/* 122 */     this.startTime = System.currentTimeMillis();
/* 123 */     this.runningState = 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stop()
/*     */   {
/* 139 */     if ((this.runningState != 1) && (this.runningState != 3)) {
/* 140 */       throw new IllegalStateException("Stopwatch is not running. ");
/*     */     }
/* 142 */     if (this.runningState == 1) {
/* 143 */       this.stopTime = System.currentTimeMillis();
/*     */     }
/* 145 */     this.runningState = 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/* 158 */     this.runningState = 0;
/* 159 */     this.splitState = 10;
/* 160 */     this.startTime = -1L;
/* 161 */     this.stopTime = -1L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void split()
/*     */   {
/* 178 */     if (this.runningState != 1) {
/* 179 */       throw new IllegalStateException("Stopwatch is not running. ");
/*     */     }
/* 181 */     this.stopTime = System.currentTimeMillis();
/* 182 */     this.splitState = 11;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void unsplit()
/*     */   {
/* 199 */     if (this.splitState != 11) {
/* 200 */       throw new IllegalStateException("Stopwatch has not been split. ");
/*     */     }
/* 202 */     this.stopTime = -1L;
/* 203 */     this.splitState = 10;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void suspend()
/*     */   {
/* 220 */     if (this.runningState != 1) {
/* 221 */       throw new IllegalStateException("Stopwatch must be running to suspend. ");
/*     */     }
/* 223 */     this.stopTime = System.currentTimeMillis();
/* 224 */     this.runningState = 3;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void resume()
/*     */   {
/* 241 */     if (this.runningState != 3) {
/* 242 */       throw new IllegalStateException("Stopwatch must be suspended to resume. ");
/*     */     }
/* 244 */     this.startTime += System.currentTimeMillis() - this.stopTime;
/* 245 */     this.stopTime = -1L;
/* 246 */     this.runningState = 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getTime()
/*     */   {
/* 262 */     if ((this.runningState == 2) || (this.runningState == 3))
/* 263 */       return this.stopTime - this.startTime;
/* 264 */     if (this.runningState == 0)
/* 265 */       return 0L;
/* 266 */     if (this.runningState == 1) {
/* 267 */       return System.currentTimeMillis() - this.startTime;
/*     */     }
/* 269 */     throw new RuntimeException("Illegal running state has occured. ");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getSplitTime()
/*     */   {
/* 288 */     if (this.splitState != 11) {
/* 289 */       throw new IllegalStateException("Stopwatch must be split to get the split time. ");
/*     */     }
/* 291 */     return this.stopTime - this.startTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getStartTime()
/*     */   {
/* 303 */     if (this.runningState == 0) {
/* 304 */       throw new IllegalStateException("Stopwatch has not been started");
/*     */     }
/* 306 */     return this.startTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 321 */     return DurationFormatUtils.formatDurationHMS(getTime());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toSplitString()
/*     */   {
/* 337 */     return DurationFormatUtils.formatDurationHMS(getSplitTime());
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-lang-2.4.jar!\org\apache\commons\lang\time\StopWatch.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */