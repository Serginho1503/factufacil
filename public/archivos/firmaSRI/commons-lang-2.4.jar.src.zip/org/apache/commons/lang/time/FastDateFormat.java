/*      */ package org.apache.commons.lang.time;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.text.DateFormat;
/*      */ import java.text.DateFormatSymbols;
/*      */ import java.text.FieldPosition;
/*      */ import java.text.Format;
/*      */ import java.text.ParsePosition;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.TimeZone;
/*      */ import org.apache.commons.lang.Validate;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FastDateFormat
/*      */   extends Format
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   public static final int FULL = 0;
/*      */   public static final int LONG = 1;
/*      */   public static final int MEDIUM = 2;
/*      */   public static final int SHORT = 3;
/*      */   private static String cDefaultPattern;
/*  110 */   private static final Map cInstanceCache = new HashMap(7);
/*  111 */   private static final Map cDateInstanceCache = new HashMap(7);
/*  112 */   private static final Map cTimeInstanceCache = new HashMap(7);
/*  113 */   private static final Map cDateTimeInstanceCache = new HashMap(7);
/*  114 */   private static final Map cTimeZoneDisplayCache = new HashMap(7);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final String mPattern;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final TimeZone mTimeZone;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final boolean mTimeZoneForced;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final Locale mLocale;
/*      */   
/*      */ 
/*      */ 
/*      */   private final boolean mLocaleForced;
/*      */   
/*      */ 
/*      */ 
/*      */   private transient Rule[] mRules;
/*      */   
/*      */ 
/*      */ 
/*      */   private transient int mMaxLengthEstimate;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static FastDateFormat getInstance()
/*      */   {
/*  153 */     return getInstance(getDefaultPattern(), null, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static FastDateFormat getInstance(String pattern)
/*      */   {
/*  166 */     return getInstance(pattern, null, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static FastDateFormat getInstance(String pattern, TimeZone timeZone)
/*      */   {
/*  181 */     return getInstance(pattern, timeZone, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static FastDateFormat getInstance(String pattern, Locale locale)
/*      */   {
/*  195 */     return getInstance(pattern, null, locale);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static synchronized FastDateFormat getInstance(String pattern, TimeZone timeZone, Locale locale)
/*      */   {
/*  212 */     FastDateFormat emptyFormat = new FastDateFormat(pattern, timeZone, locale);
/*  213 */     FastDateFormat format = (FastDateFormat)cInstanceCache.get(emptyFormat);
/*  214 */     if (format == null) {
/*  215 */       format = emptyFormat;
/*  216 */       format.init();
/*  217 */       cInstanceCache.put(format, format);
/*      */     }
/*  219 */     return format;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static FastDateFormat getDateInstance(int style)
/*      */   {
/*  234 */     return getDateInstance(style, null, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static FastDateFormat getDateInstance(int style, Locale locale)
/*      */   {
/*  249 */     return getDateInstance(style, null, locale);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static FastDateFormat getDateInstance(int style, TimeZone timeZone)
/*      */   {
/*  265 */     return getDateInstance(style, timeZone, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static synchronized FastDateFormat getDateInstance(int style, TimeZone timeZone, Locale locale)
/*      */   {
/*  280 */     Object key = new Integer(style);
/*  281 */     if (timeZone != null) {
/*  282 */       key = new Pair(key, timeZone);
/*      */     }
/*      */     
/*  285 */     if (locale == null) {
/*  286 */       locale = Locale.getDefault();
/*      */     }
/*      */     
/*  289 */     key = new Pair(key, locale);
/*      */     
/*  291 */     FastDateFormat format = (FastDateFormat)cDateInstanceCache.get(key);
/*  292 */     if (format == null) {
/*      */       try {
/*  294 */         SimpleDateFormat formatter = (SimpleDateFormat)DateFormat.getDateInstance(style, locale);
/*  295 */         String pattern = formatter.toPattern();
/*  296 */         format = getInstance(pattern, timeZone, locale);
/*  297 */         cDateInstanceCache.put(key, format);
/*      */       }
/*      */       catch (ClassCastException ex) {
/*  300 */         throw new IllegalArgumentException("No date pattern for locale: " + locale);
/*      */       }
/*      */     }
/*  303 */     return format;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static FastDateFormat getTimeInstance(int style)
/*      */   {
/*  318 */     return getTimeInstance(style, null, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static FastDateFormat getTimeInstance(int style, Locale locale)
/*      */   {
/*  333 */     return getTimeInstance(style, null, locale);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static FastDateFormat getTimeInstance(int style, TimeZone timeZone)
/*      */   {
/*  349 */     return getTimeInstance(style, timeZone, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static synchronized FastDateFormat getTimeInstance(int style, TimeZone timeZone, Locale locale)
/*      */   {
/*  365 */     Object key = new Integer(style);
/*  366 */     if (timeZone != null) {
/*  367 */       key = new Pair(key, timeZone);
/*      */     }
/*  369 */     if (locale != null) {
/*  370 */       key = new Pair(key, locale);
/*      */     }
/*      */     
/*  373 */     FastDateFormat format = (FastDateFormat)cTimeInstanceCache.get(key);
/*  374 */     if (format == null) {
/*  375 */       if (locale == null) {
/*  376 */         locale = Locale.getDefault();
/*      */       }
/*      */       try
/*      */       {
/*  380 */         SimpleDateFormat formatter = (SimpleDateFormat)DateFormat.getTimeInstance(style, locale);
/*  381 */         String pattern = formatter.toPattern();
/*  382 */         format = getInstance(pattern, timeZone, locale);
/*  383 */         cTimeInstanceCache.put(key, format);
/*      */       }
/*      */       catch (ClassCastException ex) {
/*  386 */         throw new IllegalArgumentException("No date pattern for locale: " + locale);
/*      */       }
/*      */     }
/*  389 */     return format;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static FastDateFormat getDateTimeInstance(int dateStyle, int timeStyle)
/*      */   {
/*  406 */     return getDateTimeInstance(dateStyle, timeStyle, null, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static FastDateFormat getDateTimeInstance(int dateStyle, int timeStyle, Locale locale)
/*      */   {
/*  423 */     return getDateTimeInstance(dateStyle, timeStyle, null, locale);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static FastDateFormat getDateTimeInstance(int dateStyle, int timeStyle, TimeZone timeZone)
/*      */   {
/*  441 */     return getDateTimeInstance(dateStyle, timeStyle, timeZone, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static synchronized FastDateFormat getDateTimeInstance(int dateStyle, int timeStyle, TimeZone timeZone, Locale locale)
/*      */   {
/*  459 */     Object key = new Pair(new Integer(dateStyle), new Integer(timeStyle));
/*  460 */     if (timeZone != null) {
/*  461 */       key = new Pair(key, timeZone);
/*      */     }
/*  463 */     if (locale == null) {
/*  464 */       locale = Locale.getDefault();
/*      */     }
/*  466 */     key = new Pair(key, locale);
/*      */     
/*  468 */     FastDateFormat format = (FastDateFormat)cDateTimeInstanceCache.get(key);
/*  469 */     if (format == null) {
/*      */       try {
/*  471 */         SimpleDateFormat formatter = (SimpleDateFormat)DateFormat.getDateTimeInstance(dateStyle, timeStyle, locale);
/*      */         
/*  473 */         String pattern = formatter.toPattern();
/*  474 */         format = getInstance(pattern, timeZone, locale);
/*  475 */         cDateTimeInstanceCache.put(key, format);
/*      */       }
/*      */       catch (ClassCastException ex) {
/*  478 */         throw new IllegalArgumentException("No date time pattern for locale: " + locale);
/*      */       }
/*      */     }
/*  481 */     return format;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static synchronized String getTimeZoneDisplay(TimeZone tz, boolean daylight, int style, Locale locale)
/*      */   {
/*  496 */     Object key = new TimeZoneDisplayKey(tz, daylight, style, locale);
/*  497 */     String value = (String)cTimeZoneDisplayCache.get(key);
/*  498 */     if (value == null)
/*      */     {
/*  500 */       value = tz.getDisplayName(daylight, style, locale);
/*  501 */       cTimeZoneDisplayCache.put(key, value);
/*      */     }
/*  503 */     return value;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static synchronized String getDefaultPattern()
/*      */   {
/*  512 */     if (cDefaultPattern == null) {
/*  513 */       cDefaultPattern = new SimpleDateFormat().toPattern();
/*      */     }
/*  515 */     return cDefaultPattern;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected FastDateFormat(String pattern, TimeZone timeZone, Locale locale)
/*      */   {
/*  535 */     if (pattern == null) {
/*  536 */       throw new IllegalArgumentException("The pattern must not be null");
/*      */     }
/*  538 */     this.mPattern = pattern;
/*      */     
/*  540 */     this.mTimeZoneForced = (timeZone != null);
/*  541 */     if (timeZone == null) {
/*  542 */       timeZone = TimeZone.getDefault();
/*      */     }
/*  544 */     this.mTimeZone = timeZone;
/*      */     
/*  546 */     this.mLocaleForced = (locale != null);
/*  547 */     if (locale == null) {
/*  548 */       locale = Locale.getDefault();
/*      */     }
/*  550 */     this.mLocale = locale;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void init()
/*      */   {
/*  557 */     List rulesList = parsePattern();
/*  558 */     this.mRules = ((Rule[])rulesList.toArray(new Rule[rulesList.size()]));
/*      */     
/*  560 */     int len = 0;
/*  561 */     int i = this.mRules.length; for (;;) { i--; if (i < 0) break;
/*  562 */       len += this.mRules[i].estimateLength();
/*      */     }
/*      */     
/*  565 */     this.mMaxLengthEstimate = len;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected List parsePattern()
/*      */   {
/*  577 */     DateFormatSymbols symbols = new DateFormatSymbols(this.mLocale);
/*  578 */     List rules = new ArrayList();
/*      */     
/*  580 */     String[] ERAs = symbols.getEras();
/*  581 */     String[] months = symbols.getMonths();
/*  582 */     String[] shortMonths = symbols.getShortMonths();
/*  583 */     String[] weekdays = symbols.getWeekdays();
/*  584 */     String[] shortWeekdays = symbols.getShortWeekdays();
/*  585 */     String[] AmPmStrings = symbols.getAmPmStrings();
/*      */     
/*  587 */     int length = this.mPattern.length();
/*  588 */     int[] indexRef = new int[1];
/*      */     
/*  590 */     for (int i = 0; i < length; i++) {
/*  591 */       indexRef[0] = i;
/*  592 */       String token = parseToken(this.mPattern, indexRef);
/*  593 */       i = indexRef[0];
/*      */       
/*  595 */       int tokenLen = token.length();
/*  596 */       if (tokenLen == 0) {
/*      */         break;
/*      */       }
/*      */       
/*      */ 
/*  601 */       char c = token.charAt(0);
/*      */       Rule rule;
/*  603 */       Rule rule; Rule rule; Rule rule; Rule rule; Rule rule; Rule rule; Rule rule; Rule rule; Rule rule; Rule rule; Rule rule; Rule rule; Rule rule; Rule rule; Rule rule; Rule rule; Rule rule; Rule rule; Rule rule; switch (c) {
/*      */       case 'G': 
/*  605 */         rule = new TextField(0, ERAs);
/*  606 */         break;
/*      */       case 'y':  Rule rule;
/*  608 */         if (tokenLen >= 4) {
/*  609 */           rule = selectNumberRule(1, tokenLen);
/*      */         } else {
/*  611 */           rule = TwoDigitYearField.INSTANCE;
/*      */         }
/*  613 */         break;
/*      */       case 'M':  Rule rule;
/*  615 */         if (tokenLen >= 4) {
/*  616 */           rule = new TextField(2, months); } else { Rule rule;
/*  617 */           if (tokenLen == 3) {
/*  618 */             rule = new TextField(2, shortMonths); } else { Rule rule;
/*  619 */             if (tokenLen == 2) {
/*  620 */               rule = TwoDigitMonthField.INSTANCE;
/*      */             } else
/*  622 */               rule = UnpaddedMonthField.INSTANCE;
/*      */           } }
/*  624 */         break;
/*      */       case 'd': 
/*  626 */         rule = selectNumberRule(5, tokenLen);
/*  627 */         break;
/*      */       case 'h': 
/*  629 */         rule = new TwelveHourField(selectNumberRule(10, tokenLen));
/*  630 */         break;
/*      */       case 'H': 
/*  632 */         rule = selectNumberRule(11, tokenLen);
/*  633 */         break;
/*      */       case 'm': 
/*  635 */         rule = selectNumberRule(12, tokenLen);
/*  636 */         break;
/*      */       case 's': 
/*  638 */         rule = selectNumberRule(13, tokenLen);
/*  639 */         break;
/*      */       case 'S': 
/*  641 */         rule = selectNumberRule(14, tokenLen);
/*  642 */         break;
/*      */       case 'E': 
/*  644 */         rule = new TextField(7, tokenLen < 4 ? shortWeekdays : weekdays);
/*  645 */         break;
/*      */       case 'D': 
/*  647 */         rule = selectNumberRule(6, tokenLen);
/*  648 */         break;
/*      */       case 'F': 
/*  650 */         rule = selectNumberRule(8, tokenLen);
/*  651 */         break;
/*      */       case 'w': 
/*  653 */         rule = selectNumberRule(3, tokenLen);
/*  654 */         break;
/*      */       case 'W': 
/*  656 */         rule = selectNumberRule(4, tokenLen);
/*  657 */         break;
/*      */       case 'a': 
/*  659 */         rule = new TextField(9, AmPmStrings);
/*  660 */         break;
/*      */       case 'k': 
/*  662 */         rule = new TwentyFourHourField(selectNumberRule(11, tokenLen));
/*  663 */         break;
/*      */       case 'K': 
/*  665 */         rule = selectNumberRule(10, tokenLen);
/*  666 */         break;
/*      */       case 'z':  Rule rule;
/*  668 */         if (tokenLen >= 4) {
/*  669 */           rule = new TimeZoneNameRule(this.mTimeZone, this.mTimeZoneForced, this.mLocale, 1);
/*      */         } else {
/*  671 */           rule = new TimeZoneNameRule(this.mTimeZone, this.mTimeZoneForced, this.mLocale, 0);
/*      */         }
/*  673 */         break;
/*      */       case 'Z':  Rule rule;
/*  675 */         if (tokenLen == 1) {
/*  676 */           rule = TimeZoneNumberRule.INSTANCE_NO_COLON;
/*      */         } else {
/*  678 */           rule = TimeZoneNumberRule.INSTANCE_COLON;
/*      */         }
/*  680 */         break;
/*      */       case '\'': 
/*  682 */         String sub = token.substring(1);
/*  683 */         Rule rule; if (sub.length() == 1) {
/*  684 */           rule = new CharacterLiteral(sub.charAt(0));
/*      */         } else {
/*  686 */           rule = new StringLiteral(sub);
/*      */         }
/*  688 */         break;
/*      */       case '(': case ')': case '*': case '+': case ',': case '-': case '.': case '/': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case ':': case ';': case '<': case '=': case '>': case '?': case '@': case 'A': case 'B': case 'C': case 'I': case 'J': case 'L': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'T': case 'U': case 'V': case 'X': case 'Y': case '[': case '\\': case ']': case '^': case '_': case '`': case 'b': case 'c': case 'e': case 'f': case 'g': case 'i': case 'j': case 'l': case 'n': case 'o': case 'p': case 'q': case 'r': case 't': case 'u': case 'v': case 'x': default: 
/*  690 */         throw new IllegalArgumentException("Illegal pattern component: " + token);
/*      */       }
/*      */       
/*  693 */       rules.add(rule);
/*      */     }
/*      */     
/*  696 */     return rules;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String parseToken(String pattern, int[] indexRef)
/*      */   {
/*  707 */     StringBuffer buf = new StringBuffer();
/*      */     
/*  709 */     int i = indexRef[0];
/*  710 */     int length = pattern.length();
/*      */     
/*  712 */     char c = pattern.charAt(i);
/*  713 */     if (((c >= 'A') && (c <= 'Z')) || ((c >= 'a') && (c <= 'z')))
/*      */     {
/*      */ 
/*  716 */       buf.append(c);
/*      */     }
/*  718 */     while (i + 1 < length) {
/*  719 */       char peek = pattern.charAt(i + 1);
/*  720 */       if (peek == c) {
/*  721 */         buf.append(c);
/*  722 */         i++;
/*      */         
/*  724 */         continue;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  729 */         buf.append('\'');
/*      */         
/*  731 */         boolean inLiteral = false;
/*  733 */         for (; 
/*  733 */             i < length; i++) {
/*  734 */           c = pattern.charAt(i);
/*      */           
/*  736 */           if (c == '\'') {
/*  737 */             if ((i + 1 < length) && (pattern.charAt(i + 1) == '\''))
/*      */             {
/*  739 */               i++;
/*  740 */               buf.append(c);
/*      */             } else {
/*  742 */               inLiteral = !inLiteral;
/*      */             }
/*  744 */           } else { if ((!inLiteral) && (((c >= 'A') && (c <= 'Z')) || ((c >= 'a') && (c <= 'z'))))
/*      */             {
/*  746 */               i--;
/*  747 */               break;
/*      */             }
/*  749 */             buf.append(c);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  754 */     indexRef[0] = i;
/*  755 */     return buf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected NumberRule selectNumberRule(int field, int padding)
/*      */   {
/*  766 */     switch (padding) {
/*      */     case 1: 
/*  768 */       return new UnpaddedNumberField(field);
/*      */     case 2: 
/*  770 */       return new TwoDigitNumberField(field);
/*      */     }
/*  772 */     return new PaddedNumberField(field, padding);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos)
/*      */   {
/*  788 */     if ((obj instanceof Date))
/*  789 */       return format((Date)obj, toAppendTo);
/*  790 */     if ((obj instanceof Calendar))
/*  791 */       return format((Calendar)obj, toAppendTo);
/*  792 */     if ((obj instanceof Long)) {
/*  793 */       return format(((Long)obj).longValue(), toAppendTo);
/*      */     }
/*  795 */     throw new IllegalArgumentException("Unknown class: " + (obj == null ? "<null>" : obj.getClass().getName()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String format(long millis)
/*      */   {
/*  808 */     return format(new Date(millis));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String format(Date date)
/*      */   {
/*  818 */     Calendar c = new GregorianCalendar(this.mTimeZone);
/*  819 */     c.setTime(date);
/*  820 */     return applyRules(c, new StringBuffer(this.mMaxLengthEstimate)).toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String format(Calendar calendar)
/*      */   {
/*  830 */     return format(calendar, new StringBuffer(this.mMaxLengthEstimate)).toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StringBuffer format(long millis, StringBuffer buf)
/*      */   {
/*  843 */     return format(new Date(millis), buf);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StringBuffer format(Date date, StringBuffer buf)
/*      */   {
/*  855 */     Calendar c = new GregorianCalendar(this.mTimeZone);
/*  856 */     c.setTime(date);
/*  857 */     return applyRules(c, buf);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StringBuffer format(Calendar calendar, StringBuffer buf)
/*      */   {
/*  869 */     if (this.mTimeZoneForced) {
/*  870 */       calendar = (Calendar)calendar.clone();
/*  871 */       calendar.setTimeZone(this.mTimeZone);
/*      */     }
/*  873 */     return applyRules(calendar, buf);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected StringBuffer applyRules(Calendar calendar, StringBuffer buf)
/*      */   {
/*  885 */     Rule[] rules = this.mRules;
/*  886 */     int len = this.mRules.length;
/*  887 */     for (int i = 0; i < len; i++) {
/*  888 */       rules[i].appendTo(buf, calendar);
/*      */     }
/*  890 */     return buf;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object parseObject(String source, ParsePosition pos)
/*      */   {
/*  903 */     pos.setIndex(0);
/*  904 */     pos.setErrorIndex(0);
/*  905 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPattern()
/*      */   {
/*  916 */     return this.mPattern;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TimeZone getTimeZone()
/*      */   {
/*  930 */     return this.mTimeZone;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getTimeZoneOverridesCalendar()
/*      */   {
/*  941 */     return this.mTimeZoneForced;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Locale getLocale()
/*      */   {
/*  950 */     return this.mLocale;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxLengthEstimate()
/*      */   {
/*  963 */     return this.mMaxLengthEstimate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean equals(Object obj)
/*      */   {
/*  975 */     if (!(obj instanceof FastDateFormat)) {
/*  976 */       return false;
/*      */     }
/*  978 */     FastDateFormat other = (FastDateFormat)obj;
/*  979 */     if (((this.mPattern == other.mPattern) || (this.mPattern.equals(other.mPattern))) && ((this.mTimeZone == other.mTimeZone) || (this.mTimeZone.equals(other.mTimeZone))) && ((this.mLocale == other.mLocale) || (this.mLocale.equals(other.mLocale))) && (this.mTimeZoneForced == other.mTimeZoneForced) && (this.mLocaleForced == other.mLocaleForced))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  986 */       return true;
/*      */     }
/*  988 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int hashCode()
/*      */   {
/*  997 */     int total = 0;
/*  998 */     total += this.mPattern.hashCode();
/*  999 */     total += this.mTimeZone.hashCode();
/* 1000 */     total += (this.mTimeZoneForced ? 1 : 0);
/* 1001 */     total += this.mLocale.hashCode();
/* 1002 */     total += (this.mLocaleForced ? 1 : 0);
/* 1003 */     return total;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1012 */     return "FastDateFormat[" + this.mPattern + "]";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readObject(ObjectInputStream in)
/*      */     throws IOException, ClassNotFoundException
/*      */   {
/* 1026 */     in.defaultReadObject();
/* 1027 */     init();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static abstract interface Rule
/*      */   {
/*      */     public abstract int estimateLength();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public abstract void appendTo(StringBuffer paramStringBuffer, Calendar paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static abstract interface NumberRule
/*      */     extends FastDateFormat.Rule
/*      */   {
/*      */     public abstract void appendTo(StringBuffer paramStringBuffer, int paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class CharacterLiteral
/*      */     implements FastDateFormat.Rule
/*      */   {
/*      */     private final char mValue;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     CharacterLiteral(char value)
/*      */     {
/* 1078 */       this.mValue = value;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public int estimateLength()
/*      */     {
/* 1085 */       return 1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar)
/*      */     {
/* 1092 */       buffer.append(this.mValue);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class StringLiteral
/*      */     implements FastDateFormat.Rule
/*      */   {
/*      */     private final String mValue;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     StringLiteral(String value)
/*      */     {
/* 1109 */       this.mValue = value;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public int estimateLength()
/*      */     {
/* 1116 */       return this.mValue.length();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar)
/*      */     {
/* 1123 */       buffer.append(this.mValue);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class TextField
/*      */     implements FastDateFormat.Rule
/*      */   {
/*      */     private final int mField;
/*      */     
/*      */ 
/*      */     private final String[] mValues;
/*      */     
/*      */ 
/*      */ 
/*      */     TextField(int field, String[] values)
/*      */     {
/* 1142 */       this.mField = field;
/* 1143 */       this.mValues = values;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public int estimateLength()
/*      */     {
/* 1150 */       int max = 0;
/* 1151 */       int i = this.mValues.length; for (;;) { i--; if (i < 0) break;
/* 1152 */         int len = this.mValues[i].length();
/* 1153 */         if (len > max) {
/* 1154 */           max = len;
/*      */         }
/*      */       }
/* 1157 */       return max;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar)
/*      */     {
/* 1164 */       buffer.append(this.mValues[calendar.get(this.mField)]);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static class UnpaddedNumberField
/*      */     implements FastDateFormat.NumberRule
/*      */   {
/* 1172 */     static final UnpaddedNumberField INSTANCE_YEAR = new UnpaddedNumberField(1);
/*      */     
/*      */ 
/*      */ 
/*      */     private final int mField;
/*      */     
/*      */ 
/*      */ 
/*      */     UnpaddedNumberField(int field)
/*      */     {
/* 1182 */       this.mField = field;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public int estimateLength()
/*      */     {
/* 1189 */       return 4;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar)
/*      */     {
/* 1196 */       appendTo(buffer, calendar.get(this.mField));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public final void appendTo(StringBuffer buffer, int value)
/*      */     {
/* 1203 */       if (value < 10) {
/* 1204 */         buffer.append((char)(value + 48));
/* 1205 */       } else if (value < 100) {
/* 1206 */         buffer.append((char)(value / 10 + 48));
/* 1207 */         buffer.append((char)(value % 10 + 48));
/*      */       } else {
/* 1209 */         buffer.append(Integer.toString(value));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static class UnpaddedMonthField
/*      */     implements FastDateFormat.NumberRule
/*      */   {
/* 1218 */     static final UnpaddedMonthField INSTANCE = new UnpaddedMonthField();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public int estimateLength()
/*      */     {
/* 1232 */       return 2;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar)
/*      */     {
/* 1239 */       appendTo(buffer, calendar.get(2) + 1);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public final void appendTo(StringBuffer buffer, int value)
/*      */     {
/* 1246 */       if (value < 10) {
/* 1247 */         buffer.append((char)(value + 48));
/*      */       } else {
/* 1249 */         buffer.append((char)(value / 10 + 48));
/* 1250 */         buffer.append((char)(value % 10 + 48));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static class PaddedNumberField
/*      */     implements FastDateFormat.NumberRule
/*      */   {
/*      */     private final int mField;
/*      */     
/*      */ 
/*      */     private final int mSize;
/*      */     
/*      */ 
/*      */ 
/*      */     PaddedNumberField(int field, int size)
/*      */     {
/* 1269 */       if (size < 3)
/*      */       {
/* 1271 */         throw new IllegalArgumentException();
/*      */       }
/* 1273 */       this.mField = field;
/* 1274 */       this.mSize = size;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public int estimateLength()
/*      */     {
/* 1281 */       return 4;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar)
/*      */     {
/* 1288 */       appendTo(buffer, calendar.get(this.mField));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public final void appendTo(StringBuffer buffer, int value)
/*      */     {
/* 1295 */       if (value < 100) {
/* 1296 */         int i = this.mSize; for (;;) { i--; if (i < 2) break;
/* 1297 */           buffer.append('0');
/*      */         }
/* 1299 */         buffer.append((char)(value / 10 + 48));
/* 1300 */         buffer.append((char)(value % 10 + 48));
/*      */       } else { int digits;
/*      */         int digits;
/* 1303 */         if (value < 1000) {
/* 1304 */           digits = 3;
/*      */         } else {
/* 1306 */           Validate.isTrue(value > -1, "Negative values should not be possible", value);
/* 1307 */           digits = Integer.toString(value).length();
/*      */         }
/* 1309 */         int i = this.mSize; for (;;) { i--; if (i < digits) break;
/* 1310 */           buffer.append('0');
/*      */         }
/* 1312 */         buffer.append(Integer.toString(value));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class TwoDigitNumberField
/*      */     implements FastDateFormat.NumberRule
/*      */   {
/*      */     private final int mField;
/*      */     
/*      */ 
/*      */ 
/*      */     TwoDigitNumberField(int field)
/*      */     {
/* 1329 */       this.mField = field;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public int estimateLength()
/*      */     {
/* 1336 */       return 2;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar)
/*      */     {
/* 1343 */       appendTo(buffer, calendar.get(this.mField));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public final void appendTo(StringBuffer buffer, int value)
/*      */     {
/* 1350 */       if (value < 100) {
/* 1351 */         buffer.append((char)(value / 10 + 48));
/* 1352 */         buffer.append((char)(value % 10 + 48));
/*      */       } else {
/* 1354 */         buffer.append(Integer.toString(value));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static class TwoDigitYearField
/*      */     implements FastDateFormat.NumberRule
/*      */   {
/* 1363 */     static final TwoDigitYearField INSTANCE = new TwoDigitYearField();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public int estimateLength()
/*      */     {
/* 1376 */       return 2;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar)
/*      */     {
/* 1383 */       appendTo(buffer, calendar.get(1) % 100);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public final void appendTo(StringBuffer buffer, int value)
/*      */     {
/* 1390 */       buffer.append((char)(value / 10 + 48));
/* 1391 */       buffer.append((char)(value % 10 + 48));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static class TwoDigitMonthField
/*      */     implements FastDateFormat.NumberRule
/*      */   {
/* 1399 */     static final TwoDigitMonthField INSTANCE = new TwoDigitMonthField();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public int estimateLength()
/*      */     {
/* 1412 */       return 2;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar)
/*      */     {
/* 1419 */       appendTo(buffer, calendar.get(2) + 1);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public final void appendTo(StringBuffer buffer, int value)
/*      */     {
/* 1426 */       buffer.append((char)(value / 10 + 48));
/* 1427 */       buffer.append((char)(value % 10 + 48));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class TwelveHourField
/*      */     implements FastDateFormat.NumberRule
/*      */   {
/*      */     private final FastDateFormat.NumberRule mRule;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     TwelveHourField(FastDateFormat.NumberRule rule)
/*      */     {
/* 1444 */       this.mRule = rule;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public int estimateLength()
/*      */     {
/* 1451 */       return this.mRule.estimateLength();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar)
/*      */     {
/* 1458 */       int value = calendar.get(10);
/* 1459 */       if (value == 0) {
/* 1460 */         value = calendar.getLeastMaximum(10) + 1;
/*      */       }
/* 1462 */       this.mRule.appendTo(buffer, value);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void appendTo(StringBuffer buffer, int value)
/*      */     {
/* 1469 */       this.mRule.appendTo(buffer, value);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class TwentyFourHourField
/*      */     implements FastDateFormat.NumberRule
/*      */   {
/*      */     private final FastDateFormat.NumberRule mRule;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     TwentyFourHourField(FastDateFormat.NumberRule rule)
/*      */     {
/* 1486 */       this.mRule = rule;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public int estimateLength()
/*      */     {
/* 1493 */       return this.mRule.estimateLength();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar)
/*      */     {
/* 1500 */       int value = calendar.get(11);
/* 1501 */       if (value == 0) {
/* 1502 */         value = calendar.getMaximum(11) + 1;
/*      */       }
/* 1504 */       this.mRule.appendTo(buffer, value);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void appendTo(StringBuffer buffer, int value)
/*      */     {
/* 1511 */       this.mRule.appendTo(buffer, value);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static class TimeZoneNameRule
/*      */     implements FastDateFormat.Rule
/*      */   {
/*      */     private final TimeZone mTimeZone;
/*      */     
/*      */     private final boolean mTimeZoneForced;
/*      */     
/*      */     private final Locale mLocale;
/*      */     
/*      */     private final int mStyle;
/*      */     
/*      */     private final String mStandard;
/*      */     
/*      */     private final String mDaylight;
/*      */     
/*      */ 
/*      */     TimeZoneNameRule(TimeZone timeZone, boolean timeZoneForced, Locale locale, int style)
/*      */     {
/* 1535 */       this.mTimeZone = timeZone;
/* 1536 */       this.mTimeZoneForced = timeZoneForced;
/* 1537 */       this.mLocale = locale;
/* 1538 */       this.mStyle = style;
/*      */       
/* 1540 */       if (timeZoneForced) {
/* 1541 */         this.mStandard = FastDateFormat.getTimeZoneDisplay(timeZone, false, style, locale);
/* 1542 */         this.mDaylight = FastDateFormat.getTimeZoneDisplay(timeZone, true, style, locale);
/*      */       } else {
/* 1544 */         this.mStandard = null;
/* 1545 */         this.mDaylight = null;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public int estimateLength()
/*      */     {
/* 1553 */       if (this.mTimeZoneForced)
/* 1554 */         return Math.max(this.mStandard.length(), this.mDaylight.length());
/* 1555 */       if (this.mStyle == 0) {
/* 1556 */         return 4;
/*      */       }
/* 1558 */       return 40;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar)
/*      */     {
/* 1566 */       if (this.mTimeZoneForced) {
/* 1567 */         if ((this.mTimeZone.useDaylightTime()) && (calendar.get(16) != 0)) {
/* 1568 */           buffer.append(this.mDaylight);
/*      */         } else {
/* 1570 */           buffer.append(this.mStandard);
/*      */         }
/*      */       } else {
/* 1573 */         TimeZone timeZone = calendar.getTimeZone();
/* 1574 */         if ((timeZone.useDaylightTime()) && (calendar.get(16) != 0)) {
/* 1575 */           buffer.append(FastDateFormat.getTimeZoneDisplay(timeZone, true, this.mStyle, this.mLocale));
/*      */         } else {
/* 1577 */           buffer.append(FastDateFormat.getTimeZoneDisplay(timeZone, false, this.mStyle, this.mLocale));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static class TimeZoneNumberRule
/*      */     implements FastDateFormat.Rule
/*      */   {
/* 1588 */     static final TimeZoneNumberRule INSTANCE_COLON = new TimeZoneNumberRule(true);
/* 1589 */     static final TimeZoneNumberRule INSTANCE_NO_COLON = new TimeZoneNumberRule(false);
/*      */     
/*      */ 
/*      */ 
/*      */     final boolean mColon;
/*      */     
/*      */ 
/*      */ 
/*      */     TimeZoneNumberRule(boolean colon)
/*      */     {
/* 1599 */       this.mColon = colon;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public int estimateLength()
/*      */     {
/* 1606 */       return 5;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar)
/*      */     {
/* 1613 */       int offset = calendar.get(15) + calendar.get(16);
/*      */       
/* 1615 */       if (offset < 0) {
/* 1616 */         buffer.append('-');
/* 1617 */         offset = -offset;
/*      */       } else {
/* 1619 */         buffer.append('+');
/*      */       }
/*      */       
/* 1622 */       int hours = offset / 3600000;
/* 1623 */       buffer.append((char)(hours / 10 + 48));
/* 1624 */       buffer.append((char)(hours % 10 + 48));
/*      */       
/* 1626 */       if (this.mColon) {
/* 1627 */         buffer.append(':');
/*      */       }
/*      */       
/* 1630 */       int minutes = offset / 60000 - 60 * hours;
/* 1631 */       buffer.append((char)(minutes / 10 + 48));
/* 1632 */       buffer.append((char)(minutes % 10 + 48));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class TimeZoneDisplayKey
/*      */   {
/*      */     private final TimeZone mTimeZone;
/*      */     
/*      */ 
/*      */ 
/*      */     private final int mStyle;
/*      */     
/*      */ 
/*      */ 
/*      */     private final Locale mLocale;
/*      */     
/*      */ 
/*      */ 
/*      */     TimeZoneDisplayKey(TimeZone timeZone, boolean daylight, int style, Locale locale)
/*      */     {
/* 1655 */       this.mTimeZone = timeZone;
/* 1656 */       if (daylight) {
/* 1657 */         style |= 0x80000000;
/*      */       }
/* 1659 */       this.mStyle = style;
/* 1660 */       this.mLocale = locale;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public int hashCode()
/*      */     {
/* 1667 */       return this.mStyle * 31 + this.mLocale.hashCode();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public boolean equals(Object obj)
/*      */     {
/* 1674 */       if (this == obj) {
/* 1675 */         return true;
/*      */       }
/* 1677 */       if ((obj instanceof TimeZoneDisplayKey)) {
/* 1678 */         TimeZoneDisplayKey other = (TimeZoneDisplayKey)obj;
/* 1679 */         return (this.mTimeZone.equals(other.mTimeZone)) && (this.mStyle == other.mStyle) && (this.mLocale.equals(other.mLocale));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1684 */       return false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class Pair
/*      */   {
/*      */     private final Object mObj1;
/*      */     
/*      */ 
/*      */ 
/*      */     private final Object mObj2;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public Pair(Object obj1, Object obj2)
/*      */     {
/* 1705 */       this.mObj1 = obj1;
/* 1706 */       this.mObj2 = obj2;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public boolean equals(Object obj)
/*      */     {
/* 1713 */       if (this == obj) {
/* 1714 */         return true;
/*      */       }
/*      */       
/* 1717 */       if (!(obj instanceof Pair)) {
/* 1718 */         return false;
/*      */       }
/*      */       
/* 1721 */       Pair key = (Pair)obj;
/*      */       
/* 1723 */       return (this.mObj1 == null ? key.mObj1 == null : this.mObj1.equals(key.mObj1)) && (this.mObj2 == null ? key.mObj2 == null : this.mObj2.equals(key.mObj2));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public int hashCode()
/*      */     {
/* 1734 */       return (this.mObj1 == null ? 0 : this.mObj1.hashCode()) + (this.mObj2 == null ? 0 : this.mObj2.hashCode());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public String toString()
/*      */     {
/* 1743 */       return "[" + this.mObj1 + ':' + this.mObj2 + ']';
/*      */     }
/*      */   }
/*      */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-lang-2.4.jar!\org\apache\commons\lang\time\FastDateFormat.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */