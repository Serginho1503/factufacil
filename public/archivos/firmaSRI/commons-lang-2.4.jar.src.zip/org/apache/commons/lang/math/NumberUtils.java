/*      */ package org.apache.commons.lang.math;
/*      */ 
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import org.apache.commons.lang.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class NumberUtils
/*      */ {
/*   41 */   public static final Long LONG_ZERO = new Long(0L);
/*      */   
/*   43 */   public static final Long LONG_ONE = new Long(1L);
/*      */   
/*   45 */   public static final Long LONG_MINUS_ONE = new Long(-1L);
/*      */   
/*   47 */   public static final Integer INTEGER_ZERO = new Integer(0);
/*      */   
/*   49 */   public static final Integer INTEGER_ONE = new Integer(1);
/*      */   
/*   51 */   public static final Integer INTEGER_MINUS_ONE = new Integer(-1);
/*      */   
/*   53 */   public static final Short SHORT_ZERO = new Short((short)0);
/*      */   
/*   55 */   public static final Short SHORT_ONE = new Short((short)1);
/*      */   
/*   57 */   public static final Short SHORT_MINUS_ONE = new Short((short)-1);
/*      */   
/*   59 */   public static final Byte BYTE_ZERO = new Byte((byte)0);
/*      */   
/*   61 */   public static final Byte BYTE_ONE = new Byte((byte)1);
/*      */   
/*   63 */   public static final Byte BYTE_MINUS_ONE = new Byte((byte)-1);
/*      */   
/*   65 */   public static final Double DOUBLE_ZERO = new Double(0.0D);
/*      */   
/*   67 */   public static final Double DOUBLE_ONE = new Double(1.0D);
/*      */   
/*   69 */   public static final Double DOUBLE_MINUS_ONE = new Double(-1.0D);
/*      */   
/*   71 */   public static final Float FLOAT_ZERO = new Float(0.0F);
/*      */   
/*   73 */   public static final Float FLOAT_ONE = new Float(1.0F);
/*      */   
/*   75 */   public static final Float FLOAT_MINUS_ONE = new Float(-1.0F);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public static int stringToInt(String str)
/*      */   {
/*  108 */     return toInt(str);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int toInt(String str)
/*      */   {
/*  129 */     return toInt(str, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public static int stringToInt(String str, int defaultValue)
/*      */   {
/*  151 */     return toInt(str, defaultValue);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int toInt(String str, int defaultValue)
/*      */   {
/*  172 */     if (str == null) {
/*  173 */       return defaultValue;
/*      */     }
/*      */     try {
/*  176 */       return Integer.parseInt(str);
/*      */     } catch (NumberFormatException nfe) {}
/*  178 */     return defaultValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static long toLong(String str)
/*      */   {
/*  200 */     return toLong(str, 0L);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static long toLong(String str, long defaultValue)
/*      */   {
/*  221 */     if (str == null) {
/*  222 */       return defaultValue;
/*      */     }
/*      */     try {
/*  225 */       return Long.parseLong(str);
/*      */     } catch (NumberFormatException nfe) {}
/*  227 */     return defaultValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static float toFloat(String str)
/*      */   {
/*  250 */     return toFloat(str, 0.0F);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static float toFloat(String str, float defaultValue)
/*      */   {
/*  273 */     if (str == null) {
/*  274 */       return defaultValue;
/*      */     }
/*      */     try {
/*  277 */       return Float.parseFloat(str);
/*      */     } catch (NumberFormatException nfe) {}
/*  279 */     return defaultValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static double toDouble(String str)
/*      */   {
/*  302 */     return toDouble(str, 0.0D);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static double toDouble(String str, double defaultValue)
/*      */   {
/*  325 */     if (str == null) {
/*  326 */       return defaultValue;
/*      */     }
/*      */     try {
/*  329 */       return Double.parseDouble(str);
/*      */     } catch (NumberFormatException nfe) {}
/*  331 */     return defaultValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Number createNumber(String str)
/*      */     throws NumberFormatException
/*      */   {
/*  398 */     if (str == null) {
/*  399 */       return null;
/*      */     }
/*  401 */     if (StringUtils.isBlank(str)) {
/*  402 */       throw new NumberFormatException("A blank string is not a valid number");
/*      */     }
/*  404 */     if (str.startsWith("--"))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  409 */       return null;
/*      */     }
/*  411 */     if ((str.startsWith("0x")) || (str.startsWith("-0x"))) {
/*  412 */       return createInteger(str);
/*      */     }
/*  414 */     char lastChar = str.charAt(str.length() - 1);
/*      */     
/*      */ 
/*      */ 
/*  418 */     int decPos = str.indexOf('.');
/*  419 */     int expPos = str.indexOf('e') + str.indexOf('E') + 1;
/*      */     String mant;
/*  421 */     String mant; String dec; if (decPos > -1) { String dec;
/*      */       String dec;
/*  423 */       if (expPos > -1) {
/*  424 */         if (expPos < decPos) {
/*  425 */           throw new NumberFormatException(str + " is not a valid number.");
/*      */         }
/*  427 */         dec = str.substring(decPos + 1, expPos);
/*      */       } else {
/*  429 */         dec = str.substring(decPos + 1);
/*      */       }
/*  431 */       mant = str.substring(0, decPos);
/*      */     } else { String mant;
/*  433 */       if (expPos > -1) {
/*  434 */         mant = str.substring(0, expPos);
/*      */       } else {
/*  436 */         mant = str;
/*      */       }
/*  438 */       dec = null;
/*      */     }
/*  440 */     if (!Character.isDigit(lastChar)) { String exp;
/*  441 */       String exp; if ((expPos > -1) && (expPos < str.length() - 1)) {
/*  442 */         exp = str.substring(expPos + 1, str.length() - 1);
/*      */       } else {
/*  444 */         exp = null;
/*      */       }
/*      */       
/*  447 */       String numeric = str.substring(0, str.length() - 1);
/*  448 */       boolean allZeros = (isAllZeros(mant)) && (isAllZeros(exp));
/*  449 */       switch (lastChar) {
/*      */       case 'L': 
/*      */       case 'l': 
/*  452 */         if ((dec == null) && (exp == null) && (((numeric.charAt(0) == '-') && (isDigits(numeric.substring(1)))) || (isDigits(numeric))))
/*      */         {
/*      */           try
/*      */           {
/*  456 */             return createLong(numeric);
/*      */           }
/*      */           catch (NumberFormatException nfe)
/*      */           {
/*  460 */             return createBigInteger(numeric);
/*      */           }
/*      */         }
/*  463 */         throw new NumberFormatException(str + " is not a valid number.");
/*      */       case 'F': 
/*      */       case 'f': 
/*      */         try {
/*  467 */           Float f = createFloat(numeric);
/*  468 */           if ((!f.isInfinite()) && ((f.floatValue() != 0.0F) || (allZeros)))
/*      */           {
/*      */ 
/*  471 */             return f;
/*      */           }
/*      */         }
/*      */         catch (NumberFormatException nfe) {}
/*      */       
/*      */ 
/*      */       case 'D': 
/*      */       case 'd': 
/*      */         try
/*      */         {
/*  481 */           Double d = createDouble(numeric);
/*  482 */           if ((!d.isInfinite()) && ((d.floatValue() != 0.0D) || (allZeros))) {
/*  483 */             return d;
/*      */           }
/*      */         }
/*      */         catch (NumberFormatException nfe) {}
/*      */         try
/*      */         {
/*  489 */           return createBigDecimal(numeric);
/*      */         }
/*      */         catch (NumberFormatException e) {}
/*      */       }
/*      */       
/*      */       
/*  495 */       throw new NumberFormatException(str + " is not a valid number.");
/*      */     }
/*      */     
/*      */     String exp;
/*      */     
/*      */     String exp;
/*  501 */     if ((expPos > -1) && (expPos < str.length() - 1)) {
/*  502 */       exp = str.substring(expPos + 1, str.length());
/*      */     } else {
/*  504 */       exp = null;
/*      */     }
/*  506 */     if ((dec == null) && (exp == null)) {
/*      */       try
/*      */       {
/*  509 */         return createInteger(str);
/*      */       }
/*      */       catch (NumberFormatException nfe)
/*      */       {
/*      */         try {
/*  514 */           return createLong(str);
/*      */         }
/*      */         catch (NumberFormatException nfe)
/*      */         {
/*  518 */           return createBigInteger(str);
/*      */         }
/*      */       }
/*      */     }
/*  522 */     boolean allZeros = (isAllZeros(mant)) && (isAllZeros(exp));
/*      */     try {
/*  524 */       Float f = createFloat(str);
/*  525 */       if ((!f.isInfinite()) && ((f.floatValue() != 0.0F) || (allZeros))) {
/*  526 */         return f;
/*      */       }
/*      */     }
/*      */     catch (NumberFormatException nfe) {}
/*      */     try
/*      */     {
/*  532 */       Double d = createDouble(str);
/*  533 */       if ((!d.isInfinite()) && ((d.doubleValue() != 0.0D) || (allZeros))) {
/*  534 */         return d;
/*      */       }
/*      */     }
/*      */     catch (NumberFormatException nfe) {}
/*      */     
/*      */ 
/*  540 */     return createBigDecimal(str);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static boolean isAllZeros(String str)
/*      */   {
/*  555 */     if (str == null) {
/*  556 */       return true;
/*      */     }
/*  558 */     for (int i = str.length() - 1; i >= 0; i--) {
/*  559 */       if (str.charAt(i) != '0') {
/*  560 */         return false;
/*      */       }
/*      */     }
/*  563 */     return str.length() > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Float createFloat(String str)
/*      */   {
/*  577 */     if (str == null) {
/*  578 */       return null;
/*      */     }
/*  580 */     return Float.valueOf(str);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Double createDouble(String str)
/*      */   {
/*  593 */     if (str == null) {
/*  594 */       return null;
/*      */     }
/*  596 */     return Double.valueOf(str);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Integer createInteger(String str)
/*      */   {
/*  610 */     if (str == null) {
/*  611 */       return null;
/*      */     }
/*      */     
/*  614 */     return Integer.decode(str);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Long createLong(String str)
/*      */   {
/*  627 */     if (str == null) {
/*  628 */       return null;
/*      */     }
/*  630 */     return Long.valueOf(str);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static BigInteger createBigInteger(String str)
/*      */   {
/*  643 */     if (str == null) {
/*  644 */       return null;
/*      */     }
/*  646 */     return new BigInteger(str);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static BigDecimal createBigDecimal(String str)
/*      */   {
/*  659 */     if (str == null) {
/*  660 */       return null;
/*      */     }
/*      */     
/*  663 */     if (StringUtils.isBlank(str)) {
/*  664 */       throw new NumberFormatException("A blank string is not a valid number");
/*      */     }
/*  666 */     return new BigDecimal(str);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static long min(long[] array)
/*      */   {
/*  681 */     if (array == null)
/*  682 */       throw new IllegalArgumentException("The Array must not be null");
/*  683 */     if (array.length == 0) {
/*  684 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */     
/*      */ 
/*  688 */     long min = array[0];
/*  689 */     for (int i = 1; i < array.length; i++) {
/*  690 */       if (array[i] < min) {
/*  691 */         min = array[i];
/*      */       }
/*      */     }
/*      */     
/*  695 */     return min;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int min(int[] array)
/*      */   {
/*  708 */     if (array == null)
/*  709 */       throw new IllegalArgumentException("The Array must not be null");
/*  710 */     if (array.length == 0) {
/*  711 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */     
/*      */ 
/*  715 */     int min = array[0];
/*  716 */     for (int j = 1; j < array.length; j++) {
/*  717 */       if (array[j] < min) {
/*  718 */         min = array[j];
/*      */       }
/*      */     }
/*      */     
/*  722 */     return min;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static short min(short[] array)
/*      */   {
/*  735 */     if (array == null)
/*  736 */       throw new IllegalArgumentException("The Array must not be null");
/*  737 */     if (array.length == 0) {
/*  738 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */     
/*      */ 
/*  742 */     short min = array[0];
/*  743 */     for (int i = 1; i < array.length; i++) {
/*  744 */       if (array[i] < min) {
/*  745 */         min = array[i];
/*      */       }
/*      */     }
/*      */     
/*  749 */     return min;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte min(byte[] array)
/*      */   {
/*  762 */     if (array == null)
/*  763 */       throw new IllegalArgumentException("The Array must not be null");
/*  764 */     if (array.length == 0) {
/*  765 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */     
/*      */ 
/*  769 */     byte min = array[0];
/*  770 */     for (int i = 1; i < array.length; i++) {
/*  771 */       if (array[i] < min) {
/*  772 */         min = array[i];
/*      */       }
/*      */     }
/*      */     
/*  776 */     return min;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static double min(double[] array)
/*      */   {
/*  790 */     if (array == null)
/*  791 */       throw new IllegalArgumentException("The Array must not be null");
/*  792 */     if (array.length == 0) {
/*  793 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */     
/*      */ 
/*  797 */     double min = array[0];
/*  798 */     for (int i = 1; i < array.length; i++) {
/*  799 */       if (Double.isNaN(array[i])) {
/*  800 */         return NaN.0D;
/*      */       }
/*  802 */       if (array[i] < min) {
/*  803 */         min = array[i];
/*      */       }
/*      */     }
/*      */     
/*  807 */     return min;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static float min(float[] array)
/*      */   {
/*  821 */     if (array == null)
/*  822 */       throw new IllegalArgumentException("The Array must not be null");
/*  823 */     if (array.length == 0) {
/*  824 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */     
/*      */ 
/*  828 */     float min = array[0];
/*  829 */     for (int i = 1; i < array.length; i++) {
/*  830 */       if (Float.isNaN(array[i])) {
/*  831 */         return NaN.0F;
/*      */       }
/*  833 */       if (array[i] < min) {
/*  834 */         min = array[i];
/*      */       }
/*      */     }
/*      */     
/*  838 */     return min;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static long max(long[] array)
/*      */   {
/*  853 */     if (array == null)
/*  854 */       throw new IllegalArgumentException("The Array must not be null");
/*  855 */     if (array.length == 0) {
/*  856 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */     
/*      */ 
/*  860 */     long max = array[0];
/*  861 */     for (int j = 1; j < array.length; j++) {
/*  862 */       if (array[j] > max) {
/*  863 */         max = array[j];
/*      */       }
/*      */     }
/*      */     
/*  867 */     return max;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int max(int[] array)
/*      */   {
/*  880 */     if (array == null)
/*  881 */       throw new IllegalArgumentException("The Array must not be null");
/*  882 */     if (array.length == 0) {
/*  883 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */     
/*      */ 
/*  887 */     int max = array[0];
/*  888 */     for (int j = 1; j < array.length; j++) {
/*  889 */       if (array[j] > max) {
/*  890 */         max = array[j];
/*      */       }
/*      */     }
/*      */     
/*  894 */     return max;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static short max(short[] array)
/*      */   {
/*  907 */     if (array == null)
/*  908 */       throw new IllegalArgumentException("The Array must not be null");
/*  909 */     if (array.length == 0) {
/*  910 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */     
/*      */ 
/*  914 */     short max = array[0];
/*  915 */     for (int i = 1; i < array.length; i++) {
/*  916 */       if (array[i] > max) {
/*  917 */         max = array[i];
/*      */       }
/*      */     }
/*      */     
/*  921 */     return max;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte max(byte[] array)
/*      */   {
/*  934 */     if (array == null)
/*  935 */       throw new IllegalArgumentException("The Array must not be null");
/*  936 */     if (array.length == 0) {
/*  937 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */     
/*      */ 
/*  941 */     byte max = array[0];
/*  942 */     for (int i = 1; i < array.length; i++) {
/*  943 */       if (array[i] > max) {
/*  944 */         max = array[i];
/*      */       }
/*      */     }
/*      */     
/*  948 */     return max;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static double max(double[] array)
/*      */   {
/*  962 */     if (array == null)
/*  963 */       throw new IllegalArgumentException("The Array must not be null");
/*  964 */     if (array.length == 0) {
/*  965 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */     
/*      */ 
/*  969 */     double max = array[0];
/*  970 */     for (int j = 1; j < array.length; j++) {
/*  971 */       if (Double.isNaN(array[j])) {
/*  972 */         return NaN.0D;
/*      */       }
/*  974 */       if (array[j] > max) {
/*  975 */         max = array[j];
/*      */       }
/*      */     }
/*      */     
/*  979 */     return max;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static float max(float[] array)
/*      */   {
/*  993 */     if (array == null)
/*  994 */       throw new IllegalArgumentException("The Array must not be null");
/*  995 */     if (array.length == 0) {
/*  996 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */     
/*      */ 
/* 1000 */     float max = array[0];
/* 1001 */     for (int j = 1; j < array.length; j++) {
/* 1002 */       if (Float.isNaN(array[j])) {
/* 1003 */         return NaN.0F;
/*      */       }
/* 1005 */       if (array[j] > max) {
/* 1006 */         max = array[j];
/*      */       }
/*      */     }
/*      */     
/* 1010 */     return max;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static long min(long a, long b, long c)
/*      */   {
/* 1024 */     if (b < a) {
/* 1025 */       a = b;
/*      */     }
/* 1027 */     if (c < a) {
/* 1028 */       a = c;
/*      */     }
/* 1030 */     return a;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int min(int a, int b, int c)
/*      */   {
/* 1042 */     if (b < a) {
/* 1043 */       a = b;
/*      */     }
/* 1045 */     if (c < a) {
/* 1046 */       a = c;
/*      */     }
/* 1048 */     return a;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static short min(short a, short b, short c)
/*      */   {
/* 1060 */     if (b < a) {
/* 1061 */       a = b;
/*      */     }
/* 1063 */     if (c < a) {
/* 1064 */       a = c;
/*      */     }
/* 1066 */     return a;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte min(byte a, byte b, byte c)
/*      */   {
/* 1078 */     if (b < a) {
/* 1079 */       a = b;
/*      */     }
/* 1081 */     if (c < a) {
/* 1082 */       a = c;
/*      */     }
/* 1084 */     return a;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static double min(double a, double b, double c)
/*      */   {
/* 1100 */     return Math.min(Math.min(a, b), c);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static float min(float a, float b, float c)
/*      */   {
/* 1116 */     return Math.min(Math.min(a, b), c);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static long max(long a, long b, long c)
/*      */   {
/* 1130 */     if (b > a) {
/* 1131 */       a = b;
/*      */     }
/* 1133 */     if (c > a) {
/* 1134 */       a = c;
/*      */     }
/* 1136 */     return a;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int max(int a, int b, int c)
/*      */   {
/* 1148 */     if (b > a) {
/* 1149 */       a = b;
/*      */     }
/* 1151 */     if (c > a) {
/* 1152 */       a = c;
/*      */     }
/* 1154 */     return a;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static short max(short a, short b, short c)
/*      */   {
/* 1166 */     if (b > a) {
/* 1167 */       a = b;
/*      */     }
/* 1169 */     if (c > a) {
/* 1170 */       a = c;
/*      */     }
/* 1172 */     return a;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte max(byte a, byte b, byte c)
/*      */   {
/* 1184 */     if (b > a) {
/* 1185 */       a = b;
/*      */     }
/* 1187 */     if (c > a) {
/* 1188 */       a = c;
/*      */     }
/* 1190 */     return a;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static double max(double a, double b, double c)
/*      */   {
/* 1206 */     return Math.max(Math.max(a, b), c);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static float max(float a, float b, float c)
/*      */   {
/* 1222 */     return Math.max(Math.max(a, b), c);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int compare(double lhs, double rhs)
/*      */   {
/* 1261 */     if (lhs < rhs) {
/* 1262 */       return -1;
/*      */     }
/* 1264 */     if (lhs > rhs) {
/* 1265 */       return 1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1271 */     long lhsBits = Double.doubleToLongBits(lhs);
/* 1272 */     long rhsBits = Double.doubleToLongBits(rhs);
/* 1273 */     if (lhsBits == rhsBits) {
/* 1274 */       return 0;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1282 */     if (lhsBits < rhsBits) {
/* 1283 */       return -1;
/*      */     }
/* 1285 */     return 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int compare(float lhs, float rhs)
/*      */   {
/* 1322 */     if (lhs < rhs) {
/* 1323 */       return -1;
/*      */     }
/* 1325 */     if (lhs > rhs) {
/* 1326 */       return 1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1332 */     int lhsBits = Float.floatToIntBits(lhs);
/* 1333 */     int rhsBits = Float.floatToIntBits(rhs);
/* 1334 */     if (lhsBits == rhsBits) {
/* 1335 */       return 0;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1343 */     if (lhsBits < rhsBits) {
/* 1344 */       return -1;
/*      */     }
/* 1346 */     return 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isDigits(String str)
/*      */   {
/* 1362 */     if (StringUtils.isEmpty(str)) {
/* 1363 */       return false;
/*      */     }
/* 1365 */     for (int i = 0; i < str.length(); i++) {
/* 1366 */       if (!Character.isDigit(str.charAt(i))) {
/* 1367 */         return false;
/*      */       }
/*      */     }
/* 1370 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isNumber(String str)
/*      */   {
/* 1387 */     if (StringUtils.isEmpty(str)) {
/* 1388 */       return false;
/*      */     }
/* 1390 */     char[] chars = str.toCharArray();
/* 1391 */     int sz = chars.length;
/* 1392 */     boolean hasExp = false;
/* 1393 */     boolean hasDecPoint = false;
/* 1394 */     boolean allowSigns = false;
/* 1395 */     boolean foundDigit = false;
/*      */     
/* 1397 */     int start = chars[0] == '-' ? 1 : 0;
/* 1398 */     if ((sz > start + 1) && 
/* 1399 */       (chars[start] == '0') && (chars[(start + 1)] == 'x')) {
/* 1400 */       int i = start + 2;
/* 1401 */       if (i == sz) {
/* 1402 */         return false;
/*      */       }
/* 1405 */       for (; 
/* 1405 */           i < chars.length; i++) {
/* 1406 */         if (((chars[i] < '0') || (chars[i] > '9')) && ((chars[i] < 'a') || (chars[i] > 'f')) && ((chars[i] < 'A') || (chars[i] > 'F')))
/*      */         {
/*      */ 
/* 1409 */           return false;
/*      */         }
/*      */       }
/* 1412 */       return true;
/*      */     }
/*      */     
/* 1415 */     sz--;
/*      */     
/* 1417 */     int i = start;
/*      */     
/*      */ 
/* 1420 */     while ((i < sz) || ((i < sz + 1) && (allowSigns) && (!foundDigit))) {
/* 1421 */       if ((chars[i] >= '0') && (chars[i] <= '9')) {
/* 1422 */         foundDigit = true;
/* 1423 */         allowSigns = false;
/*      */       }
/* 1425 */       else if (chars[i] == '.') {
/* 1426 */         if ((hasDecPoint) || (hasExp))
/*      */         {
/* 1428 */           return false;
/*      */         }
/* 1430 */         hasDecPoint = true;
/* 1431 */       } else if ((chars[i] == 'e') || (chars[i] == 'E'))
/*      */       {
/* 1433 */         if (hasExp)
/*      */         {
/* 1435 */           return false;
/*      */         }
/* 1437 */         if (!foundDigit) {
/* 1438 */           return false;
/*      */         }
/* 1440 */         hasExp = true;
/* 1441 */         allowSigns = true;
/* 1442 */       } else if ((chars[i] == '+') || (chars[i] == '-')) {
/* 1443 */         if (!allowSigns) {
/* 1444 */           return false;
/*      */         }
/* 1446 */         allowSigns = false;
/* 1447 */         foundDigit = false;
/*      */       } else {
/* 1449 */         return false;
/*      */       }
/* 1451 */       i++;
/*      */     }
/* 1453 */     if (i < chars.length) {
/* 1454 */       if ((chars[i] >= '0') && (chars[i] <= '9'))
/*      */       {
/* 1456 */         return true;
/*      */       }
/* 1458 */       if ((chars[i] == 'e') || (chars[i] == 'E'))
/*      */       {
/* 1460 */         return false;
/*      */       }
/* 1462 */       if ((!allowSigns) && ((chars[i] == 'd') || (chars[i] == 'D') || (chars[i] == 'f') || (chars[i] == 'F')))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1467 */         return foundDigit;
/*      */       }
/* 1469 */       if ((chars[i] == 'l') || (chars[i] == 'L'))
/*      */       {
/*      */ 
/* 1472 */         return (foundDigit) && (!hasExp);
/*      */       }
/*      */       
/* 1475 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 1479 */     return (!allowSigns) && (foundDigit);
/*      */   }
/*      */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-lang-2.4.jar!\org\apache\commons\lang\math\NumberUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */