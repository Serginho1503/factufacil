/*     */ package org.apache.commons.lang.enum;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import org.apache.commons.lang.ClassUtils;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ /**
/*     */  * @deprecated
/*     */  */
/*     */ public abstract class Enum
/*     */   implements Comparable, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -487045951170455942L;
/* 254 */   private static final Map EMPTY_MAP = Collections.unmodifiableMap(new HashMap(0));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 259 */   private static Map cEnumClasses = new WeakHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String iName;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final transient int iHashCode;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 279 */   protected transient String iToString = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class Entry
/*     */   {
/* 288 */     final Map map = new HashMap();
/*     */     
/*     */ 
/*     */ 
/* 292 */     final Map unmodifiableMap = Collections.unmodifiableMap(this.map);
/*     */     
/*     */ 
/*     */ 
/* 296 */     final List list = new ArrayList(25);
/*     */     
/*     */ 
/*     */ 
/* 300 */     final List unmodifiableList = Collections.unmodifiableList(this.list);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Enum(String name)
/*     */   {
/* 322 */     init(name);
/* 323 */     this.iName = name;
/* 324 */     this.iHashCode = (7 + getEnumClass().hashCode() + 3 * name.hashCode());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init(String name)
/*     */   {
/* 336 */     if (StringUtils.isEmpty(name)) {
/* 337 */       throw new IllegalArgumentException("The Enum name must not be empty or null");
/*     */     }
/*     */     
/* 340 */     Class enumClass = getEnumClass();
/* 341 */     if (enumClass == null) {
/* 342 */       throw new IllegalArgumentException("getEnumClass() must not be null");
/*     */     }
/* 344 */     Class cls = getClass();
/* 345 */     boolean ok = false;
/* 346 */     while ((cls != null) && (cls != Enum.class) && (cls != ValuedEnum.class)) {
/* 347 */       if (cls == enumClass) {
/* 348 */         ok = true;
/* 349 */         break;
/*     */       }
/* 351 */       cls = cls.getSuperclass();
/*     */     }
/* 353 */     if (!ok) {
/* 354 */       throw new IllegalArgumentException("getEnumClass() must return a superclass of this class");
/*     */     }
/*     */     
/*     */ 
/* 358 */     synchronized (Enum.class)
/*     */     {
/* 360 */       Entry entry = (Entry)cEnumClasses.get(enumClass);
/* 361 */       if (entry == null) {
/* 362 */         entry = createEntry(enumClass);
/* 363 */         Map myMap = new WeakHashMap();
/* 364 */         myMap.putAll(cEnumClasses);
/* 365 */         myMap.put(enumClass, entry);
/* 366 */         cEnumClasses = myMap;
/*     */       } }
/*     */     Entry entry;
/* 369 */     if (entry.map.containsKey(name)) {
/* 370 */       throw new IllegalArgumentException("The Enum name must be unique, '" + name + "' has already been added");
/*     */     }
/* 372 */     entry.map.put(name, this);
/* 373 */     entry.list.add(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object readResolve()
/*     */   {
/* 383 */     Entry entry = (Entry)cEnumClasses.get(getEnumClass());
/* 384 */     if (entry == null) {
/* 385 */       return null;
/*     */     }
/* 387 */     return entry.map.get(getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static Enum getEnum(Class enumClass, String name)
/*     */   {
/* 404 */     Entry entry = getEntry(enumClass);
/* 405 */     if (entry == null) {
/* 406 */       return null;
/*     */     }
/* 408 */     return (Enum)entry.map.get(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static Map getEnumMap(Class enumClass)
/*     */   {
/* 425 */     Entry entry = getEntry(enumClass);
/* 426 */     if (entry == null) {
/* 427 */       return EMPTY_MAP;
/*     */     }
/* 429 */     return entry.unmodifiableMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static List getEnumList(Class enumClass)
/*     */   {
/* 447 */     Entry entry = getEntry(enumClass);
/* 448 */     if (entry == null) {
/* 449 */       return Collections.EMPTY_LIST;
/*     */     }
/* 451 */     return entry.unmodifiableList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static Iterator iterator(Class enumClass)
/*     */   {
/* 469 */     return getEnumList(enumClass).iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Entry getEntry(Class enumClass)
/*     */   {
/* 480 */     if (enumClass == null) {
/* 481 */       throw new IllegalArgumentException("The Enum Class must not be null");
/*     */     }
/* 483 */     if (!Enum.class.isAssignableFrom(enumClass)) {
/* 484 */       throw new IllegalArgumentException("The Class must be a subclass of Enum");
/*     */     }
/* 486 */     Entry entry = (Entry)cEnumClasses.get(enumClass);
/* 487 */     return entry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Entry createEntry(Class enumClass)
/*     */   {
/* 499 */     Entry entry = new Entry();
/* 500 */     Class cls = enumClass.getSuperclass();
/* 501 */     while ((cls != null) && (cls != Enum.class) && (cls != ValuedEnum.class)) {
/* 502 */       Entry loopEntry = (Entry)cEnumClasses.get(cls);
/* 503 */       if (loopEntry != null) {
/* 504 */         entry.list.addAll(loopEntry.list);
/* 505 */         entry.map.putAll(loopEntry.map);
/* 506 */         break;
/*     */       }
/* 508 */       cls = cls.getSuperclass();
/*     */     }
/* 510 */     return entry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getName()
/*     */   {
/* 520 */     return this.iName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class getEnumClass()
/*     */   {
/* 534 */     return getClass();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean equals(Object other)
/*     */   {
/* 551 */     if (other == this)
/* 552 */       return true;
/* 553 */     if (other == null)
/* 554 */       return false;
/* 555 */     if (other.getClass() == getClass())
/*     */     {
/*     */ 
/*     */ 
/* 559 */       return this.iName.equals(((Enum)other).iName);
/*     */     }
/*     */     
/* 562 */     if (!other.getClass().getName().equals(getClass().getName())) {
/* 563 */       return false;
/*     */     }
/* 565 */     return this.iName.equals(getNameInOtherClassLoader(other));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int hashCode()
/*     */   {
/* 575 */     return this.iHashCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int compareTo(Object other)
/*     */   {
/* 595 */     if (other == this) {
/* 596 */       return 0;
/*     */     }
/* 598 */     if (other.getClass() != getClass()) {
/* 599 */       if (other.getClass().getName().equals(getClass().getName())) {
/* 600 */         return this.iName.compareTo(getNameInOtherClassLoader(other));
/*     */       }
/* 602 */       throw new ClassCastException("Different enum class '" + ClassUtils.getShortClassName(other.getClass()) + "'");
/*     */     }
/*     */     
/* 605 */     return this.iName.compareTo(((Enum)other).iName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getNameInOtherClassLoader(Object other)
/*     */   {
/*     */     try
/*     */     {
/* 616 */       Method mth = other.getClass().getMethod("getName", null);
/* 617 */       return (String)mth.invoke(other, null);
/*     */     }
/*     */     catch (NoSuchMethodException e) {}catch (IllegalAccessException e) {}catch (InvocationTargetException e) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 626 */     throw new IllegalStateException("This should not happen");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 637 */     if (this.iToString == null) {
/* 638 */       String shortName = ClassUtils.getShortClassName(getEnumClass());
/* 639 */       this.iToString = (shortName + "[" + getName() + "]");
/*     */     }
/* 641 */     return this.iToString;
/*     */   }
/*     */ }


/* Location:              D:\Projects\Docs\DocumPavel\testfirma\firmaSRI.jar!\commons-lang-2.4.jar!\org\apache\commons\lang\enum\Enum.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */